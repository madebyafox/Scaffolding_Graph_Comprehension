var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e26efc2f7fcfa7ae6bd278a00d199bc4",
  "created": "2017-11-21T10:13:28.7169362-08:00",
  "lastActivity": "2017-11-21T10:13:51.1589362-08:00",
  "pageViews": [
    {
      "id": "11212863cef68ac5a2adfce6bfe9b5d71d21b4ca",
      "startTime": "2017-11-21T10:13:28.7169362-08:00",
      "endTime": "2017-11-21T10:13:51.1589362-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 22442,
      "engagementTime": 22442,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 22442,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=90DXB",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8da56a75fe4525c3c8d75e996fbded33",
  "gdpr": false
}