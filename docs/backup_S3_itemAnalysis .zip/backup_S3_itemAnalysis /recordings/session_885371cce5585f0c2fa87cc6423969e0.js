var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e20a941c61d5f7312cb707fe4c737a3e",
  "created": "2017-11-30T10:16:17.6827156-08:00",
  "lastActivity": "2017-11-30T10:16:28.2457156-08:00",
  "pageViews": [
    {
      "id": "11301794b33e9995ccb5b5f88ba8dd939035bea1",
      "startTime": "2017-11-30T10:16:17.6827156-08:00",
      "endTime": "2017-11-30T10:16:28.2457156-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 10563,
      "engagementTime": 7908,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 10563,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=KBCXA",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "885371cce5585f0c2fa87cc6423969e0",
  "gdpr": false
}