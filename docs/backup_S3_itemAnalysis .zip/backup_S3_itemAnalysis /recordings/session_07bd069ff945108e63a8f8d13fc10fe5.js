var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3eefcc7cc8c2ddc71105e6878b85ed59",
  "created": "2017-11-30T11:12:55.0118339-08:00",
  "lastActivity": "2017-11-30T11:13:04.9065884-08:00",
  "pageViews": [
    {
      "id": "11305532e9b0d33337f275d0db6b2dc2aaec49a9",
      "startTime": "2017-11-30T11:12:55.0118339-08:00",
      "endTime": "2017-11-30T11:13:04.9065884-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 9915,
      "engagementTime": 9915,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 9915,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G0CPA",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "07bd069ff945108e63a8f8d13fc10fe5",
  "gdpr": false
}