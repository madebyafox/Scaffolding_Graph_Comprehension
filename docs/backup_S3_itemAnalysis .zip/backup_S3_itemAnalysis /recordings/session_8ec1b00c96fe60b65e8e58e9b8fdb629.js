var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e12fda7151907da724dd15e75feefd4c",
  "created": "2017-12-04T17:10:12.0350843-08:00",
  "lastActivity": "2017-12-04T17:10:59.312187-08:00",
  "pageViews": [
    {
      "id": "12041250af2b82b27a2fd338e2063823c6916447",
      "startTime": "2017-12-04T17:10:12.0350843-08:00",
      "endTime": "2017-12-04T17:10:59.312187-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 47447,
      "engagementTime": 47347,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 47447,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=61C10",
    "CONDITION=211"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8ec1b00c96fe60b65e8e58e9b8fdb629",
  "gdpr": false
}