var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cb7d6c72c04daffeb7102096285b04dd",
  "created": "2017-12-05T10:17:01.1500074-08:00",
  "lastActivity": "2017-12-05T10:17:27.9050074-08:00",
  "pageViews": [
    {
      "id": "12050116459c350710e86cd98808944e294af9ae",
      "startTime": "2017-12-05T10:17:01.1500074-08:00",
      "endTime": "2017-12-05T10:17:27.9050074-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 26755,
      "engagementTime": 26655,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 26755,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=2492T",
    "CONDITION=112",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "22d4286cb6fd46e34e095f408839df2c",
  "gdpr": false
}