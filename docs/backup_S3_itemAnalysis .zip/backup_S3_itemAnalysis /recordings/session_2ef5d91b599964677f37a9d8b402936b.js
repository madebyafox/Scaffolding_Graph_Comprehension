var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0860ee720d500fae1c46c23b429f93a7",
  "created": "2017-12-05T10:18:03.3058171-08:00",
  "lastActivity": "2017-12-05T10:18:22.9758171-08:00",
  "pageViews": [
    {
      "id": "120503746ba57b3e1fdf660be3e658c0a673f771",
      "startTime": "2017-12-05T10:18:03.3058171-08:00",
      "endTime": "2017-12-05T10:18:22.9758171-08:00",
      "title": "FOX2YP",
      "uri": "http://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 19670,
      "engagementTime": 19670,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 19670,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.46",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=WJWFF",
    "CONDITION=112",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2ef5d91b599964677f37a9d8b402936b",
  "gdpr": false
}