var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7ca5987f4ee3818ac5b89b160e0d104b",
  "created": "2017-12-05T09:21:46.1759004-08:00",
  "lastActivity": "2017-12-05T09:22:01.5156356-08:00",
  "pageViews": [
    {
      "id": "12054587c374515b32489b4a8ac0276d7f687445",
      "startTime": "2017-12-05T09:21:46.1759004-08:00",
      "endTime": "2017-12-05T09:22:01.5156356-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 15443,
      "engagementTime": 15443,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 15443,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.49",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=GJ8WG",
    "CONDITION=112",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9da3a8135c45b0f47e876bf85a928dd0",
  "gdpr": false
}