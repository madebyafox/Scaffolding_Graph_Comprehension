var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e1628446521a9ac618539656304a9092",
  "created": "2017-11-21T10:13:29.0245122-08:00",
  "lastActivity": "2017-11-21T10:14:04.0445122-08:00",
  "pageViews": [
    {
      "id": "11212822bf9a055857e0cb6c059951566db490c6",
      "startTime": "2017-11-21T10:13:29.0245122-08:00",
      "endTime": "2017-11-21T10:14:04.0445122-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 35020,
      "engagementTime": 31042,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 35020,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=P1BZ9",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "5bd2b1ae0a565aa01e49dfc6e76bdb59",
  "gdpr": false
}