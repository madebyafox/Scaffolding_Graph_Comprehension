var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5784e3862a97c80f9be19b679ea396b6",
  "created": "2017-11-30T10:09:42.1839623-08:00",
  "lastActivity": "2017-11-30T10:10:27.6992629-08:00",
  "pageViews": [
    {
      "id": "1130424324842783ac5a1d95f2e655c893ef9107",
      "startTime": "2017-11-30T10:09:42.38228-08:00",
      "endTime": "2017-11-30T10:10:27.6992629-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 45531,
      "engagementTime": 38982,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 45531,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=PO9J4",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "091b50a17e0b1270d89ff41819a56bc3",
  "gdpr": false
}