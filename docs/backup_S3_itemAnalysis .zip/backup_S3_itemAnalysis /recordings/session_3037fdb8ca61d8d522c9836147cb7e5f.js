var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "79d746ea195b10920c042638a7412fe1",
  "created": "2017-12-05T09:22:22.8180507-08:00",
  "lastActivity": "2017-12-05T09:22:49.9402796-08:00",
  "pageViews": [
    {
      "id": "12052285d6b801a9aad063b3bd1d6581b6d13256",
      "startTime": "2017-12-05T09:22:23.1641237-08:00",
      "endTime": "2017-12-05T09:22:49.9402796-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 26817,
      "engagementTime": 26817,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 26817,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.49",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=GJ8WG",
    "CONDITION=112",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3037fdb8ca61d8d522c9836147cb7e5f",
  "gdpr": false
}