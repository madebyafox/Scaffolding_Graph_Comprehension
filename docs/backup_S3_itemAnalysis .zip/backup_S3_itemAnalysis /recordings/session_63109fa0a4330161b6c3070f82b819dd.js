var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fa47ce1417e0cc58477c8586b35b9baf",
  "created": "2017-11-30T10:12:34.2062835-08:00",
  "lastActivity": "2017-11-30T10:12:50.6305405-08:00",
  "pageViews": [
    {
      "id": "11303497a4f69eae5c57d296fd2936790ae8b380",
      "startTime": "2017-11-30T10:12:34.2062835-08:00",
      "endTime": "2017-11-30T10:12:50.6305405-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 16623,
      "engagementTime": 16623,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 16623,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=L0M3H",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "63109fa0a4330161b6c3070f82b819dd",
  "gdpr": false
}