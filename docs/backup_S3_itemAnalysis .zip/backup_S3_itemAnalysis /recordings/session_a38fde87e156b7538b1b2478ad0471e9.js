var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b9090959928db8b8d7690f39939d1dfa",
  "created": "2017-11-28T09:18:49.4284847-08:00",
  "lastActivity": "2017-11-28T09:20:11.6627968-08:00",
  "pageViews": [
    {
      "id": "11284980b678c609a3e3321ab9e331e2a12d3863",
      "startTime": "2017-11-28T09:18:49.6143114-08:00",
      "endTime": "2017-11-28T09:20:11.6627968-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 82190,
      "engagementTime": 81839,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 82190,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G0PX0",
    "CONDITION=221",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a38fde87e156b7538b1b2478ad0471e9",
  "gdpr": false
}