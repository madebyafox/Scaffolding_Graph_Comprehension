var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8ca9ab04b7794e2c0de42d42cf4f1e9f",
  "created": "2017-12-05T09:16:15.6686778-08:00",
  "lastActivity": "2017-12-05T09:17:09.7965724-08:00",
  "pageViews": [
    {
      "id": "12051506475017c1dab6a90640bb327208aa0bbe",
      "startTime": "2017-12-05T09:16:16.026458-08:00",
      "endTime": "2017-12-05T09:17:09.7965724-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 54084,
      "engagementTime": 25904,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 54084,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=T432U",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "84878fe1c804679c71ab91c85b74e837",
  "gdpr": false
}