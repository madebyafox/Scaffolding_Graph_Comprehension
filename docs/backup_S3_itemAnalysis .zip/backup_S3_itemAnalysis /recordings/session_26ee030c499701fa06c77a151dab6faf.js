var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6d934b698134b7f658f71d6a40e39a5e",
  "created": "2017-12-05T10:24:47.1400367-08:00",
  "lastActivity": "2017-12-05T10:25:32.8580367-08:00",
  "pageViews": [
    {
      "id": "120547071f80aad687f154158555a449ca1823f6",
      "startTime": "2017-12-05T10:24:47.1400367-08:00",
      "endTime": "2017-12-05T10:25:32.8580367-08:00",
      "title": "FOX2YP",
      "uri": "http://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 45718,
      "engagementTime": 40417,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 45718,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=94NZK",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "26ee030c499701fa06c77a151dab6faf",
  "gdpr": false
}