var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a348b834ff6ce9942db4166212a136da",
  "created": "2017-11-30T09:15:39.7526233-08:00",
  "lastActivity": "2017-11-30T09:15:49.7276233-08:00",
  "pageViews": [
    {
      "id": "1130402217825b1e43925a01cfff0a0d5f61c7c1",
      "startTime": "2017-11-30T09:15:39.7526233-08:00",
      "endTime": "2017-11-30T09:15:49.7276233-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 9975,
      "engagementTime": 9875,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 9975,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=B45BJ",
    "CONDITION=111",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "42a0ab250fc2c0f1ea642af453b67a53",
  "gdpr": false
}