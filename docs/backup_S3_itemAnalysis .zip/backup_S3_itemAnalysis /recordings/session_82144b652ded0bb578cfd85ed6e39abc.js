var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "33e50c1da05c503d505c988590805f66",
  "created": "2017-11-28T10:11:37.5225135-08:00",
  "lastActivity": "2017-11-28T10:12:24.5185135-08:00",
  "pageViews": [
    {
      "id": "11283709e5c81620a1a56e5c7971b5018be1e34b",
      "startTime": "2017-11-28T10:11:37.5225135-08:00",
      "endTime": "2017-11-28T10:12:24.5185135-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 46996,
      "engagementTime": 39378,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 46996,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DF15K",
    "CONDITION=211"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "82144b652ded0bb578cfd85ed6e39abc",
  "gdpr": false
}