var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d09071d31c917a23118e4ce6a72765cb",
  "created": "2017-11-27T17:20:23.4289794-08:00",
  "lastActivity": "2017-11-27T17:20:44.4289794-08:00",
  "pageViews": [
    {
      "id": "11272345e1216e359d8ae0719ffd0f2afcba5a6e",
      "startTime": "2017-11-27T17:20:23.4289794-08:00",
      "endTime": "2017-11-27T17:20:44.4289794-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 21000,
      "engagementTime": 20400,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 21000,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=YGEAY",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "fdc083327319ea7cffa09ef861c41600",
  "gdpr": false
}