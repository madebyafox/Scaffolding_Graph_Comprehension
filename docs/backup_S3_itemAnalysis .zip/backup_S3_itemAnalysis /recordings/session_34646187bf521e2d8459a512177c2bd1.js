var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6fb64cd6fe65a1f26e44e3c274507f33",
  "created": "2017-12-05T09:20:40.956447-08:00",
  "lastActivity": "2017-12-05T09:21:49.2809122-08:00",
  "pageViews": [
    {
      "id": "12054188f3d53fd37717482ccf29432d61015739",
      "startTime": "2017-12-05T09:20:41.0429122-08:00",
      "endTime": "2017-12-05T09:21:49.2809122-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 68238,
      "engagementTime": 67788,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 68238,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=4JR4X",
    "CONDITION=122"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "34646187bf521e2d8459a512177c2bd1",
  "gdpr": false
}