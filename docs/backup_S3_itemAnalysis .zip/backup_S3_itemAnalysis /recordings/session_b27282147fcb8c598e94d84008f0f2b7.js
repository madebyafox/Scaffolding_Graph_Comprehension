var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5c939a8c0c8368720e975148691c98da",
  "created": "2017-11-28T10:15:37.7266215-08:00",
  "lastActivity": "2017-11-28T10:15:45.9483759-08:00",
  "pageViews": [
    {
      "id": "112837831629e573b3db620968cf5ee66668bf15",
      "startTime": "2017-11-28T10:15:37.7266215-08:00",
      "endTime": "2017-11-28T10:15:45.9483759-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 8279,
      "engagementTime": 8279,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 8279,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=B3OKB",
    "CONDITION=111",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b27282147fcb8c598e94d84008f0f2b7",
  "gdpr": false
}