var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5a8a185d7a0d62e97f4aaba442a3a00c",
  "created": "2017-11-29T17:11:59.4066992-08:00",
  "lastActivity": "2017-11-29T17:12:08.5106992-08:00",
  "pageViews": [
    {
      "id": "1129596472046af6fa45975aebe6fa3f6bce4ca8",
      "startTime": "2017-11-29T17:11:59.4066992-08:00",
      "endTime": "2017-11-29T17:12:08.5106992-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 9104,
      "engagementTime": 9104,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 9104,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=NSPM3",
    "CONDITION=321",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0765e15f23a29205f93acbe517086ecb",
  "gdpr": false
}