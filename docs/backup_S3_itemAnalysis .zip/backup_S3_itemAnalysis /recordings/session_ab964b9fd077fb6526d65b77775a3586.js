var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1f930b5c3b7edbc0ed6b4ec1be1fc3c1",
  "created": "2017-12-05T10:21:19.5960748-08:00",
  "lastActivity": "2017-12-05T10:21:26.744446-08:00",
  "pageViews": [
    {
      "id": "12051905dfe1a96f35ef154148629b80244cd900",
      "startTime": "2017-12-05T10:21:19.944446-08:00",
      "endTime": "2017-12-05T10:21:26.744446-08:00",
      "title": "FOX2YP",
      "uri": "http://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 6800,
      "engagementTime": 13600,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 6800,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=GKC1Y",
    "CONDITION=113",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ab964b9fd077fb6526d65b77775a3586",
  "gdpr": false
}