var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "649e164491d4f3109040078dfd833156",
  "created": "2017-11-30T10:14:30.7951316-08:00",
  "lastActivity": "2017-11-30T10:15:06.2377022-08:00",
  "pageViews": [
    {
      "id": "113030286665a243f2a2139be2b397ca0fe04d27",
      "startTime": "2017-11-30T10:14:30.7951316-08:00",
      "endTime": "2017-11-30T10:15:06.2377022-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 35891,
      "engagementTime": 34941,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 35891,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=RM2SM",
    "CONDITION=321",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "40f1c8374753b7ae3b6db43d9d7c0991",
  "gdpr": false
}