var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["112741700466a6d4ffea3a4a3a0f1d4ba91a245c"] = {
  "startTime": "2017-11-28T01:15:42.154601Z",
  "websitePageUrl": "/15",
  "visitTime": 42123,
  "engagementTime": 41873,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "1a6115603337e0abebf1d393a0f93df3",
    "created": "2017-11-28T01:15:41.7705669+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "duration": 0,
    "pages": 1,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "62.0.3202.94",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/15",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=T4UDR",
      "CONDITION=321",
      "TRI_CORRECT=1"
    ],
    "watched": false,
    "starred": false,
    "gdpr": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "dc0151ba6867df02aaacd0a3ae06bc21",
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/1a6115603337e0abebf1d393a0f93df3/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 270,
      "e": 270,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 750,
      "e": 750,
      "ty": 41,
      "x": 22659,
      "y": 13547,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 354,
      "y": 660
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 353,
      "y": 645
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 401,
      "y": 613
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 28256,
      "y": 53064,
      "ta": "#bigset.midpoint > ul > li:[13]"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 551,
      "y": 620
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 681,
      "y": 734
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 785,
      "y": 44163,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 699,
      "y": 763
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 700,
      "y": 766
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 957,
      "y": 44589,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 700,
      "y": 767
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 957,
      "y": 44660,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 787,
      "y": 792
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 9639,
      "y": 51568,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 2,
      "x": 926,
      "y": 858
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 1119,
      "y": 965
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 1263,
      "y": 1028
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 28620,
      "y": 13107,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[26] > text"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 1272,
      "y": 1037
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 1262,
      "y": 1031
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 30780,
      "y": 62956,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 1226,
      "y": 1017
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 1225,
      "y": 1011
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 1225,
      "y": 1008
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 30709,
      "y": 62311,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 31978,
      "y": 61882,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 1272,
      "y": 993
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 1307,
      "y": 991
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 36840,
      "y": 60234,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 1312,
      "y": 979
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1309,
      "y": 969
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 1298,
      "y": 965
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 35853,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1294,
      "y": 952
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 33951,
      "y": 58301,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1271,
      "y": 952
    },
    {
      "t": 5698,
      "e": 5698,
      "ty": 2,
      "x": 1273,
      "y": 950
    },
    {
      "t": 5748,
      "e": 5748,
      "ty": 41,
      "x": 34303,
      "y": 58014,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5798,
      "e": 5798,
      "ty": 2,
      "x": 1278,
      "y": 948
    },
    {
      "t": 5898,
      "e": 5898,
      "ty": 2,
      "x": 1286,
      "y": 945
    },
    {
      "t": 5998,
      "e": 5998,
      "ty": 41,
      "x": 35149,
      "y": 57656,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5999,
      "e": 5999,
      "ty": 2,
      "x": 1288,
      "y": 943
    },
    {
      "t": 6098,
      "e": 6098,
      "ty": 2,
      "x": 1288,
      "y": 966
    },
    {
      "t": 6198,
      "e": 6198,
      "ty": 2,
      "x": 1288,
      "y": 970
    },
    {
      "t": 6248,
      "e": 6248,
      "ty": 41,
      "x": 35149,
      "y": 59590,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6398,
      "e": 6398,
      "ty": 2,
      "x": 1290,
      "y": 951
    },
    {
      "t": 6498,
      "e": 6498,
      "ty": 41,
      "x": 35642,
      "y": 53215,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6498,
      "e": 6498,
      "ty": 2,
      "x": 1295,
      "y": 881
    },
    {
      "t": 6598,
      "e": 6598,
      "ty": 2,
      "x": 1295,
      "y": 854
    },
    {
      "t": 6698,
      "e": 6698,
      "ty": 2,
      "x": 1297,
      "y": 845
    },
    {
      "t": 6748,
      "e": 6748,
      "ty": 41,
      "x": 49000,
      "y": 48964,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > line:[12]"
    },
    {
      "t": 6798,
      "e": 6798,
      "ty": 2,
      "x": 1297,
      "y": 839
    },
    {
      "t": 6898,
      "e": 6898,
      "ty": 2,
      "x": 1296,
      "y": 837
    },
    {
      "t": 6999,
      "e": 6999,
      "ty": 41,
      "x": 35712,
      "y": 49992,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 2,
      "x": 1296,
      "y": 836
    },
    {
      "t": 7099,
      "e": 7099,
      "ty": 2,
      "x": 1294,
      "y": 836
    },
    {
      "t": 7249,
      "e": 7249,
      "ty": 41,
      "x": 47877,
      "y": 47700,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > line:[12]"
    },
    {
      "t": 7299,
      "e": 7299,
      "ty": 2,
      "x": 1293,
      "y": 836
    },
    {
      "t": 8502,
      "e": 8502,
      "ty": 41,
      "x": 34092,
      "y": 29078,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8502,
      "e": 8502,
      "ty": 2,
      "x": 1273,
      "y": 544
    },
    {
      "t": 8599,
      "e": 8599,
      "ty": 2,
      "x": 1233,
      "y": 243
    },
    {
      "t": 8699,
      "e": 8699,
      "ty": 2,
      "x": 1220,
      "y": 262
    },
    {
      "t": 8749,
      "e": 8749,
      "ty": 41,
      "x": 19928,
      "y": 18908,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8799,
      "e": 8799,
      "ty": 2,
      "x": 754,
      "y": 667
    },
    {
      "t": 8899,
      "e": 8899,
      "ty": 2,
      "x": 271,
      "y": 863
    },
    {
      "t": 8999,
      "e": 8999,
      "ty": 41,
      "x": 17469,
      "y": 41880,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 9000,
      "e": 9000,
      "ty": 2,
      "x": 251,
      "y": 764
    },
    {
      "t": 9099,
      "e": 9099,
      "ty": 2,
      "x": 283,
      "y": 659
    },
    {
      "t": 9199,
      "e": 9199,
      "ty": 2,
      "x": 284,
      "y": 646
    },
    {
      "t": 9249,
      "e": 9249,
      "ty": 41,
      "x": 21024,
      "y": 22637,
      "ta": "#bigset.midpoint > ul > li:[17]"
    },
    {
      "t": 9299,
      "e": 9299,
      "ty": 2,
      "x": 274,
      "y": 620
    },
    {
      "t": 9499,
      "e": 9499,
      "ty": 41,
      "x": 56140,
      "y": 50723,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 9499,
      "e": 9499,
      "ty": 2,
      "x": 228,
      "y": 612
    },
    {
      "t": 9599,
      "e": 9599,
      "ty": 2,
      "x": 182,
      "y": 596
    },
    {
      "t": 9699,
      "e": 9699,
      "ty": 2,
      "x": 174,
      "y": 593
    },
    {
      "t": 9749,
      "e": 9749,
      "ty": 41,
      "x": 18564,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 9799,
      "e": 9799,
      "ty": 2,
      "x": 171,
      "y": 583
    },
    {
      "t": 9899,
      "e": 9899,
      "ty": 2,
      "x": 176,
      "y": 579
    },
    {
      "t": 9999,
      "e": 9999,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 9999,
      "e": 9999,
      "ty": 41,
      "x": 32925,
      "y": 48757,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 2,
      "x": 184,
      "y": 606
    },
    {
      "t": 10099,
      "e": 10099,
      "ty": 2,
      "x": 183,
      "y": 614
    },
    {
      "t": 10249,
      "e": 10249,
      "ty": 41,
      "x": 29300,
      "y": 48383,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 10299,
      "e": 10299,
      "ty": 2,
      "x": 182,
      "y": 598
    },
    {
      "t": 10384,
      "e": 10384,
      "ty": 3,
      "x": 182,
      "y": 598,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10386,
      "e": 10386,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10487,
      "e": 10487,
      "ty": 4,
      "x": 22842,
      "y": 8428,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10487,
      "e": 10487,
      "ty": 5,
      "x": 182,
      "y": 598,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10488,
      "e": 10488,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > input",
      "v": "X"
    },
    {
      "t": 10499,
      "e": 10499,
      "ty": 41,
      "x": 22842,
      "y": 8428,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10599,
      "e": 10599,
      "ty": 2,
      "x": 204,
      "y": 600
    },
    {
      "t": 10699,
      "e": 10699,
      "ty": 2,
      "x": 318,
      "y": 605
    },
    {
      "t": 10749,
      "e": 10749,
      "ty": 41,
      "x": 6188,
      "y": 34340,
      "ta": "#bigset.midpoint > ul > li:[13]"
    },
    {
      "t": 10799,
      "e": 10799,
      "ty": 2,
      "x": 406,
      "y": 605
    },
    {
      "t": 10899,
      "e": 10899,
      "ty": 2,
      "x": 423,
      "y": 604
    },
    {
      "t": 10999,
      "e": 10999,
      "ty": 41,
      "x": 63447,
      "y": 55404,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 10999,
      "e": 10999,
      "ty": 2,
      "x": 460,
      "y": 586
    },
    {
      "t": 11099,
      "e": 11099,
      "ty": 2,
      "x": 527,
      "y": 574
    },
    {
      "t": 11199,
      "e": 11199,
      "ty": 2,
      "x": 587,
      "y": 566
    },
    {
      "t": 11249,
      "e": 11249,
      "ty": 41,
      "x": 12898,
      "y": 8594,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 11299,
      "e": 11299,
      "ty": 2,
      "x": 630,
      "y": 566
    },
    {
      "t": 11399,
      "e": 11399,
      "ty": 2,
      "x": 645,
      "y": 566
    },
    {
      "t": 11499,
      "e": 11499,
      "ty": 41,
      "x": 38545,
      "y": 17956,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 11499,
      "e": 11499,
      "ty": 2,
      "x": 638,
      "y": 570
    },
    {
      "t": 11599,
      "e": 11599,
      "ty": 2,
      "x": 632,
      "y": 574
    },
    {
      "t": 11616,
      "e": 11616,
      "ty": 3,
      "x": 632,
      "y": 574,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 11617,
      "e": 11617,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 11711,
      "e": 11711,
      "ty": 4,
      "x": 34966,
      "y": 27318,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 11711,
      "e": 11711,
      "ty": 5,
      "x": 632,
      "y": 574,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 11749,
      "e": 11749,
      "ty": 41,
      "x": 60651,
      "y": 28592,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 11799,
      "e": 11799,
      "ty": 2,
      "x": 627,
      "y": 574
    },
    {
      "t": 11899,
      "e": 11899,
      "ty": 2,
      "x": 623,
      "y": 576
    },
    {
      "t": 11999,
      "e": 11999,
      "ty": 41,
      "x": 30404,
      "y": 38675,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 12000,
      "e": 12000,
      "ty": 3,
      "x": 623,
      "y": 576,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 12001,
      "e": 12001,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 12071,
      "e": 12071,
      "ty": 4,
      "x": 30404,
      "y": 38675,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 12071,
      "e": 12071,
      "ty": 5,
      "x": 623,
      "y": 576,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 12071,
      "e": 12071,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[10] > input",
      "v": "K"
    },
    {
      "t": 12198,
      "e": 12198,
      "ty": 2,
      "x": 393,
      "y": 684
    },
    {
      "t": 12248,
      "e": 12248,
      "ty": 41,
      "x": 8616,
      "y": 39105,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 12299,
      "e": 12299,
      "ty": 2,
      "x": 333,
      "y": 717
    },
    {
      "t": 12399,
      "e": 12399,
      "ty": 2,
      "x": 329,
      "y": 717
    },
    {
      "t": 12498,
      "e": 12498,
      "ty": 41,
      "x": 4871,
      "y": 39761,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 12591,
      "e": 12591,
      "ty": 3,
      "x": 342,
      "y": 713,
      "ta": "#start"
    },
    {
      "t": 12591,
      "e": 12591,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 12591,
      "e": 12591,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 12599,
      "e": 12599,
      "ty": 2,
      "x": 342,
      "y": 713
    },
    {
      "t": 12679,
      "e": 12679,
      "ty": 4,
      "x": 1860,
      "y": 45627,
      "ta": "#start"
    },
    {
      "t": 12684,
      "e": 12684,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 12685,
      "e": 12685,
      "ty": 5,
      "x": 342,
      "y": 713,
      "ta": "#start"
    },
    {
      "t": 12691,
      "e": 12691,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 12748,
      "e": 12748,
      "ty": 41,
      "x": 11502,
      "y": 39055,
      "ta": "html > body"
    },
    {
      "t": 13688,
      "e": 13688,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 14226,
      "e": 14226,
      "ty": 2,
      "x": 650,
      "y": 718
    },
    {
      "t": 14248,
      "e": 14248,
      "ty": 41,
      "x": 23693,
      "y": 39498,
      "ta": "html > body"
    },
    {
      "t": 14298,
      "e": 14298,
      "ty": 2,
      "x": 817,
      "y": 728
    },
    {
      "t": 14398,
      "e": 14398,
      "ty": 2,
      "x": 878,
      "y": 696
    },
    {
      "t": 14498,
      "e": 14498,
      "ty": 41,
      "x": 12328,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 14498,
      "e": 14498,
      "ty": 2,
      "x": 865,
      "y": 650
    },
    {
      "t": 14598,
      "e": 14598,
      "ty": 2,
      "x": 863,
      "y": 623
    },
    {
      "t": 14698,
      "e": 14698,
      "ty": 2,
      "x": 844,
      "y": 601
    },
    {
      "t": 14748,
      "e": 14748,
      "ty": 41,
      "x": 4758,
      "y": 1409,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 14798,
      "e": 14798,
      "ty": 2,
      "x": 829,
      "y": 583
    },
    {
      "t": 14898,
      "e": 14898,
      "ty": 2,
      "x": 825,
      "y": 564
    },
    {
      "t": 14998,
      "e": 14998,
      "ty": 41,
      "x": 3676,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14998,
      "e": 14998,
      "ty": 2,
      "x": 825,
      "y": 561
    },
    {
      "t": 15039,
      "e": 15039,
      "ty": 3,
      "x": 825,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 15040,
      "e": 15040,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 15135,
      "e": 15135,
      "ty": 4,
      "x": 3676,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 15136,
      "e": 15136,
      "ty": 5,
      "x": 825,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 15198,
      "e": 15198,
      "ty": 2,
      "x": 825,
      "y": 570
    },
    {
      "t": 15248,
      "e": 15248,
      "ty": 41,
      "x": 3028,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 15298,
      "e": 15298,
      "ty": 2,
      "x": 822,
      "y": 574
    },
    {
      "t": 15604,
      "e": 15604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 15604,
      "e": 15604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 15707,
      "e": 15707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 15747,
      "e": 15747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 15747,
      "e": 15747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 15835,
      "e": 15835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 16398,
      "e": 16398,
      "ty": 2,
      "x": 853,
      "y": 574
    },
    {
      "t": 16498,
      "e": 16498,
      "ty": 41,
      "x": 16005,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 16498,
      "e": 16498,
      "ty": 2,
      "x": 882,
      "y": 653
    },
    {
      "t": 17087,
      "e": 17087,
      "ty": 3,
      "x": 882,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17088,
      "e": 17088,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 17089,
      "e": 17089,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 17089,
      "e": 17089,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17231,
      "e": 17231,
      "ty": 4,
      "x": 16005,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17231,
      "e": 17231,
      "ty": 5,
      "x": 882,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17539,
      "e": 17539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 18039,
      "e": 18039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 18072,
      "e": 18072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 18105,
      "e": 18105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 18138,
      "e": 18138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 18171,
      "e": 18171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 18203,
      "e": 18203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 18204,
      "e": 18204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 18258,
      "e": 18258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "A"
    },
    {
      "t": 18298,
      "e": 18298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "A"
    },
    {
      "t": 18338,
      "e": 18338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 18339,
      "e": 18339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 18435,
      "e": 18435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Am"
    },
    {
      "t": 18707,
      "e": 18707,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 18778,
      "e": 18778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "A"
    },
    {
      "t": 18842,
      "e": 18842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 18915,
      "e": 18915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 19067,
      "e": 19067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 19291,
      "e": 19291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 19292,
      "e": 19292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 19370,
      "e": 19370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 19442,
      "e": 19442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 19443,
      "e": 19443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 19507,
      "e": 19507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 19627,
      "e": 19627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 19628,
      "e": 19628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 19723,
      "e": 19723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 19803,
      "e": 19803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 19998,
      "e": 19998,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20198,
      "e": 20198,
      "ty": 2,
      "x": 927,
      "y": 587
    },
    {
      "t": 20248,
      "e": 20248,
      "ty": 41,
      "x": 25738,
      "y": 2818,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 20498,
      "e": 20498,
      "ty": 41,
      "x": 25305,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 20498,
      "e": 20498,
      "ty": 2,
      "x": 925,
      "y": 576
    },
    {
      "t": 20598,
      "e": 20598,
      "ty": 2,
      "x": 925,
      "y": 575
    },
    {
      "t": 20699,
      "e": 20699,
      "ty": 2,
      "x": 921,
      "y": 606
    },
    {
      "t": 20748,
      "e": 20748,
      "ty": 41,
      "x": 24224,
      "y": 51491,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 20798,
      "e": 20798,
      "ty": 2,
      "x": 919,
      "y": 628
    },
    {
      "t": 20898,
      "e": 20898,
      "ty": 2,
      "x": 919,
      "y": 651
    },
    {
      "t": 20998,
      "e": 20998,
      "ty": 41,
      "x": 15501,
      "y": 15887,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 20998,
      "e": 20998,
      "ty": 2,
      "x": 926,
      "y": 684
    },
    {
      "t": 21152,
      "e": 21152,
      "ty": 3,
      "x": 926,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 21153,
      "e": 21153,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 21153,
      "e": 21153,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 21154,
      "e": 21154,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 21206,
      "e": 21206,
      "ty": 4,
      "x": 15501,
      "y": 15887,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 21207,
      "e": 21207,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 21207,
      "e": 21207,
      "ty": 5,
      "x": 926,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 21207,
      "e": 21207,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 21598,
      "e": 21598,
      "ty": 2,
      "x": 930,
      "y": 678
    },
    {
      "t": 21698,
      "e": 21698,
      "ty": 2,
      "x": 941,
      "y": 642
    },
    {
      "t": 21748,
      "e": 21748,
      "ty": 41,
      "x": 32130,
      "y": 35121,
      "ta": "html > body"
    },
    {
      "t": 22227,
      "e": 22227,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 22698,
      "e": 22698,
      "ty": 2,
      "x": 937,
      "y": 617
    },
    {
      "t": 22748,
      "e": 22748,
      "ty": 41,
      "x": 17461,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 22798,
      "e": 22798,
      "ty": 2,
      "x": 847,
      "y": 299
    },
    {
      "t": 22898,
      "e": 22898,
      "ty": 2,
      "x": 825,
      "y": 251
    },
    {
      "t": 22998,
      "e": 22998,
      "ty": 41,
      "x": 849,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 22998,
      "e": 22998,
      "ty": 2,
      "x": 825,
      "y": 250
    },
    {
      "t": 23398,
      "e": 23398,
      "ty": 2,
      "x": 823,
      "y": 240
    },
    {
      "t": 23498,
      "e": 23498,
      "ty": 41,
      "x": 1292,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 23499,
      "e": 23499,
      "ty": 2,
      "x": 823,
      "y": 237
    },
    {
      "t": 23698,
      "e": 23698,
      "ty": 2,
      "x": 824,
      "y": 236
    },
    {
      "t": 23748,
      "e": 23748,
      "ty": 41,
      "x": 2914,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 23798,
      "e": 23798,
      "ty": 2,
      "x": 827,
      "y": 235
    },
    {
      "t": 23898,
      "e": 23898,
      "ty": 2,
      "x": 837,
      "y": 233
    },
    {
      "t": 23998,
      "e": 23998,
      "ty": 41,
      "x": 63408,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 23998,
      "e": 23998,
      "ty": 2,
      "x": 839,
      "y": 233
    },
    {
      "t": 24198,
      "e": 24198,
      "ty": 2,
      "x": 839,
      "y": 237
    },
    {
      "t": 24248,
      "e": 24248,
      "ty": 41,
      "x": 27309,
      "y": 15899,
      "ta": "html > body"
    },
    {
      "t": 24298,
      "e": 24298,
      "ty": 2,
      "x": 783,
      "y": 315
    },
    {
      "t": 24398,
      "e": 24398,
      "ty": 2,
      "x": 787,
      "y": 310
    },
    {
      "t": 24499,
      "e": 24499,
      "ty": 41,
      "x": 27756,
      "y": 15234,
      "ta": "html > body"
    },
    {
      "t": 24499,
      "e": 24499,
      "ty": 2,
      "x": 814,
      "y": 283
    },
    {
      "t": 24599,
      "e": 24599,
      "ty": 2,
      "x": 818,
      "y": 263
    },
    {
      "t": 24699,
      "e": 24699,
      "ty": 2,
      "x": 824,
      "y": 258
    },
    {
      "t": 24749,
      "e": 24749,
      "ty": 41,
      "x": 4248,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 24799,
      "e": 24799,
      "ty": 2,
      "x": 827,
      "y": 257
    },
    {
      "t": 25264,
      "e": 25264,
      "ty": 3,
      "x": 827,
      "y": 257,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 25352,
      "e": 25352,
      "ty": 4,
      "x": 4248,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 25352,
      "e": 25352,
      "ty": 5,
      "x": 827,
      "y": 257,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 25353,
      "e": 25353,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 25355,
      "e": 25355,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 25499,
      "e": 25499,
      "ty": 41,
      "x": 11102,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 25499,
      "e": 25499,
      "ty": 2,
      "x": 836,
      "y": 273
    },
    {
      "t": 25599,
      "e": 25599,
      "ty": 2,
      "x": 845,
      "y": 289
    },
    {
      "t": 25699,
      "e": 25699,
      "ty": 2,
      "x": 836,
      "y": 281
    },
    {
      "t": 25749,
      "e": 25749,
      "ty": 41,
      "x": 9579,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 25799,
      "e": 25799,
      "ty": 2,
      "x": 834,
      "y": 276
    },
    {
      "t": 25899,
      "e": 25899,
      "ty": 2,
      "x": 834,
      "y": 285
    },
    {
      "t": 25999,
      "e": 25999,
      "ty": 41,
      "x": 38202,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 25999,
      "e": 25999,
      "ty": 2,
      "x": 834,
      "y": 316
    },
    {
      "t": 26099,
      "e": 26099,
      "ty": 2,
      "x": 838,
      "y": 331
    },
    {
      "t": 26198,
      "e": 26198,
      "ty": 2,
      "x": 840,
      "y": 368
    },
    {
      "t": 26249,
      "e": 26249,
      "ty": 41,
      "x": 4409,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 26299,
      "e": 26299,
      "ty": 2,
      "x": 842,
      "y": 385
    },
    {
      "t": 26399,
      "e": 26399,
      "ty": 2,
      "x": 846,
      "y": 408
    },
    {
      "t": 26500,
      "e": 26400,
      "ty": 41,
      "x": 31112,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 26500,
      "e": 26400,
      "ty": 2,
      "x": 848,
      "y": 410
    },
    {
      "t": 26999,
      "e": 26899,
      "ty": 41,
      "x": 31112,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 26999,
      "e": 26899,
      "ty": 2,
      "x": 848,
      "y": 421
    },
    {
      "t": 27099,
      "e": 26999,
      "ty": 2,
      "x": 844,
      "y": 442
    },
    {
      "t": 27199,
      "e": 27099,
      "ty": 2,
      "x": 837,
      "y": 458
    },
    {
      "t": 27249,
      "e": 27149,
      "ty": 41,
      "x": 14352,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 27299,
      "e": 27199,
      "ty": 2,
      "x": 834,
      "y": 467
    },
    {
      "t": 27499,
      "e": 27399,
      "ty": 41,
      "x": 38202,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 27599,
      "e": 27499,
      "ty": 2,
      "x": 834,
      "y": 460
    },
    {
      "t": 27699,
      "e": 27599,
      "ty": 2,
      "x": 834,
      "y": 456
    },
    {
      "t": 27749,
      "e": 27649,
      "ty": 41,
      "x": 10046,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 27799,
      "e": 27699,
      "ty": 2,
      "x": 834,
      "y": 447
    },
    {
      "t": 27899,
      "e": 27799,
      "ty": 2,
      "x": 836,
      "y": 434
    },
    {
      "t": 27999,
      "e": 27899,
      "ty": 41,
      "x": 11644,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 28099,
      "e": 27999,
      "ty": 2,
      "x": 836,
      "y": 424
    },
    {
      "t": 28249,
      "e": 28149,
      "ty": 41,
      "x": 17065,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 28399,
      "e": 28299,
      "ty": 2,
      "x": 832,
      "y": 433
    },
    {
      "t": 28499,
      "e": 28399,
      "ty": 41,
      "x": 8449,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 28499,
      "e": 28399,
      "ty": 2,
      "x": 832,
      "y": 435
    },
    {
      "t": 28631,
      "e": 28531,
      "ty": 3,
      "x": 832,
      "y": 435,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 28631,
      "e": 28531,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 28735,
      "e": 28635,
      "ty": 4,
      "x": 8449,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 28735,
      "e": 28635,
      "ty": 5,
      "x": 832,
      "y": 435,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 28735,
      "e": 28635,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 28736,
      "e": 28636,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 28899,
      "e": 28799,
      "ty": 2,
      "x": 832,
      "y": 446
    },
    {
      "t": 28999,
      "e": 28899,
      "ty": 41,
      "x": 2510,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 28999,
      "e": 28899,
      "ty": 2,
      "x": 832,
      "y": 460
    },
    {
      "t": 29099,
      "e": 28999,
      "ty": 2,
      "x": 832,
      "y": 493
    },
    {
      "t": 29199,
      "e": 29099,
      "ty": 2,
      "x": 834,
      "y": 567
    },
    {
      "t": 29249,
      "e": 29149,
      "ty": 41,
      "x": 16457,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 29299,
      "e": 29199,
      "ty": 2,
      "x": 839,
      "y": 595
    },
    {
      "t": 29499,
      "e": 29399,
      "ty": 41,
      "x": 4409,
      "y": 33253,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 29499,
      "e": 29399,
      "ty": 2,
      "x": 840,
      "y": 606
    },
    {
      "t": 29599,
      "e": 29499,
      "ty": 2,
      "x": 844,
      "y": 643
    },
    {
      "t": 29699,
      "e": 29599,
      "ty": 2,
      "x": 844,
      "y": 685
    },
    {
      "t": 29749,
      "e": 29649,
      "ty": 41,
      "x": 4681,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 29799,
      "e": 29699,
      "ty": 2,
      "x": 833,
      "y": 712
    },
    {
      "t": 29899,
      "e": 29799,
      "ty": 2,
      "x": 829,
      "y": 720
    },
    {
      "t": 29999,
      "e": 29899,
      "ty": 41,
      "x": 647,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 29999,
      "e": 29899,
      "ty": 2,
      "x": 824,
      "y": 733
    },
    {
      "t": 30099,
      "e": 29999,
      "ty": 2,
      "x": 823,
      "y": 745
    },
    {
      "t": 30199,
      "e": 30099,
      "ty": 2,
      "x": 824,
      "y": 760
    },
    {
      "t": 30249,
      "e": 30099,
      "ty": 41,
      "x": 2914,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 30299,
      "e": 30149,
      "ty": 2,
      "x": 829,
      "y": 769
    },
    {
      "t": 30399,
      "e": 30249,
      "ty": 2,
      "x": 834,
      "y": 780
    },
    {
      "t": 30499,
      "e": 30349,
      "ty": 41,
      "x": 43243,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 30499,
      "e": 30349,
      "ty": 2,
      "x": 835,
      "y": 785
    },
    {
      "t": 30599,
      "e": 30449,
      "ty": 2,
      "x": 838,
      "y": 805
    },
    {
      "t": 30699,
      "e": 30549,
      "ty": 2,
      "x": 840,
      "y": 818
    },
    {
      "t": 30749,
      "e": 30599,
      "ty": 41,
      "x": 4409,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 30799,
      "e": 30649,
      "ty": 2,
      "x": 840,
      "y": 830
    },
    {
      "t": 30899,
      "e": 30749,
      "ty": 2,
      "x": 840,
      "y": 842
    },
    {
      "t": 30999,
      "e": 30849,
      "ty": 41,
      "x": 63408,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 30999,
      "e": 30849,
      "ty": 2,
      "x": 839,
      "y": 845
    },
    {
      "t": 31099,
      "e": 30949,
      "ty": 2,
      "x": 839,
      "y": 839
    },
    {
      "t": 31199,
      "e": 31049,
      "ty": 2,
      "x": 839,
      "y": 811
    },
    {
      "t": 31249,
      "e": 31099,
      "ty": 41,
      "x": 10375,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 31299,
      "e": 31149,
      "ty": 2,
      "x": 839,
      "y": 802
    },
    {
      "t": 31499,
      "e": 31349,
      "ty": 41,
      "x": 3222,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 31499,
      "e": 31349,
      "ty": 2,
      "x": 835,
      "y": 803
    },
    {
      "t": 31606,
      "e": 31456,
      "ty": 3,
      "x": 835,
      "y": 803,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 31607,
      "e": 31457,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 31710,
      "e": 31560,
      "ty": 4,
      "x": 3222,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 31710,
      "e": 31560,
      "ty": 5,
      "x": 835,
      "y": 803,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 32099,
      "e": 31949,
      "ty": 2,
      "x": 842,
      "y": 769
    },
    {
      "t": 32198,
      "e": 32048,
      "ty": 2,
      "x": 845,
      "y": 715
    },
    {
      "t": 32249,
      "e": 32099,
      "ty": 41,
      "x": 5941,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 32299,
      "e": 32149,
      "ty": 2,
      "x": 845,
      "y": 708
    },
    {
      "t": 32499,
      "e": 32349,
      "ty": 41,
      "x": 5941,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 32798,
      "e": 32648,
      "ty": 2,
      "x": 845,
      "y": 707
    },
    {
      "t": 32899,
      "e": 32749,
      "ty": 2,
      "x": 840,
      "y": 705
    },
    {
      "t": 32999,
      "e": 32849,
      "ty": 41,
      "x": 4681,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 33099,
      "e": 32949,
      "ty": 2,
      "x": 835,
      "y": 700
    },
    {
      "t": 33199,
      "e": 33049,
      "ty": 2,
      "x": 834,
      "y": 697
    },
    {
      "t": 33249,
      "e": 33099,
      "ty": 41,
      "x": 2917,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 33270,
      "e": 33120,
      "ty": 3,
      "x": 833,
      "y": 695,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 33299,
      "e": 33149,
      "ty": 2,
      "x": 833,
      "y": 695
    },
    {
      "t": 33350,
      "e": 33200,
      "ty": 4,
      "x": 2917,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 33350,
      "e": 33200,
      "ty": 5,
      "x": 833,
      "y": 695,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 33351,
      "e": 33201,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 33352,
      "e": 33202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 33749,
      "e": 33599,
      "ty": 41,
      "x": 6193,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 33798,
      "e": 33648,
      "ty": 2,
      "x": 908,
      "y": 684
    },
    {
      "t": 33899,
      "e": 33749,
      "ty": 2,
      "x": 945,
      "y": 672
    },
    {
      "t": 33999,
      "e": 33849,
      "ty": 41,
      "x": 32888,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 33999,
      "e": 33849,
      "ty": 2,
      "x": 960,
      "y": 662
    },
    {
      "t": 34198,
      "e": 34048,
      "ty": 2,
      "x": 965,
      "y": 686
    },
    {
      "t": 34249,
      "e": 34099,
      "ty": 41,
      "x": 34074,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 34299,
      "e": 34149,
      "ty": 2,
      "x": 965,
      "y": 694
    },
    {
      "t": 34398,
      "e": 34248,
      "ty": 2,
      "x": 958,
      "y": 711
    },
    {
      "t": 34499,
      "e": 34349,
      "ty": 41,
      "x": 31701,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 34499,
      "e": 34349,
      "ty": 2,
      "x": 955,
      "y": 719
    },
    {
      "t": 34598,
      "e": 34448,
      "ty": 2,
      "x": 952,
      "y": 743
    },
    {
      "t": 34699,
      "e": 34549,
      "ty": 2,
      "x": 956,
      "y": 755
    },
    {
      "t": 34749,
      "e": 34599,
      "ty": 41,
      "x": 56987,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 34798,
      "e": 34648,
      "ty": 2,
      "x": 960,
      "y": 773
    },
    {
      "t": 34899,
      "e": 34749,
      "ty": 2,
      "x": 959,
      "y": 788
    },
    {
      "t": 34999,
      "e": 34749,
      "ty": 41,
      "x": 32176,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 34999,
      "e": 34749,
      "ty": 2,
      "x": 957,
      "y": 792
    },
    {
      "t": 35099,
      "e": 34849,
      "ty": 2,
      "x": 955,
      "y": 796
    },
    {
      "t": 35249,
      "e": 34999,
      "ty": 41,
      "x": 31701,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 35299,
      "e": 35049,
      "ty": 2,
      "x": 955,
      "y": 803
    },
    {
      "t": 35398,
      "e": 35148,
      "ty": 2,
      "x": 955,
      "y": 813
    },
    {
      "t": 35499,
      "e": 35249,
      "ty": 41,
      "x": 33599,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 35499,
      "e": 35249,
      "ty": 2,
      "x": 963,
      "y": 852
    },
    {
      "t": 35599,
      "e": 35349,
      "ty": 2,
      "x": 965,
      "y": 856
    },
    {
      "t": 35749,
      "e": 35499,
      "ty": 41,
      "x": 31938,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 35798,
      "e": 35548,
      "ty": 2,
      "x": 885,
      "y": 969
    },
    {
      "t": 35899,
      "e": 35649,
      "ty": 2,
      "x": 867,
      "y": 979
    },
    {
      "t": 35998,
      "e": 35748,
      "ty": 41,
      "x": 9155,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 35998,
      "e": 35748,
      "ty": 2,
      "x": 860,
      "y": 979
    },
    {
      "t": 36099,
      "e": 35849,
      "ty": 2,
      "x": 830,
      "y": 969
    },
    {
      "t": 36199,
      "e": 35949,
      "ty": 2,
      "x": 822,
      "y": 968
    },
    {
      "t": 36249,
      "e": 35999,
      "ty": 41,
      "x": 467,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 36299,
      "e": 36049,
      "ty": 2,
      "x": 822,
      "y": 964
    },
    {
      "t": 36310,
      "e": 36060,
      "ty": 3,
      "x": 822,
      "y": 964,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 36310,
      "e": 36060,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 36406,
      "e": 36156,
      "ty": 4,
      "x": 467,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 36406,
      "e": 36156,
      "ty": 5,
      "x": 822,
      "y": 964,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 36406,
      "e": 36156,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 36407,
      "e": 36157,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 36499,
      "e": 36249,
      "ty": 41,
      "x": 467,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 36598,
      "e": 36348,
      "ty": 2,
      "x": 824,
      "y": 963
    },
    {
      "t": 36699,
      "e": 36449,
      "ty": 2,
      "x": 829,
      "y": 961
    },
    {
      "t": 36749,
      "e": 36499,
      "ty": 41,
      "x": 18263,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 36798,
      "e": 36548,
      "ty": 2,
      "x": 857,
      "y": 989
    },
    {
      "t": 36899,
      "e": 36649,
      "ty": 2,
      "x": 865,
      "y": 1007
    },
    {
      "t": 36998,
      "e": 36748,
      "ty": 41,
      "x": 18851,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 36998,
      "e": 36748,
      "ty": 2,
      "x": 866,
      "y": 1017
    },
    {
      "t": 37099,
      "e": 36849,
      "ty": 2,
      "x": 866,
      "y": 1020
    },
    {
      "t": 37118,
      "e": 36868,
      "ty": 3,
      "x": 866,
      "y": 1020,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 37118,
      "e": 36868,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 37118,
      "e": 36868,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 37206,
      "e": 36956,
      "ty": 4,
      "x": 18851,
      "y": 29788,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 37206,
      "e": 36956,
      "ty": 5,
      "x": 866,
      "y": 1020,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 37208,
      "e": 36958,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 37208,
      "e": 36958,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 37209,
      "e": 36959,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 37249,
      "e": 36999,
      "ty": 41,
      "x": 29547,
      "y": 56062,
      "ta": "html > body"
    },
    {
      "t": 37498,
      "e": 37248,
      "ty": 41,
      "x": 28376,
      "y": 54843,
      "ta": "html > body"
    },
    {
      "t": 37498,
      "e": 37248,
      "ty": 2,
      "x": 832,
      "y": 998
    },
    {
      "t": 37598,
      "e": 37348,
      "ty": 2,
      "x": 617,
      "y": 789
    },
    {
      "t": 37699,
      "e": 37449,
      "ty": 2,
      "x": 571,
      "y": 505
    },
    {
      "t": 37748,
      "e": 37498,
      "ty": 41,
      "x": 20524,
      "y": 25371,
      "ta": "html > body"
    },
    {
      "t": 37798,
      "e": 37548,
      "ty": 2,
      "x": 692,
      "y": 408
    },
    {
      "t": 37899,
      "e": 37649,
      "ty": 2,
      "x": 776,
      "y": 366
    },
    {
      "t": 37998,
      "e": 37748,
      "ty": 41,
      "x": 26448,
      "y": 19832,
      "ta": "html > body"
    },
    {
      "t": 38301,
      "e": 38051,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 38898,
      "e": 38648,
      "ty": 2,
      "x": 947,
      "y": 801
    },
    {
      "t": 38998,
      "e": 38748,
      "ty": 41,
      "x": 49385,
      "y": 31196,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 38998,
      "e": 38748,
      "ty": 2,
      "x": 995,
      "y": 1129
    },
    {
      "t": 39098,
      "e": 38848,
      "ty": 2,
      "x": 996,
      "y": 1129
    },
    {
      "t": 39198,
      "e": 38948,
      "ty": 2,
      "x": 989,
      "y": 1098
    },
    {
      "t": 39248,
      "e": 38998,
      "ty": 41,
      "x": 33382,
      "y": 65071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 39298,
      "e": 39048,
      "ty": 2,
      "x": 972,
      "y": 1066
    },
    {
      "t": 39398,
      "e": 39148,
      "ty": 2,
      "x": 969,
      "y": 1066
    },
    {
      "t": 39498,
      "e": 39248,
      "ty": 41,
      "x": 30856,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 39498,
      "e": 39248,
      "ty": 2,
      "x": 966,
      "y": 1092
    },
    {
      "t": 39598,
      "e": 39348,
      "ty": 2,
      "x": 966,
      "y": 1097
    },
    {
      "t": 39662,
      "e": 39412,
      "ty": 3,
      "x": 965,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 39662,
      "e": 39412,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 39698,
      "e": 39448,
      "ty": 2,
      "x": 965,
      "y": 1100
    },
    {
      "t": 39748,
      "e": 39498,
      "ty": 41,
      "x": 30309,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 39758,
      "e": 39508,
      "ty": 4,
      "x": 30309,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 39758,
      "e": 39508,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 39759,
      "e": 39509,
      "ty": 5,
      "x": 965,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 39759,
      "e": 39509,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 40197,
      "e": 39947,
      "ty": 2,
      "x": 960,
      "y": 1058
    },
    {
      "t": 40248,
      "e": 39998,
      "ty": 41,
      "x": 27619,
      "y": 37005,
      "ta": "html > body"
    },
    {
      "t": 40298,
      "e": 40048,
      "ty": 2,
      "x": 611,
      "y": 476
    },
    {
      "t": 40398,
      "e": 40148,
      "ty": 2,
      "x": 533,
      "y": 323
    },
    {
      "t": 40498,
      "e": 40248,
      "ty": 41,
      "x": 18079,
      "y": 17450,
      "ta": "html > body"
    },
    {
      "t": 40785,
      "e": 40535,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 42123,
      "e": 41873,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":54},{\"id\":55},{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"nodeType\":3,\"id\":1563,\"textContent\":\" $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"full\\\"; } else if (axis == 2){ axis = \\\"partial\\\"; } else if (axis ==3){ axis = \\\"diagonal\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":1560},{\"id\":1561},{\"nodeType\":3,\"id\":1564,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":1562}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1565,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":1565},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1567,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":1566},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1568,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":1567},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1569,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":1566}},{\"nodeType\":1,\"id\":1570,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":1569},\"parentNode\":{\"id\":1566}},{\"nodeType\":3,\"id\":1571,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":1569}},{\"nodeType\":1,\"id\":1572,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":1567}},{\"nodeType\":1,\"id\":1573,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":1572},\"parentNode\":{\"id\":1567}},{\"nodeType\":3,\"id\":1574,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":1572}},{\"nodeType\":3,\"id\":1575,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":1568}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":1565},{\"id\":1566},{\"id\":1569},{\"id\":1571},{\"id\":1570},{\"id\":1567},{\"id\":1572},{\"id\":1574},{\"id\":1573},{\"id\":1568},{\"id\":1575}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1576,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1577,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1578,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1577},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1579,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1578},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1580,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1579},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1581,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1580},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1582,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":1581},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1583,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1578}},{\"nodeType\":1,\"id\":1584,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1583},\"parentNode\":{\"id\":1578}},{\"nodeType\":1,\"id\":1585,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1584},\"parentNode\":{\"id\":1578}},{\"nodeType\":1,\"id\":1586,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1585},\"parentNode\":{\"id\":1578}},{\"nodeType\":1,\"id\":1587,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1586},\"parentNode\":{\"id\":1578}},{\"nodeType\":3,\"id\":1588,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":1583}},{\"nodeType\":1,\"id\":1589,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1588},\"parentNode\":{\"id\":1583}},{\"nodeType\":1,\"id\":1590,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1584}},{\"nodeType\":1,\"id\":1591,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1590}},{\"nodeType\":3,\"id\":1592,\"textContent\":\"English\",\"previousSibling\":{\"id\":1591},\"parentNode\":{\"id\":1590}},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1585}},{\"nodeType\":1,\"id\":1594,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1593}},{\"nodeType\":3,\"id\":1595,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":1594},\"parentNode\":{\"id\":1593}},{\"nodeType\":1,\"id\":1596,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1586}},{\"nodeType\":1,\"id\":1597,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1596}},{\"nodeType\":3,\"id\":1598,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":1597},\"parentNode\":{\"id\":1596}},{\"nodeType\":1,\"id\":1599,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1587}},{\"nodeType\":1,\"id\":1600,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1599}},{\"nodeType\":3,\"id\":1601,\"textContent\":\"Other\",\"previousSibling\":{\"id\":1600},\"parentNode\":{\"id\":1599}},{\"nodeType\":3,\"id\":1602,\"textContent\":\"*\",\"parentNode\":{\"id\":1589}},{\"nodeType\":1,\"id\":1603,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1604,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1603},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1605,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1604},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1605},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1606},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1607},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1609,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1608},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1609},\"parentNode\":{\"id\":1579}},{\"nodeType\":3,\"id\":1611,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":1603}},{\"nodeType\":1,\"id\":1612,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1611},\"parentNode\":{\"id\":1603}},{\"nodeType\":1,\"id\":1613,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1604}},{\"nodeType\":1,\"id\":1614,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1613}},{\"nodeType\":3,\"id\":1615,\"textContent\":\"First\",\"previousSibling\":{\"id\":1614},\"parentNode\":{\"id\":1613}},{\"nodeType\":1,\"id\":1616,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1605}},{\"nodeType\":1,\"id\":1617,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1616}},{\"nodeType\":3,\"id\":1618,\"textContent\":\"Second\",\"previousSibling\":{\"id\":1617},\"parentNode\":{\"id\":1616}},{\"nodeType\":1,\"id\":1619,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1606}},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1619}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"Third\",\"previousSibling\":{\"id\":1620},\"parentNode\":{\"id\":1619}},{\"nodeType\":1,\"id\":1622,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1607}},{\"nodeType\":1,\"id\":1623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1622}},{\"nodeType\":3,\"id\":1624,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":1623},\"parentNode\":{\"id\":1622}},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1608}},{\"nodeType\":1,\"id\":1626,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1625}},{\"nodeType\":3,\"id\":1627,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":1626},\"parentNode\":{\"id\":1625}},{\"nodeType\":1,\"id\":1628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1609}},{\"nodeType\":1,\"id\":1629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1628}},{\"nodeType\":3,\"id\":1630,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":1629},\"parentNode\":{\"id\":1628}},{\"nodeType\":1,\"id\":1631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1610}},{\"nodeType\":1,\"id\":1632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1631}},{\"nodeType\":3,\"id\":1633,\"textContent\":\"Other\",\"previousSibling\":{\"id\":1632},\"parentNode\":{\"id\":1631}},{\"nodeType\":3,\"id\":1634,\"textContent\":\"*\",\"parentNode\":{\"id\":1612}},{\"nodeType\":1,\"id\":1635,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1636,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1635},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1636},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1637},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1638},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1639},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1640},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1641},\"parentNode\":{\"id\":1580}},{\"nodeType\":3,\"id\":1643,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":1635}},{\"nodeType\":1,\"id\":1644,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1643},\"parentNode\":{\"id\":1635}},{\"nodeType\":1,\"id\":1645,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1636}},{\"nodeType\":1,\"id\":1646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1645}},{\"nodeType\":3,\"id\":1647,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":1646},\"parentNode\":{\"id\":1645}},{\"nodeType\":1,\"id\":1648,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1637}},{\"nodeType\":1,\"id\":1649,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1648}},{\"nodeType\":3,\"id\":1650,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":1649},\"parentNode\":{\"id\":1648}},{\"nodeType\":1,\"id\":1651,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1638}},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1651}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":1652},\"parentNode\":{\"id\":1651}},{\"nodeType\":1,\"id\":1654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1639}},{\"nodeType\":1,\"id\":1655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1654}},{\"nodeType\":3,\"id\":1656,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":1655},\"parentNode\":{\"id\":1654}},{\"nodeType\":1,\"id\":1657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1640}},{\"nodeType\":1,\"id\":1658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1657}},{\"nodeType\":3,\"id\":1659,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":1658},\"parentNode\":{\"id\":1657}},{\"nodeType\":1,\"id\":1660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1641}},{\"nodeType\":1,\"id\":1661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1660}},{\"nodeType\":3,\"id\":1662,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":1661},\"parentNode\":{\"id\":1660}},{\"nodeType\":1,\"id\":1663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1642}},{\"nodeType\":1,\"id\":1664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1663}},{\"nodeType\":3,\"id\":1665,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":1664},\"parentNode\":{\"id\":1663}},{\"nodeType\":3,\"id\":1666,\"textContent\":\"*\",\"parentNode\":{\"id\":1644}},{\"nodeType\":1,\"id\":1667,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1581}},{\"nodeType\":1,\"id\":1668,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1667},\"parentNode\":{\"id\":1581}},{\"nodeType\":1,\"id\":1669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1668},\"parentNode\":{\"id\":1581}},{\"nodeType\":1,\"id\":1670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1669},\"parentNode\":{\"id\":1581}},{\"nodeType\":3,\"id\":1671,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":1667}},{\"nodeType\":1,\"id\":1672,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1671},\"parentNode\":{\"id\":1667}},{\"nodeType\":1,\"id\":1673,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1668}},{\"nodeType\":1,\"id\":1674,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1673}},{\"nodeType\":3,\"id\":1675,\"textContent\":\"Male\",\"previousSibling\":{\"id\":1674},\"parentNode\":{\"id\":1673}},{\"nodeType\":1,\"id\":1676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1669}},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1676}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"Female\",\"previousSibling\":{\"id\":1677},\"parentNode\":{\"id\":1676}},{\"nodeType\":1,\"id\":1679,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1670}},{\"nodeType\":1,\"id\":1680,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1679}},{\"nodeType\":3,\"id\":1681,\"textContent\":\"Other\",\"previousSibling\":{\"id\":1680},\"parentNode\":{\"id\":1679}},{\"nodeType\":3,\"id\":1682,\"textContent\":\"*\",\"parentNode\":{\"id\":1672}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1583},{\"id\":1588},{\"id\":1589},{\"id\":1602},{\"id\":1584},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1585},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1586},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1587},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1579},{\"id\":1603},{\"id\":1611},{\"id\":1612},{\"id\":1634},{\"id\":1604},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1605},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1606},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1607},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1608},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1609},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1610},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1580},{\"id\":1635},{\"id\":1643},{\"id\":1644},{\"id\":1666},{\"id\":1636},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1637},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1638},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1639},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1640},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1641},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1642},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1581},{\"id\":1667},{\"id\":1671},{\"id\":1672},{\"id\":1682},{\"id\":1668},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1669},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1670},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1582}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1683,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":53}},{\"nodeType\":3,\"id\":1684,\"textContent\":\" \",\"previousSibling\":{\"id\":1683},\"parentNode\":{\"id\":53}},{\"nodeType\":3,\"id\":1685,\"textContent\":\" \",\"parentNode\":{\"id\":1683}},{\"nodeType\":1,\"id\":1686,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":1685},\"parentNode\":{\"id\":1683}},{\"nodeType\":3,\"id\":1687,\"textContent\":\" \",\"previousSibling\":{\"id\":1686},\"parentNode\":{\"id\":1683}},{\"nodeType\":1,\"id\":1688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":1687},\"parentNode\":{\"id\":1683}},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \",\"previousSibling\":{\"id\":1688},\"parentNode\":{\"id\":1683}},{\"nodeType\":1,\"id\":1690,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":1689},\"parentNode\":{\"id\":1683}},{\"nodeType\":3,\"id\":1691,\"textContent\":\" \",\"previousSibling\":{\"id\":1690},\"parentNode\":{\"id\":1683}},{\"nodeType\":3,\"id\":1692,\"textContent\":\" \",\"parentNode\":{\"id\":1686}},{\"nodeType\":1,\"id\":1693,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":1692},\"parentNode\":{\"id\":1686}},{\"nodeType\":3,\"id\":1694,\"textContent\":\" \",\"previousSibling\":{\"id\":1693},\"parentNode\":{\"id\":1686}},{\"nodeType\":3,\"id\":1695,\"textContent\":\" \",\"parentNode\":{\"id\":1693}},{\"nodeType\":1,\"id\":1696,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":1695},\"parentNode\":{\"id\":1693}},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \",\"previousSibling\":{\"id\":1696},\"parentNode\":{\"id\":1693}},{\"nodeType\":3,\"id\":1698,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":1696}},{\"nodeType\":3,\"id\":1699,\"textContent\":\" \",\"parentNode\":{\"id\":1688}},{\"nodeType\":1,\"id\":1700,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":1699},\"parentNode\":{\"id\":1688}},{\"nodeType\":3,\"id\":1701,\"textContent\":\" \",\"previousSibling\":{\"id\":1700},\"parentNode\":{\"id\":1688}},{\"nodeType\":3,\"id\":1702,\"textContent\":\" \",\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1703,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":1702},\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1704,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":1703},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \",\"previousSibling\":{\"id\":1704},\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1706,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":1705},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1707,\"textContent\":\" \",\"previousSibling\":{\"id\":1706},\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1708,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":1707},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1709,\"textContent\":\" \",\"previousSibling\":{\"id\":1708},\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1710,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":1709},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1711,\"textContent\":\" \",\"previousSibling\":{\"id\":1710},\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1712,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":1711},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \",\"previousSibling\":{\"id\":1712},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1714,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":1703}},{\"nodeType\":3,\"id\":1715,\"textContent\":\" \",\"parentNode\":{\"id\":1704}},{\"nodeType\":1,\"id\":1716,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":1715},\"parentNode\":{\"id\":1704}},{\"nodeType\":3,\"id\":1717,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":1716},\"parentNode\":{\"id\":1704}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":1716}},{\"nodeType\":3,\"id\":1719,\"textContent\":\" \",\"parentNode\":{\"id\":1706}},{\"nodeType\":1,\"id\":1720,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":1719},\"parentNode\":{\"id\":1706}},{\"nodeType\":3,\"id\":1721,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":1720},\"parentNode\":{\"id\":1706}},{\"nodeType\":3,\"id\":1722,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":1720}},{\"nodeType\":1,\"id\":1723,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":1708}},{\"nodeType\":3,\"id\":1724,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":1723},\"parentNode\":{\"id\":1708}},{\"nodeType\":3,\"id\":1725,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":1723}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":1710}},{\"nodeType\":3,\"id\":1727,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":1712}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \",\"parentNode\":{\"id\":1690}},{\"nodeType\":1,\"id\":1729,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":1728},\"parentNode\":{\"id\":1690}},{\"nodeType\":3,\"id\":1730,\"textContent\":\" \",\"previousSibling\":{\"id\":1729},\"parentNode\":{\"id\":1690}},{\"nodeType\":3,\"id\":1731,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":1729}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":1683},{\"id\":1685},{\"id\":1686},{\"id\":1692},{\"id\":1693},{\"id\":1695},{\"id\":1696},{\"id\":1698},{\"id\":1697},{\"id\":1694},{\"id\":1687},{\"id\":1688},{\"id\":1699},{\"id\":1700},{\"id\":1702},{\"id\":1703},{\"id\":1714},{\"id\":1704},{\"id\":1715},{\"id\":1716},{\"id\":1718},{\"id\":1717},{\"id\":1705},{\"id\":1706},{\"id\":1719},{\"id\":1720},{\"id\":1722},{\"id\":1721},{\"id\":1707},{\"id\":1708},{\"id\":1723},{\"id\":1725},{\"id\":1724},{\"id\":1709},{\"id\":1710},{\"id\":1726},{\"id\":1711},{\"id\":1712},{\"id\":1727},{\"id\":1713},{\"id\":1701},{\"id\":1689},{\"id\":1690},{\"id\":1728},{\"id\":1729},{\"id\":1731},{\"id\":1730},{\"id\":1691},{\"id\":1684}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1732,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":53}},{\"nodeType\":3,\"id\":1733,\"textContent\":\"[ { \\\"rt\\\": 94184, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 94190, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\" }, { \\\"rt\\\": 14086, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 109625, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\" }, { \\\"rt\\\": 7771, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"foxtrot\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"321\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 118413, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\" }, { \\\"rt\\\": 18203, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 137704, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\" }, { \\\"rt\\\": 16658, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 155365, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\" }, { \\\"rt\\\": 56492, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 213140, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-01 PM-12 PM-11 AM-11 AM-O -I -O -O -O -I -I -I -J -J -J -H -F -F -F -F -A -A -A -U -Z -U -U -B -B -G -G -G -K -K -K -H -H -H -H -J -D -D -E -E -X -X -J -J -J -H -H -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:919,y:935,t:1511831364154};\\\", \\\"{x:914,y:926,t:1511831364170};\\\", \\\"{x:912,y:919,t:1511831364186};\\\", \\\"{x:907,y:907,t:1511831364203};\\\", \\\"{x:895,y:891,t:1511831364220};\\\", \\\"{x:879,y:875,t:1511831364236};\\\", \\\"{x:861,y:859,t:1511831364253};\\\", \\\"{x:844,y:837,t:1511831364270};\\\", \\\"{x:824,y:800,t:1511831364287};\\\", \\\"{x:793,y:760,t:1511831364303};\\\", \\\"{x:761,y:715,t:1511831364320};\\\", \\\"{x:716,y:645,t:1511831364337};\\\", \\\"{x:697,y:596,t:1511831364353};\\\", \\\"{x:689,y:546,t:1511831364369};\\\", \\\"{x:682,y:498,t:1511831364386};\\\", \\\"{x:673,y:457,t:1511831364403};\\\", \\\"{x:663,y:428,t:1511831364419};\\\", \\\"{x:651,y:403,t:1511831364436};\\\", \\\"{x:644,y:385,t:1511831364453};\\\", \\\"{x:638,y:375,t:1511831364469};\\\", \\\"{x:631,y:367,t:1511831364487};\\\", \\\"{x:625,y:361,t:1511831364504};\\\", \\\"{x:622,y:359,t:1511831364519};\\\", \\\"{x:620,y:359,t:1511831364553};\\\", \\\"{x:615,y:359,t:1511831364569};\\\", \\\"{x:602,y:365,t:1511831364586};\\\", \\\"{x:586,y:377,t:1511831364603};\\\", \\\"{x:579,y:383,t:1511831364619};\\\", \\\"{x:576,y:384,t:1511831364636};\\\", \\\"{x:575,y:385,t:1511831364653};\\\", \\\"{x:574,y:385,t:1511831364669};\\\", \\\"{x:573,y:385,t:1511831364688};\\\", \\\"{x:572,y:385,t:1511831364704};\\\", \\\"{x:571,y:386,t:1511831364719};\\\", \\\"{x:565,y:389,t:1511831364736};\\\", \\\"{x:554,y:398,t:1511831364753};\\\", \\\"{x:543,y:408,t:1511831364769};\\\", \\\"{x:534,y:415,t:1511831364786};\\\", \\\"{x:527,y:422,t:1511831364803};\\\", \\\"{x:517,y:431,t:1511831364820};\\\", \\\"{x:511,y:438,t:1511831364836};\\\", \\\"{x:501,y:445,t:1511831364853};\\\", \\\"{x:487,y:457,t:1511831364870};\\\", \\\"{x:478,y:465,t:1511831364886};\\\", \\\"{x:470,y:471,t:1511831364903};\\\", \\\"{x:463,y:478,t:1511831364920};\\\", \\\"{x:454,y:485,t:1511831364936};\\\", \\\"{x:439,y:495,t:1511831364953};\\\", \\\"{x:430,y:503,t:1511831364970};\\\", \\\"{x:421,y:508,t:1511831364986};\\\", \\\"{x:416,y:516,t:1511831365003};\\\", \\\"{x:411,y:523,t:1511831365020};\\\", \\\"{x:403,y:533,t:1511831365036};\\\", \\\"{x:398,y:538,t:1511831365053};\\\", \\\"{x:397,y:540,t:1511831365070};\\\", \\\"{x:397,y:541,t:1511831365086};\\\", \\\"{x:397,y:542,t:1511831365113};\\\", \\\"{x:395,y:544,t:1511831365121};\\\", \\\"{x:394,y:546,t:1511831365136};\\\", \\\"{x:390,y:549,t:1511831365153};\\\", \\\"{x:386,y:553,t:1511831365170};\\\", \\\"{x:382,y:558,t:1511831365186};\\\", \\\"{x:375,y:565,t:1511831365203};\\\", \\\"{x:368,y:572,t:1511831365220};\\\", \\\"{x:365,y:574,t:1511831365236};\\\", \\\"{x:362,y:576,t:1511831365253};\\\", \\\"{x:360,y:577,t:1511831365313};\\\", \\\"{x:359,y:577,t:1511831365320};\\\", \\\"{x:354,y:577,t:1511831365337};\\\", \\\"{x:349,y:580,t:1511831365353};\\\", \\\"{x:343,y:581,t:1511831365370};\\\", \\\"{x:332,y:585,t:1511831365387};\\\", \\\"{x:325,y:585,t:1511831365403};\\\", \\\"{x:317,y:586,t:1511831365420};\\\", \\\"{x:309,y:588,t:1511831365437};\\\", \\\"{x:300,y:589,t:1511831365453};\\\", \\\"{x:286,y:591,t:1511831365470};\\\", \\\"{x:278,y:593,t:1511831365487};\\\", \\\"{x:274,y:593,t:1511831365503};\\\", \\\"{x:271,y:593,t:1511831365520};\\\", \\\"{x:270,y:593,t:1511831365568};\\\", \\\"{x:270,y:591,t:1511831365584};\\\", \\\"{x:271,y:589,t:1511831365592};\\\", \\\"{x:274,y:587,t:1511831365603};\\\", \\\"{x:288,y:583,t:1511831365620};\\\", \\\"{x:312,y:581,t:1511831365638};\\\", \\\"{x:342,y:581,t:1511831365653};\\\", \\\"{x:372,y:581,t:1511831365670};\\\", \\\"{x:415,y:581,t:1511831365687};\\\", \\\"{x:477,y:581,t:1511831365704};\\\", \\\"{x:522,y:581,t:1511831365720};\\\", \\\"{x:561,y:581,t:1511831365737};\\\", \\\"{x:600,y:581,t:1511831365754};\\\", \\\"{x:637,y:581,t:1511831365770};\\\", \\\"{x:669,y:581,t:1511831365787};\\\", \\\"{x:696,y:581,t:1511831365804};\\\", \\\"{x:722,y:581,t:1511831365820};\\\", \\\"{x:743,y:581,t:1511831365837};\\\", \\\"{x:764,y:579,t:1511831365854};\\\", \\\"{x:780,y:576,t:1511831365870};\\\", \\\"{x:794,y:573,t:1511831365887};\\\", \\\"{x:807,y:565,t:1511831365904};\\\", \\\"{x:811,y:562,t:1511831365921};\\\", \\\"{x:814,y:559,t:1511831365937};\\\", \\\"{x:818,y:554,t:1511831365954};\\\", \\\"{x:824,y:548,t:1511831365971};\\\", \\\"{x:832,y:540,t:1511831365988};\\\", \\\"{x:844,y:531,t:1511831366005};\\\", \\\"{x:852,y:525,t:1511831366022};\\\", \\\"{x:864,y:518,t:1511831366038};\\\", \\\"{x:883,y:510,t:1511831366055};\\\", \\\"{x:904,y:505,t:1511831366072};\\\", \\\"{x:930,y:498,t:1511831366088};\\\", \\\"{x:974,y:489,t:1511831366104};\\\", \\\"{x:1003,y:486,t:1511831366121};\\\", \\\"{x:1021,y:484,t:1511831366137};\\\", \\\"{x:1031,y:481,t:1511831366155};\\\", \\\"{x:1036,y:481,t:1511831366172};\\\", \\\"{x:1037,y:480,t:1511831366188};\\\", \\\"{x:1040,y:479,t:1511831366205};\\\", \\\"{x:1042,y:475,t:1511831366222};\\\", \\\"{x:1049,y:465,t:1511831366238};\\\", \\\"{x:1064,y:451,t:1511831366255};\\\", \\\"{x:1078,y:437,t:1511831366272};\\\", \\\"{x:1092,y:424,t:1511831366288};\\\", \\\"{x:1120,y:399,t:1511831366304};\\\", \\\"{x:1134,y:385,t:1511831366322};\\\", \\\"{x:1148,y:368,t:1511831366338};\\\", \\\"{x:1167,y:348,t:1511831366355};\\\", \\\"{x:1178,y:339,t:1511831366371};\\\", \\\"{x:1183,y:333,t:1511831366389};\\\", \\\"{x:1184,y:332,t:1511831366404};\\\", \\\"{x:1187,y:329,t:1511831366422};\\\", \\\"{x:1190,y:327,t:1511831366439};\\\", \\\"{x:1194,y:323,t:1511831366455};\\\", \\\"{x:1205,y:313,t:1511831366472};\\\", \\\"{x:1216,y:299,t:1511831366488};\\\", \\\"{x:1232,y:281,t:1511831366505};\\\", \\\"{x:1245,y:265,t:1511831366522};\\\", \\\"{x:1254,y:255,t:1511831366539};\\\", \\\"{x:1258,y:250,t:1511831366555};\\\", \\\"{x:1258,y:249,t:1511831366633};\\\", \\\"{x:1258,y:254,t:1511831366705};\\\", \\\"{x:1258,y:278,t:1511831366722};\\\", \\\"{x:1258,y:305,t:1511831366739};\\\", \\\"{x:1258,y:329,t:1511831366755};\\\", \\\"{x:1261,y:355,t:1511831366772};\\\", \\\"{x:1264,y:376,t:1511831366789};\\\", \\\"{x:1266,y:391,t:1511831366806};\\\", \\\"{x:1268,y:407,t:1511831366821};\\\", \\\"{x:1269,y:422,t:1511831366839};\\\", \\\"{x:1272,y:437,t:1511831366856};\\\", \\\"{x:1274,y:453,t:1511831366872};\\\", \\\"{x:1278,y:478,t:1511831366888};\\\", \\\"{x:1282,y:495,t:1511831366906};\\\", \\\"{x:1283,y:507,t:1511831366922};\\\", \\\"{x:1284,y:521,t:1511831366939};\\\", \\\"{x:1284,y:534,t:1511831366956};\\\", \\\"{x:1284,y:544,t:1511831366971};\\\", \\\"{x:1284,y:553,t:1511831366989};\\\", \\\"{x:1285,y:569,t:1511831367006};\\\", \\\"{x:1285,y:588,t:1511831367022};\\\", \\\"{x:1288,y:607,t:1511831367039};\\\", \\\"{x:1289,y:626,t:1511831367056};\\\", \\\"{x:1293,y:648,t:1511831367072};\\\", \\\"{x:1295,y:654,t:1511831367088};\\\", \\\"{x:1296,y:658,t:1511831367106};\\\", \\\"{x:1297,y:660,t:1511831367122};\\\", \\\"{x:1298,y:663,t:1511831367139};\\\", \\\"{x:1301,y:671,t:1511831367156};\\\", \\\"{x:1301,y:678,t:1511831367172};\\\", \\\"{x:1303,y:687,t:1511831367189};\\\", \\\"{x:1304,y:696,t:1511831367206};\\\", \\\"{x:1305,y:705,t:1511831367222};\\\", \\\"{x:1306,y:712,t:1511831367239};\\\", \\\"{x:1307,y:718,t:1511831367256};\\\", \\\"{x:1309,y:728,t:1511831367272};\\\", \\\"{x:1309,y:733,t:1511831367289};\\\", \\\"{x:1309,y:737,t:1511831367306};\\\", \\\"{x:1309,y:741,t:1511831367323};\\\", \\\"{x:1309,y:746,t:1511831367339};\\\", \\\"{x:1309,y:751,t:1511831367356};\\\", \\\"{x:1309,y:758,t:1511831367373};\\\", \\\"{x:1309,y:766,t:1511831367389};\\\", \\\"{x:1308,y:777,t:1511831367406};\\\", \\\"{x:1304,y:786,t:1511831367423};\\\", \\\"{x:1303,y:790,t:1511831367439};\\\", \\\"{x:1302,y:795,t:1511831367456};\\\", \\\"{x:1301,y:802,t:1511831367473};\\\", \\\"{x:1300,y:808,t:1511831367489};\\\", \\\"{x:1298,y:817,t:1511831367506};\\\", \\\"{x:1296,y:823,t:1511831367523};\\\", \\\"{x:1294,y:831,t:1511831367540};\\\", \\\"{x:1291,y:839,t:1511831367556};\\\", \\\"{x:1291,y:843,t:1511831367573};\\\", \\\"{x:1287,y:850,t:1511831367589};\\\", \\\"{x:1286,y:854,t:1511831367605};\\\", \\\"{x:1284,y:857,t:1511831367622};\\\", \\\"{x:1284,y:862,t:1511831367639};\\\", \\\"{x:1283,y:869,t:1511831367655};\\\", \\\"{x:1282,y:880,t:1511831367672};\\\", \\\"{x:1279,y:893,t:1511831367689};\\\", \\\"{x:1277,y:907,t:1511831367705};\\\", \\\"{x:1272,y:922,t:1511831367722};\\\", \\\"{x:1266,y:937,t:1511831367739};\\\", \\\"{x:1263,y:947,t:1511831367755};\\\", \\\"{x:1258,y:955,t:1511831367772};\\\", \\\"{x:1254,y:961,t:1511831367789};\\\", \\\"{x:1251,y:967,t:1511831367805};\\\", \\\"{x:1249,y:971,t:1511831367822};\\\", \\\"{x:1248,y:974,t:1511831367839};\\\", \\\"{x:1246,y:978,t:1511831367856};\\\", \\\"{x:1244,y:980,t:1511831367872};\\\", \\\"{x:1242,y:983,t:1511831367889};\\\", \\\"{x:1240,y:985,t:1511831367906};\\\", \\\"{x:1237,y:987,t:1511831367922};\\\", \\\"{x:1236,y:987,t:1511831367939};\\\", \\\"{x:1231,y:989,t:1511831367956};\\\", \\\"{x:1225,y:992,t:1511831367973};\\\", \\\"{x:1217,y:996,t:1511831367991};\\\", \\\"{x:1202,y:1002,t:1511831368006};\\\", \\\"{x:1189,y:1007,t:1511831368023};\\\", \\\"{x:1174,y:1013,t:1511831368040};\\\", \\\"{x:1148,y:1022,t:1511831368056};\\\", \\\"{x:1140,y:1024,t:1511831368072};\\\", \\\"{x:1136,y:1026,t:1511831368090};\\\", \\\"{x:1134,y:1026,t:1511831368107};\\\", \\\"{x:1129,y:1027,t:1511831368123};\\\", \\\"{x:1119,y:1029,t:1511831368140};\\\", \\\"{x:1107,y:1035,t:1511831368157};\\\", \\\"{x:1088,y:1041,t:1511831368173};\\\", \\\"{x:1071,y:1046,t:1511831368190};\\\", \\\"{x:1049,y:1053,t:1511831368207};\\\", \\\"{x:1024,y:1059,t:1511831368222};\\\", \\\"{x:1013,y:1063,t:1511831368240};\\\", \\\"{x:1010,y:1063,t:1511831368256};\\\", \\\"{x:1007,y:1063,t:1511831368273};\\\", \\\"{x:1000,y:1061,t:1511831368289};\\\", \\\"{x:994,y:1058,t:1511831368307};\\\", \\\"{x:989,y:1058,t:1511831368323};\\\", \\\"{x:983,y:1058,t:1511831368339};\\\", \\\"{x:977,y:1058,t:1511831368356};\\\", \\\"{x:971,y:1057,t:1511831368373};\\\", \\\"{x:962,y:1054,t:1511831368389};\\\", \\\"{x:957,y:1052,t:1511831368407};\\\", \\\"{x:952,y:1048,t:1511831368423};\\\", \\\"{x:945,y:1042,t:1511831368440};\\\", \\\"{x:938,y:1029,t:1511831368456};\\\", \\\"{x:928,y:1015,t:1511831368474};\\\", \\\"{x:925,y:1009,t:1511831368490};\\\", \\\"{x:925,y:1008,t:1511831368537};\\\", \\\"{x:925,y:1007,t:1511831368544};\\\", \\\"{x:926,y:1004,t:1511831368557};\\\", \\\"{x:956,y:999,t:1511831368574};\\\", \\\"{x:1010,y:996,t:1511831368590};\\\", \\\"{x:1069,y:996,t:1511831368607};\\\", \\\"{x:1119,y:996,t:1511831368624};\\\", \\\"{x:1166,y:996,t:1511831368640};\\\", \\\"{x:1200,y:996,t:1511831368656};\\\", \\\"{x:1209,y:996,t:1511831368674};\\\", \\\"{x:1209,y:995,t:1511831368729};\\\", \\\"{x:1209,y:994,t:1511831368741};\\\", \\\"{x:1208,y:994,t:1511831368768};\\\", \\\"{x:1206,y:994,t:1511831368776};\\\", \\\"{x:1201,y:994,t:1511831368790};\\\", \\\"{x:1194,y:994,t:1511831368807};\\\", \\\"{x:1185,y:994,t:1511831368824};\\\", \\\"{x:1167,y:994,t:1511831368840};\\\", \\\"{x:1155,y:994,t:1511831368856};\\\", \\\"{x:1142,y:994,t:1511831368873};\\\", \\\"{x:1133,y:993,t:1511831368890};\\\", \\\"{x:1122,y:989,t:1511831368906};\\\", \\\"{x:1112,y:984,t:1511831368923};\\\", \\\"{x:1104,y:982,t:1511831368940};\\\", \\\"{x:1096,y:979,t:1511831368956};\\\", \\\"{x:1085,y:977,t:1511831368973};\\\", \\\"{x:1072,y:977,t:1511831368990};\\\", \\\"{x:1064,y:977,t:1511831369006};\\\", \\\"{x:1055,y:977,t:1511831369023};\\\", \\\"{x:1048,y:977,t:1511831369040};\\\", \\\"{x:1045,y:977,t:1511831369057};\\\", \\\"{x:1044,y:977,t:1511831369217};\\\", \\\"{x:1043,y:975,t:1511831369224};\\\", \\\"{x:1043,y:973,t:1511831369240};\\\", \\\"{x:1042,y:972,t:1511831369272};\\\", \\\"{x:1041,y:972,t:1511831369545};\\\", \\\"{x:1041,y:970,t:1511831369560};\\\", \\\"{x:1041,y:967,t:1511831369689};\\\", \\\"{x:1041,y:966,t:1511831369696};\\\", \\\"{x:1041,y:965,t:1511831369708};\\\", \\\"{x:1041,y:963,t:1511831369725};\\\", \\\"{x:1040,y:962,t:1511831369745};\\\", \\\"{x:1040,y:964,t:1511831370416};\\\", \\\"{x:1040,y:965,t:1511831370424};\\\", \\\"{x:1038,y:967,t:1511831370441};\\\", \\\"{x:1038,y:971,t:1511831370617};\\\", \\\"{x:1038,y:972,t:1511831370624};\\\", \\\"{x:1038,y:975,t:1511831370642};\\\", \\\"{x:1039,y:978,t:1511831370659};\\\", \\\"{x:1041,y:980,t:1511831370675};\\\", \\\"{x:1041,y:981,t:1511831370692};\\\", \\\"{x:1043,y:981,t:1511831370993};\\\", \\\"{x:1047,y:960,t:1511831371009};\\\", \\\"{x:1052,y:929,t:1511831371026};\\\", \\\"{x:1059,y:890,t:1511831371042};\\\", \\\"{x:1067,y:834,t:1511831371059};\\\", \\\"{x:1068,y:804,t:1511831371076};\\\", \\\"{x:1068,y:781,t:1511831371092};\\\", \\\"{x:1068,y:760,t:1511831371109};\\\", \\\"{x:1067,y:744,t:1511831371126};\\\", \\\"{x:1063,y:729,t:1511831371142};\\\", \\\"{x:1059,y:717,t:1511831371159};\\\", \\\"{x:1055,y:708,t:1511831371175};\\\", \\\"{x:1051,y:694,t:1511831371192};\\\", \\\"{x:1050,y:689,t:1511831371208};\\\", \\\"{x:1047,y:683,t:1511831371226};\\\", \\\"{x:1047,y:679,t:1511831371243};\\\", \\\"{x:1046,y:675,t:1511831371259};\\\", \\\"{x:1046,y:672,t:1511831371276};\\\", \\\"{x:1044,y:669,t:1511831371293};\\\", \\\"{x:1044,y:666,t:1511831371309};\\\", \\\"{x:1043,y:663,t:1511831371326};\\\", \\\"{x:1042,y:658,t:1511831371343};\\\", \\\"{x:1041,y:655,t:1511831371359};\\\", \\\"{x:1039,y:651,t:1511831371376};\\\", \\\"{x:1037,y:646,t:1511831371392};\\\", \\\"{x:1033,y:643,t:1511831371409};\\\", \\\"{x:1030,y:641,t:1511831371426};\\\", \\\"{x:1029,y:640,t:1511831371443};\\\", \\\"{x:1024,y:640,t:1511831371459};\\\", \\\"{x:1023,y:640,t:1511831371545};\\\", \\\"{x:1022,y:639,t:1511831371568};\\\", \\\"{x:1020,y:639,t:1511831371713};\\\", \\\"{x:1018,y:639,t:1511831371725};\\\", \\\"{x:1017,y:637,t:1511831371743};\\\", \\\"{x:1016,y:637,t:1511831371856};\\\", \\\"{x:1015,y:634,t:1511831371863};\\\", \\\"{x:1015,y:633,t:1511831371875};\\\", \\\"{x:1014,y:633,t:1511831371899};\\\", \\\"{x:1019,y:655,t:1511831372075};\\\", \\\"{x:1024,y:680,t:1511831372092};\\\", \\\"{x:1033,y:708,t:1511831372109};\\\", \\\"{x:1043,y:734,t:1511831372125};\\\", \\\"{x:1050,y:753,t:1511831372142};\\\", \\\"{x:1053,y:765,t:1511831372159};\\\", \\\"{x:1054,y:770,t:1511831372175};\\\", \\\"{x:1056,y:783,t:1511831372192};\\\", \\\"{x:1056,y:797,t:1511831372209};\\\", \\\"{x:1055,y:815,t:1511831372225};\\\", \\\"{x:1051,y:835,t:1511831372242};\\\", \\\"{x:1048,y:852,t:1511831372259};\\\", \\\"{x:1045,y:868,t:1511831372275};\\\", \\\"{x:1045,y:878,t:1511831372292};\\\", \\\"{x:1045,y:885,t:1511831372309};\\\", \\\"{x:1045,y:888,t:1511831372325};\\\", \\\"{x:1044,y:891,t:1511831372384};\\\", \\\"{x:1043,y:895,t:1511831372392};\\\", \\\"{x:1040,y:904,t:1511831372409};\\\", \\\"{x:1034,y:913,t:1511831372426};\\\", \\\"{x:1032,y:916,t:1511831372443};\\\", \\\"{x:1032,y:908,t:1511831372472};\\\", \\\"{x:1033,y:893,t:1511831372479};\\\", \\\"{x:1034,y:872,t:1511831372492};\\\", \\\"{x:1043,y:803,t:1511831372509};\\\", \\\"{x:1043,y:711,t:1511831372526};\\\", \\\"{x:1058,y:614,t:1511831372542};\\\", \\\"{x:1067,y:553,t:1511831372559};\\\", \\\"{x:1073,y:496,t:1511831372579};\\\", \\\"{x:1075,y:482,t:1511831372593};\\\", \\\"{x:1075,y:480,t:1511831372609};\\\", \\\"{x:1067,y:488,t:1511831372720};\\\", \\\"{x:1056,y:500,t:1511831372727};\\\", \\\"{x:1037,y:531,t:1511831372743};\\\", \\\"{x:990,y:598,t:1511831372759};\\\", \\\"{x:943,y:660,t:1511831372776};\\\", \\\"{x:931,y:679,t:1511831372794};\\\", \\\"{x:929,y:682,t:1511831372809};\\\", \\\"{x:929,y:683,t:1511831372848};\\\", \\\"{x:931,y:683,t:1511831372864};\\\", \\\"{x:932,y:681,t:1511831372877};\\\", \\\"{x:936,y:676,t:1511831372894};\\\", \\\"{x:938,y:674,t:1511831372911};\\\", \\\"{x:943,y:672,t:1511831372927};\\\", \\\"{x:953,y:670,t:1511831372944};\\\", \\\"{x:972,y:666,t:1511831372960};\\\", \\\"{x:982,y:662,t:1511831372977};\\\", \\\"{x:993,y:660,t:1511831372994};\\\", \\\"{x:996,y:656,t:1511831373011};\\\", \\\"{x:998,y:655,t:1511831373027};\\\", \\\"{x:999,y:654,t:1511831373044};\\\", \\\"{x:1000,y:652,t:1511831373061};\\\", \\\"{x:1000,y:651,t:1511831373088};\\\", \\\"{x:1002,y:650,t:1511831373096};\\\", \\\"{x:1002,y:649,t:1511831373111};\\\", \\\"{x:1004,y:649,t:1511831373127};\\\", \\\"{x:1005,y:647,t:1511831373144};\\\", \\\"{x:1006,y:646,t:1511831373160};\\\", \\\"{x:1007,y:644,t:1511831373178};\\\", \\\"{x:1009,y:640,t:1511831373194};\\\", \\\"{x:1010,y:634,t:1511831373218};\\\", \\\"{x:1012,y:629,t:1511831373227};\\\", \\\"{x:1014,y:626,t:1511831373243};\\\", \\\"{x:1015,y:624,t:1511831373261};\\\", \\\"{x:1012,y:625,t:1511831373546};\\\", \\\"{x:1010,y:626,t:1511831373560};\\\", \\\"{x:1008,y:627,t:1511831373576};\\\", \\\"{x:1010,y:624,t:1511831381101};\\\", \\\"{x:1023,y:613,t:1511831381128};\\\", \\\"{x:1028,y:608,t:1511831381149};\\\", \\\"{x:1032,y:605,t:1511831381166};\\\", \\\"{x:1037,y:597,t:1511831381183};\\\", \\\"{x:1040,y:592,t:1511831381199};\\\", \\\"{x:1042,y:584,t:1511831381216};\\\", \\\"{x:1046,y:574,t:1511831381233};\\\", \\\"{x:1051,y:560,t:1511831381249};\\\", \\\"{x:1055,y:549,t:1511831381266};\\\", \\\"{x:1059,y:539,t:1511831381282};\\\", \\\"{x:1065,y:527,t:1511831381300};\\\", \\\"{x:1070,y:515,t:1511831381317};\\\", \\\"{x:1073,y:507,t:1511831381334};\\\", \\\"{x:1075,y:499,t:1511831381353};\\\", \\\"{x:1077,y:495,t:1511831381367};\\\", \\\"{x:1079,y:488,t:1511831381385};\\\", \\\"{x:1080,y:486,t:1511831381400};\\\", \\\"{x:1080,y:484,t:1511831381417};\\\", \\\"{x:1080,y:485,t:1511831381641};\\\", \\\"{x:1080,y:490,t:1511831381651};\\\", \\\"{x:1077,y:498,t:1511831381671};\\\", \\\"{x:1076,y:502,t:1511831381684};\\\", \\\"{x:1076,y:504,t:1511831381701};\\\", \\\"{x:1075,y:506,t:1511831381717};\\\", \\\"{x:1075,y:504,t:1511831382001};\\\", \\\"{x:1075,y:500,t:1511831382025};\\\", \\\"{x:1075,y:498,t:1511831382034};\\\", \\\"{x:1075,y:497,t:1511831382051};\\\", \\\"{x:1076,y:492,t:1511831383137};\\\", \\\"{x:1081,y:491,t:1511831383157};\\\", \\\"{x:1090,y:485,t:1511831383168};\\\", \\\"{x:1092,y:484,t:1511831383185};\\\", \\\"{x:1093,y:484,t:1511831383202};\\\", \\\"{x:1097,y:484,t:1511831383218};\\\", \\\"{x:1105,y:484,t:1511831383235};\\\", \\\"{x:1114,y:482,t:1511831383252};\\\", \\\"{x:1129,y:478,t:1511831383268};\\\", \\\"{x:1149,y:469,t:1511831383285};\\\", \\\"{x:1169,y:462,t:1511831383302};\\\", \\\"{x:1184,y:455,t:1511831383318};\\\", \\\"{x:1193,y:451,t:1511831383335};\\\", \\\"{x:1196,y:450,t:1511831383352};\\\", \\\"{x:1198,y:448,t:1511831383416};\\\", \\\"{x:1199,y:445,t:1511831383424};\\\", \\\"{x:1201,y:444,t:1511831383435};\\\", \\\"{x:1202,y:441,t:1511831383452};\\\", \\\"{x:1204,y:439,t:1511831383468};\\\", \\\"{x:1204,y:438,t:1511831383485};\\\", \\\"{x:1204,y:437,t:1511831383569};\\\", \\\"{x:1203,y:433,t:1511831383586};\\\", \\\"{x:1198,y:428,t:1511831383603};\\\", \\\"{x:1189,y:424,t:1511831383619};\\\", \\\"{x:1176,y:419,t:1511831383635};\\\", \\\"{x:1168,y:417,t:1511831383653};\\\", \\\"{x:1167,y:417,t:1511831383669};\\\", \\\"{x:1168,y:417,t:1511831383913};\\\", \\\"{x:1169,y:418,t:1511831383920};\\\", \\\"{x:1170,y:420,t:1511831383936};\\\", \\\"{x:1172,y:420,t:1511831383953};\\\", \\\"{x:1173,y:421,t:1511831384313};\\\", \\\"{x:1174,y:423,t:1511831384328};\\\", \\\"{x:1175,y:427,t:1511831384344};\\\", \\\"{x:1186,y:455,t:1511831384386};\\\", \\\"{x:1190,y:471,t:1511831384403};\\\", \\\"{x:1191,y:485,t:1511831384419};\\\", \\\"{x:1194,y:500,t:1511831384436};\\\", \\\"{x:1195,y:514,t:1511831384453};\\\", \\\"{x:1195,y:523,t:1511831384469};\\\", \\\"{x:1195,y:531,t:1511831384486};\\\", \\\"{x:1194,y:540,t:1511831384503};\\\", \\\"{x:1193,y:547,t:1511831384519};\\\", \\\"{x:1192,y:552,t:1511831384536};\\\", \\\"{x:1191,y:555,t:1511831384553};\\\", \\\"{x:1190,y:556,t:1511831384576};\\\", \\\"{x:1188,y:557,t:1511831384592};\\\", \\\"{x:1186,y:558,t:1511831384603};\\\", \\\"{x:1184,y:560,t:1511831384619};\\\", \\\"{x:1181,y:560,t:1511831384641};\\\", \\\"{x:1179,y:561,t:1511831384652};\\\", \\\"{x:1178,y:561,t:1511831384669};\\\", \\\"{x:1177,y:562,t:1511831384744};\\\", \\\"{x:1175,y:563,t:1511831384776};\\\", \\\"{x:1174,y:563,t:1511831384816};\\\", \\\"{x:1174,y:564,t:1511831385433};\\\", \\\"{x:1174,y:565,t:1511831385440};\\\", \\\"{x:1174,y:567,t:1511831385453};\\\", \\\"{x:1174,y:570,t:1511831385486};\\\", \\\"{x:1174,y:574,t:1511831385503};\\\", \\\"{x:1176,y:578,t:1511831385520};\\\", \\\"{x:1177,y:584,t:1511831385537};\\\", \\\"{x:1178,y:589,t:1511831385553};\\\", \\\"{x:1178,y:593,t:1511831385570};\\\", \\\"{x:1179,y:599,t:1511831385587};\\\", \\\"{x:1180,y:606,t:1511831385604};\\\", \\\"{x:1181,y:616,t:1511831385620};\\\", \\\"{x:1181,y:627,t:1511831385637};\\\", \\\"{x:1181,y:643,t:1511831385654};\\\", \\\"{x:1181,y:661,t:1511831385670};\\\", \\\"{x:1181,y:676,t:1511831385687};\\\", \\\"{x:1181,y:689,t:1511831385704};\\\", \\\"{x:1181,y:693,t:1511831385720};\\\", \\\"{x:1179,y:696,t:1511831385737};\\\", \\\"{x:1177,y:702,t:1511831385754};\\\", \\\"{x:1173,y:710,t:1511831385770};\\\", \\\"{x:1167,y:723,t:1511831385787};\\\", \\\"{x:1162,y:732,t:1511831385804};\\\", \\\"{x:1159,y:740,t:1511831385820};\\\", \\\"{x:1157,y:746,t:1511831385837};\\\", \\\"{x:1154,y:751,t:1511831385854};\\\", \\\"{x:1154,y:755,t:1511831385870};\\\", \\\"{x:1151,y:759,t:1511831385887};\\\", \\\"{x:1148,y:764,t:1511831385908};\\\", \\\"{x:1147,y:765,t:1511831385937};\\\", \\\"{x:1146,y:765,t:1511831385976};\\\", \\\"{x:1145,y:766,t:1511831385992};\\\", \\\"{x:1144,y:767,t:1511831386008};\\\", \\\"{x:1143,y:767,t:1511831386112};\\\", \\\"{x:1141,y:767,t:1511831391045};\\\", \\\"{x:1129,y:766,t:1511831391060};\\\", \\\"{x:1064,y:758,t:1511831391071};\\\", \\\"{x:960,y:750,t:1511831391088};\\\", \\\"{x:827,y:750,t:1511831391104};\\\", \\\"{x:670,y:748,t:1511831391121};\\\", \\\"{x:497,y:737,t:1511831391138};\\\", \\\"{x:376,y:724,t:1511831391154};\\\", \\\"{x:320,y:716,t:1511831391171};\\\", \\\"{x:286,y:710,t:1511831391188};\\\", \\\"{x:277,y:705,t:1511831391204};\\\", \\\"{x:266,y:698,t:1511831391222};\\\", \\\"{x:243,y:686,t:1511831391238};\\\", \\\"{x:205,y:669,t:1511831391255};\\\", \\\"{x:161,y:649,t:1511831391272};\\\", \\\"{x:125,y:634,t:1511831391288};\\\", \\\"{x:106,y:623,t:1511831391305};\\\", \\\"{x:101,y:619,t:1511831391322};\\\", \\\"{x:101,y:617,t:1511831391338};\\\", \\\"{x:101,y:616,t:1511831391356};\\\", \\\"{x:107,y:611,t:1511831391372};\\\", \\\"{x:146,y:600,t:1511831391388};\\\", \\\"{x:189,y:586,t:1511831391405};\\\", \\\"{x:220,y:576,t:1511831391422};\\\", \\\"{x:246,y:568,t:1511831391438};\\\", \\\"{x:256,y:565,t:1511831391454};\\\", \\\"{x:257,y:565,t:1511831391471};\\\", \\\"{x:259,y:565,t:1511831391487};\\\", \\\"{x:262,y:565,t:1511831391504};\\\", \\\"{x:265,y:568,t:1511831391521};\\\", \\\"{x:268,y:573,t:1511831391537};\\\", \\\"{x:269,y:575,t:1511831391554};\\\", \\\"{x:269,y:577,t:1511831391571};\\\", \\\"{x:269,y:579,t:1511831391597};\\\", \\\"{x:268,y:580,t:1511831391613};\\\", \\\"{x:266,y:581,t:1511831391621};\\\", \\\"{x:264,y:586,t:1511831391637};\\\", \\\"{x:261,y:593,t:1511831391655};\\\", \\\"{x:261,y:601,t:1511831391670};\\\", \\\"{x:261,y:605,t:1511831391687};\\\", \\\"{x:260,y:608,t:1511831391704};\\\", \\\"{x:260,y:609,t:1511831391720};\\\", \\\"{x:259,y:610,t:1511831391806};\\\", \\\"{x:258,y:611,t:1511831391829};\\\", \\\"{x:258,y:612,t:1511831391861};\\\", \\\"{x:259,y:612,t:1511831391901};\\\", \\\"{x:262,y:612,t:1511831391909};\\\", \\\"{x:266,y:612,t:1511831391920};\\\", \\\"{x:272,y:611,t:1511831391937};\\\", \\\"{x:281,y:611,t:1511831391954};\\\", \\\"{x:292,y:611,t:1511831391969};\\\", \\\"{x:312,y:611,t:1511831391987};\\\", \\\"{x:337,y:612,t:1511831392003};\\\", \\\"{x:380,y:615,t:1511831392022};\\\", \\\"{x:398,y:617,t:1511831392039};\\\", \\\"{x:406,y:617,t:1511831392056};\\\", \\\"{x:408,y:617,t:1511831392072};\\\", \\\"{x:409,y:616,t:1511831392089};\\\", \\\"{x:406,y:616,t:1511831392221};\\\", \\\"{x:399,y:613,t:1511831392228};\\\", \\\"{x:390,y:610,t:1511831392239};\\\", \\\"{x:361,y:600,t:1511831392256};\\\", \\\"{x:335,y:595,t:1511831392273};\\\", \\\"{x:320,y:594,t:1511831392289};\\\", \\\"{x:316,y:594,t:1511831392306};\\\", \\\"{x:315,y:594,t:1511831392323};\\\", \\\"{x:314,y:593,t:1511831392613};\\\", \\\"{x:314,y:592,t:1511831392624};\\\", \\\"{x:315,y:591,t:1511831392641};\\\", \\\"{x:323,y:591,t:1511831392657};\\\", \\\"{x:337,y:593,t:1511831392674};\\\", \\\"{x:352,y:594,t:1511831392690};\\\", \\\"{x:371,y:596,t:1511831392707};\\\", \\\"{x:386,y:596,t:1511831392723};\\\", \\\"{x:407,y:596,t:1511831392741};\\\", \\\"{x:412,y:596,t:1511831392757};\\\", \\\"{x:416,y:596,t:1511831392774};\\\", \\\"{x:418,y:596,t:1511831392792};\\\", \\\"{x:420,y:597,t:1511831392807};\\\", \\\"{x:422,y:599,t:1511831392828};\\\", \\\"{x:423,y:600,t:1511831392840};\\\", \\\"{x:426,y:604,t:1511831392857};\\\", \\\"{x:430,y:609,t:1511831392873};\\\", \\\"{x:433,y:613,t:1511831392890};\\\", \\\"{x:434,y:616,t:1511831392907};\\\", \\\"{x:435,y:616,t:1511831392923};\\\", \\\"{x:437,y:620,t:1511831392940};\\\", \\\"{x:437,y:621,t:1511831393013};\\\", \\\"{x:437,y:622,t:1511831393025};\\\", \\\"{x:432,y:625,t:1511831393040};\\\", \\\"{x:428,y:627,t:1511831393057};\\\", \\\"{x:420,y:630,t:1511831393074};\\\", \\\"{x:411,y:630,t:1511831393090};\\\", \\\"{x:403,y:630,t:1511831393107};\\\", \\\"{x:399,y:630,t:1511831393124};\\\", \\\"{x:396,y:630,t:1511831393140};\\\", \\\"{x:394,y:629,t:1511831393156};\\\", \\\"{x:392,y:628,t:1511831393180};\\\", \\\"{x:390,y:626,t:1511831393190};\\\", \\\"{x:379,y:622,t:1511831393206};\\\", \\\"{x:360,y:615,t:1511831393223};\\\", \\\"{x:343,y:612,t:1511831393240};\\\", \\\"{x:339,y:612,t:1511831393256};\\\", \\\"{x:338,y:612,t:1511831393273};\\\", \\\"{x:338,y:611,t:1511831393290};\\\", \\\"{x:336,y:611,t:1511831393413};\\\", \\\"{x:333,y:611,t:1511831393423};\\\", \\\"{x:329,y:611,t:1511831393440};\\\", \\\"{x:325,y:611,t:1511831393457};\\\", \\\"{x:321,y:611,t:1511831393473};\\\", \\\"{x:316,y:611,t:1511831393491};\\\", \\\"{x:311,y:611,t:1511831393507};\\\", \\\"{x:307,y:611,t:1511831393523};\\\", \\\"{x:301,y:611,t:1511831393540};\\\", \\\"{x:296,y:611,t:1511831393557};\\\", \\\"{x:294,y:611,t:1511831393573};\\\", \\\"{x:292,y:611,t:1511831393590};\\\", \\\"{x:285,y:611,t:1511831393607};\\\", \\\"{x:279,y:612,t:1511831393623};\\\", \\\"{x:272,y:613,t:1511831393640};\\\", \\\"{x:268,y:613,t:1511831393657};\\\", \\\"{x:266,y:613,t:1511831393673};\\\", \\\"{x:265,y:613,t:1511831393805};\\\", \\\"{x:263,y:613,t:1511831393828};\\\", \\\"{x:263,y:614,t:1511831393844};\\\", \\\"{x:263,y:615,t:1511831393857};\\\", \\\"{x:263,y:618,t:1511831393874};\\\", \\\"{x:266,y:625,t:1511831393890};\\\", \\\"{x:278,y:632,t:1511831393907};\\\", \\\"{x:310,y:635,t:1511831393924};\\\", \\\"{x:340,y:639,t:1511831393940};\\\", \\\"{x:368,y:641,t:1511831393957};\\\", \\\"{x:391,y:646,t:1511831393974};\\\", \\\"{x:403,y:647,t:1511831393990};\\\", \\\"{x:409,y:648,t:1511831394007};\\\", \\\"{x:412,y:649,t:1511831394025};\\\", \\\"{x:416,y:649,t:1511831394040};\\\", \\\"{x:417,y:649,t:1511831394093};\\\", \\\"{x:419,y:649,t:1511831394117};\\\", \\\"{x:421,y:649,t:1511831394125};\\\", \\\"{x:423,y:649,t:1511831394141};\\\", \\\"{x:429,y:649,t:1511831394157};\\\", \\\"{x:436,y:649,t:1511831394174};\\\", \\\"{x:444,y:649,t:1511831394191};\\\", \\\"{x:455,y:647,t:1511831394208};\\\", \\\"{x:466,y:644,t:1511831394225};\\\", \\\"{x:479,y:642,t:1511831394241};\\\", \\\"{x:488,y:642,t:1511831394257};\\\", \\\"{x:492,y:640,t:1511831394274};\\\", \\\"{x:496,y:640,t:1511831394291};\\\", \\\"{x:502,y:639,t:1511831394307};\\\", \\\"{x:515,y:639,t:1511831394324};\\\", \\\"{x:532,y:639,t:1511831394340};\\\", \\\"{x:549,y:639,t:1511831394357};\\\", \\\"{x:576,y:638,t:1511831394374};\\\", \\\"{x:609,y:638,t:1511831394391};\\\", \\\"{x:636,y:638,t:1511831394407};\\\", \\\"{x:650,y:638,t:1511831394426};\\\", \\\"{x:654,y:638,t:1511831394441};\\\", \\\"{x:653,y:638,t:1511831394501};\\\", \\\"{x:651,y:638,t:1511831394509};\\\", \\\"{x:646,y:638,t:1511831394525};\\\", \\\"{x:636,y:639,t:1511831394541};\\\", \\\"{x:616,y:639,t:1511831394557};\\\", \\\"{x:595,y:639,t:1511831394574};\\\", \\\"{x:582,y:640,t:1511831394591};\\\", \\\"{x:573,y:640,t:1511831394608};\\\", \\\"{x:572,y:640,t:1511831394625};\\\", \\\"{x:573,y:640,t:1511831394757};\\\", \\\"{x:578,y:640,t:1511831394774};\\\", \\\"{x:581,y:640,t:1511831394791};\\\", \\\"{x:582,y:640,t:1511831394808};\\\", \\\"{x:583,y:640,t:1511831394829};\\\", \\\"{x:584,y:640,t:1511831394841};\\\", \\\"{x:585,y:640,t:1511831394869};\\\", \\\"{x:586,y:640,t:1511831394877};\\\", \\\"{x:587,y:639,t:1511831395029};\\\", \\\"{x:587,y:638,t:1511831395044};\\\", \\\"{x:587,y:637,t:1511831395058};\\\", \\\"{x:587,y:636,t:1511831395420};\\\", \\\"{x:593,y:639,t:1511831395485};\\\", \\\"{x:610,y:648,t:1511831395493};\\\", \\\"{x:638,y:659,t:1511831395509};\\\", \\\"{x:684,y:678,t:1511831395525};\\\", \\\"{x:778,y:701,t:1511831395543};\\\", \\\"{x:853,y:725,t:1511831395559};\\\", \\\"{x:917,y:744,t:1511831395576};\\\", \\\"{x:972,y:766,t:1511831395593};\\\", \\\"{x:1008,y:781,t:1511831395609};\\\", \\\"{x:1028,y:786,t:1511831395626};\\\", \\\"{x:1039,y:787,t:1511831395643};\\\", \\\"{x:1050,y:787,t:1511831395659};\\\", \\\"{x:1053,y:787,t:1511831395676};\\\", \\\"{x:1054,y:787,t:1511831395693};\\\", \\\"{x:1055,y:787,t:1511831395709};\\\", \\\"{x:1056,y:787,t:1511831395733};\\\", \\\"{x:1057,y:786,t:1511831395757};\\\", \\\"{x:1064,y:786,t:1511831395765};\\\", \\\"{x:1073,y:786,t:1511831395776};\\\", \\\"{x:1093,y:785,t:1511831395793};\\\", \\\"{x:1110,y:781,t:1511831395809};\\\", \\\"{x:1127,y:777,t:1511831395826};\\\", \\\"{x:1137,y:772,t:1511831395843};\\\", \\\"{x:1138,y:771,t:1511831395859};\\\", \\\"{x:1139,y:771,t:1511831395876};\\\", \\\"{x:1140,y:771,t:1511831395933};\\\", \\\"{x:1142,y:769,t:1511831395943};\\\", \\\"{x:1145,y:767,t:1511831395968};\\\", \\\"{x:1150,y:761,t:1511831395993};\\\", \\\"{x:1150,y:760,t:1511831396009};\\\", \\\"{x:1150,y:759,t:1511831396025};\\\", \\\"{x:1150,y:758,t:1511831396092};\\\", \\\"{x:1149,y:757,t:1511831396109};\\\", \\\"{x:1144,y:757,t:1511831396125};\\\", \\\"{x:1139,y:755,t:1511831396142};\\\", \\\"{x:1136,y:755,t:1511831396159};\\\", \\\"{x:1135,y:755,t:1511831396261};\\\", \\\"{x:1135,y:757,t:1511831396381};\\\", \\\"{x:1135,y:758,t:1511831396392};\\\", \\\"{x:1136,y:763,t:1511831396410};\\\", \\\"{x:1138,y:765,t:1511831396432};\\\", \\\"{x:1139,y:765,t:1511831396644};\\\", \\\"{x:1141,y:765,t:1511831396660};\\\", \\\"{x:1141,y:763,t:1511831396701};\\\", \\\"{x:1141,y:762,t:1511831398973};\\\", \\\"{x:1137,y:760,t:1511831398984};\\\", \\\"{x:1130,y:759,t:1511831399000};\\\", \\\"{x:1120,y:759,t:1511831399016};\\\", \\\"{x:1111,y:759,t:1511831399029};\\\", \\\"{x:1105,y:759,t:1511831399045};\\\", \\\"{x:1104,y:759,t:1511831399062};\\\", \\\"{x:1103,y:759,t:1511831399079};\\\", \\\"{x:1098,y:761,t:1511831399334};\\\", \\\"{x:1095,y:762,t:1511831399346};\\\", \\\"{x:1089,y:764,t:1511831399363};\\\", \\\"{x:1084,y:767,t:1511831399380};\\\", \\\"{x:1080,y:768,t:1511831399396};\\\", \\\"{x:1079,y:768,t:1511831399421};\\\", \\\"{x:1078,y:769,t:1511831399478};\\\", \\\"{x:1072,y:771,t:1511831399496};\\\", \\\"{x:1067,y:772,t:1511831399512};\\\", \\\"{x:1064,y:774,t:1511831399529};\\\", \\\"{x:1064,y:773,t:1511831399766};\\\", \\\"{x:1066,y:771,t:1511831399780};\\\", \\\"{x:1069,y:768,t:1511831399797};\\\", \\\"{x:1069,y:767,t:1511831399813};\\\", \\\"{x:1070,y:767,t:1511831400110};\\\", \\\"{x:1071,y:767,t:1511831400126};\\\", \\\"{x:1073,y:767,t:1511831400213};\\\", \\\"{x:1080,y:756,t:1511831400231};\\\", \\\"{x:1083,y:751,t:1511831400246};\\\", \\\"{x:1084,y:750,t:1511831400263};\\\", \\\"{x:1082,y:752,t:1511831400581};\\\", \\\"{x:1078,y:758,t:1511831400599};\\\", \\\"{x:1064,y:776,t:1511831400614};\\\", \\\"{x:1056,y:787,t:1511831400630};\\\", \\\"{x:1054,y:790,t:1511831400647};\\\", \\\"{x:1054,y:792,t:1511831400663};\\\", \\\"{x:1056,y:796,t:1511831400701};\\\", \\\"{x:1066,y:799,t:1511831400713};\\\", \\\"{x:1094,y:812,t:1511831400730};\\\", \\\"{x:1120,y:824,t:1511831400747};\\\", \\\"{x:1146,y:835,t:1511831400763};\\\", \\\"{x:1170,y:851,t:1511831400780};\\\", \\\"{x:1219,y:879,t:1511831400797};\\\", \\\"{x:1237,y:889,t:1511831400813};\\\", \\\"{x:1241,y:892,t:1511831400830};\\\", \\\"{x:1242,y:892,t:1511831400847};\\\", \\\"{x:1243,y:893,t:1511831400863};\\\", \\\"{x:1241,y:893,t:1511831401022};\\\", \\\"{x:1240,y:893,t:1511831401031};\\\", \\\"{x:1234,y:892,t:1511831401048};\\\", \\\"{x:1223,y:889,t:1511831401064};\\\", \\\"{x:1210,y:886,t:1511831401081};\\\", \\\"{x:1199,y:886,t:1511831401098};\\\", \\\"{x:1198,y:886,t:1511831401115};\\\", \\\"{x:1197,y:886,t:1511831401182};\\\", \\\"{x:1195,y:886,t:1511831401246};\\\", \\\"{x:1191,y:887,t:1511831401262};\\\", \\\"{x:1190,y:888,t:1511831401270};\\\", \\\"{x:1187,y:890,t:1511831401281};\\\", \\\"{x:1185,y:892,t:1511831401298};\\\", \\\"{x:1183,y:893,t:1511831401315};\\\", \\\"{x:1182,y:894,t:1511831401422};\\\", \\\"{x:1181,y:895,t:1511831401468};\\\", \\\"{x:1180,y:895,t:1511831401497};\\\", \\\"{x:1182,y:895,t:1511831401894};\\\", \\\"{x:1186,y:895,t:1511831401906};\\\", \\\"{x:1204,y:895,t:1511831401933};\\\", \\\"{x:1215,y:895,t:1511831401948};\\\", \\\"{x:1219,y:895,t:1511831401966};\\\", \\\"{x:1221,y:895,t:1511831401981};\\\", \\\"{x:1222,y:895,t:1511831402005};\\\", \\\"{x:1221,y:895,t:1511831402294};\\\", \\\"{x:1216,y:897,t:1511831402302};\\\", \\\"{x:1213,y:897,t:1511831402317};\\\", \\\"{x:1209,y:897,t:1511831402333};\\\", \\\"{x:1207,y:897,t:1511831402348};\\\", \\\"{x:1206,y:897,t:1511831402364};\\\", \\\"{x:1205,y:897,t:1511831402381};\\\", \\\"{x:1206,y:897,t:1511831402782};\\\", \\\"{x:1226,y:892,t:1511831402804};\\\", \\\"{x:1365,y:871,t:1511831402831};\\\", \\\"{x:1470,y:855,t:1511831402848};\\\", \\\"{x:1564,y:843,t:1511831402865};\\\", \\\"{x:1615,y:835,t:1511831402882};\\\", \\\"{x:1643,y:834,t:1511831402898};\\\", \\\"{x:1653,y:831,t:1511831402915};\\\", \\\"{x:1654,y:831,t:1511831402932};\\\", \\\"{x:1654,y:829,t:1511831402981};\\\", \\\"{x:1654,y:827,t:1511831402989};\\\", \\\"{x:1652,y:824,t:1511831402998};\\\", \\\"{x:1637,y:815,t:1511831403015};\\\", \\\"{x:1613,y:807,t:1511831403032};\\\", \\\"{x:1577,y:806,t:1511831403048};\\\", \\\"{x:1548,y:806,t:1511831403065};\\\", \\\"{x:1525,y:808,t:1511831403082};\\\", \\\"{x:1512,y:812,t:1511831403098};\\\", \\\"{x:1506,y:814,t:1511831403115};\\\", \\\"{x:1494,y:818,t:1511831403132};\\\", \\\"{x:1481,y:823,t:1511831403149};\\\", \\\"{x:1477,y:826,t:1511831403165};\\\", \\\"{x:1475,y:828,t:1511831403182};\\\", \\\"{x:1475,y:829,t:1511831403199};\\\", \\\"{x:1473,y:830,t:1511831403317};\\\", \\\"{x:1470,y:830,t:1511831403332};\\\", \\\"{x:1462,y:830,t:1511831403348};\\\", \\\"{x:1455,y:830,t:1511831403365};\\\", \\\"{x:1447,y:830,t:1511831403384};\\\", \\\"{x:1441,y:831,t:1511831403399};\\\", \\\"{x:1438,y:833,t:1511831403415};\\\", \\\"{x:1437,y:833,t:1511831403667};\\\", \\\"{x:1437,y:830,t:1511831403684};\\\", \\\"{x:1437,y:824,t:1511831403700};\\\", \\\"{x:1435,y:821,t:1511831403716};\\\", \\\"{x:1434,y:818,t:1511831403732};\\\", \\\"{x:1431,y:814,t:1511831403749};\\\", \\\"{x:1430,y:813,t:1511831403766};\\\", \\\"{x:1428,y:808,t:1511831403782};\\\", \\\"{x:1425,y:804,t:1511831403799};\\\", \\\"{x:1420,y:799,t:1511831403816};\\\", \\\"{x:1414,y:793,t:1511831403832};\\\", \\\"{x:1411,y:790,t:1511831403849};\\\", \\\"{x:1410,y:789,t:1511831403866};\\\", \\\"{x:1409,y:786,t:1511831403941};\\\", \\\"{x:1408,y:781,t:1511831403949};\\\", \\\"{x:1407,y:777,t:1511831403966};\\\", \\\"{x:1405,y:772,t:1511831403982};\\\", \\\"{x:1405,y:770,t:1511831403999};\\\", \\\"{x:1405,y:769,t:1511831404126};\\\", \\\"{x:1404,y:768,t:1511831404134};\\\", \\\"{x:1404,y:767,t:1511831404150};\\\", \\\"{x:1404,y:766,t:1511831404430};\\\", \\\"{x:1404,y:764,t:1511831404446};\\\", \\\"{x:1404,y:762,t:1511831404466};\\\", \\\"{x:1404,y:761,t:1511831404525};\\\", \\\"{x:1404,y:760,t:1511831404534};\\\", \\\"{x:1406,y:760,t:1511831404552};\\\", \\\"{x:1407,y:759,t:1511831404596};\\\", \\\"{x:1407,y:758,t:1511831404677};\\\", \\\"{x:1407,y:757,t:1511831404687};\\\", \\\"{x:1403,y:751,t:1511831404700};\\\", \\\"{x:1380,y:726,t:1511831404716};\\\", \\\"{x:1311,y:663,t:1511831404733};\\\", \\\"{x:1285,y:638,t:1511831404750};\\\", \\\"{x:1277,y:625,t:1511831404769};\\\", \\\"{x:1273,y:616,t:1511831404784};\\\", \\\"{x:1273,y:614,t:1511831404804};\\\", \\\"{x:1273,y:616,t:1511831405013};\\\", \\\"{x:1273,y:620,t:1511831405021};\\\", \\\"{x:1273,y:623,t:1511831405033};\\\", \\\"{x:1273,y:627,t:1511831405053};\\\", \\\"{x:1273,y:628,t:1511831405067};\\\", \\\"{x:1272,y:626,t:1511831405774};\\\", \\\"{x:1271,y:624,t:1511831405789};\\\", \\\"{x:1268,y:617,t:1511831405801};\\\", \\\"{x:1264,y:611,t:1511831405817};\\\", \\\"{x:1260,y:607,t:1511831405834};\\\", \\\"{x:1254,y:603,t:1511831405851};\\\", \\\"{x:1244,y:599,t:1511831405867};\\\", \\\"{x:1232,y:593,t:1511831405884};\\\", \\\"{x:1211,y:584,t:1511831405900};\\\", \\\"{x:1198,y:579,t:1511831405917};\\\", \\\"{x:1186,y:578,t:1511831405934};\\\", \\\"{x:1181,y:577,t:1511831405951};\\\", \\\"{x:1180,y:577,t:1511831406013};\\\", \\\"{x:1178,y:577,t:1511831406020};\\\", \\\"{x:1177,y:577,t:1511831406034};\\\", \\\"{x:1177,y:576,t:1511831406077};\\\", \\\"{x:1177,y:574,t:1511831406084};\\\", \\\"{x:1177,y:572,t:1511831406100};\\\", \\\"{x:1177,y:571,t:1511831406133};\\\", \\\"{x:1177,y:569,t:1511831406230};\\\", \\\"{x:1176,y:568,t:1511831406245};\\\", \\\"{x:1176,y:565,t:1511831406268};\\\", \\\"{x:1175,y:564,t:1511831406284};\\\", \\\"{x:1175,y:561,t:1511831406373};\\\", \\\"{x:1175,y:559,t:1511831406384};\\\", \\\"{x:1173,y:556,t:1511831406403};\\\", \\\"{x:1172,y:554,t:1511831406418};\\\", \\\"{x:1172,y:553,t:1511831406434};\\\", \\\"{x:1172,y:552,t:1511831406838};\\\", \\\"{x:1172,y:553,t:1511831406893};\\\", \\\"{x:1170,y:555,t:1511831406958};\\\", \\\"{x:1170,y:556,t:1511831406969};\\\", \\\"{x:1170,y:558,t:1511831406986};\\\", \\\"{x:1169,y:561,t:1511831407002};\\\", \\\"{x:1169,y:562,t:1511831407110};\\\", \\\"{x:1168,y:563,t:1511831407118};\\\", \\\"{x:1168,y:564,t:1511831407135};\\\", \\\"{x:1168,y:565,t:1511831407757};\\\", \\\"{x:1169,y:565,t:1511831407770};\\\", \\\"{x:1170,y:566,t:1511831407785};\\\", \\\"{x:1171,y:566,t:1511831407820};\\\", \\\"{x:1172,y:566,t:1511831407835};\\\", \\\"{x:1173,y:564,t:1511831408453};\\\", \\\"{x:1173,y:551,t:1511831408474};\\\", \\\"{x:1170,y:541,t:1511831408486};\\\", \\\"{x:1167,y:524,t:1511831408503};\\\", \\\"{x:1164,y:504,t:1511831408519};\\\", \\\"{x:1163,y:496,t:1511831408536};\\\", \\\"{x:1162,y:489,t:1511831408553};\\\", \\\"{x:1161,y:484,t:1511831408569};\\\", \\\"{x:1161,y:482,t:1511831408586};\\\", \\\"{x:1159,y:476,t:1511831408603};\\\", \\\"{x:1159,y:471,t:1511831408619};\\\", \\\"{x:1159,y:458,t:1511831408636};\\\", \\\"{x:1159,y:453,t:1511831408653};\\\", \\\"{x:1161,y:449,t:1511831408669};\\\", \\\"{x:1162,y:446,t:1511831408686};\\\", \\\"{x:1163,y:444,t:1511831408703};\\\", \\\"{x:1163,y:443,t:1511831408719};\\\", \\\"{x:1163,y:442,t:1511831408736};\\\", \\\"{x:1164,y:441,t:1511831408862};\\\", \\\"{x:1164,y:440,t:1511831408877};\\\", \\\"{x:1164,y:439,t:1511831408887};\\\", \\\"{x:1165,y:438,t:1511831408904};\\\", \\\"{x:1165,y:437,t:1511831408941};\\\", \\\"{x:1167,y:435,t:1511831408954};\\\", \\\"{x:1167,y:434,t:1511831408971};\\\", \\\"{x:1169,y:432,t:1511831408987};\\\", \\\"{x:1170,y:430,t:1511831409004};\\\", \\\"{x:1171,y:430,t:1511831409025};\\\", \\\"{x:1171,y:429,t:1511831409389};\\\", \\\"{x:1178,y:428,t:1511831409403};\\\", \\\"{x:1248,y:432,t:1511831409422};\\\", \\\"{x:1313,y:435,t:1511831409437};\\\", \\\"{x:1377,y:435,t:1511831409456};\\\", \\\"{x:1401,y:435,t:1511831409472};\\\", \\\"{x:1408,y:435,t:1511831409487};\\\", \\\"{x:1409,y:436,t:1511831409508};\\\", \\\"{x:1410,y:436,t:1511831409581};\\\", \\\"{x:1406,y:436,t:1511831409741};\\\", \\\"{x:1400,y:436,t:1511831409755};\\\", \\\"{x:1390,y:436,t:1511831409771};\\\", \\\"{x:1383,y:435,t:1511831409788};\\\", \\\"{x:1381,y:435,t:1511831409805};\\\", \\\"{x:1380,y:434,t:1511831409830};\\\", \\\"{x:1379,y:434,t:1511831409892};\\\", \\\"{x:1378,y:434,t:1511831409916};\\\", \\\"{x:1376,y:435,t:1511831410037};\\\", \\\"{x:1377,y:439,t:1511831410149};\\\", \\\"{x:1379,y:448,t:1511831410156};\\\", \\\"{x:1383,y:454,t:1511831410171};\\\", \\\"{x:1388,y:463,t:1511831410187};\\\", \\\"{x:1392,y:468,t:1511831410204};\\\", \\\"{x:1396,y:474,t:1511831410221};\\\", \\\"{x:1404,y:481,t:1511831410237};\\\", \\\"{x:1426,y:500,t:1511831410254};\\\", \\\"{x:1448,y:528,t:1511831410271};\\\", \\\"{x:1469,y:556,t:1511831410287};\\\", \\\"{x:1484,y:573,t:1511831410304};\\\", \\\"{x:1489,y:578,t:1511831410321};\\\", \\\"{x:1490,y:578,t:1511831410337};\\\", \\\"{x:1491,y:579,t:1511831410364};\\\", \\\"{x:1490,y:580,t:1511831410388};\\\", \\\"{x:1488,y:581,t:1511831410404};\\\", \\\"{x:1485,y:581,t:1511831410421};\\\", \\\"{x:1477,y:581,t:1511831410437};\\\", \\\"{x:1468,y:581,t:1511831410454};\\\", \\\"{x:1455,y:581,t:1511831410472};\\\", \\\"{x:1445,y:579,t:1511831410488};\\\", \\\"{x:1436,y:576,t:1511831410504};\\\", \\\"{x:1430,y:574,t:1511831410521};\\\", \\\"{x:1423,y:570,t:1511831410538};\\\", \\\"{x:1419,y:570,t:1511831410554};\\\", \\\"{x:1416,y:569,t:1511831410571};\\\", \\\"{x:1415,y:569,t:1511831410588};\\\", \\\"{x:1416,y:569,t:1511831410677};\\\", \\\"{x:1418,y:569,t:1511831410689};\\\", \\\"{x:1422,y:569,t:1511831410705};\\\", \\\"{x:1425,y:569,t:1511831410722};\\\", \\\"{x:1427,y:569,t:1511831410739};\\\", \\\"{x:1428,y:569,t:1511831410755};\\\", \\\"{x:1429,y:568,t:1511831410813};\\\", \\\"{x:1430,y:568,t:1511831410829};\\\", \\\"{x:1430,y:567,t:1511831410853};\\\", \\\"{x:1431,y:567,t:1511831410901};\\\", \\\"{x:1431,y:566,t:1511831410909};\\\", \\\"{x:1433,y:566,t:1511831410927};\\\", \\\"{x:1434,y:566,t:1511831410940};\\\", \\\"{x:1437,y:565,t:1511831410954};\\\", \\\"{x:1438,y:564,t:1511831410973};\\\", \\\"{x:1439,y:563,t:1511831411325};\\\", \\\"{x:1438,y:557,t:1511831411343};\\\", \\\"{x:1418,y:534,t:1511831411356};\\\", \\\"{x:1389,y:502,t:1511831411371};\\\", \\\"{x:1347,y:452,t:1511831411388};\\\", \\\"{x:1317,y:416,t:1511831411405};\\\", \\\"{x:1300,y:385,t:1511831411422};\\\", \\\"{x:1290,y:357,t:1511831411438};\\\", \\\"{x:1275,y:332,t:1511831411455};\\\", \\\"{x:1258,y:317,t:1511831411472};\\\", \\\"{x:1240,y:305,t:1511831411488};\\\", \\\"{x:1231,y:298,t:1511831411505};\\\", \\\"{x:1224,y:294,t:1511831411522};\\\", \\\"{x:1214,y:288,t:1511831411538};\\\", \\\"{x:1209,y:281,t:1511831411555};\\\", \\\"{x:1205,y:270,t:1511831411572};\\\", \\\"{x:1204,y:261,t:1511831411588};\\\", \\\"{x:1201,y:252,t:1511831411605};\\\", \\\"{x:1200,y:246,t:1511831411623};\\\", \\\"{x:1201,y:238,t:1511831411638};\\\", \\\"{x:1213,y:226,t:1511831411656};\\\", \\\"{x:1229,y:209,t:1511831411673};\\\", \\\"{x:1245,y:189,t:1511831411689};\\\", \\\"{x:1253,y:167,t:1511831411706};\\\", \\\"{x:1256,y:143,t:1511831411722};\\\", \\\"{x:1253,y:118,t:1511831411738};\\\", \\\"{x:1241,y:95,t:1511831411755};\\\", \\\"{x:1231,y:81,t:1511831411772};\\\", \\\"{x:1230,y:81,t:1511831411813};\\\", \\\"{x:1227,y:83,t:1511831411822};\\\", \\\"{x:1220,y:90,t:1511831411839};\\\", \\\"{x:1220,y:97,t:1511831411855};\\\", \\\"{x:1219,y:105,t:1511831411872};\\\", \\\"{x:1220,y:113,t:1511831411889};\\\", \\\"{x:1224,y:122,t:1511831411905};\\\", \\\"{x:1228,y:128,t:1511831411922};\\\", \\\"{x:1232,y:134,t:1511831411939};\\\", \\\"{x:1234,y:138,t:1511831411956};\\\", \\\"{x:1235,y:140,t:1511831412005};\\\", \\\"{x:1235,y:141,t:1511831412125};\\\", \\\"{x:1235,y:143,t:1511831412140};\\\", \\\"{x:1237,y:146,t:1511831412156};\\\", \\\"{x:1237,y:147,t:1511831412173};\\\", \\\"{x:1237,y:149,t:1511831412300};\\\", \\\"{x:1237,y:151,t:1511831412308};\\\", \\\"{x:1238,y:153,t:1511831412322};\\\", \\\"{x:1238,y:155,t:1511831412339};\\\", \\\"{x:1239,y:157,t:1511831412356};\\\", \\\"{x:1239,y:158,t:1511831412380};\\\", \\\"{x:1239,y:159,t:1511831412399};\\\", \\\"{x:1239,y:161,t:1511831412422};\\\", \\\"{x:1240,y:163,t:1511831413420};\\\", \\\"{x:1240,y:175,t:1511831413430};\\\", \\\"{x:1240,y:193,t:1511831413440};\\\", \\\"{x:1237,y:237,t:1511831413456};\\\", \\\"{x:1233,y:273,t:1511831413473};\\\", \\\"{x:1230,y:306,t:1511831413490};\\\", \\\"{x:1230,y:335,t:1511831413507};\\\", \\\"{x:1230,y:357,t:1511831413523};\\\", \\\"{x:1230,y:383,t:1511831413540};\\\", \\\"{x:1230,y:399,t:1511831413557};\\\", \\\"{x:1230,y:421,t:1511831413573};\\\", \\\"{x:1230,y:435,t:1511831413591};\\\", \\\"{x:1230,y:442,t:1511831413608};\\\", \\\"{x:1230,y:446,t:1511831413623};\\\", \\\"{x:1230,y:448,t:1511831413641};\\\", \\\"{x:1229,y:449,t:1511831413797};\\\", \\\"{x:1228,y:449,t:1511831413808};\\\", \\\"{x:1225,y:449,t:1511831413824};\\\", \\\"{x:1222,y:449,t:1511831413841};\\\", \\\"{x:1218,y:449,t:1511831413858};\\\", \\\"{x:1217,y:449,t:1511831413874};\\\", \\\"{x:1215,y:448,t:1511831413891};\\\", \\\"{x:1211,y:445,t:1511831413908};\\\", \\\"{x:1207,y:440,t:1511831413925};\\\", \\\"{x:1203,y:437,t:1511831413941};\\\", \\\"{x:1195,y:431,t:1511831413957};\\\", \\\"{x:1190,y:428,t:1511831413975};\\\", \\\"{x:1184,y:425,t:1511831413991};\\\", \\\"{x:1182,y:424,t:1511831414008};\\\", \\\"{x:1180,y:424,t:1511831414026};\\\", \\\"{x:1178,y:424,t:1511831414053};\\\", \\\"{x:1173,y:424,t:1511831414075};\\\", \\\"{x:1170,y:424,t:1511831414090};\\\", \\\"{x:1169,y:425,t:1511831414107};\\\", \\\"{x:1167,y:426,t:1511831414212};\\\", \\\"{x:1166,y:427,t:1511831414225};\\\", \\\"{x:1166,y:429,t:1511831414240};\\\", \\\"{x:1166,y:430,t:1511831414257};\\\", \\\"{x:1166,y:431,t:1511831414274};\\\", \\\"{x:1166,y:432,t:1511831414453};\\\", \\\"{x:1167,y:432,t:1511831414477};\\\", \\\"{x:1168,y:432,t:1511831414493};\\\", \\\"{x:1170,y:431,t:1511831414507};\\\", \\\"{x:1171,y:431,t:1511831414526};\\\", \\\"{x:1172,y:431,t:1511831414541};\\\", \\\"{x:1173,y:430,t:1511831414620};\\\", \\\"{x:1173,y:429,t:1511831414628};\\\", \\\"{x:1174,y:429,t:1511831414644};\\\", \\\"{x:1175,y:429,t:1511831414660};\\\", \\\"{x:1175,y:428,t:1511831414674};\\\", \\\"{x:1176,y:428,t:1511831414692};\\\", \\\"{x:1177,y:430,t:1511831415028};\\\", \\\"{x:1177,y:432,t:1511831415041};\\\", \\\"{x:1178,y:437,t:1511831415060};\\\", \\\"{x:1178,y:439,t:1511831415074};\\\", \\\"{x:1178,y:440,t:1511831415091};\\\", \\\"{x:1178,y:442,t:1511831415269};\\\", \\\"{x:1178,y:445,t:1511831415277};\\\", \\\"{x:1178,y:451,t:1511831415291};\\\", \\\"{x:1177,y:480,t:1511831415308};\\\", \\\"{x:1174,y:504,t:1511831415325};\\\", \\\"{x:1174,y:525,t:1511831415341};\\\", \\\"{x:1174,y:541,t:1511831415358};\\\", \\\"{x:1174,y:551,t:1511831415375};\\\", \\\"{x:1174,y:557,t:1511831415391};\\\", \\\"{x:1174,y:563,t:1511831415413};\\\", \\\"{x:1174,y:565,t:1511831415425};\\\", \\\"{x:1174,y:567,t:1511831415540};\\\", \\\"{x:1177,y:571,t:1511831415558};\\\", \\\"{x:1178,y:572,t:1511831415575};\\\", \\\"{x:1178,y:573,t:1511831415592};\\\", \\\"{x:1178,y:574,t:1511831415741};\\\", \\\"{x:1177,y:579,t:1511831415748};\\\", \\\"{x:1175,y:582,t:1511831415758};\\\", \\\"{x:1174,y:589,t:1511831415775};\\\", \\\"{x:1172,y:601,t:1511831415792};\\\", \\\"{x:1172,y:616,t:1511831415808};\\\", \\\"{x:1173,y:630,t:1511831415825};\\\", \\\"{x:1182,y:645,t:1511831415842};\\\", \\\"{x:1187,y:663,t:1511831415858};\\\", \\\"{x:1188,y:683,t:1511831415875};\\\", \\\"{x:1188,y:703,t:1511831415892};\\\", \\\"{x:1188,y:708,t:1511831415909};\\\", \\\"{x:1188,y:713,t:1511831415925};\\\", \\\"{x:1186,y:718,t:1511831415942};\\\", \\\"{x:1180,y:728,t:1511831415959};\\\", \\\"{x:1177,y:732,t:1511831415976};\\\", \\\"{x:1171,y:738,t:1511831415993};\\\", \\\"{x:1169,y:743,t:1511831416009};\\\", \\\"{x:1167,y:746,t:1511831416025};\\\", \\\"{x:1166,y:747,t:1511831416043};\\\", \\\"{x:1164,y:749,t:1511831416060};\\\", \\\"{x:1161,y:752,t:1511831416076};\\\", \\\"{x:1157,y:755,t:1511831416093};\\\", \\\"{x:1155,y:756,t:1511831416109};\\\", \\\"{x:1153,y:758,t:1511831416126};\\\", \\\"{x:1150,y:760,t:1511831416143};\\\", \\\"{x:1150,y:761,t:1511831416160};\\\", \\\"{x:1149,y:763,t:1511831416175};\\\", \\\"{x:1149,y:764,t:1511831416518};\\\", \\\"{x:1148,y:764,t:1511831416538};\\\", \\\"{x:1147,y:765,t:1511831416669};\\\", \\\"{x:1146,y:765,t:1511831416685};\\\", \\\"{x:1144,y:766,t:1511831416693};\\\", \\\"{x:1144,y:767,t:1511831416710};\\\", \\\"{x:1143,y:768,t:1511831417086};\\\", \\\"{x:1129,y:791,t:1511831417110};\\\", \\\"{x:1119,y:817,t:1511831417127};\\\", \\\"{x:1106,y:846,t:1511831417144};\\\", \\\"{x:1098,y:868,t:1511831417160};\\\", \\\"{x:1093,y:889,t:1511831417177};\\\", \\\"{x:1086,y:908,t:1511831417194};\\\", \\\"{x:1079,y:923,t:1511831417210};\\\", \\\"{x:1074,y:932,t:1511831417227};\\\", \\\"{x:1072,y:935,t:1511831417244};\\\", \\\"{x:1070,y:938,t:1511831417260};\\\", \\\"{x:1069,y:939,t:1511831417277};\\\", \\\"{x:1068,y:939,t:1511831417294};\\\", \\\"{x:1067,y:936,t:1511831417358};\\\", \\\"{x:1068,y:930,t:1511831417365};\\\", \\\"{x:1069,y:926,t:1511831417377};\\\", \\\"{x:1077,y:915,t:1511831417394};\\\", \\\"{x:1083,y:903,t:1511831417412};\\\", \\\"{x:1094,y:890,t:1511831417427};\\\", \\\"{x:1102,y:879,t:1511831417445};\\\", \\\"{x:1112,y:866,t:1511831417461};\\\", \\\"{x:1119,y:856,t:1511831417477};\\\", \\\"{x:1127,y:844,t:1511831417495};\\\", \\\"{x:1147,y:822,t:1511831417512};\\\", \\\"{x:1203,y:758,t:1511831417527};\\\", \\\"{x:1285,y:662,t:1511831417544};\\\", \\\"{x:1331,y:597,t:1511831417561};\\\", \\\"{x:1367,y:535,t:1511831417577};\\\", \\\"{x:1395,y:471,t:1511831417594};\\\", \\\"{x:1405,y:430,t:1511831417611};\\\", \\\"{x:1405,y:407,t:1511831417627};\\\", \\\"{x:1403,y:392,t:1511831417644};\\\", \\\"{x:1360,y:382,t:1511831417661};\\\", \\\"{x:1270,y:383,t:1511831417677};\\\", \\\"{x:1146,y:417,t:1511831417694};\\\", \\\"{x:1022,y:472,t:1511831417711};\\\", \\\"{x:900,y:532,t:1511831417727};\\\", \\\"{x:781,y:588,t:1511831417745};\\\", \\\"{x:685,y:640,t:1511831417762};\\\", \\\"{x:601,y:688,t:1511831417778};\\\", \\\"{x:547,y:718,t:1511831417794};\\\", \\\"{x:499,y:740,t:1511831417811};\\\", \\\"{x:447,y:762,t:1511831417829};\\\", \\\"{x:395,y:774,t:1511831417844};\\\", \\\"{x:302,y:795,t:1511831417861};\\\", \\\"{x:230,y:805,t:1511831417878};\\\", \\\"{x:188,y:805,t:1511831417894};\\\", \\\"{x:175,y:805,t:1511831417911};\\\", \\\"{x:174,y:805,t:1511831417928};\\\", \\\"{x:172,y:803,t:1511831417944};\\\", \\\"{x:175,y:791,t:1511831417961};\\\", \\\"{x:181,y:780,t:1511831417978};\\\", \\\"{x:184,y:772,t:1511831417994};\\\", \\\"{x:190,y:763,t:1511831418011};\\\", \\\"{x:198,y:754,t:1511831418029};\\\", \\\"{x:206,y:750,t:1511831418045};\\\", \\\"{x:220,y:742,t:1511831418061};\\\", \\\"{x:224,y:740,t:1511831418078};\\\", \\\"{x:229,y:737,t:1511831418095};\\\", \\\"{x:239,y:732,t:1511831418111};\\\", \\\"{x:269,y:727,t:1511831418128};\\\", \\\"{x:312,y:713,t:1511831418144};\\\", \\\"{x:348,y:708,t:1511831418162};\\\", \\\"{x:373,y:706,t:1511831418178};\\\", \\\"{x:387,y:705,t:1511831418194};\\\", \\\"{x:390,y:705,t:1511831418211};\\\", \\\"{x:391,y:705,t:1511831418237};\\\", \\\"{x:393,y:705,t:1511831418245};\\\", \\\"{x:403,y:705,t:1511831418261};\\\", \\\"{x:423,y:705,t:1511831418278};\\\", \\\"{x:442,y:705,t:1511831418295};\\\", \\\"{x:454,y:705,t:1511831418311};\\\", \\\"{x:455,y:704,t:1511831418328};\\\", \\\"{x:454,y:705,t:1511831418526};\\\", \\\"{x:452,y:705,t:1511831418533};\\\", \\\"{x:450,y:705,t:1511831418545};\\\", \\\"{x:448,y:706,t:1511831418562};\\\", \\\"{x:447,y:706,t:1511831418578};\\\", \\\"{x:445,y:706,t:1511831418595};\\\", \\\"{x:442,y:707,t:1511831418612};\\\", \\\"{x:441,y:707,t:1511831418628};\\\", \\\"{x:429,y:708,t:1511831418644};\\\", \\\"{x:413,y:709,t:1511831418662};\\\", \\\"{x:403,y:709,t:1511831418678};\\\", \\\"{x:401,y:709,t:1511831418695};\\\", \\\"{x:400,y:709,t:1511831419286};\\\", \\\"{x:400,y:708,t:1511831419295};\\\", \\\"{x:400,y:707,t:1511831419312};\\\", \\\"{x:400,y:706,t:1511831419341};\\\" ] }, { \\\"rt\\\": 90882, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 305319, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -J -J -J -D -D -K -K -K -D -K -D -K -K -12 PM-D -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:400,y:704,t:1511831422030};\\\", \\\"{x:408,y:700,t:1511831422037};\\\", \\\"{x:429,y:699,t:1511831422048};\\\", \\\"{x:468,y:699,t:1511831422065};\\\", \\\"{x:516,y:692,t:1511831422081};\\\", \\\"{x:564,y:684,t:1511831422098};\\\", \\\"{x:617,y:676,t:1511831422115};\\\", \\\"{x:659,y:671,t:1511831422131};\\\", \\\"{x:698,y:667,t:1511831422148};\\\", \\\"{x:717,y:662,t:1511831422164};\\\", \\\"{x:719,y:660,t:1511831422253};\\\", \\\"{x:720,y:659,t:1511831422265};\\\", \\\"{x:724,y:653,t:1511831422281};\\\", \\\"{x:728,y:648,t:1511831422298};\\\", \\\"{x:732,y:643,t:1511831422315};\\\", \\\"{x:740,y:635,t:1511831422332};\\\", \\\"{x:745,y:630,t:1511831422349};\\\", \\\"{x:770,y:620,t:1511831422365};\\\", \\\"{x:797,y:615,t:1511831422382};\\\", \\\"{x:821,y:613,t:1511831422398};\\\", \\\"{x:847,y:609,t:1511831422415};\\\", \\\"{x:872,y:609,t:1511831422432};\\\", \\\"{x:895,y:609,t:1511831422449};\\\", \\\"{x:915,y:609,t:1511831422466};\\\", \\\"{x:930,y:609,t:1511831422483};\\\", \\\"{x:937,y:610,t:1511831422499};\\\", \\\"{x:938,y:611,t:1511831422515};\\\", \\\"{x:939,y:611,t:1511831422533};\\\", \\\"{x:942,y:613,t:1511831422549};\\\", \\\"{x:946,y:614,t:1511831422566};\\\", \\\"{x:947,y:614,t:1511831422583};\\\", \\\"{x:948,y:614,t:1511831422600};\\\", \\\"{x:949,y:615,t:1511831422678};\\\", \\\"{x:952,y:616,t:1511831422685};\\\", \\\"{x:956,y:617,t:1511831422700};\\\", \\\"{x:960,y:617,t:1511831422716};\\\", \\\"{x:961,y:617,t:1511831423430};\\\", \\\"{x:960,y:618,t:1511831423437};\\\", \\\"{x:950,y:620,t:1511831423450};\\\", \\\"{x:924,y:628,t:1511831423467};\\\", \\\"{x:885,y:639,t:1511831423483};\\\", \\\"{x:819,y:656,t:1511831423500};\\\", \\\"{x:683,y:681,t:1511831423516};\\\", \\\"{x:602,y:704,t:1511831423533};\\\", \\\"{x:555,y:716,t:1511831423550};\\\", \\\"{x:536,y:722,t:1511831423567};\\\", \\\"{x:527,y:725,t:1511831423583};\\\", \\\"{x:526,y:725,t:1511831424637};\\\", \\\"{x:529,y:725,t:1511831425101};\\\", \\\"{x:540,y:726,t:1511831425109};\\\", \\\"{x:556,y:730,t:1511831425119};\\\", \\\"{x:585,y:733,t:1511831425136};\\\", \\\"{x:616,y:739,t:1511831425153};\\\", \\\"{x:643,y:743,t:1511831425169};\\\", \\\"{x:666,y:747,t:1511831425186};\\\", \\\"{x:682,y:750,t:1511831425203};\\\", \\\"{x:701,y:756,t:1511831425219};\\\", \\\"{x:714,y:760,t:1511831425236};\\\", \\\"{x:724,y:765,t:1511831425253};\\\", \\\"{x:731,y:767,t:1511831425270};\\\", \\\"{x:743,y:769,t:1511831425286};\\\", \\\"{x:766,y:772,t:1511831425303};\\\", \\\"{x:790,y:774,t:1511831425320};\\\", \\\"{x:812,y:775,t:1511831425336};\\\", \\\"{x:827,y:778,t:1511831425353};\\\", \\\"{x:841,y:778,t:1511831425370};\\\", \\\"{x:859,y:779,t:1511831425386};\\\", \\\"{x:874,y:781,t:1511831425403};\\\", \\\"{x:882,y:784,t:1511831425420};\\\", \\\"{x:887,y:786,t:1511831425437};\\\", \\\"{x:889,y:787,t:1511831425454};\\\", \\\"{x:892,y:788,t:1511831425471};\\\", \\\"{x:894,y:788,t:1511831425488};\\\", \\\"{x:895,y:788,t:1511831425517};\\\", \\\"{x:896,y:788,t:1511831425533};\\\", \\\"{x:898,y:788,t:1511831425549};\\\", \\\"{x:899,y:789,t:1511831425565};\\\", \\\"{x:900,y:790,t:1511831425573};\\\", \\\"{x:901,y:790,t:1511831425588};\\\", \\\"{x:903,y:792,t:1511831425604};\\\", \\\"{x:903,y:793,t:1511831425621};\\\", \\\"{x:905,y:797,t:1511831425637};\\\", \\\"{x:905,y:799,t:1511831425653};\\\", \\\"{x:907,y:801,t:1511831425670};\\\", \\\"{x:914,y:810,t:1511831425687};\\\", \\\"{x:926,y:818,t:1511831425704};\\\", \\\"{x:941,y:825,t:1511831425720};\\\", \\\"{x:965,y:836,t:1511831425737};\\\", \\\"{x:1007,y:846,t:1511831425754};\\\", \\\"{x:1094,y:851,t:1511831425770};\\\", \\\"{x:1208,y:851,t:1511831425787};\\\", \\\"{x:1292,y:848,t:1511831425804};\\\", \\\"{x:1346,y:837,t:1511831425820};\\\", \\\"{x:1423,y:799,t:1511831425837};\\\", \\\"{x:1457,y:771,t:1511831425854};\\\", \\\"{x:1470,y:750,t:1511831425870};\\\", \\\"{x:1479,y:724,t:1511831425887};\\\", \\\"{x:1481,y:682,t:1511831425904};\\\", \\\"{x:1481,y:629,t:1511831425921};\\\", \\\"{x:1481,y:563,t:1511831425937};\\\", \\\"{x:1489,y:499,t:1511831425955};\\\", \\\"{x:1498,y:464,t:1511831425971};\\\", \\\"{x:1499,y:444,t:1511831425988};\\\", \\\"{x:1499,y:430,t:1511831426005};\\\", \\\"{x:1495,y:415,t:1511831426021};\\\", \\\"{x:1489,y:408,t:1511831426038};\\\", \\\"{x:1481,y:404,t:1511831426055};\\\", \\\"{x:1470,y:399,t:1511831426071};\\\", \\\"{x:1463,y:395,t:1511831426088};\\\", \\\"{x:1461,y:395,t:1511831426105};\\\", \\\"{x:1452,y:398,t:1511831426122};\\\", \\\"{x:1426,y:417,t:1511831426139};\\\", \\\"{x:1400,y:434,t:1511831426155};\\\", \\\"{x:1380,y:451,t:1511831426172};\\\", \\\"{x:1368,y:466,t:1511831426189};\\\", \\\"{x:1364,y:477,t:1511831426205};\\\", \\\"{x:1363,y:479,t:1511831426222};\\\", \\\"{x:1364,y:480,t:1511831426269};\\\", \\\"{x:1365,y:480,t:1511831426277};\\\", \\\"{x:1367,y:478,t:1511831426289};\\\", \\\"{x:1367,y:474,t:1511831426306};\\\", \\\"{x:1368,y:470,t:1511831426322};\\\", \\\"{x:1372,y:466,t:1511831426339};\\\", \\\"{x:1375,y:462,t:1511831426356};\\\", \\\"{x:1378,y:457,t:1511831426372};\\\", \\\"{x:1379,y:456,t:1511831426389};\\\", \\\"{x:1379,y:452,t:1511831426405};\\\", \\\"{x:1380,y:450,t:1511831426429};\\\", \\\"{x:1382,y:448,t:1511831426439};\\\", \\\"{x:1382,y:447,t:1511831426456};\\\", \\\"{x:1382,y:445,t:1511831426472};\\\", \\\"{x:1382,y:443,t:1511831426550};\\\", \\\"{x:1382,y:440,t:1511831426557};\\\", \\\"{x:1382,y:438,t:1511831426572};\\\", \\\"{x:1382,y:436,t:1511831426589};\\\", \\\"{x:1381,y:433,t:1511831426618};\\\", \\\"{x:1381,y:432,t:1511831426638};\\\", \\\"{x:1380,y:431,t:1511831432141};\\\", \\\"{x:1379,y:431,t:1511831432154};\\\", \\\"{x:1377,y:430,t:1511831432172};\\\", \\\"{x:1374,y:429,t:1511831432189};\\\", \\\"{x:1373,y:429,t:1511831432205};\\\", \\\"{x:1372,y:429,t:1511831448132};\\\", \\\"{x:1371,y:431,t:1511831448140};\\\", \\\"{x:1371,y:435,t:1511831448163};\\\", \\\"{x:1371,y:436,t:1511831448452};\\\", \\\"{x:1370,y:436,t:1511831448461};\\\", \\\"{x:1370,y:434,t:1511831448478};\\\", \\\"{x:1371,y:432,t:1511831448500};\\\", \\\"{x:1373,y:430,t:1511831448527};\\\", \\\"{x:1367,y:429,t:1511831480962};\\\", \\\"{x:1256,y:439,t:1511831480987};\\\", \\\"{x:1213,y:444,t:1511831480998};\\\", \\\"{x:1126,y:459,t:1511831481015};\\\", \\\"{x:1070,y:467,t:1511831481032};\\\", \\\"{x:1034,y:472,t:1511831481048};\\\", \\\"{x:1017,y:474,t:1511831481065};\\\", \\\"{x:1014,y:474,t:1511831481082};\\\", \\\"{x:1018,y:474,t:1511831481164};\\\", \\\"{x:1025,y:474,t:1511831481171};\\\", \\\"{x:1032,y:474,t:1511831481182};\\\", \\\"{x:1049,y:471,t:1511831481198};\\\", \\\"{x:1081,y:464,t:1511831481215};\\\", \\\"{x:1157,y:448,t:1511831481232};\\\", \\\"{x:1234,y:431,t:1511831481248};\\\", \\\"{x:1309,y:420,t:1511831481265};\\\", \\\"{x:1349,y:413,t:1511831481282};\\\", \\\"{x:1360,y:412,t:1511831481298};\\\", \\\"{x:1358,y:412,t:1511831481380};\\\", \\\"{x:1354,y:412,t:1511831481388};\\\", \\\"{x:1348,y:412,t:1511831481400};\\\", \\\"{x:1328,y:412,t:1511831481416};\\\", \\\"{x:1309,y:412,t:1511831481433};\\\", \\\"{x:1296,y:412,t:1511831481450};\\\", \\\"{x:1283,y:412,t:1511831481466};\\\", \\\"{x:1274,y:416,t:1511831481483};\\\", \\\"{x:1264,y:419,t:1511831481500};\\\", \\\"{x:1257,y:420,t:1511831481516};\\\", \\\"{x:1255,y:420,t:1511831481532};\\\", \\\"{x:1251,y:422,t:1511831481550};\\\", \\\"{x:1246,y:424,t:1511831481566};\\\", \\\"{x:1238,y:426,t:1511831481583};\\\", \\\"{x:1231,y:428,t:1511831481600};\\\", \\\"{x:1224,y:431,t:1511831481616};\\\", \\\"{x:1217,y:432,t:1511831481633};\\\", \\\"{x:1210,y:434,t:1511831481650};\\\", \\\"{x:1203,y:436,t:1511831481666};\\\", \\\"{x:1189,y:437,t:1511831481682};\\\", \\\"{x:1173,y:439,t:1511831481699};\\\", \\\"{x:1164,y:439,t:1511831481715};\\\", \\\"{x:1161,y:439,t:1511831481732};\\\", \\\"{x:1159,y:439,t:1511831481749};\\\", \\\"{x:1160,y:436,t:1511831481956};\\\", \\\"{x:1161,y:436,t:1511831481967};\\\", \\\"{x:1164,y:432,t:1511831481983};\\\", \\\"{x:1166,y:430,t:1511831482000};\\\", \\\"{x:1167,y:429,t:1511831482028};\\\", \\\"{x:1168,y:429,t:1511831482060};\\\", \\\"{x:1168,y:428,t:1511831482068};\\\", \\\"{x:1169,y:427,t:1511831482083};\\\", \\\"{x:1170,y:427,t:1511831482100};\\\", \\\"{x:1171,y:427,t:1511831482153};\\\", \\\"{x:1174,y:426,t:1511831482166};\\\", \\\"{x:1175,y:426,t:1511831482188};\\\", \\\"{x:1175,y:425,t:1511831482243};\\\", \\\"{x:1176,y:425,t:1511831483324};\\\", \\\"{x:1183,y:425,t:1511831483345};\\\", \\\"{x:1184,y:425,t:1511831483356};\\\", \\\"{x:1186,y:425,t:1511831483435};\\\", \\\"{x:1188,y:425,t:1511831483443};\\\", \\\"{x:1192,y:424,t:1511831483456};\\\", \\\"{x:1193,y:423,t:1511831483473};\\\", \\\"{x:1192,y:423,t:1511831483644};\\\", \\\"{x:1185,y:425,t:1511831483660};\\\", \\\"{x:1179,y:427,t:1511831483675};\\\", \\\"{x:1171,y:430,t:1511831483690};\\\", \\\"{x:1163,y:433,t:1511831483723};\\\", \\\"{x:1160,y:435,t:1511831483740};\\\", \\\"{x:1159,y:435,t:1511831484116};\\\", \\\"{x:1159,y:434,t:1511831484156};\\\", \\\"{x:1160,y:433,t:1511831484292};\\\", \\\"{x:1161,y:431,t:1511831484308};\\\", \\\"{x:1163,y:431,t:1511831484332};\\\", \\\"{x:1164,y:430,t:1511831484348};\\\", \\\"{x:1166,y:429,t:1511831484358};\\\", \\\"{x:1167,y:429,t:1511831484708};\\\", \\\"{x:1168,y:428,t:1511831484725};\\\", \\\"{x:1170,y:428,t:1511831484741};\\\", \\\"{x:1171,y:427,t:1511831485098};\\\", \\\"{x:1173,y:426,t:1511831486437};\\\", \\\"{x:1185,y:426,t:1511831486450};\\\", \\\"{x:1251,y:440,t:1511831486474};\\\", \\\"{x:1257,y:441,t:1511831486493};\\\", \\\"{x:1258,y:441,t:1511831486580};\\\", \\\"{x:1262,y:441,t:1511831486593};\\\", \\\"{x:1276,y:441,t:1511831486609};\\\", \\\"{x:1296,y:441,t:1511831486626};\\\", \\\"{x:1309,y:441,t:1511831486643};\\\", \\\"{x:1317,y:441,t:1511831486660};\\\", \\\"{x:1320,y:441,t:1511831486676};\\\", \\\"{x:1321,y:441,t:1511831486733};\\\", \\\"{x:1323,y:441,t:1511831486749};\\\", \\\"{x:1325,y:441,t:1511831486761};\\\", \\\"{x:1332,y:441,t:1511831486777};\\\", \\\"{x:1345,y:439,t:1511831486794};\\\", \\\"{x:1360,y:438,t:1511831486810};\\\", \\\"{x:1377,y:435,t:1511831486831};\\\", \\\"{x:1388,y:433,t:1511831486844};\\\", \\\"{x:1392,y:433,t:1511831486860};\\\", \\\"{x:1392,y:432,t:1511831487028};\\\", \\\"{x:1392,y:431,t:1511831487043};\\\", \\\"{x:1387,y:430,t:1511831487060};\\\", \\\"{x:1386,y:430,t:1511831487077};\\\", \\\"{x:1385,y:429,t:1511831487109};\\\", \\\"{x:1384,y:429,t:1511831487573};\\\", \\\"{x:1383,y:429,t:1511831487589};\\\", \\\"{x:1382,y:429,t:1511831487602};\\\", \\\"{x:1381,y:428,t:1511831487627};\\\", \\\"{x:1379,y:428,t:1511831487644};\\\", \\\"{x:1378,y:428,t:1511831487724};\\\", \\\"{x:1376,y:428,t:1511831487748};\\\", \\\"{x:1375,y:428,t:1511831487761};\\\", \\\"{x:1374,y:428,t:1511831487788};\\\", \\\"{x:1370,y:437,t:1511831488965};\\\", \\\"{x:1364,y:454,t:1511831488978};\\\", \\\"{x:1348,y:494,t:1511831488995};\\\", \\\"{x:1325,y:547,t:1511831489011};\\\", \\\"{x:1284,y:620,t:1511831489028};\\\", \\\"{x:1269,y:645,t:1511831489045};\\\", \\\"{x:1264,y:664,t:1511831489061};\\\", \\\"{x:1262,y:673,t:1511831489078};\\\", \\\"{x:1261,y:675,t:1511831489095};\\\", \\\"{x:1261,y:671,t:1511831489253};\\\", \\\"{x:1262,y:667,t:1511831489263};\\\", \\\"{x:1266,y:653,t:1511831489279};\\\", \\\"{x:1273,y:640,t:1511831489296};\\\", \\\"{x:1278,y:628,t:1511831489320};\\\", \\\"{x:1281,y:623,t:1511831489329};\\\", \\\"{x:1282,y:620,t:1511831489345};\\\", \\\"{x:1281,y:620,t:1511831489492};\\\", \\\"{x:1280,y:622,t:1511831489500};\\\", \\\"{x:1278,y:624,t:1511831489512};\\\", \\\"{x:1277,y:626,t:1511831489530};\\\", \\\"{x:1275,y:627,t:1511831489545};\\\", \\\"{x:1274,y:627,t:1511831489877};\\\", \\\"{x:1280,y:622,t:1511831491096};\\\", \\\"{x:1299,y:597,t:1511831491113};\\\", \\\"{x:1322,y:573,t:1511831491130};\\\", \\\"{x:1344,y:543,t:1511831491146};\\\", \\\"{x:1353,y:527,t:1511831491163};\\\", \\\"{x:1358,y:510,t:1511831491180};\\\", \\\"{x:1359,y:504,t:1511831491196};\\\", \\\"{x:1359,y:502,t:1511831491213};\\\", \\\"{x:1361,y:498,t:1511831491230};\\\", \\\"{x:1362,y:495,t:1511831491246};\\\", \\\"{x:1363,y:490,t:1511831491263};\\\", \\\"{x:1365,y:486,t:1511831491280};\\\", \\\"{x:1366,y:481,t:1511831491296};\\\", \\\"{x:1366,y:479,t:1511831491313};\\\", \\\"{x:1366,y:474,t:1511831491330};\\\", \\\"{x:1367,y:469,t:1511831491347};\\\", \\\"{x:1369,y:465,t:1511831491364};\\\", \\\"{x:1371,y:458,t:1511831491380};\\\", \\\"{x:1373,y:454,t:1511831491397};\\\", \\\"{x:1373,y:451,t:1511831491414};\\\", \\\"{x:1375,y:446,t:1511831491431};\\\", \\\"{x:1378,y:438,t:1511831491448};\\\", \\\"{x:1383,y:430,t:1511831491464};\\\", \\\"{x:1387,y:423,t:1511831491481};\\\", \\\"{x:1387,y:421,t:1511831491498};\\\", \\\"{x:1388,y:418,t:1511831491514};\\\", \\\"{x:1388,y:417,t:1511831491530};\\\", \\\"{x:1387,y:415,t:1511831491547};\\\", \\\"{x:1386,y:414,t:1511831491563};\\\", \\\"{x:1385,y:415,t:1511831491709};\\\", \\\"{x:1385,y:416,t:1511831491716};\\\", \\\"{x:1385,y:418,t:1511831491731};\\\", \\\"{x:1383,y:421,t:1511831491748};\\\", \\\"{x:1381,y:424,t:1511831491764};\\\", \\\"{x:1380,y:425,t:1511831491781};\\\", \\\"{x:1379,y:425,t:1511831491805};\\\", \\\"{x:1378,y:425,t:1511831491972};\\\", \\\"{x:1377,y:425,t:1511831491980};\\\", \\\"{x:1375,y:426,t:1511831491997};\\\", \\\"{x:1373,y:427,t:1511831492014};\\\", \\\"{x:1371,y:428,t:1511831492030};\\\", \\\"{x:1358,y:443,t:1511831492080};\\\", \\\"{x:1349,y:457,t:1511831492097};\\\", \\\"{x:1337,y:481,t:1511831492114};\\\", \\\"{x:1321,y:509,t:1511831492130};\\\", \\\"{x:1300,y:544,t:1511831492147};\\\", \\\"{x:1287,y:576,t:1511831492164};\\\", \\\"{x:1277,y:593,t:1511831492180};\\\", \\\"{x:1268,y:608,t:1511831492197};\\\", \\\"{x:1264,y:616,t:1511831492214};\\\", \\\"{x:1262,y:619,t:1511831492231};\\\", \\\"{x:1262,y:620,t:1511831492247};\\\", \\\"{x:1262,y:621,t:1511831492357};\\\", \\\"{x:1262,y:623,t:1511831492365};\\\", \\\"{x:1262,y:627,t:1511831492382};\\\", \\\"{x:1262,y:630,t:1511831492398};\\\", \\\"{x:1262,y:631,t:1511831492415};\\\", \\\"{x:1262,y:632,t:1511831492432};\\\", \\\"{x:1262,y:633,t:1511831492493};\\\", \\\"{x:1263,y:633,t:1511831492500};\\\", \\\"{x:1264,y:633,t:1511831492516};\\\", \\\"{x:1265,y:633,t:1511831492532};\\\", \\\"{x:1267,y:632,t:1511831492548};\\\", \\\"{x:1268,y:632,t:1511831492567};\\\", \\\"{x:1270,y:632,t:1511831492581};\\\", \\\"{x:1273,y:630,t:1511831492600};\\\", \\\"{x:1275,y:630,t:1511831492614};\\\", \\\"{x:1276,y:630,t:1511831492631};\\\", \\\"{x:1277,y:629,t:1511831492647};\\\", \\\"{x:1281,y:624,t:1511831492961};\\\", \\\"{x:1299,y:603,t:1511831492981};\\\", \\\"{x:1315,y:586,t:1511831492998};\\\", \\\"{x:1335,y:569,t:1511831493015};\\\", \\\"{x:1347,y:558,t:1511831493031};\\\", \\\"{x:1358,y:546,t:1511831493048};\\\", \\\"{x:1364,y:534,t:1511831493065};\\\", \\\"{x:1367,y:527,t:1511831493081};\\\", \\\"{x:1369,y:523,t:1511831493098};\\\", \\\"{x:1372,y:519,t:1511831493115};\\\", \\\"{x:1374,y:514,t:1511831493131};\\\", \\\"{x:1378,y:507,t:1511831493148};\\\", \\\"{x:1382,y:499,t:1511831493165};\\\", \\\"{x:1386,y:494,t:1511831493182};\\\", \\\"{x:1389,y:488,t:1511831493199};\\\", \\\"{x:1391,y:483,t:1511831493216};\\\", \\\"{x:1395,y:476,t:1511831493232};\\\", \\\"{x:1397,y:469,t:1511831493249};\\\", \\\"{x:1400,y:466,t:1511831493266};\\\", \\\"{x:1401,y:465,t:1511831493282};\\\", \\\"{x:1402,y:464,t:1511831493299};\\\", \\\"{x:1402,y:462,t:1511831493437};\\\", \\\"{x:1400,y:459,t:1511831493449};\\\", \\\"{x:1397,y:457,t:1511831493466};\\\", \\\"{x:1394,y:454,t:1511831493482};\\\", \\\"{x:1386,y:448,t:1511831493499};\\\", \\\"{x:1376,y:440,t:1511831493516};\\\", \\\"{x:1368,y:436,t:1511831493532};\\\", \\\"{x:1367,y:436,t:1511831493549};\\\", \\\"{x:1366,y:435,t:1511831493629};\\\", \\\"{x:1366,y:434,t:1511831493685};\\\", \\\"{x:1366,y:433,t:1511831493733};\\\", \\\"{x:1367,y:433,t:1511831493757};\\\", \\\"{x:1367,y:432,t:1511831493766};\\\", \\\"{x:1368,y:432,t:1511831493782};\\\", \\\"{x:1369,y:431,t:1511831493799};\\\", \\\"{x:1371,y:431,t:1511831493838};\\\", \\\"{x:1372,y:431,t:1511831493849};\\\", \\\"{x:1375,y:429,t:1511831493865};\\\", \\\"{x:1377,y:429,t:1511831493882};\\\", \\\"{x:1377,y:428,t:1511831493898};\\\", \\\"{x:1377,y:430,t:1511831494148};\\\", \\\"{x:1374,y:437,t:1511831494157};\\\", \\\"{x:1369,y:446,t:1511831494165};\\\", \\\"{x:1361,y:463,t:1511831494182};\\\", \\\"{x:1353,y:479,t:1511831494199};\\\", \\\"{x:1341,y:501,t:1511831494215};\\\", \\\"{x:1331,y:518,t:1511831494232};\\\", \\\"{x:1325,y:528,t:1511831494249};\\\", \\\"{x:1320,y:540,t:1511831494265};\\\", \\\"{x:1313,y:555,t:1511831494282};\\\", \\\"{x:1310,y:565,t:1511831494299};\\\", \\\"{x:1307,y:573,t:1511831494316};\\\", \\\"{x:1306,y:576,t:1511831494332};\\\", \\\"{x:1304,y:581,t:1511831494349};\\\", \\\"{x:1303,y:584,t:1511831494366};\\\", \\\"{x:1301,y:587,t:1511831494382};\\\", \\\"{x:1300,y:589,t:1511831494399};\\\", \\\"{x:1299,y:589,t:1511831494416};\\\", \\\"{x:1299,y:590,t:1511831494432};\\\", \\\"{x:1296,y:594,t:1511831494449};\\\", \\\"{x:1294,y:598,t:1511831494467};\\\", \\\"{x:1291,y:602,t:1511831494484};\\\", \\\"{x:1289,y:605,t:1511831494500};\\\", \\\"{x:1285,y:612,t:1511831494516};\\\", \\\"{x:1284,y:616,t:1511831494533};\\\", \\\"{x:1282,y:618,t:1511831494550};\\\", \\\"{x:1281,y:619,t:1511831494588};\\\", \\\"{x:1281,y:620,t:1511831494604};\\\", \\\"{x:1279,y:620,t:1511831494617};\\\", \\\"{x:1279,y:621,t:1511831494632};\\\", \\\"{x:1278,y:623,t:1511831494649};\\\", \\\"{x:1276,y:625,t:1511831494674};\\\", \\\"{x:1275,y:625,t:1511831494683};\\\", \\\"{x:1274,y:627,t:1511831494699};\\\", \\\"{x:1274,y:628,t:1511831494716};\\\", \\\"{x:1273,y:630,t:1511831494732};\\\", \\\"{x:1273,y:631,t:1511831494749};\\\", \\\"{x:1272,y:631,t:1511831494766};\\\", \\\"{x:1272,y:632,t:1511831494876};\\\", \\\"{x:1272,y:631,t:1511831496236};\\\", \\\"{x:1270,y:634,t:1511831498929};\\\", \\\"{x:1259,y:659,t:1511831498952};\\\", \\\"{x:1253,y:674,t:1511831498969};\\\", \\\"{x:1246,y:689,t:1511831498986};\\\", \\\"{x:1240,y:704,t:1511831499002};\\\", \\\"{x:1221,y:733,t:1511831499019};\\\", \\\"{x:1205,y:758,t:1511831499036};\\\", \\\"{x:1186,y:787,t:1511831499052};\\\", \\\"{x:1168,y:812,t:1511831499069};\\\", \\\"{x:1151,y:836,t:1511831499086};\\\", \\\"{x:1133,y:864,t:1511831499103};\\\", \\\"{x:1122,y:879,t:1511831499119};\\\", \\\"{x:1116,y:889,t:1511831499136};\\\", \\\"{x:1106,y:900,t:1511831499153};\\\", \\\"{x:1101,y:907,t:1511831499169};\\\", \\\"{x:1098,y:912,t:1511831499186};\\\", \\\"{x:1095,y:921,t:1511831499204};\\\", \\\"{x:1095,y:924,t:1511831499219};\\\", \\\"{x:1094,y:932,t:1511831499236};\\\", \\\"{x:1094,y:939,t:1511831499254};\\\", \\\"{x:1094,y:946,t:1511831499269};\\\", \\\"{x:1097,y:954,t:1511831499287};\\\", \\\"{x:1100,y:958,t:1511831499304};\\\", \\\"{x:1100,y:959,t:1511831499319};\\\", \\\"{x:1100,y:960,t:1511831499396};\\\", \\\"{x:1102,y:962,t:1511831499404};\\\", \\\"{x:1102,y:968,t:1511831499420};\\\", \\\"{x:1102,y:973,t:1511831499436};\\\", \\\"{x:1103,y:975,t:1511831499454};\\\", \\\"{x:1105,y:975,t:1511831499524};\\\", \\\"{x:1106,y:975,t:1511831499537};\\\", \\\"{x:1111,y:974,t:1511831499554};\\\", \\\"{x:1114,y:973,t:1511831499571};\\\", \\\"{x:1115,y:972,t:1511831499587};\\\", \\\"{x:1117,y:971,t:1511831499604};\\\", \\\"{x:1117,y:969,t:1511831499668};\\\", \\\"{x:1118,y:967,t:1511831499676};\\\", \\\"{x:1120,y:966,t:1511831499687};\\\", \\\"{x:1120,y:961,t:1511831499704};\\\", \\\"{x:1121,y:958,t:1511831499721};\\\", \\\"{x:1121,y:957,t:1511831499737};\\\", \\\"{x:1121,y:956,t:1511831499788};\\\", \\\"{x:1121,y:954,t:1511831499860};\\\", \\\"{x:1118,y:952,t:1511831499871};\\\", \\\"{x:1113,y:949,t:1511831499887};\\\", \\\"{x:1108,y:946,t:1511831499904};\\\", \\\"{x:1106,y:945,t:1511831499921};\\\", \\\"{x:1105,y:945,t:1511831499938};\\\", \\\"{x:1105,y:944,t:1511831499954};\\\", \\\"{x:1102,y:943,t:1511831499980};\\\", \\\"{x:1102,y:942,t:1511831499988};\\\", \\\"{x:1101,y:941,t:1511831500004};\\\", \\\"{x:1089,y:931,t:1511831500021};\\\", \\\"{x:1079,y:923,t:1511831500038};\\\", \\\"{x:1068,y:915,t:1511831500054};\\\", \\\"{x:1058,y:905,t:1511831500071};\\\", \\\"{x:1050,y:896,t:1511831500088};\\\", \\\"{x:1042,y:885,t:1511831500104};\\\", \\\"{x:1031,y:869,t:1511831500121};\\\", \\\"{x:1016,y:850,t:1511831500138};\\\", \\\"{x:1004,y:833,t:1511831500154};\\\", \\\"{x:992,y:817,t:1511831500171};\\\", \\\"{x:972,y:794,t:1511831500188};\\\", \\\"{x:959,y:782,t:1511831500204};\\\", \\\"{x:946,y:772,t:1511831500220};\\\", \\\"{x:940,y:765,t:1511831500238};\\\", \\\"{x:938,y:761,t:1511831500254};\\\", \\\"{x:935,y:757,t:1511831500271};\\\", \\\"{x:932,y:752,t:1511831500288};\\\", \\\"{x:930,y:747,t:1511831500304};\\\", \\\"{x:929,y:742,t:1511831500321};\\\", \\\"{x:927,y:734,t:1511831500338};\\\", \\\"{x:926,y:724,t:1511831500355};\\\", \\\"{x:924,y:713,t:1511831500371};\\\", \\\"{x:921,y:696,t:1511831500388};\\\", \\\"{x:919,y:689,t:1511831500404};\\\", \\\"{x:917,y:684,t:1511831500421};\\\", \\\"{x:917,y:680,t:1511831500438};\\\", \\\"{x:917,y:677,t:1511831500454};\\\", \\\"{x:917,y:676,t:1511831500475};\\\", \\\"{x:918,y:676,t:1511831500531};\\\", \\\"{x:924,y:682,t:1511831500539};\\\", \\\"{x:928,y:688,t:1511831500554};\\\", \\\"{x:939,y:708,t:1511831500570};\\\", \\\"{x:985,y:761,t:1511831500587};\\\", \\\"{x:1025,y:810,t:1511831500604};\\\", \\\"{x:1069,y:855,t:1511831500620};\\\", \\\"{x:1099,y:880,t:1511831500637};\\\", \\\"{x:1112,y:892,t:1511831500654};\\\", \\\"{x:1121,y:903,t:1511831500670};\\\", \\\"{x:1127,y:914,t:1511831500687};\\\", \\\"{x:1133,y:922,t:1511831500704};\\\", \\\"{x:1136,y:926,t:1511831500720};\\\", \\\"{x:1137,y:929,t:1511831500737};\\\", \\\"{x:1138,y:930,t:1511831500754};\\\", \\\"{x:1140,y:932,t:1511831500771};\\\", \\\"{x:1140,y:933,t:1511831500796};\\\", \\\"{x:1140,y:932,t:1511831500876};\\\", \\\"{x:1140,y:930,t:1511831500888};\\\", \\\"{x:1138,y:925,t:1511831500905};\\\", \\\"{x:1135,y:921,t:1511831500922};\\\", \\\"{x:1129,y:916,t:1511831500938};\\\", \\\"{x:1125,y:913,t:1511831500955};\\\", \\\"{x:1120,y:913,t:1511831500972};\\\", \\\"{x:1116,y:913,t:1511831500988};\\\", \\\"{x:1111,y:913,t:1511831501004};\\\", \\\"{x:1100,y:918,t:1511831501021};\\\", \\\"{x:1086,y:922,t:1511831501038};\\\", \\\"{x:1073,y:927,t:1511831501055};\\\", \\\"{x:1061,y:930,t:1511831501072};\\\", \\\"{x:1053,y:934,t:1511831501088};\\\", \\\"{x:1049,y:935,t:1511831501105};\\\", \\\"{x:1049,y:936,t:1511831501122};\\\", \\\"{x:1048,y:936,t:1511831501138};\\\", \\\"{x:1046,y:938,t:1511831501155};\\\", \\\"{x:1040,y:941,t:1511831501172};\\\", \\\"{x:1035,y:943,t:1511831501188};\\\", \\\"{x:1027,y:945,t:1511831501204};\\\", \\\"{x:1023,y:945,t:1511831501221};\\\", \\\"{x:1019,y:945,t:1511831501238};\\\", \\\"{x:1018,y:945,t:1511831501292};\\\", \\\"{x:1016,y:945,t:1511831501305};\\\", \\\"{x:1011,y:945,t:1511831501322};\\\", \\\"{x:1006,y:945,t:1511831501339};\\\", \\\"{x:1002,y:945,t:1511831501355};\\\", \\\"{x:999,y:945,t:1511831501372};\\\", \\\"{x:999,y:944,t:1511831501436};\\\", \\\"{x:999,y:939,t:1511831501444};\\\", \\\"{x:1003,y:931,t:1511831501455};\\\", \\\"{x:1023,y:909,t:1511831501472};\\\", \\\"{x:1077,y:870,t:1511831501489};\\\", \\\"{x:1164,y:810,t:1511831501505};\\\", \\\"{x:1267,y:734,t:1511831501522};\\\", \\\"{x:1347,y:664,t:1511831501539};\\\", \\\"{x:1407,y:617,t:1511831501555};\\\", \\\"{x:1442,y:586,t:1511831501572};\\\", \\\"{x:1447,y:578,t:1511831501588};\\\", \\\"{x:1448,y:570,t:1511831501605};\\\", \\\"{x:1449,y:560,t:1511831501622};\\\", \\\"{x:1449,y:550,t:1511831501639};\\\", \\\"{x:1449,y:542,t:1511831501655};\\\", \\\"{x:1449,y:535,t:1511831501672};\\\", \\\"{x:1449,y:525,t:1511831501689};\\\", \\\"{x:1445,y:508,t:1511831501705};\\\", \\\"{x:1440,y:492,t:1511831501722};\\\", \\\"{x:1431,y:473,t:1511831501739};\\\", \\\"{x:1413,y:450,t:1511831501756};\\\", \\\"{x:1398,y:442,t:1511831501772};\\\", \\\"{x:1390,y:437,t:1511831501788};\\\", \\\"{x:1385,y:434,t:1511831501806};\\\", \\\"{x:1384,y:433,t:1511831501836};\\\", \\\"{x:1384,y:432,t:1511831501852};\\\", \\\"{x:1382,y:432,t:1511831502276};\\\", \\\"{x:1380,y:430,t:1511831502290};\\\", \\\"{x:1376,y:427,t:1511831502322};\\\", \\\"{x:1375,y:427,t:1511831502338};\\\", \\\"{x:1373,y:427,t:1511831502355};\\\", \\\"{x:1372,y:427,t:1511831502372};\\\", \\\"{x:1370,y:427,t:1511831502389};\\\", \\\"{x:1369,y:427,t:1511831502419};\\\", \\\"{x:1367,y:429,t:1511831502708};\\\", \\\"{x:1359,y:432,t:1511831502723};\\\", \\\"{x:1323,y:444,t:1511831502740};\\\", \\\"{x:1298,y:449,t:1511831502756};\\\", \\\"{x:1271,y:453,t:1511831502773};\\\", \\\"{x:1248,y:455,t:1511831502790};\\\", \\\"{x:1234,y:455,t:1511831502806};\\\", \\\"{x:1228,y:455,t:1511831502823};\\\", \\\"{x:1226,y:455,t:1511831502840};\\\", \\\"{x:1225,y:456,t:1511831502860};\\\", \\\"{x:1225,y:458,t:1511831502873};\\\", \\\"{x:1224,y:470,t:1511831502890};\\\", \\\"{x:1221,y:484,t:1511831502906};\\\", \\\"{x:1217,y:498,t:1511831502923};\\\", \\\"{x:1216,y:507,t:1511831502940};\\\", \\\"{x:1215,y:514,t:1511831502956};\\\", \\\"{x:1215,y:524,t:1511831502973};\\\", \\\"{x:1215,y:534,t:1511831502990};\\\", \\\"{x:1214,y:541,t:1511831503007};\\\", \\\"{x:1212,y:548,t:1511831503022};\\\", \\\"{x:1208,y:553,t:1511831503039};\\\", \\\"{x:1207,y:556,t:1511831503057};\\\", \\\"{x:1204,y:560,t:1511831503072};\\\", \\\"{x:1202,y:561,t:1511831503090};\\\", \\\"{x:1200,y:564,t:1511831503106};\\\", \\\"{x:1197,y:564,t:1511831503123};\\\", \\\"{x:1190,y:567,t:1511831503140};\\\", \\\"{x:1186,y:569,t:1511831503156};\\\", \\\"{x:1184,y:569,t:1511831503173};\\\", \\\"{x:1182,y:570,t:1511831503190};\\\", \\\"{x:1181,y:570,t:1511831503260};\\\", \\\"{x:1180,y:570,t:1511831503292};\\\", \\\"{x:1178,y:570,t:1511831503324};\\\", \\\"{x:1176,y:570,t:1511831503364};\\\", \\\"{x:1174,y:569,t:1511831503380};\\\", \\\"{x:1173,y:568,t:1511831503394};\\\", \\\"{x:1172,y:567,t:1511831503406};\\\", \\\"{x:1171,y:567,t:1511831503424};\\\", \\\"{x:1170,y:566,t:1511831503439};\\\", \\\"{x:1169,y:565,t:1511831503456};\\\", \\\"{x:1168,y:565,t:1511831503483};\\\", \\\"{x:1166,y:569,t:1511831503773};\\\", \\\"{x:1161,y:579,t:1511831503781};\\\", \\\"{x:1154,y:589,t:1511831503795};\\\", \\\"{x:1128,y:616,t:1511831503807};\\\", \\\"{x:1086,y:648,t:1511831503824};\\\", \\\"{x:1036,y:681,t:1511831503841};\\\", \\\"{x:964,y:711,t:1511831503857};\\\", \\\"{x:873,y:734,t:1511831503874};\\\", \\\"{x:761,y:759,t:1511831503891};\\\", \\\"{x:642,y:775,t:1511831503907};\\\", \\\"{x:482,y:799,t:1511831503924};\\\", \\\"{x:391,y:810,t:1511831503941};\\\", \\\"{x:307,y:812,t:1511831503957};\\\", \\\"{x:243,y:812,t:1511831503974};\\\", \\\"{x:190,y:812,t:1511831503991};\\\", \\\"{x:148,y:812,t:1511831504007};\\\", \\\"{x:114,y:812,t:1511831504024};\\\", \\\"{x:89,y:812,t:1511831504041};\\\", \\\"{x:78,y:811,t:1511831504057};\\\", \\\"{x:77,y:811,t:1511831504074};\\\", \\\"{x:76,y:808,t:1511831504091};\\\", \\\"{x:76,y:803,t:1511831504107};\\\", \\\"{x:79,y:793,t:1511831504124};\\\", \\\"{x:82,y:789,t:1511831504141};\\\", \\\"{x:86,y:784,t:1511831504157};\\\", \\\"{x:97,y:779,t:1511831504174};\\\", \\\"{x:115,y:775,t:1511831504191};\\\", \\\"{x:137,y:773,t:1511831504210};\\\", \\\"{x:184,y:765,t:1511831504224};\\\", \\\"{x:302,y:753,t:1511831504241};\\\", \\\"{x:459,y:738,t:1511831504258};\\\", \\\"{x:636,y:713,t:1511831504274};\\\", \\\"{x:812,y:698,t:1511831504291};\\\", \\\"{x:1089,y:666,t:1511831504308};\\\", \\\"{x:1290,y:643,t:1511831504324};\\\", \\\"{x:1462,y:619,t:1511831504341};\\\", \\\"{x:1608,y:597,t:1511831504358};\\\", \\\"{x:1656,y:590,t:1511831504374};\\\", \\\"{x:1665,y:588,t:1511831504391};\\\", \\\"{x:1651,y:588,t:1511831504428};\\\", \\\"{x:1620,y:588,t:1511831504441};\\\", \\\"{x:1567,y:588,t:1511831504458};\\\", \\\"{x:1554,y:588,t:1511831504474};\\\", \\\"{x:1551,y:588,t:1511831504491};\\\", \\\"{x:1548,y:585,t:1511831504508};\\\", \\\"{x:1547,y:579,t:1511831504524};\\\", \\\"{x:1545,y:572,t:1511831504541};\\\", \\\"{x:1538,y:557,t:1511831504558};\\\", \\\"{x:1522,y:539,t:1511831504574};\\\", \\\"{x:1464,y:514,t:1511831504591};\\\", \\\"{x:1341,y:493,t:1511831504608};\\\", \\\"{x:1229,y:483,t:1511831504625};\\\", \\\"{x:1148,y:483,t:1511831504641};\\\", \\\"{x:1114,y:483,t:1511831504659};\\\", \\\"{x:1092,y:483,t:1511831504675};\\\", \\\"{x:1078,y:489,t:1511831504692};\\\", \\\"{x:1064,y:516,t:1511831504709};\\\", \\\"{x:1057,y:552,t:1511831504725};\\\", \\\"{x:1042,y:600,t:1511831504742};\\\", \\\"{x:1022,y:635,t:1511831504759};\\\", \\\"{x:1006,y:657,t:1511831504776};\\\", \\\"{x:987,y:675,t:1511831504792};\\\", \\\"{x:962,y:688,t:1511831504809};\\\", \\\"{x:929,y:692,t:1511831504825};\\\", \\\"{x:879,y:692,t:1511831504842};\\\", \\\"{x:791,y:687,t:1511831504859};\\\", \\\"{x:672,y:671,t:1511831504876};\\\", \\\"{x:558,y:654,t:1511831504892};\\\", \\\"{x:426,y:635,t:1511831504909};\\\", \\\"{x:330,y:624,t:1511831504925};\\\", \\\"{x:246,y:613,t:1511831504942};\\\", \\\"{x:179,y:601,t:1511831504959};\\\", \\\"{x:123,y:593,t:1511831504976};\\\", \\\"{x:86,y:591,t:1511831504991};\\\", \\\"{x:54,y:591,t:1511831505008};\\\", \\\"{x:15,y:591,t:1511831505025};\\\", \\\"{x:0,y:591,t:1511831505042};\\\", \\\"{x:0,y:593,t:1511831505061};\\\", \\\"{x:0,y:594,t:1511831505075};\\\", \\\"{x:0,y:595,t:1511831505097};\\\", \\\"{x:9,y:595,t:1511831505140};\\\", \\\"{x:27,y:589,t:1511831505148};\\\", \\\"{x:38,y:587,t:1511831505158};\\\", \\\"{x:62,y:579,t:1511831505175};\\\", \\\"{x:89,y:573,t:1511831505192};\\\", \\\"{x:125,y:573,t:1511831505208};\\\", \\\"{x:148,y:578,t:1511831505225};\\\", \\\"{x:180,y:589,t:1511831505242};\\\", \\\"{x:211,y:603,t:1511831505258};\\\", \\\"{x:230,y:612,t:1511831505275};\\\", \\\"{x:268,y:621,t:1511831505292};\\\", \\\"{x:301,y:626,t:1511831505308};\\\", \\\"{x:319,y:627,t:1511831505325};\\\", \\\"{x:328,y:627,t:1511831505342};\\\", \\\"{x:332,y:627,t:1511831505358};\\\", \\\"{x:333,y:627,t:1511831505404};\\\", \\\"{x:333,y:626,t:1511831505420};\\\", \\\"{x:333,y:625,t:1511831505428};\\\", \\\"{x:333,y:624,t:1511831505442};\\\", \\\"{x:334,y:620,t:1511831505458};\\\", \\\"{x:335,y:617,t:1511831505475};\\\", \\\"{x:337,y:611,t:1511831505492};\\\", \\\"{x:339,y:608,t:1511831505508};\\\", \\\"{x:342,y:606,t:1511831505525};\\\", \\\"{x:350,y:605,t:1511831505542};\\\", \\\"{x:373,y:605,t:1511831505558};\\\", \\\"{x:401,y:608,t:1511831505575};\\\", \\\"{x:423,y:612,t:1511831505592};\\\", \\\"{x:439,y:615,t:1511831505608};\\\", \\\"{x:447,y:615,t:1511831505625};\\\", \\\"{x:451,y:615,t:1511831505642};\\\", \\\"{x:459,y:613,t:1511831505659};\\\", \\\"{x:461,y:611,t:1511831505675};\\\", \\\"{x:464,y:607,t:1511831505692};\\\", \\\"{x:467,y:604,t:1511831505709};\\\", \\\"{x:473,y:601,t:1511831505726};\\\", \\\"{x:476,y:600,t:1511831505742};\\\", \\\"{x:477,y:599,t:1511831505759};\\\", \\\"{x:470,y:599,t:1511831505949};\\\", \\\"{x:458,y:599,t:1511831505959};\\\", \\\"{x:425,y:600,t:1511831505977};\\\", \\\"{x:386,y:600,t:1511831505993};\\\", \\\"{x:356,y:600,t:1511831506009};\\\", \\\"{x:335,y:600,t:1511831506026};\\\", \\\"{x:321,y:600,t:1511831506043};\\\", \\\"{x:320,y:600,t:1511831506059};\\\", \\\"{x:327,y:600,t:1511831506076};\\\", \\\"{x:335,y:598,t:1511831506093};\\\", \\\"{x:339,y:598,t:1511831506109};\\\", \\\"{x:342,y:597,t:1511831506126};\\\", \\\"{x:339,y:597,t:1511831506221};\\\", \\\"{x:336,y:598,t:1511831506229};\\\", \\\"{x:335,y:601,t:1511831506243};\\\", \\\"{x:332,y:607,t:1511831506260};\\\", \\\"{x:331,y:608,t:1511831506276};\\\", \\\"{x:330,y:610,t:1511831506300};\\\", \\\"{x:328,y:611,t:1511831506310};\\\", \\\"{x:319,y:619,t:1511831506326};\\\", \\\"{x:305,y:629,t:1511831506344};\\\", \\\"{x:285,y:639,t:1511831506360};\\\", \\\"{x:265,y:647,t:1511831506376};\\\", \\\"{x:255,y:652,t:1511831506392};\\\", \\\"{x:255,y:653,t:1511831506409};\\\", \\\"{x:253,y:653,t:1511831506426};\\\", \\\"{x:253,y:654,t:1511831506443};\\\", \\\"{x:253,y:655,t:1511831506501};\\\", \\\"{x:253,y:656,t:1511831506524};\\\", \\\"{x:254,y:658,t:1511831506540};\\\", \\\"{x:260,y:658,t:1511831506548};\\\", \\\"{x:271,y:658,t:1511831506559};\\\", \\\"{x:292,y:657,t:1511831506576};\\\", \\\"{x:309,y:651,t:1511831506593};\\\", \\\"{x:327,y:649,t:1511831506609};\\\", \\\"{x:345,y:646,t:1511831506627};\\\", \\\"{x:365,y:644,t:1511831506644};\\\", \\\"{x:383,y:639,t:1511831506660};\\\", \\\"{x:407,y:635,t:1511831506676};\\\", \\\"{x:424,y:631,t:1511831506694};\\\", \\\"{x:439,y:628,t:1511831506709};\\\", \\\"{x:453,y:624,t:1511831506726};\\\", \\\"{x:464,y:620,t:1511831506743};\\\", \\\"{x:473,y:618,t:1511831506759};\\\", \\\"{x:475,y:616,t:1511831506776};\\\", \\\"{x:477,y:615,t:1511831506793};\\\", \\\"{x:479,y:613,t:1511831506810};\\\", \\\"{x:481,y:612,t:1511831506826};\\\", \\\"{x:484,y:610,t:1511831506843};\\\", \\\"{x:485,y:610,t:1511831506860};\\\", \\\"{x:486,y:609,t:1511831506876};\\\", \\\"{x:486,y:608,t:1511831506893};\\\", \\\"{x:486,y:606,t:1511831506909};\\\", \\\"{x:486,y:603,t:1511831506926};\\\", \\\"{x:486,y:602,t:1511831506948};\\\", \\\"{x:483,y:603,t:1511831506980};\\\", \\\"{x:483,y:604,t:1511831506993};\\\", \\\"{x:483,y:609,t:1511831507000};\\\", \\\"{x:486,y:612,t:1511831507016};\\\", \\\"{x:495,y:612,t:1511831507033};\\\", \\\"{x:528,y:612,t:1511831507050};\\\", \\\"{x:551,y:611,t:1511831507066};\\\", \\\"{x:568,y:608,t:1511831507083};\\\", \\\"{x:576,y:605,t:1511831507100};\\\", \\\"{x:578,y:605,t:1511831507130};\\\", \\\"{x:582,y:605,t:1511831507139};\\\", \\\"{x:587,y:605,t:1511831507150};\\\", \\\"{x:600,y:605,t:1511831507167};\\\", \\\"{x:614,y:605,t:1511831507184};\\\", \\\"{x:630,y:606,t:1511831507200};\\\", \\\"{x:637,y:608,t:1511831507218};\\\", \\\"{x:639,y:608,t:1511831507233};\\\", \\\"{x:638,y:608,t:1511831507307};\\\", \\\"{x:636,y:610,t:1511831507318};\\\", \\\"{x:633,y:610,t:1511831507333};\\\", \\\"{x:625,y:610,t:1511831507351};\\\", \\\"{x:618,y:610,t:1511831507367};\\\", \\\"{x:606,y:610,t:1511831507383};\\\", \\\"{x:588,y:610,t:1511831507401};\\\", \\\"{x:573,y:610,t:1511831507417};\\\", \\\"{x:564,y:610,t:1511831507433};\\\", \\\"{x:558,y:608,t:1511831507450};\\\", \\\"{x:557,y:607,t:1511831507467};\\\", \\\"{x:557,y:606,t:1511831507483};\\\", \\\"{x:557,y:603,t:1511831507500};\\\", \\\"{x:557,y:601,t:1511831507517};\\\", \\\"{x:556,y:597,t:1511831507533};\\\", \\\"{x:555,y:593,t:1511831507550};\\\", \\\"{x:552,y:588,t:1511831507567};\\\", \\\"{x:552,y:586,t:1511831507583};\\\", \\\"{x:551,y:586,t:1511831507691};\\\", \\\"{x:548,y:587,t:1511831507700};\\\", \\\"{x:537,y:598,t:1511831507718};\\\", \\\"{x:521,y:607,t:1511831507734};\\\", \\\"{x:507,y:612,t:1511831507750};\\\", \\\"{x:504,y:614,t:1511831507767};\\\", \\\"{x:503,y:615,t:1511831507786};\\\", \\\"{x:506,y:615,t:1511831507800};\\\", \\\"{x:521,y:615,t:1511831507818};\\\", \\\"{x:553,y:615,t:1511831507834};\\\", \\\"{x:572,y:615,t:1511831507850};\\\", \\\"{x:581,y:615,t:1511831507867};\\\", \\\"{x:584,y:615,t:1511831507884};\\\", \\\"{x:585,y:614,t:1511831508019};\\\", \\\"{x:585,y:612,t:1511831508042};\\\", \\\"{x:585,y:611,t:1511831508067};\\\", \\\"{x:585,y:609,t:1511831508084};\\\", \\\"{x:585,y:607,t:1511831508098};\\\", \\\"{x:584,y:606,t:1511831508115};\\\", \\\"{x:584,y:602,t:1511831508131};\\\", \\\"{x:584,y:599,t:1511831508148};\\\", \\\"{x:584,y:598,t:1511831508178};\\\", \\\"{x:582,y:601,t:1511831508317};\\\", \\\"{x:570,y:614,t:1511831508334};\\\", \\\"{x:545,y:631,t:1511831508351};\\\", \\\"{x:525,y:648,t:1511831508367};\\\", \\\"{x:507,y:662,t:1511831508384};\\\", \\\"{x:496,y:671,t:1511831508401};\\\", \\\"{x:486,y:676,t:1511831508417};\\\", \\\"{x:477,y:682,t:1511831508434};\\\", \\\"{x:469,y:683,t:1511831508451};\\\", \\\"{x:462,y:684,t:1511831508468};\\\", \\\"{x:457,y:685,t:1511831508484};\\\", \\\"{x:448,y:685,t:1511831508501};\\\", \\\"{x:442,y:685,t:1511831508518};\\\", \\\"{x:441,y:685,t:1511831508554};\\\", \\\"{x:439,y:685,t:1511831508568};\\\", \\\"{x:433,y:683,t:1511831508584};\\\", \\\"{x:425,y:682,t:1511831508602};\\\", \\\"{x:408,y:681,t:1511831508618};\\\", \\\"{x:398,y:681,t:1511831508634};\\\", \\\"{x:395,y:681,t:1511831508651};\\\", \\\"{x:394,y:681,t:1511831508669};\\\", \\\"{x:394,y:682,t:1511831508747};\\\", \\\"{x:393,y:685,t:1511831508754};\\\", \\\"{x:392,y:689,t:1511831508768};\\\", \\\"{x:392,y:693,t:1511831508785};\\\", \\\"{x:391,y:697,t:1511831508801};\\\", \\\"{x:391,y:701,t:1511831508818};\\\", \\\"{x:391,y:704,t:1511831508835};\\\", \\\"{x:391,y:706,t:1511831508851};\\\", \\\"{x:391,y:711,t:1511831508868};\\\", \\\"{x:391,y:713,t:1511831508885};\\\", \\\"{x:391,y:715,t:1511831508901};\\\", \\\"{x:390,y:713,t:1511831509043};\\\", \\\"{x:388,y:710,t:1511831509053};\\\", \\\"{x:385,y:701,t:1511831509069};\\\", \\\"{x:380,y:694,t:1511831509086};\\\", \\\"{x:372,y:687,t:1511831509103};\\\", \\\"{x:361,y:680,t:1511831509118};\\\", \\\"{x:350,y:675,t:1511831509135};\\\", \\\"{x:334,y:667,t:1511831509151};\\\", \\\"{x:314,y:656,t:1511831509168};\\\", \\\"{x:283,y:643,t:1511831509185};\\\", \\\"{x:240,y:628,t:1511831509201};\\\", \\\"{x:194,y:616,t:1511831509218};\\\", \\\"{x:189,y:615,t:1511831509235};\\\", \\\"{x:190,y:612,t:1511831509282};\\\", \\\"{x:196,y:612,t:1511831509290};\\\", \\\"{x:205,y:612,t:1511831509301};\\\", \\\"{x:228,y:612,t:1511831509318};\\\", \\\"{x:251,y:612,t:1511831509335};\\\", \\\"{x:266,y:612,t:1511831509352};\\\", \\\"{x:273,y:612,t:1511831509368};\\\", \\\"{x:274,y:612,t:1511831509385};\\\", \\\"{x:275,y:612,t:1511831509418};\\\", \\\"{x:277,y:616,t:1511831509436};\\\", \\\"{x:281,y:622,t:1511831509453};\\\", \\\"{x:285,y:626,t:1511831509468};\\\", \\\"{x:287,y:628,t:1511831509486};\\\", \\\"{x:288,y:628,t:1511831509618};\\\", \\\"{x:290,y:628,t:1511831509635};\\\", \\\"{x:291,y:628,t:1511831509652};\\\", \\\"{x:292,y:628,t:1511831509668};\\\", \\\"{x:294,y:627,t:1511831509685};\\\", \\\"{x:295,y:627,t:1511831509702};\\\", \\\"{x:297,y:627,t:1511831509719};\\\", \\\"{x:297,y:626,t:1511831509735};\\\", \\\"{x:298,y:626,t:1511831509762};\\\", \\\"{x:299,y:626,t:1511831509778};\\\", \\\"{x:301,y:626,t:1511831509786};\\\", \\\"{x:302,y:626,t:1511831509826};\\\", \\\"{x:304,y:626,t:1511831509875};\\\", \\\"{x:306,y:626,t:1511831509890};\\\", \\\"{x:307,y:626,t:1511831509913};\\\", \\\"{x:307,y:627,t:1511831509937};\\\", \\\"{x:309,y:627,t:1511831509962};\\\", \\\"{x:310,y:627,t:1511831509978};\\\", \\\"{x:311,y:627,t:1511831510227};\\\", \\\"{x:311,y:628,t:1511831511187};\\\", \\\"{x:309,y:633,t:1511831511203};\\\", \\\"{x:308,y:638,t:1511831511220};\\\", \\\"{x:308,y:646,t:1511831511236};\\\", \\\"{x:308,y:653,t:1511831511253};\\\", \\\"{x:311,y:661,t:1511831511270};\\\", \\\"{x:315,y:665,t:1511831511286};\\\", \\\"{x:326,y:672,t:1511831511303};\\\", \\\"{x:338,y:678,t:1511831511320};\\\", \\\"{x:350,y:683,t:1511831511336};\\\", \\\"{x:359,y:688,t:1511831511353};\\\", \\\"{x:367,y:692,t:1511831511370};\\\", \\\"{x:369,y:693,t:1511831511386};\\\", \\\"{x:370,y:694,t:1511831511403};\\\", \\\"{x:371,y:694,t:1511831511420};\\\", \\\"{x:372,y:694,t:1511831511437};\\\", \\\"{x:373,y:694,t:1511831511457};\\\", \\\"{x:374,y:694,t:1511831511490};\\\", \\\"{x:375,y:695,t:1511831511503};\\\", \\\"{x:378,y:698,t:1511831511520};\\\", \\\"{x:379,y:698,t:1511831511537};\\\", \\\"{x:380,y:700,t:1511831511553};\\\", \\\"{x:381,y:701,t:1511831511570};\\\", \\\"{x:382,y:703,t:1511831511587};\\\", \\\"{x:383,y:704,t:1511831511603};\\\", \\\"{x:384,y:706,t:1511831511620};\\\", \\\"{x:384,y:707,t:1511831511637};\\\", \\\"{x:384,y:708,t:1511831511653};\\\", \\\"{x:385,y:709,t:1511831511739};\\\", \\\"{x:385,y:704,t:1511831513066};\\\", \\\"{x:389,y:697,t:1511831513073};\\\", \\\"{x:393,y:692,t:1511831513088};\\\", \\\"{x:409,y:677,t:1511831513104};\\\", \\\"{x:429,y:661,t:1511831513121};\\\", \\\"{x:460,y:641,t:1511831513137};\\\", \\\"{x:480,y:628,t:1511831513154};\\\", \\\"{x:510,y:608,t:1511831513177};\\\", \\\"{x:530,y:597,t:1511831513208};\\\", \\\"{x:551,y:586,t:1511831513221};\\\", \\\"{x:558,y:583,t:1511831513238};\\\", \\\"{x:562,y:581,t:1511831513255};\\\", \\\"{x:567,y:577,t:1511831513271};\\\", \\\"{x:570,y:575,t:1511831513288};\\\" ] }, { \\\"rt\\\": 16284, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 323134, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -F -C -C -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:572,y:575,t:1511831514633};\\\", \\\"{x:579,y:574,t:1511831514641};\\\", \\\"{x:588,y:570,t:1511831514656};\\\", \\\"{x:606,y:568,t:1511831514672};\\\", \\\"{x:633,y:563,t:1511831514689};\\\", \\\"{x:648,y:562,t:1511831514706};\\\", \\\"{x:659,y:559,t:1511831514722};\\\", \\\"{x:673,y:557,t:1511831514739};\\\", \\\"{x:692,y:555,t:1511831514756};\\\", \\\"{x:706,y:555,t:1511831514772};\\\", \\\"{x:718,y:555,t:1511831514789};\\\", \\\"{x:727,y:555,t:1511831514806};\\\", \\\"{x:731,y:555,t:1511831514823};\\\", \\\"{x:732,y:555,t:1511831514839};\\\", \\\"{x:733,y:555,t:1511831514856};\\\", \\\"{x:734,y:555,t:1511831514913};\\\", \\\"{x:734,y:558,t:1511831514923};\\\", \\\"{x:730,y:566,t:1511831514939};\\\", \\\"{x:727,y:572,t:1511831514956};\\\", \\\"{x:722,y:579,t:1511831514973};\\\", \\\"{x:716,y:586,t:1511831514989};\\\", \\\"{x:711,y:595,t:1511831515006};\\\", \\\"{x:706,y:601,t:1511831515023};\\\", \\\"{x:704,y:603,t:1511831515039};\\\", \\\"{x:702,y:605,t:1511831515057};\\\", \\\"{x:701,y:606,t:1511831515081};\\\", \\\"{x:700,y:606,t:1511831515105};\\\", \\\"{x:706,y:606,t:1511831516986};\\\", \\\"{x:720,y:606,t:1511831516993};\\\", \\\"{x:735,y:606,t:1511831517008};\\\", \\\"{x:768,y:606,t:1511831517024};\\\", \\\"{x:821,y:610,t:1511831517041};\\\", \\\"{x:858,y:611,t:1511831517058};\\\", \\\"{x:895,y:611,t:1511831517074};\\\", \\\"{x:929,y:611,t:1511831517091};\\\", \\\"{x:961,y:611,t:1511831517108};\\\", \\\"{x:988,y:611,t:1511831517125};\\\", \\\"{x:1012,y:611,t:1511831517141};\\\", \\\"{x:1033,y:611,t:1511831517159};\\\", \\\"{x:1044,y:611,t:1511831517175};\\\", \\\"{x:1055,y:611,t:1511831517191};\\\", \\\"{x:1058,y:611,t:1511831517208};\\\", \\\"{x:1061,y:611,t:1511831517225};\\\", \\\"{x:1062,y:612,t:1511831517241};\\\", \\\"{x:1063,y:613,t:1511831517258};\\\", \\\"{x:1064,y:615,t:1511831517275};\\\", \\\"{x:1067,y:620,t:1511831517291};\\\", \\\"{x:1081,y:637,t:1511831517308};\\\", \\\"{x:1104,y:664,t:1511831517325};\\\", \\\"{x:1127,y:691,t:1511831517341};\\\", \\\"{x:1144,y:707,t:1511831517358};\\\", \\\"{x:1160,y:719,t:1511831517375};\\\", \\\"{x:1171,y:727,t:1511831517391};\\\", \\\"{x:1174,y:730,t:1511831517408};\\\", \\\"{x:1178,y:738,t:1511831517425};\\\", \\\"{x:1182,y:744,t:1511831517441};\\\", \\\"{x:1187,y:751,t:1511831517458};\\\", \\\"{x:1191,y:758,t:1511831517475};\\\", \\\"{x:1195,y:765,t:1511831517492};\\\", \\\"{x:1196,y:769,t:1511831517508};\\\", \\\"{x:1199,y:782,t:1511831517525};\\\", \\\"{x:1198,y:804,t:1511831517542};\\\", \\\"{x:1188,y:835,t:1511831517558};\\\", \\\"{x:1176,y:859,t:1511831517575};\\\", \\\"{x:1166,y:876,t:1511831517592};\\\", \\\"{x:1157,y:890,t:1511831517608};\\\", \\\"{x:1144,y:906,t:1511831517625};\\\", \\\"{x:1138,y:915,t:1511831517642};\\\", \\\"{x:1131,y:923,t:1511831517658};\\\", \\\"{x:1130,y:927,t:1511831517675};\\\", \\\"{x:1129,y:928,t:1511831517692};\\\", \\\"{x:1128,y:929,t:1511831517761};\\\", \\\"{x:1132,y:929,t:1511831517802};\\\", \\\"{x:1142,y:929,t:1511831517809};\\\", \\\"{x:1167,y:921,t:1511831517826};\\\", \\\"{x:1198,y:912,t:1511831517842};\\\", \\\"{x:1252,y:894,t:1511831517859};\\\", \\\"{x:1304,y:871,t:1511831517875};\\\", \\\"{x:1352,y:849,t:1511831517892};\\\", \\\"{x:1390,y:825,t:1511831517909};\\\", \\\"{x:1407,y:810,t:1511831517925};\\\", \\\"{x:1415,y:796,t:1511831517942};\\\", \\\"{x:1416,y:786,t:1511831517959};\\\", \\\"{x:1416,y:773,t:1511831517975};\\\", \\\"{x:1416,y:751,t:1511831517992};\\\", \\\"{x:1416,y:704,t:1511831518009};\\\", \\\"{x:1419,y:679,t:1511831518025};\\\", \\\"{x:1422,y:657,t:1511831518042};\\\", \\\"{x:1422,y:631,t:1511831518059};\\\", \\\"{x:1422,y:592,t:1511831518075};\\\", \\\"{x:1415,y:554,t:1511831518092};\\\", \\\"{x:1405,y:532,t:1511831518109};\\\", \\\"{x:1395,y:517,t:1511831518125};\\\", \\\"{x:1386,y:505,t:1511831518142};\\\", \\\"{x:1383,y:499,t:1511831518159};\\\", \\\"{x:1381,y:498,t:1511831518175};\\\", \\\"{x:1381,y:497,t:1511831518193};\\\", \\\"{x:1381,y:495,t:1511831518209};\\\", \\\"{x:1381,y:493,t:1511831518225};\\\", \\\"{x:1381,y:492,t:1511831518242};\\\", \\\"{x:1381,y:491,t:1511831518259};\\\", \\\"{x:1381,y:487,t:1511831518276};\\\", \\\"{x:1381,y:486,t:1511831518292};\\\", \\\"{x:1380,y:482,t:1511831518309};\\\", \\\"{x:1375,y:475,t:1511831518326};\\\", \\\"{x:1361,y:462,t:1511831518342};\\\", \\\"{x:1344,y:452,t:1511831518359};\\\", \\\"{x:1331,y:445,t:1511831518376};\\\", \\\"{x:1320,y:438,t:1511831518392};\\\", \\\"{x:1308,y:433,t:1511831518409};\\\", \\\"{x:1306,y:433,t:1511831518427};\\\", \\\"{x:1305,y:437,t:1511831518481};\\\", \\\"{x:1303,y:444,t:1511831518492};\\\", \\\"{x:1296,y:465,t:1511831518509};\\\", \\\"{x:1287,y:489,t:1511831518526};\\\", \\\"{x:1279,y:511,t:1511831518542};\\\", \\\"{x:1274,y:531,t:1511831518559};\\\", \\\"{x:1272,y:548,t:1511831518576};\\\", \\\"{x:1268,y:566,t:1511831518593};\\\", \\\"{x:1267,y:580,t:1511831518609};\\\", \\\"{x:1266,y:591,t:1511831518626};\\\", \\\"{x:1264,y:605,t:1511831518643};\\\", \\\"{x:1264,y:616,t:1511831518659};\\\", \\\"{x:1264,y:623,t:1511831518676};\\\", \\\"{x:1264,y:625,t:1511831518693};\\\", \\\"{x:1264,y:627,t:1511831518709};\\\", \\\"{x:1264,y:629,t:1511831518745};\\\", \\\"{x:1264,y:630,t:1511831518759};\\\", \\\"{x:1264,y:633,t:1511831518776};\\\", \\\"{x:1258,y:644,t:1511831518793};\\\", \\\"{x:1249,y:651,t:1511831518809};\\\", \\\"{x:1240,y:662,t:1511831518826};\\\", \\\"{x:1227,y:676,t:1511831518843};\\\", \\\"{x:1213,y:689,t:1511831518859};\\\", \\\"{x:1198,y:701,t:1511831518876};\\\", \\\"{x:1187,y:710,t:1511831518893};\\\", \\\"{x:1177,y:719,t:1511831518909};\\\", \\\"{x:1166,y:728,t:1511831518926};\\\", \\\"{x:1154,y:744,t:1511831518943};\\\", \\\"{x:1138,y:760,t:1511831518962};\\\", \\\"{x:1128,y:772,t:1511831518978};\\\", \\\"{x:1112,y:782,t:1511831519009};\\\", \\\"{x:1106,y:785,t:1511831519024};\\\", \\\"{x:1089,y:788,t:1511831519041};\\\", \\\"{x:1080,y:790,t:1511831519058};\\\", \\\"{x:1073,y:791,t:1511831519074};\\\", \\\"{x:1066,y:795,t:1511831519091};\\\", \\\"{x:1059,y:796,t:1511831519108};\\\", \\\"{x:1053,y:799,t:1511831519124};\\\", \\\"{x:1050,y:799,t:1511831519141};\\\", \\\"{x:1047,y:800,t:1511831519158};\\\", \\\"{x:1037,y:803,t:1511831519174};\\\", \\\"{x:1022,y:803,t:1511831519191};\\\", \\\"{x:1010,y:805,t:1511831519208};\\\", \\\"{x:1009,y:805,t:1511831519224};\\\", \\\"{x:1007,y:805,t:1511831519281};\\\", \\\"{x:1005,y:805,t:1511831519291};\\\", \\\"{x:1000,y:805,t:1511831519308};\\\", \\\"{x:995,y:806,t:1511831519325};\\\", \\\"{x:993,y:807,t:1511831519341};\\\", \\\"{x:991,y:808,t:1511831519358};\\\", \\\"{x:989,y:810,t:1511831519375};\\\", \\\"{x:988,y:811,t:1511831519391};\\\", \\\"{x:986,y:813,t:1511831519408};\\\", \\\"{x:985,y:814,t:1511831519433};\\\", \\\"{x:984,y:814,t:1511831519449};\\\", \\\"{x:983,y:816,t:1511831519458};\\\", \\\"{x:981,y:818,t:1511831519475};\\\", \\\"{x:978,y:819,t:1511831519491};\\\", \\\"{x:978,y:820,t:1511831519508};\\\", \\\"{x:977,y:820,t:1511831519529};\\\", \\\"{x:977,y:821,t:1511831519541};\\\", \\\"{x:975,y:823,t:1511831519558};\\\", \\\"{x:972,y:825,t:1511831519576};\\\", \\\"{x:971,y:826,t:1511831519593};\\\", \\\"{x:970,y:826,t:1511831519609};\\\", \\\"{x:969,y:827,t:1511831519705};\\\", \\\"{x:969,y:829,t:1511831519986};\\\", \\\"{x:970,y:829,t:1511831519994};\\\", \\\"{x:970,y:830,t:1511831520008};\\\", \\\"{x:972,y:831,t:1511831520027};\\\", \\\"{x:973,y:831,t:1511831520060};\\\", \\\"{x:975,y:832,t:1511831520076};\\\", \\\"{x:986,y:832,t:1511831524496};\\\", \\\"{x:1048,y:830,t:1511831524514};\\\", \\\"{x:1086,y:823,t:1511831524531};\\\", \\\"{x:1116,y:819,t:1511831524548};\\\", \\\"{x:1146,y:815,t:1511831524564};\\\", \\\"{x:1171,y:811,t:1511831524581};\\\", \\\"{x:1185,y:806,t:1511831524598};\\\", \\\"{x:1187,y:806,t:1511831524614};\\\", \\\"{x:1188,y:806,t:1511831524634};\\\", \\\"{x:1188,y:803,t:1511831524706};\\\", \\\"{x:1188,y:802,t:1511831524715};\\\", \\\"{x:1184,y:798,t:1511831524731};\\\", \\\"{x:1176,y:793,t:1511831524749};\\\", \\\"{x:1170,y:789,t:1511831524765};\\\", \\\"{x:1169,y:788,t:1511831524781};\\\", \\\"{x:1168,y:787,t:1511831524851};\\\", \\\"{x:1168,y:786,t:1511831524865};\\\", \\\"{x:1166,y:783,t:1511831524882};\\\", \\\"{x:1164,y:775,t:1511831524899};\\\", \\\"{x:1162,y:771,t:1511831524915};\\\", \\\"{x:1160,y:768,t:1511831524932};\\\", \\\"{x:1159,y:766,t:1511831524949};\\\", \\\"{x:1159,y:765,t:1511831525163};\\\", \\\"{x:1159,y:762,t:1511831525171};\\\", \\\"{x:1157,y:762,t:1511831525182};\\\", \\\"{x:1154,y:758,t:1511831525198};\\\", \\\"{x:1149,y:755,t:1511831525215};\\\", \\\"{x:1147,y:753,t:1511831525231};\\\", \\\"{x:1146,y:753,t:1511831525248};\\\", \\\"{x:1144,y:753,t:1511831525763};\\\", \\\"{x:1142,y:754,t:1511831525770};\\\", \\\"{x:1141,y:757,t:1511831525782};\\\", \\\"{x:1139,y:761,t:1511831525804};\\\", \\\"{x:1137,y:763,t:1511831525815};\\\", \\\"{x:1137,y:762,t:1511831526066};\\\", \\\"{x:1135,y:763,t:1511831527051};\\\", \\\"{x:1121,y:765,t:1511831527066};\\\", \\\"{x:1092,y:765,t:1511831527083};\\\", \\\"{x:1037,y:765,t:1511831527100};\\\", \\\"{x:942,y:765,t:1511831527116};\\\", \\\"{x:815,y:747,t:1511831527133};\\\", \\\"{x:673,y:725,t:1511831527150};\\\", \\\"{x:537,y:704,t:1511831527166};\\\", \\\"{x:412,y:683,t:1511831527183};\\\", \\\"{x:289,y:658,t:1511831527200};\\\", \\\"{x:176,y:627,t:1511831527216};\\\", \\\"{x:89,y:600,t:1511831527234};\\\", \\\"{x:42,y:582,t:1511831527249};\\\", \\\"{x:37,y:577,t:1511831527267};\\\", \\\"{x:37,y:572,t:1511831527283};\\\", \\\"{x:46,y:567,t:1511831527300};\\\", \\\"{x:59,y:562,t:1511831527317};\\\", \\\"{x:68,y:560,t:1511831527333};\\\", \\\"{x:73,y:558,t:1511831527350};\\\", \\\"{x:85,y:555,t:1511831527367};\\\", \\\"{x:104,y:551,t:1511831527383};\\\", \\\"{x:127,y:551,t:1511831527400};\\\", \\\"{x:152,y:551,t:1511831527417};\\\", \\\"{x:175,y:551,t:1511831527433};\\\", \\\"{x:195,y:557,t:1511831527450};\\\", \\\"{x:209,y:563,t:1511831527467};\\\", \\\"{x:229,y:573,t:1511831527483};\\\", \\\"{x:250,y:583,t:1511831527500};\\\", \\\"{x:268,y:593,t:1511831527517};\\\", \\\"{x:281,y:601,t:1511831527533};\\\", \\\"{x:290,y:605,t:1511831527550};\\\", \\\"{x:293,y:606,t:1511831527567};\\\", \\\"{x:296,y:606,t:1511831527583};\\\", \\\"{x:300,y:607,t:1511831527600};\\\", \\\"{x:305,y:607,t:1511831527617};\\\", \\\"{x:309,y:608,t:1511831527633};\\\", \\\"{x:333,y:614,t:1511831527650};\\\", \\\"{x:352,y:617,t:1511831527667};\\\", \\\"{x:369,y:619,t:1511831527683};\\\", \\\"{x:388,y:620,t:1511831527700};\\\", \\\"{x:410,y:620,t:1511831527717};\\\", \\\"{x:431,y:620,t:1511831527733};\\\", \\\"{x:465,y:612,t:1511831527750};\\\", \\\"{x:516,y:603,t:1511831527767};\\\", \\\"{x:555,y:592,t:1511831527784};\\\", \\\"{x:580,y:584,t:1511831527800};\\\", \\\"{x:590,y:581,t:1511831527817};\\\", \\\"{x:590,y:584,t:1511831527915};\\\", \\\"{x:586,y:589,t:1511831527934};\\\", \\\"{x:579,y:596,t:1511831527951};\\\", \\\"{x:568,y:603,t:1511831527968};\\\", \\\"{x:553,y:608,t:1511831527984};\\\", \\\"{x:526,y:614,t:1511831528001};\\\", \\\"{x:482,y:619,t:1511831528017};\\\", \\\"{x:379,y:628,t:1511831528034};\\\", \\\"{x:315,y:628,t:1511831528051};\\\", \\\"{x:282,y:628,t:1511831528067};\\\", \\\"{x:262,y:628,t:1511831528084};\\\", \\\"{x:258,y:628,t:1511831528101};\\\", \\\"{x:256,y:628,t:1511831528117};\\\", \\\"{x:255,y:628,t:1511831528145};\\\", \\\"{x:254,y:628,t:1511831528153};\\\", \\\"{x:252,y:628,t:1511831528167};\\\", \\\"{x:244,y:628,t:1511831528184};\\\", \\\"{x:233,y:626,t:1511831528201};\\\", \\\"{x:219,y:624,t:1511831528217};\\\", \\\"{x:211,y:622,t:1511831528234};\\\", \\\"{x:209,y:622,t:1511831528251};\\\", \\\"{x:209,y:621,t:1511831528267};\\\", \\\"{x:209,y:618,t:1511831528284};\\\", \\\"{x:209,y:617,t:1511831528301};\\\", \\\"{x:209,y:615,t:1511831528317};\\\", \\\"{x:209,y:614,t:1511831528334};\\\", \\\"{x:209,y:612,t:1511831528466};\\\", \\\"{x:209,y:610,t:1511831528473};\\\", \\\"{x:209,y:608,t:1511831528489};\\\", \\\"{x:209,y:607,t:1511831528501};\\\", \\\"{x:209,y:605,t:1511831528518};\\\", \\\"{x:210,y:601,t:1511831528534};\\\", \\\"{x:211,y:601,t:1511831528594};\\\", \\\"{x:213,y:601,t:1511831528617};\\\", \\\"{x:215,y:600,t:1511831528634};\\\", \\\"{x:217,y:600,t:1511831528651};\\\", \\\"{x:218,y:600,t:1511831528667};\\\", \\\"{x:219,y:600,t:1511831528684};\\\", \\\"{x:219,y:600,t:1511831528714};\\\", \\\"{x:220,y:600,t:1511831528786};\\\", \\\"{x:221,y:600,t:1511831528800};\\\", \\\"{x:222,y:601,t:1511831528817};\\\", \\\"{x:227,y:609,t:1511831528834};\\\", \\\"{x:228,y:615,t:1511831528851};\\\", \\\"{x:231,y:619,t:1511831528867};\\\", \\\"{x:231,y:621,t:1511831528884};\\\", \\\"{x:232,y:621,t:1511831528901};\\\", \\\"{x:232,y:622,t:1511831528918};\\\", \\\"{x:231,y:620,t:1511831529051};\\\", \\\"{x:231,y:618,t:1511831529069};\\\", \\\"{x:230,y:616,t:1511831529085};\\\", \\\"{x:228,y:613,t:1511831529101};\\\", \\\"{x:226,y:610,t:1511831529119};\\\", \\\"{x:224,y:608,t:1511831529135};\\\", \\\"{x:224,y:607,t:1511831529151};\\\", \\\"{x:222,y:607,t:1511831529170};\\\", \\\"{x:221,y:606,t:1511831529186};\\\", \\\"{x:219,y:606,t:1511831529218};\\\", \\\"{x:218,y:606,t:1511831529242};\\\", \\\"{x:224,y:611,t:1511831529466};\\\", \\\"{x:232,y:617,t:1511831529474};\\\", \\\"{x:243,y:623,t:1511831529485};\\\", \\\"{x:263,y:638,t:1511831529501};\\\", \\\"{x:287,y:646,t:1511831529518};\\\", \\\"{x:308,y:656,t:1511831529535};\\\", \\\"{x:324,y:666,t:1511831529552};\\\", \\\"{x:334,y:674,t:1511831529568};\\\", \\\"{x:339,y:680,t:1511831529585};\\\", \\\"{x:347,y:687,t:1511831529602};\\\", \\\"{x:350,y:689,t:1511831529618};\\\", \\\"{x:351,y:689,t:1511831529691};\\\", \\\"{x:352,y:691,t:1511831529703};\\\", \\\"{x:353,y:692,t:1511831529718};\\\", \\\"{x:357,y:697,t:1511831529735};\\\", \\\"{x:360,y:701,t:1511831529752};\\\", \\\"{x:364,y:705,t:1511831529768};\\\", \\\"{x:367,y:707,t:1511831529785};\\\", \\\"{x:368,y:707,t:1511831529802};\\\", \\\"{x:370,y:707,t:1511831529858};\\\", \\\"{x:371,y:707,t:1511831530033};\\\", \\\"{x:372,y:707,t:1511831530065};\\\", \\\"{x:373,y:706,t:1511831530226};\\\", \\\"{x:374,y:706,t:1511831530250};\\\", \\\"{x:375,y:705,t:1511831530258};\\\", \\\"{x:376,y:705,t:1511831530269};\\\", \\\"{x:377,y:704,t:1511831530286};\\\", \\\"{x:379,y:703,t:1511831530302};\\\", \\\"{x:381,y:703,t:1511831530319};\\\", \\\"{x:382,y:702,t:1511831530336};\\\", \\\"{x:385,y:701,t:1511831530352};\\\", \\\"{x:390,y:699,t:1511831530369};\\\", \\\"{x:400,y:696,t:1511831530385};\\\", \\\"{x:407,y:695,t:1511831530402};\\\", \\\"{x:416,y:692,t:1511831530419};\\\", \\\"{x:427,y:689,t:1511831530436};\\\", \\\"{x:433,y:687,t:1511831530452};\\\", \\\"{x:442,y:685,t:1511831530469};\\\", \\\"{x:458,y:682,t:1511831530486};\\\", \\\"{x:474,y:681,t:1511831530502};\\\", \\\"{x:490,y:678,t:1511831530519};\\\", \\\"{x:505,y:675,t:1511831530536};\\\", \\\"{x:514,y:673,t:1511831530552};\\\", \\\"{x:522,y:672,t:1511831530569};\\\", \\\"{x:527,y:671,t:1511831530586};\\\", \\\"{x:528,y:671,t:1511831531001};\\\", \\\"{x:528,y:670,t:1511831531089};\\\", \\\"{x:529,y:669,t:1511831531103};\\\", \\\"{x:529,y:668,t:1511831531120};\\\" ] }, { \\\"rt\\\": 16304, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 340760, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-04 PM-H -H -H -B -H -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:665,t:1511831531298};\\\", \\\"{x:529,y:663,t:1511831532313};\\\", \\\"{x:542,y:661,t:1511831532321};\\\", \\\"{x:598,y:653,t:1511831532337};\\\", \\\"{x:648,y:647,t:1511831532353};\\\", \\\"{x:694,y:644,t:1511831532370};\\\", \\\"{x:723,y:640,t:1511831532387};\\\", \\\"{x:745,y:639,t:1511831532404};\\\", \\\"{x:763,y:638,t:1511831532420};\\\", \\\"{x:776,y:635,t:1511831532437};\\\", \\\"{x:790,y:636,t:1511831532454};\\\", \\\"{x:803,y:640,t:1511831532471};\\\", \\\"{x:827,y:649,t:1511831532487};\\\", \\\"{x:853,y:660,t:1511831532504};\\\", \\\"{x:918,y:681,t:1511831532521};\\\", \\\"{x:965,y:694,t:1511831532537};\\\", \\\"{x:993,y:701,t:1511831532554};\\\", \\\"{x:1021,y:709,t:1511831532571};\\\", \\\"{x:1046,y:717,t:1511831532587};\\\", \\\"{x:1065,y:725,t:1511831532604};\\\", \\\"{x:1077,y:731,t:1511831532621};\\\", \\\"{x:1085,y:736,t:1511831532637};\\\", \\\"{x:1089,y:739,t:1511831532654};\\\", \\\"{x:1093,y:746,t:1511831532671};\\\", \\\"{x:1095,y:751,t:1511831532687};\\\", \\\"{x:1097,y:758,t:1511831532704};\\\", \\\"{x:1100,y:765,t:1511831532721};\\\", \\\"{x:1104,y:773,t:1511831532738};\\\", \\\"{x:1110,y:781,t:1511831532754};\\\", \\\"{x:1116,y:788,t:1511831532771};\\\", \\\"{x:1120,y:798,t:1511831532787};\\\", \\\"{x:1124,y:807,t:1511831532804};\\\", \\\"{x:1130,y:814,t:1511831532821};\\\", \\\"{x:1134,y:822,t:1511831532838};\\\", \\\"{x:1139,y:830,t:1511831532855};\\\", \\\"{x:1143,y:837,t:1511831532872};\\\", \\\"{x:1147,y:842,t:1511831532889};\\\", \\\"{x:1150,y:846,t:1511831532905};\\\", \\\"{x:1152,y:850,t:1511831532922};\\\", \\\"{x:1159,y:859,t:1511831532938};\\\", \\\"{x:1160,y:866,t:1511831532955};\\\", \\\"{x:1160,y:868,t:1511831532972};\\\", \\\"{x:1160,y:869,t:1511831533002};\\\", \\\"{x:1160,y:870,t:1511831533018};\\\", \\\"{x:1160,y:872,t:1511831533059};\\\", \\\"{x:1160,y:873,t:1511831533074};\\\", \\\"{x:1159,y:875,t:1511831533090};\\\", \\\"{x:1158,y:876,t:1511831533105};\\\", \\\"{x:1155,y:881,t:1511831533122};\\\", \\\"{x:1154,y:883,t:1511831533138};\\\", \\\"{x:1152,y:886,t:1511831533155};\\\", \\\"{x:1151,y:889,t:1511831533172};\\\", \\\"{x:1150,y:891,t:1511831533189};\\\", \\\"{x:1149,y:893,t:1511831533205};\\\", \\\"{x:1146,y:896,t:1511831533222};\\\", \\\"{x:1145,y:898,t:1511831533239};\\\", \\\"{x:1141,y:902,t:1511831533255};\\\", \\\"{x:1140,y:906,t:1511831533272};\\\", \\\"{x:1138,y:910,t:1511831533289};\\\", \\\"{x:1138,y:913,t:1511831533306};\\\", \\\"{x:1138,y:916,t:1511831533322};\\\", \\\"{x:1141,y:922,t:1511831533338};\\\", \\\"{x:1147,y:927,t:1511831533356};\\\", \\\"{x:1155,y:931,t:1511831533372};\\\", \\\"{x:1166,y:938,t:1511831533389};\\\", \\\"{x:1179,y:945,t:1511831533406};\\\", \\\"{x:1190,y:952,t:1511831533422};\\\", \\\"{x:1199,y:956,t:1511831533439};\\\", \\\"{x:1204,y:959,t:1511831533456};\\\", \\\"{x:1207,y:959,t:1511831533472};\\\", \\\"{x:1208,y:959,t:1511831533489};\\\", \\\"{x:1209,y:959,t:1511831533506};\\\", \\\"{x:1211,y:959,t:1511831533522};\\\", \\\"{x:1218,y:959,t:1511831533539};\\\", \\\"{x:1233,y:959,t:1511831533556};\\\", \\\"{x:1250,y:959,t:1511831533572};\\\", \\\"{x:1267,y:963,t:1511831533589};\\\", \\\"{x:1285,y:965,t:1511831533606};\\\", \\\"{x:1298,y:965,t:1511831533622};\\\", \\\"{x:1304,y:965,t:1511831533639};\\\", \\\"{x:1306,y:965,t:1511831533656};\\\", \\\"{x:1307,y:965,t:1511831533715};\\\", \\\"{x:1309,y:965,t:1511831533722};\\\", \\\"{x:1318,y:965,t:1511831533739};\\\", \\\"{x:1325,y:965,t:1511831533756};\\\", \\\"{x:1331,y:966,t:1511831533773};\\\", \\\"{x:1332,y:967,t:1511831533789};\\\", \\\"{x:1334,y:967,t:1511831533806};\\\", \\\"{x:1338,y:968,t:1511831533834};\\\", \\\"{x:1346,y:970,t:1511831533842};\\\", \\\"{x:1352,y:972,t:1511831533856};\\\", \\\"{x:1368,y:975,t:1511831533873};\\\", \\\"{x:1380,y:979,t:1511831533889};\\\", \\\"{x:1392,y:982,t:1511831533906};\\\", \\\"{x:1397,y:983,t:1511831533923};\\\", \\\"{x:1403,y:983,t:1511831533939};\\\", \\\"{x:1407,y:983,t:1511831533956};\\\", \\\"{x:1409,y:983,t:1511831533973};\\\", \\\"{x:1406,y:983,t:1511831534122};\\\", \\\"{x:1397,y:983,t:1511831534139};\\\", \\\"{x:1390,y:983,t:1511831534156};\\\", \\\"{x:1386,y:983,t:1511831534173};\\\", \\\"{x:1385,y:982,t:1511831534242};\\\", \\\"{x:1384,y:981,t:1511831534256};\\\", \\\"{x:1382,y:979,t:1511831534273};\\\", \\\"{x:1380,y:976,t:1511831534290};\\\", \\\"{x:1379,y:975,t:1511831534306};\\\", \\\"{x:1377,y:974,t:1511831534443};\\\", \\\"{x:1377,y:972,t:1511831534456};\\\", \\\"{x:1377,y:970,t:1511831534482};\\\", \\\"{x:1377,y:969,t:1511831534498};\\\", \\\"{x:1377,y:968,t:1511831534522};\\\", \\\"{x:1377,y:967,t:1511831534540};\\\", \\\"{x:1377,y:964,t:1511831534556};\\\", \\\"{x:1377,y:960,t:1511831534573};\\\", \\\"{x:1377,y:955,t:1511831534590};\\\", \\\"{x:1376,y:949,t:1511831534606};\\\", \\\"{x:1373,y:942,t:1511831534623};\\\", \\\"{x:1371,y:934,t:1511831534640};\\\", \\\"{x:1367,y:928,t:1511831534657};\\\", \\\"{x:1364,y:922,t:1511831534673};\\\", \\\"{x:1362,y:916,t:1511831534690};\\\", \\\"{x:1360,y:911,t:1511831534706};\\\", \\\"{x:1356,y:903,t:1511831534722};\\\", \\\"{x:1354,y:897,t:1511831534740};\\\", \\\"{x:1351,y:890,t:1511831534757};\\\", \\\"{x:1350,y:880,t:1511831534773};\\\", \\\"{x:1347,y:871,t:1511831534790};\\\", \\\"{x:1344,y:864,t:1511831534807};\\\", \\\"{x:1340,y:859,t:1511831534823};\\\", \\\"{x:1339,y:856,t:1511831534840};\\\", \\\"{x:1336,y:851,t:1511831534857};\\\", \\\"{x:1335,y:850,t:1511831534873};\\\", \\\"{x:1332,y:846,t:1511831534890};\\\", \\\"{x:1326,y:834,t:1511831534906};\\\", \\\"{x:1319,y:823,t:1511831534923};\\\", \\\"{x:1306,y:808,t:1511831534940};\\\", \\\"{x:1289,y:794,t:1511831534957};\\\", \\\"{x:1282,y:786,t:1511831534973};\\\", \\\"{x:1277,y:783,t:1511831534990};\\\", \\\"{x:1274,y:779,t:1511831535007};\\\", \\\"{x:1273,y:778,t:1511831535023};\\\", \\\"{x:1272,y:776,t:1511831535040};\\\", \\\"{x:1269,y:771,t:1511831535057};\\\", \\\"{x:1269,y:769,t:1511831535074};\\\", \\\"{x:1269,y:767,t:1511831535090};\\\", \\\"{x:1267,y:762,t:1511831535107};\\\", \\\"{x:1266,y:760,t:1511831535124};\\\", \\\"{x:1266,y:759,t:1511831535140};\\\", \\\"{x:1265,y:757,t:1511831535170};\\\", \\\"{x:1265,y:756,t:1511831535186};\\\", \\\"{x:1265,y:753,t:1511831535202};\\\", \\\"{x:1263,y:749,t:1511831535210};\\\", \\\"{x:1263,y:747,t:1511831535224};\\\", \\\"{x:1260,y:733,t:1511831535240};\\\", \\\"{x:1255,y:713,t:1511831535257};\\\", \\\"{x:1245,y:687,t:1511831535274};\\\", \\\"{x:1239,y:671,t:1511831535290};\\\", \\\"{x:1236,y:657,t:1511831535307};\\\", \\\"{x:1234,y:643,t:1511831535324};\\\", \\\"{x:1232,y:630,t:1511831535340};\\\", \\\"{x:1231,y:620,t:1511831535357};\\\", \\\"{x:1229,y:610,t:1511831535374};\\\", \\\"{x:1224,y:599,t:1511831535390};\\\", \\\"{x:1220,y:592,t:1511831535407};\\\", \\\"{x:1212,y:584,t:1511831535424};\\\", \\\"{x:1203,y:577,t:1511831535440};\\\", \\\"{x:1194,y:571,t:1511831535457};\\\", \\\"{x:1185,y:564,t:1511831535474};\\\", \\\"{x:1182,y:562,t:1511831535498};\\\", \\\"{x:1181,y:561,t:1511831535523};\\\", \\\"{x:1180,y:561,t:1511831535540};\\\", \\\"{x:1174,y:558,t:1511831535556};\\\", \\\"{x:1170,y:556,t:1511831535575};\\\", \\\"{x:1167,y:555,t:1511831535590};\\\", \\\"{x:1170,y:555,t:1511831535803};\\\", \\\"{x:1177,y:559,t:1511831535814};\\\", \\\"{x:1179,y:561,t:1511831535823};\\\", \\\"{x:1183,y:565,t:1511831535841};\\\", \\\"{x:1184,y:568,t:1511831535857};\\\", \\\"{x:1183,y:568,t:1511831536010};\\\", \\\"{x:1181,y:568,t:1511831536023};\\\", \\\"{x:1178,y:567,t:1511831536045};\\\", \\\"{x:1177,y:566,t:1511831536057};\\\", \\\"{x:1176,y:566,t:1511831536073};\\\", \\\"{x:1176,y:565,t:1511831536090};\\\", \\\"{x:1175,y:565,t:1511831541627};\\\", \\\"{x:1173,y:565,t:1511831541635};\\\", \\\"{x:1171,y:565,t:1511831541645};\\\", \\\"{x:1156,y:568,t:1511831541679};\\\", \\\"{x:1147,y:569,t:1511831541695};\\\", \\\"{x:1128,y:571,t:1511831541712};\\\", \\\"{x:1095,y:575,t:1511831541729};\\\", \\\"{x:1025,y:577,t:1511831541745};\\\", \\\"{x:858,y:578,t:1511831541762};\\\", \\\"{x:715,y:578,t:1511831541779};\\\", \\\"{x:576,y:578,t:1511831541795};\\\", \\\"{x:476,y:578,t:1511831541812};\\\", \\\"{x:401,y:578,t:1511831541829};\\\", \\\"{x:362,y:578,t:1511831541846};\\\", \\\"{x:343,y:578,t:1511831541862};\\\", \\\"{x:342,y:578,t:1511831541879};\\\", \\\"{x:339,y:580,t:1511831541955};\\\", \\\"{x:338,y:581,t:1511831541962};\\\", \\\"{x:336,y:581,t:1511831541979};\\\", \\\"{x:331,y:584,t:1511831541996};\\\", \\\"{x:328,y:586,t:1511831542012};\\\", \\\"{x:325,y:589,t:1511831542029};\\\", \\\"{x:323,y:589,t:1511831542046};\\\", \\\"{x:322,y:591,t:1511831542062};\\\", \\\"{x:321,y:592,t:1511831542080};\\\", \\\"{x:320,y:594,t:1511831542096};\\\", \\\"{x:317,y:599,t:1511831542113};\\\", \\\"{x:315,y:603,t:1511831542129};\\\", \\\"{x:312,y:605,t:1511831542146};\\\", \\\"{x:312,y:606,t:1511831542290};\\\", \\\"{x:322,y:607,t:1511831542546};\\\", \\\"{x:403,y:607,t:1511831542563};\\\", \\\"{x:528,y:607,t:1511831542580};\\\", \\\"{x:673,y:613,t:1511831542596};\\\", \\\"{x:794,y:628,t:1511831542613};\\\", \\\"{x:914,y:646,t:1511831542629};\\\", \\\"{x:1022,y:662,t:1511831542646};\\\", \\\"{x:1102,y:681,t:1511831542663};\\\", \\\"{x:1151,y:700,t:1511831542679};\\\", \\\"{x:1175,y:715,t:1511831542696};\\\", \\\"{x:1196,y:733,t:1511831542713};\\\", \\\"{x:1224,y:764,t:1511831542729};\\\", \\\"{x:1259,y:810,t:1511831542746};\\\", \\\"{x:1273,y:831,t:1511831542763};\\\", \\\"{x:1298,y:853,t:1511831542780};\\\", \\\"{x:1317,y:869,t:1511831542797};\\\", \\\"{x:1341,y:884,t:1511831542814};\\\", \\\"{x:1364,y:899,t:1511831542830};\\\", \\\"{x:1378,y:910,t:1511831542846};\\\", \\\"{x:1383,y:913,t:1511831542864};\\\", \\\"{x:1385,y:915,t:1511831542880};\\\", \\\"{x:1387,y:917,t:1511831542896};\\\", \\\"{x:1388,y:918,t:1511831542913};\\\", \\\"{x:1390,y:922,t:1511831542930};\\\", \\\"{x:1391,y:924,t:1511831542946};\\\", \\\"{x:1391,y:925,t:1511831542971};\\\", \\\"{x:1391,y:926,t:1511831542987};\\\", \\\"{x:1391,y:928,t:1511831542997};\\\", \\\"{x:1390,y:929,t:1511831543014};\\\", \\\"{x:1389,y:929,t:1511831543030};\\\", \\\"{x:1387,y:930,t:1511831543046};\\\", \\\"{x:1387,y:931,t:1511831543063};\\\", \\\"{x:1386,y:932,t:1511831543080};\\\", \\\"{x:1384,y:934,t:1511831543096};\\\", \\\"{x:1384,y:935,t:1511831543113};\\\", \\\"{x:1384,y:943,t:1511831543131};\\\", \\\"{x:1384,y:946,t:1511831543147};\\\", \\\"{x:1384,y:947,t:1511831543179};\\\", \\\"{x:1384,y:949,t:1511831543235};\\\", \\\"{x:1384,y:951,t:1511831543247};\\\", \\\"{x:1381,y:956,t:1511831543264};\\\", \\\"{x:1380,y:961,t:1511831543281};\\\", \\\"{x:1380,y:964,t:1511831543297};\\\", \\\"{x:1379,y:965,t:1511831543315};\\\", \\\"{x:1380,y:962,t:1511831543515};\\\", \\\"{x:1387,y:951,t:1511831543530};\\\", \\\"{x:1396,y:938,t:1511831543547};\\\", \\\"{x:1406,y:924,t:1511831543564};\\\", \\\"{x:1414,y:910,t:1511831543581};\\\", \\\"{x:1420,y:897,t:1511831543597};\\\", \\\"{x:1424,y:890,t:1511831543614};\\\", \\\"{x:1429,y:884,t:1511831543631};\\\", \\\"{x:1432,y:878,t:1511831543646};\\\", \\\"{x:1435,y:873,t:1511831543664};\\\", \\\"{x:1437,y:867,t:1511831543680};\\\", \\\"{x:1439,y:861,t:1511831543697};\\\", \\\"{x:1441,y:856,t:1511831543714};\\\", \\\"{x:1443,y:852,t:1511831543730};\\\", \\\"{x:1444,y:850,t:1511831543747};\\\", \\\"{x:1444,y:846,t:1511831543764};\\\", \\\"{x:1444,y:843,t:1511831543781};\\\", \\\"{x:1444,y:840,t:1511831543797};\\\", \\\"{x:1444,y:837,t:1511831543814};\\\", \\\"{x:1443,y:831,t:1511831543838};\\\", \\\"{x:1443,y:827,t:1511831543863};\\\", \\\"{x:1443,y:826,t:1511831543880};\\\", \\\"{x:1442,y:825,t:1511831544331};\\\", \\\"{x:1436,y:830,t:1511831544352};\\\", \\\"{x:1413,y:853,t:1511831544381};\\\", \\\"{x:1400,y:867,t:1511831544397};\\\", \\\"{x:1390,y:878,t:1511831544414};\\\", \\\"{x:1383,y:890,t:1511831544431};\\\", \\\"{x:1378,y:901,t:1511831544448};\\\", \\\"{x:1373,y:910,t:1511831544464};\\\", \\\"{x:1371,y:915,t:1511831544481};\\\", \\\"{x:1369,y:921,t:1511831544498};\\\", \\\"{x:1368,y:925,t:1511831544514};\\\", \\\"{x:1368,y:933,t:1511831544531};\\\", \\\"{x:1368,y:938,t:1511831544548};\\\", \\\"{x:1365,y:944,t:1511831544564};\\\", \\\"{x:1365,y:946,t:1511831544581};\\\", \\\"{x:1365,y:948,t:1511831544598};\\\", \\\"{x:1365,y:946,t:1511831544667};\\\", \\\"{x:1365,y:945,t:1511831544682};\\\", \\\"{x:1359,y:933,t:1511831544698};\\\", \\\"{x:1355,y:929,t:1511831544715};\\\", \\\"{x:1351,y:923,t:1511831544732};\\\", \\\"{x:1350,y:918,t:1511831544749};\\\", \\\"{x:1348,y:913,t:1511831544765};\\\", \\\"{x:1346,y:905,t:1511831544782};\\\", \\\"{x:1343,y:899,t:1511831544799};\\\", \\\"{x:1339,y:890,t:1511831544815};\\\", \\\"{x:1336,y:878,t:1511831544832};\\\", \\\"{x:1333,y:868,t:1511831544849};\\\", \\\"{x:1329,y:856,t:1511831544865};\\\", \\\"{x:1326,y:847,t:1511831544882};\\\", \\\"{x:1320,y:834,t:1511831544898};\\\", \\\"{x:1316,y:828,t:1511831544915};\\\", \\\"{x:1312,y:823,t:1511831544932};\\\", \\\"{x:1311,y:820,t:1511831544949};\\\", \\\"{x:1308,y:815,t:1511831544966};\\\", \\\"{x:1307,y:812,t:1511831544982};\\\", \\\"{x:1303,y:808,t:1511831544999};\\\", \\\"{x:1300,y:804,t:1511831545016};\\\", \\\"{x:1297,y:800,t:1511831545032};\\\", \\\"{x:1296,y:799,t:1511831545049};\\\", \\\"{x:1295,y:797,t:1511831545066};\\\", \\\"{x:1294,y:795,t:1511831545082};\\\", \\\"{x:1293,y:793,t:1511831545098};\\\", \\\"{x:1291,y:789,t:1511831545116};\\\", \\\"{x:1289,y:786,t:1511831545132};\\\", \\\"{x:1286,y:781,t:1511831545149};\\\", \\\"{x:1285,y:776,t:1511831545166};\\\", \\\"{x:1282,y:773,t:1511831545182};\\\", \\\"{x:1280,y:769,t:1511831545199};\\\", \\\"{x:1277,y:766,t:1511831545216};\\\", \\\"{x:1273,y:761,t:1511831545232};\\\", \\\"{x:1270,y:757,t:1511831545249};\\\", \\\"{x:1268,y:754,t:1511831545266};\\\", \\\"{x:1265,y:749,t:1511831545282};\\\", \\\"{x:1263,y:745,t:1511831545298};\\\", \\\"{x:1261,y:741,t:1511831545315};\\\", \\\"{x:1260,y:741,t:1511831545332};\\\", \\\"{x:1260,y:740,t:1511831545348};\\\", \\\"{x:1260,y:739,t:1511831545418};\\\", \\\"{x:1259,y:738,t:1511831545432};\\\", \\\"{x:1257,y:735,t:1511831545448};\\\", \\\"{x:1255,y:730,t:1511831545465};\\\", \\\"{x:1250,y:721,t:1511831545482};\\\", \\\"{x:1247,y:717,t:1511831545498};\\\", \\\"{x:1245,y:713,t:1511831545515};\\\", \\\"{x:1245,y:712,t:1511831545532};\\\", \\\"{x:1242,y:708,t:1511831545548};\\\", \\\"{x:1240,y:703,t:1511831545566};\\\", \\\"{x:1234,y:695,t:1511831545583};\\\", \\\"{x:1227,y:685,t:1511831545599};\\\", \\\"{x:1221,y:672,t:1511831545615};\\\", \\\"{x:1214,y:661,t:1511831545633};\\\", \\\"{x:1207,y:650,t:1511831545649};\\\", \\\"{x:1201,y:639,t:1511831545666};\\\", \\\"{x:1193,y:625,t:1511831545682};\\\", \\\"{x:1190,y:620,t:1511831545699};\\\", \\\"{x:1189,y:617,t:1511831545715};\\\", \\\"{x:1186,y:614,t:1511831545732};\\\", \\\"{x:1184,y:611,t:1511831545749};\\\", \\\"{x:1183,y:609,t:1511831545765};\\\", \\\"{x:1182,y:605,t:1511831545782};\\\", \\\"{x:1178,y:599,t:1511831545799};\\\", \\\"{x:1177,y:595,t:1511831545815};\\\", \\\"{x:1174,y:591,t:1511831545832};\\\", \\\"{x:1172,y:584,t:1511831545849};\\\", \\\"{x:1170,y:582,t:1511831545865};\\\", \\\"{x:1170,y:579,t:1511831545883};\\\", \\\"{x:1168,y:576,t:1511831545900};\\\", \\\"{x:1168,y:574,t:1511831545916};\\\", \\\"{x:1167,y:570,t:1511831545933};\\\", \\\"{x:1167,y:567,t:1511831545949};\\\", \\\"{x:1166,y:562,t:1511831545965};\\\", \\\"{x:1166,y:559,t:1511831545983};\\\", \\\"{x:1166,y:558,t:1511831546000};\\\", \\\"{x:1166,y:557,t:1511831546015};\\\", \\\"{x:1167,y:557,t:1511831546251};\\\", \\\"{x:1170,y:559,t:1511831546266};\\\", \\\"{x:1172,y:559,t:1511831546288};\\\", \\\"{x:1172,y:560,t:1511831546316};\\\", \\\"{x:1173,y:562,t:1511831546402};\\\", \\\"{x:1173,y:565,t:1511831546415};\\\", \\\"{x:1161,y:573,t:1511831546434};\\\", \\\"{x:1135,y:584,t:1511831546449};\\\", \\\"{x:1076,y:592,t:1511831546465};\\\", \\\"{x:1046,y:597,t:1511831546482};\\\", \\\"{x:1032,y:599,t:1511831546499};\\\", \\\"{x:1027,y:601,t:1511831546516};\\\", \\\"{x:1026,y:601,t:1511831546538};\\\", \\\"{x:1025,y:601,t:1511831546549};\\\", \\\"{x:1020,y:604,t:1511831546566};\\\", \\\"{x:1007,y:611,t:1511831546583};\\\", \\\"{x:984,y:617,t:1511831546600};\\\", \\\"{x:954,y:626,t:1511831546616};\\\", \\\"{x:906,y:633,t:1511831546633};\\\", \\\"{x:836,y:644,t:1511831546649};\\\", \\\"{x:748,y:655,t:1511831546666};\\\", \\\"{x:717,y:665,t:1511831546684};\\\", \\\"{x:704,y:673,t:1511831546699};\\\", \\\"{x:701,y:675,t:1511831546716};\\\", \\\"{x:700,y:676,t:1511831546733};\\\", \\\"{x:698,y:677,t:1511831546811};\\\", \\\"{x:694,y:679,t:1511831546818};\\\", \\\"{x:689,y:681,t:1511831546833};\\\", \\\"{x:685,y:684,t:1511831546849};\\\", \\\"{x:671,y:691,t:1511831546866};\\\", \\\"{x:660,y:697,t:1511831546883};\\\", \\\"{x:646,y:702,t:1511831546899};\\\", \\\"{x:636,y:707,t:1511831546916};\\\", \\\"{x:629,y:712,t:1511831546934};\\\", \\\"{x:620,y:718,t:1511831546950};\\\", \\\"{x:611,y:725,t:1511831546966};\\\", \\\"{x:604,y:730,t:1511831546983};\\\", \\\"{x:599,y:734,t:1511831547001};\\\", \\\"{x:596,y:738,t:1511831547016};\\\", \\\"{x:590,y:746,t:1511831547033};\\\", \\\"{x:586,y:754,t:1511831547050};\\\", \\\"{x:579,y:760,t:1511831547066};\\\", \\\"{x:571,y:764,t:1511831547083};\\\", \\\"{x:562,y:768,t:1511831547100};\\\", \\\"{x:552,y:771,t:1511831547116};\\\", \\\"{x:541,y:771,t:1511831547133};\\\", \\\"{x:526,y:768,t:1511831547150};\\\", \\\"{x:506,y:757,t:1511831547166};\\\", \\\"{x:483,y:743,t:1511831547183};\\\", \\\"{x:453,y:729,t:1511831547201};\\\", \\\"{x:434,y:722,t:1511831547217};\\\", \\\"{x:429,y:717,t:1511831547233};\\\", \\\"{x:424,y:714,t:1511831547249};\\\", \\\"{x:420,y:708,t:1511831547266};\\\", \\\"{x:417,y:706,t:1511831547283};\\\", \\\"{x:414,y:703,t:1511831547299};\\\", \\\"{x:411,y:702,t:1511831547316};\\\", \\\"{x:411,y:701,t:1511831548002};\\\", \\\"{x:415,y:700,t:1511831548017};\\\", \\\"{x:474,y:681,t:1511831548034};\\\", \\\"{x:532,y:664,t:1511831548051};\\\", \\\"{x:607,y:644,t:1511831548067};\\\", \\\"{x:667,y:620,t:1511831548084};\\\", \\\"{x:720,y:597,t:1511831548101};\\\", \\\"{x:745,y:588,t:1511831548117};\\\", \\\"{x:756,y:585,t:1511831548134};\\\", \\\"{x:759,y:584,t:1511831548151};\\\" ] }, { \\\"rt\\\": 15666, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 357737, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -I -A -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:760,y:583,t:1511831548962};\\\", \\\"{x:760,y:582,t:1511831548969};\\\", \\\"{x:750,y:582,t:1511831548984};\\\", \\\"{x:679,y:600,t:1511831549001};\\\", \\\"{x:560,y:631,t:1511831549036};\\\", \\\"{x:543,y:633,t:1511831549051};\\\", \\\"{x:536,y:635,t:1511831549068};\\\", \\\"{x:534,y:636,t:1511831549084};\\\", \\\"{x:532,y:637,t:1511831549101};\\\", \\\"{x:531,y:637,t:1511831549145};\\\", \\\"{x:530,y:639,t:1511831549153};\\\", \\\"{x:526,y:642,t:1511831549168};\\\", \\\"{x:519,y:648,t:1511831549185};\\\", \\\"{x:498,y:667,t:1511831549218};\\\", \\\"{x:487,y:682,t:1511831549235};\\\", \\\"{x:476,y:699,t:1511831549251};\\\", \\\"{x:467,y:718,t:1511831549268};\\\", \\\"{x:457,y:734,t:1511831549285};\\\", \\\"{x:452,y:749,t:1511831549301};\\\", \\\"{x:451,y:763,t:1511831549318};\\\", \\\"{x:449,y:777,t:1511831549335};\\\", \\\"{x:449,y:795,t:1511831549351};\\\", \\\"{x:449,y:810,t:1511831549368};\\\", \\\"{x:449,y:822,t:1511831549385};\\\", \\\"{x:449,y:832,t:1511831549401};\\\", \\\"{x:449,y:837,t:1511831549418};\\\", \\\"{x:449,y:842,t:1511831549435};\\\", \\\"{x:446,y:849,t:1511831549451};\\\", \\\"{x:444,y:855,t:1511831549468};\\\", \\\"{x:441,y:859,t:1511831549485};\\\", \\\"{x:439,y:862,t:1511831549501};\\\", \\\"{x:437,y:864,t:1511831549518};\\\", \\\"{x:435,y:865,t:1511831549535};\\\", \\\"{x:434,y:866,t:1511831549552};\\\", \\\"{x:430,y:867,t:1511831549568};\\\", \\\"{x:425,y:867,t:1511831549585};\\\", \\\"{x:417,y:867,t:1511831549601};\\\", \\\"{x:414,y:867,t:1511831549618};\\\", \\\"{x:413,y:867,t:1511831549635};\\\", \\\"{x:420,y:863,t:1511831552698};\\\", \\\"{x:477,y:846,t:1511831552706};\\\", \\\"{x:646,y:815,t:1511831552722};\\\", \\\"{x:825,y:799,t:1511831552738};\\\", \\\"{x:1019,y:790,t:1511831552755};\\\", \\\"{x:1184,y:782,t:1511831552772};\\\", \\\"{x:1281,y:768,t:1511831552788};\\\", \\\"{x:1316,y:757,t:1511831552805};\\\", \\\"{x:1329,y:751,t:1511831552822};\\\", \\\"{x:1330,y:749,t:1511831552838};\\\", \\\"{x:1330,y:744,t:1511831552855};\\\", \\\"{x:1329,y:732,t:1511831552872};\\\", \\\"{x:1309,y:716,t:1511831552888};\\\", \\\"{x:1296,y:707,t:1511831552905};\\\", \\\"{x:1296,y:699,t:1511831552922};\\\", \\\"{x:1296,y:691,t:1511831552938};\\\", \\\"{x:1296,y:678,t:1511831552955};\\\", \\\"{x:1294,y:668,t:1511831552972};\\\", \\\"{x:1290,y:652,t:1511831552988};\\\", \\\"{x:1285,y:642,t:1511831553005};\\\", \\\"{x:1274,y:627,t:1511831553032};\\\", \\\"{x:1204,y:571,t:1511831553056};\\\", \\\"{x:1150,y:541,t:1511831553071};\\\", \\\"{x:1110,y:520,t:1511831553088};\\\", \\\"{x:1094,y:511,t:1511831553104};\\\", \\\"{x:1088,y:503,t:1511831553121};\\\", \\\"{x:1087,y:499,t:1511831553137};\\\", \\\"{x:1080,y:490,t:1511831553154};\\\", \\\"{x:1069,y:483,t:1511831553171};\\\", \\\"{x:1048,y:474,t:1511831553188};\\\", \\\"{x:1036,y:468,t:1511831553204};\\\", \\\"{x:1033,y:466,t:1511831553221};\\\", \\\"{x:1033,y:464,t:1511831553241};\\\", \\\"{x:1034,y:464,t:1511831553254};\\\", \\\"{x:1037,y:466,t:1511831553330};\\\", \\\"{x:1038,y:470,t:1511831553338};\\\", \\\"{x:1042,y:483,t:1511831553355};\\\", \\\"{x:1044,y:492,t:1511831553372};\\\", \\\"{x:1046,y:498,t:1511831553388};\\\", \\\"{x:1047,y:502,t:1511831553405};\\\", \\\"{x:1048,y:504,t:1511831553421};\\\", \\\"{x:1050,y:506,t:1511831553438};\\\", \\\"{x:1053,y:506,t:1511831553498};\\\", \\\"{x:1057,y:506,t:1511831553506};\\\", \\\"{x:1061,y:506,t:1511831553522};\\\", \\\"{x:1065,y:505,t:1511831553538};\\\", \\\"{x:1068,y:503,t:1511831553555};\\\", \\\"{x:1069,y:502,t:1511831553571};\\\", \\\"{x:1072,y:500,t:1511831553596};\\\", \\\"{x:1077,y:497,t:1511831553621};\\\", \\\"{x:1079,y:496,t:1511831553638};\\\", \\\"{x:1077,y:496,t:1511831554066};\\\", \\\"{x:1076,y:496,t:1511831554074};\\\", \\\"{x:1076,y:502,t:1511831561123};\\\", \\\"{x:1077,y:511,t:1511831561141};\\\", \\\"{x:1087,y:553,t:1511831561168};\\\", \\\"{x:1088,y:578,t:1511831561178};\\\", \\\"{x:1088,y:600,t:1511831561195};\\\", \\\"{x:1088,y:622,t:1511831561212};\\\", \\\"{x:1086,y:643,t:1511831561228};\\\", \\\"{x:1082,y:660,t:1511831561245};\\\", \\\"{x:1080,y:674,t:1511831561262};\\\", \\\"{x:1076,y:687,t:1511831561278};\\\", \\\"{x:1075,y:701,t:1511831561295};\\\", \\\"{x:1074,y:715,t:1511831561312};\\\", \\\"{x:1074,y:731,t:1511831561328};\\\", \\\"{x:1074,y:745,t:1511831561345};\\\", \\\"{x:1072,y:760,t:1511831561366};\\\", \\\"{x:1072,y:764,t:1511831561378};\\\", \\\"{x:1072,y:766,t:1511831561395};\\\", \\\"{x:1072,y:767,t:1511831561412};\\\", \\\"{x:1071,y:768,t:1511831561492};\\\", \\\"{x:1071,y:769,t:1511831561512};\\\", \\\"{x:1071,y:771,t:1511831561529};\\\", \\\"{x:1071,y:770,t:1511831561771};\\\", \\\"{x:1071,y:769,t:1511831561787};\\\", \\\"{x:1071,y:768,t:1511831561939};\\\", \\\"{x:1071,y:767,t:1511831561946};\\\", \\\"{x:1071,y:766,t:1511831561970};\\\", \\\"{x:1071,y:765,t:1511831562058};\\\", \\\"{x:1071,y:764,t:1511831562066};\\\", \\\"{x:1071,y:763,t:1511831562081};\\\", \\\"{x:1071,y:762,t:1511831562095};\\\", \\\"{x:1071,y:761,t:1511831562112};\\\", \\\"{x:1072,y:760,t:1511831562129};\\\", \\\"{x:1069,y:760,t:1511831562803};\\\", \\\"{x:1054,y:760,t:1511831562812};\\\", \\\"{x:983,y:760,t:1511831562829};\\\", \\\"{x:867,y:758,t:1511831562846};\\\", \\\"{x:695,y:733,t:1511831562863};\\\", \\\"{x:522,y:688,t:1511831562880};\\\", \\\"{x:365,y:649,t:1511831562896};\\\", \\\"{x:259,y:616,t:1511831562913};\\\", \\\"{x:191,y:585,t:1511831562930};\\\", \\\"{x:173,y:577,t:1511831562946};\\\", \\\"{x:166,y:574,t:1511831562963};\\\", \\\"{x:163,y:572,t:1511831562980};\\\", \\\"{x:161,y:571,t:1511831562996};\\\", \\\"{x:157,y:567,t:1511831563013};\\\", \\\"{x:157,y:563,t:1511831563030};\\\", \\\"{x:155,y:557,t:1511831563047};\\\", \\\"{x:153,y:549,t:1511831563063};\\\", \\\"{x:148,y:540,t:1511831563080};\\\", \\\"{x:145,y:534,t:1511831563097};\\\", \\\"{x:143,y:532,t:1511831563113};\\\", \\\"{x:144,y:531,t:1511831563147};\\\", \\\"{x:154,y:535,t:1511831563163};\\\", \\\"{x:176,y:548,t:1511831563181};\\\", \\\"{x:223,y:571,t:1511831563198};\\\", \\\"{x:256,y:584,t:1511831563214};\\\", \\\"{x:297,y:594,t:1511831563231};\\\", \\\"{x:323,y:601,t:1511831563247};\\\", \\\"{x:336,y:605,t:1511831563263};\\\", \\\"{x:337,y:606,t:1511831563281};\\\", \\\"{x:338,y:607,t:1511831563435};\\\", \\\"{x:338,y:608,t:1511831563450};\\\", \\\"{x:336,y:608,t:1511831563466};\\\", \\\"{x:335,y:607,t:1511831563482};\\\", \\\"{x:334,y:607,t:1511831563497};\\\", \\\"{x:333,y:604,t:1511831563514};\\\", \\\"{x:330,y:600,t:1511831563530};\\\", \\\"{x:327,y:595,t:1511831563548};\\\", \\\"{x:324,y:590,t:1511831563564};\\\", \\\"{x:320,y:585,t:1511831563580};\\\", \\\"{x:319,y:584,t:1511831563597};\\\", \\\"{x:317,y:584,t:1511831563851};\\\", \\\"{x:315,y:585,t:1511831563864};\\\", \\\"{x:314,y:585,t:1511831563881};\\\", \\\"{x:313,y:585,t:1511831563897};\\\", \\\"{x:312,y:586,t:1511831563913};\\\", \\\"{x:311,y:586,t:1511831563945};\\\", \\\"{x:311,y:587,t:1511831563954};\\\", \\\"{x:311,y:592,t:1511831564162};\\\", \\\"{x:312,y:601,t:1511831564170};\\\", \\\"{x:314,y:609,t:1511831564181};\\\", \\\"{x:322,y:630,t:1511831564197};\\\", \\\"{x:332,y:649,t:1511831564214};\\\", \\\"{x:340,y:664,t:1511831564231};\\\", \\\"{x:347,y:684,t:1511831564247};\\\", \\\"{x:352,y:699,t:1511831564264};\\\", \\\"{x:361,y:716,t:1511831564281};\\\", \\\"{x:370,y:728,t:1511831564297};\\\", \\\"{x:379,y:736,t:1511831564314};\\\", \\\"{x:380,y:737,t:1511831564331};\\\", \\\"{x:381,y:738,t:1511831564347};\\\", \\\"{x:381,y:739,t:1511831564370};\\\", \\\"{x:383,y:738,t:1511831564522};\\\", \\\"{x:383,y:736,t:1511831564538};\\\", \\\"{x:383,y:735,t:1511831564554};\\\", \\\"{x:383,y:733,t:1511831564570};\\\", \\\"{x:383,y:733,t:1511831564589};\\\", \\\"{x:383,y:732,t:1511831564598};\\\", \\\"{x:383,y:730,t:1511831564633};\\\", \\\"{x:383,y:729,t:1511831564657};\\\", \\\"{x:383,y:727,t:1511831564673};\\\", \\\"{x:383,y:726,t:1511831564705};\\\", \\\"{x:385,y:725,t:1511831564930};\\\", \\\"{x:388,y:723,t:1511831564938};\\\", \\\"{x:396,y:720,t:1511831564948};\\\", \\\"{x:420,y:710,t:1511831564965};\\\", \\\"{x:443,y:699,t:1511831564981};\\\", \\\"{x:458,y:693,t:1511831564998};\\\", \\\"{x:467,y:689,t:1511831565015};\\\", \\\"{x:471,y:688,t:1511831565031};\\\", \\\"{x:475,y:685,t:1511831565048};\\\", \\\"{x:484,y:683,t:1511831565065};\\\", \\\"{x:495,y:681,t:1511831565081};\\\", \\\"{x:521,y:671,t:1511831565098};\\\", \\\"{x:538,y:665,t:1511831565115};\\\", \\\"{x:554,y:657,t:1511831565132};\\\", \\\"{x:568,y:648,t:1511831565148};\\\", \\\"{x:573,y:642,t:1511831565165};\\\", \\\"{x:573,y:640,t:1511831565182};\\\", \\\"{x:574,y:638,t:1511831565198};\\\", \\\"{x:573,y:635,t:1511831565242};\\\", \\\"{x:572,y:633,t:1511831565250};\\\", \\\"{x:570,y:631,t:1511831565265};\\\", \\\"{x:552,y:617,t:1511831565282};\\\", \\\"{x:537,y:607,t:1511831565298};\\\", \\\"{x:529,y:602,t:1511831565315};\\\", \\\"{x:526,y:600,t:1511831565332};\\\", \\\"{x:525,y:600,t:1511831565370};\\\" ] }, { \\\"rt\\\": 7203, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 366219, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:599,t:1511831566786};\\\", \\\"{x:528,y:598,t:1511831566802};\\\", \\\"{x:530,y:597,t:1511831566816};\\\", \\\"{x:530,y:596,t:1511831566833};\\\", \\\"{x:531,y:596,t:1511831567058};\\\", \\\"{x:528,y:600,t:1511831567074};\\\", \\\"{x:523,y:603,t:1511831567091};\\\", \\\"{x:519,y:606,t:1511831567108};\\\", \\\"{x:515,y:610,t:1511831567124};\\\", \\\"{x:514,y:611,t:1511831567140};\\\", \\\"{x:514,y:614,t:1511831567157};\\\", \\\"{x:514,y:629,t:1511831567175};\\\", \\\"{x:518,y:647,t:1511831567191};\\\", \\\"{x:536,y:665,t:1511831567207};\\\", \\\"{x:568,y:685,t:1511831567224};\\\", \\\"{x:678,y:714,t:1511831567240};\\\", \\\"{x:758,y:732,t:1511831567257};\\\", \\\"{x:828,y:755,t:1511831567274};\\\", \\\"{x:903,y:775,t:1511831567291};\\\", \\\"{x:979,y:792,t:1511831567307};\\\", \\\"{x:1035,y:806,t:1511831567324};\\\", \\\"{x:1055,y:814,t:1511831567341};\\\", \\\"{x:1064,y:821,t:1511831567357};\\\", \\\"{x:1068,y:824,t:1511831567374};\\\", \\\"{x:1069,y:825,t:1511831567391};\\\", \\\"{x:1069,y:826,t:1511831567425};\\\", \\\"{x:1069,y:827,t:1511831567441};\\\", \\\"{x:1069,y:830,t:1511831567457};\\\", \\\"{x:1069,y:833,t:1511831567474};\\\", \\\"{x:1069,y:835,t:1511831567491};\\\", \\\"{x:1069,y:837,t:1511831567508};\\\", \\\"{x:1068,y:839,t:1511831567524};\\\", \\\"{x:1065,y:839,t:1511831567542};\\\", \\\"{x:1055,y:839,t:1511831567557};\\\", \\\"{x:1044,y:839,t:1511831567575};\\\", \\\"{x:1032,y:839,t:1511831567592};\\\", \\\"{x:1020,y:838,t:1511831567608};\\\", \\\"{x:1017,y:838,t:1511831567624};\\\", \\\"{x:1016,y:838,t:1511831567714};\\\", \\\"{x:1016,y:837,t:1511831567725};\\\", \\\"{x:1016,y:836,t:1511831567742};\\\", \\\"{x:1016,y:834,t:1511831567758};\\\", \\\"{x:1016,y:831,t:1511831567774};\\\", \\\"{x:1017,y:829,t:1511831567794};\\\", \\\"{x:1019,y:827,t:1511831567808};\\\", \\\"{x:1020,y:825,t:1511831567856};\\\", \\\"{x:1021,y:825,t:1511831567913};\\\", \\\"{x:1022,y:825,t:1511831567928};\\\", \\\"{x:1023,y:825,t:1511831567941};\\\", \\\"{x:1024,y:825,t:1511831567958};\\\", \\\"{x:1025,y:825,t:1511831567977};\\\", \\\"{x:1026,y:825,t:1511831568001};\\\", \\\"{x:1027,y:826,t:1511831568025};\\\", \\\"{x:1027,y:827,t:1511831568065};\\\", \\\"{x:1027,y:828,t:1511831568081};\\\", \\\"{x:1027,y:829,t:1511831568097};\\\", \\\"{x:1027,y:830,t:1511831568201};\\\", \\\"{x:1027,y:831,t:1511831568233};\\\", \\\"{x:1027,y:832,t:1511831568249};\\\", \\\"{x:1026,y:832,t:1511831568258};\\\", \\\"{x:1025,y:832,t:1511831568281};\\\", \\\"{x:1024,y:832,t:1511831568369};\\\", \\\"{x:1023,y:832,t:1511831568393};\\\", \\\"{x:1019,y:832,t:1511831568481};\\\", \\\"{x:1016,y:832,t:1511831568493};\\\", \\\"{x:1011,y:828,t:1511831568509};\\\", \\\"{x:1005,y:823,t:1511831568526};\\\", \\\"{x:1000,y:817,t:1511831568542};\\\", \\\"{x:997,y:809,t:1511831568559};\\\", \\\"{x:993,y:801,t:1511831568576};\\\", \\\"{x:989,y:788,t:1511831568592};\\\", \\\"{x:986,y:773,t:1511831568609};\\\", \\\"{x:977,y:756,t:1511831568625};\\\", \\\"{x:972,y:746,t:1511831568643};\\\", \\\"{x:964,y:733,t:1511831568659};\\\", \\\"{x:951,y:715,t:1511831568676};\\\", \\\"{x:939,y:694,t:1511831568693};\\\", \\\"{x:929,y:671,t:1511831568709};\\\", \\\"{x:913,y:640,t:1511831568726};\\\", \\\"{x:886,y:603,t:1511831568743};\\\", \\\"{x:857,y:568,t:1511831568759};\\\", \\\"{x:841,y:551,t:1511831568776};\\\", \\\"{x:832,y:539,t:1511831568793};\\\", \\\"{x:830,y:535,t:1511831568808};\\\", \\\"{x:830,y:530,t:1511831568825};\\\", \\\"{x:832,y:526,t:1511831568842};\\\", \\\"{x:838,y:522,t:1511831568859};\\\", \\\"{x:843,y:519,t:1511831568876};\\\", \\\"{x:844,y:518,t:1511831568893};\\\", \\\"{x:846,y:517,t:1511831568921};\\\", \\\"{x:848,y:517,t:1511831568929};\\\", \\\"{x:851,y:517,t:1511831568943};\\\", \\\"{x:855,y:517,t:1511831568959};\\\", \\\"{x:859,y:519,t:1511831568976};\\\", \\\"{x:874,y:535,t:1511831568993};\\\", \\\"{x:880,y:542,t:1511831569009};\\\", \\\"{x:900,y:558,t:1511831569026};\\\", \\\"{x:906,y:564,t:1511831569043};\\\", \\\"{x:909,y:568,t:1511831569059};\\\", \\\"{x:910,y:571,t:1511831569076};\\\", \\\"{x:911,y:573,t:1511831569093};\\\", \\\"{x:915,y:577,t:1511831569109};\\\", \\\"{x:920,y:582,t:1511831569126};\\\", \\\"{x:923,y:585,t:1511831569143};\\\", \\\"{x:926,y:586,t:1511831569159};\\\", \\\"{x:928,y:589,t:1511831569176};\\\", \\\"{x:930,y:591,t:1511831569193};\\\", \\\"{x:932,y:592,t:1511831569210};\\\", \\\"{x:933,y:592,t:1511831569266};\\\", \\\"{x:935,y:592,t:1511831569276};\\\", \\\"{x:936,y:591,t:1511831569293};\\\", \\\"{x:936,y:589,t:1511831569310};\\\", \\\"{x:936,y:587,t:1511831569326};\\\", \\\"{x:937,y:585,t:1511831569343};\\\", \\\"{x:939,y:583,t:1511831569360};\\\", \\\"{x:940,y:581,t:1511831569376};\\\", \\\"{x:942,y:580,t:1511831569393};\\\", \\\"{x:947,y:580,t:1511831569409};\\\", \\\"{x:956,y:580,t:1511831569426};\\\", \\\"{x:974,y:580,t:1511831569443};\\\", \\\"{x:996,y:580,t:1511831569460};\\\", \\\"{x:1020,y:580,t:1511831569476};\\\", \\\"{x:1039,y:580,t:1511831569493};\\\", \\\"{x:1056,y:580,t:1511831569510};\\\", \\\"{x:1077,y:580,t:1511831569526};\\\", \\\"{x:1099,y:580,t:1511831569543};\\\", \\\"{x:1120,y:580,t:1511831569560};\\\", \\\"{x:1129,y:580,t:1511831569576};\\\", \\\"{x:1125,y:580,t:1511831569642};\\\", \\\"{x:1102,y:577,t:1511831569660};\\\", \\\"{x:1039,y:570,t:1511831569677};\\\", \\\"{x:947,y:566,t:1511831569693};\\\", \\\"{x:864,y:566,t:1511831569710};\\\", \\\"{x:805,y:566,t:1511831569727};\\\", \\\"{x:766,y:566,t:1511831569743};\\\", \\\"{x:754,y:566,t:1511831569760};\\\", \\\"{x:751,y:566,t:1511831569776};\\\", \\\"{x:747,y:566,t:1511831569809};\\\", \\\"{x:735,y:570,t:1511831569826};\\\", \\\"{x:717,y:576,t:1511831569843};\\\", \\\"{x:693,y:580,t:1511831569859};\\\", \\\"{x:666,y:586,t:1511831569877};\\\", \\\"{x:636,y:591,t:1511831569893};\\\", \\\"{x:609,y:595,t:1511831569909};\\\", \\\"{x:583,y:597,t:1511831569926};\\\", \\\"{x:556,y:602,t:1511831569943};\\\", \\\"{x:525,y:603,t:1511831569960};\\\", \\\"{x:485,y:605,t:1511831569977};\\\", \\\"{x:414,y:609,t:1511831569993};\\\", \\\"{x:384,y:614,t:1511831570009};\\\", \\\"{x:361,y:617,t:1511831570026};\\\", \\\"{x:344,y:619,t:1511831570043};\\\", \\\"{x:336,y:620,t:1511831570059};\\\", \\\"{x:335,y:620,t:1511831570217};\\\", \\\"{x:333,y:620,t:1511831570226};\\\", \\\"{x:329,y:612,t:1511831570243};\\\", \\\"{x:321,y:604,t:1511831570259};\\\", \\\"{x:310,y:597,t:1511831570276};\\\", \\\"{x:307,y:595,t:1511831570293};\\\", \\\"{x:304,y:593,t:1511831570309};\\\", \\\"{x:302,y:592,t:1511831570326};\\\", \\\"{x:301,y:591,t:1511831570343};\\\", \\\"{x:299,y:590,t:1511831570359};\\\", \\\"{x:298,y:589,t:1511831570376};\\\", \\\"{x:298,y:587,t:1511831570393};\\\", \\\"{x:298,y:583,t:1511831570410};\\\", \\\"{x:298,y:576,t:1511831570427};\\\", \\\"{x:296,y:570,t:1511831570443};\\\", \\\"{x:295,y:565,t:1511831570460};\\\", \\\"{x:295,y:563,t:1511831570476};\\\", \\\"{x:295,y:561,t:1511831570493};\\\", \\\"{x:295,y:560,t:1511831570510};\\\", \\\"{x:303,y:557,t:1511831570527};\\\", \\\"{x:317,y:551,t:1511831570543};\\\", \\\"{x:333,y:549,t:1511831570560};\\\", \\\"{x:342,y:548,t:1511831570577};\\\", \\\"{x:348,y:547,t:1511831570593};\\\", \\\"{x:350,y:547,t:1511831570610};\\\", \\\"{x:352,y:546,t:1511831570627};\\\", \\\"{x:354,y:546,t:1511831570672};\\\", \\\"{x:357,y:543,t:1511831570680};\\\", \\\"{x:362,y:541,t:1511831570694};\\\", \\\"{x:368,y:538,t:1511831570710};\\\", \\\"{x:376,y:533,t:1511831570727};\\\", \\\"{x:379,y:533,t:1511831570744};\\\", \\\"{x:380,y:532,t:1511831570760};\\\", \\\"{x:382,y:531,t:1511831570777};\\\", \\\"{x:385,y:530,t:1511831570794};\\\", \\\"{x:392,y:527,t:1511831570811};\\\", \\\"{x:396,y:526,t:1511831570827};\\\", \\\"{x:398,y:526,t:1511831570845};\\\", \\\"{x:399,y:525,t:1511831570905};\\\", \\\"{x:401,y:525,t:1511831571129};\\\", \\\"{x:404,y:529,t:1511831571145};\\\", \\\"{x:406,y:539,t:1511831571161};\\\", \\\"{x:407,y:545,t:1511831571178};\\\", \\\"{x:408,y:552,t:1511831571195};\\\", \\\"{x:409,y:555,t:1511831571211};\\\", \\\"{x:409,y:554,t:1511831571785};\\\", \\\"{x:409,y:551,t:1511831571794};\\\", \\\"{x:409,y:546,t:1511831571811};\\\", \\\"{x:409,y:540,t:1511831571828};\\\", \\\"{x:409,y:536,t:1511831571844};\\\", \\\"{x:409,y:533,t:1511831571861};\\\", \\\"{x:409,y:530,t:1511831571878};\\\", \\\"{x:409,y:529,t:1511831571894};\\\", \\\"{x:409,y:534,t:1511831572186};\\\", \\\"{x:409,y:545,t:1511831572194};\\\", \\\"{x:412,y:568,t:1511831572211};\\\", \\\"{x:418,y:589,t:1511831572228};\\\", \\\"{x:422,y:602,t:1511831572245};\\\", \\\"{x:422,y:608,t:1511831572261};\\\", \\\"{x:423,y:617,t:1511831572278};\\\", \\\"{x:424,y:623,t:1511831572295};\\\", \\\"{x:425,y:632,t:1511831572311};\\\", \\\"{x:430,y:662,t:1511831572328};\\\", \\\"{x:434,y:687,t:1511831572345};\\\", \\\"{x:436,y:706,t:1511831572361};\\\", \\\"{x:439,y:718,t:1511831572378};\\\", \\\"{x:440,y:725,t:1511831572395};\\\", \\\"{x:440,y:726,t:1511831572411};\\\", \\\"{x:439,y:725,t:1511831572545};\\\", \\\"{x:439,y:721,t:1511831572561};\\\", \\\"{x:437,y:714,t:1511831572578};\\\", \\\"{x:437,y:706,t:1511831572595};\\\", \\\"{x:435,y:700,t:1511831572612};\\\", \\\"{x:431,y:691,t:1511831572628};\\\", \\\"{x:431,y:688,t:1511831572645};\\\", \\\"{x:431,y:686,t:1511831572662};\\\", \\\"{x:431,y:685,t:1511831572678};\\\" ] }, { \\\"rt\\\": 28309, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 395806, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-I -I -C -C -H -F -F -F -F -B -N -N -04:30-M -M -M -O -O -O -X -X -X -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:434,y:684,t:1511831574633};\\\", \\\"{x:441,y:681,t:1511831574648};\\\", \\\"{x:529,y:668,t:1511831574697};\\\", \\\"{x:545,y:666,t:1511831574715};\\\", \\\"{x:562,y:664,t:1511831574731};\\\", \\\"{x:581,y:664,t:1511831574747};\\\", \\\"{x:606,y:664,t:1511831574764};\\\", \\\"{x:627,y:664,t:1511831574781};\\\", \\\"{x:649,y:664,t:1511831574797};\\\", \\\"{x:664,y:664,t:1511831574814};\\\", \\\"{x:674,y:664,t:1511831574831};\\\", \\\"{x:683,y:664,t:1511831574847};\\\", \\\"{x:690,y:664,t:1511831574864};\\\", \\\"{x:696,y:665,t:1511831574881};\\\", \\\"{x:698,y:665,t:1511831578746};\\\", \\\"{x:704,y:665,t:1511831578753};\\\", \\\"{x:709,y:665,t:1511831578766};\\\", \\\"{x:727,y:660,t:1511831578783};\\\", \\\"{x:749,y:652,t:1511831578799};\\\", \\\"{x:771,y:646,t:1511831578817};\\\", \\\"{x:796,y:639,t:1511831578833};\\\", \\\"{x:807,y:635,t:1511831578849};\\\", \\\"{x:826,y:632,t:1511831578866};\\\", \\\"{x:845,y:629,t:1511831578883};\\\", \\\"{x:867,y:622,t:1511831578899};\\\", \\\"{x:884,y:617,t:1511831578916};\\\", \\\"{x:901,y:610,t:1511831578933};\\\", \\\"{x:913,y:603,t:1511831578949};\\\", \\\"{x:917,y:600,t:1511831578966};\\\", \\\"{x:922,y:595,t:1511831578983};\\\", \\\"{x:924,y:592,t:1511831578999};\\\", \\\"{x:925,y:589,t:1511831579016};\\\", \\\"{x:926,y:586,t:1511831579033};\\\", \\\"{x:926,y:585,t:1511831579049};\\\", \\\"{x:926,y:586,t:1511831579282};\\\", \\\"{x:926,y:592,t:1511831579290};\\\", \\\"{x:926,y:598,t:1511831579300};\\\", \\\"{x:926,y:608,t:1511831579317};\\\", \\\"{x:926,y:620,t:1511831579334};\\\", \\\"{x:926,y:629,t:1511831579350};\\\", \\\"{x:926,y:636,t:1511831579366};\\\", \\\"{x:926,y:641,t:1511831579384};\\\", \\\"{x:926,y:645,t:1511831579400};\\\", \\\"{x:926,y:647,t:1511831579417};\\\", \\\"{x:926,y:649,t:1511831579434};\\\", \\\"{x:926,y:650,t:1511831579490};\\\", \\\"{x:926,y:651,t:1511831579500};\\\", \\\"{x:926,y:652,t:1511831579517};\\\", \\\"{x:926,y:654,t:1511831579534};\\\", \\\"{x:926,y:655,t:1511831579698};\\\", \\\"{x:926,y:656,t:1511831579706};\\\", \\\"{x:926,y:657,t:1511831579722};\\\", \\\"{x:926,y:658,t:1511831579754};\\\", \\\"{x:927,y:659,t:1511831579767};\\\", \\\"{x:928,y:659,t:1511831579802};\\\", \\\"{x:929,y:660,t:1511831579817};\\\", \\\"{x:930,y:663,t:1511831579833};\\\", \\\"{x:932,y:664,t:1511831579851};\\\", \\\"{x:932,y:665,t:1511831581010};\\\", \\\"{x:935,y:672,t:1511831581601};\\\", \\\"{x:941,y:692,t:1511831581617};\\\", \\\"{x:949,y:706,t:1511831581634};\\\", \\\"{x:955,y:715,t:1511831581651};\\\", \\\"{x:959,y:722,t:1511831581667};\\\", \\\"{x:960,y:724,t:1511831581684};\\\", \\\"{x:961,y:725,t:1511831581701};\\\", \\\"{x:961,y:728,t:1511831581717};\\\", \\\"{x:963,y:732,t:1511831581734};\\\", \\\"{x:963,y:734,t:1511831581751};\\\", \\\"{x:963,y:737,t:1511831581767};\\\", \\\"{x:964,y:739,t:1511831581784};\\\", \\\"{x:968,y:750,t:1511831581801};\\\", \\\"{x:972,y:755,t:1511831581817};\\\", \\\"{x:973,y:758,t:1511831581835};\\\", \\\"{x:974,y:758,t:1511831581852};\\\", \\\"{x:974,y:759,t:1511831581868};\\\", \\\"{x:975,y:760,t:1511831581885};\\\", \\\"{x:976,y:763,t:1511831581902};\\\", \\\"{x:981,y:769,t:1511831581918};\\\", \\\"{x:984,y:773,t:1511831581935};\\\", \\\"{x:988,y:775,t:1511831581952};\\\", \\\"{x:991,y:776,t:1511831581968};\\\", \\\"{x:992,y:776,t:1511831582050};\\\", \\\"{x:993,y:776,t:1511831582057};\\\", \\\"{x:994,y:776,t:1511831582081};\\\", \\\"{x:994,y:775,t:1511831582097};\\\", \\\"{x:995,y:774,t:1511831582105};\\\", \\\"{x:995,y:773,t:1511831582130};\\\", \\\"{x:995,y:772,t:1511831582138};\\\", \\\"{x:995,y:771,t:1511831582152};\\\", \\\"{x:995,y:770,t:1511831582168};\\\", \\\"{x:996,y:770,t:1511831582185};\\\", \\\"{x:996,y:769,t:1511831582202};\\\", \\\"{x:996,y:768,t:1511831582233};\\\", \\\"{x:995,y:768,t:1511831582274};\\\", \\\"{x:994,y:768,t:1511831582284};\\\", \\\"{x:993,y:768,t:1511831582312};\\\", \\\"{x:991,y:768,t:1511831582345};\\\", \\\"{x:989,y:767,t:1511831582368};\\\", \\\"{x:987,y:767,t:1511831582384};\\\", \\\"{x:996,y:767,t:1511831582738};\\\", \\\"{x:1011,y:767,t:1511831582751};\\\", \\\"{x:1034,y:767,t:1511831582768};\\\", \\\"{x:1050,y:767,t:1511831582785};\\\", \\\"{x:1054,y:767,t:1511831582802};\\\", \\\"{x:1055,y:767,t:1511831583018};\\\", \\\"{x:1055,y:768,t:1511831583041};\\\", \\\"{x:1054,y:768,t:1511831583057};\\\", \\\"{x:1051,y:768,t:1511831583106};\\\", \\\"{x:1045,y:768,t:1511831583119};\\\", \\\"{x:1030,y:768,t:1511831583136};\\\", \\\"{x:1016,y:768,t:1511831583152};\\\", \\\"{x:1005,y:768,t:1511831583169};\\\", \\\"{x:999,y:768,t:1511831583186};\\\", \\\"{x:998,y:768,t:1511831583202};\\\", \\\"{x:997,y:768,t:1511831583258};\\\", \\\"{x:996,y:768,t:1511831583269};\\\", \\\"{x:995,y:768,t:1511831583286};\\\", \\\"{x:992,y:767,t:1511831583302};\\\", \\\"{x:990,y:767,t:1511831583318};\\\", \\\"{x:988,y:766,t:1511831583336};\\\", \\\"{x:987,y:766,t:1511831583353};\\\", \\\"{x:987,y:764,t:1511831583426};\\\", \\\"{x:987,y:762,t:1511831583436};\\\", \\\"{x:994,y:754,t:1511831583452};\\\", \\\"{x:1011,y:743,t:1511831583469};\\\", \\\"{x:1041,y:731,t:1511831583486};\\\", \\\"{x:1072,y:720,t:1511831583502};\\\", \\\"{x:1108,y:710,t:1511831583519};\\\", \\\"{x:1156,y:703,t:1511831583536};\\\", \\\"{x:1198,y:697,t:1511831583552};\\\", \\\"{x:1222,y:693,t:1511831583569};\\\", \\\"{x:1230,y:691,t:1511831583585};\\\", \\\"{x:1230,y:690,t:1511831583682};\\\", \\\"{x:1230,y:689,t:1511831583689};\\\", \\\"{x:1230,y:687,t:1511831583702};\\\", \\\"{x:1223,y:682,t:1511831583719};\\\", \\\"{x:1213,y:680,t:1511831583736};\\\", \\\"{x:1203,y:679,t:1511831583752};\\\", \\\"{x:1192,y:678,t:1511831583769};\\\", \\\"{x:1170,y:676,t:1511831583785};\\\", \\\"{x:1161,y:676,t:1511831583803};\\\", \\\"{x:1157,y:676,t:1511831583819};\\\", \\\"{x:1157,y:675,t:1511831583890};\\\", \\\"{x:1157,y:674,t:1511831583902};\\\", \\\"{x:1165,y:670,t:1511831583919};\\\", \\\"{x:1178,y:665,t:1511831583936};\\\", \\\"{x:1195,y:662,t:1511831583953};\\\", \\\"{x:1205,y:658,t:1511831583969};\\\", \\\"{x:1224,y:653,t:1511831583985};\\\", \\\"{x:1229,y:651,t:1511831584002};\\\", \\\"{x:1232,y:650,t:1511831584018};\\\", \\\"{x:1233,y:649,t:1511831584035};\\\", \\\"{x:1236,y:649,t:1511831584072};\\\", \\\"{x:1242,y:649,t:1511831584085};\\\", \\\"{x:1253,y:649,t:1511831584102};\\\", \\\"{x:1261,y:649,t:1511831584118};\\\", \\\"{x:1270,y:649,t:1511831584135};\\\", \\\"{x:1273,y:649,t:1511831584152};\\\", \\\"{x:1274,y:649,t:1511831584168};\\\", \\\"{x:1276,y:647,t:1511831584185};\\\", \\\"{x:1278,y:647,t:1511831584202};\\\", \\\"{x:1283,y:647,t:1511831584218};\\\", \\\"{x:1285,y:647,t:1511831584235};\\\", \\\"{x:1286,y:647,t:1511831584252};\\\", \\\"{x:1287,y:646,t:1511831584268};\\\", \\\"{x:1287,y:645,t:1511831584346};\\\", \\\"{x:1287,y:644,t:1511831584386};\\\", \\\"{x:1285,y:643,t:1511831584403};\\\", \\\"{x:1280,y:640,t:1511831584419};\\\", \\\"{x:1277,y:638,t:1511831584436};\\\", \\\"{x:1272,y:636,t:1511831584453};\\\", \\\"{x:1269,y:635,t:1511831584470};\\\", \\\"{x:1266,y:634,t:1511831584486};\\\", \\\"{x:1261,y:632,t:1511831584503};\\\", \\\"{x:1259,y:631,t:1511831584519};\\\", \\\"{x:1253,y:628,t:1511831584536};\\\", \\\"{x:1243,y:625,t:1511831584553};\\\", \\\"{x:1237,y:623,t:1511831584569};\\\", \\\"{x:1236,y:623,t:1511831584746};\\\", \\\"{x:1236,y:625,t:1511831584777};\\\", \\\"{x:1237,y:625,t:1511831584786};\\\", \\\"{x:1241,y:627,t:1511831584804};\\\", \\\"{x:1242,y:628,t:1511831584820};\\\", \\\"{x:1243,y:629,t:1511831584836};\\\", \\\"{x:1244,y:629,t:1511831584906};\\\", \\\"{x:1246,y:629,t:1511831584920};\\\", \\\"{x:1248,y:630,t:1511831584936};\\\", \\\"{x:1250,y:630,t:1511831584953};\\\", \\\"{x:1252,y:630,t:1511831584970};\\\", \\\"{x:1253,y:631,t:1511831584985};\\\", \\\"{x:1254,y:631,t:1511831585065};\\\", \\\"{x:1256,y:631,t:1511831585073};\\\", \\\"{x:1257,y:632,t:1511831585086};\\\", \\\"{x:1259,y:632,t:1511831585313};\\\", \\\"{x:1260,y:632,t:1511831585353};\\\", \\\"{x:1259,y:632,t:1511831585873};\\\", \\\"{x:1258,y:632,t:1511831585889};\\\", \\\"{x:1257,y:632,t:1511831585905};\\\", \\\"{x:1257,y:631,t:1511831586128};\\\", \\\"{x:1257,y:630,t:1511831586144};\\\", \\\"{x:1257,y:628,t:1511831586160};\\\", \\\"{x:1257,y:627,t:1511831586176};\\\", \\\"{x:1256,y:627,t:1511831586601};\\\", \\\"{x:1258,y:627,t:1511831586897};\\\", \\\"{x:1275,y:628,t:1511831586906};\\\", \\\"{x:1319,y:628,t:1511831586921};\\\", \\\"{x:1345,y:628,t:1511831586937};\\\", \\\"{x:1405,y:630,t:1511831586953};\\\", \\\"{x:1422,y:633,t:1511831586971};\\\", \\\"{x:1425,y:634,t:1511831586987};\\\", \\\"{x:1423,y:634,t:1511831587136};\\\", \\\"{x:1418,y:634,t:1511831587153};\\\", \\\"{x:1413,y:635,t:1511831587170};\\\", \\\"{x:1409,y:635,t:1511831587186};\\\", \\\"{x:1408,y:635,t:1511831587203};\\\", \\\"{x:1407,y:635,t:1511831587297};\\\", \\\"{x:1404,y:635,t:1511831587305};\\\", \\\"{x:1402,y:635,t:1511831587321};\\\", \\\"{x:1399,y:633,t:1511831587386};\\\", \\\"{x:1396,y:632,t:1511831587393};\\\", \\\"{x:1394,y:631,t:1511831587404};\\\", \\\"{x:1388,y:630,t:1511831587420};\\\", \\\"{x:1387,y:630,t:1511831587438};\\\", \\\"{x:1382,y:627,t:1511831587850};\\\", \\\"{x:1364,y:623,t:1511831587857};\\\", \\\"{x:1340,y:620,t:1511831587871};\\\", \\\"{x:1283,y:617,t:1511831587888};\\\", \\\"{x:1208,y:617,t:1511831587904};\\\", \\\"{x:1148,y:617,t:1511831587921};\\\", \\\"{x:1140,y:617,t:1511831587937};\\\", \\\"{x:1139,y:617,t:1511831587954};\\\", \\\"{x:1138,y:617,t:1511831587993};\\\", \\\"{x:1138,y:618,t:1511831588004};\\\", \\\"{x:1133,y:619,t:1511831588021};\\\", \\\"{x:1124,y:623,t:1511831588038};\\\", \\\"{x:1111,y:629,t:1511831588054};\\\", \\\"{x:1097,y:636,t:1511831588071};\\\", \\\"{x:1089,y:643,t:1511831588088};\\\", \\\"{x:1086,y:646,t:1511831588104};\\\", \\\"{x:1085,y:652,t:1511831588121};\\\", \\\"{x:1085,y:655,t:1511831588137};\\\", \\\"{x:1085,y:656,t:1511831588155};\\\", \\\"{x:1085,y:657,t:1511831588171};\\\", \\\"{x:1085,y:659,t:1511831588188};\\\", \\\"{x:1085,y:660,t:1511831588204};\\\", \\\"{x:1085,y:663,t:1511831588221};\\\", \\\"{x:1085,y:668,t:1511831588238};\\\", \\\"{x:1085,y:674,t:1511831588254};\\\", \\\"{x:1085,y:680,t:1511831588271};\\\", \\\"{x:1084,y:685,t:1511831588288};\\\", \\\"{x:1076,y:695,t:1511831588305};\\\", \\\"{x:1073,y:698,t:1511831588321};\\\", \\\"{x:1070,y:699,t:1511831588337};\\\", \\\"{x:1067,y:699,t:1511831588355};\\\", \\\"{x:1064,y:699,t:1511831588371};\\\", \\\"{x:1059,y:699,t:1511831588388};\\\", \\\"{x:1050,y:700,t:1511831588405};\\\", \\\"{x:1042,y:702,t:1511831588421};\\\", \\\"{x:1037,y:703,t:1511831588438};\\\", \\\"{x:1036,y:705,t:1511831588455};\\\", \\\"{x:1040,y:703,t:1511831588529};\\\", \\\"{x:1054,y:699,t:1511831588537};\\\", \\\"{x:1102,y:691,t:1511831588555};\\\", \\\"{x:1155,y:685,t:1511831588571};\\\", \\\"{x:1189,y:685,t:1511831588588};\\\", \\\"{x:1203,y:685,t:1511831588605};\\\", \\\"{x:1206,y:685,t:1511831588621};\\\", \\\"{x:1205,y:686,t:1511831588657};\\\", \\\"{x:1204,y:686,t:1511831588671};\\\", \\\"{x:1195,y:689,t:1511831588688};\\\", \\\"{x:1189,y:690,t:1511831588705};\\\", \\\"{x:1186,y:690,t:1511831588721};\\\", \\\"{x:1181,y:691,t:1511831588738};\\\", \\\"{x:1175,y:693,t:1511831588755};\\\", \\\"{x:1169,y:695,t:1511831588771};\\\", \\\"{x:1166,y:695,t:1511831588788};\\\", \\\"{x:1163,y:697,t:1511831588805};\\\", \\\"{x:1162,y:697,t:1511831588857};\\\", \\\"{x:1159,y:697,t:1511831588871};\\\", \\\"{x:1156,y:696,t:1511831588888};\\\", \\\"{x:1151,y:694,t:1511831588904};\\\", \\\"{x:1151,y:690,t:1511831589002};\\\", \\\"{x:1157,y:685,t:1511831589009};\\\", \\\"{x:1166,y:681,t:1511831589022};\\\", \\\"{x:1193,y:669,t:1511831589038};\\\", \\\"{x:1231,y:655,t:1511831589055};\\\", \\\"{x:1263,y:646,t:1511831589072};\\\", \\\"{x:1274,y:643,t:1511831589088};\\\", \\\"{x:1277,y:642,t:1511831589105};\\\", \\\"{x:1277,y:639,t:1511831589169};\\\", \\\"{x:1277,y:637,t:1511831589177};\\\", \\\"{x:1275,y:636,t:1511831589188};\\\", \\\"{x:1273,y:635,t:1511831589205};\\\", \\\"{x:1271,y:634,t:1511831589222};\\\", \\\"{x:1270,y:634,t:1511831589249};\\\", \\\"{x:1264,y:634,t:1511831589512};\\\", \\\"{x:1257,y:636,t:1511831589521};\\\", \\\"{x:1242,y:648,t:1511831589537};\\\", \\\"{x:1226,y:660,t:1511831589554};\\\", \\\"{x:1212,y:667,t:1511831589571};\\\", \\\"{x:1209,y:670,t:1511831589588};\\\", \\\"{x:1207,y:671,t:1511831589632};\\\", \\\"{x:1206,y:671,t:1511831589645};\\\", \\\"{x:1202,y:673,t:1511831589654};\\\", \\\"{x:1184,y:677,t:1511831589671};\\\", \\\"{x:1148,y:682,t:1511831589688};\\\", \\\"{x:1126,y:687,t:1511831589704};\\\", \\\"{x:1109,y:691,t:1511831589721};\\\", \\\"{x:1096,y:695,t:1511831589738};\\\", \\\"{x:1091,y:696,t:1511831589754};\\\", \\\"{x:1089,y:697,t:1511831589771};\\\", \\\"{x:1088,y:697,t:1511831589788};\\\", \\\"{x:1084,y:695,t:1511831589804};\\\", \\\"{x:1079,y:692,t:1511831589821};\\\", \\\"{x:1074,y:691,t:1511831589838};\\\", \\\"{x:1070,y:690,t:1511831589854};\\\", \\\"{x:1066,y:690,t:1511831589871};\\\", \\\"{x:1055,y:690,t:1511831589888};\\\", \\\"{x:1043,y:692,t:1511831589904};\\\", \\\"{x:1034,y:697,t:1511831589921};\\\", \\\"{x:1020,y:704,t:1511831589938};\\\", \\\"{x:1011,y:708,t:1511831589954};\\\", \\\"{x:1006,y:709,t:1511831589971};\\\", \\\"{x:1000,y:711,t:1511831589988};\\\", \\\"{x:996,y:711,t:1511831590004};\\\", \\\"{x:994,y:711,t:1511831590021};\\\", \\\"{x:996,y:711,t:1511831590097};\\\", \\\"{x:1006,y:711,t:1511831590105};\\\", \\\"{x:1035,y:711,t:1511831590122};\\\", \\\"{x:1074,y:711,t:1511831590139};\\\", \\\"{x:1113,y:711,t:1511831590155};\\\", \\\"{x:1142,y:711,t:1511831590172};\\\", \\\"{x:1157,y:711,t:1511831590189};\\\", \\\"{x:1161,y:711,t:1511831590205};\\\", \\\"{x:1162,y:711,t:1511831590222};\\\", \\\"{x:1162,y:709,t:1511831590362};\\\", \\\"{x:1162,y:708,t:1511831590504};\\\", \\\"{x:1161,y:707,t:1511831590512};\\\", \\\"{x:1159,y:705,t:1511831590521};\\\", \\\"{x:1153,y:703,t:1511831590538};\\\", \\\"{x:1150,y:701,t:1511831590555};\\\", \\\"{x:1149,y:701,t:1511831590571};\\\", \\\"{x:1148,y:700,t:1511831590588};\\\", \\\"{x:1148,y:699,t:1511831590648};\\\", \\\"{x:1146,y:697,t:1511831590655};\\\", \\\"{x:1146,y:695,t:1511831590671};\\\", \\\"{x:1146,y:690,t:1511831590688};\\\", \\\"{x:1146,y:688,t:1511831590705};\\\", \\\"{x:1146,y:687,t:1511831590721};\\\", \\\"{x:1147,y:687,t:1511831591169};\\\", \\\"{x:1148,y:688,t:1511831591177};\\\", \\\"{x:1149,y:688,t:1511831591189};\\\", \\\"{x:1152,y:689,t:1511831591206};\\\", \\\"{x:1154,y:690,t:1511831591223};\\\", \\\"{x:1155,y:690,t:1511831591239};\\\", \\\"{x:1156,y:690,t:1511831591289};\\\", \\\"{x:1157,y:690,t:1511831591306};\\\", \\\"{x:1158,y:690,t:1511831591323};\\\", \\\"{x:1159,y:691,t:1511831591346};\\\", \\\"{x:1160,y:691,t:1511831591435};\\\", \\\"{x:1162,y:691,t:1511831591442};\\\", \\\"{x:1165,y:690,t:1511831591457};\\\", \\\"{x:1166,y:690,t:1511831591474};\\\", \\\"{x:1168,y:690,t:1511831591490};\\\", \\\"{x:1168,y:689,t:1511831591506};\\\", \\\"{x:1167,y:689,t:1511831591690};\\\", \\\"{x:1167,y:690,t:1511831591738};\\\", \\\"{x:1166,y:690,t:1511831591762};\\\", \\\"{x:1165,y:690,t:1511831591826};\\\", \\\"{x:1164,y:691,t:1511831591840};\\\", \\\"{x:1163,y:693,t:1511831591857};\\\", \\\"{x:1162,y:699,t:1511831591874};\\\", \\\"{x:1162,y:701,t:1511831591890};\\\", \\\"{x:1162,y:704,t:1511831591907};\\\", \\\"{x:1161,y:706,t:1511831591924};\\\", \\\"{x:1161,y:708,t:1511831591941};\\\", \\\"{x:1161,y:709,t:1511831591957};\\\", \\\"{x:1161,y:712,t:1511831591974};\\\", \\\"{x:1161,y:715,t:1511831591991};\\\", \\\"{x:1161,y:722,t:1511831592007};\\\", \\\"{x:1157,y:729,t:1511831592024};\\\", \\\"{x:1155,y:740,t:1511831592041};\\\", \\\"{x:1153,y:746,t:1511831592057};\\\", \\\"{x:1150,y:752,t:1511831592074};\\\", \\\"{x:1150,y:754,t:1511831592091};\\\", \\\"{x:1149,y:755,t:1511831592106};\\\", \\\"{x:1149,y:756,t:1511831592123};\\\", \\\"{x:1149,y:757,t:1511831592153};\\\", \\\"{x:1148,y:758,t:1511831592249};\\\", \\\"{x:1146,y:760,t:1511831592265};\\\", \\\"{x:1144,y:761,t:1511831592289};\\\", \\\"{x:1144,y:763,t:1511831592297};\\\", \\\"{x:1143,y:764,t:1511831592306};\\\", \\\"{x:1143,y:766,t:1511831592386};\\\", \\\"{x:1143,y:767,t:1511831592401};\\\", \\\"{x:1148,y:768,t:1511831592409};\\\", \\\"{x:1154,y:771,t:1511831592423};\\\", \\\"{x:1174,y:776,t:1511831592440};\\\", \\\"{x:1196,y:778,t:1511831592457};\\\", \\\"{x:1219,y:782,t:1511831592474};\\\", \\\"{x:1232,y:783,t:1511831592490};\\\", \\\"{x:1242,y:784,t:1511831592507};\\\", \\\"{x:1251,y:786,t:1511831592524};\\\", \\\"{x:1263,y:787,t:1511831592541};\\\", \\\"{x:1283,y:789,t:1511831592557};\\\", \\\"{x:1302,y:791,t:1511831592574};\\\", \\\"{x:1324,y:792,t:1511831592591};\\\", \\\"{x:1347,y:797,t:1511831592608};\\\", \\\"{x:1378,y:800,t:1511831592624};\\\", \\\"{x:1417,y:805,t:1511831592641};\\\", \\\"{x:1464,y:813,t:1511831592658};\\\", \\\"{x:1488,y:816,t:1511831592674};\\\", \\\"{x:1507,y:821,t:1511831592691};\\\", \\\"{x:1516,y:823,t:1511831592708};\\\", \\\"{x:1517,y:823,t:1511831592724};\\\", \\\"{x:1516,y:823,t:1511831592890};\\\", \\\"{x:1509,y:826,t:1511831592908};\\\", \\\"{x:1504,y:827,t:1511831592924};\\\", \\\"{x:1502,y:827,t:1511831592941};\\\", \\\"{x:1501,y:827,t:1511831592994};\\\", \\\"{x:1498,y:827,t:1511831593008};\\\", \\\"{x:1492,y:829,t:1511831593024};\\\", \\\"{x:1480,y:834,t:1511831593041};\\\", \\\"{x:1466,y:839,t:1511831593058};\\\", \\\"{x:1460,y:841,t:1511831593074};\\\", \\\"{x:1458,y:842,t:1511831593091};\\\", \\\"{x:1459,y:842,t:1511831593138};\\\", \\\"{x:1462,y:838,t:1511831593146};\\\", \\\"{x:1462,y:835,t:1511831593158};\\\", \\\"{x:1466,y:830,t:1511831593174};\\\", \\\"{x:1468,y:827,t:1511831593191};\\\", \\\"{x:1468,y:830,t:1511831593258};\\\", \\\"{x:1468,y:839,t:1511831593274};\\\", \\\"{x:1468,y:846,t:1511831593291};\\\", \\\"{x:1468,y:852,t:1511831593308};\\\", \\\"{x:1464,y:860,t:1511831593325};\\\", \\\"{x:1461,y:868,t:1511831593341};\\\", \\\"{x:1454,y:879,t:1511831593358};\\\", \\\"{x:1446,y:890,t:1511831593375};\\\", \\\"{x:1432,y:901,t:1511831593391};\\\", \\\"{x:1422,y:910,t:1511831593408};\\\", \\\"{x:1419,y:911,t:1511831593425};\\\", \\\"{x:1421,y:911,t:1511831593458};\\\", \\\"{x:1434,y:902,t:1511831593474};\\\", \\\"{x:1461,y:886,t:1511831593491};\\\", \\\"{x:1491,y:869,t:1511831593508};\\\", \\\"{x:1549,y:844,t:1511831593525};\\\", \\\"{x:1596,y:821,t:1511831593541};\\\", \\\"{x:1621,y:808,t:1511831593558};\\\", \\\"{x:1630,y:801,t:1511831593575};\\\", \\\"{x:1631,y:800,t:1511831593591};\\\", \\\"{x:1629,y:801,t:1511831593626};\\\", \\\"{x:1621,y:808,t:1511831593641};\\\", \\\"{x:1589,y:843,t:1511831593658};\\\", \\\"{x:1554,y:884,t:1511831593674};\\\", \\\"{x:1525,y:920,t:1511831593691};\\\", \\\"{x:1496,y:949,t:1511831593708};\\\", \\\"{x:1477,y:962,t:1511831593725};\\\", \\\"{x:1461,y:967,t:1511831593741};\\\", \\\"{x:1458,y:967,t:1511831593758};\\\", \\\"{x:1457,y:966,t:1511831593775};\\\", \\\"{x:1457,y:956,t:1511831593791};\\\", \\\"{x:1457,y:935,t:1511831593808};\\\", \\\"{x:1447,y:907,t:1511831593825};\\\", \\\"{x:1438,y:884,t:1511831593841};\\\", \\\"{x:1429,y:862,t:1511831593858};\\\", \\\"{x:1424,y:853,t:1511831593875};\\\", \\\"{x:1423,y:852,t:1511831593891};\\\", \\\"{x:1420,y:851,t:1511831593946};\\\", \\\"{x:1412,y:851,t:1511831593958};\\\", \\\"{x:1391,y:847,t:1511831593975};\\\", \\\"{x:1359,y:842,t:1511831593992};\\\", \\\"{x:1297,y:834,t:1511831594008};\\\", \\\"{x:1265,y:830,t:1511831594025};\\\", \\\"{x:1255,y:827,t:1511831594042};\\\", \\\"{x:1254,y:826,t:1511831594058};\\\", \\\"{x:1254,y:825,t:1511831594082};\\\", \\\"{x:1252,y:825,t:1511831594121};\\\", \\\"{x:1251,y:825,t:1511831594129};\\\", \\\"{x:1249,y:825,t:1511831594141};\\\", \\\"{x:1242,y:828,t:1511831594157};\\\", \\\"{x:1238,y:829,t:1511831594174};\\\", \\\"{x:1236,y:829,t:1511831594191};\\\", \\\"{x:1236,y:831,t:1511831594207};\\\", \\\"{x:1237,y:833,t:1511831594224};\\\", \\\"{x:1249,y:835,t:1511831594241};\\\", \\\"{x:1258,y:836,t:1511831594257};\\\", \\\"{x:1266,y:836,t:1511831594274};\\\", \\\"{x:1271,y:836,t:1511831594291};\\\", \\\"{x:1273,y:836,t:1511831594307};\\\", \\\"{x:1274,y:835,t:1511831594324};\\\", \\\"{x:1277,y:834,t:1511831594341};\\\", \\\"{x:1278,y:833,t:1511831594357};\\\", \\\"{x:1279,y:834,t:1511831594522};\\\", \\\"{x:1276,y:834,t:1511831594690};\\\", \\\"{x:1263,y:843,t:1511831594698};\\\", \\\"{x:1250,y:852,t:1511831594708};\\\", \\\"{x:1218,y:879,t:1511831594725};\\\", \\\"{x:1190,y:901,t:1511831594742};\\\", \\\"{x:1178,y:915,t:1511831594759};\\\", \\\"{x:1175,y:919,t:1511831594775};\\\", \\\"{x:1174,y:921,t:1511831594792};\\\", \\\"{x:1174,y:919,t:1511831594858};\\\", \\\"{x:1176,y:915,t:1511831594875};\\\", \\\"{x:1177,y:908,t:1511831594892};\\\", \\\"{x:1184,y:899,t:1511831594909};\\\", \\\"{x:1188,y:892,t:1511831594925};\\\", \\\"{x:1191,y:885,t:1511831594942};\\\", \\\"{x:1195,y:880,t:1511831594959};\\\", \\\"{x:1202,y:872,t:1511831594975};\\\", \\\"{x:1206,y:870,t:1511831594992};\\\", \\\"{x:1208,y:870,t:1511831595009};\\\", \\\"{x:1208,y:871,t:1511831595082};\\\", \\\"{x:1208,y:872,t:1511831595092};\\\", \\\"{x:1208,y:879,t:1511831595109};\\\", \\\"{x:1203,y:890,t:1511831595125};\\\", \\\"{x:1193,y:905,t:1511831595142};\\\", \\\"{x:1180,y:922,t:1511831595159};\\\", \\\"{x:1169,y:933,t:1511831595175};\\\", \\\"{x:1164,y:939,t:1511831595192};\\\", \\\"{x:1164,y:940,t:1511831595209};\\\", \\\"{x:1164,y:937,t:1511831595258};\\\", \\\"{x:1177,y:924,t:1511831595275};\\\", \\\"{x:1206,y:900,t:1511831595292};\\\", \\\"{x:1264,y:867,t:1511831595309};\\\", \\\"{x:1318,y:837,t:1511831595325};\\\", \\\"{x:1348,y:819,t:1511831595342};\\\", \\\"{x:1366,y:806,t:1511831595359};\\\", \\\"{x:1371,y:801,t:1511831595375};\\\", \\\"{x:1372,y:801,t:1511831595392};\\\", \\\"{x:1372,y:800,t:1511831595458};\\\", \\\"{x:1369,y:799,t:1511831595476};\\\", \\\"{x:1365,y:799,t:1511831595492};\\\", \\\"{x:1361,y:798,t:1511831595509};\\\", \\\"{x:1360,y:797,t:1511831595525};\\\", \\\"{x:1359,y:796,t:1511831595541};\\\", \\\"{x:1357,y:794,t:1511831595558};\\\", \\\"{x:1355,y:793,t:1511831595575};\\\", \\\"{x:1354,y:791,t:1511831595625};\\\", \\\"{x:1354,y:789,t:1511831595641};\\\", \\\"{x:1351,y:785,t:1511831595658};\\\", \\\"{x:1350,y:783,t:1511831595675};\\\", \\\"{x:1348,y:779,t:1511831595691};\\\", \\\"{x:1344,y:776,t:1511831595708};\\\", \\\"{x:1341,y:775,t:1511831595725};\\\", \\\"{x:1340,y:774,t:1511831595741};\\\", \\\"{x:1337,y:772,t:1511831595826};\\\", \\\"{x:1331,y:771,t:1511831595841};\\\", \\\"{x:1321,y:770,t:1511831595859};\\\", \\\"{x:1310,y:768,t:1511831595876};\\\", \\\"{x:1307,y:768,t:1511831595892};\\\", \\\"{x:1307,y:767,t:1511831596114};\\\", \\\"{x:1309,y:766,t:1511831596146};\\\", \\\"{x:1310,y:765,t:1511831596159};\\\", \\\"{x:1311,y:764,t:1511831596176};\\\", \\\"{x:1312,y:764,t:1511831596274};\\\", \\\"{x:1313,y:764,t:1511831596298};\\\", \\\"{x:1313,y:763,t:1511831596314};\\\", \\\"{x:1315,y:762,t:1511831596326};\\\", \\\"{x:1318,y:760,t:1511831596343};\\\", \\\"{x:1322,y:758,t:1511831596359};\\\", \\\"{x:1324,y:757,t:1511831596376};\\\", \\\"{x:1325,y:757,t:1511831596514};\\\", \\\"{x:1326,y:761,t:1511831596986};\\\", \\\"{x:1321,y:771,t:1511831597010};\\\", \\\"{x:1312,y:784,t:1511831597026};\\\", \\\"{x:1305,y:794,t:1511831597043};\\\", \\\"{x:1301,y:802,t:1511831597060};\\\", \\\"{x:1296,y:810,t:1511831597076};\\\", \\\"{x:1295,y:812,t:1511831597094};\\\", \\\"{x:1294,y:812,t:1511831597138};\\\", \\\"{x:1294,y:815,t:1511831597162};\\\", \\\"{x:1293,y:817,t:1511831597176};\\\", \\\"{x:1291,y:823,t:1511831597193};\\\", \\\"{x:1286,y:832,t:1511831597210};\\\", \\\"{x:1283,y:836,t:1511831597226};\\\", \\\"{x:1279,y:840,t:1511831597243};\\\", \\\"{x:1277,y:843,t:1511831597260};\\\", \\\"{x:1274,y:848,t:1511831597276};\\\", \\\"{x:1271,y:851,t:1511831597293};\\\", \\\"{x:1269,y:852,t:1511831597310};\\\", \\\"{x:1269,y:849,t:1511831597378};\\\", \\\"{x:1269,y:847,t:1511831597393};\\\", \\\"{x:1274,y:831,t:1511831597409};\\\", \\\"{x:1286,y:819,t:1511831597426};\\\", \\\"{x:1292,y:812,t:1511831597443};\\\", \\\"{x:1298,y:805,t:1511831597460};\\\", \\\"{x:1305,y:800,t:1511831597475};\\\", \\\"{x:1308,y:796,t:1511831597492};\\\", \\\"{x:1312,y:791,t:1511831597509};\\\", \\\"{x:1315,y:784,t:1511831597525};\\\", \\\"{x:1319,y:779,t:1511831597542};\\\", \\\"{x:1325,y:772,t:1511831597559};\\\", \\\"{x:1331,y:768,t:1511831597575};\\\", \\\"{x:1334,y:767,t:1511831597593};\\\", \\\"{x:1334,y:766,t:1511831597738};\\\", \\\"{x:1334,y:765,t:1511831597746};\\\", \\\"{x:1334,y:764,t:1511831597809};\\\", \\\"{x:1334,y:762,t:1511831597827};\\\", \\\"{x:1334,y:760,t:1511831597843};\\\", \\\"{x:1334,y:759,t:1511831597860};\\\", \\\"{x:1333,y:758,t:1511831597877};\\\", \\\"{x:1332,y:757,t:1511831597894};\\\", \\\"{x:1331,y:757,t:1511831598130};\\\", \\\"{x:1330,y:757,t:1511831598143};\\\", \\\"{x:1329,y:757,t:1511831598160};\\\", \\\"{x:1327,y:757,t:1511831598177};\\\", \\\"{x:1326,y:757,t:1511831598193};\\\", \\\"{x:1324,y:757,t:1511831598402};\\\", \\\"{x:1322,y:757,t:1511831598417};\\\", \\\"{x:1321,y:757,t:1511831598427};\\\", \\\"{x:1320,y:757,t:1511831598444};\\\", \\\"{x:1318,y:758,t:1511831598460};\\\", \\\"{x:1312,y:762,t:1511831598906};\\\", \\\"{x:1302,y:766,t:1511831598914};\\\", \\\"{x:1286,y:771,t:1511831598927};\\\", \\\"{x:1243,y:779,t:1511831598944};\\\", \\\"{x:1176,y:787,t:1511831598960};\\\", \\\"{x:1078,y:791,t:1511831598977};\\\", \\\"{x:906,y:793,t:1511831598993};\\\", \\\"{x:770,y:793,t:1511831599010};\\\", \\\"{x:679,y:793,t:1511831599027};\\\", \\\"{x:640,y:793,t:1511831599043};\\\", \\\"{x:622,y:793,t:1511831599059};\\\", \\\"{x:615,y:792,t:1511831599076};\\\", \\\"{x:612,y:790,t:1511831599095};\\\", \\\"{x:608,y:788,t:1511831599110};\\\", \\\"{x:600,y:785,t:1511831599126};\\\", \\\"{x:581,y:777,t:1511831599144};\\\", \\\"{x:558,y:763,t:1511831599161};\\\", \\\"{x:535,y:751,t:1511831599176};\\\", \\\"{x:501,y:727,t:1511831599193};\\\", \\\"{x:487,y:715,t:1511831599210};\\\", \\\"{x:474,y:687,t:1511831599226};\\\", \\\"{x:461,y:669,t:1511831599243};\\\", \\\"{x:450,y:649,t:1511831599260};\\\", \\\"{x:444,y:635,t:1511831599277};\\\", \\\"{x:442,y:623,t:1511831599294};\\\", \\\"{x:441,y:616,t:1511831599311};\\\", \\\"{x:441,y:606,t:1511831599327};\\\", \\\"{x:441,y:597,t:1511831599349};\\\", \\\"{x:441,y:593,t:1511831599360};\\\", \\\"{x:441,y:590,t:1511831599376};\\\", \\\"{x:441,y:588,t:1511831599441};\\\", \\\"{x:441,y:586,t:1511831599457};\\\", \\\"{x:439,y:583,t:1511831599465};\\\", \\\"{x:435,y:579,t:1511831599476};\\\", \\\"{x:419,y:570,t:1511831599493};\\\", \\\"{x:398,y:562,t:1511831599510};\\\", \\\"{x:390,y:560,t:1511831599526};\\\", \\\"{x:389,y:560,t:1511831599543};\\\", \\\"{x:385,y:561,t:1511831599565};\\\", \\\"{x:382,y:566,t:1511831599581};\\\", \\\"{x:379,y:573,t:1511831599598};\\\", \\\"{x:379,y:575,t:1511831599615};\\\", \\\"{x:379,y:578,t:1511831599631};\\\", \\\"{x:378,y:582,t:1511831599648};\\\", \\\"{x:378,y:589,t:1511831599664};\\\", \\\"{x:377,y:595,t:1511831599681};\\\", \\\"{x:377,y:604,t:1511831599698};\\\", \\\"{x:377,y:611,t:1511831599715};\\\", \\\"{x:377,y:613,t:1511831599731};\\\", \\\"{x:377,y:614,t:1511831599748};\\\", \\\"{x:377,y:615,t:1511831599785};\\\", \\\"{x:376,y:616,t:1511831599798};\\\", \\\"{x:371,y:616,t:1511831599815};\\\", \\\"{x:358,y:616,t:1511831599832};\\\", \\\"{x:337,y:616,t:1511831599849};\\\", \\\"{x:298,y:616,t:1511831599865};\\\", \\\"{x:284,y:616,t:1511831599882};\\\", \\\"{x:281,y:617,t:1511831599901};\\\", \\\"{x:281,y:615,t:1511831599944};\\\", \\\"{x:281,y:614,t:1511831599952};\\\", \\\"{x:281,y:611,t:1511831599967};\\\", \\\"{x:283,y:607,t:1511831599984};\\\", \\\"{x:283,y:605,t:1511831600001};\\\", \\\"{x:283,y:604,t:1511831600081};\\\", \\\"{x:282,y:599,t:1511831600089};\\\", \\\"{x:276,y:597,t:1511831600100};\\\", \\\"{x:257,y:590,t:1511831600117};\\\", \\\"{x:232,y:582,t:1511831600134};\\\", \\\"{x:189,y:575,t:1511831600151};\\\", \\\"{x:152,y:573,t:1511831600167};\\\", \\\"{x:133,y:573,t:1511831600184};\\\", \\\"{x:128,y:573,t:1511831600201};\\\", \\\"{x:132,y:573,t:1511831600273};\\\", \\\"{x:137,y:572,t:1511831600284};\\\", \\\"{x:145,y:572,t:1511831600300};\\\", \\\"{x:148,y:572,t:1511831600318};\\\", \\\"{x:150,y:572,t:1511831600333};\\\", \\\"{x:152,y:573,t:1511831600350};\\\", \\\"{x:152,y:574,t:1511831600367};\\\", \\\"{x:154,y:576,t:1511831600384};\\\", \\\"{x:155,y:579,t:1511831600400};\\\", \\\"{x:160,y:590,t:1511831600417};\\\", \\\"{x:167,y:596,t:1511831600433};\\\", \\\"{x:170,y:598,t:1511831600450};\\\", \\\"{x:171,y:599,t:1511831600467};\\\", \\\"{x:172,y:599,t:1511831600554};\\\", \\\"{x:173,y:599,t:1511831600567};\\\", \\\"{x:174,y:597,t:1511831600583};\\\", \\\"{x:176,y:596,t:1511831600600};\\\", \\\"{x:177,y:596,t:1511831600617};\\\", \\\"{x:177,y:593,t:1511831600722};\\\", \\\"{x:177,y:592,t:1511831600737};\\\", \\\"{x:177,y:589,t:1511831600751};\\\", \\\"{x:178,y:586,t:1511831600768};\\\", \\\"{x:180,y:583,t:1511831600784};\\\", \\\"{x:183,y:582,t:1511831601000};\\\", \\\"{x:190,y:582,t:1511831601008};\\\", \\\"{x:200,y:585,t:1511831601019};\\\", \\\"{x:233,y:596,t:1511831601036};\\\", \\\"{x:289,y:606,t:1511831601052};\\\", \\\"{x:330,y:614,t:1511831601069};\\\", \\\"{x:343,y:616,t:1511831601086};\\\", \\\"{x:344,y:617,t:1511831601102};\\\", \\\"{x:345,y:616,t:1511831601234};\\\", \\\"{x:344,y:612,t:1511831601241};\\\", \\\"{x:342,y:608,t:1511831601252};\\\", \\\"{x:330,y:598,t:1511831601269};\\\", \\\"{x:322,y:595,t:1511831601286};\\\", \\\"{x:319,y:592,t:1511831601302};\\\", \\\"{x:317,y:591,t:1511831601319};\\\", \\\"{x:315,y:590,t:1511831601336};\\\", \\\"{x:314,y:590,t:1511831601353};\\\", \\\"{x:313,y:590,t:1511831601409};\\\", \\\"{x:311,y:588,t:1511831601419};\\\", \\\"{x:310,y:587,t:1511831601436};\\\", \\\"{x:308,y:586,t:1511831601453};\\\", \\\"{x:307,y:586,t:1511831601489};\\\", \\\"{x:305,y:586,t:1511831601503};\\\", \\\"{x:304,y:586,t:1511831601519};\\\", \\\"{x:301,y:586,t:1511831601536};\\\", \\\"{x:298,y:586,t:1511831601553};\\\", \\\"{x:297,y:586,t:1511831601569};\\\", \\\"{x:296,y:587,t:1511831601586};\\\", \\\"{x:294,y:587,t:1511831601603};\\\", \\\"{x:292,y:588,t:1511831601657};\\\", \\\"{x:291,y:588,t:1511831601856};\\\", \\\"{x:292,y:597,t:1511831601872};\\\", \\\"{x:298,y:610,t:1511831601886};\\\", \\\"{x:308,y:630,t:1511831601903};\\\", \\\"{x:325,y:650,t:1511831601920};\\\", \\\"{x:338,y:667,t:1511831601936};\\\", \\\"{x:358,y:685,t:1511831601953};\\\", \\\"{x:368,y:692,t:1511831601970};\\\", \\\"{x:373,y:695,t:1511831601986};\\\", \\\"{x:375,y:696,t:1511831602009};\\\", \\\"{x:376,y:696,t:1511831602336};\\\", \\\"{x:376,y:695,t:1511831602352};\\\", \\\"{x:377,y:692,t:1511831603465};\\\", \\\"{x:387,y:684,t:1511831603473};\\\", \\\"{x:400,y:672,t:1511831603488};\\\", \\\"{x:435,y:635,t:1511831603504};\\\", \\\"{x:492,y:586,t:1511831603521};\\\", \\\"{x:535,y:553,t:1511831603538};\\\", \\\"{x:571,y:529,t:1511831603554};\\\", \\\"{x:590,y:518,t:1511831603571};\\\", \\\"{x:609,y:512,t:1511831603587};\\\", \\\"{x:621,y:507,t:1511831603604};\\\", \\\"{x:626,y:506,t:1511831603621};\\\", \\\"{x:629,y:504,t:1511831603638};\\\", \\\"{x:630,y:504,t:1511831603654};\\\", \\\"{x:631,y:503,t:1511831603688};\\\", \\\"{x:634,y:502,t:1511831603704};\\\", \\\"{x:647,y:498,t:1511831603721};\\\", \\\"{x:668,y:495,t:1511831603738};\\\" ] }, { \\\"rt\\\": 45480, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 442555, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-B -B -B -B -B -B -B -B -F -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:728,y:482,t:1511831603920};\\\", \\\"{x:729,y:480,t:1511831604296};\\\", \\\"{x:728,y:479,t:1511831604384};\\\", \\\"{x:720,y:479,t:1511831604392};\\\", \\\"{x:717,y:479,t:1511831604405};\\\", \\\"{x:709,y:479,t:1511831604422};\\\", \\\"{x:711,y:480,t:1511831604472};\\\", \\\"{x:713,y:480,t:1511831604488};\\\", \\\"{x:742,y:485,t:1511831604505};\\\", \\\"{x:761,y:489,t:1511831604522};\\\", \\\"{x:777,y:498,t:1511831604538};\\\", \\\"{x:791,y:503,t:1511831604555};\\\", \\\"{x:800,y:503,t:1511831604572};\\\", \\\"{x:804,y:504,t:1511831604588};\\\", \\\"{x:808,y:504,t:1511831604605};\\\", \\\"{x:810,y:504,t:1511831604622};\\\", \\\"{x:811,y:504,t:1511831604638};\\\", \\\"{x:812,y:504,t:1511831604655};\\\", \\\"{x:813,y:503,t:1511831604672};\\\", \\\"{x:812,y:503,t:1511831604745};\\\", \\\"{x:810,y:503,t:1511831604761};\\\", \\\"{x:808,y:503,t:1511831604773};\\\", \\\"{x:799,y:503,t:1511831604789};\\\", \\\"{x:792,y:503,t:1511831604806};\\\", \\\"{x:777,y:503,t:1511831604823};\\\", \\\"{x:758,y:501,t:1511831604839};\\\", \\\"{x:738,y:501,t:1511831604855};\\\", \\\"{x:712,y:501,t:1511831604873};\\\", \\\"{x:697,y:504,t:1511831604889};\\\", \\\"{x:687,y:508,t:1511831604905};\\\", \\\"{x:683,y:509,t:1511831604922};\\\", \\\"{x:681,y:509,t:1511831604940};\\\", \\\"{x:681,y:511,t:1511831604955};\\\", \\\"{x:681,y:512,t:1511831604972};\\\", \\\"{x:681,y:514,t:1511831604990};\\\", \\\"{x:681,y:515,t:1511831605005};\\\", \\\"{x:681,y:517,t:1511831605022};\\\", \\\"{x:685,y:517,t:1511831607993};\\\", \\\"{x:694,y:517,t:1511831608008};\\\", \\\"{x:731,y:517,t:1511831608025};\\\", \\\"{x:773,y:517,t:1511831608041};\\\", \\\"{x:801,y:517,t:1511831608058};\\\", \\\"{x:819,y:519,t:1511831608075};\\\", \\\"{x:825,y:520,t:1511831608091};\\\", \\\"{x:826,y:521,t:1511831608108};\\\", \\\"{x:827,y:521,t:1511831608193};\\\", \\\"{x:829,y:521,t:1511831608209};\\\", \\\"{x:831,y:521,t:1511831608225};\\\", \\\"{x:833,y:521,t:1511831608242};\\\", \\\"{x:835,y:520,t:1511831608259};\\\", \\\"{x:836,y:520,t:1511831608275};\\\", \\\"{x:837,y:519,t:1511831608292};\\\", \\\"{x:839,y:515,t:1511831608309};\\\", \\\"{x:841,y:513,t:1511831608325};\\\", \\\"{x:845,y:509,t:1511831608342};\\\", \\\"{x:851,y:505,t:1511831608359};\\\", \\\"{x:855,y:501,t:1511831608375};\\\", \\\"{x:857,y:499,t:1511831608392};\\\", \\\"{x:861,y:497,t:1511831608409};\\\", \\\"{x:862,y:496,t:1511831608425};\\\", \\\"{x:864,y:495,t:1511831608442};\\\", \\\"{x:865,y:495,t:1511831608459};\\\", \\\"{x:866,y:494,t:1511831608475};\\\", \\\"{x:867,y:494,t:1511831608492};\\\", \\\"{x:870,y:493,t:1511831616962};\\\", \\\"{x:872,y:492,t:1511831616970};\\\", \\\"{x:877,y:491,t:1511831616982};\\\", \\\"{x:880,y:489,t:1511831616999};\\\", \\\"{x:881,y:489,t:1511831617234};\\\", \\\"{x:883,y:489,t:1511831617249};\\\", \\\"{x:895,y:491,t:1511831617265};\\\", \\\"{x:905,y:494,t:1511831617281};\\\", \\\"{x:920,y:499,t:1511831617298};\\\", \\\"{x:934,y:502,t:1511831617316};\\\", \\\"{x:955,y:508,t:1511831617333};\\\", \\\"{x:979,y:513,t:1511831617349};\\\", \\\"{x:996,y:519,t:1511831617365};\\\", \\\"{x:1014,y:524,t:1511831617383};\\\", \\\"{x:1034,y:530,t:1511831617399};\\\", \\\"{x:1048,y:535,t:1511831617416};\\\", \\\"{x:1059,y:538,t:1511831617433};\\\", \\\"{x:1068,y:541,t:1511831617449};\\\", \\\"{x:1081,y:544,t:1511831617465};\\\", \\\"{x:1103,y:547,t:1511831617483};\\\", \\\"{x:1126,y:553,t:1511831617499};\\\", \\\"{x:1149,y:555,t:1511831617516};\\\", \\\"{x:1170,y:557,t:1511831617533};\\\", \\\"{x:1185,y:558,t:1511831617549};\\\", \\\"{x:1192,y:558,t:1511831617566};\\\", \\\"{x:1194,y:559,t:1511831617583};\\\", \\\"{x:1195,y:559,t:1511831617599};\\\", \\\"{x:1196,y:559,t:1511831617738};\\\", \\\"{x:1196,y:558,t:1511831617749};\\\", \\\"{x:1193,y:555,t:1511831617766};\\\", \\\"{x:1182,y:552,t:1511831617783};\\\", \\\"{x:1173,y:550,t:1511831617800};\\\", \\\"{x:1172,y:550,t:1511831617850};\\\", \\\"{x:1172,y:547,t:1511831617866};\\\", \\\"{x:1183,y:541,t:1511831617883};\\\", \\\"{x:1205,y:535,t:1511831617900};\\\", \\\"{x:1239,y:528,t:1511831617916};\\\", \\\"{x:1279,y:521,t:1511831617933};\\\", \\\"{x:1335,y:514,t:1511831617950};\\\", \\\"{x:1399,y:505,t:1511831617966};\\\", \\\"{x:1460,y:497,t:1511831617983};\\\", \\\"{x:1497,y:490,t:1511831618000};\\\", \\\"{x:1523,y:485,t:1511831618016};\\\", \\\"{x:1532,y:484,t:1511831618033};\\\", \\\"{x:1529,y:485,t:1511831618114};\\\", \\\"{x:1528,y:486,t:1511831618121};\\\", \\\"{x:1526,y:486,t:1511831618133};\\\", \\\"{x:1525,y:486,t:1511831618150};\\\", \\\"{x:1523,y:487,t:1511831618166};\\\", \\\"{x:1520,y:487,t:1511831618183};\\\", \\\"{x:1514,y:490,t:1511831618200};\\\", \\\"{x:1506,y:494,t:1511831618216};\\\", \\\"{x:1497,y:498,t:1511831618233};\\\", \\\"{x:1476,y:508,t:1511831618249};\\\", \\\"{x:1464,y:516,t:1511831618267};\\\", \\\"{x:1454,y:524,t:1511831618283};\\\", \\\"{x:1447,y:528,t:1511831618300};\\\", \\\"{x:1446,y:529,t:1511831618317};\\\", \\\"{x:1446,y:530,t:1511831618333};\\\", \\\"{x:1445,y:531,t:1511831618350};\\\", \\\"{x:1443,y:534,t:1511831618367};\\\", \\\"{x:1438,y:541,t:1511831618383};\\\", \\\"{x:1431,y:553,t:1511831618400};\\\", \\\"{x:1420,y:566,t:1511831618417};\\\", \\\"{x:1405,y:580,t:1511831618433};\\\", \\\"{x:1378,y:606,t:1511831618449};\\\", \\\"{x:1364,y:620,t:1511831618467};\\\", \\\"{x:1355,y:627,t:1511831618483};\\\", \\\"{x:1350,y:630,t:1511831618500};\\\", \\\"{x:1347,y:633,t:1511831618517};\\\", \\\"{x:1339,y:637,t:1511831618533};\\\", \\\"{x:1333,y:641,t:1511831618550};\\\", \\\"{x:1327,y:648,t:1511831618567};\\\", \\\"{x:1318,y:658,t:1511831618583};\\\", \\\"{x:1306,y:672,t:1511831618600};\\\", \\\"{x:1297,y:683,t:1511831618617};\\\", \\\"{x:1290,y:694,t:1511831618633};\\\", \\\"{x:1282,y:711,t:1511831618650};\\\", \\\"{x:1272,y:723,t:1511831618667};\\\", \\\"{x:1262,y:736,t:1511831618683};\\\", \\\"{x:1256,y:743,t:1511831618700};\\\", \\\"{x:1247,y:753,t:1511831618717};\\\", \\\"{x:1242,y:760,t:1511831618733};\\\", \\\"{x:1236,y:767,t:1511831618750};\\\", \\\"{x:1230,y:772,t:1511831618767};\\\", \\\"{x:1219,y:780,t:1511831618784};\\\", \\\"{x:1211,y:786,t:1511831618800};\\\", \\\"{x:1206,y:790,t:1511831618817};\\\", \\\"{x:1194,y:794,t:1511831618833};\\\", \\\"{x:1189,y:795,t:1511831618850};\\\", \\\"{x:1186,y:795,t:1511831618867};\\\", \\\"{x:1182,y:795,t:1511831618884};\\\", \\\"{x:1180,y:795,t:1511831618900};\\\", \\\"{x:1179,y:795,t:1511831618921};\\\", \\\"{x:1177,y:795,t:1511831618934};\\\", \\\"{x:1173,y:792,t:1511831618950};\\\", \\\"{x:1171,y:790,t:1511831618967};\\\", \\\"{x:1169,y:787,t:1511831618984};\\\", \\\"{x:1169,y:785,t:1511831619000};\\\", \\\"{x:1166,y:778,t:1511831619017};\\\", \\\"{x:1166,y:772,t:1511831619033};\\\", \\\"{x:1166,y:768,t:1511831619050};\\\", \\\"{x:1165,y:767,t:1511831619073};\\\", \\\"{x:1163,y:764,t:1511831619162};\\\", \\\"{x:1162,y:764,t:1511831619169};\\\", \\\"{x:1160,y:764,t:1511831619186};\\\", \\\"{x:1157,y:762,t:1511831619200};\\\", \\\"{x:1155,y:760,t:1511831619216};\\\", \\\"{x:1154,y:760,t:1511831619256};\\\", \\\"{x:1153,y:760,t:1511831619266};\\\", \\\"{x:1151,y:759,t:1511831619283};\\\", \\\"{x:1150,y:758,t:1511831619300};\\\", \\\"{x:1149,y:758,t:1511831619345};\\\", \\\"{x:1148,y:758,t:1511831619361};\\\", \\\"{x:1147,y:758,t:1511831619377};\\\", \\\"{x:1147,y:759,t:1511831619698};\\\", \\\"{x:1147,y:760,t:1511831619705};\\\", \\\"{x:1147,y:761,t:1511831619721};\\\", \\\"{x:1147,y:763,t:1511831619970};\\\", \\\"{x:1149,y:765,t:1511831620001};\\\", \\\"{x:1150,y:765,t:1511831620074};\\\", \\\"{x:1151,y:765,t:1511831620089};\\\", \\\"{x:1152,y:764,t:1511831620216};\\\", \\\"{x:1153,y:760,t:1511831620234};\\\", \\\"{x:1153,y:756,t:1511831620250};\\\", \\\"{x:1153,y:754,t:1511831620267};\\\", \\\"{x:1154,y:754,t:1511831620593};\\\", \\\"{x:1155,y:756,t:1511831620600};\\\", \\\"{x:1157,y:758,t:1511831620617};\\\", \\\"{x:1158,y:760,t:1511831620634};\\\", \\\"{x:1158,y:761,t:1511831621001};\\\", \\\"{x:1158,y:762,t:1511831621281};\\\", \\\"{x:1158,y:763,t:1511831621297};\\\", \\\"{x:1158,y:765,t:1511831621313};\\\", \\\"{x:1157,y:765,t:1511831621321};\\\", \\\"{x:1157,y:766,t:1511831621337};\\\", \\\"{x:1156,y:766,t:1511831621386};\\\", \\\"{x:1155,y:766,t:1511831621729};\\\", \\\"{x:1155,y:765,t:1511831624336};\\\", \\\"{x:1155,y:764,t:1511831624689};\\\", \\\"{x:1155,y:763,t:1511831624705};\\\", \\\"{x:1152,y:762,t:1511831627296};\\\", \\\"{x:1131,y:763,t:1511831627314};\\\", \\\"{x:1116,y:765,t:1511831627330};\\\", \\\"{x:1099,y:769,t:1511831627347};\\\", \\\"{x:1089,y:770,t:1511831627364};\\\", \\\"{x:1085,y:772,t:1511831627381};\\\", \\\"{x:1085,y:773,t:1511831627536};\\\", \\\"{x:1085,y:775,t:1511831627547};\\\", \\\"{x:1084,y:778,t:1511831627564};\\\", \\\"{x:1083,y:781,t:1511831627581};\\\", \\\"{x:1083,y:783,t:1511831627597};\\\", \\\"{x:1083,y:786,t:1511831627640};\\\", \\\"{x:1083,y:789,t:1511831627648};\\\", \\\"{x:1084,y:795,t:1511831627664};\\\", \\\"{x:1087,y:799,t:1511831627680};\\\", \\\"{x:1090,y:802,t:1511831627697};\\\", \\\"{x:1094,y:806,t:1511831627714};\\\", \\\"{x:1096,y:807,t:1511831627731};\\\", \\\"{x:1099,y:807,t:1511831627792};\\\", \\\"{x:1103,y:807,t:1511831627800};\\\", \\\"{x:1108,y:807,t:1511831627814};\\\", \\\"{x:1122,y:806,t:1511831627831};\\\", \\\"{x:1136,y:802,t:1511831627848};\\\", \\\"{x:1139,y:801,t:1511831627864};\\\", \\\"{x:1139,y:800,t:1511831627880};\\\", \\\"{x:1138,y:800,t:1511831627968};\\\", \\\"{x:1136,y:800,t:1511831627981};\\\", \\\"{x:1134,y:802,t:1511831627998};\\\", \\\"{x:1133,y:804,t:1511831628014};\\\", \\\"{x:1132,y:806,t:1511831628031};\\\", \\\"{x:1132,y:807,t:1511831628048};\\\", \\\"{x:1132,y:808,t:1511831628072};\\\", \\\"{x:1133,y:808,t:1511831628096};\\\", \\\"{x:1134,y:808,t:1511831628104};\\\", \\\"{x:1136,y:808,t:1511831628114};\\\", \\\"{x:1137,y:805,t:1511831628131};\\\", \\\"{x:1139,y:802,t:1511831628148};\\\", \\\"{x:1141,y:796,t:1511831628164};\\\", \\\"{x:1141,y:792,t:1511831628181};\\\", \\\"{x:1141,y:786,t:1511831628198};\\\", \\\"{x:1141,y:780,t:1511831628214};\\\", \\\"{x:1140,y:779,t:1511831628231};\\\", \\\"{x:1139,y:778,t:1511831628248};\\\", \\\"{x:1138,y:778,t:1511831628280};\\\", \\\"{x:1135,y:782,t:1511831628298};\\\", \\\"{x:1132,y:788,t:1511831628315};\\\", \\\"{x:1132,y:792,t:1511831628331};\\\", \\\"{x:1131,y:795,t:1511831628348};\\\", \\\"{x:1131,y:796,t:1511831628365};\\\", \\\"{x:1131,y:797,t:1511831628392};\\\", \\\"{x:1131,y:798,t:1511831628408};\\\", \\\"{x:1131,y:799,t:1511831628416};\\\", \\\"{x:1131,y:800,t:1511831628431};\\\", \\\"{x:1132,y:803,t:1511831628448};\\\", \\\"{x:1135,y:804,t:1511831628464};\\\", \\\"{x:1137,y:805,t:1511831628481};\\\", \\\"{x:1138,y:805,t:1511831628504};\\\", \\\"{x:1141,y:805,t:1511831628552};\\\", \\\"{x:1143,y:803,t:1511831628565};\\\", \\\"{x:1146,y:800,t:1511831628581};\\\", \\\"{x:1149,y:796,t:1511831628598};\\\", \\\"{x:1149,y:795,t:1511831628615};\\\", \\\"{x:1150,y:794,t:1511831628631};\\\", \\\"{x:1150,y:793,t:1511831628720};\\\", \\\"{x:1150,y:792,t:1511831628731};\\\", \\\"{x:1150,y:791,t:1511831628748};\\\", \\\"{x:1150,y:790,t:1511831628765};\\\", \\\"{x:1150,y:789,t:1511831628784};\\\", \\\"{x:1150,y:788,t:1511831628912};\\\", \\\"{x:1150,y:787,t:1511831630888};\\\", \\\"{x:1148,y:787,t:1511831630912};\\\", \\\"{x:1147,y:787,t:1511831630920};\\\", \\\"{x:1146,y:787,t:1511831630933};\\\", \\\"{x:1145,y:787,t:1511831630950};\\\", \\\"{x:1143,y:787,t:1511831631168};\\\", \\\"{x:1138,y:787,t:1511831631183};\\\", \\\"{x:1125,y:783,t:1511831631199};\\\", \\\"{x:1120,y:782,t:1511831631216};\\\", \\\"{x:1116,y:779,t:1511831631233};\\\", \\\"{x:1113,y:777,t:1511831631250};\\\", \\\"{x:1113,y:776,t:1511831631267};\\\", \\\"{x:1112,y:775,t:1511831631288};\\\", \\\"{x:1110,y:774,t:1511831631312};\\\", \\\"{x:1109,y:773,t:1511831631320};\\\", \\\"{x:1107,y:772,t:1511831631333};\\\", \\\"{x:1103,y:772,t:1511831631350};\\\", \\\"{x:1100,y:771,t:1511831631367};\\\", \\\"{x:1096,y:771,t:1511831631383};\\\", \\\"{x:1091,y:770,t:1511831631399};\\\", \\\"{x:1090,y:769,t:1511831631416};\\\", \\\"{x:1089,y:769,t:1511831631433};\\\", \\\"{x:1088,y:769,t:1511831631520};\\\", \\\"{x:1087,y:768,t:1511831631533};\\\", \\\"{x:1091,y:767,t:1511831631688};\\\", \\\"{x:1096,y:765,t:1511831631700};\\\", \\\"{x:1106,y:761,t:1511831631717};\\\", \\\"{x:1120,y:759,t:1511831631734};\\\", \\\"{x:1136,y:757,t:1511831631750};\\\", \\\"{x:1146,y:757,t:1511831631767};\\\", \\\"{x:1158,y:757,t:1511831631784};\\\", \\\"{x:1167,y:757,t:1511831631800};\\\", \\\"{x:1173,y:757,t:1511831631817};\\\", \\\"{x:1174,y:757,t:1511831631944};\\\", \\\"{x:1173,y:759,t:1511831631952};\\\", \\\"{x:1171,y:760,t:1511831631967};\\\", \\\"{x:1166,y:761,t:1511831631984};\\\", \\\"{x:1163,y:762,t:1511831632000};\\\", \\\"{x:1162,y:763,t:1511831632017};\\\", \\\"{x:1161,y:763,t:1511831632056};\\\", \\\"{x:1160,y:763,t:1511831632067};\\\", \\\"{x:1157,y:763,t:1511831632084};\\\", \\\"{x:1154,y:764,t:1511831632100};\\\", \\\"{x:1153,y:764,t:1511831632117};\\\", \\\"{x:1152,y:764,t:1511831632135};\\\", \\\"{x:1151,y:764,t:1511831632184};\\\", \\\"{x:1150,y:764,t:1511831632208};\\\", \\\"{x:1149,y:765,t:1511831632217};\\\", \\\"{x:1148,y:766,t:1511831632234};\\\", \\\"{x:1147,y:766,t:1511831632367};\\\", \\\"{x:1148,y:765,t:1511831632800};\\\", \\\"{x:1150,y:765,t:1511831632818};\\\", \\\"{x:1151,y:763,t:1511831632968};\\\", \\\"{x:1151,y:760,t:1511831632983};\\\", \\\"{x:1152,y:758,t:1511831633001};\\\", \\\"{x:1153,y:757,t:1511831633392};\\\", \\\"{x:1153,y:756,t:1511831633415};\\\", \\\"{x:1153,y:752,t:1511831633423};\\\", \\\"{x:1154,y:750,t:1511831633435};\\\", \\\"{x:1154,y:744,t:1511831633450};\\\", \\\"{x:1156,y:739,t:1511831633468};\\\", \\\"{x:1158,y:733,t:1511831633485};\\\", \\\"{x:1160,y:729,t:1511831633501};\\\", \\\"{x:1160,y:726,t:1511831633518};\\\", \\\"{x:1161,y:722,t:1511831633535};\\\", \\\"{x:1161,y:719,t:1511831633551};\\\", \\\"{x:1161,y:713,t:1511831633567};\\\", \\\"{x:1161,y:709,t:1511831633585};\\\", \\\"{x:1161,y:705,t:1511831633602};\\\", \\\"{x:1161,y:701,t:1511831633618};\\\", \\\"{x:1158,y:699,t:1511831633634};\\\", \\\"{x:1156,y:697,t:1511831633651};\\\", \\\"{x:1154,y:694,t:1511831633667};\\\", \\\"{x:1153,y:693,t:1511831633684};\\\", \\\"{x:1150,y:691,t:1511831633701};\\\", \\\"{x:1149,y:691,t:1511831633717};\\\", \\\"{x:1145,y:690,t:1511831633734};\\\", \\\"{x:1140,y:689,t:1511831633750};\\\", \\\"{x:1136,y:689,t:1511831633767};\\\", \\\"{x:1130,y:689,t:1511831633784};\\\", \\\"{x:1127,y:689,t:1511831633801};\\\", \\\"{x:1122,y:689,t:1511831633817};\\\", \\\"{x:1119,y:689,t:1511831633834};\\\", \\\"{x:1114,y:691,t:1511831633851};\\\", \\\"{x:1109,y:692,t:1511831633867};\\\", \\\"{x:1104,y:695,t:1511831633884};\\\", \\\"{x:1100,y:697,t:1511831633901};\\\", \\\"{x:1098,y:699,t:1511831633917};\\\", \\\"{x:1095,y:700,t:1511831633934};\\\", \\\"{x:1094,y:701,t:1511831633951};\\\", \\\"{x:1092,y:703,t:1511831633967};\\\", \\\"{x:1088,y:706,t:1511831633984};\\\", \\\"{x:1085,y:707,t:1511831634001};\\\", \\\"{x:1080,y:709,t:1511831634017};\\\", \\\"{x:1075,y:711,t:1511831634035};\\\", \\\"{x:1072,y:713,t:1511831634052};\\\", \\\"{x:1069,y:714,t:1511831634067};\\\", \\\"{x:1068,y:714,t:1511831634084};\\\", \\\"{x:1067,y:714,t:1511831634184};\\\", \\\"{x:1067,y:715,t:1511831634202};\\\", \\\"{x:1067,y:716,t:1511831634304};\\\", \\\"{x:1066,y:717,t:1511831634319};\\\", \\\"{x:1064,y:717,t:1511831634335};\\\", \\\"{x:1062,y:719,t:1511831634352};\\\", \\\"{x:1060,y:720,t:1511831634369};\\\", \\\"{x:1060,y:717,t:1511831634560};\\\", \\\"{x:1060,y:711,t:1511831634569};\\\", \\\"{x:1067,y:700,t:1511831634586};\\\", \\\"{x:1072,y:688,t:1511831634602};\\\", \\\"{x:1074,y:677,t:1511831634619};\\\", \\\"{x:1077,y:660,t:1511831634636};\\\", \\\"{x:1078,y:650,t:1511831634652};\\\", \\\"{x:1080,y:637,t:1511831634669};\\\", \\\"{x:1085,y:618,t:1511831634686};\\\", \\\"{x:1089,y:597,t:1511831634702};\\\", \\\"{x:1093,y:576,t:1511831634719};\\\", \\\"{x:1095,y:555,t:1511831634735};\\\", \\\"{x:1096,y:550,t:1511831634752};\\\", \\\"{x:1096,y:549,t:1511831634769};\\\", \\\"{x:1096,y:548,t:1511831634824};\\\", \\\"{x:1097,y:545,t:1511831634839};\\\", \\\"{x:1098,y:544,t:1511831634855};\\\", \\\"{x:1098,y:549,t:1511831634952};\\\", \\\"{x:1096,y:562,t:1511831634969};\\\", \\\"{x:1093,y:573,t:1511831634986};\\\", \\\"{x:1092,y:577,t:1511831635002};\\\", \\\"{x:1091,y:579,t:1511831635019};\\\", \\\"{x:1091,y:580,t:1511831635176};\\\", \\\"{x:1090,y:579,t:1511831635191};\\\", \\\"{x:1090,y:578,t:1511831635203};\\\", \\\"{x:1087,y:572,t:1511831635219};\\\", \\\"{x:1085,y:568,t:1511831635236};\\\", \\\"{x:1084,y:568,t:1511831635253};\\\", \\\"{x:1084,y:567,t:1511831635368};\\\", \\\"{x:1084,y:564,t:1511831635386};\\\", \\\"{x:1086,y:563,t:1511831639879};\\\", \\\"{x:1096,y:564,t:1511831639889};\\\", \\\"{x:1126,y:568,t:1511831639906};\\\", \\\"{x:1154,y:571,t:1511831639923};\\\", \\\"{x:1184,y:575,t:1511831639939};\\\", \\\"{x:1206,y:578,t:1511831639956};\\\", \\\"{x:1218,y:581,t:1511831639973};\\\", \\\"{x:1222,y:582,t:1511831639989};\\\", \\\"{x:1223,y:582,t:1511831640096};\\\", \\\"{x:1223,y:581,t:1511831640192};\\\", \\\"{x:1223,y:580,t:1511831640206};\\\", \\\"{x:1223,y:577,t:1511831640223};\\\", \\\"{x:1223,y:571,t:1511831640239};\\\", \\\"{x:1223,y:568,t:1511831640256};\\\", \\\"{x:1223,y:565,t:1511831640272};\\\", \\\"{x:1223,y:564,t:1511831640391};\\\", \\\"{x:1223,y:562,t:1511831640415};\\\", \\\"{x:1207,y:564,t:1511831647529};\\\", \\\"{x:1125,y:590,t:1511831647546};\\\", \\\"{x:1013,y:612,t:1511831647562};\\\", \\\"{x:880,y:633,t:1511831647579};\\\", \\\"{x:747,y:652,t:1511831647596};\\\", \\\"{x:652,y:654,t:1511831647612};\\\", \\\"{x:603,y:657,t:1511831647628};\\\", \\\"{x:578,y:657,t:1511831647645};\\\", \\\"{x:553,y:653,t:1511831647661};\\\", \\\"{x:530,y:647,t:1511831647678};\\\", \\\"{x:493,y:635,t:1511831647696};\\\", \\\"{x:460,y:628,t:1511831647712};\\\", \\\"{x:415,y:621,t:1511831647728};\\\", \\\"{x:378,y:616,t:1511831647746};\\\", \\\"{x:351,y:614,t:1511831647762};\\\", \\\"{x:338,y:612,t:1511831647778};\\\", \\\"{x:333,y:610,t:1511831647795};\\\", \\\"{x:332,y:609,t:1511831647811};\\\", \\\"{x:332,y:607,t:1511831647828};\\\", \\\"{x:331,y:606,t:1511831647845};\\\", \\\"{x:329,y:602,t:1511831647862};\\\", \\\"{x:326,y:595,t:1511831647879};\\\", \\\"{x:308,y:581,t:1511831647895};\\\", \\\"{x:297,y:573,t:1511831647912};\\\", \\\"{x:289,y:568,t:1511831647928};\\\", \\\"{x:284,y:566,t:1511831647945};\\\", \\\"{x:283,y:566,t:1511831647963};\\\", \\\"{x:283,y:565,t:1511831647978};\\\", \\\"{x:283,y:564,t:1511831647995};\\\", \\\"{x:283,y:563,t:1511831648012};\\\", \\\"{x:283,y:560,t:1511831648028};\\\", \\\"{x:283,y:558,t:1511831648045};\\\", \\\"{x:283,y:557,t:1511831648062};\\\", \\\"{x:283,y:556,t:1511831648096};\\\", \\\"{x:283,y:554,t:1511831648112};\\\", \\\"{x:292,y:550,t:1511831648129};\\\", \\\"{x:304,y:549,t:1511831648145};\\\", \\\"{x:313,y:549,t:1511831648162};\\\", \\\"{x:324,y:549,t:1511831648178};\\\", \\\"{x:333,y:549,t:1511831648196};\\\", \\\"{x:336,y:549,t:1511831648212};\\\", \\\"{x:338,y:549,t:1511831648280};\\\", \\\"{x:346,y:549,t:1511831648295};\\\", \\\"{x:359,y:549,t:1511831648313};\\\", \\\"{x:371,y:551,t:1511831648328};\\\", \\\"{x:376,y:551,t:1511831648345};\\\", \\\"{x:377,y:552,t:1511831648362};\\\", \\\"{x:378,y:552,t:1511831648416};\\\", \\\"{x:382,y:554,t:1511831648429};\\\", \\\"{x:393,y:561,t:1511831648445};\\\", \\\"{x:397,y:564,t:1511831648464};\\\", \\\"{x:399,y:564,t:1511831648479};\\\", \\\"{x:400,y:564,t:1511831648583};\\\", \\\"{x:401,y:564,t:1511831648599};\\\", \\\"{x:402,y:564,t:1511831648711};\\\", \\\"{x:402,y:563,t:1511831648719};\\\", \\\"{x:403,y:563,t:1511831648735};\\\", \\\"{x:403,y:568,t:1511831648935};\\\", \\\"{x:403,y:579,t:1511831648949};\\\", \\\"{x:403,y:599,t:1511831648966};\\\", \\\"{x:403,y:615,t:1511831648983};\\\", \\\"{x:405,y:622,t:1511831648999};\\\", \\\"{x:405,y:629,t:1511831649016};\\\", \\\"{x:407,y:637,t:1511831649033};\\\", \\\"{x:410,y:644,t:1511831649049};\\\", \\\"{x:411,y:649,t:1511831649066};\\\", \\\"{x:412,y:657,t:1511831649083};\\\", \\\"{x:412,y:667,t:1511831649099};\\\", \\\"{x:412,y:677,t:1511831649117};\\\", \\\"{x:412,y:683,t:1511831649133};\\\", \\\"{x:412,y:684,t:1511831649149};\\\", \\\"{x:412,y:685,t:1511831649166};\\\", \\\"{x:413,y:686,t:1511831649832};\\\", \\\"{x:416,y:684,t:1511831649839};\\\", \\\"{x:419,y:678,t:1511831649850};\\\", \\\"{x:423,y:674,t:1511831649867};\\\", \\\"{x:424,y:673,t:1511831649883};\\\", \\\"{x:426,y:672,t:1511831649968};\\\", \\\"{x:428,y:670,t:1511831649983};\\\", \\\"{x:433,y:665,t:1511831650000};\\\", \\\"{x:437,y:660,t:1511831650017};\\\", \\\"{x:440,y:657,t:1511831650033};\\\", \\\"{x:440,y:656,t:1511831650050};\\\", \\\"{x:442,y:654,t:1511831650067};\\\", \\\"{x:443,y:652,t:1511831650083};\\\", \\\"{x:446,y:651,t:1511831650100};\\\", \\\"{x:455,y:645,t:1511831650117};\\\", \\\"{x:469,y:636,t:1511831650134};\\\", \\\"{x:483,y:623,t:1511831650151};\\\", \\\"{x:504,y:598,t:1511831650167};\\\", \\\"{x:512,y:587,t:1511831650184};\\\", \\\"{x:519,y:575,t:1511831650200};\\\", \\\"{x:524,y:561,t:1511831650217};\\\", \\\"{x:529,y:547,t:1511831650234};\\\", \\\"{x:530,y:541,t:1511831650250};\\\", \\\"{x:534,y:528,t:1511831650267};\\\", \\\"{x:535,y:511,t:1511831650284};\\\", \\\"{x:537,y:487,t:1511831650300};\\\", \\\"{x:537,y:455,t:1511831650317};\\\", \\\"{x:531,y:415,t:1511831650335};\\\", \\\"{x:528,y:395,t:1511831650351};\\\", \\\"{x:510,y:360,t:1511831650367};\\\", \\\"{x:485,y:326,t:1511831650384};\\\", \\\"{x:470,y:307,t:1511831650400};\\\", \\\"{x:463,y:300,t:1511831650417};\\\", \\\"{x:459,y:296,t:1511831650434};\\\", \\\"{x:458,y:296,t:1511831650450};\\\" ] }, { \\\"rt\\\": 16210, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 460107, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -O -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:462,y:301,t:1511831653616};\\\", \\\"{x:468,y:307,t:1511831653623};\\\", \\\"{x:473,y:312,t:1511831653636};\\\", \\\"{x:486,y:324,t:1511831653653};\\\", \\\"{x:504,y:338,t:1511831653669};\\\", \\\"{x:519,y:351,t:1511831653686};\\\", \\\"{x:538,y:371,t:1511831653703};\\\", \\\"{x:549,y:390,t:1511831653719};\\\", \\\"{x:555,y:410,t:1511831653736};\\\", \\\"{x:562,y:434,t:1511831653753};\\\", \\\"{x:577,y:473,t:1511831653769};\\\", \\\"{x:587,y:511,t:1511831653786};\\\", \\\"{x:599,y:539,t:1511831653803};\\\", \\\"{x:618,y:580,t:1511831653823};\\\", \\\"{x:623,y:596,t:1511831653836};\\\", \\\"{x:632,y:619,t:1511831653853};\\\", \\\"{x:639,y:644,t:1511831653870};\\\", \\\"{x:641,y:664,t:1511831653886};\\\", \\\"{x:650,y:690,t:1511831653903};\\\", \\\"{x:654,y:704,t:1511831653920};\\\", \\\"{x:656,y:710,t:1511831653936};\\\", \\\"{x:660,y:715,t:1511831653953};\\\", \\\"{x:666,y:720,t:1511831653970};\\\", \\\"{x:672,y:723,t:1511831653986};\\\", \\\"{x:677,y:725,t:1511831654003};\\\", \\\"{x:679,y:726,t:1511831654020};\\\", \\\"{x:680,y:727,t:1511831654036};\\\", \\\"{x:681,y:727,t:1511831654095};\\\", \\\"{x:682,y:729,t:1511831654103};\\\", \\\"{x:682,y:730,t:1511831654127};\\\", \\\"{x:683,y:730,t:1511831654137};\\\", \\\"{x:685,y:731,t:1511831654153};\\\", \\\"{x:694,y:731,t:1511831654170};\\\", \\\"{x:705,y:731,t:1511831654187};\\\", \\\"{x:720,y:731,t:1511831654203};\\\", \\\"{x:740,y:726,t:1511831654220};\\\", \\\"{x:771,y:716,t:1511831654237};\\\", \\\"{x:823,y:705,t:1511831654254};\\\", \\\"{x:873,y:697,t:1511831654271};\\\", \\\"{x:907,y:692,t:1511831654287};\\\", \\\"{x:943,y:686,t:1511831654303};\\\", \\\"{x:964,y:682,t:1511831654321};\\\", \\\"{x:986,y:675,t:1511831654337};\\\", \\\"{x:1015,y:666,t:1511831654354};\\\", \\\"{x:1066,y:648,t:1511831654371};\\\", \\\"{x:1143,y:616,t:1511831654388};\\\", \\\"{x:1235,y:587,t:1511831654404};\\\", \\\"{x:1322,y:570,t:1511831654423};\\\", \\\"{x:1372,y:564,t:1511831654437};\\\", \\\"{x:1402,y:562,t:1511831654455};\\\", \\\"{x:1406,y:562,t:1511831654470};\\\", \\\"{x:1413,y:562,t:1511831654486};\\\", \\\"{x:1415,y:562,t:1511831654503};\\\", \\\"{x:1420,y:562,t:1511831654520};\\\", \\\"{x:1428,y:562,t:1511831654537};\\\", \\\"{x:1448,y:562,t:1511831654553};\\\", \\\"{x:1483,y:572,t:1511831654570};\\\", \\\"{x:1516,y:585,t:1511831654587};\\\", \\\"{x:1529,y:594,t:1511831654603};\\\", \\\"{x:1537,y:607,t:1511831654620};\\\", \\\"{x:1542,y:617,t:1511831654637};\\\", \\\"{x:1545,y:622,t:1511831654653};\\\", \\\"{x:1545,y:623,t:1511831654670};\\\", \\\"{x:1545,y:624,t:1511831654703};\\\", \\\"{x:1545,y:635,t:1511831654721};\\\", \\\"{x:1540,y:647,t:1511831654738};\\\", \\\"{x:1532,y:663,t:1511831654754};\\\", \\\"{x:1520,y:679,t:1511831654771};\\\", \\\"{x:1507,y:700,t:1511831654788};\\\", \\\"{x:1493,y:719,t:1511831654804};\\\", \\\"{x:1484,y:730,t:1511831654820};\\\", \\\"{x:1480,y:734,t:1511831654837};\\\", \\\"{x:1479,y:735,t:1511831654853};\\\", \\\"{x:1477,y:737,t:1511831654870};\\\", \\\"{x:1475,y:739,t:1511831654903};\\\", \\\"{x:1475,y:740,t:1511831654911};\\\", \\\"{x:1474,y:741,t:1511831654927};\\\", \\\"{x:1474,y:742,t:1511831654938};\\\", \\\"{x:1473,y:743,t:1511831654955};\\\", \\\"{x:1471,y:745,t:1511831654971};\\\", \\\"{x:1468,y:750,t:1511831654988};\\\", \\\"{x:1464,y:753,t:1511831655005};\\\", \\\"{x:1461,y:756,t:1511831655021};\\\", \\\"{x:1459,y:758,t:1511831655038};\\\", \\\"{x:1456,y:760,t:1511831655055};\\\", \\\"{x:1454,y:761,t:1511831655071};\\\", \\\"{x:1453,y:761,t:1511831655088};\\\", \\\"{x:1451,y:761,t:1511831655105};\\\", \\\"{x:1450,y:761,t:1511831655168};\\\", \\\"{x:1448,y:761,t:1511831655175};\\\", \\\"{x:1446,y:761,t:1511831655188};\\\", \\\"{x:1438,y:761,t:1511831655205};\\\", \\\"{x:1430,y:762,t:1511831655221};\\\", \\\"{x:1422,y:762,t:1511831655238};\\\", \\\"{x:1416,y:762,t:1511831655255};\\\", \\\"{x:1410,y:762,t:1511831655271};\\\", \\\"{x:1407,y:762,t:1511831655288};\\\", \\\"{x:1406,y:762,t:1511831655305};\\\", \\\"{x:1399,y:757,t:1511831655536};\\\", \\\"{x:1379,y:753,t:1511831655543};\\\", \\\"{x:1353,y:748,t:1511831655554};\\\", \\\"{x:1302,y:748,t:1511831655571};\\\", \\\"{x:1271,y:758,t:1511831655587};\\\", \\\"{x:1247,y:764,t:1511831655604};\\\", \\\"{x:1233,y:768,t:1511831655621};\\\", \\\"{x:1227,y:772,t:1511831655637};\\\", \\\"{x:1226,y:773,t:1511831655663};\\\", \\\"{x:1225,y:774,t:1511831655671};\\\", \\\"{x:1225,y:776,t:1511831655687};\\\", \\\"{x:1219,y:780,t:1511831655704};\\\", \\\"{x:1205,y:787,t:1511831655721};\\\", \\\"{x:1196,y:792,t:1511831655737};\\\", \\\"{x:1194,y:793,t:1511831655754};\\\", \\\"{x:1193,y:793,t:1511831655771};\\\", \\\"{x:1191,y:793,t:1511831655832};\\\", \\\"{x:1190,y:792,t:1511831655839};\\\", \\\"{x:1187,y:790,t:1511831655854};\\\", \\\"{x:1181,y:784,t:1511831655871};\\\", \\\"{x:1169,y:781,t:1511831655889};\\\", \\\"{x:1162,y:780,t:1511831655905};\\\", \\\"{x:1160,y:779,t:1511831655921};\\\", \\\"{x:1159,y:778,t:1511831655976};\\\", \\\"{x:1159,y:777,t:1511831655989};\\\", \\\"{x:1159,y:775,t:1511831656005};\\\", \\\"{x:1159,y:773,t:1511831656022};\\\", \\\"{x:1159,y:772,t:1511831656039};\\\", \\\"{x:1159,y:770,t:1511831656055};\\\", \\\"{x:1161,y:766,t:1511831656074};\\\", \\\"{x:1161,y:765,t:1511831656088};\\\", \\\"{x:1162,y:764,t:1511831656104};\\\", \\\"{x:1163,y:762,t:1511831656121};\\\", \\\"{x:1163,y:761,t:1511831656158};\\\", \\\"{x:1161,y:761,t:1511831656600};\\\", \\\"{x:1156,y:761,t:1511831656622};\\\", \\\"{x:1152,y:760,t:1511831656639};\\\", \\\"{x:1150,y:760,t:1511831656656};\\\", \\\"{x:1149,y:759,t:1511831656776};\\\", \\\"{x:1150,y:759,t:1511831657560};\\\", \\\"{x:1154,y:758,t:1511831657573};\\\", \\\"{x:1162,y:758,t:1511831657590};\\\", \\\"{x:1175,y:758,t:1511831657606};\\\", \\\"{x:1187,y:758,t:1511831657623};\\\", \\\"{x:1198,y:758,t:1511831657639};\\\", \\\"{x:1201,y:757,t:1511831657656};\\\", \\\"{x:1202,y:757,t:1511831657703};\\\", \\\"{x:1205,y:756,t:1511831657711};\\\", \\\"{x:1209,y:756,t:1511831657727};\\\", \\\"{x:1213,y:756,t:1511831657740};\\\", \\\"{x:1224,y:756,t:1511831657757};\\\", \\\"{x:1237,y:756,t:1511831657773};\\\", \\\"{x:1254,y:756,t:1511831657790};\\\", \\\"{x:1272,y:756,t:1511831657807};\\\", \\\"{x:1291,y:755,t:1511831657823};\\\", \\\"{x:1318,y:751,t:1511831657840};\\\", \\\"{x:1329,y:751,t:1511831657857};\\\", \\\"{x:1336,y:751,t:1511831657873};\\\", \\\"{x:1341,y:751,t:1511831657890};\\\", \\\"{x:1348,y:751,t:1511831657907};\\\", \\\"{x:1355,y:754,t:1511831657923};\\\", \\\"{x:1371,y:758,t:1511831657940};\\\", \\\"{x:1388,y:763,t:1511831657957};\\\", \\\"{x:1403,y:767,t:1511831657973};\\\", \\\"{x:1419,y:767,t:1511831657990};\\\", \\\"{x:1441,y:767,t:1511831658007};\\\", \\\"{x:1448,y:767,t:1511831658022};\\\", \\\"{x:1451,y:767,t:1511831658039};\\\", \\\"{x:1452,y:766,t:1511831658142};\\\", \\\"{x:1453,y:764,t:1511831658156};\\\", \\\"{x:1454,y:759,t:1511831658172};\\\", \\\"{x:1454,y:756,t:1511831658189};\\\", \\\"{x:1455,y:750,t:1511831658206};\\\", \\\"{x:1457,y:744,t:1511831658222};\\\", \\\"{x:1461,y:737,t:1511831658239};\\\", \\\"{x:1470,y:728,t:1511831658256};\\\", \\\"{x:1479,y:716,t:1511831658273};\\\", \\\"{x:1490,y:700,t:1511831658289};\\\", \\\"{x:1497,y:685,t:1511831658306};\\\", \\\"{x:1505,y:669,t:1511831658323};\\\", \\\"{x:1507,y:650,t:1511831658339};\\\", \\\"{x:1507,y:631,t:1511831658356};\\\", \\\"{x:1507,y:616,t:1511831658373};\\\", \\\"{x:1504,y:604,t:1511831658389};\\\", \\\"{x:1498,y:593,t:1511831658406};\\\", \\\"{x:1495,y:587,t:1511831658423};\\\", \\\"{x:1492,y:582,t:1511831658439};\\\", \\\"{x:1488,y:576,t:1511831658456};\\\", \\\"{x:1485,y:572,t:1511831658473};\\\", \\\"{x:1478,y:563,t:1511831658489};\\\", \\\"{x:1471,y:559,t:1511831658507};\\\", \\\"{x:1466,y:556,t:1511831658523};\\\", \\\"{x:1461,y:554,t:1511831658540};\\\", \\\"{x:1460,y:553,t:1511831659519};\\\", \\\"{x:1455,y:552,t:1511831659527};\\\", \\\"{x:1448,y:554,t:1511831659541};\\\", \\\"{x:1429,y:565,t:1511831659558};\\\", \\\"{x:1390,y:593,t:1511831659574};\\\", \\\"{x:1274,y:668,t:1511831659591};\\\", \\\"{x:1167,y:726,t:1511831659607};\\\", \\\"{x:1044,y:798,t:1511831659625};\\\", \\\"{x:942,y:860,t:1511831659641};\\\", \\\"{x:899,y:893,t:1511831659658};\\\", \\\"{x:892,y:901,t:1511831659675};\\\", \\\"{x:891,y:902,t:1511831659695};\\\", \\\"{x:891,y:904,t:1511831659708};\\\", \\\"{x:891,y:920,t:1511831659725};\\\", \\\"{x:891,y:935,t:1511831659741};\\\", \\\"{x:888,y:943,t:1511831659758};\\\", \\\"{x:885,y:949,t:1511831659775};\\\", \\\"{x:882,y:951,t:1511831659791};\\\", \\\"{x:882,y:947,t:1511831659855};\\\", \\\"{x:886,y:944,t:1511831659863};\\\", \\\"{x:892,y:939,t:1511831659875};\\\", \\\"{x:910,y:927,t:1511831659891};\\\", \\\"{x:925,y:918,t:1511831659908};\\\", \\\"{x:934,y:910,t:1511831659925};\\\", \\\"{x:938,y:907,t:1511831659941};\\\", \\\"{x:940,y:906,t:1511831659958};\\\", \\\"{x:945,y:899,t:1511831659975};\\\", \\\"{x:954,y:891,t:1511831659991};\\\", \\\"{x:964,y:884,t:1511831660008};\\\", \\\"{x:976,y:875,t:1511831660025};\\\", \\\"{x:981,y:871,t:1511831660041};\\\", \\\"{x:982,y:870,t:1511831660058};\\\", \\\"{x:983,y:869,t:1511831660143};\\\", \\\"{x:984,y:867,t:1511831660158};\\\", \\\"{x:996,y:857,t:1511831660175};\\\", \\\"{x:1012,y:849,t:1511831660191};\\\", \\\"{x:1024,y:843,t:1511831660208};\\\", \\\"{x:1031,y:838,t:1511831660225};\\\", \\\"{x:1034,y:837,t:1511831660242};\\\", \\\"{x:1036,y:835,t:1511831660258};\\\", \\\"{x:1036,y:834,t:1511831660275};\\\", \\\"{x:1037,y:832,t:1511831660292};\\\", \\\"{x:1038,y:828,t:1511831660438};\\\", \\\"{x:1038,y:827,t:1511831660446};\\\", \\\"{x:1039,y:825,t:1511831660457};\\\", \\\"{x:1040,y:822,t:1511831660474};\\\", \\\"{x:1040,y:821,t:1511831660491};\\\", \\\"{x:1040,y:820,t:1511831661880};\\\", \\\"{x:1037,y:822,t:1511831661894};\\\", \\\"{x:1036,y:823,t:1511831661910};\\\", \\\"{x:1034,y:824,t:1511831661927};\\\", \\\"{x:1032,y:825,t:1511831662135};\\\", \\\"{x:1031,y:826,t:1511831662143};\\\", \\\"{x:1027,y:826,t:1511831662160};\\\", \\\"{x:1026,y:828,t:1511831662176};\\\", \\\"{x:1026,y:829,t:1511831662193};\\\", \\\"{x:1025,y:829,t:1511831663047};\\\", \\\"{x:1023,y:829,t:1511831663060};\\\", \\\"{x:1020,y:828,t:1511831663077};\\\", \\\"{x:1018,y:828,t:1511831663103};\\\", \\\"{x:1018,y:827,t:1511831664304};\\\", \\\"{x:1019,y:816,t:1511831664312};\\\", \\\"{x:1029,y:794,t:1511831664329};\\\", \\\"{x:1039,y:773,t:1511831664345};\\\", \\\"{x:1051,y:751,t:1511831664362};\\\", \\\"{x:1059,y:736,t:1511831664378};\\\", \\\"{x:1068,y:717,t:1511831664395};\\\", \\\"{x:1073,y:705,t:1511831664412};\\\", \\\"{x:1074,y:699,t:1511831664429};\\\", \\\"{x:1074,y:697,t:1511831664446};\\\", \\\"{x:1076,y:692,t:1511831664462};\\\", \\\"{x:1076,y:686,t:1511831664478};\\\", \\\"{x:1076,y:667,t:1511831664495};\\\", \\\"{x:1076,y:661,t:1511831664511};\\\", \\\"{x:1075,y:657,t:1511831664528};\\\", \\\"{x:1074,y:655,t:1511831664545};\\\", \\\"{x:1073,y:654,t:1511831664561};\\\", \\\"{x:1073,y:653,t:1511831664615};\\\", \\\"{x:1073,y:650,t:1511831664628};\\\", \\\"{x:1073,y:642,t:1511831664645};\\\", \\\"{x:1072,y:635,t:1511831664662};\\\", \\\"{x:1071,y:629,t:1511831664679};\\\", \\\"{x:1069,y:622,t:1511831664696};\\\", \\\"{x:1069,y:621,t:1511831664712};\\\", \\\"{x:1069,y:618,t:1511831664729};\\\", \\\"{x:1069,y:616,t:1511831664745};\\\", \\\"{x:1069,y:615,t:1511831664761};\\\", \\\"{x:1070,y:610,t:1511831664778};\\\", \\\"{x:1074,y:599,t:1511831664795};\\\", \\\"{x:1078,y:584,t:1511831664812};\\\", \\\"{x:1080,y:573,t:1511831664829};\\\", \\\"{x:1082,y:564,t:1511831664846};\\\", \\\"{x:1083,y:560,t:1511831664861};\\\", \\\"{x:1084,y:556,t:1511831664879};\\\", \\\"{x:1077,y:560,t:1511831665160};\\\", \\\"{x:1061,y:572,t:1511831665168};\\\", \\\"{x:1041,y:587,t:1511831665179};\\\", \\\"{x:971,y:622,t:1511831665196};\\\", \\\"{x:892,y:654,t:1511831665213};\\\", \\\"{x:820,y:686,t:1511831665229};\\\", \\\"{x:765,y:699,t:1511831665246};\\\", \\\"{x:699,y:704,t:1511831665262};\\\", \\\"{x:600,y:704,t:1511831665279};\\\", \\\"{x:424,y:682,t:1511831665296};\\\", \\\"{x:313,y:666,t:1511831665312};\\\", \\\"{x:239,y:648,t:1511831665329};\\\", \\\"{x:183,y:632,t:1511831665347};\\\", \\\"{x:149,y:622,t:1511831665363};\\\", \\\"{x:145,y:621,t:1511831665380};\\\", \\\"{x:144,y:620,t:1511831665397};\\\", \\\"{x:147,y:614,t:1511831665431};\\\", \\\"{x:158,y:604,t:1511831665447};\\\", \\\"{x:166,y:592,t:1511831665463};\\\", \\\"{x:177,y:578,t:1511831665480};\\\", \\\"{x:193,y:567,t:1511831665497};\\\", \\\"{x:211,y:559,t:1511831665513};\\\", \\\"{x:231,y:553,t:1511831665530};\\\", \\\"{x:247,y:549,t:1511831665547};\\\", \\\"{x:255,y:548,t:1511831665563};\\\", \\\"{x:266,y:546,t:1511831665580};\\\", \\\"{x:287,y:545,t:1511831665597};\\\", \\\"{x:309,y:545,t:1511831665613};\\\", \\\"{x:319,y:543,t:1511831665630};\\\", \\\"{x:322,y:543,t:1511831665647};\\\", \\\"{x:325,y:543,t:1511831665688};\\\", \\\"{x:329,y:543,t:1511831665697};\\\", \\\"{x:342,y:546,t:1511831665715};\\\", \\\"{x:353,y:548,t:1511831665731};\\\", \\\"{x:363,y:550,t:1511831665747};\\\", \\\"{x:372,y:550,t:1511831665765};\\\", \\\"{x:375,y:550,t:1511831665780};\\\", \\\"{x:376,y:550,t:1511831665798};\\\", \\\"{x:376,y:548,t:1511831665815};\\\", \\\"{x:378,y:547,t:1511831665830};\\\", \\\"{x:389,y:539,t:1511831665848};\\\", \\\"{x:402,y:534,t:1511831665865};\\\", \\\"{x:409,y:532,t:1511831665881};\\\", \\\"{x:411,y:530,t:1511831665897};\\\", \\\"{x:411,y:529,t:1511831665943};\\\", \\\"{x:411,y:528,t:1511831665959};\\\", \\\"{x:411,y:527,t:1511831666055};\\\", \\\"{x:410,y:527,t:1511831666152};\\\", \\\"{x:408,y:527,t:1511831666168};\\\", \\\"{x:407,y:527,t:1511831666180};\\\", \\\"{x:402,y:528,t:1511831666197};\\\", \\\"{x:401,y:529,t:1511831666214};\\\", \\\"{x:400,y:529,t:1511831666239};\\\", \\\"{x:400,y:531,t:1511831666423};\\\", \\\"{x:402,y:533,t:1511831666431};\\\", \\\"{x:406,y:540,t:1511831666447};\\\", \\\"{x:411,y:551,t:1511831666464};\\\", \\\"{x:417,y:568,t:1511831666481};\\\", \\\"{x:423,y:594,t:1511831666497};\\\", \\\"{x:429,y:625,t:1511831666514};\\\", \\\"{x:435,y:655,t:1511831666531};\\\", \\\"{x:440,y:679,t:1511831666547};\\\", \\\"{x:442,y:695,t:1511831666564};\\\", \\\"{x:442,y:703,t:1511831666581};\\\", \\\"{x:442,y:707,t:1511831666597};\\\", \\\"{x:440,y:709,t:1511831666614};\\\", \\\"{x:439,y:710,t:1511831666631};\\\", \\\"{x:437,y:710,t:1511831666647};\\\", \\\"{x:433,y:711,t:1511831666664};\\\", \\\"{x:426,y:712,t:1511831666681};\\\", \\\"{x:424,y:712,t:1511831666698};\\\", \\\"{x:423,y:712,t:1511831666760};\\\", \\\"{x:420,y:709,t:1511831666776};\\\", \\\"{x:419,y:704,t:1511831666783};\\\", \\\"{x:417,y:700,t:1511831666798};\\\", \\\"{x:416,y:693,t:1511831666814};\\\", \\\"{x:415,y:689,t:1511831666831};\\\", \\\"{x:413,y:687,t:1511831666848};\\\", \\\"{x:419,y:687,t:1511831667480};\\\", \\\"{x:428,y:687,t:1511831667487};\\\", \\\"{x:437,y:687,t:1511831667498};\\\", \\\"{x:465,y:683,t:1511831667515};\\\", \\\"{x:503,y:676,t:1511831667531};\\\", \\\"{x:559,y:662,t:1511831667548};\\\", \\\"{x:617,y:653,t:1511831667565};\\\", \\\"{x:682,y:643,t:1511831667581};\\\", \\\"{x:708,y:638,t:1511831667599};\\\", \\\"{x:721,y:633,t:1511831667615};\\\", \\\"{x:725,y:630,t:1511831667632};\\\", \\\"{x:728,y:623,t:1511831667648};\\\", \\\"{x:730,y:617,t:1511831667666};\\\", \\\"{x:730,y:605,t:1511831667682};\\\", \\\"{x:730,y:587,t:1511831667698};\\\", \\\"{x:722,y:565,t:1511831667715};\\\", \\\"{x:698,y:531,t:1511831667732};\\\", \\\"{x:666,y:495,t:1511831667748};\\\", \\\"{x:630,y:462,t:1511831667765};\\\", \\\"{x:595,y:434,t:1511831667783};\\\", \\\"{x:566,y:413,t:1511831667798};\\\", \\\"{x:534,y:391,t:1511831667815};\\\", \\\"{x:523,y:381,t:1511831667832};\\\", \\\"{x:520,y:378,t:1511831667848};\\\", \\\"{x:520,y:374,t:1511831667865};\\\", \\\"{x:519,y:371,t:1511831667882};\\\", \\\"{x:518,y:370,t:1511831667898};\\\" ] }, { \\\"rt\\\": 19515, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 480918, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -F -F -02 PM-B -B -B -B -02 PM-F -F -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:373,t:1511831669680};\\\", \\\"{x:520,y:379,t:1511831669693};\\\", \\\"{x:526,y:388,t:1511831669700};\\\", \\\"{x:549,y:409,t:1511831669716};\\\", \\\"{x:587,y:431,t:1511831669733};\\\", \\\"{x:649,y:452,t:1511831669750};\\\", \\\"{x:744,y:479,t:1511831669766};\\\", \\\"{x:915,y:527,t:1511831669783};\\\", \\\"{x:1020,y:557,t:1511831669800};\\\", \\\"{x:1128,y:583,t:1511831669816};\\\", \\\"{x:1203,y:607,t:1511831669833};\\\", \\\"{x:1239,y:617,t:1511831669850};\\\", \\\"{x:1255,y:622,t:1511831669866};\\\", \\\"{x:1258,y:623,t:1511831669883};\\\", \\\"{x:1259,y:624,t:1511831670056};\\\", \\\"{x:1260,y:624,t:1511831670068};\\\", \\\"{x:1267,y:628,t:1511831670084};\\\", \\\"{x:1275,y:630,t:1511831670101};\\\", \\\"{x:1282,y:632,t:1511831670118};\\\", \\\"{x:1288,y:636,t:1511831670133};\\\", \\\"{x:1291,y:638,t:1511831670150};\\\", \\\"{x:1298,y:642,t:1511831670167};\\\", \\\"{x:1307,y:647,t:1511831670184};\\\", \\\"{x:1316,y:651,t:1511831670201};\\\", \\\"{x:1329,y:655,t:1511831670218};\\\", \\\"{x:1341,y:659,t:1511831670234};\\\", \\\"{x:1356,y:665,t:1511831670251};\\\", \\\"{x:1364,y:671,t:1511831670267};\\\", \\\"{x:1365,y:672,t:1511831670283};\\\", \\\"{x:1365,y:675,t:1511831670300};\\\", \\\"{x:1362,y:681,t:1511831670317};\\\", \\\"{x:1352,y:690,t:1511831670333};\\\", \\\"{x:1343,y:696,t:1511831670350};\\\", \\\"{x:1331,y:705,t:1511831670367};\\\", \\\"{x:1327,y:705,t:1511831670383};\\\", \\\"{x:1325,y:707,t:1511831670400};\\\", \\\"{x:1322,y:707,t:1511831670417};\\\", \\\"{x:1314,y:707,t:1511831670433};\\\", \\\"{x:1305,y:707,t:1511831670450};\\\", \\\"{x:1295,y:707,t:1511831670467};\\\", \\\"{x:1284,y:705,t:1511831670484};\\\", \\\"{x:1273,y:705,t:1511831670500};\\\", \\\"{x:1257,y:705,t:1511831670517};\\\", \\\"{x:1249,y:705,t:1511831670534};\\\", \\\"{x:1243,y:705,t:1511831670550};\\\", \\\"{x:1235,y:705,t:1511831670567};\\\", \\\"{x:1230,y:705,t:1511831670584};\\\", \\\"{x:1224,y:705,t:1511831670600};\\\", \\\"{x:1212,y:707,t:1511831670617};\\\", \\\"{x:1208,y:707,t:1511831670634};\\\", \\\"{x:1207,y:707,t:1511831670650};\\\", \\\"{x:1206,y:707,t:1511831670728};\\\", \\\"{x:1203,y:707,t:1511831670735};\\\", \\\"{x:1199,y:707,t:1511831670751};\\\", \\\"{x:1185,y:700,t:1511831670767};\\\", \\\"{x:1170,y:697,t:1511831670785};\\\", \\\"{x:1156,y:696,t:1511831670803};\\\", \\\"{x:1152,y:696,t:1511831670817};\\\", \\\"{x:1148,y:696,t:1511831670834};\\\", \\\"{x:1147,y:696,t:1511831671344};\\\", \\\"{x:1147,y:697,t:1511831671360};\\\", \\\"{x:1148,y:698,t:1511831671368};\\\", \\\"{x:1150,y:699,t:1511831671385};\\\", \\\"{x:1151,y:699,t:1511831671402};\\\", \\\"{x:1152,y:700,t:1511831672432};\\\", \\\"{x:1155,y:704,t:1511831672464};\\\", \\\"{x:1157,y:708,t:1511831672471};\\\", \\\"{x:1160,y:713,t:1511831672486};\\\", \\\"{x:1162,y:717,t:1511831672503};\\\", \\\"{x:1163,y:720,t:1511831672519};\\\", \\\"{x:1166,y:726,t:1511831672535};\\\", \\\"{x:1168,y:730,t:1511831672553};\\\", \\\"{x:1170,y:734,t:1511831672569};\\\", \\\"{x:1171,y:736,t:1511831672586};\\\", \\\"{x:1173,y:738,t:1511831672604};\\\", \\\"{x:1174,y:740,t:1511831672619};\\\", \\\"{x:1175,y:741,t:1511831672636};\\\", \\\"{x:1175,y:742,t:1511831672653};\\\", \\\"{x:1176,y:743,t:1511831672669};\\\", \\\"{x:1177,y:745,t:1511831672686};\\\", \\\"{x:1179,y:748,t:1511831672703};\\\", \\\"{x:1182,y:754,t:1511831672719};\\\", \\\"{x:1191,y:765,t:1511831672736};\\\", \\\"{x:1197,y:776,t:1511831672753};\\\", \\\"{x:1202,y:783,t:1511831672768};\\\", \\\"{x:1207,y:789,t:1511831672786};\\\", \\\"{x:1210,y:793,t:1511831672804};\\\", \\\"{x:1213,y:800,t:1511831672819};\\\", \\\"{x:1216,y:808,t:1511831672836};\\\", \\\"{x:1218,y:810,t:1511831672853};\\\", \\\"{x:1219,y:813,t:1511831672870};\\\", \\\"{x:1223,y:816,t:1511831672886};\\\", \\\"{x:1228,y:820,t:1511831672903};\\\", \\\"{x:1232,y:824,t:1511831672920};\\\", \\\"{x:1236,y:829,t:1511831672936};\\\", \\\"{x:1239,y:835,t:1511831672953};\\\", \\\"{x:1243,y:842,t:1511831672970};\\\", \\\"{x:1248,y:850,t:1511831672986};\\\", \\\"{x:1252,y:858,t:1511831673003};\\\", \\\"{x:1256,y:863,t:1511831673020};\\\", \\\"{x:1258,y:865,t:1511831673036};\\\", \\\"{x:1258,y:868,t:1511831673053};\\\", \\\"{x:1258,y:869,t:1511831673070};\\\", \\\"{x:1259,y:872,t:1511831673086};\\\", \\\"{x:1261,y:876,t:1511831673103};\\\", \\\"{x:1262,y:884,t:1511831673119};\\\", \\\"{x:1265,y:887,t:1511831673136};\\\", \\\"{x:1266,y:891,t:1511831673153};\\\", \\\"{x:1268,y:894,t:1511831673170};\\\", \\\"{x:1269,y:896,t:1511831673186};\\\", \\\"{x:1270,y:898,t:1511831673204};\\\", \\\"{x:1271,y:899,t:1511831673220};\\\", \\\"{x:1271,y:901,t:1511831673236};\\\", \\\"{x:1272,y:903,t:1511831673253};\\\", \\\"{x:1274,y:906,t:1511831673270};\\\", \\\"{x:1275,y:910,t:1511831673286};\\\", \\\"{x:1276,y:913,t:1511831673303};\\\", \\\"{x:1278,y:918,t:1511831673319};\\\", \\\"{x:1279,y:921,t:1511831673337};\\\", \\\"{x:1279,y:923,t:1511831673353};\\\", \\\"{x:1281,y:925,t:1511831673370};\\\", \\\"{x:1281,y:926,t:1511831673407};\\\", \\\"{x:1281,y:928,t:1511831673423};\\\", \\\"{x:1282,y:929,t:1511831673437};\\\", \\\"{x:1284,y:933,t:1511831673453};\\\", \\\"{x:1285,y:937,t:1511831673470};\\\", \\\"{x:1286,y:939,t:1511831673487};\\\", \\\"{x:1286,y:941,t:1511831673503};\\\", \\\"{x:1288,y:943,t:1511831673520};\\\", \\\"{x:1288,y:944,t:1511831673600};\\\", \\\"{x:1289,y:946,t:1511831673615};\\\", \\\"{x:1290,y:948,t:1511831673623};\\\", \\\"{x:1290,y:949,t:1511831673637};\\\", \\\"{x:1290,y:953,t:1511831673653};\\\", \\\"{x:1291,y:954,t:1511831673670};\\\", \\\"{x:1291,y:955,t:1511831673687};\\\", \\\"{x:1292,y:956,t:1511831673703};\\\", \\\"{x:1292,y:957,t:1511831673727};\\\", \\\"{x:1292,y:958,t:1511831673737};\\\", \\\"{x:1292,y:959,t:1511831673753};\\\", \\\"{x:1292,y:961,t:1511831673770};\\\", \\\"{x:1292,y:962,t:1511831673787};\\\", \\\"{x:1292,y:965,t:1511831673804};\\\", \\\"{x:1292,y:966,t:1511831673820};\\\", \\\"{x:1292,y:969,t:1511831673836};\\\", \\\"{x:1292,y:971,t:1511831673853};\\\", \\\"{x:1293,y:972,t:1511831673886};\\\", \\\"{x:1293,y:974,t:1511831673951};\\\", \\\"{x:1293,y:975,t:1511831673974};\\\", \\\"{x:1292,y:974,t:1511831674143};\\\", \\\"{x:1292,y:972,t:1511831674167};\\\", \\\"{x:1291,y:971,t:1511831674175};\\\", \\\"{x:1291,y:970,t:1511831674191};\\\", \\\"{x:1291,y:968,t:1511831674204};\\\", \\\"{x:1291,y:967,t:1511831674220};\\\", \\\"{x:1291,y:965,t:1511831674237};\\\", \\\"{x:1291,y:964,t:1511831674254};\\\", \\\"{x:1291,y:962,t:1511831674270};\\\", \\\"{x:1291,y:960,t:1511831674287};\\\", \\\"{x:1290,y:959,t:1511831674448};\\\", \\\"{x:1290,y:958,t:1511831674463};\\\", \\\"{x:1289,y:958,t:1511831674696};\\\", \\\"{x:1287,y:959,t:1511831674704};\\\", \\\"{x:1285,y:964,t:1511831674721};\\\", \\\"{x:1282,y:968,t:1511831674737};\\\", \\\"{x:1281,y:970,t:1511831674754};\\\", \\\"{x:1281,y:971,t:1511831674783};\\\", \\\"{x:1282,y:971,t:1511831674856};\\\", \\\"{x:1285,y:970,t:1511831674871};\\\", \\\"{x:1289,y:969,t:1511831674887};\\\", \\\"{x:1286,y:971,t:1511831675639};\\\", \\\"{x:1281,y:972,t:1511831675654};\\\", \\\"{x:1280,y:972,t:1511831675670};\\\", \\\"{x:1280,y:971,t:1511831675735};\\\", \\\"{x:1281,y:969,t:1511831675751};\\\", \\\"{x:1283,y:966,t:1511831675759};\\\", \\\"{x:1284,y:965,t:1511831675771};\\\", \\\"{x:1284,y:964,t:1511831676015};\\\", \\\"{x:1284,y:963,t:1511831676031};\\\", \\\"{x:1284,y:961,t:1511831676104};\\\", \\\"{x:1284,y:959,t:1511831676122};\\\", \\\"{x:1286,y:957,t:1511831676138};\\\", \\\"{x:1288,y:956,t:1511831676155};\\\", \\\"{x:1289,y:955,t:1511831676172};\\\", \\\"{x:1289,y:954,t:1511831676328};\\\", \\\"{x:1292,y:953,t:1511831676339};\\\", \\\"{x:1298,y:949,t:1511831676355};\\\", \\\"{x:1301,y:947,t:1511831676372};\\\", \\\"{x:1301,y:946,t:1511831676389};\\\", \\\"{x:1299,y:947,t:1511831676456};\\\", \\\"{x:1289,y:949,t:1511831676471};\\\", \\\"{x:1277,y:953,t:1511831676488};\\\", \\\"{x:1274,y:954,t:1511831676504};\\\", \\\"{x:1277,y:954,t:1511831676591};\\\", \\\"{x:1283,y:952,t:1511831676604};\\\", \\\"{x:1288,y:950,t:1511831676621};\\\", \\\"{x:1291,y:950,t:1511831676638};\\\", \\\"{x:1290,y:950,t:1511831676728};\\\", \\\"{x:1288,y:951,t:1511831676739};\\\", \\\"{x:1289,y:951,t:1511831676848};\\\", \\\"{x:1290,y:951,t:1511831676855};\\\", \\\"{x:1289,y:952,t:1511831676968};\\\", \\\"{x:1288,y:952,t:1511831676975};\\\", \\\"{x:1287,y:953,t:1511831677183};\\\", \\\"{x:1286,y:952,t:1511831677359};\\\", \\\"{x:1282,y:945,t:1511831677373};\\\", \\\"{x:1272,y:926,t:1511831677389};\\\", \\\"{x:1261,y:902,t:1511831677406};\\\", \\\"{x:1250,y:882,t:1511831677422};\\\", \\\"{x:1246,y:870,t:1511831677438};\\\", \\\"{x:1246,y:864,t:1511831677455};\\\", \\\"{x:1245,y:858,t:1511831677472};\\\", \\\"{x:1244,y:854,t:1511831677488};\\\", \\\"{x:1242,y:847,t:1511831677505};\\\", \\\"{x:1239,y:841,t:1511831677522};\\\", \\\"{x:1237,y:839,t:1511831677538};\\\", \\\"{x:1236,y:836,t:1511831677555};\\\", \\\"{x:1234,y:833,t:1511831677572};\\\", \\\"{x:1233,y:829,t:1511831677588};\\\", \\\"{x:1230,y:824,t:1511831677605};\\\", \\\"{x:1215,y:805,t:1511831677623};\\\", \\\"{x:1202,y:789,t:1511831677639};\\\", \\\"{x:1176,y:767,t:1511831677656};\\\", \\\"{x:1150,y:750,t:1511831677673};\\\", \\\"{x:1127,y:738,t:1511831677690};\\\", \\\"{x:1111,y:731,t:1511831677706};\\\", \\\"{x:1105,y:728,t:1511831677723};\\\", \\\"{x:1103,y:728,t:1511831677739};\\\", \\\"{x:1103,y:727,t:1511831677799};\\\", \\\"{x:1104,y:727,t:1511831677807};\\\", \\\"{x:1109,y:724,t:1511831677823};\\\", \\\"{x:1118,y:721,t:1511831677839};\\\", \\\"{x:1127,y:721,t:1511831677856};\\\", \\\"{x:1135,y:722,t:1511831677873};\\\", \\\"{x:1141,y:728,t:1511831677890};\\\", \\\"{x:1149,y:737,t:1511831677906};\\\", \\\"{x:1153,y:746,t:1511831677923};\\\", \\\"{x:1155,y:753,t:1511831677940};\\\", \\\"{x:1158,y:761,t:1511831677956};\\\", \\\"{x:1160,y:770,t:1511831677973};\\\", \\\"{x:1163,y:776,t:1511831677990};\\\", \\\"{x:1164,y:778,t:1511831678006};\\\", \\\"{x:1164,y:779,t:1511831678134};\\\", \\\"{x:1164,y:781,t:1511831678150};\\\", \\\"{x:1163,y:781,t:1511831678158};\\\", \\\"{x:1160,y:781,t:1511831678172};\\\", \\\"{x:1156,y:781,t:1511831678189};\\\", \\\"{x:1152,y:781,t:1511831678206};\\\", \\\"{x:1150,y:780,t:1511831678223};\\\", \\\"{x:1149,y:780,t:1511831678239};\\\", \\\"{x:1149,y:778,t:1511831678367};\\\", \\\"{x:1150,y:778,t:1511831678489};\\\", \\\"{x:1151,y:778,t:1511831678536};\\\", \\\"{x:1152,y:778,t:1511831678552};\\\", \\\"{x:1152,y:777,t:1511831678560};\\\", \\\"{x:1154,y:776,t:1511831678576};\\\", \\\"{x:1155,y:776,t:1511831678591};\\\", \\\"{x:1156,y:775,t:1511831678608};\\\", \\\"{x:1158,y:775,t:1511831678625};\\\", \\\"{x:1159,y:774,t:1511831678664};\\\", \\\"{x:1160,y:774,t:1511831678675};\\\", \\\"{x:1162,y:771,t:1511831678691};\\\", \\\"{x:1163,y:768,t:1511831678708};\\\", \\\"{x:1163,y:764,t:1511831678725};\\\", \\\"{x:1163,y:762,t:1511831678741};\\\", \\\"{x:1163,y:761,t:1511831678760};\\\", \\\"{x:1163,y:760,t:1511831679104};\\\", \\\"{x:1163,y:758,t:1511831679112};\\\", \\\"{x:1162,y:758,t:1511831679125};\\\", \\\"{x:1158,y:756,t:1511831679142};\\\", \\\"{x:1157,y:755,t:1511831679158};\\\", \\\"{x:1156,y:755,t:1511831679384};\\\", \\\"{x:1156,y:759,t:1511831679392};\\\", \\\"{x:1156,y:768,t:1511831679408};\\\", \\\"{x:1156,y:770,t:1511831679425};\\\", \\\"{x:1156,y:771,t:1511831679442};\\\", \\\"{x:1156,y:774,t:1511831679552};\\\", \\\"{x:1156,y:777,t:1511831679560};\\\", \\\"{x:1156,y:779,t:1511831679575};\\\", \\\"{x:1160,y:785,t:1511831679592};\\\", \\\"{x:1161,y:786,t:1511831679616};\\\", \\\"{x:1162,y:787,t:1511831679625};\\\", \\\"{x:1164,y:790,t:1511831679642};\\\", \\\"{x:1168,y:794,t:1511831679659};\\\", \\\"{x:1172,y:798,t:1511831679675};\\\", \\\"{x:1174,y:802,t:1511831679692};\\\", \\\"{x:1180,y:809,t:1511831679709};\\\", \\\"{x:1188,y:820,t:1511831679725};\\\", \\\"{x:1198,y:834,t:1511831679742};\\\", \\\"{x:1212,y:846,t:1511831679759};\\\", \\\"{x:1224,y:855,t:1511831679775};\\\", \\\"{x:1229,y:859,t:1511831679792};\\\", \\\"{x:1230,y:860,t:1511831679808};\\\", \\\"{x:1231,y:862,t:1511831679825};\\\", \\\"{x:1233,y:864,t:1511831679842};\\\", \\\"{x:1236,y:869,t:1511831679859};\\\", \\\"{x:1240,y:876,t:1511831679875};\\\", \\\"{x:1244,y:884,t:1511831679892};\\\", \\\"{x:1248,y:892,t:1511831679909};\\\", \\\"{x:1250,y:897,t:1511831679925};\\\", \\\"{x:1253,y:903,t:1511831679942};\\\", \\\"{x:1254,y:905,t:1511831679959};\\\", \\\"{x:1255,y:907,t:1511831679975};\\\", \\\"{x:1257,y:910,t:1511831679992};\\\", \\\"{x:1257,y:911,t:1511831680009};\\\", \\\"{x:1258,y:914,t:1511831680025};\\\", \\\"{x:1259,y:916,t:1511831680042};\\\", \\\"{x:1260,y:920,t:1511831680059};\\\", \\\"{x:1262,y:923,t:1511831680076};\\\", \\\"{x:1265,y:928,t:1511831680092};\\\", \\\"{x:1269,y:933,t:1511831680109};\\\", \\\"{x:1272,y:936,t:1511831680126};\\\", \\\"{x:1273,y:936,t:1511831680142};\\\", \\\"{x:1274,y:937,t:1511831680200};\\\", \\\"{x:1275,y:939,t:1511831680208};\\\", \\\"{x:1276,y:941,t:1511831680226};\\\", \\\"{x:1277,y:943,t:1511831680242};\\\", \\\"{x:1279,y:947,t:1511831680258};\\\", \\\"{x:1281,y:949,t:1511831680276};\\\", \\\"{x:1283,y:952,t:1511831680292};\\\", \\\"{x:1284,y:953,t:1511831680309};\\\", \\\"{x:1284,y:955,t:1511831680377};\\\", \\\"{x:1286,y:957,t:1511831680392};\\\", \\\"{x:1287,y:960,t:1511831680409};\\\", \\\"{x:1288,y:963,t:1511831680426};\\\", \\\"{x:1289,y:965,t:1511831680442};\\\", \\\"{x:1290,y:966,t:1511831680464};\\\", \\\"{x:1290,y:965,t:1511831681272};\\\", \\\"{x:1290,y:964,t:1511831681280};\\\", \\\"{x:1290,y:962,t:1511831681296};\\\", \\\"{x:1290,y:960,t:1511831681312};\\\", \\\"{x:1290,y:959,t:1511831681326};\\\", \\\"{x:1290,y:958,t:1511831681343};\\\", \\\"{x:1289,y:958,t:1511831683512};\\\", \\\"{x:1286,y:958,t:1511831683528};\\\", \\\"{x:1284,y:958,t:1511831683544};\\\", \\\"{x:1283,y:958,t:1511831683664};\\\", \\\"{x:1282,y:951,t:1511831683720};\\\", \\\"{x:1278,y:940,t:1511831683728};\\\", \\\"{x:1272,y:920,t:1511831683745};\\\", \\\"{x:1260,y:895,t:1511831683763};\\\", \\\"{x:1249,y:872,t:1511831683777};\\\", \\\"{x:1241,y:851,t:1511831683794};\\\", \\\"{x:1233,y:837,t:1511831683810};\\\", \\\"{x:1227,y:825,t:1511831683827};\\\", \\\"{x:1221,y:816,t:1511831683844};\\\", \\\"{x:1213,y:804,t:1511831683860};\\\", \\\"{x:1206,y:794,t:1511831683877};\\\", \\\"{x:1203,y:788,t:1511831683894};\\\", \\\"{x:1198,y:777,t:1511831683911};\\\", \\\"{x:1196,y:770,t:1511831683927};\\\", \\\"{x:1194,y:767,t:1511831683944};\\\", \\\"{x:1190,y:761,t:1511831683961};\\\", \\\"{x:1187,y:758,t:1511831683977};\\\", \\\"{x:1184,y:753,t:1511831683994};\\\", \\\"{x:1178,y:746,t:1511831684011};\\\", \\\"{x:1175,y:739,t:1511831684027};\\\", \\\"{x:1171,y:728,t:1511831684044};\\\", \\\"{x:1169,y:723,t:1511831684061};\\\", \\\"{x:1167,y:717,t:1511831684078};\\\", \\\"{x:1165,y:708,t:1511831684095};\\\", \\\"{x:1163,y:699,t:1511831684111};\\\", \\\"{x:1161,y:696,t:1511831684127};\\\", \\\"{x:1161,y:693,t:1511831684145};\\\", \\\"{x:1161,y:692,t:1511831684161};\\\", \\\"{x:1161,y:690,t:1511831684224};\\\", \\\"{x:1161,y:688,t:1511831684232};\\\", \\\"{x:1161,y:686,t:1511831684248};\\\", \\\"{x:1161,y:685,t:1511831684262};\\\", \\\"{x:1161,y:683,t:1511831684278};\\\", \\\"{x:1161,y:682,t:1511831685104};\\\", \\\"{x:1157,y:680,t:1511831685112};\\\", \\\"{x:1154,y:678,t:1511831685129};\\\", \\\"{x:1151,y:677,t:1511831685146};\\\", \\\"{x:1149,y:676,t:1511831685162};\\\", \\\"{x:1149,y:675,t:1511831685179};\\\", \\\"{x:1148,y:675,t:1511831685416};\\\", \\\"{x:1147,y:676,t:1511831685429};\\\", \\\"{x:1147,y:682,t:1511831685446};\\\", \\\"{x:1145,y:690,t:1511831685463};\\\", \\\"{x:1145,y:701,t:1511831685479};\\\", \\\"{x:1146,y:714,t:1511831685496};\\\", \\\"{x:1147,y:716,t:1511831685512};\\\", \\\"{x:1149,y:720,t:1511831685529};\\\", \\\"{x:1153,y:724,t:1511831685546};\\\", \\\"{x:1155,y:729,t:1511831685563};\\\", \\\"{x:1158,y:732,t:1511831685579};\\\", \\\"{x:1162,y:737,t:1511831685595};\\\", \\\"{x:1169,y:747,t:1511831685612};\\\", \\\"{x:1175,y:758,t:1511831685628};\\\", \\\"{x:1181,y:768,t:1511831685645};\\\", \\\"{x:1188,y:776,t:1511831685662};\\\", \\\"{x:1195,y:783,t:1511831685678};\\\", \\\"{x:1209,y:797,t:1511831685695};\\\", \\\"{x:1220,y:807,t:1511831685712};\\\", \\\"{x:1230,y:819,t:1511831685728};\\\", \\\"{x:1238,y:831,t:1511831685745};\\\", \\\"{x:1251,y:854,t:1511831685762};\\\", \\\"{x:1272,y:896,t:1511831685778};\\\", \\\"{x:1298,y:945,t:1511831685796};\\\", \\\"{x:1318,y:980,t:1511831685813};\\\", \\\"{x:1331,y:999,t:1511831685830};\\\", \\\"{x:1345,y:1010,t:1511831685845};\\\", \\\"{x:1347,y:1011,t:1511831685863};\\\", \\\"{x:1343,y:1011,t:1511831685960};\\\", \\\"{x:1337,y:1002,t:1511831685968};\\\", \\\"{x:1330,y:993,t:1511831685980};\\\", \\\"{x:1283,y:958,t:1511831685996};\\\", \\\"{x:1192,y:895,t:1511831686013};\\\", \\\"{x:1063,y:825,t:1511831686030};\\\", \\\"{x:947,y:775,t:1511831686046};\\\", \\\"{x:859,y:737,t:1511831686063};\\\", \\\"{x:761,y:693,t:1511831686079};\\\", \\\"{x:737,y:678,t:1511831686095};\\\", \\\"{x:733,y:675,t:1511831686112};\\\", \\\"{x:732,y:675,t:1511831686130};\\\", \\\"{x:732,y:673,t:1511831686192};\\\", \\\"{x:729,y:672,t:1511831686199};\\\", \\\"{x:725,y:671,t:1511831686212};\\\", \\\"{x:717,y:668,t:1511831686229};\\\", \\\"{x:708,y:667,t:1511831686245};\\\", \\\"{x:694,y:662,t:1511831686263};\\\", \\\"{x:648,y:652,t:1511831686279};\\\", \\\"{x:593,y:641,t:1511831686296};\\\", \\\"{x:527,y:625,t:1511831686312};\\\", \\\"{x:456,y:609,t:1511831686330};\\\", \\\"{x:407,y:598,t:1511831686347};\\\", \\\"{x:370,y:586,t:1511831686363};\\\", \\\"{x:350,y:581,t:1511831686380};\\\", \\\"{x:347,y:580,t:1511831686396};\\\", \\\"{x:346,y:579,t:1511831686488};\\\", \\\"{x:346,y:576,t:1511831686496};\\\", \\\"{x:346,y:571,t:1511831686513};\\\", \\\"{x:347,y:566,t:1511831686530};\\\", \\\"{x:360,y:561,t:1511831686547};\\\", \\\"{x:383,y:551,t:1511831686562};\\\", \\\"{x:399,y:545,t:1511831686580};\\\", \\\"{x:404,y:541,t:1511831686597};\\\", \\\"{x:405,y:541,t:1511831686613};\\\", \\\"{x:405,y:539,t:1511831686832};\\\", \\\"{x:405,y:537,t:1511831686846};\\\", \\\"{x:404,y:532,t:1511831686862};\\\", \\\"{x:402,y:529,t:1511831686881};\\\", \\\"{x:401,y:527,t:1511831686898};\\\", \\\"{x:400,y:526,t:1511831687039};\\\", \\\"{x:400,y:528,t:1511831687048};\\\", \\\"{x:400,y:548,t:1511831687058};\\\", \\\"{x:403,y:579,t:1511831687075};\\\", \\\"{x:404,y:603,t:1511831687092};\\\", \\\"{x:404,y:624,t:1511831687108};\\\", \\\"{x:407,y:648,t:1511831687125};\\\", \\\"{x:411,y:672,t:1511831687142};\\\", \\\"{x:415,y:689,t:1511831687158};\\\", \\\"{x:418,y:704,t:1511831687175};\\\", \\\"{x:419,y:713,t:1511831687192};\\\", \\\"{x:420,y:719,t:1511831687208};\\\", \\\"{x:420,y:721,t:1511831687273};\\\", \\\"{x:420,y:724,t:1511831687281};\\\", \\\"{x:419,y:725,t:1511831687292};\\\", \\\"{x:417,y:727,t:1511831687308};\\\", \\\"{x:417,y:728,t:1511831687325};\\\", \\\"{x:417,y:726,t:1511831687458};\\\", \\\"{x:417,y:722,t:1511831687465};\\\", \\\"{x:416,y:718,t:1511831687475};\\\", \\\"{x:416,y:712,t:1511831687492};\\\", \\\"{x:414,y:705,t:1511831687510};\\\", \\\"{x:413,y:698,t:1511831687525};\\\", \\\"{x:413,y:695,t:1511831687542};\\\", \\\"{x:413,y:694,t:1511831687559};\\\", \\\"{x:413,y:693,t:1511831687575};\\\", \\\"{x:413,y:691,t:1511831688289};\\\", \\\"{x:414,y:690,t:1511831688297};\\\", \\\"{x:415,y:689,t:1511831688309};\\\", \\\"{x:419,y:688,t:1511831688326};\\\", \\\"{x:422,y:687,t:1511831688343};\\\", \\\"{x:424,y:686,t:1511831688359};\\\", \\\"{x:426,y:685,t:1511831688376};\\\", \\\"{x:435,y:679,t:1511831688393};\\\", \\\"{x:449,y:671,t:1511831688409};\\\", \\\"{x:465,y:663,t:1511831688426};\\\", \\\"{x:488,y:658,t:1511831688443};\\\", \\\"{x:517,y:647,t:1511831688459};\\\", \\\"{x:547,y:640,t:1511831688476};\\\", \\\"{x:576,y:629,t:1511831688493};\\\", \\\"{x:599,y:621,t:1511831688509};\\\", \\\"{x:621,y:612,t:1511831688526};\\\", \\\"{x:640,y:604,t:1511831688543};\\\", \\\"{x:657,y:597,t:1511831688559};\\\", \\\"{x:676,y:589,t:1511831688576};\\\", \\\"{x:697,y:574,t:1511831688592};\\\", \\\"{x:717,y:563,t:1511831688609};\\\", \\\"{x:735,y:552,t:1511831688626};\\\", \\\"{x:750,y:540,t:1511831688643};\\\", \\\"{x:763,y:528,t:1511831688659};\\\", \\\"{x:773,y:519,t:1511831688676};\\\", \\\"{x:778,y:514,t:1511831688693};\\\", \\\"{x:782,y:510,t:1511831688709};\\\", \\\"{x:782,y:505,t:1511831688726};\\\", \\\"{x:785,y:497,t:1511831688743};\\\", \\\"{x:787,y:491,t:1511831688760};\\\", \\\"{x:789,y:481,t:1511831688778};\\\", \\\"{x:789,y:476,t:1511831688793};\\\", \\\"{x:789,y:471,t:1511831688810};\\\", \\\"{x:789,y:468,t:1511831688826};\\\" ] }, { \\\"rt\\\": 17913, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 500101, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -M -M -B -B -F -F -F -M -01 PM-C -11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:788,y:468,t:1511831689754};\\\", \\\"{x:786,y:468,t:1511831689770};\\\", \\\"{x:789,y:467,t:1511831690202};\\\", \\\"{x:796,y:463,t:1511831690212};\\\", \\\"{x:806,y:459,t:1511831690228};\\\", \\\"{x:813,y:456,t:1511831690245};\\\", \\\"{x:827,y:454,t:1511831690262};\\\", \\\"{x:840,y:454,t:1511831690278};\\\", \\\"{x:858,y:455,t:1511831690295};\\\", \\\"{x:880,y:457,t:1511831690312};\\\", \\\"{x:911,y:462,t:1511831690328};\\\", \\\"{x:948,y:464,t:1511831690345};\\\", \\\"{x:998,y:470,t:1511831690361};\\\", \\\"{x:1015,y:474,t:1511831690380};\\\", \\\"{x:1027,y:480,t:1511831690395};\\\", \\\"{x:1042,y:492,t:1511831690412};\\\", \\\"{x:1059,y:508,t:1511831690429};\\\", \\\"{x:1074,y:528,t:1511831690445};\\\", \\\"{x:1087,y:550,t:1511831690462};\\\", \\\"{x:1098,y:574,t:1511831690479};\\\", \\\"{x:1108,y:604,t:1511831690495};\\\", \\\"{x:1119,y:646,t:1511831690512};\\\", \\\"{x:1124,y:699,t:1511831690529};\\\", \\\"{x:1124,y:713,t:1511831690545};\\\", \\\"{x:1112,y:758,t:1511831690562};\\\", \\\"{x:1107,y:798,t:1511831690578};\\\", \\\"{x:1103,y:836,t:1511831690594};\\\", \\\"{x:1098,y:863,t:1511831690611};\\\", \\\"{x:1093,y:881,t:1511831690628};\\\", \\\"{x:1089,y:890,t:1511831690644};\\\", \\\"{x:1089,y:894,t:1511831690661};\\\", \\\"{x:1089,y:897,t:1511831690678};\\\", \\\"{x:1089,y:898,t:1511831690694};\\\", \\\"{x:1089,y:899,t:1511831690711};\\\", \\\"{x:1093,y:901,t:1511831690761};\\\", \\\"{x:1113,y:907,t:1511831690780};\\\", \\\"{x:1135,y:912,t:1511831690796};\\\", \\\"{x:1160,y:919,t:1511831690812};\\\", \\\"{x:1180,y:924,t:1511831690829};\\\", \\\"{x:1191,y:928,t:1511831690846};\\\", \\\"{x:1194,y:929,t:1511831690862};\\\", \\\"{x:1195,y:930,t:1511831690962};\\\", \\\"{x:1195,y:929,t:1511831691106};\\\", \\\"{x:1195,y:926,t:1511831691113};\\\", \\\"{x:1195,y:925,t:1511831691128};\\\", \\\"{x:1195,y:918,t:1511831691145};\\\", \\\"{x:1195,y:913,t:1511831691161};\\\", \\\"{x:1194,y:907,t:1511831691179};\\\", \\\"{x:1194,y:904,t:1511831691195};\\\", \\\"{x:1194,y:903,t:1511831691217};\\\", \\\"{x:1193,y:903,t:1511831691241};\\\", \\\"{x:1192,y:900,t:1511831691251};\\\", \\\"{x:1192,y:899,t:1511831691369};\\\", \\\"{x:1192,y:897,t:1511831691393};\\\", \\\"{x:1192,y:894,t:1511831691400};\\\", \\\"{x:1192,y:893,t:1511831691412};\\\", \\\"{x:1191,y:893,t:1511831691428};\\\", \\\"{x:1191,y:892,t:1511831691445};\\\", \\\"{x:1189,y:885,t:1511831691706};\\\", \\\"{x:1185,y:874,t:1511831691714};\\\", \\\"{x:1179,y:858,t:1511831691729};\\\", \\\"{x:1170,y:840,t:1511831691746};\\\", \\\"{x:1166,y:827,t:1511831691763};\\\", \\\"{x:1165,y:824,t:1511831691780};\\\", \\\"{x:1165,y:821,t:1511831691796};\\\", \\\"{x:1165,y:819,t:1511831691813};\\\", \\\"{x:1165,y:816,t:1511831691830};\\\", \\\"{x:1165,y:810,t:1511831691846};\\\", \\\"{x:1165,y:805,t:1511831691863};\\\", \\\"{x:1165,y:799,t:1511831691880};\\\", \\\"{x:1164,y:793,t:1511831691896};\\\", \\\"{x:1164,y:791,t:1511831691913};\\\", \\\"{x:1162,y:786,t:1511831691929};\\\", \\\"{x:1162,y:782,t:1511831691946};\\\", \\\"{x:1162,y:779,t:1511831691963};\\\", \\\"{x:1161,y:772,t:1511831691980};\\\", \\\"{x:1161,y:768,t:1511831691996};\\\", \\\"{x:1160,y:764,t:1511831692013};\\\", \\\"{x:1159,y:760,t:1511831692029};\\\", \\\"{x:1159,y:757,t:1511831692047};\\\", \\\"{x:1158,y:754,t:1511831692063};\\\", \\\"{x:1157,y:752,t:1511831692080};\\\", \\\"{x:1157,y:751,t:1511831692097};\\\", \\\"{x:1157,y:750,t:1511831692513};\\\", \\\"{x:1155,y:747,t:1511831692529};\\\", \\\"{x:1155,y:740,t:1511831692547};\\\", \\\"{x:1154,y:732,t:1511831692564};\\\", \\\"{x:1154,y:721,t:1511831692579};\\\", \\\"{x:1154,y:707,t:1511831692596};\\\", \\\"{x:1154,y:694,t:1511831692614};\\\", \\\"{x:1154,y:688,t:1511831692630};\\\", \\\"{x:1154,y:683,t:1511831692646};\\\", \\\"{x:1154,y:680,t:1511831692663};\\\", \\\"{x:1154,y:686,t:1511831692857};\\\", \\\"{x:1154,y:696,t:1511831692866};\\\", \\\"{x:1155,y:703,t:1511831692880};\\\", \\\"{x:1156,y:716,t:1511831692897};\\\", \\\"{x:1161,y:733,t:1511831692913};\\\", \\\"{x:1163,y:749,t:1511831692930};\\\", \\\"{x:1171,y:774,t:1511831692947};\\\", \\\"{x:1174,y:803,t:1511831692964};\\\", \\\"{x:1179,y:832,t:1511831692981};\\\", \\\"{x:1183,y:859,t:1511831692997};\\\", \\\"{x:1189,y:886,t:1511831693014};\\\", \\\"{x:1194,y:914,t:1511831693031};\\\", \\\"{x:1198,y:943,t:1511831693047};\\\", \\\"{x:1203,y:967,t:1511831693064};\\\", \\\"{x:1207,y:980,t:1511831693081};\\\", \\\"{x:1208,y:982,t:1511831693097};\\\", \\\"{x:1208,y:983,t:1511831693114};\\\", \\\"{x:1208,y:984,t:1511831693161};\\\", \\\"{x:1207,y:984,t:1511831693185};\\\", \\\"{x:1203,y:984,t:1511831693289};\\\", \\\"{x:1199,y:984,t:1511831693298};\\\", \\\"{x:1192,y:984,t:1511831693314};\\\", \\\"{x:1190,y:984,t:1511831693331};\\\", \\\"{x:1189,y:984,t:1511831693347};\\\", \\\"{x:1188,y:984,t:1511831693364};\\\", \\\"{x:1187,y:984,t:1511831693393};\\\", \\\"{x:1186,y:983,t:1511831693409};\\\", \\\"{x:1185,y:983,t:1511831693417};\\\", \\\"{x:1185,y:982,t:1511831693433};\\\", \\\"{x:1185,y:981,t:1511831693448};\\\", \\\"{x:1184,y:980,t:1511831693464};\\\", \\\"{x:1183,y:978,t:1511831693481};\\\", \\\"{x:1183,y:977,t:1511831693498};\\\", \\\"{x:1182,y:976,t:1511831693514};\\\", \\\"{x:1182,y:975,t:1511831693545};\\\", \\\"{x:1182,y:974,t:1511831693553};\\\", \\\"{x:1181,y:972,t:1511831693569};\\\", \\\"{x:1181,y:970,t:1511831693650};\\\", \\\"{x:1181,y:967,t:1511831693778};\\\", \\\"{x:1182,y:963,t:1511831693785};\\\", \\\"{x:1183,y:961,t:1511831693798};\\\", \\\"{x:1183,y:957,t:1511831693814};\\\", \\\"{x:1183,y:954,t:1511831693831};\\\", \\\"{x:1183,y:952,t:1511831693848};\\\", \\\"{x:1183,y:951,t:1511831694353};\\\", \\\"{x:1181,y:952,t:1511831694377};\\\", \\\"{x:1180,y:955,t:1511831694385};\\\", \\\"{x:1179,y:955,t:1511831694398};\\\", \\\"{x:1176,y:958,t:1511831694415};\\\", \\\"{x:1175,y:960,t:1511831694432};\\\", \\\"{x:1175,y:961,t:1511831694448};\\\", \\\"{x:1174,y:961,t:1511831694465};\\\", \\\"{x:1174,y:962,t:1511831694513};\\\", \\\"{x:1172,y:964,t:1511831694521};\\\", \\\"{x:1170,y:966,t:1511831694545};\\\", \\\"{x:1169,y:966,t:1511831694553};\\\", \\\"{x:1168,y:968,t:1511831694565};\\\", \\\"{x:1167,y:968,t:1511831694582};\\\", \\\"{x:1166,y:969,t:1511831694598};\\\", \\\"{x:1165,y:969,t:1511831694673};\\\", \\\"{x:1164,y:969,t:1511831694681};\\\", \\\"{x:1162,y:970,t:1511831694705};\\\", \\\"{x:1162,y:971,t:1511831695409};\\\", \\\"{x:1160,y:971,t:1511831695417};\\\", \\\"{x:1159,y:971,t:1511831695432};\\\", \\\"{x:1154,y:972,t:1511831695449};\\\", \\\"{x:1149,y:973,t:1511831695465};\\\", \\\"{x:1149,y:971,t:1511831695962};\\\", \\\"{x:1149,y:969,t:1511831695970};\\\", \\\"{x:1150,y:966,t:1511831695984};\\\", \\\"{x:1156,y:957,t:1511831696000};\\\", \\\"{x:1164,y:949,t:1511831696017};\\\", \\\"{x:1170,y:938,t:1511831696034};\\\", \\\"{x:1172,y:934,t:1511831696050};\\\", \\\"{x:1173,y:931,t:1511831696067};\\\", \\\"{x:1173,y:929,t:1511831696084};\\\", \\\"{x:1174,y:925,t:1511831696101};\\\", \\\"{x:1175,y:924,t:1511831696117};\\\", \\\"{x:1176,y:922,t:1511831696134};\\\", \\\"{x:1177,y:917,t:1511831696151};\\\", \\\"{x:1179,y:911,t:1511831696167};\\\", \\\"{x:1180,y:904,t:1511831696184};\\\", \\\"{x:1180,y:898,t:1511831696201};\\\", \\\"{x:1183,y:894,t:1511831696217};\\\", \\\"{x:1183,y:890,t:1511831696410};\\\", \\\"{x:1184,y:886,t:1511831696418};\\\", \\\"{x:1189,y:875,t:1511831696434};\\\", \\\"{x:1199,y:854,t:1511831696451};\\\", \\\"{x:1219,y:829,t:1511831696467};\\\", \\\"{x:1257,y:787,t:1511831696484};\\\", \\\"{x:1306,y:730,t:1511831696501};\\\", \\\"{x:1337,y:685,t:1511831696518};\\\", \\\"{x:1345,y:663,t:1511831696534};\\\", \\\"{x:1342,y:648,t:1511831696551};\\\", \\\"{x:1319,y:636,t:1511831696568};\\\", \\\"{x:1254,y:625,t:1511831696584};\\\", \\\"{x:1174,y:625,t:1511831696601};\\\", \\\"{x:994,y:625,t:1511831696618};\\\", \\\"{x:856,y:625,t:1511831696634};\\\", \\\"{x:720,y:625,t:1511831696650};\\\", \\\"{x:626,y:625,t:1511831696668};\\\", \\\"{x:567,y:625,t:1511831696684};\\\", \\\"{x:525,y:625,t:1511831696700};\\\", \\\"{x:506,y:622,t:1511831696718};\\\", \\\"{x:497,y:621,t:1511831696734};\\\", \\\"{x:495,y:621,t:1511831696751};\\\", \\\"{x:493,y:621,t:1511831696826};\\\", \\\"{x:489,y:617,t:1511831696834};\\\", \\\"{x:469,y:603,t:1511831696851};\\\", \\\"{x:446,y:593,t:1511831696868};\\\", \\\"{x:412,y:583,t:1511831696884};\\\", \\\"{x:377,y:574,t:1511831696901};\\\", \\\"{x:357,y:570,t:1511831696917};\\\", \\\"{x:343,y:569,t:1511831696935};\\\", \\\"{x:339,y:569,t:1511831696950};\\\", \\\"{x:338,y:567,t:1511831697026};\\\", \\\"{x:338,y:566,t:1511831697034};\\\", \\\"{x:338,y:562,t:1511831697051};\\\", \\\"{x:338,y:560,t:1511831697067};\\\", \\\"{x:339,y:557,t:1511831697084};\\\", \\\"{x:342,y:556,t:1511831697101};\\\", \\\"{x:347,y:553,t:1511831697117};\\\", \\\"{x:350,y:552,t:1511831697134};\\\", \\\"{x:351,y:552,t:1511831697154};\\\", \\\"{x:352,y:552,t:1511831697170};\\\", \\\"{x:353,y:550,t:1511831697186};\\\", \\\"{x:352,y:550,t:1511831697314};\\\", \\\"{x:350,y:550,t:1511831697322};\\\", \\\"{x:346,y:550,t:1511831697334};\\\", \\\"{x:336,y:550,t:1511831697351};\\\", \\\"{x:322,y:549,t:1511831697368};\\\", \\\"{x:312,y:549,t:1511831697384};\\\", \\\"{x:309,y:549,t:1511831697401};\\\", \\\"{x:308,y:549,t:1511831697417};\\\", \\\"{x:308,y:552,t:1511831697914};\\\", \\\"{x:317,y:561,t:1511831697922};\\\", \\\"{x:339,y:576,t:1511831697935};\\\", \\\"{x:449,y:623,t:1511831697952};\\\", \\\"{x:595,y:683,t:1511831697969};\\\", \\\"{x:738,y:749,t:1511831697985};\\\", \\\"{x:919,y:853,t:1511831698002};\\\", \\\"{x:997,y:909,t:1511831698018};\\\", \\\"{x:1043,y:945,t:1511831698035};\\\", \\\"{x:1062,y:964,t:1511831698052};\\\", \\\"{x:1069,y:977,t:1511831698069};\\\", \\\"{x:1073,y:983,t:1511831698085};\\\", \\\"{x:1079,y:996,t:1511831698102};\\\", \\\"{x:1088,y:1007,t:1511831698119};\\\", \\\"{x:1103,y:1017,t:1511831698134};\\\", \\\"{x:1133,y:1034,t:1511831698151};\\\", \\\"{x:1161,y:1048,t:1511831698168};\\\", \\\"{x:1177,y:1056,t:1511831698184};\\\", \\\"{x:1189,y:1061,t:1511831698201};\\\", \\\"{x:1190,y:1061,t:1511831698241};\\\", \\\"{x:1192,y:1061,t:1511831698251};\\\", \\\"{x:1193,y:1051,t:1511831698268};\\\", \\\"{x:1197,y:1042,t:1511831698285};\\\", \\\"{x:1198,y:1030,t:1511831698301};\\\", \\\"{x:1200,y:1016,t:1511831698319};\\\", \\\"{x:1200,y:1003,t:1511831698336};\\\", \\\"{x:1194,y:989,t:1511831698351};\\\", \\\"{x:1179,y:973,t:1511831698368};\\\", \\\"{x:1170,y:966,t:1511831698386};\\\", \\\"{x:1170,y:965,t:1511831698402};\\\", \\\"{x:1168,y:965,t:1511831698586};\\\", \\\"{x:1165,y:966,t:1511831698602};\\\", \\\"{x:1161,y:967,t:1511831698619};\\\", \\\"{x:1156,y:970,t:1511831698636};\\\", \\\"{x:1155,y:971,t:1511831698652};\\\", \\\"{x:1154,y:972,t:1511831698794};\\\", \\\"{x:1153,y:973,t:1511831698802};\\\", \\\"{x:1150,y:974,t:1511831698819};\\\", \\\"{x:1147,y:976,t:1511831698836};\\\", \\\"{x:1146,y:976,t:1511831698853};\\\", \\\"{x:1148,y:974,t:1511831699818};\\\", \\\"{x:1151,y:970,t:1511831699825};\\\", \\\"{x:1155,y:965,t:1511831699836};\\\", \\\"{x:1163,y:960,t:1511831699852};\\\", \\\"{x:1166,y:957,t:1511831699869};\\\", \\\"{x:1170,y:953,t:1511831699886};\\\", \\\"{x:1170,y:951,t:1511831699902};\\\", \\\"{x:1172,y:950,t:1511831699919};\\\", \\\"{x:1173,y:947,t:1511831699937};\\\", \\\"{x:1174,y:944,t:1511831699953};\\\", \\\"{x:1177,y:940,t:1511831699969};\\\", \\\"{x:1178,y:937,t:1511831699987};\\\", \\\"{x:1179,y:935,t:1511831700010};\\\", \\\"{x:1180,y:934,t:1511831700021};\\\", \\\"{x:1180,y:931,t:1511831700161};\\\", \\\"{x:1181,y:929,t:1511831700169};\\\", \\\"{x:1182,y:925,t:1511831700186};\\\", \\\"{x:1183,y:922,t:1511831700203};\\\", \\\"{x:1184,y:920,t:1511831700219};\\\", \\\"{x:1176,y:920,t:1511831700586};\\\", \\\"{x:1146,y:920,t:1511831700603};\\\", \\\"{x:1093,y:913,t:1511831700620};\\\", \\\"{x:1021,y:902,t:1511831700636};\\\", \\\"{x:920,y:886,t:1511831700653};\\\", \\\"{x:824,y:861,t:1511831700670};\\\", \\\"{x:735,y:834,t:1511831700686};\\\", \\\"{x:654,y:795,t:1511831700703};\\\", \\\"{x:583,y:766,t:1511831700720};\\\", \\\"{x:527,y:739,t:1511831700736};\\\", \\\"{x:486,y:714,t:1511831700753};\\\", \\\"{x:463,y:703,t:1511831700770};\\\", \\\"{x:434,y:685,t:1511831700787};\\\", \\\"{x:407,y:673,t:1511831700803};\\\", \\\"{x:382,y:659,t:1511831700820};\\\", \\\"{x:356,y:646,t:1511831700836};\\\", \\\"{x:317,y:635,t:1511831700853};\\\", \\\"{x:284,y:628,t:1511831700870};\\\", \\\"{x:272,y:628,t:1511831700887};\\\", \\\"{x:269,y:628,t:1511831700903};\\\", \\\"{x:269,y:629,t:1511831700921};\\\", \\\"{x:279,y:630,t:1511831700937};\\\", \\\"{x:288,y:630,t:1511831700953};\\\", \\\"{x:293,y:630,t:1511831700970};\\\", \\\"{x:295,y:628,t:1511831700987};\\\", \\\"{x:299,y:628,t:1511831701003};\\\", \\\"{x:313,y:623,t:1511831701020};\\\", \\\"{x:329,y:614,t:1511831701037};\\\", \\\"{x:351,y:606,t:1511831701053};\\\", \\\"{x:372,y:599,t:1511831701071};\\\", \\\"{x:385,y:593,t:1511831701087};\\\", \\\"{x:389,y:590,t:1511831701103};\\\", \\\"{x:391,y:589,t:1511831701120};\\\", \\\"{x:391,y:585,t:1511831701137};\\\", \\\"{x:391,y:580,t:1511831701154};\\\", \\\"{x:391,y:576,t:1511831701170};\\\", \\\"{x:391,y:575,t:1511831701188};\\\", \\\"{x:391,y:572,t:1511831701204};\\\", \\\"{x:391,y:568,t:1511831701220};\\\", \\\"{x:391,y:565,t:1511831701237};\\\", \\\"{x:391,y:563,t:1511831701254};\\\", \\\"{x:391,y:562,t:1511831701271};\\\", \\\"{x:394,y:561,t:1511831701288};\\\", \\\"{x:396,y:560,t:1511831701305};\\\", \\\"{x:399,y:558,t:1511831701320};\\\", \\\"{x:404,y:558,t:1511831701337};\\\", \\\"{x:419,y:558,t:1511831701354};\\\", \\\"{x:448,y:564,t:1511831701371};\\\", \\\"{x:473,y:567,t:1511831701387};\\\", \\\"{x:496,y:571,t:1511831701404};\\\", \\\"{x:515,y:572,t:1511831701420};\\\", \\\"{x:523,y:572,t:1511831701437};\\\", \\\"{x:524,y:572,t:1511831701455};\\\", \\\"{x:525,y:572,t:1511831701470};\\\", \\\"{x:527,y:572,t:1511831701487};\\\", \\\"{x:531,y:572,t:1511831701504};\\\", \\\"{x:538,y:572,t:1511831701521};\\\", \\\"{x:539,y:572,t:1511831701537};\\\", \\\"{x:541,y:572,t:1511831701554};\\\", \\\"{x:539,y:572,t:1511831701650};\\\", \\\"{x:538,y:572,t:1511831701657};\\\", \\\"{x:537,y:572,t:1511831701671};\\\", \\\"{x:534,y:573,t:1511831701687};\\\", \\\"{x:533,y:574,t:1511831701713};\\\", \\\"{x:536,y:576,t:1511831701722};\\\", \\\"{x:551,y:581,t:1511831701737};\\\", \\\"{x:571,y:584,t:1511831701754};\\\", \\\"{x:596,y:587,t:1511831701772};\\\", \\\"{x:616,y:587,t:1511831701787};\\\", \\\"{x:622,y:587,t:1511831701804};\\\", \\\"{x:623,y:587,t:1511831701821};\\\", \\\"{x:621,y:588,t:1511831701994};\\\", \\\"{x:617,y:590,t:1511831702913};\\\", \\\"{x:606,y:596,t:1511831702923};\\\", \\\"{x:596,y:601,t:1511831702940};\\\", \\\"{x:583,y:606,t:1511831702955};\\\", \\\"{x:569,y:614,t:1511831702972};\\\", \\\"{x:561,y:616,t:1511831702988};\\\", \\\"{x:554,y:620,t:1511831703005};\\\", \\\"{x:553,y:621,t:1511831703022};\\\", \\\"{x:552,y:621,t:1511831703038};\\\", \\\"{x:552,y:622,t:1511831703057};\\\", \\\"{x:551,y:622,t:1511831703072};\\\", \\\"{x:548,y:625,t:1511831703089};\\\", \\\"{x:546,y:627,t:1511831703105};\\\", \\\"{x:543,y:629,t:1511831703122};\\\", \\\"{x:537,y:630,t:1511831703139};\\\", \\\"{x:532,y:634,t:1511831703155};\\\", \\\"{x:530,y:634,t:1511831703226};\\\", \\\"{x:528,y:633,t:1511831703240};\\\", \\\"{x:517,y:623,t:1511831703255};\\\", \\\"{x:510,y:619,t:1511831703273};\\\", \\\"{x:508,y:618,t:1511831703290};\\\", \\\"{x:507,y:618,t:1511831703305};\\\", \\\"{x:506,y:616,t:1511831703337};\\\", \\\"{x:506,y:613,t:1511831703345};\\\", \\\"{x:506,y:610,t:1511831703355};\\\", \\\"{x:506,y:604,t:1511831703373};\\\", \\\"{x:505,y:598,t:1511831703390};\\\", \\\"{x:505,y:593,t:1511831703405};\\\", \\\"{x:505,y:589,t:1511831703422};\\\", \\\"{x:505,y:586,t:1511831703439};\\\", \\\"{x:507,y:582,t:1511831703456};\\\", \\\"{x:507,y:581,t:1511831703945};\\\", \\\"{x:498,y:581,t:1511831703956};\\\", \\\"{x:470,y:581,t:1511831703972};\\\", \\\"{x:458,y:581,t:1511831703989};\\\", \\\"{x:449,y:580,t:1511831704006};\\\", \\\"{x:440,y:579,t:1511831704023};\\\", \\\"{x:433,y:577,t:1511831704039};\\\", \\\"{x:420,y:577,t:1511831704056};\\\", \\\"{x:384,y:574,t:1511831704073};\\\", \\\"{x:346,y:567,t:1511831704089};\\\", \\\"{x:321,y:562,t:1511831704106};\\\", \\\"{x:297,y:553,t:1511831704123};\\\", \\\"{x:282,y:546,t:1511831704139};\\\", \\\"{x:279,y:545,t:1511831704156};\\\", \\\"{x:279,y:544,t:1511831704173};\\\", \\\"{x:278,y:543,t:1511831704189};\\\", \\\"{x:278,y:544,t:1511831704266};\\\", \\\"{x:278,y:548,t:1511831704274};\\\", \\\"{x:276,y:561,t:1511831704290};\\\", \\\"{x:276,y:571,t:1511831704306};\\\", \\\"{x:276,y:581,t:1511831704324};\\\", \\\"{x:276,y:585,t:1511831704340};\\\", \\\"{x:276,y:588,t:1511831704356};\\\", \\\"{x:275,y:592,t:1511831704374};\\\", \\\"{x:274,y:595,t:1511831704390};\\\", \\\"{x:274,y:597,t:1511831704406};\\\", \\\"{x:272,y:596,t:1511831704538};\\\", \\\"{x:271,y:593,t:1511831704545};\\\", \\\"{x:267,y:588,t:1511831704556};\\\", \\\"{x:256,y:578,t:1511831704573};\\\", \\\"{x:235,y:568,t:1511831704591};\\\", \\\"{x:213,y:557,t:1511831704606};\\\", \\\"{x:200,y:554,t:1511831704623};\\\", \\\"{x:192,y:551,t:1511831704641};\\\", \\\"{x:190,y:551,t:1511831704656};\\\", \\\"{x:188,y:551,t:1511831704906};\\\", \\\"{x:187,y:552,t:1511831704921};\\\", \\\"{x:187,y:553,t:1511831704929};\\\", \\\"{x:186,y:554,t:1511831704941};\\\", \\\"{x:185,y:555,t:1511831704957};\\\", \\\"{x:184,y:556,t:1511831705018};\\\", \\\"{x:182,y:556,t:1511831705033};\\\", \\\"{x:181,y:557,t:1511831705041};\\\", \\\"{x:179,y:557,t:1511831705057};\\\", \\\"{x:176,y:558,t:1511831705073};\\\", \\\"{x:175,y:559,t:1511831705091};\\\", \\\"{x:175,y:561,t:1511831705265};\\\", \\\"{x:177,y:566,t:1511831705273};\\\", \\\"{x:202,y:583,t:1511831705290};\\\", \\\"{x:235,y:609,t:1511831705307};\\\", \\\"{x:263,y:628,t:1511831705323};\\\", \\\"{x:279,y:641,t:1511831705340};\\\", \\\"{x:290,y:655,t:1511831705357};\\\", \\\"{x:298,y:665,t:1511831705373};\\\", \\\"{x:305,y:675,t:1511831705390};\\\", \\\"{x:314,y:686,t:1511831705407};\\\", \\\"{x:321,y:698,t:1511831705423};\\\", \\\"{x:327,y:703,t:1511831705440};\\\", \\\"{x:331,y:705,t:1511831705457};\\\", \\\"{x:331,y:702,t:1511831705505};\\\", \\\"{x:330,y:696,t:1511831705513};\\\", \\\"{x:329,y:688,t:1511831705523};\\\", \\\"{x:321,y:671,t:1511831705540};\\\", \\\"{x:307,y:652,t:1511831705557};\\\", \\\"{x:282,y:635,t:1511831705574};\\\", \\\"{x:265,y:628,t:1511831705590};\\\", \\\"{x:257,y:625,t:1511831705607};\\\", \\\"{x:251,y:621,t:1511831705623};\\\", \\\"{x:247,y:621,t:1511831705640};\\\", \\\"{x:244,y:619,t:1511831705656};\\\", \\\"{x:243,y:618,t:1511831705673};\\\", \\\"{x:239,y:614,t:1511831705690};\\\", \\\"{x:232,y:604,t:1511831705707};\\\", \\\"{x:224,y:591,t:1511831705723};\\\", \\\"{x:217,y:582,t:1511831705740};\\\", \\\"{x:214,y:576,t:1511831705757};\\\", \\\"{x:211,y:573,t:1511831705773};\\\", \\\"{x:210,y:568,t:1511831705790};\\\", \\\"{x:207,y:562,t:1511831705807};\\\", \\\"{x:202,y:556,t:1511831705823};\\\", \\\"{x:195,y:549,t:1511831705840};\\\", \\\"{x:182,y:541,t:1511831705857};\\\", \\\"{x:178,y:539,t:1511831705873};\\\", \\\"{x:177,y:539,t:1511831705890};\\\", \\\"{x:176,y:539,t:1511831705913};\\\", \\\"{x:175,y:539,t:1511831705923};\\\", \\\"{x:175,y:540,t:1511831705969};\\\", \\\"{x:174,y:540,t:1511831705977};\\\", \\\"{x:174,y:541,t:1511831705990};\\\", \\\"{x:172,y:544,t:1511831706007};\\\", \\\"{x:172,y:545,t:1511831706024};\\\", \\\"{x:172,y:546,t:1511831706041};\\\", \\\"{x:172,y:549,t:1511831706057};\\\", \\\"{x:174,y:556,t:1511831706074};\\\", \\\"{x:176,y:559,t:1511831706091};\\\", \\\"{x:178,y:561,t:1511831706107};\\\", \\\"{x:179,y:561,t:1511831706124};\\\", \\\"{x:179,y:562,t:1511831706140};\\\", \\\"{x:180,y:563,t:1511831706376};\\\", \\\"{x:187,y:569,t:1511831706391};\\\", \\\"{x:207,y:584,t:1511831706408};\\\", \\\"{x:236,y:610,t:1511831706424};\\\", \\\"{x:316,y:707,t:1511831706441};\\\", \\\"{x:361,y:767,t:1511831706458};\\\", \\\"{x:388,y:789,t:1511831706474};\\\", \\\"{x:392,y:793,t:1511831706491};\\\", \\\"{x:391,y:787,t:1511831706529};\\\", \\\"{x:384,y:777,t:1511831706541};\\\", \\\"{x:372,y:760,t:1511831706558};\\\", \\\"{x:359,y:744,t:1511831706575};\\\", \\\"{x:347,y:730,t:1511831706592};\\\", \\\"{x:340,y:724,t:1511831706608};\\\", \\\"{x:339,y:723,t:1511831706625};\\\", \\\"{x:339,y:721,t:1511831706641};\\\", \\\"{x:339,y:720,t:1511831706658};\\\", \\\"{x:339,y:718,t:1511831706675};\\\", \\\"{x:339,y:716,t:1511831706691};\\\", \\\"{x:339,y:713,t:1511831706708};\\\", \\\"{x:339,y:709,t:1511831706725};\\\", \\\"{x:349,y:704,t:1511831706741};\\\", \\\"{x:358,y:698,t:1511831706758};\\\", \\\"{x:366,y:693,t:1511831706775};\\\", \\\"{x:369,y:690,t:1511831706791};\\\", \\\"{x:371,y:689,t:1511831706808};\\\", \\\"{x:372,y:689,t:1511831706825};\\\", \\\"{x:373,y:689,t:1511831706841};\\\", \\\"{x:374,y:688,t:1511831707161};\\\", \\\"{x:371,y:693,t:1511831707785};\\\", \\\"{x:339,y:715,t:1511831707793};\\\", \\\"{x:237,y:784,t:1511831707809};\\\", \\\"{x:179,y:831,t:1511831707825};\\\" ] }, { \\\"rt\\\": 6257, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 507629, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:360,y:622,t:1511831708216};\\\", \\\"{x:366,y:607,t:1511831708227};\\\", \\\"{x:379,y:576,t:1511831708254};\\\", \\\"{x:383,y:564,t:1511831708258};\\\", \\\"{x:386,y:549,t:1511831708275};\\\", \\\"{x:391,y:527,t:1511831708292};\\\", \\\"{x:395,y:512,t:1511831708311};\\\", \\\"{x:396,y:504,t:1511831708325};\\\", \\\"{x:396,y:500,t:1511831708342};\\\", \\\"{x:398,y:497,t:1511831708609};\\\", \\\"{x:423,y:480,t:1511831708626};\\\", \\\"{x:467,y:460,t:1511831708643};\\\", \\\"{x:491,y:453,t:1511831708659};\\\", \\\"{x:513,y:450,t:1511831708676};\\\", \\\"{x:535,y:445,t:1511831708693};\\\", \\\"{x:557,y:443,t:1511831708709};\\\", \\\"{x:571,y:440,t:1511831708726};\\\", \\\"{x:576,y:440,t:1511831708743};\\\", \\\"{x:580,y:439,t:1511831708760};\\\", \\\"{x:588,y:439,t:1511831708776};\\\", \\\"{x:600,y:439,t:1511831708793};\\\", \\\"{x:610,y:437,t:1511831708810};\\\", \\\"{x:626,y:435,t:1511831708826};\\\", \\\"{x:642,y:435,t:1511831708843};\\\", \\\"{x:672,y:435,t:1511831708860};\\\", \\\"{x:706,y:435,t:1511831708876};\\\", \\\"{x:745,y:435,t:1511831708893};\\\", \\\"{x:786,y:438,t:1511831708910};\\\", \\\"{x:829,y:445,t:1511831708927};\\\", \\\"{x:883,y:455,t:1511831708944};\\\", \\\"{x:914,y:459,t:1511831708960};\\\", \\\"{x:944,y:464,t:1511831708976};\\\", \\\"{x:957,y:465,t:1511831708993};\\\", \\\"{x:963,y:466,t:1511831709010};\\\", \\\"{x:967,y:469,t:1511831709026};\\\", \\\"{x:972,y:470,t:1511831709043};\\\", \\\"{x:981,y:474,t:1511831709061};\\\", \\\"{x:992,y:479,t:1511831709077};\\\", \\\"{x:1013,y:486,t:1511831709094};\\\", \\\"{x:1041,y:491,t:1511831709111};\\\", \\\"{x:1078,y:498,t:1511831709127};\\\", \\\"{x:1117,y:503,t:1511831709144};\\\", \\\"{x:1157,y:509,t:1511831709161};\\\", \\\"{x:1206,y:516,t:1511831709177};\\\", \\\"{x:1240,y:521,t:1511831709194};\\\", \\\"{x:1265,y:524,t:1511831709211};\\\", \\\"{x:1279,y:527,t:1511831709228};\\\", \\\"{x:1294,y:527,t:1511831709244};\\\", \\\"{x:1310,y:529,t:1511831709261};\\\", \\\"{x:1325,y:532,t:1511831709278};\\\", \\\"{x:1337,y:536,t:1511831709294};\\\", \\\"{x:1346,y:541,t:1511831709311};\\\", \\\"{x:1352,y:544,t:1511831709328};\\\", \\\"{x:1359,y:548,t:1511831709344};\\\", \\\"{x:1364,y:554,t:1511831709361};\\\", \\\"{x:1372,y:563,t:1511831709377};\\\", \\\"{x:1377,y:569,t:1511831709394};\\\", \\\"{x:1382,y:579,t:1511831709411};\\\", \\\"{x:1391,y:591,t:1511831709428};\\\", \\\"{x:1396,y:608,t:1511831709444};\\\", \\\"{x:1397,y:622,t:1511831709460};\\\", \\\"{x:1398,y:639,t:1511831709477};\\\", \\\"{x:1401,y:654,t:1511831709493};\\\", \\\"{x:1401,y:669,t:1511831709510};\\\", \\\"{x:1401,y:683,t:1511831709527};\\\", \\\"{x:1399,y:697,t:1511831709543};\\\", \\\"{x:1393,y:719,t:1511831709560};\\\", \\\"{x:1389,y:731,t:1511831709577};\\\", \\\"{x:1387,y:739,t:1511831709593};\\\", \\\"{x:1384,y:750,t:1511831709610};\\\", \\\"{x:1380,y:759,t:1511831709627};\\\", \\\"{x:1374,y:768,t:1511831709644};\\\", \\\"{x:1365,y:782,t:1511831709660};\\\", \\\"{x:1357,y:797,t:1511831709677};\\\", \\\"{x:1347,y:808,t:1511831709694};\\\", \\\"{x:1338,y:818,t:1511831709710};\\\", \\\"{x:1330,y:825,t:1511831709728};\\\", \\\"{x:1326,y:827,t:1511831709745};\\\", \\\"{x:1324,y:827,t:1511831709761};\\\", \\\"{x:1323,y:827,t:1511831709778};\\\", \\\"{x:1322,y:827,t:1511831709801};\\\", \\\"{x:1321,y:827,t:1511831709841};\\\", \\\"{x:1321,y:826,t:1511831709849};\\\", \\\"{x:1321,y:824,t:1511831709861};\\\", \\\"{x:1321,y:818,t:1511831709877};\\\", \\\"{x:1325,y:808,t:1511831709895};\\\", \\\"{x:1327,y:800,t:1511831709911};\\\", \\\"{x:1330,y:795,t:1511831709928};\\\", \\\"{x:1331,y:792,t:1511831709945};\\\", \\\"{x:1331,y:790,t:1511831709961};\\\", \\\"{x:1331,y:789,t:1511831709978};\\\", \\\"{x:1331,y:787,t:1511831710066};\\\", \\\"{x:1330,y:787,t:1511831710078};\\\", \\\"{x:1326,y:785,t:1511831710095};\\\", \\\"{x:1320,y:784,t:1511831710112};\\\", \\\"{x:1315,y:783,t:1511831710127};\\\", \\\"{x:1303,y:782,t:1511831710145};\\\", \\\"{x:1288,y:782,t:1511831710161};\\\", \\\"{x:1271,y:782,t:1511831710177};\\\", \\\"{x:1257,y:782,t:1511831710195};\\\", \\\"{x:1245,y:782,t:1511831710212};\\\", \\\"{x:1233,y:781,t:1511831710228};\\\", \\\"{x:1217,y:774,t:1511831710244};\\\", \\\"{x:1201,y:765,t:1511831710262};\\\", \\\"{x:1194,y:760,t:1511831710278};\\\", \\\"{x:1186,y:755,t:1511831710295};\\\", \\\"{x:1178,y:748,t:1511831710312};\\\", \\\"{x:1172,y:743,t:1511831710328};\\\", \\\"{x:1162,y:738,t:1511831710345};\\\", \\\"{x:1160,y:737,t:1511831710362};\\\", \\\"{x:1160,y:736,t:1511831710409};\\\", \\\"{x:1160,y:735,t:1511831710417};\\\", \\\"{x:1160,y:733,t:1511831710428};\\\", \\\"{x:1160,y:731,t:1511831710444};\\\", \\\"{x:1160,y:728,t:1511831710462};\\\", \\\"{x:1160,y:725,t:1511831710478};\\\", \\\"{x:1160,y:722,t:1511831710495};\\\", \\\"{x:1160,y:720,t:1511831710512};\\\", \\\"{x:1160,y:719,t:1511831710529};\\\", \\\"{x:1160,y:717,t:1511831710577};\\\", \\\"{x:1160,y:715,t:1511831710595};\\\", \\\"{x:1160,y:711,t:1511831710611};\\\", \\\"{x:1160,y:708,t:1511831710628};\\\", \\\"{x:1158,y:704,t:1511831710644};\\\", \\\"{x:1158,y:702,t:1511831710661};\\\", \\\"{x:1158,y:701,t:1511831710681};\\\", \\\"{x:1157,y:700,t:1511831710744};\\\", \\\"{x:1157,y:698,t:1511831710792};\\\", \\\"{x:1156,y:696,t:1511831710808};\\\", \\\"{x:1155,y:695,t:1511831710824};\\\", \\\"{x:1155,y:694,t:1511831710832};\\\", \\\"{x:1155,y:693,t:1511831710845};\\\", \\\"{x:1154,y:693,t:1511831711497};\\\", \\\"{x:1156,y:675,t:1511831711514};\\\", \\\"{x:1165,y:661,t:1511831711529};\\\", \\\"{x:1183,y:635,t:1511831711546};\\\", \\\"{x:1186,y:627,t:1511831711563};\\\", \\\"{x:1187,y:625,t:1511831711579};\\\", \\\"{x:1187,y:624,t:1511831711596};\\\", \\\"{x:1188,y:621,t:1511831711613};\\\", \\\"{x:1192,y:616,t:1511831711629};\\\", \\\"{x:1196,y:611,t:1511831711646};\\\", \\\"{x:1202,y:605,t:1511831711663};\\\", \\\"{x:1208,y:600,t:1511831711679};\\\", \\\"{x:1218,y:591,t:1511831711696};\\\", \\\"{x:1236,y:578,t:1511831711713};\\\", \\\"{x:1241,y:574,t:1511831711729};\\\", \\\"{x:1242,y:573,t:1511831711746};\\\", \\\"{x:1243,y:571,t:1511831711769};\\\", \\\"{x:1244,y:570,t:1511831711826};\\\", \\\"{x:1242,y:570,t:1511831711930};\\\", \\\"{x:1240,y:570,t:1511831711946};\\\", \\\"{x:1239,y:570,t:1511831711985};\\\", \\\"{x:1238,y:569,t:1511831711996};\\\", \\\"{x:1237,y:569,t:1511831712013};\\\", \\\"{x:1234,y:567,t:1511831712030};\\\", \\\"{x:1233,y:567,t:1511831712046};\\\", \\\"{x:1232,y:567,t:1511831712063};\\\", \\\"{x:1231,y:566,t:1511831712080};\\\", \\\"{x:1230,y:564,t:1511831712096};\\\", \\\"{x:1226,y:561,t:1511831712113};\\\", \\\"{x:1222,y:557,t:1511831712130};\\\", \\\"{x:1219,y:556,t:1511831712146};\\\", \\\"{x:1216,y:555,t:1511831712164};\\\", \\\"{x:1213,y:555,t:1511831712180};\\\", \\\"{x:1206,y:553,t:1511831712196};\\\", \\\"{x:1204,y:553,t:1511831712213};\\\", \\\"{x:1202,y:553,t:1511831712230};\\\", \\\"{x:1203,y:553,t:1511831712441};\\\", \\\"{x:1204,y:552,t:1511831712465};\\\", \\\"{x:1205,y:552,t:1511831712481};\\\", \\\"{x:1206,y:552,t:1511831712497};\\\", \\\"{x:1208,y:552,t:1511831712513};\\\", \\\"{x:1210,y:552,t:1511831712537};\\\", \\\"{x:1210,y:553,t:1511831712561};\\\", \\\"{x:1210,y:554,t:1511831712569};\\\", \\\"{x:1210,y:556,t:1511831712580};\\\", \\\"{x:1210,y:561,t:1511831712597};\\\", \\\"{x:1204,y:573,t:1511831712613};\\\", \\\"{x:1187,y:587,t:1511831712630};\\\", \\\"{x:1161,y:606,t:1511831712647};\\\", \\\"{x:1136,y:620,t:1511831712663};\\\", \\\"{x:1104,y:637,t:1511831712680};\\\", \\\"{x:1043,y:667,t:1511831712697};\\\", \\\"{x:997,y:683,t:1511831712713};\\\", \\\"{x:974,y:691,t:1511831712729};\\\", \\\"{x:955,y:697,t:1511831712747};\\\", \\\"{x:947,y:698,t:1511831712764};\\\", \\\"{x:937,y:699,t:1511831712780};\\\", \\\"{x:929,y:699,t:1511831712797};\\\", \\\"{x:917,y:699,t:1511831712814};\\\", \\\"{x:888,y:703,t:1511831712830};\\\", \\\"{x:846,y:709,t:1511831712847};\\\", \\\"{x:805,y:719,t:1511831712864};\\\", \\\"{x:771,y:730,t:1511831712880};\\\", \\\"{x:733,y:737,t:1511831712897};\\\", \\\"{x:717,y:738,t:1511831712913};\\\", \\\"{x:702,y:738,t:1511831712929};\\\", \\\"{x:696,y:738,t:1511831712946};\\\", \\\"{x:695,y:736,t:1511831712964};\\\", \\\"{x:693,y:731,t:1511831712979};\\\", \\\"{x:687,y:723,t:1511831712996};\\\", \\\"{x:680,y:712,t:1511831713014};\\\", \\\"{x:671,y:701,t:1511831713029};\\\", \\\"{x:658,y:693,t:1511831713046};\\\", \\\"{x:644,y:689,t:1511831713064};\\\", \\\"{x:627,y:685,t:1511831713079};\\\", \\\"{x:592,y:681,t:1511831713096};\\\", \\\"{x:526,y:671,t:1511831713113};\\\", \\\"{x:478,y:664,t:1511831713130};\\\", \\\"{x:447,y:660,t:1511831713147};\\\", \\\"{x:427,y:654,t:1511831713166};\\\", \\\"{x:422,y:651,t:1511831713180};\\\", \\\"{x:419,y:650,t:1511831713196};\\\", \\\"{x:419,y:649,t:1511831713213};\\\", \\\"{x:418,y:648,t:1511831713230};\\\", \\\"{x:415,y:647,t:1511831713246};\\\", \\\"{x:406,y:643,t:1511831713263};\\\", \\\"{x:398,y:636,t:1511831713280};\\\", \\\"{x:394,y:631,t:1511831713296};\\\", \\\"{x:393,y:627,t:1511831713313};\\\", \\\"{x:391,y:621,t:1511831713330};\\\", \\\"{x:389,y:617,t:1511831713346};\\\", \\\"{x:389,y:612,t:1511831713363};\\\", \\\"{x:389,y:609,t:1511831713380};\\\", \\\"{x:387,y:606,t:1511831713396};\\\", \\\"{x:387,y:603,t:1511831713413};\\\", \\\"{x:387,y:599,t:1511831713430};\\\", \\\"{x:387,y:593,t:1511831713447};\\\", \\\"{x:393,y:587,t:1511831713464};\\\", \\\"{x:398,y:583,t:1511831713482};\\\", \\\"{x:401,y:580,t:1511831713497};\\\", \\\"{x:402,y:579,t:1511831713514};\\\", \\\"{x:402,y:578,t:1511831713531};\\\", \\\"{x:402,y:576,t:1511831713548};\\\", \\\"{x:402,y:575,t:1511831713564};\\\", \\\"{x:402,y:570,t:1511831713581};\\\", \\\"{x:402,y:567,t:1511831713598};\\\", \\\"{x:402,y:563,t:1511831713614};\\\", \\\"{x:402,y:561,t:1511831713631};\\\", \\\"{x:402,y:559,t:1511831713648};\\\", \\\"{x:402,y:556,t:1511831713664};\\\", \\\"{x:402,y:563,t:1511831713937};\\\", \\\"{x:402,y:571,t:1511831713948};\\\", \\\"{x:405,y:591,t:1511831713965};\\\", \\\"{x:408,y:610,t:1511831713981};\\\", \\\"{x:409,y:629,t:1511831713998};\\\", \\\"{x:410,y:647,t:1511831714015};\\\", \\\"{x:410,y:662,t:1511831714031};\\\", \\\"{x:410,y:676,t:1511831714048};\\\", \\\"{x:407,y:697,t:1511831714065};\\\", \\\"{x:405,y:705,t:1511831714081};\\\", \\\"{x:405,y:708,t:1511831714098};\\\", \\\"{x:404,y:708,t:1511831714234};\\\", \\\"{x:403,y:707,t:1511831714248};\\\", \\\"{x:403,y:701,t:1511831714266};\\\", \\\"{x:402,y:698,t:1511831714282};\\\", \\\"{x:402,y:696,t:1511831714298};\\\", \\\"{x:402,y:695,t:1511831714316};\\\", \\\"{x:402,y:693,t:1511831714332};\\\", \\\"{x:402,y:692,t:1511831714348};\\\", \\\"{x:402,y:690,t:1511831714365};\\\", \\\"{x:402,y:689,t:1511831714415};\\\", \\\"{x:402,y:689,t:1511831714484};\\\" ] }, { \\\"rt\\\": 10986, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 519888, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -M -B -G -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:618,y:673,t:1511831715737};\\\", \\\"{x:635,y:673,t:1511831715749};\\\", \\\"{x:669,y:680,t:1511831715771};\\\", \\\"{x:673,y:681,t:1511831715783};\\\", \\\"{x:680,y:686,t:1511831715800};\\\", \\\"{x:685,y:691,t:1511831715816};\\\", \\\"{x:689,y:697,t:1511831715833};\\\", \\\"{x:690,y:698,t:1511831715849};\\\", \\\"{x:690,y:699,t:1511831715866};\\\", \\\"{x:690,y:700,t:1511831715897};\\\", \\\"{x:689,y:705,t:1511831715916};\\\", \\\"{x:682,y:710,t:1511831715933};\\\", \\\"{x:671,y:718,t:1511831715949};\\\", \\\"{x:657,y:724,t:1511831715966};\\\", \\\"{x:638,y:728,t:1511831715983};\\\", \\\"{x:627,y:731,t:1511831716000};\\\", \\\"{x:625,y:731,t:1511831716016};\\\", \\\"{x:623,y:731,t:1511831716033};\\\", \\\"{x:622,y:731,t:1511831716057};\\\", \\\"{x:619,y:731,t:1511831716098};\\\", \\\"{x:618,y:731,t:1511831716106};\\\", \\\"{x:618,y:732,t:1511831716116};\\\", \\\"{x:617,y:734,t:1511831717122};\\\", \\\"{x:618,y:736,t:1511831717134};\\\", \\\"{x:631,y:740,t:1511831717150};\\\", \\\"{x:655,y:744,t:1511831717167};\\\", \\\"{x:687,y:747,t:1511831717184};\\\", \\\"{x:738,y:749,t:1511831717200};\\\", \\\"{x:833,y:749,t:1511831717217};\\\", \\\"{x:919,y:749,t:1511831717234};\\\", \\\"{x:1000,y:749,t:1511831717250};\\\", \\\"{x:1070,y:748,t:1511831717267};\\\", \\\"{x:1126,y:748,t:1511831717285};\\\", \\\"{x:1171,y:748,t:1511831717301};\\\", \\\"{x:1195,y:748,t:1511831717318};\\\", \\\"{x:1209,y:748,t:1511831717335};\\\", \\\"{x:1215,y:748,t:1511831717352};\\\", \\\"{x:1217,y:748,t:1511831717368};\\\", \\\"{x:1219,y:748,t:1511831717385};\\\", \\\"{x:1223,y:748,t:1511831717402};\\\", \\\"{x:1226,y:748,t:1511831717418};\\\", \\\"{x:1227,y:748,t:1511831717442};\\\", \\\"{x:1228,y:748,t:1511831717458};\\\", \\\"{x:1229,y:748,t:1511831717468};\\\", \\\"{x:1231,y:748,t:1511831717485};\\\", \\\"{x:1237,y:748,t:1511831717502};\\\", \\\"{x:1243,y:748,t:1511831717518};\\\", \\\"{x:1252,y:743,t:1511831717535};\\\", \\\"{x:1262,y:734,t:1511831717552};\\\", \\\"{x:1270,y:728,t:1511831717568};\\\", \\\"{x:1272,y:725,t:1511831717585};\\\", \\\"{x:1273,y:724,t:1511831717602};\\\", \\\"{x:1274,y:723,t:1511831717626};\\\", \\\"{x:1275,y:722,t:1511831717642};\\\", \\\"{x:1276,y:722,t:1511831717652};\\\", \\\"{x:1276,y:721,t:1511831717668};\\\", \\\"{x:1277,y:720,t:1511831717690};\\\", \\\"{x:1278,y:719,t:1511831717714};\\\", \\\"{x:1281,y:719,t:1511831718306};\\\", \\\"{x:1283,y:719,t:1511831718319};\\\", \\\"{x:1286,y:719,t:1511831718336};\\\", \\\"{x:1296,y:728,t:1511831718352};\\\", \\\"{x:1314,y:743,t:1511831718369};\\\", \\\"{x:1349,y:769,t:1511831718386};\\\", \\\"{x:1371,y:784,t:1511831718402};\\\", \\\"{x:1394,y:794,t:1511831718419};\\\", \\\"{x:1411,y:801,t:1511831718436};\\\", \\\"{x:1425,y:806,t:1511831718452};\\\", \\\"{x:1441,y:810,t:1511831718469};\\\", \\\"{x:1450,y:812,t:1511831718486};\\\", \\\"{x:1457,y:815,t:1511831718502};\\\", \\\"{x:1459,y:815,t:1511831718519};\\\", \\\"{x:1459,y:816,t:1511831718586};\\\", \\\"{x:1459,y:817,t:1511831718634};\\\", \\\"{x:1458,y:818,t:1511831718642};\\\", \\\"{x:1456,y:819,t:1511831718658};\\\", \\\"{x:1454,y:819,t:1511831718669};\\\", \\\"{x:1451,y:821,t:1511831718686};\\\", \\\"{x:1448,y:821,t:1511831718703};\\\", \\\"{x:1445,y:821,t:1511831718719};\\\", \\\"{x:1441,y:821,t:1511831718736};\\\", \\\"{x:1434,y:819,t:1511831718753};\\\", \\\"{x:1421,y:809,t:1511831718769};\\\", \\\"{x:1384,y:785,t:1511831718786};\\\", \\\"{x:1361,y:776,t:1511831718802};\\\", \\\"{x:1347,y:772,t:1511831718819};\\\", \\\"{x:1338,y:769,t:1511831718836};\\\", \\\"{x:1331,y:768,t:1511831718853};\\\", \\\"{x:1326,y:767,t:1511831718871};\\\", \\\"{x:1318,y:767,t:1511831718885};\\\", \\\"{x:1307,y:771,t:1511831718902};\\\", \\\"{x:1300,y:776,t:1511831718918};\\\", \\\"{x:1291,y:786,t:1511831718935};\\\", \\\"{x:1280,y:796,t:1511831718952};\\\", \\\"{x:1271,y:803,t:1511831718968};\\\", \\\"{x:1252,y:819,t:1511831718985};\\\", \\\"{x:1239,y:834,t:1511831719002};\\\", \\\"{x:1225,y:850,t:1511831719018};\\\", \\\"{x:1209,y:869,t:1511831719035};\\\", \\\"{x:1198,y:886,t:1511831719052};\\\", \\\"{x:1195,y:892,t:1511831719068};\\\", \\\"{x:1194,y:896,t:1511831719085};\\\", \\\"{x:1194,y:899,t:1511831719102};\\\", \\\"{x:1193,y:901,t:1511831719119};\\\", \\\"{x:1188,y:904,t:1511831719136};\\\", \\\"{x:1177,y:906,t:1511831719152};\\\", \\\"{x:1152,y:909,t:1511831719169};\\\", \\\"{x:1134,y:909,t:1511831719185};\\\", \\\"{x:1115,y:909,t:1511831719203};\\\", \\\"{x:1097,y:909,t:1511831719220};\\\", \\\"{x:1075,y:905,t:1511831719235};\\\", \\\"{x:1053,y:898,t:1511831719253};\\\", \\\"{x:1038,y:893,t:1511831719270};\\\", \\\"{x:1022,y:884,t:1511831719286};\\\", \\\"{x:1011,y:875,t:1511831719303};\\\", \\\"{x:999,y:864,t:1511831719320};\\\", \\\"{x:989,y:854,t:1511831719335};\\\", \\\"{x:982,y:847,t:1511831719353};\\\", \\\"{x:978,y:845,t:1511831719370};\\\", \\\"{x:978,y:844,t:1511831719426};\\\", \\\"{x:978,y:842,t:1511831719436};\\\", \\\"{x:978,y:839,t:1511831719453};\\\", \\\"{x:978,y:836,t:1511831719470};\\\", \\\"{x:981,y:832,t:1511831719487};\\\", \\\"{x:986,y:829,t:1511831719502};\\\", \\\"{x:995,y:824,t:1511831719520};\\\", \\\"{x:1005,y:819,t:1511831719536};\\\", \\\"{x:1013,y:815,t:1511831719552};\\\", \\\"{x:1028,y:810,t:1511831719570};\\\", \\\"{x:1038,y:806,t:1511831719586};\\\", \\\"{x:1049,y:801,t:1511831719603};\\\", \\\"{x:1057,y:797,t:1511831719620};\\\", \\\"{x:1068,y:792,t:1511831719637};\\\", \\\"{x:1084,y:784,t:1511831719653};\\\", \\\"{x:1103,y:775,t:1511831719670};\\\", \\\"{x:1124,y:766,t:1511831719687};\\\", \\\"{x:1142,y:758,t:1511831719703};\\\", \\\"{x:1157,y:752,t:1511831719720};\\\", \\\"{x:1170,y:746,t:1511831719737};\\\", \\\"{x:1183,y:737,t:1511831719753};\\\", \\\"{x:1195,y:727,t:1511831719770};\\\", \\\"{x:1204,y:720,t:1511831719787};\\\", \\\"{x:1211,y:713,t:1511831719803};\\\", \\\"{x:1216,y:706,t:1511831719820};\\\", \\\"{x:1222,y:700,t:1511831719837};\\\", \\\"{x:1225,y:697,t:1511831719853};\\\", \\\"{x:1227,y:694,t:1511831719870};\\\", \\\"{x:1229,y:693,t:1511831719887};\\\", \\\"{x:1231,y:690,t:1511831719903};\\\", \\\"{x:1232,y:688,t:1511831719920};\\\", \\\"{x:1235,y:680,t:1511831719937};\\\", \\\"{x:1239,y:662,t:1511831719954};\\\", \\\"{x:1240,y:646,t:1511831719970};\\\", \\\"{x:1241,y:631,t:1511831719987};\\\", \\\"{x:1241,y:621,t:1511831720004};\\\", \\\"{x:1241,y:618,t:1511831720020};\\\", \\\"{x:1242,y:614,t:1511831720037};\\\", \\\"{x:1242,y:609,t:1511831720054};\\\", \\\"{x:1242,y:605,t:1511831720070};\\\", \\\"{x:1242,y:602,t:1511831720087};\\\", \\\"{x:1242,y:598,t:1511831720104};\\\", \\\"{x:1242,y:595,t:1511831720120};\\\", \\\"{x:1239,y:592,t:1511831720137};\\\", \\\"{x:1235,y:586,t:1511831720154};\\\", \\\"{x:1232,y:581,t:1511831720170};\\\", \\\"{x:1231,y:579,t:1511831720187};\\\", \\\"{x:1228,y:573,t:1511831720204};\\\", \\\"{x:1224,y:566,t:1511831720220};\\\", \\\"{x:1219,y:559,t:1511831720236};\\\", \\\"{x:1214,y:551,t:1511831720254};\\\", \\\"{x:1211,y:547,t:1511831720270};\\\", \\\"{x:1207,y:540,t:1511831720287};\\\", \\\"{x:1202,y:528,t:1511831720304};\\\", \\\"{x:1197,y:501,t:1511831720320};\\\", \\\"{x:1191,y:456,t:1511831720337};\\\", \\\"{x:1190,y:418,t:1511831720354};\\\", \\\"{x:1190,y:399,t:1511831720370};\\\", \\\"{x:1190,y:381,t:1511831720387};\\\", \\\"{x:1190,y:366,t:1511831720404};\\\", \\\"{x:1192,y:351,t:1511831720421};\\\", \\\"{x:1193,y:341,t:1511831720437};\\\", \\\"{x:1196,y:333,t:1511831720454};\\\", \\\"{x:1197,y:328,t:1511831720471};\\\", \\\"{x:1200,y:324,t:1511831720487};\\\", \\\"{x:1203,y:319,t:1511831720504};\\\", \\\"{x:1208,y:314,t:1511831720521};\\\", \\\"{x:1215,y:308,t:1511831720537};\\\", \\\"{x:1237,y:298,t:1511831720553};\\\", \\\"{x:1261,y:293,t:1511831720570};\\\", \\\"{x:1284,y:291,t:1511831720587};\\\", \\\"{x:1305,y:287,t:1511831720604};\\\", \\\"{x:1324,y:287,t:1511831720620};\\\", \\\"{x:1344,y:287,t:1511831720636};\\\", \\\"{x:1370,y:289,t:1511831720653};\\\", \\\"{x:1409,y:294,t:1511831720670};\\\", \\\"{x:1446,y:299,t:1511831720686};\\\", \\\"{x:1472,y:303,t:1511831720703};\\\", \\\"{x:1487,y:308,t:1511831720720};\\\", \\\"{x:1501,y:314,t:1511831720736};\\\", \\\"{x:1514,y:330,t:1511831720753};\\\", \\\"{x:1528,y:351,t:1511831720770};\\\", \\\"{x:1546,y:376,t:1511831720786};\\\", \\\"{x:1560,y:403,t:1511831720803};\\\", \\\"{x:1574,y:438,t:1511831720820};\\\", \\\"{x:1587,y:468,t:1511831720836};\\\", \\\"{x:1592,y:495,t:1511831720853};\\\", \\\"{x:1593,y:518,t:1511831720870};\\\", \\\"{x:1596,y:535,t:1511831720886};\\\", \\\"{x:1595,y:549,t:1511831720903};\\\", \\\"{x:1591,y:563,t:1511831720920};\\\", \\\"{x:1585,y:581,t:1511831720937};\\\", \\\"{x:1580,y:592,t:1511831720953};\\\", \\\"{x:1574,y:605,t:1511831720970};\\\", \\\"{x:1567,y:621,t:1511831720988};\\\", \\\"{x:1558,y:631,t:1511831721003};\\\", \\\"{x:1550,y:642,t:1511831721020};\\\", \\\"{x:1540,y:657,t:1511831721038};\\\", \\\"{x:1533,y:666,t:1511831721054};\\\", \\\"{x:1527,y:676,t:1511831721070};\\\", \\\"{x:1520,y:683,t:1511831721088};\\\", \\\"{x:1516,y:687,t:1511831721104};\\\", \\\"{x:1512,y:690,t:1511831721121};\\\", \\\"{x:1507,y:696,t:1511831721137};\\\", \\\"{x:1500,y:699,t:1511831721154};\\\", \\\"{x:1491,y:702,t:1511831721171};\\\", \\\"{x:1476,y:705,t:1511831721188};\\\", \\\"{x:1458,y:707,t:1511831721204};\\\", \\\"{x:1446,y:709,t:1511831721221};\\\", \\\"{x:1437,y:710,t:1511831721238};\\\", \\\"{x:1431,y:710,t:1511831721255};\\\", \\\"{x:1427,y:710,t:1511831721271};\\\", \\\"{x:1422,y:710,t:1511831721288};\\\", \\\"{x:1413,y:710,t:1511831721305};\\\", \\\"{x:1400,y:708,t:1511831721321};\\\", \\\"{x:1385,y:704,t:1511831721337};\\\", \\\"{x:1381,y:703,t:1511831721354};\\\", \\\"{x:1379,y:701,t:1511831721371};\\\", \\\"{x:1378,y:701,t:1511831721388};\\\", \\\"{x:1378,y:702,t:1511831721466};\\\", \\\"{x:1378,y:703,t:1511831721474};\\\", \\\"{x:1378,y:705,t:1511831721488};\\\", \\\"{x:1378,y:712,t:1511831721505};\\\", \\\"{x:1378,y:722,t:1511831721521};\\\", \\\"{x:1378,y:744,t:1511831721537};\\\", \\\"{x:1378,y:754,t:1511831721555};\\\", \\\"{x:1378,y:762,t:1511831721571};\\\", \\\"{x:1382,y:768,t:1511831721588};\\\", \\\"{x:1383,y:770,t:1511831721605};\\\", \\\"{x:1384,y:770,t:1511831721626};\\\", \\\"{x:1385,y:770,t:1511831721666};\\\", \\\"{x:1386,y:767,t:1511831721674};\\\", \\\"{x:1390,y:761,t:1511831721688};\\\", \\\"{x:1397,y:750,t:1511831721705};\\\", \\\"{x:1405,y:737,t:1511831721721};\\\", \\\"{x:1411,y:728,t:1511831721738};\\\", \\\"{x:1413,y:723,t:1511831721755};\\\", \\\"{x:1415,y:717,t:1511831721772};\\\", \\\"{x:1417,y:710,t:1511831721788};\\\", \\\"{x:1417,y:700,t:1511831721805};\\\", \\\"{x:1418,y:695,t:1511831721822};\\\", \\\"{x:1418,y:693,t:1511831721837};\\\", \\\"{x:1418,y:692,t:1511831721855};\\\", \\\"{x:1418,y:693,t:1511831722106};\\\", \\\"{x:1418,y:699,t:1511831722121};\\\", \\\"{x:1417,y:700,t:1511831722139};\\\", \\\"{x:1417,y:702,t:1511831722155};\\\", \\\"{x:1417,y:703,t:1511831722178};\\\", \\\"{x:1417,y:705,t:1511831722193};\\\", \\\"{x:1416,y:705,t:1511831722205};\\\", \\\"{x:1416,y:706,t:1511831722282};\\\", \\\"{x:1415,y:711,t:1511831722290};\\\", \\\"{x:1414,y:713,t:1511831722305};\\\", \\\"{x:1407,y:728,t:1511831722321};\\\", \\\"{x:1399,y:744,t:1511831722339};\\\", \\\"{x:1386,y:767,t:1511831722355};\\\", \\\"{x:1374,y:785,t:1511831722372};\\\", \\\"{x:1360,y:809,t:1511831722389};\\\", \\\"{x:1352,y:823,t:1511831722405};\\\", \\\"{x:1343,y:843,t:1511831722422};\\\", \\\"{x:1336,y:861,t:1511831722439};\\\", \\\"{x:1330,y:875,t:1511831722455};\\\", \\\"{x:1325,y:887,t:1511831722472};\\\", \\\"{x:1321,y:895,t:1511831722489};\\\", \\\"{x:1319,y:900,t:1511831722505};\\\", \\\"{x:1317,y:904,t:1511831722521};\\\", \\\"{x:1315,y:908,t:1511831722539};\\\", \\\"{x:1313,y:912,t:1511831722555};\\\", \\\"{x:1310,y:915,t:1511831722572};\\\", \\\"{x:1306,y:918,t:1511831722589};\\\", \\\"{x:1304,y:920,t:1511831722606};\\\", \\\"{x:1301,y:923,t:1511831722622};\\\", \\\"{x:1299,y:925,t:1511831722639};\\\", \\\"{x:1297,y:931,t:1511831722656};\\\", \\\"{x:1293,y:937,t:1511831722672};\\\", \\\"{x:1290,y:942,t:1511831722689};\\\", \\\"{x:1287,y:948,t:1511831722705};\\\", \\\"{x:1286,y:950,t:1511831722722};\\\", \\\"{x:1284,y:952,t:1511831722739};\\\", \\\"{x:1284,y:953,t:1511831722761};\\\", \\\"{x:1284,y:954,t:1511831722772};\\\", \\\"{x:1284,y:957,t:1511831722789};\\\", \\\"{x:1282,y:960,t:1511831722806};\\\", \\\"{x:1282,y:961,t:1511831722822};\\\", \\\"{x:1282,y:962,t:1511831722839};\\\", \\\"{x:1282,y:963,t:1511831722856};\\\", \\\"{x:1282,y:962,t:1511831723274};\\\", \\\"{x:1282,y:961,t:1511831723289};\\\", \\\"{x:1282,y:960,t:1511831723362};\\\", \\\"{x:1282,y:957,t:1511831723882};\\\", \\\"{x:1282,y:954,t:1511831723889};\\\", \\\"{x:1274,y:938,t:1511831723907};\\\", \\\"{x:1257,y:912,t:1511831723923};\\\", \\\"{x:1235,y:879,t:1511831723940};\\\", \\\"{x:1192,y:829,t:1511831723956};\\\", \\\"{x:1147,y:779,t:1511831723973};\\\", \\\"{x:1089,y:727,t:1511831723990};\\\", \\\"{x:1021,y:672,t:1511831724007};\\\", \\\"{x:955,y:629,t:1511831724023};\\\", \\\"{x:898,y:598,t:1511831724040};\\\", \\\"{x:853,y:578,t:1511831724057};\\\", \\\"{x:821,y:565,t:1511831724073};\\\", \\\"{x:780,y:552,t:1511831724089};\\\", \\\"{x:753,y:547,t:1511831724106};\\\", \\\"{x:725,y:545,t:1511831724122};\\\", \\\"{x:705,y:545,t:1511831724139};\\\", \\\"{x:694,y:545,t:1511831724156};\\\", \\\"{x:681,y:547,t:1511831724173};\\\", \\\"{x:672,y:550,t:1511831724190};\\\", \\\"{x:659,y:554,t:1511831724206};\\\", \\\"{x:644,y:558,t:1511831724223};\\\", \\\"{x:630,y:562,t:1511831724239};\\\", \\\"{x:613,y:566,t:1511831724256};\\\", \\\"{x:593,y:574,t:1511831724273};\\\", \\\"{x:552,y:580,t:1511831724290};\\\", \\\"{x:519,y:580,t:1511831724306};\\\", \\\"{x:494,y:580,t:1511831724323};\\\", \\\"{x:464,y:579,t:1511831724339};\\\", \\\"{x:443,y:574,t:1511831724357};\\\", \\\"{x:437,y:574,t:1511831724373};\\\", \\\"{x:433,y:574,t:1511831724389};\\\", \\\"{x:428,y:572,t:1511831724406};\\\", \\\"{x:425,y:571,t:1511831724423};\\\", \\\"{x:424,y:571,t:1511831724482};\\\", \\\"{x:422,y:571,t:1511831724625};\\\", \\\"{x:420,y:571,t:1511831724641};\\\", \\\"{x:419,y:570,t:1511831724656};\\\", \\\"{x:412,y:566,t:1511831724673};\\\", \\\"{x:405,y:562,t:1511831724690};\\\", \\\"{x:404,y:560,t:1511831724706};\\\", \\\"{x:402,y:558,t:1511831724723};\\\", \\\"{x:401,y:555,t:1511831724740};\\\", \\\"{x:400,y:551,t:1511831724756};\\\", \\\"{x:398,y:547,t:1511831724773};\\\", \\\"{x:397,y:544,t:1511831724790};\\\", \\\"{x:395,y:542,t:1511831724806};\\\", \\\"{x:394,y:538,t:1511831724823};\\\", \\\"{x:392,y:536,t:1511831724840};\\\", \\\"{x:391,y:530,t:1511831724856};\\\", \\\"{x:388,y:526,t:1511831724873};\\\", \\\"{x:388,y:525,t:1511831724929};\\\", \\\"{x:388,y:524,t:1511831724969};\\\", \\\"{x:389,y:524,t:1511831724985};\\\", \\\"{x:391,y:524,t:1511831724993};\\\", \\\"{x:394,y:524,t:1511831725009};\\\", \\\"{x:395,y:524,t:1511831725023};\\\", \\\"{x:399,y:525,t:1511831725040};\\\", \\\"{x:402,y:530,t:1511831725057};\\\", \\\"{x:402,y:531,t:1511831725073};\\\", \\\"{x:403,y:532,t:1511831725090};\\\", \\\"{x:403,y:533,t:1511831725107};\\\", \\\"{x:404,y:534,t:1511831725324};\\\", \\\"{x:404,y:533,t:1511831725344};\\\", \\\"{x:404,y:532,t:1511831725360};\\\", \\\"{x:406,y:532,t:1511831725401};\\\", \\\"{x:409,y:531,t:1511831725409};\\\", \\\"{x:413,y:531,t:1511831725424};\\\", \\\"{x:422,y:532,t:1511831725440};\\\", \\\"{x:430,y:535,t:1511831725457};\\\", \\\"{x:434,y:537,t:1511831725474};\\\", \\\"{x:437,y:537,t:1511831725490};\\\", \\\"{x:439,y:537,t:1511831725507};\\\", \\\"{x:446,y:537,t:1511831725524};\\\", \\\"{x:466,y:537,t:1511831725540};\\\", \\\"{x:493,y:537,t:1511831725557};\\\", \\\"{x:509,y:537,t:1511831725575};\\\", \\\"{x:523,y:537,t:1511831725590};\\\", \\\"{x:529,y:539,t:1511831725607};\\\", \\\"{x:529,y:541,t:1511831725681};\\\", \\\"{x:529,y:542,t:1511831725690};\\\", \\\"{x:529,y:543,t:1511831725707};\\\", \\\"{x:527,y:543,t:1511831725858};\\\", \\\"{x:519,y:542,t:1511831725874};\\\", \\\"{x:518,y:542,t:1511831725891};\\\", \\\"{x:517,y:542,t:1511831725907};\\\", \\\"{x:516,y:541,t:1511831725986};\\\", \\\"{x:516,y:539,t:1511831726001};\\\", \\\"{x:516,y:538,t:1511831726009};\\\", \\\"{x:516,y:536,t:1511831726025};\\\", \\\"{x:516,y:535,t:1511831726041};\\\", \\\"{x:515,y:533,t:1511831726057};\\\", \\\"{x:512,y:537,t:1511831726248};\\\", \\\"{x:508,y:545,t:1511831726258};\\\", \\\"{x:498,y:566,t:1511831726274};\\\", \\\"{x:491,y:583,t:1511831726291};\\\", \\\"{x:486,y:592,t:1511831726307};\\\", \\\"{x:485,y:597,t:1511831726324};\\\", \\\"{x:483,y:600,t:1511831726341};\\\", \\\"{x:474,y:612,t:1511831726358};\\\", \\\"{x:452,y:632,t:1511831726374};\\\", \\\"{x:432,y:649,t:1511831726391};\\\", \\\"{x:417,y:662,t:1511831726408};\\\", \\\"{x:403,y:671,t:1511831726424};\\\", \\\"{x:394,y:678,t:1511831726441};\\\", \\\"{x:394,y:679,t:1511831726458};\\\", \\\"{x:393,y:679,t:1511831726474};\\\", \\\"{x:392,y:680,t:1511831726491};\\\", \\\"{x:391,y:680,t:1511831726577};\\\", \\\"{x:391,y:681,t:1511831726591};\\\", \\\"{x:390,y:682,t:1511831726608};\\\", \\\"{x:391,y:681,t:1511831727560};\\\", \\\"{x:391,y:680,t:1511831727576};\\\", \\\"{x:391,y:679,t:1511831727592};\\\" ] }, { \\\"rt\\\": 12468, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 533617, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -B -11 AM-12 PM-01 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:395,y:677,t:1511831728681};\\\", \\\"{x:406,y:671,t:1511831728694};\\\", \\\"{x:424,y:662,t:1511831728710};\\\", \\\"{x:432,y:659,t:1511831728726};\\\", \\\"{x:445,y:654,t:1511831728743};\\\", \\\"{x:473,y:646,t:1511831728759};\\\", \\\"{x:546,y:637,t:1511831728776};\\\", \\\"{x:597,y:637,t:1511831728792};\\\", \\\"{x:642,y:637,t:1511831728809};\\\", \\\"{x:692,y:637,t:1511831728826};\\\", \\\"{x:761,y:637,t:1511831728843};\\\", \\\"{x:834,y:637,t:1511831728860};\\\", \\\"{x:889,y:637,t:1511831728876};\\\", \\\"{x:929,y:637,t:1511831728893};\\\", \\\"{x:959,y:637,t:1511831728910};\\\", \\\"{x:988,y:637,t:1511831728926};\\\", \\\"{x:1017,y:637,t:1511831728943};\\\", \\\"{x:1055,y:637,t:1511831728961};\\\", \\\"{x:1066,y:637,t:1511831728976};\\\", \\\"{x:1096,y:637,t:1511831728993};\\\", \\\"{x:1115,y:637,t:1511831729010};\\\", \\\"{x:1132,y:637,t:1511831729026};\\\", \\\"{x:1152,y:634,t:1511831729043};\\\", \\\"{x:1169,y:632,t:1511831729060};\\\", \\\"{x:1189,y:628,t:1511831729077};\\\", \\\"{x:1207,y:626,t:1511831729094};\\\", \\\"{x:1223,y:621,t:1511831729111};\\\", \\\"{x:1233,y:618,t:1511831729127};\\\", \\\"{x:1246,y:616,t:1511831729144};\\\", \\\"{x:1265,y:613,t:1511831729161};\\\", \\\"{x:1276,y:611,t:1511831729177};\\\", \\\"{x:1294,y:611,t:1511831729193};\\\", \\\"{x:1311,y:610,t:1511831729210};\\\", \\\"{x:1328,y:610,t:1511831729227};\\\", \\\"{x:1353,y:610,t:1511831729244};\\\", \\\"{x:1375,y:610,t:1511831729261};\\\", \\\"{x:1396,y:610,t:1511831729277};\\\", \\\"{x:1418,y:610,t:1511831729294};\\\", \\\"{x:1444,y:610,t:1511831729311};\\\", \\\"{x:1468,y:610,t:1511831729327};\\\", \\\"{x:1485,y:610,t:1511831729344};\\\", \\\"{x:1497,y:610,t:1511831729361};\\\", \\\"{x:1498,y:610,t:1511831729378};\\\", \\\"{x:1498,y:614,t:1511831729433};\\\", \\\"{x:1498,y:620,t:1511831729444};\\\", \\\"{x:1496,y:634,t:1511831729461};\\\", \\\"{x:1493,y:644,t:1511831729478};\\\", \\\"{x:1493,y:645,t:1511831729494};\\\", \\\"{x:1492,y:646,t:1511831729511};\\\", \\\"{x:1489,y:646,t:1511831730162};\\\", \\\"{x:1483,y:645,t:1511831730178};\\\", \\\"{x:1478,y:644,t:1511831730195};\\\", \\\"{x:1474,y:643,t:1511831730211};\\\", \\\"{x:1470,y:642,t:1511831730228};\\\", \\\"{x:1466,y:641,t:1511831730245};\\\", \\\"{x:1460,y:641,t:1511831730262};\\\", \\\"{x:1454,y:641,t:1511831730278};\\\", \\\"{x:1445,y:639,t:1511831730295};\\\", \\\"{x:1437,y:638,t:1511831730312};\\\", \\\"{x:1431,y:636,t:1511831730328};\\\", \\\"{x:1422,y:633,t:1511831730345};\\\", \\\"{x:1414,y:631,t:1511831730361};\\\", \\\"{x:1408,y:629,t:1511831730378};\\\", \\\"{x:1406,y:629,t:1511831730395};\\\", \\\"{x:1405,y:629,t:1511831730412};\\\", \\\"{x:1404,y:628,t:1511831730428};\\\", \\\"{x:1403,y:626,t:1511831730445};\\\", \\\"{x:1399,y:623,t:1511831730462};\\\", \\\"{x:1391,y:617,t:1511831730478};\\\", \\\"{x:1380,y:609,t:1511831730494};\\\", \\\"{x:1370,y:600,t:1511831730511};\\\", \\\"{x:1362,y:592,t:1511831730527};\\\", \\\"{x:1355,y:586,t:1511831730544};\\\", \\\"{x:1353,y:585,t:1511831730561};\\\", \\\"{x:1352,y:584,t:1511831730578};\\\", \\\"{x:1351,y:582,t:1511831730600};\\\", \\\"{x:1350,y:582,t:1511831730611};\\\", \\\"{x:1349,y:581,t:1511831730627};\\\", \\\"{x:1347,y:579,t:1511831730644};\\\", \\\"{x:1342,y:575,t:1511831730661};\\\", \\\"{x:1334,y:570,t:1511831730678};\\\", \\\"{x:1329,y:566,t:1511831730694};\\\", \\\"{x:1324,y:563,t:1511831730711};\\\", \\\"{x:1320,y:560,t:1511831730729};\\\", \\\"{x:1319,y:559,t:1511831730744};\\\", \\\"{x:1317,y:555,t:1511831730761};\\\", \\\"{x:1314,y:552,t:1511831730778};\\\", \\\"{x:1309,y:546,t:1511831730794};\\\", \\\"{x:1303,y:537,t:1511831730812};\\\", \\\"{x:1292,y:530,t:1511831730829};\\\", \\\"{x:1283,y:522,t:1511831730845};\\\", \\\"{x:1275,y:516,t:1511831730862};\\\", \\\"{x:1271,y:512,t:1511831730879};\\\", \\\"{x:1268,y:509,t:1511831730895};\\\", \\\"{x:1265,y:506,t:1511831730912};\\\", \\\"{x:1263,y:505,t:1511831730930};\\\", \\\"{x:1262,y:505,t:1511831730946};\\\", \\\"{x:1258,y:506,t:1511831731018};\\\", \\\"{x:1257,y:511,t:1511831731030};\\\", \\\"{x:1252,y:528,t:1511831731047};\\\", \\\"{x:1247,y:546,t:1511831731063};\\\", \\\"{x:1242,y:559,t:1511831731080};\\\", \\\"{x:1237,y:571,t:1511831731097};\\\", \\\"{x:1233,y:580,t:1511831731113};\\\", \\\"{x:1229,y:591,t:1511831731130};\\\", \\\"{x:1228,y:595,t:1511831731146};\\\", \\\"{x:1226,y:599,t:1511831731163};\\\", \\\"{x:1225,y:603,t:1511831731180};\\\", \\\"{x:1224,y:605,t:1511831731197};\\\", \\\"{x:1223,y:607,t:1511831731213};\\\", \\\"{x:1222,y:609,t:1511831731230};\\\", \\\"{x:1219,y:611,t:1511831731247};\\\", \\\"{x:1212,y:617,t:1511831731262};\\\", \\\"{x:1204,y:619,t:1511831731279};\\\", \\\"{x:1196,y:623,t:1511831731296};\\\", \\\"{x:1187,y:628,t:1511831731312};\\\", \\\"{x:1174,y:632,t:1511831731329};\\\", \\\"{x:1165,y:637,t:1511831731346};\\\", \\\"{x:1160,y:638,t:1511831731363};\\\", \\\"{x:1160,y:639,t:1511831731379};\\\", \\\"{x:1156,y:639,t:1511831731577};\\\", \\\"{x:1152,y:638,t:1511831731585};\\\", \\\"{x:1146,y:637,t:1511831731596};\\\", \\\"{x:1129,y:632,t:1511831731613};\\\", \\\"{x:1110,y:626,t:1511831731629};\\\", \\\"{x:1091,y:621,t:1511831731646};\\\", \\\"{x:1072,y:615,t:1511831731663};\\\", \\\"{x:1049,y:612,t:1511831731679};\\\", \\\"{x:1027,y:612,t:1511831731696};\\\", \\\"{x:1004,y:612,t:1511831731713};\\\", \\\"{x:993,y:612,t:1511831731729};\\\", \\\"{x:991,y:612,t:1511831731746};\\\", \\\"{x:988,y:612,t:1511831731945};\\\", \\\"{x:981,y:612,t:1511831731953};\\\", \\\"{x:969,y:613,t:1511831731963};\\\", \\\"{x:928,y:628,t:1511831731980};\\\", \\\"{x:874,y:647,t:1511831731996};\\\", \\\"{x:836,y:669,t:1511831732013};\\\", \\\"{x:811,y:686,t:1511831732030};\\\", \\\"{x:790,y:697,t:1511831732046};\\\", \\\"{x:785,y:701,t:1511831732063};\\\", \\\"{x:781,y:704,t:1511831732080};\\\", \\\"{x:780,y:706,t:1511831732096};\\\", \\\"{x:778,y:716,t:1511831732113};\\\", \\\"{x:778,y:730,t:1511831732130};\\\", \\\"{x:777,y:748,t:1511831732146};\\\", \\\"{x:777,y:760,t:1511831732163};\\\", \\\"{x:787,y:772,t:1511831732180};\\\", \\\"{x:811,y:782,t:1511831732196};\\\", \\\"{x:835,y:789,t:1511831732213};\\\", \\\"{x:856,y:796,t:1511831732230};\\\", \\\"{x:873,y:804,t:1511831732246};\\\", \\\"{x:888,y:809,t:1511831732263};\\\", \\\"{x:900,y:812,t:1511831732280};\\\", \\\"{x:914,y:823,t:1511831732297};\\\", \\\"{x:916,y:825,t:1511831732313};\\\", \\\"{x:917,y:826,t:1511831732402};\\\", \\\"{x:918,y:826,t:1511831732418};\\\", \\\"{x:920,y:826,t:1511831732431};\\\", \\\"{x:928,y:826,t:1511831732448};\\\", \\\"{x:932,y:823,t:1511831732464};\\\", \\\"{x:938,y:822,t:1511831732481};\\\", \\\"{x:940,y:820,t:1511831732498};\\\", \\\"{x:941,y:819,t:1511831732514};\\\", \\\"{x:942,y:818,t:1511831732530};\\\", \\\"{x:942,y:815,t:1511831732548};\\\", \\\"{x:942,y:810,t:1511831732564};\\\", \\\"{x:941,y:804,t:1511831732581};\\\", \\\"{x:928,y:796,t:1511831732598};\\\", \\\"{x:912,y:787,t:1511831732614};\\\", \\\"{x:900,y:780,t:1511831732631};\\\", \\\"{x:891,y:776,t:1511831732648};\\\", \\\"{x:885,y:775,t:1511831732664};\\\", \\\"{x:884,y:774,t:1511831732681};\\\", \\\"{x:883,y:774,t:1511831732698};\\\", \\\"{x:885,y:772,t:1511831732714};\\\", \\\"{x:904,y:762,t:1511831732731};\\\", \\\"{x:931,y:756,t:1511831732748};\\\", \\\"{x:965,y:754,t:1511831732764};\\\", \\\"{x:989,y:752,t:1511831732781};\\\", \\\"{x:1014,y:752,t:1511831732798};\\\", \\\"{x:1047,y:752,t:1511831732815};\\\", \\\"{x:1081,y:752,t:1511831732831};\\\", \\\"{x:1111,y:752,t:1511831732848};\\\", \\\"{x:1134,y:752,t:1511831732865};\\\", \\\"{x:1143,y:752,t:1511831732881};\\\", \\\"{x:1147,y:752,t:1511831732898};\\\", \\\"{x:1148,y:752,t:1511831732922};\\\", \\\"{x:1149,y:752,t:1511831732931};\\\", \\\"{x:1151,y:752,t:1511831732948};\\\", \\\"{x:1153,y:752,t:1511831732965};\\\", \\\"{x:1157,y:752,t:1511831732980};\\\", \\\"{x:1159,y:752,t:1511831732998};\\\", \\\"{x:1160,y:752,t:1511831733122};\\\", \\\"{x:1161,y:752,t:1511831733131};\\\", \\\"{x:1173,y:757,t:1511831733148};\\\", \\\"{x:1182,y:760,t:1511831733165};\\\", \\\"{x:1186,y:761,t:1511831733181};\\\", \\\"{x:1189,y:761,t:1511831733198};\\\", \\\"{x:1190,y:761,t:1511831733234};\\\", \\\"{x:1195,y:761,t:1511831733250};\\\", \\\"{x:1199,y:763,t:1511831733265};\\\", \\\"{x:1215,y:764,t:1511831733282};\\\", \\\"{x:1227,y:765,t:1511831733298};\\\", \\\"{x:1242,y:765,t:1511831733314};\\\", \\\"{x:1251,y:765,t:1511831733332};\\\", \\\"{x:1256,y:765,t:1511831733348};\\\", \\\"{x:1257,y:765,t:1511831733365};\\\", \\\"{x:1258,y:765,t:1511831733382};\\\", \\\"{x:1262,y:764,t:1511831733398};\\\", \\\"{x:1266,y:763,t:1511831733415};\\\", \\\"{x:1275,y:762,t:1511831733432};\\\", \\\"{x:1281,y:761,t:1511831733448};\\\", \\\"{x:1282,y:761,t:1511831733465};\\\", \\\"{x:1284,y:761,t:1511831733482};\\\", \\\"{x:1286,y:760,t:1511831733498};\\\", \\\"{x:1290,y:760,t:1511831733515};\\\", \\\"{x:1293,y:759,t:1511831733532};\\\", \\\"{x:1295,y:759,t:1511831733548};\\\", \\\"{x:1297,y:759,t:1511831733602};\\\", \\\"{x:1299,y:759,t:1511831733615};\\\", \\\"{x:1302,y:759,t:1511831733632};\\\", \\\"{x:1303,y:759,t:1511831733648};\\\", \\\"{x:1304,y:759,t:1511831733665};\\\", \\\"{x:1303,y:759,t:1511831733762};\\\", \\\"{x:1301,y:759,t:1511831733770};\\\", \\\"{x:1299,y:759,t:1511831733782};\\\", \\\"{x:1291,y:761,t:1511831733799};\\\", \\\"{x:1281,y:762,t:1511831733815};\\\", \\\"{x:1263,y:765,t:1511831733832};\\\", \\\"{x:1248,y:767,t:1511831733849};\\\", \\\"{x:1231,y:769,t:1511831733865};\\\", \\\"{x:1206,y:773,t:1511831733882};\\\", \\\"{x:1186,y:777,t:1511831733898};\\\", \\\"{x:1160,y:782,t:1511831733915};\\\", \\\"{x:1145,y:789,t:1511831733932};\\\", \\\"{x:1133,y:797,t:1511831733949};\\\", \\\"{x:1129,y:801,t:1511831733965};\\\", \\\"{x:1128,y:804,t:1511831733982};\\\", \\\"{x:1126,y:813,t:1511831733999};\\\", \\\"{x:1125,y:827,t:1511831734015};\\\", \\\"{x:1124,y:843,t:1511831734032};\\\", \\\"{x:1124,y:857,t:1511831734049};\\\", \\\"{x:1124,y:868,t:1511831734065};\\\", \\\"{x:1124,y:881,t:1511831734082};\\\", \\\"{x:1123,y:887,t:1511831734098};\\\", \\\"{x:1119,y:897,t:1511831734115};\\\", \\\"{x:1114,y:903,t:1511831734132};\\\", \\\"{x:1110,y:913,t:1511831734149};\\\", \\\"{x:1105,y:922,t:1511831734166};\\\", \\\"{x:1100,y:930,t:1511831734182};\\\", \\\"{x:1093,y:941,t:1511831734199};\\\", \\\"{x:1092,y:944,t:1511831734216};\\\", \\\"{x:1091,y:949,t:1511831734232};\\\", \\\"{x:1091,y:955,t:1511831734250};\\\", \\\"{x:1091,y:959,t:1511831734265};\\\", \\\"{x:1091,y:961,t:1511831734290};\\\", \\\"{x:1092,y:963,t:1511831734298};\\\", \\\"{x:1093,y:966,t:1511831734316};\\\", \\\"{x:1094,y:967,t:1511831734338};\\\", \\\"{x:1094,y:968,t:1511831734349};\\\", \\\"{x:1094,y:969,t:1511831734366};\\\", \\\"{x:1094,y:975,t:1511831734382};\\\", \\\"{x:1094,y:982,t:1511831734399};\\\", \\\"{x:1094,y:987,t:1511831734416};\\\", \\\"{x:1093,y:989,t:1511831734432};\\\", \\\"{x:1093,y:990,t:1511831734458};\\\", \\\"{x:1093,y:991,t:1511831734466};\\\", \\\"{x:1093,y:994,t:1511831734482};\\\", \\\"{x:1101,y:994,t:1511831734499};\\\", \\\"{x:1109,y:994,t:1511831734516};\\\", \\\"{x:1123,y:994,t:1511831734532};\\\", \\\"{x:1134,y:994,t:1511831734549};\\\", \\\"{x:1139,y:994,t:1511831734566};\\\", \\\"{x:1140,y:994,t:1511831734583};\\\", \\\"{x:1141,y:994,t:1511831734599};\\\", \\\"{x:1144,y:994,t:1511831734626};\\\", \\\"{x:1149,y:994,t:1511831734634};\\\", \\\"{x:1156,y:994,t:1511831734648};\\\", \\\"{x:1178,y:994,t:1511831734666};\\\", \\\"{x:1192,y:993,t:1511831734682};\\\", \\\"{x:1206,y:989,t:1511831734699};\\\", \\\"{x:1214,y:988,t:1511831734716};\\\", \\\"{x:1221,y:986,t:1511831734733};\\\", \\\"{x:1226,y:986,t:1511831734749};\\\", \\\"{x:1233,y:985,t:1511831734766};\\\", \\\"{x:1240,y:984,t:1511831734783};\\\", \\\"{x:1241,y:984,t:1511831734799};\\\", \\\"{x:1244,y:983,t:1511831734931};\\\", \\\"{x:1245,y:982,t:1511831734938};\\\", \\\"{x:1249,y:980,t:1511831734949};\\\", \\\"{x:1254,y:979,t:1511831734966};\\\", \\\"{x:1265,y:978,t:1511831734983};\\\", \\\"{x:1279,y:975,t:1511831735000};\\\", \\\"{x:1288,y:974,t:1511831735016};\\\", \\\"{x:1293,y:973,t:1511831735033};\\\", \\\"{x:1296,y:973,t:1511831735050};\\\", \\\"{x:1300,y:973,t:1511831735130};\\\", \\\"{x:1304,y:973,t:1511831735138};\\\", \\\"{x:1308,y:973,t:1511831735151};\\\", \\\"{x:1322,y:973,t:1511831735166};\\\", \\\"{x:1336,y:973,t:1511831735183};\\\", \\\"{x:1344,y:973,t:1511831735200};\\\", \\\"{x:1346,y:973,t:1511831735216};\\\", \\\"{x:1348,y:973,t:1511831735250};\\\", \\\"{x:1352,y:973,t:1511831735266};\\\", \\\"{x:1354,y:973,t:1511831735283};\\\", \\\"{x:1355,y:973,t:1511831735337};\\\", \\\"{x:1356,y:973,t:1511831735353};\\\", \\\"{x:1356,y:968,t:1511831736898};\\\", \\\"{x:1355,y:961,t:1511831736906};\\\", \\\"{x:1352,y:957,t:1511831736918};\\\", \\\"{x:1349,y:953,t:1511831736934};\\\", \\\"{x:1342,y:943,t:1511831736951};\\\", \\\"{x:1337,y:937,t:1511831736968};\\\", \\\"{x:1330,y:927,t:1511831736984};\\\", \\\"{x:1321,y:919,t:1511831737001};\\\", \\\"{x:1302,y:903,t:1511831737018};\\\", \\\"{x:1284,y:890,t:1511831737034};\\\", \\\"{x:1277,y:883,t:1511831737051};\\\", \\\"{x:1275,y:881,t:1511831737068};\\\", \\\"{x:1273,y:877,t:1511831737084};\\\", \\\"{x:1272,y:872,t:1511831737101};\\\", \\\"{x:1272,y:860,t:1511831737118};\\\", \\\"{x:1272,y:841,t:1511831737134};\\\", \\\"{x:1272,y:822,t:1511831737151};\\\", \\\"{x:1271,y:812,t:1511831737168};\\\", \\\"{x:1271,y:806,t:1511831737185};\\\", \\\"{x:1271,y:804,t:1511831737201};\\\", \\\"{x:1271,y:803,t:1511831737218};\\\", \\\"{x:1271,y:801,t:1511831737234};\\\", \\\"{x:1272,y:801,t:1511831737251};\\\", \\\"{x:1277,y:801,t:1511831737268};\\\", \\\"{x:1284,y:801,t:1511831737285};\\\", \\\"{x:1287,y:801,t:1511831737301};\\\", \\\"{x:1288,y:801,t:1511831737318};\\\", \\\"{x:1289,y:801,t:1511831737346};\\\", \\\"{x:1292,y:801,t:1511831737362};\\\", \\\"{x:1294,y:801,t:1511831737370};\\\", \\\"{x:1299,y:802,t:1511831737385};\\\", \\\"{x:1309,y:806,t:1511831737401};\\\", \\\"{x:1312,y:808,t:1511831737418};\\\", \\\"{x:1312,y:809,t:1511831737434};\\\", \\\"{x:1312,y:810,t:1511831737451};\\\", \\\"{x:1312,y:814,t:1511831737468};\\\", \\\"{x:1312,y:816,t:1511831737485};\\\", \\\"{x:1312,y:821,t:1511831737501};\\\", \\\"{x:1312,y:824,t:1511831737518};\\\", \\\"{x:1312,y:825,t:1511831737535};\\\", \\\"{x:1311,y:825,t:1511831737562};\\\", \\\"{x:1305,y:825,t:1511831737570};\\\", \\\"{x:1295,y:821,t:1511831737585};\\\", \\\"{x:1251,y:800,t:1511831737601};\\\", \\\"{x:1124,y:752,t:1511831737618};\\\", \\\"{x:986,y:710,t:1511831737635};\\\", \\\"{x:816,y:672,t:1511831737652};\\\", \\\"{x:642,y:627,t:1511831737668};\\\", \\\"{x:490,y:606,t:1511831737684};\\\", \\\"{x:409,y:594,t:1511831737702};\\\", \\\"{x:382,y:590,t:1511831737718};\\\", \\\"{x:371,y:589,t:1511831737734};\\\", \\\"{x:365,y:587,t:1511831737751};\\\", \\\"{x:364,y:587,t:1511831737889};\\\", \\\"{x:364,y:586,t:1511831737905};\\\", \\\"{x:365,y:585,t:1511831737918};\\\", \\\"{x:367,y:585,t:1511831737934};\\\", \\\"{x:367,y:583,t:1511831738050};\\\", \\\"{x:367,y:581,t:1511831738057};\\\", \\\"{x:367,y:580,t:1511831738073};\\\", \\\"{x:367,y:579,t:1511831738106};\\\", \\\"{x:364,y:579,t:1511831738129};\\\", \\\"{x:359,y:580,t:1511831738137};\\\", \\\"{x:356,y:581,t:1511831738151};\\\", \\\"{x:347,y:588,t:1511831738169};\\\", \\\"{x:338,y:592,t:1511831738185};\\\", \\\"{x:320,y:597,t:1511831738201};\\\", \\\"{x:308,y:601,t:1511831738218};\\\", \\\"{x:304,y:601,t:1511831738235};\\\", \\\"{x:304,y:602,t:1511831738306};\\\", \\\"{x:303,y:602,t:1511831738318};\\\", \\\"{x:301,y:602,t:1511831738335};\\\", \\\"{x:300,y:603,t:1511831738351};\\\", \\\"{x:298,y:603,t:1511831738369};\\\", \\\"{x:294,y:605,t:1511831738385};\\\", \\\"{x:289,y:610,t:1511831738401};\\\", \\\"{x:285,y:615,t:1511831738419};\\\", \\\"{x:282,y:620,t:1511831738435};\\\", \\\"{x:279,y:622,t:1511831738451};\\\", \\\"{x:278,y:623,t:1511831738468};\\\", \\\"{x:279,y:623,t:1511831738633};\\\", \\\"{x:283,y:622,t:1511831738640};\\\", \\\"{x:283,y:621,t:1511831738651};\\\", \\\"{x:286,y:619,t:1511831738668};\\\", \\\"{x:287,y:618,t:1511831738685};\\\", \\\"{x:288,y:616,t:1511831738745};\\\", \\\"{x:289,y:615,t:1511831738760};\\\", \\\"{x:289,y:614,t:1511831738768};\\\", \\\"{x:290,y:611,t:1511831738785};\\\", \\\"{x:290,y:607,t:1511831738802};\\\", \\\"{x:290,y:604,t:1511831738819};\\\", \\\"{x:290,y:600,t:1511831738835};\\\", \\\"{x:290,y:596,t:1511831738852};\\\", \\\"{x:283,y:593,t:1511831738868};\\\", \\\"{x:268,y:590,t:1511831738885};\\\", \\\"{x:248,y:588,t:1511831738902};\\\", \\\"{x:221,y:585,t:1511831738918};\\\", \\\"{x:200,y:582,t:1511831738935};\\\", \\\"{x:194,y:582,t:1511831738952};\\\", \\\"{x:193,y:582,t:1511831738968};\\\", \\\"{x:191,y:582,t:1511831739050};\\\", \\\"{x:190,y:582,t:1511831739058};\\\", \\\"{x:189,y:583,t:1511831739068};\\\", \\\"{x:186,y:585,t:1511831739085};\\\", \\\"{x:183,y:586,t:1511831739103};\\\", \\\"{x:182,y:587,t:1511831739119};\\\", \\\"{x:182,y:588,t:1511831739137};\\\", \\\"{x:182,y:591,t:1511831739153};\\\", \\\"{x:182,y:599,t:1511831739169};\\\", \\\"{x:182,y:605,t:1511831739186};\\\", \\\"{x:182,y:607,t:1511831739202};\\\", \\\"{x:182,y:606,t:1511831739474};\\\", \\\"{x:182,y:602,t:1511831739486};\\\", \\\"{x:181,y:599,t:1511831739502};\\\", \\\"{x:181,y:596,t:1511831739519};\\\", \\\"{x:180,y:595,t:1511831739537};\\\", \\\"{x:180,y:594,t:1511831739552};\\\", \\\"{x:187,y:600,t:1511831739993};\\\", \\\"{x:196,y:609,t:1511831740003};\\\", \\\"{x:218,y:624,t:1511831740019};\\\", \\\"{x:241,y:640,t:1511831740036};\\\", \\\"{x:263,y:652,t:1511831740053};\\\", \\\"{x:276,y:659,t:1511831740069};\\\", \\\"{x:296,y:664,t:1511831740086};\\\", \\\"{x:314,y:668,t:1511831740103};\\\", \\\"{x:328,y:669,t:1511831740120};\\\", \\\"{x:342,y:671,t:1511831740137};\\\", \\\"{x:356,y:675,t:1511831740154};\\\", \\\"{x:358,y:677,t:1511831740169};\\\", \\\"{x:360,y:677,t:1511831740186};\\\", \\\"{x:360,y:678,t:1511831740203};\\\", \\\"{x:362,y:679,t:1511831740289};\\\", \\\"{x:364,y:681,t:1511831740303};\\\", \\\"{x:366,y:684,t:1511831740319};\\\", \\\"{x:367,y:686,t:1511831740336};\\\", \\\"{x:368,y:687,t:1511831740353};\\\", \\\"{x:369,y:687,t:1511831740369};\\\" ] }, { \\\"rt\\\": 12413, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 547308, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"explicit\\\": 3, \\\"impasse\\\": 2, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-12 PM-02 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:369,y:682,t:1511831742209};\\\", \\\"{x:367,y:677,t:1511831742221};\\\", \\\"{x:361,y:668,t:1511831742238};\\\", \\\"{x:357,y:663,t:1511831742254};\\\", \\\"{x:354,y:660,t:1511831742271};\\\", \\\"{x:353,y:659,t:1511831742288};\\\", \\\"{x:353,y:658,t:1511831742304};\\\", \\\"{x:353,y:655,t:1511831742321};\\\", \\\"{x:353,y:651,t:1511831742338};\\\", \\\"{x:353,y:649,t:1511831742354};\\\", \\\"{x:353,y:645,t:1511831742372};\\\", \\\"{x:353,y:641,t:1511831742388};\\\", \\\"{x:353,y:637,t:1511831742405};\\\", \\\"{x:357,y:631,t:1511831742421};\\\", \\\"{x:369,y:623,t:1511831742438};\\\", \\\"{x:388,y:617,t:1511831742455};\\\", \\\"{x:401,y:613,t:1511831742471};\\\", \\\"{x:420,y:609,t:1511831742488};\\\", \\\"{x:455,y:605,t:1511831742505};\\\", \\\"{x:482,y:605,t:1511831742521};\\\", \\\"{x:506,y:605,t:1511831742538};\\\", \\\"{x:528,y:609,t:1511831742554};\\\", \\\"{x:551,y:620,t:1511831742572};\\\", \\\"{x:575,y:639,t:1511831742588};\\\", \\\"{x:604,y:660,t:1511831742605};\\\", \\\"{x:625,y:678,t:1511831742621};\\\", \\\"{x:647,y:696,t:1511831742638};\\\", \\\"{x:665,y:716,t:1511831742655};\\\", \\\"{x:681,y:734,t:1511831742671};\\\", \\\"{x:692,y:747,t:1511831742688};\\\", \\\"{x:696,y:757,t:1511831742704};\\\", \\\"{x:697,y:760,t:1511831742721};\\\", \\\"{x:699,y:762,t:1511831742738};\\\", \\\"{x:699,y:763,t:1511831742755};\\\", \\\"{x:699,y:764,t:1511831742784};\\\", \\\"{x:699,y:765,t:1511831742800};\\\", \\\"{x:700,y:766,t:1511831742832};\\\", \\\"{x:700,y:767,t:1511831743138};\\\", \\\"{x:708,y:770,t:1511831744801};\\\", \\\"{x:723,y:776,t:1511831744809};\\\", \\\"{x:736,y:779,t:1511831744823};\\\", \\\"{x:763,y:785,t:1511831744840};\\\", \\\"{x:787,y:792,t:1511831744856};\\\", \\\"{x:822,y:805,t:1511831744874};\\\", \\\"{x:843,y:815,t:1511831744891};\\\", \\\"{x:867,y:824,t:1511831744907};\\\", \\\"{x:885,y:834,t:1511831744925};\\\", \\\"{x:905,y:846,t:1511831744941};\\\", \\\"{x:926,y:858,t:1511831744957};\\\", \\\"{x:950,y:872,t:1511831744974};\\\", \\\"{x:982,y:891,t:1511831744991};\\\", \\\"{x:1021,y:908,t:1511831745007};\\\", \\\"{x:1051,y:926,t:1511831745024};\\\", \\\"{x:1083,y:944,t:1511831745041};\\\", \\\"{x:1119,y:965,t:1511831745057};\\\", \\\"{x:1170,y:992,t:1511831745074};\\\", \\\"{x:1199,y:1007,t:1511831745091};\\\", \\\"{x:1229,y:1018,t:1511831745107};\\\", \\\"{x:1246,y:1022,t:1511831745124};\\\", \\\"{x:1260,y:1027,t:1511831745141};\\\", \\\"{x:1263,y:1028,t:1511831745158};\\\", \\\"{x:1264,y:1028,t:1511831745174};\\\", \\\"{x:1265,y:1029,t:1511831745191};\\\", \\\"{x:1265,y:1031,t:1511831745208};\\\", \\\"{x:1269,y:1035,t:1511831745224};\\\", \\\"{x:1272,y:1037,t:1511831745241};\\\", \\\"{x:1272,y:1036,t:1511831745338};\\\", \\\"{x:1269,y:1034,t:1511831745345};\\\", \\\"{x:1262,y:1031,t:1511831745357};\\\", \\\"{x:1246,y:1023,t:1511831745374};\\\", \\\"{x:1234,y:1020,t:1511831745390};\\\", \\\"{x:1228,y:1018,t:1511831745408};\\\", \\\"{x:1226,y:1018,t:1511831745424};\\\", \\\"{x:1226,y:1017,t:1511831745441};\\\", \\\"{x:1226,y:1016,t:1511831745474};\\\", \\\"{x:1225,y:1015,t:1511831745491};\\\", \\\"{x:1225,y:1014,t:1511831745508};\\\", \\\"{x:1225,y:1013,t:1511831745529};\\\", \\\"{x:1225,y:1012,t:1511831745545};\\\", \\\"{x:1225,y:1011,t:1511831745561};\\\", \\\"{x:1225,y:1010,t:1511831745574};\\\", \\\"{x:1225,y:1009,t:1511831745591};\\\", \\\"{x:1225,y:1008,t:1511831745632};\\\", \\\"{x:1227,y:1007,t:1511831746186};\\\", \\\"{x:1235,y:1004,t:1511831746193};\\\", \\\"{x:1243,y:1002,t:1511831746207};\\\", \\\"{x:1256,y:998,t:1511831746225};\\\", \\\"{x:1261,y:996,t:1511831746241};\\\", \\\"{x:1272,y:993,t:1511831746258};\\\", \\\"{x:1288,y:991,t:1511831746275};\\\", \\\"{x:1301,y:991,t:1511831746292};\\\", \\\"{x:1306,y:991,t:1511831746308};\\\", \\\"{x:1307,y:991,t:1511831746325};\\\", \\\"{x:1307,y:990,t:1511831746377};\\\", \\\"{x:1309,y:988,t:1511831746426};\\\", \\\"{x:1311,y:982,t:1511831746441};\\\", \\\"{x:1312,y:979,t:1511831746458};\\\", \\\"{x:1313,y:977,t:1511831746474};\\\", \\\"{x:1313,y:974,t:1511831746492};\\\", \\\"{x:1313,y:973,t:1511831746509};\\\", \\\"{x:1313,y:971,t:1511831746525};\\\", \\\"{x:1313,y:969,t:1511831746542};\\\", \\\"{x:1309,y:969,t:1511831746559};\\\", \\\"{x:1307,y:968,t:1511831746575};\\\", \\\"{x:1306,y:968,t:1511831746601};\\\", \\\"{x:1304,y:967,t:1511831746609};\\\", \\\"{x:1301,y:967,t:1511831746625};\\\", \\\"{x:1300,y:966,t:1511831746642};\\\", \\\"{x:1298,y:965,t:1511831746659};\\\", \\\"{x:1298,y:963,t:1511831746776};\\\", \\\"{x:1297,y:962,t:1511831746791};\\\", \\\"{x:1297,y:956,t:1511831746808};\\\", \\\"{x:1296,y:954,t:1511831746824};\\\", \\\"{x:1295,y:952,t:1511831746841};\\\", \\\"{x:1294,y:952,t:1511831746864};\\\", \\\"{x:1292,y:952,t:1511831746874};\\\", \\\"{x:1284,y:952,t:1511831746891};\\\", \\\"{x:1276,y:952,t:1511831746908};\\\", \\\"{x:1272,y:952,t:1511831746925};\\\", \\\"{x:1271,y:952,t:1511831746945};\\\", \\\"{x:1271,y:951,t:1511831747143};\\\", \\\"{x:1273,y:950,t:1511831747158};\\\", \\\"{x:1275,y:949,t:1511831747182};\\\", \\\"{x:1276,y:948,t:1511831747206};\\\", \\\"{x:1277,y:948,t:1511831747238};\\\", \\\"{x:1278,y:948,t:1511831747256};\\\", \\\"{x:1279,y:947,t:1511831747278};\\\", \\\"{x:1280,y:947,t:1511831747318};\\\", \\\"{x:1282,y:946,t:1511831747326};\\\", \\\"{x:1284,y:945,t:1511831747339};\\\", \\\"{x:1286,y:945,t:1511831747356};\\\", \\\"{x:1288,y:943,t:1511831747373};\\\", \\\"{x:1288,y:947,t:1511831747494};\\\", \\\"{x:1288,y:952,t:1511831747506};\\\", \\\"{x:1288,y:961,t:1511831747523};\\\", \\\"{x:1288,y:964,t:1511831747540};\\\", \\\"{x:1288,y:966,t:1511831747556};\\\", \\\"{x:1288,y:968,t:1511831747573};\\\", \\\"{x:1288,y:969,t:1511831747590};\\\", \\\"{x:1288,y:970,t:1511831747606};\\\", \\\"{x:1288,y:966,t:1511831747830};\\\", \\\"{x:1288,y:962,t:1511831747840};\\\", \\\"{x:1290,y:951,t:1511831747855};\\\", \\\"{x:1290,y:939,t:1511831747872};\\\", \\\"{x:1292,y:928,t:1511831747889};\\\", \\\"{x:1293,y:914,t:1511831747906};\\\", \\\"{x:1295,y:900,t:1511831747922};\\\", \\\"{x:1295,y:888,t:1511831747939};\\\", \\\"{x:1295,y:881,t:1511831747956};\\\", \\\"{x:1295,y:873,t:1511831747972};\\\", \\\"{x:1295,y:864,t:1511831747989};\\\", \\\"{x:1295,y:859,t:1511831748006};\\\", \\\"{x:1295,y:857,t:1511831748022};\\\", \\\"{x:1295,y:855,t:1511831748040};\\\", \\\"{x:1295,y:854,t:1511831748057};\\\", \\\"{x:1296,y:852,t:1511831748073};\\\", \\\"{x:1296,y:850,t:1511831748090};\\\", \\\"{x:1297,y:847,t:1511831748107};\\\", \\\"{x:1297,y:846,t:1511831748123};\\\", \\\"{x:1297,y:845,t:1511831748142};\\\", \\\"{x:1297,y:843,t:1511831748223};\\\", \\\"{x:1297,y:841,t:1511831748240};\\\", \\\"{x:1297,y:839,t:1511831748257};\\\", \\\"{x:1296,y:837,t:1511831748278};\\\", \\\"{x:1296,y:836,t:1511831748374};\\\", \\\"{x:1295,y:836,t:1511831748527};\\\", \\\"{x:1294,y:836,t:1511831748559};\\\", \\\"{x:1293,y:836,t:1511831748687};\\\", \\\"{x:1292,y:820,t:1511831749903};\\\", \\\"{x:1292,y:792,t:1511831749912};\\\", \\\"{x:1292,y:767,t:1511831749926};\\\", \\\"{x:1292,y:689,t:1511831749942};\\\", \\\"{x:1273,y:544,t:1511831749959};\\\", \\\"{x:1253,y:440,t:1511831749978};\\\", \\\"{x:1238,y:348,t:1511831749993};\\\", \\\"{x:1233,y:259,t:1511831750027};\\\", \\\"{x:1233,y:246,t:1511831750042};\\\", \\\"{x:1233,y:243,t:1511831750058};\\\", \\\"{x:1231,y:242,t:1511831750134};\\\", \\\"{x:1229,y:243,t:1511831750142};\\\", \\\"{x:1220,y:262,t:1511831750158};\\\", \\\"{x:1195,y:290,t:1511831750175};\\\", \\\"{x:1149,y:337,t:1511831750192};\\\", \\\"{x:1072,y:402,t:1511831750208};\\\", \\\"{x:976,y:484,t:1511831750225};\\\", \\\"{x:872,y:571,t:1511831750242};\\\", \\\"{x:754,y:667,t:1511831750258};\\\", \\\"{x:627,y:746,t:1511831750275};\\\", \\\"{x:500,y:808,t:1511831750292};\\\", \\\"{x:374,y:851,t:1511831750308};\\\", \\\"{x:304,y:865,t:1511831750325};\\\", \\\"{x:276,y:865,t:1511831750342};\\\", \\\"{x:271,y:863,t:1511831750359};\\\", \\\"{x:269,y:860,t:1511831750375};\\\", \\\"{x:266,y:850,t:1511831750392};\\\", \\\"{x:266,y:835,t:1511831750408};\\\", \\\"{x:265,y:812,t:1511831750425};\\\", \\\"{x:259,y:787,t:1511831750442};\\\", \\\"{x:251,y:764,t:1511831750459};\\\", \\\"{x:247,y:742,t:1511831750475};\\\", \\\"{x:246,y:723,t:1511831750492};\\\", \\\"{x:248,y:705,t:1511831750509};\\\", \\\"{x:260,y:690,t:1511831750525};\\\", \\\"{x:277,y:671,t:1511831750543};\\\", \\\"{x:283,y:659,t:1511831750559};\\\", \\\"{x:284,y:656,t:1511831750576};\\\", \\\"{x:284,y:655,t:1511831750592};\\\", \\\"{x:284,y:654,t:1511831750610};\\\", \\\"{x:284,y:652,t:1511831750628};\\\", \\\"{x:284,y:651,t:1511831750642};\\\", \\\"{x:284,y:646,t:1511831750665};\\\", \\\"{x:284,y:644,t:1511831750675};\\\", \\\"{x:283,y:638,t:1511831750692};\\\", \\\"{x:279,y:628,t:1511831750709};\\\", \\\"{x:275,y:623,t:1511831750725};\\\", \\\"{x:275,y:620,t:1511831750742};\\\", \\\"{x:274,y:620,t:1511831750759};\\\", \\\"{x:272,y:619,t:1511831750902};\\\", \\\"{x:269,y:618,t:1511831750910};\\\", \\\"{x:258,y:617,t:1511831750926};\\\", \\\"{x:245,y:614,t:1511831750942};\\\", \\\"{x:228,y:612,t:1511831750959};\\\", \\\"{x:214,y:610,t:1511831750976};\\\", \\\"{x:203,y:607,t:1511831750992};\\\", \\\"{x:193,y:603,t:1511831751009};\\\", \\\"{x:186,y:600,t:1511831751026};\\\", \\\"{x:185,y:599,t:1511831751042};\\\", \\\"{x:182,y:596,t:1511831751059};\\\", \\\"{x:181,y:595,t:1511831751074};\\\", \\\"{x:181,y:594,t:1511831751091};\\\", \\\"{x:180,y:594,t:1511831751107};\\\", \\\"{x:179,y:594,t:1511831751124};\\\", \\\"{x:177,y:594,t:1511831751141};\\\", \\\"{x:174,y:593,t:1511831751157};\\\", \\\"{x:168,y:591,t:1511831751174};\\\", \\\"{x:165,y:590,t:1511831751191};\\\", \\\"{x:165,y:589,t:1511831751222};\\\", \\\"{x:165,y:587,t:1511831751238};\\\", \\\"{x:168,y:586,t:1511831751246};\\\", \\\"{x:171,y:583,t:1511831751257};\\\", \\\"{x:173,y:581,t:1511831751274};\\\", \\\"{x:174,y:580,t:1511831751291};\\\", \\\"{x:174,y:579,t:1511831751343};\\\", \\\"{x:176,y:579,t:1511831751359};\\\", \\\"{x:179,y:579,t:1511831751374};\\\", \\\"{x:183,y:582,t:1511831751393};\\\", \\\"{x:184,y:587,t:1511831751410};\\\", \\\"{x:184,y:593,t:1511831751426};\\\", \\\"{x:184,y:599,t:1511831751443};\\\", \\\"{x:184,y:606,t:1511831751460};\\\", \\\"{x:184,y:609,t:1511831751476};\\\", \\\"{x:184,y:613,t:1511831751493};\\\", \\\"{x:183,y:614,t:1511831751510};\\\", \\\"{x:183,y:611,t:1511831751718};\\\", \\\"{x:183,y:609,t:1511831751726};\\\", \\\"{x:183,y:602,t:1511831751743};\\\", \\\"{x:182,y:598,t:1511831751760};\\\", \\\"{x:182,y:597,t:1511831752006};\\\", \\\"{x:186,y:597,t:1511831752014};\\\", \\\"{x:188,y:597,t:1511831752027};\\\", \\\"{x:197,y:599,t:1511831752043};\\\", \\\"{x:204,y:600,t:1511831752060};\\\", \\\"{x:208,y:600,t:1511831752077};\\\", \\\"{x:220,y:601,t:1511831752093};\\\", \\\"{x:262,y:602,t:1511831752110};\\\", \\\"{x:284,y:602,t:1511831752127};\\\", \\\"{x:304,y:602,t:1511831752143};\\\", \\\"{x:318,y:605,t:1511831752160};\\\", \\\"{x:329,y:605,t:1511831752177};\\\", \\\"{x:344,y:605,t:1511831752193};\\\", \\\"{x:364,y:605,t:1511831752210};\\\", \\\"{x:383,y:605,t:1511831752227};\\\", \\\"{x:398,y:605,t:1511831752244};\\\", \\\"{x:406,y:605,t:1511831752260};\\\", \\\"{x:409,y:605,t:1511831752277};\\\", \\\"{x:410,y:605,t:1511831752293};\\\", \\\"{x:413,y:605,t:1511831752310};\\\", \\\"{x:415,y:605,t:1511831752327};\\\", \\\"{x:419,y:605,t:1511831752343};\\\", \\\"{x:423,y:604,t:1511831752360};\\\", \\\"{x:427,y:601,t:1511831752377};\\\", \\\"{x:429,y:601,t:1511831752394};\\\", \\\"{x:430,y:600,t:1511831752410};\\\", \\\"{x:437,y:596,t:1511831752427};\\\", \\\"{x:446,y:592,t:1511831752444};\\\", \\\"{x:460,y:586,t:1511831752460};\\\", \\\"{x:472,y:581,t:1511831752477};\\\", \\\"{x:477,y:579,t:1511831752494};\\\", \\\"{x:479,y:578,t:1511831752510};\\\", \\\"{x:481,y:578,t:1511831752527};\\\", \\\"{x:499,y:576,t:1511831752545};\\\", \\\"{x:527,y:574,t:1511831752560};\\\", \\\"{x:556,y:570,t:1511831752578};\\\", \\\"{x:577,y:567,t:1511831752595};\\\", \\\"{x:586,y:566,t:1511831752610};\\\", \\\"{x:587,y:566,t:1511831752628};\\\", \\\"{x:589,y:566,t:1511831752687};\\\", \\\"{x:592,y:566,t:1511831752695};\\\", \\\"{x:595,y:566,t:1511831752710};\\\", \\\"{x:602,y:566,t:1511831752727};\\\", \\\"{x:615,y:566,t:1511831752745};\\\", \\\"{x:630,y:566,t:1511831752761};\\\", \\\"{x:640,y:566,t:1511831752778};\\\", \\\"{x:643,y:566,t:1511831752795};\\\", \\\"{x:645,y:566,t:1511831752811};\\\", \\\"{x:645,y:567,t:1511831752872};\\\", \\\"{x:644,y:567,t:1511831752879};\\\", \\\"{x:640,y:569,t:1511831752895};\\\", \\\"{x:638,y:570,t:1511831752912};\\\", \\\"{x:638,y:571,t:1511831752983};\\\", \\\"{x:637,y:571,t:1511831752994};\\\", \\\"{x:635,y:572,t:1511831753012};\\\", \\\"{x:634,y:573,t:1511831753027};\\\", \\\"{x:632,y:574,t:1511831753045};\\\", \\\"{x:630,y:574,t:1511831753198};\\\", \\\"{x:629,y:574,t:1511831753214};\\\", \\\"{x:627,y:574,t:1511831753262};\\\", \\\"{x:627,y:575,t:1511831753277};\\\", \\\"{x:623,y:576,t:1511831753294};\\\", \\\"{x:622,y:577,t:1511831753574};\\\", \\\"{x:619,y:579,t:1511831753582};\\\", \\\"{x:616,y:583,t:1511831753594};\\\", \\\"{x:579,y:601,t:1511831753611};\\\", \\\"{x:519,y:625,t:1511831753628};\\\", \\\"{x:447,y:654,t:1511831753644};\\\", \\\"{x:393,y:684,t:1511831753661};\\\", \\\"{x:349,y:710,t:1511831753678};\\\", \\\"{x:340,y:714,t:1511831753695};\\\", \\\"{x:337,y:716,t:1511831753711};\\\", \\\"{x:336,y:717,t:1511831753728};\\\", \\\"{x:335,y:717,t:1511831753745};\\\", \\\"{x:333,y:717,t:1511831753761};\\\", \\\"{x:329,y:717,t:1511831753778};\\\", \\\"{x:330,y:716,t:1511831753975};\\\", \\\"{x:335,y:716,t:1511831753983};\\\", \\\"{x:337,y:715,t:1511831753995};\\\", \\\"{x:340,y:715,t:1511831754012};\\\", \\\"{x:342,y:713,t:1511831754028};\\\", \\\"{x:344,y:713,t:1511831755623};\\\", \\\"{x:368,y:713,t:1511831755630};\\\", \\\"{x:450,y:718,t:1511831755646};\\\", \\\"{x:650,y:718,t:1511831755697};\\\", \\\"{x:696,y:721,t:1511831755713};\\\", \\\"{x:743,y:723,t:1511831755729};\\\", \\\"{x:786,y:728,t:1511831755746};\\\", \\\"{x:817,y:728,t:1511831755763};\\\", \\\"{x:839,y:728,t:1511831755779};\\\", \\\"{x:856,y:723,t:1511831755796};\\\", \\\"{x:871,y:715,t:1511831755813};\\\", \\\"{x:877,y:709,t:1511831755830};\\\", \\\"{x:878,y:703,t:1511831755846};\\\", \\\"{x:878,y:696,t:1511831755863};\\\", \\\"{x:873,y:686,t:1511831755880};\\\", \\\"{x:868,y:678,t:1511831755896};\\\", \\\"{x:865,y:671,t:1511831755913};\\\", \\\"{x:865,y:663,t:1511831755930};\\\", \\\"{x:865,y:657,t:1511831755946};\\\", \\\"{x:865,y:650,t:1511831755963};\\\", \\\"{x:865,y:646,t:1511831755981};\\\", \\\"{x:864,y:640,t:1511831755996};\\\", \\\"{x:864,y:636,t:1511831756013};\\\", \\\"{x:864,y:631,t:1511831756030};\\\", \\\"{x:864,y:627,t:1511831756047};\\\", \\\"{x:863,y:623,t:1511831756063};\\\", \\\"{x:861,y:620,t:1511831756080};\\\", \\\"{x:858,y:617,t:1511831756097};\\\", \\\"{x:855,y:614,t:1511831756113};\\\", \\\"{x:851,y:611,t:1511831756130};\\\", \\\"{x:848,y:608,t:1511831756147};\\\", \\\"{x:844,y:601,t:1511831756163};\\\", \\\"{x:837,y:592,t:1511831756181};\\\", \\\"{x:833,y:588,t:1511831756197};\\\", \\\"{x:830,y:585,t:1511831756214};\\\", \\\"{x:829,y:584,t:1511831756230};\\\", \\\"{x:829,y:583,t:1511831756254};\\\", \\\"{x:829,y:582,t:1511831756287};\\\", \\\"{x:829,y:580,t:1511831756297};\\\", \\\"{x:829,y:576,t:1511831756313};\\\", \\\"{x:829,y:572,t:1511831756331};\\\", \\\"{x:828,y:568,t:1511831756347};\\\", \\\"{x:825,y:564,t:1511831756363};\\\", \\\"{x:825,y:562,t:1511831756380};\\\", \\\"{x:825,y:561,t:1511831756397};\\\", \\\"{x:825,y:562,t:1511831756646};\\\", \\\"{x:825,y:566,t:1511831756654};\\\", \\\"{x:825,y:570,t:1511831756664};\\\", \\\"{x:822,y:574,t:1511831756680};\\\", \\\"{x:827,y:573,t:1511831757839};\\\", \\\"{x:832,y:573,t:1511831757849};\\\", \\\"{x:853,y:574,t:1511831757865};\\\", \\\"{x:878,y:585,t:1511831757882};\\\", \\\"{x:887,y:595,t:1511831757899};\\\", \\\"{x:887,y:606,t:1511831757915};\\\", \\\"{x:887,y:626,t:1511831757932};\\\", \\\"{x:886,y:646,t:1511831757949};\\\", \\\"{x:882,y:653,t:1511831757966};\\\", \\\"{x:883,y:650,t:1511831761575};\\\", \\\"{x:902,y:618,t:1511831761584};\\\", \\\"{x:927,y:587,t:1511831761601};\\\", \\\"{x:928,y:582,t:1511831761895};\\\", \\\"{x:926,y:577,t:1511831761902};\\\", \\\"{x:925,y:576,t:1511831761918};\\\", \\\"{x:925,y:575,t:1511831761991};\\\", \\\"{x:925,y:578,t:1511831762118};\\\", \\\"{x:925,y:588,t:1511831762135};\\\", \\\"{x:923,y:596,t:1511831762152};\\\", \\\"{x:921,y:606,t:1511831762169};\\\", \\\"{x:921,y:614,t:1511831762185};\\\", \\\"{x:920,y:621,t:1511831762201};\\\", \\\"{x:920,y:623,t:1511831762219};\\\", \\\"{x:920,y:625,t:1511831762235};\\\", \\\"{x:919,y:626,t:1511831762252};\\\", \\\"{x:919,y:628,t:1511831762268};\\\", \\\"{x:919,y:631,t:1511831762284};\\\", \\\"{x:919,y:634,t:1511831762301};\\\", \\\"{x:919,y:635,t:1511831762318};\\\", \\\"{x:919,y:636,t:1511831762334};\\\", \\\"{x:919,y:641,t:1511831762351};\\\", \\\"{x:919,y:651,t:1511831762368};\\\", \\\"{x:919,y:665,t:1511831762384};\\\", \\\"{x:923,y:676,t:1511831762401};\\\", \\\"{x:925,y:681,t:1511831762418};\\\", \\\"{x:926,y:684,t:1511831762435};\\\", \\\"{x:927,y:684,t:1511831763046};\\\", \\\"{x:929,y:680,t:1511831763054};\\\", \\\"{x:930,y:678,t:1511831763068};\\\", \\\"{x:932,y:669,t:1511831763085};\\\", \\\"{x:934,y:660,t:1511831763102};\\\", \\\"{x:938,y:648,t:1511831763118};\\\", \\\"{x:941,y:643,t:1511831763135};\\\", \\\"{x:941,y:642,t:1511831763152};\\\", \\\"{x:941,y:635,t:1511831764150};\\\", \\\"{x:937,y:617,t:1511831764158};\\\", \\\"{x:932,y:593,t:1511831764171};\\\", \\\"{x:895,y:416,t:1511831764205};\\\", \\\"{x:887,y:390,t:1511831764220};\\\", \\\"{x:874,y:345,t:1511831764236};\\\", \\\"{x:847,y:299,t:1511831764253};\\\", \\\"{x:837,y:283,t:1511831764270};\\\", \\\"{x:831,y:269,t:1511831764286};\\\", \\\"{x:828,y:260,t:1511831764303};\\\", \\\"{x:826,y:256,t:1511831764319};\\\", \\\"{x:826,y:252,t:1511831764336};\\\", \\\"{x:825,y:251,t:1511831764353};\\\", \\\"{x:825,y:250,t:1511831764369};\\\", \\\"{x:825,y:249,t:1511831764782};\\\", \\\"{x:824,y:247,t:1511831764790};\\\", \\\"{x:823,y:246,t:1511831764805};\\\", \\\"{x:823,y:243,t:1511831764821};\\\", \\\"{x:823,y:242,t:1511831764837};\\\", \\\"{x:823,y:240,t:1511831764854};\\\", \\\"{x:823,y:239,t:1511831764870};\\\", \\\"{x:823,y:237,t:1511831764887};\\\", \\\"{x:824,y:236,t:1511831765166};\\\", \\\"{x:826,y:235,t:1511831765174};\\\", \\\"{x:827,y:235,t:1511831765198};\\\", \\\"{x:829,y:235,t:1511831765294};\\\", \\\"{x:829,y:234,t:1511831765304};\\\", \\\"{x:830,y:234,t:1511831765322};\\\", \\\"{x:835,y:233,t:1511831765339};\\\", \\\"{x:837,y:233,t:1511831765354};\\\", \\\"{x:838,y:233,t:1511831765371};\\\", \\\"{x:839,y:233,t:1511831765388};\\\", \\\"{x:839,y:237,t:1511831765661};\\\", \\\"{x:833,y:249,t:1511831765671};\\\", \\\"{x:819,y:271,t:1511831765688};\\\", \\\"{x:801,y:295,t:1511831765704};\\\", \\\"{x:786,y:312,t:1511831765721};\\\", \\\"{x:783,y:315,t:1511831765737};\\\", \\\"{x:784,y:312,t:1511831765846};\\\", \\\"{x:787,y:310,t:1511831765854};\\\", \\\"{x:795,y:302,t:1511831765871};\\\", \\\"{x:804,y:295,t:1511831765888};\\\", \\\"{x:811,y:289,t:1511831765905};\\\", \\\"{x:812,y:287,t:1511831765922};\\\", \\\"{x:813,y:284,t:1511831765938};\\\", \\\"{x:814,y:283,t:1511831765955};\\\", \\\"{x:814,y:282,t:1511831765972};\\\", \\\"{x:814,y:279,t:1511831765988};\\\", \\\"{x:814,y:276,t:1511831766006};\\\", \\\"{x:817,y:269,t:1511831766023};\\\", \\\"{x:817,y:265,t:1511831766039};\\\", \\\"{x:818,y:263,t:1511831766055};\\\", \\\"{x:818,y:262,t:1511831766072};\\\", \\\"{x:818,y:261,t:1511831766111};\\\", \\\"{x:820,y:261,t:1511831766123};\\\", \\\"{x:822,y:259,t:1511831766139};\\\", \\\"{x:824,y:258,t:1511831766155};\\\", \\\"{x:825,y:258,t:1511831766172};\\\", \\\"{x:826,y:257,t:1511831766190};\\\", \\\"{x:827,y:257,t:1511831766205};\\\", \\\"{x:828,y:260,t:1511831766926};\\\", \\\"{x:830,y:265,t:1511831766939};\\\", \\\"{x:836,y:273,t:1511831766956};\\\", \\\"{x:842,y:281,t:1511831766973};\\\", \\\"{x:845,y:287,t:1511831766989};\\\", \\\"{x:845,y:289,t:1511831767006};\\\", \\\"{x:844,y:289,t:1511831767111};\\\", \\\"{x:842,y:288,t:1511831767123};\\\", \\\"{x:839,y:285,t:1511831767139};\\\", \\\"{x:836,y:281,t:1511831767157};\\\", \\\"{x:836,y:279,t:1511831767173};\\\", \\\"{x:835,y:277,t:1511831767189};\\\", \\\"{x:834,y:276,t:1511831767207};\\\", \\\"{x:834,y:279,t:1511831767351};\\\", \\\"{x:834,y:285,t:1511831767359};\\\", \\\"{x:834,y:293,t:1511831767374};\\\", \\\"{x:834,y:310,t:1511831767391};\\\", \\\"{x:834,y:316,t:1511831767407};\\\", \\\"{x:834,y:317,t:1511831767486};\\\", \\\"{x:834,y:319,t:1511831767510};\\\", \\\"{x:835,y:322,t:1511831767523};\\\", \\\"{x:836,y:327,t:1511831767540};\\\", \\\"{x:838,y:331,t:1511831767556};\\\", \\\"{x:839,y:335,t:1511831767573};\\\", \\\"{x:839,y:339,t:1511831767589};\\\", \\\"{x:839,y:349,t:1511831767606};\\\", \\\"{x:839,y:356,t:1511831767623};\\\", \\\"{x:839,y:363,t:1511831767639};\\\", \\\"{x:840,y:368,t:1511831767656};\\\", \\\"{x:840,y:369,t:1511831767673};\\\", \\\"{x:840,y:370,t:1511831767702};\\\", \\\"{x:840,y:372,t:1511831767710};\\\", \\\"{x:842,y:373,t:1511831767722};\\\", \\\"{x:842,y:380,t:1511831767739};\\\", \\\"{x:842,y:385,t:1511831767756};\\\", \\\"{x:844,y:391,t:1511831767772};\\\", \\\"{x:846,y:396,t:1511831767789};\\\", \\\"{x:846,y:402,t:1511831767806};\\\", \\\"{x:846,y:404,t:1511831767822};\\\", \\\"{x:846,y:406,t:1511831767839};\\\", \\\"{x:846,y:408,t:1511831767856};\\\", \\\"{x:847,y:409,t:1511831767873};\\\", \\\"{x:847,y:410,t:1511831767890};\\\", \\\"{x:848,y:410,t:1511831767917};\\\", \\\"{x:848,y:412,t:1511831768430};\\\", \\\"{x:848,y:416,t:1511831768441};\\\", \\\"{x:848,y:421,t:1511831768458};\\\", \\\"{x:848,y:424,t:1511831768474};\\\", \\\"{x:848,y:428,t:1511831768491};\\\", \\\"{x:846,y:432,t:1511831768508};\\\", \\\"{x:846,y:437,t:1511831768524};\\\", \\\"{x:845,y:440,t:1511831768540};\\\", \\\"{x:844,y:442,t:1511831768557};\\\", \\\"{x:843,y:445,t:1511831768574};\\\", \\\"{x:842,y:447,t:1511831768590};\\\", \\\"{x:839,y:452,t:1511831768607};\\\", \\\"{x:838,y:456,t:1511831768624};\\\", \\\"{x:837,y:458,t:1511831768641};\\\", \\\"{x:836,y:461,t:1511831768694};\\\", \\\"{x:835,y:462,t:1511831768710};\\\", \\\"{x:835,y:463,t:1511831768724};\\\", \\\"{x:834,y:466,t:1511831768741};\\\", \\\"{x:834,y:467,t:1511831768758};\\\", \\\"{x:834,y:466,t:1511831769014};\\\", \\\"{x:834,y:465,t:1511831769024};\\\", \\\"{x:834,y:462,t:1511831769041};\\\", \\\"{x:834,y:460,t:1511831769058};\\\", \\\"{x:834,y:459,t:1511831769074};\\\", \\\"{x:834,y:458,t:1511831769091};\\\", \\\"{x:834,y:457,t:1511831769108};\\\", \\\"{x:834,y:456,t:1511831769158};\\\", \\\"{x:834,y:454,t:1511831769190};\\\", \\\"{x:834,y:452,t:1511831769214};\\\", \\\"{x:834,y:451,t:1511831769238};\\\", \\\"{x:834,y:449,t:1511831769254};\\\", \\\"{x:834,y:447,t:1511831769262};\\\", \\\"{x:834,y:445,t:1511831769278};\\\", \\\"{x:835,y:443,t:1511831769291};\\\", \\\"{x:836,y:441,t:1511831769308};\\\", \\\"{x:836,y:440,t:1511831769324};\\\", \\\"{x:836,y:438,t:1511831769341};\\\", \\\"{x:836,y:434,t:1511831769358};\\\", \\\"{x:836,y:433,t:1511831769470};\\\", \\\"{x:836,y:432,t:1511831769478};\\\", \\\"{x:836,y:430,t:1511831769491};\\\", \\\"{x:836,y:428,t:1511831769508};\\\", \\\"{x:836,y:425,t:1511831769525};\\\", \\\"{x:836,y:424,t:1511831769550};\\\", \\\"{x:835,y:428,t:1511831769830};\\\", \\\"{x:834,y:430,t:1511831769841};\\\", \\\"{x:832,y:433,t:1511831769858};\\\", \\\"{x:832,y:435,t:1511831769875};\\\", \\\"{x:832,y:435,t:1511831770103};\\\", \\\"{x:832,y:438,t:1511831770326};\\\", \\\"{x:832,y:442,t:1511831770341};\\\", \\\"{x:832,y:446,t:1511831770359};\\\", \\\"{x:832,y:453,t:1511831770375};\\\", \\\"{x:832,y:457,t:1511831770392};\\\", \\\"{x:832,y:460,t:1511831770409};\\\", \\\"{x:832,y:461,t:1511831770494};\\\", \\\"{x:832,y:465,t:1511831770509};\\\", \\\"{x:832,y:471,t:1511831770525};\\\", \\\"{x:832,y:485,t:1511831770541};\\\", \\\"{x:832,y:493,t:1511831770559};\\\", \\\"{x:832,y:503,t:1511831770575};\\\", \\\"{x:832,y:515,t:1511831770592};\\\", \\\"{x:832,y:531,t:1511831770609};\\\", \\\"{x:832,y:543,t:1511831770625};\\\", \\\"{x:833,y:556,t:1511831770642};\\\", \\\"{x:834,y:567,t:1511831770659};\\\", \\\"{x:837,y:580,t:1511831770675};\\\", \\\"{x:837,y:587,t:1511831770692};\\\", \\\"{x:838,y:592,t:1511831770709};\\\", \\\"{x:839,y:595,t:1511831770725};\\\", \\\"{x:839,y:596,t:1511831770894};\\\", \\\"{x:839,y:598,t:1511831770909};\\\", \\\"{x:839,y:601,t:1511831770925};\\\", \\\"{x:840,y:604,t:1511831770942};\\\", \\\"{x:840,y:606,t:1511831770959};\\\", \\\"{x:841,y:609,t:1511831770976};\\\", \\\"{x:841,y:614,t:1511831770992};\\\", \\\"{x:842,y:619,t:1511831771009};\\\", \\\"{x:843,y:626,t:1511831771026};\\\", \\\"{x:844,y:634,t:1511831771042};\\\", \\\"{x:844,y:643,t:1511831771059};\\\", \\\"{x:844,y:653,t:1511831771076};\\\", \\\"{x:844,y:660,t:1511831771093};\\\", \\\"{x:844,y:665,t:1511831771109};\\\", \\\"{x:844,y:673,t:1511831771126};\\\", \\\"{x:844,y:679,t:1511831771142};\\\", \\\"{x:844,y:685,t:1511831771159};\\\", \\\"{x:844,y:689,t:1511831771175};\\\", \\\"{x:843,y:695,t:1511831771192};\\\", \\\"{x:840,y:700,t:1511831771209};\\\", \\\"{x:837,y:706,t:1511831771226};\\\", \\\"{x:835,y:710,t:1511831771243};\\\", \\\"{x:833,y:712,t:1511831771259};\\\", \\\"{x:831,y:713,t:1511831771276};\\\", \\\"{x:830,y:715,t:1511831771301};\\\", \\\"{x:829,y:717,t:1511831771334};\\\", \\\"{x:829,y:718,t:1511831771343};\\\", \\\"{x:829,y:720,t:1511831771359};\\\", \\\"{x:827,y:721,t:1511831771376};\\\", \\\"{x:826,y:725,t:1511831771393};\\\", \\\"{x:825,y:728,t:1511831771409};\\\", \\\"{x:825,y:730,t:1511831771426};\\\", \\\"{x:824,y:732,t:1511831771443};\\\", \\\"{x:824,y:733,t:1511831771459};\\\", \\\"{x:824,y:735,t:1511831771476};\\\", \\\"{x:824,y:738,t:1511831771493};\\\", \\\"{x:824,y:741,t:1511831771509};\\\", \\\"{x:824,y:742,t:1511831771526};\\\", \\\"{x:824,y:744,t:1511831771543};\\\", \\\"{x:823,y:745,t:1511831771559};\\\", \\\"{x:823,y:747,t:1511831771576};\\\", \\\"{x:823,y:750,t:1511831771593};\\\", \\\"{x:823,y:753,t:1511831771609};\\\", \\\"{x:823,y:755,t:1511831771626};\\\", \\\"{x:824,y:757,t:1511831771643};\\\", \\\"{x:824,y:760,t:1511831771660};\\\", \\\"{x:825,y:761,t:1511831771676};\\\", \\\"{x:826,y:763,t:1511831771693};\\\", \\\"{x:827,y:764,t:1511831771710};\\\", \\\"{x:827,y:766,t:1511831771726};\\\", \\\"{x:828,y:767,t:1511831771743};\\\", \\\"{x:829,y:769,t:1511831771760};\\\", \\\"{x:829,y:771,t:1511831771776};\\\", \\\"{x:830,y:773,t:1511831771794};\\\", \\\"{x:833,y:778,t:1511831771810};\\\", \\\"{x:833,y:780,t:1511831771830};\\\", \\\"{x:834,y:780,t:1511831771846};\\\", \\\"{x:834,y:781,t:1511831771934};\\\", \\\"{x:834,y:783,t:1511831771950};\\\", \\\"{x:835,y:785,t:1511831771960};\\\", \\\"{x:835,y:789,t:1511831771977};\\\", \\\"{x:836,y:794,t:1511831771994};\\\", \\\"{x:837,y:797,t:1511831772010};\\\", \\\"{x:837,y:799,t:1511831772027};\\\", \\\"{x:837,y:802,t:1511831772043};\\\", \\\"{x:838,y:805,t:1511831772060};\\\", \\\"{x:840,y:808,t:1511831772077};\\\", \\\"{x:840,y:810,t:1511831772093};\\\", \\\"{x:840,y:812,t:1511831772110};\\\", \\\"{x:840,y:814,t:1511831772127};\\\", \\\"{x:840,y:817,t:1511831772143};\\\", \\\"{x:840,y:818,t:1511831772160};\\\", \\\"{x:840,y:820,t:1511831772177};\\\", \\\"{x:840,y:823,t:1511831772194};\\\", \\\"{x:840,y:825,t:1511831772210};\\\", \\\"{x:840,y:827,t:1511831772227};\\\", \\\"{x:840,y:829,t:1511831772243};\\\", \\\"{x:840,y:830,t:1511831772260};\\\", \\\"{x:840,y:832,t:1511831772277};\\\", \\\"{x:840,y:833,t:1511831772293};\\\", \\\"{x:840,y:836,t:1511831772310};\\\", \\\"{x:840,y:837,t:1511831772327};\\\", \\\"{x:840,y:840,t:1511831772343};\\\", \\\"{x:840,y:842,t:1511831772360};\\\", \\\"{x:840,y:843,t:1511831772389};\\\", \\\"{x:840,y:845,t:1511831772429};\\\", \\\"{x:839,y:845,t:1511831772445};\\\", \\\"{x:839,y:842,t:1511831772549};\\\", \\\"{x:839,y:839,t:1511831772560};\\\", \\\"{x:839,y:830,t:1511831772577};\\\", \\\"{x:839,y:823,t:1511831772593};\\\", \\\"{x:839,y:818,t:1511831772610};\\\", \\\"{x:839,y:815,t:1511831772627};\\\", \\\"{x:839,y:812,t:1511831772644};\\\", \\\"{x:839,y:811,t:1511831772660};\\\", \\\"{x:839,y:809,t:1511831772677};\\\", \\\"{x:839,y:808,t:1511831772693};\\\", \\\"{x:839,y:806,t:1511831772710};\\\", \\\"{x:839,y:803,t:1511831772727};\\\", \\\"{x:839,y:802,t:1511831772749};\\\", \\\"{x:839,y:801,t:1511831772909};\\\", \\\"{x:838,y:801,t:1511831772917};\\\", \\\"{x:837,y:802,t:1511831772927};\\\", \\\"{x:836,y:802,t:1511831772944};\\\", \\\"{x:835,y:803,t:1511831772961};\\\", \\\"{x:834,y:803,t:1511831773509};\\\", \\\"{x:834,y:802,t:1511831773517};\\\", \\\"{x:834,y:798,t:1511831773528};\\\", \\\"{x:841,y:783,t:1511831773544};\\\", \\\"{x:842,y:769,t:1511831773561};\\\", \\\"{x:844,y:756,t:1511831773578};\\\", \\\"{x:845,y:741,t:1511831773594};\\\", \\\"{x:845,y:730,t:1511831773611};\\\", \\\"{x:845,y:722,t:1511831773628};\\\", \\\"{x:845,y:717,t:1511831773644};\\\", \\\"{x:845,y:715,t:1511831773661};\\\", \\\"{x:845,y:713,t:1511831773678};\\\", \\\"{x:845,y:711,t:1511831773694};\\\", \\\"{x:845,y:709,t:1511831773711};\\\", \\\"{x:845,y:708,t:1511831773728};\\\", \\\"{x:845,y:707,t:1511831774261};\\\", \\\"{x:844,y:706,t:1511831774278};\\\", \\\"{x:843,y:706,t:1511831774295};\\\", \\\"{x:842,y:706,t:1511831774312};\\\", \\\"{x:840,y:705,t:1511831774328};\\\", \\\"{x:839,y:704,t:1511831774517};\\\", \\\"{x:838,y:702,t:1511831774529};\\\", \\\"{x:837,y:702,t:1511831774545};\\\", \\\"{x:835,y:700,t:1511831774562};\\\", \\\"{x:835,y:699,t:1511831774581};\\\", \\\"{x:835,y:698,t:1511831774595};\\\", \\\"{x:834,y:697,t:1511831774653};\\\", \\\"{x:834,y:696,t:1511831774677};\\\", \\\"{x:833,y:695,t:1511831774685};\\\", \\\"{x:838,y:694,t:1511831775197};\\\", \\\"{x:846,y:694,t:1511831775213};\\\", \\\"{x:867,y:692,t:1511831775229};\\\", \\\"{x:893,y:688,t:1511831775246};\\\", \\\"{x:908,y:684,t:1511831775262};\\\", \\\"{x:918,y:683,t:1511831775279};\\\", \\\"{x:928,y:679,t:1511831775296};\\\", \\\"{x:932,y:679,t:1511831775312};\\\", \\\"{x:935,y:677,t:1511831775329};\\\", \\\"{x:939,y:675,t:1511831775346};\\\", \\\"{x:945,y:672,t:1511831775362};\\\", \\\"{x:953,y:667,t:1511831775379};\\\", \\\"{x:957,y:664,t:1511831775396};\\\", \\\"{x:960,y:663,t:1511831775413};\\\", \\\"{x:960,y:662,t:1511831775429};\\\", \\\"{x:962,y:663,t:1511831775598};\\\", \\\"{x:962,y:667,t:1511831775613};\\\", \\\"{x:963,y:675,t:1511831775629};\\\", \\\"{x:964,y:682,t:1511831775646};\\\", \\\"{x:965,y:686,t:1511831775663};\\\", \\\"{x:965,y:688,t:1511831775679};\\\", \\\"{x:965,y:690,t:1511831775696};\\\", \\\"{x:965,y:691,t:1511831775713};\\\", \\\"{x:965,y:692,t:1511831775729};\\\", \\\"{x:965,y:693,t:1511831775746};\\\", \\\"{x:965,y:694,t:1511831775763};\\\", \\\"{x:965,y:696,t:1511831775779};\\\", \\\"{x:964,y:699,t:1511831775796};\\\", \\\"{x:963,y:702,t:1511831775813};\\\", \\\"{x:961,y:706,t:1511831775829};\\\", \\\"{x:959,y:709,t:1511831775846};\\\", \\\"{x:958,y:711,t:1511831775863};\\\", \\\"{x:956,y:713,t:1511831775880};\\\", \\\"{x:956,y:714,t:1511831775896};\\\", \\\"{x:955,y:716,t:1511831775913};\\\", \\\"{x:955,y:717,t:1511831775933};\\\", \\\"{x:955,y:718,t:1511831775946};\\\", \\\"{x:955,y:719,t:1511831775963};\\\", \\\"{x:953,y:723,t:1511831775979};\\\", \\\"{x:952,y:726,t:1511831775996};\\\", \\\"{x:952,y:730,t:1511831776013};\\\", \\\"{x:952,y:734,t:1511831776029};\\\", \\\"{x:952,y:739,t:1511831776046};\\\", \\\"{x:952,y:743,t:1511831776063};\\\", \\\"{x:954,y:747,t:1511831776080};\\\", \\\"{x:955,y:751,t:1511831776096};\\\", \\\"{x:955,y:752,t:1511831776113};\\\", \\\"{x:956,y:753,t:1511831776130};\\\", \\\"{x:956,y:754,t:1511831776146};\\\", \\\"{x:956,y:755,t:1511831776163};\\\", \\\"{x:957,y:757,t:1511831776180};\\\", \\\"{x:958,y:761,t:1511831776196};\\\", \\\"{x:958,y:763,t:1511831776213};\\\", \\\"{x:959,y:768,t:1511831776229};\\\", \\\"{x:960,y:770,t:1511831776246};\\\", \\\"{x:960,y:773,t:1511831776263};\\\", \\\"{x:960,y:774,t:1511831776280};\\\", \\\"{x:960,y:777,t:1511831776297};\\\", \\\"{x:960,y:778,t:1511831776313};\\\", \\\"{x:960,y:781,t:1511831776330};\\\", \\\"{x:960,y:784,t:1511831776347};\\\", \\\"{x:959,y:788,t:1511831776363};\\\", \\\"{x:958,y:789,t:1511831776380};\\\", \\\"{x:958,y:791,t:1511831776397};\\\", \\\"{x:957,y:792,t:1511831776413};\\\", \\\"{x:956,y:793,t:1511831776533};\\\", \\\"{x:955,y:794,t:1511831776549};\\\", \\\"{x:955,y:796,t:1511831776565};\\\", \\\"{x:955,y:797,t:1511831776693};\\\", \\\"{x:955,y:799,t:1511831776701};\\\", \\\"{x:955,y:800,t:1511831776717};\\\", \\\"{x:955,y:802,t:1511831776733};\\\", \\\"{x:955,y:803,t:1511831776757};\\\", \\\"{x:955,y:804,t:1511831776773};\\\", \\\"{x:955,y:805,t:1511831776781};\\\", \\\"{x:955,y:806,t:1511831776797};\\\", \\\"{x:955,y:808,t:1511831776821};\\\", \\\"{x:955,y:809,t:1511831776830};\\\", \\\"{x:955,y:811,t:1511831776847};\\\", \\\"{x:955,y:813,t:1511831776864};\\\", \\\"{x:955,y:816,t:1511831776880};\\\", \\\"{x:955,y:821,t:1511831776897};\\\", \\\"{x:956,y:826,t:1511831776914};\\\", \\\"{x:959,y:837,t:1511831776930};\\\", \\\"{x:962,y:845,t:1511831776947};\\\", \\\"{x:963,y:852,t:1511831776964};\\\", \\\"{x:965,y:856,t:1511831776980};\\\", \\\"{x:965,y:863,t:1511831777197};\\\", \\\"{x:956,y:889,t:1511831777214};\\\", \\\"{x:925,y:929,t:1511831777231};\\\", \\\"{x:902,y:954,t:1511831777247};\\\", \\\"{x:885,y:969,t:1511831777264};\\\", \\\"{x:874,y:976,t:1511831777281};\\\", \\\"{x:868,y:979,t:1511831777297};\\\", \\\"{x:867,y:979,t:1511831777314};\\\", \\\"{x:866,y:979,t:1511831777413};\\\", \\\"{x:865,y:979,t:1511831777437};\\\", \\\"{x:864,y:979,t:1511831777447};\\\", \\\"{x:860,y:979,t:1511831777464};\\\", \\\"{x:856,y:976,t:1511831777481};\\\", \\\"{x:853,y:974,t:1511831777497};\\\", \\\"{x:850,y:972,t:1511831777514};\\\", \\\"{x:846,y:971,t:1511831777531};\\\", \\\"{x:840,y:971,t:1511831777547};\\\", \\\"{x:830,y:969,t:1511831777564};\\\", \\\"{x:825,y:969,t:1511831777581};\\\", \\\"{x:822,y:968,t:1511831777597};\\\", \\\"{x:822,y:967,t:1511831777717};\\\", \\\"{x:822,y:965,t:1511831777731};\\\", \\\"{x:822,y:964,t:1511831777748};\\\", \\\"{x:822,y:964,t:1511831777782};\\\", \\\"{x:822,y:963,t:1511831778045};\\\", \\\"{x:824,y:963,t:1511831778061};\\\", \\\"{x:825,y:963,t:1511831778069};\\\", \\\"{x:826,y:961,t:1511831778081};\\\", \\\"{x:828,y:961,t:1511831778098};\\\", \\\"{x:829,y:961,t:1511831778157};\\\", \\\"{x:832,y:961,t:1511831778173};\\\", \\\"{x:835,y:961,t:1511831778181};\\\", \\\"{x:840,y:966,t:1511831778198};\\\", \\\"{x:844,y:971,t:1511831778215};\\\", \\\"{x:848,y:976,t:1511831778231};\\\", \\\"{x:854,y:984,t:1511831778248};\\\", \\\"{x:857,y:989,t:1511831778265};\\\", \\\"{x:860,y:993,t:1511831778281};\\\", \\\"{x:860,y:995,t:1511831778298};\\\", \\\"{x:861,y:996,t:1511831778315};\\\", \\\"{x:862,y:998,t:1511831778331};\\\", \\\"{x:864,y:1001,t:1511831778348};\\\", \\\"{x:865,y:1007,t:1511831778365};\\\", \\\"{x:865,y:1008,t:1511831778381};\\\", \\\"{x:866,y:1009,t:1511831778398};\\\", \\\"{x:866,y:1010,t:1511831778429};\\\", \\\"{x:866,y:1011,t:1511831778437};\\\", \\\"{x:866,y:1014,t:1511831778448};\\\", \\\"{x:866,y:1017,t:1511831778465};\\\", \\\"{x:866,y:1018,t:1511831778482};\\\", \\\"{x:866,y:1020,t:1511831778501};\\\", \\\"{x:864,y:1020,t:1511831778925};\\\", \\\"{x:859,y:1018,t:1511831778933};\\\", \\\"{x:852,y:1012,t:1511831778949};\\\", \\\"{x:832,y:998,t:1511831778965};\\\", \\\"{x:794,y:974,t:1511831778982};\\\", \\\"{x:759,y:954,t:1511831778999};\\\", \\\"{x:724,y:926,t:1511831779015};\\\", \\\"{x:693,y:898,t:1511831779032};\\\", \\\"{x:655,y:852,t:1511831779049};\\\", \\\"{x:617,y:789,t:1511831779065};\\\", \\\"{x:586,y:705,t:1511831779082};\\\", \\\"{x:574,y:637,t:1511831779099};\\\", \\\"{x:571,y:594,t:1511831779115};\\\", \\\"{x:571,y:552,t:1511831779132};\\\", \\\"{x:571,y:514,t:1511831779149};\\\", \\\"{x:571,y:505,t:1511831779165};\\\", \\\"{x:578,y:488,t:1511831779182};\\\", \\\"{x:585,y:480,t:1511831779199};\\\", \\\"{x:604,y:466,t:1511831779215};\\\", \\\"{x:624,y:453,t:1511831779232};\\\", \\\"{x:658,y:432,t:1511831779249};\\\", \\\"{x:692,y:408,t:1511831779266};\\\", \\\"{x:723,y:394,t:1511831779282};\\\", \\\"{x:745,y:384,t:1511831779299};\\\", \\\"{x:757,y:376,t:1511831779316};\\\", \\\"{x:762,y:373,t:1511831779332};\\\", \\\"{x:776,y:367,t:1511831779349};\\\", \\\"{x:776,y:366,t:1511831779366};\\\", \\\"{x:780,y:392,t:1511831780301};\\\", \\\"{x:797,y:453,t:1511831780316};\\\", \\\"{x:873,y:625,t:1511831780333};\\\", \\\"{x:910,y:713,t:1511831780350};\\\", \\\"{x:947,y:801,t:1511831780366};\\\", \\\"{x:968,y:869,t:1511831780383};\\\", \\\"{x:985,y:924,t:1511831780400};\\\", \\\"{x:993,y:986,t:1511831780416};\\\", \\\"{x:995,y:1064,t:1511831780433};\\\", \\\"{x:995,y:1109,t:1511831780450};\\\", \\\"{x:995,y:1129,t:1511831780466};\\\", \\\"{x:996,y:1129,t:1511831780485};\\\", \\\"{x:996,y:1121,t:1511831780637};\\\", \\\"{x:995,y:1114,t:1511831780650};\\\", \\\"{x:989,y:1098,t:1511831780667};\\\", \\\"{x:981,y:1081,t:1511831780683};\\\", \\\"{x:976,y:1072,t:1511831780700};\\\", \\\"{x:972,y:1066,t:1511831780717};\\\", \\\"{x:971,y:1066,t:1511831780845};\\\", \\\"{x:970,y:1066,t:1511831780853};\\\", \\\"{x:969,y:1066,t:1511831780867};\\\", \\\"{x:966,y:1069,t:1511831780883};\\\", \\\"{x:966,y:1071,t:1511831780900};\\\", \\\"{x:966,y:1077,t:1511831780917};\\\", \\\"{x:966,y:1082,t:1511831780933};\\\", \\\"{x:966,y:1087,t:1511831780950};\\\", \\\"{x:966,y:1092,t:1511831780967};\\\", \\\"{x:966,y:1093,t:1511831780984};\\\", \\\"{x:966,y:1094,t:1511831781037};\\\", \\\"{x:966,y:1095,t:1511831781050};\\\", \\\"{x:966,y:1097,t:1511831781067};\\\", \\\"{x:965,y:1099,t:1511831781084};\\\", \\\"{x:965,y:1100,t:1511831781100};\\\", \\\"{x:965,y:1096,t:1511831781645};\\\", \\\"{x:964,y:1077,t:1511831781653};\\\", \\\"{x:960,y:1058,t:1511831781667};\\\", \\\"{x:937,y:967,t:1511831781684};\\\", \\\"{x:873,y:786,t:1511831781701};\\\", \\\"{x:810,y:676,t:1511831781717};\\\", \\\"{x:742,y:594,t:1511831781734};\\\", \\\"{x:679,y:527,t:1511831781751};\\\", \\\"{x:611,y:476,t:1511831781767};\\\", \\\"{x:572,y:442,t:1511831781784};\\\", \\\"{x:546,y:388,t:1511831781801};\\\", \\\"{x:535,y:339,t:1511831781817};\\\", \\\"{x:533,y:324,t:1511831781834};\\\", \\\"{x:533,y:323,t:1511831781851};\\\" ] }, { \\\"rt\\\": 7519, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 555830, \\\"internal_node_id\\\": \\\"0.0-7.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\" }, { \\\"rt\\\": 14983, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Spanish\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 571831, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\" }, { \\\"rt\\\": 1458, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 574382, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"T4UDR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"foxtrot\\\", \\\"condition\\\": \\\"321\\\" } ]\",\"parentNode\":{\"id\":1732}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":1,\"id\":53,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":8,\"id\":57},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\"T4UDR\"}]},{\"nodeType\":3,\"id\":75,\"textContent\":\" \"},{\"nodeType\":1,\"id\":76,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":8,\"id\":78},{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":1,\"id\":80,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\"Hint: hover your mouse over the data points for help\"}]},{\"nodeType\":3,\"id\":84,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":85,\"textContent\":\" \"},{\"nodeType\":8,\"id\":86},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":1,\"id\":90,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":96,\"textContent\":\" \"},{\"nodeType\":1,\"id\":97,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":100,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":101,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":103,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":106,\"textContent\":\" \"},{\"nodeType\":1,\"id\":107,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":108,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":109,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":111,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":114,\"textContent\":\" \"},{\"nodeType\":1,\"id\":115,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":116,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":117,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":119,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":122,\"textContent\":\" \"},{\"nodeType\":1,\"id\":123,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":124,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":125,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":127,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":130,\"textContent\":\" \"},{\"nodeType\":1,\"id\":131,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":132,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":133,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":135,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":138,\"textContent\":\" \"},{\"nodeType\":1,\"id\":139,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":140,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":141,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":143,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":146,\"textContent\":\" \"},{\"nodeType\":1,\"id\":147,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":148,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":149,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":151,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":154,\"textContent\":\" \"},{\"nodeType\":1,\"id\":155,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":156,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":157,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":158,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":159,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":161,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":162,\"textContent\":\" \"},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":164,\"textContent\":\"Which shift(s) start with D?\"}]},{\"nodeType\":3,\"id\":165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":166,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":170,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"},{\"nodeType\":1,\"id\":172,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":173,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":174,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":178,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"},{\"nodeType\":1,\"id\":180,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":181,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":182,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":186,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"},{\"nodeType\":1,\"id\":188,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":189,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":190,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":194,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"},{\"nodeType\":1,\"id\":196,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":197,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":198,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":201,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":202,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"},{\"nodeType\":1,\"id\":204,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":205,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":206,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":209,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":210,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"},{\"nodeType\":1,\"id\":212,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":213,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":214,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":217,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":218,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"},{\"nodeType\":1,\"id\":220,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":221,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":222,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":224,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":225,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":226,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":228,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":232,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":233,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":236,\"textContent\":\" \"},{\"nodeType\":1,\"id\":237,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":238,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":239,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":243,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"},{\"nodeType\":1,\"id\":245,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":246,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":247,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":251,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"},{\"nodeType\":1,\"id\":253,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":254,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":255,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":259,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"},{\"nodeType\":1,\"id\":261,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":262,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":263,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":267,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"},{\"nodeType\":1,\"id\":269,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":270,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":271,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":275,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"},{\"nodeType\":1,\"id\":277,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":278,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":279,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":283,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"},{\"nodeType\":1,\"id\":285,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":286,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":287,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":291,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"},{\"nodeType\":1,\"id\":293,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":294,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":295,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":296,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":297,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":300,\"textContent\":\" \"},{\"nodeType\":1,\"id\":301,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":302,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":303,\"textContent\":\" \"},{\"nodeType\":1,\"id\":304,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":306,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":307,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":312,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":314,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":315,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":320,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":322,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":323,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":328,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":330,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":331,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":336,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":338,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":339,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":344,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":346,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":347,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"},{\"nodeType\":1,\"id\":350,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":351,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":352,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":355,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":356,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":358,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":359,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":360,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":364,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":368,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":371,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":372,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":373,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":376,\"textContent\":\" \"},{\"nodeType\":1,\"id\":377,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":380,\"textContent\":\" \"},{\"nodeType\":1,\"id\":381,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":382,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":383,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":384,\"textContent\":\" \"},{\"nodeType\":1,\"id\":385,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":388,\"textContent\":\" \"},{\"nodeType\":1,\"id\":389,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":390,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":391,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":392,\"textContent\":\" \"},{\"nodeType\":1,\"id\":393,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":396,\"textContent\":\" \"},{\"nodeType\":1,\"id\":397,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":398,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":399,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":400,\"textContent\":\" \"},{\"nodeType\":1,\"id\":401,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":404,\"textContent\":\" \"},{\"nodeType\":1,\"id\":405,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":406,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":407,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":408,\"textContent\":\" \"},{\"nodeType\":1,\"id\":409,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":412,\"textContent\":\" \"},{\"nodeType\":1,\"id\":413,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":414,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":415,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":416,\"textContent\":\" \"},{\"nodeType\":1,\"id\":417,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":420,\"textContent\":\" \"},{\"nodeType\":1,\"id\":421,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":422,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":423,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":424,\"textContent\":\" \"},{\"nodeType\":1,\"id\":425,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":428,\"textContent\":\" \"},{\"nodeType\":1,\"id\":429,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":430,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":431,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":432,\"textContent\":\" \"},{\"nodeType\":1,\"id\":433,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":436,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":440,\"textContent\":\" \"},{\"nodeType\":1,\"id\":441,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":442,\"textContent\":\"Which shifts are six hours long?\"}]},{\"nodeType\":3,\"id\":443,\"textContent\":\" \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":445,\"textContent\":\" \"},{\"nodeType\":1,\"id\":446,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":447,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":448,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":452,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"},{\"nodeType\":1,\"id\":454,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":455,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":456,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":460,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"},{\"nodeType\":1,\"id\":462,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":463,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":464,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":468,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"},{\"nodeType\":1,\"id\":470,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":471,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":472,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":476,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"},{\"nodeType\":1,\"id\":478,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":479,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":480,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":481,\"textContent\":\" \"},{\"nodeType\":1,\"id\":482,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":484,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":487,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":488,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":489,\"textContent\":\" \"},{\"nodeType\":1,\"id\":490,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":493,\"textContent\":\" \"},{\"nodeType\":1,\"id\":494,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":495,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":496,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":497,\"textContent\":\" \"},{\"nodeType\":1,\"id\":498,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":501,\"textContent\":\" \"},{\"nodeType\":1,\"id\":502,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":503,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":504,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":506,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":509,\"textContent\":\" \"},{\"nodeType\":1,\"id\":510,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":511,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":512,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":513,\"textContent\":\" \"},{\"nodeType\":1,\"id\":514,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":517,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":521,\"textContent\":\" \"},{\"nodeType\":1,\"id\":522,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":523,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":524,\"textContent\":\" \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":526,\"textContent\":\" \"},{\"nodeType\":1,\"id\":527,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":528,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":529,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":533,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"},{\"nodeType\":1,\"id\":535,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":536,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":537,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":541,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"},{\"nodeType\":1,\"id\":543,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":544,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":545,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":549,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"},{\"nodeType\":1,\"id\":551,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":552,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":553,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":557,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"},{\"nodeType\":1,\"id\":559,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":560,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":561,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":565,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"},{\"nodeType\":1,\"id\":567,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":568,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":569,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":573,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"},{\"nodeType\":1,\"id\":575,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":576,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":577,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":581,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"},{\"nodeType\":1,\"id\":583,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":584,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":585,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":589,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"},{\"nodeType\":1,\"id\":591,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":592,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":593,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":597,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":601,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":604,\"textContent\":\"Which shift under 7 hours long starts before B and ends after X?\"}]},{\"nodeType\":3,\"id\":605,\"textContent\":\" \"},{\"nodeType\":1,\"id\":606,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":607,\"textContent\":\" \"},{\"nodeType\":1,\"id\":608,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":609,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":610,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":613,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":614,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":615,\"textContent\":\" \"},{\"nodeType\":1,\"id\":616,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":617,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":618,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":620,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":621,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":622,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":623,\"textContent\":\" \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":625,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":626,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":628,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":630,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":631,\"textContent\":\" \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":634,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":636,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":637,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":638,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":639,\"textContent\":\" \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":642,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":644,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":645,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":646,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":647,\"textContent\":\" \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":649,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":650,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":652,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":654,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":655,\"textContent\":\" \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":657,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":658,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":660,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":662,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":666,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":667,\"textContent\":\" \"},{\"nodeType\":1,\"id\":668,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":670,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":671,\"textContent\":\" \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":674,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":675,\"textContent\":\" \"},{\"nodeType\":1,\"id\":676,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":678,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":679,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":680,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":682,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":683,\"textContent\":\" \"},{\"nodeType\":1,\"id\":684,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\"Which shift begins before J and ends during B?\"}]},{\"nodeType\":3,\"id\":686,\"textContent\":\" \"},{\"nodeType\":1,\"id\":687,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":688,\"textContent\":\" \"},{\"nodeType\":1,\"id\":689,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":691,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":693,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":696,\"textContent\":\" \"},{\"nodeType\":1,\"id\":697,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":698,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":699,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":701,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":704,\"textContent\":\" \"},{\"nodeType\":1,\"id\":705,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":706,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":707,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":709,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":712,\"textContent\":\" \"},{\"nodeType\":1,\"id\":713,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":714,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":715,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":717,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":720,\"textContent\":\" \"},{\"nodeType\":1,\"id\":721,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":722,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":723,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":725,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":728,\"textContent\":\" \"},{\"nodeType\":1,\"id\":729,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":730,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":731,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":733,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":736,\"textContent\":\" \"},{\"nodeType\":1,\"id\":737,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":738,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":739,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":742,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":743,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":744,\"textContent\":\" \"},{\"nodeType\":1,\"id\":745,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":746,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":747,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":749,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":750,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":751,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":752,\"textContent\":\" \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":754,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":755,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":757,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":758,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":759,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":760,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":761,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"},{\"nodeType\":1,\"id\":763,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":765,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\"Which shift ends with F?\"}]},{\"nodeType\":3,\"id\":767,\"textContent\":\" \"},{\"nodeType\":1,\"id\":768,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":770,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":771,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":772,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":773,\"textContent\":\" \"},{\"nodeType\":1,\"id\":774,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":778,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":779,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":780,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":781,\"textContent\":\" \"},{\"nodeType\":1,\"id\":782,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":786,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":787,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":788,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":789,\"textContent\":\" \"},{\"nodeType\":1,\"id\":790,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":794,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":795,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":796,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":797,\"textContent\":\" \"},{\"nodeType\":1,\"id\":798,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":802,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":803,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":804,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":805,\"textContent\":\" \"},{\"nodeType\":1,\"id\":806,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":809,\"textContent\":\" \"},{\"nodeType\":1,\"id\":810,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":811,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":812,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":814,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":817,\"textContent\":\" \"},{\"nodeType\":1,\"id\":818,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":819,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":820,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":822,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":825,\"textContent\":\" \"},{\"nodeType\":1,\"id\":826,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":827,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":828,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":830,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":833,\"textContent\":\" \"},{\"nodeType\":1,\"id\":834,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":835,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":836,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":838,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":841,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":846,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":847,\"textContent\":\"Which shifts start at 12pm?\"}]},{\"nodeType\":3,\"id\":848,\"textContent\":\" \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":851,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":852,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":853,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":856,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":857,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":859,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":860,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":861,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":864,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":865,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":867,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":868,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":869,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":872,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":873,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":875,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":876,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":877,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":880,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":881,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":883,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":884,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":885,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":888,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":889,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":891,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":892,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":893,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":895,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":896,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":897,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":900,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":901,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":902,\"textContent\":\" \"},{\"nodeType\":1,\"id\":903,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":907,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":908,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":909,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":910,\"textContent\":\" \"},{\"nodeType\":1,\"id\":911,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":915,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":916,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":917,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":918,\"textContent\":\" \"},{\"nodeType\":1,\"id\":919,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":922,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":926,\"textContent\":\" \"},{\"nodeType\":1,\"id\":927,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":928,\"textContent\":\"Which shift starts with F?\"}]},{\"nodeType\":3,\"id\":929,\"textContent\":\" \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":931,\"textContent\":\" \"},{\"nodeType\":1,\"id\":932,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":933,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":934,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":937,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":938,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"},{\"nodeType\":1,\"id\":940,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":941,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":942,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":945,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":946,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"},{\"nodeType\":1,\"id\":948,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":949,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":950,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":953,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":954,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"},{\"nodeType\":1,\"id\":956,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":957,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":958,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":961,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":962,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"},{\"nodeType\":1,\"id\":964,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":965,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":966,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":969,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":970,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":972,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":973,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":974,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":977,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":978,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":980,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":981,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":982,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":985,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":986,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":988,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":989,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":990,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":993,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":994,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":996,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":997,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":998,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1001,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1002,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1005,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1006,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1009,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1010,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1011,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1015,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1016,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1017,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1018,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1023,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1024,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1025,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1026,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1031,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1032,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1033,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1034,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1039,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1040,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1041,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1042,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1045,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1046,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1047,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1050,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1051,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1053,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1054,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1055,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1058,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1059,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1061,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1062,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1063,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1066,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1067,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1069,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1070,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1071,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1074,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1075,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1077,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1078,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1079,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1082,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1083,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1087,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1090,\"textContent\":\"Which shift ends at 3pm?\"}]},{\"nodeType\":3,\"id\":1091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1092,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1096,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1097,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1098,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1099,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1104,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1105,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1106,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1107,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1112,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1113,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1114,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1115,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1120,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1121,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1122,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1123,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1128,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1130,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1131,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1136,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1138,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1139,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1144,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1146,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1147,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1152,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1154,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1155,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1160,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1162,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1163,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1166,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1168,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1170,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1171,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":1172,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":1173,\"textContent\":\"Which 2 shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":1174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1175,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1179,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1181,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1182,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1183,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1187,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1189,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1190,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1191,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1195,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1197,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1198,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1199,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1201,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1203,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1206,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1207,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1208,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1209,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1213,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1214,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1215,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1216,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1217,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1220,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1221,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1222,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1223,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1225,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1228,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1229,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1230,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1231,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1233,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1236,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1237,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1238,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1239,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1241,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1244,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1245,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1246,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1247,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1248,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1250,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1251,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1252},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1254},{\"nodeType\":3,\"id\":1255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1256,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"start\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":1259,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":1260,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1263},{\"nodeType\":3,\"id\":1264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1265,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":1266,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":1267,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1268,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":1269,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":1270,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":1271,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":1272,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1273,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1274,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1275,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":1276,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1277,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1278,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1279,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":1280,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1281,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1282,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1283,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":1284,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1285,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1286,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1287,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":1288,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1289,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1290,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1291,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":1292,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1293,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1294,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1295,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":1296,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1297,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1298,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1299,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":1300,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1301,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1302,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1303,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":1304,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1305,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1306,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1307,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":1308,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1309,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1310,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1311,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":1312,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1313,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1314,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1315,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":1316,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1317,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1318,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1319,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":1320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1321,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1322,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1323,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":1324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1325,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1326,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1327,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":1328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1329,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1330,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1331,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":1332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1333,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1334,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1335,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":1336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1337,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1338,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1339,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":1340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1341,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1342,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1343,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":1344,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1347,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":1348,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1351,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":1352,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1355,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":1356,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":1360,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1363,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":1364,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1367,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":1368,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1371,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":1372,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":1373,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1374,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":1375,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1376,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":1377,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":1378,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":1379,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":1380,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":1381,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":1382,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":1383,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":1384,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":1385,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":1386,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":1387,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":1388,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":1389,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":1390,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":1391,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":1392,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":1393,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":1394,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":1395,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":1396,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":1397,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":1398,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":1399,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":1400,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":1402,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1403,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1404,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1405,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":1406,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1407,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1408,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1409,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":1410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1413,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":1414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1417,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":1418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1421,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":1422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1425,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":1426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1429,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":1430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1433,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":1434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1437,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":1438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1441,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":1442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1445,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":1446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1449,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":1450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1453,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":1454,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":1455,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1456,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":1457,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1458,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1459,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":1460,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1461,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":1462,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1463,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":1464,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":1466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":1468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":1470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":1472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":1474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":1476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":1478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":1480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":1482,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":1483,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1484,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1485,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":1486,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":1487,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1488,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1489,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":1491,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1492,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1493,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":1494,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":1495,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1496,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1497,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":1499,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1500,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1501,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":1502,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":1503,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1504,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1505,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":1506,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":1507,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1508,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1509,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":1510,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":1511,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1512,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1513,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":1514,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":1515,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1516,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1517,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":1518,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":1519,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1520,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1521,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1522,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":1523,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1524,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1525,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":1526,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":1527,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1528,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1529,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":1530,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":1531,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1532,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1533,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":1534,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":1535,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1536,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1537,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1538,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":1539,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1540,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1541,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":1542,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":1543,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":1546,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":1547,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":1550,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":1551,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1554,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1556,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1557},{\"nodeType\":3,\"id\":1558,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1559,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":1562,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 89, dom: 624, initialDom: 695",
  "javascriptErrors": []
}