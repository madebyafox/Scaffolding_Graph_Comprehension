var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3d84864e3e9b79262fa4b840854de301",
  "created": "2017-12-05T10:20:45.2109652-08:00",
  "lastActivity": "2017-12-05T10:21:01.2223359-08:00",
  "pageViews": [
    {
      "id": "120545959593bfea57d4b099e8b2902984ef9dcb",
      "startTime": "2017-12-05T10:20:45.6971152-08:00",
      "endTime": "2017-12-05T10:21:01.2223359-08:00",
      "title": "FOX2YP",
      "uri": "http://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 15841,
      "engagementTime": 15841,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 15841,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=YS42C",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0346563fdd613de0d174e60e812d5e48",
  "gdpr": false
}