var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2b6f199638f2149333e4c380aad63bbf",
  "created": "2017-12-05T10:22:01.3116852-08:00",
  "lastActivity": "2017-12-05T10:23:27.4386852-08:00",
  "pageViews": [
    {
      "id": "1205012705d859b888dd42c8ce56b67aa1b787f0",
      "startTime": "2017-12-05T10:22:01.3116852-08:00",
      "endTime": "2017-12-05T10:23:27.4386852-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 86127,
      "engagementTime": 64726,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "annotations": []
    }
  ],
  "duration": 86127,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=73N5W",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "81deb02df7a1b8d617f611531bf4be0d",
  "gdpr": false
}