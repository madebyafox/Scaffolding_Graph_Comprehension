var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ca5f17fbcf8b5dd7c98036d07855c9f1",
  "created": "2017-12-05T09:15:41.4939227-08:00",
  "lastActivity": "2017-12-05T09:16:33.8355098-08:00",
  "pageViews": [
    {
      "id": "12054176fbd566858c2532318ae04e3ed152acd5",
      "startTime": "2017-12-05T09:15:41.4939227-08:00",
      "endTime": "2017-12-05T09:16:33.8355098-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 52592,
      "engagementTime": 50641,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 52592,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=LL91X",
    "CONDITION=112",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "db9d59005979a228c4ba6858ae97de56",
  "gdpr": false
}