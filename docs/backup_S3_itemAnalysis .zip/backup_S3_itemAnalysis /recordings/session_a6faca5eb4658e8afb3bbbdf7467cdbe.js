var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f6c5da88b0306bf1ee36e81d4336f653",
  "created": "2017-12-05T10:21:39.9349461-08:00",
  "lastActivity": "2017-12-05T10:22:04.8789461-08:00",
  "pageViews": [
    {
      "id": "1205404887b1354fc82a1cc053b4227595440d42",
      "startTime": "2017-12-05T10:21:39.9349461-08:00",
      "endTime": "2017-12-05T10:22:04.8789461-08:00",
      "title": "FOX2YP",
      "uri": "http://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 24944,
      "engagementTime": 24944,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 24944,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=GKC1Y",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a6faca5eb4658e8afb3bbbdf7467cdbe",
  "gdpr": false
}