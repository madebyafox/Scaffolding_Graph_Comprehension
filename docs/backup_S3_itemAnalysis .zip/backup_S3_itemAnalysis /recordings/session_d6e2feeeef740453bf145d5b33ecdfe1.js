var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "030057e78e5f8c046d00e29d82538381",
  "created": "2017-12-05T10:18:21.251682-08:00",
  "lastActivity": "2017-12-05T10:19:17.774682-08:00",
  "pageViews": [
    {
      "id": "120521773afe0df4fd09899b0b7dd6865d400e67",
      "startTime": "2017-12-05T10:18:21.251682-08:00",
      "endTime": "2017-12-05T10:19:17.774682-08:00",
      "title": "FOX2YP",
      "uri": "http://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 56523,
      "engagementTime": 56523,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 56523,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TMVBA",
    "CONDITION=112",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d6e2feeeef740453bf145d5b33ecdfe1",
  "gdpr": false
}