var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4eaf36fdabd94d710df15d77991c5e7b",
  "created": "2017-11-16T09:09:49.9719455-08:00",
  "lastActivity": "2017-11-16T09:10:13.2559455-08:00",
  "pageViews": [
    {
      "id": "111649167b4af9cc6b45ad28fee796af1d47a35f",
      "startTime": "2017-11-16T09:09:49.9719455-08:00",
      "endTime": "2017-11-16T09:10:13.2559455-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 23284,
      "engagementTime": 23284,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 23284,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=O577M",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "eae009922ade54fb5720fc674524f4ec",
  "gdpr": false
}