var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5e9e3209a48312f47c740ed104ae2c7e",
  "created": "2017-12-05T10:18:56.229032-08:00",
  "lastActivity": "2017-12-05T10:20:55.1301125-08:00",
  "pageViews": [
    {
      "id": "1205568630ea137abca1abefc9e3d03b7f379be2",
      "startTime": "2017-12-05T10:18:56.728663-08:00",
      "endTime": "2017-12-05T10:20:55.1301125-08:00",
      "title": "FOX2YP",
      "uri": "http://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 118896,
      "engagementTime": 103038,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 118896,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=10XMB",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d0a6aa95542e8bedef3f4775b8329035",
  "gdpr": false
}