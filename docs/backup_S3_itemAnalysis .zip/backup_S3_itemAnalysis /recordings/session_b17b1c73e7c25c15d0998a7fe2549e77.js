var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ee7f43c31a38933445cb0d5d5313d703",
  "created": "2017-11-30T10:12:56.7767354-08:00",
  "lastActivity": "2017-11-30T10:13:11.7847354-08:00",
  "pageViews": [
    {
      "id": "1130569970fa37c32096df333817f9674e1dc546",
      "startTime": "2017-11-30T10:12:56.7767354-08:00",
      "endTime": "2017-11-30T10:13:11.7847354-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 15008,
      "engagementTime": 15008,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 15008,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=OQB9V",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b17b1c73e7c25c15d0998a7fe2549e77",
  "gdpr": false
}