var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "aaede7af842c3e09c28768df13c61e4c",
  "created": "2017-11-29T17:14:31.3910718-08:00",
  "lastActivity": "2017-11-29T17:15:24.5720718-08:00",
  "pageViews": [
    {
      "id": "11293186e7dd6c8b56547c502a40ace6961a1b64",
      "startTime": "2017-11-29T17:14:31.3910718-08:00",
      "endTime": "2017-11-29T17:15:24.5720718-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 53181,
      "engagementTime": 53181,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 53181,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DOS1L",
    "CONDITION=321",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b98d5c24acd06993f468bc25e5c47429",
  "gdpr": false
}