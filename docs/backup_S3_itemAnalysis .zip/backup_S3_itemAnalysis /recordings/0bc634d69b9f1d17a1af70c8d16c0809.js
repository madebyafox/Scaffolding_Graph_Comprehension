var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["113051073619be0eb5d8ead6e41fb2cf85e4bee7"] = {
  "startTime": "2017-11-30T18:15:51.2058665Z",
  "websitePageUrl": "/15",
  "visitTime": 71380,
  "engagementTime": 59630,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "59defaad047116f0f20f1f0ed161353a",
    "created": "2017-11-30T18:15:51.1043631+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "duration": 0,
    "pages": 1,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "62.0.3202.94",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/15",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=ACPUO",
      "CONDITION=311",
      "TRI_CORRECT=1"
    ],
    "watched": false,
    "starred": false,
    "gdpr": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "0bc634d69b9f1d17a1af70c8d16c0809",
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/59defaad047116f0f20f1f0ed161353a/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 296,
      "e": 296,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 801,
      "y": 811
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 794,
      "y": 621
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 5836,
      "y": 30104,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 771,
      "y": 511
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 646,
      "y": 416
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 592,
      "y": 393
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 55382,
      "y": 21327,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 588,
      "y": 391
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 54937,
      "y": 21217,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4752,
      "e": 4752,
      "ty": 41,
      "x": 54826,
      "y": 21217,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4802,
      "e": 4802,
      "ty": 2,
      "x": 612,
      "y": 496
    },
    {
      "t": 4902,
      "e": 4902,
      "ty": 2,
      "x": 644,
      "y": 608
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 41,
      "x": 9005,
      "y": 52786,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5002,
      "e": 5002,
      "ty": 2,
      "x": 917,
      "y": 875
    },
    {
      "t": 5102,
      "e": 5102,
      "ty": 2,
      "x": 1032,
      "y": 876
    },
    {
      "t": 5202,
      "e": 5202,
      "ty": 2,
      "x": 1106,
      "y": 872
    },
    {
      "t": 5252,
      "e": 5252,
      "ty": 41,
      "x": 43480,
      "y": 43171,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > line:[18]"
    },
    {
      "t": 5302,
      "e": 5302,
      "ty": 2,
      "x": 1232,
      "y": 886
    },
    {
      "t": 5402,
      "e": 5402,
      "ty": 2,
      "x": 1272,
      "y": 889
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 41,
      "x": 34444,
      "y": 54576,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5502,
      "e": 5502,
      "ty": 2,
      "x": 1278,
      "y": 900
    },
    {
      "t": 5602,
      "e": 5602,
      "ty": 2,
      "x": 1288,
      "y": 919
    },
    {
      "t": 5702,
      "e": 5702,
      "ty": 2,
      "x": 1290,
      "y": 847
    },
    {
      "t": 5752,
      "e": 5752,
      "ty": 41,
      "x": 44543,
      "y": 62463,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[18] > text"
    },
    {
      "t": 5802,
      "e": 5802,
      "ty": 2,
      "x": 1290,
      "y": 803
    },
    {
      "t": 5902,
      "e": 5902,
      "ty": 2,
      "x": 1290,
      "y": 798
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 51096,
      "y": 34376,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[18] > text"
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 2,
      "x": 1291,
      "y": 818
    },
    {
      "t": 6102,
      "e": 6102,
      "ty": 2,
      "x": 1291,
      "y": 829
    },
    {
      "t": 6252,
      "e": 6252,
      "ty": 41,
      "x": 42580,
      "y": 29126,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[18] > circle"
    },
    {
      "t": 8602,
      "e": 8602,
      "ty": 2,
      "x": 1280,
      "y": 830
    },
    {
      "t": 8702,
      "e": 8702,
      "ty": 2,
      "x": 746,
      "y": 726
    },
    {
      "t": 8752,
      "e": 8752,
      "ty": 41,
      "x": 96,
      "y": 41181,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 8802,
      "e": 8802,
      "ty": 2,
      "x": 588,
      "y": 706
    },
    {
      "t": 8902,
      "e": 8902,
      "ty": 2,
      "x": 478,
      "y": 700
    },
    {
      "t": 9002,
      "e": 9002,
      "ty": 41,
      "x": 16105,
      "y": 1095,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 9002,
      "e": 9002,
      "ty": 2,
      "x": 353,
      "y": 658
    },
    {
      "t": 9102,
      "e": 9102,
      "ty": 2,
      "x": 244,
      "y": 612
    },
    {
      "t": 9202,
      "e": 9202,
      "ty": 2,
      "x": 229,
      "y": 606
    },
    {
      "t": 9251,
      "e": 9251,
      "ty": 41,
      "x": 56140,
      "y": 34340,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 9302,
      "e": 9302,
      "ty": 2,
      "x": 227,
      "y": 605
    },
    {
      "t": 9402,
      "e": 9402,
      "ty": 2,
      "x": 210,
      "y": 598
    },
    {
      "t": 9502,
      "e": 9502,
      "ty": 41,
      "x": 29897,
      "y": 8594,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 9502,
      "e": 9502,
      "ty": 2,
      "x": 184,
      "y": 594
    },
    {
      "t": 9602,
      "e": 9602,
      "ty": 2,
      "x": 178,
      "y": 594
    },
    {
      "t": 9702,
      "e": 9702,
      "ty": 2,
      "x": 174,
      "y": 596
    },
    {
      "t": 9752,
      "e": 9752,
      "ty": 41,
      "x": 23932,
      "y": 15615,
      "ta": "#bigset.midpoint > ul > li:[11]"
    },
    {
      "t": 9802,
      "e": 9802,
      "ty": 2,
      "x": 175,
      "y": 601
    },
    {
      "t": 9902,
      "e": 9902,
      "ty": 2,
      "x": 180,
      "y": 602
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10003,
      "e": 10003,
      "ty": 41,
      "x": 17801,
      "y": 28592,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10003,
      "e": 10003,
      "ty": 3,
      "x": 181,
      "y": 602,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10004,
      "e": 10004,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10005,
      "e": 10005,
      "ty": 2,
      "x": 181,
      "y": 602
    },
    {
      "t": 10139,
      "e": 10139,
      "ty": 4,
      "x": 17801,
      "y": 28592,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10139,
      "e": 10139,
      "ty": 5,
      "x": 181,
      "y": 602,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10140,
      "e": 10140,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > input",
      "v": "X"
    },
    {
      "t": 10252,
      "e": 10252,
      "ty": 41,
      "x": 32925,
      "y": 28592,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 10302,
      "e": 10302,
      "ty": 2,
      "x": 189,
      "y": 600
    },
    {
      "t": 10402,
      "e": 10402,
      "ty": 2,
      "x": 195,
      "y": 597
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 41,
      "x": 4324,
      "y": 60085,
      "ta": "#bigset.midpoint > ul > li:[7]"
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 2,
      "x": 251,
      "y": 588
    },
    {
      "t": 10602,
      "e": 10602,
      "ty": 2,
      "x": 315,
      "y": 578
    },
    {
      "t": 10702,
      "e": 10702,
      "ty": 2,
      "x": 357,
      "y": 576
    },
    {
      "t": 10752,
      "e": 10752,
      "ty": 41,
      "x": 10363,
      "y": 31999,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 10802,
      "e": 10802,
      "ty": 2,
      "x": 402,
      "y": 576
    },
    {
      "t": 10902,
      "e": 10902,
      "ty": 2,
      "x": 497,
      "y": 581
    },
    {
      "t": 11002,
      "e": 11002,
      "ty": 41,
      "x": 372,
      "y": 57745,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 11002,
      "e": 11002,
      "ty": 2,
      "x": 574,
      "y": 587
    },
    {
      "t": 11102,
      "e": 11102,
      "ty": 2,
      "x": 609,
      "y": 587
    },
    {
      "t": 11202,
      "e": 11202,
      "ty": 2,
      "x": 613,
      "y": 587
    },
    {
      "t": 11252,
      "e": 11252,
      "ty": 41,
      "x": 24827,
      "y": 55404,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 11302,
      "e": 11302,
      "ty": 2,
      "x": 621,
      "y": 582
    },
    {
      "t": 11402,
      "e": 11402,
      "ty": 2,
      "x": 627,
      "y": 577
    },
    {
      "t": 11467,
      "e": 11467,
      "ty": 3,
      "x": 627,
      "y": 577,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 11469,
      "e": 11469,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[11] > input"
    },
    {
      "t": 11469,
      "e": 11469,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 11502,
      "e": 11502,
      "ty": 41,
      "x": 50569,
      "y": 43716,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 11586,
      "e": 11586,
      "ty": 4,
      "x": 50569,
      "y": 43716,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 11587,
      "e": 11587,
      "ty": 5,
      "x": 627,
      "y": 577,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 11587,
      "e": 11587,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[10] > input",
      "v": "K"
    },
    {
      "t": 11702,
      "e": 11702,
      "ty": 2,
      "x": 627,
      "y": 576
    },
    {
      "t": 11752,
      "e": 11752,
      "ty": 41,
      "x": 21845,
      "y": 48383,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 11802,
      "e": 11802,
      "ty": 2,
      "x": 541,
      "y": 626
    },
    {
      "t": 11902,
      "e": 11902,
      "ty": 2,
      "x": 455,
      "y": 684
    },
    {
      "t": 12002,
      "e": 12002,
      "ty": 41,
      "x": 52103,
      "y": 18642,
      "ta": "#start"
    },
    {
      "t": 12002,
      "e": 12002,
      "ty": 2,
      "x": 434,
      "y": 699
    },
    {
      "t": 12102,
      "e": 12102,
      "ty": 2,
      "x": 429,
      "y": 700
    },
    {
      "t": 12171,
      "e": 12171,
      "ty": 3,
      "x": 428,
      "y": 701,
      "ta": "#start"
    },
    {
      "t": 12172,
      "e": 12172,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[10] > input"
    },
    {
      "t": 12173,
      "e": 12173,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 12202,
      "e": 12202,
      "ty": 2,
      "x": 428,
      "y": 701
    },
    {
      "t": 12252,
      "e": 12252,
      "ty": 41,
      "x": 48826,
      "y": 22497,
      "ta": "#start"
    },
    {
      "t": 12274,
      "e": 12274,
      "ty": 4,
      "x": 48826,
      "y": 22497,
      "ta": "#start"
    },
    {
      "t": 12278,
      "e": 12278,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 12280,
      "e": 12280,
      "ty": 5,
      "x": 428,
      "y": 701,
      "ta": "#start"
    },
    {
      "t": 12285,
      "e": 12285,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 12602,
      "e": 12602,
      "ty": 2,
      "x": 445,
      "y": 701
    },
    {
      "t": 12702,
      "e": 12702,
      "ty": 2,
      "x": 591,
      "y": 728
    },
    {
      "t": 12752,
      "e": 12752,
      "ty": 41,
      "x": 26034,
      "y": 42545,
      "ta": "html > body"
    },
    {
      "t": 12802,
      "e": 12802,
      "ty": 2,
      "x": 790,
      "y": 784
    },
    {
      "t": 13002,
      "e": 13002,
      "ty": 41,
      "x": 26930,
      "y": 42988,
      "ta": "html > body"
    },
    {
      "t": 13288,
      "e": 13288,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 14102,
      "e": 14102,
      "ty": 2,
      "x": 854,
      "y": 685
    },
    {
      "t": 14202,
      "e": 14202,
      "ty": 2,
      "x": 904,
      "y": 592
    },
    {
      "t": 14252,
      "e": 14252,
      "ty": 41,
      "x": 22710,
      "y": 59293,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14302,
      "e": 14302,
      "ty": 2,
      "x": 914,
      "y": 569
    },
    {
      "t": 14402,
      "e": 14402,
      "ty": 2,
      "x": 915,
      "y": 568
    },
    {
      "t": 14501,
      "e": 14501,
      "ty": 41,
      "x": 23142,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14501,
      "e": 14501,
      "ty": 2,
      "x": 915,
      "y": 567
    },
    {
      "t": 14571,
      "e": 14571,
      "ty": 3,
      "x": 915,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14572,
      "e": 14572,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14690,
      "e": 14690,
      "ty": 4,
      "x": 23142,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14691,
      "e": 14691,
      "ty": 5,
      "x": 915,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 16679,
      "e": 16679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 16680,
      "e": 16680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 16766,
      "e": 16766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 16854,
      "e": 16854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 16855,
      "e": 16855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 16935,
      "e": 16935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 18001,
      "e": 18001,
      "ty": 41,
      "x": 18816,
      "y": 21064,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 18001,
      "e": 18001,
      "ty": 2,
      "x": 895,
      "y": 610
    },
    {
      "t": 18101,
      "e": 18101,
      "ty": 2,
      "x": 880,
      "y": 649
    },
    {
      "t": 18201,
      "e": 18201,
      "ty": 2,
      "x": 876,
      "y": 659
    },
    {
      "t": 18251,
      "e": 18251,
      "ty": 41,
      "x": 14707,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 18291,
      "e": 18291,
      "ty": 3,
      "x": 876,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 18292,
      "e": 18292,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 18293,
      "e": 18293,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 18294,
      "e": 18294,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 18402,
      "e": 18402,
      "ty": 4,
      "x": 14707,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 18402,
      "e": 18402,
      "ty": 5,
      "x": 876,
      "y": 659,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 20002,
      "e": 20002,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20328,
      "e": 20328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 20480,
      "e": 20480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 20480,
      "e": 20480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 20559,
      "e": 20559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 20856,
      "e": 20856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 20856,
      "e": 20856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 20943,
      "e": 20943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 21120,
      "e": 21120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 21120,
      "e": 21120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 21183,
      "e": 21183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 21455,
      "e": 21455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 22702,
      "e": 22702,
      "ty": 2,
      "x": 880,
      "y": 665
    },
    {
      "t": 22752,
      "e": 22752,
      "ty": 41,
      "x": 17302,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 22802,
      "e": 22802,
      "ty": 2,
      "x": 896,
      "y": 675
    },
    {
      "t": 22902,
      "e": 22902,
      "ty": 2,
      "x": 918,
      "y": 685
    },
    {
      "t": 23002,
      "e": 23002,
      "ty": 41,
      "x": 11894,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 23002,
      "e": 23002,
      "ty": 2,
      "x": 919,
      "y": 685
    },
    {
      "t": 23044,
      "e": 23044,
      "ty": 3,
      "x": 919,
      "y": 685,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 23045,
      "e": 23045,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 23045,
      "e": 23045,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 23046,
      "e": 23046,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 23163,
      "e": 23163,
      "ty": 4,
      "x": 11894,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 23164,
      "e": 23164,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 23164,
      "e": 23164,
      "ty": 5,
      "x": 919,
      "y": 685,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 23164,
      "e": 23164,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 23602,
      "e": 23602,
      "ty": 2,
      "x": 939,
      "y": 693
    },
    {
      "t": 23702,
      "e": 23702,
      "ty": 2,
      "x": 941,
      "y": 751
    },
    {
      "t": 23752,
      "e": 23752,
      "ty": 41,
      "x": 32199,
      "y": 41769,
      "ta": "html > body"
    },
    {
      "t": 23802,
      "e": 23802,
      "ty": 2,
      "x": 943,
      "y": 763
    },
    {
      "t": 23902,
      "e": 23902,
      "ty": 2,
      "x": 944,
      "y": 766
    },
    {
      "t": 24002,
      "e": 24002,
      "ty": 41,
      "x": 32543,
      "y": 45038,
      "ta": "html > body"
    },
    {
      "t": 24002,
      "e": 24002,
      "ty": 2,
      "x": 953,
      "y": 821
    },
    {
      "t": 24102,
      "e": 24102,
      "ty": 2,
      "x": 953,
      "y": 835
    },
    {
      "t": 24179,
      "e": 24179,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 24252,
      "e": 24252,
      "ty": 41,
      "x": 31226,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 24802,
      "e": 24802,
      "ty": 2,
      "x": 960,
      "y": 778
    },
    {
      "t": 24902,
      "e": 24902,
      "ty": 2,
      "x": 953,
      "y": 308
    },
    {
      "t": 25002,
      "e": 25002,
      "ty": 41,
      "x": 31476,
      "y": 2215,
      "ta": "html > body"
    },
    {
      "t": 25002,
      "e": 25002,
      "ty": 2,
      "x": 922,
      "y": 48
    },
    {
      "t": 25102,
      "e": 25102,
      "ty": 2,
      "x": 916,
      "y": 0
    },
    {
      "t": 25252,
      "e": 25252,
      "ty": 41,
      "x": 31544,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 25502,
      "e": 25502,
      "ty": 41,
      "x": 31028,
      "y": 166,
      "ta": "html > body"
    },
    {
      "t": 25502,
      "e": 25502,
      "ty": 2,
      "x": 909,
      "y": 11
    },
    {
      "t": 25602,
      "e": 25602,
      "ty": 2,
      "x": 901,
      "y": 122
    },
    {
      "t": 25702,
      "e": 25702,
      "ty": 2,
      "x": 899,
      "y": 149
    },
    {
      "t": 25752,
      "e": 25752,
      "ty": 41,
      "x": 30684,
      "y": 7866,
      "ta": "html > body"
    },
    {
      "t": 25802,
      "e": 25802,
      "ty": 2,
      "x": 895,
      "y": 157
    },
    {
      "t": 25904,
      "e": 25904,
      "ty": 2,
      "x": 872,
      "y": 198
    },
    {
      "t": 26004,
      "e": 26004,
      "ty": 41,
      "x": 6544,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 26004,
      "e": 26004,
      "ty": 2,
      "x": 849,
      "y": 226
    },
    {
      "t": 26104,
      "e": 26104,
      "ty": 2,
      "x": 844,
      "y": 231
    },
    {
      "t": 26204,
      "e": 26204,
      "ty": 2,
      "x": 839,
      "y": 238
    },
    {
      "t": 26254,
      "e": 26254,
      "ty": 41,
      "x": 63408,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 26304,
      "e": 26304,
      "ty": 2,
      "x": 838,
      "y": 239
    },
    {
      "t": 26404,
      "e": 26404,
      "ty": 2,
      "x": 837,
      "y": 239
    },
    {
      "t": 26504,
      "e": 26504,
      "ty": 41,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 26504,
      "e": 26504,
      "ty": 2,
      "x": 836,
      "y": 239
    },
    {
      "t": 26604,
      "e": 26604,
      "ty": 2,
      "x": 834,
      "y": 239
    },
    {
      "t": 26704,
      "e": 26704,
      "ty": 2,
      "x": 830,
      "y": 239
    },
    {
      "t": 26754,
      "e": 26754,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 26904,
      "e": 26904,
      "ty": 2,
      "x": 830,
      "y": 238
    },
    {
      "t": 27004,
      "e": 27004,
      "ty": 41,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 27104,
      "e": 27104,
      "ty": 2,
      "x": 831,
      "y": 253
    },
    {
      "t": 27204,
      "e": 27204,
      "ty": 2,
      "x": 831,
      "y": 256
    },
    {
      "t": 27254,
      "e": 27254,
      "ty": 41,
      "x": 7294,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 27304,
      "e": 27304,
      "ty": 2,
      "x": 831,
      "y": 259
    },
    {
      "t": 27404,
      "e": 27404,
      "ty": 2,
      "x": 830,
      "y": 260
    },
    {
      "t": 27504,
      "e": 27504,
      "ty": 41,
      "x": 18037,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 27504,
      "e": 27504,
      "ty": 2,
      "x": 830,
      "y": 261
    },
    {
      "t": 27604,
      "e": 27604,
      "ty": 2,
      "x": 830,
      "y": 262
    },
    {
      "t": 27704,
      "e": 27704,
      "ty": 2,
      "x": 829,
      "y": 264
    },
    {
      "t": 27754,
      "e": 27754,
      "ty": 41,
      "x": 12996,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 28582,
      "e": 28582,
      "ty": 3,
      "x": 829,
      "y": 264,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 28583,
      "e": 28583,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 28757,
      "e": 28757,
      "ty": 4,
      "x": 12996,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 28757,
      "e": 28757,
      "ty": 5,
      "x": 829,
      "y": 264,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 28758,
      "e": 28758,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 29104,
      "e": 29104,
      "ty": 2,
      "x": 842,
      "y": 260
    },
    {
      "t": 29204,
      "e": 29204,
      "ty": 2,
      "x": 853,
      "y": 262
    },
    {
      "t": 29254,
      "e": 29254,
      "ty": 41,
      "x": 26335,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 29304,
      "e": 29304,
      "ty": 2,
      "x": 859,
      "y": 276
    },
    {
      "t": 29404,
      "e": 29404,
      "ty": 2,
      "x": 862,
      "y": 284
    },
    {
      "t": 29504,
      "e": 29504,
      "ty": 41,
      "x": 13030,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 29504,
      "e": 29504,
      "ty": 2,
      "x": 863,
      "y": 288
    },
    {
      "t": 29604,
      "e": 29604,
      "ty": 2,
      "x": 866,
      "y": 300
    },
    {
      "t": 29704,
      "e": 29704,
      "ty": 2,
      "x": 873,
      "y": 321
    },
    {
      "t": 29755,
      "e": 29705,
      "ty": 41,
      "x": 53188,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 29804,
      "e": 29754,
      "ty": 2,
      "x": 875,
      "y": 338
    },
    {
      "t": 29904,
      "e": 29854,
      "ty": 2,
      "x": 875,
      "y": 358
    },
    {
      "t": 30004,
      "e": 29954,
      "ty": 41,
      "x": 12478,
      "y": 7582,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 30004,
      "e": 29954,
      "ty": 2,
      "x": 874,
      "y": 383
    },
    {
      "t": 30104,
      "e": 30054,
      "ty": 2,
      "x": 869,
      "y": 408
    },
    {
      "t": 30204,
      "e": 30154,
      "ty": 2,
      "x": 861,
      "y": 425
    },
    {
      "t": 30254,
      "e": 30204,
      "ty": 41,
      "x": 8443,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 30304,
      "e": 30254,
      "ty": 2,
      "x": 854,
      "y": 433
    },
    {
      "t": 30404,
      "e": 30354,
      "ty": 2,
      "x": 851,
      "y": 437
    },
    {
      "t": 30504,
      "e": 30454,
      "ty": 41,
      "x": 22028,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 30504,
      "e": 30454,
      "ty": 2,
      "x": 849,
      "y": 437
    },
    {
      "t": 30604,
      "e": 30554,
      "ty": 2,
      "x": 845,
      "y": 437
    },
    {
      "t": 30704,
      "e": 30654,
      "ty": 2,
      "x": 838,
      "y": 437
    },
    {
      "t": 30754,
      "e": 30704,
      "ty": 41,
      "x": 11644,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 30804,
      "e": 30754,
      "ty": 2,
      "x": 834,
      "y": 428
    },
    {
      "t": 30904,
      "e": 30854,
      "ty": 2,
      "x": 832,
      "y": 425
    },
    {
      "t": 31004,
      "e": 30954,
      "ty": 41,
      "x": 12382,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 31005,
      "e": 30955,
      "ty": 2,
      "x": 832,
      "y": 421
    },
    {
      "t": 31104,
      "e": 31054,
      "ty": 2,
      "x": 831,
      "y": 416
    },
    {
      "t": 31204,
      "e": 31154,
      "ty": 2,
      "x": 830,
      "y": 414
    },
    {
      "t": 31254,
      "e": 31204,
      "ty": 41,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 31404,
      "e": 31354,
      "ty": 2,
      "x": 830,
      "y": 413
    },
    {
      "t": 31504,
      "e": 31454,
      "ty": 41,
      "x": 12996,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 31504,
      "e": 31454,
      "ty": 2,
      "x": 829,
      "y": 410
    },
    {
      "t": 32974,
      "e": 32924,
      "ty": 3,
      "x": 829,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 32975,
      "e": 32925,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 32976,
      "e": 32926,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 33116,
      "e": 33066,
      "ty": 4,
      "x": 12996,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 33117,
      "e": 33067,
      "ty": 5,
      "x": 829,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 33117,
      "e": 33067,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 33404,
      "e": 33354,
      "ty": 2,
      "x": 848,
      "y": 425
    },
    {
      "t": 33504,
      "e": 33454,
      "ty": 41,
      "x": 21971,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 33504,
      "e": 33454,
      "ty": 2,
      "x": 914,
      "y": 509
    },
    {
      "t": 33604,
      "e": 33554,
      "ty": 2,
      "x": 973,
      "y": 556
    },
    {
      "t": 33704,
      "e": 33654,
      "ty": 2,
      "x": 981,
      "y": 561
    },
    {
      "t": 33754,
      "e": 33704,
      "ty": 41,
      "x": 40245,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 33804,
      "e": 33754,
      "ty": 2,
      "x": 1006,
      "y": 582
    },
    {
      "t": 33904,
      "e": 33854,
      "ty": 2,
      "x": 1038,
      "y": 600
    },
    {
      "t": 34004,
      "e": 33954,
      "ty": 41,
      "x": 37571,
      "y": 33681,
      "ta": "html > body"
    },
    {
      "t": 34004,
      "e": 33954,
      "ty": 2,
      "x": 1099,
      "y": 616
    },
    {
      "t": 34104,
      "e": 34054,
      "ty": 2,
      "x": 1112,
      "y": 619
    },
    {
      "t": 34254,
      "e": 34204,
      "ty": 41,
      "x": 38019,
      "y": 33847,
      "ta": "html > body"
    },
    {
      "t": 34754,
      "e": 34704,
      "ty": 41,
      "x": 38053,
      "y": 34124,
      "ta": "html > body"
    },
    {
      "t": 34804,
      "e": 34754,
      "ty": 2,
      "x": 1050,
      "y": 693
    },
    {
      "t": 34904,
      "e": 34854,
      "ty": 2,
      "x": 964,
      "y": 734
    },
    {
      "t": 35004,
      "e": 34954,
      "ty": 41,
      "x": 27309,
      "y": 40329,
      "ta": "html > body"
    },
    {
      "t": 35004,
      "e": 34954,
      "ty": 2,
      "x": 801,
      "y": 736
    },
    {
      "t": 35104,
      "e": 35054,
      "ty": 2,
      "x": 790,
      "y": 730
    },
    {
      "t": 35204,
      "e": 35154,
      "ty": 2,
      "x": 788,
      "y": 727
    },
    {
      "t": 35254,
      "e": 35204,
      "ty": 41,
      "x": 27102,
      "y": 39553,
      "ta": "html > body"
    },
    {
      "t": 35304,
      "e": 35254,
      "ty": 2,
      "x": 808,
      "y": 717
    },
    {
      "t": 35404,
      "e": 35354,
      "ty": 2,
      "x": 821,
      "y": 719
    },
    {
      "t": 35504,
      "e": 35454,
      "ty": 41,
      "x": 43243,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 35504,
      "e": 35454,
      "ty": 2,
      "x": 835,
      "y": 729
    },
    {
      "t": 35604,
      "e": 35554,
      "ty": 2,
      "x": 838,
      "y": 730
    },
    {
      "t": 35754,
      "e": 35704,
      "ty": 41,
      "x": 58367,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 36004,
      "e": 35954,
      "ty": 41,
      "x": 48284,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 36004,
      "e": 35954,
      "ty": 2,
      "x": 836,
      "y": 725
    },
    {
      "t": 36104,
      "e": 36054,
      "ty": 2,
      "x": 835,
      "y": 723
    },
    {
      "t": 36255,
      "e": 36055,
      "ty": 41,
      "x": 3407,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 36990,
      "e": 36790,
      "ty": 3,
      "x": 835,
      "y": 723,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 36991,
      "e": 36791,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 37105,
      "e": 36905,
      "ty": 2,
      "x": 835,
      "y": 721
    },
    {
      "t": 37157,
      "e": 36957,
      "ty": 4,
      "x": 3222,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 37205,
      "e": 37005,
      "ty": 2,
      "x": 835,
      "y": 720
    },
    {
      "t": 37254,
      "e": 37054,
      "ty": 41,
      "x": 3222,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 37754,
      "e": 37554,
      "ty": 41,
      "x": 3156,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 37805,
      "e": 37605,
      "ty": 2,
      "x": 831,
      "y": 727
    },
    {
      "t": 37904,
      "e": 37704,
      "ty": 2,
      "x": 830,
      "y": 727
    },
    {
      "t": 37950,
      "e": 37750,
      "ty": 3,
      "x": 830,
      "y": 727,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 37950,
      "e": 37750,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 38004,
      "e": 37804,
      "ty": 41,
      "x": 18037,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 38045,
      "e": 37845,
      "ty": 4,
      "x": 18037,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 38046,
      "e": 37846,
      "ty": 5,
      "x": 830,
      "y": 727,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 38047,
      "e": 37847,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 38304,
      "e": 38104,
      "ty": 2,
      "x": 832,
      "y": 728
    },
    {
      "t": 38404,
      "e": 38204,
      "ty": 2,
      "x": 844,
      "y": 728
    },
    {
      "t": 38504,
      "e": 38304,
      "ty": 41,
      "x": 27251,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 38504,
      "e": 38304,
      "ty": 2,
      "x": 930,
      "y": 740
    },
    {
      "t": 38604,
      "e": 38404,
      "ty": 2,
      "x": 1050,
      "y": 755
    },
    {
      "t": 38704,
      "e": 38504,
      "ty": 2,
      "x": 1211,
      "y": 799
    },
    {
      "t": 38754,
      "e": 38554,
      "ty": 41,
      "x": 44355,
      "y": 45481,
      "ta": "html > body"
    },
    {
      "t": 38804,
      "e": 38604,
      "ty": 2,
      "x": 1329,
      "y": 838
    },
    {
      "t": 39004,
      "e": 38804,
      "ty": 41,
      "x": 45492,
      "y": 45979,
      "ta": "html > body"
    },
    {
      "t": 39704,
      "e": 39504,
      "ty": 2,
      "x": 1322,
      "y": 840
    },
    {
      "t": 39754,
      "e": 39554,
      "ty": 41,
      "x": 43976,
      "y": 47530,
      "ta": "html > body"
    },
    {
      "t": 39804,
      "e": 39604,
      "ty": 2,
      "x": 1201,
      "y": 892
    },
    {
      "t": 39904,
      "e": 39704,
      "ty": 2,
      "x": 1016,
      "y": 951
    },
    {
      "t": 40004,
      "e": 39804,
      "ty": 41,
      "x": 1798,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 40004,
      "e": 39804,
      "ty": 2,
      "x": 829,
      "y": 976
    },
    {
      "t": 40104,
      "e": 39904,
      "ty": 2,
      "x": 804,
      "y": 967
    },
    {
      "t": 40204,
      "e": 40004,
      "ty": 2,
      "x": 804,
      "y": 939
    },
    {
      "t": 40254,
      "e": 40054,
      "ty": 41,
      "x": 27550,
      "y": 51353,
      "ta": "html > body"
    },
    {
      "t": 40304,
      "e": 40104,
      "ty": 2,
      "x": 813,
      "y": 932
    },
    {
      "t": 40404,
      "e": 40204,
      "ty": 2,
      "x": 816,
      "y": 931
    },
    {
      "t": 40504,
      "e": 40304,
      "ty": 41,
      "x": 27963,
      "y": 51131,
      "ta": "html > body"
    },
    {
      "t": 40504,
      "e": 40304,
      "ty": 2,
      "x": 820,
      "y": 931
    },
    {
      "t": 40604,
      "e": 40404,
      "ty": 2,
      "x": 828,
      "y": 932
    },
    {
      "t": 40704,
      "e": 40504,
      "ty": 2,
      "x": 832,
      "y": 933
    },
    {
      "t": 40754,
      "e": 40554,
      "ty": 41,
      "x": 28120,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 40804,
      "e": 40604,
      "ty": 2,
      "x": 832,
      "y": 935
    },
    {
      "t": 40904,
      "e": 40704,
      "ty": 2,
      "x": 832,
      "y": 938
    },
    {
      "t": 41004,
      "e": 40804,
      "ty": 41,
      "x": 28120,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 41110,
      "e": 40910,
      "ty": 3,
      "x": 832,
      "y": 938,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 41111,
      "e": 40911,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 41112,
      "e": 40912,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 41213,
      "e": 41013,
      "ty": 4,
      "x": 28120,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 41213,
      "e": 41013,
      "ty": 5,
      "x": 832,
      "y": 938,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 41213,
      "e": 41013,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 41504,
      "e": 41304,
      "ty": 41,
      "x": 11528,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 41504,
      "e": 41304,
      "ty": 2,
      "x": 870,
      "y": 976
    },
    {
      "t": 41604,
      "e": 41404,
      "ty": 2,
      "x": 918,
      "y": 1026
    },
    {
      "t": 41704,
      "e": 41504,
      "ty": 2,
      "x": 922,
      "y": 1035
    },
    {
      "t": 41754,
      "e": 41554,
      "ty": 41,
      "x": 31544,
      "y": 57225,
      "ta": "html > body"
    },
    {
      "t": 41804,
      "e": 41604,
      "ty": 2,
      "x": 928,
      "y": 1054
    },
    {
      "t": 41904,
      "e": 41704,
      "ty": 2,
      "x": 929,
      "y": 1056
    },
    {
      "t": 42004,
      "e": 41804,
      "ty": 41,
      "x": 31751,
      "y": 58056,
      "ta": "html > body"
    },
    {
      "t": 42004,
      "e": 41804,
      "ty": 2,
      "x": 930,
      "y": 1056
    },
    {
      "t": 42104,
      "e": 41904,
      "ty": 2,
      "x": 931,
      "y": 1040
    },
    {
      "t": 42204,
      "e": 42004,
      "ty": 2,
      "x": 931,
      "y": 1031
    },
    {
      "t": 42254,
      "e": 42054,
      "ty": 41,
      "x": 52352,
      "y": 49647,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 42304,
      "e": 42104,
      "ty": 2,
      "x": 931,
      "y": 1028
    },
    {
      "t": 42504,
      "e": 42304,
      "ty": 41,
      "x": 52352,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 42804,
      "e": 42604,
      "ty": 2,
      "x": 942,
      "y": 1019
    },
    {
      "t": 42904,
      "e": 42704,
      "ty": 2,
      "x": 1081,
      "y": 876
    },
    {
      "t": 43004,
      "e": 42804,
      "ty": 41,
      "x": 38949,
      "y": 40827,
      "ta": "html > body"
    },
    {
      "t": 43004,
      "e": 42804,
      "ty": 2,
      "x": 1139,
      "y": 745
    },
    {
      "t": 43104,
      "e": 42904,
      "ty": 2,
      "x": 1160,
      "y": 629
    },
    {
      "t": 43204,
      "e": 43004,
      "ty": 2,
      "x": 1160,
      "y": 601
    },
    {
      "t": 43254,
      "e": 43054,
      "ty": 41,
      "x": 38776,
      "y": 38002,
      "ta": "html > body"
    },
    {
      "t": 43304,
      "e": 43104,
      "ty": 2,
      "x": 1114,
      "y": 808
    },
    {
      "t": 43404,
      "e": 43204,
      "ty": 2,
      "x": 1077,
      "y": 897
    },
    {
      "t": 43504,
      "e": 43304,
      "ty": 41,
      "x": 48788,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 43504,
      "e": 43304,
      "ty": 2,
      "x": 1027,
      "y": 952
    },
    {
      "t": 43604,
      "e": 43404,
      "ty": 2,
      "x": 1012,
      "y": 975
    },
    {
      "t": 43704,
      "e": 43504,
      "ty": 2,
      "x": 1010,
      "y": 985
    },
    {
      "t": 43754,
      "e": 43554,
      "ty": 41,
      "x": 44042,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 43804,
      "e": 43604,
      "ty": 2,
      "x": 1007,
      "y": 1005
    },
    {
      "t": 43904,
      "e": 43704,
      "ty": 2,
      "x": 1007,
      "y": 1006
    },
    {
      "t": 44004,
      "e": 43804,
      "ty": 41,
      "x": 44042,
      "y": 63143,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 44704,
      "e": 44504,
      "ty": 2,
      "x": 991,
      "y": 1010
    },
    {
      "t": 44754,
      "e": 44554,
      "ty": 41,
      "x": 37159,
      "y": 63442,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 44804,
      "e": 44604,
      "ty": 2,
      "x": 974,
      "y": 1010
    },
    {
      "t": 44904,
      "e": 44704,
      "ty": 2,
      "x": 972,
      "y": 1009
    },
    {
      "t": 45004,
      "e": 44804,
      "ty": 41,
      "x": 35498,
      "y": 63367,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 45004,
      "e": 44804,
      "ty": 2,
      "x": 971,
      "y": 1009
    },
    {
      "t": 45404,
      "e": 45204,
      "ty": 2,
      "x": 963,
      "y": 1010
    },
    {
      "t": 45504,
      "e": 45304,
      "ty": 41,
      "x": 49259,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 45504,
      "e": 45304,
      "ty": 2,
      "x": 925,
      "y": 1022
    },
    {
      "t": 45604,
      "e": 45404,
      "ty": 2,
      "x": 913,
      "y": 1026
    },
    {
      "t": 45735,
      "e": 45535,
      "ty": 3,
      "x": 913,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 45736,
      "e": 45536,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 45736,
      "e": 45536,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 45754,
      "e": 45554,
      "ty": 41,
      "x": 43075,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 45885,
      "e": 45685,
      "ty": 4,
      "x": 43075,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 45885,
      "e": 45685,
      "ty": 5,
      "x": 913,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 45888,
      "e": 45688,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 45889,
      "e": 45689,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 45890,
      "e": 45690,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 46204,
      "e": 46004,
      "ty": 2,
      "x": 918,
      "y": 1025
    },
    {
      "t": 46256,
      "e": 46006,
      "ty": 41,
      "x": 32750,
      "y": 55508,
      "ta": "html > body"
    },
    {
      "t": 46304,
      "e": 46054,
      "ty": 2,
      "x": 1077,
      "y": 962
    },
    {
      "t": 46404,
      "e": 46154,
      "ty": 2,
      "x": 1210,
      "y": 895
    },
    {
      "t": 46504,
      "e": 46254,
      "ty": 41,
      "x": 42771,
      "y": 46312,
      "ta": "html > body"
    },
    {
      "t": 46504,
      "e": 46254,
      "ty": 2,
      "x": 1250,
      "y": 844
    },
    {
      "t": 46604,
      "e": 46354,
      "ty": 2,
      "x": 1265,
      "y": 816
    },
    {
      "t": 46704,
      "e": 46454,
      "ty": 2,
      "x": 1267,
      "y": 810
    },
    {
      "t": 46754,
      "e": 46504,
      "ty": 41,
      "x": 43357,
      "y": 44428,
      "ta": "html > body"
    },
    {
      "t": 46986,
      "e": 46736,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 47704,
      "e": 47454,
      "ty": 2,
      "x": 1265,
      "y": 785
    },
    {
      "t": 47754,
      "e": 47504,
      "ty": 41,
      "x": 47157,
      "y": 41846,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 47804,
      "e": 47554,
      "ty": 2,
      "x": 1235,
      "y": 701
    },
    {
      "t": 47904,
      "e": 47654,
      "ty": 2,
      "x": 1188,
      "y": 587
    },
    {
      "t": 48004,
      "e": 47754,
      "ty": 41,
      "x": 42582,
      "y": 4492,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 48004,
      "e": 47754,
      "ty": 2,
      "x": 1159,
      "y": 494
    },
    {
      "t": 48104,
      "e": 47854,
      "ty": 2,
      "x": 1131,
      "y": 414
    },
    {
      "t": 48204,
      "e": 47954,
      "ty": 2,
      "x": 1112,
      "y": 371
    },
    {
      "t": 48254,
      "e": 48004,
      "ty": 41,
      "x": 39433,
      "y": 19931,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 48304,
      "e": 48054,
      "ty": 2,
      "x": 1089,
      "y": 331
    },
    {
      "t": 48404,
      "e": 48154,
      "ty": 2,
      "x": 1071,
      "y": 302
    },
    {
      "t": 48504,
      "e": 48254,
      "ty": 41,
      "x": 37859,
      "y": 11474,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48504,
      "e": 48254,
      "ty": 2,
      "x": 1063,
      "y": 292
    },
    {
      "t": 48604,
      "e": 48354,
      "ty": 2,
      "x": 1052,
      "y": 286
    },
    {
      "t": 48704,
      "e": 48454,
      "ty": 2,
      "x": 1033,
      "y": 281
    },
    {
      "t": 48754,
      "e": 48504,
      "ty": 41,
      "x": 36285,
      "y": 10574,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48804,
      "e": 48554,
      "ty": 2,
      "x": 1030,
      "y": 278
    },
    {
      "t": 49004,
      "e": 48754,
      "ty": 41,
      "x": 36235,
      "y": 10505,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60004,
      "e": 53754,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 65504,
      "e": 53754,
      "ty": 41,
      "x": 36137,
      "y": 12028,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 65504,
      "e": 53754,
      "ty": 2,
      "x": 1028,
      "y": 300
    },
    {
      "t": 65604,
      "e": 53854,
      "ty": 2,
      "x": 1031,
      "y": 338
    },
    {
      "t": 65704,
      "e": 53954,
      "ty": 2,
      "x": 1040,
      "y": 390
    },
    {
      "t": 65754,
      "e": 54004,
      "ty": 41,
      "x": 36875,
      "y": 36290,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 65804,
      "e": 54054,
      "ty": 2,
      "x": 1043,
      "y": 463
    },
    {
      "t": 65904,
      "e": 54154,
      "ty": 2,
      "x": 1033,
      "y": 536
    },
    {
      "t": 66004,
      "e": 54254,
      "ty": 41,
      "x": 35251,
      "y": 48182,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66004,
      "e": 54254,
      "ty": 2,
      "x": 1010,
      "y": 606
    },
    {
      "t": 66104,
      "e": 54354,
      "ty": 2,
      "x": 996,
      "y": 630
    },
    {
      "t": 66204,
      "e": 54454,
      "ty": 2,
      "x": 995,
      "y": 630
    },
    {
      "t": 66254,
      "e": 54504,
      "ty": 41,
      "x": 34513,
      "y": 57544,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66404,
      "e": 54654,
      "ty": 2,
      "x": 893,
      "y": 964
    },
    {
      "t": 66506,
      "e": 54756,
      "ty": 41,
      "x": 29102,
      "y": 63963,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 66507,
      "e": 54757,
      "ty": 2,
      "x": 885,
      "y": 1050
    },
    {
      "t": 66604,
      "e": 54854,
      "ty": 2,
      "x": 893,
      "y": 1070
    },
    {
      "t": 66704,
      "e": 54954,
      "ty": 2,
      "x": 904,
      "y": 1076
    },
    {
      "t": 66754,
      "e": 55004,
      "ty": 41,
      "x": 3549,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 66804,
      "e": 55054,
      "ty": 2,
      "x": 933,
      "y": 1079
    },
    {
      "t": 66904,
      "e": 55154,
      "ty": 2,
      "x": 950,
      "y": 1079
    },
    {
      "t": 67004,
      "e": 55254,
      "ty": 41,
      "x": 29763,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 67004,
      "e": 55254,
      "ty": 2,
      "x": 964,
      "y": 1078
    },
    {
      "t": 67104,
      "e": 55354,
      "ty": 2,
      "x": 965,
      "y": 1078
    },
    {
      "t": 67254,
      "e": 55504,
      "ty": 41,
      "x": 30309,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 67504,
      "e": 55754,
      "ty": 41,
      "x": 30856,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 67504,
      "e": 55754,
      "ty": 2,
      "x": 966,
      "y": 1078
    },
    {
      "t": 67904,
      "e": 56154,
      "ty": 2,
      "x": 970,
      "y": 1086
    },
    {
      "t": 68004,
      "e": 56254,
      "ty": 41,
      "x": 33040,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 68004,
      "e": 56254,
      "ty": 2,
      "x": 970,
      "y": 1087
    },
    {
      "t": 68966,
      "e": 57216,
      "ty": 3,
      "x": 970,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 68967,
      "e": 57217,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 69116,
      "e": 57366,
      "ty": 4,
      "x": 33040,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 69117,
      "e": 57367,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 69117,
      "e": 57367,
      "ty": 5,
      "x": 970,
      "y": 1087,
      "ta": "#start"
    },
    {
      "t": 69118,
      "e": 57368,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 70147,
      "e": 58397,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 71380,
      "e": 59630,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":54},{\"id\":55},{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"nodeType\":3,\"id\":1563,\"textContent\":\" $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"full\\\"; } else if (axis == 2){ axis = \\\"partial\\\"; } else if (axis ==3){ axis = \\\"diagonal\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":1560},{\"id\":1561},{\"nodeType\":3,\"id\":1564,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":1562}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1565,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":1565},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1567,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":1566},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1568,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":1567},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1569,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":1566}},{\"nodeType\":1,\"id\":1570,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":1569},\"parentNode\":{\"id\":1566}},{\"nodeType\":3,\"id\":1571,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":1569}},{\"nodeType\":1,\"id\":1572,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":1567}},{\"nodeType\":1,\"id\":1573,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":1572},\"parentNode\":{\"id\":1567}},{\"nodeType\":3,\"id\":1574,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":1572}},{\"nodeType\":3,\"id\":1575,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":1568}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":1565},{\"id\":1566},{\"id\":1569},{\"id\":1571},{\"id\":1570},{\"id\":1567},{\"id\":1572},{\"id\":1574},{\"id\":1573},{\"id\":1568},{\"id\":1575}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1576,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1577,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1578,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1577},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1579,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1578},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1580,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1579},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1581,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1580},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1582,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":1581},\"parentNode\":{\"id\":1576}},{\"nodeType\":1,\"id\":1583,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1578}},{\"nodeType\":1,\"id\":1584,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1583},\"parentNode\":{\"id\":1578}},{\"nodeType\":1,\"id\":1585,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1584},\"parentNode\":{\"id\":1578}},{\"nodeType\":1,\"id\":1586,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1585},\"parentNode\":{\"id\":1578}},{\"nodeType\":1,\"id\":1587,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1586},\"parentNode\":{\"id\":1578}},{\"nodeType\":3,\"id\":1588,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":1583}},{\"nodeType\":1,\"id\":1589,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1588},\"parentNode\":{\"id\":1583}},{\"nodeType\":1,\"id\":1590,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1584}},{\"nodeType\":1,\"id\":1591,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1590}},{\"nodeType\":3,\"id\":1592,\"textContent\":\"English\",\"previousSibling\":{\"id\":1591},\"parentNode\":{\"id\":1590}},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1585}},{\"nodeType\":1,\"id\":1594,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1593}},{\"nodeType\":3,\"id\":1595,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":1594},\"parentNode\":{\"id\":1593}},{\"nodeType\":1,\"id\":1596,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1586}},{\"nodeType\":1,\"id\":1597,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1596}},{\"nodeType\":3,\"id\":1598,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":1597},\"parentNode\":{\"id\":1596}},{\"nodeType\":1,\"id\":1599,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1587}},{\"nodeType\":1,\"id\":1600,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1599}},{\"nodeType\":3,\"id\":1601,\"textContent\":\"Other\",\"previousSibling\":{\"id\":1600},\"parentNode\":{\"id\":1599}},{\"nodeType\":3,\"id\":1602,\"textContent\":\"*\",\"parentNode\":{\"id\":1589}},{\"nodeType\":1,\"id\":1603,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1604,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1603},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1605,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1604},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1605},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1606},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1607},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1609,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1608},\"parentNode\":{\"id\":1579}},{\"nodeType\":1,\"id\":1610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1609},\"parentNode\":{\"id\":1579}},{\"nodeType\":3,\"id\":1611,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":1603}},{\"nodeType\":1,\"id\":1612,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1611},\"parentNode\":{\"id\":1603}},{\"nodeType\":1,\"id\":1613,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1604}},{\"nodeType\":1,\"id\":1614,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1613}},{\"nodeType\":3,\"id\":1615,\"textContent\":\"First\",\"previousSibling\":{\"id\":1614},\"parentNode\":{\"id\":1613}},{\"nodeType\":1,\"id\":1616,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1605}},{\"nodeType\":1,\"id\":1617,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1616}},{\"nodeType\":3,\"id\":1618,\"textContent\":\"Second\",\"previousSibling\":{\"id\":1617},\"parentNode\":{\"id\":1616}},{\"nodeType\":1,\"id\":1619,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1606}},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1619}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"Third\",\"previousSibling\":{\"id\":1620},\"parentNode\":{\"id\":1619}},{\"nodeType\":1,\"id\":1622,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1607}},{\"nodeType\":1,\"id\":1623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1622}},{\"nodeType\":3,\"id\":1624,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":1623},\"parentNode\":{\"id\":1622}},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1608}},{\"nodeType\":1,\"id\":1626,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1625}},{\"nodeType\":3,\"id\":1627,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":1626},\"parentNode\":{\"id\":1625}},{\"nodeType\":1,\"id\":1628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1609}},{\"nodeType\":1,\"id\":1629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1628}},{\"nodeType\":3,\"id\":1630,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":1629},\"parentNode\":{\"id\":1628}},{\"nodeType\":1,\"id\":1631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1610}},{\"nodeType\":1,\"id\":1632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1631}},{\"nodeType\":3,\"id\":1633,\"textContent\":\"Other\",\"previousSibling\":{\"id\":1632},\"parentNode\":{\"id\":1631}},{\"nodeType\":3,\"id\":1634,\"textContent\":\"*\",\"parentNode\":{\"id\":1612}},{\"nodeType\":1,\"id\":1635,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1636,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1635},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1636},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1637},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1638},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1639},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1640},\"parentNode\":{\"id\":1580}},{\"nodeType\":1,\"id\":1642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1641},\"parentNode\":{\"id\":1580}},{\"nodeType\":3,\"id\":1643,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":1635}},{\"nodeType\":1,\"id\":1644,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1643},\"parentNode\":{\"id\":1635}},{\"nodeType\":1,\"id\":1645,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1636}},{\"nodeType\":1,\"id\":1646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1645}},{\"nodeType\":3,\"id\":1647,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":1646},\"parentNode\":{\"id\":1645}},{\"nodeType\":1,\"id\":1648,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1637}},{\"nodeType\":1,\"id\":1649,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1648}},{\"nodeType\":3,\"id\":1650,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":1649},\"parentNode\":{\"id\":1648}},{\"nodeType\":1,\"id\":1651,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1638}},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1651}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":1652},\"parentNode\":{\"id\":1651}},{\"nodeType\":1,\"id\":1654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1639}},{\"nodeType\":1,\"id\":1655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1654}},{\"nodeType\":3,\"id\":1656,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":1655},\"parentNode\":{\"id\":1654}},{\"nodeType\":1,\"id\":1657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1640}},{\"nodeType\":1,\"id\":1658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1657}},{\"nodeType\":3,\"id\":1659,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":1658},\"parentNode\":{\"id\":1657}},{\"nodeType\":1,\"id\":1660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1641}},{\"nodeType\":1,\"id\":1661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1660}},{\"nodeType\":3,\"id\":1662,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":1661},\"parentNode\":{\"id\":1660}},{\"nodeType\":1,\"id\":1663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1642}},{\"nodeType\":1,\"id\":1664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1663}},{\"nodeType\":3,\"id\":1665,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":1664},\"parentNode\":{\"id\":1663}},{\"nodeType\":3,\"id\":1666,\"textContent\":\"*\",\"parentNode\":{\"id\":1644}},{\"nodeType\":1,\"id\":1667,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1581}},{\"nodeType\":1,\"id\":1668,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1667},\"parentNode\":{\"id\":1581}},{\"nodeType\":1,\"id\":1669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1668},\"parentNode\":{\"id\":1581}},{\"nodeType\":1,\"id\":1670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1669},\"parentNode\":{\"id\":1581}},{\"nodeType\":3,\"id\":1671,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":1667}},{\"nodeType\":1,\"id\":1672,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1671},\"parentNode\":{\"id\":1667}},{\"nodeType\":1,\"id\":1673,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1668}},{\"nodeType\":1,\"id\":1674,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1673}},{\"nodeType\":3,\"id\":1675,\"textContent\":\"Male\",\"previousSibling\":{\"id\":1674},\"parentNode\":{\"id\":1673}},{\"nodeType\":1,\"id\":1676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1669}},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1676}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"Female\",\"previousSibling\":{\"id\":1677},\"parentNode\":{\"id\":1676}},{\"nodeType\":1,\"id\":1679,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1670}},{\"nodeType\":1,\"id\":1680,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1679}},{\"nodeType\":3,\"id\":1681,\"textContent\":\"Other\",\"previousSibling\":{\"id\":1680},\"parentNode\":{\"id\":1679}},{\"nodeType\":3,\"id\":1682,\"textContent\":\"*\",\"parentNode\":{\"id\":1672}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1583},{\"id\":1588},{\"id\":1589},{\"id\":1602},{\"id\":1584},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1585},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1586},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1587},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1579},{\"id\":1603},{\"id\":1611},{\"id\":1612},{\"id\":1634},{\"id\":1604},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1605},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1606},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1607},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1608},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1609},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1610},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1580},{\"id\":1635},{\"id\":1643},{\"id\":1644},{\"id\":1666},{\"id\":1636},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1637},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1638},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1639},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1640},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1641},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1642},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1581},{\"id\":1667},{\"id\":1671},{\"id\":1672},{\"id\":1682},{\"id\":1668},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1669},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1670},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1582}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1683,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":53}},{\"nodeType\":3,\"id\":1684,\"textContent\":\" \",\"previousSibling\":{\"id\":1683},\"parentNode\":{\"id\":53}},{\"nodeType\":3,\"id\":1685,\"textContent\":\" \",\"parentNode\":{\"id\":1683}},{\"nodeType\":1,\"id\":1686,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":1685},\"parentNode\":{\"id\":1683}},{\"nodeType\":3,\"id\":1687,\"textContent\":\" \",\"previousSibling\":{\"id\":1686},\"parentNode\":{\"id\":1683}},{\"nodeType\":1,\"id\":1688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":1687},\"parentNode\":{\"id\":1683}},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \",\"previousSibling\":{\"id\":1688},\"parentNode\":{\"id\":1683}},{\"nodeType\":1,\"id\":1690,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":1689},\"parentNode\":{\"id\":1683}},{\"nodeType\":3,\"id\":1691,\"textContent\":\" \",\"previousSibling\":{\"id\":1690},\"parentNode\":{\"id\":1683}},{\"nodeType\":3,\"id\":1692,\"textContent\":\" \",\"parentNode\":{\"id\":1686}},{\"nodeType\":1,\"id\":1693,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":1692},\"parentNode\":{\"id\":1686}},{\"nodeType\":3,\"id\":1694,\"textContent\":\" \",\"previousSibling\":{\"id\":1693},\"parentNode\":{\"id\":1686}},{\"nodeType\":3,\"id\":1695,\"textContent\":\" \",\"parentNode\":{\"id\":1693}},{\"nodeType\":1,\"id\":1696,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":1695},\"parentNode\":{\"id\":1693}},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \",\"previousSibling\":{\"id\":1696},\"parentNode\":{\"id\":1693}},{\"nodeType\":3,\"id\":1698,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":1696}},{\"nodeType\":3,\"id\":1699,\"textContent\":\" \",\"parentNode\":{\"id\":1688}},{\"nodeType\":1,\"id\":1700,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":1699},\"parentNode\":{\"id\":1688}},{\"nodeType\":3,\"id\":1701,\"textContent\":\" \",\"previousSibling\":{\"id\":1700},\"parentNode\":{\"id\":1688}},{\"nodeType\":3,\"id\":1702,\"textContent\":\" \",\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1703,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":1702},\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1704,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":1703},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \",\"previousSibling\":{\"id\":1704},\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1706,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":1705},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1707,\"textContent\":\" \",\"previousSibling\":{\"id\":1706},\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1708,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":1707},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1709,\"textContent\":\" \",\"previousSibling\":{\"id\":1708},\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1710,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":1709},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1711,\"textContent\":\" \",\"previousSibling\":{\"id\":1710},\"parentNode\":{\"id\":1700}},{\"nodeType\":1,\"id\":1712,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":1711},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \",\"previousSibling\":{\"id\":1712},\"parentNode\":{\"id\":1700}},{\"nodeType\":3,\"id\":1714,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":1703}},{\"nodeType\":3,\"id\":1715,\"textContent\":\" \",\"parentNode\":{\"id\":1704}},{\"nodeType\":1,\"id\":1716,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":1715},\"parentNode\":{\"id\":1704}},{\"nodeType\":3,\"id\":1717,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":1716},\"parentNode\":{\"id\":1704}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":1716}},{\"nodeType\":3,\"id\":1719,\"textContent\":\" \",\"parentNode\":{\"id\":1706}},{\"nodeType\":1,\"id\":1720,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":1719},\"parentNode\":{\"id\":1706}},{\"nodeType\":3,\"id\":1721,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":1720},\"parentNode\":{\"id\":1706}},{\"nodeType\":3,\"id\":1722,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":1720}},{\"nodeType\":1,\"id\":1723,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":1708}},{\"nodeType\":3,\"id\":1724,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":1723},\"parentNode\":{\"id\":1708}},{\"nodeType\":3,\"id\":1725,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":1723}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":1710}},{\"nodeType\":3,\"id\":1727,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":1712}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \",\"parentNode\":{\"id\":1690}},{\"nodeType\":1,\"id\":1729,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":1728},\"parentNode\":{\"id\":1690}},{\"nodeType\":3,\"id\":1730,\"textContent\":\" \",\"previousSibling\":{\"id\":1729},\"parentNode\":{\"id\":1690}},{\"nodeType\":3,\"id\":1731,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":1729}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":1683},{\"id\":1685},{\"id\":1686},{\"id\":1692},{\"id\":1693},{\"id\":1695},{\"id\":1696},{\"id\":1698},{\"id\":1697},{\"id\":1694},{\"id\":1687},{\"id\":1688},{\"id\":1699},{\"id\":1700},{\"id\":1702},{\"id\":1703},{\"id\":1714},{\"id\":1704},{\"id\":1715},{\"id\":1716},{\"id\":1718},{\"id\":1717},{\"id\":1705},{\"id\":1706},{\"id\":1719},{\"id\":1720},{\"id\":1722},{\"id\":1721},{\"id\":1707},{\"id\":1708},{\"id\":1723},{\"id\":1725},{\"id\":1724},{\"id\":1709},{\"id\":1710},{\"id\":1726},{\"id\":1711},{\"id\":1712},{\"id\":1727},{\"id\":1713},{\"id\":1701},{\"id\":1689},{\"id\":1690},{\"id\":1728},{\"id\":1729},{\"id\":1731},{\"id\":1730},{\"id\":1691},{\"id\":1684}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1732,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":53}},{\"nodeType\":3,\"id\":1733,\"textContent\":\"[ { \\\"rt\\\": 74338, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 74342, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 23033, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 98719, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 9355, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"kilo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 109090, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 21336, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 131516, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 18153, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 150672, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 55659, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 207620, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-03 PM-12 PM-11 AM-A -A -A -11 AM-11 AM-A -A -A -A -A -A -A -A -A -C -X -H -F -F -F -A -A -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:894,y:752,t:1512065389384};\\\", \\\"{x:900,y:751,t:1512065389401};\\\", \\\"{x:900,y:750,t:1512065389417};\\\", \\\"{x:900,y:746,t:1512065389434};\\\", \\\"{x:891,y:727,t:1512065389451};\\\", \\\"{x:866,y:693,t:1512065389467};\\\", \\\"{x:841,y:661,t:1512065389484};\\\", \\\"{x:818,y:629,t:1512065389500};\\\", \\\"{x:797,y:604,t:1512065389517};\\\", \\\"{x:773,y:578,t:1512065389533};\\\", \\\"{x:743,y:554,t:1512065389550};\\\", \\\"{x:735,y:548,t:1512065389566};\\\", \\\"{x:726,y:541,t:1512065389583};\\\", \\\"{x:719,y:535,t:1512065389600};\\\", \\\"{x:707,y:524,t:1512065389616};\\\", \\\"{x:689,y:505,t:1512065389633};\\\", \\\"{x:664,y:482,t:1512065389650};\\\", \\\"{x:638,y:463,t:1512065389666};\\\", \\\"{x:615,y:450,t:1512065389683};\\\", \\\"{x:596,y:441,t:1512065389700};\\\", \\\"{x:572,y:432,t:1512065389716};\\\", \\\"{x:547,y:425,t:1512065389733};\\\", \\\"{x:514,y:420,t:1512065389749};\\\", \\\"{x:492,y:416,t:1512065389766};\\\", \\\"{x:477,y:414,t:1512065389783};\\\", \\\"{x:468,y:414,t:1512065389800};\\\", \\\"{x:461,y:414,t:1512065389817};\\\", \\\"{x:459,y:414,t:1512065389833};\\\", \\\"{x:458,y:414,t:1512065390711};\\\", \\\"{x:457,y:414,t:1512065390718};\\\", \\\"{x:455,y:415,t:1512065390735};\\\", \\\"{x:454,y:416,t:1512065390751};\\\", \\\"{x:452,y:418,t:1512065390767};\\\", \\\"{x:447,y:423,t:1512065390784};\\\", \\\"{x:442,y:430,t:1512065390801};\\\", \\\"{x:437,y:436,t:1512065390817};\\\", \\\"{x:429,y:446,t:1512065390835};\\\", \\\"{x:424,y:452,t:1512065390851};\\\", \\\"{x:419,y:459,t:1512065390868};\\\", \\\"{x:414,y:467,t:1512065390884};\\\", \\\"{x:411,y:475,t:1512065390901};\\\", \\\"{x:410,y:479,t:1512065390918};\\\", \\\"{x:408,y:483,t:1512065390934};\\\", \\\"{x:407,y:486,t:1512065390951};\\\", \\\"{x:407,y:489,t:1512065390968};\\\", \\\"{x:407,y:490,t:1512065391071};\\\", \\\"{x:409,y:490,t:1512065391084};\\\", \\\"{x:416,y:490,t:1512065391102};\\\", \\\"{x:422,y:490,t:1512065391118};\\\", \\\"{x:432,y:490,t:1512065391134};\\\", \\\"{x:439,y:490,t:1512065391151};\\\", \\\"{x:446,y:490,t:1512065391168};\\\", \\\"{x:453,y:488,t:1512065391184};\\\", \\\"{x:468,y:484,t:1512065391202};\\\", \\\"{x:487,y:481,t:1512065391218};\\\", \\\"{x:501,y:479,t:1512065391235};\\\", \\\"{x:514,y:479,t:1512065391251};\\\", \\\"{x:528,y:478,t:1512065391268};\\\", \\\"{x:535,y:477,t:1512065391285};\\\", \\\"{x:543,y:477,t:1512065391302};\\\", \\\"{x:563,y:477,t:1512065391319};\\\", \\\"{x:576,y:477,t:1512065391334};\\\", \\\"{x:592,y:477,t:1512065391351};\\\", \\\"{x:607,y:477,t:1512065391369};\\\", \\\"{x:618,y:477,t:1512065391385};\\\", \\\"{x:626,y:477,t:1512065391401};\\\", \\\"{x:634,y:477,t:1512065391418};\\\", \\\"{x:642,y:477,t:1512065391435};\\\", \\\"{x:649,y:477,t:1512065391451};\\\", \\\"{x:651,y:477,t:1512065391468};\\\", \\\"{x:652,y:477,t:1512065391485};\\\", \\\"{x:653,y:477,t:1512065391501};\\\", \\\"{x:655,y:477,t:1512065391518};\\\", \\\"{x:656,y:476,t:1512065391535};\\\", \\\"{x:655,y:476,t:1512065392247};\\\", \\\"{x:648,y:476,t:1512065392254};\\\", \\\"{x:642,y:478,t:1512065392268};\\\", \\\"{x:625,y:481,t:1512065392286};\\\", \\\"{x:599,y:491,t:1512065392302};\\\", \\\"{x:584,y:495,t:1512065392319};\\\", \\\"{x:571,y:499,t:1512065392335};\\\", \\\"{x:558,y:502,t:1512065392352};\\\", \\\"{x:546,y:506,t:1512065392369};\\\", \\\"{x:535,y:510,t:1512065392385};\\\", \\\"{x:523,y:515,t:1512065392402};\\\", \\\"{x:512,y:519,t:1512065392419};\\\", \\\"{x:504,y:523,t:1512065392435};\\\", \\\"{x:497,y:526,t:1512065392452};\\\", \\\"{x:487,y:531,t:1512065392469};\\\", \\\"{x:478,y:534,t:1512065392485};\\\", \\\"{x:467,y:539,t:1512065392502};\\\", \\\"{x:461,y:542,t:1512065392519};\\\", \\\"{x:452,y:546,t:1512065392535};\\\", \\\"{x:448,y:548,t:1512065392553};\\\", \\\"{x:440,y:551,t:1512065392569};\\\", \\\"{x:433,y:554,t:1512065392585};\\\", \\\"{x:427,y:557,t:1512065392602};\\\", \\\"{x:419,y:560,t:1512065392619};\\\", \\\"{x:414,y:562,t:1512065392635};\\\", \\\"{x:412,y:563,t:1512065392652};\\\", \\\"{x:411,y:563,t:1512065392669};\\\", \\\"{x:409,y:563,t:1512065392686};\\\", \\\"{x:406,y:564,t:1512065392702};\\\", \\\"{x:404,y:564,t:1512065392719};\\\", \\\"{x:402,y:566,t:1512065392735};\\\", \\\"{x:400,y:566,t:1512065392782};\\\", \\\"{x:399,y:566,t:1512065392823};\\\", \\\"{x:398,y:566,t:1512065392838};\\\", \\\"{x:398,y:564,t:1512065392870};\\\", \\\"{x:398,y:563,t:1512065392886};\\\", \\\"{x:398,y:557,t:1512065392902};\\\", \\\"{x:400,y:555,t:1512065392919};\\\", \\\"{x:401,y:552,t:1512065392936};\\\", \\\"{x:404,y:548,t:1512065392952};\\\", \\\"{x:407,y:544,t:1512065392970};\\\", \\\"{x:411,y:540,t:1512065392986};\\\", \\\"{x:415,y:536,t:1512065393002};\\\", \\\"{x:419,y:534,t:1512065393019};\\\", \\\"{x:421,y:532,t:1512065393036};\\\", \\\"{x:425,y:530,t:1512065393053};\\\", \\\"{x:427,y:528,t:1512065393069};\\\", \\\"{x:431,y:527,t:1512065393086};\\\", \\\"{x:436,y:525,t:1512065393102};\\\", \\\"{x:439,y:523,t:1512065393119};\\\", \\\"{x:441,y:523,t:1512065393136};\\\", \\\"{x:445,y:523,t:1512065393152};\\\", \\\"{x:448,y:521,t:1512065393169};\\\", \\\"{x:450,y:521,t:1512065393187};\\\", \\\"{x:452,y:520,t:1512065393203};\\\", \\\"{x:455,y:519,t:1512065393219};\\\", \\\"{x:456,y:519,t:1512065393237};\\\", \\\"{x:459,y:519,t:1512065393253};\\\", \\\"{x:460,y:518,t:1512065393269};\\\", \\\"{x:462,y:518,t:1512065393288};\\\", \\\"{x:463,y:518,t:1512065393303};\\\", \\\"{x:465,y:518,t:1512065393319};\\\", \\\"{x:466,y:518,t:1512065393336};\\\", \\\"{x:467,y:518,t:1512065393353};\\\", \\\"{x:468,y:518,t:1512065393369};\\\", \\\"{x:469,y:518,t:1512065393386};\\\", \\\"{x:471,y:518,t:1512065393414};\\\", \\\"{x:472,y:518,t:1512065393438};\\\", \\\"{x:474,y:518,t:1512065393462};\\\", \\\"{x:475,y:518,t:1512065393478};\\\", \\\"{x:477,y:518,t:1512065393494};\\\", \\\"{x:478,y:518,t:1512065393518};\\\", \\\"{x:479,y:518,t:1512065393542};\\\", \\\"{x:480,y:518,t:1512065393558};\\\", \\\"{x:481,y:518,t:1512065393574};\\\", \\\"{x:482,y:518,t:1512065393631};\\\", \\\"{x:483,y:518,t:1512065393638};\\\", \\\"{x:484,y:518,t:1512065393654};\\\", \\\"{x:485,y:519,t:1512065393670};\\\", \\\"{x:486,y:519,t:1512065393688};\\\", \\\"{x:487,y:519,t:1512065393703};\\\", \\\"{x:489,y:519,t:1512065393720};\\\", \\\"{x:490,y:520,t:1512065393736};\\\", \\\"{x:490,y:521,t:1512065393754};\\\", \\\"{x:492,y:521,t:1512065393807};\\\", \\\"{x:493,y:522,t:1512065393838};\\\", \\\"{x:494,y:522,t:1512065393870};\\\", \\\"{x:496,y:523,t:1512065393889};\\\", \\\"{x:497,y:524,t:1512065393903};\\\", \\\"{x:499,y:524,t:1512065393919};\\\", \\\"{x:500,y:526,t:1512065393936};\\\", \\\"{x:501,y:526,t:1512065393957};\\\", \\\"{x:502,y:526,t:1512065393969};\\\", \\\"{x:503,y:527,t:1512065393997};\\\", \\\"{x:504,y:527,t:1512065394021};\\\", \\\"{x:506,y:528,t:1512065394036};\\\", \\\"{x:507,y:528,t:1512065394053};\\\", \\\"{x:509,y:529,t:1512065394070};\\\", \\\"{x:511,y:530,t:1512065394134};\\\", \\\"{x:513,y:532,t:1512065394150};\\\", \\\"{x:514,y:532,t:1512065394174};\\\", \\\"{x:514,y:533,t:1512065394187};\\\", \\\"{x:515,y:533,t:1512065394204};\\\", \\\"{x:516,y:534,t:1512065394220};\\\", \\\"{x:517,y:534,t:1512065394238};\\\", \\\"{x:517,y:535,t:1512065394253};\\\", \\\"{x:517,y:536,t:1512065394391};\\\", \\\"{x:517,y:537,t:1512065394403};\\\", \\\"{x:517,y:538,t:1512065394438};\\\", \\\"{x:517,y:539,t:1512065394454};\\\", \\\"{x:517,y:540,t:1512065394470};\\\", \\\"{x:517,y:541,t:1512065394487};\\\", \\\"{x:517,y:542,t:1512065394503};\\\", \\\"{x:517,y:543,t:1512065394520};\\\", \\\"{x:517,y:544,t:1512065394536};\\\", \\\"{x:516,y:545,t:1512065394553};\\\", \\\"{x:513,y:547,t:1512065394570};\\\", \\\"{x:512,y:547,t:1512065394587};\\\", \\\"{x:509,y:547,t:1512065394603};\\\", \\\"{x:506,y:547,t:1512065394620};\\\", \\\"{x:502,y:547,t:1512065394637};\\\", \\\"{x:497,y:547,t:1512065394653};\\\", \\\"{x:494,y:547,t:1512065394670};\\\", \\\"{x:488,y:547,t:1512065394687};\\\", \\\"{x:487,y:547,t:1512065394703};\\\", \\\"{x:484,y:547,t:1512065394720};\\\", \\\"{x:483,y:547,t:1512065394737};\\\", \\\"{x:481,y:547,t:1512065394753};\\\", \\\"{x:480,y:547,t:1512065394790};\\\", \\\"{x:479,y:547,t:1512065394804};\\\", \\\"{x:478,y:547,t:1512065394820};\\\", \\\"{x:477,y:547,t:1512065394837};\\\", \\\"{x:475,y:547,t:1512065394853};\\\", \\\"{x:473,y:546,t:1512065394870};\\\", \\\"{x:472,y:546,t:1512065394887};\\\", \\\"{x:471,y:546,t:1512065394903};\\\", \\\"{x:470,y:546,t:1512065394920};\\\", \\\"{x:469,y:546,t:1512065394937};\\\", \\\"{x:469,y:545,t:1512065394954};\\\", \\\"{x:468,y:544,t:1512065394971};\\\", \\\"{x:466,y:544,t:1512065394988};\\\", \\\"{x:464,y:544,t:1512065395004};\\\", \\\"{x:462,y:544,t:1512065395021};\\\", \\\"{x:459,y:544,t:1512065395037};\\\", \\\"{x:458,y:544,t:1512065395053};\\\", \\\"{x:467,y:544,t:1512065395230};\\\", \\\"{x:487,y:544,t:1512065395238};\\\", \\\"{x:576,y:557,t:1512065395254};\\\", \\\"{x:661,y:574,t:1512065395271};\\\", \\\"{x:741,y:596,t:1512065395288};\\\", \\\"{x:819,y:618,t:1512065395305};\\\", \\\"{x:902,y:643,t:1512065395321};\\\", \\\"{x:1003,y:677,t:1512065395338};\\\", \\\"{x:1106,y:714,t:1512065395355};\\\", \\\"{x:1205,y:754,t:1512065395371};\\\", \\\"{x:1280,y:788,t:1512065395388};\\\", \\\"{x:1319,y:805,t:1512065395405};\\\", \\\"{x:1350,y:825,t:1512065395421};\\\", \\\"{x:1371,y:842,t:1512065395438};\\\", \\\"{x:1381,y:855,t:1512065395454};\\\", \\\"{x:1385,y:864,t:1512065395471};\\\", \\\"{x:1392,y:879,t:1512065395488};\\\", \\\"{x:1398,y:896,t:1512065395505};\\\", \\\"{x:1400,y:913,t:1512065395521};\\\", \\\"{x:1402,y:927,t:1512065395538};\\\", \\\"{x:1402,y:933,t:1512065395555};\\\", \\\"{x:1399,y:939,t:1512065395572};\\\", \\\"{x:1393,y:946,t:1512065395588};\\\", \\\"{x:1384,y:954,t:1512065395605};\\\", \\\"{x:1370,y:962,t:1512065395622};\\\", \\\"{x:1335,y:976,t:1512065395638};\\\", \\\"{x:1311,y:987,t:1512065395655};\\\", \\\"{x:1288,y:992,t:1512065395672};\\\", \\\"{x:1260,y:997,t:1512065395688};\\\", \\\"{x:1240,y:999,t:1512065395705};\\\", \\\"{x:1222,y:999,t:1512065395722};\\\", \\\"{x:1207,y:999,t:1512065395738};\\\", \\\"{x:1185,y:999,t:1512065395755};\\\", \\\"{x:1164,y:999,t:1512065395772};\\\", \\\"{x:1138,y:996,t:1512065395788};\\\", \\\"{x:1123,y:990,t:1512065395805};\\\", \\\"{x:1101,y:980,t:1512065395822};\\\", \\\"{x:1083,y:973,t:1512065395838};\\\", \\\"{x:1061,y:963,t:1512065395855};\\\", \\\"{x:1050,y:957,t:1512065395872};\\\", \\\"{x:1046,y:954,t:1512065395888};\\\", \\\"{x:1043,y:952,t:1512065395905};\\\", \\\"{x:1037,y:946,t:1512065395922};\\\", \\\"{x:1032,y:940,t:1512065395938};\\\", \\\"{x:1028,y:938,t:1512065395955};\\\", \\\"{x:1022,y:937,t:1512065395972};\\\", \\\"{x:1021,y:937,t:1512065395998};\\\", \\\"{x:1020,y:937,t:1512065396022};\\\", \\\"{x:1019,y:937,t:1512065396046};\\\", \\\"{x:1017,y:937,t:1512065396055};\\\", \\\"{x:1016,y:937,t:1512065396078};\\\", \\\"{x:1016,y:939,t:1512065396215};\\\", \\\"{x:1017,y:943,t:1512065396222};\\\", \\\"{x:1021,y:949,t:1512065396238};\\\", \\\"{x:1023,y:950,t:1512065396255};\\\", \\\"{x:1025,y:954,t:1512065396272};\\\", \\\"{x:1025,y:956,t:1512065396289};\\\", \\\"{x:1026,y:957,t:1512065396305};\\\", \\\"{x:1026,y:958,t:1512065396326};\\\", \\\"{x:1026,y:959,t:1512065396358};\\\", \\\"{x:1027,y:960,t:1512065396390};\\\", \\\"{x:1028,y:961,t:1512065396414};\\\", \\\"{x:1029,y:961,t:1512065396470};\\\", \\\"{x:1030,y:961,t:1512065396489};\\\", \\\"{x:1031,y:961,t:1512065396506};\\\", \\\"{x:1032,y:961,t:1512065396522};\\\", \\\"{x:1034,y:962,t:1512065396550};\\\", \\\"{x:1035,y:962,t:1512065396558};\\\", \\\"{x:1036,y:962,t:1512065396607};\\\", \\\"{x:1038,y:963,t:1512065396622};\\\", \\\"{x:1039,y:963,t:1512065396638};\\\", \\\"{x:1040,y:963,t:1512065396655};\\\", \\\"{x:1041,y:963,t:1512065396685};\\\", \\\"{x:1042,y:963,t:1512065396693};\\\", \\\"{x:1044,y:963,t:1512065396705};\\\", \\\"{x:1045,y:963,t:1512065396822};\\\", \\\"{x:1045,y:962,t:1512065396870};\\\", \\\"{x:1046,y:962,t:1512065396902};\\\", \\\"{x:1046,y:961,t:1512065396918};\\\", \\\"{x:1047,y:960,t:1512065396950};\\\", \\\"{x:1047,y:959,t:1512065396958};\\\", \\\"{x:1047,y:958,t:1512065396972};\\\", \\\"{x:1048,y:956,t:1512065396988};\\\", \\\"{x:1050,y:947,t:1512065397006};\\\", \\\"{x:1050,y:941,t:1512065397022};\\\", \\\"{x:1050,y:930,t:1512065397039};\\\", \\\"{x:1050,y:913,t:1512065397056};\\\", \\\"{x:1050,y:893,t:1512065397073};\\\", \\\"{x:1050,y:874,t:1512065397088};\\\", \\\"{x:1050,y:853,t:1512065397105};\\\", \\\"{x:1050,y:830,t:1512065397122};\\\", \\\"{x:1050,y:810,t:1512065397138};\\\", \\\"{x:1050,y:797,t:1512065397155};\\\", \\\"{x:1050,y:787,t:1512065397172};\\\", \\\"{x:1050,y:776,t:1512065397188};\\\", \\\"{x:1050,y:761,t:1512065397205};\\\", \\\"{x:1050,y:757,t:1512065397221};\\\", \\\"{x:1050,y:756,t:1512065397238};\\\", \\\"{x:1049,y:756,t:1512065397318};\\\", \\\"{x:1048,y:757,t:1512065397326};\\\", \\\"{x:1048,y:761,t:1512065397338};\\\", \\\"{x:1047,y:769,t:1512065397356};\\\", \\\"{x:1046,y:779,t:1512065397373};\\\", \\\"{x:1044,y:792,t:1512065397389};\\\", \\\"{x:1041,y:808,t:1512065397406};\\\", \\\"{x:1040,y:816,t:1512065397422};\\\", \\\"{x:1040,y:820,t:1512065397439};\\\", \\\"{x:1040,y:822,t:1512065397456};\\\", \\\"{x:1040,y:823,t:1512065397494};\\\", \\\"{x:1041,y:826,t:1512065397661};\\\", \\\"{x:1042,y:828,t:1512065397672};\\\", \\\"{x:1044,y:830,t:1512065397689};\\\", \\\"{x:1045,y:832,t:1512065397705};\\\", \\\"{x:1046,y:832,t:1512065397723};\\\", \\\"{x:1046,y:833,t:1512065398206};\\\", \\\"{x:1045,y:833,t:1512065398270};\\\", \\\"{x:1044,y:833,t:1512065398518};\\\", \\\"{x:1043,y:832,t:1512065398606};\\\", \\\"{x:1042,y:831,t:1512065398622};\\\", \\\"{x:1041,y:830,t:1512065398718};\\\", \\\"{x:1040,y:830,t:1512065400462};\\\", \\\"{x:1039,y:830,t:1512065400478};\\\", \\\"{x:1038,y:830,t:1512065400492};\\\", \\\"{x:1036,y:830,t:1512065400516};\\\", \\\"{x:1033,y:830,t:1512065400543};\\\", \\\"{x:1032,y:830,t:1512065400558};\\\", \\\"{x:1031,y:830,t:1512065400575};\\\", \\\"{x:1030,y:830,t:1512065400592};\\\", \\\"{x:1029,y:829,t:1512065400629};\\\", \\\"{x:1028,y:829,t:1512065400653};\\\", \\\"{x:1027,y:829,t:1512065400669};\\\", \\\"{x:1026,y:829,t:1512065400677};\\\", \\\"{x:1025,y:829,t:1512065400692};\\\", \\\"{x:1024,y:829,t:1512065400708};\\\", \\\"{x:1021,y:829,t:1512065400725};\\\", \\\"{x:1019,y:829,t:1512065400742};\\\", \\\"{x:1015,y:829,t:1512065400758};\\\", \\\"{x:1011,y:828,t:1512065400775};\\\", \\\"{x:1007,y:828,t:1512065400792};\\\", \\\"{x:1004,y:828,t:1512065400809};\\\", \\\"{x:1001,y:828,t:1512065400825};\\\", \\\"{x:999,y:828,t:1512065400842};\\\", \\\"{x:998,y:828,t:1512065400859};\\\", \\\"{x:997,y:828,t:1512065400875};\\\", \\\"{x:996,y:828,t:1512065400892};\\\", \\\"{x:998,y:827,t:1512065401086};\\\", \\\"{x:1000,y:826,t:1512065401094};\\\", \\\"{x:1004,y:826,t:1512065401110};\\\", \\\"{x:1008,y:826,t:1512065401126};\\\", \\\"{x:1009,y:826,t:1512065401143};\\\", \\\"{x:1011,y:826,t:1512065401160};\\\", \\\"{x:1015,y:826,t:1512065401176};\\\", \\\"{x:1018,y:826,t:1512065401193};\\\", \\\"{x:1023,y:825,t:1512065401210};\\\", \\\"{x:1024,y:825,t:1512065401227};\\\", \\\"{x:1025,y:825,t:1512065401246};\\\", \\\"{x:1026,y:825,t:1512065401260};\\\", \\\"{x:1027,y:825,t:1512065401277};\\\", \\\"{x:1028,y:825,t:1512065401318};\\\", \\\"{x:1029,y:825,t:1512065401326};\\\", \\\"{x:1030,y:825,t:1512065401343};\\\", \\\"{x:1031,y:825,t:1512065401360};\\\", \\\"{x:1032,y:825,t:1512065401377};\\\", \\\"{x:1033,y:825,t:1512065401393};\\\", \\\"{x:1034,y:825,t:1512065401422};\\\", \\\"{x:1035,y:825,t:1512065401430};\\\", \\\"{x:1037,y:825,t:1512065401443};\\\", \\\"{x:1038,y:825,t:1512065401460};\\\", \\\"{x:1039,y:825,t:1512065401477};\\\", \\\"{x:1040,y:825,t:1512065401500};\\\", \\\"{x:1040,y:826,t:1512065401718};\\\", \\\"{x:1040,y:827,t:1512065402750};\\\", \\\"{x:1039,y:827,t:1512065402782};\\\", \\\"{x:1038,y:829,t:1512065402798};\\\", \\\"{x:1037,y:829,t:1512065402814};\\\", \\\"{x:1035,y:829,t:1512065402894};\\\", \\\"{x:1034,y:829,t:1512065402933};\\\", \\\"{x:1033,y:829,t:1512065403207};\\\", \\\"{x:1033,y:831,t:1512065403775};\\\", \\\"{x:1031,y:837,t:1512065403783};\\\", \\\"{x:1031,y:842,t:1512065403796};\\\", \\\"{x:1031,y:861,t:1512065403812};\\\", \\\"{x:1031,y:879,t:1512065403830};\\\", \\\"{x:1036,y:905,t:1512065403846};\\\", \\\"{x:1039,y:940,t:1512065403863};\\\", \\\"{x:1043,y:963,t:1512065403879};\\\", \\\"{x:1045,y:984,t:1512065403896};\\\", \\\"{x:1049,y:1013,t:1512065403913};\\\", \\\"{x:1053,y:1037,t:1512065403929};\\\", \\\"{x:1058,y:1058,t:1512065403945};\\\", \\\"{x:1061,y:1073,t:1512065403963};\\\", \\\"{x:1063,y:1077,t:1512065403979};\\\", \\\"{x:1063,y:1073,t:1512065404143};\\\", \\\"{x:1063,y:1070,t:1512065404151};\\\", \\\"{x:1063,y:1065,t:1512065404162};\\\", \\\"{x:1061,y:1057,t:1512065404180};\\\", \\\"{x:1059,y:1051,t:1512065404196};\\\", \\\"{x:1058,y:1040,t:1512065404213};\\\", \\\"{x:1058,y:1033,t:1512065404230};\\\", \\\"{x:1057,y:1015,t:1512065404246};\\\", \\\"{x:1054,y:1000,t:1512065404262};\\\", \\\"{x:1053,y:987,t:1512065404280};\\\", \\\"{x:1053,y:963,t:1512065404297};\\\", \\\"{x:1049,y:927,t:1512065404313};\\\", \\\"{x:1045,y:898,t:1512065404330};\\\", \\\"{x:1040,y:876,t:1512065404346};\\\", \\\"{x:1037,y:865,t:1512065404362};\\\", \\\"{x:1037,y:861,t:1512065404379};\\\", \\\"{x:1035,y:845,t:1512065404396};\\\", \\\"{x:1032,y:837,t:1512065404412};\\\", \\\"{x:1032,y:830,t:1512065404429};\\\", \\\"{x:1032,y:812,t:1512065404446};\\\", \\\"{x:1031,y:807,t:1512065404462};\\\", \\\"{x:1031,y:802,t:1512065404479};\\\", \\\"{x:1030,y:799,t:1512065404496};\\\", \\\"{x:1030,y:798,t:1512065404512};\\\", \\\"{x:1030,y:797,t:1512065404529};\\\", \\\"{x:1030,y:796,t:1512065404546};\\\", \\\"{x:1030,y:795,t:1512065404607};\\\", \\\"{x:1032,y:795,t:1512065404615};\\\", \\\"{x:1034,y:798,t:1512065404630};\\\", \\\"{x:1037,y:806,t:1512065404647};\\\", \\\"{x:1037,y:811,t:1512065404663};\\\", \\\"{x:1037,y:816,t:1512065404680};\\\", \\\"{x:1037,y:820,t:1512065404697};\\\", \\\"{x:1037,y:823,t:1512065404714};\\\", \\\"{x:1037,y:825,t:1512065404735};\\\", \\\"{x:1038,y:825,t:1512065404983};\\\", \\\"{x:1039,y:825,t:1512065404997};\\\", \\\"{x:1040,y:825,t:1512065405021};\\\", \\\"{x:1043,y:816,t:1512065405048};\\\", \\\"{x:1043,y:814,t:1512065405063};\\\", \\\"{x:1044,y:812,t:1512065405080};\\\", \\\"{x:1044,y:811,t:1512065405102};\\\", \\\"{x:1044,y:810,t:1512065405158};\\\", \\\"{x:1044,y:808,t:1512065405174};\\\", \\\"{x:1044,y:807,t:1512065405182};\\\", \\\"{x:1044,y:806,t:1512065405196};\\\", \\\"{x:1044,y:805,t:1512065405213};\\\", \\\"{x:1044,y:799,t:1512065405230};\\\", \\\"{x:1044,y:795,t:1512065405246};\\\", \\\"{x:1044,y:791,t:1512065405263};\\\", \\\"{x:1044,y:785,t:1512065405280};\\\", \\\"{x:1042,y:778,t:1512065405296};\\\", \\\"{x:1042,y:770,t:1512065405313};\\\", \\\"{x:1040,y:757,t:1512065405330};\\\", \\\"{x:1040,y:753,t:1512065405346};\\\", \\\"{x:1038,y:746,t:1512065405363};\\\", \\\"{x:1038,y:743,t:1512065405380};\\\", \\\"{x:1038,y:742,t:1512065405396};\\\", \\\"{x:1038,y:741,t:1512065405413};\\\", \\\"{x:1038,y:740,t:1512065405454};\\\", \\\"{x:1038,y:739,t:1512065405470};\\\", \\\"{x:1038,y:737,t:1512065405480};\\\", \\\"{x:1038,y:736,t:1512065405497};\\\", \\\"{x:1038,y:734,t:1512065405518};\\\", \\\"{x:1038,y:733,t:1512065405534};\\\", \\\"{x:1038,y:731,t:1512065405547};\\\", \\\"{x:1038,y:730,t:1512065405563};\\\", \\\"{x:1038,y:727,t:1512065405581};\\\", \\\"{x:1037,y:725,t:1512065405598};\\\", \\\"{x:1037,y:723,t:1512065405614};\\\", \\\"{x:1037,y:718,t:1512065405630};\\\", \\\"{x:1037,y:714,t:1512065405647};\\\", \\\"{x:1036,y:712,t:1512065405664};\\\", \\\"{x:1036,y:710,t:1512065405680};\\\", \\\"{x:1036,y:709,t:1512065405697};\\\", \\\"{x:1036,y:708,t:1512065405713};\\\", \\\"{x:1036,y:705,t:1512065405730};\\\", \\\"{x:1036,y:703,t:1512065405747};\\\", \\\"{x:1036,y:702,t:1512065405763};\\\", \\\"{x:1036,y:701,t:1512065405781};\\\", \\\"{x:1036,y:699,t:1512065405798};\\\", \\\"{x:1036,y:698,t:1512065405839};\\\", \\\"{x:1036,y:697,t:1512065405879};\\\", \\\"{x:1037,y:697,t:1512065405911};\\\", \\\"{x:1037,y:696,t:1512065405919};\\\", \\\"{x:1038,y:696,t:1512065405931};\\\", \\\"{x:1039,y:696,t:1512065405948};\\\", \\\"{x:1041,y:696,t:1512065405965};\\\", \\\"{x:1043,y:696,t:1512065405980};\\\", \\\"{x:1044,y:696,t:1512065405998};\\\", \\\"{x:1045,y:696,t:1512065406014};\\\", \\\"{x:1047,y:695,t:1512065406047};\\\", \\\"{x:1048,y:694,t:1512065406079};\\\", \\\"{x:1050,y:694,t:1512065406087};\\\", \\\"{x:1051,y:694,t:1512065406143};\\\", \\\"{x:1050,y:694,t:1512065406327};\\\", \\\"{x:1049,y:694,t:1512065406335};\\\", \\\"{x:1048,y:695,t:1512065406351};\\\", \\\"{x:1047,y:695,t:1512065406365};\\\", \\\"{x:1046,y:695,t:1512065406382};\\\", \\\"{x:1044,y:696,t:1512065406398};\\\", \\\"{x:1043,y:696,t:1512065406414};\\\", \\\"{x:1042,y:698,t:1512065406432};\\\", \\\"{x:1041,y:698,t:1512065406463};\\\", \\\"{x:1040,y:698,t:1512065406479};\\\", \\\"{x:1039,y:698,t:1512065406495};\\\", \\\"{x:1038,y:699,t:1512065406502};\\\", \\\"{x:1040,y:699,t:1512065406719};\\\", \\\"{x:1041,y:698,t:1512065406775};\\\", \\\"{x:1040,y:697,t:1512065407007};\\\", \\\"{x:1040,y:696,t:1512065407023};\\\", \\\"{x:1040,y:695,t:1512065407039};\\\", \\\"{x:1039,y:694,t:1512065407049};\\\", \\\"{x:1038,y:689,t:1512065407065};\\\", \\\"{x:1038,y:683,t:1512065407082};\\\", \\\"{x:1035,y:667,t:1512065407099};\\\", \\\"{x:1032,y:651,t:1512065407114};\\\", \\\"{x:1030,y:634,t:1512065407131};\\\", \\\"{x:1027,y:615,t:1512065407149};\\\", \\\"{x:1025,y:595,t:1512065407165};\\\", \\\"{x:1024,y:572,t:1512065407182};\\\", \\\"{x:1024,y:541,t:1512065407198};\\\", \\\"{x:1024,y:523,t:1512065407215};\\\", \\\"{x:1024,y:511,t:1512065407231};\\\", \\\"{x:1024,y:501,t:1512065407249};\\\", \\\"{x:1024,y:494,t:1512065407266};\\\", \\\"{x:1026,y:490,t:1512065407281};\\\", \\\"{x:1027,y:485,t:1512065407298};\\\", \\\"{x:1028,y:484,t:1512065407316};\\\", \\\"{x:1029,y:484,t:1512065407332};\\\", \\\"{x:1030,y:484,t:1512065407349};\\\", \\\"{x:1032,y:483,t:1512065407366};\\\", \\\"{x:1033,y:482,t:1512065407382};\\\", \\\"{x:1036,y:482,t:1512065407406};\\\", \\\"{x:1036,y:483,t:1512065407416};\\\", \\\"{x:1037,y:490,t:1512065407432};\\\", \\\"{x:1039,y:498,t:1512065407449};\\\", \\\"{x:1039,y:503,t:1512065407466};\\\", \\\"{x:1040,y:509,t:1512065407482};\\\", \\\"{x:1040,y:512,t:1512065407499};\\\", \\\"{x:1040,y:517,t:1512065407516};\\\", \\\"{x:1040,y:524,t:1512065407532};\\\", \\\"{x:1040,y:531,t:1512065407549};\\\", \\\"{x:1040,y:541,t:1512065407566};\\\", \\\"{x:1039,y:549,t:1512065407582};\\\", \\\"{x:1038,y:559,t:1512065407598};\\\", \\\"{x:1038,y:570,t:1512065407616};\\\", \\\"{x:1038,y:582,t:1512065407633};\\\", \\\"{x:1035,y:595,t:1512065407649};\\\", \\\"{x:1034,y:610,t:1512065407666};\\\", \\\"{x:1034,y:625,t:1512065407683};\\\", \\\"{x:1034,y:637,t:1512065407699};\\\", \\\"{x:1034,y:650,t:1512065407716};\\\", \\\"{x:1034,y:663,t:1512065407733};\\\", \\\"{x:1034,y:673,t:1512065407749};\\\", \\\"{x:1034,y:688,t:1512065407766};\\\", \\\"{x:1034,y:719,t:1512065407782};\\\", \\\"{x:1034,y:734,t:1512065407799};\\\", \\\"{x:1034,y:744,t:1512065407816};\\\", \\\"{x:1035,y:753,t:1512065407833};\\\", \\\"{x:1037,y:763,t:1512065407849};\\\", \\\"{x:1037,y:770,t:1512065407866};\\\", \\\"{x:1038,y:774,t:1512065407883};\\\", \\\"{x:1038,y:775,t:1512065407899};\\\", \\\"{x:1038,y:780,t:1512065407916};\\\", \\\"{x:1039,y:784,t:1512065407933};\\\", \\\"{x:1039,y:788,t:1512065407949};\\\", \\\"{x:1040,y:789,t:1512065407966};\\\", \\\"{x:1040,y:794,t:1512065407982};\\\", \\\"{x:1040,y:795,t:1512065408007};\\\", \\\"{x:1040,y:797,t:1512065408022};\\\", \\\"{x:1040,y:798,t:1512065408033};\\\", \\\"{x:1041,y:800,t:1512065408049};\\\", \\\"{x:1041,y:804,t:1512065408066};\\\", \\\"{x:1043,y:814,t:1512065408083};\\\", \\\"{x:1044,y:824,t:1512065408099};\\\", \\\"{x:1048,y:837,t:1512065408116};\\\", \\\"{x:1048,y:843,t:1512065408133};\\\", \\\"{x:1049,y:846,t:1512065408150};\\\", \\\"{x:1050,y:847,t:1512065408166};\\\", \\\"{x:1050,y:848,t:1512065408207};\\\", \\\"{x:1050,y:845,t:1512065408447};\\\", \\\"{x:1050,y:843,t:1512065408462};\\\", \\\"{x:1050,y:842,t:1512065408471};\\\", \\\"{x:1050,y:841,t:1512065408483};\\\", \\\"{x:1050,y:837,t:1512065408499};\\\", \\\"{x:1049,y:835,t:1512065408516};\\\", \\\"{x:1049,y:834,t:1512065408549};\\\", \\\"{x:1049,y:833,t:1512065408574};\\\", \\\"{x:1048,y:833,t:1512065408582};\\\", \\\"{x:1047,y:829,t:1512065408602};\\\", \\\"{x:1046,y:827,t:1512065408616};\\\", \\\"{x:1046,y:826,t:1512065408632};\\\", \\\"{x:1045,y:826,t:1512065408641};\\\", \\\"{x:1045,y:825,t:1512065408661};\\\", \\\"{x:1044,y:824,t:1512065408695};\\\", \\\"{x:1042,y:824,t:1512065408717};\\\", \\\"{x:1041,y:824,t:1512065408757};\\\", \\\"{x:1040,y:824,t:1512065408765};\\\", \\\"{x:1038,y:825,t:1512065408782};\\\", \\\"{x:1037,y:825,t:1512065408799};\\\", \\\"{x:1036,y:825,t:1512065408816};\\\", \\\"{x:1035,y:825,t:1512065408832};\\\", \\\"{x:1035,y:826,t:1512065408849};\\\", \\\"{x:1034,y:826,t:1512065409343};\\\", \\\"{x:1035,y:826,t:1512065409454};\\\", \\\"{x:1036,y:825,t:1512065409478};\\\", \\\"{x:1037,y:825,t:1512065409615};\\\", \\\"{x:1038,y:825,t:1512065409630};\\\", \\\"{x:1039,y:825,t:1512065409646};\\\", \\\"{x:1040,y:825,t:1512065409688};\\\", \\\"{x:1042,y:824,t:1512065409727};\\\", \\\"{x:1043,y:824,t:1512065409741};\\\", \\\"{x:1044,y:824,t:1512065409750};\\\", \\\"{x:1045,y:824,t:1512065409789};\\\", \\\"{x:1043,y:824,t:1512065410318};\\\", \\\"{x:1043,y:826,t:1512065410341};\\\", \\\"{x:1041,y:828,t:1512065410367};\\\", \\\"{x:1041,y:829,t:1512065410384};\\\", \\\"{x:1040,y:830,t:1512065410910};\\\", \\\"{x:1040,y:831,t:1512065410966};\\\", \\\"{x:1040,y:832,t:1512065411022};\\\", \\\"{x:1039,y:832,t:1512065411034};\\\", \\\"{x:1038,y:833,t:1512065411051};\\\", \\\"{x:1037,y:836,t:1512065411084};\\\", \\\"{x:1037,y:837,t:1512065411101};\\\", \\\"{x:1035,y:838,t:1512065411117};\\\", \\\"{x:1035,y:839,t:1512065411141};\\\", \\\"{x:1034,y:841,t:1512065411173};\\\", \\\"{x:1033,y:842,t:1512065411198};\\\", \\\"{x:1032,y:843,t:1512065411206};\\\", \\\"{x:1032,y:844,t:1512065411218};\\\", \\\"{x:1030,y:846,t:1512065411234};\\\", \\\"{x:1029,y:848,t:1512065411251};\\\", \\\"{x:1028,y:849,t:1512065411268};\\\", \\\"{x:1026,y:852,t:1512065411284};\\\", \\\"{x:1025,y:854,t:1512065411301};\\\", \\\"{x:1024,y:856,t:1512065411342};\\\", \\\"{x:1024,y:857,t:1512065411391};\\\", \\\"{x:1023,y:857,t:1512065411402};\\\", \\\"{x:1023,y:857,t:1512065411528};\\\", \\\"{x:1023,y:856,t:1512065411550};\\\", \\\"{x:1023,y:854,t:1512065411558};\\\", \\\"{x:1024,y:853,t:1512065411574};\\\", \\\"{x:1025,y:851,t:1512065411586};\\\", \\\"{x:1026,y:847,t:1512065411602};\\\", \\\"{x:1030,y:844,t:1512065411619};\\\", \\\"{x:1031,y:842,t:1512065411635};\\\", \\\"{x:1033,y:840,t:1512065411651};\\\", \\\"{x:1034,y:838,t:1512065411669};\\\", \\\"{x:1036,y:837,t:1512065411686};\\\", \\\"{x:1037,y:837,t:1512065411702};\\\", \\\"{x:1038,y:835,t:1512065411719};\\\", \\\"{x:1040,y:834,t:1512065411758};\\\", \\\"{x:1041,y:833,t:1512065411797};\\\", \\\"{x:1042,y:832,t:1512065411813};\\\", \\\"{x:1043,y:832,t:1512065411829};\\\", \\\"{x:1044,y:832,t:1512065411839};\\\", \\\"{x:1045,y:832,t:1512065411877};\\\", \\\"{x:1045,y:831,t:1512065411982};\\\", \\\"{x:1041,y:830,t:1512065419801};\\\", \\\"{x:1021,y:828,t:1512065419827};\\\", \\\"{x:1014,y:828,t:1512065419844};\\\", \\\"{x:1006,y:828,t:1512065419861};\\\", \\\"{x:1000,y:826,t:1512065419877};\\\", \\\"{x:998,y:826,t:1512065419904};\\\", \\\"{x:997,y:826,t:1512065419960};\\\", \\\"{x:990,y:827,t:1512065419977};\\\", \\\"{x:985,y:830,t:1512065419994};\\\", \\\"{x:984,y:831,t:1512065420011};\\\", \\\"{x:982,y:832,t:1512065420027};\\\", \\\"{x:981,y:832,t:1512065420112};\\\", \\\"{x:981,y:833,t:1512065420144};\\\", \\\"{x:980,y:833,t:1512065420161};\\\", \\\"{x:979,y:833,t:1512065420232};\\\", \\\"{x:978,y:833,t:1512065420305};\\\", \\\"{x:977,y:833,t:1512065420497};\\\", \\\"{x:997,y:833,t:1512065422271};\\\", \\\"{x:1113,y:798,t:1512065422297};\\\", \\\"{x:1138,y:770,t:1512065422314};\\\", \\\"{x:1200,y:686,t:1512065422330};\\\", \\\"{x:1288,y:556,t:1512065422347};\\\", \\\"{x:1400,y:403,t:1512065422364};\\\", \\\"{x:1511,y:261,t:1512065422380};\\\", \\\"{x:1592,y:167,t:1512065422397};\\\", \\\"{x:1629,y:107,t:1512065422414};\\\", \\\"{x:1645,y:68,t:1512065422430};\\\", \\\"{x:1652,y:45,t:1512065422447};\\\", \\\"{x:1654,y:31,t:1512065422464};\\\", \\\"{x:1654,y:18,t:1512065422480};\\\", \\\"{x:1654,y:10,t:1512065422497};\\\", \\\"{x:1654,y:8,t:1512065422514};\\\", \\\"{x:1650,y:8,t:1512065422545};\\\", \\\"{x:1643,y:8,t:1512065422553};\\\", \\\"{x:1638,y:8,t:1512065422564};\\\", \\\"{x:1617,y:14,t:1512065422580};\\\", \\\"{x:1581,y:23,t:1512065422597};\\\", \\\"{x:1537,y:35,t:1512065422614};\\\", \\\"{x:1481,y:51,t:1512065422630};\\\", \\\"{x:1404,y:85,t:1512065422647};\\\", \\\"{x:1314,y:135,t:1512065422664};\\\", \\\"{x:1235,y:180,t:1512065422680};\\\", \\\"{x:1190,y:211,t:1512065422697};\\\", \\\"{x:1185,y:214,t:1512065422715};\\\", \\\"{x:1182,y:216,t:1512065422731};\\\", \\\"{x:1179,y:218,t:1512065422748};\\\", \\\"{x:1178,y:220,t:1512065422765};\\\", \\\"{x:1174,y:222,t:1512065422781};\\\", \\\"{x:1173,y:222,t:1512065422882};\\\", \\\"{x:1175,y:219,t:1512065422898};\\\", \\\"{x:1184,y:210,t:1512065422915};\\\", \\\"{x:1188,y:207,t:1512065422932};\\\", \\\"{x:1197,y:199,t:1512065422948};\\\", \\\"{x:1202,y:193,t:1512065422965};\\\", \\\"{x:1205,y:190,t:1512065422982};\\\", \\\"{x:1209,y:188,t:1512065422998};\\\", \\\"{x:1214,y:185,t:1512065423015};\\\", \\\"{x:1216,y:184,t:1512065423032};\\\", \\\"{x:1217,y:183,t:1512065423066};\\\", \\\"{x:1223,y:178,t:1512065423081};\\\", \\\"{x:1230,y:174,t:1512065423098};\\\", \\\"{x:1234,y:170,t:1512065423115};\\\", \\\"{x:1237,y:168,t:1512065423132};\\\", \\\"{x:1239,y:167,t:1512065423157};\\\", \\\"{x:1243,y:165,t:1512065423181};\\\", \\\"{x:1244,y:164,t:1512065423198};\\\", \\\"{x:1245,y:164,t:1512065423217};\\\", \\\"{x:1246,y:164,t:1512065423231};\\\", \\\"{x:1247,y:163,t:1512065423248};\\\", \\\"{x:1248,y:163,t:1512065423264};\\\", \\\"{x:1248,y:170,t:1512065427839};\\\", \\\"{x:1239,y:197,t:1512065427851};\\\", \\\"{x:1237,y:210,t:1512065427868};\\\", \\\"{x:1234,y:223,t:1512065427885};\\\", \\\"{x:1233,y:238,t:1512065427901};\\\", \\\"{x:1231,y:248,t:1512065427918};\\\", \\\"{x:1229,y:261,t:1512065427935};\\\", \\\"{x:1227,y:278,t:1512065427951};\\\", \\\"{x:1226,y:289,t:1512065427968};\\\", \\\"{x:1222,y:317,t:1512065427984};\\\", \\\"{x:1219,y:338,t:1512065428001};\\\", \\\"{x:1217,y:350,t:1512065428018};\\\", \\\"{x:1216,y:360,t:1512065428035};\\\", \\\"{x:1214,y:373,t:1512065428051};\\\", \\\"{x:1212,y:382,t:1512065428068};\\\", \\\"{x:1211,y:388,t:1512065428085};\\\", \\\"{x:1209,y:395,t:1512065428101};\\\", \\\"{x:1209,y:403,t:1512065428118};\\\", \\\"{x:1207,y:417,t:1512065428136};\\\", \\\"{x:1203,y:434,t:1512065428151};\\\", \\\"{x:1199,y:447,t:1512065428168};\\\", \\\"{x:1193,y:464,t:1512065428185};\\\", \\\"{x:1190,y:472,t:1512065428202};\\\", \\\"{x:1187,y:481,t:1512065428218};\\\", \\\"{x:1184,y:486,t:1512065428236};\\\", \\\"{x:1184,y:490,t:1512065428252};\\\", \\\"{x:1183,y:492,t:1512065428268};\\\", \\\"{x:1183,y:494,t:1512065428305};\\\", \\\"{x:1183,y:496,t:1512065428321};\\\", \\\"{x:1183,y:497,t:1512065428336};\\\", \\\"{x:1183,y:502,t:1512065428352};\\\", \\\"{x:1181,y:507,t:1512065428369};\\\", \\\"{x:1181,y:514,t:1512065428385};\\\", \\\"{x:1181,y:519,t:1512065428403};\\\", \\\"{x:1181,y:532,t:1512065428419};\\\", \\\"{x:1181,y:541,t:1512065428436};\\\", \\\"{x:1179,y:555,t:1512065428453};\\\", \\\"{x:1179,y:570,t:1512065428469};\\\", \\\"{x:1179,y:587,t:1512065428485};\\\", \\\"{x:1179,y:610,t:1512065428502};\\\", \\\"{x:1179,y:636,t:1512065428519};\\\", \\\"{x:1178,y:659,t:1512065428535};\\\", \\\"{x:1173,y:692,t:1512065428552};\\\", \\\"{x:1170,y:708,t:1512065428568};\\\", \\\"{x:1168,y:720,t:1512065428585};\\\", \\\"{x:1165,y:727,t:1512065428602};\\\", \\\"{x:1164,y:734,t:1512065428618};\\\", \\\"{x:1161,y:740,t:1512065428635};\\\", \\\"{x:1157,y:750,t:1512065428652};\\\", \\\"{x:1154,y:760,t:1512065428668};\\\", \\\"{x:1151,y:765,t:1512065428685};\\\", \\\"{x:1146,y:772,t:1512065428702};\\\", \\\"{x:1142,y:780,t:1512065428718};\\\", \\\"{x:1138,y:787,t:1512065428735};\\\", \\\"{x:1137,y:789,t:1512065428752};\\\", \\\"{x:1137,y:785,t:1512065428857};\\\", \\\"{x:1137,y:778,t:1512065428870};\\\", \\\"{x:1137,y:767,t:1512065428886};\\\", \\\"{x:1137,y:764,t:1512065428908};\\\", \\\"{x:1137,y:760,t:1512065428920};\\\", \\\"{x:1139,y:756,t:1512065428936};\\\", \\\"{x:1139,y:755,t:1512065428952};\\\", \\\"{x:1140,y:755,t:1512065429154};\\\", \\\"{x:1143,y:755,t:1512065429169};\\\", \\\"{x:1147,y:757,t:1512065429187};\\\", \\\"{x:1150,y:760,t:1512065429203};\\\", \\\"{x:1151,y:761,t:1512065429220};\\\", \\\"{x:1151,y:762,t:1512065429237};\\\", \\\"{x:1151,y:763,t:1512065429281};\\\", \\\"{x:1151,y:764,t:1512065429465};\\\", \\\"{x:1151,y:765,t:1512065429489};\\\", \\\"{x:1150,y:765,t:1512065429505};\\\", \\\"{x:1149,y:765,t:1512065429519};\\\", \\\"{x:1148,y:765,t:1512065429540};\\\", \\\"{x:1146,y:766,t:1512065429553};\\\", \\\"{x:1145,y:766,t:1512065429576};\\\", \\\"{x:1145,y:767,t:1512065429586};\\\", \\\"{x:1144,y:767,t:1512065429603};\\\", \\\"{x:1143,y:767,t:1512065429620};\\\", \\\"{x:1142,y:767,t:1512065429636};\\\", \\\"{x:1141,y:767,t:1512065429653};\\\", \\\"{x:1140,y:767,t:1512065429670};\\\", \\\"{x:1139,y:767,t:1512065429729};\\\", \\\"{x:1139,y:766,t:1512065429857};\\\", \\\"{x:1139,y:765,t:1512065429881};\\\", \\\"{x:1139,y:764,t:1512065429897};\\\", \\\"{x:1139,y:763,t:1512065429905};\\\", \\\"{x:1139,y:762,t:1512065429937};\\\", \\\"{x:1139,y:761,t:1512065429953};\\\", \\\"{x:1137,y:760,t:1512065435102};\\\", \\\"{x:1123,y:766,t:1512065435125};\\\", \\\"{x:1108,y:776,t:1512065435140};\\\", \\\"{x:1099,y:780,t:1512065435157};\\\", \\\"{x:1090,y:786,t:1512065435174};\\\", \\\"{x:1079,y:791,t:1512065435190};\\\", \\\"{x:1076,y:792,t:1512065435207};\\\", \\\"{x:1072,y:794,t:1512065435224};\\\", \\\"{x:1070,y:794,t:1512065435240};\\\", \\\"{x:1067,y:795,t:1512065435257};\\\", \\\"{x:1064,y:796,t:1512065435274};\\\", \\\"{x:1062,y:797,t:1512065435291};\\\", \\\"{x:1059,y:798,t:1512065435307};\\\", \\\"{x:1057,y:799,t:1512065435324};\\\", \\\"{x:1054,y:801,t:1512065435340};\\\", \\\"{x:1050,y:804,t:1512065435357};\\\", \\\"{x:1046,y:806,t:1512065435375};\\\", \\\"{x:1042,y:810,t:1512065435391};\\\", \\\"{x:1039,y:813,t:1512065435407};\\\", \\\"{x:1035,y:817,t:1512065435425};\\\", \\\"{x:1033,y:820,t:1512065435441};\\\", \\\"{x:1031,y:824,t:1512065435458};\\\", \\\"{x:1031,y:826,t:1512065435474};\\\", \\\"{x:1030,y:828,t:1512065435491};\\\", \\\"{x:1030,y:830,t:1512065435507};\\\", \\\"{x:1030,y:831,t:1512065435524};\\\", \\\"{x:1030,y:832,t:1512065435541};\\\", \\\"{x:1030,y:833,t:1512065435557};\\\", \\\"{x:1030,y:834,t:1512065435609};\\\", \\\"{x:1030,y:835,t:1512065435625};\\\", \\\"{x:1030,y:836,t:1512065435641};\\\", \\\"{x:1031,y:838,t:1512065435658};\\\", \\\"{x:1032,y:839,t:1512065435674};\\\", \\\"{x:1033,y:839,t:1512065435692};\\\", \\\"{x:1035,y:839,t:1512065435713};\\\", \\\"{x:1036,y:839,t:1512065435729};\\\", \\\"{x:1037,y:839,t:1512065435741};\\\", \\\"{x:1038,y:838,t:1512065435757};\\\", \\\"{x:1039,y:837,t:1512065435775};\\\", \\\"{x:1040,y:837,t:1512065435849};\\\", \\\"{x:1041,y:837,t:1512065435858};\\\", \\\"{x:1042,y:836,t:1512065435875};\\\", \\\"{x:1043,y:835,t:1512065435920};\\\", \\\"{x:1044,y:834,t:1512065435968};\\\", \\\"{x:1046,y:832,t:1512065436024};\\\", \\\"{x:1046,y:830,t:1512065436289};\\\", \\\"{x:1046,y:829,t:1512065438746};\\\", \\\"{x:1047,y:828,t:1512065438762};\\\", \\\"{x:1049,y:826,t:1512065438782};\\\", \\\"{x:1056,y:820,t:1512065438794};\\\", \\\"{x:1064,y:815,t:1512065438811};\\\", \\\"{x:1080,y:808,t:1512065438828};\\\", \\\"{x:1089,y:804,t:1512065438844};\\\", \\\"{x:1107,y:797,t:1512065438861};\\\", \\\"{x:1121,y:793,t:1512065438878};\\\", \\\"{x:1131,y:790,t:1512065438894};\\\", \\\"{x:1139,y:787,t:1512065438911};\\\", \\\"{x:1144,y:786,t:1512065438928};\\\", \\\"{x:1150,y:783,t:1512065438944};\\\", \\\"{x:1156,y:782,t:1512065438961};\\\", \\\"{x:1160,y:779,t:1512065438978};\\\", \\\"{x:1164,y:779,t:1512065438994};\\\", \\\"{x:1173,y:778,t:1512065439011};\\\", \\\"{x:1182,y:776,t:1512065439028};\\\", \\\"{x:1186,y:775,t:1512065439045};\\\", \\\"{x:1188,y:774,t:1512065439061};\\\", \\\"{x:1190,y:774,t:1512065439078};\\\", \\\"{x:1191,y:773,t:1512065439098};\\\", \\\"{x:1191,y:772,t:1512065439146};\\\", \\\"{x:1190,y:772,t:1512065439162};\\\", \\\"{x:1187,y:772,t:1512065439179};\\\", \\\"{x:1186,y:772,t:1512065439195};\\\", \\\"{x:1184,y:772,t:1512065439211};\\\", \\\"{x:1183,y:772,t:1512065439229};\\\", \\\"{x:1180,y:773,t:1512065439246};\\\", \\\"{x:1178,y:773,t:1512065439262};\\\", \\\"{x:1177,y:773,t:1512065439278};\\\", \\\"{x:1174,y:773,t:1512065439296};\\\", \\\"{x:1171,y:773,t:1512065439311};\\\", \\\"{x:1167,y:773,t:1512065439329};\\\", \\\"{x:1162,y:773,t:1512065439345};\\\", \\\"{x:1157,y:771,t:1512065439361};\\\", \\\"{x:1152,y:768,t:1512065439378};\\\", \\\"{x:1149,y:768,t:1512065439396};\\\", \\\"{x:1148,y:767,t:1512065439411};\\\", \\\"{x:1145,y:766,t:1512065439435};\\\", \\\"{x:1143,y:765,t:1512065439445};\\\", \\\"{x:1142,y:764,t:1512065439461};\\\", \\\"{x:1114,y:764,t:1512065441958};\\\", \\\"{x:1049,y:755,t:1512065441963};\\\", \\\"{x:971,y:736,t:1512065441980};\\\", \\\"{x:953,y:730,t:1512065441997};\\\", \\\"{x:937,y:730,t:1512065442013};\\\", \\\"{x:906,y:730,t:1512065442030};\\\", \\\"{x:861,y:723,t:1512065442047};\\\", \\\"{x:822,y:717,t:1512065442063};\\\", \\\"{x:755,y:707,t:1512065442080};\\\", \\\"{x:677,y:695,t:1512065442096};\\\", \\\"{x:655,y:694,t:1512065442113};\\\", \\\"{x:647,y:694,t:1512065442130};\\\", \\\"{x:640,y:694,t:1512065442147};\\\", \\\"{x:630,y:694,t:1512065442163};\\\", \\\"{x:620,y:694,t:1512065442180};\\\", \\\"{x:612,y:694,t:1512065442197};\\\", \\\"{x:611,y:694,t:1512065442217};\\\", \\\"{x:609,y:694,t:1512065442230};\\\", \\\"{x:602,y:693,t:1512065442247};\\\", \\\"{x:589,y:689,t:1512065442263};\\\", \\\"{x:573,y:683,t:1512065442280};\\\", \\\"{x:562,y:679,t:1512065442297};\\\", \\\"{x:560,y:678,t:1512065442313};\\\", \\\"{x:556,y:674,t:1512065442330};\\\", \\\"{x:553,y:670,t:1512065442347};\\\", \\\"{x:549,y:666,t:1512065442363};\\\", \\\"{x:547,y:665,t:1512065442380};\\\", \\\"{x:547,y:664,t:1512065442397};\\\", \\\"{x:544,y:661,t:1512065442414};\\\", \\\"{x:543,y:660,t:1512065442430};\\\", \\\"{x:539,y:656,t:1512065442448};\\\", \\\"{x:537,y:654,t:1512065442464};\\\", \\\"{x:535,y:653,t:1512065442480};\\\", \\\"{x:534,y:652,t:1512065442497};\\\", \\\"{x:534,y:651,t:1512065442586};\\\", \\\"{x:539,y:650,t:1512065442597};\\\", \\\"{x:557,y:647,t:1512065442615};\\\", \\\"{x:575,y:645,t:1512065442631};\\\", \\\"{x:589,y:644,t:1512065442647};\\\", \\\"{x:605,y:640,t:1512065442665};\\\", \\\"{x:615,y:639,t:1512065442681};\\\", \\\"{x:623,y:639,t:1512065442697};\\\", \\\"{x:625,y:639,t:1512065442714};\\\", \\\"{x:626,y:639,t:1512065442738};\\\", \\\"{x:626,y:638,t:1512065442747};\\\", \\\"{x:627,y:636,t:1512065442765};\\\", \\\"{x:627,y:635,t:1512065442781};\\\", \\\"{x:627,y:634,t:1512065442801};\\\", \\\"{x:627,y:633,t:1512065442817};\\\", \\\"{x:627,y:632,t:1512065442841};\\\", \\\"{x:626,y:632,t:1512065442890};\\\", \\\"{x:625,y:631,t:1512065442897};\\\", \\\"{x:619,y:631,t:1512065442914};\\\", \\\"{x:614,y:631,t:1512065442931};\\\", \\\"{x:610,y:631,t:1512065442947};\\\", \\\"{x:606,y:631,t:1512065442964};\\\", \\\"{x:604,y:632,t:1512065442981};\\\", \\\"{x:600,y:633,t:1512065442997};\\\", \\\"{x:597,y:635,t:1512065443014};\\\", \\\"{x:593,y:636,t:1512065443032};\\\", \\\"{x:590,y:636,t:1512065443047};\\\", \\\"{x:589,y:637,t:1512065443129};\\\", \\\"{x:588,y:637,t:1512065443377};\\\", \\\"{x:588,y:637,t:1512065443450};\\\", \\\"{x:587,y:638,t:1512065443561};\\\", \\\"{x:586,y:639,t:1512065443569};\\\", \\\"{x:582,y:641,t:1512065443581};\\\", \\\"{x:576,y:645,t:1512065443598};\\\", \\\"{x:575,y:646,t:1512065443625};\\\", \\\"{x:574,y:646,t:1512065443698};\\\", \\\"{x:571,y:648,t:1512065443715};\\\", \\\"{x:567,y:651,t:1512065443731};\\\", \\\"{x:563,y:654,t:1512065443748};\\\", \\\"{x:551,y:659,t:1512065443765};\\\", \\\"{x:528,y:668,t:1512065443781};\\\", \\\"{x:498,y:682,t:1512065443798};\\\", \\\"{x:474,y:692,t:1512065443815};\\\", \\\"{x:449,y:702,t:1512065443832};\\\", \\\"{x:431,y:704,t:1512065443848};\\\", \\\"{x:417,y:704,t:1512065443865};\\\", \\\"{x:417,y:703,t:1512065443881};\\\", \\\"{x:417,y:704,t:1512065443938};\\\", \\\"{x:416,y:707,t:1512065443949};\\\", \\\"{x:415,y:716,t:1512065443965};\\\", \\\"{x:414,y:719,t:1512065443983};\\\", \\\"{x:414,y:717,t:1512065444154};\\\", \\\"{x:414,y:716,t:1512065444166};\\\", \\\"{x:416,y:712,t:1512065444183};\\\", \\\"{x:416,y:710,t:1512065444198};\\\", \\\"{x:417,y:709,t:1512065444215};\\\", \\\"{x:419,y:706,t:1512065444233};\\\", \\\"{x:420,y:705,t:1512065444265};\\\", \\\"{x:422,y:705,t:1512065444569};\\\", \\\"{x:423,y:705,t:1512065444585};\\\", \\\"{x:425,y:705,t:1512065444599};\\\", \\\"{x:430,y:705,t:1512065444615};\\\", \\\"{x:444,y:708,t:1512065444632};\\\", \\\"{x:470,y:719,t:1512065444649};\\\", \\\"{x:490,y:728,t:1512065444665};\\\", \\\"{x:508,y:735,t:1512065444682};\\\", \\\"{x:533,y:742,t:1512065444699};\\\", \\\"{x:574,y:750,t:1512065444716};\\\", \\\"{x:613,y:755,t:1512065444732};\\\", \\\"{x:648,y:760,t:1512065444749};\\\", \\\"{x:699,y:768,t:1512065444765};\\\", \\\"{x:755,y:776,t:1512065444782};\\\", \\\"{x:805,y:782,t:1512065444799};\\\", \\\"{x:855,y:782,t:1512065444816};\\\", \\\"{x:891,y:782,t:1512065444832};\\\", \\\"{x:923,y:780,t:1512065444849};\\\", \\\"{x:926,y:778,t:1512065444866};\\\", \\\"{x:927,y:777,t:1512065444882};\\\", \\\"{x:930,y:774,t:1512065444899};\\\", \\\"{x:934,y:771,t:1512065444916};\\\", \\\"{x:937,y:765,t:1512065444932};\\\", \\\"{x:941,y:759,t:1512065444949};\\\", \\\"{x:945,y:752,t:1512065444966};\\\", \\\"{x:952,y:743,t:1512065444982};\\\", \\\"{x:954,y:740,t:1512065444999};\\\", \\\"{x:955,y:739,t:1512065445016};\\\" ] }, { \\\"rt\\\": 14667, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 223564, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-8-6-D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:955,y:734,t:1512065446217};\\\", \\\"{x:955,y:702,t:1512065446233};\\\", \\\"{x:949,y:674,t:1512065446250};\\\", \\\"{x:946,y:650,t:1512065446267};\\\", \\\"{x:943,y:633,t:1512065446283};\\\", \\\"{x:941,y:620,t:1512065446300};\\\", \\\"{x:939,y:605,t:1512065446317};\\\", \\\"{x:937,y:585,t:1512065446333};\\\", \\\"{x:932,y:570,t:1512065446350};\\\", \\\"{x:930,y:552,t:1512065446367};\\\", \\\"{x:926,y:537,t:1512065446383};\\\", \\\"{x:920,y:523,t:1512065446400};\\\", \\\"{x:904,y:496,t:1512065446417};\\\", \\\"{x:895,y:483,t:1512065446434};\\\", \\\"{x:891,y:473,t:1512065446450};\\\", \\\"{x:886,y:465,t:1512065446467};\\\", \\\"{x:878,y:454,t:1512065446484};\\\", \\\"{x:875,y:451,t:1512065446501};\\\", \\\"{x:872,y:446,t:1512065446518};\\\", \\\"{x:865,y:441,t:1512065446535};\\\", \\\"{x:853,y:436,t:1512065446551};\\\", \\\"{x:840,y:432,t:1512065446568};\\\", \\\"{x:836,y:431,t:1512065446585};\\\", \\\"{x:834,y:429,t:1512065446601};\\\", \\\"{x:823,y:427,t:1512065446617};\\\", \\\"{x:815,y:426,t:1512065446636};\\\", \\\"{x:805,y:425,t:1512065446651};\\\", \\\"{x:787,y:425,t:1512065446668};\\\", \\\"{x:768,y:425,t:1512065446685};\\\", \\\"{x:741,y:425,t:1512065446701};\\\", \\\"{x:717,y:425,t:1512065446717};\\\", \\\"{x:695,y:426,t:1512065446734};\\\", \\\"{x:674,y:428,t:1512065446750};\\\", \\\"{x:650,y:433,t:1512065446767};\\\", \\\"{x:628,y:436,t:1512065446785};\\\", \\\"{x:608,y:438,t:1512065446801};\\\", \\\"{x:576,y:443,t:1512065446818};\\\", \\\"{x:560,y:445,t:1512065446834};\\\", \\\"{x:543,y:450,t:1512065446851};\\\", \\\"{x:533,y:453,t:1512065446867};\\\", \\\"{x:525,y:455,t:1512065446884};\\\", \\\"{x:521,y:456,t:1512065446901};\\\", \\\"{x:516,y:457,t:1512065446917};\\\", \\\"{x:514,y:457,t:1512065446934};\\\", \\\"{x:508,y:457,t:1512065446951};\\\", \\\"{x:502,y:458,t:1512065446968};\\\", \\\"{x:493,y:459,t:1512065446984};\\\", \\\"{x:475,y:461,t:1512065447000};\\\", \\\"{x:458,y:463,t:1512065447017};\\\", \\\"{x:445,y:466,t:1512065447034};\\\", \\\"{x:437,y:467,t:1512065447051};\\\", \\\"{x:434,y:468,t:1512065447067};\\\", \\\"{x:432,y:470,t:1512065447084};\\\", \\\"{x:429,y:471,t:1512065447101};\\\", \\\"{x:428,y:471,t:1512065447117};\\\", \\\"{x:427,y:471,t:1512065447145};\\\", \\\"{x:426,y:472,t:1512065447185};\\\", \\\"{x:425,y:473,t:1512065447201};\\\", \\\"{x:422,y:475,t:1512065447217};\\\", \\\"{x:419,y:477,t:1512065447234};\\\", \\\"{x:418,y:478,t:1512065447251};\\\", \\\"{x:416,y:481,t:1512065447267};\\\", \\\"{x:413,y:485,t:1512065447284};\\\", \\\"{x:411,y:487,t:1512065447302};\\\", \\\"{x:409,y:490,t:1512065447318};\\\", \\\"{x:406,y:495,t:1512065447334};\\\", \\\"{x:402,y:500,t:1512065447352};\\\", \\\"{x:400,y:503,t:1512065447368};\\\", \\\"{x:397,y:507,t:1512065447385};\\\", \\\"{x:395,y:512,t:1512065447401};\\\", \\\"{x:394,y:513,t:1512065447418};\\\", \\\"{x:394,y:514,t:1512065447457};\\\", \\\"{x:394,y:515,t:1512065447473};\\\", \\\"{x:394,y:516,t:1512065447513};\\\", \\\"{x:394,y:517,t:1512065447593};\\\", \\\"{x:393,y:518,t:1512065447602};\\\", \\\"{x:393,y:519,t:1512065447618};\\\", \\\"{x:393,y:520,t:1512065447641};\\\", \\\"{x:393,y:521,t:1512065447651};\\\", \\\"{x:393,y:522,t:1512065447669};\\\", \\\"{x:393,y:523,t:1512065447729};\\\", \\\"{x:393,y:525,t:1512065447778};\\\", \\\"{x:393,y:526,t:1512065447793};\\\", \\\"{x:395,y:527,t:1512065447801};\\\", \\\"{x:396,y:528,t:1512065447819};\\\", \\\"{x:399,y:530,t:1512065447836};\\\", \\\"{x:401,y:531,t:1512065447851};\\\", \\\"{x:414,y:535,t:1512065447868};\\\", \\\"{x:435,y:539,t:1512065447885};\\\", \\\"{x:448,y:541,t:1512065447902};\\\", \\\"{x:460,y:542,t:1512065447919};\\\", \\\"{x:466,y:543,t:1512065447936};\\\", \\\"{x:468,y:543,t:1512065447951};\\\", \\\"{x:469,y:543,t:1512065447969};\\\", \\\"{x:473,y:543,t:1512065447985};\\\", \\\"{x:480,y:543,t:1512065448001};\\\", \\\"{x:500,y:543,t:1512065448018};\\\", \\\"{x:522,y:543,t:1512065448036};\\\", \\\"{x:546,y:543,t:1512065448051};\\\", \\\"{x:574,y:543,t:1512065448068};\\\", \\\"{x:602,y:543,t:1512065448086};\\\", \\\"{x:642,y:546,t:1512065448102};\\\", \\\"{x:696,y:549,t:1512065448118};\\\", \\\"{x:752,y:551,t:1512065448136};\\\", \\\"{x:818,y:558,t:1512065448152};\\\", \\\"{x:900,y:567,t:1512065448170};\\\", \\\"{x:942,y:573,t:1512065448185};\\\", \\\"{x:995,y:581,t:1512065448202};\\\", \\\"{x:1045,y:587,t:1512065448219};\\\", \\\"{x:1104,y:595,t:1512065448236};\\\", \\\"{x:1157,y:603,t:1512065448253};\\\", \\\"{x:1188,y:608,t:1512065448269};\\\", \\\"{x:1212,y:611,t:1512065448286};\\\", \\\"{x:1227,y:614,t:1512065448303};\\\", \\\"{x:1236,y:615,t:1512065448319};\\\", \\\"{x:1240,y:615,t:1512065448336};\\\", \\\"{x:1241,y:616,t:1512065448353};\\\", \\\"{x:1237,y:616,t:1512065449258};\\\", \\\"{x:1225,y:616,t:1512065449270};\\\", \\\"{x:1200,y:616,t:1512065449287};\\\", \\\"{x:1178,y:616,t:1512065449303};\\\", \\\"{x:1155,y:616,t:1512065449320};\\\", \\\"{x:1130,y:616,t:1512065449337};\\\", \\\"{x:1125,y:614,t:1512065449353};\\\", \\\"{x:1113,y:613,t:1512065449370};\\\", \\\"{x:1104,y:611,t:1512065449387};\\\", \\\"{x:1095,y:610,t:1512065449403};\\\", \\\"{x:1086,y:609,t:1512065449420};\\\", \\\"{x:1072,y:607,t:1512065449437};\\\", \\\"{x:1050,y:603,t:1512065449453};\\\", \\\"{x:1026,y:602,t:1512065449470};\\\", \\\"{x:1007,y:602,t:1512065449487};\\\", \\\"{x:989,y:601,t:1512065449503};\\\", \\\"{x:961,y:598,t:1512065449520};\\\", \\\"{x:929,y:593,t:1512065449537};\\\", \\\"{x:918,y:592,t:1512065449553};\\\", \\\"{x:904,y:590,t:1512065449570};\\\", \\\"{x:894,y:589,t:1512065449587};\\\", \\\"{x:884,y:588,t:1512065449604};\\\", \\\"{x:869,y:586,t:1512065449620};\\\", \\\"{x:855,y:582,t:1512065449637};\\\", \\\"{x:837,y:577,t:1512065449654};\\\", \\\"{x:820,y:572,t:1512065449670};\\\", \\\"{x:800,y:566,t:1512065449687};\\\", \\\"{x:785,y:565,t:1512065449704};\\\", \\\"{x:770,y:558,t:1512065449719};\\\", \\\"{x:756,y:555,t:1512065449737};\\\", \\\"{x:741,y:549,t:1512065449753};\\\", \\\"{x:727,y:545,t:1512065449770};\\\", \\\"{x:718,y:541,t:1512065449786};\\\", \\\"{x:708,y:537,t:1512065449803};\\\", \\\"{x:690,y:529,t:1512065449819};\\\", \\\"{x:673,y:523,t:1512065449836};\\\", \\\"{x:661,y:517,t:1512065449853};\\\", \\\"{x:653,y:514,t:1512065449869};\\\", \\\"{x:645,y:512,t:1512065449886};\\\", \\\"{x:639,y:510,t:1512065449903};\\\", \\\"{x:632,y:507,t:1512065449920};\\\", \\\"{x:624,y:503,t:1512065449937};\\\", \\\"{x:617,y:501,t:1512065449953};\\\", \\\"{x:610,y:499,t:1512065449970};\\\", \\\"{x:605,y:497,t:1512065449986};\\\", \\\"{x:601,y:497,t:1512065450003};\\\", \\\"{x:594,y:495,t:1512065450021};\\\", \\\"{x:589,y:494,t:1512065450036};\\\", \\\"{x:582,y:493,t:1512065450053};\\\", \\\"{x:577,y:493,t:1512065450070};\\\", \\\"{x:572,y:492,t:1512065450086};\\\", \\\"{x:568,y:492,t:1512065450103};\\\", \\\"{x:566,y:492,t:1512065450121};\\\", \\\"{x:563,y:492,t:1512065450137};\\\", \\\"{x:560,y:492,t:1512065450153};\\\", \\\"{x:557,y:492,t:1512065450170};\\\", \\\"{x:552,y:493,t:1512065450186};\\\", \\\"{x:549,y:495,t:1512065450203};\\\", \\\"{x:545,y:495,t:1512065450220};\\\", \\\"{x:542,y:496,t:1512065450236};\\\", \\\"{x:539,y:498,t:1512065450253};\\\", \\\"{x:536,y:499,t:1512065450270};\\\", \\\"{x:531,y:501,t:1512065450286};\\\", \\\"{x:529,y:503,t:1512065450303};\\\", \\\"{x:524,y:506,t:1512065450320};\\\", \\\"{x:520,y:509,t:1512065450337};\\\", \\\"{x:513,y:514,t:1512065450353};\\\", \\\"{x:509,y:516,t:1512065450370};\\\", \\\"{x:507,y:518,t:1512065450386};\\\", \\\"{x:505,y:519,t:1512065450403};\\\", \\\"{x:503,y:522,t:1512065450420};\\\", \\\"{x:498,y:525,t:1512065450437};\\\", \\\"{x:493,y:528,t:1512065450453};\\\", \\\"{x:489,y:531,t:1512065450470};\\\", \\\"{x:484,y:534,t:1512065450487};\\\", \\\"{x:482,y:536,t:1512065450503};\\\", \\\"{x:480,y:536,t:1512065450520};\\\", \\\"{x:479,y:537,t:1512065450537};\\\", \\\"{x:477,y:538,t:1512065450561};\\\", \\\"{x:476,y:539,t:1512065450601};\\\", \\\"{x:475,y:539,t:1512065450681};\\\", \\\"{x:478,y:539,t:1512065450833};\\\", \\\"{x:483,y:539,t:1512065450841};\\\", \\\"{x:491,y:539,t:1512065450854};\\\", \\\"{x:513,y:539,t:1512065450870};\\\", \\\"{x:536,y:539,t:1512065450888};\\\", \\\"{x:570,y:539,t:1512065450905};\\\", \\\"{x:591,y:539,t:1512065450921};\\\", \\\"{x:612,y:539,t:1512065450937};\\\", \\\"{x:633,y:539,t:1512065450955};\\\", \\\"{x:653,y:539,t:1512065450971};\\\", \\\"{x:675,y:539,t:1512065450987};\\\", \\\"{x:701,y:539,t:1512065451004};\\\", \\\"{x:739,y:539,t:1512065451020};\\\", \\\"{x:784,y:539,t:1512065451038};\\\", \\\"{x:824,y:546,t:1512065451055};\\\", \\\"{x:862,y:548,t:1512065451071};\\\", \\\"{x:889,y:553,t:1512065451088};\\\", \\\"{x:921,y:557,t:1512065451105};\\\", \\\"{x:940,y:559,t:1512065451121};\\\", \\\"{x:957,y:562,t:1512065451138};\\\", \\\"{x:976,y:564,t:1512065451155};\\\", \\\"{x:991,y:568,t:1512065451171};\\\", \\\"{x:1005,y:570,t:1512065451188};\\\", \\\"{x:1015,y:572,t:1512065451205};\\\", \\\"{x:1024,y:574,t:1512065451221};\\\", \\\"{x:1032,y:576,t:1512065451238};\\\", \\\"{x:1035,y:576,t:1512065451255};\\\", \\\"{x:1040,y:578,t:1512065451271};\\\", \\\"{x:1042,y:579,t:1512065451288};\\\", \\\"{x:1047,y:580,t:1512065451305};\\\", \\\"{x:1051,y:581,t:1512065451321};\\\", \\\"{x:1055,y:582,t:1512065451338};\\\", \\\"{x:1063,y:585,t:1512065451355};\\\", \\\"{x:1070,y:588,t:1512065451372};\\\", \\\"{x:1079,y:591,t:1512065451388};\\\", \\\"{x:1086,y:594,t:1512065451405};\\\", \\\"{x:1091,y:597,t:1512065451422};\\\", \\\"{x:1096,y:598,t:1512065451438};\\\", \\\"{x:1103,y:599,t:1512065451455};\\\", \\\"{x:1107,y:601,t:1512065451472};\\\", \\\"{x:1110,y:602,t:1512065451488};\\\", \\\"{x:1115,y:603,t:1512065451505};\\\", \\\"{x:1118,y:605,t:1512065451521};\\\", \\\"{x:1119,y:605,t:1512065451538};\\\", \\\"{x:1121,y:605,t:1512065451555};\\\", \\\"{x:1124,y:606,t:1512065451572};\\\", \\\"{x:1127,y:609,t:1512065451588};\\\", \\\"{x:1128,y:610,t:1512065451605};\\\", \\\"{x:1131,y:611,t:1512065451622};\\\", \\\"{x:1134,y:613,t:1512065451638};\\\", \\\"{x:1138,y:616,t:1512065451655};\\\", \\\"{x:1142,y:617,t:1512065451672};\\\", \\\"{x:1146,y:619,t:1512065451688};\\\", \\\"{x:1150,y:620,t:1512065451705};\\\", \\\"{x:1150,y:621,t:1512065451722};\\\", \\\"{x:1152,y:622,t:1512065451738};\\\", \\\"{x:1153,y:622,t:1512065451755};\\\", \\\"{x:1154,y:623,t:1512065451785};\\\", \\\"{x:1155,y:624,t:1512065451809};\\\", \\\"{x:1156,y:624,t:1512065451833};\\\", \\\"{x:1157,y:624,t:1512065451873};\\\", \\\"{x:1158,y:625,t:1512065453425};\\\", \\\"{x:1165,y:621,t:1512065453440};\\\", \\\"{x:1180,y:609,t:1512065453456};\\\", \\\"{x:1202,y:596,t:1512065453473};\\\", \\\"{x:1212,y:592,t:1512065453489};\\\", \\\"{x:1221,y:586,t:1512065453506};\\\", \\\"{x:1228,y:582,t:1512065453523};\\\", \\\"{x:1239,y:578,t:1512065453540};\\\", \\\"{x:1250,y:571,t:1512065453557};\\\", \\\"{x:1268,y:557,t:1512065453572};\\\", \\\"{x:1287,y:542,t:1512065453590};\\\", \\\"{x:1310,y:524,t:1512065453607};\\\", \\\"{x:1329,y:511,t:1512065453623};\\\", \\\"{x:1339,y:502,t:1512065453640};\\\", \\\"{x:1344,y:495,t:1512065453657};\\\", \\\"{x:1346,y:490,t:1512065453673};\\\", \\\"{x:1349,y:483,t:1512065453689};\\\", \\\"{x:1352,y:474,t:1512065453707};\\\", \\\"{x:1355,y:469,t:1512065453723};\\\", \\\"{x:1356,y:467,t:1512065453740};\\\", \\\"{x:1356,y:466,t:1512065453757};\\\", \\\"{x:1357,y:465,t:1512065453841};\\\", \\\"{x:1358,y:463,t:1512065453857};\\\", \\\"{x:1360,y:461,t:1512065453873};\\\", \\\"{x:1362,y:457,t:1512065453890};\\\", \\\"{x:1362,y:455,t:1512065453907};\\\", \\\"{x:1363,y:453,t:1512065453925};\\\", \\\"{x:1363,y:452,t:1512065453940};\\\", \\\"{x:1364,y:452,t:1512065453984};\\\", \\\"{x:1365,y:450,t:1512065454000};\\\", \\\"{x:1366,y:449,t:1512065454008};\\\", \\\"{x:1366,y:447,t:1512065454023};\\\", \\\"{x:1366,y:446,t:1512065454039};\\\", \\\"{x:1368,y:443,t:1512065454056};\\\", \\\"{x:1369,y:441,t:1512065454080};\\\", \\\"{x:1369,y:440,t:1512065454096};\\\", \\\"{x:1370,y:439,t:1512065454106};\\\", \\\"{x:1373,y:437,t:1512065454123};\\\", \\\"{x:1373,y:435,t:1512065454139};\\\", \\\"{x:1375,y:434,t:1512065454168};\\\", \\\"{x:1375,y:433,t:1512065454206};\\\", \\\"{x:1377,y:430,t:1512065454352};\\\", \\\"{x:1377,y:428,t:1512065454368};\\\", \\\"{x:1378,y:427,t:1512065454376};\\\", \\\"{x:1364,y:428,t:1512065457915};\\\", \\\"{x:1292,y:448,t:1512065457927};\\\", \\\"{x:1231,y:465,t:1512065457943};\\\", \\\"{x:1170,y:491,t:1512065457960};\\\", \\\"{x:1058,y:527,t:1512065457977};\\\", \\\"{x:1003,y:542,t:1512065457994};\\\", \\\"{x:952,y:551,t:1512065458010};\\\", \\\"{x:914,y:558,t:1512065458027};\\\", \\\"{x:888,y:569,t:1512065458044};\\\", \\\"{x:861,y:576,t:1512065458060};\\\", \\\"{x:826,y:586,t:1512065458077};\\\", \\\"{x:783,y:601,t:1512065458094};\\\", \\\"{x:744,y:612,t:1512065458110};\\\", \\\"{x:700,y:630,t:1512065458128};\\\", \\\"{x:676,y:642,t:1512065458144};\\\", \\\"{x:655,y:651,t:1512065458160};\\\", \\\"{x:640,y:656,t:1512065458177};\\\", \\\"{x:633,y:658,t:1512065458194};\\\", \\\"{x:629,y:659,t:1512065458210};\\\", \\\"{x:626,y:660,t:1512065458227};\\\", \\\"{x:619,y:663,t:1512065458244};\\\", \\\"{x:606,y:664,t:1512065458260};\\\", \\\"{x:589,y:664,t:1512065458277};\\\", \\\"{x:563,y:664,t:1512065458294};\\\", \\\"{x:534,y:660,t:1512065458310};\\\", \\\"{x:505,y:658,t:1512065458328};\\\", \\\"{x:487,y:654,t:1512065458345};\\\", \\\"{x:474,y:653,t:1512065458361};\\\", \\\"{x:465,y:649,t:1512065458377};\\\", \\\"{x:461,y:644,t:1512065458395};\\\", \\\"{x:458,y:640,t:1512065458410};\\\", \\\"{x:457,y:637,t:1512065458427};\\\", \\\"{x:455,y:632,t:1512065458444};\\\", \\\"{x:455,y:629,t:1512065458461};\\\", \\\"{x:455,y:623,t:1512065458477};\\\", \\\"{x:459,y:614,t:1512065458495};\\\", \\\"{x:463,y:610,t:1512065458511};\\\", \\\"{x:475,y:604,t:1512065458527};\\\", \\\"{x:489,y:597,t:1512065458545};\\\", \\\"{x:510,y:592,t:1512065458561};\\\", \\\"{x:526,y:591,t:1512065458577};\\\", \\\"{x:541,y:589,t:1512065458594};\\\", \\\"{x:557,y:589,t:1512065458612};\\\", \\\"{x:570,y:589,t:1512065458627};\\\", \\\"{x:580,y:589,t:1512065458644};\\\", \\\"{x:583,y:589,t:1512065458661};\\\", \\\"{x:585,y:589,t:1512065458681};\\\", \\\"{x:586,y:589,t:1512065458694};\\\", \\\"{x:589,y:589,t:1512065458711};\\\", \\\"{x:592,y:591,t:1512065458727};\\\", \\\"{x:594,y:591,t:1512065458744};\\\", \\\"{x:596,y:592,t:1512065458761};\\\", \\\"{x:596,y:593,t:1512065458793};\\\", \\\"{x:596,y:594,t:1512065458801};\\\", \\\"{x:596,y:595,t:1512065458817};\\\", \\\"{x:597,y:597,t:1512065458827};\\\", \\\"{x:597,y:599,t:1512065458849};\\\", \\\"{x:598,y:600,t:1512065458861};\\\", \\\"{x:599,y:602,t:1512065458877};\\\", \\\"{x:600,y:604,t:1512065458894};\\\", \\\"{x:600,y:605,t:1512065458911};\\\", \\\"{x:600,y:606,t:1512065458928};\\\", \\\"{x:600,y:607,t:1512065458953};\\\", \\\"{x:599,y:608,t:1512065458994};\\\", \\\"{x:599,y:609,t:1512065459025};\\\", \\\"{x:598,y:609,t:1512065459058};\\\", \\\"{x:597,y:609,t:1512065459065};\\\", \\\"{x:596,y:609,t:1512065459089};\\\", \\\"{x:594,y:609,t:1512065459146};\\\", \\\"{x:593,y:609,t:1512065459169};\\\", \\\"{x:591,y:609,t:1512065459186};\\\", \\\"{x:591,y:608,t:1512065459201};\\\", \\\"{x:590,y:608,t:1512065459211};\\\", \\\"{x:589,y:607,t:1512065459233};\\\", \\\"{x:588,y:606,t:1512065459337};\\\", \\\"{x:587,y:606,t:1512065459553};\\\", \\\"{x:586,y:606,t:1512065459585};\\\", \\\"{x:584,y:606,t:1512065459641};\\\", \\\"{x:580,y:607,t:1512065459657};\\\", \\\"{x:571,y:612,t:1512065459665};\\\", \\\"{x:563,y:615,t:1512065459678};\\\", \\\"{x:549,y:624,t:1512065459695};\\\", \\\"{x:541,y:630,t:1512065459712};\\\", \\\"{x:534,y:635,t:1512065459728};\\\", \\\"{x:520,y:646,t:1512065459745};\\\", \\\"{x:514,y:651,t:1512065459762};\\\", \\\"{x:510,y:655,t:1512065459778};\\\", \\\"{x:505,y:660,t:1512065459795};\\\", \\\"{x:497,y:666,t:1512065459812};\\\", \\\"{x:488,y:674,t:1512065459828};\\\", \\\"{x:479,y:680,t:1512065459845};\\\", \\\"{x:471,y:686,t:1512065459862};\\\", \\\"{x:465,y:688,t:1512065459878};\\\", \\\"{x:462,y:691,t:1512065459895};\\\", \\\"{x:460,y:691,t:1512065459912};\\\", \\\"{x:457,y:693,t:1512065459928};\\\", \\\"{x:453,y:694,t:1512065459945};\\\", \\\"{x:448,y:697,t:1512065459962};\\\", \\\"{x:444,y:699,t:1512065459978};\\\", \\\"{x:440,y:701,t:1512065459995};\\\", \\\"{x:438,y:701,t:1512065460012};\\\", \\\"{x:437,y:701,t:1512065460028};\\\", \\\"{x:436,y:702,t:1512065460045};\\\", \\\"{x:435,y:702,t:1512065460062};\\\", \\\"{x:434,y:703,t:1512065460078};\\\", \\\"{x:432,y:705,t:1512065460095};\\\", \\\"{x:430,y:705,t:1512065460113};\\\", \\\"{x:426,y:708,t:1512065460129};\\\", \\\"{x:425,y:708,t:1512065460154};\\\", \\\"{x:424,y:709,t:1512065460169};\\\", \\\"{x:425,y:709,t:1512065460553};\\\", \\\"{x:427,y:709,t:1512065460577};\\\", \\\"{x:431,y:709,t:1512065460585};\\\", \\\"{x:437,y:709,t:1512065460596};\\\", \\\"{x:445,y:709,t:1512065460612};\\\", \\\"{x:453,y:711,t:1512065460629};\\\", \\\"{x:467,y:715,t:1512065460646};\\\", \\\"{x:485,y:721,t:1512065460662};\\\", \\\"{x:502,y:728,t:1512065460679};\\\", \\\"{x:528,y:735,t:1512065460696};\\\", \\\"{x:564,y:745,t:1512065460712};\\\", \\\"{x:635,y:761,t:1512065460729};\\\", \\\"{x:672,y:766,t:1512065460746};\\\", \\\"{x:702,y:769,t:1512065460762};\\\", \\\"{x:730,y:774,t:1512065460779};\\\", \\\"{x:765,y:774,t:1512065460796};\\\", \\\"{x:792,y:774,t:1512065460812};\\\", \\\"{x:815,y:774,t:1512065460829};\\\", \\\"{x:837,y:774,t:1512065460846};\\\", \\\"{x:854,y:774,t:1512065460862};\\\", \\\"{x:865,y:774,t:1512065460879};\\\", \\\"{x:872,y:773,t:1512065460896};\\\", \\\"{x:877,y:772,t:1512065460913};\\\", \\\"{x:882,y:772,t:1512065460929};\\\", \\\"{x:885,y:769,t:1512065460946};\\\", \\\"{x:887,y:769,t:1512065460962};\\\", \\\"{x:890,y:766,t:1512065460979};\\\", \\\"{x:893,y:764,t:1512065460996};\\\", \\\"{x:895,y:762,t:1512065461012};\\\", \\\"{x:898,y:759,t:1512065461029};\\\", \\\"{x:900,y:758,t:1512065461046};\\\", \\\"{x:900,y:757,t:1512065461062};\\\", \\\"{x:901,y:756,t:1512065461079};\\\", \\\"{x:902,y:754,t:1512065461096};\\\", \\\"{x:905,y:751,t:1512065461113};\\\", \\\"{x:906,y:750,t:1512065461129};\\\", \\\"{x:907,y:749,t:1512065461146};\\\", \\\"{x:908,y:748,t:1512065461169};\\\", \\\"{x:908,y:747,t:1512065461266};\\\" ] }, { \\\"rt\\\": 11623, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 236460, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-C -F -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:909,y:747,t:1512065463354};\\\", \\\"{x:904,y:741,t:1512065463364};\\\", \\\"{x:861,y:694,t:1512065463381};\\\", \\\"{x:792,y:645,t:1512065463398};\\\", \\\"{x:718,y:605,t:1512065463414};\\\", \\\"{x:650,y:576,t:1512065463431};\\\", \\\"{x:585,y:544,t:1512065463448};\\\", \\\"{x:519,y:516,t:1512065463464};\\\", \\\"{x:439,y:466,t:1512065463481};\\\", \\\"{x:404,y:447,t:1512065463498};\\\", \\\"{x:379,y:432,t:1512065463514};\\\", \\\"{x:359,y:418,t:1512065463531};\\\", \\\"{x:347,y:410,t:1512065463548};\\\", \\\"{x:333,y:403,t:1512065463564};\\\", \\\"{x:320,y:398,t:1512065463581};\\\", \\\"{x:293,y:385,t:1512065463598};\\\", \\\"{x:268,y:374,t:1512065463614};\\\", \\\"{x:246,y:363,t:1512065463631};\\\", \\\"{x:244,y:361,t:1512065463648};\\\", \\\"{x:243,y:361,t:1512065463713};\\\", \\\"{x:247,y:358,t:1512065463720};\\\", \\\"{x:258,y:357,t:1512065463731};\\\", \\\"{x:290,y:356,t:1512065463748};\\\", \\\"{x:330,y:356,t:1512065463764};\\\", \\\"{x:372,y:356,t:1512065463781};\\\", \\\"{x:417,y:356,t:1512065463798};\\\", \\\"{x:448,y:360,t:1512065463815};\\\", \\\"{x:471,y:362,t:1512065463831};\\\", \\\"{x:492,y:365,t:1512065463848};\\\", \\\"{x:511,y:370,t:1512065463865};\\\", \\\"{x:516,y:371,t:1512065463881};\\\", \\\"{x:522,y:372,t:1512065463898};\\\", \\\"{x:533,y:374,t:1512065463915};\\\", \\\"{x:546,y:375,t:1512065463931};\\\", \\\"{x:557,y:375,t:1512065463948};\\\", \\\"{x:567,y:374,t:1512065463965};\\\", \\\"{x:589,y:373,t:1512065463982};\\\", \\\"{x:617,y:369,t:1512065463998};\\\", \\\"{x:646,y:368,t:1512065464016};\\\", \\\"{x:675,y:368,t:1512065464031};\\\", \\\"{x:699,y:368,t:1512065464048};\\\", \\\"{x:739,y:368,t:1512065464065};\\\", \\\"{x:772,y:368,t:1512065464082};\\\", \\\"{x:809,y:368,t:1512065464099};\\\", \\\"{x:836,y:368,t:1512065464116};\\\", \\\"{x:859,y:368,t:1512065464132};\\\", \\\"{x:882,y:368,t:1512065464149};\\\", \\\"{x:902,y:368,t:1512065464166};\\\", \\\"{x:914,y:370,t:1512065464182};\\\", \\\"{x:925,y:371,t:1512065464198};\\\", \\\"{x:936,y:371,t:1512065464215};\\\", \\\"{x:950,y:374,t:1512065464232};\\\", \\\"{x:959,y:379,t:1512065464248};\\\", \\\"{x:960,y:380,t:1512065464265};\\\", \\\"{x:960,y:381,t:1512065464754};\\\", \\\"{x:962,y:381,t:1512065464826};\\\", \\\"{x:963,y:381,t:1512065464833};\\\", \\\"{x:967,y:381,t:1512065464849};\\\", \\\"{x:968,y:381,t:1512065464866};\\\", \\\"{x:970,y:381,t:1512065464883};\\\", \\\"{x:976,y:384,t:1512065464899};\\\", \\\"{x:994,y:407,t:1512065464915};\\\", \\\"{x:1035,y:466,t:1512065464932};\\\", \\\"{x:1090,y:559,t:1512065464949};\\\", \\\"{x:1139,y:632,t:1512065464965};\\\", \\\"{x:1182,y:715,t:1512065464982};\\\", \\\"{x:1208,y:771,t:1512065464999};\\\", \\\"{x:1225,y:819,t:1512065465016};\\\", \\\"{x:1238,y:859,t:1512065465032};\\\", \\\"{x:1246,y:906,t:1512065465049};\\\", \\\"{x:1250,y:929,t:1512065465066};\\\", \\\"{x:1251,y:946,t:1512065465082};\\\", \\\"{x:1251,y:959,t:1512065465100};\\\", \\\"{x:1243,y:981,t:1512065465116};\\\", \\\"{x:1233,y:995,t:1512065465132};\\\", \\\"{x:1221,y:1005,t:1512065465150};\\\", \\\"{x:1210,y:1012,t:1512065465166};\\\", \\\"{x:1194,y:1018,t:1512065465183};\\\", \\\"{x:1169,y:1024,t:1512065465200};\\\", \\\"{x:1137,y:1024,t:1512065465216};\\\", \\\"{x:1101,y:1021,t:1512065465233};\\\", \\\"{x:1047,y:1003,t:1512065465249};\\\", \\\"{x:1018,y:988,t:1512065465267};\\\", \\\"{x:1004,y:975,t:1512065465283};\\\", \\\"{x:993,y:956,t:1512065465300};\\\", \\\"{x:982,y:928,t:1512065465316};\\\", \\\"{x:976,y:903,t:1512065465333};\\\", \\\"{x:971,y:884,t:1512065465350};\\\", \\\"{x:971,y:875,t:1512065465367};\\\", \\\"{x:971,y:871,t:1512065465383};\\\", \\\"{x:971,y:867,t:1512065465400};\\\", \\\"{x:971,y:863,t:1512065465417};\\\", \\\"{x:972,y:861,t:1512065465433};\\\", \\\"{x:974,y:851,t:1512065465449};\\\", \\\"{x:975,y:847,t:1512065465467};\\\", \\\"{x:975,y:846,t:1512065465489};\\\", \\\"{x:975,y:845,t:1512065465512};\\\", \\\"{x:975,y:844,t:1512065465544};\\\", \\\"{x:975,y:843,t:1512065465552};\\\", \\\"{x:975,y:842,t:1512065465566};\\\", \\\"{x:975,y:841,t:1512065465584};\\\", \\\"{x:975,y:840,t:1512065465600};\\\", \\\"{x:975,y:839,t:1512065465632};\\\", \\\"{x:975,y:835,t:1512065465823};\\\", \\\"{x:975,y:832,t:1512065465833};\\\", \\\"{x:975,y:831,t:1512065465864};\\\", \\\"{x:975,y:830,t:1512065465880};\\\", \\\"{x:975,y:829,t:1512065465896};\\\", \\\"{x:974,y:829,t:1512065465961};\\\", \\\"{x:974,y:828,t:1512065466041};\\\", \\\"{x:973,y:828,t:1512065466113};\\\", \\\"{x:1000,y:823,t:1512065467951};\\\", \\\"{x:1157,y:808,t:1512065467969};\\\", \\\"{x:1200,y:808,t:1512065467986};\\\", \\\"{x:1218,y:808,t:1512065468001};\\\", \\\"{x:1225,y:806,t:1512065468018};\\\", \\\"{x:1230,y:803,t:1512065468035};\\\", \\\"{x:1232,y:802,t:1512065468051};\\\", \\\"{x:1233,y:801,t:1512065468068};\\\", \\\"{x:1236,y:799,t:1512065468085};\\\", \\\"{x:1238,y:798,t:1512065468101};\\\", \\\"{x:1242,y:794,t:1512065468118};\\\", \\\"{x:1244,y:792,t:1512065468135};\\\", \\\"{x:1246,y:791,t:1512065468151};\\\", \\\"{x:1246,y:790,t:1512065468201};\\\", \\\"{x:1246,y:789,t:1512065468242};\\\", \\\"{x:1244,y:789,t:1512065468252};\\\", \\\"{x:1229,y:784,t:1512065468269};\\\", \\\"{x:1208,y:779,t:1512065468286};\\\", \\\"{x:1188,y:775,t:1512065468302};\\\", \\\"{x:1176,y:774,t:1512065468319};\\\", \\\"{x:1169,y:773,t:1512065468335};\\\", \\\"{x:1168,y:773,t:1512065468352};\\\", \\\"{x:1167,y:773,t:1512065468368};\\\", \\\"{x:1164,y:772,t:1512065468385};\\\", \\\"{x:1158,y:771,t:1512065468402};\\\", \\\"{x:1149,y:769,t:1512065468418};\\\", \\\"{x:1142,y:768,t:1512065468440};\\\", \\\"{x:1137,y:767,t:1512065468454};\\\", \\\"{x:1135,y:766,t:1512065468468};\\\", \\\"{x:1134,y:765,t:1512065468485};\\\", \\\"{x:1132,y:765,t:1512065468502};\\\", \\\"{x:1129,y:764,t:1512065468518};\\\", \\\"{x:1125,y:763,t:1512065468535};\\\", \\\"{x:1120,y:761,t:1512065468552};\\\", \\\"{x:1120,y:760,t:1512065468633};\\\", \\\"{x:1120,y:759,t:1512065468640};\\\", \\\"{x:1121,y:758,t:1512065468652};\\\", \\\"{x:1123,y:758,t:1512065468668};\\\", \\\"{x:1125,y:758,t:1512065468685};\\\", \\\"{x:1126,y:757,t:1512065468702};\\\", \\\"{x:1128,y:757,t:1512065468720};\\\", \\\"{x:1130,y:755,t:1512065468736};\\\", \\\"{x:1134,y:754,t:1512065468753};\\\", \\\"{x:1141,y:752,t:1512065468769};\\\", \\\"{x:1146,y:750,t:1512065468786};\\\", \\\"{x:1150,y:748,t:1512065468803};\\\", \\\"{x:1149,y:750,t:1512065468977};\\\", \\\"{x:1149,y:751,t:1512065468986};\\\", \\\"{x:1148,y:753,t:1512065469003};\\\", \\\"{x:1148,y:754,t:1512065469025};\\\", \\\"{x:1148,y:755,t:1512065469041};\\\", \\\"{x:1148,y:756,t:1512065469053};\\\", \\\"{x:1147,y:757,t:1512065469070};\\\", \\\"{x:1146,y:758,t:1512065469137};\\\", \\\"{x:1145,y:759,t:1512065469152};\\\", \\\"{x:1143,y:759,t:1512065469208};\\\", \\\"{x:1143,y:760,t:1512065469224};\\\", \\\"{x:1142,y:760,t:1512065469240};\\\", \\\"{x:1142,y:761,t:1512065469252};\\\", \\\"{x:1141,y:761,t:1512065469269};\\\", \\\"{x:1140,y:762,t:1512065469286};\\\", \\\"{x:1139,y:762,t:1512065469312};\\\", \\\"{x:1139,y:763,t:1512065469328};\\\", \\\"{x:1138,y:763,t:1512065469361};\\\", \\\"{x:1134,y:763,t:1512065470789};\\\", \\\"{x:1109,y:763,t:1512065470804};\\\", \\\"{x:1068,y:761,t:1512065470820};\\\", \\\"{x:1014,y:753,t:1512065470837};\\\", \\\"{x:931,y:742,t:1512065470854};\\\", \\\"{x:834,y:726,t:1512065470870};\\\", \\\"{x:684,y:704,t:1512065470887};\\\", \\\"{x:470,y:679,t:1512065470904};\\\", \\\"{x:348,y:658,t:1512065470920};\\\", \\\"{x:247,y:642,t:1512065470937};\\\", \\\"{x:183,y:634,t:1512065470954};\\\", \\\"{x:151,y:629,t:1512065470970};\\\", \\\"{x:139,y:628,t:1512065470987};\\\", \\\"{x:138,y:628,t:1512065471057};\\\", \\\"{x:137,y:627,t:1512065471073};\\\", \\\"{x:135,y:625,t:1512065471087};\\\", \\\"{x:134,y:624,t:1512065471104};\\\", \\\"{x:134,y:623,t:1512065471153};\\\", \\\"{x:134,y:621,t:1512065471161};\\\", \\\"{x:136,y:618,t:1512065471170};\\\", \\\"{x:143,y:614,t:1512065471188};\\\", \\\"{x:150,y:610,t:1512065471204};\\\", \\\"{x:162,y:604,t:1512065471221};\\\", \\\"{x:181,y:597,t:1512065471238};\\\", \\\"{x:198,y:591,t:1512065471255};\\\", \\\"{x:215,y:588,t:1512065471271};\\\", \\\"{x:227,y:587,t:1512065471287};\\\", \\\"{x:235,y:586,t:1512065471305};\\\", \\\"{x:237,y:585,t:1512065471321};\\\", \\\"{x:238,y:585,t:1512065471337};\\\", \\\"{x:240,y:588,t:1512065471425};\\\", \\\"{x:241,y:593,t:1512065471438};\\\", \\\"{x:241,y:598,t:1512065471454};\\\", \\\"{x:241,y:600,t:1512065471471};\\\", \\\"{x:241,y:603,t:1512065471487};\\\", \\\"{x:241,y:604,t:1512065471561};\\\", \\\"{x:239,y:605,t:1512065471571};\\\", \\\"{x:236,y:607,t:1512065471587};\\\", \\\"{x:232,y:610,t:1512065471604};\\\", \\\"{x:231,y:610,t:1512065471621};\\\", \\\"{x:229,y:610,t:1512065471641};\\\", \\\"{x:227,y:610,t:1512065471729};\\\", \\\"{x:227,y:611,t:1512065471841};\\\", \\\"{x:226,y:611,t:1512065471890};\\\", \\\"{x:224,y:611,t:1512065472073};\\\", \\\"{x:223,y:611,t:1512065472121};\\\", \\\"{x:221,y:611,t:1512065472169};\\\", \\\"{x:220,y:611,t:1512065472489};\\\", \\\"{x:220,y:610,t:1512065472521};\\\", \\\"{x:221,y:610,t:1512065472538};\\\", \\\"{x:232,y:610,t:1512065472556};\\\", \\\"{x:252,y:619,t:1512065472571};\\\", \\\"{x:268,y:630,t:1512065472588};\\\", \\\"{x:282,y:639,t:1512065472605};\\\", \\\"{x:296,y:649,t:1512065472622};\\\", \\\"{x:318,y:667,t:1512065472638};\\\", \\\"{x:336,y:681,t:1512065472655};\\\", \\\"{x:359,y:706,t:1512065472672};\\\", \\\"{x:373,y:717,t:1512065472689};\\\", \\\"{x:383,y:726,t:1512065472705};\\\", \\\"{x:386,y:730,t:1512065472722};\\\", \\\"{x:388,y:733,t:1512065472738};\\\", \\\"{x:390,y:736,t:1512065472755};\\\", \\\"{x:391,y:737,t:1512065472833};\\\", \\\"{x:393,y:737,t:1512065472857};\\\", \\\"{x:395,y:737,t:1512065472881};\\\", \\\"{x:396,y:737,t:1512065472889};\\\", \\\"{x:398,y:734,t:1512065472905};\\\", \\\"{x:399,y:731,t:1512065472922};\\\", \\\"{x:401,y:723,t:1512065472939};\\\", \\\"{x:401,y:718,t:1512065472955};\\\", \\\"{x:403,y:713,t:1512065472972};\\\", \\\"{x:404,y:710,t:1512065472989};\\\", \\\"{x:404,y:707,t:1512065473005};\\\", \\\"{x:404,y:704,t:1512065473022};\\\", \\\"{x:404,y:703,t:1512065473039};\\\", \\\"{x:404,y:702,t:1512065473055};\\\", \\\"{x:409,y:712,t:1512065473618};\\\", \\\"{x:425,y:734,t:1512065473626};\\\", \\\"{x:456,y:768,t:1512065473641};\\\", \\\"{x:551,y:858,t:1512065473657};\\\", \\\"{x:598,y:889,t:1512065473673};\\\", \\\"{x:631,y:902,t:1512065473690};\\\", \\\"{x:658,y:910,t:1512065473707};\\\", \\\"{x:682,y:915,t:1512065473723};\\\", \\\"{x:706,y:916,t:1512065473740};\\\", \\\"{x:726,y:916,t:1512065473757};\\\", \\\"{x:746,y:914,t:1512065473774};\\\", \\\"{x:758,y:911,t:1512065473790};\\\", \\\"{x:769,y:905,t:1512065473807};\\\", \\\"{x:776,y:899,t:1512065473824};\\\", \\\"{x:778,y:899,t:1512065473840};\\\", \\\"{x:782,y:894,t:1512065473858};\\\", \\\"{x:786,y:891,t:1512065473874};\\\", \\\"{x:788,y:889,t:1512065473891};\\\", \\\"{x:789,y:888,t:1512065473907};\\\", \\\"{x:791,y:886,t:1512065473924};\\\", \\\"{x:791,y:885,t:1512065473940};\\\", \\\"{x:791,y:884,t:1512065473957};\\\", \\\"{x:792,y:883,t:1512065473974};\\\" ] }, { \\\"rt\\\": 12161, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 249884, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:792,y:882,t:1512065474985};\\\", \\\"{x:791,y:879,t:1512065474993};\\\", \\\"{x:782,y:865,t:1512065475008};\\\", \\\"{x:741,y:807,t:1512065475024};\\\", \\\"{x:656,y:684,t:1512065475041};\\\", \\\"{x:608,y:617,t:1512065475058};\\\", \\\"{x:576,y:574,t:1512065475075};\\\", \\\"{x:557,y:539,t:1512065475091};\\\", \\\"{x:539,y:505,t:1512065475108};\\\", \\\"{x:524,y:469,t:1512065475125};\\\", \\\"{x:513,y:446,t:1512065475141};\\\", \\\"{x:508,y:425,t:1512065475158};\\\", \\\"{x:505,y:418,t:1512065475175};\\\", \\\"{x:505,y:416,t:1512065475191};\\\", \\\"{x:505,y:411,t:1512065475208};\\\", \\\"{x:505,y:410,t:1512065475225};\\\", \\\"{x:503,y:409,t:1512065477699};\\\", \\\"{x:498,y:412,t:1512065477712};\\\", \\\"{x:486,y:428,t:1512065477729};\\\", \\\"{x:478,y:436,t:1512065477745};\\\", \\\"{x:475,y:443,t:1512065477763};\\\", \\\"{x:471,y:451,t:1512065477780};\\\", \\\"{x:468,y:458,t:1512065477795};\\\", \\\"{x:467,y:461,t:1512065477813};\\\", \\\"{x:467,y:464,t:1512065477829};\\\", \\\"{x:467,y:465,t:1512065477851};\\\", \\\"{x:466,y:466,t:1512065477862};\\\", \\\"{x:466,y:467,t:1512065477881};\\\", \\\"{x:465,y:470,t:1512065477895};\\\", \\\"{x:464,y:471,t:1512065477912};\\\", \\\"{x:464,y:472,t:1512065477929};\\\", \\\"{x:463,y:475,t:1512065477945};\\\", \\\"{x:461,y:482,t:1512065477963};\\\", \\\"{x:458,y:494,t:1512065477979};\\\", \\\"{x:457,y:500,t:1512065477995};\\\", \\\"{x:455,y:504,t:1512065478013};\\\", \\\"{x:455,y:505,t:1512065478030};\\\", \\\"{x:455,y:507,t:1512065478045};\\\", \\\"{x:455,y:508,t:1512065478062};\\\", \\\"{x:455,y:511,t:1512065478080};\\\", \\\"{x:455,y:512,t:1512065478095};\\\", \\\"{x:455,y:513,t:1512065478123};\\\", \\\"{x:455,y:515,t:1512065478139};\\\", \\\"{x:456,y:515,t:1512065478155};\\\", \\\"{x:460,y:517,t:1512065478163};\\\", \\\"{x:466,y:520,t:1512065478179};\\\", \\\"{x:485,y:528,t:1512065478196};\\\", \\\"{x:510,y:534,t:1512065478212};\\\", \\\"{x:537,y:537,t:1512065478230};\\\", \\\"{x:565,y:540,t:1512065478247};\\\", \\\"{x:593,y:545,t:1512065478262};\\\", \\\"{x:621,y:548,t:1512065478281};\\\", \\\"{x:658,y:549,t:1512065478297};\\\", \\\"{x:702,y:554,t:1512065478312};\\\", \\\"{x:751,y:557,t:1512065478330};\\\", \\\"{x:794,y:560,t:1512065478347};\\\", \\\"{x:832,y:562,t:1512065478363};\\\", \\\"{x:890,y:569,t:1512065478379};\\\", \\\"{x:932,y:573,t:1512065478397};\\\", \\\"{x:955,y:574,t:1512065478413};\\\", \\\"{x:977,y:575,t:1512065478430};\\\", \\\"{x:997,y:575,t:1512065478447};\\\", \\\"{x:1019,y:575,t:1512065478463};\\\", \\\"{x:1041,y:580,t:1512065478481};\\\", \\\"{x:1065,y:582,t:1512065478497};\\\", \\\"{x:1085,y:586,t:1512065478513};\\\", \\\"{x:1102,y:591,t:1512065478530};\\\", \\\"{x:1121,y:596,t:1512065478547};\\\", \\\"{x:1144,y:602,t:1512065478563};\\\", \\\"{x:1147,y:605,t:1512065478580};\\\", \\\"{x:1148,y:605,t:1512065478597};\\\", \\\"{x:1151,y:608,t:1512065478614};\\\", \\\"{x:1155,y:613,t:1512065478630};\\\", \\\"{x:1158,y:621,t:1512065478647};\\\", \\\"{x:1166,y:634,t:1512065478664};\\\", \\\"{x:1172,y:646,t:1512065478681};\\\", \\\"{x:1181,y:662,t:1512065478697};\\\", \\\"{x:1192,y:680,t:1512065478714};\\\", \\\"{x:1205,y:698,t:1512065478730};\\\", \\\"{x:1214,y:715,t:1512065478747};\\\", \\\"{x:1230,y:742,t:1512065478763};\\\", \\\"{x:1237,y:755,t:1512065478780};\\\", \\\"{x:1242,y:762,t:1512065478797};\\\", \\\"{x:1246,y:768,t:1512065478814};\\\", \\\"{x:1246,y:771,t:1512065478830};\\\", \\\"{x:1248,y:776,t:1512065478847};\\\", \\\"{x:1252,y:789,t:1512065478864};\\\", \\\"{x:1258,y:805,t:1512065478881};\\\", \\\"{x:1263,y:817,t:1512065478897};\\\", \\\"{x:1269,y:827,t:1512065478914};\\\", \\\"{x:1272,y:832,t:1512065478930};\\\", \\\"{x:1274,y:837,t:1512065478947};\\\", \\\"{x:1276,y:842,t:1512065478963};\\\", \\\"{x:1277,y:844,t:1512065478980};\\\", \\\"{x:1277,y:845,t:1512065478997};\\\", \\\"{x:1277,y:847,t:1512065479019};\\\", \\\"{x:1277,y:848,t:1512065479030};\\\", \\\"{x:1279,y:851,t:1512065479047};\\\", \\\"{x:1279,y:855,t:1512065479064};\\\", \\\"{x:1279,y:858,t:1512065479081};\\\", \\\"{x:1279,y:862,t:1512065479097};\\\", \\\"{x:1279,y:871,t:1512065479114};\\\", \\\"{x:1280,y:886,t:1512065479131};\\\", \\\"{x:1281,y:901,t:1512065479147};\\\", \\\"{x:1284,y:916,t:1512065479163};\\\", \\\"{x:1285,y:921,t:1512065479181};\\\", \\\"{x:1287,y:926,t:1512065479197};\\\", \\\"{x:1288,y:928,t:1512065479220};\\\", \\\"{x:1289,y:931,t:1512065479231};\\\", \\\"{x:1295,y:939,t:1512065479247};\\\", \\\"{x:1304,y:950,t:1512065479264};\\\", \\\"{x:1314,y:958,t:1512065479281};\\\", \\\"{x:1321,y:962,t:1512065479297};\\\", \\\"{x:1324,y:963,t:1512065479314};\\\", \\\"{x:1328,y:965,t:1512065479331};\\\", \\\"{x:1331,y:966,t:1512065479347};\\\", \\\"{x:1335,y:966,t:1512065479363};\\\", \\\"{x:1338,y:966,t:1512065479381};\\\", \\\"{x:1342,y:966,t:1512065479397};\\\", \\\"{x:1346,y:967,t:1512065479414};\\\", \\\"{x:1349,y:967,t:1512065479431};\\\", \\\"{x:1351,y:967,t:1512065479447};\\\", \\\"{x:1355,y:967,t:1512065479464};\\\", \\\"{x:1357,y:967,t:1512065479481};\\\", \\\"{x:1359,y:967,t:1512065479498};\\\", \\\"{x:1364,y:966,t:1512065479514};\\\", \\\"{x:1369,y:965,t:1512065479534};\\\", \\\"{x:1372,y:963,t:1512065479546};\\\", \\\"{x:1373,y:963,t:1512065479563};\\\", \\\"{x:1373,y:962,t:1512065479580};\\\", \\\"{x:1374,y:960,t:1512065479597};\\\", \\\"{x:1374,y:959,t:1512065479613};\\\", \\\"{x:1375,y:957,t:1512065479630};\\\", \\\"{x:1375,y:955,t:1512065479648};\\\", \\\"{x:1375,y:952,t:1512065479663};\\\", \\\"{x:1375,y:950,t:1512065479680};\\\", \\\"{x:1375,y:947,t:1512065479697};\\\", \\\"{x:1375,y:946,t:1512065479713};\\\", \\\"{x:1375,y:945,t:1512065479730};\\\", \\\"{x:1375,y:944,t:1512065479747};\\\", \\\"{x:1375,y:942,t:1512065479771};\\\", \\\"{x:1373,y:941,t:1512065479795};\\\", \\\"{x:1372,y:939,t:1512065479803};\\\", \\\"{x:1371,y:938,t:1512065479819};\\\", \\\"{x:1370,y:936,t:1512065479830};\\\", \\\"{x:1369,y:936,t:1512065479847};\\\", \\\"{x:1367,y:933,t:1512065479863};\\\", \\\"{x:1366,y:932,t:1512065479880};\\\", \\\"{x:1364,y:930,t:1512065479897};\\\", \\\"{x:1363,y:929,t:1512065479914};\\\", \\\"{x:1362,y:927,t:1512065479930};\\\", \\\"{x:1360,y:926,t:1512065479948};\\\", \\\"{x:1359,y:924,t:1512065479965};\\\", \\\"{x:1357,y:924,t:1512065479981};\\\", \\\"{x:1357,y:923,t:1512065480012};\\\", \\\"{x:1356,y:923,t:1512065480027};\\\", \\\"{x:1356,y:922,t:1512065480043};\\\", \\\"{x:1355,y:921,t:1512065480059};\\\", \\\"{x:1354,y:920,t:1512065480092};\\\", \\\"{x:1353,y:918,t:1512065480107};\\\", \\\"{x:1352,y:916,t:1512065480132};\\\", \\\"{x:1349,y:914,t:1512065480147};\\\", \\\"{x:1348,y:911,t:1512065480165};\\\", \\\"{x:1346,y:908,t:1512065480181};\\\", \\\"{x:1345,y:907,t:1512065480198};\\\", \\\"{x:1344,y:905,t:1512065480215};\\\", \\\"{x:1343,y:900,t:1512065480231};\\\", \\\"{x:1340,y:897,t:1512065480248};\\\", \\\"{x:1339,y:892,t:1512065480265};\\\", \\\"{x:1337,y:888,t:1512065480281};\\\", \\\"{x:1336,y:886,t:1512065480298};\\\", \\\"{x:1335,y:883,t:1512065480315};\\\", \\\"{x:1333,y:879,t:1512065480331};\\\", \\\"{x:1333,y:877,t:1512065480348};\\\", \\\"{x:1332,y:873,t:1512065480365};\\\", \\\"{x:1329,y:869,t:1512065480382};\\\", \\\"{x:1328,y:867,t:1512065480398};\\\", \\\"{x:1327,y:864,t:1512065480415};\\\", \\\"{x:1326,y:863,t:1512065480432};\\\", \\\"{x:1326,y:862,t:1512065480448};\\\", \\\"{x:1325,y:860,t:1512065480465};\\\", \\\"{x:1325,y:859,t:1512065480482};\\\", \\\"{x:1325,y:857,t:1512065480498};\\\", \\\"{x:1323,y:854,t:1512065480515};\\\", \\\"{x:1323,y:852,t:1512065480532};\\\", \\\"{x:1322,y:849,t:1512065480548};\\\", \\\"{x:1320,y:845,t:1512065480565};\\\", \\\"{x:1319,y:844,t:1512065480582};\\\", \\\"{x:1319,y:842,t:1512065480598};\\\", \\\"{x:1317,y:840,t:1512065480615};\\\", \\\"{x:1316,y:839,t:1512065480632};\\\", \\\"{x:1315,y:834,t:1512065480648};\\\", \\\"{x:1312,y:828,t:1512065480665};\\\", \\\"{x:1309,y:822,t:1512065480682};\\\", \\\"{x:1308,y:818,t:1512065480698};\\\", \\\"{x:1305,y:813,t:1512065480715};\\\", \\\"{x:1300,y:806,t:1512065480731};\\\", \\\"{x:1298,y:802,t:1512065480749};\\\", \\\"{x:1295,y:797,t:1512065480765};\\\", \\\"{x:1294,y:795,t:1512065480787};\\\", \\\"{x:1293,y:794,t:1512065480799};\\\", \\\"{x:1293,y:793,t:1512065480815};\\\", \\\"{x:1291,y:790,t:1512065480832};\\\", \\\"{x:1289,y:787,t:1512065480849};\\\", \\\"{x:1285,y:782,t:1512065480865};\\\", \\\"{x:1280,y:773,t:1512065480882};\\\", \\\"{x:1277,y:770,t:1512065480899};\\\", \\\"{x:1275,y:767,t:1512065480915};\\\", \\\"{x:1268,y:755,t:1512065480931};\\\", \\\"{x:1262,y:745,t:1512065480949};\\\", \\\"{x:1258,y:736,t:1512065480965};\\\", \\\"{x:1255,y:732,t:1512065480982};\\\", \\\"{x:1252,y:726,t:1512065480999};\\\", \\\"{x:1251,y:723,t:1512065481015};\\\", \\\"{x:1248,y:719,t:1512065481032};\\\", \\\"{x:1248,y:715,t:1512065481049};\\\", \\\"{x:1245,y:710,t:1512065481065};\\\", \\\"{x:1241,y:706,t:1512065481082};\\\", \\\"{x:1240,y:701,t:1512065481099};\\\", \\\"{x:1237,y:696,t:1512065481115};\\\", \\\"{x:1231,y:686,t:1512065481132};\\\", \\\"{x:1225,y:677,t:1512065481149};\\\", \\\"{x:1221,y:671,t:1512065481165};\\\", \\\"{x:1219,y:666,t:1512065481182};\\\", \\\"{x:1218,y:662,t:1512065481199};\\\", \\\"{x:1213,y:653,t:1512065481215};\\\", \\\"{x:1205,y:642,t:1512065481232};\\\", \\\"{x:1198,y:633,t:1512065481249};\\\", \\\"{x:1188,y:622,t:1512065481266};\\\", \\\"{x:1179,y:611,t:1512065481282};\\\", \\\"{x:1173,y:602,t:1512065481299};\\\", \\\"{x:1169,y:597,t:1512065481315};\\\", \\\"{x:1169,y:595,t:1512065481332};\\\", \\\"{x:1167,y:593,t:1512065481349};\\\", \\\"{x:1167,y:590,t:1512065481366};\\\", \\\"{x:1166,y:586,t:1512065481382};\\\", \\\"{x:1166,y:583,t:1512065481399};\\\", \\\"{x:1166,y:580,t:1512065481416};\\\", \\\"{x:1166,y:579,t:1512065481432};\\\", \\\"{x:1166,y:577,t:1512065481449};\\\", \\\"{x:1167,y:573,t:1512065481466};\\\", \\\"{x:1168,y:570,t:1512065481482};\\\", \\\"{x:1170,y:568,t:1512065481499};\\\", \\\"{x:1173,y:564,t:1512065481525};\\\", \\\"{x:1177,y:560,t:1512065481565};\\\", \\\"{x:1177,y:559,t:1512065481580};\\\", \\\"{x:1178,y:558,t:1512065481610};\\\", \\\"{x:1173,y:558,t:1512065484635};\\\", \\\"{x:1152,y:558,t:1512065484654};\\\", \\\"{x:980,y:558,t:1512065484681};\\\", \\\"{x:887,y:555,t:1512065484701};\\\", \\\"{x:811,y:553,t:1512065484717};\\\", \\\"{x:755,y:553,t:1512065484734};\\\", \\\"{x:704,y:551,t:1512065484751};\\\", \\\"{x:649,y:551,t:1512065484767};\\\", \\\"{x:587,y:551,t:1512065484784};\\\", \\\"{x:536,y:552,t:1512065484801};\\\", \\\"{x:513,y:555,t:1512065484817};\\\", \\\"{x:498,y:559,t:1512065484834};\\\", \\\"{x:494,y:560,t:1512065484851};\\\", \\\"{x:488,y:563,t:1512065484867};\\\", \\\"{x:478,y:564,t:1512065484884};\\\", \\\"{x:462,y:573,t:1512065484901};\\\", \\\"{x:451,y:580,t:1512065484918};\\\", \\\"{x:441,y:588,t:1512065484934};\\\", \\\"{x:431,y:595,t:1512065484952};\\\", \\\"{x:426,y:599,t:1512065484968};\\\", \\\"{x:423,y:602,t:1512065484984};\\\", \\\"{x:421,y:603,t:1512065485002};\\\", \\\"{x:419,y:605,t:1512065485018};\\\", \\\"{x:419,y:606,t:1512065485043};\\\", \\\"{x:417,y:606,t:1512065485067};\\\", \\\"{x:416,y:606,t:1512065485075};\\\", \\\"{x:413,y:606,t:1512065485085};\\\", \\\"{x:405,y:606,t:1512065485102};\\\", \\\"{x:394,y:606,t:1512065485118};\\\", \\\"{x:379,y:603,t:1512065485134};\\\", \\\"{x:365,y:598,t:1512065485151};\\\", \\\"{x:349,y:595,t:1512065485168};\\\", \\\"{x:340,y:592,t:1512065485184};\\\", \\\"{x:336,y:591,t:1512065485201};\\\", \\\"{x:332,y:590,t:1512065485218};\\\", \\\"{x:330,y:590,t:1512065485234};\\\", \\\"{x:329,y:590,t:1512065485251};\\\", \\\"{x:328,y:590,t:1512065485268};\\\", \\\"{x:327,y:590,t:1512065485284};\\\", \\\"{x:326,y:590,t:1512065485301};\\\", \\\"{x:324,y:590,t:1512065485318};\\\", \\\"{x:323,y:590,t:1512065485335};\\\", \\\"{x:322,y:590,t:1512065485351};\\\", \\\"{x:320,y:590,t:1512065485368};\\\", \\\"{x:319,y:592,t:1512065485386};\\\", \\\"{x:317,y:596,t:1512065485401};\\\", \\\"{x:315,y:602,t:1512065485419};\\\", \\\"{x:314,y:604,t:1512065485435};\\\", \\\"{x:313,y:605,t:1512065485451};\\\", \\\"{x:313,y:606,t:1512065485468};\\\", \\\"{x:313,y:607,t:1512065485485};\\\", \\\"{x:312,y:607,t:1512065485530};\\\", \\\"{x:313,y:607,t:1512065485826};\\\", \\\"{x:314,y:606,t:1512065485842};\\\", \\\"{x:315,y:605,t:1512065485882};\\\", \\\"{x:316,y:605,t:1512065485914};\\\", \\\"{x:318,y:605,t:1512065485922};\\\", \\\"{x:320,y:605,t:1512065485935};\\\", \\\"{x:331,y:605,t:1512065485952};\\\", \\\"{x:344,y:615,t:1512065485968};\\\", \\\"{x:357,y:628,t:1512065485985};\\\", \\\"{x:367,y:640,t:1512065486003};\\\", \\\"{x:374,y:648,t:1512065486019};\\\", \\\"{x:380,y:659,t:1512065486035};\\\", \\\"{x:385,y:668,t:1512065486052};\\\", \\\"{x:395,y:683,t:1512065486068};\\\", \\\"{x:403,y:697,t:1512065486086};\\\", \\\"{x:410,y:707,t:1512065486102};\\\", \\\"{x:413,y:710,t:1512065486118};\\\", \\\"{x:414,y:712,t:1512065486135};\\\", \\\"{x:414,y:713,t:1512065486307};\\\", \\\"{x:414,y:714,t:1512065487195};\\\", \\\"{x:419,y:731,t:1512065487203};\\\", \\\"{x:446,y:799,t:1512065487219};\\\", \\\"{x:468,y:834,t:1512065487236};\\\", \\\"{x:481,y:850,t:1512065487253};\\\", \\\"{x:491,y:863,t:1512065487269};\\\", \\\"{x:505,y:874,t:1512065487286};\\\", \\\"{x:513,y:882,t:1512065487303};\\\", \\\"{x:521,y:886,t:1512065487319};\\\", \\\"{x:532,y:891,t:1512065487336};\\\", \\\"{x:541,y:895,t:1512065487353};\\\", \\\"{x:548,y:895,t:1512065487369};\\\", \\\"{x:556,y:897,t:1512065487386};\\\", \\\"{x:583,y:899,t:1512065487403};\\\", \\\"{x:609,y:902,t:1512065487419};\\\", \\\"{x:642,y:902,t:1512065487436};\\\", \\\"{x:675,y:900,t:1512065487453};\\\", \\\"{x:706,y:890,t:1512065487469};\\\", \\\"{x:732,y:879,t:1512065487486};\\\", \\\"{x:745,y:871,t:1512065487503};\\\", \\\"{x:752,y:865,t:1512065487520};\\\", \\\"{x:754,y:862,t:1512065487536};\\\", \\\"{x:755,y:860,t:1512065487553};\\\", \\\"{x:758,y:855,t:1512065487571};\\\", \\\"{x:759,y:853,t:1512065487587};\\\" ] }, { \\\"rt\\\": 36165, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 287324, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -A -11 AM-11:30-O -O -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:760,y:851,t:1512065488531};\\\", \\\"{x:765,y:848,t:1512065488538};\\\", \\\"{x:780,y:838,t:1512065488554};\\\", \\\"{x:790,y:823,t:1512065488570};\\\", \\\"{x:793,y:808,t:1512065488587};\\\", \\\"{x:797,y:790,t:1512065488604};\\\", \\\"{x:800,y:765,t:1512065488620};\\\", \\\"{x:801,y:735,t:1512065488637};\\\", \\\"{x:803,y:695,t:1512065488654};\\\", \\\"{x:803,y:662,t:1512065488670};\\\", \\\"{x:803,y:637,t:1512065488687};\\\", \\\"{x:803,y:613,t:1512065488704};\\\", \\\"{x:804,y:590,t:1512065488720};\\\", \\\"{x:804,y:572,t:1512065488737};\\\", \\\"{x:804,y:551,t:1512065488754};\\\", \\\"{x:804,y:537,t:1512065488770};\\\", \\\"{x:797,y:520,t:1512065488787};\\\", \\\"{x:787,y:503,t:1512065488804};\\\", \\\"{x:774,y:483,t:1512065488821};\\\", \\\"{x:765,y:474,t:1512065488838};\\\", \\\"{x:755,y:466,t:1512065488855};\\\", \\\"{x:739,y:456,t:1512065488872};\\\", \\\"{x:718,y:446,t:1512065488887};\\\", \\\"{x:696,y:438,t:1512065488904};\\\", \\\"{x:678,y:431,t:1512065488921};\\\", \\\"{x:669,y:428,t:1512065488937};\\\", \\\"{x:664,y:426,t:1512065488955};\\\", \\\"{x:662,y:426,t:1512065488971};\\\", \\\"{x:659,y:426,t:1512065488987};\\\", \\\"{x:655,y:426,t:1512065489004};\\\", \\\"{x:646,y:426,t:1512065489021};\\\", \\\"{x:636,y:426,t:1512065489037};\\\", \\\"{x:622,y:429,t:1512065489055};\\\", \\\"{x:605,y:432,t:1512065489071};\\\", \\\"{x:591,y:435,t:1512065489088};\\\", \\\"{x:576,y:437,t:1512065489104};\\\", \\\"{x:566,y:440,t:1512065489121};\\\", \\\"{x:556,y:444,t:1512065489138};\\\", \\\"{x:544,y:447,t:1512065489155};\\\", \\\"{x:535,y:451,t:1512065489171};\\\", \\\"{x:523,y:454,t:1512065489187};\\\", \\\"{x:511,y:456,t:1512065489204};\\\", \\\"{x:493,y:461,t:1512065489221};\\\", \\\"{x:475,y:465,t:1512065489238};\\\", \\\"{x:461,y:467,t:1512065489254};\\\", \\\"{x:448,y:471,t:1512065489271};\\\", \\\"{x:436,y:475,t:1512065489288};\\\", \\\"{x:422,y:477,t:1512065489304};\\\", \\\"{x:406,y:480,t:1512065489321};\\\", \\\"{x:381,y:485,t:1512065489338};\\\", \\\"{x:363,y:488,t:1512065489355};\\\", \\\"{x:345,y:492,t:1512065489371};\\\", \\\"{x:329,y:497,t:1512065489388};\\\", \\\"{x:318,y:498,t:1512065489404};\\\", \\\"{x:308,y:501,t:1512065489421};\\\", \\\"{x:303,y:502,t:1512065489438};\\\", \\\"{x:301,y:502,t:1512065489454};\\\", \\\"{x:299,y:504,t:1512065489472};\\\", \\\"{x:295,y:505,t:1512065489489};\\\", \\\"{x:289,y:509,t:1512065489504};\\\", \\\"{x:285,y:509,t:1512065489521};\\\", \\\"{x:281,y:512,t:1512065489538};\\\", \\\"{x:276,y:513,t:1512065489554};\\\", \\\"{x:271,y:517,t:1512065489571};\\\", \\\"{x:268,y:519,t:1512065489588};\\\", \\\"{x:267,y:520,t:1512065489604};\\\", \\\"{x:266,y:520,t:1512065489635};\\\", \\\"{x:267,y:520,t:1512065489779};\\\", \\\"{x:268,y:520,t:1512065489788};\\\", \\\"{x:277,y:518,t:1512065489805};\\\", \\\"{x:295,y:515,t:1512065489821};\\\", \\\"{x:313,y:513,t:1512065489838};\\\", \\\"{x:327,y:510,t:1512065489855};\\\", \\\"{x:341,y:509,t:1512065489871};\\\", \\\"{x:357,y:504,t:1512065489888};\\\", \\\"{x:368,y:502,t:1512065489906};\\\", \\\"{x:376,y:502,t:1512065489922};\\\", \\\"{x:382,y:499,t:1512065489939};\\\", \\\"{x:384,y:499,t:1512065489955};\\\", \\\"{x:392,y:497,t:1512065489972};\\\", \\\"{x:399,y:495,t:1512065489989};\\\", \\\"{x:405,y:493,t:1512065490005};\\\", \\\"{x:412,y:491,t:1512065490021};\\\", \\\"{x:413,y:490,t:1512065490038};\\\", \\\"{x:414,y:490,t:1512065490055};\\\", \\\"{x:415,y:490,t:1512065490071};\\\", \\\"{x:416,y:490,t:1512065490155};\\\", \\\"{x:417,y:490,t:1512065490179};\\\", \\\"{x:418,y:490,t:1512065490188};\\\", \\\"{x:422,y:490,t:1512065490206};\\\", \\\"{x:425,y:490,t:1512065490221};\\\", \\\"{x:426,y:490,t:1512065490238};\\\", \\\"{x:427,y:490,t:1512065490255};\\\", \\\"{x:431,y:490,t:1512065490271};\\\", \\\"{x:438,y:493,t:1512065490288};\\\", \\\"{x:445,y:495,t:1512065490305};\\\", \\\"{x:454,y:497,t:1512065490322};\\\", \\\"{x:457,y:497,t:1512065490338};\\\", \\\"{x:459,y:499,t:1512065490355};\\\", \\\"{x:461,y:499,t:1512065490372};\\\", \\\"{x:463,y:499,t:1512065490388};\\\", \\\"{x:466,y:500,t:1512065490405};\\\", \\\"{x:470,y:501,t:1512065490422};\\\", \\\"{x:475,y:503,t:1512065490438};\\\", \\\"{x:478,y:504,t:1512065490455};\\\", \\\"{x:481,y:505,t:1512065490472};\\\", \\\"{x:489,y:507,t:1512065490488};\\\", \\\"{x:496,y:509,t:1512065490505};\\\", \\\"{x:502,y:511,t:1512065490523};\\\", \\\"{x:504,y:511,t:1512065490539};\\\", \\\"{x:506,y:512,t:1512065490555};\\\", \\\"{x:507,y:512,t:1512065490572};\\\", \\\"{x:509,y:512,t:1512065490589};\\\", \\\"{x:512,y:512,t:1512065490606};\\\", \\\"{x:516,y:512,t:1512065490623};\\\", \\\"{x:518,y:512,t:1512065490640};\\\", \\\"{x:520,y:513,t:1512065490656};\\\", \\\"{x:521,y:514,t:1512065490673};\\\", \\\"{x:525,y:514,t:1512065490690};\\\", \\\"{x:529,y:514,t:1512065490706};\\\", \\\"{x:537,y:515,t:1512065490725};\\\", \\\"{x:543,y:515,t:1512065490740};\\\", \\\"{x:548,y:515,t:1512065490756};\\\", \\\"{x:553,y:515,t:1512065490773};\\\", \\\"{x:556,y:515,t:1512065490790};\\\", \\\"{x:557,y:515,t:1512065490806};\\\", \\\"{x:558,y:515,t:1512065490823};\\\", \\\"{x:554,y:515,t:1512065491108};\\\", \\\"{x:535,y:514,t:1512065491123};\\\", \\\"{x:517,y:514,t:1512065491140};\\\", \\\"{x:506,y:513,t:1512065491157};\\\", \\\"{x:499,y:512,t:1512065491173};\\\", \\\"{x:489,y:511,t:1512065491190};\\\", \\\"{x:481,y:511,t:1512065491207};\\\", \\\"{x:478,y:511,t:1512065491223};\\\", \\\"{x:469,y:511,t:1512065491240};\\\", \\\"{x:456,y:513,t:1512065491257};\\\", \\\"{x:451,y:515,t:1512065491273};\\\", \\\"{x:450,y:515,t:1512065491290};\\\", \\\"{x:445,y:517,t:1512065491307};\\\", \\\"{x:444,y:518,t:1512065491323};\\\", \\\"{x:443,y:518,t:1512065491340};\\\", \\\"{x:441,y:519,t:1512065491357};\\\", \\\"{x:437,y:520,t:1512065491374};\\\", \\\"{x:433,y:522,t:1512065491390};\\\", \\\"{x:426,y:525,t:1512065491407};\\\", \\\"{x:424,y:526,t:1512065491424};\\\", \\\"{x:420,y:528,t:1512065491440};\\\", \\\"{x:418,y:529,t:1512065491458};\\\", \\\"{x:415,y:530,t:1512065491474};\\\", \\\"{x:414,y:530,t:1512065491492};\\\", \\\"{x:412,y:531,t:1512065491508};\\\", \\\"{x:410,y:531,t:1512065491524};\\\", \\\"{x:409,y:532,t:1512065491540};\\\", \\\"{x:407,y:532,t:1512065491558};\\\", \\\"{x:406,y:532,t:1512065491574};\\\", \\\"{x:402,y:533,t:1512065491590};\\\", \\\"{x:400,y:533,t:1512065491607};\\\", \\\"{x:398,y:534,t:1512065491624};\\\", \\\"{x:396,y:534,t:1512065491640};\\\", \\\"{x:392,y:535,t:1512065491657};\\\", \\\"{x:391,y:535,t:1512065491674};\\\", \\\"{x:390,y:535,t:1512065491690};\\\", \\\"{x:388,y:536,t:1512065491707};\\\", \\\"{x:386,y:536,t:1512065491724};\\\", \\\"{x:380,y:536,t:1512065491740};\\\", \\\"{x:378,y:536,t:1512065491757};\\\", \\\"{x:376,y:536,t:1512065491774};\\\", \\\"{x:375,y:536,t:1512065491791};\\\", \\\"{x:373,y:538,t:1512065491807};\\\", \\\"{x:371,y:538,t:1512065491824};\\\", \\\"{x:370,y:538,t:1512065491840};\\\", \\\"{x:368,y:538,t:1512065491857};\\\", \\\"{x:364,y:538,t:1512065491874};\\\", \\\"{x:358,y:539,t:1512065491891};\\\", \\\"{x:356,y:539,t:1512065491907};\\\", \\\"{x:354,y:540,t:1512065491924};\\\", \\\"{x:353,y:540,t:1512065491941};\\\", \\\"{x:352,y:541,t:1512065491957};\\\", \\\"{x:351,y:541,t:1512065491980};\\\", \\\"{x:350,y:542,t:1512065491991};\\\", \\\"{x:348,y:542,t:1512065492007};\\\", \\\"{x:347,y:543,t:1512065492024};\\\", \\\"{x:344,y:544,t:1512065492041};\\\", \\\"{x:343,y:544,t:1512065492057};\\\", \\\"{x:341,y:544,t:1512065492074};\\\", \\\"{x:341,y:545,t:1512065492091};\\\", \\\"{x:339,y:545,t:1512065492107};\\\", \\\"{x:334,y:546,t:1512065492124};\\\", \\\"{x:332,y:548,t:1512065492141};\\\", \\\"{x:327,y:548,t:1512065492157};\\\", \\\"{x:324,y:548,t:1512065492174};\\\", \\\"{x:321,y:549,t:1512065492191};\\\", \\\"{x:320,y:549,t:1512065492207};\\\", \\\"{x:318,y:549,t:1512065492244};\\\", \\\"{x:318,y:550,t:1512065492260};\\\", \\\"{x:318,y:551,t:1512065492452};\\\", \\\"{x:319,y:551,t:1512065492460};\\\", \\\"{x:323,y:551,t:1512065492474};\\\", \\\"{x:334,y:551,t:1512065492491};\\\", \\\"{x:347,y:549,t:1512065492507};\\\", \\\"{x:365,y:549,t:1512065492524};\\\", \\\"{x:378,y:549,t:1512065492541};\\\", \\\"{x:388,y:549,t:1512065492558};\\\", \\\"{x:396,y:549,t:1512065492574};\\\", \\\"{x:403,y:549,t:1512065492591};\\\", \\\"{x:410,y:549,t:1512065492607};\\\", \\\"{x:419,y:547,t:1512065492624};\\\", \\\"{x:428,y:547,t:1512065492641};\\\", \\\"{x:440,y:547,t:1512065492658};\\\", \\\"{x:452,y:547,t:1512065492675};\\\", \\\"{x:467,y:547,t:1512065492691};\\\", \\\"{x:478,y:547,t:1512065492708};\\\", \\\"{x:487,y:547,t:1512065492725};\\\", \\\"{x:491,y:546,t:1512065492741};\\\", \\\"{x:495,y:545,t:1512065492758};\\\", \\\"{x:497,y:545,t:1512065492775};\\\", \\\"{x:500,y:543,t:1512065492791};\\\", \\\"{x:503,y:542,t:1512065492808};\\\", \\\"{x:506,y:541,t:1512065492825};\\\", \\\"{x:508,y:540,t:1512065492841};\\\", \\\"{x:510,y:539,t:1512065492859};\\\", \\\"{x:513,y:538,t:1512065492875};\\\", \\\"{x:516,y:538,t:1512065492891};\\\", \\\"{x:519,y:537,t:1512065492908};\\\", \\\"{x:519,y:536,t:1512065492925};\\\", \\\"{x:523,y:535,t:1512065492941};\\\", \\\"{x:525,y:535,t:1512065492958};\\\", \\\"{x:527,y:535,t:1512065492974};\\\", \\\"{x:529,y:533,t:1512065492992};\\\", \\\"{x:532,y:532,t:1512065493008};\\\", \\\"{x:533,y:532,t:1512065493025};\\\", \\\"{x:536,y:532,t:1512065493041};\\\", \\\"{x:542,y:532,t:1512065493058};\\\", \\\"{x:545,y:531,t:1512065493075};\\\", \\\"{x:546,y:531,t:1512065493091};\\\", \\\"{x:547,y:531,t:1512065493108};\\\", \\\"{x:548,y:531,t:1512065493227};\\\", \\\"{x:558,y:531,t:1512065493643};\\\", \\\"{x:589,y:528,t:1512065493658};\\\", \\\"{x:734,y:524,t:1512065493675};\\\", \\\"{x:815,y:524,t:1512065493692};\\\", \\\"{x:873,y:524,t:1512065493708};\\\", \\\"{x:924,y:524,t:1512065493725};\\\", \\\"{x:988,y:516,t:1512065493742};\\\", \\\"{x:1061,y:510,t:1512065493758};\\\", \\\"{x:1117,y:510,t:1512065493775};\\\", \\\"{x:1148,y:509,t:1512065493792};\\\", \\\"{x:1160,y:509,t:1512065493808};\\\", \\\"{x:1162,y:509,t:1512065493825};\\\", \\\"{x:1159,y:509,t:1512065493964};\\\", \\\"{x:1151,y:509,t:1512065493975};\\\", \\\"{x:1132,y:509,t:1512065493992};\\\", \\\"{x:1111,y:509,t:1512065494008};\\\", \\\"{x:1093,y:508,t:1512065494026};\\\", \\\"{x:1081,y:507,t:1512065494043};\\\", \\\"{x:1072,y:504,t:1512065494059};\\\", \\\"{x:1065,y:504,t:1512065494075};\\\", \\\"{x:1063,y:502,t:1512065494092};\\\", \\\"{x:1061,y:501,t:1512065494109};\\\", \\\"{x:1061,y:499,t:1512065494188};\\\", \\\"{x:1061,y:498,t:1512065494196};\\\", \\\"{x:1061,y:497,t:1512065494209};\\\", \\\"{x:1061,y:496,t:1512065494226};\\\", \\\"{x:1061,y:495,t:1512065494243};\\\", \\\"{x:1061,y:494,t:1512065494300};\\\", \\\"{x:1062,y:494,t:1512065494380};\\\", \\\"{x:1064,y:494,t:1512065494393};\\\", \\\"{x:1069,y:494,t:1512065494410};\\\", \\\"{x:1072,y:494,t:1512065494431};\\\", \\\"{x:1075,y:494,t:1512065494458};\\\", \\\"{x:1076,y:494,t:1512065494491};\\\", \\\"{x:1077,y:494,t:1512065494515};\\\", \\\"{x:1078,y:494,t:1512065494526};\\\", \\\"{x:1085,y:494,t:1512065494545};\\\", \\\"{x:1085,y:495,t:1512065494560};\\\", \\\"{x:1086,y:495,t:1512065494587};\\\", \\\"{x:1086,y:497,t:1512065494707};\\\", \\\"{x:1085,y:497,t:1512065494747};\\\", \\\"{x:1084,y:498,t:1512065494760};\\\", \\\"{x:1082,y:499,t:1512065494780};\\\", \\\"{x:1081,y:499,t:1512065494801};\\\", \\\"{x:1078,y:500,t:1512065494810};\\\", \\\"{x:1077,y:500,t:1512065494907};\\\", \\\"{x:1076,y:500,t:1512065494931};\\\", \\\"{x:1075,y:500,t:1512065495100};\\\", \\\"{x:1074,y:500,t:1512065495196};\\\", \\\"{x:1073,y:500,t:1512065516380};\\\", \\\"{x:1071,y:507,t:1512065516399};\\\", \\\"{x:1068,y:530,t:1512065516410};\\\", \\\"{x:1064,y:569,t:1512065516427};\\\", \\\"{x:1061,y:593,t:1512065516444};\\\", \\\"{x:1060,y:614,t:1512065516461};\\\", \\\"{x:1057,y:635,t:1512065516477};\\\", \\\"{x:1054,y:654,t:1512065516494};\\\", \\\"{x:1050,y:674,t:1512065516511};\\\", \\\"{x:1049,y:692,t:1512065516527};\\\", \\\"{x:1046,y:716,t:1512065516544};\\\", \\\"{x:1046,y:754,t:1512065516561};\\\", \\\"{x:1046,y:796,t:1512065516578};\\\", \\\"{x:1046,y:826,t:1512065516598};\\\", \\\"{x:1045,y:854,t:1512065516612};\\\", \\\"{x:1045,y:873,t:1512065516628};\\\", \\\"{x:1045,y:895,t:1512065516644};\\\", \\\"{x:1045,y:916,t:1512065516661};\\\", \\\"{x:1046,y:932,t:1512065516678};\\\", \\\"{x:1048,y:948,t:1512065516694};\\\", \\\"{x:1050,y:961,t:1512065516711};\\\", \\\"{x:1051,y:966,t:1512065516728};\\\", \\\"{x:1053,y:974,t:1512065516744};\\\", \\\"{x:1055,y:980,t:1512065516761};\\\", \\\"{x:1056,y:987,t:1512065516778};\\\", \\\"{x:1058,y:992,t:1512065516794};\\\", \\\"{x:1058,y:994,t:1512065516811};\\\", \\\"{x:1059,y:994,t:1512065516956};\\\", \\\"{x:1061,y:993,t:1512065516971};\\\", \\\"{x:1062,y:993,t:1512065516979};\\\", \\\"{x:1066,y:990,t:1512065516996};\\\", \\\"{x:1067,y:989,t:1512065517012};\\\", \\\"{x:1068,y:988,t:1512065517029};\\\", \\\"{x:1070,y:987,t:1512065517045};\\\", \\\"{x:1073,y:985,t:1512065517061};\\\", \\\"{x:1077,y:978,t:1512065517078};\\\", \\\"{x:1086,y:965,t:1512065517096};\\\", \\\"{x:1093,y:947,t:1512065517111};\\\", \\\"{x:1101,y:929,t:1512065517128};\\\", \\\"{x:1104,y:904,t:1512065517146};\\\", \\\"{x:1104,y:880,t:1512065517161};\\\", \\\"{x:1104,y:857,t:1512065517178};\\\", \\\"{x:1104,y:790,t:1512065517195};\\\", \\\"{x:1104,y:740,t:1512065517211};\\\", \\\"{x:1104,y:698,t:1512065517228};\\\", \\\"{x:1104,y:659,t:1512065517246};\\\", \\\"{x:1104,y:630,t:1512065517262};\\\", \\\"{x:1104,y:613,t:1512065517279};\\\", \\\"{x:1105,y:599,t:1512065517296};\\\", \\\"{x:1106,y:586,t:1512065517312};\\\", \\\"{x:1106,y:575,t:1512065517329};\\\", \\\"{x:1106,y:562,t:1512065517346};\\\", \\\"{x:1106,y:554,t:1512065517362};\\\", \\\"{x:1106,y:552,t:1512065517379};\\\", \\\"{x:1106,y:550,t:1512065517395};\\\", \\\"{x:1103,y:550,t:1512065517427};\\\", \\\"{x:1098,y:550,t:1512065517435};\\\", \\\"{x:1095,y:551,t:1512065517447};\\\", \\\"{x:1090,y:555,t:1512065517463};\\\", \\\"{x:1086,y:559,t:1512065517479};\\\", \\\"{x:1082,y:566,t:1512065517496};\\\", \\\"{x:1070,y:582,t:1512065517513};\\\", \\\"{x:1056,y:599,t:1512065517529};\\\", \\\"{x:1048,y:611,t:1512065517546};\\\", \\\"{x:1044,y:618,t:1512065517563};\\\", \\\"{x:1042,y:625,t:1512065517579};\\\", \\\"{x:1042,y:630,t:1512065517596};\\\", \\\"{x:1042,y:631,t:1512065517613};\\\", \\\"{x:1042,y:633,t:1512065517643};\\\", \\\"{x:1044,y:635,t:1512065517667};\\\", \\\"{x:1046,y:635,t:1512065517679};\\\", \\\"{x:1050,y:637,t:1512065517696};\\\", \\\"{x:1052,y:637,t:1512065517713};\\\", \\\"{x:1053,y:637,t:1512065517739};\\\", \\\"{x:1054,y:637,t:1512065517747};\\\", \\\"{x:1055,y:637,t:1512065517763};\\\", \\\"{x:1058,y:636,t:1512065517779};\\\", \\\"{x:1061,y:634,t:1512065517796};\\\", \\\"{x:1066,y:631,t:1512065517813};\\\", \\\"{x:1068,y:629,t:1512065517830};\\\", \\\"{x:1071,y:627,t:1512065517853};\\\", \\\"{x:1071,y:626,t:1512065517899};\\\", \\\"{x:1072,y:626,t:1512065517914};\\\", \\\"{x:1073,y:626,t:1512065517929};\\\", \\\"{x:1074,y:625,t:1512065517945};\\\", \\\"{x:1075,y:624,t:1512065517963};\\\", \\\"{x:1076,y:624,t:1512065517979};\\\", \\\"{x:1076,y:626,t:1512065518400};\\\", \\\"{x:1076,y:627,t:1512065518413};\\\", \\\"{x:1075,y:629,t:1512065518429};\\\", \\\"{x:1075,y:630,t:1512065518660};\\\", \\\"{x:1074,y:631,t:1512065518716};\\\", \\\"{x:1070,y:631,t:1512065520160};\\\", \\\"{x:1009,y:631,t:1512065520180};\\\", \\\"{x:956,y:631,t:1512065520197};\\\", \\\"{x:929,y:631,t:1512065520214};\\\", \\\"{x:876,y:631,t:1512065520230};\\\", \\\"{x:782,y:631,t:1512065520247};\\\", \\\"{x:698,y:631,t:1512065520264};\\\", \\\"{x:637,y:631,t:1512065520280};\\\", \\\"{x:589,y:631,t:1512065520297};\\\", \\\"{x:522,y:631,t:1512065520314};\\\", \\\"{x:498,y:634,t:1512065520330};\\\", \\\"{x:488,y:635,t:1512065520347};\\\", \\\"{x:486,y:635,t:1512065520364};\\\", \\\"{x:483,y:636,t:1512065520380};\\\", \\\"{x:482,y:636,t:1512065520397};\\\", \\\"{x:475,y:636,t:1512065520414};\\\", \\\"{x:467,y:636,t:1512065520431};\\\", \\\"{x:463,y:636,t:1512065520447};\\\", \\\"{x:460,y:637,t:1512065520464};\\\", \\\"{x:459,y:635,t:1512065520498};\\\", \\\"{x:461,y:620,t:1512065520514};\\\", \\\"{x:465,y:613,t:1512065520530};\\\", \\\"{x:469,y:604,t:1512065520547};\\\", \\\"{x:471,y:597,t:1512065520564};\\\", \\\"{x:472,y:596,t:1512065520602};\\\", \\\"{x:473,y:595,t:1512065520618};\\\", \\\"{x:476,y:594,t:1512065520631};\\\", \\\"{x:482,y:591,t:1512065520647};\\\", \\\"{x:486,y:589,t:1512065520664};\\\", \\\"{x:489,y:588,t:1512065520681};\\\", \\\"{x:490,y:588,t:1512065520697};\\\", \\\"{x:491,y:588,t:1512065520738};\\\", \\\"{x:493,y:586,t:1512065520755};\\\", \\\"{x:495,y:586,t:1512065520764};\\\", \\\"{x:502,y:585,t:1512065520781};\\\", \\\"{x:506,y:584,t:1512065520798};\\\", \\\"{x:507,y:584,t:1512065520827};\\\", \\\"{x:506,y:584,t:1512065520947};\\\", \\\"{x:505,y:584,t:1512065520971};\\\", \\\"{x:504,y:584,t:1512065520981};\\\", \\\"{x:503,y:584,t:1512065520999};\\\", \\\"{x:501,y:584,t:1512065521014};\\\", \\\"{x:500,y:585,t:1512065521032};\\\", \\\"{x:499,y:586,t:1512065521048};\\\", \\\"{x:498,y:586,t:1512065521083};\\\", \\\"{x:497,y:586,t:1512065521099};\\\", \\\"{x:496,y:587,t:1512065521203};\\\", \\\"{x:495,y:587,t:1512065521323};\\\", \\\"{x:494,y:587,t:1512065521716};\\\", \\\"{x:493,y:587,t:1512065521867};\\\", \\\"{x:489,y:590,t:1512065521883};\\\", \\\"{x:487,y:590,t:1512065521898};\\\", \\\"{x:486,y:591,t:1512065521917};\\\", \\\"{x:484,y:592,t:1512065521932};\\\", \\\"{x:481,y:593,t:1512065521948};\\\", \\\"{x:479,y:595,t:1512065521965};\\\", \\\"{x:462,y:623,t:1512065521982};\\\", \\\"{x:441,y:663,t:1512065521998};\\\", \\\"{x:434,y:675,t:1512065522015};\\\", \\\"{x:428,y:684,t:1512065522032};\\\", \\\"{x:425,y:690,t:1512065522048};\\\", \\\"{x:422,y:696,t:1512065522065};\\\", \\\"{x:419,y:707,t:1512065522082};\\\", \\\"{x:418,y:712,t:1512065522098};\\\", \\\"{x:418,y:714,t:1512065522116};\\\", \\\"{x:418,y:715,t:1512065522132};\\\", \\\"{x:418,y:717,t:1512065522149};\\\", \\\"{x:417,y:718,t:1512065522165};\\\", \\\"{x:416,y:719,t:1512065522182};\\\", \\\"{x:416,y:720,t:1512065522199};\\\", \\\"{x:416,y:721,t:1512065522219};\\\", \\\"{x:416,y:722,t:1512065522235};\\\", \\\"{x:415,y:724,t:1512065522249};\\\", \\\"{x:416,y:724,t:1512065524435};\\\", \\\"{x:419,y:724,t:1512065524451};\\\", \\\"{x:430,y:725,t:1512065524469};\\\", \\\"{x:454,y:733,t:1512065524484};\\\", \\\"{x:475,y:737,t:1512065524500};\\\", \\\"{x:507,y:742,t:1512065524517};\\\", \\\"{x:570,y:749,t:1512065524534};\\\", \\\"{x:621,y:749,t:1512065524550};\\\", \\\"{x:643,y:749,t:1512065524567};\\\", \\\"{x:656,y:749,t:1512065524584};\\\", \\\"{x:667,y:747,t:1512065524600};\\\", \\\"{x:672,y:745,t:1512065524617};\\\", \\\"{x:676,y:742,t:1512065524634};\\\", \\\"{x:681,y:740,t:1512065524650};\\\", \\\"{x:687,y:736,t:1512065524667};\\\", \\\"{x:697,y:727,t:1512065524684};\\\", \\\"{x:711,y:716,t:1512065524701};\\\", \\\"{x:725,y:701,t:1512065524717};\\\", \\\"{x:739,y:687,t:1512065524734};\\\", \\\"{x:754,y:674,t:1512065524751};\\\", \\\"{x:771,y:656,t:1512065524767};\\\", \\\"{x:778,y:647,t:1512065524784};\\\", \\\"{x:785,y:640,t:1512065524801};\\\", \\\"{x:797,y:623,t:1512065524817};\\\", \\\"{x:805,y:611,t:1512065524835};\\\", \\\"{x:810,y:603,t:1512065524851};\\\", \\\"{x:814,y:598,t:1512065524867};\\\", \\\"{x:815,y:596,t:1512065524884};\\\" ] }, { \\\"rt\\\": 11230, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 299827, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -E -E -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:816,y:595,t:1512065525772};\\\", \\\"{x:817,y:595,t:1512065525786};\\\", \\\"{x:818,y:593,t:1512065525802};\\\", \\\"{x:826,y:569,t:1512065525818};\\\", \\\"{x:834,y:541,t:1512065525836};\\\", \\\"{x:838,y:516,t:1512065525852};\\\", \\\"{x:840,y:497,t:1512065525869};\\\", \\\"{x:841,y:478,t:1512065525886};\\\", \\\"{x:841,y:453,t:1512065525902};\\\", \\\"{x:837,y:431,t:1512065525919};\\\", \\\"{x:828,y:407,t:1512065525936};\\\", \\\"{x:821,y:388,t:1512065525952};\\\", \\\"{x:816,y:378,t:1512065525969};\\\", \\\"{x:814,y:373,t:1512065525986};\\\", \\\"{x:811,y:369,t:1512065526002};\\\", \\\"{x:809,y:366,t:1512065526019};\\\", \\\"{x:809,y:364,t:1512065527820};\\\", \\\"{x:819,y:363,t:1512065527838};\\\", \\\"{x:844,y:358,t:1512065527855};\\\", \\\"{x:855,y:357,t:1512065527871};\\\", \\\"{x:859,y:356,t:1512065527888};\\\", \\\"{x:864,y:354,t:1512065527905};\\\", \\\"{x:869,y:352,t:1512065527921};\\\", \\\"{x:870,y:352,t:1512065527938};\\\", \\\"{x:871,y:351,t:1512065527955};\\\", \\\"{x:872,y:351,t:1512065527972};\\\", \\\"{x:873,y:351,t:1512065527988};\\\", \\\"{x:875,y:351,t:1512065528020};\\\", \\\"{x:876,y:352,t:1512065528028};\\\", \\\"{x:878,y:354,t:1512065528038};\\\", \\\"{x:880,y:364,t:1512065528055};\\\", \\\"{x:883,y:378,t:1512065528072};\\\", \\\"{x:883,y:391,t:1512065528088};\\\", \\\"{x:885,y:404,t:1512065528104};\\\", \\\"{x:887,y:424,t:1512065528121};\\\", \\\"{x:888,y:441,t:1512065528137};\\\", \\\"{x:889,y:460,t:1512065528154};\\\", \\\"{x:889,y:486,t:1512065528171};\\\", \\\"{x:889,y:496,t:1512065528187};\\\", \\\"{x:886,y:511,t:1512065528204};\\\", \\\"{x:886,y:519,t:1512065528221};\\\", \\\"{x:885,y:522,t:1512065528237};\\\", \\\"{x:884,y:523,t:1512065528254};\\\", \\\"{x:884,y:525,t:1512065528271};\\\", \\\"{x:884,y:526,t:1512065528308};\\\", \\\"{x:884,y:527,t:1512065528348};\\\", \\\"{x:884,y:528,t:1512065528372};\\\", \\\"{x:884,y:529,t:1512065528396};\\\", \\\"{x:884,y:531,t:1512065528412};\\\", \\\"{x:884,y:532,t:1512065528436};\\\", \\\"{x:884,y:534,t:1512065528460};\\\", \\\"{x:884,y:536,t:1512065528484};\\\", \\\"{x:884,y:540,t:1512065528492};\\\", \\\"{x:884,y:542,t:1512065528505};\\\", \\\"{x:886,y:551,t:1512065528522};\\\", \\\"{x:889,y:556,t:1512065528539};\\\", \\\"{x:893,y:565,t:1512065528555};\\\", \\\"{x:898,y:570,t:1512065528572};\\\", \\\"{x:901,y:573,t:1512065528588};\\\", \\\"{x:903,y:576,t:1512065528605};\\\", \\\"{x:906,y:577,t:1512065528622};\\\", \\\"{x:910,y:579,t:1512065528639};\\\", \\\"{x:919,y:581,t:1512065528655};\\\", \\\"{x:937,y:584,t:1512065528672};\\\", \\\"{x:960,y:586,t:1512065528689};\\\", \\\"{x:989,y:589,t:1512065528705};\\\", \\\"{x:1019,y:589,t:1512065528722};\\\", \\\"{x:1045,y:589,t:1512065528739};\\\", \\\"{x:1064,y:585,t:1512065528755};\\\", \\\"{x:1082,y:579,t:1512065528772};\\\", \\\"{x:1091,y:577,t:1512065528789};\\\", \\\"{x:1098,y:573,t:1512065528805};\\\", \\\"{x:1103,y:571,t:1512065528822};\\\", \\\"{x:1104,y:571,t:1512065528839};\\\", \\\"{x:1105,y:570,t:1512065528855};\\\", \\\"{x:1106,y:570,t:1512065528884};\\\", \\\"{x:1108,y:570,t:1512065528892};\\\", \\\"{x:1109,y:570,t:1512065528908};\\\", \\\"{x:1111,y:569,t:1512065528922};\\\", \\\"{x:1111,y:568,t:1512065528939};\\\", \\\"{x:1111,y:567,t:1512065528980};\\\", \\\"{x:1111,y:566,t:1512065528989};\\\", \\\"{x:1108,y:564,t:1512065529006};\\\", \\\"{x:1106,y:564,t:1512065529022};\\\", \\\"{x:1105,y:564,t:1512065529039};\\\", \\\"{x:1101,y:563,t:1512065529056};\\\", \\\"{x:1098,y:562,t:1512065529072};\\\", \\\"{x:1096,y:561,t:1512065529089};\\\", \\\"{x:1095,y:561,t:1512065529108};\\\", \\\"{x:1094,y:561,t:1512065529134};\\\", \\\"{x:1092,y:561,t:1512065529155};\\\", \\\"{x:1089,y:561,t:1512065529171};\\\", \\\"{x:1087,y:561,t:1512065529188};\\\", \\\"{x:1083,y:561,t:1512065529205};\\\", \\\"{x:1082,y:561,t:1512065529221};\\\", \\\"{x:1081,y:561,t:1512065529291};\\\", \\\"{x:1081,y:559,t:1512065529620};\\\", \\\"{x:1081,y:557,t:1512065529636};\\\", \\\"{x:1081,y:555,t:1512065529644};\\\", \\\"{x:1081,y:554,t:1512065529656};\\\", \\\"{x:1081,y:550,t:1512065529673};\\\", \\\"{x:1081,y:548,t:1512065529689};\\\", \\\"{x:1082,y:548,t:1512065529971};\\\", \\\"{x:1083,y:551,t:1512065529979};\\\", \\\"{x:1086,y:557,t:1512065529989};\\\", \\\"{x:1089,y:563,t:1512065530005};\\\", \\\"{x:1090,y:564,t:1512065530022};\\\", \\\"{x:1090,y:567,t:1512065530039};\\\", \\\"{x:1091,y:567,t:1512065530055};\\\", \\\"{x:1091,y:568,t:1512065530072};\\\", \\\"{x:1090,y:568,t:1512065530284};\\\", \\\"{x:1089,y:567,t:1512065530291};\\\", \\\"{x:1088,y:566,t:1512065530306};\\\", \\\"{x:1087,y:563,t:1512065530323};\\\", \\\"{x:1085,y:558,t:1512065530340};\\\", \\\"{x:1085,y:556,t:1512065530356};\\\", \\\"{x:1085,y:555,t:1512065530540};\\\", \\\"{x:1086,y:555,t:1512065530708};\\\", \\\"{x:1086,y:556,t:1512065530723};\\\", \\\"{x:1086,y:557,t:1512065530740};\\\", \\\"{x:1086,y:558,t:1512065530772};\\\", \\\"{x:1086,y:559,t:1512065530790};\\\", \\\"{x:1086,y:560,t:1512065531444};\\\", \\\"{x:1086,y:561,t:1512065532196};\\\", \\\"{x:1088,y:561,t:1512065532660};\\\", \\\"{x:1090,y:561,t:1512065532675};\\\", \\\"{x:1091,y:560,t:1512065532691};\\\", \\\"{x:1092,y:560,t:1512065532731};\\\", \\\"{x:1093,y:560,t:1512065532763};\\\", \\\"{x:1095,y:559,t:1512065532775};\\\", \\\"{x:1100,y:558,t:1512065532792};\\\", \\\"{x:1113,y:558,t:1512065532808};\\\", \\\"{x:1129,y:557,t:1512065532825};\\\", \\\"{x:1150,y:554,t:1512065532842};\\\", \\\"{x:1167,y:552,t:1512065532858};\\\", \\\"{x:1175,y:550,t:1512065532875};\\\", \\\"{x:1179,y:550,t:1512065532891};\\\", \\\"{x:1182,y:549,t:1512065532908};\\\", \\\"{x:1184,y:549,t:1512065532925};\\\", \\\"{x:1186,y:548,t:1512065532942};\\\", \\\"{x:1189,y:547,t:1512065532958};\\\", \\\"{x:1193,y:546,t:1512065532975};\\\", \\\"{x:1195,y:546,t:1512065532992};\\\", \\\"{x:1198,y:546,t:1512065533008};\\\", \\\"{x:1201,y:546,t:1512065533025};\\\", \\\"{x:1205,y:546,t:1512065533042};\\\", \\\"{x:1214,y:547,t:1512065533058};\\\", \\\"{x:1224,y:549,t:1512065533075};\\\", \\\"{x:1232,y:551,t:1512065533092};\\\", \\\"{x:1241,y:552,t:1512065533108};\\\", \\\"{x:1245,y:553,t:1512065533125};\\\", \\\"{x:1251,y:553,t:1512065533142};\\\", \\\"{x:1254,y:555,t:1512065533158};\\\", \\\"{x:1257,y:555,t:1512065533175};\\\", \\\"{x:1259,y:555,t:1512065533192};\\\", \\\"{x:1261,y:555,t:1512065533209};\\\", \\\"{x:1262,y:555,t:1512065533243};\\\", \\\"{x:1262,y:556,t:1512065533258};\\\", \\\"{x:1263,y:556,t:1512065533275};\\\", \\\"{x:1264,y:557,t:1512065533348};\\\", \\\"{x:1264,y:559,t:1512065533404};\\\", \\\"{x:1255,y:564,t:1512065533411};\\\", \\\"{x:1242,y:569,t:1512065533425};\\\", \\\"{x:1196,y:578,t:1512065533442};\\\", \\\"{x:1116,y:585,t:1512065533459};\\\", \\\"{x:1002,y:585,t:1512065533475};\\\", \\\"{x:803,y:585,t:1512065533491};\\\", \\\"{x:676,y:585,t:1512065533509};\\\", \\\"{x:562,y:585,t:1512065533525};\\\", \\\"{x:490,y:585,t:1512065533542};\\\", \\\"{x:448,y:585,t:1512065533559};\\\", \\\"{x:419,y:585,t:1512065533574};\\\", \\\"{x:399,y:585,t:1512065533592};\\\", \\\"{x:379,y:589,t:1512065533609};\\\", \\\"{x:361,y:591,t:1512065533625};\\\", \\\"{x:335,y:597,t:1512065533642};\\\", \\\"{x:293,y:607,t:1512065533658};\\\", \\\"{x:243,y:620,t:1512065533675};\\\", \\\"{x:196,y:633,t:1512065533692};\\\", \\\"{x:182,y:635,t:1512065533709};\\\", \\\"{x:180,y:635,t:1512065533726};\\\", \\\"{x:178,y:635,t:1512065533742};\\\", \\\"{x:184,y:627,t:1512065533779};\\\", \\\"{x:200,y:613,t:1512065533792};\\\", \\\"{x:230,y:596,t:1512065533809};\\\", \\\"{x:250,y:587,t:1512065533826};\\\", \\\"{x:266,y:581,t:1512065533842};\\\", \\\"{x:283,y:573,t:1512065533860};\\\", \\\"{x:292,y:571,t:1512065533876};\\\", \\\"{x:298,y:568,t:1512065533893};\\\", \\\"{x:302,y:567,t:1512065533910};\\\", \\\"{x:307,y:567,t:1512065533926};\\\", \\\"{x:315,y:564,t:1512065533944};\\\", \\\"{x:328,y:558,t:1512065533959};\\\", \\\"{x:339,y:552,t:1512065533976};\\\", \\\"{x:341,y:550,t:1512065533993};\\\", \\\"{x:342,y:548,t:1512065534009};\\\", \\\"{x:343,y:548,t:1512065534026};\\\", \\\"{x:343,y:547,t:1512065534051};\\\", \\\"{x:344,y:547,t:1512065534067};\\\", \\\"{x:344,y:546,t:1512065534076};\\\", \\\"{x:347,y:543,t:1512065534093};\\\", \\\"{x:349,y:542,t:1512065534109};\\\", \\\"{x:352,y:539,t:1512065534126};\\\", \\\"{x:355,y:536,t:1512065534144};\\\", \\\"{x:359,y:533,t:1512065534159};\\\", \\\"{x:364,y:532,t:1512065534176};\\\", \\\"{x:380,y:529,t:1512065534193};\\\", \\\"{x:395,y:527,t:1512065534210};\\\", \\\"{x:405,y:526,t:1512065534227};\\\", \\\"{x:411,y:523,t:1512065534243};\\\", \\\"{x:414,y:523,t:1512065534259};\\\", \\\"{x:415,y:523,t:1512065534276};\\\", \\\"{x:416,y:523,t:1512065534293};\\\", \\\"{x:418,y:523,t:1512065534310};\\\", \\\"{x:419,y:524,t:1512065534379};\\\", \\\"{x:419,y:525,t:1512065534452};\\\", \\\"{x:419,y:526,t:1512065534461};\\\", \\\"{x:419,y:527,t:1512065534477};\\\", \\\"{x:418,y:528,t:1512065534499};\\\", \\\"{x:418,y:529,t:1512065534510};\\\", \\\"{x:418,y:530,t:1512065534527};\\\", \\\"{x:417,y:530,t:1512065534544};\\\", \\\"{x:417,y:531,t:1512065534561};\\\", \\\"{x:415,y:533,t:1512065534577};\\\", \\\"{x:414,y:533,t:1512065534603};\\\", \\\"{x:413,y:533,t:1512065534627};\\\", \\\"{x:412,y:534,t:1512065534644};\\\", \\\"{x:411,y:535,t:1512065534675};\\\", \\\"{x:410,y:536,t:1512065534683};\\\", \\\"{x:409,y:536,t:1512065534698};\\\", \\\"{x:407,y:537,t:1512065534714};\\\", \\\"{x:406,y:537,t:1512065534726};\\\", \\\"{x:405,y:538,t:1512065534743};\\\", \\\"{x:404,y:539,t:1512065534778};\\\", \\\"{x:404,y:538,t:1512065534932};\\\", \\\"{x:404,y:537,t:1512065534944};\\\", \\\"{x:404,y:536,t:1512065534960};\\\", \\\"{x:404,y:535,t:1512065534979};\\\", \\\"{x:404,y:534,t:1512065534995};\\\", \\\"{x:404,y:533,t:1512065535011};\\\", \\\"{x:403,y:533,t:1512065535299};\\\", \\\"{x:403,y:534,t:1512065535310};\\\", \\\"{x:403,y:536,t:1512065535327};\\\", \\\"{x:402,y:539,t:1512065535344};\\\", \\\"{x:402,y:540,t:1512065535360};\\\", \\\"{x:402,y:542,t:1512065535377};\\\", \\\"{x:402,y:543,t:1512065535393};\\\", \\\"{x:402,y:544,t:1512065535427};\\\", \\\"{x:402,y:545,t:1512065535443};\\\", \\\"{x:402,y:546,t:1512065535460};\\\", \\\"{x:402,y:548,t:1512065535478};\\\", \\\"{x:402,y:549,t:1512065535493};\\\", \\\"{x:402,y:550,t:1512065535515};\\\", \\\"{x:402,y:551,t:1512065535527};\\\", \\\"{x:402,y:552,t:1512065535544};\\\", \\\"{x:402,y:555,t:1512065535561};\\\", \\\"{x:402,y:557,t:1512065535577};\\\", \\\"{x:402,y:558,t:1512065535593};\\\", \\\"{x:402,y:560,t:1512065535610};\\\", \\\"{x:402,y:561,t:1512065535626};\\\", \\\"{x:402,y:563,t:1512065535650};\\\", \\\"{x:402,y:564,t:1512065535666};\\\", \\\"{x:402,y:566,t:1512065535682};\\\", \\\"{x:402,y:568,t:1512065536076};\\\", \\\"{x:398,y:590,t:1512065536095};\\\", \\\"{x:396,y:616,t:1512065536110};\\\", \\\"{x:395,y:641,t:1512065536127};\\\", \\\"{x:395,y:658,t:1512065536144};\\\", \\\"{x:395,y:669,t:1512065536161};\\\", \\\"{x:395,y:677,t:1512065536178};\\\", \\\"{x:393,y:681,t:1512065536194};\\\", \\\"{x:393,y:683,t:1512065536210};\\\", \\\"{x:393,y:684,t:1512065536234};\\\", \\\"{x:393,y:685,t:1512065536250};\\\", \\\"{x:393,y:686,t:1512065536260};\\\", \\\"{x:393,y:687,t:1512065536854};\\\", \\\"{x:395,y:687,t:1512065536870};\\\", \\\"{x:396,y:687,t:1512065536881};\\\", \\\"{x:407,y:688,t:1512065536897};\\\", \\\"{x:428,y:693,t:1512065536914};\\\", \\\"{x:449,y:698,t:1512065536931};\\\", \\\"{x:482,y:703,t:1512065536948};\\\", \\\"{x:541,y:704,t:1512065536964};\\\", \\\"{x:597,y:704,t:1512065536981};\\\", \\\"{x:667,y:704,t:1512065536998};\\\", \\\"{x:694,y:704,t:1512065537014};\\\", \\\"{x:711,y:704,t:1512065537031};\\\", \\\"{x:729,y:704,t:1512065537048};\\\", \\\"{x:738,y:703,t:1512065537064};\\\", \\\"{x:744,y:701,t:1512065537081};\\\", \\\"{x:756,y:696,t:1512065537098};\\\", \\\"{x:766,y:691,t:1512065537114};\\\", \\\"{x:772,y:689,t:1512065537131};\\\", \\\"{x:773,y:688,t:1512065537148};\\\", \\\"{x:774,y:687,t:1512065537166};\\\" ] }, { \\\"rt\\\": 25757, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 326888, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:770,y:687,t:1512065538470};\\\", \\\"{x:769,y:687,t:1512065538482};\\\", \\\"{x:765,y:687,t:1512065538499};\\\", \\\"{x:752,y:684,t:1512065538515};\\\", \\\"{x:739,y:676,t:1512065538532};\\\", \\\"{x:721,y:658,t:1512065538550};\\\", \\\"{x:702,y:636,t:1512065538566};\\\", \\\"{x:674,y:605,t:1512065538582};\\\", \\\"{x:634,y:576,t:1512065538600};\\\", \\\"{x:611,y:562,t:1512065538615};\\\", \\\"{x:573,y:541,t:1512065538633};\\\", \\\"{x:534,y:524,t:1512065538649};\\\", \\\"{x:498,y:508,t:1512065538666};\\\", \\\"{x:472,y:498,t:1512065538683};\\\", \\\"{x:451,y:487,t:1512065538699};\\\", \\\"{x:429,y:475,t:1512065538716};\\\", \\\"{x:413,y:468,t:1512065538733};\\\", \\\"{x:387,y:456,t:1512065538750};\\\", \\\"{x:372,y:452,t:1512065538766};\\\", \\\"{x:353,y:446,t:1512065538782};\\\", \\\"{x:338,y:445,t:1512065538799};\\\", \\\"{x:319,y:442,t:1512065538816};\\\", \\\"{x:297,y:440,t:1512065538832};\\\", \\\"{x:276,y:438,t:1512065538849};\\\", \\\"{x:258,y:438,t:1512065538866};\\\", \\\"{x:243,y:438,t:1512065538882};\\\", \\\"{x:231,y:438,t:1512065538899};\\\", \\\"{x:226,y:439,t:1512065538916};\\\", \\\"{x:221,y:442,t:1512065538932};\\\", \\\"{x:207,y:450,t:1512065538950};\\\", \\\"{x:200,y:455,t:1512065538966};\\\", \\\"{x:196,y:460,t:1512065538983};\\\", \\\"{x:194,y:465,t:1512065539000};\\\", \\\"{x:190,y:473,t:1512065539016};\\\", \\\"{x:185,y:484,t:1512065539033};\\\", \\\"{x:183,y:489,t:1512065539049};\\\", \\\"{x:180,y:497,t:1512065539067};\\\", \\\"{x:178,y:501,t:1512065539082};\\\", \\\"{x:177,y:503,t:1512065539100};\\\", \\\"{x:178,y:503,t:1512065539278};\\\", \\\"{x:181,y:503,t:1512065539286};\\\", \\\"{x:187,y:500,t:1512065539300};\\\", \\\"{x:201,y:498,t:1512065539317};\\\", \\\"{x:225,y:490,t:1512065539334};\\\", \\\"{x:243,y:484,t:1512065539350};\\\", \\\"{x:256,y:482,t:1512065539366};\\\", \\\"{x:260,y:480,t:1512065539383};\\\", \\\"{x:262,y:480,t:1512065539400};\\\", \\\"{x:263,y:479,t:1512065539416};\\\", \\\"{x:262,y:479,t:1512065539814};\\\", \\\"{x:258,y:477,t:1512065539830};\\\", \\\"{x:256,y:476,t:1512065539838};\\\", \\\"{x:255,y:476,t:1512065539850};\\\", \\\"{x:254,y:476,t:1512065539866};\\\", \\\"{x:253,y:476,t:1512065539883};\\\", \\\"{x:252,y:476,t:1512065539900};\\\", \\\"{x:251,y:476,t:1512065539916};\\\", \\\"{x:251,y:475,t:1512065540013};\\\", \\\"{x:251,y:474,t:1512065540021};\\\", \\\"{x:251,y:473,t:1512065540033};\\\", \\\"{x:257,y:469,t:1512065540050};\\\", \\\"{x:260,y:467,t:1512065540067};\\\", \\\"{x:263,y:466,t:1512065540083};\\\", \\\"{x:266,y:465,t:1512065540100};\\\", \\\"{x:277,y:461,t:1512065540117};\\\", \\\"{x:285,y:460,t:1512065540133};\\\", \\\"{x:292,y:459,t:1512065540150};\\\", \\\"{x:299,y:457,t:1512065540167};\\\", \\\"{x:308,y:456,t:1512065540183};\\\", \\\"{x:318,y:454,t:1512065540200};\\\", \\\"{x:325,y:453,t:1512065540217};\\\", \\\"{x:331,y:452,t:1512065540233};\\\", \\\"{x:335,y:452,t:1512065540250};\\\", \\\"{x:338,y:450,t:1512065540267};\\\", \\\"{x:342,y:449,t:1512065540283};\\\", \\\"{x:344,y:448,t:1512065540300};\\\", \\\"{x:350,y:446,t:1512065540318};\\\", \\\"{x:355,y:444,t:1512065540334};\\\", \\\"{x:358,y:442,t:1512065540350};\\\", \\\"{x:362,y:441,t:1512065540367};\\\", \\\"{x:366,y:439,t:1512065540383};\\\", \\\"{x:368,y:438,t:1512065540400};\\\", \\\"{x:372,y:437,t:1512065540417};\\\", \\\"{x:378,y:435,t:1512065540433};\\\", \\\"{x:386,y:433,t:1512065540450};\\\", \\\"{x:392,y:431,t:1512065540467};\\\", \\\"{x:398,y:429,t:1512065540484};\\\", \\\"{x:403,y:428,t:1512065540500};\\\", \\\"{x:403,y:427,t:1512065540517};\\\", \\\"{x:404,y:427,t:1512065540542};\\\", \\\"{x:404,y:426,t:1512065544463};\\\", \\\"{x:409,y:424,t:1512065544471};\\\", \\\"{x:420,y:421,t:1512065544488};\\\", \\\"{x:425,y:419,t:1512065544504};\\\", \\\"{x:430,y:418,t:1512065544521};\\\", \\\"{x:435,y:417,t:1512065544538};\\\", \\\"{x:441,y:416,t:1512065544554};\\\", \\\"{x:444,y:415,t:1512065544571};\\\", \\\"{x:449,y:414,t:1512065544588};\\\", \\\"{x:453,y:414,t:1512065544604};\\\", \\\"{x:459,y:413,t:1512065544621};\\\", \\\"{x:474,y:412,t:1512065544638};\\\", \\\"{x:481,y:411,t:1512065544654};\\\", \\\"{x:491,y:410,t:1512065544671};\\\", \\\"{x:501,y:409,t:1512065544688};\\\", \\\"{x:509,y:409,t:1512065544704};\\\", \\\"{x:517,y:409,t:1512065544721};\\\", \\\"{x:522,y:409,t:1512065544738};\\\", \\\"{x:526,y:409,t:1512065544754};\\\", \\\"{x:533,y:409,t:1512065544771};\\\", \\\"{x:545,y:409,t:1512065544788};\\\", \\\"{x:562,y:409,t:1512065544804};\\\", \\\"{x:577,y:412,t:1512065544822};\\\", \\\"{x:609,y:416,t:1512065544839};\\\", \\\"{x:634,y:420,t:1512065544854};\\\", \\\"{x:656,y:423,t:1512065544871};\\\", \\\"{x:677,y:425,t:1512065544888};\\\", \\\"{x:698,y:430,t:1512065544906};\\\", \\\"{x:709,y:430,t:1512065544921};\\\", \\\"{x:717,y:430,t:1512065544938};\\\", \\\"{x:727,y:430,t:1512065544955};\\\", \\\"{x:734,y:430,t:1512065544971};\\\", \\\"{x:738,y:430,t:1512065544988};\\\", \\\"{x:742,y:430,t:1512065545005};\\\", \\\"{x:745,y:430,t:1512065545021};\\\", \\\"{x:750,y:433,t:1512065545039};\\\", \\\"{x:756,y:434,t:1512065545055};\\\", \\\"{x:764,y:438,t:1512065545071};\\\", \\\"{x:766,y:438,t:1512065545088};\\\", \\\"{x:767,y:438,t:1512065545105};\\\", \\\"{x:773,y:441,t:1512065545121};\\\", \\\"{x:779,y:446,t:1512065545138};\\\", \\\"{x:795,y:461,t:1512065545156};\\\", \\\"{x:814,y:483,t:1512065545172};\\\", \\\"{x:832,y:511,t:1512065545189};\\\", \\\"{x:844,y:536,t:1512065545206};\\\", \\\"{x:855,y:560,t:1512065545222};\\\", \\\"{x:867,y:588,t:1512065545239};\\\", \\\"{x:874,y:604,t:1512065545256};\\\", \\\"{x:885,y:619,t:1512065545271};\\\", \\\"{x:894,y:632,t:1512065545288};\\\", \\\"{x:900,y:640,t:1512065545305};\\\", \\\"{x:902,y:643,t:1512065545322};\\\", \\\"{x:903,y:645,t:1512065545338};\\\", \\\"{x:905,y:646,t:1512065546023};\\\", \\\"{x:913,y:646,t:1512065546039};\\\", \\\"{x:919,y:644,t:1512065546056};\\\", \\\"{x:921,y:643,t:1512065546073};\\\", \\\"{x:925,y:643,t:1512065546090};\\\", \\\"{x:930,y:643,t:1512065546106};\\\", \\\"{x:933,y:642,t:1512065546123};\\\", \\\"{x:936,y:641,t:1512065546140};\\\", \\\"{x:938,y:640,t:1512065546156};\\\", \\\"{x:940,y:640,t:1512065546173};\\\", \\\"{x:943,y:639,t:1512065546190};\\\", \\\"{x:944,y:638,t:1512065546206};\\\", \\\"{x:945,y:637,t:1512065546223};\\\", \\\"{x:946,y:636,t:1512065546239};\\\", \\\"{x:946,y:635,t:1512065546495};\\\", \\\"{x:947,y:635,t:1512065546507};\\\", \\\"{x:947,y:634,t:1512065546575};\\\", \\\"{x:948,y:633,t:1512065546591};\\\", \\\"{x:949,y:632,t:1512065546606};\\\", \\\"{x:950,y:632,t:1512065546623};\\\", \\\"{x:950,y:631,t:1512065546640};\\\", \\\"{x:951,y:630,t:1512065546657};\\\", \\\"{x:952,y:628,t:1512065546674};\\\", \\\"{x:952,y:627,t:1512065546711};\\\", \\\"{x:952,y:628,t:1512065546807};\\\", \\\"{x:951,y:633,t:1512065546823};\\\", \\\"{x:950,y:639,t:1512065546840};\\\", \\\"{x:949,y:642,t:1512065546857};\\\", \\\"{x:949,y:646,t:1512065546874};\\\", \\\"{x:949,y:652,t:1512065546890};\\\", \\\"{x:949,y:657,t:1512065546907};\\\", \\\"{x:949,y:662,t:1512065546924};\\\", \\\"{x:949,y:666,t:1512065546940};\\\", \\\"{x:949,y:670,t:1512065546957};\\\", \\\"{x:950,y:674,t:1512065546974};\\\", \\\"{x:951,y:677,t:1512065546990};\\\", \\\"{x:952,y:680,t:1512065547006};\\\", \\\"{x:952,y:681,t:1512065547039};\\\", \\\"{x:952,y:682,t:1512065547057};\\\", \\\"{x:954,y:683,t:1512065547074};\\\", \\\"{x:954,y:684,t:1512065547090};\\\", \\\"{x:955,y:685,t:1512065547111};\\\", \\\"{x:956,y:686,t:1512065547151};\\\", \\\"{x:957,y:686,t:1512065547167};\\\", \\\"{x:957,y:687,t:1512065547183};\\\", \\\"{x:958,y:687,t:1512065547191};\\\", \\\"{x:960,y:687,t:1512065547207};\\\", \\\"{x:961,y:688,t:1512065547224};\\\", \\\"{x:962,y:688,t:1512065547241};\\\", \\\"{x:963,y:688,t:1512065547257};\\\", \\\"{x:964,y:689,t:1512065547583};\\\", \\\"{x:964,y:691,t:1512065547599};\\\", \\\"{x:964,y:692,t:1512065547607};\\\", \\\"{x:964,y:695,t:1512065547624};\\\", \\\"{x:964,y:696,t:1512065547647};\\\", \\\"{x:964,y:697,t:1512065547670};\\\", \\\"{x:964,y:698,t:1512065548679};\\\", \\\"{x:965,y:698,t:1512065548759};\\\", \\\"{x:966,y:698,t:1512065548815};\\\", \\\"{x:967,y:697,t:1512065548825};\\\", \\\"{x:968,y:697,t:1512065548863};\\\", \\\"{x:969,y:697,t:1512065548875};\\\", \\\"{x:974,y:697,t:1512065548892};\\\", \\\"{x:982,y:697,t:1512065548909};\\\", \\\"{x:990,y:697,t:1512065548925};\\\", \\\"{x:1005,y:697,t:1512065548942};\\\", \\\"{x:1037,y:697,t:1512065548958};\\\", \\\"{x:1054,y:697,t:1512065548975};\\\", \\\"{x:1067,y:697,t:1512065548992};\\\", \\\"{x:1077,y:697,t:1512065549009};\\\", \\\"{x:1085,y:697,t:1512065549025};\\\", \\\"{x:1092,y:697,t:1512065549042};\\\", \\\"{x:1101,y:697,t:1512065549059};\\\", \\\"{x:1114,y:697,t:1512065549075};\\\", \\\"{x:1129,y:697,t:1512065549092};\\\", \\\"{x:1146,y:697,t:1512065549109};\\\", \\\"{x:1161,y:697,t:1512065549127};\\\", \\\"{x:1175,y:697,t:1512065549142};\\\", \\\"{x:1189,y:697,t:1512065549157};\\\", \\\"{x:1192,y:697,t:1512065549174};\\\", \\\"{x:1194,y:696,t:1512065549262};\\\", \\\"{x:1194,y:695,t:1512065549367};\\\", \\\"{x:1192,y:695,t:1512065549375};\\\", \\\"{x:1189,y:695,t:1512065549392};\\\", \\\"{x:1185,y:696,t:1512065549409};\\\", \\\"{x:1183,y:696,t:1512065549426};\\\", \\\"{x:1181,y:696,t:1512065549446};\\\", \\\"{x:1180,y:696,t:1512065549459};\\\", \\\"{x:1175,y:698,t:1512065549476};\\\", \\\"{x:1166,y:698,t:1512065549492};\\\", \\\"{x:1151,y:700,t:1512065549509};\\\", \\\"{x:1147,y:701,t:1512065549526};\\\", \\\"{x:1144,y:701,t:1512065549542};\\\", \\\"{x:1143,y:702,t:1512065549558};\\\", \\\"{x:1142,y:702,t:1512065549583};\\\", \\\"{x:1141,y:702,t:1512065549607};\\\", \\\"{x:1140,y:702,t:1512065549615};\\\", \\\"{x:1139,y:702,t:1512065549626};\\\", \\\"{x:1140,y:702,t:1512065549767};\\\", \\\"{x:1141,y:702,t:1512065549783};\\\", \\\"{x:1142,y:702,t:1512065549799};\\\", \\\"{x:1143,y:702,t:1512065549815};\\\", \\\"{x:1144,y:702,t:1512065549826};\\\", \\\"{x:1145,y:702,t:1512065549879};\\\", \\\"{x:1145,y:701,t:1512065549893};\\\", \\\"{x:1146,y:701,t:1512065549991};\\\", \\\"{x:1148,y:700,t:1512065550007};\\\", \\\"{x:1150,y:699,t:1512065550055};\\\", \\\"{x:1152,y:698,t:1512065550087};\\\", \\\"{x:1155,y:698,t:1512065554335};\\\", \\\"{x:1161,y:696,t:1512065554345};\\\", \\\"{x:1164,y:696,t:1512065554363};\\\", \\\"{x:1172,y:700,t:1512065554379};\\\", \\\"{x:1183,y:707,t:1512065554396};\\\", \\\"{x:1194,y:712,t:1512065554413};\\\", \\\"{x:1205,y:717,t:1512065554429};\\\", \\\"{x:1218,y:724,t:1512065554446};\\\", \\\"{x:1244,y:736,t:1512065554462};\\\", \\\"{x:1261,y:742,t:1512065554479};\\\", \\\"{x:1279,y:749,t:1512065554496};\\\", \\\"{x:1288,y:752,t:1512065554513};\\\", \\\"{x:1291,y:752,t:1512065554529};\\\", \\\"{x:1292,y:752,t:1512065554550};\\\", \\\"{x:1294,y:754,t:1512065554582};\\\", \\\"{x:1297,y:755,t:1512065554596};\\\", \\\"{x:1307,y:758,t:1512065554613};\\\", \\\"{x:1318,y:761,t:1512065554629};\\\", \\\"{x:1324,y:763,t:1512065554646};\\\", \\\"{x:1325,y:763,t:1512065554662};\\\", \\\"{x:1327,y:764,t:1512065554718};\\\", \\\"{x:1328,y:764,t:1512065554734};\\\", \\\"{x:1329,y:764,t:1512065554747};\\\", \\\"{x:1331,y:765,t:1512065554763};\\\", \\\"{x:1332,y:766,t:1512065555094};\\\", \\\"{x:1332,y:767,t:1512065555158};\\\", \\\"{x:1331,y:767,t:1512065555198};\\\", \\\"{x:1328,y:768,t:1512065555230};\\\", \\\"{x:1327,y:769,t:1512065555254};\\\", \\\"{x:1325,y:769,t:1512065555294};\\\", \\\"{x:1325,y:770,t:1512065555310};\\\", \\\"{x:1323,y:771,t:1512065555326};\\\", \\\"{x:1322,y:771,t:1512065555342};\\\", \\\"{x:1321,y:771,t:1512065555407};\\\", \\\"{x:1320,y:771,t:1512065555695};\\\", \\\"{x:1320,y:770,t:1512065555751};\\\", \\\"{x:1320,y:769,t:1512065555774};\\\", \\\"{x:1320,y:768,t:1512065555782};\\\", \\\"{x:1320,y:767,t:1512065555814};\\\", \\\"{x:1320,y:766,t:1512065555870};\\\", \\\"{x:1320,y:765,t:1512065555894};\\\", \\\"{x:1320,y:764,t:1512065555982};\\\", \\\"{x:1313,y:761,t:1512065560191};\\\", \\\"{x:1289,y:756,t:1512065560200};\\\", \\\"{x:1197,y:743,t:1512065560217};\\\", \\\"{x:1136,y:733,t:1512065560233};\\\", \\\"{x:1069,y:714,t:1512065560249};\\\", \\\"{x:986,y:689,t:1512065560266};\\\", \\\"{x:901,y:658,t:1512065560283};\\\", \\\"{x:824,y:624,t:1512065560299};\\\", \\\"{x:755,y:595,t:1512065560316};\\\", \\\"{x:684,y:572,t:1512065560333};\\\", \\\"{x:659,y:565,t:1512065560349};\\\", \\\"{x:636,y:562,t:1512065560366};\\\", \\\"{x:617,y:559,t:1512065560383};\\\", \\\"{x:594,y:559,t:1512065560400};\\\", \\\"{x:567,y:559,t:1512065560416};\\\", \\\"{x:544,y:559,t:1512065560433};\\\", \\\"{x:519,y:559,t:1512065560450};\\\", \\\"{x:494,y:559,t:1512065560466};\\\", \\\"{x:455,y:564,t:1512065560484};\\\", \\\"{x:403,y:576,t:1512065560500};\\\", \\\"{x:325,y:600,t:1512065560517};\\\", \\\"{x:306,y:608,t:1512065560534};\\\", \\\"{x:295,y:613,t:1512065560551};\\\", \\\"{x:286,y:617,t:1512065560568};\\\", \\\"{x:282,y:618,t:1512065560585};\\\", \\\"{x:278,y:620,t:1512065560602};\\\", \\\"{x:276,y:620,t:1512065560618};\\\", \\\"{x:276,y:621,t:1512065560635};\\\", \\\"{x:275,y:621,t:1512065560651};\\\", \\\"{x:274,y:622,t:1512065560668};\\\", \\\"{x:273,y:623,t:1512065560685};\\\", \\\"{x:272,y:623,t:1512065560702};\\\", \\\"{x:272,y:624,t:1512065560718};\\\", \\\"{x:270,y:624,t:1512065560735};\\\", \\\"{x:270,y:623,t:1512065560855};\\\", \\\"{x:272,y:622,t:1512065560868};\\\", \\\"{x:278,y:617,t:1512065560885};\\\", \\\"{x:288,y:610,t:1512065560901};\\\", \\\"{x:298,y:603,t:1512065560918};\\\", \\\"{x:301,y:600,t:1512065560935};\\\", \\\"{x:301,y:599,t:1512065561039};\\\", \\\"{x:301,y:598,t:1512065561055};\\\", \\\"{x:301,y:597,t:1512065561103};\\\", \\\"{x:301,y:596,t:1512065561127};\\\", \\\"{x:301,y:595,t:1512065561143};\\\", \\\"{x:300,y:594,t:1512065561183};\\\", \\\"{x:300,y:593,t:1512065561215};\\\", \\\"{x:300,y:592,t:1512065561223};\\\", \\\"{x:300,y:591,t:1512065561239};\\\", \\\"{x:299,y:590,t:1512065561253};\\\", \\\"{x:299,y:589,t:1512065561278};\\\", \\\"{x:298,y:589,t:1512065561622};\\\", \\\"{x:297,y:589,t:1512065561635};\\\", \\\"{x:296,y:589,t:1512065561652};\\\", \\\"{x:295,y:589,t:1512065561678};\\\", \\\"{x:291,y:589,t:1512065561710};\\\", \\\"{x:287,y:589,t:1512065561719};\\\", \\\"{x:278,y:589,t:1512065561735};\\\", \\\"{x:269,y:589,t:1512065561752};\\\", \\\"{x:261,y:589,t:1512065561769};\\\", \\\"{x:258,y:589,t:1512065561785};\\\", \\\"{x:253,y:589,t:1512065561802};\\\", \\\"{x:244,y:589,t:1512065561819};\\\", \\\"{x:237,y:589,t:1512065561836};\\\", \\\"{x:233,y:589,t:1512065561852};\\\", \\\"{x:226,y:590,t:1512065561869};\\\", \\\"{x:221,y:592,t:1512065561886};\\\", \\\"{x:219,y:593,t:1512065561902};\\\", \\\"{x:218,y:593,t:1512065561926};\\\", \\\"{x:217,y:593,t:1512065561936};\\\", \\\"{x:216,y:593,t:1512065561952};\\\", \\\"{x:213,y:593,t:1512065561969};\\\", \\\"{x:211,y:593,t:1512065561986};\\\", \\\"{x:209,y:594,t:1512065562002};\\\", \\\"{x:207,y:595,t:1512065562019};\\\", \\\"{x:206,y:595,t:1512065562047};\\\", \\\"{x:204,y:595,t:1512065562055};\\\", \\\"{x:203,y:595,t:1512065562069};\\\", \\\"{x:199,y:595,t:1512065562086};\\\", \\\"{x:197,y:595,t:1512065562102};\\\", \\\"{x:196,y:595,t:1512065562119};\\\", \\\"{x:195,y:595,t:1512065562151};\\\", \\\"{x:195,y:594,t:1512065562319};\\\", \\\"{x:195,y:593,t:1512065562383};\\\", \\\"{x:194,y:592,t:1512065562399};\\\", \\\"{x:192,y:591,t:1512065562415};\\\", \\\"{x:191,y:590,t:1512065562431};\\\", \\\"{x:190,y:590,t:1512065562439};\\\", \\\"{x:190,y:589,t:1512065562453};\\\", \\\"{x:188,y:589,t:1512065562469};\\\", \\\"{x:185,y:587,t:1512065562486};\\\", \\\"{x:184,y:587,t:1512065562503};\\\", \\\"{x:183,y:586,t:1512065562534};\\\", \\\"{x:181,y:586,t:1512065562614};\\\", \\\"{x:183,y:587,t:1512065562846};\\\", \\\"{x:184,y:587,t:1512065562854};\\\", \\\"{x:188,y:588,t:1512065562870};\\\", \\\"{x:190,y:590,t:1512065562886};\\\", \\\"{x:193,y:590,t:1512065562903};\\\", \\\"{x:197,y:592,t:1512065562920};\\\", \\\"{x:206,y:597,t:1512065562936};\\\", \\\"{x:218,y:603,t:1512065562953};\\\", \\\"{x:229,y:607,t:1512065562970};\\\", \\\"{x:234,y:608,t:1512065562986};\\\", \\\"{x:235,y:609,t:1512065563003};\\\", \\\"{x:242,y:611,t:1512065563020};\\\", \\\"{x:251,y:616,t:1512065563037};\\\", \\\"{x:259,y:620,t:1512065563053};\\\", \\\"{x:274,y:627,t:1512065563071};\\\", \\\"{x:283,y:632,t:1512065563087};\\\", \\\"{x:288,y:634,t:1512065563104};\\\", \\\"{x:289,y:635,t:1512065563120};\\\", \\\"{x:290,y:635,t:1512065563137};\\\", \\\"{x:293,y:638,t:1512065563153};\\\", \\\"{x:303,y:645,t:1512065563170};\\\", \\\"{x:314,y:653,t:1512065563187};\\\", \\\"{x:325,y:659,t:1512065563203};\\\", \\\"{x:333,y:662,t:1512065563220};\\\", \\\"{x:336,y:664,t:1512065563237};\\\", \\\"{x:338,y:665,t:1512065563253};\\\", \\\"{x:338,y:666,t:1512065563270};\\\", \\\"{x:340,y:667,t:1512065563287};\\\", \\\"{x:343,y:670,t:1512065563303};\\\", \\\"{x:347,y:673,t:1512065563320};\\\", \\\"{x:348,y:674,t:1512065563337};\\\", \\\"{x:352,y:677,t:1512065563354};\\\", \\\"{x:354,y:678,t:1512065563370};\\\", \\\"{x:355,y:680,t:1512065563387};\\\", \\\"{x:359,y:683,t:1512065563404};\\\", \\\"{x:366,y:686,t:1512065563420};\\\", \\\"{x:370,y:688,t:1512065563437};\\\", \\\"{x:376,y:691,t:1512065563454};\\\", \\\"{x:377,y:692,t:1512065563734};\\\" ] }, { \\\"rt\\\": 61629, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 389858, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"J\\\", \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -G -G -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:382,y:692,t:1512065565398};\\\", \\\"{x:397,y:687,t:1512065565408};\\\", \\\"{x:412,y:676,t:1512065565422};\\\", \\\"{x:417,y:667,t:1512065565439};\\\", \\\"{x:424,y:653,t:1512065565456};\\\", \\\"{x:425,y:643,t:1512065565472};\\\", \\\"{x:430,y:628,t:1512065565488};\\\", \\\"{x:434,y:610,t:1512065565505};\\\", \\\"{x:434,y:592,t:1512065565522};\\\", \\\"{x:434,y:569,t:1512065565538};\\\", \\\"{x:428,y:547,t:1512065565555};\\\", \\\"{x:422,y:527,t:1512065565572};\\\", \\\"{x:417,y:516,t:1512065565588};\\\", \\\"{x:413,y:509,t:1512065565605};\\\", \\\"{x:409,y:497,t:1512065565622};\\\", \\\"{x:402,y:484,t:1512065565639};\\\", \\\"{x:394,y:466,t:1512065565656};\\\", \\\"{x:388,y:457,t:1512065565672};\\\", \\\"{x:383,y:448,t:1512065565690};\\\", \\\"{x:382,y:445,t:1512065565705};\\\", \\\"{x:379,y:441,t:1512065565722};\\\", \\\"{x:378,y:438,t:1512065565739};\\\", \\\"{x:377,y:437,t:1512065565755};\\\", \\\"{x:376,y:436,t:1512065565772};\\\", \\\"{x:373,y:436,t:1512065565790};\\\", \\\"{x:364,y:434,t:1512065565806};\\\", \\\"{x:351,y:434,t:1512065565822};\\\", \\\"{x:338,y:434,t:1512065565839};\\\", \\\"{x:321,y:434,t:1512065565855};\\\", \\\"{x:312,y:435,t:1512065565872};\\\", \\\"{x:306,y:437,t:1512065565889};\\\", \\\"{x:300,y:438,t:1512065565905};\\\", \\\"{x:290,y:439,t:1512065565922};\\\", \\\"{x:281,y:442,t:1512065565939};\\\", \\\"{x:279,y:443,t:1512065565955};\\\", \\\"{x:272,y:444,t:1512065565972};\\\", \\\"{x:260,y:449,t:1512065565990};\\\", \\\"{x:241,y:454,t:1512065566006};\\\", \\\"{x:221,y:462,t:1512065566022};\\\", \\\"{x:210,y:467,t:1512065566040};\\\", \\\"{x:200,y:471,t:1512065566056};\\\", \\\"{x:195,y:472,t:1512065566072};\\\", \\\"{x:192,y:473,t:1512065566089};\\\", \\\"{x:189,y:475,t:1512065566107};\\\", \\\"{x:187,y:476,t:1512065566122};\\\", \\\"{x:186,y:477,t:1512065566140};\\\", \\\"{x:184,y:478,t:1512065566157};\\\", \\\"{x:183,y:478,t:1512065566172};\\\", \\\"{x:183,y:479,t:1512065566190};\\\", \\\"{x:189,y:479,t:1512065567023};\\\", \\\"{x:209,y:476,t:1512065567041};\\\", \\\"{x:226,y:470,t:1512065567057};\\\", \\\"{x:242,y:465,t:1512065567073};\\\", \\\"{x:256,y:462,t:1512065567090};\\\", \\\"{x:265,y:460,t:1512065567106};\\\", \\\"{x:272,y:460,t:1512065567123};\\\", \\\"{x:276,y:459,t:1512065567140};\\\", \\\"{x:282,y:458,t:1512065567156};\\\", \\\"{x:284,y:458,t:1512065567173};\\\", \\\"{x:297,y:458,t:1512065567189};\\\", \\\"{x:312,y:458,t:1512065567206};\\\", \\\"{x:337,y:458,t:1512065567223};\\\", \\\"{x:361,y:457,t:1512065567240};\\\", \\\"{x:383,y:456,t:1512065567256};\\\", \\\"{x:401,y:452,t:1512065567273};\\\", \\\"{x:418,y:450,t:1512065567290};\\\", \\\"{x:431,y:449,t:1512065567306};\\\", \\\"{x:446,y:449,t:1512065567323};\\\", \\\"{x:465,y:447,t:1512065567340};\\\", \\\"{x:480,y:447,t:1512065567357};\\\", \\\"{x:490,y:447,t:1512065567373};\\\", \\\"{x:501,y:447,t:1512065567389};\\\", \\\"{x:509,y:447,t:1512065567406};\\\", \\\"{x:515,y:447,t:1512065567423};\\\", \\\"{x:523,y:447,t:1512065567440};\\\", \\\"{x:535,y:447,t:1512065567457};\\\", \\\"{x:549,y:447,t:1512065567473};\\\", \\\"{x:564,y:447,t:1512065567490};\\\", \\\"{x:577,y:445,t:1512065567507};\\\", \\\"{x:591,y:444,t:1512065567523};\\\", \\\"{x:613,y:441,t:1512065567540};\\\", \\\"{x:640,y:441,t:1512065567557};\\\", \\\"{x:663,y:441,t:1512065567573};\\\", \\\"{x:696,y:441,t:1512065567590};\\\", \\\"{x:717,y:443,t:1512065567607};\\\", \\\"{x:738,y:449,t:1512065567623};\\\", \\\"{x:755,y:454,t:1512065567640};\\\", \\\"{x:777,y:461,t:1512065567657};\\\", \\\"{x:802,y:470,t:1512065567674};\\\", \\\"{x:825,y:477,t:1512065567695};\\\", \\\"{x:846,y:483,t:1512065567707};\\\", \\\"{x:862,y:491,t:1512065567723};\\\", \\\"{x:873,y:496,t:1512065567740};\\\", \\\"{x:880,y:498,t:1512065567757};\\\", \\\"{x:883,y:500,t:1512065567773};\\\", \\\"{x:884,y:500,t:1512065568030};\\\", \\\"{x:885,y:501,t:1512065568759};\\\", \\\"{x:885,y:519,t:1512065568775};\\\", \\\"{x:885,y:541,t:1512065568792};\\\", \\\"{x:888,y:555,t:1512065568809};\\\", \\\"{x:888,y:564,t:1512065568825};\\\", \\\"{x:888,y:570,t:1512065568842};\\\", \\\"{x:889,y:576,t:1512065568859};\\\", \\\"{x:890,y:579,t:1512065568875};\\\", \\\"{x:891,y:581,t:1512065568891};\\\", \\\"{x:891,y:579,t:1512065569159};\\\", \\\"{x:891,y:575,t:1512065569176};\\\", \\\"{x:891,y:572,t:1512065569192};\\\", \\\"{x:891,y:571,t:1512065569209};\\\", \\\"{x:891,y:570,t:1512065569225};\\\", \\\"{x:891,y:569,t:1512065569350};\\\", \\\"{x:892,y:569,t:1512065573447};\\\", \\\"{x:913,y:573,t:1512065573462};\\\", \\\"{x:936,y:583,t:1512065573484};\\\", \\\"{x:950,y:589,t:1512065573494};\\\", \\\"{x:962,y:595,t:1512065573511};\\\", \\\"{x:992,y:609,t:1512065573528};\\\", \\\"{x:1015,y:620,t:1512065573544};\\\", \\\"{x:1026,y:625,t:1512065573561};\\\", \\\"{x:1036,y:630,t:1512065573578};\\\", \\\"{x:1043,y:633,t:1512065573595};\\\", \\\"{x:1051,y:640,t:1512065573611};\\\", \\\"{x:1054,y:641,t:1512065573628};\\\", \\\"{x:1055,y:642,t:1512065573645};\\\", \\\"{x:1056,y:646,t:1512065573661};\\\", \\\"{x:1060,y:654,t:1512065573678};\\\", \\\"{x:1061,y:661,t:1512065573695};\\\", \\\"{x:1063,y:668,t:1512065573711};\\\", \\\"{x:1069,y:681,t:1512065573728};\\\", \\\"{x:1079,y:701,t:1512065573745};\\\", \\\"{x:1088,y:713,t:1512065573761};\\\", \\\"{x:1092,y:719,t:1512065573779};\\\", \\\"{x:1094,y:721,t:1512065573796};\\\", \\\"{x:1095,y:721,t:1512065573855};\\\", \\\"{x:1096,y:721,t:1512065573862};\\\", \\\"{x:1100,y:723,t:1512065573879};\\\", \\\"{x:1104,y:724,t:1512065573896};\\\", \\\"{x:1106,y:724,t:1512065573912};\\\", \\\"{x:1107,y:724,t:1512065573929};\\\", \\\"{x:1110,y:725,t:1512065573958};\\\", \\\"{x:1116,y:729,t:1512065573966};\\\", \\\"{x:1124,y:736,t:1512065573978};\\\", \\\"{x:1157,y:759,t:1512065573997};\\\", \\\"{x:1199,y:798,t:1512065574013};\\\", \\\"{x:1232,y:826,t:1512065574028};\\\", \\\"{x:1245,y:839,t:1512065574046};\\\", \\\"{x:1246,y:840,t:1512065574062};\\\", \\\"{x:1245,y:840,t:1512065574166};\\\", \\\"{x:1243,y:840,t:1512065574178};\\\", \\\"{x:1237,y:835,t:1512065574195};\\\", \\\"{x:1229,y:830,t:1512065574212};\\\", \\\"{x:1221,y:825,t:1512065574228};\\\", \\\"{x:1207,y:815,t:1512065574245};\\\", \\\"{x:1202,y:811,t:1512065574261};\\\", \\\"{x:1197,y:808,t:1512065574278};\\\", \\\"{x:1196,y:807,t:1512065574295};\\\", \\\"{x:1193,y:804,t:1512065574312};\\\", \\\"{x:1189,y:800,t:1512065574328};\\\", \\\"{x:1187,y:797,t:1512065574345};\\\", \\\"{x:1183,y:795,t:1512065574362};\\\", \\\"{x:1179,y:793,t:1512065574378};\\\", \\\"{x:1178,y:792,t:1512065574395};\\\", \\\"{x:1176,y:789,t:1512065574412};\\\", \\\"{x:1175,y:787,t:1512065574429};\\\", \\\"{x:1173,y:785,t:1512065574446};\\\", \\\"{x:1172,y:783,t:1512065574463};\\\", \\\"{x:1171,y:783,t:1512065574480};\\\", \\\"{x:1169,y:779,t:1512065574496};\\\", \\\"{x:1167,y:778,t:1512065574513};\\\", \\\"{x:1165,y:776,t:1512065574530};\\\", \\\"{x:1165,y:775,t:1512065574546};\\\", \\\"{x:1165,y:774,t:1512065574590};\\\", \\\"{x:1164,y:772,t:1512065574598};\\\", \\\"{x:1163,y:771,t:1512065574614};\\\", \\\"{x:1162,y:770,t:1512065574630};\\\", \\\"{x:1161,y:769,t:1512065574677};\\\", \\\"{x:1160,y:768,t:1512065574693};\\\", \\\"{x:1159,y:768,t:1512065574717};\\\", \\\"{x:1159,y:767,t:1512065574729};\\\", \\\"{x:1158,y:766,t:1512065574749};\\\", \\\"{x:1158,y:765,t:1512065574762};\\\", \\\"{x:1157,y:765,t:1512065574779};\\\", \\\"{x:1156,y:764,t:1512065574805};\\\", \\\"{x:1153,y:763,t:1512065574837};\\\", \\\"{x:1153,y:762,t:1512065574861};\\\", \\\"{x:1152,y:762,t:1512065574966};\\\", \\\"{x:1147,y:765,t:1512065575431};\\\", \\\"{x:1138,y:773,t:1512065575447};\\\", \\\"{x:1135,y:778,t:1512065575464};\\\", \\\"{x:1130,y:786,t:1512065575480};\\\", \\\"{x:1125,y:796,t:1512065575497};\\\", \\\"{x:1123,y:804,t:1512065575514};\\\", \\\"{x:1120,y:813,t:1512065575530};\\\", \\\"{x:1113,y:828,t:1512065575547};\\\", \\\"{x:1105,y:846,t:1512065575564};\\\", \\\"{x:1096,y:863,t:1512065575580};\\\", \\\"{x:1089,y:876,t:1512065575597};\\\", \\\"{x:1085,y:884,t:1512065575614};\\\", \\\"{x:1083,y:887,t:1512065575630};\\\", \\\"{x:1081,y:890,t:1512065575646};\\\", \\\"{x:1079,y:896,t:1512065575664};\\\", \\\"{x:1076,y:911,t:1512065575680};\\\", \\\"{x:1069,y:924,t:1512065575697};\\\", \\\"{x:1066,y:932,t:1512065575714};\\\", \\\"{x:1062,y:941,t:1512065575730};\\\", \\\"{x:1059,y:945,t:1512065575747};\\\", \\\"{x:1059,y:947,t:1512065575764};\\\", \\\"{x:1057,y:949,t:1512065575780};\\\", \\\"{x:1056,y:950,t:1512065575798};\\\", \\\"{x:1055,y:951,t:1512065575830};\\\", \\\"{x:1054,y:953,t:1512065575847};\\\", \\\"{x:1053,y:954,t:1512065575864};\\\", \\\"{x:1053,y:955,t:1512065575881};\\\", \\\"{x:1053,y:956,t:1512065575982};\\\", \\\"{x:1052,y:957,t:1512065575997};\\\", \\\"{x:1054,y:956,t:1512065577437};\\\", \\\"{x:1054,y:951,t:1512065577447};\\\", \\\"{x:1059,y:936,t:1512065577464};\\\", \\\"{x:1063,y:914,t:1512065577481};\\\", \\\"{x:1066,y:892,t:1512065577497};\\\", \\\"{x:1071,y:875,t:1512065577514};\\\", \\\"{x:1081,y:855,t:1512065577531};\\\", \\\"{x:1092,y:836,t:1512065577548};\\\", \\\"{x:1103,y:816,t:1512065577565};\\\", \\\"{x:1121,y:785,t:1512065577582};\\\", \\\"{x:1131,y:765,t:1512065577598};\\\", \\\"{x:1141,y:748,t:1512065577615};\\\", \\\"{x:1152,y:728,t:1512065577632};\\\", \\\"{x:1161,y:714,t:1512065577649};\\\", \\\"{x:1169,y:701,t:1512065577665};\\\", \\\"{x:1176,y:691,t:1512065577682};\\\", \\\"{x:1182,y:680,t:1512065577699};\\\", \\\"{x:1191,y:665,t:1512065577715};\\\", \\\"{x:1201,y:646,t:1512065577732};\\\", \\\"{x:1210,y:628,t:1512065577749};\\\", \\\"{x:1217,y:612,t:1512065577765};\\\", \\\"{x:1222,y:600,t:1512065577782};\\\", \\\"{x:1222,y:598,t:1512065577798};\\\", \\\"{x:1223,y:597,t:1512065577815};\\\", \\\"{x:1224,y:596,t:1512065577832};\\\", \\\"{x:1224,y:595,t:1512065577849};\\\", \\\"{x:1224,y:593,t:1512065577865};\\\", \\\"{x:1225,y:591,t:1512065577882};\\\", \\\"{x:1226,y:589,t:1512065577899};\\\", \\\"{x:1226,y:586,t:1512065577915};\\\", \\\"{x:1226,y:585,t:1512065577934};\\\", \\\"{x:1226,y:583,t:1512065578039};\\\", \\\"{x:1226,y:582,t:1512065578127};\\\", \\\"{x:1226,y:581,t:1512065578151};\\\", \\\"{x:1226,y:579,t:1512065578167};\\\", \\\"{x:1226,y:576,t:1512065578183};\\\", \\\"{x:1226,y:574,t:1512065578200};\\\", \\\"{x:1226,y:573,t:1512065578223};\\\", \\\"{x:1226,y:572,t:1512065578247};\\\", \\\"{x:1226,y:571,t:1512065578271};\\\", \\\"{x:1226,y:570,t:1512065578295};\\\", \\\"{x:1226,y:568,t:1512065578319};\\\", \\\"{x:1226,y:567,t:1512065578607};\\\", \\\"{x:1225,y:567,t:1512065587327};\\\", \\\"{x:1220,y:567,t:1512065587340};\\\", \\\"{x:1208,y:571,t:1512065587357};\\\", \\\"{x:1197,y:572,t:1512065587374};\\\", \\\"{x:1187,y:573,t:1512065587390};\\\", \\\"{x:1183,y:574,t:1512065587407};\\\", \\\"{x:1182,y:574,t:1512065587424};\\\", \\\"{x:1181,y:574,t:1512065587446};\\\", \\\"{x:1180,y:574,t:1512065587519};\\\", \\\"{x:1180,y:575,t:1512065587526};\\\", \\\"{x:1182,y:575,t:1512065587703};\\\", \\\"{x:1185,y:575,t:1512065587710};\\\", \\\"{x:1190,y:573,t:1512065587724};\\\", \\\"{x:1203,y:571,t:1512065587741};\\\", \\\"{x:1219,y:569,t:1512065587757};\\\", \\\"{x:1231,y:566,t:1512065587774};\\\", \\\"{x:1237,y:565,t:1512065587790};\\\", \\\"{x:1243,y:562,t:1512065587807};\\\", \\\"{x:1247,y:561,t:1512065587824};\\\", \\\"{x:1250,y:559,t:1512065587841};\\\", \\\"{x:1253,y:558,t:1512065587857};\\\", \\\"{x:1254,y:558,t:1512065587874};\\\", \\\"{x:1255,y:558,t:1512065587891};\\\", \\\"{x:1254,y:558,t:1512065587983};\\\", \\\"{x:1253,y:558,t:1512065587991};\\\", \\\"{x:1251,y:558,t:1512065588007};\\\", \\\"{x:1246,y:559,t:1512065588024};\\\", \\\"{x:1244,y:560,t:1512065588041};\\\", \\\"{x:1242,y:560,t:1512065588057};\\\", \\\"{x:1240,y:561,t:1512065588074};\\\", \\\"{x:1239,y:562,t:1512065588091};\\\", \\\"{x:1238,y:562,t:1512065588107};\\\", \\\"{x:1237,y:562,t:1512065588126};\\\", \\\"{x:1236,y:562,t:1512065588263};\\\", \\\"{x:1235,y:562,t:1512065588286};\\\", \\\"{x:1235,y:563,t:1512065588343};\\\", \\\"{x:1234,y:563,t:1512065588382};\\\", \\\"{x:1233,y:563,t:1512065588406};\\\", \\\"{x:1231,y:563,t:1512065588487};\\\", \\\"{x:1229,y:563,t:1512065588727};\\\", \\\"{x:1229,y:564,t:1512065589255};\\\", \\\"{x:1228,y:565,t:1512065589263};\\\", \\\"{x:1224,y:566,t:1512065589275};\\\", \\\"{x:1209,y:582,t:1512065589292};\\\", \\\"{x:1201,y:588,t:1512065589308};\\\", \\\"{x:1189,y:598,t:1512065589325};\\\", \\\"{x:1179,y:607,t:1512065589342};\\\", \\\"{x:1171,y:613,t:1512065589358};\\\", \\\"{x:1161,y:619,t:1512065589375};\\\", \\\"{x:1158,y:621,t:1512065589392};\\\", \\\"{x:1156,y:624,t:1512065589408};\\\", \\\"{x:1154,y:626,t:1512065589425};\\\", \\\"{x:1153,y:627,t:1512065589442};\\\", \\\"{x:1151,y:629,t:1512065589458};\\\", \\\"{x:1150,y:630,t:1512065589475};\\\", \\\"{x:1149,y:632,t:1512065589495};\\\", \\\"{x:1148,y:632,t:1512065589518};\\\", \\\"{x:1148,y:633,t:1512065589534};\\\", \\\"{x:1148,y:635,t:1512065589542};\\\", \\\"{x:1148,y:636,t:1512065589559};\\\", \\\"{x:1147,y:639,t:1512065589575};\\\", \\\"{x:1147,y:641,t:1512065589592};\\\", \\\"{x:1147,y:648,t:1512065589609};\\\", \\\"{x:1146,y:660,t:1512065589625};\\\", \\\"{x:1144,y:671,t:1512065589641};\\\", \\\"{x:1142,y:679,t:1512065589658};\\\", \\\"{x:1142,y:685,t:1512065589674};\\\", \\\"{x:1142,y:691,t:1512065589691};\\\", \\\"{x:1142,y:696,t:1512065589708};\\\", \\\"{x:1142,y:698,t:1512065589724};\\\", \\\"{x:1142,y:700,t:1512065589741};\\\", \\\"{x:1142,y:701,t:1512065589773};\\\", \\\"{x:1142,y:702,t:1512065589927};\\\", \\\"{x:1143,y:702,t:1512065589950};\\\", \\\"{x:1144,y:701,t:1512065589966};\\\", \\\"{x:1145,y:700,t:1512065589982};\\\", \\\"{x:1146,y:700,t:1512065589998};\\\", \\\"{x:1146,y:699,t:1512065590014};\\\", \\\"{x:1147,y:698,t:1512065590038};\\\", \\\"{x:1148,y:698,t:1512065590046};\\\", \\\"{x:1149,y:697,t:1512065590059};\\\", \\\"{x:1151,y:696,t:1512065590076};\\\", \\\"{x:1152,y:696,t:1512065590091};\\\", \\\"{x:1153,y:696,t:1512065590110};\\\", \\\"{x:1154,y:696,t:1512065590126};\\\", \\\"{x:1155,y:695,t:1512065590142};\\\", \\\"{x:1157,y:694,t:1512065590190};\\\", \\\"{x:1158,y:694,t:1512065590214};\\\", \\\"{x:1158,y:692,t:1512065591206};\\\", \\\"{x:1155,y:692,t:1512065617785};\\\", \\\"{x:1154,y:692,t:1512065617800};\\\", \\\"{x:1133,y:693,t:1512065617817};\\\", \\\"{x:1102,y:698,t:1512065617834};\\\", \\\"{x:1076,y:699,t:1512065617850};\\\", \\\"{x:1053,y:700,t:1512065617867};\\\", \\\"{x:1032,y:703,t:1512065617884};\\\", \\\"{x:1010,y:708,t:1512065617901};\\\", \\\"{x:989,y:710,t:1512065617917};\\\", \\\"{x:972,y:715,t:1512065617934};\\\", \\\"{x:959,y:718,t:1512065617951};\\\", \\\"{x:945,y:721,t:1512065617967};\\\", \\\"{x:927,y:727,t:1512065617983};\\\", \\\"{x:887,y:737,t:1512065618000};\\\", \\\"{x:870,y:743,t:1512065618016};\\\", \\\"{x:851,y:752,t:1512065618033};\\\", \\\"{x:834,y:759,t:1512065618051};\\\", \\\"{x:824,y:762,t:1512065618067};\\\", \\\"{x:808,y:768,t:1512065618084};\\\", \\\"{x:790,y:770,t:1512065618101};\\\", \\\"{x:777,y:772,t:1512065618117};\\\", \\\"{x:771,y:772,t:1512065618133};\\\", \\\"{x:762,y:772,t:1512065618150};\\\", \\\"{x:749,y:772,t:1512065618166};\\\", \\\"{x:728,y:772,t:1512065618184};\\\", \\\"{x:705,y:771,t:1512065618200};\\\", \\\"{x:693,y:767,t:1512065618217};\\\", \\\"{x:686,y:765,t:1512065618233};\\\", \\\"{x:681,y:764,t:1512065618251};\\\", \\\"{x:676,y:762,t:1512065618266};\\\", \\\"{x:667,y:758,t:1512065618283};\\\", \\\"{x:651,y:752,t:1512065618300};\\\", \\\"{x:631,y:743,t:1512065618318};\\\", \\\"{x:610,y:733,t:1512065618333};\\\", \\\"{x:590,y:724,t:1512065618350};\\\", \\\"{x:570,y:715,t:1512065618368};\\\", \\\"{x:555,y:707,t:1512065618384};\\\", \\\"{x:536,y:696,t:1512065618400};\\\", \\\"{x:523,y:687,t:1512065618417};\\\", \\\"{x:509,y:675,t:1512065618434};\\\", \\\"{x:499,y:664,t:1512065618451};\\\", \\\"{x:495,y:659,t:1512065618467};\\\", \\\"{x:492,y:653,t:1512065618483};\\\", \\\"{x:488,y:645,t:1512065618500};\\\", \\\"{x:483,y:635,t:1512065618518};\\\", \\\"{x:479,y:625,t:1512065618534};\\\", \\\"{x:474,y:616,t:1512065618551};\\\", \\\"{x:468,y:606,t:1512065618568};\\\", \\\"{x:460,y:596,t:1512065618584};\\\", \\\"{x:451,y:583,t:1512065618600};\\\", \\\"{x:449,y:580,t:1512065618617};\\\", \\\"{x:447,y:577,t:1512065618634};\\\", \\\"{x:447,y:576,t:1512065618650};\\\", \\\"{x:447,y:575,t:1512065618668};\\\", \\\"{x:447,y:574,t:1512065618688};\\\", \\\"{x:447,y:573,t:1512065618700};\\\", \\\"{x:447,y:572,t:1512065618720};\\\", \\\"{x:447,y:568,t:1512065618734};\\\", \\\"{x:449,y:560,t:1512065618751};\\\", \\\"{x:454,y:552,t:1512065618768};\\\", \\\"{x:457,y:543,t:1512065618785};\\\", \\\"{x:457,y:542,t:1512065618800};\\\", \\\"{x:457,y:540,t:1512065618818};\\\", \\\"{x:457,y:538,t:1512065618834};\\\", \\\"{x:452,y:534,t:1512065618851};\\\", \\\"{x:436,y:528,t:1512065618868};\\\", \\\"{x:414,y:524,t:1512065618885};\\\", \\\"{x:386,y:519,t:1512065618901};\\\", \\\"{x:363,y:518,t:1512065618918};\\\", \\\"{x:330,y:518,t:1512065618935};\\\", \\\"{x:279,y:518,t:1512065618950};\\\", \\\"{x:226,y:518,t:1512065618968};\\\", \\\"{x:200,y:518,t:1512065618984};\\\", \\\"{x:194,y:518,t:1512065619000};\\\", \\\"{x:191,y:518,t:1512065619018};\\\", \\\"{x:190,y:518,t:1512065619056};\\\", \\\"{x:189,y:518,t:1512065619068};\\\", \\\"{x:188,y:520,t:1512065619085};\\\", \\\"{x:188,y:521,t:1512065619101};\\\", \\\"{x:186,y:522,t:1512065619118};\\\", \\\"{x:184,y:523,t:1512065619135};\\\", \\\"{x:182,y:523,t:1512065619150};\\\", \\\"{x:179,y:524,t:1512065619168};\\\", \\\"{x:177,y:526,t:1512065619185};\\\", \\\"{x:176,y:526,t:1512065619232};\\\", \\\"{x:176,y:528,t:1512065619353};\\\", \\\"{x:177,y:529,t:1512065619384};\\\", \\\"{x:178,y:529,t:1512065619401};\\\", \\\"{x:179,y:529,t:1512065619417};\\\", \\\"{x:180,y:529,t:1512065619435};\\\", \\\"{x:182,y:529,t:1512065619451};\\\", \\\"{x:183,y:529,t:1512065619467};\\\", \\\"{x:185,y:530,t:1512065619485};\\\", \\\"{x:186,y:530,t:1512065619502};\\\", \\\"{x:189,y:530,t:1512065619519};\\\", \\\"{x:190,y:532,t:1512065619535};\\\", \\\"{x:192,y:532,t:1512065619552};\\\", \\\"{x:193,y:532,t:1512065619960};\\\", \\\"{x:195,y:532,t:1512065619969};\\\", \\\"{x:204,y:532,t:1512065619986};\\\", \\\"{x:208,y:532,t:1512065620003};\\\", \\\"{x:212,y:532,t:1512065620019};\\\", \\\"{x:215,y:532,t:1512065620036};\\\", \\\"{x:218,y:532,t:1512065620053};\\\", \\\"{x:220,y:532,t:1512065620069};\\\", \\\"{x:223,y:532,t:1512065620086};\\\", \\\"{x:229,y:532,t:1512065620103};\\\", \\\"{x:235,y:532,t:1512065620119};\\\", \\\"{x:250,y:532,t:1512065620136};\\\", \\\"{x:259,y:534,t:1512065620153};\\\", \\\"{x:264,y:534,t:1512065620169};\\\", \\\"{x:266,y:534,t:1512065620186};\\\", \\\"{x:269,y:534,t:1512065620203};\\\", \\\"{x:270,y:534,t:1512065620219};\\\", \\\"{x:272,y:534,t:1512065620236};\\\", \\\"{x:275,y:534,t:1512065620253};\\\", \\\"{x:279,y:534,t:1512065620269};\\\", \\\"{x:282,y:534,t:1512065620286};\\\", \\\"{x:287,y:534,t:1512065620303};\\\", \\\"{x:291,y:534,t:1512065620320};\\\", \\\"{x:294,y:534,t:1512065620336};\\\", \\\"{x:297,y:534,t:1512065620353};\\\", \\\"{x:300,y:534,t:1512065620370};\\\", \\\"{x:301,y:534,t:1512065620386};\\\", \\\"{x:303,y:534,t:1512065620403};\\\", \\\"{x:302,y:535,t:1512065620833};\\\", \\\"{x:301,y:535,t:1512065621377};\\\", \\\"{x:300,y:535,t:1512065621387};\\\", \\\"{x:299,y:532,t:1512065621404};\\\", \\\"{x:296,y:530,t:1512065621420};\\\", \\\"{x:296,y:529,t:1512065621440};\\\", \\\"{x:295,y:528,t:1512065621464};\\\", \\\"{x:294,y:528,t:1512065621609};\\\", \\\"{x:293,y:528,t:1512065621657};\\\", \\\"{x:292,y:528,t:1512065621680};\\\", \\\"{x:291,y:528,t:1512065621696};\\\", \\\"{x:290,y:528,t:1512065621761};\\\", \\\"{x:291,y:528,t:1512065622057};\\\", \\\"{x:295,y:528,t:1512065622072};\\\", \\\"{x:306,y:528,t:1512065622088};\\\", \\\"{x:319,y:531,t:1512065622104};\\\", \\\"{x:328,y:534,t:1512065622121};\\\", \\\"{x:335,y:535,t:1512065622139};\\\", \\\"{x:337,y:536,t:1512065622154};\\\", \\\"{x:338,y:536,t:1512065622171};\\\", \\\"{x:339,y:536,t:1512065622188};\\\", \\\"{x:341,y:536,t:1512065622204};\\\", \\\"{x:346,y:536,t:1512065622221};\\\", \\\"{x:353,y:536,t:1512065622239};\\\", \\\"{x:360,y:536,t:1512065622254};\\\", \\\"{x:363,y:536,t:1512065622271};\\\", \\\"{x:365,y:536,t:1512065622288};\\\", \\\"{x:366,y:536,t:1512065622345};\\\", \\\"{x:367,y:536,t:1512065622354};\\\", \\\"{x:370,y:536,t:1512065622371};\\\", \\\"{x:373,y:536,t:1512065622388};\\\", \\\"{x:374,y:536,t:1512065622405};\\\", \\\"{x:375,y:536,t:1512065622421};\\\", \\\"{x:376,y:535,t:1512065622439};\\\", \\\"{x:378,y:535,t:1512065622455};\\\", \\\"{x:380,y:534,t:1512065622471};\\\", \\\"{x:392,y:530,t:1512065622488};\\\", \\\"{x:396,y:530,t:1512065622505};\\\", \\\"{x:398,y:529,t:1512065622522};\\\", \\\"{x:399,y:529,t:1512065622538};\\\", \\\"{x:401,y:528,t:1512065622555};\\\", \\\"{x:403,y:527,t:1512065622583};\\\", \\\"{x:404,y:526,t:1512065622599};\\\", \\\"{x:405,y:526,t:1512065622881};\\\", \\\"{x:405,y:527,t:1512065622945};\\\", \\\"{x:405,y:528,t:1512065623080};\\\", \\\"{x:405,y:528,t:1512065623096};\\\", \\\"{x:405,y:529,t:1512065623801};\\\", \\\"{x:410,y:531,t:1512065623808};\\\", \\\"{x:414,y:531,t:1512065623823};\\\", \\\"{x:418,y:532,t:1512065623839};\\\", \\\"{x:429,y:534,t:1512065623856};\\\", \\\"{x:435,y:534,t:1512065623872};\\\", \\\"{x:436,y:534,t:1512065623889};\\\", \\\"{x:437,y:534,t:1512065623906};\\\", \\\"{x:438,y:534,t:1512065623922};\\\", \\\"{x:442,y:534,t:1512065623939};\\\", \\\"{x:444,y:534,t:1512065623957};\\\", \\\"{x:448,y:534,t:1512065623973};\\\", \\\"{x:450,y:534,t:1512065623989};\\\", \\\"{x:455,y:534,t:1512065624007};\\\", \\\"{x:460,y:533,t:1512065624023};\\\", \\\"{x:465,y:533,t:1512065624040};\\\", \\\"{x:473,y:531,t:1512065624056};\\\", \\\"{x:480,y:530,t:1512065624073};\\\", \\\"{x:487,y:529,t:1512065624089};\\\", \\\"{x:492,y:528,t:1512065624106};\\\", \\\"{x:495,y:527,t:1512065624123};\\\", \\\"{x:496,y:527,t:1512065624139};\\\", \\\"{x:498,y:527,t:1512065624156};\\\", \\\"{x:500,y:527,t:1512065624192};\\\", \\\"{x:501,y:527,t:1512065624206};\\\", \\\"{x:504,y:527,t:1512065624223};\\\", \\\"{x:507,y:527,t:1512065624240};\\\", \\\"{x:510,y:527,t:1512065624256};\\\", \\\"{x:513,y:527,t:1512065624273};\\\", \\\"{x:514,y:527,t:1512065624289};\\\", \\\"{x:516,y:527,t:1512065624306};\\\", \\\"{x:517,y:527,t:1512065624335};\\\", \\\"{x:519,y:527,t:1512065624343};\\\", \\\"{x:520,y:527,t:1512065624356};\\\", \\\"{x:525,y:527,t:1512065624373};\\\", \\\"{x:527,y:527,t:1512065624389};\\\", \\\"{x:528,y:527,t:1512065624406};\\\", \\\"{x:528,y:528,t:1512065624576};\\\", \\\"{x:527,y:529,t:1512065624590};\\\", \\\"{x:524,y:530,t:1512065624606};\\\", \\\"{x:523,y:531,t:1512065624623};\\\", \\\"{x:521,y:531,t:1512065624640};\\\", \\\"{x:520,y:532,t:1512065624656};\\\", \\\"{x:519,y:532,t:1512065624673};\\\", \\\"{x:518,y:532,t:1512065624696};\\\", \\\"{x:517,y:533,t:1512065624727};\\\", \\\"{x:516,y:533,t:1512065624744};\\\", \\\"{x:515,y:533,t:1512065624760};\\\", \\\"{x:515,y:534,t:1512065624800};\\\", \\\"{x:514,y:534,t:1512065624911};\\\", \\\"{x:513,y:535,t:1512065624923};\\\", \\\"{x:513,y:535,t:1512065625001};\\\", \\\"{x:512,y:535,t:1512065625319};\\\", \\\"{x:506,y:538,t:1512065625327};\\\", \\\"{x:503,y:540,t:1512065625340};\\\", \\\"{x:499,y:541,t:1512065625357};\\\", \\\"{x:495,y:544,t:1512065625373};\\\", \\\"{x:491,y:547,t:1512065625390};\\\", \\\"{x:491,y:548,t:1512065625407};\\\", \\\"{x:490,y:548,t:1512065625423};\\\", \\\"{x:488,y:550,t:1512065625440};\\\", \\\"{x:488,y:551,t:1512065625457};\\\", \\\"{x:486,y:553,t:1512065625474};\\\", \\\"{x:484,y:555,t:1512065625490};\\\", \\\"{x:482,y:558,t:1512065625507};\\\", \\\"{x:481,y:559,t:1512065625524};\\\", \\\"{x:480,y:561,t:1512065625540};\\\", \\\"{x:477,y:566,t:1512065625557};\\\", \\\"{x:473,y:573,t:1512065625574};\\\", \\\"{x:467,y:582,t:1512065625590};\\\", \\\"{x:462,y:595,t:1512065625607};\\\", \\\"{x:454,y:613,t:1512065625624};\\\", \\\"{x:450,y:622,t:1512065625640};\\\", \\\"{x:447,y:635,t:1512065625658};\\\", \\\"{x:444,y:644,t:1512065625675};\\\", \\\"{x:443,y:649,t:1512065625690};\\\", \\\"{x:443,y:652,t:1512065625707};\\\", \\\"{x:442,y:654,t:1512065625724};\\\", \\\"{x:442,y:655,t:1512065625740};\\\", \\\"{x:442,y:656,t:1512065625757};\\\", \\\"{x:442,y:658,t:1512065625774};\\\", \\\"{x:441,y:659,t:1512065625790};\\\", \\\"{x:441,y:661,t:1512065625807};\\\", \\\"{x:440,y:665,t:1512065625824};\\\", \\\"{x:440,y:669,t:1512065625840};\\\", \\\"{x:440,y:672,t:1512065625857};\\\", \\\"{x:440,y:675,t:1512065625875};\\\", \\\"{x:440,y:677,t:1512065625891};\\\", \\\"{x:438,y:680,t:1512065625907};\\\", \\\"{x:438,y:681,t:1512065625924};\\\", \\\"{x:438,y:683,t:1512065625941};\\\", \\\"{x:438,y:684,t:1512065625959};\\\", \\\"{x:438,y:685,t:1512065625975};\\\", \\\"{x:438,y:687,t:1512065625991};\\\", \\\"{x:438,y:688,t:1512065626007};\\\", \\\"{x:438,y:694,t:1512065626024};\\\", \\\"{x:438,y:701,t:1512065626041};\\\", \\\"{x:437,y:704,t:1512065626057};\\\", \\\"{x:436,y:706,t:1512065626074};\\\", \\\"{x:436,y:710,t:1512065626092};\\\", \\\"{x:435,y:712,t:1512065626107};\\\", \\\"{x:434,y:713,t:1512065626124};\\\", \\\"{x:434,y:714,t:1512065626144};\\\", \\\"{x:434,y:715,t:1512065626158};\\\", \\\"{x:433,y:715,t:1512065626224};\\\", \\\"{x:433,y:714,t:1512065626288};\\\", \\\"{x:433,y:712,t:1512065626296};\\\", \\\"{x:433,y:711,t:1512065626308};\\\", \\\"{x:433,y:708,t:1512065626325};\\\", \\\"{x:433,y:702,t:1512065626341};\\\", \\\"{x:433,y:698,t:1512065626358};\\\", \\\"{x:433,y:694,t:1512065626374};\\\", \\\"{x:433,y:693,t:1512065626399};\\\", \\\"{x:433,y:692,t:1512065626456};\\\", \\\"{x:433,y:700,t:1512065626872};\\\", \\\"{x:435,y:703,t:1512065626880};\\\", \\\"{x:435,y:705,t:1512065626891};\\\", \\\"{x:440,y:716,t:1512065626908};\\\", \\\"{x:447,y:729,t:1512065626925};\\\", \\\"{x:456,y:745,t:1512065626942};\\\", \\\"{x:462,y:756,t:1512065626958};\\\", \\\"{x:477,y:784,t:1512065626976};\\\", \\\"{x:491,y:804,t:1512065626992};\\\", \\\"{x:504,y:826,t:1512065627008};\\\", \\\"{x:518,y:843,t:1512065627025};\\\", \\\"{x:528,y:857,t:1512065627042};\\\", \\\"{x:538,y:868,t:1512065627058};\\\", \\\"{x:547,y:875,t:1512065627075};\\\", \\\"{x:558,y:883,t:1512065627092};\\\", \\\"{x:571,y:892,t:1512065627108};\\\", \\\"{x:583,y:900,t:1512065627125};\\\", \\\"{x:593,y:905,t:1512065627142};\\\", \\\"{x:596,y:908,t:1512065627158};\\\", \\\"{x:597,y:908,t:1512065627175};\\\", \\\"{x:598,y:908,t:1512065627192};\\\" ] }, { \\\"rt\\\": 52622, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 444060, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -I -J -E -E -E -F -02 PM-02 PM-B -B -B -J -J -09 AM-09 AM-E -I -J -B -B -F -B -B -B -B -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:599,y:908,t:1512065630906};\\\", \\\"{x:586,y:889,t:1512065630912};\\\", \\\"{x:536,y:817,t:1512065630929};\\\", \\\"{x:485,y:747,t:1512065630945};\\\", \\\"{x:458,y:701,t:1512065630963};\\\", \\\"{x:429,y:654,t:1512065630979};\\\", \\\"{x:401,y:612,t:1512065630995};\\\", \\\"{x:359,y:555,t:1512065631012};\\\", \\\"{x:332,y:516,t:1512065631029};\\\", \\\"{x:320,y:498,t:1512065631046};\\\", \\\"{x:302,y:474,t:1512065631062};\\\", \\\"{x:282,y:446,t:1512065631079};\\\", \\\"{x:266,y:424,t:1512065631096};\\\", \\\"{x:261,y:416,t:1512065631112};\\\", \\\"{x:253,y:405,t:1512065631129};\\\", \\\"{x:247,y:396,t:1512065631146};\\\", \\\"{x:246,y:396,t:1512065631162};\\\", \\\"{x:247,y:396,t:1512065631329};\\\", \\\"{x:264,y:409,t:1512065631346};\\\", \\\"{x:286,y:420,t:1512065631362};\\\", \\\"{x:306,y:430,t:1512065631379};\\\", \\\"{x:325,y:441,t:1512065631396};\\\", \\\"{x:344,y:452,t:1512065631413};\\\", \\\"{x:354,y:458,t:1512065631430};\\\", \\\"{x:368,y:465,t:1512065631447};\\\", \\\"{x:380,y:469,t:1512065631463};\\\", \\\"{x:385,y:470,t:1512065631479};\\\", \\\"{x:393,y:471,t:1512065631497};\\\", \\\"{x:401,y:471,t:1512065631513};\\\", \\\"{x:410,y:471,t:1512065631529};\\\", \\\"{x:419,y:471,t:1512065631546};\\\", \\\"{x:425,y:471,t:1512065631563};\\\", \\\"{x:430,y:471,t:1512065631580};\\\", \\\"{x:436,y:470,t:1512065631596};\\\", \\\"{x:443,y:467,t:1512065631614};\\\", \\\"{x:451,y:467,t:1512065631629};\\\", \\\"{x:464,y:467,t:1512065631646};\\\", \\\"{x:477,y:467,t:1512065631664};\\\", \\\"{x:495,y:467,t:1512065631679};\\\", \\\"{x:509,y:467,t:1512065631697};\\\", \\\"{x:515,y:467,t:1512065631713};\\\", \\\"{x:520,y:467,t:1512065631729};\\\", \\\"{x:527,y:467,t:1512065631746};\\\", \\\"{x:531,y:467,t:1512065631763};\\\", \\\"{x:536,y:466,t:1512065631780};\\\", \\\"{x:539,y:466,t:1512065631796};\\\", \\\"{x:544,y:464,t:1512065631814};\\\", \\\"{x:547,y:463,t:1512065631830};\\\", \\\"{x:552,y:463,t:1512065631846};\\\", \\\"{x:557,y:462,t:1512065631864};\\\", \\\"{x:568,y:460,t:1512065631881};\\\", \\\"{x:573,y:460,t:1512065631897};\\\", \\\"{x:580,y:459,t:1512065631913};\\\", \\\"{x:589,y:459,t:1512065631931};\\\", \\\"{x:593,y:459,t:1512065631946};\\\", \\\"{x:597,y:459,t:1512065631964};\\\", \\\"{x:603,y:459,t:1512065631980};\\\", \\\"{x:604,y:459,t:1512065631996};\\\", \\\"{x:606,y:459,t:1512065632014};\\\", \\\"{x:607,y:458,t:1512065632121};\\\", \\\"{x:611,y:458,t:1512065633929};\\\", \\\"{x:625,y:456,t:1512065633937};\\\", \\\"{x:650,y:453,t:1512065633949};\\\", \\\"{x:745,y:442,t:1512065633965};\\\", \\\"{x:853,y:426,t:1512065633982};\\\", \\\"{x:913,y:429,t:1512065633999};\\\", \\\"{x:939,y:447,t:1512065634016};\\\", \\\"{x:955,y:454,t:1512065634032};\\\", \\\"{x:974,y:459,t:1512065634049};\\\", \\\"{x:988,y:463,t:1512065634065};\\\", \\\"{x:1014,y:474,t:1512065634082};\\\", \\\"{x:1074,y:498,t:1512065634099};\\\", \\\"{x:1148,y:530,t:1512065634116};\\\", \\\"{x:1215,y:562,t:1512065634132};\\\", \\\"{x:1258,y:584,t:1512065634149};\\\", \\\"{x:1281,y:597,t:1512065634166};\\\", \\\"{x:1306,y:614,t:1512065634182};\\\", \\\"{x:1323,y:628,t:1512065634199};\\\", \\\"{x:1333,y:637,t:1512065634216};\\\", \\\"{x:1340,y:653,t:1512065634232};\\\", \\\"{x:1351,y:719,t:1512065634249};\\\", \\\"{x:1356,y:765,t:1512065634265};\\\", \\\"{x:1356,y:805,t:1512065634282};\\\", \\\"{x:1357,y:828,t:1512065634299};\\\", \\\"{x:1357,y:838,t:1512065634316};\\\", \\\"{x:1357,y:843,t:1512065634332};\\\", \\\"{x:1357,y:845,t:1512065634349};\\\", \\\"{x:1357,y:846,t:1512065634366};\\\", \\\"{x:1357,y:847,t:1512065634473};\\\", \\\"{x:1356,y:847,t:1512065634489};\\\", \\\"{x:1352,y:847,t:1512065634499};\\\", \\\"{x:1330,y:847,t:1512065634516};\\\", \\\"{x:1311,y:847,t:1512065634533};\\\", \\\"{x:1288,y:847,t:1512065634549};\\\", \\\"{x:1251,y:843,t:1512065634566};\\\", \\\"{x:1218,y:843,t:1512065634583};\\\", \\\"{x:1191,y:843,t:1512065634599};\\\", \\\"{x:1163,y:840,t:1512065634616};\\\", \\\"{x:1125,y:828,t:1512065634633};\\\", \\\"{x:1109,y:824,t:1512065634649};\\\", \\\"{x:1100,y:822,t:1512065634666};\\\", \\\"{x:1094,y:821,t:1512065634683};\\\", \\\"{x:1090,y:817,t:1512065634699};\\\", \\\"{x:1083,y:813,t:1512065634716};\\\", \\\"{x:1079,y:811,t:1512065634733};\\\", \\\"{x:1075,y:810,t:1512065634749};\\\", \\\"{x:1070,y:809,t:1512065634766};\\\", \\\"{x:1067,y:809,t:1512065634783};\\\", \\\"{x:1066,y:809,t:1512065634799};\\\", \\\"{x:1064,y:809,t:1512065634816};\\\", \\\"{x:1062,y:810,t:1512065634833};\\\", \\\"{x:1055,y:814,t:1512065634848};\\\", \\\"{x:1043,y:821,t:1512065634865};\\\", \\\"{x:1029,y:827,t:1512065634882};\\\", \\\"{x:1022,y:831,t:1512065634899};\\\", \\\"{x:1019,y:832,t:1512065634915};\\\", \\\"{x:1017,y:833,t:1512065634933};\\\", \\\"{x:1016,y:834,t:1512065634949};\\\", \\\"{x:1015,y:834,t:1512065634992};\\\", \\\"{x:1013,y:834,t:1512065635008};\\\", \\\"{x:1012,y:836,t:1512065635024};\\\", \\\"{x:1011,y:837,t:1512065635040};\\\", \\\"{x:1012,y:836,t:1512065635265};\\\", \\\"{x:1013,y:836,t:1512065635505};\\\", \\\"{x:1013,y:835,t:1512065635517};\\\", \\\"{x:1013,y:834,t:1512065635561};\\\", \\\"{x:1013,y:833,t:1512065635593};\\\", \\\"{x:1014,y:833,t:1512065635601};\\\", \\\"{x:1014,y:832,t:1512065635625};\\\", \\\"{x:1015,y:831,t:1512065635665};\\\", \\\"{x:1016,y:830,t:1512065635745};\\\", \\\"{x:1017,y:830,t:1512065635753};\\\", \\\"{x:1018,y:829,t:1512065635783};\\\", \\\"{x:1019,y:828,t:1512065635799};\\\", \\\"{x:1020,y:828,t:1512065635816};\\\", \\\"{x:1021,y:828,t:1512065635857};\\\", \\\"{x:1022,y:827,t:1512065635872};\\\", \\\"{x:1023,y:827,t:1512065635884};\\\", \\\"{x:1025,y:827,t:1512065635899};\\\", \\\"{x:1027,y:827,t:1512065635916};\\\", \\\"{x:1028,y:826,t:1512065635935};\\\", \\\"{x:1028,y:820,t:1512065636904};\\\", \\\"{x:1035,y:804,t:1512065636917};\\\", \\\"{x:1050,y:758,t:1512065636933};\\\", \\\"{x:1057,y:734,t:1512065636950};\\\", \\\"{x:1061,y:717,t:1512065636967};\\\", \\\"{x:1065,y:694,t:1512065636983};\\\", \\\"{x:1068,y:669,t:1512065637000};\\\", \\\"{x:1072,y:655,t:1512065637017};\\\", \\\"{x:1076,y:644,t:1512065637033};\\\", \\\"{x:1081,y:625,t:1512065637050};\\\", \\\"{x:1087,y:612,t:1512065637067};\\\", \\\"{x:1091,y:600,t:1512065637083};\\\", \\\"{x:1095,y:593,t:1512065637100};\\\", \\\"{x:1095,y:590,t:1512065637117};\\\", \\\"{x:1096,y:589,t:1512065637134};\\\", \\\"{x:1096,y:588,t:1512065637209};\\\", \\\"{x:1096,y:587,t:1512065637224};\\\", \\\"{x:1096,y:586,t:1512065637296};\\\", \\\"{x:1096,y:585,t:1512065637304};\\\", \\\"{x:1096,y:584,t:1512065637320};\\\", \\\"{x:1096,y:582,t:1512065637334};\\\", \\\"{x:1096,y:581,t:1512065637350};\\\", \\\"{x:1095,y:579,t:1512065637367};\\\", \\\"{x:1094,y:575,t:1512065637384};\\\", \\\"{x:1093,y:574,t:1512065637424};\\\", \\\"{x:1093,y:573,t:1512065637481};\\\", \\\"{x:1093,y:572,t:1512065637545};\\\", \\\"{x:1092,y:572,t:1512065637577};\\\", \\\"{x:1091,y:571,t:1512065644281};\\\", \\\"{x:1089,y:572,t:1512065644290};\\\", \\\"{x:1081,y:574,t:1512065644308};\\\", \\\"{x:1070,y:583,t:1512065644323};\\\", \\\"{x:1057,y:592,t:1512065644340};\\\", \\\"{x:1052,y:596,t:1512065644357};\\\", \\\"{x:1045,y:603,t:1512065644373};\\\", \\\"{x:1034,y:617,t:1512065644390};\\\", \\\"{x:1027,y:636,t:1512065644407};\\\", \\\"{x:1019,y:653,t:1512065644423};\\\", \\\"{x:1014,y:666,t:1512065644440};\\\", \\\"{x:1010,y:685,t:1512065644456};\\\", \\\"{x:1007,y:699,t:1512065644473};\\\", \\\"{x:1005,y:710,t:1512065644490};\\\", \\\"{x:1004,y:723,t:1512065644508};\\\", \\\"{x:1004,y:741,t:1512065644523};\\\", \\\"{x:1004,y:757,t:1512065644540};\\\", \\\"{x:1002,y:771,t:1512065644557};\\\", \\\"{x:1000,y:779,t:1512065644573};\\\", \\\"{x:1000,y:782,t:1512065644590};\\\", \\\"{x:999,y:784,t:1512065644607};\\\", \\\"{x:999,y:785,t:1512065644623};\\\", \\\"{x:999,y:786,t:1512065644640};\\\", \\\"{x:998,y:786,t:1512065644880};\\\", \\\"{x:996,y:786,t:1512065644896};\\\", \\\"{x:995,y:786,t:1512065644908};\\\", \\\"{x:994,y:785,t:1512065644924};\\\", \\\"{x:993,y:784,t:1512065644944};\\\", \\\"{x:993,y:783,t:1512065644957};\\\", \\\"{x:993,y:782,t:1512065644974};\\\", \\\"{x:993,y:780,t:1512065644992};\\\", \\\"{x:992,y:779,t:1512065645007};\\\", \\\"{x:991,y:778,t:1512065645024};\\\", \\\"{x:990,y:775,t:1512065645040};\\\", \\\"{x:990,y:774,t:1512065645057};\\\", \\\"{x:989,y:772,t:1512065645088};\\\", \\\"{x:989,y:771,t:1512065645296};\\\", \\\"{x:989,y:770,t:1512065645336};\\\", \\\"{x:989,y:769,t:1512065645344};\\\", \\\"{x:989,y:768,t:1512065645368};\\\", \\\"{x:990,y:767,t:1512065645390};\\\", \\\"{x:990,y:766,t:1512065645407};\\\", \\\"{x:990,y:764,t:1512065645424};\\\", \\\"{x:991,y:761,t:1512065645440};\\\", \\\"{x:991,y:760,t:1512065645480};\\\", \\\"{x:994,y:762,t:1512065645936};\\\", \\\"{x:996,y:768,t:1512065645945};\\\", \\\"{x:999,y:774,t:1512065645958};\\\", \\\"{x:1004,y:786,t:1512065645974};\\\", \\\"{x:1010,y:802,t:1512065645991};\\\", \\\"{x:1027,y:832,t:1512065646008};\\\", \\\"{x:1037,y:851,t:1512065646025};\\\", \\\"{x:1048,y:868,t:1512065646041};\\\", \\\"{x:1060,y:896,t:1512065646058};\\\", \\\"{x:1073,y:920,t:1512065646075};\\\", \\\"{x:1084,y:939,t:1512065646091};\\\", \\\"{x:1090,y:952,t:1512065646109};\\\", \\\"{x:1094,y:961,t:1512065646125};\\\", \\\"{x:1097,y:966,t:1512065646141};\\\", \\\"{x:1097,y:968,t:1512065646160};\\\", \\\"{x:1097,y:969,t:1512065646175};\\\", \\\"{x:1097,y:971,t:1512065646191};\\\", \\\"{x:1098,y:973,t:1512065646208};\\\", \\\"{x:1098,y:974,t:1512065646224};\\\", \\\"{x:1098,y:975,t:1512065646241};\\\", \\\"{x:1097,y:972,t:1512065646368};\\\", \\\"{x:1097,y:955,t:1512065646376};\\\", \\\"{x:1097,y:930,t:1512065646391};\\\", \\\"{x:1097,y:881,t:1512065646408};\\\", \\\"{x:1097,y:844,t:1512065646425};\\\", \\\"{x:1104,y:812,t:1512065646442};\\\", \\\"{x:1110,y:780,t:1512065646458};\\\", \\\"{x:1114,y:759,t:1512065646475};\\\", \\\"{x:1120,y:739,t:1512065646492};\\\", \\\"{x:1126,y:720,t:1512065646508};\\\", \\\"{x:1130,y:705,t:1512065646525};\\\", \\\"{x:1133,y:695,t:1512065646542};\\\", \\\"{x:1135,y:687,t:1512065646558};\\\", \\\"{x:1136,y:683,t:1512065646575};\\\", \\\"{x:1137,y:678,t:1512065646592};\\\", \\\"{x:1139,y:673,t:1512065646608};\\\", \\\"{x:1140,y:660,t:1512065646625};\\\", \\\"{x:1140,y:644,t:1512065646642};\\\", \\\"{x:1141,y:632,t:1512065646658};\\\", \\\"{x:1141,y:624,t:1512065646675};\\\", \\\"{x:1141,y:617,t:1512065646692};\\\", \\\"{x:1141,y:613,t:1512065646707};\\\", \\\"{x:1140,y:610,t:1512065646724};\\\", \\\"{x:1139,y:609,t:1512065646741};\\\", \\\"{x:1136,y:605,t:1512065646757};\\\", \\\"{x:1134,y:603,t:1512065646774};\\\", \\\"{x:1133,y:602,t:1512065646791};\\\", \\\"{x:1131,y:602,t:1512065646807};\\\", \\\"{x:1124,y:600,t:1512065646824};\\\", \\\"{x:1119,y:599,t:1512065646841};\\\", \\\"{x:1117,y:598,t:1512065646857};\\\", \\\"{x:1114,y:598,t:1512065646874};\\\", \\\"{x:1111,y:596,t:1512065646891};\\\", \\\"{x:1108,y:594,t:1512065646908};\\\", \\\"{x:1105,y:592,t:1512065646924};\\\", \\\"{x:1103,y:591,t:1512065646941};\\\", \\\"{x:1102,y:591,t:1512065646959};\\\", \\\"{x:1101,y:589,t:1512065646974};\\\", \\\"{x:1099,y:588,t:1512065646991};\\\", \\\"{x:1098,y:586,t:1512065647009};\\\", \\\"{x:1097,y:583,t:1512065647025};\\\", \\\"{x:1094,y:581,t:1512065647042};\\\", \\\"{x:1093,y:578,t:1512065647059};\\\", \\\"{x:1092,y:576,t:1512065647075};\\\", \\\"{x:1091,y:575,t:1512065647092};\\\", \\\"{x:1090,y:574,t:1512065647109};\\\", \\\"{x:1088,y:572,t:1512065647125};\\\", \\\"{x:1088,y:570,t:1512065647280};\\\", \\\"{x:1088,y:569,t:1512065647292};\\\", \\\"{x:1087,y:566,t:1512065647309};\\\", \\\"{x:1086,y:564,t:1512065647342};\\\", \\\"{x:1086,y:563,t:1512065647359};\\\", \\\"{x:1086,y:561,t:1512065647375};\\\", \\\"{x:1086,y:557,t:1512065647393};\\\", \\\"{x:1086,y:556,t:1512065647408};\\\", \\\"{x:1086,y:554,t:1512065647432};\\\", \\\"{x:1086,y:556,t:1512065647816};\\\", \\\"{x:1086,y:557,t:1512065647825};\\\", \\\"{x:1087,y:560,t:1512065647842};\\\", \\\"{x:1088,y:562,t:1512065647858};\\\", \\\"{x:1088,y:564,t:1512065647875};\\\", \\\"{x:1089,y:565,t:1512065647892};\\\", \\\"{x:1089,y:566,t:1512065647908};\\\", \\\"{x:1089,y:567,t:1512065647925};\\\", \\\"{x:1089,y:571,t:1512065647942};\\\", \\\"{x:1091,y:573,t:1512065647959};\\\", \\\"{x:1092,y:578,t:1512065647976};\\\", \\\"{x:1093,y:580,t:1512065647993};\\\", \\\"{x:1094,y:583,t:1512065648010};\\\", \\\"{x:1095,y:585,t:1512065648027};\\\", \\\"{x:1095,y:586,t:1512065648044};\\\", \\\"{x:1096,y:591,t:1512065648060};\\\", \\\"{x:1100,y:601,t:1512065648077};\\\", \\\"{x:1105,y:613,t:1512065648096};\\\", \\\"{x:1113,y:626,t:1512065648109};\\\", \\\"{x:1118,y:633,t:1512065648126};\\\", \\\"{x:1120,y:637,t:1512065648143};\\\", \\\"{x:1123,y:642,t:1512065648159};\\\", \\\"{x:1129,y:656,t:1512065648176};\\\", \\\"{x:1134,y:669,t:1512065648193};\\\", \\\"{x:1143,y:683,t:1512065648209};\\\", \\\"{x:1150,y:692,t:1512065648226};\\\", \\\"{x:1156,y:701,t:1512065648243};\\\", \\\"{x:1159,y:705,t:1512065648261};\\\", \\\"{x:1161,y:707,t:1512065648276};\\\", \\\"{x:1161,y:710,t:1512065648293};\\\", \\\"{x:1164,y:714,t:1512065648310};\\\", \\\"{x:1164,y:716,t:1512065648326};\\\", \\\"{x:1165,y:720,t:1512065648343};\\\", \\\"{x:1168,y:725,t:1512065648361};\\\", \\\"{x:1168,y:728,t:1512065648377};\\\", \\\"{x:1169,y:729,t:1512065648394};\\\", \\\"{x:1170,y:731,t:1512065648411};\\\", \\\"{x:1171,y:733,t:1512065648427};\\\", \\\"{x:1171,y:734,t:1512065648444};\\\", \\\"{x:1171,y:736,t:1512065648460};\\\", \\\"{x:1172,y:737,t:1512065648477};\\\", \\\"{x:1173,y:740,t:1512065648494};\\\", \\\"{x:1175,y:744,t:1512065648511};\\\", \\\"{x:1177,y:749,t:1512065648527};\\\", \\\"{x:1178,y:752,t:1512065648544};\\\", \\\"{x:1181,y:758,t:1512065648561};\\\", \\\"{x:1182,y:760,t:1512065648577};\\\", \\\"{x:1182,y:762,t:1512065648594};\\\", \\\"{x:1183,y:763,t:1512065648611};\\\", \\\"{x:1184,y:766,t:1512065648627};\\\", \\\"{x:1185,y:768,t:1512065648644};\\\", \\\"{x:1185,y:769,t:1512065648665};\\\", \\\"{x:1186,y:770,t:1512065648681};\\\", \\\"{x:1186,y:771,t:1512065648697};\\\", \\\"{x:1187,y:774,t:1512065648711};\\\", \\\"{x:1188,y:776,t:1512065648728};\\\", \\\"{x:1188,y:779,t:1512065648744};\\\", \\\"{x:1189,y:780,t:1512065648761};\\\", \\\"{x:1189,y:782,t:1512065648777};\\\", \\\"{x:1190,y:783,t:1512065648794};\\\", \\\"{x:1191,y:784,t:1512065648811};\\\", \\\"{x:1192,y:785,t:1512065648828};\\\", \\\"{x:1192,y:786,t:1512065648849};\\\", \\\"{x:1194,y:787,t:1512065648861};\\\", \\\"{x:1195,y:791,t:1512065648878};\\\", \\\"{x:1196,y:793,t:1512065648894};\\\", \\\"{x:1197,y:795,t:1512065648911};\\\", \\\"{x:1198,y:796,t:1512065648928};\\\", \\\"{x:1200,y:800,t:1512065648944};\\\", \\\"{x:1202,y:805,t:1512065648961};\\\", \\\"{x:1205,y:810,t:1512065648977};\\\", \\\"{x:1206,y:811,t:1512065648994};\\\", \\\"{x:1208,y:814,t:1512065649011};\\\", \\\"{x:1209,y:815,t:1512065649028};\\\", \\\"{x:1212,y:818,t:1512065649044};\\\", \\\"{x:1215,y:823,t:1512065649061};\\\", \\\"{x:1219,y:829,t:1512065649078};\\\", \\\"{x:1223,y:833,t:1512065649094};\\\", \\\"{x:1228,y:840,t:1512065649111};\\\", \\\"{x:1229,y:843,t:1512065649127};\\\", \\\"{x:1231,y:845,t:1512065649144};\\\", \\\"{x:1234,y:849,t:1512065649161};\\\", \\\"{x:1235,y:851,t:1512065649178};\\\", \\\"{x:1240,y:859,t:1512065649195};\\\", \\\"{x:1242,y:861,t:1512065649211};\\\", \\\"{x:1243,y:863,t:1512065649228};\\\", \\\"{x:1245,y:866,t:1512065649245};\\\", \\\"{x:1246,y:868,t:1512065649261};\\\", \\\"{x:1248,y:873,t:1512065649278};\\\", \\\"{x:1252,y:880,t:1512065649295};\\\", \\\"{x:1259,y:891,t:1512065649311};\\\", \\\"{x:1264,y:899,t:1512065649328};\\\", \\\"{x:1270,y:910,t:1512065649345};\\\", \\\"{x:1272,y:914,t:1512065649361};\\\", \\\"{x:1277,y:922,t:1512065649378};\\\", \\\"{x:1281,y:931,t:1512065649395};\\\", \\\"{x:1285,y:942,t:1512065649411};\\\", \\\"{x:1292,y:955,t:1512065649428};\\\", \\\"{x:1298,y:969,t:1512065649444};\\\", \\\"{x:1303,y:983,t:1512065649461};\\\", \\\"{x:1308,y:991,t:1512065649478};\\\", \\\"{x:1311,y:997,t:1512065649495};\\\", \\\"{x:1315,y:1004,t:1512065649511};\\\", \\\"{x:1319,y:1011,t:1512065649528};\\\", \\\"{x:1321,y:1014,t:1512065649545};\\\", \\\"{x:1322,y:1015,t:1512065649561};\\\", \\\"{x:1322,y:1016,t:1512065649641};\\\", \\\"{x:1319,y:1013,t:1512065649657};\\\", \\\"{x:1314,y:1005,t:1512065649665};\\\", \\\"{x:1310,y:1001,t:1512065649678};\\\", \\\"{x:1299,y:989,t:1512065649695};\\\", \\\"{x:1286,y:971,t:1512065649712};\\\", \\\"{x:1274,y:957,t:1512065649728};\\\", \\\"{x:1259,y:938,t:1512065649745};\\\", \\\"{x:1250,y:926,t:1512065649761};\\\", \\\"{x:1245,y:917,t:1512065649778};\\\", \\\"{x:1241,y:911,t:1512065649795};\\\", \\\"{x:1237,y:904,t:1512065649812};\\\", \\\"{x:1234,y:898,t:1512065649828};\\\", \\\"{x:1231,y:893,t:1512065649845};\\\", \\\"{x:1228,y:889,t:1512065649862};\\\", \\\"{x:1225,y:884,t:1512065649878};\\\", \\\"{x:1221,y:875,t:1512065649895};\\\", \\\"{x:1215,y:865,t:1512065649912};\\\", \\\"{x:1210,y:855,t:1512065649928};\\\", \\\"{x:1199,y:839,t:1512065649945};\\\", \\\"{x:1192,y:827,t:1512065649961};\\\", \\\"{x:1187,y:820,t:1512065649978};\\\", \\\"{x:1183,y:813,t:1512065649995};\\\", \\\"{x:1178,y:806,t:1512065650012};\\\", \\\"{x:1174,y:802,t:1512065650029};\\\", \\\"{x:1170,y:797,t:1512065650045};\\\", \\\"{x:1167,y:793,t:1512065650062};\\\", \\\"{x:1163,y:787,t:1512065650079};\\\", \\\"{x:1161,y:784,t:1512065650095};\\\", \\\"{x:1158,y:779,t:1512065650112};\\\", \\\"{x:1156,y:776,t:1512065650129};\\\", \\\"{x:1155,y:775,t:1512065650145};\\\", \\\"{x:1154,y:771,t:1512065650162};\\\", \\\"{x:1151,y:766,t:1512065650179};\\\", \\\"{x:1150,y:763,t:1512065650195};\\\", \\\"{x:1149,y:760,t:1512065650212};\\\", \\\"{x:1148,y:758,t:1512065650229};\\\", \\\"{x:1148,y:757,t:1512065650257};\\\", \\\"{x:1148,y:755,t:1512065650297};\\\", \\\"{x:1149,y:755,t:1512065650681};\\\", \\\"{x:1150,y:755,t:1512065650737};\\\", \\\"{x:1151,y:755,t:1512065650769};\\\", \\\"{x:1152,y:756,t:1512065650793};\\\", \\\"{x:1153,y:757,t:1512065650809};\\\", \\\"{x:1154,y:758,t:1512065650817};\\\", \\\"{x:1155,y:759,t:1512065650857};\\\", \\\"{x:1155,y:761,t:1512065653729};\\\", \\\"{x:1152,y:762,t:1512065653736};\\\", \\\"{x:1141,y:768,t:1512065653748};\\\", \\\"{x:1118,y:777,t:1512065653765};\\\", \\\"{x:1098,y:785,t:1512065653781};\\\", \\\"{x:1088,y:790,t:1512065653798};\\\", \\\"{x:1073,y:795,t:1512065653815};\\\", \\\"{x:1061,y:801,t:1512065653831};\\\", \\\"{x:1055,y:803,t:1512065653848};\\\", \\\"{x:1048,y:806,t:1512065653864};\\\", \\\"{x:1038,y:807,t:1512065653881};\\\", \\\"{x:1033,y:808,t:1512065653898};\\\", \\\"{x:1025,y:810,t:1512065653915};\\\", \\\"{x:1018,y:812,t:1512065653931};\\\", \\\"{x:1017,y:812,t:1512065653948};\\\", \\\"{x:1015,y:812,t:1512065653965};\\\", \\\"{x:1013,y:812,t:1512065653985};\\\", \\\"{x:1012,y:812,t:1512065654033};\\\", \\\"{x:1011,y:812,t:1512065654065};\\\", \\\"{x:1010,y:812,t:1512065654081};\\\", \\\"{x:1009,y:812,t:1512065654098};\\\", \\\"{x:1007,y:812,t:1512065654115};\\\", \\\"{x:1005,y:814,t:1512065654132};\\\", \\\"{x:1004,y:814,t:1512065654153};\\\", \\\"{x:1003,y:814,t:1512065654165};\\\", \\\"{x:1002,y:814,t:1512065654193};\\\", \\\"{x:1001,y:814,t:1512065654385};\\\", \\\"{x:1001,y:817,t:1512065655425};\\\", \\\"{x:1001,y:818,t:1512065655433};\\\", \\\"{x:1001,y:819,t:1512065655449};\\\", \\\"{x:1001,y:820,t:1512065655466};\\\", \\\"{x:1001,y:821,t:1512065655483};\\\", \\\"{x:1001,y:823,t:1512065655499};\\\", \\\"{x:1003,y:825,t:1512065655516};\\\", \\\"{x:1003,y:826,t:1512065655533};\\\", \\\"{x:1004,y:827,t:1512065655609};\\\", \\\"{x:1004,y:828,t:1512065655625};\\\", \\\"{x:1005,y:828,t:1512065655641};\\\", \\\"{x:1006,y:829,t:1512065655657};\\\", \\\"{x:1006,y:830,t:1512065655666};\\\", \\\"{x:1007,y:830,t:1512065655683};\\\", \\\"{x:1008,y:831,t:1512065655699};\\\", \\\"{x:1011,y:831,t:1512065655716};\\\", \\\"{x:1015,y:833,t:1512065655733};\\\", \\\"{x:1017,y:834,t:1512065655749};\\\", \\\"{x:1019,y:834,t:1512065655777};\\\", \\\"{x:1020,y:834,t:1512065655800};\\\", \\\"{x:1022,y:834,t:1512065655816};\\\", \\\"{x:1023,y:834,t:1512065655832};\\\", \\\"{x:1024,y:834,t:1512065655977};\\\", \\\"{x:1024,y:833,t:1512065656113};\\\", \\\"{x:1022,y:833,t:1512065656680};\\\", \\\"{x:1021,y:833,t:1512065656695};\\\", \\\"{x:1020,y:833,t:1512065656703};\\\", \\\"{x:1017,y:834,t:1512065656716};\\\", \\\"{x:1012,y:839,t:1512065656733};\\\", \\\"{x:1002,y:854,t:1512065656749};\\\", \\\"{x:992,y:871,t:1512065656766};\\\", \\\"{x:982,y:889,t:1512065656783};\\\", \\\"{x:975,y:902,t:1512065656799};\\\", \\\"{x:968,y:918,t:1512065656816};\\\", \\\"{x:965,y:923,t:1512065656833};\\\", \\\"{x:963,y:930,t:1512065656849};\\\", \\\"{x:962,y:934,t:1512065656866};\\\", \\\"{x:961,y:940,t:1512065656883};\\\", \\\"{x:959,y:948,t:1512065656899};\\\", \\\"{x:959,y:954,t:1512065656917};\\\", \\\"{x:958,y:958,t:1512065656937};\\\", \\\"{x:957,y:961,t:1512065656952};\\\", \\\"{x:957,y:962,t:1512065656971};\\\", \\\"{x:957,y:963,t:1512065656987};\\\", \\\"{x:956,y:964,t:1512065657019};\\\", \\\"{x:956,y:963,t:1512065657420};\\\", \\\"{x:957,y:963,t:1512065657437};\\\", \\\"{x:958,y:962,t:1512065657454};\\\", \\\"{x:958,y:961,t:1512065657470};\\\", \\\"{x:958,y:960,t:1512065657487};\\\", \\\"{x:959,y:958,t:1512065657504};\\\", \\\"{x:959,y:957,t:1512065657520};\\\", \\\"{x:960,y:956,t:1512065657537};\\\", \\\"{x:960,y:955,t:1512065657554};\\\", \\\"{x:961,y:954,t:1512065657571};\\\", \\\"{x:962,y:952,t:1512065657587};\\\", \\\"{x:962,y:951,t:1512065657635};\\\", \\\"{x:962,y:950,t:1512065657708};\\\", \\\"{x:962,y:949,t:1512065657980};\\\", \\\"{x:961,y:949,t:1512065658019};\\\", \\\"{x:960,y:950,t:1512065658027};\\\", \\\"{x:960,y:951,t:1512065658037};\\\", \\\"{x:957,y:955,t:1512065658054};\\\", \\\"{x:956,y:956,t:1512065658071};\\\", \\\"{x:955,y:957,t:1512065658087};\\\", \\\"{x:954,y:958,t:1512065658103};\\\", \\\"{x:953,y:958,t:1512065658120};\\\", \\\"{x:952,y:959,t:1512065658138};\\\", \\\"{x:951,y:960,t:1512065658154};\\\", \\\"{x:950,y:960,t:1512065658171};\\\", \\\"{x:949,y:961,t:1512065658188};\\\", \\\"{x:947,y:961,t:1512065658420};\\\", \\\"{x:938,y:962,t:1512065658438};\\\", \\\"{x:926,y:964,t:1512065658454};\\\", \\\"{x:911,y:969,t:1512065658471};\\\", \\\"{x:897,y:973,t:1512065658488};\\\", \\\"{x:885,y:977,t:1512065658505};\\\", \\\"{x:883,y:978,t:1512065658521};\\\", \\\"{x:884,y:978,t:1512065658636};\\\", \\\"{x:886,y:977,t:1512065658643};\\\", \\\"{x:888,y:975,t:1512065658659};\\\", \\\"{x:892,y:973,t:1512065658671};\\\", \\\"{x:901,y:967,t:1512065658688};\\\", \\\"{x:908,y:963,t:1512065658705};\\\", \\\"{x:917,y:958,t:1512065658720};\\\", \\\"{x:931,y:952,t:1512065658737};\\\", \\\"{x:937,y:947,t:1512065658754};\\\", \\\"{x:940,y:946,t:1512065658770};\\\", \\\"{x:941,y:945,t:1512065658787};\\\", \\\"{x:941,y:943,t:1512065658940};\\\", \\\"{x:941,y:942,t:1512065658955};\\\", \\\"{x:943,y:940,t:1512065658971};\\\", \\\"{x:944,y:935,t:1512065658988};\\\", \\\"{x:948,y:927,t:1512065659005};\\\", \\\"{x:951,y:919,t:1512065659022};\\\", \\\"{x:957,y:911,t:1512065659038};\\\", \\\"{x:961,y:903,t:1512065659055};\\\", \\\"{x:966,y:897,t:1512065659072};\\\", \\\"{x:970,y:890,t:1512065659088};\\\", \\\"{x:974,y:883,t:1512065659105};\\\", \\\"{x:981,y:875,t:1512065659122};\\\", \\\"{x:986,y:867,t:1512065659138};\\\", \\\"{x:992,y:857,t:1512065659155};\\\", \\\"{x:997,y:844,t:1512065659171};\\\", \\\"{x:999,y:839,t:1512065659188};\\\", \\\"{x:999,y:835,t:1512065659205};\\\", \\\"{x:999,y:831,t:1512065659222};\\\", \\\"{x:1001,y:826,t:1512065659238};\\\", \\\"{x:1002,y:823,t:1512065659255};\\\", \\\"{x:1002,y:817,t:1512065659272};\\\", \\\"{x:1002,y:813,t:1512065659288};\\\", \\\"{x:1003,y:808,t:1512065659305};\\\", \\\"{x:1005,y:803,t:1512065659322};\\\", \\\"{x:1006,y:796,t:1512065659339};\\\", \\\"{x:1009,y:792,t:1512065659355};\\\", \\\"{x:1010,y:781,t:1512065659371};\\\", \\\"{x:1013,y:776,t:1512065659389};\\\", \\\"{x:1015,y:770,t:1512065659405};\\\", \\\"{x:1020,y:759,t:1512065659422};\\\", \\\"{x:1023,y:752,t:1512065659439};\\\", \\\"{x:1026,y:749,t:1512065659455};\\\", \\\"{x:1028,y:745,t:1512065659472};\\\", \\\"{x:1030,y:741,t:1512065659489};\\\", \\\"{x:1031,y:739,t:1512065659505};\\\", \\\"{x:1031,y:737,t:1512065659522};\\\", \\\"{x:1031,y:736,t:1512065659539};\\\", \\\"{x:1031,y:735,t:1512065659572};\\\", \\\"{x:1033,y:734,t:1512065660004};\\\", \\\"{x:1035,y:733,t:1512065660019};\\\", \\\"{x:1038,y:731,t:1512065660027};\\\", \\\"{x:1040,y:730,t:1512065660039};\\\", \\\"{x:1051,y:725,t:1512065660056};\\\", \\\"{x:1059,y:717,t:1512065660072};\\\", \\\"{x:1063,y:713,t:1512065660088};\\\", \\\"{x:1065,y:707,t:1512065660105};\\\", \\\"{x:1068,y:704,t:1512065660121};\\\", \\\"{x:1069,y:700,t:1512065660138};\\\", \\\"{x:1073,y:691,t:1512065660155};\\\", \\\"{x:1075,y:686,t:1512065660172};\\\", \\\"{x:1076,y:681,t:1512065660188};\\\", \\\"{x:1077,y:672,t:1512065660205};\\\", \\\"{x:1080,y:663,t:1512065660222};\\\", \\\"{x:1080,y:657,t:1512065660238};\\\", \\\"{x:1081,y:654,t:1512065660255};\\\", \\\"{x:1081,y:650,t:1512065660272};\\\", \\\"{x:1081,y:643,t:1512065660288};\\\", \\\"{x:1083,y:638,t:1512065660305};\\\", \\\"{x:1084,y:631,t:1512065660322};\\\", \\\"{x:1086,y:620,t:1512065660338};\\\", \\\"{x:1088,y:607,t:1512065660355};\\\", \\\"{x:1089,y:602,t:1512065660373};\\\", \\\"{x:1089,y:597,t:1512065660389};\\\", \\\"{x:1090,y:592,t:1512065660406};\\\", \\\"{x:1092,y:584,t:1512065660423};\\\", \\\"{x:1092,y:583,t:1512065660439};\\\", \\\"{x:1093,y:578,t:1512065660456};\\\", \\\"{x:1093,y:575,t:1512065660472};\\\", \\\"{x:1093,y:571,t:1512065660489};\\\", \\\"{x:1093,y:568,t:1512065660506};\\\", \\\"{x:1093,y:565,t:1512065660523};\\\", \\\"{x:1093,y:564,t:1512065660556};\\\", \\\"{x:1093,y:562,t:1512065660573};\\\", \\\"{x:1093,y:561,t:1512065660589};\\\", \\\"{x:1093,y:559,t:1512065660619};\\\", \\\"{x:1092,y:558,t:1512065660740};\\\", \\\"{x:1091,y:558,t:1512065660771};\\\", \\\"{x:1090,y:558,t:1512065660795};\\\", \\\"{x:1089,y:558,t:1512065660819};\\\", \\\"{x:1089,y:559,t:1512065660875};\\\", \\\"{x:1087,y:561,t:1512065660890};\\\", \\\"{x:1085,y:567,t:1512065660906};\\\", \\\"{x:1079,y:581,t:1512065660923};\\\", \\\"{x:1070,y:601,t:1512065660939};\\\", \\\"{x:1063,y:617,t:1512065660956};\\\", \\\"{x:1060,y:627,t:1512065660973};\\\", \\\"{x:1055,y:639,t:1512065660990};\\\", \\\"{x:1050,y:650,t:1512065661006};\\\", \\\"{x:1045,y:665,t:1512065661023};\\\", \\\"{x:1042,y:675,t:1512065661040};\\\", \\\"{x:1040,y:679,t:1512065661056};\\\", \\\"{x:1039,y:679,t:1512065661073};\\\", \\\"{x:1039,y:681,t:1512065661091};\\\", \\\"{x:1037,y:683,t:1512065661106};\\\", \\\"{x:1037,y:688,t:1512065661123};\\\", \\\"{x:1035,y:694,t:1512065661140};\\\", \\\"{x:1034,y:697,t:1512065661157};\\\", \\\"{x:1033,y:699,t:1512065661173};\\\", \\\"{x:1033,y:700,t:1512065661190};\\\", \\\"{x:1031,y:703,t:1512065661207};\\\", \\\"{x:1031,y:706,t:1512065661223};\\\", \\\"{x:1026,y:713,t:1512065661240};\\\", \\\"{x:1022,y:721,t:1512065661257};\\\", \\\"{x:1016,y:728,t:1512065661273};\\\", \\\"{x:1010,y:735,t:1512065661290};\\\", \\\"{x:1006,y:740,t:1512065661307};\\\", \\\"{x:1003,y:742,t:1512065661323};\\\", \\\"{x:999,y:744,t:1512065661340};\\\", \\\"{x:999,y:745,t:1512065661357};\\\", \\\"{x:998,y:746,t:1512065661373};\\\", \\\"{x:996,y:746,t:1512065661452};\\\", \\\"{x:995,y:747,t:1512065661467};\\\", \\\"{x:994,y:747,t:1512065661483};\\\", \\\"{x:994,y:748,t:1512065661491};\\\", \\\"{x:993,y:749,t:1512065661507};\\\", \\\"{x:988,y:752,t:1512065661523};\\\", \\\"{x:984,y:754,t:1512065661540};\\\", \\\"{x:981,y:755,t:1512065661556};\\\", \\\"{x:980,y:756,t:1512065661573};\\\", \\\"{x:979,y:757,t:1512065661589};\\\", \\\"{x:978,y:757,t:1512065661634};\\\", \\\"{x:979,y:757,t:1512065664003};\\\", \\\"{x:980,y:757,t:1512065664275};\\\", \\\"{x:981,y:757,t:1512065664292};\\\", \\\"{x:982,y:757,t:1512065664339};\\\", \\\"{x:983,y:757,t:1512065664347};\\\", \\\"{x:984,y:758,t:1512065664363};\\\", \\\"{x:985,y:758,t:1512065664376};\\\", \\\"{x:985,y:759,t:1512065664392};\\\", \\\"{x:987,y:759,t:1512065664409};\\\", \\\"{x:987,y:761,t:1512065664425};\\\", \\\"{x:989,y:765,t:1512065664442};\\\", \\\"{x:995,y:778,t:1512065664460};\\\", \\\"{x:999,y:783,t:1512065664475};\\\", \\\"{x:1002,y:789,t:1512065664492};\\\", \\\"{x:1009,y:798,t:1512065664509};\\\", \\\"{x:1013,y:804,t:1512065664526};\\\", \\\"{x:1019,y:813,t:1512065664542};\\\", \\\"{x:1024,y:820,t:1512065664559};\\\", \\\"{x:1028,y:825,t:1512065664576};\\\", \\\"{x:1032,y:831,t:1512065664592};\\\", \\\"{x:1036,y:837,t:1512065664609};\\\", \\\"{x:1045,y:845,t:1512065664626};\\\", \\\"{x:1053,y:859,t:1512065664643};\\\", \\\"{x:1056,y:865,t:1512065664659};\\\", \\\"{x:1058,y:870,t:1512065664675};\\\", \\\"{x:1059,y:873,t:1512065664693};\\\", \\\"{x:1060,y:876,t:1512065664709};\\\", \\\"{x:1062,y:881,t:1512065664726};\\\", \\\"{x:1063,y:884,t:1512065664743};\\\", \\\"{x:1063,y:886,t:1512065664759};\\\", \\\"{x:1065,y:888,t:1512065664776};\\\", \\\"{x:1065,y:891,t:1512065664793};\\\", \\\"{x:1065,y:896,t:1512065664809};\\\", \\\"{x:1066,y:898,t:1512065664826};\\\", \\\"{x:1066,y:900,t:1512065664842};\\\", \\\"{x:1067,y:905,t:1512065664858};\\\", \\\"{x:1068,y:909,t:1512065664875};\\\", \\\"{x:1068,y:911,t:1512065664892};\\\", \\\"{x:1069,y:913,t:1512065664908};\\\", \\\"{x:1070,y:914,t:1512065664925};\\\", \\\"{x:1070,y:915,t:1512065664942};\\\", \\\"{x:1070,y:917,t:1512065664958};\\\", \\\"{x:1070,y:918,t:1512065664978};\\\", \\\"{x:1070,y:919,t:1512065665019};\\\", \\\"{x:1072,y:921,t:1512065665027};\\\", \\\"{x:1072,y:923,t:1512065665051};\\\", \\\"{x:1072,y:924,t:1512065665067};\\\", \\\"{x:1073,y:925,t:1512065665075};\\\", \\\"{x:1073,y:926,t:1512065665093};\\\", \\\"{x:1074,y:928,t:1512065665111};\\\", \\\"{x:1074,y:929,t:1512065665126};\\\", \\\"{x:1074,y:930,t:1512065665147};\\\", \\\"{x:1074,y:931,t:1512065665160};\\\", \\\"{x:1075,y:932,t:1512065665176};\\\", \\\"{x:1075,y:933,t:1512065665193};\\\", \\\"{x:1077,y:936,t:1512065665210};\\\", \\\"{x:1078,y:937,t:1512065665226};\\\", \\\"{x:1078,y:938,t:1512065665283};\\\", \\\"{x:1079,y:938,t:1512065665293};\\\", \\\"{x:1079,y:939,t:1512065665315};\\\", \\\"{x:1080,y:940,t:1512065665331};\\\", \\\"{x:1080,y:942,t:1512065665347};\\\", \\\"{x:1082,y:943,t:1512065665360};\\\", \\\"{x:1082,y:944,t:1512065665376};\\\", \\\"{x:1083,y:946,t:1512065665393};\\\", \\\"{x:1084,y:947,t:1512065665410};\\\", \\\"{x:1085,y:947,t:1512065665444};\\\", \\\"{x:1088,y:947,t:1512065665460};\\\", \\\"{x:1099,y:934,t:1512065665477};\\\", \\\"{x:1111,y:906,t:1512065665494};\\\", \\\"{x:1123,y:878,t:1512065665512};\\\", \\\"{x:1135,y:851,t:1512065665528};\\\", \\\"{x:1144,y:829,t:1512065665544};\\\", \\\"{x:1147,y:814,t:1512065665561};\\\", \\\"{x:1151,y:801,t:1512065665578};\\\", \\\"{x:1152,y:793,t:1512065665594};\\\", \\\"{x:1154,y:789,t:1512065665611};\\\", \\\"{x:1154,y:782,t:1512065665628};\\\", \\\"{x:1154,y:781,t:1512065665644};\\\", \\\"{x:1154,y:779,t:1512065665660};\\\", \\\"{x:1154,y:778,t:1512065665678};\\\", \\\"{x:1154,y:776,t:1512065665694};\\\", \\\"{x:1154,y:774,t:1512065665712};\\\", \\\"{x:1153,y:773,t:1512065665728};\\\", \\\"{x:1153,y:772,t:1512065665804};\\\", \\\"{x:1153,y:771,t:1512065665812};\\\", \\\"{x:1151,y:770,t:1512065665828};\\\", \\\"{x:1151,y:768,t:1512065665844};\\\", \\\"{x:1151,y:767,t:1512065665860};\\\", \\\"{x:1151,y:766,t:1512065665925};\\\", \\\"{x:1151,y:764,t:1512065665944};\\\", \\\"{x:1151,y:763,t:1512065665961};\\\", \\\"{x:1151,y:762,t:1512065665978};\\\", \\\"{x:1151,y:761,t:1512065666012};\\\", \\\"{x:1151,y:760,t:1512065666132};\\\", \\\"{x:1151,y:759,t:1512065666245};\\\", \\\"{x:1152,y:758,t:1512065666261};\\\", \\\"{x:1151,y:761,t:1512065669084};\\\", \\\"{x:1149,y:765,t:1512065669097};\\\", \\\"{x:1140,y:776,t:1512065669114};\\\", \\\"{x:1137,y:779,t:1512065669130};\\\", \\\"{x:1135,y:781,t:1512065669147};\\\", \\\"{x:1133,y:784,t:1512065669164};\\\", \\\"{x:1132,y:787,t:1512065669180};\\\", \\\"{x:1130,y:792,t:1512065669197};\\\", \\\"{x:1127,y:795,t:1512065669214};\\\", \\\"{x:1124,y:801,t:1512065669233};\\\", \\\"{x:1122,y:804,t:1512065669246};\\\", \\\"{x:1121,y:808,t:1512065669263};\\\", \\\"{x:1118,y:813,t:1512065669279};\\\", \\\"{x:1115,y:818,t:1512065669296};\\\", \\\"{x:1113,y:824,t:1512065669313};\\\", \\\"{x:1110,y:830,t:1512065669329};\\\", \\\"{x:1107,y:834,t:1512065669346};\\\", \\\"{x:1102,y:843,t:1512065669363};\\\", \\\"{x:1098,y:851,t:1512065669379};\\\", \\\"{x:1093,y:859,t:1512065669396};\\\", \\\"{x:1085,y:873,t:1512065669413};\\\", \\\"{x:1077,y:890,t:1512065669429};\\\", \\\"{x:1071,y:906,t:1512065669446};\\\", \\\"{x:1063,y:922,t:1512065669463};\\\", \\\"{x:1057,y:933,t:1512065669479};\\\", \\\"{x:1054,y:942,t:1512065669496};\\\", \\\"{x:1051,y:949,t:1512065669513};\\\", \\\"{x:1050,y:954,t:1512065669530};\\\", \\\"{x:1049,y:958,t:1512065669547};\\\", \\\"{x:1047,y:964,t:1512065669564};\\\", \\\"{x:1046,y:967,t:1512065669580};\\\", \\\"{x:1046,y:970,t:1512065669597};\\\", \\\"{x:1046,y:972,t:1512065669614};\\\", \\\"{x:1045,y:973,t:1512065669631};\\\", \\\"{x:1045,y:977,t:1512065669647};\\\", \\\"{x:1045,y:978,t:1512065669684};\\\", \\\"{x:1048,y:973,t:1512065669764};\\\", \\\"{x:1053,y:961,t:1512065669780};\\\", \\\"{x:1061,y:945,t:1512065669797};\\\", \\\"{x:1071,y:929,t:1512065669814};\\\", \\\"{x:1078,y:920,t:1512065669831};\\\", \\\"{x:1081,y:913,t:1512065669847};\\\", \\\"{x:1082,y:910,t:1512065669864};\\\", \\\"{x:1083,y:908,t:1512065669881};\\\", \\\"{x:1086,y:903,t:1512065669897};\\\", \\\"{x:1088,y:899,t:1512065669914};\\\", \\\"{x:1089,y:897,t:1512065669931};\\\", \\\"{x:1092,y:890,t:1512065669948};\\\", \\\"{x:1094,y:886,t:1512065669964};\\\", \\\"{x:1096,y:881,t:1512065669981};\\\", \\\"{x:1102,y:874,t:1512065669998};\\\", \\\"{x:1110,y:859,t:1512065670014};\\\", \\\"{x:1122,y:844,t:1512065670031};\\\", \\\"{x:1132,y:833,t:1512065670048};\\\", \\\"{x:1136,y:827,t:1512065670064};\\\", \\\"{x:1140,y:821,t:1512065670081};\\\", \\\"{x:1142,y:816,t:1512065670098};\\\", \\\"{x:1146,y:808,t:1512065670114};\\\", \\\"{x:1151,y:797,t:1512065670131};\\\", \\\"{x:1155,y:788,t:1512065670147};\\\", \\\"{x:1156,y:783,t:1512065670163};\\\", \\\"{x:1157,y:782,t:1512065670180};\\\", \\\"{x:1157,y:781,t:1512065670218};\\\", \\\"{x:1157,y:779,t:1512065670230};\\\", \\\"{x:1157,y:770,t:1512065670247};\\\", \\\"{x:1159,y:752,t:1512065670263};\\\", \\\"{x:1162,y:728,t:1512065670280};\\\", \\\"{x:1162,y:706,t:1512065670297};\\\", \\\"{x:1162,y:695,t:1512065670314};\\\", \\\"{x:1155,y:681,t:1512065670330};\\\", \\\"{x:1149,y:665,t:1512065670347};\\\", \\\"{x:1146,y:660,t:1512065670364};\\\", \\\"{x:1142,y:653,t:1512065670380};\\\", \\\"{x:1139,y:644,t:1512065670397};\\\", \\\"{x:1138,y:635,t:1512065670414};\\\", \\\"{x:1133,y:624,t:1512065670430};\\\", \\\"{x:1130,y:619,t:1512065670447};\\\", \\\"{x:1128,y:613,t:1512065670464};\\\", \\\"{x:1124,y:604,t:1512065670480};\\\", \\\"{x:1121,y:599,t:1512065670497};\\\", \\\"{x:1119,y:596,t:1512065670514};\\\", \\\"{x:1118,y:594,t:1512065670530};\\\", \\\"{x:1114,y:590,t:1512065670547};\\\", \\\"{x:1110,y:587,t:1512065670564};\\\", \\\"{x:1102,y:581,t:1512065670580};\\\", \\\"{x:1097,y:578,t:1512065670597};\\\", \\\"{x:1096,y:577,t:1512065670614};\\\", \\\"{x:1094,y:576,t:1512065670630};\\\", \\\"{x:1092,y:574,t:1512065670647};\\\", \\\"{x:1090,y:573,t:1512065670664};\\\", \\\"{x:1088,y:571,t:1512065670680};\\\", \\\"{x:1087,y:571,t:1512065670697};\\\", \\\"{x:1085,y:570,t:1512065670714};\\\", \\\"{x:1083,y:568,t:1512065670731};\\\", \\\"{x:1082,y:567,t:1512065670763};\\\", \\\"{x:1081,y:567,t:1512065670779};\\\", \\\"{x:1081,y:566,t:1512065670795};\\\", \\\"{x:1081,y:565,t:1512065670803};\\\", \\\"{x:1081,y:564,t:1512065670827};\\\", \\\"{x:1080,y:563,t:1512065670843};\\\", \\\"{x:1080,y:562,t:1512065670859};\\\", \\\"{x:1082,y:563,t:1512065670940};\\\", \\\"{x:1084,y:567,t:1512065670948};\\\", \\\"{x:1092,y:584,t:1512065670965};\\\", \\\"{x:1103,y:609,t:1512065670982};\\\", \\\"{x:1111,y:634,t:1512065670998};\\\", \\\"{x:1118,y:661,t:1512065671015};\\\", \\\"{x:1123,y:683,t:1512065671032};\\\", \\\"{x:1131,y:703,t:1512065671048};\\\", \\\"{x:1136,y:722,t:1512065671065};\\\", \\\"{x:1144,y:741,t:1512065671082};\\\", \\\"{x:1154,y:762,t:1512065671098};\\\", \\\"{x:1163,y:785,t:1512065671115};\\\", \\\"{x:1166,y:792,t:1512065671131};\\\", \\\"{x:1166,y:793,t:1512065671147};\\\", \\\"{x:1168,y:794,t:1512065671165};\\\", \\\"{x:1168,y:795,t:1512065671347};\\\", \\\"{x:1166,y:794,t:1512065671355};\\\", \\\"{x:1164,y:792,t:1512065671364};\\\", \\\"{x:1164,y:788,t:1512065671381};\\\", \\\"{x:1162,y:783,t:1512065671398};\\\", \\\"{x:1160,y:779,t:1512065671414};\\\", \\\"{x:1159,y:777,t:1512065671431};\\\", \\\"{x:1157,y:775,t:1512065671448};\\\", \\\"{x:1157,y:774,t:1512065671464};\\\", \\\"{x:1157,y:773,t:1512065671483};\\\", \\\"{x:1157,y:772,t:1512065671508};\\\", \\\"{x:1157,y:771,t:1512065671516};\\\", \\\"{x:1157,y:770,t:1512065671533};\\\", \\\"{x:1157,y:769,t:1512065671572};\\\", \\\"{x:1157,y:768,t:1512065671582};\\\", \\\"{x:1157,y:767,t:1512065671599};\\\", \\\"{x:1157,y:765,t:1512065671614};\\\", \\\"{x:1157,y:764,t:1512065671631};\\\", \\\"{x:1157,y:761,t:1512065671648};\\\", \\\"{x:1157,y:758,t:1512065671665};\\\", \\\"{x:1157,y:756,t:1512065671682};\\\", \\\"{x:1157,y:755,t:1512065671699};\\\", \\\"{x:1159,y:758,t:1512065671892};\\\", \\\"{x:1169,y:775,t:1512065671916};\\\", \\\"{x:1175,y:790,t:1512065671932};\\\", \\\"{x:1182,y:805,t:1512065671949};\\\", \\\"{x:1187,y:817,t:1512065671966};\\\", \\\"{x:1190,y:822,t:1512065671982};\\\", \\\"{x:1192,y:824,t:1512065671999};\\\", \\\"{x:1192,y:828,t:1512065672016};\\\", \\\"{x:1195,y:831,t:1512065672032};\\\", \\\"{x:1196,y:835,t:1512065672049};\\\", \\\"{x:1200,y:843,t:1512065672066};\\\", \\\"{x:1201,y:849,t:1512065672081};\\\", \\\"{x:1203,y:853,t:1512065672098};\\\", \\\"{x:1206,y:860,t:1512065672115};\\\", \\\"{x:1209,y:866,t:1512065672132};\\\", \\\"{x:1211,y:871,t:1512065672148};\\\", \\\"{x:1214,y:875,t:1512065672165};\\\", \\\"{x:1214,y:877,t:1512065672182};\\\", \\\"{x:1215,y:880,t:1512065672198};\\\", \\\"{x:1216,y:885,t:1512065672215};\\\", \\\"{x:1218,y:892,t:1512065672232};\\\", \\\"{x:1224,y:904,t:1512065672248};\\\", \\\"{x:1229,y:914,t:1512065672265};\\\", \\\"{x:1233,y:922,t:1512065672282};\\\", \\\"{x:1237,y:932,t:1512065672298};\\\", \\\"{x:1240,y:939,t:1512065672315};\\\", \\\"{x:1242,y:941,t:1512065672332};\\\", \\\"{x:1243,y:946,t:1512065672349};\\\", \\\"{x:1245,y:948,t:1512065672366};\\\", \\\"{x:1246,y:950,t:1512065672383};\\\", \\\"{x:1246,y:951,t:1512065672398};\\\", \\\"{x:1248,y:953,t:1512065672415};\\\", \\\"{x:1248,y:954,t:1512065672433};\\\", \\\"{x:1249,y:955,t:1512065672448};\\\", \\\"{x:1249,y:956,t:1512065672467};\\\", \\\"{x:1249,y:957,t:1512065672524};\\\", \\\"{x:1249,y:958,t:1512065672580};\\\", \\\"{x:1250,y:958,t:1512065672596};\\\", \\\"{x:1251,y:959,t:1512065672652};\\\", \\\"{x:1252,y:959,t:1512065672668};\\\", \\\"{x:1253,y:961,t:1512065672682};\\\", \\\"{x:1254,y:961,t:1512065672700};\\\", \\\"{x:1255,y:962,t:1512065672716};\\\", \\\"{x:1236,y:943,t:1512065677420};\\\", \\\"{x:1164,y:884,t:1512065677436};\\\", \\\"{x:1135,y:874,t:1512065677453};\\\", \\\"{x:1117,y:867,t:1512065677470};\\\", \\\"{x:1098,y:859,t:1512065677486};\\\", \\\"{x:1084,y:850,t:1512065677503};\\\", \\\"{x:1076,y:845,t:1512065677520};\\\", \\\"{x:1070,y:840,t:1512065677537};\\\", \\\"{x:1064,y:836,t:1512065677553};\\\", \\\"{x:1062,y:835,t:1512065677570};\\\", \\\"{x:1060,y:834,t:1512065677587};\\\", \\\"{x:1059,y:834,t:1512065677603};\\\", \\\"{x:1058,y:834,t:1512065677619};\\\", \\\"{x:1057,y:834,t:1512065677651};\\\", \\\"{x:1057,y:833,t:1512065677676};\\\", \\\"{x:1055,y:832,t:1512065677691};\\\", \\\"{x:1051,y:828,t:1512065677703};\\\", \\\"{x:1044,y:823,t:1512065677719};\\\", \\\"{x:1032,y:815,t:1512065677736};\\\", \\\"{x:1024,y:810,t:1512065677752};\\\", \\\"{x:1018,y:805,t:1512065677769};\\\", \\\"{x:1012,y:799,t:1512065677786};\\\", \\\"{x:1005,y:794,t:1512065677802};\\\", \\\"{x:1004,y:793,t:1512065677819};\\\", \\\"{x:1002,y:790,t:1512065677836};\\\", \\\"{x:999,y:787,t:1512065677852};\\\", \\\"{x:998,y:786,t:1512065677874};\\\", \\\"{x:996,y:784,t:1512065677891};\\\", \\\"{x:993,y:781,t:1512065677902};\\\", \\\"{x:989,y:777,t:1512065677919};\\\", \\\"{x:988,y:775,t:1512065677936};\\\", \\\"{x:988,y:774,t:1512065677988};\\\", \\\"{x:987,y:771,t:1512065678003};\\\", \\\"{x:985,y:763,t:1512065678020};\\\", \\\"{x:984,y:759,t:1512065678037};\\\", \\\"{x:980,y:750,t:1512065678053};\\\", \\\"{x:968,y:733,t:1512065678069};\\\", \\\"{x:945,y:713,t:1512065678086};\\\", \\\"{x:913,y:688,t:1512065678103};\\\", \\\"{x:861,y:658,t:1512065678119};\\\", \\\"{x:808,y:631,t:1512065678136};\\\", \\\"{x:746,y:603,t:1512065678153};\\\", \\\"{x:707,y:576,t:1512065678169};\\\", \\\"{x:691,y:563,t:1512065678186};\\\", \\\"{x:682,y:553,t:1512065678203};\\\", \\\"{x:678,y:549,t:1512065678219};\\\", \\\"{x:677,y:547,t:1512065678236};\\\", \\\"{x:675,y:546,t:1512065678253};\\\", \\\"{x:674,y:544,t:1512065678269};\\\", \\\"{x:665,y:540,t:1512065678286};\\\", \\\"{x:641,y:533,t:1512065678303};\\\", \\\"{x:606,y:528,t:1512065678319};\\\", \\\"{x:567,y:528,t:1512065678337};\\\", \\\"{x:545,y:528,t:1512065678353};\\\", \\\"{x:536,y:528,t:1512065678371};\\\", \\\"{x:523,y:528,t:1512065678386};\\\", \\\"{x:504,y:528,t:1512065678403};\\\", \\\"{x:493,y:527,t:1512065678420};\\\", \\\"{x:477,y:527,t:1512065678436};\\\", \\\"{x:463,y:525,t:1512065678453};\\\", \\\"{x:450,y:521,t:1512065678471};\\\", \\\"{x:433,y:518,t:1512065678487};\\\", \\\"{x:417,y:516,t:1512065678503};\\\", \\\"{x:401,y:515,t:1512065678520};\\\", \\\"{x:392,y:515,t:1512065678536};\\\", \\\"{x:380,y:515,t:1512065678553};\\\", \\\"{x:372,y:515,t:1512065678570};\\\", \\\"{x:367,y:515,t:1512065678586};\\\", \\\"{x:352,y:515,t:1512065678603};\\\", \\\"{x:337,y:515,t:1512065678620};\\\", \\\"{x:318,y:515,t:1512065678636};\\\", \\\"{x:298,y:515,t:1512065678653};\\\", \\\"{x:280,y:515,t:1512065678671};\\\", \\\"{x:257,y:515,t:1512065678686};\\\", \\\"{x:233,y:518,t:1512065678703};\\\", \\\"{x:222,y:520,t:1512065678721};\\\", \\\"{x:217,y:522,t:1512065678737};\\\", \\\"{x:214,y:523,t:1512065678753};\\\", \\\"{x:214,y:524,t:1512065678811};\\\", \\\"{x:213,y:524,t:1512065678859};\\\", \\\"{x:213,y:525,t:1512065678875};\\\", \\\"{x:213,y:526,t:1512065678939};\\\", \\\"{x:213,y:527,t:1512065678955};\\\", \\\"{x:213,y:528,t:1512065678970};\\\", \\\"{x:212,y:529,t:1512065678987};\\\", \\\"{x:210,y:530,t:1512065679003};\\\", \\\"{x:207,y:532,t:1512065679020};\\\", \\\"{x:204,y:532,t:1512065679037};\\\", \\\"{x:200,y:533,t:1512065679053};\\\", \\\"{x:198,y:534,t:1512065679070};\\\", \\\"{x:195,y:535,t:1512065679087};\\\", \\\"{x:192,y:536,t:1512065679104};\\\", \\\"{x:190,y:536,t:1512065679120};\\\", \\\"{x:187,y:537,t:1512065679137};\\\", \\\"{x:187,y:538,t:1512065679150};\\\", \\\"{x:186,y:538,t:1512065679178};\\\", \\\"{x:185,y:538,t:1512065679194};\\\", \\\"{x:184,y:538,t:1512065679331};\\\", \\\"{x:184,y:536,t:1512065679363};\\\", \\\"{x:184,y:535,t:1512065679371};\\\", \\\"{x:185,y:534,t:1512065679385};\\\", \\\"{x:185,y:533,t:1512065679401};\\\", \\\"{x:188,y:529,t:1512065679419};\\\", \\\"{x:189,y:528,t:1512065679435};\\\", \\\"{x:190,y:528,t:1512065679452};\\\", \\\"{x:191,y:526,t:1512065679468};\\\", \\\"{x:193,y:526,t:1512065679586};\\\", \\\"{x:193,y:526,t:1512065679676};\\\", \\\"{x:192,y:526,t:1512065679851};\\\", \\\"{x:191,y:527,t:1512065679867};\\\", \\\"{x:191,y:528,t:1512065679883};\\\", \\\"{x:190,y:529,t:1512065679899};\\\", \\\"{x:190,y:530,t:1512065679939};\\\", \\\"{x:190,y:532,t:1512065679955};\\\", \\\"{x:190,y:535,t:1512065679972};\\\", \\\"{x:191,y:539,t:1512065679989};\\\", \\\"{x:197,y:546,t:1512065680006};\\\", \\\"{x:204,y:554,t:1512065680022};\\\", \\\"{x:221,y:565,t:1512065680039};\\\", \\\"{x:242,y:578,t:1512065680055};\\\", \\\"{x:265,y:593,t:1512065680073};\\\", \\\"{x:280,y:601,t:1512065680090};\\\", \\\"{x:295,y:610,t:1512065680106};\\\", \\\"{x:308,y:619,t:1512065680123};\\\", \\\"{x:314,y:624,t:1512065680139};\\\", \\\"{x:321,y:629,t:1512065680156};\\\", \\\"{x:332,y:639,t:1512065680172};\\\", \\\"{x:343,y:647,t:1512065680189};\\\", \\\"{x:356,y:655,t:1512065680206};\\\", \\\"{x:367,y:664,t:1512065680222};\\\", \\\"{x:377,y:674,t:1512065680239};\\\", \\\"{x:384,y:682,t:1512065680256};\\\", \\\"{x:387,y:685,t:1512065680272};\\\", \\\"{x:392,y:687,t:1512065680289};\\\", \\\"{x:401,y:696,t:1512065680306};\\\", \\\"{x:407,y:702,t:1512065680322};\\\", \\\"{x:410,y:705,t:1512065680339};\\\", \\\"{x:411,y:706,t:1512065680356};\\\", \\\"{x:412,y:707,t:1512065680378};\\\", \\\"{x:413,y:708,t:1512065680394};\\\", \\\"{x:413,y:709,t:1512065680507};\\\", \\\"{x:412,y:708,t:1512065680547};\\\", \\\"{x:410,y:705,t:1512065680571};\\\", \\\"{x:410,y:704,t:1512065680587};\\\", \\\"{x:410,y:702,t:1512065680595};\\\", \\\"{x:410,y:701,t:1512065680619};\\\", \\\"{x:409,y:699,t:1512065680635};\\\", \\\"{x:408,y:699,t:1512065680715};\\\", \\\"{x:407,y:699,t:1512065680778};\\\", \\\"{x:407,y:699,t:1512065680873};\\\", \\\"{x:407,y:700,t:1512065681140};\\\", \\\"{x:417,y:708,t:1512065681156};\\\", \\\"{x:430,y:715,t:1512065681173};\\\", \\\"{x:442,y:723,t:1512065681190};\\\", \\\"{x:453,y:730,t:1512065681206};\\\", \\\"{x:472,y:743,t:1512065681223};\\\", \\\"{x:491,y:753,t:1512065681240};\\\", \\\"{x:502,y:760,t:1512065681256};\\\", \\\"{x:523,y:768,t:1512065681273};\\\", \\\"{x:567,y:785,t:1512065681291};\\\", \\\"{x:595,y:796,t:1512065681307};\\\", \\\"{x:625,y:803,t:1512065681323};\\\", \\\"{x:655,y:810,t:1512065681340};\\\", \\\"{x:679,y:814,t:1512065681356};\\\", \\\"{x:695,y:816,t:1512065681373};\\\", \\\"{x:709,y:818,t:1512065681390};\\\", \\\"{x:723,y:820,t:1512065681407};\\\", \\\"{x:732,y:821,t:1512065681423};\\\", \\\"{x:737,y:821,t:1512065681440};\\\", \\\"{x:740,y:821,t:1512065681457};\\\", \\\"{x:742,y:821,t:1512065681473};\\\" ] }, { \\\"rt\\\": 7254, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 452605, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:743,y:821,t:1512065685156};\\\", \\\"{x:755,y:821,t:1512065685176};\\\", \\\"{x:766,y:821,t:1512065685180};\\\", \\\"{x:778,y:821,t:1512065685194};\\\", \\\"{x:803,y:821,t:1512065685210};\\\", \\\"{x:838,y:817,t:1512065685227};\\\", \\\"{x:863,y:813,t:1512065685244};\\\", \\\"{x:884,y:807,t:1512065685260};\\\", \\\"{x:903,y:801,t:1512065685277};\\\", \\\"{x:921,y:795,t:1512065685294};\\\", \\\"{x:931,y:795,t:1512065685310};\\\", \\\"{x:941,y:795,t:1512065685327};\\\", \\\"{x:960,y:795,t:1512065685344};\\\", \\\"{x:986,y:791,t:1512065685360};\\\", \\\"{x:1011,y:788,t:1512065685377};\\\", \\\"{x:1036,y:784,t:1512065685394};\\\", \\\"{x:1073,y:775,t:1512065685410};\\\", \\\"{x:1159,y:760,t:1512065685428};\\\", \\\"{x:1201,y:755,t:1512065685445};\\\", \\\"{x:1233,y:745,t:1512065685460};\\\", \\\"{x:1255,y:734,t:1512065685477};\\\", \\\"{x:1276,y:722,t:1512065685494};\\\", \\\"{x:1292,y:709,t:1512065685511};\\\", \\\"{x:1309,y:697,t:1512065685527};\\\", \\\"{x:1321,y:685,t:1512065685544};\\\", \\\"{x:1330,y:677,t:1512065685560};\\\", \\\"{x:1336,y:669,t:1512065685577};\\\", \\\"{x:1339,y:665,t:1512065685594};\\\", \\\"{x:1340,y:665,t:1512065685611};\\\", \\\"{x:1340,y:664,t:1512065685644};\\\", \\\"{x:1336,y:664,t:1512065685692};\\\", \\\"{x:1330,y:664,t:1512065685700};\\\", \\\"{x:1326,y:664,t:1512065685712};\\\", \\\"{x:1317,y:664,t:1512065685728};\\\", \\\"{x:1308,y:665,t:1512065685745};\\\", \\\"{x:1292,y:668,t:1512065685762};\\\", \\\"{x:1274,y:672,t:1512065685778};\\\", \\\"{x:1268,y:673,t:1512065685795};\\\", \\\"{x:1258,y:676,t:1512065685812};\\\", \\\"{x:1239,y:680,t:1512065685828};\\\", \\\"{x:1217,y:688,t:1512065685845};\\\", \\\"{x:1193,y:697,t:1512065685862};\\\", \\\"{x:1174,y:705,t:1512065685878};\\\", \\\"{x:1167,y:708,t:1512065685895};\\\", \\\"{x:1166,y:709,t:1512065685916};\\\", \\\"{x:1165,y:709,t:1512065685932};\\\", \\\"{x:1164,y:710,t:1512065685948};\\\", \\\"{x:1163,y:710,t:1512065685972};\\\", \\\"{x:1160,y:710,t:1512065685980};\\\", \\\"{x:1157,y:711,t:1512065685995};\\\", \\\"{x:1147,y:711,t:1512065686012};\\\", \\\"{x:1142,y:712,t:1512065686028};\\\", \\\"{x:1141,y:713,t:1512065686045};\\\", \\\"{x:1140,y:713,t:1512065686062};\\\", \\\"{x:1139,y:713,t:1512065686092};\\\", \\\"{x:1138,y:713,t:1512065686116};\\\", \\\"{x:1137,y:712,t:1512065686132};\\\", \\\"{x:1137,y:709,t:1512065686145};\\\", \\\"{x:1137,y:708,t:1512065686162};\\\", \\\"{x:1137,y:706,t:1512065686179};\\\", \\\"{x:1137,y:704,t:1512065686195};\\\", \\\"{x:1139,y:698,t:1512065686212};\\\", \\\"{x:1141,y:694,t:1512065686228};\\\", \\\"{x:1143,y:693,t:1512065686245};\\\", \\\"{x:1144,y:691,t:1512065686262};\\\", \\\"{x:1145,y:691,t:1512065686279};\\\", \\\"{x:1146,y:691,t:1512065686340};\\\", \\\"{x:1147,y:691,t:1512065686388};\\\", \\\"{x:1148,y:691,t:1512065686396};\\\", \\\"{x:1149,y:691,t:1512065686412};\\\", \\\"{x:1149,y:693,t:1512065686452};\\\", \\\"{x:1149,y:692,t:1512065686692};\\\", \\\"{x:1149,y:689,t:1512065686700};\\\", \\\"{x:1149,y:687,t:1512065686712};\\\", \\\"{x:1149,y:683,t:1512065686729};\\\", \\\"{x:1147,y:676,t:1512065686746};\\\", \\\"{x:1142,y:667,t:1512065686762};\\\", \\\"{x:1139,y:660,t:1512065686779};\\\", \\\"{x:1132,y:644,t:1512065686796};\\\", \\\"{x:1128,y:639,t:1512065686812};\\\", \\\"{x:1114,y:618,t:1512065686829};\\\", \\\"{x:1106,y:603,t:1512065686846};\\\", \\\"{x:1096,y:589,t:1512065686862};\\\", \\\"{x:1090,y:577,t:1512065686879};\\\", \\\"{x:1083,y:566,t:1512065686896};\\\", \\\"{x:1078,y:554,t:1512065686912};\\\", \\\"{x:1072,y:543,t:1512065686929};\\\", \\\"{x:1068,y:535,t:1512065686946};\\\", \\\"{x:1065,y:530,t:1512065686962};\\\", \\\"{x:1062,y:526,t:1512065686979};\\\", \\\"{x:1061,y:523,t:1512065686996};\\\", \\\"{x:1060,y:522,t:1512065687012};\\\", \\\"{x:1060,y:521,t:1512065687029};\\\", \\\"{x:1059,y:520,t:1512065687052};\\\", \\\"{x:1059,y:519,t:1512065687100};\\\", \\\"{x:1058,y:519,t:1512065687148};\\\", \\\"{x:1057,y:519,t:1512065687162};\\\", \\\"{x:1054,y:519,t:1512065687179};\\\", \\\"{x:1029,y:528,t:1512065687196};\\\", \\\"{x:1003,y:536,t:1512065687212};\\\", \\\"{x:959,y:548,t:1512065687229};\\\", \\\"{x:928,y:557,t:1512065687246};\\\", \\\"{x:902,y:562,t:1512065687263};\\\", \\\"{x:874,y:566,t:1512065687279};\\\", \\\"{x:839,y:568,t:1512065687296};\\\", \\\"{x:818,y:566,t:1512065687313};\\\", \\\"{x:805,y:564,t:1512065687329};\\\", \\\"{x:787,y:561,t:1512065687346};\\\", \\\"{x:772,y:560,t:1512065687362};\\\", \\\"{x:765,y:558,t:1512065687379};\\\", \\\"{x:764,y:558,t:1512065687395};\\\", \\\"{x:762,y:558,t:1512065687412};\\\", \\\"{x:758,y:558,t:1512065687428};\\\", \\\"{x:749,y:558,t:1512065687445};\\\", \\\"{x:737,y:555,t:1512065687462};\\\", \\\"{x:711,y:548,t:1512065687479};\\\", \\\"{x:663,y:534,t:1512065687496};\\\", \\\"{x:624,y:529,t:1512065687513};\\\", \\\"{x:608,y:526,t:1512065687529};\\\", \\\"{x:598,y:523,t:1512065687545};\\\", \\\"{x:593,y:521,t:1512065687562};\\\", \\\"{x:583,y:520,t:1512065687579};\\\", \\\"{x:559,y:518,t:1512065687596};\\\", \\\"{x:531,y:517,t:1512065687612};\\\", \\\"{x:495,y:514,t:1512065687629};\\\", \\\"{x:469,y:511,t:1512065687646};\\\", \\\"{x:458,y:511,t:1512065687662};\\\", \\\"{x:457,y:509,t:1512065687679};\\\", \\\"{x:456,y:509,t:1512065687696};\\\", \\\"{x:455,y:509,t:1512065687747};\\\", \\\"{x:453,y:510,t:1512065687763};\\\", \\\"{x:448,y:512,t:1512065687779};\\\", \\\"{x:447,y:513,t:1512065687796};\\\", \\\"{x:446,y:513,t:1512065687820};\\\", \\\"{x:443,y:515,t:1512065687844};\\\", \\\"{x:442,y:515,t:1512065687851};\\\", \\\"{x:439,y:516,t:1512065687864};\\\", \\\"{x:435,y:518,t:1512065687879};\\\", \\\"{x:429,y:521,t:1512065687897};\\\", \\\"{x:425,y:523,t:1512065687914};\\\", \\\"{x:422,y:524,t:1512065687929};\\\", \\\"{x:421,y:524,t:1512065687947};\\\", \\\"{x:418,y:526,t:1512065687963};\\\", \\\"{x:417,y:526,t:1512065687980};\\\", \\\"{x:415,y:527,t:1512065687997};\\\", \\\"{x:412,y:529,t:1512065688014};\\\", \\\"{x:410,y:530,t:1512065688030};\\\", \\\"{x:409,y:530,t:1512065688047};\\\", \\\"{x:408,y:530,t:1512065688063};\\\", \\\"{x:407,y:531,t:1512065688079};\\\", \\\"{x:406,y:531,t:1512065688100};\\\", \\\"{x:404,y:532,t:1512065688113};\\\", \\\"{x:403,y:533,t:1512065688129};\\\", \\\"{x:401,y:533,t:1512065688146};\\\", \\\"{x:400,y:534,t:1512065688172};\\\", \\\"{x:398,y:535,t:1512065688260};\\\", \\\"{x:399,y:535,t:1512065688555};\\\", \\\"{x:401,y:535,t:1512065688571};\\\", \\\"{x:404,y:535,t:1512065688580};\\\", \\\"{x:408,y:537,t:1512065688596};\\\", \\\"{x:410,y:538,t:1512065688613};\\\", \\\"{x:413,y:540,t:1512065688631};\\\", \\\"{x:416,y:542,t:1512065688647};\\\", \\\"{x:417,y:544,t:1512065688663};\\\", \\\"{x:421,y:550,t:1512065688680};\\\", \\\"{x:428,y:561,t:1512065688698};\\\", \\\"{x:434,y:573,t:1512065688714};\\\", \\\"{x:437,y:581,t:1512065688731};\\\", \\\"{x:440,y:605,t:1512065688748};\\\", \\\"{x:441,y:620,t:1512065688763};\\\", \\\"{x:444,y:640,t:1512065688781};\\\", \\\"{x:444,y:663,t:1512065688798};\\\", \\\"{x:445,y:682,t:1512065688814};\\\", \\\"{x:446,y:692,t:1512065688830};\\\", \\\"{x:446,y:696,t:1512065688847};\\\", \\\"{x:446,y:697,t:1512065688863};\\\", \\\"{x:447,y:701,t:1512065688880};\\\", \\\"{x:447,y:702,t:1512065688899};\\\", \\\"{x:447,y:703,t:1512065688955};\\\", \\\"{x:447,y:704,t:1512065688979};\\\", \\\"{x:446,y:704,t:1512065689011};\\\", \\\"{x:445,y:704,t:1512065689060};\\\", \\\"{x:444,y:704,t:1512065689067};\\\", \\\"{x:443,y:704,t:1512065689080};\\\", \\\"{x:442,y:702,t:1512065689097};\\\", \\\"{x:441,y:701,t:1512065689115};\\\", \\\"{x:439,y:698,t:1512065689130};\\\", \\\"{x:438,y:696,t:1512065689147};\\\", \\\"{x:438,y:695,t:1512065689164};\\\", \\\"{x:440,y:694,t:1512065689716};\\\", \\\"{x:449,y:700,t:1512065689731};\\\", \\\"{x:459,y:707,t:1512065689747};\\\", \\\"{x:472,y:716,t:1512065689764};\\\", \\\"{x:481,y:724,t:1512065689781};\\\", \\\"{x:488,y:730,t:1512065689797};\\\", \\\"{x:495,y:740,t:1512065689814};\\\", \\\"{x:504,y:751,t:1512065689831};\\\", \\\"{x:512,y:762,t:1512065689847};\\\", \\\"{x:524,y:778,t:1512065689864};\\\", \\\"{x:534,y:791,t:1512065689881};\\\", \\\"{x:550,y:809,t:1512065689897};\\\", \\\"{x:567,y:827,t:1512065689915};\\\", \\\"{x:582,y:840,t:1512065689931};\\\", \\\"{x:595,y:849,t:1512065689948};\\\", \\\"{x:608,y:857,t:1512065689964};\\\", \\\"{x:623,y:870,t:1512065689981};\\\", \\\"{x:639,y:877,t:1512065689998};\\\", \\\"{x:651,y:883,t:1512065690014};\\\", \\\"{x:667,y:888,t:1512065690031};\\\", \\\"{x:677,y:892,t:1512065690048};\\\", \\\"{x:690,y:896,t:1512065690064};\\\", \\\"{x:698,y:897,t:1512065690081};\\\", \\\"{x:702,y:898,t:1512065690099};\\\", \\\"{x:707,y:899,t:1512065690114};\\\", \\\"{x:711,y:900,t:1512065690131};\\\", \\\"{x:712,y:900,t:1512065690155};\\\" ] }, { \\\"rt\\\": 12444, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 466325, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-12 PM-M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:714,y:900,t:1512065692514};\\\", \\\"{x:725,y:900,t:1512065692522};\\\", \\\"{x:750,y:900,t:1512065692533};\\\", \\\"{x:844,y:913,t:1512065692550};\\\", \\\"{x:917,y:924,t:1512065692566};\\\", \\\"{x:947,y:930,t:1512065692583};\\\", \\\"{x:960,y:935,t:1512065692600};\\\", \\\"{x:974,y:939,t:1512065692616};\\\", \\\"{x:989,y:944,t:1512065692633};\\\", \\\"{x:998,y:945,t:1512065692650};\\\", \\\"{x:1007,y:948,t:1512065692666};\\\", \\\"{x:1024,y:953,t:1512065692683};\\\", \\\"{x:1036,y:957,t:1512065692700};\\\", \\\"{x:1050,y:960,t:1512065692716};\\\", \\\"{x:1062,y:964,t:1512065692733};\\\", \\\"{x:1075,y:968,t:1512065692751};\\\", \\\"{x:1086,y:972,t:1512065692766};\\\", \\\"{x:1087,y:972,t:1512065692787};\\\", \\\"{x:1088,y:972,t:1512065692811};\\\", \\\"{x:1089,y:972,t:1512065692819};\\\", \\\"{x:1090,y:972,t:1512065692835};\\\", \\\"{x:1092,y:972,t:1512065692850};\\\", \\\"{x:1096,y:972,t:1512065692866};\\\", \\\"{x:1105,y:972,t:1512065692883};\\\", \\\"{x:1111,y:972,t:1512065692900};\\\", \\\"{x:1119,y:972,t:1512065692916};\\\", \\\"{x:1129,y:972,t:1512065692933};\\\", \\\"{x:1139,y:972,t:1512065692951};\\\", \\\"{x:1148,y:968,t:1512065692968};\\\", \\\"{x:1151,y:967,t:1512065692984};\\\", \\\"{x:1157,y:965,t:1512065693001};\\\", \\\"{x:1162,y:963,t:1512065693018};\\\", \\\"{x:1164,y:962,t:1512065693034};\\\", \\\"{x:1165,y:962,t:1512065693051};\\\", \\\"{x:1166,y:961,t:1512065693068};\\\", \\\"{x:1167,y:960,t:1512065693091};\\\", \\\"{x:1168,y:960,t:1512065693132};\\\", \\\"{x:1169,y:959,t:1512065693147};\\\", \\\"{x:1170,y:958,t:1512065693163};\\\", \\\"{x:1172,y:957,t:1512065693171};\\\", \\\"{x:1173,y:956,t:1512065693187};\\\", \\\"{x:1174,y:956,t:1512065693201};\\\", \\\"{x:1178,y:953,t:1512065693218};\\\", \\\"{x:1181,y:947,t:1512065693234};\\\", \\\"{x:1185,y:938,t:1512065693251};\\\", \\\"{x:1190,y:922,t:1512065693267};\\\", \\\"{x:1193,y:915,t:1512065693284};\\\", \\\"{x:1194,y:911,t:1512065693301};\\\", \\\"{x:1194,y:908,t:1512065693318};\\\", \\\"{x:1194,y:906,t:1512065693334};\\\", \\\"{x:1194,y:904,t:1512065693351};\\\", \\\"{x:1196,y:902,t:1512065693368};\\\", \\\"{x:1196,y:900,t:1512065693384};\\\", \\\"{x:1196,y:898,t:1512065693401};\\\", \\\"{x:1196,y:897,t:1512065693419};\\\", \\\"{x:1196,y:896,t:1512065693443};\\\", \\\"{x:1196,y:895,t:1512065693588};\\\", \\\"{x:1195,y:895,t:1512065693638};\\\", \\\"{x:1193,y:895,t:1512065693667};\\\", \\\"{x:1192,y:895,t:1512065693684};\\\", \\\"{x:1190,y:895,t:1512065693700};\\\", \\\"{x:1186,y:897,t:1512065693717};\\\", \\\"{x:1185,y:898,t:1512065693734};\\\", \\\"{x:1183,y:899,t:1512065693751};\\\", \\\"{x:1181,y:899,t:1512065693767};\\\", \\\"{x:1180,y:899,t:1512065693784};\\\", \\\"{x:1181,y:899,t:1512065695411};\\\", \\\"{x:1182,y:899,t:1512065695436};\\\", \\\"{x:1183,y:899,t:1512065695572};\\\", \\\"{x:1184,y:899,t:1512065695700};\\\", \\\"{x:1180,y:897,t:1512065698812};\\\", \\\"{x:1159,y:890,t:1512065698822};\\\", \\\"{x:1098,y:862,t:1512065698839};\\\", \\\"{x:1045,y:837,t:1512065698855};\\\", \\\"{x:1015,y:824,t:1512065698872};\\\", \\\"{x:998,y:816,t:1512065698889};\\\", \\\"{x:990,y:811,t:1512065698905};\\\", \\\"{x:984,y:807,t:1512065698922};\\\", \\\"{x:971,y:798,t:1512065698939};\\\", \\\"{x:947,y:785,t:1512065698955};\\\", \\\"{x:914,y:770,t:1512065698971};\\\", \\\"{x:870,y:750,t:1512065698989};\\\", \\\"{x:831,y:733,t:1512065699005};\\\", \\\"{x:789,y:715,t:1512065699021};\\\", \\\"{x:764,y:706,t:1512065699039};\\\", \\\"{x:742,y:698,t:1512065699055};\\\", \\\"{x:726,y:692,t:1512065699071};\\\", \\\"{x:707,y:687,t:1512065699088};\\\", \\\"{x:688,y:677,t:1512065699105};\\\", \\\"{x:673,y:670,t:1512065699122};\\\", \\\"{x:647,y:658,t:1512065699139};\\\", \\\"{x:635,y:653,t:1512065699155};\\\", \\\"{x:625,y:646,t:1512065699171};\\\", \\\"{x:614,y:640,t:1512065699189};\\\", \\\"{x:606,y:635,t:1512065699206};\\\", \\\"{x:592,y:629,t:1512065699221};\\\", \\\"{x:574,y:620,t:1512065699238};\\\", \\\"{x:558,y:614,t:1512065699255};\\\", \\\"{x:545,y:610,t:1512065699271};\\\", \\\"{x:534,y:607,t:1512065699288};\\\", \\\"{x:523,y:603,t:1512065699306};\\\", \\\"{x:512,y:600,t:1512065699321};\\\", \\\"{x:506,y:599,t:1512065699339};\\\", \\\"{x:500,y:599,t:1512065699355};\\\", \\\"{x:489,y:598,t:1512065699371};\\\", \\\"{x:473,y:593,t:1512065699388};\\\", \\\"{x:461,y:593,t:1512065699406};\\\", \\\"{x:452,y:591,t:1512065699422};\\\", \\\"{x:447,y:590,t:1512065699438};\\\", \\\"{x:443,y:590,t:1512065699455};\\\", \\\"{x:438,y:590,t:1512065699472};\\\", \\\"{x:434,y:590,t:1512065699488};\\\", \\\"{x:430,y:590,t:1512065699505};\\\", \\\"{x:427,y:590,t:1512065699522};\\\", \\\"{x:420,y:590,t:1512065699539};\\\", \\\"{x:415,y:590,t:1512065699555};\\\", \\\"{x:413,y:590,t:1512065699572};\\\", \\\"{x:409,y:591,t:1512065699589};\\\", \\\"{x:405,y:592,t:1512065699605};\\\", \\\"{x:399,y:592,t:1512065699622};\\\", \\\"{x:396,y:593,t:1512065699638};\\\", \\\"{x:391,y:593,t:1512065699655};\\\", \\\"{x:387,y:593,t:1512065699672};\\\", \\\"{x:383,y:593,t:1512065699688};\\\", \\\"{x:378,y:593,t:1512065699705};\\\", \\\"{x:370,y:593,t:1512065699722};\\\", \\\"{x:363,y:593,t:1512065699738};\\\", \\\"{x:358,y:593,t:1512065699755};\\\", \\\"{x:355,y:593,t:1512065699772};\\\", \\\"{x:351,y:593,t:1512065699788};\\\", \\\"{x:349,y:593,t:1512065699805};\\\", \\\"{x:347,y:593,t:1512065699822};\\\", \\\"{x:346,y:593,t:1512065699838};\\\", \\\"{x:345,y:593,t:1512065699859};\\\", \\\"{x:343,y:593,t:1512065699875};\\\", \\\"{x:342,y:593,t:1512065699888};\\\", \\\"{x:338,y:593,t:1512065699905};\\\", \\\"{x:329,y:593,t:1512065699923};\\\", \\\"{x:320,y:593,t:1512065699939};\\\", \\\"{x:308,y:592,t:1512065699955};\\\", \\\"{x:292,y:588,t:1512065699973};\\\", \\\"{x:274,y:584,t:1512065699990};\\\", \\\"{x:263,y:583,t:1512065700005};\\\", \\\"{x:255,y:581,t:1512065700022};\\\", \\\"{x:251,y:580,t:1512065700039};\\\", \\\"{x:250,y:579,t:1512065700056};\\\", \\\"{x:248,y:579,t:1512065700075};\\\", \\\"{x:246,y:578,t:1512065700091};\\\", \\\"{x:245,y:576,t:1512065700105};\\\", \\\"{x:240,y:572,t:1512065700123};\\\", \\\"{x:238,y:569,t:1512065700139};\\\", \\\"{x:236,y:567,t:1512065700156};\\\", \\\"{x:235,y:566,t:1512065700172};\\\", \\\"{x:233,y:565,t:1512065700189};\\\", \\\"{x:230,y:563,t:1512065700206};\\\", \\\"{x:223,y:560,t:1512065700222};\\\", \\\"{x:219,y:556,t:1512065700239};\\\", \\\"{x:217,y:554,t:1512065700256};\\\", \\\"{x:216,y:554,t:1512065700272};\\\", \\\"{x:215,y:554,t:1512065700355};\\\", \\\"{x:214,y:554,t:1512065700387};\\\", \\\"{x:213,y:554,t:1512065700395};\\\", \\\"{x:212,y:554,t:1512065700407};\\\", \\\"{x:206,y:554,t:1512065700426};\\\", \\\"{x:201,y:555,t:1512065700440};\\\", \\\"{x:192,y:556,t:1512065700457};\\\", \\\"{x:183,y:556,t:1512065700474};\\\", \\\"{x:179,y:556,t:1512065700490};\\\", \\\"{x:177,y:556,t:1512065700507};\\\", \\\"{x:176,y:556,t:1512065700539};\\\", \\\"{x:175,y:557,t:1512065700555};\\\", \\\"{x:174,y:558,t:1512065700573};\\\", \\\"{x:175,y:558,t:1512065700804};\\\", \\\"{x:176,y:558,t:1512065700812};\\\", \\\"{x:176,y:559,t:1512065700824};\\\", \\\"{x:177,y:559,t:1512065700843};\\\", \\\"{x:178,y:559,t:1512065700868};\\\", \\\"{x:179,y:559,t:1512065700884};\\\", \\\"{x:180,y:559,t:1512065700908};\\\", \\\"{x:185,y:559,t:1512065701212};\\\", \\\"{x:194,y:563,t:1512065701225};\\\", \\\"{x:224,y:568,t:1512065701241};\\\", \\\"{x:250,y:573,t:1512065701257};\\\", \\\"{x:284,y:580,t:1512065701274};\\\", \\\"{x:309,y:583,t:1512065701291};\\\", \\\"{x:326,y:586,t:1512065701308};\\\", \\\"{x:340,y:587,t:1512065701324};\\\", \\\"{x:354,y:590,t:1512065701342};\\\", \\\"{x:384,y:590,t:1512065701358};\\\", \\\"{x:404,y:592,t:1512065701375};\\\", \\\"{x:429,y:596,t:1512065701391};\\\", \\\"{x:447,y:599,t:1512065701408};\\\", \\\"{x:455,y:600,t:1512065701425};\\\", \\\"{x:457,y:600,t:1512065701556};\\\", \\\"{x:458,y:600,t:1512065701564};\\\", \\\"{x:460,y:600,t:1512065701580};\\\", \\\"{x:462,y:600,t:1512065701591};\\\", \\\"{x:471,y:599,t:1512065701609};\\\", \\\"{x:485,y:597,t:1512065701624};\\\", \\\"{x:503,y:594,t:1512065701641};\\\", \\\"{x:514,y:593,t:1512065701659};\\\", \\\"{x:520,y:592,t:1512065701675};\\\", \\\"{x:526,y:592,t:1512065701692};\\\", \\\"{x:527,y:591,t:1512065701741};\\\", \\\"{x:526,y:591,t:1512065701924};\\\", \\\"{x:525,y:591,t:1512065701932};\\\", \\\"{x:524,y:591,t:1512065701948};\\\", \\\"{x:523,y:591,t:1512065701972};\\\", \\\"{x:522,y:591,t:1512065701980};\\\", \\\"{x:521,y:591,t:1512065701996};\\\", \\\"{x:520,y:591,t:1512065702009};\\\", \\\"{x:519,y:591,t:1512065702028};\\\", \\\"{x:518,y:591,t:1512065702044};\\\", \\\"{x:517,y:591,t:1512065702084};\\\", \\\"{x:516,y:591,t:1512065702092};\\\", \\\"{x:515,y:591,t:1512065702109};\\\", \\\"{x:514,y:591,t:1512065702156};\\\", \\\"{x:513,y:591,t:1512065702208};\\\", \\\"{x:512,y:591,t:1512065702243};\\\", \\\"{x:512,y:591,t:1512065702300};\\\", \\\"{x:511,y:591,t:1512065702308};\\\", \\\"{x:510,y:592,t:1512065702325};\\\", \\\"{x:509,y:592,t:1512065702347};\\\", \\\"{x:508,y:593,t:1512065702363};\\\", \\\"{x:507,y:593,t:1512065702395};\\\", \\\"{x:506,y:594,t:1512065702412};\\\", \\\"{x:505,y:594,t:1512065702426};\\\", \\\"{x:501,y:597,t:1512065702442};\\\", \\\"{x:496,y:602,t:1512065702458};\\\", \\\"{x:489,y:616,t:1512065702475};\\\", \\\"{x:487,y:620,t:1512065702492};\\\", \\\"{x:483,y:625,t:1512065702509};\\\", \\\"{x:480,y:631,t:1512065702525};\\\", \\\"{x:476,y:636,t:1512065702542};\\\", \\\"{x:471,y:640,t:1512065702559};\\\", \\\"{x:464,y:650,t:1512065702575};\\\", \\\"{x:458,y:657,t:1512065702592};\\\", \\\"{x:454,y:661,t:1512065702609};\\\", \\\"{x:454,y:662,t:1512065702626};\\\", \\\"{x:453,y:663,t:1512065702642};\\\", \\\"{x:451,y:664,t:1512065702659};\\\", \\\"{x:451,y:665,t:1512065702675};\\\", \\\"{x:449,y:666,t:1512065702692};\\\", \\\"{x:448,y:667,t:1512065702709};\\\", \\\"{x:446,y:668,t:1512065702725};\\\", \\\"{x:445,y:669,t:1512065702742};\\\", \\\"{x:443,y:671,t:1512065702760};\\\", \\\"{x:441,y:673,t:1512065702776};\\\", \\\"{x:439,y:675,t:1512065702793};\\\", \\\"{x:438,y:675,t:1512065702809};\\\", \\\"{x:436,y:677,t:1512065702825};\\\", \\\"{x:435,y:679,t:1512065702842};\\\", \\\"{x:432,y:681,t:1512065702859};\\\", \\\"{x:431,y:681,t:1512065702875};\\\", \\\"{x:429,y:682,t:1512065702892};\\\", \\\"{x:428,y:683,t:1512065702931};\\\", \\\"{x:428,y:684,t:1512065702947};\\\", \\\"{x:427,y:684,t:1512065702959};\\\", \\\"{x:426,y:684,t:1512065702975};\\\", \\\"{x:429,y:684,t:1512065703291};\\\", \\\"{x:434,y:684,t:1512065703299};\\\", \\\"{x:443,y:684,t:1512065703309};\\\", \\\"{x:453,y:684,t:1512065703326};\\\", \\\"{x:470,y:688,t:1512065703342};\\\", \\\"{x:487,y:693,t:1512065703359};\\\", \\\"{x:507,y:698,t:1512065703376};\\\", \\\"{x:529,y:704,t:1512065703392};\\\", \\\"{x:562,y:711,t:1512065703409};\\\", \\\"{x:606,y:717,t:1512065703426};\\\", \\\"{x:649,y:724,t:1512065703443};\\\", \\\"{x:701,y:733,t:1512065703460};\\\", \\\"{x:722,y:737,t:1512065703476};\\\", \\\"{x:746,y:744,t:1512065703492};\\\", \\\"{x:763,y:748,t:1512065703509};\\\", \\\"{x:776,y:752,t:1512065703526};\\\", \\\"{x:790,y:757,t:1512065703542};\\\", \\\"{x:805,y:760,t:1512065703559};\\\", \\\"{x:814,y:765,t:1512065703576};\\\", \\\"{x:817,y:767,t:1512065703593};\\\", \\\"{x:818,y:767,t:1512065703612};\\\" ] }, { \\\"rt\\\": 11938, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 479532, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:821,y:767,t:1512065704915};\\\", \\\"{x:823,y:770,t:1512065704927};\\\", \\\"{x:825,y:779,t:1512065704944};\\\", \\\"{x:825,y:780,t:1512065704960};\\\", \\\"{x:825,y:777,t:1512065705924};\\\", \\\"{x:825,y:773,t:1512065705932};\\\", \\\"{x:825,y:771,t:1512065705945};\\\", \\\"{x:824,y:763,t:1512065705962};\\\", \\\"{x:824,y:760,t:1512065705979};\\\", \\\"{x:824,y:758,t:1512065705995};\\\", \\\"{x:824,y:757,t:1512065706012};\\\", \\\"{x:823,y:755,t:1512065706029};\\\", \\\"{x:822,y:755,t:1512065706045};\\\", \\\"{x:821,y:754,t:1512065706068};\\\", \\\"{x:819,y:753,t:1512065706084};\\\", \\\"{x:818,y:752,t:1512065706108};\\\", \\\"{x:817,y:752,t:1512065706116};\\\", \\\"{x:819,y:754,t:1512065709620};\\\", \\\"{x:824,y:756,t:1512065709631};\\\", \\\"{x:839,y:762,t:1512065709648};\\\", \\\"{x:845,y:766,t:1512065709665};\\\", \\\"{x:847,y:768,t:1512065709681};\\\", \\\"{x:848,y:768,t:1512065709972};\\\", \\\"{x:866,y:769,t:1512065709982};\\\", \\\"{x:979,y:777,t:1512065709999};\\\", \\\"{x:1107,y:781,t:1512065710015};\\\", \\\"{x:1204,y:781,t:1512065710032};\\\", \\\"{x:1241,y:764,t:1512065710048};\\\", \\\"{x:1252,y:755,t:1512065710065};\\\", \\\"{x:1258,y:748,t:1512065710082};\\\", \\\"{x:1261,y:742,t:1512065710098};\\\", \\\"{x:1263,y:739,t:1512065710115};\\\", \\\"{x:1268,y:729,t:1512065710131};\\\", \\\"{x:1270,y:722,t:1512065710147};\\\", \\\"{x:1271,y:719,t:1512065710164};\\\", \\\"{x:1272,y:717,t:1512065710181};\\\", \\\"{x:1274,y:715,t:1512065710198};\\\", \\\"{x:1274,y:714,t:1512065710219};\\\", \\\"{x:1274,y:712,t:1512065710243};\\\", \\\"{x:1271,y:710,t:1512065710251};\\\", \\\"{x:1264,y:709,t:1512065710264};\\\", \\\"{x:1248,y:709,t:1512065710281};\\\", \\\"{x:1221,y:709,t:1512065710298};\\\", \\\"{x:1199,y:709,t:1512065710314};\\\", \\\"{x:1182,y:709,t:1512065710331};\\\", \\\"{x:1178,y:708,t:1512065710349};\\\", \\\"{x:1176,y:707,t:1512065710365};\\\", \\\"{x:1175,y:707,t:1512065710382};\\\", \\\"{x:1174,y:706,t:1512065710399};\\\", \\\"{x:1173,y:706,t:1512065710484};\\\", \\\"{x:1172,y:704,t:1512065710499};\\\", \\\"{x:1171,y:704,t:1512065710514};\\\", \\\"{x:1170,y:703,t:1512065710531};\\\", \\\"{x:1169,y:702,t:1512065710548};\\\", \\\"{x:1167,y:702,t:1512065710595};\\\", \\\"{x:1165,y:702,t:1512065710603};\\\", \\\"{x:1163,y:702,t:1512065710614};\\\", \\\"{x:1156,y:702,t:1512065710632};\\\", \\\"{x:1152,y:702,t:1512065710649};\\\", \\\"{x:1149,y:702,t:1512065710665};\\\", \\\"{x:1147,y:702,t:1512065710681};\\\", \\\"{x:1146,y:702,t:1512065710698};\\\", \\\"{x:1145,y:702,t:1512065710723};\\\", \\\"{x:1142,y:701,t:1512065710739};\\\", \\\"{x:1141,y:700,t:1512065710749};\\\", \\\"{x:1137,y:698,t:1512065710766};\\\", \\\"{x:1136,y:697,t:1512065710782};\\\", \\\"{x:1136,y:696,t:1512065710799};\\\", \\\"{x:1137,y:696,t:1512065710972};\\\", \\\"{x:1138,y:697,t:1512065711052};\\\", \\\"{x:1139,y:697,t:1512065711075};\\\", \\\"{x:1141,y:697,t:1512065711091};\\\", \\\"{x:1141,y:696,t:1512065711099};\\\", \\\"{x:1144,y:696,t:1512065711556};\\\", \\\"{x:1146,y:694,t:1512065711566};\\\", \\\"{x:1148,y:694,t:1512065711583};\\\", \\\"{x:1153,y:693,t:1512065711600};\\\", \\\"{x:1157,y:692,t:1512065711615};\\\", \\\"{x:1161,y:690,t:1512065711633};\\\", \\\"{x:1162,y:690,t:1512065711649};\\\", \\\"{x:1163,y:689,t:1512065711699};\\\", \\\"{x:1161,y:689,t:1512065712068};\\\", \\\"{x:1160,y:689,t:1512065712084};\\\", \\\"{x:1158,y:689,t:1512065712100};\\\", \\\"{x:1157,y:688,t:1512065712492};\\\", \\\"{x:1152,y:685,t:1512065712499};\\\", \\\"{x:1118,y:665,t:1512065712517};\\\", \\\"{x:1042,y:625,t:1512065712534};\\\", \\\"{x:940,y:580,t:1512065712550};\\\", \\\"{x:856,y:549,t:1512065712567};\\\", \\\"{x:810,y:534,t:1512065712584};\\\", \\\"{x:769,y:524,t:1512065712600};\\\", \\\"{x:711,y:507,t:1512065712616};\\\", \\\"{x:669,y:496,t:1512065712634};\\\", \\\"{x:652,y:491,t:1512065712649};\\\", \\\"{x:639,y:489,t:1512065712666};\\\", \\\"{x:617,y:486,t:1512065712683};\\\", \\\"{x:608,y:486,t:1512065712700};\\\", \\\"{x:604,y:486,t:1512065712716};\\\", \\\"{x:601,y:486,t:1512065712733};\\\", \\\"{x:595,y:488,t:1512065712750};\\\", \\\"{x:583,y:493,t:1512065712767};\\\", \\\"{x:565,y:503,t:1512065712784};\\\", \\\"{x:550,y:513,t:1512065712800};\\\", \\\"{x:536,y:525,t:1512065712817};\\\", \\\"{x:532,y:530,t:1512065712834};\\\", \\\"{x:532,y:531,t:1512065712850};\\\", \\\"{x:532,y:532,t:1512065712867};\\\", \\\"{x:530,y:533,t:1512065712883};\\\", \\\"{x:529,y:535,t:1512065712901};\\\", \\\"{x:527,y:537,t:1512065712923};\\\", \\\"{x:526,y:539,t:1512065713091};\\\", \\\"{x:521,y:540,t:1512065713100};\\\", \\\"{x:513,y:541,t:1512065713117};\\\", \\\"{x:501,y:543,t:1512065713133};\\\", \\\"{x:489,y:546,t:1512065713151};\\\", \\\"{x:475,y:551,t:1512065713167};\\\", \\\"{x:464,y:553,t:1512065713184};\\\", \\\"{x:446,y:558,t:1512065713201};\\\", \\\"{x:423,y:563,t:1512065713217};\\\", \\\"{x:407,y:566,t:1512065713234};\\\", \\\"{x:395,y:567,t:1512065713250};\\\", \\\"{x:390,y:568,t:1512065713266};\\\", \\\"{x:387,y:568,t:1512065713282};\\\", \\\"{x:383,y:568,t:1512065713298};\\\", \\\"{x:380,y:568,t:1512065713315};\\\", \\\"{x:373,y:568,t:1512065713332};\\\", \\\"{x:363,y:568,t:1512065713348};\\\", \\\"{x:349,y:568,t:1512065713365};\\\", \\\"{x:339,y:568,t:1512065713382};\\\", \\\"{x:335,y:568,t:1512065713398};\\\", \\\"{x:332,y:569,t:1512065713415};\\\", \\\"{x:331,y:569,t:1512065713435};\\\", \\\"{x:330,y:569,t:1512065713448};\\\", \\\"{x:329,y:569,t:1512065713465};\\\", \\\"{x:327,y:569,t:1512065713482};\\\", \\\"{x:324,y:569,t:1512065713499};\\\", \\\"{x:322,y:569,t:1512065713515};\\\", \\\"{x:320,y:569,t:1512065713532};\\\", \\\"{x:319,y:569,t:1512065713549};\\\", \\\"{x:318,y:569,t:1512065713566};\\\", \\\"{x:317,y:570,t:1512065713582};\\\", \\\"{x:316,y:570,t:1512065713603};\\\", \\\"{x:314,y:570,t:1512065713627};\\\", \\\"{x:313,y:570,t:1512065713643};\\\", \\\"{x:311,y:570,t:1512065713659};\\\", \\\"{x:310,y:570,t:1512065713667};\\\", \\\"{x:308,y:570,t:1512065713683};\\\", \\\"{x:307,y:569,t:1512065713700};\\\", \\\"{x:306,y:569,t:1512065713715};\\\", \\\"{x:305,y:569,t:1512065713739};\\\", \\\"{x:304,y:568,t:1512065713750};\\\", \\\"{x:302,y:567,t:1512065713766};\\\", \\\"{x:297,y:567,t:1512065713783};\\\", \\\"{x:294,y:566,t:1512065713800};\\\", \\\"{x:292,y:566,t:1512065713818};\\\", \\\"{x:291,y:566,t:1512065713834};\\\", \\\"{x:290,y:566,t:1512065713859};\\\", \\\"{x:288,y:566,t:1512065713875};\\\", \\\"{x:287,y:566,t:1512065713883};\\\", \\\"{x:284,y:566,t:1512065713901};\\\", \\\"{x:284,y:567,t:1512065713917};\\\", \\\"{x:285,y:567,t:1512065713979};\\\", \\\"{x:289,y:567,t:1512065713987};\\\", \\\"{x:292,y:567,t:1512065714001};\\\", \\\"{x:306,y:567,t:1512065714017};\\\", \\\"{x:325,y:567,t:1512065714034};\\\", \\\"{x:330,y:567,t:1512065714050};\\\", \\\"{x:336,y:567,t:1512065714067};\\\", \\\"{x:345,y:567,t:1512065714084};\\\", \\\"{x:346,y:567,t:1512065714101};\\\", \\\"{x:350,y:567,t:1512065714117};\\\", \\\"{x:351,y:567,t:1512065714134};\\\", \\\"{x:353,y:565,t:1512065714151};\\\", \\\"{x:356,y:564,t:1512065714167};\\\", \\\"{x:357,y:563,t:1512065714186};\\\", \\\"{x:358,y:563,t:1512065714267};\\\", \\\"{x:359,y:562,t:1512065714274};\\\", \\\"{x:360,y:562,t:1512065714284};\\\", \\\"{x:363,y:560,t:1512065714301};\\\", \\\"{x:366,y:560,t:1512065714318};\\\", \\\"{x:369,y:560,t:1512065714334};\\\", \\\"{x:371,y:559,t:1512065714351};\\\", \\\"{x:377,y:559,t:1512065714368};\\\", \\\"{x:391,y:559,t:1512065714384};\\\", \\\"{x:408,y:559,t:1512065714402};\\\", \\\"{x:414,y:563,t:1512065714419};\\\", \\\"{x:415,y:564,t:1512065714434};\\\", \\\"{x:416,y:564,t:1512065714451};\\\", \\\"{x:416,y:565,t:1512065714707};\\\", \\\"{x:416,y:563,t:1512065714787};\\\", \\\"{x:414,y:563,t:1512065714811};\\\", \\\"{x:414,y:562,t:1512065714819};\\\", \\\"{x:413,y:562,t:1512065714843};\\\", \\\"{x:411,y:561,t:1512065714859};\\\", \\\"{x:411,y:560,t:1512065714891};\\\", \\\"{x:409,y:560,t:1512065714902};\\\", \\\"{x:408,y:558,t:1512065714918};\\\", \\\"{x:405,y:557,t:1512065714935};\\\", \\\"{x:403,y:556,t:1512065714951};\\\", \\\"{x:402,y:555,t:1512065714968};\\\", \\\"{x:401,y:555,t:1512065714986};\\\", \\\"{x:401,y:554,t:1512065715001};\\\", \\\"{x:400,y:554,t:1512065715018};\\\", \\\"{x:399,y:554,t:1512065715252};\\\", \\\"{x:398,y:554,t:1512065715282};\\\", \\\"{x:397,y:554,t:1512065715290};\\\", \\\"{x:396,y:554,t:1512065715322};\\\", \\\"{x:395,y:554,t:1512065715371};\\\", \\\"{x:394,y:554,t:1512065715427};\\\", \\\"{x:393,y:554,t:1512065715435};\\\", \\\"{x:393,y:555,t:1512065715452};\\\", \\\"{x:393,y:556,t:1512065715468};\\\", \\\"{x:392,y:558,t:1512065715485};\\\", \\\"{x:392,y:559,t:1512065715547};\\\", \\\"{x:394,y:561,t:1512065715555};\\\", \\\"{x:395,y:561,t:1512065715568};\\\", \\\"{x:397,y:562,t:1512065715585};\\\", \\\"{x:397,y:563,t:1512065715635};\\\", \\\"{x:397,y:564,t:1512065715652};\\\", \\\"{x:399,y:568,t:1512065715670};\\\", \\\"{x:401,y:576,t:1512065715686};\\\", \\\"{x:404,y:595,t:1512065715703};\\\", \\\"{x:405,y:618,t:1512065715720};\\\", \\\"{x:406,y:631,t:1512065715735};\\\", \\\"{x:407,y:652,t:1512065715753};\\\", \\\"{x:409,y:663,t:1512065715769};\\\", \\\"{x:409,y:669,t:1512065715785};\\\", \\\"{x:409,y:673,t:1512065715802};\\\", \\\"{x:409,y:675,t:1512065715820};\\\", \\\"{x:409,y:677,t:1512065716003};\\\", \\\"{x:410,y:680,t:1512065716019};\\\", \\\"{x:410,y:681,t:1512065716059};\\\", \\\"{x:410,y:682,t:1512065716075};\\\", \\\"{x:410,y:683,t:1512065716131};\\\", \\\"{x:410,y:684,t:1512065716139};\\\", \\\"{x:410,y:685,t:1512065716475};\\\", \\\"{x:412,y:688,t:1512065716486};\\\", \\\"{x:419,y:697,t:1512065716503};\\\", \\\"{x:433,y:709,t:1512065716519};\\\", \\\"{x:454,y:722,t:1512065716536};\\\", \\\"{x:470,y:731,t:1512065716553};\\\", \\\"{x:492,y:741,t:1512065716569};\\\", \\\"{x:535,y:761,t:1512065716586};\\\", \\\"{x:567,y:772,t:1512065716602};\\\", \\\"{x:600,y:783,t:1512065716619};\\\", \\\"{x:624,y:789,t:1512065716636};\\\", \\\"{x:642,y:794,t:1512065716653};\\\", \\\"{x:650,y:795,t:1512065716669};\\\", \\\"{x:652,y:795,t:1512065716686};\\\", \\\"{x:656,y:795,t:1512065716703};\\\", \\\"{x:658,y:796,t:1512065716719};\\\", \\\"{x:665,y:798,t:1512065716736};\\\", \\\"{x:671,y:798,t:1512065716753};\\\", \\\"{x:678,y:798,t:1512065716769};\\\", \\\"{x:685,y:798,t:1512065716787};\\\", \\\"{x:686,y:798,t:1512065716803};\\\", \\\"{x:687,y:798,t:1512065716819};\\\", \\\"{x:688,y:798,t:1512065716899};\\\", \\\"{x:689,y:797,t:1512065716907};\\\", \\\"{x:689,y:796,t:1512065716923};\\\", \\\"{x:689,y:795,t:1512065716942};\\\", \\\"{x:689,y:794,t:1512065716966};\\\" ] }, { \\\"rt\\\": 23112, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 503925, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -B -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:689,y:793,t:1512065726511};\\\", \\\"{x:700,y:779,t:1512065726518};\\\", \\\"{x:726,y:759,t:1512065726530};\\\", \\\"{x:798,y:711,t:1512065726548};\\\", \\\"{x:853,y:688,t:1512065726565};\\\", \\\"{x:878,y:676,t:1512065726581};\\\", \\\"{x:888,y:667,t:1512065726598};\\\", \\\"{x:900,y:653,t:1512065726615};\\\", \\\"{x:925,y:644,t:1512065726631};\\\", \\\"{x:950,y:641,t:1512065726648};\\\", \\\"{x:986,y:641,t:1512065726665};\\\", \\\"{x:1042,y:641,t:1512065726681};\\\", \\\"{x:1115,y:637,t:1512065726698};\\\", \\\"{x:1171,y:637,t:1512065726715};\\\", \\\"{x:1209,y:637,t:1512065726731};\\\", \\\"{x:1229,y:637,t:1512065726748};\\\", \\\"{x:1236,y:637,t:1512065726765};\\\", \\\"{x:1242,y:639,t:1512065726781};\\\", \\\"{x:1256,y:645,t:1512065726798};\\\", \\\"{x:1321,y:661,t:1512065726814};\\\", \\\"{x:1411,y:674,t:1512065726831};\\\", \\\"{x:1473,y:679,t:1512065726848};\\\", \\\"{x:1493,y:679,t:1512065726865};\\\", \\\"{x:1497,y:679,t:1512065726881};\\\", \\\"{x:1498,y:679,t:1512065726898};\\\", \\\"{x:1496,y:679,t:1512065726951};\\\", \\\"{x:1496,y:680,t:1512065726999};\\\", \\\"{x:1497,y:681,t:1512065727023};\\\", \\\"{x:1497,y:682,t:1512065727062};\\\", \\\"{x:1492,y:687,t:1512065727071};\\\", \\\"{x:1482,y:691,t:1512065727082};\\\", \\\"{x:1470,y:697,t:1512065727098};\\\", \\\"{x:1464,y:701,t:1512065727115};\\\", \\\"{x:1461,y:703,t:1512065727132};\\\", \\\"{x:1460,y:704,t:1512065727150};\\\", \\\"{x:1457,y:705,t:1512065727174};\\\", \\\"{x:1455,y:706,t:1512065727182};\\\", \\\"{x:1453,y:708,t:1512065727198};\\\", \\\"{x:1445,y:712,t:1512065727214};\\\", \\\"{x:1441,y:713,t:1512065727232};\\\", \\\"{x:1440,y:714,t:1512065727248};\\\", \\\"{x:1439,y:714,t:1512065727319};\\\", \\\"{x:1438,y:714,t:1512065727332};\\\", \\\"{x:1437,y:714,t:1512065727348};\\\", \\\"{x:1436,y:714,t:1512065727365};\\\", \\\"{x:1435,y:714,t:1512065727381};\\\", \\\"{x:1434,y:714,t:1512065727398};\\\", \\\"{x:1431,y:712,t:1512065727414};\\\", \\\"{x:1425,y:702,t:1512065727431};\\\", \\\"{x:1421,y:699,t:1512065727449};\\\", \\\"{x:1419,y:697,t:1512065727464};\\\", \\\"{x:1417,y:695,t:1512065727481};\\\", \\\"{x:1416,y:694,t:1512065727499};\\\", \\\"{x:1413,y:691,t:1512065727514};\\\", \\\"{x:1411,y:689,t:1512065727531};\\\", \\\"{x:1410,y:688,t:1512065727548};\\\", \\\"{x:1410,y:685,t:1512065727564};\\\", \\\"{x:1409,y:684,t:1512065727581};\\\", \\\"{x:1409,y:683,t:1512065727599};\\\", \\\"{x:1409,y:682,t:1512065727671};\\\", \\\"{x:1409,y:683,t:1512065727702};\\\", \\\"{x:1409,y:686,t:1512065727715};\\\", \\\"{x:1408,y:690,t:1512065727732};\\\", \\\"{x:1407,y:696,t:1512065727749};\\\", \\\"{x:1406,y:702,t:1512065727765};\\\", \\\"{x:1405,y:706,t:1512065727782};\\\", \\\"{x:1404,y:707,t:1512065727799};\\\", \\\"{x:1404,y:708,t:1512065727815};\\\", \\\"{x:1404,y:710,t:1512065727832};\\\", \\\"{x:1402,y:716,t:1512065727849};\\\", \\\"{x:1400,y:720,t:1512065727866};\\\", \\\"{x:1398,y:728,t:1512065727882};\\\", \\\"{x:1395,y:733,t:1512065727899};\\\", \\\"{x:1393,y:744,t:1512065727916};\\\", \\\"{x:1387,y:756,t:1512065727932};\\\", \\\"{x:1382,y:767,t:1512065727949};\\\", \\\"{x:1375,y:783,t:1512065727966};\\\", \\\"{x:1370,y:794,t:1512065727982};\\\", \\\"{x:1363,y:809,t:1512065727998};\\\", \\\"{x:1358,y:819,t:1512065728015};\\\", \\\"{x:1355,y:825,t:1512065728031};\\\", \\\"{x:1352,y:833,t:1512065728049};\\\", \\\"{x:1348,y:841,t:1512065728065};\\\", \\\"{x:1346,y:846,t:1512065728082};\\\", \\\"{x:1343,y:853,t:1512065728099};\\\", \\\"{x:1341,y:856,t:1512065728116};\\\", \\\"{x:1340,y:858,t:1512065728132};\\\", \\\"{x:1338,y:862,t:1512065728149};\\\", \\\"{x:1335,y:866,t:1512065728166};\\\", \\\"{x:1334,y:871,t:1512065728182};\\\", \\\"{x:1331,y:877,t:1512065728199};\\\", \\\"{x:1329,y:881,t:1512065728216};\\\", \\\"{x:1328,y:884,t:1512065728232};\\\", \\\"{x:1327,y:886,t:1512065728249};\\\", \\\"{x:1326,y:887,t:1512065728266};\\\", \\\"{x:1324,y:891,t:1512065728282};\\\", \\\"{x:1323,y:893,t:1512065728299};\\\", \\\"{x:1321,y:899,t:1512065728316};\\\", \\\"{x:1319,y:904,t:1512065728333};\\\", \\\"{x:1316,y:911,t:1512065728349};\\\", \\\"{x:1315,y:913,t:1512065728366};\\\", \\\"{x:1311,y:919,t:1512065728382};\\\", \\\"{x:1308,y:924,t:1512065728399};\\\", \\\"{x:1306,y:931,t:1512065728416};\\\", \\\"{x:1304,y:934,t:1512065728433};\\\", \\\"{x:1303,y:938,t:1512065728449};\\\", \\\"{x:1301,y:939,t:1512065728466};\\\", \\\"{x:1300,y:943,t:1512065728483};\\\", \\\"{x:1299,y:944,t:1512065728499};\\\", \\\"{x:1299,y:945,t:1512065728516};\\\", \\\"{x:1299,y:946,t:1512065728533};\\\", \\\"{x:1298,y:947,t:1512065728549};\\\", \\\"{x:1297,y:949,t:1512065728565};\\\", \\\"{x:1296,y:950,t:1512065728581};\\\", \\\"{x:1296,y:952,t:1512065728598};\\\", \\\"{x:1295,y:952,t:1512065728615};\\\", \\\"{x:1294,y:953,t:1512065728653};\\\", \\\"{x:1294,y:954,t:1512065728669};\\\", \\\"{x:1294,y:955,t:1512065728685};\\\", \\\"{x:1293,y:955,t:1512065728734};\\\", \\\"{x:1293,y:956,t:1512065728750};\\\", \\\"{x:1292,y:957,t:1512065728774};\\\", \\\"{x:1291,y:958,t:1512065728782};\\\", \\\"{x:1291,y:959,t:1512065728871};\\\", \\\"{x:1290,y:959,t:1512065728883};\\\", \\\"{x:1289,y:960,t:1512065728991};\\\", \\\"{x:1288,y:960,t:1512065729439};\\\", \\\"{x:1286,y:958,t:1512065736728};\\\", \\\"{x:1285,y:957,t:1512065736739};\\\", \\\"{x:1278,y:954,t:1512065736756};\\\", \\\"{x:1268,y:940,t:1512065736773};\\\", \\\"{x:1254,y:920,t:1512065736789};\\\", \\\"{x:1244,y:906,t:1512065736806};\\\", \\\"{x:1240,y:897,t:1512065736823};\\\", \\\"{x:1238,y:891,t:1512065736839};\\\", \\\"{x:1235,y:885,t:1512065736856};\\\", \\\"{x:1232,y:878,t:1512065736873};\\\", \\\"{x:1230,y:875,t:1512065736889};\\\", \\\"{x:1230,y:870,t:1512065736906};\\\", \\\"{x:1228,y:862,t:1512065736923};\\\", \\\"{x:1227,y:852,t:1512065736939};\\\", \\\"{x:1225,y:842,t:1512065736956};\\\", \\\"{x:1221,y:836,t:1512065736973};\\\", \\\"{x:1212,y:824,t:1512065736989};\\\", \\\"{x:1203,y:813,t:1512065737006};\\\", \\\"{x:1190,y:798,t:1512065737023};\\\", \\\"{x:1183,y:790,t:1512065737039};\\\", \\\"{x:1172,y:776,t:1512065737056};\\\", \\\"{x:1163,y:762,t:1512065737073};\\\", \\\"{x:1152,y:747,t:1512065737090};\\\", \\\"{x:1147,y:740,t:1512065737106};\\\", \\\"{x:1142,y:730,t:1512065737123};\\\", \\\"{x:1139,y:723,t:1512065737140};\\\", \\\"{x:1138,y:715,t:1512065737156};\\\", \\\"{x:1138,y:707,t:1512065737173};\\\", \\\"{x:1138,y:698,t:1512065737190};\\\", \\\"{x:1139,y:694,t:1512065737206};\\\", \\\"{x:1142,y:685,t:1512065737223};\\\", \\\"{x:1144,y:681,t:1512065737239};\\\", \\\"{x:1147,y:678,t:1512065737256};\\\", \\\"{x:1152,y:674,t:1512065737273};\\\", \\\"{x:1154,y:672,t:1512065737290};\\\", \\\"{x:1154,y:671,t:1512065737311};\\\", \\\"{x:1156,y:670,t:1512065737323};\\\", \\\"{x:1156,y:669,t:1512065737340};\\\", \\\"{x:1156,y:668,t:1512065737363};\\\", \\\"{x:1156,y:667,t:1512065737374};\\\", \\\"{x:1156,y:666,t:1512065737389};\\\", \\\"{x:1155,y:663,t:1512065737405};\\\", \\\"{x:1143,y:653,t:1512065737422};\\\", \\\"{x:1133,y:645,t:1512065737439};\\\", \\\"{x:1123,y:636,t:1512065737455};\\\", \\\"{x:1116,y:628,t:1512065737472};\\\", \\\"{x:1111,y:622,t:1512065737489};\\\", \\\"{x:1109,y:618,t:1512065737506};\\\", \\\"{x:1105,y:614,t:1512065737522};\\\", \\\"{x:1104,y:611,t:1512065737539};\\\", \\\"{x:1103,y:609,t:1512065737556};\\\", \\\"{x:1102,y:606,t:1512065737572};\\\", \\\"{x:1101,y:604,t:1512065737589};\\\", \\\"{x:1101,y:599,t:1512065737606};\\\", \\\"{x:1101,y:595,t:1512065737622};\\\", \\\"{x:1101,y:589,t:1512065737639};\\\", \\\"{x:1099,y:581,t:1512065737656};\\\", \\\"{x:1096,y:575,t:1512065737672};\\\", \\\"{x:1091,y:566,t:1512065737690};\\\", \\\"{x:1080,y:562,t:1512065737707};\\\", \\\"{x:1061,y:555,t:1512065737722};\\\", \\\"{x:1038,y:551,t:1512065737739};\\\", \\\"{x:1006,y:551,t:1512065737756};\\\", \\\"{x:967,y:551,t:1512065737772};\\\", \\\"{x:909,y:551,t:1512065737789};\\\", \\\"{x:820,y:565,t:1512065737806};\\\", \\\"{x:766,y:579,t:1512065737823};\\\", \\\"{x:714,y:590,t:1512065737839};\\\", \\\"{x:694,y:592,t:1512065737856};\\\", \\\"{x:685,y:592,t:1512065737872};\\\", \\\"{x:679,y:589,t:1512065737890};\\\", \\\"{x:677,y:588,t:1512065737906};\\\", \\\"{x:675,y:588,t:1512065737922};\\\", \\\"{x:674,y:587,t:1512065737943};\\\", \\\"{x:672,y:587,t:1512065737956};\\\", \\\"{x:657,y:587,t:1512065737974};\\\", \\\"{x:639,y:584,t:1512065737989};\\\", \\\"{x:622,y:578,t:1512065738007};\\\", \\\"{x:608,y:573,t:1512065738023};\\\", \\\"{x:588,y:569,t:1512065738040};\\\", \\\"{x:567,y:564,t:1512065738057};\\\", \\\"{x:545,y:561,t:1512065738074};\\\", \\\"{x:536,y:557,t:1512065738089};\\\", \\\"{x:530,y:554,t:1512065738107};\\\", \\\"{x:522,y:550,t:1512065738124};\\\", \\\"{x:518,y:549,t:1512065738139};\\\", \\\"{x:514,y:546,t:1512065738157};\\\", \\\"{x:513,y:546,t:1512065738215};\\\", \\\"{x:513,y:545,t:1512065738231};\\\", \\\"{x:513,y:544,t:1512065738239};\\\", \\\"{x:513,y:543,t:1512065738439};\\\", \\\"{x:512,y:542,t:1512065738455};\\\", \\\"{x:512,y:541,t:1512065738495};\\\", \\\"{x:512,y:540,t:1512065738519};\\\", \\\"{x:512,y:539,t:1512065738567};\\\", \\\"{x:515,y:537,t:1512065738590};\\\", \\\"{x:515,y:536,t:1512065738606};\\\", \\\"{x:515,y:535,t:1512065738625};\\\", \\\"{x:515,y:534,t:1512065738862};\\\", \\\"{x:515,y:534,t:1512065738866};\\\", \\\"{x:515,y:533,t:1512065738878};\\\", \\\"{x:514,y:531,t:1512065738902};\\\", \\\"{x:511,y:531,t:1512065738926};\\\", \\\"{x:505,y:531,t:1512065738942};\\\", \\\"{x:501,y:532,t:1512065738959};\\\", \\\"{x:493,y:533,t:1512065738975};\\\", \\\"{x:485,y:535,t:1512065738992};\\\", \\\"{x:472,y:537,t:1512065739008};\\\", \\\"{x:459,y:540,t:1512065739025};\\\", \\\"{x:449,y:542,t:1512065739042};\\\", \\\"{x:441,y:546,t:1512065739058};\\\", \\\"{x:435,y:548,t:1512065739075};\\\", \\\"{x:431,y:550,t:1512065739092};\\\", \\\"{x:427,y:552,t:1512065739109};\\\", \\\"{x:426,y:552,t:1512065739125};\\\", \\\"{x:423,y:553,t:1512065739142};\\\", \\\"{x:422,y:553,t:1512065739207};\\\", \\\"{x:421,y:552,t:1512065739231};\\\", \\\"{x:421,y:551,t:1512065739255};\\\", \\\"{x:421,y:550,t:1512065739263};\\\", \\\"{x:420,y:549,t:1512065739275};\\\", \\\"{x:415,y:545,t:1512065739293};\\\", \\\"{x:410,y:543,t:1512065739310};\\\", \\\"{x:406,y:541,t:1512065739325};\\\", \\\"{x:403,y:540,t:1512065739343};\\\", \\\"{x:403,y:539,t:1512065739399};\\\", \\\"{x:403,y:538,t:1512065739431};\\\", \\\"{x:402,y:537,t:1512065739442};\\\", \\\"{x:402,y:536,t:1512065739459};\\\", \\\"{x:402,y:535,t:1512065739575};\\\", \\\"{x:402,y:534,t:1512065739583};\\\", \\\"{x:402,y:533,t:1512065739615};\\\", \\\"{x:403,y:533,t:1512065739830};\\\", \\\"{x:404,y:533,t:1512065739846};\\\", \\\"{x:404,y:535,t:1512065739870};\\\", \\\"{x:404,y:537,t:1512065739878};\\\", \\\"{x:404,y:543,t:1512065739892};\\\", \\\"{x:406,y:552,t:1512065739909};\\\", \\\"{x:406,y:562,t:1512065739926};\\\", \\\"{x:406,y:569,t:1512065739943};\\\", \\\"{x:406,y:577,t:1512065739959};\\\", \\\"{x:406,y:594,t:1512065739976};\\\", \\\"{x:406,y:613,t:1512065739993};\\\", \\\"{x:406,y:629,t:1512065740009};\\\", \\\"{x:406,y:638,t:1512065740026};\\\", \\\"{x:405,y:644,t:1512065740043};\\\", \\\"{x:405,y:649,t:1512065740059};\\\", \\\"{x:405,y:652,t:1512065740076};\\\", \\\"{x:405,y:656,t:1512065740093};\\\", \\\"{x:405,y:657,t:1512065740109};\\\", \\\"{x:405,y:659,t:1512065740126};\\\", \\\"{x:405,y:660,t:1512065740150};\\\", \\\"{x:406,y:661,t:1512065740174};\\\", \\\"{x:407,y:663,t:1512065740262};\\\", \\\"{x:407,y:664,t:1512065740294};\\\", \\\"{x:408,y:667,t:1512065740310};\\\", \\\"{x:409,y:668,t:1512065740326};\\\", \\\"{x:410,y:670,t:1512065740343};\\\", \\\"{x:411,y:673,t:1512065740360};\\\", \\\"{x:412,y:675,t:1512065740377};\\\", \\\"{x:413,y:676,t:1512065740393};\\\", \\\"{x:413,y:677,t:1512065740410};\\\", \\\"{x:413,y:679,t:1512065740426};\\\", \\\"{x:413,y:681,t:1512065740442};\\\", \\\"{x:413,y:682,t:1512065740459};\\\", \\\"{x:413,y:683,t:1512065740478};\\\", \\\"{x:413,y:684,t:1512065740492};\\\", \\\"{x:413,y:685,t:1512065740519};\\\", \\\"{x:414,y:685,t:1512065740790};\\\", \\\"{x:415,y:685,t:1512065740798};\\\", \\\"{x:416,y:685,t:1512065740810};\\\", \\\"{x:419,y:684,t:1512065740827};\\\", \\\"{x:422,y:684,t:1512065740843};\\\", \\\"{x:426,y:684,t:1512065740860};\\\", \\\"{x:433,y:684,t:1512065740877};\\\", \\\"{x:439,y:688,t:1512065740893};\\\", \\\"{x:453,y:694,t:1512065740910};\\\", \\\"{x:468,y:696,t:1512065740927};\\\", \\\"{x:486,y:701,t:1512065740943};\\\", \\\"{x:499,y:702,t:1512065740960};\\\", \\\"{x:509,y:705,t:1512065740977};\\\", \\\"{x:517,y:707,t:1512065740994};\\\", \\\"{x:523,y:709,t:1512065741010};\\\", \\\"{x:535,y:712,t:1512065741027};\\\", \\\"{x:553,y:716,t:1512065741044};\\\", \\\"{x:586,y:721,t:1512065741060};\\\", \\\"{x:633,y:727,t:1512065741078};\\\", \\\"{x:692,y:735,t:1512065741094};\\\", \\\"{x:708,y:737,t:1512065741110};\\\", \\\"{x:710,y:737,t:1512065741127};\\\", \\\"{x:709,y:737,t:1512065741191};\\\", \\\"{x:708,y:737,t:1512065741239};\\\" ] }, { \\\"rt\\\": 8035, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 513287, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-03 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:711,y:737,t:1512065745575};\\\", \\\"{x:717,y:737,t:1512065745586};\\\", \\\"{x:725,y:737,t:1512065745597};\\\", \\\"{x:752,y:737,t:1512065745613};\\\", \\\"{x:763,y:737,t:1512065745630};\\\", \\\"{x:776,y:737,t:1512065745647};\\\", \\\"{x:794,y:737,t:1512065745664};\\\", \\\"{x:819,y:737,t:1512065745680};\\\", \\\"{x:849,y:737,t:1512065745697};\\\", \\\"{x:884,y:735,t:1512065745714};\\\", \\\"{x:924,y:728,t:1512065745730};\\\", \\\"{x:950,y:726,t:1512065745747};\\\", \\\"{x:972,y:720,t:1512065745764};\\\", \\\"{x:987,y:719,t:1512065745780};\\\", \\\"{x:997,y:719,t:1512065745797};\\\", \\\"{x:1011,y:719,t:1512065745814};\\\", \\\"{x:1029,y:719,t:1512065745830};\\\", \\\"{x:1048,y:719,t:1512065745847};\\\", \\\"{x:1074,y:725,t:1512065745865};\\\", \\\"{x:1099,y:733,t:1512065745881};\\\", \\\"{x:1121,y:741,t:1512065745898};\\\", \\\"{x:1134,y:750,t:1512065745915};\\\", \\\"{x:1143,y:757,t:1512065745931};\\\", \\\"{x:1147,y:765,t:1512065745948};\\\", \\\"{x:1152,y:775,t:1512065745965};\\\", \\\"{x:1157,y:784,t:1512065745981};\\\", \\\"{x:1160,y:789,t:1512065745998};\\\", \\\"{x:1163,y:797,t:1512065746014};\\\", \\\"{x:1164,y:805,t:1512065746032};\\\", \\\"{x:1165,y:822,t:1512065746048};\\\", \\\"{x:1168,y:844,t:1512065746065};\\\", \\\"{x:1173,y:868,t:1512065746082};\\\", \\\"{x:1176,y:894,t:1512065746098};\\\", \\\"{x:1180,y:917,t:1512065746115};\\\", \\\"{x:1185,y:932,t:1512065746132};\\\", \\\"{x:1189,y:943,t:1512065746148};\\\", \\\"{x:1194,y:957,t:1512065746165};\\\", \\\"{x:1197,y:970,t:1512065746182};\\\", \\\"{x:1199,y:979,t:1512065746198};\\\", \\\"{x:1206,y:991,t:1512065746214};\\\", \\\"{x:1209,y:994,t:1512065746232};\\\", \\\"{x:1212,y:996,t:1512065746248};\\\", \\\"{x:1219,y:999,t:1512065746264};\\\", \\\"{x:1227,y:1000,t:1512065746281};\\\", \\\"{x:1231,y:1000,t:1512065746298};\\\", \\\"{x:1239,y:1000,t:1512065746315};\\\", \\\"{x:1256,y:1000,t:1512065746332};\\\", \\\"{x:1282,y:1000,t:1512065746348};\\\", \\\"{x:1306,y:1000,t:1512065746365};\\\", \\\"{x:1331,y:1000,t:1512065746382};\\\", \\\"{x:1344,y:999,t:1512065746398};\\\", \\\"{x:1360,y:999,t:1512065746415};\\\", \\\"{x:1363,y:999,t:1512065746432};\\\", \\\"{x:1364,y:999,t:1512065746449};\\\", \\\"{x:1365,y:998,t:1512065746478};\\\", \\\"{x:1366,y:998,t:1512065746494};\\\", \\\"{x:1367,y:996,t:1512065746502};\\\", \\\"{x:1368,y:996,t:1512065746515};\\\", \\\"{x:1371,y:991,t:1512065746532};\\\", \\\"{x:1374,y:986,t:1512065746549};\\\", \\\"{x:1378,y:982,t:1512065746565};\\\", \\\"{x:1379,y:981,t:1512065746582};\\\", \\\"{x:1380,y:980,t:1512065746599};\\\", \\\"{x:1380,y:979,t:1512065746622};\\\", \\\"{x:1380,y:978,t:1512065746637};\\\", \\\"{x:1380,y:977,t:1512065746661};\\\", \\\"{x:1380,y:976,t:1512065746702};\\\", \\\"{x:1380,y:974,t:1512065746717};\\\", \\\"{x:1378,y:973,t:1512065746731};\\\", \\\"{x:1376,y:973,t:1512065746757};\\\", \\\"{x:1375,y:972,t:1512065746766};\\\", \\\"{x:1374,y:971,t:1512065746781};\\\", \\\"{x:1368,y:968,t:1512065746797};\\\", \\\"{x:1359,y:962,t:1512065746814};\\\", \\\"{x:1346,y:958,t:1512065746831};\\\", \\\"{x:1333,y:954,t:1512065746848};\\\", \\\"{x:1322,y:950,t:1512065746865};\\\", \\\"{x:1310,y:946,t:1512065746881};\\\", \\\"{x:1297,y:940,t:1512065746899};\\\", \\\"{x:1291,y:936,t:1512065746916};\\\", \\\"{x:1288,y:933,t:1512065746932};\\\", \\\"{x:1285,y:930,t:1512065746949};\\\", \\\"{x:1283,y:925,t:1512065746966};\\\", \\\"{x:1281,y:920,t:1512065746982};\\\", \\\"{x:1277,y:909,t:1512065746998};\\\", \\\"{x:1276,y:900,t:1512065747016};\\\", \\\"{x:1273,y:891,t:1512065747032};\\\", \\\"{x:1273,y:884,t:1512065747049};\\\", \\\"{x:1273,y:873,t:1512065747066};\\\", \\\"{x:1273,y:862,t:1512065747082};\\\", \\\"{x:1273,y:857,t:1512065747099};\\\", \\\"{x:1273,y:847,t:1512065747116};\\\", \\\"{x:1273,y:837,t:1512065747132};\\\", \\\"{x:1273,y:832,t:1512065747149};\\\", \\\"{x:1273,y:829,t:1512065747166};\\\", \\\"{x:1274,y:826,t:1512065747182};\\\", \\\"{x:1274,y:824,t:1512065747199};\\\", \\\"{x:1275,y:823,t:1512065747216};\\\", \\\"{x:1276,y:821,t:1512065747232};\\\", \\\"{x:1277,y:821,t:1512065747295};\\\", \\\"{x:1278,y:819,t:1512065747302};\\\", \\\"{x:1279,y:819,t:1512065747316};\\\", \\\"{x:1282,y:819,t:1512065747333};\\\", \\\"{x:1283,y:819,t:1512065747349};\\\", \\\"{x:1284,y:819,t:1512065747366};\\\", \\\"{x:1286,y:819,t:1512065747382};\\\", \\\"{x:1287,y:819,t:1512065747398};\\\", \\\"{x:1288,y:820,t:1512065747415};\\\", \\\"{x:1289,y:820,t:1512065747454};\\\", \\\"{x:1290,y:820,t:1512065747590};\\\", \\\"{x:1290,y:821,t:1512065747655};\\\", \\\"{x:1291,y:822,t:1512065747742};\\\", \\\"{x:1292,y:823,t:1512065747766};\\\", \\\"{x:1290,y:823,t:1512065747831};\\\", \\\"{x:1285,y:823,t:1512065747838};\\\", \\\"{x:1275,y:823,t:1512065747850};\\\", \\\"{x:1243,y:823,t:1512065747865};\\\", \\\"{x:1154,y:808,t:1512065747883};\\\", \\\"{x:1016,y:769,t:1512065747900};\\\", \\\"{x:902,y:753,t:1512065747916};\\\", \\\"{x:760,y:757,t:1512065747933};\\\", \\\"{x:582,y:744,t:1512065747950};\\\", \\\"{x:478,y:710,t:1512065747966};\\\", \\\"{x:430,y:690,t:1512065747982};\\\", \\\"{x:423,y:686,t:1512065747999};\\\", \\\"{x:422,y:686,t:1512065748021};\\\", \\\"{x:421,y:685,t:1512065748032};\\\", \\\"{x:418,y:682,t:1512065748077};\\\", \\\"{x:415,y:682,t:1512065748085};\\\", \\\"{x:409,y:677,t:1512065748099};\\\", \\\"{x:405,y:675,t:1512065748116};\\\", \\\"{x:402,y:673,t:1512065748132};\\\", \\\"{x:398,y:667,t:1512065748149};\\\", \\\"{x:390,y:655,t:1512065748165};\\\", \\\"{x:387,y:651,t:1512065748182};\\\", \\\"{x:385,y:645,t:1512065748199};\\\", \\\"{x:383,y:635,t:1512065748216};\\\", \\\"{x:382,y:625,t:1512065748232};\\\", \\\"{x:382,y:617,t:1512065748249};\\\", \\\"{x:381,y:610,t:1512065748266};\\\", \\\"{x:381,y:601,t:1512065748282};\\\", \\\"{x:381,y:594,t:1512065748299};\\\", \\\"{x:381,y:586,t:1512065748317};\\\", \\\"{x:383,y:571,t:1512065748333};\\\", \\\"{x:383,y:567,t:1512065748349};\\\", \\\"{x:383,y:562,t:1512065748366};\\\", \\\"{x:384,y:559,t:1512065748382};\\\", \\\"{x:385,y:557,t:1512065748399};\\\", \\\"{x:384,y:557,t:1512065748478};\\\", \\\"{x:383,y:557,t:1512065748494};\\\", \\\"{x:381,y:557,t:1512065748502};\\\", \\\"{x:380,y:557,t:1512065748517};\\\", \\\"{x:377,y:557,t:1512065748533};\\\", \\\"{x:371,y:560,t:1512065748549};\\\", \\\"{x:366,y:562,t:1512065748566};\\\", \\\"{x:353,y:564,t:1512065748584};\\\", \\\"{x:343,y:565,t:1512065748600};\\\", \\\"{x:328,y:567,t:1512065748616};\\\", \\\"{x:317,y:569,t:1512065748634};\\\", \\\"{x:304,y:570,t:1512065748649};\\\", \\\"{x:295,y:571,t:1512065748666};\\\", \\\"{x:287,y:571,t:1512065748683};\\\", \\\"{x:280,y:571,t:1512065748699};\\\", \\\"{x:271,y:573,t:1512065748716};\\\", \\\"{x:260,y:575,t:1512065748733};\\\", \\\"{x:247,y:575,t:1512065748750};\\\", \\\"{x:236,y:575,t:1512065748767};\\\", \\\"{x:230,y:576,t:1512065748784};\\\", \\\"{x:227,y:576,t:1512065748799};\\\", \\\"{x:223,y:577,t:1512065748816};\\\", \\\"{x:221,y:579,t:1512065748833};\\\", \\\"{x:219,y:579,t:1512065748850};\\\", \\\"{x:216,y:581,t:1512065748866};\\\", \\\"{x:213,y:582,t:1512065748883};\\\", \\\"{x:210,y:583,t:1512065748900};\\\", \\\"{x:207,y:585,t:1512065748916};\\\", \\\"{x:206,y:586,t:1512065748933};\\\", \\\"{x:205,y:586,t:1512065748950};\\\", \\\"{x:204,y:586,t:1512065748966};\\\", \\\"{x:200,y:588,t:1512065748983};\\\", \\\"{x:197,y:588,t:1512065749000};\\\", \\\"{x:193,y:589,t:1512065749016};\\\", \\\"{x:190,y:589,t:1512065749034};\\\", \\\"{x:189,y:589,t:1512065749051};\\\", \\\"{x:187,y:589,t:1512065749069};\\\", \\\"{x:186,y:589,t:1512065749085};\\\", \\\"{x:184,y:588,t:1512065749101};\\\", \\\"{x:182,y:588,t:1512065749117};\\\", \\\"{x:181,y:588,t:1512065749141};\\\", \\\"{x:180,y:588,t:1512065749206};\\\", \\\"{x:179,y:588,t:1512065749302};\\\", \\\"{x:180,y:588,t:1512065749477};\\\", \\\"{x:184,y:589,t:1512065749485};\\\", \\\"{x:190,y:591,t:1512065749500};\\\", \\\"{x:198,y:593,t:1512065749517};\\\", \\\"{x:212,y:599,t:1512065749533};\\\", \\\"{x:246,y:614,t:1512065749550};\\\", \\\"{x:265,y:622,t:1512065749567};\\\", \\\"{x:282,y:629,t:1512065749583};\\\", \\\"{x:303,y:639,t:1512065749600};\\\", \\\"{x:322,y:648,t:1512065749617};\\\", \\\"{x:330,y:650,t:1512065749633};\\\", \\\"{x:338,y:654,t:1512065749650};\\\", \\\"{x:344,y:658,t:1512065749667};\\\", \\\"{x:350,y:661,t:1512065749683};\\\", \\\"{x:356,y:665,t:1512065749700};\\\", \\\"{x:369,y:672,t:1512065749717};\\\", \\\"{x:377,y:676,t:1512065749734};\\\", \\\"{x:381,y:679,t:1512065749750};\\\", \\\"{x:383,y:680,t:1512065749767};\\\", \\\"{x:385,y:681,t:1512065749784};\\\", \\\"{x:386,y:682,t:1512065749800};\\\", \\\"{x:388,y:685,t:1512065749817};\\\", \\\"{x:390,y:686,t:1512065749834};\\\", \\\"{x:394,y:689,t:1512065749850};\\\", \\\"{x:397,y:692,t:1512065749867};\\\", \\\"{x:399,y:693,t:1512065749884};\\\", \\\"{x:399,y:694,t:1512065749901};\\\", \\\"{x:399,y:695,t:1512065750189};\\\", \\\"{x:402,y:697,t:1512065750201};\\\", \\\"{x:418,y:708,t:1512065750217};\\\", \\\"{x:442,y:724,t:1512065750234};\\\", \\\"{x:489,y:751,t:1512065750251};\\\", \\\"{x:558,y:782,t:1512065750267};\\\", \\\"{x:630,y:813,t:1512065750284};\\\", \\\"{x:711,y:847,t:1512065750301};\\\", \\\"{x:735,y:860,t:1512065750317};\\\", \\\"{x:786,y:883,t:1512065750334};\\\", \\\"{x:804,y:889,t:1512065750351};\\\", \\\"{x:809,y:893,t:1512065750367};\\\", \\\"{x:812,y:893,t:1512065750384};\\\", \\\"{x:814,y:894,t:1512065750401};\\\", \\\"{x:814,y:895,t:1512065750430};\\\" ] }, { \\\"rt\\\": 11983, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 526583, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"full\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:810,y:890,t:1512065752143};\\\", \\\"{x:807,y:879,t:1512065752153};\\\", \\\"{x:801,y:863,t:1512065752170};\\\", \\\"{x:801,y:843,t:1512065752186};\\\", \\\"{x:801,y:811,t:1512065752203};\\\", \\\"{x:801,y:774,t:1512065752220};\\\", \\\"{x:801,y:747,t:1512065752236};\\\", \\\"{x:800,y:718,t:1512065752253};\\\", \\\"{x:800,y:672,t:1512065752270};\\\", \\\"{x:799,y:644,t:1512065752286};\\\", \\\"{x:794,y:621,t:1512065752303};\\\", \\\"{x:791,y:599,t:1512065752320};\\\", \\\"{x:789,y:581,t:1512065752337};\\\", \\\"{x:785,y:562,t:1512065752353};\\\", \\\"{x:780,y:542,t:1512065752369};\\\", \\\"{x:777,y:528,t:1512065752386};\\\", \\\"{x:771,y:511,t:1512065752402};\\\", \\\"{x:761,y:491,t:1512065752419};\\\", \\\"{x:751,y:476,t:1512065752436};\\\", \\\"{x:734,y:459,t:1512065752452};\\\", \\\"{x:695,y:434,t:1512065752470};\\\", \\\"{x:675,y:427,t:1512065752486};\\\", \\\"{x:646,y:416,t:1512065752502};\\\", \\\"{x:629,y:408,t:1512065752519};\\\", \\\"{x:613,y:402,t:1512065752536};\\\", \\\"{x:601,y:396,t:1512065752552};\\\", \\\"{x:596,y:394,t:1512065752569};\\\", \\\"{x:595,y:394,t:1512065752586};\\\", \\\"{x:592,y:393,t:1512065752602};\\\", \\\"{x:592,y:392,t:1512065752619};\\\", \\\"{x:590,y:392,t:1512065752636};\\\", \\\"{x:589,y:392,t:1512065752652};\\\", \\\"{x:588,y:391,t:1512065752669};\\\", \\\"{x:587,y:391,t:1512065755855};\\\", \\\"{x:590,y:412,t:1512065755863};\\\", \\\"{x:595,y:439,t:1512065755873};\\\", \\\"{x:607,y:474,t:1512065755890};\\\", \\\"{x:612,y:496,t:1512065755906};\\\", \\\"{x:616,y:514,t:1512065755924};\\\", \\\"{x:619,y:534,t:1512065755940};\\\", \\\"{x:623,y:545,t:1512065755957};\\\", \\\"{x:626,y:555,t:1512065755973};\\\", \\\"{x:631,y:573,t:1512065755989};\\\", \\\"{x:644,y:608,t:1512065756005};\\\", \\\"{x:689,y:706,t:1512065756022};\\\", \\\"{x:733,y:761,t:1512065756039};\\\", \\\"{x:772,y:795,t:1512065756055};\\\", \\\"{x:827,y:829,t:1512065756072};\\\", \\\"{x:876,y:859,t:1512065756089};\\\", \\\"{x:917,y:875,t:1512065756105};\\\", \\\"{x:961,y:883,t:1512065756122};\\\", \\\"{x:988,y:886,t:1512065756139};\\\", \\\"{x:1003,y:885,t:1512065756155};\\\", \\\"{x:1014,y:882,t:1512065756172};\\\", \\\"{x:1019,y:880,t:1512065756189};\\\", \\\"{x:1032,y:876,t:1512065756205};\\\", \\\"{x:1080,y:875,t:1512065756222};\\\", \\\"{x:1096,y:875,t:1512065756239};\\\", \\\"{x:1101,y:875,t:1512065756255};\\\", \\\"{x:1104,y:874,t:1512065756273};\\\", \\\"{x:1106,y:873,t:1512065756290};\\\", \\\"{x:1106,y:872,t:1512065756306};\\\", \\\"{x:1108,y:872,t:1512065756335};\\\", \\\"{x:1111,y:872,t:1512065756351};\\\", \\\"{x:1118,y:872,t:1512065756360};\\\", \\\"{x:1132,y:872,t:1512065756373};\\\", \\\"{x:1176,y:878,t:1512065756390};\\\", \\\"{x:1232,y:886,t:1512065756406};\\\", \\\"{x:1264,y:886,t:1512065756423};\\\", \\\"{x:1266,y:886,t:1512065756440};\\\", \\\"{x:1267,y:886,t:1512065756471};\\\", \\\"{x:1269,y:886,t:1512065756487};\\\", \\\"{x:1272,y:888,t:1512065756495};\\\", \\\"{x:1272,y:889,t:1512065756506};\\\", \\\"{x:1273,y:891,t:1512065756523};\\\", \\\"{x:1274,y:891,t:1512065756543};\\\", \\\"{x:1275,y:893,t:1512065756591};\\\", \\\"{x:1278,y:900,t:1512065756607};\\\", \\\"{x:1281,y:908,t:1512065756623};\\\", \\\"{x:1286,y:915,t:1512065756640};\\\", \\\"{x:1288,y:918,t:1512065756657};\\\", \\\"{x:1288,y:919,t:1512065756673};\\\", \\\"{x:1289,y:919,t:1512065756735};\\\", \\\"{x:1290,y:915,t:1512065756743};\\\", \\\"{x:1290,y:908,t:1512065756757};\\\", \\\"{x:1290,y:888,t:1512065756773};\\\", \\\"{x:1290,y:871,t:1512065756790};\\\", \\\"{x:1290,y:847,t:1512065756807};\\\", \\\"{x:1290,y:838,t:1512065756823};\\\", \\\"{x:1290,y:832,t:1512065756842};\\\", \\\"{x:1290,y:824,t:1512065756856};\\\", \\\"{x:1290,y:820,t:1512065756872};\\\", \\\"{x:1290,y:812,t:1512065756889};\\\", \\\"{x:1290,y:803,t:1512065756906};\\\", \\\"{x:1290,y:801,t:1512065756922};\\\", \\\"{x:1290,y:800,t:1512065756939};\\\", \\\"{x:1290,y:799,t:1512065756956};\\\", \\\"{x:1290,y:798,t:1512065756972};\\\", \\\"{x:1290,y:799,t:1512065757063};\\\", \\\"{x:1290,y:803,t:1512065757073};\\\", \\\"{x:1290,y:811,t:1512065757090};\\\", \\\"{x:1291,y:818,t:1512065757106};\\\", \\\"{x:1291,y:823,t:1512065757123};\\\", \\\"{x:1291,y:825,t:1512065757140};\\\", \\\"{x:1291,y:827,t:1512065757156};\\\", \\\"{x:1291,y:829,t:1512065757173};\\\", \\\"{x:1280,y:830,t:1512065759704};\\\", \\\"{x:1252,y:826,t:1512065759711};\\\", \\\"{x:1211,y:815,t:1512065759724};\\\", \\\"{x:1122,y:790,t:1512065759741};\\\", \\\"{x:1018,y:766,t:1512065759757};\\\", \\\"{x:869,y:742,t:1512065759774};\\\", \\\"{x:794,y:733,t:1512065759791};\\\", \\\"{x:746,y:726,t:1512065759807};\\\", \\\"{x:720,y:722,t:1512065759824};\\\", \\\"{x:703,y:719,t:1512065759841};\\\", \\\"{x:685,y:718,t:1512065759857};\\\", \\\"{x:659,y:714,t:1512065759874};\\\", \\\"{x:620,y:711,t:1512065759891};\\\", \\\"{x:588,y:706,t:1512065759907};\\\", \\\"{x:558,y:706,t:1512065759924};\\\", \\\"{x:536,y:706,t:1512065759942};\\\", \\\"{x:516,y:706,t:1512065759958};\\\", \\\"{x:498,y:706,t:1512065759974};\\\", \\\"{x:490,y:705,t:1512065759991};\\\", \\\"{x:478,y:700,t:1512065760007};\\\", \\\"{x:463,y:696,t:1512065760024};\\\", \\\"{x:435,y:686,t:1512065760042};\\\", \\\"{x:413,y:678,t:1512065760058};\\\", \\\"{x:395,y:672,t:1512065760075};\\\", \\\"{x:374,y:664,t:1512065760091};\\\", \\\"{x:353,y:658,t:1512065760108};\\\", \\\"{x:337,y:650,t:1512065760125};\\\", \\\"{x:317,y:641,t:1512065760142};\\\", \\\"{x:283,y:624,t:1512065760158};\\\", \\\"{x:261,y:618,t:1512065760174};\\\", \\\"{x:249,y:614,t:1512065760192};\\\", \\\"{x:244,y:612,t:1512065760208};\\\", \\\"{x:239,y:610,t:1512065760225};\\\", \\\"{x:232,y:608,t:1512065760241};\\\", \\\"{x:229,y:606,t:1512065760258};\\\", \\\"{x:228,y:606,t:1512065760327};\\\", \\\"{x:228,y:605,t:1512065760341};\\\", \\\"{x:227,y:605,t:1512065760359};\\\", \\\"{x:227,y:604,t:1512065760415};\\\", \\\"{x:226,y:603,t:1512065760425};\\\", \\\"{x:225,y:603,t:1512065760442};\\\", \\\"{x:222,y:601,t:1512065760458};\\\", \\\"{x:217,y:600,t:1512065760474};\\\", \\\"{x:213,y:598,t:1512065760491};\\\", \\\"{x:210,y:598,t:1512065760508};\\\", \\\"{x:209,y:598,t:1512065760524};\\\", \\\"{x:207,y:598,t:1512065760541};\\\", \\\"{x:202,y:598,t:1512065760558};\\\", \\\"{x:197,y:596,t:1512065760575};\\\", \\\"{x:189,y:594,t:1512065760591};\\\", \\\"{x:184,y:594,t:1512065760608};\\\", \\\"{x:182,y:594,t:1512065760624};\\\", \\\"{x:181,y:594,t:1512065760642};\\\", \\\"{x:180,y:594,t:1512065760670};\\\", \\\"{x:179,y:594,t:1512065760678};\\\", \\\"{x:178,y:594,t:1512065760691};\\\", \\\"{x:177,y:594,t:1512065760711};\\\", \\\"{x:176,y:594,t:1512065760742};\\\", \\\"{x:175,y:594,t:1512065760759};\\\", \\\"{x:174,y:595,t:1512065760775};\\\", \\\"{x:174,y:596,t:1512065760791};\\\", \\\"{x:174,y:597,t:1512065760814};\\\", \\\"{x:174,y:598,t:1512065760879};\\\", \\\"{x:174,y:599,t:1512065760891};\\\", \\\"{x:175,y:601,t:1512065760908};\\\", \\\"{x:176,y:602,t:1512065760925};\\\", \\\"{x:178,y:602,t:1512065760942};\\\", \\\"{x:179,y:602,t:1512065760958};\\\", \\\"{x:180,y:602,t:1512065760982};\\\", \\\"{x:181,y:602,t:1512065761070};\\\", \\\"{x:182,y:602,t:1512065761326};\\\", \\\"{x:184,y:602,t:1512065761350};\\\", \\\"{x:186,y:602,t:1512065761366};\\\", \\\"{x:187,y:601,t:1512065761377};\\\", \\\"{x:189,y:600,t:1512065761394};\\\", \\\"{x:192,y:600,t:1512065761410};\\\", \\\"{x:192,y:599,t:1512065761427};\\\", \\\"{x:193,y:598,t:1512065761444};\\\", \\\"{x:195,y:597,t:1512065761460};\\\", \\\"{x:197,y:597,t:1512065761511};\\\", \\\"{x:200,y:595,t:1512065761528};\\\", \\\"{x:204,y:595,t:1512065761545};\\\", \\\"{x:214,y:593,t:1512065761560};\\\", \\\"{x:231,y:590,t:1512065761577};\\\", \\\"{x:251,y:588,t:1512065761594};\\\", \\\"{x:267,y:584,t:1512065761610};\\\", \\\"{x:277,y:583,t:1512065761627};\\\", \\\"{x:288,y:580,t:1512065761644};\\\", \\\"{x:295,y:579,t:1512065761660};\\\", \\\"{x:302,y:578,t:1512065761677};\\\", \\\"{x:315,y:578,t:1512065761693};\\\", \\\"{x:325,y:576,t:1512065761711};\\\", \\\"{x:336,y:576,t:1512065761727};\\\", \\\"{x:347,y:576,t:1512065761744};\\\", \\\"{x:354,y:576,t:1512065761761};\\\", \\\"{x:356,y:576,t:1512065761777};\\\", \\\"{x:357,y:576,t:1512065761794};\\\", \\\"{x:359,y:576,t:1512065761811};\\\", \\\"{x:364,y:576,t:1512065761827};\\\", \\\"{x:371,y:576,t:1512065761844};\\\", \\\"{x:382,y:576,t:1512065761861};\\\", \\\"{x:392,y:576,t:1512065761877};\\\", \\\"{x:402,y:576,t:1512065761894};\\\", \\\"{x:406,y:576,t:1512065761911};\\\", \\\"{x:416,y:576,t:1512065761927};\\\", \\\"{x:429,y:577,t:1512065761944};\\\", \\\"{x:448,y:578,t:1512065761961};\\\", \\\"{x:474,y:578,t:1512065761978};\\\", \\\"{x:497,y:581,t:1512065761994};\\\", \\\"{x:514,y:584,t:1512065762011};\\\", \\\"{x:522,y:584,t:1512065762028};\\\", \\\"{x:530,y:584,t:1512065762044};\\\", \\\"{x:538,y:585,t:1512065762062};\\\", \\\"{x:558,y:585,t:1512065762078};\\\", \\\"{x:574,y:587,t:1512065762095};\\\", \\\"{x:583,y:587,t:1512065762111};\\\", \\\"{x:591,y:587,t:1512065762128};\\\", \\\"{x:602,y:587,t:1512065762144};\\\", \\\"{x:606,y:587,t:1512065762161};\\\", \\\"{x:607,y:587,t:1512065762178};\\\", \\\"{x:609,y:587,t:1512065762194};\\\", \\\"{x:610,y:587,t:1512065762211};\\\", \\\"{x:611,y:587,t:1512065762228};\\\", \\\"{x:612,y:587,t:1512065762246};\\\", \\\"{x:613,y:587,t:1512065762262};\\\", \\\"{x:615,y:586,t:1512065762359};\\\", \\\"{x:616,y:585,t:1512065762374};\\\", \\\"{x:619,y:584,t:1512065762382};\\\", \\\"{x:621,y:582,t:1512065762395};\\\", \\\"{x:624,y:580,t:1512065762412};\\\", \\\"{x:625,y:579,t:1512065762430};\\\", \\\"{x:627,y:577,t:1512065762470};\\\", \\\"{x:627,y:576,t:1512065762798};\\\", \\\"{x:626,y:576,t:1512065762811};\\\", \\\"{x:619,y:578,t:1512065762828};\\\", \\\"{x:610,y:583,t:1512065762846};\\\", \\\"{x:594,y:593,t:1512065762862};\\\", \\\"{x:564,y:612,t:1512065762879};\\\", \\\"{x:541,y:626,t:1512065762896};\\\", \\\"{x:525,y:635,t:1512065762912};\\\", \\\"{x:510,y:644,t:1512065762929};\\\", \\\"{x:495,y:655,t:1512065762946};\\\", \\\"{x:481,y:665,t:1512065762962};\\\", \\\"{x:465,y:677,t:1512065762978};\\\", \\\"{x:455,y:684,t:1512065762996};\\\", \\\"{x:444,y:692,t:1512065763013};\\\", \\\"{x:439,y:696,t:1512065763028};\\\", \\\"{x:437,y:698,t:1512065763045};\\\", \\\"{x:436,y:699,t:1512065763062};\\\", \\\"{x:435,y:699,t:1512065763078};\\\", \\\"{x:434,y:699,t:1512065763095};\\\", \\\"{x:433,y:699,t:1512065763134};\\\", \\\"{x:431,y:699,t:1512065763150};\\\", \\\"{x:430,y:700,t:1512065763166};\\\", \\\"{x:429,y:700,t:1512065763178};\\\", \\\"{x:428,y:701,t:1512065763230};\\\", \\\"{x:429,y:701,t:1512065763671};\\\", \\\"{x:431,y:701,t:1512065763679};\\\", \\\"{x:445,y:701,t:1512065763695};\\\", \\\"{x:464,y:701,t:1512065763712};\\\", \\\"{x:484,y:703,t:1512065763729};\\\", \\\"{x:506,y:705,t:1512065763745};\\\", \\\"{x:529,y:710,t:1512065763762};\\\", \\\"{x:551,y:718,t:1512065763779};\\\", \\\"{x:591,y:728,t:1512065763795};\\\", \\\"{x:653,y:747,t:1512065763812};\\\", \\\"{x:707,y:760,t:1512065763829};\\\", \\\"{x:764,y:776,t:1512065763846};\\\", \\\"{x:783,y:782,t:1512065763862};\\\", \\\"{x:789,y:784,t:1512065763879};\\\", \\\"{x:790,y:784,t:1512065763896};\\\", \\\"{x:794,y:781,t:1512065765110};\\\", \\\"{x:801,y:770,t:1512065765118};\\\", \\\"{x:806,y:758,t:1512065765130};\\\", \\\"{x:816,y:741,t:1512065765146};\\\", \\\"{x:825,y:727,t:1512065765163};\\\", \\\"{x:838,y:707,t:1512065765180};\\\", \\\"{x:854,y:685,t:1512065765196};\\\", \\\"{x:867,y:667,t:1512065765214};\\\", \\\"{x:877,y:648,t:1512065765230};\\\", \\\"{x:888,y:629,t:1512065765248};\\\", \\\"{x:897,y:610,t:1512065765263};\\\", \\\"{x:903,y:598,t:1512065765280};\\\", \\\"{x:904,y:592,t:1512065765297};\\\", \\\"{x:908,y:586,t:1512065765313};\\\", \\\"{x:911,y:577,t:1512065765331};\\\", \\\"{x:913,y:573,t:1512065765348};\\\", \\\"{x:913,y:572,t:1512065765363};\\\", \\\"{x:913,y:571,t:1512065765380};\\\", \\\"{x:914,y:569,t:1512065765397};\\\", \\\"{x:915,y:568,t:1512065765413};\\\", \\\"{x:915,y:567,t:1512065765534};\\\", \\\"{x:914,y:569,t:1512065769014};\\\", \\\"{x:912,y:572,t:1512065769022};\\\", \\\"{x:909,y:578,t:1512065769034};\\\", \\\"{x:905,y:586,t:1512065769051};\\\", \\\"{x:902,y:591,t:1512065769066};\\\", \\\"{x:900,y:597,t:1512065769084};\\\", \\\"{x:895,y:610,t:1512065769101};\\\", \\\"{x:884,y:636,t:1512065769117};\\\", \\\"{x:882,y:646,t:1512065769134};\\\", \\\"{x:881,y:647,t:1512065769174};\\\", \\\"{x:881,y:648,t:1512065769198};\\\", \\\"{x:880,y:649,t:1512065769206};\\\", \\\"{x:880,y:650,t:1512065769217};\\\", \\\"{x:879,y:653,t:1512065769234};\\\", \\\"{x:877,y:656,t:1512065769251};\\\", \\\"{x:877,y:658,t:1512065769267};\\\", \\\"{x:876,y:659,t:1512065769283};\\\", \\\"{x:876,y:661,t:1512065773783};\\\", \\\"{x:877,y:663,t:1512065773791};\\\", \\\"{x:880,y:665,t:1512065773804};\\\", \\\"{x:886,y:670,t:1512065773822};\\\", \\\"{x:887,y:670,t:1512065773839};\\\", \\\"{x:888,y:670,t:1512065773855};\\\", \\\"{x:889,y:671,t:1512065773872};\\\", \\\"{x:893,y:674,t:1512065773889};\\\", \\\"{x:896,y:675,t:1512065773904};\\\", \\\"{x:901,y:678,t:1512065773922};\\\", \\\"{x:907,y:680,t:1512065773939};\\\", \\\"{x:912,y:682,t:1512065773955};\\\", \\\"{x:916,y:683,t:1512065773972};\\\", \\\"{x:917,y:685,t:1512065773989};\\\", \\\"{x:918,y:685,t:1512065774007};\\\", \\\"{x:919,y:685,t:1512065774039};\\\", \\\"{x:924,y:685,t:1512065774639};\\\", \\\"{x:938,y:687,t:1512065774655};\\\", \\\"{x:939,y:688,t:1512065774687};\\\", \\\"{x:939,y:689,t:1512065774695};\\\", \\\"{x:939,y:693,t:1512065774705};\\\", \\\"{x:939,y:707,t:1512065774722};\\\", \\\"{x:941,y:715,t:1512065774738};\\\", \\\"{x:941,y:719,t:1512065774755};\\\", \\\"{x:941,y:729,t:1512065774772};\\\", \\\"{x:941,y:741,t:1512065774788};\\\", \\\"{x:941,y:751,t:1512065774805};\\\", \\\"{x:943,y:760,t:1512065774822};\\\", \\\"{x:943,y:762,t:1512065774838};\\\", \\\"{x:943,y:763,t:1512065774871};\\\", \\\"{x:944,y:764,t:1512065774991};\\\", \\\"{x:944,y:766,t:1512065775005};\\\", \\\"{x:947,y:777,t:1512065775023};\\\", \\\"{x:948,y:790,t:1512065775038};\\\", \\\"{x:952,y:803,t:1512065775055};\\\", \\\"{x:953,y:812,t:1512065775072};\\\", \\\"{x:953,y:816,t:1512065775088};\\\", \\\"{x:953,y:821,t:1512065775105};\\\", \\\"{x:953,y:828,t:1512065775122};\\\", \\\"{x:953,y:832,t:1512065775139};\\\", \\\"{x:953,y:834,t:1512065775155};\\\", \\\"{x:953,y:835,t:1512065775175};\\\", \\\"{x:953,y:830,t:1512065775886};\\\", \\\"{x:959,y:810,t:1512065775894};\\\", \\\"{x:960,y:778,t:1512065775906};\\\", \\\"{x:960,y:714,t:1512065775923};\\\", \\\"{x:963,y:665,t:1512065775939};\\\", \\\"{x:965,y:606,t:1512065775956};\\\", \\\"{x:967,y:520,t:1512065775973};\\\", \\\"{x:967,y:436,t:1512065775989};\\\", \\\"{x:953,y:308,t:1512065776006};\\\", \\\"{x:944,y:236,t:1512065776023};\\\", \\\"{x:934,y:174,t:1512065776039};\\\", \\\"{x:930,y:140,t:1512065776056};\\\", \\\"{x:929,y:106,t:1512065776073};\\\", \\\"{x:927,y:77,t:1512065776089};\\\", \\\"{x:922,y:48,t:1512065776106};\\\", \\\"{x:921,y:34,t:1512065776124};\\\", \\\"{x:919,y:22,t:1512065776140};\\\", \\\"{x:917,y:3,t:1512065776157};\\\", \\\"{x:916,y:0,t:1512065776174};\\\", \\\"{x:915,y:0,t:1512065776567};\\\", \\\"{x:914,y:0,t:1512065776574};\\\", \\\"{x:911,y:0,t:1512065776598};\\\", \\\"{x:909,y:11,t:1512065776607};\\\", \\\"{x:905,y:33,t:1512065776623};\\\", \\\"{x:904,y:54,t:1512065776640};\\\", \\\"{x:904,y:72,t:1512065776657};\\\", \\\"{x:904,y:88,t:1512065776673};\\\", \\\"{x:904,y:106,t:1512065776690};\\\", \\\"{x:901,y:122,t:1512065776706};\\\", \\\"{x:900,y:132,t:1512065776723};\\\", \\\"{x:899,y:139,t:1512065776740};\\\", \\\"{x:899,y:143,t:1512065776758};\\\", \\\"{x:899,y:147,t:1512065776773};\\\", \\\"{x:899,y:149,t:1512065776790};\\\", \\\"{x:899,y:150,t:1512065776847};\\\", \\\"{x:899,y:151,t:1512065776862};\\\", \\\"{x:897,y:154,t:1512065776873};\\\", \\\"{x:896,y:156,t:1512065776890};\\\", \\\"{x:895,y:157,t:1512065776907};\\\", \\\"{x:895,y:159,t:1512065776923};\\\", \\\"{x:894,y:162,t:1512065776941};\\\", \\\"{x:892,y:166,t:1512065776960};\\\", \\\"{x:889,y:170,t:1512065776976};\\\", \\\"{x:881,y:185,t:1512065776993};\\\", \\\"{x:872,y:198,t:1512065777009};\\\", \\\"{x:864,y:210,t:1512065777026};\\\", \\\"{x:860,y:217,t:1512065777042};\\\", \\\"{x:857,y:220,t:1512065777059};\\\", \\\"{x:853,y:222,t:1512065777075};\\\", \\\"{x:851,y:224,t:1512065777092};\\\", \\\"{x:849,y:226,t:1512065777110};\\\", \\\"{x:848,y:227,t:1512065777126};\\\", \\\"{x:846,y:228,t:1512065777142};\\\", \\\"{x:845,y:229,t:1512065777160};\\\", \\\"{x:844,y:231,t:1512065777208};\\\", \\\"{x:843,y:231,t:1512065777216};\\\", \\\"{x:843,y:232,t:1512065777226};\\\", \\\"{x:840,y:236,t:1512065777242};\\\", \\\"{x:839,y:238,t:1512065777259};\\\", \\\"{x:839,y:239,t:1512065777336};\\\", \\\"{x:838,y:239,t:1512065777401};\\\", \\\"{x:837,y:239,t:1512065777481};\\\", \\\"{x:836,y:239,t:1512065777537};\\\", \\\"{x:835,y:239,t:1512065777649};\\\", \\\"{x:834,y:239,t:1512065777705};\\\", \\\"{x:833,y:239,t:1512065777753};\\\", \\\"{x:832,y:239,t:1512065777768};\\\", \\\"{x:831,y:239,t:1512065777776};\\\", \\\"{x:830,y:239,t:1512065777808};\\\", \\\"{x:830,y:238,t:1512065777968};\\\", \\\"{x:830,y:239,t:1512065778113};\\\", \\\"{x:830,y:242,t:1512065778126};\\\", \\\"{x:830,y:245,t:1512065778144};\\\", \\\"{x:830,y:250,t:1512065778161};\\\", \\\"{x:831,y:251,t:1512065778176};\\\", \\\"{x:831,y:252,t:1512065778193};\\\", \\\"{x:831,y:253,t:1512065778210};\\\", \\\"{x:831,y:254,t:1512065778232};\\\", \\\"{x:831,y:255,t:1512065778256};\\\", \\\"{x:831,y:256,t:1512065778272};\\\", \\\"{x:831,y:257,t:1512065778353};\\\", \\\"{x:831,y:259,t:1512065778376};\\\", \\\"{x:830,y:260,t:1512065778480};\\\", \\\"{x:830,y:261,t:1512065778585};\\\", \\\"{x:830,y:262,t:1512065778624};\\\", \\\"{x:830,y:263,t:1512065778737};\\\", \\\"{x:829,y:264,t:1512065778761};\\\", \\\"{x:829,y:264,t:1512065779691};\\\", \\\"{x:830,y:264,t:1512065780137};\\\", \\\"{x:831,y:264,t:1512065780152};\\\", \\\"{x:832,y:264,t:1512065780162};\\\", \\\"{x:839,y:261,t:1512065780178};\\\", \\\"{x:842,y:260,t:1512065780195};\\\", \\\"{x:845,y:260,t:1512065780211};\\\", \\\"{x:848,y:260,t:1512065780228};\\\", \\\"{x:850,y:260,t:1512065780248};\\\", \\\"{x:852,y:261,t:1512065780272};\\\", \\\"{x:853,y:261,t:1512065780280};\\\", \\\"{x:853,y:262,t:1512065780296};\\\", \\\"{x:855,y:266,t:1512065780312};\\\", \\\"{x:856,y:267,t:1512065780336};\\\", \\\"{x:856,y:269,t:1512065780345};\\\", \\\"{x:857,y:270,t:1512065780362};\\\", \\\"{x:857,y:274,t:1512065780378};\\\", \\\"{x:859,y:276,t:1512065780395};\\\", \\\"{x:859,y:279,t:1512065780412};\\\", \\\"{x:860,y:281,t:1512065780429};\\\", \\\"{x:861,y:282,t:1512065780445};\\\", \\\"{x:861,y:283,t:1512065780462};\\\", \\\"{x:862,y:284,t:1512065780478};\\\", \\\"{x:862,y:285,t:1512065780513};\\\", \\\"{x:862,y:286,t:1512065780528};\\\", \\\"{x:863,y:286,t:1512065780559};\\\", \\\"{x:863,y:287,t:1512065780584};\\\", \\\"{x:863,y:288,t:1512065780595};\\\", \\\"{x:863,y:289,t:1512065780612};\\\", \\\"{x:863,y:291,t:1512065780628};\\\", \\\"{x:864,y:292,t:1512065780645};\\\", \\\"{x:865,y:296,t:1512065780662};\\\", \\\"{x:866,y:297,t:1512065780678};\\\", \\\"{x:866,y:300,t:1512065780695};\\\", \\\"{x:868,y:307,t:1512065780712};\\\", \\\"{x:869,y:310,t:1512065780728};\\\", \\\"{x:871,y:314,t:1512065780745};\\\", \\\"{x:872,y:317,t:1512065780762};\\\", \\\"{x:873,y:319,t:1512065780778};\\\", \\\"{x:873,y:321,t:1512065780795};\\\", \\\"{x:873,y:324,t:1512065780812};\\\", \\\"{x:873,y:325,t:1512065780828};\\\", \\\"{x:875,y:329,t:1512065780845};\\\", \\\"{x:875,y:331,t:1512065780863};\\\", \\\"{x:875,y:334,t:1512065780878};\\\", \\\"{x:875,y:338,t:1512065780895};\\\", \\\"{x:875,y:344,t:1512065780912};\\\", \\\"{x:875,y:348,t:1512065780929};\\\", \\\"{x:875,y:351,t:1512065780945};\\\", \\\"{x:875,y:354,t:1512065780962};\\\", \\\"{x:875,y:355,t:1512065780979};\\\", \\\"{x:875,y:358,t:1512065780995};\\\", \\\"{x:875,y:362,t:1512065781012};\\\", \\\"{x:875,y:367,t:1512065781029};\\\", \\\"{x:875,y:371,t:1512065781045};\\\", \\\"{x:875,y:375,t:1512065781062};\\\", \\\"{x:875,y:378,t:1512065781080};\\\", \\\"{x:874,y:383,t:1512065781096};\\\", \\\"{x:872,y:396,t:1512065781112};\\\", \\\"{x:872,y:399,t:1512065781129};\\\", \\\"{x:870,y:402,t:1512065781146};\\\", \\\"{x:870,y:405,t:1512065781163};\\\", \\\"{x:869,y:406,t:1512065781179};\\\", \\\"{x:869,y:408,t:1512065781195};\\\", \\\"{x:868,y:410,t:1512065781212};\\\", \\\"{x:867,y:414,t:1512065781229};\\\", \\\"{x:865,y:417,t:1512065781245};\\\", \\\"{x:864,y:419,t:1512065781262};\\\", \\\"{x:863,y:422,t:1512065781279};\\\", \\\"{x:861,y:425,t:1512065781295};\\\", \\\"{x:860,y:427,t:1512065781312};\\\", \\\"{x:858,y:428,t:1512065781329};\\\", \\\"{x:857,y:430,t:1512065781346};\\\", \\\"{x:855,y:432,t:1512065781362};\\\", \\\"{x:855,y:433,t:1512065781379};\\\", \\\"{x:854,y:433,t:1512065781396};\\\", \\\"{x:853,y:434,t:1512065781412};\\\", \\\"{x:853,y:435,t:1512065781432};\\\", \\\"{x:852,y:436,t:1512065781446};\\\", \\\"{x:851,y:437,t:1512065781497};\\\", \\\"{x:850,y:437,t:1512065781561};\\\", \\\"{x:849,y:437,t:1512065781584};\\\", \\\"{x:848,y:437,t:1512065781657};\\\", \\\"{x:847,y:437,t:1512065781672};\\\", \\\"{x:846,y:437,t:1512065781680};\\\", \\\"{x:845,y:437,t:1512065781704};\\\", \\\"{x:843,y:437,t:1512065781712};\\\", \\\"{x:842,y:437,t:1512065781744};\\\", \\\"{x:841,y:437,t:1512065781760};\\\", \\\"{x:840,y:437,t:1512065781768};\\\", \\\"{x:838,y:437,t:1512065781800};\\\", \\\"{x:838,y:436,t:1512065781812};\\\", \\\"{x:836,y:434,t:1512065781829};\\\", \\\"{x:836,y:433,t:1512065781846};\\\", \\\"{x:835,y:430,t:1512065781863};\\\", \\\"{x:834,y:429,t:1512065781879};\\\", \\\"{x:834,y:428,t:1512065781896};\\\", \\\"{x:833,y:427,t:1512065781913};\\\", \\\"{x:833,y:426,t:1512065781936};\\\", \\\"{x:832,y:425,t:1512065781968};\\\", \\\"{x:832,y:424,t:1512065782049};\\\", \\\"{x:832,y:423,t:1512065782064};\\\", \\\"{x:832,y:421,t:1512065782088};\\\", \\\"{x:832,y:420,t:1512065782120};\\\", \\\"{x:832,y:418,t:1512065782169};\\\", \\\"{x:831,y:416,t:1512065782200};\\\", \\\"{x:830,y:414,t:1512065782304};\\\", \\\"{x:830,y:413,t:1512065782425};\\\", \\\"{x:830,y:411,t:1512065782575};\\\", \\\"{x:829,y:410,t:1512065782607};\\\", \\\"{x:829,y:410,t:1512065784084};\\\", \\\"{x:830,y:410,t:1512065784432};\\\", \\\"{x:838,y:416,t:1512065784448};\\\", \\\"{x:843,y:421,t:1512065784466};\\\", \\\"{x:846,y:423,t:1512065784481};\\\", \\\"{x:848,y:425,t:1512065784499};\\\", \\\"{x:849,y:427,t:1512065784515};\\\", \\\"{x:851,y:429,t:1512065784531};\\\", \\\"{x:854,y:436,t:1512065784549};\\\", \\\"{x:866,y:453,t:1512065784565};\\\", \\\"{x:888,y:480,t:1512065784582};\\\", \\\"{x:914,y:509,t:1512065784598};\\\", \\\"{x:935,y:528,t:1512065784615};\\\", \\\"{x:957,y:544,t:1512065784631};\\\", \\\"{x:967,y:551,t:1512065784648};\\\", \\\"{x:971,y:554,t:1512065784665};\\\", \\\"{x:972,y:555,t:1512065784682};\\\", \\\"{x:973,y:556,t:1512065784698};\\\", \\\"{x:974,y:557,t:1512065784715};\\\", \\\"{x:976,y:558,t:1512065784732};\\\", \\\"{x:977,y:559,t:1512065784748};\\\", \\\"{x:978,y:559,t:1512065784765};\\\", \\\"{x:980,y:560,t:1512065784782};\\\", \\\"{x:981,y:561,t:1512065784798};\\\", \\\"{x:982,y:562,t:1512065784815};\\\", \\\"{x:986,y:566,t:1512065784832};\\\", \\\"{x:991,y:570,t:1512065784849};\\\", \\\"{x:996,y:574,t:1512065784865};\\\", \\\"{x:999,y:577,t:1512065784882};\\\", \\\"{x:1006,y:582,t:1512065784898};\\\", \\\"{x:1012,y:586,t:1512065784916};\\\", \\\"{x:1018,y:590,t:1512065784932};\\\", \\\"{x:1023,y:594,t:1512065784949};\\\", \\\"{x:1028,y:596,t:1512065784965};\\\", \\\"{x:1031,y:598,t:1512065784983};\\\", \\\"{x:1038,y:600,t:1512065785000};\\\", \\\"{x:1044,y:601,t:1512065785016};\\\", \\\"{x:1054,y:603,t:1512065785032};\\\", \\\"{x:1064,y:605,t:1512065785049};\\\", \\\"{x:1077,y:609,t:1512065785066};\\\", \\\"{x:1090,y:613,t:1512065785082};\\\", \\\"{x:1099,y:616,t:1512065785100};\\\", \\\"{x:1105,y:617,t:1512065785115};\\\", \\\"{x:1108,y:618,t:1512065785132};\\\", \\\"{x:1110,y:618,t:1512065785149};\\\", \\\"{x:1112,y:619,t:1512065785165};\\\", \\\"{x:1113,y:624,t:1512065785856};\\\", \\\"{x:1109,y:636,t:1512065785866};\\\", \\\"{x:1081,y:671,t:1512065785884};\\\", \\\"{x:1050,y:693,t:1512065785900};\\\", \\\"{x:1020,y:705,t:1512065785916};\\\", \\\"{x:1003,y:718,t:1512065785933};\\\", \\\"{x:994,y:725,t:1512065785949};\\\", \\\"{x:990,y:727,t:1512065785966};\\\", \\\"{x:981,y:729,t:1512065785984};\\\", \\\"{x:964,y:734,t:1512065785999};\\\", \\\"{x:944,y:737,t:1512065786015};\\\", \\\"{x:916,y:738,t:1512065786032};\\\", \\\"{x:878,y:738,t:1512065786049};\\\", \\\"{x:841,y:738,t:1512065786066};\\\", \\\"{x:814,y:738,t:1512065786083};\\\", \\\"{x:801,y:736,t:1512065786099};\\\", \\\"{x:794,y:733,t:1512065786116};\\\", \\\"{x:793,y:732,t:1512065786132};\\\", \\\"{x:791,y:731,t:1512065786149};\\\", \\\"{x:790,y:730,t:1512065786167};\\\", \\\"{x:789,y:730,t:1512065786216};\\\", \\\"{x:788,y:729,t:1512065786233};\\\", \\\"{x:788,y:727,t:1512065786304};\\\", \\\"{x:790,y:726,t:1512065786316};\\\", \\\"{x:792,y:723,t:1512065786333};\\\", \\\"{x:795,y:722,t:1512065786349};\\\", \\\"{x:800,y:719,t:1512065786366};\\\", \\\"{x:806,y:718,t:1512065786384};\\\", \\\"{x:808,y:717,t:1512065786400};\\\", \\\"{x:811,y:717,t:1512065786416};\\\", \\\"{x:814,y:717,t:1512065786433};\\\", \\\"{x:816,y:717,t:1512065786449};\\\", \\\"{x:818,y:717,t:1512065786466};\\\", \\\"{x:819,y:719,t:1512065786483};\\\", \\\"{x:821,y:719,t:1512065786500};\\\", \\\"{x:822,y:720,t:1512065786516};\\\", \\\"{x:824,y:721,t:1512065786534};\\\", \\\"{x:826,y:723,t:1512065786549};\\\", \\\"{x:829,y:725,t:1512065786566};\\\", \\\"{x:832,y:728,t:1512065786583};\\\", \\\"{x:835,y:729,t:1512065786600};\\\", \\\"{x:836,y:729,t:1512065786616};\\\", \\\"{x:837,y:729,t:1512065786633};\\\", \\\"{x:838,y:730,t:1512065786650};\\\", \\\"{x:838,y:729,t:1512065787064};\\\", \\\"{x:837,y:727,t:1512065787072};\\\", \\\"{x:837,y:726,t:1512065787087};\\\", \\\"{x:836,y:725,t:1512065787103};\\\", \\\"{x:836,y:724,t:1512065787117};\\\", \\\"{x:835,y:724,t:1512065787133};\\\", \\\"{x:835,y:723,t:1512065787150};\\\", \\\"{x:835,y:723,t:1512065788099};\\\", \\\"{x:835,y:721,t:1512065788160};\\\", \\\"{x:835,y:720,t:1512065788216};\\\", \\\"{x:835,y:720,t:1512065788265};\\\", \\\"{x:834,y:721,t:1512065788849};\\\", \\\"{x:831,y:727,t:1512065788869};\\\", \\\"{x:830,y:727,t:1512065788952};\\\", \\\"{x:831,y:728,t:1512065789393};\\\", \\\"{x:832,y:728,t:1512065789403};\\\", \\\"{x:834,y:728,t:1512065789419};\\\", \\\"{x:836,y:728,t:1512065789481};\\\", \\\"{x:839,y:728,t:1512065789489};\\\", \\\"{x:844,y:728,t:1512065789504};\\\", \\\"{x:866,y:730,t:1512065789520};\\\", \\\"{x:883,y:734,t:1512065789536};\\\", \\\"{x:901,y:736,t:1512065789553};\\\", \\\"{x:918,y:739,t:1512065789570};\\\", \\\"{x:924,y:739,t:1512065789586};\\\", \\\"{x:930,y:740,t:1512065789603};\\\", \\\"{x:937,y:742,t:1512065789621};\\\", \\\"{x:952,y:742,t:1512065789636};\\\", \\\"{x:973,y:744,t:1512065789653};\\\", \\\"{x:999,y:749,t:1512065789670};\\\", \\\"{x:1024,y:751,t:1512065789686};\\\", \\\"{x:1050,y:755,t:1512065789703};\\\", \\\"{x:1091,y:760,t:1512065789720};\\\", \\\"{x:1114,y:767,t:1512065789736};\\\", \\\"{x:1139,y:774,t:1512065789753};\\\", \\\"{x:1166,y:782,t:1512065789770};\\\", \\\"{x:1187,y:789,t:1512065789786};\\\", \\\"{x:1211,y:799,t:1512065789803};\\\", \\\"{x:1236,y:810,t:1512065789820};\\\", \\\"{x:1266,y:819,t:1512065789836};\\\", \\\"{x:1296,y:829,t:1512065789853};\\\", \\\"{x:1317,y:835,t:1512065789870};\\\", \\\"{x:1327,y:837,t:1512065789886};\\\", \\\"{x:1329,y:838,t:1512065789903};\\\", \\\"{x:1327,y:838,t:1512065790793};\\\", \\\"{x:1322,y:840,t:1512065790804};\\\", \\\"{x:1304,y:853,t:1512065790820};\\\", \\\"{x:1295,y:861,t:1512065790837};\\\", \\\"{x:1285,y:866,t:1512065790854};\\\", \\\"{x:1276,y:869,t:1512065790870};\\\", \\\"{x:1257,y:876,t:1512065790887};\\\", \\\"{x:1201,y:892,t:1512065790904};\\\", \\\"{x:1156,y:908,t:1512065790920};\\\", \\\"{x:1113,y:921,t:1512065790937};\\\", \\\"{x:1078,y:934,t:1512065790954};\\\", \\\"{x:1052,y:941,t:1512065790971};\\\", \\\"{x:1031,y:947,t:1512065790987};\\\", \\\"{x:1016,y:951,t:1512065791004};\\\", \\\"{x:988,y:955,t:1512065791021};\\\", \\\"{x:955,y:961,t:1512065791037};\\\", \\\"{x:917,y:964,t:1512065791054};\\\", \\\"{x:885,y:969,t:1512065791072};\\\", \\\"{x:858,y:973,t:1512065791087};\\\", \\\"{x:829,y:976,t:1512065791104};\\\", \\\"{x:813,y:976,t:1512065791121};\\\", \\\"{x:808,y:975,t:1512065791138};\\\", \\\"{x:807,y:974,t:1512065791176};\\\", \\\"{x:806,y:971,t:1512065791188};\\\", \\\"{x:804,y:967,t:1512065791204};\\\", \\\"{x:804,y:964,t:1512065791221};\\\", \\\"{x:804,y:960,t:1512065791238};\\\", \\\"{x:804,y:954,t:1512065791254};\\\", \\\"{x:804,y:948,t:1512065791271};\\\", \\\"{x:804,y:942,t:1512065791288};\\\", \\\"{x:804,y:939,t:1512065791305};\\\", \\\"{x:804,y:938,t:1512065791329};\\\", \\\"{x:805,y:937,t:1512065791338};\\\", \\\"{x:808,y:935,t:1512065791355};\\\", \\\"{x:811,y:934,t:1512065791371};\\\", \\\"{x:812,y:933,t:1512065791388};\\\", \\\"{x:813,y:932,t:1512065791405};\\\", \\\"{x:814,y:931,t:1512065791421};\\\", \\\"{x:815,y:931,t:1512065791457};\\\", \\\"{x:816,y:931,t:1512065791505};\\\", \\\"{x:817,y:931,t:1512065791521};\\\", \\\"{x:818,y:931,t:1512065791585};\\\", \\\"{x:819,y:931,t:1512065791593};\\\", \\\"{x:820,y:931,t:1512065791605};\\\", \\\"{x:823,y:931,t:1512065791621};\\\", \\\"{x:824,y:931,t:1512065791638};\\\", \\\"{x:826,y:932,t:1512065791654};\\\", \\\"{x:827,y:932,t:1512065791671};\\\", \\\"{x:828,y:932,t:1512065791688};\\\", \\\"{x:829,y:932,t:1512065791729};\\\", \\\"{x:830,y:932,t:1512065791753};\\\", \\\"{x:831,y:933,t:1512065791793};\\\", \\\"{x:832,y:933,t:1512065791805};\\\", \\\"{x:832,y:934,t:1512065791857};\\\", \\\"{x:832,y:935,t:1512065791905};\\\", \\\"{x:832,y:937,t:1512065791945};\\\", \\\"{x:832,y:938,t:1512065791969};\\\", \\\"{x:832,y:938,t:1512065792220};\\\", \\\"{x:832,y:938,t:1512065792277};\\\", \\\"{x:835,y:942,t:1512065792553};\\\", \\\"{x:848,y:953,t:1512065792572};\\\", \\\"{x:863,y:969,t:1512065792589};\\\", \\\"{x:870,y:976,t:1512065792605};\\\", \\\"{x:880,y:988,t:1512065792622};\\\", \\\"{x:892,y:1001,t:1512065792639};\\\", \\\"{x:902,y:1011,t:1512065792655};\\\", \\\"{x:913,y:1020,t:1512065792672};\\\", \\\"{x:915,y:1023,t:1512065792689};\\\", \\\"{x:918,y:1026,t:1512065792705};\\\", \\\"{x:918,y:1028,t:1512065792728};\\\", \\\"{x:920,y:1030,t:1512065792744};\\\", \\\"{x:920,y:1031,t:1512065792768};\\\", \\\"{x:920,y:1033,t:1512065792776};\\\", \\\"{x:921,y:1034,t:1512065792789};\\\", \\\"{x:922,y:1035,t:1512065792805};\\\", \\\"{x:922,y:1036,t:1512065792822};\\\", \\\"{x:924,y:1039,t:1512065792839};\\\", \\\"{x:924,y:1041,t:1512065792855};\\\", \\\"{x:927,y:1046,t:1512065792872};\\\", \\\"{x:928,y:1051,t:1512065792889};\\\", \\\"{x:928,y:1054,t:1512065792906};\\\", \\\"{x:929,y:1055,t:1512065792923};\\\", \\\"{x:929,y:1056,t:1512065792945};\\\", \\\"{x:930,y:1056,t:1512065793089};\\\", \\\"{x:930,y:1055,t:1512065793112};\\\", \\\"{x:930,y:1054,t:1512065793123};\\\", \\\"{x:930,y:1051,t:1512065793140};\\\", \\\"{x:931,y:1049,t:1512065793156};\\\", \\\"{x:931,y:1043,t:1512065793173};\\\", \\\"{x:931,y:1041,t:1512065793190};\\\", \\\"{x:931,y:1040,t:1512065793206};\\\", \\\"{x:931,y:1037,t:1512065793224};\\\", \\\"{x:931,y:1033,t:1512065793240};\\\", \\\"{x:931,y:1032,t:1512065793265};\\\", \\\"{x:931,y:1031,t:1512065793297};\\\", \\\"{x:931,y:1030,t:1512065793329};\\\", \\\"{x:931,y:1028,t:1512065793393};\\\", \\\"{x:931,y:1027,t:1512065793881};\\\", \\\"{x:936,y:1024,t:1512065793890};\\\", \\\"{x:942,y:1019,t:1512065793907};\\\", \\\"{x:952,y:1011,t:1512065793923};\\\", \\\"{x:970,y:995,t:1512065793941};\\\", \\\"{x:998,y:970,t:1512065793958};\\\", \\\"{x:1034,y:931,t:1512065793974};\\\", \\\"{x:1065,y:895,t:1512065793991};\\\", \\\"{x:1081,y:876,t:1512065794007};\\\", \\\"{x:1089,y:861,t:1512065794024};\\\", \\\"{x:1102,y:835,t:1512065794041};\\\", \\\"{x:1111,y:813,t:1512065794057};\\\", \\\"{x:1123,y:779,t:1512065794073};\\\", \\\"{x:1133,y:761,t:1512065794090};\\\", \\\"{x:1139,y:745,t:1512065794107};\\\", \\\"{x:1148,y:722,t:1512065794123};\\\", \\\"{x:1154,y:702,t:1512065794140};\\\", \\\"{x:1157,y:682,t:1512065794157};\\\", \\\"{x:1160,y:661,t:1512065794173};\\\", \\\"{x:1160,y:643,t:1512065794190};\\\", \\\"{x:1160,y:629,t:1512065794208};\\\", \\\"{x:1160,y:614,t:1512065794223};\\\", \\\"{x:1160,y:602,t:1512065794240};\\\", \\\"{x:1160,y:601,t:1512065794257};\\\", \\\"{x:1159,y:601,t:1512065794313};\\\", \\\"{x:1156,y:607,t:1512065794323};\\\", \\\"{x:1146,y:647,t:1512065794340};\\\", \\\"{x:1134,y:694,t:1512065794357};\\\", \\\"{x:1126,y:748,t:1512065794379};\\\", \\\"{x:1120,y:787,t:1512065794390};\\\", \\\"{x:1114,y:808,t:1512065794407};\\\", \\\"{x:1108,y:832,t:1512065794424};\\\", \\\"{x:1102,y:852,t:1512065794440};\\\", \\\"{x:1097,y:868,t:1512065794457};\\\", \\\"{x:1093,y:873,t:1512065794474};\\\", \\\"{x:1088,y:882,t:1512065794490};\\\", \\\"{x:1077,y:897,t:1512065794507};\\\", \\\"{x:1067,y:909,t:1512065794524};\\\", \\\"{x:1055,y:923,t:1512065794540};\\\", \\\"{x:1046,y:931,t:1512065794557};\\\", \\\"{x:1033,y:945,t:1512065794574};\\\", \\\"{x:1029,y:950,t:1512065794590};\\\", \\\"{x:1027,y:952,t:1512065794607};\\\", \\\"{x:1023,y:957,t:1512065794624};\\\", \\\"{x:1021,y:959,t:1512065794640};\\\", \\\"{x:1018,y:966,t:1512065794657};\\\", \\\"{x:1016,y:970,t:1512065794674};\\\", \\\"{x:1013,y:973,t:1512065794690};\\\", \\\"{x:1012,y:975,t:1512065794707};\\\", \\\"{x:1012,y:976,t:1512065794736};\\\", \\\"{x:1012,y:977,t:1512065794752};\\\", \\\"{x:1011,y:978,t:1512065794768};\\\", \\\"{x:1011,y:979,t:1512065794776};\\\", \\\"{x:1011,y:980,t:1512065794791};\\\", \\\"{x:1010,y:985,t:1512065794808};\\\", \\\"{x:1008,y:993,t:1512065794824};\\\", \\\"{x:1007,y:1001,t:1512065794841};\\\", \\\"{x:1007,y:1002,t:1512065794857};\\\", \\\"{x:1007,y:1004,t:1512065794874};\\\", \\\"{x:1007,y:1005,t:1512065794897};\\\", \\\"{x:1007,y:1006,t:1512065794912};\\\", \\\"{x:1006,y:1007,t:1512065795753};\\\", \\\"{x:1005,y:1007,t:1512065795760};\\\", \\\"{x:1003,y:1007,t:1512065795775};\\\", \\\"{x:998,y:1008,t:1512065795791};\\\", \\\"{x:991,y:1010,t:1512065795808};\\\", \\\"{x:986,y:1010,t:1512065795825};\\\", \\\"{x:983,y:1010,t:1512065795841};\\\", \\\"{x:978,y:1010,t:1512065795858};\\\", \\\"{x:976,y:1010,t:1512065795875};\\\", \\\"{x:974,y:1010,t:1512065795891};\\\", \\\"{x:973,y:1010,t:1512065795945};\\\", \\\"{x:973,y:1009,t:1512065795960};\\\", \\\"{x:972,y:1009,t:1512065795976};\\\", \\\"{x:971,y:1009,t:1512065796025};\\\", \\\"{x:970,y:1009,t:1512065796465};\\\", \\\"{x:969,y:1009,t:1512065796475};\\\", \\\"{x:968,y:1009,t:1512065796492};\\\", \\\"{x:963,y:1010,t:1512065796509};\\\", \\\"{x:958,y:1011,t:1512065796525};\\\", \\\"{x:951,y:1014,t:1512065796543};\\\", \\\"{x:946,y:1015,t:1512065796559};\\\", \\\"{x:941,y:1016,t:1512065796575};\\\", \\\"{x:932,y:1020,t:1512065796591};\\\", \\\"{x:925,y:1022,t:1512065796608};\\\", \\\"{x:920,y:1023,t:1512065796625};\\\", \\\"{x:916,y:1024,t:1512065796642};\\\", \\\"{x:915,y:1024,t:1512065796658};\\\", \\\"{x:914,y:1024,t:1512065796675};\\\", \\\"{x:913,y:1026,t:1512065796704};\\\", \\\"{x:915,y:1026,t:1512065797289};\\\", \\\"{x:916,y:1025,t:1512065797296};\\\", \\\"{x:918,y:1025,t:1512065797309};\\\", \\\"{x:926,y:1022,t:1512065797326};\\\", \\\"{x:936,y:1018,t:1512065797342};\\\", \\\"{x:959,y:1010,t:1512065797359};\\\", \\\"{x:1004,y:990,t:1512065797375};\\\", \\\"{x:1045,y:973,t:1512065797392};\\\", \\\"{x:1077,y:962,t:1512065797409};\\\", \\\"{x:1104,y:951,t:1512065797426};\\\", \\\"{x:1128,y:940,t:1512065797442};\\\", \\\"{x:1152,y:928,t:1512065797459};\\\", \\\"{x:1180,y:913,t:1512065797476};\\\", \\\"{x:1198,y:904,t:1512065797492};\\\", \\\"{x:1210,y:895,t:1512065797509};\\\", \\\"{x:1223,y:883,t:1512065797526};\\\", \\\"{x:1231,y:875,t:1512065797542};\\\", \\\"{x:1236,y:869,t:1512065797559};\\\", \\\"{x:1243,y:857,t:1512065797576};\\\", \\\"{x:1246,y:853,t:1512065797593};\\\", \\\"{x:1250,y:844,t:1512065797609};\\\", \\\"{x:1253,y:837,t:1512065797626};\\\", \\\"{x:1256,y:833,t:1512065797643};\\\", \\\"{x:1261,y:824,t:1512065797659};\\\", \\\"{x:1264,y:821,t:1512065797676};\\\", \\\"{x:1264,y:820,t:1512065797693};\\\", \\\"{x:1265,y:816,t:1512065797709};\\\", \\\"{x:1266,y:813,t:1512065797726};\\\", \\\"{x:1266,y:811,t:1512065797744};\\\", \\\"{x:1267,y:810,t:1512065797759};\\\", \\\"{x:1267,y:809,t:1512065798761};\\\", \\\"{x:1267,y:805,t:1512065798778};\\\", \\\"{x:1267,y:798,t:1512065798794};\\\", \\\"{x:1265,y:785,t:1512065798811};\\\", \\\"{x:1261,y:771,t:1512065798828};\\\", \\\"{x:1257,y:758,t:1512065798844};\\\", \\\"{x:1252,y:740,t:1512065798861};\\\", \\\"{x:1246,y:725,t:1512065798877};\\\", \\\"{x:1241,y:714,t:1512065798894};\\\", \\\"{x:1235,y:701,t:1512065798910};\\\", \\\"{x:1227,y:679,t:1512065798928};\\\", \\\"{x:1213,y:648,t:1512065798944};\\\", \\\"{x:1205,y:630,t:1512065798960};\\\", \\\"{x:1200,y:616,t:1512065798978};\\\", \\\"{x:1193,y:599,t:1512065798995};\\\", \\\"{x:1188,y:587,t:1512065799010};\\\", \\\"{x:1185,y:575,t:1512065799028};\\\", \\\"{x:1181,y:562,t:1512065799045};\\\", \\\"{x:1178,y:552,t:1512065799061};\\\", \\\"{x:1172,y:535,t:1512065799078};\\\", \\\"{x:1167,y:515,t:1512065799095};\\\", \\\"{x:1159,y:494,t:1512065799110};\\\", \\\"{x:1154,y:478,t:1512065799128};\\\", \\\"{x:1148,y:461,t:1512065799144};\\\", \\\"{x:1144,y:451,t:1512065799160};\\\", \\\"{x:1139,y:439,t:1512065799178};\\\", \\\"{x:1135,y:425,t:1512065799195};\\\", \\\"{x:1131,y:414,t:1512065799211};\\\", \\\"{x:1129,y:405,t:1512065799228};\\\", \\\"{x:1125,y:395,t:1512065799245};\\\", \\\"{x:1120,y:387,t:1512065799261};\\\", \\\"{x:1118,y:382,t:1512065799278};\\\", \\\"{x:1112,y:371,t:1512065799295};\\\", \\\"{x:1106,y:361,t:1512065799312};\\\", \\\"{x:1100,y:351,t:1512065799328};\\\", \\\"{x:1095,y:343,t:1512065799344};\\\", \\\"{x:1093,y:339,t:1512065799362};\\\", \\\"{x:1091,y:337,t:1512065799378};\\\", \\\"{x:1089,y:331,t:1512065799395};\\\", \\\"{x:1086,y:326,t:1512065799411};\\\", \\\"{x:1083,y:320,t:1512065799427};\\\", \\\"{x:1078,y:314,t:1512065799444};\\\", \\\"{x:1075,y:309,t:1512065799461};\\\", \\\"{x:1073,y:305,t:1512065799478};\\\", \\\"{x:1071,y:302,t:1512065799495};\\\", \\\"{x:1070,y:299,t:1512065799512};\\\", \\\"{x:1068,y:298,t:1512065799528};\\\", \\\"{x:1067,y:296,t:1512065799544};\\\", \\\"{x:1064,y:294,t:1512065799568};\\\", \\\"{x:1064,y:292,t:1512065799592};\\\", \\\"{x:1063,y:292,t:1512065799600};\\\", \\\"{x:1062,y:292,t:1512065799612};\\\", \\\"{x:1060,y:290,t:1512065799628};\\\", \\\"{x:1059,y:290,t:1512065799644};\\\", \\\"{x:1058,y:289,t:1512065799661};\\\", \\\"{x:1055,y:288,t:1512065799677};\\\", \\\"{x:1052,y:286,t:1512065799694};\\\", \\\"{x:1047,y:285,t:1512065799711};\\\", \\\"{x:1038,y:281,t:1512065799727};\\\", \\\"{x:1036,y:281,t:1512065799744};\\\", \\\"{x:1035,y:281,t:1512065799761};\\\", \\\"{x:1034,y:281,t:1512065799778};\\\", \\\"{x:1033,y:281,t:1512065799794};\\\", \\\"{x:1032,y:279,t:1512065799816};\\\", \\\"{x:1031,y:279,t:1512065799856};\\\", \\\"{x:1030,y:278,t:1512065799872};\\\", \\\"{x:1028,y:288,t:1512065816585};\\\", \\\"{x:1028,y:294,t:1512065816592};\\\", \\\"{x:1028,y:300,t:1512065816608};\\\", \\\"{x:1028,y:308,t:1512065816626};\\\", \\\"{x:1028,y:317,t:1512065816642};\\\", \\\"{x:1028,y:321,t:1512065816658};\\\", \\\"{x:1029,y:326,t:1512065816675};\\\", \\\"{x:1030,y:329,t:1512065816692};\\\", \\\"{x:1031,y:338,t:1512065816709};\\\", \\\"{x:1032,y:345,t:1512065816726};\\\", \\\"{x:1034,y:356,t:1512065816742};\\\", \\\"{x:1036,y:364,t:1512065816759};\\\", \\\"{x:1038,y:374,t:1512065816775};\\\", \\\"{x:1038,y:382,t:1512065816792};\\\", \\\"{x:1040,y:390,t:1512065816808};\\\", \\\"{x:1043,y:410,t:1512065816826};\\\", \\\"{x:1043,y:417,t:1512065816842};\\\", \\\"{x:1043,y:427,t:1512065816859};\\\", \\\"{x:1043,y:440,t:1512065816876};\\\", \\\"{x:1043,y:452,t:1512065816892};\\\", \\\"{x:1043,y:463,t:1512065816909};\\\", \\\"{x:1043,y:472,t:1512065816926};\\\", \\\"{x:1043,y:481,t:1512065816942};\\\", \\\"{x:1042,y:495,t:1512065816959};\\\", \\\"{x:1041,y:505,t:1512065816976};\\\", \\\"{x:1038,y:520,t:1512065816992};\\\", \\\"{x:1033,y:536,t:1512065817009};\\\", \\\"{x:1031,y:545,t:1512065817026};\\\", \\\"{x:1026,y:559,t:1512065817043};\\\", \\\"{x:1022,y:571,t:1512065817059};\\\", \\\"{x:1018,y:583,t:1512065817075};\\\", \\\"{x:1013,y:596,t:1512065817093};\\\", \\\"{x:1010,y:606,t:1512065817109};\\\", \\\"{x:1008,y:614,t:1512065817126};\\\", \\\"{x:1005,y:619,t:1512065817143};\\\", \\\"{x:1004,y:621,t:1512065817159};\\\", \\\"{x:1000,y:626,t:1512065817176};\\\", \\\"{x:996,y:630,t:1512065817192};\\\", \\\"{x:995,y:630,t:1512065817224};\\\", \\\"{x:994,y:636,t:1512065817433};\\\", \\\"{x:988,y:655,t:1512065817443};\\\", \\\"{x:963,y:723,t:1512065817459};\\\", \\\"{x:931,y:823,t:1512065817476};\\\", \\\"{x:908,y:909,t:1512065817493};\\\", \\\"{x:893,y:964,t:1512065817510};\\\", \\\"{x:886,y:1004,t:1512065817526};\\\", \\\"{x:885,y:1023,t:1512065817542};\\\", \\\"{x:885,y:1035,t:1512065817560};\\\", \\\"{x:885,y:1042,t:1512065817576};\\\", \\\"{x:885,y:1046,t:1512065817592};\\\", \\\"{x:885,y:1050,t:1512065817609};\\\", \\\"{x:885,y:1052,t:1512065817626};\\\", \\\"{x:885,y:1055,t:1512065817643};\\\", \\\"{x:887,y:1060,t:1512065817660};\\\", \\\"{x:890,y:1067,t:1512065817676};\\\", \\\"{x:891,y:1069,t:1512065817693};\\\", \\\"{x:893,y:1070,t:1512065817710};\\\", \\\"{x:894,y:1070,t:1512065817726};\\\", \\\"{x:895,y:1072,t:1512065817743};\\\", \\\"{x:897,y:1072,t:1512065817759};\\\", \\\"{x:899,y:1074,t:1512065817775};\\\", \\\"{x:901,y:1075,t:1512065817793};\\\", \\\"{x:904,y:1076,t:1512065817809};\\\", \\\"{x:906,y:1076,t:1512065817826};\\\", \\\"{x:910,y:1076,t:1512065817843};\\\", \\\"{x:916,y:1078,t:1512065817860};\\\", \\\"{x:922,y:1079,t:1512065817876};\\\", \\\"{x:926,y:1079,t:1512065817892};\\\", \\\"{x:933,y:1079,t:1512065817909};\\\", \\\"{x:938,y:1079,t:1512065817926};\\\", \\\"{x:941,y:1079,t:1512065817943};\\\", \\\"{x:942,y:1079,t:1512065817959};\\\", \\\"{x:943,y:1079,t:1512065817976};\\\", \\\"{x:947,y:1079,t:1512065817993};\\\", \\\"{x:950,y:1079,t:1512065818009};\\\", \\\"{x:952,y:1079,t:1512065818026};\\\", \\\"{x:956,y:1079,t:1512065818043};\\\", \\\"{x:960,y:1079,t:1512065818059};\\\", \\\"{x:961,y:1079,t:1512065818076};\\\", \\\"{x:963,y:1078,t:1512065818093};\\\", \\\"{x:964,y:1078,t:1512065818110};\\\", \\\"{x:965,y:1078,t:1512065818177};\\\", \\\"{x:966,y:1078,t:1512065818569};\\\", \\\"{x:968,y:1079,t:1512065818921};\\\", \\\"{x:968,y:1080,t:1512065818936};\\\", \\\"{x:969,y:1081,t:1512065818944};\\\", \\\"{x:969,y:1083,t:1512065818960};\\\", \\\"{x:970,y:1085,t:1512065818977};\\\", \\\"{x:970,y:1086,t:1512065819000};\\\", \\\"{x:970,y:1087,t:1512065819024};\\\" ] }, { \\\"rt\\\": 9878, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 537468, \\\"internal_node_id\\\": \\\"0.0-7.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 21711, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Spanish\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 560193, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 22135, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 583421, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"ACPUO\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":1732}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":1,\"id\":53,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":8,\"id\":57},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\"ACPUO\"}]},{\"nodeType\":3,\"id\":75,\"textContent\":\" \"},{\"nodeType\":1,\"id\":76,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":8,\"id\":78},{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":1,\"id\":80,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\"Hint: hover your mouse over the data points for help\"}]},{\"nodeType\":3,\"id\":84,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":85,\"textContent\":\" \"},{\"nodeType\":8,\"id\":86},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":1,\"id\":90,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":96,\"textContent\":\" \"},{\"nodeType\":1,\"id\":97,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":100,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":101,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":103,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":106,\"textContent\":\" \"},{\"nodeType\":1,\"id\":107,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":108,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":109,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":111,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":114,\"textContent\":\" \"},{\"nodeType\":1,\"id\":115,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":116,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":117,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":119,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":122,\"textContent\":\" \"},{\"nodeType\":1,\"id\":123,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":124,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":125,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":127,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":130,\"textContent\":\" \"},{\"nodeType\":1,\"id\":131,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":132,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":133,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":135,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":138,\"textContent\":\" \"},{\"nodeType\":1,\"id\":139,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":140,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":141,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":143,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":146,\"textContent\":\" \"},{\"nodeType\":1,\"id\":147,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":148,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":149,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":151,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":154,\"textContent\":\" \"},{\"nodeType\":1,\"id\":155,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":156,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":157,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":158,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":159,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":161,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":162,\"textContent\":\" \"},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":164,\"textContent\":\"Which shift(s) start with D?\"}]},{\"nodeType\":3,\"id\":165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":166,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":170,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"},{\"nodeType\":1,\"id\":172,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":173,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":174,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":178,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"},{\"nodeType\":1,\"id\":180,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":181,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":182,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":186,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"},{\"nodeType\":1,\"id\":188,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":189,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":190,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":194,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"},{\"nodeType\":1,\"id\":196,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":197,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":198,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":201,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":202,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"},{\"nodeType\":1,\"id\":204,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":205,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":206,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":209,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":210,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"},{\"nodeType\":1,\"id\":212,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":213,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":214,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":217,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":218,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"},{\"nodeType\":1,\"id\":220,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":221,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":222,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":224,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":225,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":226,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":228,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":232,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":233,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":236,\"textContent\":\" \"},{\"nodeType\":1,\"id\":237,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":238,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":239,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":243,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"},{\"nodeType\":1,\"id\":245,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":246,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":247,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":251,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"},{\"nodeType\":1,\"id\":253,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":254,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":255,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":259,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"},{\"nodeType\":1,\"id\":261,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":262,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":263,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":267,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"},{\"nodeType\":1,\"id\":269,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":270,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":271,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":275,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"},{\"nodeType\":1,\"id\":277,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":278,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":279,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":283,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"},{\"nodeType\":1,\"id\":285,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":286,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":287,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":291,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"},{\"nodeType\":1,\"id\":293,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":294,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":295,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":296,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":297,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":300,\"textContent\":\" \"},{\"nodeType\":1,\"id\":301,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":302,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":303,\"textContent\":\" \"},{\"nodeType\":1,\"id\":304,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":306,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":307,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":312,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":314,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":315,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":320,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":322,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":323,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":328,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":330,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":331,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":336,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":338,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":339,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":344,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":346,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":347,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"},{\"nodeType\":1,\"id\":350,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":351,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":352,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":355,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":356,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":358,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":359,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":360,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":364,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":368,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":371,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":372,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":373,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":376,\"textContent\":\" \"},{\"nodeType\":1,\"id\":377,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":380,\"textContent\":\" \"},{\"nodeType\":1,\"id\":381,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":382,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":383,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":384,\"textContent\":\" \"},{\"nodeType\":1,\"id\":385,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":388,\"textContent\":\" \"},{\"nodeType\":1,\"id\":389,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":390,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":391,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":392,\"textContent\":\" \"},{\"nodeType\":1,\"id\":393,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":396,\"textContent\":\" \"},{\"nodeType\":1,\"id\":397,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":398,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":399,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":400,\"textContent\":\" \"},{\"nodeType\":1,\"id\":401,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":404,\"textContent\":\" \"},{\"nodeType\":1,\"id\":405,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":406,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":407,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":408,\"textContent\":\" \"},{\"nodeType\":1,\"id\":409,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":412,\"textContent\":\" \"},{\"nodeType\":1,\"id\":413,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":414,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":415,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":416,\"textContent\":\" \"},{\"nodeType\":1,\"id\":417,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":420,\"textContent\":\" \"},{\"nodeType\":1,\"id\":421,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":422,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":423,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":424,\"textContent\":\" \"},{\"nodeType\":1,\"id\":425,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":428,\"textContent\":\" \"},{\"nodeType\":1,\"id\":429,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":430,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":431,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":432,\"textContent\":\" \"},{\"nodeType\":1,\"id\":433,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":436,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":440,\"textContent\":\" \"},{\"nodeType\":1,\"id\":441,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":442,\"textContent\":\"Which shifts are six hours long?\"}]},{\"nodeType\":3,\"id\":443,\"textContent\":\" \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":445,\"textContent\":\" \"},{\"nodeType\":1,\"id\":446,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":447,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":448,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":452,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"},{\"nodeType\":1,\"id\":454,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":455,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":456,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":460,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"},{\"nodeType\":1,\"id\":462,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":463,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":464,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":468,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"},{\"nodeType\":1,\"id\":470,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":471,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":472,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":476,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"},{\"nodeType\":1,\"id\":478,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":479,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":480,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":481,\"textContent\":\" \"},{\"nodeType\":1,\"id\":482,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":484,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":487,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":488,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":489,\"textContent\":\" \"},{\"nodeType\":1,\"id\":490,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":493,\"textContent\":\" \"},{\"nodeType\":1,\"id\":494,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":495,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":496,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":497,\"textContent\":\" \"},{\"nodeType\":1,\"id\":498,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":501,\"textContent\":\" \"},{\"nodeType\":1,\"id\":502,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":503,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":504,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":506,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":509,\"textContent\":\" \"},{\"nodeType\":1,\"id\":510,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":511,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":512,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":513,\"textContent\":\" \"},{\"nodeType\":1,\"id\":514,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":517,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":521,\"textContent\":\" \"},{\"nodeType\":1,\"id\":522,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":523,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":524,\"textContent\":\" \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":526,\"textContent\":\" \"},{\"nodeType\":1,\"id\":527,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":528,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":529,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":533,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"},{\"nodeType\":1,\"id\":535,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":536,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":537,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":541,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"},{\"nodeType\":1,\"id\":543,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":544,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":545,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":549,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"},{\"nodeType\":1,\"id\":551,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":552,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":553,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":557,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"},{\"nodeType\":1,\"id\":559,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":560,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":561,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":565,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"},{\"nodeType\":1,\"id\":567,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":568,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":569,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":573,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"},{\"nodeType\":1,\"id\":575,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":576,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":577,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":581,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"},{\"nodeType\":1,\"id\":583,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":584,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":585,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":589,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"},{\"nodeType\":1,\"id\":591,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":592,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":593,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":597,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":601,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":604,\"textContent\":\"Which shift under 7 hours long starts before B and ends after X?\"}]},{\"nodeType\":3,\"id\":605,\"textContent\":\" \"},{\"nodeType\":1,\"id\":606,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":607,\"textContent\":\" \"},{\"nodeType\":1,\"id\":608,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":609,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":610,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":613,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":614,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":615,\"textContent\":\" \"},{\"nodeType\":1,\"id\":616,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":617,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":618,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":620,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":621,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":622,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":623,\"textContent\":\" \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":625,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":626,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":628,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":630,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":631,\"textContent\":\" \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":634,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":636,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":637,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":638,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":639,\"textContent\":\" \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":642,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":644,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":645,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":646,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":647,\"textContent\":\" \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":649,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":650,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":652,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":654,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":655,\"textContent\":\" \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":657,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":658,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":660,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":662,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":666,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":667,\"textContent\":\" \"},{\"nodeType\":1,\"id\":668,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":670,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":671,\"textContent\":\" \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":674,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":675,\"textContent\":\" \"},{\"nodeType\":1,\"id\":676,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":678,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":679,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":680,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":682,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":683,\"textContent\":\" \"},{\"nodeType\":1,\"id\":684,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\"Which shift begins before J and ends during B?\"}]},{\"nodeType\":3,\"id\":686,\"textContent\":\" \"},{\"nodeType\":1,\"id\":687,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":688,\"textContent\":\" \"},{\"nodeType\":1,\"id\":689,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":691,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":693,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":696,\"textContent\":\" \"},{\"nodeType\":1,\"id\":697,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":698,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":699,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":701,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":704,\"textContent\":\" \"},{\"nodeType\":1,\"id\":705,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":706,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":707,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":709,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":712,\"textContent\":\" \"},{\"nodeType\":1,\"id\":713,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":714,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":715,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":717,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":720,\"textContent\":\" \"},{\"nodeType\":1,\"id\":721,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":722,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":723,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":725,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":728,\"textContent\":\" \"},{\"nodeType\":1,\"id\":729,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":730,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":731,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":733,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":736,\"textContent\":\" \"},{\"nodeType\":1,\"id\":737,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":738,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":739,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":742,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":743,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":744,\"textContent\":\" \"},{\"nodeType\":1,\"id\":745,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":746,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":747,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":749,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":750,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":751,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":752,\"textContent\":\" \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":754,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":755,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":757,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":758,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":759,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":760,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":761,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"},{\"nodeType\":1,\"id\":763,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":765,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\"Which shift ends with F?\"}]},{\"nodeType\":3,\"id\":767,\"textContent\":\" \"},{\"nodeType\":1,\"id\":768,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":770,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":771,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":772,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":773,\"textContent\":\" \"},{\"nodeType\":1,\"id\":774,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":778,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":779,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":780,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":781,\"textContent\":\" \"},{\"nodeType\":1,\"id\":782,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":786,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":787,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":788,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":789,\"textContent\":\" \"},{\"nodeType\":1,\"id\":790,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":794,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":795,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":796,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":797,\"textContent\":\" \"},{\"nodeType\":1,\"id\":798,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":802,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":803,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":804,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":805,\"textContent\":\" \"},{\"nodeType\":1,\"id\":806,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":809,\"textContent\":\" \"},{\"nodeType\":1,\"id\":810,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":811,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":812,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":814,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":817,\"textContent\":\" \"},{\"nodeType\":1,\"id\":818,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":819,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":820,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":822,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":825,\"textContent\":\" \"},{\"nodeType\":1,\"id\":826,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":827,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":828,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":830,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":833,\"textContent\":\" \"},{\"nodeType\":1,\"id\":834,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":835,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":836,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":838,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":841,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":846,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":847,\"textContent\":\"Which shifts start at 12pm?\"}]},{\"nodeType\":3,\"id\":848,\"textContent\":\" \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":851,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":852,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":853,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":856,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":857,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":859,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":860,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":861,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":864,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":865,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":867,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":868,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":869,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":872,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":873,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":875,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":876,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":877,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":880,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":881,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":883,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":884,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":885,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":888,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":889,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":891,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":892,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":893,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":895,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":896,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":897,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":900,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":901,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":902,\"textContent\":\" \"},{\"nodeType\":1,\"id\":903,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":907,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":908,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":909,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":910,\"textContent\":\" \"},{\"nodeType\":1,\"id\":911,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":915,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":916,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":917,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":918,\"textContent\":\" \"},{\"nodeType\":1,\"id\":919,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":922,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":926,\"textContent\":\" \"},{\"nodeType\":1,\"id\":927,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":928,\"textContent\":\"Which shift starts with F?\"}]},{\"nodeType\":3,\"id\":929,\"textContent\":\" \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":931,\"textContent\":\" \"},{\"nodeType\":1,\"id\":932,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":933,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":934,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":937,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":938,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"},{\"nodeType\":1,\"id\":940,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":941,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":942,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":945,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":946,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"},{\"nodeType\":1,\"id\":948,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":949,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":950,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":953,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":954,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"},{\"nodeType\":1,\"id\":956,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":957,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":958,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":961,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":962,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"},{\"nodeType\":1,\"id\":964,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":965,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":966,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":969,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":970,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":972,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":973,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":974,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":977,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":978,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":980,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":981,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":982,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":985,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":986,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":988,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":989,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":990,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":993,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":994,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":996,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":997,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":998,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1001,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1002,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1005,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1006,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1009,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1010,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1011,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1015,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1016,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1017,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1018,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1023,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1024,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1025,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1026,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1031,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1032,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1033,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1034,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1039,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1040,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1041,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1042,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1045,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1046,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1047,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1050,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1051,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1053,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1054,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1055,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1058,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1059,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1061,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1062,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1063,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1066,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1067,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1069,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1070,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1071,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1074,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1075,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1077,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1078,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1079,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1082,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1083,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1087,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1090,\"textContent\":\"Which shift ends at 3pm?\"}]},{\"nodeType\":3,\"id\":1091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1092,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1096,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1097,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1098,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1099,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1104,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1105,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1106,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1107,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1112,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1113,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1114,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1115,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1120,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1121,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1122,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1123,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1128,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1130,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1131,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1136,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1138,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1139,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1144,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1146,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1147,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1152,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1154,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1155,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1160,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1162,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1163,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1166,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1168,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1170,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1171,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":1172,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":1173,\"textContent\":\"Which 2 shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":1174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1175,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1179,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1181,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1182,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1183,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1187,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1189,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1190,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1191,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1195,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1197,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1198,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1199,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1201,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1203,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1206,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1207,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1208,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1209,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1213,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1214,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1215,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1216,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1217,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1220,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1221,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1222,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1223,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1225,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1228,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1229,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1230,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1231,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1233,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1236,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1237,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1238,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1239,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1241,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1244,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1245,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1246,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1247,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1248,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1250,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1251,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1252},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1254},{\"nodeType\":3,\"id\":1255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1256,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"start\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":1259,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":1260,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1263},{\"nodeType\":3,\"id\":1264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1265,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":1266,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":1267,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1268,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":1269,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":1270,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":1271,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":1272,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1273,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1274,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1275,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":1276,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1277,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1278,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1279,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":1280,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1281,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1282,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1283,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":1284,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1285,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1286,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1287,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":1288,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1289,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1290,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1291,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":1292,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1293,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1294,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1295,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":1296,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1297,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1298,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1299,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":1300,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1301,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1302,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1303,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":1304,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1305,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1306,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1307,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":1308,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1309,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1310,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1311,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":1312,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1313,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1314,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1315,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":1316,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1317,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1318,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1319,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":1320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1321,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1322,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1323,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":1324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1325,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1326,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1327,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":1328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1329,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1330,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1331,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":1332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1333,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1334,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1335,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":1336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1337,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1338,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1339,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":1340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1341,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1342,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1343,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":1344,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1347,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":1348,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1351,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":1352,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1355,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":1356,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":1360,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1363,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":1364,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1367,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":1368,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1371,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":1372,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":1373,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1374,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":1375,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1376,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":1377,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":1378,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":1379,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":1380,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":1381,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":1382,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":1383,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":1384,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":1385,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":1386,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":1387,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":1388,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":1389,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":1390,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":1391,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":1392,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":1393,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":1394,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":1395,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":1396,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":1397,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":1398,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":1399,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":1400,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":1402,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1403,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1404,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1405,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":1406,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1407,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1408,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1409,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":1410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1413,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":1414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1417,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":1418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1421,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":1422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1425,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":1426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1429,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":1430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1433,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":1434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1437,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":1438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1441,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":1442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1445,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":1446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1449,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":1450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":1452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":1453,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":1454,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":1455,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1456,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":1457,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1458,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1459,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":1460,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1461,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":1462,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1463,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":1464,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":1466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":1468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":1470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":1472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":1474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":1476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":1478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":1480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":1482,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":1483,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1484,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1485,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":1486,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":1487,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1488,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1489,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":1491,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1492,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1493,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":1494,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":1495,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1496,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1497,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":1499,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1500,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1501,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":1502,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":1503,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1504,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1505,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":1506,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":1507,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1508,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1509,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":1510,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":1511,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1512,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1513,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":1514,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":1515,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1516,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1517,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":1518,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":1519,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1520,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1521,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1522,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":1523,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1524,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1525,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":1526,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":1527,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1528,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1529,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":1530,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":1531,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1532,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1533,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":1534,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":1535,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1536,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1537,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1538,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":1539,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1540,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1541,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":1542,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":1543,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":1546,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":1547,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":1550,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":1551,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1554,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1556,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1557},{\"nodeType\":3,\"id\":1558,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1559,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":1562,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 167, dom: 1907, initialDom: 2007",
  "javascriptErrors": []
}