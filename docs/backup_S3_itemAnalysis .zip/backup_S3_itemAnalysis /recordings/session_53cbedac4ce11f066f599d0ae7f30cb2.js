var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1bf34d02cdf6abf14a3cc6cced160117",
  "created": "2017-11-28T10:12:57.2153361-08:00",
  "lastActivity": "2017-11-28T10:13:41.6163361-08:00",
  "pageViews": [
    {
      "id": "1128574674ff9f934d2f9726ffaf995b7fe9c1ec",
      "startTime": "2017-11-28T10:12:57.2153361-08:00",
      "endTime": "2017-11-28T10:13:41.6163361-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 44401,
      "engagementTime": 38198,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 44401,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=68W24",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "53cbedac4ce11f066f599d0ae7f30cb2",
  "gdpr": false
}