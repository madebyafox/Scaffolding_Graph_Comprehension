var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cc45eab402be91abd26b25974b7dc932",
  "created": "2017-11-29T17:19:06.0304884-08:00",
  "lastActivity": "2017-11-29T17:19:11.5584884-08:00",
  "pageViews": [
    {
      "id": "11290625d9afffcf34b8826931fc85bf1c347f33",
      "startTime": "2017-11-29T17:19:06.0304884-08:00",
      "endTime": "2017-11-29T17:19:11.5584884-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 5528,
      "engagementTime": 5528,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 5528,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.35",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=B2WUH",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "92f38ea1e0322cb5ce855df7fd5d08ad",
  "gdpr": false
}