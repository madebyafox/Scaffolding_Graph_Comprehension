var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "520080225384d22cdf5cef6ff9a877e7",
  "created": "2017-11-29T17:12:58.8272517-08:00",
  "lastActivity": "2017-11-29T17:13:18.0882517-08:00",
  "pageViews": [
    {
      "id": "11295862f63f927d1c0efd4af022956c1c0027a7",
      "startTime": "2017-11-29T17:12:58.8272517-08:00",
      "endTime": "2017-11-29T17:13:18.0882517-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 19261,
      "engagementTime": 19261,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 19261,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=JFJSX",
    "CONDITION=211",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "039f0bbe0eeb32eed5c5b25684d5c50f",
  "gdpr": false
}