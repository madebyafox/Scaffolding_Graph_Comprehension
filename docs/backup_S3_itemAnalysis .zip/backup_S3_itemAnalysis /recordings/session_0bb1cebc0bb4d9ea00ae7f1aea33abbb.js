var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ba674915b9e95b13206024a178d51beb",
  "created": "2017-11-28T10:12:27.2358878-08:00",
  "lastActivity": "2017-11-28T10:12:38.2207416-08:00",
  "pageViews": [
    {
      "id": "11282755a3cc3fda30672231329b906db0ebb1df",
      "startTime": "2017-11-28T10:12:27.4667416-08:00",
      "endTime": "2017-11-28T10:12:38.2207416-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 10754,
      "engagementTime": 11756,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 10754,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=VLTVY",
    "CONDITION=321",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0bb1cebc0bb4d9ea00ae7f1aea33abbb",
  "gdpr": false
}