var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7c250fbe8274115e100323200eacd338",
  "created": "2017-11-28T09:18:50.5277057-08:00",
  "lastActivity": "2017-11-28T09:19:53.614037-08:00",
  "pageViews": [
    {
      "id": "112850915800077793d7d573057b2c725c0b938a",
      "startTime": "2017-11-28T09:18:50.6562378-08:00",
      "endTime": "2017-11-28T09:19:53.614037-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 63456,
      "engagementTime": 42457,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 63456,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=HP71D",
    "CONDITION=221"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e4d41c5edf3bd96e9ff323f14b34fb06",
  "gdpr": false
}