var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2d05dec8aff7f82fec640f9335d56f5f",
  "created": "2017-11-29T17:11:51.3878353-08:00",
  "lastActivity": "2017-11-29T17:12:00.8278353-08:00",
  "pageViews": [
    {
      "id": "11295132b5359fad82fa434a2a4c55d347aba072",
      "startTime": "2017-11-29T17:11:51.3878353-08:00",
      "endTime": "2017-11-29T17:12:00.8278353-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 9440,
      "engagementTime": 18880,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 9440,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DUV1M",
    "CONDITION=221",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "65ac2dae046ef1331a6a8f5703f98535",
  "gdpr": false
}