var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "115485628ba1c792372454677e765a9d",
  "created": "2017-12-05T10:18:40.7775358-08:00",
  "lastActivity": "2017-12-05T10:18:51.6295358-08:00",
  "pageViews": [
    {
      "id": "120540602a914600fd7756c6a0586c5dd32dd61e",
      "startTime": "2017-12-05T10:18:40.7775358-08:00",
      "endTime": "2017-12-05T10:18:51.6295358-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 10852,
      "engagementTime": 10852,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 10852,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=KGNTA",
    "CONDITION=112",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "673026af732731ec2e2179f73ccf9f91",
  "gdpr": false
}