var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6a8127fd5d05a0cd9576b3dd4f88584c",
  "created": "2017-11-21T09:11:22.3959912-08:00",
  "lastActivity": "2017-11-21T09:13:44.3539912-08:00",
  "pageViews": [
    {
      "id": "11212249a46f1bed738fd85fbf23684f969bc106",
      "startTime": "2017-11-21T09:11:22.3959912-08:00",
      "endTime": "2017-11-21T09:13:44.3539912-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 141958,
      "engagementTime": 130908,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 141958,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=7WCYU",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f14a5512b6dfebefdd8a8fa419de24a7",
  "gdpr": false
}