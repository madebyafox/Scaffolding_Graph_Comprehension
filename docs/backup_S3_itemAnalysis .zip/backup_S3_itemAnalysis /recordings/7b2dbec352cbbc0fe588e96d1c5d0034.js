var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["11292370dbebe3881cbfda0557cfb5bd3f369379"] = {
  "startTime": "2017-11-30T01:15:23.7325489Z",
  "websitePageUrl": "/7",
  "visitTime": 19290,
  "engagementTime": 19089,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "c6fff5d52edb8936a5c7c5d2bdc9751c",
    "created": "2017-11-30T01:15:23.7325489+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "duration": 0,
    "pages": 1,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "62.0.3202.94",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/7",
    "tags": [
      "form-interact"
    ],
    "variables": [
      "SID=B2WUH",
      "CONDITION=211",
      "TRI_CORRECT=1"
    ],
    "watched": false,
    "starred": false,
    "gdpr": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "7b2dbec352cbbc0fe588e96d1c5d0034",
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c6fff5d52edb8936a5c7c5d2bdc9751c/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 676,
      "e": 676,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 5302,
      "e": 5101,
      "ty": 2,
      "x": 427,
      "y": 694
    },
    {
      "t": 5401,
      "e": 5200,
      "ty": 2,
      "x": 973,
      "y": 649
    },
    {
      "t": 5502,
      "e": 5301,
      "ty": 41,
      "x": 17532,
      "y": 35310,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5502,
      "e": 5301,
      "ty": 2,
      "x": 1038,
      "y": 631
    },
    {
      "t": 5601,
      "e": 5400,
      "ty": 2,
      "x": 1053,
      "y": 637
    },
    {
      "t": 5702,
      "e": 5501,
      "ty": 2,
      "x": 1069,
      "y": 633
    },
    {
      "t": 5752,
      "e": 5551,
      "ty": 41,
      "x": 19716,
      "y": 35453,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6202,
      "e": 6001,
      "ty": 2,
      "x": 1091,
      "y": 639
    },
    {
      "t": 6252,
      "e": 6051,
      "ty": 41,
      "x": 25988,
      "y": 37816,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6302,
      "e": 6101,
      "ty": 2,
      "x": 1181,
      "y": 680
    },
    {
      "t": 6402,
      "e": 6201,
      "ty": 2,
      "x": 1201,
      "y": 703
    },
    {
      "t": 6502,
      "e": 6301,
      "ty": 41,
      "x": 30709,
      "y": 44692,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6502,
      "e": 6301,
      "ty": 2,
      "x": 1225,
      "y": 762
    },
    {
      "t": 6602,
      "e": 6401,
      "ty": 2,
      "x": 1261,
      "y": 836
    },
    {
      "t": 6702,
      "e": 6501,
      "ty": 2,
      "x": 1265,
      "y": 868
    },
    {
      "t": 6752,
      "e": 6551,
      "ty": 41,
      "x": 33316,
      "y": 52499,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6802,
      "e": 6601,
      "ty": 2,
      "x": 1240,
      "y": 886
    },
    {
      "t": 6902,
      "e": 6701,
      "ty": 2,
      "x": 1225,
      "y": 907
    },
    {
      "t": 7002,
      "e": 6801,
      "ty": 41,
      "x": 30709,
      "y": 55292,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7002,
      "e": 6801,
      "ty": 2,
      "x": 1225,
      "y": 910
    },
    {
      "t": 7102,
      "e": 6901,
      "ty": 2,
      "x": 1256,
      "y": 885
    },
    {
      "t": 7202,
      "e": 7001,
      "ty": 2,
      "x": 1259,
      "y": 871
    },
    {
      "t": 7252,
      "e": 7051,
      "ty": 41,
      "x": 33175,
      "y": 52428,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7302,
      "e": 7101,
      "ty": 2,
      "x": 1263,
      "y": 867
    },
    {
      "t": 7402,
      "e": 7201,
      "ty": 2,
      "x": 1281,
      "y": 846
    },
    {
      "t": 7502,
      "e": 7301,
      "ty": 41,
      "x": 35219,
      "y": 49992,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7502,
      "e": 7301,
      "ty": 2,
      "x": 1289,
      "y": 836
    },
    {
      "t": 8102,
      "e": 7901,
      "ty": 2,
      "x": 1288,
      "y": 837
    },
    {
      "t": 8202,
      "e": 8001,
      "ty": 2,
      "x": 1287,
      "y": 838
    },
    {
      "t": 8252,
      "e": 8051,
      "ty": 41,
      "x": 35078,
      "y": 50136,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8402,
      "e": 8201,
      "ty": 2,
      "x": 1279,
      "y": 861
    },
    {
      "t": 8502,
      "e": 8301,
      "ty": 41,
      "x": 32894,
      "y": 56080,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8502,
      "e": 8301,
      "ty": 2,
      "x": 1256,
      "y": 921
    },
    {
      "t": 8602,
      "e": 8401,
      "ty": 2,
      "x": 1249,
      "y": 944
    },
    {
      "t": 8702,
      "e": 8501,
      "ty": 2,
      "x": 1247,
      "y": 954
    },
    {
      "t": 8752,
      "e": 8551,
      "ty": 41,
      "x": 32259,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8802,
      "e": 8601,
      "ty": 2,
      "x": 1247,
      "y": 953
    },
    {
      "t": 8902,
      "e": 8701,
      "ty": 2,
      "x": 1251,
      "y": 938
    },
    {
      "t": 9002,
      "e": 8801,
      "ty": 41,
      "x": 32612,
      "y": 57083,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9002,
      "e": 8801,
      "ty": 2,
      "x": 1252,
      "y": 935
    },
    {
      "t": 9102,
      "e": 8901,
      "ty": 2,
      "x": 1255,
      "y": 923
    },
    {
      "t": 9202,
      "e": 9001,
      "ty": 2,
      "x": 1267,
      "y": 889
    },
    {
      "t": 9252,
      "e": 9051,
      "ty": 41,
      "x": 33951,
      "y": 52929,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9302,
      "e": 9101,
      "ty": 2,
      "x": 1272,
      "y": 874
    },
    {
      "t": 9402,
      "e": 9201,
      "ty": 2,
      "x": 1279,
      "y": 859
    },
    {
      "t": 9502,
      "e": 9301,
      "ty": 41,
      "x": 35008,
      "y": 50565,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9502,
      "e": 9301,
      "ty": 2,
      "x": 1286,
      "y": 844
    },
    {
      "t": 9601,
      "e": 9400,
      "ty": 2,
      "x": 1289,
      "y": 838
    },
    {
      "t": 9702,
      "e": 9501,
      "ty": 2,
      "x": 1301,
      "y": 810
    },
    {
      "t": 9752,
      "e": 9551,
      "ty": 41,
      "x": 36910,
      "y": 46769,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9802,
      "e": 9601,
      "ty": 2,
      "x": 1317,
      "y": 781
    },
    {
      "t": 9902,
      "e": 9701,
      "ty": 2,
      "x": 1319,
      "y": 778
    },
    {
      "t": 10002,
      "e": 9801,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10003,
      "e": 9802,
      "ty": 41,
      "x": 37474,
      "y": 45337,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10003,
      "e": 9802,
      "ty": 2,
      "x": 1321,
      "y": 771
    },
    {
      "t": 10102,
      "e": 9901,
      "ty": 2,
      "x": 1323,
      "y": 763
    },
    {
      "t": 10252,
      "e": 10051,
      "ty": 41,
      "x": 37544,
      "y": 45695,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10302,
      "e": 10101,
      "ty": 2,
      "x": 1313,
      "y": 797
    },
    {
      "t": 10402,
      "e": 10201,
      "ty": 2,
      "x": 1304,
      "y": 822
    },
    {
      "t": 10502,
      "e": 10301,
      "ty": 41,
      "x": 35008,
      "y": 51998,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10502,
      "e": 10301,
      "ty": 2,
      "x": 1286,
      "y": 864
    },
    {
      "t": 10602,
      "e": 10401,
      "ty": 2,
      "x": 1261,
      "y": 918
    },
    {
      "t": 10702,
      "e": 10501,
      "ty": 2,
      "x": 1245,
      "y": 953
    },
    {
      "t": 10752,
      "e": 10551,
      "ty": 41,
      "x": 31625,
      "y": 59590,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10802,
      "e": 10601,
      "ty": 2,
      "x": 1236,
      "y": 973
    },
    {
      "t": 10902,
      "e": 10701,
      "ty": 2,
      "x": 1234,
      "y": 965
    },
    {
      "t": 11002,
      "e": 10801,
      "ty": 41,
      "x": 33175,
      "y": 52571,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11002,
      "e": 10801,
      "ty": 2,
      "x": 1260,
      "y": 872
    },
    {
      "t": 11102,
      "e": 10901,
      "ty": 2,
      "x": 1271,
      "y": 838
    },
    {
      "t": 11202,
      "e": 11001,
      "ty": 2,
      "x": 1281,
      "y": 820
    },
    {
      "t": 11252,
      "e": 11051,
      "ty": 41,
      "x": 34655,
      "y": 48846,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11302,
      "e": 11101,
      "ty": 2,
      "x": 1287,
      "y": 829
    },
    {
      "t": 11402,
      "e": 11201,
      "ty": 2,
      "x": 1319,
      "y": 899
    },
    {
      "t": 11502,
      "e": 11301,
      "ty": 41,
      "x": 39236,
      "y": 58301,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11502,
      "e": 11301,
      "ty": 2,
      "x": 1346,
      "y": 952
    },
    {
      "t": 11602,
      "e": 11401,
      "ty": 2,
      "x": 1350,
      "y": 960
    },
    {
      "t": 11702,
      "e": 11501,
      "ty": 2,
      "x": 1350,
      "y": 918
    },
    {
      "t": 11752,
      "e": 11551,
      "ty": 41,
      "x": 38954,
      "y": 53717,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11802,
      "e": 11601,
      "ty": 2,
      "x": 1334,
      "y": 858
    },
    {
      "t": 11902,
      "e": 11701,
      "ty": 2,
      "x": 1324,
      "y": 813
    },
    {
      "t": 12002,
      "e": 11801,
      "ty": 41,
      "x": 37474,
      "y": 47844,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12002,
      "e": 11801,
      "ty": 2,
      "x": 1321,
      "y": 806
    },
    {
      "t": 12102,
      "e": 11901,
      "ty": 2,
      "x": 1321,
      "y": 789
    },
    {
      "t": 12202,
      "e": 12001,
      "ty": 2,
      "x": 1319,
      "y": 766
    },
    {
      "t": 12252,
      "e": 12051,
      "ty": 41,
      "x": 7992,
      "y": 21845,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[15] > circle"
    },
    {
      "t": 12302,
      "e": 12101,
      "ty": 2,
      "x": 1318,
      "y": 761
    },
    {
      "t": 12402,
      "e": 12201,
      "ty": 2,
      "x": 1371,
      "y": 858
    },
    {
      "t": 12502,
      "e": 12301,
      "ty": 41,
      "x": 42759,
      "y": 55507,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12502,
      "e": 12301,
      "ty": 2,
      "x": 1396,
      "y": 913
    },
    {
      "t": 12602,
      "e": 12401,
      "ty": 2,
      "x": 1410,
      "y": 949
    },
    {
      "t": 12702,
      "e": 12501,
      "ty": 2,
      "x": 1414,
      "y": 962
    },
    {
      "t": 12752,
      "e": 12551,
      "ty": 41,
      "x": 44028,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 12902,
      "e": 12701,
      "ty": 2,
      "x": 1311,
      "y": 930
    },
    {
      "t": 13002,
      "e": 12801,
      "ty": 41,
      "x": 56,
      "y": 40681,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 13002,
      "e": 12801,
      "ty": 2,
      "x": 790,
      "y": 706
    },
    {
      "t": 13102,
      "e": 12901,
      "ty": 2,
      "x": 644,
      "y": 635
    },
    {
      "t": 13202,
      "e": 13001,
      "ty": 2,
      "x": 598,
      "y": 608
    },
    {
      "t": 13252,
      "e": 13051,
      "ty": 41,
      "x": 2162,
      "y": 48383,
      "ta": "#bigset.duration+starts > ul > li:[15]"
    },
    {
      "t": 13302,
      "e": 13101,
      "ty": 2,
      "x": 525,
      "y": 587
    },
    {
      "t": 13402,
      "e": 13201,
      "ty": 2,
      "x": 366,
      "y": 586
    },
    {
      "t": 13502,
      "e": 13301,
      "ty": 41,
      "x": 17801,
      "y": 13469,
      "ta": "#bigset.duration+starts > ul > li:[12] > input"
    },
    {
      "t": 13502,
      "e": 13301,
      "ty": 2,
      "x": 290,
      "y": 585
    },
    {
      "t": 13602,
      "e": 13401,
      "ty": 2,
      "x": 276,
      "y": 588
    },
    {
      "t": 13702,
      "e": 13501,
      "ty": 2,
      "x": 258,
      "y": 588
    },
    {
      "t": 13752,
      "e": 13551,
      "ty": 41,
      "x": 45404,
      "y": 27318,
      "ta": "#bigset.duration+starts > ul > li:[11]"
    },
    {
      "t": 13802,
      "e": 13601,
      "ty": 2,
      "x": 202,
      "y": 587
    },
    {
      "t": 13902,
      "e": 13701,
      "ty": 2,
      "x": 194,
      "y": 585
    },
    {
      "t": 14001,
      "e": 13800,
      "ty": 41,
      "x": 32879,
      "y": 10934,
      "ta": "#bigset.duration+starts > ul > li:[11]"
    },
    {
      "t": 14001,
      "e": 13800,
      "ty": 2,
      "x": 189,
      "y": 581
    },
    {
      "t": 14102,
      "e": 13901,
      "ty": 2,
      "x": 186,
      "y": 581
    },
    {
      "t": 14107,
      "e": 13906,
      "ty": 3,
      "x": 186,
      "y": 581,
      "ta": "#bigset.duration+starts > ul > li:[11]"
    },
    {
      "t": 14234,
      "e": 14033,
      "ty": 4,
      "x": 31089,
      "y": 10934,
      "ta": "#bigset.duration+starts > ul > li:[11]"
    },
    {
      "t": 14234,
      "e": 14033,
      "ty": 5,
      "x": 186,
      "y": 581,
      "ta": "#bigset.duration+starts > ul > li:[11]"
    },
    {
      "t": 14252,
      "e": 14051,
      "ty": 41,
      "x": 31089,
      "y": 10934,
      "ta": "#bigset.duration+starts > ul > li:[11]"
    },
    {
      "t": 14402,
      "e": 14201,
      "ty": 2,
      "x": 192,
      "y": 581
    },
    {
      "t": 14502,
      "e": 14301,
      "ty": 41,
      "x": 42422,
      "y": 10934,
      "ta": "#bigset.duration+starts > ul > li:[11]"
    },
    {
      "t": 14502,
      "e": 14301,
      "ty": 2,
      "x": 205,
      "y": 581
    },
    {
      "t": 14601,
      "e": 14400,
      "ty": 2,
      "x": 190,
      "y": 593
    },
    {
      "t": 14702,
      "e": 14501,
      "ty": 2,
      "x": 184,
      "y": 593
    },
    {
      "t": 14752,
      "e": 14551,
      "ty": 41,
      "x": 27883,
      "y": 53798,
      "ta": "#bigset.duration+starts > ul > li:[11] > input"
    },
    {
      "t": 14794,
      "e": 14593,
      "ty": 3,
      "x": 183,
      "y": 593,
      "ta": "#bigset.duration+starts > ul > li:[11] > input"
    },
    {
      "t": 14794,
      "e": 14593,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.duration+starts > ul > li:[11] > input"
    },
    {
      "t": 14802,
      "e": 14601,
      "ty": 2,
      "x": 183,
      "y": 593
    },
    {
      "t": 14889,
      "e": 14688,
      "ty": 4,
      "x": 27883,
      "y": 53798,
      "ta": "#bigset.duration+starts > ul > li:[11] > input"
    },
    {
      "t": 14890,
      "e": 14689,
      "ty": 5,
      "x": 183,
      "y": 593,
      "ta": "#bigset.duration+starts > ul > li:[11] > input"
    },
    {
      "t": 14890,
      "e": 14689,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.duration+starts > ul > li:[11] > input",
      "v": "X"
    },
    {
      "t": 15102,
      "e": 14901,
      "ty": 2,
      "x": 290,
      "y": 583
    },
    {
      "t": 15202,
      "e": 15001,
      "ty": 2,
      "x": 306,
      "y": 581
    },
    {
      "t": 15252,
      "e": 15051,
      "ty": 41,
      "x": 38321,
      "y": 10934,
      "ta": "#bigset.duration+starts > ul > li:[12]"
    },
    {
      "t": 15302,
      "e": 15101,
      "ty": 2,
      "x": 308,
      "y": 581
    },
    {
      "t": 15402,
      "e": 15201,
      "ty": 2,
      "x": 291,
      "y": 587
    },
    {
      "t": 15502,
      "e": 15301,
      "ty": 41,
      "x": 0,
      "y": 28592,
      "ta": "#bigset.duration+starts > ul > li:[12] > input"
    },
    {
      "t": 15502,
      "e": 15301,
      "ty": 2,
      "x": 286,
      "y": 588
    },
    {
      "t": 15610,
      "e": 15409,
      "ty": 3,
      "x": 286,
      "y": 588,
      "ta": "#bigset.duration+starts > ul > li:[12] > input"
    },
    {
      "t": 15611,
      "e": 15410,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.duration+starts > ul > li:[11] > input"
    },
    {
      "t": 15612,
      "e": 15411,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.duration+starts > ul > li:[12] > input"
    },
    {
      "t": 15737,
      "e": 15536,
      "ty": 4,
      "x": 0,
      "y": 28592,
      "ta": "#bigset.duration+starts > ul > li:[12] > input"
    },
    {
      "t": 15738,
      "e": 15537,
      "ty": 5,
      "x": 286,
      "y": 588,
      "ta": "#bigset.duration+starts > ul > li:[12] > input"
    },
    {
      "t": 15738,
      "e": 15537,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.duration+starts > ul > li:[12] > input",
      "v": "O"
    },
    {
      "t": 16901,
      "e": 16700,
      "ty": 2,
      "x": 314,
      "y": 588
    },
    {
      "t": 17001,
      "e": 16800,
      "ty": 41,
      "x": 6680,
      "y": 32588,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17001,
      "e": 16800,
      "ty": 2,
      "x": 884,
      "y": 593
    },
    {
      "t": 17102,
      "e": 16901,
      "ty": 2,
      "x": 910,
      "y": 591
    },
    {
      "t": 17202,
      "e": 17001,
      "ty": 2,
      "x": 935,
      "y": 593
    },
    {
      "t": 17252,
      "e": 17051,
      "ty": 41,
      "x": 10908,
      "y": 32731,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 17302,
      "e": 17101,
      "ty": 2,
      "x": 944,
      "y": 595
    },
    {
      "t": 17601,
      "e": 17400,
      "ty": 2,
      "x": 716,
      "y": 624
    },
    {
      "t": 17702,
      "e": 17501,
      "ty": 2,
      "x": 645,
      "y": 614
    },
    {
      "t": 17752,
      "e": 17551,
      "ty": 41,
      "x": 58829,
      "y": 54830,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 17801,
      "e": 17600,
      "ty": 2,
      "x": 499,
      "y": 624
    },
    {
      "t": 17902,
      "e": 17701,
      "ty": 2,
      "x": 373,
      "y": 684
    },
    {
      "t": 18001,
      "e": 17800,
      "ty": 41,
      "x": 16059,
      "y": 28280,
      "ta": "#start"
    },
    {
      "t": 18001,
      "e": 17800,
      "ty": 2,
      "x": 368,
      "y": 690
    },
    {
      "t": 18102,
      "e": 17901,
      "ty": 2,
      "x": 369,
      "y": 695
    },
    {
      "t": 18170,
      "e": 17969,
      "ty": 3,
      "x": 369,
      "y": 695,
      "ta": "#start"
    },
    {
      "t": 18171,
      "e": 17970,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.duration+starts > ul > li:[12] > input"
    },
    {
      "t": 18172,
      "e": 17971,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 18252,
      "e": 18051,
      "ty": 41,
      "x": 16605,
      "y": 37917,
      "ta": "#start"
    },
    {
      "t": 18265,
      "e": 18064,
      "ty": 4,
      "x": 16605,
      "y": 37917,
      "ta": "#start"
    },
    {
      "t": 18268,
      "e": 18067,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 18270,
      "e": 18069,
      "ty": 5,
      "x": 369,
      "y": 695,
      "ta": "#start"
    },
    {
      "t": 18274,
      "e": 18073,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 18702,
      "e": 18501,
      "ty": 2,
      "x": 379,
      "y": 687
    },
    {
      "t": 18752,
      "e": 18551,
      "ty": 41,
      "x": 12914,
      "y": 37448,
      "ta": "html > body"
    },
    {
      "t": 18802,
      "e": 18601,
      "ty": 2,
      "x": 386,
      "y": 681
    },
    {
      "t": 18902,
      "e": 18701,
      "ty": 2,
      "x": 388,
      "y": 680
    },
    {
      "t": 19002,
      "e": 18801,
      "ty": 41,
      "x": 13086,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 19002,
      "e": 18801,
      "ty": 2,
      "x": 388,
      "y": 679
    },
    {
      "t": 19290,
      "e": 19089,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1278,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":1269},\"parentNode\":{\"id\":1267}},{\"nodeType\":1,\"id\":1279,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":1278},\"parentNode\":{\"id\":1267}},{\"nodeType\":1,\"id\":1280,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":1279},\"parentNode\":{\"id\":1267}},{\"nodeType\":1,\"id\":1281,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1280},\"parentNode\":{\"id\":1267}},{\"nodeType\":1,\"id\":1282,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":1281},\"parentNode\":{\"id\":1267}},{\"nodeType\":1,\"id\":1283,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1284,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":1283},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1285,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":1284},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1286,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":1285},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1287,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":1286},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1288,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":1287},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1289,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":1288},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1290,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":1289},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1291,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":1290},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1292,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":1291},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1293,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":1292},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1294,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":1293},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1295,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":1294},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1296,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":1295},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1297,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":1296},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1298,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":1297},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1299,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":1298},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1300,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":1299},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1301,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":1300},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1302,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":1301},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1303,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":1302},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1304,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":1303},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":1304},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1306,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":1305},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1307,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":1306},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1308,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":1307},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1309,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":1308},\"parentNode\":{\"id\":1278}},{\"nodeType\":1,\"id\":1310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1284}},{\"nodeType\":1,\"id\":1311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1310},\"parentNode\":{\"id\":1284}},{\"nodeType\":1,\"id\":1312,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1285}},{\"nodeType\":1,\"id\":1313,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1312},\"parentNode\":{\"id\":1285}},{\"nodeType\":1,\"id\":1314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1286}},{\"nodeType\":1,\"id\":1315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1314},\"parentNode\":{\"id\":1286}},{\"nodeType\":1,\"id\":1316,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1287}},{\"nodeType\":1,\"id\":1317,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1316},\"parentNode\":{\"id\":1287}},{\"nodeType\":1,\"id\":1318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1288}},{\"nodeType\":1,\"id\":1319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1318},\"parentNode\":{\"id\":1288}},{\"nodeType\":1,\"id\":1320,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1289}},{\"nodeType\":1,\"id\":1321,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1320},\"parentNode\":{\"id\":1289}},{\"nodeType\":1,\"id\":1322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1290}},{\"nodeType\":1,\"id\":1323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1322},\"parentNode\":{\"id\":1290}},{\"nodeType\":1,\"id\":1324,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1291}},{\"nodeType\":1,\"id\":1325,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1324},\"parentNode\":{\"id\":1291}},{\"nodeType\":1,\"id\":1326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1292}},{\"nodeType\":1,\"id\":1327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1326},\"parentNode\":{\"id\":1292}},{\"nodeType\":1,\"id\":1328,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1293}},{\"nodeType\":1,\"id\":1329,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1328},\"parentNode\":{\"id\":1293}},{\"nodeType\":1,\"id\":1330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1294}},{\"nodeType\":1,\"id\":1331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1330},\"parentNode\":{\"id\":1294}},{\"nodeType\":1,\"id\":1332,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1295}},{\"nodeType\":1,\"id\":1333,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1332},\"parentNode\":{\"id\":1295}},{\"nodeType\":1,\"id\":1334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1296}},{\"nodeType\":1,\"id\":1335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1334},\"parentNode\":{\"id\":1296}},{\"nodeType\":1,\"id\":1336,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1297}},{\"nodeType\":1,\"id\":1337,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1336},\"parentNode\":{\"id\":1297}},{\"nodeType\":1,\"id\":1338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1298}},{\"nodeType\":1,\"id\":1339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1338},\"parentNode\":{\"id\":1298}},{\"nodeType\":1,\"id\":1340,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1299}},{\"nodeType\":1,\"id\":1341,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1340},\"parentNode\":{\"id\":1299}},{\"nodeType\":1,\"id\":1342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1300}},{\"nodeType\":1,\"id\":1343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1342},\"parentNode\":{\"id\":1300}},{\"nodeType\":1,\"id\":1344,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1301}},{\"nodeType\":1,\"id\":1345,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1344},\"parentNode\":{\"id\":1301}},{\"nodeType\":1,\"id\":1346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1302}},{\"nodeType\":1,\"id\":1347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1346},\"parentNode\":{\"id\":1302}},{\"nodeType\":1,\"id\":1348,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1303}},{\"nodeType\":1,\"id\":1349,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1348},\"parentNode\":{\"id\":1303}},{\"nodeType\":1,\"id\":1350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1304}},{\"nodeType\":1,\"id\":1351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1350},\"parentNode\":{\"id\":1304}},{\"nodeType\":1,\"id\":1352,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1305}},{\"nodeType\":1,\"id\":1353,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1352},\"parentNode\":{\"id\":1305}},{\"nodeType\":1,\"id\":1354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1306}},{\"nodeType\":1,\"id\":1355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1354},\"parentNode\":{\"id\":1306}},{\"nodeType\":1,\"id\":1356,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1307}},{\"nodeType\":1,\"id\":1357,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":1356},\"parentNode\":{\"id\":1307}},{\"nodeType\":1,\"id\":1358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"},\"parentNode\":{\"id\":1308}},{\"nodeType\":1,\"id\":1359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":1358},\"parentNode\":{\"id\":1308}},{\"nodeType\":3,\"id\":1360,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":1311}},{\"nodeType\":3,\"id\":1361,\"textContent\":\"08:30\",\"parentNode\":{\"id\":1313}},{\"nodeType\":3,\"id\":1362,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":1315}},{\"nodeType\":3,\"id\":1363,\"textContent\":\"09:30\",\"parentNode\":{\"id\":1317}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":1319}},{\"nodeType\":3,\"id\":1365,\"textContent\":\"10:30\",\"parentNode\":{\"id\":1321}},{\"nodeType\":3,\"id\":1366,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":1323}},{\"nodeType\":3,\"id\":1367,\"textContent\":\"11:30\",\"parentNode\":{\"id\":1325}},{\"nodeType\":3,\"id\":1368,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":1327}},{\"nodeType\":3,\"id\":1369,\"textContent\":\"12:30\",\"parentNode\":{\"id\":1329}},{\"nodeType\":3,\"id\":1370,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":1331}},{\"nodeType\":3,\"id\":1371,\"textContent\":\"01:30\",\"parentNode\":{\"id\":1333}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":1335}},{\"nodeType\":3,\"id\":1373,\"textContent\":\"02:30\",\"parentNode\":{\"id\":1337}},{\"nodeType\":3,\"id\":1374,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":1339}},{\"nodeType\":3,\"id\":1375,\"textContent\":\"03:30\",\"parentNode\":{\"id\":1341}},{\"nodeType\":3,\"id\":1376,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":1343}},{\"nodeType\":3,\"id\":1377,\"textContent\":\"04:30\",\"parentNode\":{\"id\":1345}},{\"nodeType\":3,\"id\":1378,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":1347}},{\"nodeType\":3,\"id\":1379,\"textContent\":\"05:30\",\"parentNode\":{\"id\":1349}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":1351}},{\"nodeType\":3,\"id\":1381,\"textContent\":\"06:30\",\"parentNode\":{\"id\":1353}},{\"nodeType\":3,\"id\":1382,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":1355}},{\"nodeType\":3,\"id\":1383,\"textContent\":\"07:30\",\"parentNode\":{\"id\":1357}},{\"nodeType\":3,\"id\":1384,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":1359}},{\"nodeType\":1,\"id\":1385,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":1309}},{\"nodeType\":3,\"id\":1386,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":1385}},{\"nodeType\":1,\"id\":1387,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1388,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":1387},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1389,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":1388},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1390,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":1389},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1391,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":1390},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1392,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":1391},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1393,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":1392},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1394,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":1393},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1395,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":1394},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1396,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":1395},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1397,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":1396},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1398,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":1397},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1399,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":1398},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1400,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":1399},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1401,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":1400},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1402,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":1401},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1403,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":1402},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1404,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":1403},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1405,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":1404},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1406,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":1405},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1407,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":1406},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1408,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":1407},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1409,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":1408},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1410,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":1409},\"parentNode\":{\"id\":1279}},{\"nodeType\":1,\"id\":1411,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1412,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":1411},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1413,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":1412},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":1413},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1415,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":1414},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1416,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":1415},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1417,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":1416},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":1417},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1419,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":1418},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1420,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":1419},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":1420},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":1421},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":1422},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":1423},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1425,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":1424},\"parentNode\":{\"id\":1280}},{\"nodeType\":1,\"id\":1426,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1412}},{\"nodeType\":1,\"id\":1427,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1426},\"parentNode\":{\"id\":1412}},{\"nodeType\":1,\"id\":1428,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1413}},{\"nodeType\":1,\"id\":1429,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1428},\"parentNode\":{\"id\":1413}},{\"nodeType\":1,\"id\":1430,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1414}},{\"nodeType\":1,\"id\":1431,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1430},\"parentNode\":{\"id\":1414}},{\"nodeType\":1,\"id\":1432,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1415}},{\"nodeType\":1,\"id\":1433,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1432},\"parentNode\":{\"id\":1415}},{\"nodeType\":1,\"id\":1434,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1416}},{\"nodeType\":1,\"id\":1435,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1434},\"parentNode\":{\"id\":1416}},{\"nodeType\":1,\"id\":1436,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1417}},{\"nodeType\":1,\"id\":1437,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1436},\"parentNode\":{\"id\":1417}},{\"nodeType\":1,\"id\":1438,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1418}},{\"nodeType\":1,\"id\":1439,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1438},\"parentNode\":{\"id\":1418}},{\"nodeType\":1,\"id\":1440,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1419}},{\"nodeType\":1,\"id\":1441,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1440},\"parentNode\":{\"id\":1419}},{\"nodeType\":1,\"id\":1442,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1420}},{\"nodeType\":1,\"id\":1443,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1442},\"parentNode\":{\"id\":1420}},{\"nodeType\":1,\"id\":1444,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1421}},{\"nodeType\":1,\"id\":1445,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1444},\"parentNode\":{\"id\":1421}},{\"nodeType\":1,\"id\":1446,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1422}},{\"nodeType\":1,\"id\":1447,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1446},\"parentNode\":{\"id\":1422}},{\"nodeType\":1,\"id\":1448,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1423}},{\"nodeType\":1,\"id\":1449,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1448},\"parentNode\":{\"id\":1423}},{\"nodeType\":1,\"id\":1450,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":1424}},{\"nodeType\":1,\"id\":1451,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":1450},\"parentNode\":{\"id\":1424}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"0\",\"parentNode\":{\"id\":1427}},{\"nodeType\":3,\"id\":1453,\"textContent\":\"1\",\"parentNode\":{\"id\":1429}},{\"nodeType\":3,\"id\":1454,\"textContent\":\"2\",\"parentNode\":{\"id\":1431}},{\"nodeType\":3,\"id\":1455,\"textContent\":\"3\",\"parentNode\":{\"id\":1433}},{\"nodeType\":3,\"id\":1456,\"textContent\":\"4\",\"parentNode\":{\"id\":1435}},{\"nodeType\":3,\"id\":1457,\"textContent\":\"5\",\"parentNode\":{\"id\":1437}},{\"nodeType\":3,\"id\":1458,\"textContent\":\"6\",\"parentNode\":{\"id\":1439}},{\"nodeType\":3,\"id\":1459,\"textContent\":\"7\",\"parentNode\":{\"id\":1441}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"8\",\"parentNode\":{\"id\":1443}},{\"nodeType\":3,\"id\":1461,\"textContent\":\"9\",\"parentNode\":{\"id\":1445}},{\"nodeType\":3,\"id\":1462,\"textContent\":\"10\",\"parentNode\":{\"id\":1447}},{\"nodeType\":3,\"id\":1463,\"textContent\":\"11\",\"parentNode\":{\"id\":1449}},{\"nodeType\":3,\"id\":1464,\"textContent\":\"12\",\"parentNode\":{\"id\":1451}},{\"nodeType\":1,\"id\":1465,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":1425}},{\"nodeType\":3,\"id\":1466,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":1465}},{\"nodeType\":1,\"id\":1467,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1467},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1469,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1468},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1469},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1471,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1470},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1471},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1473,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1472},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1473},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1475,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1474},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1475},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1476},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":1477},\"parentNode\":{\"id\":1281}},{\"nodeType\":1,\"id\":1479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":1467}},{\"nodeType\":1,\"id\":1480,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":1468}},{\"nodeType\":1,\"id\":1481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":1469}},{\"nodeType\":1,\"id\":1482,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":1470}},{\"nodeType\":1,\"id\":1483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":1471}},{\"nodeType\":1,\"id\":1484,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":1472}},{\"nodeType\":1,\"id\":1485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":1473}},{\"nodeType\":1,\"id\":1486,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":1474}},{\"nodeType\":1,\"id\":1487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":1475}},{\"nodeType\":1,\"id\":1488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":1476}},{\"nodeType\":1,\"id\":1489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":1477}},{\"nodeType\":1,\"id\":1490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":1478}},{\"nodeType\":1,\"id\":1491,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1492,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1491},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1493,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1492},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1494,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1493},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1495,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1494},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1496,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1495},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1497,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1496},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1498,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1497},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1499,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1498},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1500,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1499},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1501,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1500},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1502,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1501},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1503,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1502},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1504,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1503},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1505,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1504},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1506,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1505},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1507,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1506},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1508,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":1507},\"parentNode\":{\"id\":1282}},{\"nodeType\":1,\"id\":1509,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1491}},{\"nodeType\":1,\"id\":1510,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":1509},\"parentNode\":{\"id\":1491}},{\"nodeType\":1,\"id\":1511,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1492}},{\"nodeType\":1,\"id\":1512,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":1511},\"parentNode\":{\"id\":1492}},{\"nodeType\":1,\"id\":1513,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1493}},{\"nodeType\":1,\"id\":1514,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":1513},\"parentNode\":{\"id\":1493}},{\"nodeType\":1,\"id\":1515,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1494}},{\"nodeType\":1,\"id\":1516,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":1515},\"parentNode\":{\"id\":1494}},{\"nodeType\":1,\"id\":1517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1495}},{\"nodeType\":1,\"id\":1518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":1517},\"parentNode\":{\"id\":1495}},{\"nodeType\":1,\"id\":1519,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1496}},{\"nodeType\":1,\"id\":1520,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":1519},\"parentNode\":{\"id\":1496}},{\"nodeType\":1,\"id\":1521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1497}},{\"nodeType\":1,\"id\":1522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":1521},\"parentNode\":{\"id\":1497}},{\"nodeType\":1,\"id\":1523,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1498}},{\"nodeType\":1,\"id\":1524,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":1523},\"parentNode\":{\"id\":1498}},{\"nodeType\":1,\"id\":1525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1499}},{\"nodeType\":1,\"id\":1526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":1525},\"parentNode\":{\"id\":1499}},{\"nodeType\":1,\"id\":1527,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1500}},{\"nodeType\":1,\"id\":1528,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":1527},\"parentNode\":{\"id\":1500}},{\"nodeType\":1,\"id\":1529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1501}},{\"nodeType\":1,\"id\":1530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":1529},\"parentNode\":{\"id\":1501}},{\"nodeType\":1,\"id\":1531,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1502}},{\"nodeType\":1,\"id\":1532,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":1531},\"parentNode\":{\"id\":1502}},{\"nodeType\":1,\"id\":1533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1503}},{\"nodeType\":1,\"id\":1534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":1533},\"parentNode\":{\"id\":1503}},{\"nodeType\":1,\"id\":1535,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1504}},{\"nodeType\":1,\"id\":1536,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":1535},\"parentNode\":{\"id\":1504}},{\"nodeType\":1,\"id\":1537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1505}},{\"nodeType\":1,\"id\":1538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":1537},\"parentNode\":{\"id\":1505}},{\"nodeType\":1,\"id\":1539,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1506}},{\"nodeType\":1,\"id\":1540,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":1539},\"parentNode\":{\"id\":1506}},{\"nodeType\":1,\"id\":1541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1507}},{\"nodeType\":1,\"id\":1542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":1541},\"parentNode\":{\"id\":1507}},{\"nodeType\":1,\"id\":1543,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":1508}},{\"nodeType\":1,\"id\":1544,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":1543},\"parentNode\":{\"id\":1508}},{\"nodeType\":3,\"id\":1545,\"textContent\":\"A \",\"parentNode\":{\"id\":1510}},{\"nodeType\":3,\"id\":1546,\"textContent\":\"B \",\"parentNode\":{\"id\":1512}},{\"nodeType\":3,\"id\":1547,\"textContent\":\"C \",\"parentNode\":{\"id\":1514}},{\"nodeType\":3,\"id\":1548,\"textContent\":\"D \",\"parentNode\":{\"id\":1516}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"E \",\"parentNode\":{\"id\":1518}},{\"nodeType\":3,\"id\":1550,\"textContent\":\"F \",\"parentNode\":{\"id\":1520}},{\"nodeType\":3,\"id\":1551,\"textContent\":\"G \",\"parentNode\":{\"id\":1522}},{\"nodeType\":3,\"id\":1552,\"textContent\":\"H \",\"parentNode\":{\"id\":1524}},{\"nodeType\":3,\"id\":1553,\"textContent\":\"I \",\"parentNode\":{\"id\":1526}},{\"nodeType\":3,\"id\":1554,\"textContent\":\"J \",\"parentNode\":{\"id\":1528}},{\"nodeType\":3,\"id\":1555,\"textContent\":\"K \",\"parentNode\":{\"id\":1530}},{\"nodeType\":3,\"id\":1556,\"textContent\":\"L \",\"parentNode\":{\"id\":1532}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \",\"parentNode\":{\"id\":1534}},{\"nodeType\":3,\"id\":1558,\"textContent\":\"N \",\"parentNode\":{\"id\":1536}},{\"nodeType\":3,\"id\":1559,\"textContent\":\"O \",\"parentNode\":{\"id\":1538}},{\"nodeType\":3,\"id\":1560,\"textContent\":\"P \",\"parentNode\":{\"id\":1540}},{\"nodeType\":3,\"id\":1561,\"textContent\":\"Z \",\"parentNode\":{\"id\":1542}},{\"nodeType\":3,\"id\":1562,\"textContent\":\"X \",\"parentNode\":{\"id\":1544}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":54},{\"id\":55},{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1278},{\"id\":1283},{\"id\":1284},{\"id\":1310},{\"id\":1311},{\"id\":1360},{\"id\":1285},{\"id\":1312},{\"id\":1313},{\"id\":1361},{\"id\":1286},{\"id\":1314},{\"id\":1315},{\"id\":1362},{\"id\":1287},{\"id\":1316},{\"id\":1317},{\"id\":1363},{\"id\":1288},{\"id\":1318},{\"id\":1319},{\"id\":1364},{\"id\":1289},{\"id\":1320},{\"id\":1321},{\"id\":1365},{\"id\":1290},{\"id\":1322},{\"id\":1323},{\"id\":1366},{\"id\":1291},{\"id\":1324},{\"id\":1325},{\"id\":1367},{\"id\":1292},{\"id\":1326},{\"id\":1327},{\"id\":1368},{\"id\":1293},{\"id\":1328},{\"id\":1329},{\"id\":1369},{\"id\":1294},{\"id\":1330},{\"id\":1331},{\"id\":1370},{\"id\":1295},{\"id\":1332},{\"id\":1333},{\"id\":1371},{\"id\":1296},{\"id\":1334},{\"id\":1335},{\"id\":1372},{\"id\":1297},{\"id\":1336},{\"id\":1337},{\"id\":1373},{\"id\":1298},{\"id\":1338},{\"id\":1339},{\"id\":1374},{\"id\":1299},{\"id\":1340},{\"id\":1341},{\"id\":1375},{\"id\":1300},{\"id\":1342},{\"id\":1343},{\"id\":1376},{\"id\":1301},{\"id\":1344},{\"id\":1345},{\"id\":1377},{\"id\":1302},{\"id\":1346},{\"id\":1347},{\"id\":1378},{\"id\":1303},{\"id\":1348},{\"id\":1349},{\"id\":1379},{\"id\":1304},{\"id\":1350},{\"id\":1351},{\"id\":1380},{\"id\":1305},{\"id\":1352},{\"id\":1353},{\"id\":1381},{\"id\":1306},{\"id\":1354},{\"id\":1355},{\"id\":1382},{\"id\":1307},{\"id\":1356},{\"id\":1357},{\"id\":1383},{\"id\":1308},{\"id\":1358},{\"id\":1359},{\"id\":1384},{\"id\":1309},{\"id\":1385},{\"id\":1386},{\"id\":1279},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1280},{\"id\":1411},{\"id\":1412},{\"id\":1426},{\"id\":1427},{\"id\":1452},{\"id\":1413},{\"id\":1428},{\"id\":1429},{\"id\":1453},{\"id\":1414},{\"id\":1430},{\"id\":1431},{\"id\":1454},{\"id\":1415},{\"id\":1432},{\"id\":1433},{\"id\":1455},{\"id\":1416},{\"id\":1434},{\"id\":1435},{\"id\":1456},{\"id\":1417},{\"id\":1436},{\"id\":1437},{\"id\":1457},{\"id\":1418},{\"id\":1438},{\"id\":1439},{\"id\":1458},{\"id\":1419},{\"id\":1440},{\"id\":1441},{\"id\":1459},{\"id\":1420},{\"id\":1442},{\"id\":1443},{\"id\":1460},{\"id\":1421},{\"id\":1444},{\"id\":1445},{\"id\":1461},{\"id\":1422},{\"id\":1446},{\"id\":1447},{\"id\":1462},{\"id\":1423},{\"id\":1448},{\"id\":1449},{\"id\":1463},{\"id\":1424},{\"id\":1450},{\"id\":1451},{\"id\":1464},{\"id\":1425},{\"id\":1465},{\"id\":1466},{\"id\":1281},{\"id\":1467},{\"id\":1479},{\"id\":1468},{\"id\":1480},{\"id\":1469},{\"id\":1481},{\"id\":1470},{\"id\":1482},{\"id\":1471},{\"id\":1483},{\"id\":1472},{\"id\":1484},{\"id\":1473},{\"id\":1485},{\"id\":1474},{\"id\":1486},{\"id\":1475},{\"id\":1487},{\"id\":1476},{\"id\":1488},{\"id\":1477},{\"id\":1489},{\"id\":1478},{\"id\":1490},{\"id\":1282},{\"id\":1491},{\"id\":1509},{\"id\":1510},{\"id\":1545},{\"id\":1492},{\"id\":1511},{\"id\":1512},{\"id\":1546},{\"id\":1493},{\"id\":1513},{\"id\":1514},{\"id\":1547},{\"id\":1494},{\"id\":1515},{\"id\":1516},{\"id\":1548},{\"id\":1495},{\"id\":1517},{\"id\":1518},{\"id\":1549},{\"id\":1496},{\"id\":1519},{\"id\":1520},{\"id\":1550},{\"id\":1497},{\"id\":1521},{\"id\":1522},{\"id\":1551},{\"id\":1498},{\"id\":1523},{\"id\":1524},{\"id\":1552},{\"id\":1499},{\"id\":1525},{\"id\":1526},{\"id\":1553},{\"id\":1500},{\"id\":1527},{\"id\":1528},{\"id\":1554},{\"id\":1501},{\"id\":1529},{\"id\":1530},{\"id\":1555},{\"id\":1502},{\"id\":1531},{\"id\":1532},{\"id\":1556},{\"id\":1503},{\"id\":1533},{\"id\":1534},{\"id\":1557},{\"id\":1504},{\"id\":1535},{\"id\":1536},{\"id\":1558},{\"id\":1505},{\"id\":1537},{\"id\":1538},{\"id\":1559},{\"id\":1506},{\"id\":1539},{\"id\":1540},{\"id\":1560},{\"id\":1507},{\"id\":1541},{\"id\":1542},{\"id\":1561},{\"id\":1508},{\"id\":1543},{\"id\":1544},{\"id\":1562},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"nodeType\":3,\"id\":1563,\"textContent\":\" $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"full\\\"; } else if (axis == 2){ axis = \\\"partial\\\"; } else if (axis ==3){ axis = \\\"diagonal\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":1275},{\"id\":1276},{\"nodeType\":3,\"id\":1564,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":1277}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":1,\"id\":53,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":8,\"id\":57},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\"B2WUH\"}]},{\"nodeType\":3,\"id\":75,\"textContent\":\" \"},{\"nodeType\":1,\"id\":76,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":8,\"id\":78},{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":1,\"id\":80,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\"Hint: hover your mouse over the data points for help\"}]},{\"nodeType\":3,\"id\":84,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":85,\"textContent\":\" \"},{\"nodeType\":8,\"id\":86},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":1,\"id\":90,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":96,\"textContent\":\" \"},{\"nodeType\":1,\"id\":97,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":100,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":101,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":103,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":106,\"textContent\":\" \"},{\"nodeType\":1,\"id\":107,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":108,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":109,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":111,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":114,\"textContent\":\" \"},{\"nodeType\":1,\"id\":115,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":116,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":117,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":119,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":122,\"textContent\":\" \"},{\"nodeType\":1,\"id\":123,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":124,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":125,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":127,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":130,\"textContent\":\" \"},{\"nodeType\":1,\"id\":131,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":132,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":133,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":135,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":138,\"textContent\":\" \"},{\"nodeType\":1,\"id\":139,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":140,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":141,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":143,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":146,\"textContent\":\" \"},{\"nodeType\":1,\"id\":147,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":148,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":149,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":151,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":154,\"textContent\":\" \"},{\"nodeType\":1,\"id\":155,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":156,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":157,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":158,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":159,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":161,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":162,\"textContent\":\" \"},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":164,\"textContent\":\"Which shift(s) start with D?\"}]},{\"nodeType\":3,\"id\":165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":166,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":170,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"},{\"nodeType\":1,\"id\":172,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":173,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":174,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":178,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"},{\"nodeType\":1,\"id\":180,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":181,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":182,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":186,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"},{\"nodeType\":1,\"id\":188,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":189,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":190,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":194,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"},{\"nodeType\":1,\"id\":196,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":197,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":198,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":201,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":202,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"},{\"nodeType\":1,\"id\":204,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":205,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":206,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":209,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":210,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"},{\"nodeType\":1,\"id\":212,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":213,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":214,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":217,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":218,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"},{\"nodeType\":1,\"id\":220,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":221,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":222,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":224,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":225,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":226,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":228,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":232,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":233,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":236,\"textContent\":\" \"},{\"nodeType\":1,\"id\":237,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":238,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":239,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":243,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"},{\"nodeType\":1,\"id\":245,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":246,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":247,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":251,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"},{\"nodeType\":1,\"id\":253,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":254,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":255,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":259,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"},{\"nodeType\":1,\"id\":261,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":262,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":263,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":267,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"},{\"nodeType\":1,\"id\":269,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":270,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":271,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":275,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"},{\"nodeType\":1,\"id\":277,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":278,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":279,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":283,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"},{\"nodeType\":1,\"id\":285,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":286,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":287,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":291,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"},{\"nodeType\":1,\"id\":293,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":294,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":295,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":296,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":297,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":300,\"textContent\":\" \"},{\"nodeType\":1,\"id\":301,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":302,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":303,\"textContent\":\" \"},{\"nodeType\":1,\"id\":304,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":306,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":307,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":312,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":314,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":315,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":320,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":322,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":323,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":328,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":330,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":331,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":336,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":338,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":339,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":344,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":346,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":347,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"},{\"nodeType\":1,\"id\":350,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":351,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":352,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":355,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":356,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":358,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":359,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":360,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":364,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":368,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":371,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":372,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":373,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":376,\"textContent\":\" \"},{\"nodeType\":1,\"id\":377,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":380,\"textContent\":\" \"},{\"nodeType\":1,\"id\":381,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":382,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":383,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":384,\"textContent\":\" \"},{\"nodeType\":1,\"id\":385,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":388,\"textContent\":\" \"},{\"nodeType\":1,\"id\":389,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":390,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":391,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":392,\"textContent\":\" \"},{\"nodeType\":1,\"id\":393,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":396,\"textContent\":\" \"},{\"nodeType\":1,\"id\":397,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":398,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":399,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":400,\"textContent\":\" \"},{\"nodeType\":1,\"id\":401,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":404,\"textContent\":\" \"},{\"nodeType\":1,\"id\":405,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":406,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":407,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":408,\"textContent\":\" \"},{\"nodeType\":1,\"id\":409,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":412,\"textContent\":\" \"},{\"nodeType\":1,\"id\":413,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":414,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":415,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":416,\"textContent\":\" \"},{\"nodeType\":1,\"id\":417,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":420,\"textContent\":\" \"},{\"nodeType\":1,\"id\":421,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":422,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":423,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":424,\"textContent\":\" \"},{\"nodeType\":1,\"id\":425,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":428,\"textContent\":\" \"},{\"nodeType\":1,\"id\":429,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":430,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":431,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":432,\"textContent\":\" \"},{\"nodeType\":1,\"id\":433,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":436,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":440,\"textContent\":\" \"},{\"nodeType\":1,\"id\":441,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":442,\"textContent\":\"Which shifts are six hours long?\"}]},{\"nodeType\":3,\"id\":443,\"textContent\":\" \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":445,\"textContent\":\" \"},{\"nodeType\":1,\"id\":446,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":447,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":448,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":452,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"},{\"nodeType\":1,\"id\":454,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":455,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":456,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":460,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"},{\"nodeType\":1,\"id\":462,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":463,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":464,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":468,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"},{\"nodeType\":1,\"id\":470,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":471,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":472,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":476,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"},{\"nodeType\":1,\"id\":478,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":479,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":480,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":481,\"textContent\":\" \"},{\"nodeType\":1,\"id\":482,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":484,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":487,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":488,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":489,\"textContent\":\" \"},{\"nodeType\":1,\"id\":490,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":493,\"textContent\":\" \"},{\"nodeType\":1,\"id\":494,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":495,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":496,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":497,\"textContent\":\" \"},{\"nodeType\":1,\"id\":498,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":501,\"textContent\":\" \"},{\"nodeType\":1,\"id\":502,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":503,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":504,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":506,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":509,\"textContent\":\" \"},{\"nodeType\":1,\"id\":510,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":511,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":512,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":513,\"textContent\":\" \"},{\"nodeType\":1,\"id\":514,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":517,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":521,\"textContent\":\" \"},{\"nodeType\":1,\"id\":522,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":523,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":524,\"textContent\":\" \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":526,\"textContent\":\" \"},{\"nodeType\":1,\"id\":527,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":528,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":529,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":533,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"},{\"nodeType\":1,\"id\":535,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":536,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":537,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":541,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"},{\"nodeType\":1,\"id\":543,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":544,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":545,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":549,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"},{\"nodeType\":1,\"id\":551,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":552,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":553,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":557,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"},{\"nodeType\":1,\"id\":559,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":560,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":561,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":565,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"},{\"nodeType\":1,\"id\":567,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":568,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":569,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":573,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"},{\"nodeType\":1,\"id\":575,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":576,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":577,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":581,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"},{\"nodeType\":1,\"id\":583,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":584,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":585,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":589,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"},{\"nodeType\":1,\"id\":591,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":592,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":593,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":597,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":601,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":604,\"textContent\":\"Which shift under 7 hours long starts before B and ends after X?\"}]},{\"nodeType\":3,\"id\":605,\"textContent\":\" \"},{\"nodeType\":1,\"id\":606,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":607,\"textContent\":\" \"},{\"nodeType\":1,\"id\":608,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":609,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":610,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":613,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":614,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":615,\"textContent\":\" \"},{\"nodeType\":1,\"id\":616,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":617,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":618,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":620,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":621,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":622,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":623,\"textContent\":\" \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":625,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":626,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":628,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":630,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":631,\"textContent\":\" \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":634,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":636,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":637,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":638,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":639,\"textContent\":\" \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":642,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":644,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":645,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":646,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":647,\"textContent\":\" \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":649,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":650,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":652,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":654,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":655,\"textContent\":\" \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":657,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":658,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":660,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":662,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":666,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":667,\"textContent\":\" \"},{\"nodeType\":1,\"id\":668,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":670,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":671,\"textContent\":\" \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":674,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":675,\"textContent\":\" \"},{\"nodeType\":1,\"id\":676,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":678,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":679,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":680,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":682,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":683,\"textContent\":\" \"},{\"nodeType\":1,\"id\":684,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\"Which shift begins before J and ends during B?\"}]},{\"nodeType\":3,\"id\":686,\"textContent\":\" \"},{\"nodeType\":1,\"id\":687,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":688,\"textContent\":\" \"},{\"nodeType\":1,\"id\":689,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":691,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":693,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":696,\"textContent\":\" \"},{\"nodeType\":1,\"id\":697,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":698,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":699,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":701,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":704,\"textContent\":\" \"},{\"nodeType\":1,\"id\":705,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":706,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":707,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":709,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":712,\"textContent\":\" \"},{\"nodeType\":1,\"id\":713,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":714,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":715,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":717,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":720,\"textContent\":\" \"},{\"nodeType\":1,\"id\":721,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":722,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":723,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":725,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":728,\"textContent\":\" \"},{\"nodeType\":1,\"id\":729,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":730,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":731,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":733,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":736,\"textContent\":\" \"},{\"nodeType\":1,\"id\":737,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":738,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":739,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":742,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":743,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":744,\"textContent\":\" \"},{\"nodeType\":1,\"id\":745,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":746,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":747,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":749,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":750,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":751,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":752,\"textContent\":\" \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":754,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":755,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":757,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":758,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":759,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":760,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":761,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"},{\"nodeType\":1,\"id\":763,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":765,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\"Which shift ends with F?\"}]},{\"nodeType\":3,\"id\":767,\"textContent\":\" \"},{\"nodeType\":1,\"id\":768,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":770,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":771,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":772,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":773,\"textContent\":\" \"},{\"nodeType\":1,\"id\":774,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":778,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":779,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":780,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":781,\"textContent\":\" \"},{\"nodeType\":1,\"id\":782,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":786,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":787,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":788,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":789,\"textContent\":\" \"},{\"nodeType\":1,\"id\":790,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":794,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":795,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":796,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":797,\"textContent\":\" \"},{\"nodeType\":1,\"id\":798,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":802,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":803,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":804,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":805,\"textContent\":\" \"},{\"nodeType\":1,\"id\":806,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":809,\"textContent\":\" \"},{\"nodeType\":1,\"id\":810,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":811,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":812,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":814,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":817,\"textContent\":\" \"},{\"nodeType\":1,\"id\":818,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":819,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":820,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":822,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":825,\"textContent\":\" \"},{\"nodeType\":1,\"id\":826,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":827,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":828,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":830,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":833,\"textContent\":\" \"},{\"nodeType\":1,\"id\":834,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":835,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":836,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":838,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":841,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":846,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":847,\"textContent\":\"Which shifts start at 12pm?\"}]},{\"nodeType\":3,\"id\":848,\"textContent\":\" \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":851,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":852,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":853,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":856,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":857,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":859,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":860,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":861,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":864,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":865,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":867,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":868,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":869,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":872,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":873,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":875,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":876,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":877,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":880,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":881,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":883,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":884,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":885,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":888,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":889,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":891,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":892,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":893,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":895,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":896,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":897,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":900,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":901,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":902,\"textContent\":\" \"},{\"nodeType\":1,\"id\":903,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":907,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":908,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":909,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":910,\"textContent\":\" \"},{\"nodeType\":1,\"id\":911,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":915,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":916,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":917,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":918,\"textContent\":\" \"},{\"nodeType\":1,\"id\":919,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":922,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":926,\"textContent\":\" \"},{\"nodeType\":1,\"id\":927,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":928,\"textContent\":\"Which shift starts with F?\"}]},{\"nodeType\":3,\"id\":929,\"textContent\":\" \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":931,\"textContent\":\" \"},{\"nodeType\":1,\"id\":932,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":933,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":934,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":937,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":938,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"},{\"nodeType\":1,\"id\":940,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":941,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":942,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":945,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":946,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"},{\"nodeType\":1,\"id\":948,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":949,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":950,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":953,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":954,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"},{\"nodeType\":1,\"id\":956,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":957,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":958,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":961,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":962,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"},{\"nodeType\":1,\"id\":964,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":965,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":966,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":969,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":970,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":972,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":973,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":974,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":977,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":978,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":980,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":981,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":982,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":985,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":986,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":988,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":989,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":990,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":993,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":994,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":996,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":997,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":998,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1001,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1002,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1005,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1006,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1009,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1010,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1011,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1015,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1016,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1017,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1018,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1023,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1024,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1025,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1026,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1031,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1032,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1033,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1034,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1039,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1040,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1041,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1042,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1045,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1046,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1047,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1050,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1051,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1053,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1054,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1055,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1058,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1059,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1061,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1062,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1063,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1066,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1067,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1069,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1070,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1071,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1074,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1075,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1077,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1078,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1079,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1082,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1083,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1087,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1090,\"textContent\":\"Which shift ends at 3pm?\"}]},{\"nodeType\":3,\"id\":1091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1092,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1096,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1097,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1098,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1099,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1104,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1105,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1106,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1107,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1112,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1113,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1114,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1115,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1120,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1121,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1122,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1123,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1128,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1130,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1131,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1136,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1138,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1139,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1144,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1146,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1147,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1152,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1154,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1155,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1160,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1162,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1163,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1166,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1168,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1170,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1171,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":1172,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":1173,\"textContent\":\"Which 2 shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":1174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1175,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1179,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1181,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1182,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1183,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1187,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1189,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1190,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1191,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1195,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1197,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1198,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1199,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1201,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1203,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1206,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1207,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1208,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1209,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1213,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1214,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1215,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1216,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1217,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1220,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1221,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1222,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1223,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1225,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1228,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1229,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1230,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1231,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1233,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1236,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1237,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1238,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1239,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1241,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1244,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1245,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1246,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1247,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1248,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1250,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1251,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1252},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1254},{\"nodeType\":3,\"id\":1255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1256,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"start\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":1259,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":1260,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1263},{\"nodeType\":3,\"id\":1264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1265,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":1266,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":1267,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1268,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":1269,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1271,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1272},{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":1275,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 134, dom: 635, initialDom: 755",
  "javascriptErrors": []
}