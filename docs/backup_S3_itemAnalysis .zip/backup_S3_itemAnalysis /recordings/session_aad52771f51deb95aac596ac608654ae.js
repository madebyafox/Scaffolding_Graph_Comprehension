var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "eb6fed74ae4f8327bea49c5ce5aa3f6d",
  "created": "2017-11-21T10:16:35.4739281-08:00",
  "lastActivity": "2017-11-21T10:17:05.0091947-08:00",
  "pageViews": [
    {
      "id": "112135179449184dfc98ce1c34ac1bd9ed75a61f",
      "startTime": "2017-11-21T10:16:35.7629134-08:00",
      "endTime": "2017-11-21T10:17:05.0091947-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 29354,
      "engagementTime": 29354,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 29354,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.38",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MU5EY",
    "CONDITION=211",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "aad52771f51deb95aac596ac608654ae",
  "gdpr": false
}