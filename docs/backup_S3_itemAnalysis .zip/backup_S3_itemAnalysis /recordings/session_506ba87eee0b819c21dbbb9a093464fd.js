var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ecf1c5ac6208357f9838fcaf8c85f787",
  "created": "2017-11-29T17:13:53.1616229-08:00",
  "lastActivity": "2017-11-29T17:14:05.9876229-08:00",
  "pageViews": [
    {
      "id": "112953418c03beafbf646b3dfb09d35c3c730800",
      "startTime": "2017-11-29T17:13:53.1616229-08:00",
      "endTime": "2017-11-29T17:14:05.9876229-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 12826,
      "engagementTime": 12726,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 12826,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=SH7C5",
    "CONDITION=221",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "506ba87eee0b819c21dbbb9a093464fd",
  "gdpr": false
}