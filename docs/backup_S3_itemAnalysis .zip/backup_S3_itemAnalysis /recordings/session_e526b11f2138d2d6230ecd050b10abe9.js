var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e0a6520023abfba9f61e03d7eef31569",
  "created": "2017-11-21T10:11:16.8781894-08:00",
  "lastActivity": "2017-11-21T10:11:37.5121894-08:00",
  "pageViews": [
    {
      "id": "1121167789377c1c486e53457f663ccbcbe89f5b",
      "startTime": "2017-11-21T10:11:16.8781894-08:00",
      "endTime": "2017-11-21T10:11:37.5121894-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 20634,
      "engagementTime": 17433,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 20634,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.35",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=W3AS2",
    "CONDITION=211",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e526b11f2138d2d6230ecd050b10abe9",
  "gdpr": false
}