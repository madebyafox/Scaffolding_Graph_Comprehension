var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b37b1923e1c745353e94c04a553b20b9",
  "created": "2017-12-05T10:19:44.3233284-08:00",
  "lastActivity": "2017-12-05T10:20:16.7823284-08:00",
  "pageViews": [
    {
      "id": "12054431a632e624620c9769a401e77a1920159d",
      "startTime": "2017-12-05T10:19:44.3233284-08:00",
      "endTime": "2017-12-05T10:20:16.7823284-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 32459,
      "engagementTime": 31559,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 32459,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=KGNTA",
    "CONDITION=112",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c77aba21b15fc9643fea35fd5ce79f7e",
  "gdpr": false
}