var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e418c6fda8dd852e4e5de96de94f2123",
  "created": "2017-11-30T11:10:54.3143051-08:00",
  "lastActivity": "2017-11-30T11:11:20.1947161-08:00",
  "pageViews": [
    {
      "id": "113054209bb95a346ee683ef60c8dc967ff557fb",
      "startTime": "2017-11-30T11:10:54.3143051-08:00",
      "endTime": "2017-11-30T11:11:20.1947161-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 25903,
      "engagementTime": 24430,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 25903,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=6CR5M",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0db55ac2f3aaf0562ed734e5cc84626e",
  "gdpr": false
}