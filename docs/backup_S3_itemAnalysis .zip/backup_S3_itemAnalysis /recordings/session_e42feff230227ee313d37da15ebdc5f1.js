var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5080ec4eca2e746823301d982eaceb7a",
  "created": "2017-11-29T17:13:21.5860847-08:00",
  "lastActivity": "2017-11-29T17:14:35.5637822-08:00",
  "pageViews": [
    {
      "id": "112921277d9b5bb855b26c72b5113f0d27feadc5",
      "startTime": "2017-11-29T17:13:21.6162334-08:00",
      "endTime": "2017-11-29T17:14:35.5637822-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 74251,
      "engagementTime": 69847,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 74251,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=1FO1D",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e42feff230227ee313d37da15ebdc5f1",
  "gdpr": false
}