var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5b7efb87a621fde5dfa6be12f9f013cb",
  "created": "2017-11-30T11:11:16.3128456-08:00",
  "lastActivity": "2017-11-30T11:11:39.9741855-08:00",
  "pageViews": [
    {
      "id": "11301665e441e411de0760737491646630624d31",
      "startTime": "2017-11-30T11:11:16.3128456-08:00",
      "endTime": "2017-11-30T11:11:39.9741855-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 23937,
      "engagementTime": 14585,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 23937,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G5XSH",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "0e7db1dbe9f5ce3ebc09947f6e3bae6e",
  "gdpr": false
}