var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1b5ce2e398b65c843547f600fa516295",
  "created": "2017-11-27T17:13:23.50561-08:00",
  "lastActivity": "2017-11-27T17:14:10.25161-08:00",
  "pageViews": [
    {
      "id": "112723650bd08c8c74d0c28311ae9d8874f42ce6",
      "startTime": "2017-11-27T17:13:23.50561-08:00",
      "endTime": "2017-11-27T17:14:10.25161-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 46746,
      "engagementTime": 41550,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 46746,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=T4UDR",
    "CONDITION=321",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b17614c5829a9aa7a7dbe19ddb568f7a",
  "gdpr": false
}