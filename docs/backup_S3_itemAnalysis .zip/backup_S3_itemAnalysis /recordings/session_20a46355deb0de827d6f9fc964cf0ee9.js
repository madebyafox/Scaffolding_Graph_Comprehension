var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "507304072f679da919476c7024a8e5b2",
  "created": "2017-11-21T09:19:23.6590062-08:00",
  "lastActivity": "2017-11-21T09:20:36.3880062-08:00",
  "pageViews": [
    {
      "id": "11212388fccb9d688974fed04fee628e150af69b",
      "startTime": "2017-11-21T09:19:23.6590062-08:00",
      "endTime": "2017-11-21T09:20:36.3880062-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 72729,
      "engagementTime": 59218,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "annotations": []
    }
  ],
  "duration": 72729,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.35",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=NFRT5",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "20a46355deb0de827d6f9fc964cf0ee9",
  "gdpr": false
}