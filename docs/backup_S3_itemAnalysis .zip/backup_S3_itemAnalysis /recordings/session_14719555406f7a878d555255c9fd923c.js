var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a0f8c3c045006e0fae8ad04c2fb335b7",
  "created": "2017-12-05T09:13:22.8407441-08:00",
  "lastActivity": "2017-12-05T09:13:49.8747441-08:00",
  "pageViews": [
    {
      "id": "120523699a4a7f5c567f3f31667e6e540cbf7fb1",
      "startTime": "2017-12-05T09:13:22.8407441-08:00",
      "endTime": "2017-12-05T09:13:49.8747441-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 27034,
      "engagementTime": 27034,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 27034,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=HA04H",
    "CONDITION=311",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "14719555406f7a878d555255c9fd923c",
  "gdpr": false
}