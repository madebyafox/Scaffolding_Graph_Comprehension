var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "aceae1d1e35a3f1374726acadb98e5b7",
  "created": "2017-11-30T09:21:57.0689196-08:00",
  "lastActivity": "2017-11-30T09:22:09.778109-08:00",
  "pageViews": [
    {
      "id": "113057215e96d1cdd51616617c074d46f99f2505",
      "startTime": "2017-11-30T09:21:57.0689196-08:00",
      "endTime": "2017-11-30T09:22:09.778109-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 12919,
      "engagementTime": 12919,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 12919,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.35",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FGMSN",
    "CONDITION=121",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c12d940d041216a0f4a72851206ddbc2",
  "gdpr": false
}