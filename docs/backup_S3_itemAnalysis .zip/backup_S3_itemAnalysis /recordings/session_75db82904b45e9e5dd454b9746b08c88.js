var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6f26688a948c5174b049e5973d0f4b05",
  "created": "2017-11-28T09:16:48.8210271-08:00",
  "lastActivity": "2017-11-28T09:17:12.5799989-08:00",
  "pageViews": [
    {
      "id": "112848483ee11bb59e4cd7d4ec1486138beb62bb",
      "startTime": "2017-11-28T09:16:48.8210271-08:00",
      "endTime": "2017-11-28T09:17:12.5799989-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 23825,
      "engagementTime": 20118,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 23825,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=KLYG7",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "75db82904b45e9e5dd454b9746b08c88",
  "gdpr": false
}