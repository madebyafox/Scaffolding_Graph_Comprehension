var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b5829e5a516509a4f8fe406af8754a51",
  "created": "2017-11-28T10:16:16.1595319-08:00",
  "lastActivity": "2017-11-28T10:16:27.5347834-08:00",
  "pageViews": [
    {
      "id": "1128162457493644acc1382ec8a9fb74eff6c9cb",
      "startTime": "2017-11-28T10:16:16.5271053-08:00",
      "endTime": "2017-11-28T10:16:27.5347834-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 11078,
      "engagementTime": 9777,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 11078,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=7L4J4",
    "CONDITION=111",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f77149a85e388e6cc1b12f9b810032db",
  "gdpr": false
}