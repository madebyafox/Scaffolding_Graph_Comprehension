var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6cb779dfb4c805d70e4854ccb02b431e",
  "created": "2017-12-04T17:10:33.8881405-08:00",
  "lastActivity": "2017-12-04T17:11:03.2692298-08:00",
  "pageViews": [
    {
      "id": "12043343b9b84db09e5eae5e9329df4df6f88ca3",
      "startTime": "2017-12-04T17:10:33.9591351-08:00",
      "endTime": "2017-12-04T17:11:03.2692298-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 29542,
      "engagementTime": 28889,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 29542,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=H9B17",
    "CONDITION=221",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "913b0fc3d77dbdfbe4ee6557601e2595",
  "gdpr": false
}