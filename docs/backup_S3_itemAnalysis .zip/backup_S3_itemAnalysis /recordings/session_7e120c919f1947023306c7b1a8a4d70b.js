var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "52429aaa550cc42ea8a88d1e4e648ffa",
  "created": "2017-11-30T10:10:34.5319977-08:00",
  "lastActivity": "2017-11-30T10:10:55.9092514-08:00",
  "pageViews": [
    {
      "id": "113034213fc97bd3064bfce05095fb84e3f041a5",
      "startTime": "2017-11-30T10:10:34.9796393-08:00",
      "endTime": "2017-11-30T10:10:55.9092514-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 21337,
      "engagementTime": 21337,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 21337,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FD7Z1",
    "CONDITION=321"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7e120c919f1947023306c7b1a8a4d70b",
  "gdpr": false
}