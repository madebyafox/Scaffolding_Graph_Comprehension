var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3981eaf21d438433ae86ad51c60cb999",
  "created": "2017-12-05T10:18:29.3824358-08:00",
  "lastActivity": "2017-12-05T10:18:56.1944358-08:00",
  "pageViews": [
    {
      "id": "120529735f2742db47b24d0247f47a541c84a464",
      "startTime": "2017-12-05T10:18:29.3824358-08:00",
      "endTime": "2017-12-05T10:18:56.1944358-08:00",
      "title": "FOX2YP",
      "uri": "http://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 26812,
      "engagementTime": 26812,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 26812,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=10XMB",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2afa2bcc3c6744477b9bdde43c7ba7e9",
  "gdpr": false
}