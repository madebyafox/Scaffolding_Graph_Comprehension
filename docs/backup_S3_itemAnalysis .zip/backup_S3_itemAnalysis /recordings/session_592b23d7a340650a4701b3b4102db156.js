var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "eb03ccc2a6ef079dd872644ed67d0d00",
  "created": "2017-11-28T10:17:09.3840214-08:00",
  "lastActivity": "2017-11-28T10:18:13.8321636-08:00",
  "pageViews": [
    {
      "id": "112809372cf4399e1b81bc86b560cdda578cb058",
      "startTime": "2017-11-28T10:17:09.4509287-08:00",
      "endTime": "2017-11-28T10:18:13.8321636-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 64605,
      "engagementTime": 64355,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "annotations": []
    }
  ],
  "duration": 64605,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=LST9D",
    "CONDITION=211",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "592b23d7a340650a4701b3b4102db156",
  "gdpr": false
}