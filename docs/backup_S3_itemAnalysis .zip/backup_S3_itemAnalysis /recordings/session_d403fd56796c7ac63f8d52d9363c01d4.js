var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5ec2e4a143ec6713e9a9abfe13ea5539",
  "created": "2017-12-05T10:22:32.4199831-08:00",
  "lastActivity": "2017-12-05T10:23:47.7308474-08:00",
  "pageViews": [
    {
      "id": "120532784bc4715146678be4182b7269bd057449",
      "startTime": "2017-12-05T10:22:32.7118474-08:00",
      "endTime": "2017-12-05T10:23:47.7308474-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 75019,
      "engagementTime": 69909,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "annotations": []
    }
  ],
  "duration": 75019,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=7E6TJ",
    "CONDITION=112",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d403fd56796c7ac63f8d52d9363c01d4",
  "gdpr": false
}