var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "dfa19a40e8a4ba77277a19c3ef7aca7e",
  "created": "2017-11-30T09:16:04.8141639-08:00",
  "lastActivity": "2017-11-30T09:16:32.057917-08:00",
  "pageViews": [
    {
      "id": "11300410b04c317f79d9834ccb7d2adc09d868d3",
      "startTime": "2017-11-30T09:16:04.8141639-08:00",
      "endTime": "2017-11-30T09:16:32.057917-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 27471,
      "engagementTime": 27170,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 27471,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=M1REU",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b42eaffff5cbd989f99cae8a1153ab4e",
  "gdpr": false
}