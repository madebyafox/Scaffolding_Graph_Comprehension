var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4774915292fff7f050e82ae14afd9bf9",
  "created": "2017-11-30T11:09:46.7206754-08:00",
  "lastActivity": "2017-11-30T11:09:57.5686754-08:00",
  "pageViews": [
    {
      "id": "11304726515635a33df375a7094d42d46f726c6b",
      "startTime": "2017-11-30T11:09:46.7206754-08:00",
      "endTime": "2017-11-30T11:09:57.5686754-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 10848,
      "engagementTime": 10848,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 10848,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G5XSH",
    "CONDITION=311",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7031d568c110515c74a47445afc3f98a",
  "gdpr": false
}