var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8cd2dab644595a4a6dff84a4bb55f039",
  "created": "2017-11-28T10:20:36.5199274-08:00",
  "lastActivity": "2017-11-28T10:22:41.8086712-08:00",
  "pageViews": [
    {
      "id": "1128363963989d8abd53f4e1d7a31d1a003b19bd",
      "startTime": "2017-11-28T10:20:36.7716409-08:00",
      "endTime": "2017-11-28T10:22:41.8086712-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 125294,
      "engagementTime": 80240,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "annotations": []
    }
  ],
  "duration": 125294,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=ZZYXF",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "621941a5ac5ac9c1e922187d951e9dc5",
  "gdpr": false
}