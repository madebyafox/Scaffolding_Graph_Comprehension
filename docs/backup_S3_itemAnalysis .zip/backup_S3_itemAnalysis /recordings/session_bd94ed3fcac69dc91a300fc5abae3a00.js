var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a1d71fdb8c90b8169e9c2a5c5b1cbebe",
  "created": "2017-11-30T11:12:53.7304844-08:00",
  "lastActivity": "2017-11-30T11:14:22.7794844-08:00",
  "pageViews": [
    {
      "id": "113053005c4d17181aaf4e4e481bd017bc9363e2",
      "startTime": "2017-11-30T11:12:53.7304844-08:00",
      "endTime": "2017-11-30T11:14:22.7794844-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 89049,
      "engagementTime": 58998,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "annotations": []
    }
  ],
  "duration": 89049,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.50",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=8970T",
    "CONDITION=321",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "bd94ed3fcac69dc91a300fc5abae3a00",
  "gdpr": false
}