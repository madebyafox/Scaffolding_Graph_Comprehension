var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a3da022b67d775230a91855f857f7997",
  "created": "2017-12-05T09:15:13.0488474-08:00",
  "lastActivity": "2017-12-05T09:15:27.5157982-08:00",
  "pageViews": [
    {
      "id": "12051230bd30f8c9fdde8a41a325d1214166c380",
      "startTime": "2017-12-05T09:15:13.1224044-08:00",
      "endTime": "2017-12-05T09:15:27.5157982-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 14517,
      "engagementTime": 14517,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 14517,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=J6H2B",
    "CONDITION=112",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1f183377370aaffff01c54f654714deb",
  "gdpr": false
}