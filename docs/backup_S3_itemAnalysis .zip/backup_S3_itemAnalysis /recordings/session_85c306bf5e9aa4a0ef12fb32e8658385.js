var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5713c7338b2b55ccb081fc120cf80345",
  "created": "2017-12-05T10:18:27.1144424-08:00",
  "lastActivity": "2017-12-05T10:19:03.6757462-08:00",
  "pageViews": [
    {
      "id": "12052797c396f6ff3091a4be2720b89a437a172f",
      "startTime": "2017-12-05T10:18:27.3361767-08:00",
      "endTime": "2017-12-05T10:19:03.6757462-08:00",
      "title": "FOX2YP",
      "uri": "http://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 36413,
      "engagementTime": 36413,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 36413,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=TELDD",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "85c306bf5e9aa4a0ef12fb32e8658385",
  "gdpr": false
}