var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a8a268704fe19db9ea5bbf48c6240b89",
  "created": "2017-11-30T10:13:40.7715107-08:00",
  "lastActivity": "2017-11-30T10:14:00.9135107-08:00",
  "pageViews": [
    {
      "id": "11304075559b699e13ef1ee364f09e3a177363bf",
      "startTime": "2017-11-30T10:13:40.7715107-08:00",
      "endTime": "2017-11-30T10:14:00.9135107-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 20142,
      "engagementTime": 20014,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 20142,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=BPUXY",
    "CONDITION=321",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8ff801232308cb7d643995700a5f9447",
  "gdpr": false
}