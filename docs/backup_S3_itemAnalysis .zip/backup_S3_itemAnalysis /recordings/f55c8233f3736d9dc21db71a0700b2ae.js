var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["120502218106d1cfcecd2a474720428b3d455497"] = {
  "startTime": "2017-12-05T18:26:02.9482513Z",
  "websitePageUrl": "/15",
  "visitTime": 83485,
  "engagementTime": 60072,
  "pageTitle": "FOX2YP",
  "url": "http://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "5c7e96c751340e80c39b9a04c872e644",
    "created": "2017-12-05T18:26:02.5574367+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "duration": 0,
    "pages": 1,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "62.0.3202.94",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/15",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=WLDKB",
      "CONDITION=113",
      "ORTH_CORRECT=1"
    ],
    "watched": false,
    "starred": false,
    "gdpr": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "f55c8233f3736d9dc21db71a0700b2ae",
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/5c7e96c751340e80c39b9a04c872e644/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 261,
      "e": 261,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 261,
      "e": 261,
      "ty": 2,
      "x": 442,
      "y": 682
    },
    {
      "t": 262,
      "e": 262,
      "ty": 41,
      "x": 57767,
      "y": 16824,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 6701,
      "e": 5262,
      "ty": 2,
      "x": 539,
      "y": 667
    },
    {
      "t": 6751,
      "e": 5312,
      "ty": 41,
      "x": 65389,
      "y": 36506,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 6801,
      "e": 5362,
      "ty": 2,
      "x": 878,
      "y": 705
    },
    {
      "t": 6901,
      "e": 5462,
      "ty": 2,
      "x": 1197,
      "y": 820
    },
    {
      "t": 7001,
      "e": 5562,
      "ty": 41,
      "x": 37474,
      "y": 57584,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7001,
      "e": 5562,
      "ty": 2,
      "x": 1321,
      "y": 942
    },
    {
      "t": 7101,
      "e": 5662,
      "ty": 2,
      "x": 1333,
      "y": 957
    },
    {
      "t": 7201,
      "e": 5762,
      "ty": 2,
      "x": 1332,
      "y": 957
    },
    {
      "t": 7251,
      "e": 5812,
      "ty": 41,
      "x": 37333,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7301,
      "e": 5862,
      "ty": 2,
      "x": 1303,
      "y": 953
    },
    {
      "t": 7401,
      "e": 5962,
      "ty": 2,
      "x": 1296,
      "y": 954
    },
    {
      "t": 7501,
      "e": 6062,
      "ty": 41,
      "x": 34444,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7501,
      "e": 6062,
      "ty": 2,
      "x": 1278,
      "y": 954
    },
    {
      "t": 7601,
      "e": 6162,
      "ty": 2,
      "x": 1276,
      "y": 955
    },
    {
      "t": 7701,
      "e": 6262,
      "ty": 2,
      "x": 1283,
      "y": 957
    },
    {
      "t": 7751,
      "e": 6312,
      "ty": 41,
      "x": 34796,
      "y": 58659,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8101,
      "e": 6662,
      "ty": 2,
      "x": 1285,
      "y": 957
    },
    {
      "t": 8251,
      "e": 6812,
      "ty": 41,
      "x": 35078,
      "y": 58659,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8301,
      "e": 6862,
      "ty": 2,
      "x": 1289,
      "y": 957
    },
    {
      "t": 8401,
      "e": 6962,
      "ty": 2,
      "x": 1294,
      "y": 955
    },
    {
      "t": 8501,
      "e": 7062,
      "ty": 41,
      "x": 1571,
      "y": 64060,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[4] > line:[13]"
    },
    {
      "t": 8502,
      "e": 7063,
      "ty": 2,
      "x": 1294,
      "y": 954
    },
    {
      "t": 9301,
      "e": 7862,
      "ty": 2,
      "x": 1295,
      "y": 954
    },
    {
      "t": 9501,
      "e": 8062,
      "ty": 41,
      "x": 35642,
      "y": 58659,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9502,
      "e": 8063,
      "ty": 2,
      "x": 1295,
      "y": 957
    },
    {
      "t": 9701,
      "e": 8262,
      "ty": 2,
      "x": 1291,
      "y": 958
    },
    {
      "t": 9751,
      "e": 8312,
      "ty": 41,
      "x": 35360,
      "y": 58730,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9801,
      "e": 8362,
      "ty": 2,
      "x": 1291,
      "y": 959
    },
    {
      "t": 9901,
      "e": 8462,
      "ty": 2,
      "x": 1290,
      "y": 959
    },
    {
      "t": 10001,
      "e": 8562,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10003,
      "e": 8564,
      "ty": 41,
      "x": 35290,
      "y": 58802,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 20001,
      "e": 13564,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 22201,
      "e": 13564,
      "ty": 2,
      "x": 975,
      "y": 762
    },
    {
      "t": 22251,
      "e": 13614,
      "ty": 41,
      "x": 40334,
      "y": 46042,
      "ta": "#bigset.midpoint > ul > li:[15]"
    },
    {
      "t": 22301,
      "e": 13664,
      "ty": 2,
      "x": 548,
      "y": 579
    },
    {
      "t": 22401,
      "e": 13764,
      "ty": 2,
      "x": 536,
      "y": 567
    },
    {
      "t": 22501,
      "e": 13864,
      "ty": 41,
      "x": 42049,
      "y": 6253,
      "ta": "#bigset.midpoint > ul > li:[9]"
    },
    {
      "t": 22501,
      "e": 13864,
      "ty": 2,
      "x": 534,
      "y": 565
    },
    {
      "t": 22601,
      "e": 13964,
      "ty": 2,
      "x": 508,
      "y": 552
    },
    {
      "t": 22701,
      "e": 14064,
      "ty": 2,
      "x": 506,
      "y": 552
    },
    {
      "t": 22751,
      "e": 14114,
      "ty": 41,
      "x": 25349,
      "y": 41361,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 22801,
      "e": 14164,
      "ty": 2,
      "x": 508,
      "y": 548
    },
    {
      "t": 22901,
      "e": 14264,
      "ty": 2,
      "x": 516,
      "y": 545
    },
    {
      "t": 22968,
      "e": 14331,
      "ty": 3,
      "x": 516,
      "y": 545,
      "ta": "#bigset.midpoint > ul > li:[4] > input"
    },
    {
      "t": 22969,
      "e": 14332,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > input"
    },
    {
      "t": 23001,
      "e": 14364,
      "ty": 41,
      "x": 42613,
      "y": 23551,
      "ta": "#bigset.midpoint > ul > li:[4] > input"
    },
    {
      "t": 23046,
      "e": 14409,
      "ty": 4,
      "x": 42613,
      "y": 23551,
      "ta": "#bigset.midpoint > ul > li:[4] > input"
    },
    {
      "t": 23047,
      "e": 14410,
      "ty": 5,
      "x": 516,
      "y": 545,
      "ta": "#bigset.midpoint > ul > li:[4] > input"
    },
    {
      "t": 23047,
      "e": 14410,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > input",
      "v": "F"
    },
    {
      "t": 23301,
      "e": 14664,
      "ty": 2,
      "x": 517,
      "y": 545
    },
    {
      "t": 23401,
      "e": 14764,
      "ty": 2,
      "x": 619,
      "y": 617
    },
    {
      "t": 23501,
      "e": 14864,
      "ty": 41,
      "x": 6891,
      "y": 43188,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 23501,
      "e": 14864,
      "ty": 2,
      "x": 887,
      "y": 741
    },
    {
      "t": 23601,
      "e": 14964,
      "ty": 2,
      "x": 1045,
      "y": 762
    },
    {
      "t": 23701,
      "e": 15064,
      "ty": 2,
      "x": 1055,
      "y": 759
    },
    {
      "t": 23751,
      "e": 15114,
      "ty": 41,
      "x": 19575,
      "y": 43761,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 23801,
      "e": 15164,
      "ty": 2,
      "x": 1096,
      "y": 726
    },
    {
      "t": 23901,
      "e": 15264,
      "ty": 2,
      "x": 1117,
      "y": 715
    },
    {
      "t": 24001,
      "e": 15364,
      "ty": 41,
      "x": 24226,
      "y": 40466,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 24002,
      "e": 15365,
      "ty": 2,
      "x": 1133,
      "y": 703
    },
    {
      "t": 24101,
      "e": 15464,
      "ty": 2,
      "x": 1144,
      "y": 698
    },
    {
      "t": 24201,
      "e": 15564,
      "ty": 2,
      "x": 1150,
      "y": 693
    },
    {
      "t": 24251,
      "e": 15614,
      "ty": 41,
      "x": 25424,
      "y": 39750,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 24402,
      "e": 15765,
      "ty": 2,
      "x": 1177,
      "y": 718
    },
    {
      "t": 24501,
      "e": 15864,
      "ty": 41,
      "x": 30709,
      "y": 43618,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 24501,
      "e": 15864,
      "ty": 2,
      "x": 1225,
      "y": 747
    },
    {
      "t": 24601,
      "e": 15964,
      "ty": 2,
      "x": 1250,
      "y": 768
    },
    {
      "t": 24701,
      "e": 16064,
      "ty": 2,
      "x": 1261,
      "y": 790
    },
    {
      "t": 24751,
      "e": 16114,
      "ty": 41,
      "x": 33810,
      "y": 49634,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 24801,
      "e": 16164,
      "ty": 2,
      "x": 1271,
      "y": 886
    },
    {
      "t": 24901,
      "e": 16264,
      "ty": 2,
      "x": 1273,
      "y": 915
    },
    {
      "t": 25001,
      "e": 16364,
      "ty": 41,
      "x": 34655,
      "y": 57011,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 25002,
      "e": 16365,
      "ty": 2,
      "x": 1281,
      "y": 934
    },
    {
      "t": 25101,
      "e": 16464,
      "ty": 2,
      "x": 1281,
      "y": 938
    },
    {
      "t": 25201,
      "e": 16564,
      "ty": 2,
      "x": 1281,
      "y": 951
    },
    {
      "t": 25251,
      "e": 16614,
      "ty": 41,
      "x": 34655,
      "y": 58229,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 25401,
      "e": 16764,
      "ty": 2,
      "x": 1281,
      "y": 953
    },
    {
      "t": 25501,
      "e": 16864,
      "ty": 41,
      "x": 34726,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 25501,
      "e": 16864,
      "ty": 2,
      "x": 1282,
      "y": 954
    },
    {
      "t": 25601,
      "e": 16964,
      "ty": 2,
      "x": 1285,
      "y": 957
    },
    {
      "t": 25701,
      "e": 17064,
      "ty": 2,
      "x": 1287,
      "y": 957
    },
    {
      "t": 25751,
      "e": 17114,
      "ty": 41,
      "x": 35290,
      "y": 58659,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 25801,
      "e": 17164,
      "ty": 2,
      "x": 1290,
      "y": 957
    },
    {
      "t": 30001,
      "e": 21364,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 34401,
      "e": 22164,
      "ty": 2,
      "x": 1288,
      "y": 956
    },
    {
      "t": 34501,
      "e": 22264,
      "ty": 41,
      "x": 29793,
      "y": 54075,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 34502,
      "e": 22265,
      "ty": 2,
      "x": 1212,
      "y": 893
    },
    {
      "t": 34601,
      "e": 22364,
      "ty": 2,
      "x": 1042,
      "y": 736
    },
    {
      "t": 34701,
      "e": 22464,
      "ty": 2,
      "x": 980,
      "y": 657
    },
    {
      "t": 34751,
      "e": 22514,
      "ty": 41,
      "x": 11190,
      "y": 29651,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 34801,
      "e": 22564,
      "ty": 2,
      "x": 916,
      "y": 500
    },
    {
      "t": 34901,
      "e": 22664,
      "ty": 2,
      "x": 574,
      "y": 534
    },
    {
      "t": 35001,
      "e": 22764,
      "ty": 41,
      "x": 56290,
      "y": 34340,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 35001,
      "e": 22764,
      "ty": 2,
      "x": 448,
      "y": 577
    },
    {
      "t": 35101,
      "e": 22864,
      "ty": 2,
      "x": 434,
      "y": 580
    },
    {
      "t": 35201,
      "e": 22964,
      "ty": 2,
      "x": 472,
      "y": 559
    },
    {
      "t": 35251,
      "e": 23014,
      "ty": 41,
      "x": 31313,
      "y": 53064,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 35301,
      "e": 23064,
      "ty": 2,
      "x": 531,
      "y": 557
    },
    {
      "t": 35401,
      "e": 23164,
      "ty": 2,
      "x": 499,
      "y": 558
    },
    {
      "t": 35501,
      "e": 23264,
      "ty": 41,
      "x": 57482,
      "y": 55404,
      "ta": "#bigset.midpoint > ul > li:[3]"
    },
    {
      "t": 35502,
      "e": 23265,
      "ty": 2,
      "x": 450,
      "y": 558
    },
    {
      "t": 35601,
      "e": 23364,
      "ty": 2,
      "x": 434,
      "y": 549
    },
    {
      "t": 35701,
      "e": 23464,
      "ty": 2,
      "x": 405,
      "y": 549
    },
    {
      "t": 35751,
      "e": 23514,
      "ty": 41,
      "x": 39226,
      "y": 43716,
      "ta": "#bigset.midpoint > ul > li:[3] > input"
    },
    {
      "t": 35895,
      "e": 23658,
      "ty": 3,
      "x": 405,
      "y": 549,
      "ta": "#bigset.midpoint > ul > li:[3] > input"
    },
    {
      "t": 35896,
      "e": 23659,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > input"
    },
    {
      "t": 35896,
      "e": 23659,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[3] > input"
    },
    {
      "t": 35998,
      "e": 23761,
      "ty": 4,
      "x": 39226,
      "y": 43716,
      "ta": "#bigset.midpoint > ul > li:[3] > input"
    },
    {
      "t": 35999,
      "e": 23762,
      "ty": 5,
      "x": 405,
      "y": 549,
      "ta": "#bigset.midpoint > ul > li:[3] > input"
    },
    {
      "t": 36000,
      "e": 23763,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[3] > input",
      "v": "E"
    },
    {
      "t": 36101,
      "e": 23864,
      "ty": 2,
      "x": 406,
      "y": 589
    },
    {
      "t": 36201,
      "e": 23964,
      "ty": 2,
      "x": 431,
      "y": 664
    },
    {
      "t": 36251,
      "e": 24014,
      "ty": 41,
      "x": 53086,
      "y": 10925,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 36301,
      "e": 24064,
      "ty": 2,
      "x": 434,
      "y": 676
    },
    {
      "t": 36401,
      "e": 24164,
      "ty": 2,
      "x": 435,
      "y": 691
    },
    {
      "t": 36501,
      "e": 24264,
      "ty": 41,
      "x": 52649,
      "y": 20570,
      "ta": "#start"
    },
    {
      "t": 36501,
      "e": 24264,
      "ty": 2,
      "x": 435,
      "y": 700
    },
    {
      "t": 36534,
      "e": 24297,
      "ty": 3,
      "x": 435,
      "y": 700,
      "ta": "#start"
    },
    {
      "t": 36534,
      "e": 24297,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[3] > input"
    },
    {
      "t": 36535,
      "e": 24298,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 36630,
      "e": 24393,
      "ty": 4,
      "x": 52649,
      "y": 20570,
      "ta": "#start"
    },
    {
      "t": 36636,
      "e": 24399,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 36638,
      "e": 24401,
      "ty": 5,
      "x": 435,
      "y": 700,
      "ta": "#start"
    },
    {
      "t": 36648,
      "e": 24411,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 37645,
      "e": 25408,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 38201,
      "e": 25964,
      "ty": 2,
      "x": 517,
      "y": 629
    },
    {
      "t": 38251,
      "e": 26014,
      "ty": 41,
      "x": 23452,
      "y": 29748,
      "ta": "html > body"
    },
    {
      "t": 38301,
      "e": 26064,
      "ty": 2,
      "x": 799,
      "y": 540
    },
    {
      "t": 38401,
      "e": 26164,
      "ty": 2,
      "x": 920,
      "y": 565
    },
    {
      "t": 38501,
      "e": 26264,
      "ty": 41,
      "x": 28549,
      "y": 1409,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 38501,
      "e": 26264,
      "ty": 2,
      "x": 940,
      "y": 585
    },
    {
      "t": 38701,
      "e": 26464,
      "ty": 2,
      "x": 941,
      "y": 585
    },
    {
      "t": 38751,
      "e": 26514,
      "ty": 41,
      "x": 28766,
      "y": 64125,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 38801,
      "e": 26564,
      "ty": 2,
      "x": 940,
      "y": 578
    },
    {
      "t": 39001,
      "e": 26764,
      "ty": 41,
      "x": 27252,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39001,
      "e": 26764,
      "ty": 2,
      "x": 934,
      "y": 565
    },
    {
      "t": 39070,
      "e": 26833,
      "ty": 3,
      "x": 934,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39072,
      "e": 26835,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39157,
      "e": 26920,
      "ty": 4,
      "x": 27252,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39157,
      "e": 26920,
      "ty": 5,
      "x": 934,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40002,
      "e": 27765,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40267,
      "e": 28030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 40267,
      "e": 28030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40331,
      "e": 28094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 40339,
      "e": 28102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 40339,
      "e": 28102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40386,
      "e": 28149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 41101,
      "e": 28864,
      "ty": 2,
      "x": 947,
      "y": 593
    },
    {
      "t": 41202,
      "e": 28965,
      "ty": 2,
      "x": 978,
      "y": 661
    },
    {
      "t": 41252,
      "e": 29015,
      "ty": 41,
      "x": 36768,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41302,
      "e": 29065,
      "ty": 2,
      "x": 978,
      "y": 664
    },
    {
      "t": 41486,
      "e": 29249,
      "ty": 3,
      "x": 978,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41487,
      "e": 29250,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 41487,
      "e": 29250,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41487,
      "e": 29250,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41550,
      "e": 29313,
      "ty": 4,
      "x": 36768,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41551,
      "e": 29314,
      "ty": 5,
      "x": 978,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42837,
      "e": 30600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 42917,
      "e": 30680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 42917,
      "e": 30680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42964,
      "e": 30727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 43012,
      "e": 30775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 43173,
      "e": 30936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 43173,
      "e": 30936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43260,
      "e": 31023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 43348,
      "e": 31111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 43349,
      "e": 31112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43421,
      "e": 31184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 43565,
      "e": 31328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 43565,
      "e": 31328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43684,
      "e": 31447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 43685,
      "e": 31448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43692,
      "e": 31455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 43732,
      "e": 31495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 43868,
      "e": 31631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 43869,
      "e": 31632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43940,
      "e": 31703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 43988,
      "e": 31751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 43988,
      "e": 31751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44012,
      "e": 31775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 44213,
      "e": 31976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 44317,
      "e": 32080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 44318,
      "e": 32081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44340,
      "e": 32103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 44380,
      "e": 32143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 44517,
      "e": 32280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 44517,
      "e": 32280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44588,
      "e": 32351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 44596,
      "e": 32359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 44596,
      "e": 32359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44692,
      "e": 32455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 44693,
      "e": 32456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44716,
      "e": 32479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||at"
    },
    {
      "t": 44772,
      "e": 32535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 44772,
      "e": 32535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44820,
      "e": 32583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 44876,
      "e": 32639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 44877,
      "e": 32640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44948,
      "e": 32711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 45004,
      "e": 32767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 46103,
      "e": 33866,
      "ty": 2,
      "x": 979,
      "y": 665
    },
    {
      "t": 46203,
      "e": 33966,
      "ty": 2,
      "x": 980,
      "y": 666
    },
    {
      "t": 46253,
      "e": 34016,
      "ty": 41,
      "x": 36336,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 46303,
      "e": 34066,
      "ty": 2,
      "x": 976,
      "y": 675
    },
    {
      "t": 46403,
      "e": 34166,
      "ty": 2,
      "x": 977,
      "y": 678
    },
    {
      "t": 46503,
      "e": 34266,
      "ty": 41,
      "x": 42817,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46503,
      "e": 34266,
      "ty": 2,
      "x": 979,
      "y": 685
    },
    {
      "t": 46600,
      "e": 34363,
      "ty": 3,
      "x": 980,
      "y": 688,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46601,
      "e": 34364,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 46601,
      "e": 34364,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46601,
      "e": 34364,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46602,
      "e": 34365,
      "ty": 2,
      "x": 980,
      "y": 688
    },
    {
      "t": 46672,
      "e": 34435,
      "ty": 4,
      "x": 43332,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46673,
      "e": 34436,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46674,
      "e": 34437,
      "ty": 5,
      "x": 980,
      "y": 688,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46674,
      "e": 34437,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 46753,
      "e": 34516,
      "ty": 41,
      "x": 33473,
      "y": 37670,
      "ta": "html > body"
    },
    {
      "t": 47686,
      "e": 35449,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 48503,
      "e": 36266,
      "ty": 41,
      "x": 37634,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 48504,
      "e": 36267,
      "ty": 2,
      "x": 980,
      "y": 687
    },
    {
      "t": 48603,
      "e": 36366,
      "ty": 2,
      "x": 1014,
      "y": 527
    },
    {
      "t": 48703,
      "e": 36466,
      "ty": 2,
      "x": 1009,
      "y": 383
    },
    {
      "t": 48753,
      "e": 36516,
      "ty": 41,
      "x": 39770,
      "y": 14422,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 48803,
      "e": 36566,
      "ty": 2,
      "x": 965,
      "y": 332
    },
    {
      "t": 48903,
      "e": 36666,
      "ty": 2,
      "x": 946,
      "y": 225
    },
    {
      "t": 49003,
      "e": 36766,
      "ty": 41,
      "x": 28378,
      "y": 12028,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 49003,
      "e": 36766,
      "ty": 2,
      "x": 941,
      "y": 208
    },
    {
      "t": 49203,
      "e": 36966,
      "ty": 2,
      "x": 941,
      "y": 207
    },
    {
      "t": 49253,
      "e": 37016,
      "ty": 41,
      "x": 27904,
      "y": 12028,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 49303,
      "e": 37066,
      "ty": 2,
      "x": 934,
      "y": 211
    },
    {
      "t": 49403,
      "e": 37166,
      "ty": 2,
      "x": 912,
      "y": 224
    },
    {
      "t": 49503,
      "e": 37266,
      "ty": 41,
      "x": 56975,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49504,
      "e": 37267,
      "ty": 2,
      "x": 891,
      "y": 234
    },
    {
      "t": 49603,
      "e": 37366,
      "ty": 2,
      "x": 872,
      "y": 242
    },
    {
      "t": 49703,
      "e": 37466,
      "ty": 2,
      "x": 852,
      "y": 242
    },
    {
      "t": 49753,
      "e": 37516,
      "ty": 41,
      "x": 23401,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49803,
      "e": 37566,
      "ty": 2,
      "x": 844,
      "y": 241
    },
    {
      "t": 49903,
      "e": 37666,
      "ty": 2,
      "x": 842,
      "y": 240
    },
    {
      "t": 50003,
      "e": 37766,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50004,
      "e": 37767,
      "ty": 41,
      "x": 15213,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 50004,
      "e": 37767,
      "ty": 2,
      "x": 840,
      "y": 240
    },
    {
      "t": 50103,
      "e": 37866,
      "ty": 2,
      "x": 839,
      "y": 240
    },
    {
      "t": 50253,
      "e": 38016,
      "ty": 41,
      "x": 63408,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50503,
      "e": 38266,
      "ty": 41,
      "x": 53325,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50503,
      "e": 38266,
      "ty": 2,
      "x": 837,
      "y": 240
    },
    {
      "t": 50603,
      "e": 38366,
      "ty": 2,
      "x": 832,
      "y": 239
    },
    {
      "t": 50703,
      "e": 38466,
      "ty": 2,
      "x": 831,
      "y": 238
    },
    {
      "t": 50753,
      "e": 38516,
      "ty": 3,
      "x": 831,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50754,
      "e": 38517,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50756,
      "e": 38519,
      "ty": 41,
      "x": 23079,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50832,
      "e": 38595,
      "ty": 4,
      "x": 23079,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50832,
      "e": 38595,
      "ty": 5,
      "x": 831,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50832,
      "e": 38595,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 51103,
      "e": 38866,
      "ty": 2,
      "x": 831,
      "y": 240
    },
    {
      "t": 51203,
      "e": 38966,
      "ty": 2,
      "x": 830,
      "y": 278
    },
    {
      "t": 51253,
      "e": 39016,
      "ty": 41,
      "x": 10501,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 51303,
      "e": 39066,
      "ty": 2,
      "x": 833,
      "y": 353
    },
    {
      "t": 51403,
      "e": 39166,
      "ty": 2,
      "x": 833,
      "y": 386
    },
    {
      "t": 51503,
      "e": 39266,
      "ty": 41,
      "x": 2747,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 51503,
      "e": 39266,
      "ty": 2,
      "x": 833,
      "y": 399
    },
    {
      "t": 51603,
      "e": 39366,
      "ty": 2,
      "x": 833,
      "y": 403
    },
    {
      "t": 51703,
      "e": 39466,
      "ty": 2,
      "x": 833,
      "y": 408
    },
    {
      "t": 51753,
      "e": 39516,
      "ty": 41,
      "x": 33161,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 52603,
      "e": 40366,
      "ty": 2,
      "x": 833,
      "y": 410
    },
    {
      "t": 52703,
      "e": 40466,
      "ty": 2,
      "x": 833,
      "y": 411
    },
    {
      "t": 52753,
      "e": 40516,
      "ty": 41,
      "x": 33161,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 52803,
      "e": 40566,
      "ty": 2,
      "x": 833,
      "y": 425
    },
    {
      "t": 52903,
      "e": 40666,
      "ty": 2,
      "x": 833,
      "y": 433
    },
    {
      "t": 53003,
      "e": 40766,
      "ty": 41,
      "x": 28120,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53003,
      "e": 40766,
      "ty": 2,
      "x": 832,
      "y": 437
    },
    {
      "t": 53169,
      "e": 40932,
      "ty": 3,
      "x": 832,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53170,
      "e": 40933,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53170,
      "e": 40933,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53280,
      "e": 41043,
      "ty": 4,
      "x": 28120,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53280,
      "e": 41043,
      "ty": 5,
      "x": 832,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 53280,
      "e": 41043,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 53603,
      "e": 41366,
      "ty": 2,
      "x": 827,
      "y": 502
    },
    {
      "t": 53703,
      "e": 41466,
      "ty": 2,
      "x": 823,
      "y": 538
    },
    {
      "t": 53753,
      "e": 41516,
      "ty": 41,
      "x": 1759,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 53803,
      "e": 41566,
      "ty": 2,
      "x": 825,
      "y": 560
    },
    {
      "t": 53903,
      "e": 41666,
      "ty": 2,
      "x": 828,
      "y": 590
    },
    {
      "t": 54003,
      "e": 41766,
      "ty": 41,
      "x": 3934,
      "y": 11644,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 54003,
      "e": 41766,
      "ty": 2,
      "x": 838,
      "y": 658
    },
    {
      "t": 54103,
      "e": 41866,
      "ty": 2,
      "x": 838,
      "y": 671
    },
    {
      "t": 54253,
      "e": 42016,
      "ty": 41,
      "x": 58367,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 54403,
      "e": 42166,
      "ty": 2,
      "x": 838,
      "y": 672
    },
    {
      "t": 54503,
      "e": 42266,
      "ty": 41,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 55003,
      "e": 42766,
      "ty": 41,
      "x": 53325,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 55003,
      "e": 42766,
      "ty": 2,
      "x": 837,
      "y": 679
    },
    {
      "t": 55103,
      "e": 42866,
      "ty": 2,
      "x": 837,
      "y": 701
    },
    {
      "t": 55203,
      "e": 42966,
      "ty": 2,
      "x": 820,
      "y": 720
    },
    {
      "t": 55253,
      "e": 43016,
      "ty": 41,
      "x": 27377,
      "y": 40163,
      "ta": "html > body"
    },
    {
      "t": 55303,
      "e": 43066,
      "ty": 2,
      "x": 798,
      "y": 739
    },
    {
      "t": 55503,
      "e": 43266,
      "ty": 41,
      "x": 27205,
      "y": 40495,
      "ta": "html > body"
    },
    {
      "t": 55603,
      "e": 43366,
      "ty": 2,
      "x": 796,
      "y": 739
    },
    {
      "t": 55703,
      "e": 43466,
      "ty": 2,
      "x": 794,
      "y": 740
    },
    {
      "t": 55753,
      "e": 43516,
      "ty": 41,
      "x": 27068,
      "y": 40550,
      "ta": "html > body"
    },
    {
      "t": 55803,
      "e": 43566,
      "ty": 2,
      "x": 794,
      "y": 741
    },
    {
      "t": 55903,
      "e": 43666,
      "ty": 2,
      "x": 794,
      "y": 745
    },
    {
      "t": 56003,
      "e": 43766,
      "ty": 41,
      "x": 27068,
      "y": 40938,
      "ta": "html > body"
    },
    {
      "t": 56003,
      "e": 43766,
      "ty": 2,
      "x": 794,
      "y": 747
    },
    {
      "t": 56103,
      "e": 43866,
      "ty": 2,
      "x": 796,
      "y": 753
    },
    {
      "t": 56203,
      "e": 43966,
      "ty": 2,
      "x": 799,
      "y": 755
    },
    {
      "t": 56253,
      "e": 44016,
      "ty": 41,
      "x": 27412,
      "y": 41824,
      "ta": "html > body"
    },
    {
      "t": 56303,
      "e": 44066,
      "ty": 2,
      "x": 804,
      "y": 767
    },
    {
      "t": 56403,
      "e": 44166,
      "ty": 2,
      "x": 804,
      "y": 772
    },
    {
      "t": 56503,
      "e": 44266,
      "ty": 41,
      "x": 27412,
      "y": 42600,
      "ta": "html > body"
    },
    {
      "t": 56503,
      "e": 44266,
      "ty": 2,
      "x": 804,
      "y": 777
    },
    {
      "t": 56603,
      "e": 44366,
      "ty": 2,
      "x": 803,
      "y": 780
    },
    {
      "t": 56703,
      "e": 44466,
      "ty": 2,
      "x": 803,
      "y": 784
    },
    {
      "t": 56753,
      "e": 44516,
      "ty": 41,
      "x": 27377,
      "y": 42988,
      "ta": "html > body"
    },
    {
      "t": 56803,
      "e": 44566,
      "ty": 2,
      "x": 801,
      "y": 787
    },
    {
      "t": 56903,
      "e": 44666,
      "ty": 2,
      "x": 801,
      "y": 788
    },
    {
      "t": 57006,
      "e": 44668,
      "ty": 41,
      "x": 27309,
      "y": 43209,
      "ta": "html > body"
    },
    {
      "t": 57304,
      "e": 44966,
      "ty": 2,
      "x": 800,
      "y": 784
    },
    {
      "t": 57404,
      "e": 45066,
      "ty": 2,
      "x": 798,
      "y": 779
    },
    {
      "t": 57504,
      "e": 45166,
      "ty": 41,
      "x": 27205,
      "y": 42489,
      "ta": "html > body"
    },
    {
      "t": 57504,
      "e": 45166,
      "ty": 2,
      "x": 798,
      "y": 775
    },
    {
      "t": 57604,
      "e": 45266,
      "ty": 2,
      "x": 798,
      "y": 773
    },
    {
      "t": 57704,
      "e": 45366,
      "ty": 2,
      "x": 798,
      "y": 769
    },
    {
      "t": 57754,
      "e": 45416,
      "ty": 41,
      "x": 27205,
      "y": 42157,
      "ta": "html > body"
    },
    {
      "t": 57904,
      "e": 45566,
      "ty": 2,
      "x": 811,
      "y": 741
    },
    {
      "t": 58004,
      "e": 45666,
      "ty": 41,
      "x": 3169,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 58004,
      "e": 45666,
      "ty": 2,
      "x": 834,
      "y": 712
    },
    {
      "t": 58104,
      "e": 45766,
      "ty": 2,
      "x": 839,
      "y": 704
    },
    {
      "t": 58254,
      "e": 45916,
      "ty": 41,
      "x": 63408,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58404,
      "e": 46066,
      "ty": 2,
      "x": 838,
      "y": 704
    },
    {
      "t": 58504,
      "e": 46166,
      "ty": 41,
      "x": 58367,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58698,
      "e": 46360,
      "ty": 3,
      "x": 838,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58699,
      "e": 46361,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 58700,
      "e": 46362,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58760,
      "e": 46422,
      "ty": 4,
      "x": 58367,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58760,
      "e": 46422,
      "ty": 5,
      "x": 838,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58761,
      "e": 46423,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 59104,
      "e": 46766,
      "ty": 2,
      "x": 828,
      "y": 773
    },
    {
      "t": 59204,
      "e": 46866,
      "ty": 2,
      "x": 816,
      "y": 823
    },
    {
      "t": 59254,
      "e": 46916,
      "ty": 41,
      "x": 27825,
      "y": 45148,
      "ta": "html > body"
    },
    {
      "t": 59304,
      "e": 46966,
      "ty": 2,
      "x": 816,
      "y": 828
    },
    {
      "t": 59404,
      "e": 47066,
      "ty": 2,
      "x": 816,
      "y": 839
    },
    {
      "t": 59504,
      "e": 47166,
      "ty": 41,
      "x": 27928,
      "y": 48029,
      "ta": "html > body"
    },
    {
      "t": 59504,
      "e": 47166,
      "ty": 2,
      "x": 819,
      "y": 875
    },
    {
      "t": 59604,
      "e": 47266,
      "ty": 2,
      "x": 822,
      "y": 894
    },
    {
      "t": 59704,
      "e": 47366,
      "ty": 2,
      "x": 823,
      "y": 904
    },
    {
      "t": 59754,
      "e": 47416,
      "ty": 41,
      "x": 849,
      "y": 15627,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 59804,
      "e": 47466,
      "ty": 2,
      "x": 825,
      "y": 906
    },
    {
      "t": 59904,
      "e": 47566,
      "ty": 2,
      "x": 833,
      "y": 913
    },
    {
      "t": 60004,
      "e": 47666,
      "ty": 41,
      "x": 3934,
      "y": 21676,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 60004,
      "e": 47666,
      "ty": 2,
      "x": 838,
      "y": 918
    },
    {
      "t": 60104,
      "e": 47766,
      "ty": 2,
      "x": 839,
      "y": 929
    },
    {
      "t": 60204,
      "e": 47866,
      "ty": 2,
      "x": 839,
      "y": 931
    },
    {
      "t": 60254,
      "e": 47916,
      "ty": 41,
      "x": 63408,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 60304,
      "e": 47966,
      "ty": 2,
      "x": 839,
      "y": 933
    },
    {
      "t": 60473,
      "e": 48135,
      "ty": 3,
      "x": 839,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 60474,
      "e": 48136,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60475,
      "e": 48137,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 60504,
      "e": 48166,
      "ty": 41,
      "x": 63408,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 60568,
      "e": 48230,
      "ty": 4,
      "x": 63408,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 60568,
      "e": 48230,
      "ty": 5,
      "x": 839,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 60569,
      "e": 48231,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 60904,
      "e": 48566,
      "ty": 2,
      "x": 900,
      "y": 990
    },
    {
      "t": 61004,
      "e": 48666,
      "ty": 41,
      "x": 21259,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 61004,
      "e": 48666,
      "ty": 2,
      "x": 911,
      "y": 1004
    },
    {
      "t": 61104,
      "e": 48766,
      "ty": 2,
      "x": 911,
      "y": 1010
    },
    {
      "t": 61254,
      "e": 48916,
      "ty": 41,
      "x": 42044,
      "y": 9929,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61338,
      "e": 49000,
      "ty": 3,
      "x": 911,
      "y": 1010,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61339,
      "e": 49001,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 61339,
      "e": 49001,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61448,
      "e": 49110,
      "ty": 4,
      "x": 42044,
      "y": 9929,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61448,
      "e": 49110,
      "ty": 5,
      "x": 911,
      "y": 1010,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61451,
      "e": 49113,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61452,
      "e": 49114,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 61452,
      "e": 49114,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 62705,
      "e": 50367,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 64104,
      "e": 51766,
      "ty": 2,
      "x": 870,
      "y": 985
    },
    {
      "t": 64203,
      "e": 51865,
      "ty": 2,
      "x": 804,
      "y": 946
    },
    {
      "t": 64254,
      "e": 51916,
      "ty": 41,
      "x": 22755,
      "y": 54546,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 64303,
      "e": 51965,
      "ty": 2,
      "x": 748,
      "y": 910
    },
    {
      "t": 64503,
      "e": 52165,
      "ty": 41,
      "x": 22559,
      "y": 54200,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 64503,
      "e": 52165,
      "ty": 2,
      "x": 752,
      "y": 909
    },
    {
      "t": 64603,
      "e": 52265,
      "ty": 2,
      "x": 859,
      "y": 953
    },
    {
      "t": 64703,
      "e": 52365,
      "ty": 2,
      "x": 899,
      "y": 1008
    },
    {
      "t": 64753,
      "e": 52415,
      "ty": 41,
      "x": 30725,
      "y": 63271,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 64803,
      "e": 52465,
      "ty": 2,
      "x": 923,
      "y": 1049
    },
    {
      "t": 64904,
      "e": 52566,
      "ty": 2,
      "x": 939,
      "y": 1072
    },
    {
      "t": 65003,
      "e": 52665,
      "ty": 41,
      "x": 17749,
      "y": 8312,
      "ta": "#start"
    },
    {
      "t": 65003,
      "e": 52665,
      "ty": 2,
      "x": 942,
      "y": 1077
    },
    {
      "t": 65103,
      "e": 52765,
      "ty": 2,
      "x": 943,
      "y": 1078
    },
    {
      "t": 65253,
      "e": 52915,
      "ty": 41,
      "x": 18841,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 65303,
      "e": 52965,
      "ty": 2,
      "x": 945,
      "y": 1080
    },
    {
      "t": 65403,
      "e": 53065,
      "ty": 2,
      "x": 947,
      "y": 1081
    },
    {
      "t": 65503,
      "e": 53165,
      "ty": 41,
      "x": 21571,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 65503,
      "e": 53165,
      "ty": 2,
      "x": 949,
      "y": 1081
    },
    {
      "t": 70003,
      "e": 57665,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 81578,
      "e": 58165,
      "ty": 3,
      "x": 949,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 81580,
      "e": 58167,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 81696,
      "e": 58283,
      "ty": 4,
      "x": 21571,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 81697,
      "e": 58284,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 81697,
      "e": 58284,
      "ty": 5,
      "x": 949,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 81698,
      "e": 58285,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 82731,
      "e": 59318,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 83485,
      "e": 60072,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":54},{\"id\":55},{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"nodeType\":3,\"id\":1571,\"textContent\":\" $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"full\\\"; } else if (axis == 2){ axis = \\\"partial\\\"; } else if (axis ==3){ axis = \\\"diagonal\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":1568},{\"id\":1569},{\"nodeType\":3,\"id\":1572,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":1570}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1573,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":1573},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1575,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":1574},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1576,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":1575},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1577,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":1574}},{\"nodeType\":1,\"id\":1578,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":1577},\"parentNode\":{\"id\":1574}},{\"nodeType\":3,\"id\":1579,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":1577}},{\"nodeType\":1,\"id\":1580,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":1575}},{\"nodeType\":1,\"id\":1581,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":1580},\"parentNode\":{\"id\":1575}},{\"nodeType\":3,\"id\":1582,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":1580}},{\"nodeType\":3,\"id\":1583,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":1576}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":1573},{\"id\":1574},{\"id\":1577},{\"id\":1579},{\"id\":1578},{\"id\":1575},{\"id\":1580},{\"id\":1582},{\"id\":1581},{\"id\":1576},{\"id\":1583}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1584,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":53}},{\"nodeType\":1,\"id\":1585,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":1584}},{\"nodeType\":1,\"id\":1586,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1585},\"parentNode\":{\"id\":1584}},{\"nodeType\":1,\"id\":1587,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1586},\"parentNode\":{\"id\":1584}},{\"nodeType\":1,\"id\":1588,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1587},\"parentNode\":{\"id\":1584}},{\"nodeType\":1,\"id\":1589,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":1588},\"parentNode\":{\"id\":1584}},{\"nodeType\":1,\"id\":1590,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":1589},\"parentNode\":{\"id\":1584}},{\"nodeType\":1,\"id\":1591,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1586}},{\"nodeType\":1,\"id\":1592,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1591},\"parentNode\":{\"id\":1586}},{\"nodeType\":1,\"id\":1593,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1592},\"parentNode\":{\"id\":1586}},{\"nodeType\":1,\"id\":1594,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1593},\"parentNode\":{\"id\":1586}},{\"nodeType\":1,\"id\":1595,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1594},\"parentNode\":{\"id\":1586}},{\"nodeType\":3,\"id\":1596,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":1591}},{\"nodeType\":1,\"id\":1597,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1596},\"parentNode\":{\"id\":1591}},{\"nodeType\":1,\"id\":1598,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1592}},{\"nodeType\":1,\"id\":1599,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1598}},{\"nodeType\":3,\"id\":1600,\"textContent\":\"English\",\"previousSibling\":{\"id\":1599},\"parentNode\":{\"id\":1598}},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1593}},{\"nodeType\":1,\"id\":1602,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1601}},{\"nodeType\":3,\"id\":1603,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":1602},\"parentNode\":{\"id\":1601}},{\"nodeType\":1,\"id\":1604,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1594}},{\"nodeType\":1,\"id\":1605,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1604}},{\"nodeType\":3,\"id\":1606,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":1605},\"parentNode\":{\"id\":1604}},{\"nodeType\":1,\"id\":1607,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1595}},{\"nodeType\":1,\"id\":1608,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1607}},{\"nodeType\":3,\"id\":1609,\"textContent\":\"Other\",\"previousSibling\":{\"id\":1608},\"parentNode\":{\"id\":1607}},{\"nodeType\":3,\"id\":1610,\"textContent\":\"*\",\"parentNode\":{\"id\":1597}},{\"nodeType\":1,\"id\":1611,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1587}},{\"nodeType\":1,\"id\":1612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1611},\"parentNode\":{\"id\":1587}},{\"nodeType\":1,\"id\":1613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1612},\"parentNode\":{\"id\":1587}},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1613},\"parentNode\":{\"id\":1587}},{\"nodeType\":1,\"id\":1615,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1614},\"parentNode\":{\"id\":1587}},{\"nodeType\":1,\"id\":1616,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1615},\"parentNode\":{\"id\":1587}},{\"nodeType\":1,\"id\":1617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1616},\"parentNode\":{\"id\":1587}},{\"nodeType\":1,\"id\":1618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1617},\"parentNode\":{\"id\":1587}},{\"nodeType\":3,\"id\":1619,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":1611}},{\"nodeType\":1,\"id\":1620,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1619},\"parentNode\":{\"id\":1611}},{\"nodeType\":1,\"id\":1621,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1612}},{\"nodeType\":1,\"id\":1622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1621}},{\"nodeType\":3,\"id\":1623,\"textContent\":\"First\",\"previousSibling\":{\"id\":1622},\"parentNode\":{\"id\":1621}},{\"nodeType\":1,\"id\":1624,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1613}},{\"nodeType\":1,\"id\":1625,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1624}},{\"nodeType\":3,\"id\":1626,\"textContent\":\"Second\",\"previousSibling\":{\"id\":1625},\"parentNode\":{\"id\":1624}},{\"nodeType\":1,\"id\":1627,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1614}},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1627}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"Third\",\"previousSibling\":{\"id\":1628},\"parentNode\":{\"id\":1627}},{\"nodeType\":1,\"id\":1630,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1615}},{\"nodeType\":1,\"id\":1631,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1630}},{\"nodeType\":3,\"id\":1632,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":1631},\"parentNode\":{\"id\":1630}},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1616}},{\"nodeType\":1,\"id\":1634,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1633}},{\"nodeType\":3,\"id\":1635,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":1634},\"parentNode\":{\"id\":1633}},{\"nodeType\":1,\"id\":1636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1617}},{\"nodeType\":1,\"id\":1637,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1636}},{\"nodeType\":3,\"id\":1638,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":1637},\"parentNode\":{\"id\":1636}},{\"nodeType\":1,\"id\":1639,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1618}},{\"nodeType\":1,\"id\":1640,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1639}},{\"nodeType\":3,\"id\":1641,\"textContent\":\"Other\",\"previousSibling\":{\"id\":1640},\"parentNode\":{\"id\":1639}},{\"nodeType\":3,\"id\":1642,\"textContent\":\"*\",\"parentNode\":{\"id\":1620}},{\"nodeType\":1,\"id\":1643,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1588}},{\"nodeType\":1,\"id\":1644,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1643},\"parentNode\":{\"id\":1588}},{\"nodeType\":1,\"id\":1645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1644},\"parentNode\":{\"id\":1588}},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1645},\"parentNode\":{\"id\":1588}},{\"nodeType\":1,\"id\":1647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1646},\"parentNode\":{\"id\":1588}},{\"nodeType\":1,\"id\":1648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1647},\"parentNode\":{\"id\":1588}},{\"nodeType\":1,\"id\":1649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1648},\"parentNode\":{\"id\":1588}},{\"nodeType\":1,\"id\":1650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1649},\"parentNode\":{\"id\":1588}},{\"nodeType\":3,\"id\":1651,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":1643}},{\"nodeType\":1,\"id\":1652,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1651},\"parentNode\":{\"id\":1643}},{\"nodeType\":1,\"id\":1653,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1644}},{\"nodeType\":1,\"id\":1654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1653}},{\"nodeType\":3,\"id\":1655,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":1654},\"parentNode\":{\"id\":1653}},{\"nodeType\":1,\"id\":1656,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1645}},{\"nodeType\":1,\"id\":1657,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1656}},{\"nodeType\":3,\"id\":1658,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":1657},\"parentNode\":{\"id\":1656}},{\"nodeType\":1,\"id\":1659,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1646}},{\"nodeType\":1,\"id\":1660,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1659}},{\"nodeType\":3,\"id\":1661,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":1660},\"parentNode\":{\"id\":1659}},{\"nodeType\":1,\"id\":1662,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1647}},{\"nodeType\":1,\"id\":1663,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1662}},{\"nodeType\":3,\"id\":1664,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":1663},\"parentNode\":{\"id\":1662}},{\"nodeType\":1,\"id\":1665,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1648}},{\"nodeType\":1,\"id\":1666,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1665}},{\"nodeType\":3,\"id\":1667,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":1666},\"parentNode\":{\"id\":1665}},{\"nodeType\":1,\"id\":1668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1649}},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1668}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":1669},\"parentNode\":{\"id\":1668}},{\"nodeType\":1,\"id\":1671,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1650}},{\"nodeType\":1,\"id\":1672,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1671}},{\"nodeType\":3,\"id\":1673,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":1672},\"parentNode\":{\"id\":1671}},{\"nodeType\":3,\"id\":1674,\"textContent\":\"*\",\"parentNode\":{\"id\":1652}},{\"nodeType\":1,\"id\":1675,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":1589}},{\"nodeType\":1,\"id\":1676,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1675},\"parentNode\":{\"id\":1589}},{\"nodeType\":1,\"id\":1677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1676},\"parentNode\":{\"id\":1589}},{\"nodeType\":1,\"id\":1678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":1677},\"parentNode\":{\"id\":1589}},{\"nodeType\":3,\"id\":1679,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":1675}},{\"nodeType\":1,\"id\":1680,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":1679},\"parentNode\":{\"id\":1675}},{\"nodeType\":1,\"id\":1681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1676}},{\"nodeType\":1,\"id\":1682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1681}},{\"nodeType\":3,\"id\":1683,\"textContent\":\"Male\",\"previousSibling\":{\"id\":1682},\"parentNode\":{\"id\":1681}},{\"nodeType\":1,\"id\":1684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1677}},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1684}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"Female\",\"previousSibling\":{\"id\":1685},\"parentNode\":{\"id\":1684}},{\"nodeType\":1,\"id\":1687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":1678}},{\"nodeType\":1,\"id\":1688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":1687}},{\"nodeType\":3,\"id\":1689,\"textContent\":\"Other\",\"previousSibling\":{\"id\":1688},\"parentNode\":{\"id\":1687}},{\"nodeType\":3,\"id\":1690,\"textContent\":\"*\",\"parentNode\":{\"id\":1680}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1591},{\"id\":1596},{\"id\":1597},{\"id\":1610},{\"id\":1592},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1593},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1594},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1595},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1587},{\"id\":1611},{\"id\":1619},{\"id\":1620},{\"id\":1642},{\"id\":1612},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1613},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1614},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1615},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1616},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1617},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1618},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1588},{\"id\":1643},{\"id\":1651},{\"id\":1652},{\"id\":1674},{\"id\":1644},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1645},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1646},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1647},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1648},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1649},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1650},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1589},{\"id\":1675},{\"id\":1679},{\"id\":1680},{\"id\":1690},{\"id\":1676},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1677},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1678},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1590}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1691,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":53}},{\"nodeType\":3,\"id\":1692,\"textContent\":\" \",\"previousSibling\":{\"id\":1691},\"parentNode\":{\"id\":53}},{\"nodeType\":3,\"id\":1693,\"textContent\":\" \",\"parentNode\":{\"id\":1691}},{\"nodeType\":1,\"id\":1694,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":1693},\"parentNode\":{\"id\":1691}},{\"nodeType\":3,\"id\":1695,\"textContent\":\" \",\"previousSibling\":{\"id\":1694},\"parentNode\":{\"id\":1691}},{\"nodeType\":1,\"id\":1696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":1695},\"parentNode\":{\"id\":1691}},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \",\"previousSibling\":{\"id\":1696},\"parentNode\":{\"id\":1691}},{\"nodeType\":1,\"id\":1698,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":1697},\"parentNode\":{\"id\":1691}},{\"nodeType\":3,\"id\":1699,\"textContent\":\" \",\"previousSibling\":{\"id\":1698},\"parentNode\":{\"id\":1691}},{\"nodeType\":3,\"id\":1700,\"textContent\":\" \",\"parentNode\":{\"id\":1694}},{\"nodeType\":1,\"id\":1701,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":1700},\"parentNode\":{\"id\":1694}},{\"nodeType\":3,\"id\":1702,\"textContent\":\" \",\"previousSibling\":{\"id\":1701},\"parentNode\":{\"id\":1694}},{\"nodeType\":3,\"id\":1703,\"textContent\":\" \",\"parentNode\":{\"id\":1701}},{\"nodeType\":1,\"id\":1704,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":1703},\"parentNode\":{\"id\":1701}},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \",\"previousSibling\":{\"id\":1704},\"parentNode\":{\"id\":1701}},{\"nodeType\":3,\"id\":1706,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":1704}},{\"nodeType\":3,\"id\":1707,\"textContent\":\" \",\"parentNode\":{\"id\":1696}},{\"nodeType\":1,\"id\":1708,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":1707},\"parentNode\":{\"id\":1696}},{\"nodeType\":3,\"id\":1709,\"textContent\":\" \",\"previousSibling\":{\"id\":1708},\"parentNode\":{\"id\":1696}},{\"nodeType\":3,\"id\":1710,\"textContent\":\" \",\"parentNode\":{\"id\":1708}},{\"nodeType\":1,\"id\":1711,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":1710},\"parentNode\":{\"id\":1708}},{\"nodeType\":1,\"id\":1712,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":1711},\"parentNode\":{\"id\":1708}},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \",\"previousSibling\":{\"id\":1712},\"parentNode\":{\"id\":1708}},{\"nodeType\":1,\"id\":1714,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":1713},\"parentNode\":{\"id\":1708}},{\"nodeType\":3,\"id\":1715,\"textContent\":\" \",\"previousSibling\":{\"id\":1714},\"parentNode\":{\"id\":1708}},{\"nodeType\":1,\"id\":1716,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":1715},\"parentNode\":{\"id\":1708}},{\"nodeType\":3,\"id\":1717,\"textContent\":\" \",\"previousSibling\":{\"id\":1716},\"parentNode\":{\"id\":1708}},{\"nodeType\":1,\"id\":1718,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":1717},\"parentNode\":{\"id\":1708}},{\"nodeType\":3,\"id\":1719,\"textContent\":\" \",\"previousSibling\":{\"id\":1718},\"parentNode\":{\"id\":1708}},{\"nodeType\":1,\"id\":1720,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":1719},\"parentNode\":{\"id\":1708}},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \",\"previousSibling\":{\"id\":1720},\"parentNode\":{\"id\":1708}},{\"nodeType\":3,\"id\":1722,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":1711}},{\"nodeType\":3,\"id\":1723,\"textContent\":\" \",\"parentNode\":{\"id\":1712}},{\"nodeType\":1,\"id\":1724,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":1723},\"parentNode\":{\"id\":1712}},{\"nodeType\":3,\"id\":1725,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":1724},\"parentNode\":{\"id\":1712}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":1724}},{\"nodeType\":3,\"id\":1727,\"textContent\":\" \",\"parentNode\":{\"id\":1714}},{\"nodeType\":1,\"id\":1728,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":1727},\"parentNode\":{\"id\":1714}},{\"nodeType\":3,\"id\":1729,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":1728},\"parentNode\":{\"id\":1714}},{\"nodeType\":3,\"id\":1730,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":1728}},{\"nodeType\":1,\"id\":1731,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":1716}},{\"nodeType\":3,\"id\":1732,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":1731},\"parentNode\":{\"id\":1716}},{\"nodeType\":3,\"id\":1733,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":1731}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":1718}},{\"nodeType\":3,\"id\":1735,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":1720}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \",\"parentNode\":{\"id\":1698}},{\"nodeType\":1,\"id\":1737,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":1736},\"parentNode\":{\"id\":1698}},{\"nodeType\":3,\"id\":1738,\"textContent\":\" \",\"previousSibling\":{\"id\":1737},\"parentNode\":{\"id\":1698}},{\"nodeType\":3,\"id\":1739,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":1737}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":1691},{\"id\":1693},{\"id\":1694},{\"id\":1700},{\"id\":1701},{\"id\":1703},{\"id\":1704},{\"id\":1706},{\"id\":1705},{\"id\":1702},{\"id\":1695},{\"id\":1696},{\"id\":1707},{\"id\":1708},{\"id\":1710},{\"id\":1711},{\"id\":1722},{\"id\":1712},{\"id\":1723},{\"id\":1724},{\"id\":1726},{\"id\":1725},{\"id\":1713},{\"id\":1714},{\"id\":1727},{\"id\":1728},{\"id\":1730},{\"id\":1729},{\"id\":1715},{\"id\":1716},{\"id\":1731},{\"id\":1733},{\"id\":1732},{\"id\":1717},{\"id\":1718},{\"id\":1734},{\"id\":1719},{\"id\":1720},{\"id\":1735},{\"id\":1721},{\"id\":1709},{\"id\":1697},{\"id\":1698},{\"id\":1736},{\"id\":1737},{\"id\":1739},{\"id\":1738},{\"id\":1699},{\"id\":1692}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":1740,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":53}},{\"nodeType\":3,\"id\":1741,\"textContent\":\"[ { \\\"rt\\\": 196715, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 196720, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 5267, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 203226, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 6915, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"bravo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 211162, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 14632, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 226938, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 34609, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 262550, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 61750, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 325655, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-11 AM-11 AM-11:30-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1916,y:748,t:1512497833597};\\\", \\\"{x:1912,y:748,t:1512497833605};\\\", \\\"{x:1900,y:750,t:1512497833620};\\\", \\\"{x:1882,y:752,t:1512497833637};\\\", \\\"{x:1857,y:752,t:1512497833654};\\\", \\\"{x:1829,y:747,t:1512497833671};\\\", \\\"{x:1795,y:746,t:1512497833688};\\\", \\\"{x:1756,y:746,t:1512497833704};\\\", \\\"{x:1706,y:746,t:1512497833721};\\\", \\\"{x:1663,y:746,t:1512497833738};\\\", \\\"{x:1623,y:753,t:1512497833754};\\\", \\\"{x:1607,y:759,t:1512497833771};\\\", \\\"{x:1593,y:765,t:1512497833788};\\\", \\\"{x:1582,y:770,t:1512497833804};\\\", \\\"{x:1558,y:784,t:1512497833821};\\\", \\\"{x:1543,y:790,t:1512497833838};\\\", \\\"{x:1525,y:796,t:1512497833854};\\\", \\\"{x:1502,y:798,t:1512497833871};\\\", \\\"{x:1481,y:801,t:1512497833888};\\\", \\\"{x:1466,y:802,t:1512497833904};\\\", \\\"{x:1453,y:805,t:1512497833921};\\\", \\\"{x:1446,y:806,t:1512497833939};\\\", \\\"{x:1436,y:805,t:1512497833955};\\\", \\\"{x:1427,y:801,t:1512497833972};\\\", \\\"{x:1415,y:796,t:1512497833989};\\\", \\\"{x:1399,y:788,t:1512497834005};\\\", \\\"{x:1373,y:772,t:1512497834022};\\\", \\\"{x:1348,y:756,t:1512497834039};\\\", \\\"{x:1318,y:744,t:1512497834055};\\\", \\\"{x:1293,y:733,t:1512497834072};\\\", \\\"{x:1272,y:726,t:1512497834089};\\\", \\\"{x:1249,y:720,t:1512497834106};\\\", \\\"{x:1222,y:717,t:1512497834122};\\\", \\\"{x:1186,y:710,t:1512497834139};\\\", \\\"{x:1156,y:708,t:1512497834156};\\\", \\\"{x:1119,y:702,t:1512497834172};\\\", \\\"{x:1066,y:696,t:1512497834189};\\\", \\\"{x:1036,y:703,t:1512497834206};\\\", \\\"{x:1025,y:715,t:1512497834222};\\\", \\\"{x:1023,y:722,t:1512497834239};\\\", \\\"{x:1021,y:723,t:1512497835302};\\\", \\\"{x:1021,y:722,t:1512497835422};\\\", \\\"{x:1021,y:721,t:1512497835440};\\\", \\\"{x:1021,y:720,t:1512497835461};\\\", \\\"{x:1020,y:719,t:1512497835493};\\\", \\\"{x:1019,y:719,t:1512497835726};\\\", \\\"{x:1018,y:719,t:1512497835741};\\\", \\\"{x:1018,y:721,t:1512497836094};\\\", \\\"{x:1018,y:722,t:1512497836109};\\\", \\\"{x:1018,y:724,t:1512497836125};\\\", \\\"{x:1018,y:726,t:1512497836141};\\\", \\\"{x:1018,y:728,t:1512497836157};\\\", \\\"{x:1018,y:732,t:1512497836173};\\\", \\\"{x:1018,y:736,t:1512497836190};\\\", \\\"{x:1018,y:741,t:1512497836207};\\\", \\\"{x:1018,y:745,t:1512497836224};\\\", \\\"{x:1018,y:750,t:1512497836240};\\\", \\\"{x:1020,y:755,t:1512497836257};\\\", \\\"{x:1021,y:760,t:1512497836274};\\\", \\\"{x:1023,y:765,t:1512497836291};\\\", \\\"{x:1026,y:771,t:1512497836307};\\\", \\\"{x:1031,y:779,t:1512497836324};\\\", \\\"{x:1033,y:786,t:1512497836341};\\\", \\\"{x:1037,y:794,t:1512497836357};\\\", \\\"{x:1043,y:810,t:1512497836373};\\\", \\\"{x:1047,y:819,t:1512497836391};\\\", \\\"{x:1052,y:830,t:1512497836407};\\\", \\\"{x:1056,y:838,t:1512497836424};\\\", \\\"{x:1060,y:847,t:1512497836441};\\\", \\\"{x:1064,y:853,t:1512497836457};\\\", \\\"{x:1066,y:861,t:1512497836474};\\\", \\\"{x:1069,y:869,t:1512497836491};\\\", \\\"{x:1071,y:876,t:1512497836507};\\\", \\\"{x:1073,y:885,t:1512497836524};\\\", \\\"{x:1077,y:894,t:1512497836541};\\\", \\\"{x:1081,y:905,t:1512497836557};\\\", \\\"{x:1086,y:915,t:1512497836573};\\\", \\\"{x:1090,y:922,t:1512497836591};\\\", \\\"{x:1091,y:926,t:1512497836607};\\\", \\\"{x:1093,y:929,t:1512497836624};\\\", \\\"{x:1094,y:934,t:1512497836641};\\\", \\\"{x:1096,y:937,t:1512497836657};\\\", \\\"{x:1097,y:945,t:1512497836674};\\\", \\\"{x:1099,y:952,t:1512497836691};\\\", \\\"{x:1102,y:961,t:1512497836709};\\\", \\\"{x:1103,y:966,t:1512497836727};\\\", \\\"{x:1103,y:969,t:1512497836740};\\\", \\\"{x:1105,y:974,t:1512497836756};\\\", \\\"{x:1105,y:977,t:1512497836773};\\\", \\\"{x:1105,y:980,t:1512497836790};\\\", \\\"{x:1105,y:982,t:1512497836807};\\\", \\\"{x:1105,y:985,t:1512497836823};\\\", \\\"{x:1105,y:987,t:1512497836840};\\\", \\\"{x:1105,y:989,t:1512497836857};\\\", \\\"{x:1105,y:992,t:1512497836873};\\\", \\\"{x:1105,y:993,t:1512497836890};\\\", \\\"{x:1104,y:995,t:1512497836907};\\\", \\\"{x:1103,y:996,t:1512497836924};\\\", \\\"{x:1102,y:998,t:1512497836940};\\\", \\\"{x:1102,y:999,t:1512497836957};\\\", \\\"{x:1101,y:1001,t:1512497836973};\\\", \\\"{x:1101,y:1002,t:1512497836997};\\\", \\\"{x:1101,y:1003,t:1512497837007};\\\", \\\"{x:1101,y:1004,t:1512497837024};\\\", \\\"{x:1100,y:1006,t:1512497837040};\\\", \\\"{x:1099,y:1007,t:1512497837058};\\\", \\\"{x:1098,y:1008,t:1512497837174};\\\", \\\"{x:1097,y:1008,t:1512497837197};\\\", \\\"{x:1096,y:1008,t:1512497837208};\\\", \\\"{x:1095,y:1008,t:1512497837225};\\\", \\\"{x:1090,y:1008,t:1512497837241};\\\", \\\"{x:1087,y:1008,t:1512497837258};\\\", \\\"{x:1083,y:1008,t:1512497837275};\\\", \\\"{x:1081,y:1008,t:1512497837291};\\\", \\\"{x:1079,y:1008,t:1512497837308};\\\", \\\"{x:1076,y:1008,t:1512497837325};\\\", \\\"{x:1075,y:1008,t:1512497837349};\\\", \\\"{x:1074,y:1008,t:1512497837357};\\\", \\\"{x:1072,y:1007,t:1512497837374};\\\", \\\"{x:1070,y:1006,t:1512497837390};\\\", \\\"{x:1069,y:1005,t:1512497837407};\\\", \\\"{x:1067,y:1004,t:1512497837424};\\\", \\\"{x:1066,y:1004,t:1512497837440};\\\", \\\"{x:1064,y:1004,t:1512497837457};\\\", \\\"{x:1063,y:1004,t:1512497837474};\\\", \\\"{x:1062,y:1003,t:1512497837490};\\\", \\\"{x:1060,y:1002,t:1512497837507};\\\", \\\"{x:1057,y:1001,t:1512497837524};\\\", \\\"{x:1051,y:999,t:1512497837540};\\\", \\\"{x:1048,y:998,t:1512497837557};\\\", \\\"{x:1046,y:998,t:1512497837589};\\\", \\\"{x:1046,y:997,t:1512497837597};\\\", \\\"{x:1045,y:997,t:1512497837629};\\\", \\\"{x:1043,y:997,t:1512497837645};\\\", \\\"{x:1043,y:996,t:1512497837846};\\\", \\\"{x:1043,y:994,t:1512497837902};\\\", \\\"{x:1044,y:994,t:1512497837933};\\\", \\\"{x:1045,y:993,t:1512497838061};\\\", \\\"{x:1045,y:992,t:1512497838117};\\\", \\\"{x:1045,y:991,t:1512497838140};\\\", \\\"{x:1046,y:991,t:1512497838158};\\\", \\\"{x:1046,y:989,t:1512497838196};\\\", \\\"{x:1046,y:988,t:1512497838374};\\\", \\\"{x:1046,y:986,t:1512497838421};\\\", \\\"{x:1048,y:985,t:1512497838437};\\\", \\\"{x:1048,y:984,t:1512497838469};\\\", \\\"{x:1049,y:982,t:1512497838477};\\\", \\\"{x:1049,y:981,t:1512497838526};\\\", \\\"{x:1049,y:980,t:1512497838549};\\\", \\\"{x:1049,y:979,t:1512497838566};\\\", \\\"{x:1049,y:978,t:1512497838576};\\\", \\\"{x:1050,y:977,t:1512497838592};\\\", \\\"{x:1050,y:976,t:1512497838609};\\\", \\\"{x:1050,y:975,t:1512497838626};\\\", \\\"{x:1050,y:974,t:1512497838642};\\\", \\\"{x:1050,y:973,t:1512497838677};\\\", \\\"{x:1050,y:972,t:1512497838758};\\\", \\\"{x:1050,y:970,t:1512497838805};\\\", \\\"{x:1049,y:969,t:1512497838821};\\\", \\\"{x:1048,y:969,t:1512497838845};\\\", \\\"{x:1047,y:969,t:1512497838861};\\\", \\\"{x:1046,y:969,t:1512497838910};\\\", \\\"{x:1044,y:968,t:1512497838957};\\\", \\\"{x:1043,y:968,t:1512497840773};\\\", \\\"{x:1042,y:968,t:1512497840782};\\\", \\\"{x:1041,y:968,t:1512497840797};\\\", \\\"{x:1040,y:969,t:1512497840821};\\\", \\\"{x:1039,y:969,t:1512497840853};\\\", \\\"{x:1040,y:969,t:1512497844982};\\\", \\\"{x:1041,y:968,t:1512497844998};\\\", \\\"{x:1041,y:967,t:1512497845014};\\\", \\\"{x:1042,y:967,t:1512497845031};\\\", \\\"{x:1040,y:962,t:1512497869944};\\\", \\\"{x:1035,y:953,t:1512497869953};\\\", \\\"{x:1032,y:948,t:1512497869970};\\\", \\\"{x:1027,y:939,t:1512497869986};\\\", \\\"{x:1022,y:930,t:1512497870003};\\\", \\\"{x:1018,y:924,t:1512497870020};\\\", \\\"{x:1014,y:920,t:1512497870036};\\\", \\\"{x:1012,y:917,t:1512497870053};\\\", \\\"{x:1011,y:915,t:1512497870070};\\\", \\\"{x:1009,y:911,t:1512497870086};\\\", \\\"{x:1007,y:907,t:1512497870103};\\\", \\\"{x:1003,y:902,t:1512497870119};\\\", \\\"{x:1001,y:898,t:1512497870137};\\\", \\\"{x:999,y:896,t:1512497870152};\\\", \\\"{x:998,y:893,t:1512497870169};\\\", \\\"{x:997,y:889,t:1512497870186};\\\", \\\"{x:996,y:886,t:1512497870202};\\\", \\\"{x:995,y:881,t:1512497870219};\\\", \\\"{x:992,y:875,t:1512497870236};\\\", \\\"{x:988,y:869,t:1512497870252};\\\", \\\"{x:987,y:865,t:1512497870269};\\\", \\\"{x:985,y:862,t:1512497870286};\\\", \\\"{x:985,y:858,t:1512497870302};\\\", \\\"{x:983,y:855,t:1512497870319};\\\", \\\"{x:983,y:852,t:1512497870336};\\\", \\\"{x:981,y:849,t:1512497870352};\\\", \\\"{x:981,y:848,t:1512497870369};\\\", \\\"{x:981,y:846,t:1512497870386};\\\", \\\"{x:981,y:845,t:1512497870402};\\\", \\\"{x:980,y:844,t:1512497870419};\\\", \\\"{x:980,y:843,t:1512497870447};\\\", \\\"{x:979,y:842,t:1512497870471};\\\", \\\"{x:979,y:841,t:1512497870528};\\\", \\\"{x:978,y:840,t:1512497870543};\\\", \\\"{x:977,y:840,t:1512497871248};\\\", \\\"{x:978,y:843,t:1512497871271};\\\", \\\"{x:978,y:845,t:1512497871287};\\\", \\\"{x:980,y:849,t:1512497871304};\\\", \\\"{x:983,y:855,t:1512497871321};\\\", \\\"{x:983,y:858,t:1512497871337};\\\", \\\"{x:986,y:862,t:1512497871354};\\\", \\\"{x:988,y:868,t:1512497871371};\\\", \\\"{x:990,y:870,t:1512497871387};\\\", \\\"{x:992,y:874,t:1512497871404};\\\", \\\"{x:997,y:879,t:1512497871421};\\\", \\\"{x:1001,y:884,t:1512497871437};\\\", \\\"{x:1007,y:891,t:1512497871454};\\\", \\\"{x:1021,y:900,t:1512497871471};\\\", \\\"{x:1037,y:911,t:1512497871487};\\\", \\\"{x:1050,y:919,t:1512497871504};\\\", \\\"{x:1058,y:926,t:1512497871521};\\\", \\\"{x:1067,y:932,t:1512497871538};\\\", \\\"{x:1073,y:937,t:1512497871554};\\\", \\\"{x:1080,y:944,t:1512497871571};\\\", \\\"{x:1087,y:948,t:1512497871588};\\\", \\\"{x:1091,y:952,t:1512497871604};\\\", \\\"{x:1093,y:954,t:1512497871621};\\\", \\\"{x:1094,y:955,t:1512497871638};\\\", \\\"{x:1094,y:956,t:1512497871672};\\\", \\\"{x:1094,y:957,t:1512497871695};\\\", \\\"{x:1094,y:958,t:1512497871711};\\\", \\\"{x:1093,y:958,t:1512497871727};\\\", \\\"{x:1092,y:960,t:1512497871738};\\\", \\\"{x:1090,y:960,t:1512497871754};\\\", \\\"{x:1086,y:961,t:1512497871771};\\\", \\\"{x:1083,y:961,t:1512497871788};\\\", \\\"{x:1077,y:963,t:1512497871804};\\\", \\\"{x:1074,y:964,t:1512497871821};\\\", \\\"{x:1071,y:964,t:1512497871838};\\\", \\\"{x:1066,y:965,t:1512497871854};\\\", \\\"{x:1062,y:965,t:1512497871871};\\\", \\\"{x:1055,y:965,t:1512497871887};\\\", \\\"{x:1051,y:967,t:1512497871905};\\\", \\\"{x:1049,y:968,t:1512497871921};\\\", \\\"{x:1046,y:968,t:1512497871938};\\\", \\\"{x:1045,y:968,t:1512497871955};\\\", \\\"{x:1044,y:968,t:1512497872200};\\\", \\\"{x:1043,y:968,t:1512497872207};\\\", \\\"{x:1042,y:968,t:1512497872288};\\\", \\\"{x:1042,y:967,t:1512497872368};\\\", \\\"{x:1042,y:966,t:1512497872383};\\\", \\\"{x:1042,y:965,t:1512497872407};\\\", \\\"{x:1042,y:964,t:1512497872440};\\\", \\\"{x:1041,y:963,t:1512497872455};\\\", \\\"{x:1041,y:962,t:1512497872472};\\\", \\\"{x:1041,y:961,t:1512497872495};\\\", \\\"{x:1041,y:960,t:1512497872528};\\\", \\\"{x:1041,y:959,t:1512497872543};\\\", \\\"{x:1041,y:958,t:1512497872656};\\\", \\\"{x:1041,y:957,t:1512497875304};\\\", \\\"{x:1041,y:956,t:1512497875311};\\\", \\\"{x:1041,y:955,t:1512497875343};\\\", \\\"{x:1040,y:954,t:1512497875357};\\\", \\\"{x:1039,y:954,t:1512497875374};\\\", \\\"{x:1039,y:953,t:1512497875390};\\\", \\\"{x:1038,y:952,t:1512497875407};\\\", \\\"{x:1036,y:951,t:1512497875423};\\\", \\\"{x:1033,y:948,t:1512497875441};\\\", \\\"{x:1027,y:944,t:1512497875457};\\\", \\\"{x:1015,y:939,t:1512497875474};\\\", \\\"{x:992,y:921,t:1512497875491};\\\", \\\"{x:928,y:879,t:1512497875507};\\\", \\\"{x:817,y:824,t:1512497875523};\\\", \\\"{x:666,y:762,t:1512497875540};\\\", \\\"{x:491,y:693,t:1512497875556};\\\", \\\"{x:328,y:646,t:1512497875573};\\\", \\\"{x:157,y:601,t:1512497875590};\\\", \\\"{x:80,y:593,t:1512497875606};\\\", \\\"{x:54,y:589,t:1512497875623};\\\", \\\"{x:38,y:587,t:1512497875640};\\\", \\\"{x:36,y:586,t:1512497875656};\\\", \\\"{x:37,y:584,t:1512497875673};\\\", \\\"{x:39,y:581,t:1512497875690};\\\", \\\"{x:43,y:576,t:1512497875706};\\\", \\\"{x:47,y:573,t:1512497875723};\\\", \\\"{x:49,y:571,t:1512497875740};\\\", \\\"{x:52,y:569,t:1512497875756};\\\", \\\"{x:56,y:567,t:1512497875773};\\\", \\\"{x:61,y:565,t:1512497875790};\\\", \\\"{x:68,y:562,t:1512497875806};\\\", \\\"{x:73,y:559,t:1512497875823};\\\", \\\"{x:75,y:557,t:1512497875840};\\\", \\\"{x:77,y:555,t:1512497875856};\\\", \\\"{x:82,y:552,t:1512497875873};\\\", \\\"{x:86,y:551,t:1512497875890};\\\", \\\"{x:90,y:549,t:1512497875906};\\\", \\\"{x:95,y:547,t:1512497875923};\\\", \\\"{x:101,y:544,t:1512497875940};\\\", \\\"{x:106,y:544,t:1512497875957};\\\", \\\"{x:111,y:544,t:1512497875973};\\\", \\\"{x:118,y:544,t:1512497875991};\\\", \\\"{x:124,y:546,t:1512497876007};\\\", \\\"{x:129,y:548,t:1512497876023};\\\", \\\"{x:135,y:550,t:1512497876040};\\\", \\\"{x:142,y:551,t:1512497876059};\\\", \\\"{x:152,y:553,t:1512497876073};\\\", \\\"{x:162,y:557,t:1512497876090};\\\", \\\"{x:172,y:561,t:1512497876107};\\\", \\\"{x:180,y:564,t:1512497876124};\\\", \\\"{x:185,y:566,t:1512497876141};\\\", \\\"{x:187,y:569,t:1512497876158};\\\", \\\"{x:189,y:570,t:1512497876174};\\\", \\\"{x:191,y:574,t:1512497876191};\\\", \\\"{x:196,y:576,t:1512497876207};\\\", \\\"{x:202,y:577,t:1512497876223};\\\", \\\"{x:206,y:581,t:1512497876240};\\\", \\\"{x:210,y:583,t:1512497876258};\\\", \\\"{x:214,y:585,t:1512497876273};\\\", \\\"{x:218,y:587,t:1512497876290};\\\", \\\"{x:219,y:587,t:1512497876308};\\\", \\\"{x:220,y:588,t:1512497876324};\\\", \\\"{x:221,y:588,t:1512497876343};\\\", \\\"{x:223,y:588,t:1512497876367};\\\", \\\"{x:224,y:588,t:1512497876375};\\\", \\\"{x:226,y:588,t:1512497876391};\\\", \\\"{x:231,y:586,t:1512497876408};\\\", \\\"{x:236,y:585,t:1512497876424};\\\", \\\"{x:247,y:578,t:1512497876441};\\\", \\\"{x:262,y:575,t:1512497876458};\\\", \\\"{x:282,y:570,t:1512497876475};\\\", \\\"{x:306,y:567,t:1512497876491};\\\", \\\"{x:332,y:564,t:1512497876507};\\\", \\\"{x:361,y:560,t:1512497876524};\\\", \\\"{x:399,y:559,t:1512497876542};\\\", \\\"{x:418,y:559,t:1512497876558};\\\", \\\"{x:433,y:559,t:1512497876575};\\\", \\\"{x:446,y:563,t:1512497876592};\\\", \\\"{x:453,y:567,t:1512497876608};\\\", \\\"{x:458,y:570,t:1512497876625};\\\", \\\"{x:460,y:573,t:1512497876642};\\\", \\\"{x:462,y:575,t:1512497876658};\\\", \\\"{x:463,y:576,t:1512497876675};\\\", \\\"{x:464,y:578,t:1512497876692};\\\", \\\"{x:465,y:579,t:1512497876709};\\\", \\\"{x:467,y:581,t:1512497876725};\\\", \\\"{x:472,y:583,t:1512497876742};\\\", \\\"{x:475,y:584,t:1512497876759};\\\", \\\"{x:478,y:584,t:1512497876775};\\\", \\\"{x:480,y:586,t:1512497876792};\\\", \\\"{x:483,y:586,t:1512497876809};\\\", \\\"{x:486,y:586,t:1512497876825};\\\", \\\"{x:491,y:586,t:1512497876842};\\\", \\\"{x:497,y:586,t:1512497876859};\\\", \\\"{x:502,y:586,t:1512497876875};\\\", \\\"{x:513,y:586,t:1512497876892};\\\", \\\"{x:521,y:585,t:1512497876909};\\\", \\\"{x:530,y:585,t:1512497876925};\\\", \\\"{x:539,y:585,t:1512497876943};\\\", \\\"{x:544,y:585,t:1512497876959};\\\", \\\"{x:547,y:585,t:1512497876975};\\\", \\\"{x:551,y:585,t:1512497876992};\\\", \\\"{x:554,y:585,t:1512497877009};\\\", \\\"{x:556,y:585,t:1512497877026};\\\", \\\"{x:557,y:585,t:1512497877047};\\\", \\\"{x:558,y:585,t:1512497877062};\\\", \\\"{x:559,y:584,t:1512497877075};\\\", \\\"{x:561,y:583,t:1512497877102};\\\", \\\"{x:563,y:582,t:1512497877118};\\\", \\\"{x:564,y:581,t:1512497877134};\\\", \\\"{x:566,y:580,t:1512497877142};\\\", \\\"{x:567,y:579,t:1512497877159};\\\", \\\"{x:568,y:579,t:1512497877177};\\\", \\\"{x:571,y:577,t:1512497877192};\\\", \\\"{x:571,y:576,t:1512497877209};\\\", \\\"{x:572,y:576,t:1512497877226};\\\", \\\"{x:575,y:574,t:1512497877262};\\\", \\\"{x:576,y:573,t:1512497877278};\\\", \\\"{x:578,y:572,t:1512497877292};\\\", \\\"{x:579,y:572,t:1512497877309};\\\", \\\"{x:580,y:572,t:1512497877326};\\\", \\\"{x:582,y:571,t:1512497877358};\\\", \\\"{x:578,y:572,t:1512497888031};\\\", \\\"{x:570,y:576,t:1512497888038};\\\", \\\"{x:561,y:582,t:1512497888052};\\\", \\\"{x:540,y:597,t:1512497888068};\\\", \\\"{x:498,y:625,t:1512497888085};\\\", \\\"{x:462,y:648,t:1512497888102};\\\", \\\"{x:418,y:675,t:1512497888119};\\\", \\\"{x:379,y:702,t:1512497888136};\\\", \\\"{x:371,y:706,t:1512497888152};\\\", \\\"{x:368,y:708,t:1512497888168};\\\", \\\"{x:370,y:707,t:1512497888352};\\\", \\\"{x:372,y:701,t:1512497888369};\\\", \\\"{x:376,y:696,t:1512497888385};\\\", \\\"{x:379,y:691,t:1512497888403};\\\", \\\"{x:380,y:689,t:1512497888419};\\\", \\\"{x:382,y:687,t:1512497888436};\\\", \\\"{x:383,y:686,t:1512497888452};\\\", \\\"{x:384,y:685,t:1512497888479};\\\", \\\"{x:386,y:686,t:1512497888968};\\\", \\\"{x:387,y:689,t:1512497888975};\\\", \\\"{x:388,y:690,t:1512497888987};\\\", \\\"{x:390,y:696,t:1512497889005};\\\", \\\"{x:392,y:701,t:1512497889021};\\\", \\\"{x:392,y:705,t:1512497889036};\\\", \\\"{x:393,y:707,t:1512497889053};\\\", \\\"{x:393,y:708,t:1512497889071};\\\", \\\"{x:393,y:707,t:1512497889279};\\\", \\\"{x:394,y:704,t:1512497889287};\\\", \\\"{x:394,y:702,t:1512497889303};\\\", \\\"{x:395,y:700,t:1512497889320};\\\", \\\"{x:396,y:700,t:1512497889336};\\\", \\\"{x:396,y:699,t:1512497889353};\\\", \\\"{x:396,y:698,t:1512497889776};\\\", \\\"{x:396,y:697,t:1512497889791};\\\", \\\"{x:396,y:695,t:1512497889803};\\\", \\\"{x:396,y:692,t:1512497889821};\\\", \\\"{x:396,y:689,t:1512497889837};\\\", \\\"{x:396,y:687,t:1512497889853};\\\", \\\"{x:396,y:685,t:1512497889870};\\\", \\\"{x:396,y:684,t:1512497889886};\\\", \\\"{x:396,y:682,t:1512497889903};\\\", \\\"{x:396,y:681,t:1512497889920};\\\", \\\"{x:396,y:679,t:1512497889937};\\\", \\\"{x:396,y:678,t:1512497889958};\\\" ] }, { \\\"rt\\\": 57543, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 384635, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:396,y:677,t:1512497893320};\\\", \\\"{x:397,y:668,t:1512497893338};\\\", \\\"{x:398,y:660,t:1512497893353};\\\", \\\"{x:398,y:649,t:1512497893370};\\\", \\\"{x:395,y:634,t:1512497893387};\\\", \\\"{x:393,y:624,t:1512497893403};\\\", \\\"{x:386,y:610,t:1512497893423};\\\", \\\"{x:384,y:601,t:1512497893439};\\\", \\\"{x:380,y:591,t:1512497893456};\\\", \\\"{x:376,y:579,t:1512497893473};\\\", \\\"{x:372,y:567,t:1512497893490};\\\", \\\"{x:370,y:557,t:1512497893506};\\\", \\\"{x:366,y:549,t:1512497893523};\\\", \\\"{x:365,y:546,t:1512497893540};\\\", \\\"{x:365,y:545,t:1512497893556};\\\", \\\"{x:363,y:542,t:1512497893573};\\\", \\\"{x:363,y:539,t:1512497893590};\\\", \\\"{x:363,y:535,t:1512497893606};\\\", \\\"{x:362,y:533,t:1512497893623};\\\", \\\"{x:362,y:529,t:1512497893640};\\\", \\\"{x:362,y:527,t:1512497893656};\\\", \\\"{x:362,y:523,t:1512497893673};\\\", \\\"{x:362,y:521,t:1512497893690};\\\", \\\"{x:362,y:516,t:1512497893706};\\\", \\\"{x:363,y:512,t:1512497893724};\\\", \\\"{x:364,y:510,t:1512497893740};\\\", \\\"{x:364,y:508,t:1512497893756};\\\", \\\"{x:365,y:507,t:1512497893773};\\\", \\\"{x:365,y:506,t:1512497893790};\\\", \\\"{x:367,y:505,t:1512497893807};\\\", \\\"{x:369,y:503,t:1512497893823};\\\", \\\"{x:371,y:501,t:1512497893840};\\\", \\\"{x:372,y:500,t:1512497893857};\\\", \\\"{x:375,y:499,t:1512497893873};\\\", \\\"{x:379,y:498,t:1512497893890};\\\", \\\"{x:381,y:498,t:1512497893907};\\\", \\\"{x:385,y:498,t:1512497893923};\\\", \\\"{x:389,y:498,t:1512497893940};\\\", \\\"{x:394,y:498,t:1512497893957};\\\", \\\"{x:400,y:498,t:1512497893973};\\\", \\\"{x:407,y:499,t:1512497893990};\\\", \\\"{x:416,y:500,t:1512497894007};\\\", \\\"{x:426,y:502,t:1512497894024};\\\", \\\"{x:436,y:502,t:1512497894040};\\\", \\\"{x:450,y:502,t:1512497894057};\\\", \\\"{x:461,y:502,t:1512497894074};\\\", \\\"{x:469,y:502,t:1512497894090};\\\", \\\"{x:474,y:502,t:1512497894107};\\\", \\\"{x:476,y:502,t:1512497894124};\\\", \\\"{x:477,y:502,t:1512497894140};\\\", \\\"{x:478,y:502,t:1512497894157};\\\", \\\"{x:479,y:502,t:1512497894174};\\\", \\\"{x:479,y:503,t:1512497897888};\\\", \\\"{x:478,y:505,t:1512497897897};\\\", \\\"{x:468,y:514,t:1512497897915};\\\", \\\"{x:457,y:523,t:1512497897931};\\\", \\\"{x:442,y:534,t:1512497897948};\\\", \\\"{x:431,y:540,t:1512497897965};\\\", \\\"{x:418,y:547,t:1512497897981};\\\", \\\"{x:412,y:549,t:1512497897998};\\\", \\\"{x:407,y:552,t:1512497898014};\\\", \\\"{x:406,y:552,t:1512497898030};\\\", \\\"{x:406,y:553,t:1512497898044};\\\", \\\"{x:404,y:554,t:1512497898060};\\\", \\\"{x:403,y:555,t:1512497898077};\\\", \\\"{x:402,y:556,t:1512497898094};\\\", \\\"{x:400,y:556,t:1512497898110};\\\", \\\"{x:401,y:556,t:1512497898231};\\\", \\\"{x:403,y:556,t:1512497898244};\\\", \\\"{x:409,y:553,t:1512497898261};\\\", \\\"{x:416,y:552,t:1512497898277};\\\", \\\"{x:423,y:550,t:1512497898294};\\\", \\\"{x:426,y:549,t:1512497898311};\\\", \\\"{x:427,y:549,t:1512497898335};\\\", \\\"{x:426,y:549,t:1512497898560};\\\", \\\"{x:425,y:550,t:1512497898568};\\\", \\\"{x:423,y:550,t:1512497898578};\\\", \\\"{x:420,y:552,t:1512497898595};\\\", \\\"{x:417,y:553,t:1512497898612};\\\", \\\"{x:413,y:554,t:1512497898628};\\\", \\\"{x:411,y:556,t:1512497898644};\\\", \\\"{x:407,y:557,t:1512497898661};\\\", \\\"{x:403,y:557,t:1512497898678};\\\", \\\"{x:398,y:559,t:1512497898694};\\\", \\\"{x:392,y:561,t:1512497898712};\\\", \\\"{x:388,y:562,t:1512497898728};\\\", \\\"{x:383,y:564,t:1512497898745};\\\", \\\"{x:379,y:566,t:1512497898761};\\\", \\\"{x:372,y:568,t:1512497898778};\\\", \\\"{x:367,y:570,t:1512497898795};\\\", \\\"{x:361,y:572,t:1512497898811};\\\", \\\"{x:354,y:575,t:1512497898828};\\\", \\\"{x:351,y:575,t:1512497898844};\\\", \\\"{x:349,y:577,t:1512497898861};\\\", \\\"{x:348,y:577,t:1512497898879};\\\", \\\"{x:346,y:578,t:1512497898903};\\\", \\\"{x:345,y:579,t:1512497898911};\\\", \\\"{x:342,y:579,t:1512497898928};\\\", \\\"{x:339,y:580,t:1512497898945};\\\", \\\"{x:334,y:582,t:1512497898961};\\\", \\\"{x:329,y:583,t:1512497898978};\\\", \\\"{x:325,y:584,t:1512497898995};\\\", \\\"{x:322,y:586,t:1512497899011};\\\", \\\"{x:319,y:586,t:1512497899028};\\\", \\\"{x:317,y:588,t:1512497899045};\\\", \\\"{x:316,y:588,t:1512497899061};\\\", \\\"{x:313,y:589,t:1512497899078};\\\", \\\"{x:309,y:591,t:1512497899095};\\\", \\\"{x:307,y:593,t:1512497899111};\\\", \\\"{x:304,y:595,t:1512497899128};\\\", \\\"{x:302,y:597,t:1512497899145};\\\", \\\"{x:301,y:597,t:1512497899161};\\\", \\\"{x:299,y:599,t:1512497899178};\\\", \\\"{x:297,y:600,t:1512497899195};\\\", \\\"{x:296,y:601,t:1512497899352};\\\", \\\"{x:297,y:601,t:1512497899392};\\\", \\\"{x:298,y:601,t:1512497899408};\\\", \\\"{x:299,y:601,t:1512497899416};\\\", \\\"{x:300,y:601,t:1512497899432};\\\", \\\"{x:301,y:601,t:1512497899445};\\\", \\\"{x:303,y:601,t:1512497899463};\\\", \\\"{x:305,y:601,t:1512497899479};\\\", \\\"{x:309,y:601,t:1512497899496};\\\", \\\"{x:311,y:601,t:1512497899508};\\\", \\\"{x:313,y:601,t:1512497899525};\\\", \\\"{x:316,y:601,t:1512497899541};\\\", \\\"{x:315,y:601,t:1512497900880};\\\", \\\"{x:314,y:601,t:1512497900888};\\\", \\\"{x:313,y:601,t:1512497936355};\\\", \\\"{x:316,y:599,t:1512497936363};\\\", \\\"{x:345,y:575,t:1512497936380};\\\", \\\"{x:386,y:540,t:1512497936396};\\\", \\\"{x:445,y:501,t:1512497936412};\\\", \\\"{x:506,y:472,t:1512497936429};\\\", \\\"{x:569,y:445,t:1512497936445};\\\", \\\"{x:619,y:424,t:1512497936462};\\\", \\\"{x:681,y:402,t:1512497936479};\\\", \\\"{x:747,y:377,t:1512497936495};\\\", \\\"{x:811,y:358,t:1512497936512};\\\", \\\"{x:880,y:340,t:1512497936529};\\\", \\\"{x:970,y:322,t:1512497936546};\\\", \\\"{x:1018,y:313,t:1512497936562};\\\", \\\"{x:1054,y:306,t:1512497936579};\\\", \\\"{x:1078,y:301,t:1512497936596};\\\", \\\"{x:1089,y:300,t:1512497936612};\\\", \\\"{x:1095,y:300,t:1512497936629};\\\", \\\"{x:1100,y:300,t:1512497936646};\\\", \\\"{x:1113,y:307,t:1512497936662};\\\", \\\"{x:1136,y:316,t:1512497936679};\\\", \\\"{x:1163,y:328,t:1512497936696};\\\", \\\"{x:1193,y:339,t:1512497936712};\\\", \\\"{x:1237,y:351,t:1512497936729};\\\", \\\"{x:1318,y:367,t:1512497936746};\\\", \\\"{x:1354,y:371,t:1512497936762};\\\", \\\"{x:1372,y:374,t:1512497936779};\\\", \\\"{x:1385,y:376,t:1512497936796};\\\", \\\"{x:1399,y:380,t:1512497936812};\\\", \\\"{x:1409,y:384,t:1512497936829};\\\", \\\"{x:1412,y:384,t:1512497936846};\\\", \\\"{x:1413,y:385,t:1512497936947};\\\", \\\"{x:1413,y:386,t:1512497936963};\\\", \\\"{x:1413,y:389,t:1512497936980};\\\", \\\"{x:1409,y:393,t:1512497936996};\\\", \\\"{x:1406,y:399,t:1512497937013};\\\", \\\"{x:1405,y:401,t:1512497937029};\\\", \\\"{x:1402,y:406,t:1512497937046};\\\", \\\"{x:1401,y:408,t:1512497937063};\\\", \\\"{x:1398,y:412,t:1512497937079};\\\", \\\"{x:1395,y:417,t:1512497937096};\\\", \\\"{x:1393,y:420,t:1512497937113};\\\", \\\"{x:1391,y:421,t:1512497937129};\\\", \\\"{x:1390,y:423,t:1512497937146};\\\", \\\"{x:1389,y:424,t:1512497937178};\\\", \\\"{x:1388,y:426,t:1512497937275};\\\", \\\"{x:1387,y:426,t:1512497937347};\\\", \\\"{x:1386,y:427,t:1512497937364};\\\", \\\"{x:1385,y:427,t:1512497937380};\\\", \\\"{x:1384,y:427,t:1512497937403};\\\", \\\"{x:1382,y:428,t:1512497937443};\\\", \\\"{x:1381,y:428,t:1512497937502};\\\", \\\"{x:1380,y:428,t:1512497937578};\\\", \\\"{x:1379,y:428,t:1512497939259};\\\", \\\"{x:1378,y:429,t:1512497939274};\\\", \\\"{x:1377,y:429,t:1512497939282};\\\", \\\"{x:1377,y:430,t:1512497939298};\\\", \\\"{x:1376,y:431,t:1512497939338};\\\", \\\"{x:1372,y:431,t:1512497947210};\\\", \\\"{x:1366,y:431,t:1512497947223};\\\", \\\"{x:1353,y:431,t:1512497947239};\\\", \\\"{x:1338,y:430,t:1512497947255};\\\", \\\"{x:1314,y:427,t:1512497947272};\\\", \\\"{x:1293,y:427,t:1512497947289};\\\", \\\"{x:1270,y:427,t:1512497947305};\\\", \\\"{x:1219,y:437,t:1512497947322};\\\", \\\"{x:1169,y:451,t:1512497947338};\\\", \\\"{x:1088,y:473,t:1512497947355};\\\", \\\"{x:990,y:495,t:1512497947372};\\\", \\\"{x:892,y:513,t:1512497947389};\\\", \\\"{x:779,y:539,t:1512497947405};\\\", \\\"{x:677,y:565,t:1512497947422};\\\", \\\"{x:596,y:578,t:1512497947439};\\\", \\\"{x:546,y:586,t:1512497947455};\\\", \\\"{x:515,y:589,t:1512497947472};\\\", \\\"{x:498,y:592,t:1512497947489};\\\", \\\"{x:479,y:592,t:1512497947505};\\\", \\\"{x:464,y:592,t:1512497947523};\\\", \\\"{x:460,y:592,t:1512497947539};\\\", \\\"{x:457,y:592,t:1512497947555};\\\", \\\"{x:454,y:592,t:1512497947573};\\\", \\\"{x:449,y:592,t:1512497947590};\\\", \\\"{x:444,y:592,t:1512497947606};\\\", \\\"{x:440,y:592,t:1512497947623};\\\", \\\"{x:439,y:592,t:1512497947640};\\\", \\\"{x:436,y:591,t:1512497947657};\\\", \\\"{x:431,y:591,t:1512497947672};\\\", \\\"{x:424,y:591,t:1512497947690};\\\", \\\"{x:404,y:591,t:1512497947707};\\\", \\\"{x:390,y:591,t:1512497947723};\\\", \\\"{x:375,y:591,t:1512497947739};\\\", \\\"{x:361,y:591,t:1512497947757};\\\", \\\"{x:347,y:591,t:1512497947773};\\\", \\\"{x:335,y:592,t:1512497947790};\\\", \\\"{x:322,y:593,t:1512497947807};\\\", \\\"{x:314,y:594,t:1512497947823};\\\", \\\"{x:311,y:595,t:1512497947839};\\\", \\\"{x:310,y:595,t:1512497947856};\\\", \\\"{x:310,y:597,t:1512497948035};\\\", \\\"{x:310,y:598,t:1512497948051};\\\", \\\"{x:312,y:599,t:1512497948067};\\\", \\\"{x:312,y:600,t:1512497948083};\\\", \\\"{x:313,y:600,t:1512497948139};\\\", \\\"{x:316,y:601,t:1512497948563};\\\", \\\"{x:317,y:603,t:1512497948573};\\\", \\\"{x:323,y:609,t:1512497948590};\\\", \\\"{x:329,y:615,t:1512497948606};\\\", \\\"{x:335,y:622,t:1512497948623};\\\", \\\"{x:344,y:631,t:1512497948639};\\\", \\\"{x:350,y:639,t:1512497948656};\\\", \\\"{x:357,y:646,t:1512497948673};\\\", \\\"{x:363,y:651,t:1512497948689};\\\", \\\"{x:370,y:656,t:1512497948706};\\\", \\\"{x:372,y:658,t:1512497948723};\\\", \\\"{x:375,y:661,t:1512497948739};\\\", \\\"{x:376,y:662,t:1512497948756};\\\", \\\"{x:377,y:663,t:1512497948773};\\\", \\\"{x:378,y:664,t:1512497948789};\\\", \\\"{x:381,y:666,t:1512497948806};\\\", \\\"{x:382,y:668,t:1512497948823};\\\", \\\"{x:385,y:670,t:1512497948839};\\\", \\\"{x:386,y:671,t:1512497948856};\\\" ] }, { \\\"rt\\\": 26964, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 412889, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-C -C -C -C -C -C -10:30-11 AM-11:30-12 PM-12 PM-Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:387,y:671,t:1512497953739};\\\", \\\"{x:391,y:671,t:1512497953750};\\\", \\\"{x:399,y:669,t:1512497953763};\\\", \\\"{x:404,y:667,t:1512497953779};\\\", \\\"{x:411,y:664,t:1512497953796};\\\", \\\"{x:418,y:661,t:1512497953813};\\\", \\\"{x:423,y:659,t:1512497953830};\\\", \\\"{x:431,y:656,t:1512497953846};\\\", \\\"{x:446,y:650,t:1512497953863};\\\", \\\"{x:465,y:641,t:1512497953880};\\\", \\\"{x:484,y:633,t:1512497953893};\\\", \\\"{x:502,y:627,t:1512497953910};\\\", \\\"{x:520,y:618,t:1512497953927};\\\", \\\"{x:535,y:612,t:1512497953943};\\\", \\\"{x:556,y:606,t:1512497953960};\\\", \\\"{x:585,y:598,t:1512497953977};\\\", \\\"{x:613,y:589,t:1512497953993};\\\", \\\"{x:662,y:575,t:1512497954010};\\\", \\\"{x:689,y:570,t:1512497954027};\\\", \\\"{x:711,y:566,t:1512497954043};\\\", \\\"{x:728,y:562,t:1512497954060};\\\", \\\"{x:740,y:560,t:1512497954077};\\\", \\\"{x:752,y:559,t:1512497954093};\\\", \\\"{x:761,y:559,t:1512497954110};\\\", \\\"{x:774,y:559,t:1512497954127};\\\", \\\"{x:779,y:559,t:1512497954143};\\\", \\\"{x:782,y:559,t:1512497954160};\\\", \\\"{x:784,y:559,t:1512497954177};\\\", \\\"{x:788,y:562,t:1512497954194};\\\", \\\"{x:789,y:563,t:1512497954210};\\\", \\\"{x:794,y:568,t:1512497954227};\\\", \\\"{x:802,y:574,t:1512497954244};\\\", \\\"{x:816,y:584,t:1512497954260};\\\", \\\"{x:832,y:592,t:1512497954278};\\\", \\\"{x:853,y:604,t:1512497954295};\\\", \\\"{x:873,y:615,t:1512497954311};\\\", \\\"{x:890,y:626,t:1512497954328};\\\", \\\"{x:906,y:639,t:1512497954345};\\\", \\\"{x:922,y:657,t:1512497954361};\\\", \\\"{x:934,y:672,t:1512497954378};\\\", \\\"{x:948,y:696,t:1512497954395};\\\", \\\"{x:956,y:709,t:1512497954413};\\\", \\\"{x:962,y:720,t:1512497954427};\\\", \\\"{x:966,y:728,t:1512497954444};\\\", \\\"{x:969,y:736,t:1512497954460};\\\", \\\"{x:970,y:739,t:1512497954477};\\\", \\\"{x:970,y:741,t:1512497954494};\\\", \\\"{x:972,y:743,t:1512497954510};\\\", \\\"{x:972,y:745,t:1512497954527};\\\", \\\"{x:973,y:749,t:1512497954544};\\\", \\\"{x:976,y:753,t:1512497954561};\\\", \\\"{x:978,y:757,t:1512497954577};\\\", \\\"{x:980,y:760,t:1512497954594};\\\", \\\"{x:981,y:762,t:1512497954611};\\\", \\\"{x:981,y:763,t:1512497954627};\\\", \\\"{x:983,y:764,t:1512497954644};\\\", \\\"{x:988,y:766,t:1512497954661};\\\", \\\"{x:993,y:768,t:1512497954677};\\\", \\\"{x:999,y:771,t:1512497954694};\\\", \\\"{x:1003,y:772,t:1512497954712};\\\", \\\"{x:1005,y:773,t:1512497954728};\\\", \\\"{x:1005,y:774,t:1512497954859};\\\", \\\"{x:1005,y:775,t:1512497954867};\\\", \\\"{x:1005,y:777,t:1512497954878};\\\", \\\"{x:1003,y:779,t:1512497954895};\\\", \\\"{x:1000,y:784,t:1512497954912};\\\", \\\"{x:997,y:788,t:1512497954928};\\\", \\\"{x:994,y:793,t:1512497954944};\\\", \\\"{x:990,y:800,t:1512497954962};\\\", \\\"{x:986,y:805,t:1512497954978};\\\", \\\"{x:983,y:809,t:1512497954995};\\\", \\\"{x:981,y:811,t:1512497955012};\\\", \\\"{x:978,y:814,t:1512497955029};\\\", \\\"{x:976,y:815,t:1512497955044};\\\", \\\"{x:975,y:816,t:1512497955062};\\\", \\\"{x:975,y:817,t:1512497955259};\\\", \\\"{x:976,y:818,t:1512497955275};\\\", \\\"{x:977,y:818,t:1512497955282};\\\", \\\"{x:977,y:819,t:1512497955298};\\\", \\\"{x:978,y:820,t:1512497955311};\\\", \\\"{x:979,y:822,t:1512497955329};\\\", \\\"{x:979,y:824,t:1512497955344};\\\", \\\"{x:980,y:825,t:1512497955460};\\\", \\\"{x:979,y:825,t:1512497955790};\\\", \\\"{x:978,y:825,t:1512497955811};\\\", \\\"{x:977,y:825,t:1512497955874};\\\", \\\"{x:976,y:825,t:1512497955906};\\\", \\\"{x:975,y:826,t:1512497957843};\\\", \\\"{x:975,y:827,t:1512497957915};\\\", \\\"{x:975,y:828,t:1512497957938};\\\", \\\"{x:975,y:829,t:1512497957954};\\\", \\\"{x:975,y:830,t:1512497957978};\\\", \\\"{x:976,y:831,t:1512497958010};\\\", \\\"{x:976,y:832,t:1512497958059};\\\", \\\"{x:977,y:832,t:1512497958163};\\\", \\\"{x:978,y:832,t:1512497958186};\\\", \\\"{x:979,y:832,t:1512497958198};\\\", \\\"{x:980,y:832,t:1512497958275};\\\", \\\"{x:979,y:832,t:1512497959154};\\\", \\\"{x:978,y:832,t:1512497959165};\\\", \\\"{x:976,y:832,t:1512497959181};\\\", \\\"{x:974,y:832,t:1512497959198};\\\", \\\"{x:974,y:831,t:1512497959218};\\\", \\\"{x:974,y:833,t:1512497961706};\\\", \\\"{x:974,y:838,t:1512497961718};\\\", \\\"{x:975,y:843,t:1512497961734};\\\", \\\"{x:977,y:851,t:1512497961750};\\\", \\\"{x:980,y:860,t:1512497961767};\\\", \\\"{x:980,y:863,t:1512497961784};\\\", \\\"{x:981,y:871,t:1512497961800};\\\", \\\"{x:981,y:874,t:1512497961816};\\\", \\\"{x:982,y:878,t:1512497961834};\\\", \\\"{x:983,y:883,t:1512497961849};\\\", \\\"{x:984,y:892,t:1512497961867};\\\", \\\"{x:985,y:897,t:1512497961884};\\\", \\\"{x:986,y:904,t:1512497961900};\\\", \\\"{x:987,y:913,t:1512497961917};\\\", \\\"{x:987,y:917,t:1512497961934};\\\", \\\"{x:987,y:919,t:1512497961950};\\\", \\\"{x:987,y:921,t:1512497961967};\\\", \\\"{x:987,y:924,t:1512497961984};\\\", \\\"{x:987,y:927,t:1512497962000};\\\", \\\"{x:987,y:929,t:1512497962016};\\\", \\\"{x:985,y:934,t:1512497962033};\\\", \\\"{x:983,y:937,t:1512497962049};\\\", \\\"{x:981,y:942,t:1512497962066};\\\", \\\"{x:980,y:944,t:1512497962083};\\\", \\\"{x:980,y:946,t:1512497962099};\\\", \\\"{x:979,y:950,t:1512497962116};\\\", \\\"{x:977,y:953,t:1512497962133};\\\", \\\"{x:977,y:956,t:1512497962150};\\\", \\\"{x:977,y:959,t:1512497962166};\\\", \\\"{x:976,y:960,t:1512497962183};\\\", \\\"{x:975,y:962,t:1512497962200};\\\", \\\"{x:975,y:963,t:1512497962218};\\\", \\\"{x:975,y:964,t:1512497962242};\\\", \\\"{x:975,y:965,t:1512497962266};\\\", \\\"{x:974,y:964,t:1512497962979};\\\", \\\"{x:974,y:962,t:1512497962986};\\\", \\\"{x:974,y:959,t:1512497963000};\\\", \\\"{x:973,y:951,t:1512497963017};\\\", \\\"{x:973,y:946,t:1512497963033};\\\", \\\"{x:973,y:937,t:1512497963050};\\\", \\\"{x:973,y:931,t:1512497963067};\\\", \\\"{x:973,y:926,t:1512497963084};\\\", \\\"{x:973,y:919,t:1512497963100};\\\", \\\"{x:973,y:915,t:1512497963117};\\\", \\\"{x:974,y:910,t:1512497963134};\\\", \\\"{x:975,y:904,t:1512497963150};\\\", \\\"{x:976,y:899,t:1512497963167};\\\", \\\"{x:978,y:895,t:1512497963184};\\\", \\\"{x:979,y:889,t:1512497963200};\\\", \\\"{x:981,y:884,t:1512497963217};\\\", \\\"{x:982,y:879,t:1512497963234};\\\", \\\"{x:982,y:875,t:1512497963250};\\\", \\\"{x:983,y:873,t:1512497963267};\\\", \\\"{x:983,y:871,t:1512497963284};\\\", \\\"{x:983,y:869,t:1512497963300};\\\", \\\"{x:983,y:868,t:1512497963317};\\\", \\\"{x:984,y:866,t:1512497963334};\\\", \\\"{x:984,y:865,t:1512497963350};\\\", \\\"{x:984,y:864,t:1512497963370};\\\", \\\"{x:984,y:863,t:1512497963384};\\\", \\\"{x:984,y:861,t:1512497963401};\\\", \\\"{x:984,y:860,t:1512497963418};\\\", \\\"{x:984,y:858,t:1512497963435};\\\", \\\"{x:983,y:855,t:1512497963452};\\\", \\\"{x:982,y:853,t:1512497963468};\\\", \\\"{x:981,y:851,t:1512497963485};\\\", \\\"{x:981,y:849,t:1512497963502};\\\", \\\"{x:978,y:846,t:1512497963518};\\\", \\\"{x:978,y:845,t:1512497963538};\\\", \\\"{x:978,y:844,t:1512497963551};\\\", \\\"{x:978,y:843,t:1512497963568};\\\", \\\"{x:978,y:842,t:1512497963584};\\\", \\\"{x:978,y:839,t:1512497963602};\\\", \\\"{x:978,y:837,t:1512497963626};\\\", \\\"{x:978,y:836,t:1512497963642};\\\", \\\"{x:978,y:834,t:1512497963675};\\\", \\\"{x:978,y:831,t:1512497963702};\\\", \\\"{x:978,y:830,t:1512497963722};\\\", \\\"{x:978,y:829,t:1512497963738};\\\", \\\"{x:978,y:828,t:1512497963762};\\\", \\\"{x:977,y:827,t:1512497964035};\\\", \\\"{x:975,y:822,t:1512497964052};\\\", \\\"{x:973,y:818,t:1512497964068};\\\", \\\"{x:970,y:813,t:1512497964085};\\\", \\\"{x:969,y:811,t:1512497964102};\\\", \\\"{x:965,y:807,t:1512497964119};\\\", \\\"{x:964,y:804,t:1512497964135};\\\", \\\"{x:963,y:801,t:1512497964151};\\\", \\\"{x:960,y:797,t:1512497964169};\\\", \\\"{x:956,y:787,t:1512497964185};\\\", \\\"{x:951,y:778,t:1512497964202};\\\", \\\"{x:948,y:770,t:1512497964218};\\\", \\\"{x:946,y:767,t:1512497964235};\\\", \\\"{x:946,y:766,t:1512497964258};\\\", \\\"{x:947,y:771,t:1512497964467};\\\", \\\"{x:947,y:776,t:1512497964474};\\\", \\\"{x:951,y:785,t:1512497964486};\\\", \\\"{x:956,y:798,t:1512497964502};\\\", \\\"{x:961,y:809,t:1512497964519};\\\", \\\"{x:965,y:817,t:1512497964536};\\\", \\\"{x:970,y:825,t:1512497964552};\\\", \\\"{x:975,y:831,t:1512497964569};\\\", \\\"{x:980,y:838,t:1512497964587};\\\", \\\"{x:982,y:842,t:1512497964602};\\\", \\\"{x:983,y:844,t:1512497964618};\\\", \\\"{x:983,y:846,t:1512497964636};\\\", \\\"{x:983,y:848,t:1512497964652};\\\", \\\"{x:983,y:850,t:1512497964669};\\\", \\\"{x:983,y:851,t:1512497964686};\\\", \\\"{x:983,y:852,t:1512497964702};\\\", \\\"{x:983,y:853,t:1512497964719};\\\", \\\"{x:984,y:853,t:1512497964770};\\\", \\\"{x:984,y:851,t:1512497964794};\\\", \\\"{x:984,y:849,t:1512497964810};\\\", \\\"{x:984,y:848,t:1512497964819};\\\", \\\"{x:984,y:846,t:1512497964836};\\\", \\\"{x:983,y:843,t:1512497964853};\\\", \\\"{x:982,y:842,t:1512497964874};\\\", \\\"{x:982,y:841,t:1512497964898};\\\", \\\"{x:981,y:839,t:1512497964970};\\\", \\\"{x:981,y:838,t:1512497965004};\\\", \\\"{x:980,y:837,t:1512497965060};\\\", \\\"{x:980,y:836,t:1512497965070};\\\", \\\"{x:979,y:835,t:1512497965132};\\\", \\\"{x:978,y:835,t:1512497965292};\\\", \\\"{x:978,y:841,t:1512497965321};\\\", \\\"{x:975,y:849,t:1512497965337};\\\", \\\"{x:974,y:861,t:1512497965354};\\\", \\\"{x:972,y:875,t:1512497965371};\\\", \\\"{x:971,y:883,t:1512497965387};\\\", \\\"{x:970,y:894,t:1512497965403};\\\", \\\"{x:970,y:905,t:1512497965421};\\\", \\\"{x:969,y:917,t:1512497965437};\\\", \\\"{x:969,y:928,t:1512497965454};\\\", \\\"{x:969,y:932,t:1512497965471};\\\", \\\"{x:969,y:937,t:1512497965487};\\\", \\\"{x:970,y:943,t:1512497965504};\\\", \\\"{x:970,y:947,t:1512497965521};\\\", \\\"{x:971,y:950,t:1512497965537};\\\", \\\"{x:971,y:951,t:1512497965554};\\\", \\\"{x:972,y:953,t:1512497965611};\\\", \\\"{x:972,y:954,t:1512497966307};\\\", \\\"{x:972,y:956,t:1512497966331};\\\", \\\"{x:973,y:957,t:1512497966347};\\\", \\\"{x:974,y:958,t:1512497966355};\\\", \\\"{x:976,y:960,t:1512497966379};\\\", \\\"{x:977,y:960,t:1512497966388};\\\", \\\"{x:979,y:961,t:1512497966405};\\\", \\\"{x:981,y:961,t:1512497966421};\\\", \\\"{x:983,y:961,t:1512497966438};\\\", \\\"{x:986,y:961,t:1512497966455};\\\", \\\"{x:988,y:963,t:1512497966471};\\\", \\\"{x:990,y:964,t:1512497966488};\\\", \\\"{x:993,y:964,t:1512497966505};\\\", \\\"{x:996,y:964,t:1512497966521};\\\", \\\"{x:997,y:964,t:1512497966538};\\\", \\\"{x:1001,y:965,t:1512497966555};\\\", \\\"{x:1004,y:966,t:1512497966572};\\\", \\\"{x:1007,y:966,t:1512497966588};\\\", \\\"{x:1011,y:967,t:1512497966605};\\\", \\\"{x:1013,y:967,t:1512497966622};\\\", \\\"{x:1014,y:967,t:1512497966638};\\\", \\\"{x:1017,y:968,t:1512497966655};\\\", \\\"{x:1019,y:968,t:1512497966675};\\\", \\\"{x:1020,y:968,t:1512497966691};\\\", \\\"{x:1022,y:968,t:1512497966705};\\\", \\\"{x:1024,y:968,t:1512497966722};\\\", \\\"{x:1029,y:968,t:1512497966738};\\\", \\\"{x:1033,y:968,t:1512497966755};\\\", \\\"{x:1036,y:968,t:1512497966771};\\\", \\\"{x:1037,y:968,t:1512497966788};\\\", \\\"{x:1038,y:968,t:1512497966805};\\\", \\\"{x:1039,y:968,t:1512497966835};\\\", \\\"{x:1040,y:968,t:1512497966843};\\\", \\\"{x:1041,y:968,t:1512497966858};\\\", \\\"{x:1041,y:967,t:1512497966871};\\\", \\\"{x:1043,y:967,t:1512497967523};\\\", \\\"{x:1044,y:968,t:1512497967539};\\\", \\\"{x:1046,y:970,t:1512497967555};\\\", \\\"{x:1048,y:971,t:1512497967572};\\\", \\\"{x:1051,y:972,t:1512497967589};\\\", \\\"{x:1054,y:974,t:1512497967606};\\\", \\\"{x:1059,y:975,t:1512497967622};\\\", \\\"{x:1062,y:975,t:1512497967638};\\\", \\\"{x:1064,y:977,t:1512497967656};\\\", \\\"{x:1065,y:977,t:1512497967672};\\\", \\\"{x:1067,y:977,t:1512497967689};\\\", \\\"{x:1068,y:977,t:1512497967707};\\\", \\\"{x:1069,y:977,t:1512497967747};\\\", \\\"{x:1070,y:977,t:1512497967763};\\\", \\\"{x:1071,y:977,t:1512497967779};\\\", \\\"{x:1073,y:976,t:1512497967789};\\\", \\\"{x:1076,y:976,t:1512497967806};\\\", \\\"{x:1079,y:974,t:1512497967822};\\\", \\\"{x:1081,y:974,t:1512497967839};\\\", \\\"{x:1084,y:974,t:1512497967856};\\\", \\\"{x:1085,y:974,t:1512497967873};\\\", \\\"{x:1089,y:973,t:1512497967889};\\\", \\\"{x:1096,y:970,t:1512497967906};\\\", \\\"{x:1102,y:969,t:1512497967923};\\\", \\\"{x:1105,y:968,t:1512497967939};\\\", \\\"{x:1108,y:968,t:1512497967955};\\\", \\\"{x:1109,y:968,t:1512497967973};\\\", \\\"{x:1111,y:967,t:1512497967989};\\\", \\\"{x:1112,y:967,t:1512497968006};\\\", \\\"{x:1114,y:966,t:1512497968023};\\\", \\\"{x:1115,y:966,t:1512497968039};\\\", \\\"{x:1116,y:966,t:1512497968056};\\\", \\\"{x:1115,y:966,t:1512497968442};\\\", \\\"{x:1114,y:966,t:1512497968531};\\\", \\\"{x:1113,y:966,t:1512497968579};\\\", \\\"{x:1112,y:967,t:1512497968603};\\\", \\\"{x:1112,y:966,t:1512497969459};\\\", \\\"{x:1111,y:964,t:1512497969475};\\\", \\\"{x:1111,y:963,t:1512497969490};\\\", \\\"{x:1110,y:956,t:1512497969507};\\\", \\\"{x:1110,y:951,t:1512497969523};\\\", \\\"{x:1110,y:948,t:1512497969540};\\\", \\\"{x:1110,y:945,t:1512497969557};\\\", \\\"{x:1110,y:942,t:1512497969574};\\\", \\\"{x:1109,y:940,t:1512497969590};\\\", \\\"{x:1109,y:938,t:1512497969607};\\\", \\\"{x:1108,y:935,t:1512497969624};\\\", \\\"{x:1108,y:932,t:1512497969640};\\\", \\\"{x:1108,y:929,t:1512497969657};\\\", \\\"{x:1108,y:925,t:1512497969674};\\\", \\\"{x:1108,y:922,t:1512497969691};\\\", \\\"{x:1108,y:920,t:1512497969707};\\\", \\\"{x:1108,y:919,t:1512497969724};\\\", \\\"{x:1108,y:917,t:1512497969741};\\\", \\\"{x:1108,y:916,t:1512497969757};\\\", \\\"{x:1108,y:915,t:1512497969774};\\\", \\\"{x:1108,y:914,t:1512497969791};\\\", \\\"{x:1108,y:913,t:1512497969807};\\\", \\\"{x:1108,y:911,t:1512497969824};\\\", \\\"{x:1108,y:910,t:1512497969841};\\\", \\\"{x:1108,y:908,t:1512497969857};\\\", \\\"{x:1108,y:906,t:1512497969874};\\\", \\\"{x:1108,y:905,t:1512497969891};\\\", \\\"{x:1108,y:904,t:1512497969907};\\\", \\\"{x:1108,y:903,t:1512497969931};\\\", \\\"{x:1109,y:903,t:1512497969941};\\\", \\\"{x:1109,y:902,t:1512497969957};\\\", \\\"{x:1109,y:901,t:1512497969973};\\\", \\\"{x:1109,y:900,t:1512497969991};\\\", \\\"{x:1109,y:899,t:1512497970019};\\\", \\\"{x:1109,y:898,t:1512497970027};\\\", \\\"{x:1109,y:897,t:1512497970051};\\\", \\\"{x:1110,y:895,t:1512497970067};\\\", \\\"{x:1111,y:893,t:1512497970091};\\\", \\\"{x:1109,y:894,t:1512497974267};\\\", \\\"{x:1108,y:894,t:1512497974276};\\\", \\\"{x:1106,y:894,t:1512497974293};\\\", \\\"{x:1101,y:894,t:1512497974311};\\\", \\\"{x:1093,y:894,t:1512497974327};\\\", \\\"{x:1086,y:891,t:1512497974344};\\\", \\\"{x:1080,y:889,t:1512497974361};\\\", \\\"{x:1071,y:884,t:1512497974377};\\\", \\\"{x:1057,y:879,t:1512497974394};\\\", \\\"{x:1013,y:861,t:1512497974411};\\\", \\\"{x:958,y:837,t:1512497974427};\\\", \\\"{x:878,y:815,t:1512497974444};\\\", \\\"{x:777,y:779,t:1512497974461};\\\", \\\"{x:674,y:748,t:1512497974476};\\\", \\\"{x:572,y:718,t:1512497974494};\\\", \\\"{x:475,y:691,t:1512497974510};\\\", \\\"{x:408,y:671,t:1512497974527};\\\", \\\"{x:353,y:650,t:1512497974543};\\\", \\\"{x:320,y:635,t:1512497974560};\\\", \\\"{x:299,y:627,t:1512497974577};\\\", \\\"{x:289,y:623,t:1512497974594};\\\", \\\"{x:289,y:621,t:1512497974633};\\\", \\\"{x:289,y:620,t:1512497974650};\\\", \\\"{x:289,y:618,t:1512497974666};\\\", \\\"{x:289,y:617,t:1512497974682};\\\", \\\"{x:289,y:615,t:1512497974694};\\\", \\\"{x:291,y:613,t:1512497974711};\\\", \\\"{x:294,y:609,t:1512497974728};\\\", \\\"{x:302,y:603,t:1512497974746};\\\", \\\"{x:304,y:602,t:1512497974762};\\\", \\\"{x:308,y:600,t:1512497974778};\\\", \\\"{x:311,y:598,t:1512497974795};\\\", \\\"{x:313,y:597,t:1512497974810};\\\", \\\"{x:316,y:595,t:1512497974827};\\\", \\\"{x:318,y:594,t:1512497974844};\\\", \\\"{x:320,y:593,t:1512497974860};\\\", \\\"{x:321,y:592,t:1512497974890};\\\", \\\"{x:322,y:591,t:1512497974922};\\\", \\\"{x:323,y:591,t:1512497975019};\\\", \\\"{x:324,y:590,t:1512497975028};\\\", \\\"{x:328,y:589,t:1512497975044};\\\", \\\"{x:338,y:587,t:1512497975062};\\\", \\\"{x:355,y:587,t:1512497975077};\\\", \\\"{x:384,y:587,t:1512497975095};\\\", \\\"{x:417,y:587,t:1512497975111};\\\", \\\"{x:453,y:594,t:1512497975129};\\\", \\\"{x:483,y:603,t:1512497975145};\\\", \\\"{x:509,y:610,t:1512497975162};\\\", \\\"{x:537,y:618,t:1512497975179};\\\", \\\"{x:542,y:619,t:1512497975194};\\\", \\\"{x:544,y:619,t:1512497975211};\\\", \\\"{x:545,y:619,t:1512497975299};\\\", \\\"{x:545,y:618,t:1512497975311};\\\", \\\"{x:550,y:613,t:1512497975329};\\\", \\\"{x:555,y:607,t:1512497975344};\\\", \\\"{x:562,y:604,t:1512497975362};\\\", \\\"{x:566,y:600,t:1512497975377};\\\", \\\"{x:567,y:600,t:1512497975394};\\\", \\\"{x:568,y:599,t:1512497975411};\\\", \\\"{x:569,y:599,t:1512497975530};\\\", \\\"{x:569,y:598,t:1512497975546};\\\", \\\"{x:569,y:597,t:1512497975562};\\\", \\\"{x:569,y:596,t:1512497975586};\\\", \\\"{x:569,y:595,t:1512497975602};\\\", \\\"{x:569,y:594,t:1512497975611};\\\", \\\"{x:569,y:593,t:1512497975628};\\\", \\\"{x:569,y:591,t:1512497975645};\\\", \\\"{x:567,y:589,t:1512497975661};\\\", \\\"{x:564,y:586,t:1512497975678};\\\", \\\"{x:562,y:586,t:1512497975695};\\\", \\\"{x:561,y:586,t:1512497975711};\\\", \\\"{x:559,y:585,t:1512497975728};\\\", \\\"{x:558,y:585,t:1512497975754};\\\", \\\"{x:557,y:584,t:1512497975778};\\\", \\\"{x:557,y:583,t:1512497975818};\\\", \\\"{x:557,y:582,t:1512497975828};\\\", \\\"{x:557,y:579,t:1512497975845};\\\", \\\"{x:557,y:577,t:1512497975862};\\\", \\\"{x:559,y:573,t:1512497975878};\\\", \\\"{x:562,y:568,t:1512497975895};\\\", \\\"{x:566,y:565,t:1512497975912};\\\", \\\"{x:567,y:563,t:1512497975928};\\\", \\\"{x:572,y:555,t:1512497975947};\\\", \\\"{x:574,y:554,t:1512497975962};\\\", \\\"{x:575,y:552,t:1512497975978};\\\", \\\"{x:576,y:550,t:1512497975995};\\\", \\\"{x:577,y:550,t:1512497976139};\\\", \\\"{x:578,y:549,t:1512497976147};\\\", \\\"{x:579,y:547,t:1512497976170};\\\", \\\"{x:580,y:547,t:1512497976179};\\\", \\\"{x:581,y:546,t:1512497976195};\\\", \\\"{x:582,y:545,t:1512497976212};\\\", \\\"{x:583,y:544,t:1512497976229};\\\", \\\"{x:584,y:543,t:1512497976265};\\\", \\\"{x:580,y:545,t:1512497976586};\\\", \\\"{x:574,y:549,t:1512497976595};\\\", \\\"{x:554,y:564,t:1512497976612};\\\", \\\"{x:538,y:580,t:1512497976629};\\\", \\\"{x:524,y:594,t:1512497976645};\\\", \\\"{x:511,y:606,t:1512497976662};\\\", \\\"{x:503,y:613,t:1512497976679};\\\", \\\"{x:500,y:618,t:1512497976695};\\\", \\\"{x:497,y:620,t:1512497976712};\\\", \\\"{x:496,y:621,t:1512497976729};\\\", \\\"{x:495,y:621,t:1512497976746};\\\", \\\"{x:494,y:622,t:1512497976762};\\\", \\\"{x:492,y:623,t:1512497976779};\\\", \\\"{x:490,y:624,t:1512497976802};\\\", \\\"{x:489,y:625,t:1512497976812};\\\", \\\"{x:486,y:627,t:1512497976829};\\\", \\\"{x:485,y:627,t:1512497976846};\\\", \\\"{x:483,y:628,t:1512497976862};\\\", \\\"{x:478,y:631,t:1512497976879};\\\", \\\"{x:474,y:633,t:1512497976896};\\\", \\\"{x:472,y:635,t:1512497976912};\\\", \\\"{x:467,y:639,t:1512497976929};\\\", \\\"{x:458,y:646,t:1512497976946};\\\", \\\"{x:453,y:650,t:1512497976962};\\\", \\\"{x:446,y:656,t:1512497976979};\\\", \\\"{x:442,y:659,t:1512497976997};\\\", \\\"{x:438,y:662,t:1512497977012};\\\", \\\"{x:433,y:666,t:1512497977029};\\\", \\\"{x:429,y:669,t:1512497977046};\\\", \\\"{x:428,y:670,t:1512497977062};\\\", \\\"{x:427,y:670,t:1512497977079};\\\", \\\"{x:427,y:671,t:1512497977635};\\\", \\\"{x:428,y:676,t:1512497977646};\\\", \\\"{x:440,y:690,t:1512497977663};\\\", \\\"{x:460,y:712,t:1512497977680};\\\", \\\"{x:489,y:739,t:1512497977696};\\\", \\\"{x:519,y:764,t:1512497977713};\\\", \\\"{x:556,y:794,t:1512497977730};\\\", \\\"{x:581,y:808,t:1512497977746};\\\", \\\"{x:595,y:813,t:1512497977763};\\\", \\\"{x:607,y:818,t:1512497977780};\\\", \\\"{x:609,y:818,t:1512497977796};\\\" ] }, { \\\"rt\\\": 19723, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 433900, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:613,y:818,t:1512497980618};\\\", \\\"{x:621,y:818,t:1512497980632};\\\", \\\"{x:642,y:817,t:1512497980649};\\\", \\\"{x:673,y:812,t:1512497980666};\\\", \\\"{x:755,y:801,t:1512497980682};\\\", \\\"{x:838,y:790,t:1512497980699};\\\", \\\"{x:930,y:777,t:1512497980716};\\\", \\\"{x:1031,y:773,t:1512497980733};\\\", \\\"{x:1142,y:773,t:1512497980749};\\\", \\\"{x:1233,y:773,t:1512497980766};\\\", \\\"{x:1317,y:773,t:1512497980783};\\\", \\\"{x:1355,y:772,t:1512497980799};\\\", \\\"{x:1361,y:770,t:1512497980816};\\\", \\\"{x:1362,y:768,t:1512497980833};\\\", \\\"{x:1362,y:769,t:1512497981411};\\\", \\\"{x:1362,y:770,t:1512497981442};\\\", \\\"{x:1362,y:771,t:1512497981458};\\\", \\\"{x:1361,y:772,t:1512497981466};\\\", \\\"{x:1360,y:773,t:1512497981547};\\\", \\\"{x:1360,y:774,t:1512497981578};\\\", \\\"{x:1359,y:775,t:1512497981610};\\\", \\\"{x:1359,y:777,t:1512497981651};\\\", \\\"{x:1358,y:778,t:1512497981674};\\\", \\\"{x:1357,y:779,t:1512497981690};\\\", \\\"{x:1357,y:780,t:1512497981700};\\\", \\\"{x:1356,y:782,t:1512497981717};\\\", \\\"{x:1356,y:783,t:1512497981738};\\\", \\\"{x:1356,y:784,t:1512497981754};\\\", \\\"{x:1355,y:785,t:1512497981770};\\\", \\\"{x:1354,y:786,t:1512497981794};\\\", \\\"{x:1353,y:787,t:1512497981810};\\\", \\\"{x:1353,y:788,t:1512497981818};\\\", \\\"{x:1353,y:789,t:1512497981834};\\\", \\\"{x:1352,y:791,t:1512497981858};\\\", \\\"{x:1351,y:792,t:1512497981874};\\\", \\\"{x:1351,y:793,t:1512497981890};\\\", \\\"{x:1350,y:794,t:1512497981906};\\\", \\\"{x:1350,y:796,t:1512497981922};\\\", \\\"{x:1349,y:796,t:1512497981934};\\\", \\\"{x:1349,y:798,t:1512497981950};\\\", \\\"{x:1347,y:801,t:1512497981967};\\\", \\\"{x:1347,y:802,t:1512497981986};\\\", \\\"{x:1347,y:803,t:1512497982002};\\\", \\\"{x:1347,y:805,t:1512497982026};\\\", \\\"{x:1348,y:806,t:1512497982051};\\\", \\\"{x:1348,y:808,t:1512497982066};\\\", \\\"{x:1351,y:813,t:1512497982084};\\\", \\\"{x:1354,y:818,t:1512497982100};\\\", \\\"{x:1355,y:821,t:1512497982117};\\\", \\\"{x:1357,y:826,t:1512497982134};\\\", \\\"{x:1358,y:828,t:1512497982150};\\\", \\\"{x:1359,y:830,t:1512497982167};\\\", \\\"{x:1359,y:831,t:1512497982184};\\\", \\\"{x:1359,y:835,t:1512497982200};\\\", \\\"{x:1359,y:837,t:1512497982217};\\\", \\\"{x:1359,y:841,t:1512497982234};\\\", \\\"{x:1359,y:845,t:1512497982250};\\\", \\\"{x:1359,y:849,t:1512497982267};\\\", \\\"{x:1357,y:855,t:1512497982284};\\\", \\\"{x:1351,y:862,t:1512497982300};\\\", \\\"{x:1345,y:867,t:1512497982317};\\\", \\\"{x:1338,y:873,t:1512497982334};\\\", \\\"{x:1329,y:880,t:1512497982350};\\\", \\\"{x:1322,y:884,t:1512497982367};\\\", \\\"{x:1313,y:890,t:1512497982384};\\\", \\\"{x:1303,y:894,t:1512497982401};\\\", \\\"{x:1294,y:900,t:1512497982417};\\\", \\\"{x:1285,y:907,t:1512497982434};\\\", \\\"{x:1278,y:914,t:1512497982450};\\\", \\\"{x:1272,y:918,t:1512497982467};\\\", \\\"{x:1269,y:920,t:1512497982485};\\\", \\\"{x:1266,y:922,t:1512497982502};\\\", \\\"{x:1263,y:924,t:1512497982518};\\\", \\\"{x:1261,y:925,t:1512497982535};\\\", \\\"{x:1261,y:926,t:1512497982552};\\\", \\\"{x:1262,y:926,t:1512497982652};\\\", \\\"{x:1264,y:926,t:1512497982668};\\\", \\\"{x:1268,y:926,t:1512497982685};\\\", \\\"{x:1273,y:926,t:1512497982702};\\\", \\\"{x:1282,y:926,t:1512497982718};\\\", \\\"{x:1294,y:926,t:1512497982735};\\\", \\\"{x:1305,y:925,t:1512497982752};\\\", \\\"{x:1319,y:924,t:1512497982768};\\\", \\\"{x:1329,y:924,t:1512497982785};\\\", \\\"{x:1337,y:924,t:1512497982802};\\\", \\\"{x:1344,y:924,t:1512497982818};\\\", \\\"{x:1351,y:924,t:1512497982835};\\\", \\\"{x:1360,y:926,t:1512497982852};\\\", \\\"{x:1364,y:927,t:1512497982868};\\\", \\\"{x:1367,y:929,t:1512497982885};\\\", \\\"{x:1370,y:931,t:1512497982902};\\\", \\\"{x:1371,y:933,t:1512497982919};\\\", \\\"{x:1372,y:935,t:1512497982935};\\\", \\\"{x:1372,y:938,t:1512497982952};\\\", \\\"{x:1372,y:939,t:1512497982969};\\\", \\\"{x:1373,y:942,t:1512497982985};\\\", \\\"{x:1373,y:944,t:1512497983002};\\\", \\\"{x:1374,y:946,t:1512497983019};\\\", \\\"{x:1375,y:947,t:1512497983043};\\\", \\\"{x:1375,y:948,t:1512497983051};\\\", \\\"{x:1375,y:949,t:1512497983069};\\\", \\\"{x:1375,y:951,t:1512497983085};\\\", \\\"{x:1375,y:952,t:1512497983102};\\\", \\\"{x:1376,y:952,t:1512497983119};\\\", \\\"{x:1376,y:953,t:1512497983187};\\\", \\\"{x:1376,y:954,t:1512497983203};\\\", \\\"{x:1376,y:955,t:1512497983219};\\\", \\\"{x:1376,y:957,t:1512497983235};\\\", \\\"{x:1376,y:958,t:1512497983283};\\\", \\\"{x:1375,y:957,t:1512497983603};\\\", \\\"{x:1375,y:956,t:1512497983627};\\\", \\\"{x:1375,y:955,t:1512497983635};\\\", \\\"{x:1375,y:952,t:1512497983652};\\\", \\\"{x:1375,y:951,t:1512497983669};\\\", \\\"{x:1375,y:949,t:1512497983686};\\\", \\\"{x:1375,y:945,t:1512497983702};\\\", \\\"{x:1375,y:943,t:1512497983719};\\\", \\\"{x:1375,y:941,t:1512497983736};\\\", \\\"{x:1375,y:938,t:1512497983752};\\\", \\\"{x:1375,y:936,t:1512497983769};\\\", \\\"{x:1375,y:934,t:1512497983786};\\\", \\\"{x:1375,y:932,t:1512497983802};\\\", \\\"{x:1376,y:929,t:1512497983818};\\\", \\\"{x:1376,y:926,t:1512497983835};\\\", \\\"{x:1376,y:924,t:1512497983852};\\\", \\\"{x:1376,y:920,t:1512497983868};\\\", \\\"{x:1378,y:916,t:1512497983885};\\\", \\\"{x:1379,y:914,t:1512497983902};\\\", \\\"{x:1379,y:911,t:1512497983918};\\\", \\\"{x:1380,y:909,t:1512497983935};\\\", \\\"{x:1380,y:907,t:1512497983952};\\\", \\\"{x:1380,y:904,t:1512497983968};\\\", \\\"{x:1381,y:902,t:1512497983985};\\\", \\\"{x:1382,y:899,t:1512497984002};\\\", \\\"{x:1382,y:896,t:1512497984018};\\\", \\\"{x:1382,y:892,t:1512497984035};\\\", \\\"{x:1382,y:888,t:1512497984052};\\\", \\\"{x:1382,y:883,t:1512497984068};\\\", \\\"{x:1382,y:881,t:1512497984085};\\\", \\\"{x:1382,y:878,t:1512497984102};\\\", \\\"{x:1382,y:876,t:1512497984118};\\\", \\\"{x:1382,y:875,t:1512497984135};\\\", \\\"{x:1382,y:873,t:1512497984152};\\\", \\\"{x:1382,y:872,t:1512497984168};\\\", \\\"{x:1382,y:870,t:1512497984186};\\\", \\\"{x:1382,y:867,t:1512497984203};\\\", \\\"{x:1381,y:866,t:1512497984219};\\\", \\\"{x:1381,y:864,t:1512497984236};\\\", \\\"{x:1381,y:863,t:1512497984253};\\\", \\\"{x:1381,y:861,t:1512497984269};\\\", \\\"{x:1381,y:860,t:1512497984286};\\\", \\\"{x:1381,y:857,t:1512497984303};\\\", \\\"{x:1381,y:854,t:1512497984320};\\\", \\\"{x:1381,y:853,t:1512497984336};\\\", \\\"{x:1381,y:851,t:1512497984353};\\\", \\\"{x:1380,y:851,t:1512497984370};\\\", \\\"{x:1380,y:850,t:1512497984386};\\\", \\\"{x:1380,y:849,t:1512497984403};\\\", \\\"{x:1380,y:848,t:1512497984422};\\\", \\\"{x:1380,y:847,t:1512497984438};\\\", \\\"{x:1380,y:846,t:1512497984455};\\\", \\\"{x:1380,y:845,t:1512497984472};\\\", \\\"{x:1380,y:842,t:1512497986997};\\\", \\\"{x:1380,y:841,t:1512497987008};\\\", \\\"{x:1380,y:840,t:1512497987022};\\\", \\\"{x:1380,y:838,t:1512497987039};\\\", \\\"{x:1379,y:837,t:1512497987056};\\\", \\\"{x:1379,y:835,t:1512497987072};\\\", \\\"{x:1379,y:833,t:1512497987089};\\\", \\\"{x:1379,y:832,t:1512497987106};\\\", \\\"{x:1378,y:831,t:1512497987122};\\\", \\\"{x:1378,y:830,t:1512497987139};\\\", \\\"{x:1378,y:827,t:1512497987156};\\\", \\\"{x:1378,y:826,t:1512497987172};\\\", \\\"{x:1378,y:823,t:1512497987189};\\\", \\\"{x:1378,y:820,t:1512497987207};\\\", \\\"{x:1377,y:817,t:1512497987223};\\\", \\\"{x:1377,y:816,t:1512497987240};\\\", \\\"{x:1377,y:814,t:1512497987257};\\\", \\\"{x:1377,y:812,t:1512497987277};\\\", \\\"{x:1377,y:811,t:1512497987290};\\\", \\\"{x:1377,y:810,t:1512497987309};\\\", \\\"{x:1377,y:809,t:1512497987324};\\\", \\\"{x:1377,y:808,t:1512497987340};\\\", \\\"{x:1377,y:805,t:1512497987357};\\\", \\\"{x:1377,y:801,t:1512497987373};\\\", \\\"{x:1377,y:799,t:1512497987390};\\\", \\\"{x:1377,y:797,t:1512497987407};\\\", \\\"{x:1377,y:794,t:1512497987424};\\\", \\\"{x:1377,y:792,t:1512497987440};\\\", \\\"{x:1377,y:788,t:1512497987457};\\\", \\\"{x:1377,y:786,t:1512497987474};\\\", \\\"{x:1377,y:782,t:1512497987490};\\\", \\\"{x:1377,y:781,t:1512497987507};\\\", \\\"{x:1377,y:778,t:1512497987524};\\\", \\\"{x:1377,y:775,t:1512497987540};\\\", \\\"{x:1377,y:768,t:1512497987557};\\\", \\\"{x:1378,y:765,t:1512497987573};\\\", \\\"{x:1379,y:761,t:1512497987590};\\\", \\\"{x:1381,y:758,t:1512497987608};\\\", \\\"{x:1383,y:753,t:1512497987624};\\\", \\\"{x:1384,y:748,t:1512497987640};\\\", \\\"{x:1386,y:741,t:1512497987657};\\\", \\\"{x:1387,y:733,t:1512497987674};\\\", \\\"{x:1388,y:725,t:1512497987691};\\\", \\\"{x:1388,y:716,t:1512497987707};\\\", \\\"{x:1388,y:705,t:1512497987724};\\\", \\\"{x:1388,y:687,t:1512497987741};\\\", \\\"{x:1388,y:673,t:1512497987757};\\\", \\\"{x:1389,y:665,t:1512497987774};\\\", \\\"{x:1391,y:656,t:1512497987791};\\\", \\\"{x:1391,y:647,t:1512497987808};\\\", \\\"{x:1391,y:640,t:1512497987824};\\\", \\\"{x:1391,y:634,t:1512497987841};\\\", \\\"{x:1391,y:627,t:1512497987857};\\\", \\\"{x:1391,y:622,t:1512497987874};\\\", \\\"{x:1391,y:616,t:1512497987891};\\\", \\\"{x:1391,y:612,t:1512497987907};\\\", \\\"{x:1390,y:607,t:1512497987924};\\\", \\\"{x:1390,y:597,t:1512497987941};\\\", \\\"{x:1390,y:593,t:1512497987957};\\\", \\\"{x:1388,y:587,t:1512497987974};\\\", \\\"{x:1387,y:585,t:1512497987991};\\\", \\\"{x:1387,y:582,t:1512497988008};\\\", \\\"{x:1386,y:579,t:1512497988024};\\\", \\\"{x:1384,y:575,t:1512497988041};\\\", \\\"{x:1384,y:572,t:1512497988057};\\\", \\\"{x:1384,y:569,t:1512497988074};\\\", \\\"{x:1384,y:566,t:1512497988091};\\\", \\\"{x:1383,y:565,t:1512497988107};\\\", \\\"{x:1383,y:562,t:1512497988124};\\\", \\\"{x:1381,y:559,t:1512497988141};\\\", \\\"{x:1381,y:558,t:1512497988158};\\\", \\\"{x:1380,y:557,t:1512497988174};\\\", \\\"{x:1380,y:556,t:1512497988191};\\\", \\\"{x:1379,y:556,t:1512497988208};\\\", \\\"{x:1379,y:555,t:1512497988224};\\\", \\\"{x:1379,y:553,t:1512497988241};\\\", \\\"{x:1378,y:552,t:1512497988258};\\\", \\\"{x:1375,y:554,t:1512497989077};\\\", \\\"{x:1371,y:559,t:1512497989092};\\\", \\\"{x:1359,y:572,t:1512497989108};\\\", \\\"{x:1328,y:599,t:1512497989125};\\\", \\\"{x:1283,y:633,t:1512497989141};\\\", \\\"{x:1231,y:663,t:1512497989158};\\\", \\\"{x:1161,y:698,t:1512497989175};\\\", \\\"{x:1094,y:735,t:1512497989192};\\\", \\\"{x:1020,y:774,t:1512497989208};\\\", \\\"{x:946,y:806,t:1512497989225};\\\", \\\"{x:884,y:828,t:1512497989242};\\\", \\\"{x:833,y:842,t:1512497989258};\\\", \\\"{x:795,y:846,t:1512497989275};\\\", \\\"{x:755,y:846,t:1512497989292};\\\", \\\"{x:715,y:833,t:1512497989308};\\\", \\\"{x:649,y:803,t:1512497989324};\\\", \\\"{x:620,y:786,t:1512497989341};\\\", \\\"{x:597,y:768,t:1512497989357};\\\", \\\"{x:585,y:751,t:1512497989375};\\\", \\\"{x:574,y:732,t:1512497989392};\\\", \\\"{x:567,y:716,t:1512497989407};\\\", \\\"{x:560,y:697,t:1512497989424};\\\", \\\"{x:551,y:678,t:1512497989442};\\\", \\\"{x:543,y:661,t:1512497989458};\\\", \\\"{x:537,y:646,t:1512497989475};\\\", \\\"{x:532,y:633,t:1512497989491};\\\", \\\"{x:526,y:620,t:1512497989508};\\\", \\\"{x:520,y:607,t:1512497989525};\\\", \\\"{x:516,y:603,t:1512497989542};\\\", \\\"{x:515,y:603,t:1512497989558};\\\", \\\"{x:513,y:602,t:1512497989575};\\\", \\\"{x:507,y:601,t:1512497989591};\\\", \\\"{x:502,y:600,t:1512497989608};\\\", \\\"{x:496,y:599,t:1512497989625};\\\", \\\"{x:490,y:599,t:1512497989641};\\\", \\\"{x:477,y:599,t:1512497989658};\\\", \\\"{x:462,y:599,t:1512497989675};\\\", \\\"{x:443,y:598,t:1512497989692};\\\", \\\"{x:427,y:595,t:1512497989709};\\\", \\\"{x:413,y:590,t:1512497989725};\\\", \\\"{x:407,y:588,t:1512497989742};\\\", \\\"{x:406,y:587,t:1512497989764};\\\", \\\"{x:404,y:586,t:1512497989775};\\\", \\\"{x:402,y:586,t:1512497989796};\\\", \\\"{x:401,y:586,t:1512497989809};\\\", \\\"{x:397,y:586,t:1512497989826};\\\", \\\"{x:391,y:586,t:1512497989842};\\\", \\\"{x:387,y:586,t:1512497989859};\\\", \\\"{x:383,y:587,t:1512497989876};\\\", \\\"{x:382,y:587,t:1512497989900};\\\", \\\"{x:381,y:588,t:1512497989909};\\\", \\\"{x:381,y:589,t:1512497989927};\\\", \\\"{x:381,y:591,t:1512497989942};\\\", \\\"{x:381,y:592,t:1512497989989};\\\", \\\"{x:383,y:593,t:1512497990004};\\\", \\\"{x:385,y:593,t:1512497990020};\\\", \\\"{x:388,y:596,t:1512497990028};\\\", \\\"{x:390,y:596,t:1512497990044};\\\", \\\"{x:391,y:597,t:1512497990060};\\\", \\\"{x:392,y:598,t:1512497990077};\\\", \\\"{x:393,y:599,t:1512497990094};\\\", \\\"{x:394,y:599,t:1512497990181};\\\", \\\"{x:396,y:600,t:1512497990261};\\\", \\\"{x:398,y:601,t:1512497990277};\\\", \\\"{x:400,y:602,t:1512497990293};\\\", \\\"{x:401,y:603,t:1512497990325};\\\", \\\"{x:402,y:603,t:1512497990348};\\\", \\\"{x:403,y:603,t:1512497990364};\\\", \\\"{x:404,y:603,t:1512497990405};\\\", \\\"{x:401,y:603,t:1512497990901};\\\", \\\"{x:398,y:603,t:1512497990910};\\\", \\\"{x:390,y:602,t:1512497990927};\\\", \\\"{x:381,y:601,t:1512497990944};\\\", \\\"{x:375,y:600,t:1512497990960};\\\", \\\"{x:368,y:597,t:1512497990977};\\\", \\\"{x:359,y:593,t:1512497990994};\\\", \\\"{x:346,y:590,t:1512497991010};\\\", \\\"{x:332,y:586,t:1512497991027};\\\", \\\"{x:322,y:583,t:1512497991044};\\\", \\\"{x:312,y:581,t:1512497991060};\\\", \\\"{x:304,y:580,t:1512497991076};\\\", \\\"{x:300,y:580,t:1512497991094};\\\", \\\"{x:297,y:579,t:1512497991111};\\\", \\\"{x:295,y:579,t:1512497991127};\\\", \\\"{x:292,y:578,t:1512497991143};\\\", \\\"{x:291,y:577,t:1512497991160};\\\", \\\"{x:288,y:575,t:1512497991177};\\\", \\\"{x:287,y:575,t:1512497991193};\\\", \\\"{x:284,y:575,t:1512497991211};\\\", \\\"{x:283,y:575,t:1512497991228};\\\", \\\"{x:282,y:575,t:1512497991243};\\\", \\\"{x:281,y:575,t:1512497991261};\\\", \\\"{x:280,y:575,t:1512497991277};\\\", \\\"{x:282,y:574,t:1512497991365};\\\", \\\"{x:283,y:574,t:1512497991377};\\\", \\\"{x:294,y:572,t:1512497991394};\\\", \\\"{x:308,y:571,t:1512497991411};\\\", \\\"{x:325,y:570,t:1512497991427};\\\", \\\"{x:342,y:570,t:1512497991443};\\\", \\\"{x:369,y:569,t:1512497991459};\\\", \\\"{x:384,y:567,t:1512497991477};\\\", \\\"{x:393,y:566,t:1512497991493};\\\", \\\"{x:396,y:565,t:1512497991510};\\\", \\\"{x:398,y:565,t:1512497991527};\\\", \\\"{x:399,y:565,t:1512497991564};\\\", \\\"{x:400,y:564,t:1512497991580};\\\", \\\"{x:401,y:564,t:1512497991593};\\\", \\\"{x:403,y:563,t:1512497991610};\\\", \\\"{x:406,y:562,t:1512497991627};\\\", \\\"{x:410,y:560,t:1512497991643};\\\", \\\"{x:409,y:560,t:1512497991813};\\\", \\\"{x:408,y:561,t:1512497991852};\\\", \\\"{x:407,y:561,t:1512497991860};\\\", \\\"{x:405,y:562,t:1512497991878};\\\", \\\"{x:404,y:563,t:1512497991895};\\\", \\\"{x:403,y:564,t:1512497991910};\\\", \\\"{x:399,y:564,t:1512497991928};\\\", \\\"{x:395,y:564,t:1512497991945};\\\", \\\"{x:389,y:564,t:1512497991961};\\\", \\\"{x:383,y:564,t:1512497991978};\\\", \\\"{x:375,y:564,t:1512497991995};\\\", \\\"{x:368,y:564,t:1512497992010};\\\", \\\"{x:355,y:564,t:1512497992028};\\\", \\\"{x:336,y:564,t:1512497992044};\\\", \\\"{x:326,y:564,t:1512497992060};\\\", \\\"{x:318,y:564,t:1512497992077};\\\", \\\"{x:317,y:564,t:1512497992094};\\\", \\\"{x:315,y:564,t:1512497992110};\\\", \\\"{x:314,y:564,t:1512497992132};\\\", \\\"{x:313,y:563,t:1512497992148};\\\", \\\"{x:312,y:563,t:1512497992172};\\\", \\\"{x:311,y:563,t:1512497992196};\\\", \\\"{x:310,y:563,t:1512497992211};\\\", \\\"{x:308,y:562,t:1512497992227};\\\", \\\"{x:307,y:562,t:1512497992252};\\\", \\\"{x:305,y:562,t:1512497992301};\\\", \\\"{x:305,y:563,t:1512497992324};\\\", \\\"{x:304,y:566,t:1512497992332};\\\", \\\"{x:304,y:567,t:1512497992345};\\\", \\\"{x:303,y:570,t:1512497992362};\\\", \\\"{x:302,y:573,t:1512497992377};\\\", \\\"{x:302,y:576,t:1512497992395};\\\", \\\"{x:302,y:579,t:1512497992412};\\\", \\\"{x:302,y:581,t:1512497992428};\\\", \\\"{x:304,y:585,t:1512497992444};\\\", \\\"{x:305,y:586,t:1512497992461};\\\", \\\"{x:305,y:587,t:1512497992478};\\\", \\\"{x:306,y:588,t:1512497992501};\\\", \\\"{x:307,y:589,t:1512497992516};\\\", \\\"{x:308,y:590,t:1512497992540};\\\", \\\"{x:308,y:591,t:1512497992556};\\\", \\\"{x:309,y:591,t:1512497992564};\\\", \\\"{x:310,y:593,t:1512497992580};\\\", \\\"{x:311,y:594,t:1512497992645};\\\", \\\"{x:311,y:595,t:1512497992661};\\\", \\\"{x:311,y:596,t:1512497992675};\\\", \\\"{x:311,y:597,t:1512497992699};\\\", \\\"{x:311,y:598,t:1512497994213};\\\", \\\"{x:311,y:604,t:1512497994229};\\\", \\\"{x:311,y:614,t:1512497994246};\\\", \\\"{x:311,y:624,t:1512497994262};\\\", \\\"{x:311,y:631,t:1512497994279};\\\", \\\"{x:311,y:638,t:1512497994296};\\\", \\\"{x:311,y:643,t:1512497994312};\\\", \\\"{x:311,y:645,t:1512497994329};\\\", \\\"{x:311,y:649,t:1512497994346};\\\", \\\"{x:311,y:650,t:1512497994362};\\\", \\\"{x:311,y:651,t:1512497994379};\\\", \\\"{x:312,y:653,t:1512497994396};\\\", \\\"{x:313,y:653,t:1512497994476};\\\", \\\"{x:314,y:653,t:1512497994508};\\\", \\\"{x:315,y:653,t:1512497994524};\\\", \\\"{x:316,y:653,t:1512497994556};\\\", \\\"{x:317,y:653,t:1512497994613};\\\", \\\"{x:318,y:652,t:1512497995325};\\\", \\\"{x:319,y:652,t:1512497995332};\\\", \\\"{x:321,y:651,t:1512497995347};\\\", \\\"{x:326,y:649,t:1512497995364};\\\", \\\"{x:331,y:648,t:1512497995380};\\\", \\\"{x:334,y:648,t:1512497995396};\\\", \\\"{x:340,y:648,t:1512497995413};\\\", \\\"{x:346,y:648,t:1512497995430};\\\", \\\"{x:353,y:648,t:1512497995447};\\\", \\\"{x:363,y:652,t:1512497995463};\\\", \\\"{x:374,y:658,t:1512497995481};\\\", \\\"{x:386,y:663,t:1512497995497};\\\", \\\"{x:395,y:666,t:1512497995513};\\\", \\\"{x:404,y:671,t:1512497995530};\\\", \\\"{x:410,y:674,t:1512497995546};\\\", \\\"{x:418,y:679,t:1512497995563};\\\", \\\"{x:426,y:683,t:1512497995579};\\\", \\\"{x:430,y:684,t:1512497995596};\\\", \\\"{x:432,y:686,t:1512497995613};\\\", \\\"{x:434,y:687,t:1512497995630};\\\", \\\"{x:436,y:688,t:1512497995646};\\\", \\\"{x:438,y:688,t:1512497995663};\\\", \\\"{x:438,y:689,t:1512497995724};\\\", \\\"{x:438,y:688,t:1512497996140};\\\", \\\"{x:437,y:687,t:1512497996164};\\\", \\\"{x:437,y:686,t:1512497996204};\\\", \\\"{x:436,y:685,t:1512497996268};\\\", \\\"{x:436,y:684,t:1512497996348};\\\", \\\"{x:436,y:683,t:1512497996596};\\\", \\\"{x:436,y:682,t:1512497996620};\\\", \\\"{x:434,y:680,t:1512497996636};\\\" ] }, { \\\"rt\\\": 46501, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 481745, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -12:30-01 PM-01:30-02 PM-02:30-03 PM-Z -3-11:30-12 PM-12:30-12:30-12 PM-11:30-11:30-12 PM-01 PM-01:30-02 PM-02:30-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:433,y:678,t:1512498006149};\\\", \\\"{x:436,y:675,t:1512498006157};\\\", \\\"{x:440,y:668,t:1512498006167};\\\", \\\"{x:447,y:657,t:1512498006183};\\\", \\\"{x:456,y:644,t:1512498006200};\\\", \\\"{x:467,y:626,t:1512498006222};\\\", \\\"{x:477,y:610,t:1512498006239};\\\", \\\"{x:490,y:597,t:1512498006256};\\\", \\\"{x:501,y:587,t:1512498006272};\\\", \\\"{x:505,y:583,t:1512498006289};\\\", \\\"{x:508,y:580,t:1512498006306};\\\", \\\"{x:509,y:579,t:1512498006323};\\\", \\\"{x:509,y:578,t:1512498006340};\\\", \\\"{x:509,y:577,t:1512498006356};\\\", \\\"{x:510,y:575,t:1512498006436};\\\", \\\"{x:511,y:574,t:1512498006444};\\\", \\\"{x:511,y:573,t:1512498006456};\\\", \\\"{x:512,y:570,t:1512498006473};\\\", \\\"{x:514,y:565,t:1512498006489};\\\", \\\"{x:514,y:560,t:1512498006506};\\\", \\\"{x:514,y:556,t:1512498006523};\\\", \\\"{x:514,y:550,t:1512498006539};\\\", \\\"{x:514,y:542,t:1512498006556};\\\", \\\"{x:514,y:539,t:1512498006573};\\\", \\\"{x:514,y:537,t:1512498006590};\\\", \\\"{x:514,y:535,t:1512498006606};\\\", \\\"{x:514,y:534,t:1512498006629};\\\", \\\"{x:514,y:533,t:1512498006640};\\\", \\\"{x:514,y:532,t:1512498006656};\\\", \\\"{x:514,y:530,t:1512498006674};\\\", \\\"{x:514,y:528,t:1512498006690};\\\", \\\"{x:513,y:526,t:1512498006707};\\\", \\\"{x:513,y:525,t:1512498006724};\\\", \\\"{x:512,y:524,t:1512498006740};\\\", \\\"{x:512,y:523,t:1512498006757};\\\", \\\"{x:512,y:522,t:1512498006774};\\\", \\\"{x:512,y:520,t:1512498006796};\\\", \\\"{x:511,y:520,t:1512498006806};\\\", \\\"{x:510,y:519,t:1512498006823};\\\", \\\"{x:510,y:518,t:1512498009109};\\\", \\\"{x:512,y:517,t:1512498009125};\\\", \\\"{x:514,y:515,t:1512498009142};\\\", \\\"{x:521,y:515,t:1512498009158};\\\", \\\"{x:529,y:515,t:1512498009176};\\\", \\\"{x:543,y:515,t:1512498009192};\\\", \\\"{x:564,y:522,t:1512498009208};\\\", \\\"{x:592,y:530,t:1512498009226};\\\", \\\"{x:623,y:538,t:1512498009242};\\\", \\\"{x:673,y:551,t:1512498009259};\\\", \\\"{x:723,y:565,t:1512498009276};\\\", \\\"{x:781,y:580,t:1512498009292};\\\", \\\"{x:867,y:605,t:1512498009308};\\\", \\\"{x:911,y:615,t:1512498009326};\\\", \\\"{x:938,y:622,t:1512498009342};\\\", \\\"{x:968,y:631,t:1512498009359};\\\", \\\"{x:995,y:636,t:1512498009376};\\\", \\\"{x:1012,y:637,t:1512498009393};\\\", \\\"{x:1023,y:637,t:1512498009409};\\\", \\\"{x:1029,y:637,t:1512498009425};\\\", \\\"{x:1036,y:633,t:1512498009442};\\\", \\\"{x:1041,y:628,t:1512498009458};\\\", \\\"{x:1051,y:617,t:1512498009475};\\\", \\\"{x:1069,y:598,t:1512498009492};\\\", \\\"{x:1081,y:581,t:1512498009508};\\\", \\\"{x:1088,y:566,t:1512498009525};\\\", \\\"{x:1090,y:555,t:1512498009542};\\\", \\\"{x:1093,y:545,t:1512498009558};\\\", \\\"{x:1093,y:542,t:1512498009575};\\\", \\\"{x:1095,y:538,t:1512498009592};\\\", \\\"{x:1095,y:537,t:1512498009608};\\\", \\\"{x:1096,y:534,t:1512498009625};\\\", \\\"{x:1096,y:533,t:1512498009642};\\\", \\\"{x:1096,y:532,t:1512498009658};\\\", \\\"{x:1096,y:529,t:1512498009675};\\\", \\\"{x:1092,y:529,t:1512498009692};\\\", \\\"{x:1090,y:529,t:1512498009708};\\\", \\\"{x:1089,y:529,t:1512498009725};\\\", \\\"{x:1087,y:528,t:1512498009781};\\\", \\\"{x:1087,y:527,t:1512498009793};\\\", \\\"{x:1087,y:524,t:1512498009809};\\\", \\\"{x:1085,y:520,t:1512498009826};\\\", \\\"{x:1085,y:517,t:1512498009843};\\\", \\\"{x:1084,y:515,t:1512498009860};\\\", \\\"{x:1083,y:512,t:1512498009876};\\\", \\\"{x:1082,y:510,t:1512498009893};\\\", \\\"{x:1082,y:508,t:1512498009910};\\\", \\\"{x:1080,y:506,t:1512498009926};\\\", \\\"{x:1079,y:504,t:1512498009943};\\\", \\\"{x:1079,y:503,t:1512498009973};\\\", \\\"{x:1078,y:503,t:1512498010005};\\\", \\\"{x:1077,y:502,t:1512498010064};\\\", \\\"{x:1077,y:501,t:1512498010092};\\\", \\\"{x:1077,y:500,t:1512498010116};\\\", \\\"{x:1076,y:500,t:1512498010140};\\\", \\\"{x:1076,y:499,t:1512498010188};\\\", \\\"{x:1076,y:498,t:1512498010228};\\\", \\\"{x:1076,y:497,t:1512498010244};\\\", \\\"{x:1076,y:496,t:1512498010284};\\\", \\\"{x:1075,y:495,t:1512498010324};\\\", \\\"{x:1075,y:496,t:1512498012941};\\\", \\\"{x:1075,y:498,t:1512498012948};\\\", \\\"{x:1075,y:500,t:1512498012964};\\\", \\\"{x:1075,y:502,t:1512498012979};\\\", \\\"{x:1077,y:504,t:1512498012998};\\\", \\\"{x:1077,y:506,t:1512498013011};\\\", \\\"{x:1077,y:510,t:1512498013028};\\\", \\\"{x:1077,y:513,t:1512498013044};\\\", \\\"{x:1077,y:515,t:1512498013061};\\\", \\\"{x:1077,y:520,t:1512498013078};\\\", \\\"{x:1077,y:523,t:1512498013094};\\\", \\\"{x:1077,y:528,t:1512498013111};\\\", \\\"{x:1077,y:532,t:1512498013128};\\\", \\\"{x:1077,y:537,t:1512498013144};\\\", \\\"{x:1077,y:542,t:1512498013161};\\\", \\\"{x:1077,y:544,t:1512498013178};\\\", \\\"{x:1077,y:546,t:1512498013194};\\\", \\\"{x:1078,y:550,t:1512498013211};\\\", \\\"{x:1079,y:556,t:1512498013228};\\\", \\\"{x:1080,y:560,t:1512498013244};\\\", \\\"{x:1080,y:563,t:1512498013262};\\\", \\\"{x:1081,y:566,t:1512498013279};\\\", \\\"{x:1081,y:569,t:1512498013295};\\\", \\\"{x:1081,y:571,t:1512498013311};\\\", \\\"{x:1082,y:575,t:1512498013329};\\\", \\\"{x:1082,y:578,t:1512498013345};\\\", \\\"{x:1082,y:581,t:1512498013362};\\\", \\\"{x:1084,y:584,t:1512498013379};\\\", \\\"{x:1084,y:585,t:1512498013396};\\\", \\\"{x:1084,y:588,t:1512498013412};\\\", \\\"{x:1085,y:593,t:1512498013428};\\\", \\\"{x:1085,y:596,t:1512498013446};\\\", \\\"{x:1085,y:600,t:1512498013462};\\\", \\\"{x:1086,y:602,t:1512498013479};\\\", \\\"{x:1086,y:605,t:1512498013496};\\\", \\\"{x:1087,y:610,t:1512498013512};\\\", \\\"{x:1087,y:612,t:1512498013529};\\\", \\\"{x:1087,y:614,t:1512498013546};\\\", \\\"{x:1088,y:618,t:1512498013562};\\\", \\\"{x:1088,y:619,t:1512498013579};\\\", \\\"{x:1088,y:621,t:1512498013596};\\\", \\\"{x:1088,y:623,t:1512498013612};\\\", \\\"{x:1088,y:626,t:1512498013629};\\\", \\\"{x:1088,y:628,t:1512498013646};\\\", \\\"{x:1088,y:631,t:1512498013662};\\\", \\\"{x:1088,y:633,t:1512498013679};\\\", \\\"{x:1088,y:635,t:1512498013696};\\\", \\\"{x:1088,y:636,t:1512498013712};\\\", \\\"{x:1088,y:639,t:1512498013729};\\\", \\\"{x:1088,y:640,t:1512498013746};\\\", \\\"{x:1088,y:643,t:1512498013762};\\\", \\\"{x:1088,y:645,t:1512498013779};\\\", \\\"{x:1087,y:647,t:1512498013796};\\\", \\\"{x:1087,y:649,t:1512498013813};\\\", \\\"{x:1087,y:653,t:1512498013829};\\\", \\\"{x:1087,y:655,t:1512498013845};\\\", \\\"{x:1087,y:657,t:1512498013862};\\\", \\\"{x:1085,y:661,t:1512498013878};\\\", \\\"{x:1085,y:663,t:1512498013895};\\\", \\\"{x:1084,y:666,t:1512498013912};\\\", \\\"{x:1083,y:669,t:1512498013928};\\\", \\\"{x:1083,y:673,t:1512498013945};\\\", \\\"{x:1081,y:677,t:1512498013962};\\\", \\\"{x:1080,y:681,t:1512498013978};\\\", \\\"{x:1080,y:684,t:1512498013995};\\\", \\\"{x:1080,y:689,t:1512498014011};\\\", \\\"{x:1079,y:692,t:1512498014028};\\\", \\\"{x:1078,y:695,t:1512498014045};\\\", \\\"{x:1077,y:697,t:1512498014062};\\\", \\\"{x:1077,y:699,t:1512498014078};\\\", \\\"{x:1077,y:701,t:1512498014095};\\\", \\\"{x:1076,y:705,t:1512498014112};\\\", \\\"{x:1076,y:707,t:1512498014128};\\\", \\\"{x:1076,y:709,t:1512498014145};\\\", \\\"{x:1076,y:712,t:1512498014162};\\\", \\\"{x:1074,y:715,t:1512498014178};\\\", \\\"{x:1074,y:718,t:1512498014196};\\\", \\\"{x:1074,y:722,t:1512498014212};\\\", \\\"{x:1074,y:725,t:1512498014229};\\\", \\\"{x:1074,y:729,t:1512498014245};\\\", \\\"{x:1074,y:734,t:1512498014263};\\\", \\\"{x:1074,y:739,t:1512498014280};\\\", \\\"{x:1074,y:741,t:1512498014296};\\\", \\\"{x:1074,y:744,t:1512498014313};\\\", \\\"{x:1074,y:747,t:1512498014330};\\\", \\\"{x:1074,y:750,t:1512498014346};\\\", \\\"{x:1074,y:753,t:1512498014363};\\\", \\\"{x:1074,y:757,t:1512498014381};\\\", \\\"{x:1074,y:763,t:1512498014396};\\\", \\\"{x:1074,y:765,t:1512498014412};\\\", \\\"{x:1074,y:767,t:1512498014430};\\\", \\\"{x:1073,y:771,t:1512498014446};\\\", \\\"{x:1073,y:772,t:1512498014463};\\\", \\\"{x:1073,y:776,t:1512498014480};\\\", \\\"{x:1073,y:778,t:1512498014496};\\\", \\\"{x:1073,y:781,t:1512498014513};\\\", \\\"{x:1073,y:784,t:1512498014530};\\\", \\\"{x:1073,y:787,t:1512498014546};\\\", \\\"{x:1073,y:791,t:1512498014563};\\\", \\\"{x:1073,y:797,t:1512498014579};\\\", \\\"{x:1073,y:801,t:1512498014596};\\\", \\\"{x:1073,y:808,t:1512498014612};\\\", \\\"{x:1073,y:813,t:1512498014630};\\\", \\\"{x:1073,y:817,t:1512498014646};\\\", \\\"{x:1073,y:821,t:1512498014663};\\\", \\\"{x:1073,y:824,t:1512498014679};\\\", \\\"{x:1073,y:827,t:1512498014696};\\\", \\\"{x:1073,y:832,t:1512498014713};\\\", \\\"{x:1073,y:836,t:1512498014729};\\\", \\\"{x:1072,y:841,t:1512498014747};\\\", \\\"{x:1070,y:850,t:1512498014763};\\\", \\\"{x:1068,y:857,t:1512498014779};\\\", \\\"{x:1067,y:868,t:1512498014796};\\\", \\\"{x:1065,y:874,t:1512498014813};\\\", \\\"{x:1065,y:879,t:1512498014830};\\\", \\\"{x:1065,y:883,t:1512498014847};\\\", \\\"{x:1064,y:887,t:1512498014863};\\\", \\\"{x:1064,y:890,t:1512498014880};\\\", \\\"{x:1062,y:894,t:1512498014896};\\\", \\\"{x:1062,y:897,t:1512498014913};\\\", \\\"{x:1062,y:901,t:1512498014929};\\\", \\\"{x:1062,y:904,t:1512498014947};\\\", \\\"{x:1062,y:906,t:1512498014963};\\\", \\\"{x:1062,y:910,t:1512498014980};\\\", \\\"{x:1062,y:912,t:1512498014996};\\\", \\\"{x:1063,y:916,t:1512498015013};\\\", \\\"{x:1063,y:917,t:1512498015030};\\\", \\\"{x:1064,y:921,t:1512498015047};\\\", \\\"{x:1064,y:924,t:1512498015063};\\\", \\\"{x:1065,y:928,t:1512498015079};\\\", \\\"{x:1065,y:931,t:1512498015097};\\\", \\\"{x:1066,y:933,t:1512498015113};\\\", \\\"{x:1066,y:935,t:1512498015129};\\\", \\\"{x:1067,y:937,t:1512498015147};\\\", \\\"{x:1067,y:938,t:1512498015164};\\\", \\\"{x:1068,y:941,t:1512498015180};\\\", \\\"{x:1069,y:943,t:1512498015196};\\\", \\\"{x:1070,y:944,t:1512498015214};\\\", \\\"{x:1070,y:946,t:1512498015230};\\\", \\\"{x:1070,y:947,t:1512498015247};\\\", \\\"{x:1070,y:949,t:1512498015264};\\\", \\\"{x:1070,y:950,t:1512498015284};\\\", \\\"{x:1070,y:951,t:1512498015300};\\\", \\\"{x:1070,y:952,t:1512498015316};\\\", \\\"{x:1071,y:953,t:1512498015330};\\\", \\\"{x:1072,y:955,t:1512498015348};\\\", \\\"{x:1073,y:956,t:1512498015380};\\\", \\\"{x:1073,y:958,t:1512498015428};\\\", \\\"{x:1073,y:959,t:1512498015469};\\\", \\\"{x:1074,y:960,t:1512498015781};\\\", \\\"{x:1075,y:962,t:1512498015837};\\\", \\\"{x:1076,y:962,t:1512498015957};\\\", \\\"{x:1078,y:962,t:1512498015996};\\\", \\\"{x:1079,y:962,t:1512498016036};\\\", \\\"{x:1081,y:963,t:1512498016060};\\\", \\\"{x:1082,y:963,t:1512498016076};\\\", \\\"{x:1084,y:963,t:1512498016092};\\\", \\\"{x:1085,y:963,t:1512498016108};\\\", \\\"{x:1087,y:963,t:1512498016149};\\\", \\\"{x:1088,y:963,t:1512498016196};\\\", \\\"{x:1090,y:963,t:1512498016269};\\\", \\\"{x:1091,y:963,t:1512498016292};\\\", \\\"{x:1093,y:963,t:1512498016341};\\\", \\\"{x:1094,y:963,t:1512498016389};\\\", \\\"{x:1096,y:963,t:1512498016412};\\\", \\\"{x:1097,y:964,t:1512498016428};\\\", \\\"{x:1098,y:964,t:1512498016444};\\\", \\\"{x:1099,y:964,t:1512498016460};\\\", \\\"{x:1100,y:964,t:1512498016476};\\\", \\\"{x:1101,y:964,t:1512498016484};\\\", \\\"{x:1102,y:965,t:1512498016498};\\\", \\\"{x:1103,y:965,t:1512498016515};\\\", \\\"{x:1106,y:965,t:1512498016531};\\\", \\\"{x:1107,y:966,t:1512498016548};\\\", \\\"{x:1112,y:966,t:1512498016564};\\\", \\\"{x:1114,y:966,t:1512498016581};\\\", \\\"{x:1119,y:967,t:1512498016598};\\\", \\\"{x:1120,y:967,t:1512498016615};\\\", \\\"{x:1125,y:967,t:1512498016631};\\\", \\\"{x:1129,y:969,t:1512498016648};\\\", \\\"{x:1133,y:969,t:1512498016665};\\\", \\\"{x:1138,y:970,t:1512498016681};\\\", \\\"{x:1141,y:970,t:1512498016698};\\\", \\\"{x:1144,y:971,t:1512498016715};\\\", \\\"{x:1145,y:971,t:1512498016731};\\\", \\\"{x:1146,y:971,t:1512498016748};\\\", \\\"{x:1147,y:971,t:1512498016772};\\\", \\\"{x:1148,y:971,t:1512498017012};\\\", \\\"{x:1149,y:971,t:1512498017020};\\\", \\\"{x:1150,y:971,t:1512498017032};\\\", \\\"{x:1151,y:971,t:1512498017060};\\\", \\\"{x:1152,y:971,t:1512498017068};\\\", \\\"{x:1153,y:971,t:1512498017082};\\\", \\\"{x:1156,y:971,t:1512498017098};\\\", \\\"{x:1158,y:971,t:1512498017115};\\\", \\\"{x:1164,y:971,t:1512498017132};\\\", \\\"{x:1168,y:971,t:1512498017148};\\\", \\\"{x:1171,y:971,t:1512498017165};\\\", \\\"{x:1172,y:971,t:1512498017188};\\\", \\\"{x:1173,y:971,t:1512498017212};\\\", \\\"{x:1174,y:971,t:1512498017244};\\\", \\\"{x:1175,y:971,t:1512498017292};\\\", \\\"{x:1176,y:971,t:1512498017324};\\\", \\\"{x:1177,y:971,t:1512498017332};\\\", \\\"{x:1177,y:970,t:1512498017348};\\\", \\\"{x:1178,y:970,t:1512498017373};\\\", \\\"{x:1179,y:970,t:1512498017382};\\\", \\\"{x:1180,y:970,t:1512498017399};\\\", \\\"{x:1181,y:970,t:1512498017415};\\\", \\\"{x:1183,y:970,t:1512498017432};\\\", \\\"{x:1186,y:970,t:1512498017450};\\\", \\\"{x:1190,y:970,t:1512498017466};\\\", \\\"{x:1193,y:970,t:1512498017483};\\\", \\\"{x:1196,y:970,t:1512498017500};\\\", \\\"{x:1198,y:970,t:1512498017516};\\\", \\\"{x:1199,y:970,t:1512498017533};\\\", \\\"{x:1200,y:970,t:1512498017557};\\\", \\\"{x:1201,y:969,t:1512498017566};\\\", \\\"{x:1202,y:969,t:1512498017654};\\\", \\\"{x:1203,y:968,t:1512498017685};\\\", \\\"{x:1204,y:968,t:1512498018006};\\\", \\\"{x:1205,y:968,t:1512498018017};\\\", \\\"{x:1206,y:968,t:1512498018077};\\\", \\\"{x:1207,y:968,t:1512498018085};\\\", \\\"{x:1208,y:968,t:1512498018100};\\\", \\\"{x:1211,y:968,t:1512498018117};\\\", \\\"{x:1212,y:968,t:1512498018133};\\\", \\\"{x:1214,y:968,t:1512498018150};\\\", \\\"{x:1215,y:968,t:1512498018167};\\\", \\\"{x:1216,y:968,t:1512498018189};\\\", \\\"{x:1217,y:968,t:1512498018200};\\\", \\\"{x:1218,y:969,t:1512498018217};\\\", \\\"{x:1219,y:969,t:1512498018237};\\\", \\\"{x:1221,y:969,t:1512498018253};\\\", \\\"{x:1222,y:969,t:1512498018269};\\\", \\\"{x:1224,y:969,t:1512498018283};\\\", \\\"{x:1225,y:970,t:1512498018300};\\\", \\\"{x:1228,y:970,t:1512498018317};\\\", \\\"{x:1231,y:970,t:1512498018333};\\\", \\\"{x:1234,y:970,t:1512498018350};\\\", \\\"{x:1238,y:970,t:1512498018367};\\\", \\\"{x:1241,y:970,t:1512498018384};\\\", \\\"{x:1244,y:970,t:1512498018400};\\\", \\\"{x:1248,y:970,t:1512498018417};\\\", \\\"{x:1252,y:970,t:1512498018434};\\\", \\\"{x:1255,y:970,t:1512498018450};\\\", \\\"{x:1259,y:970,t:1512498018467};\\\", \\\"{x:1261,y:970,t:1512498018484};\\\", \\\"{x:1263,y:970,t:1512498018500};\\\", \\\"{x:1264,y:970,t:1512498018517};\\\", \\\"{x:1267,y:970,t:1512498018533};\\\", \\\"{x:1268,y:970,t:1512498018550};\\\", \\\"{x:1270,y:970,t:1512498018567};\\\", \\\"{x:1271,y:970,t:1512498018584};\\\", \\\"{x:1272,y:970,t:1512498018600};\\\", \\\"{x:1273,y:970,t:1512498018677};\\\", \\\"{x:1274,y:970,t:1512498018693};\\\", \\\"{x:1275,y:970,t:1512498018741};\\\", \\\"{x:1276,y:970,t:1512498018798};\\\", \\\"{x:1277,y:970,t:1512498018805};\\\", \\\"{x:1280,y:969,t:1512498018817};\\\", \\\"{x:1284,y:968,t:1512498018834};\\\", \\\"{x:1287,y:968,t:1512498018851};\\\", \\\"{x:1292,y:966,t:1512498018867};\\\", \\\"{x:1294,y:966,t:1512498018885};\\\", \\\"{x:1295,y:966,t:1512498018901};\\\", \\\"{x:1297,y:966,t:1512498018917};\\\", \\\"{x:1299,y:966,t:1512498018934};\\\", \\\"{x:1300,y:966,t:1512498018951};\\\", \\\"{x:1301,y:966,t:1512498019037};\\\", \\\"{x:1302,y:966,t:1512498019051};\\\", \\\"{x:1303,y:966,t:1512498019067};\\\", \\\"{x:1304,y:966,t:1512498019109};\\\", \\\"{x:1305,y:966,t:1512498019133};\\\", \\\"{x:1306,y:966,t:1512498019157};\\\", \\\"{x:1308,y:966,t:1512498019492};\\\", \\\"{x:1309,y:965,t:1512498019805};\\\", \\\"{x:1309,y:963,t:1512498019845};\\\", \\\"{x:1309,y:962,t:1512498019949};\\\", \\\"{x:1308,y:961,t:1512498019997};\\\", \\\"{x:1308,y:960,t:1512498020061};\\\", \\\"{x:1307,y:960,t:1512498023661};\\\", \\\"{x:1307,y:959,t:1512498024509};\\\", \\\"{x:1309,y:959,t:1512498024533};\\\", \\\"{x:1310,y:958,t:1512498024541};\\\", \\\"{x:1311,y:958,t:1512498024557};\\\", \\\"{x:1312,y:958,t:1512498024581};\\\", \\\"{x:1312,y:959,t:1512498025117};\\\", \\\"{x:1312,y:961,t:1512498025141};\\\", \\\"{x:1312,y:962,t:1512498025197};\\\", \\\"{x:1312,y:963,t:1512498025301};\\\", \\\"{x:1311,y:964,t:1512498025341};\\\", \\\"{x:1308,y:963,t:1512498032213};\\\", \\\"{x:1301,y:958,t:1512498032227};\\\", \\\"{x:1281,y:951,t:1512498032244};\\\", \\\"{x:1256,y:945,t:1512498032260};\\\", \\\"{x:1207,y:931,t:1512498032277};\\\", \\\"{x:1159,y:915,t:1512498032294};\\\", \\\"{x:1136,y:905,t:1512498032311};\\\", \\\"{x:1109,y:889,t:1512498032327};\\\", \\\"{x:1067,y:866,t:1512498032344};\\\", \\\"{x:1017,y:836,t:1512498032361};\\\", \\\"{x:970,y:803,t:1512498032377};\\\", \\\"{x:932,y:775,t:1512498032394};\\\", \\\"{x:915,y:759,t:1512498032411};\\\", \\\"{x:913,y:750,t:1512498032428};\\\", \\\"{x:911,y:740,t:1512498032444};\\\", \\\"{x:911,y:727,t:1512498032460};\\\", \\\"{x:912,y:720,t:1512498032477};\\\", \\\"{x:915,y:705,t:1512498032494};\\\", \\\"{x:920,y:691,t:1512498032511};\\\", \\\"{x:927,y:675,t:1512498032527};\\\", \\\"{x:935,y:660,t:1512498032544};\\\", \\\"{x:949,y:641,t:1512498032561};\\\", \\\"{x:959,y:630,t:1512498032578};\\\", \\\"{x:970,y:618,t:1512498032594};\\\", \\\"{x:980,y:610,t:1512498032611};\\\", \\\"{x:989,y:605,t:1512498032628};\\\", \\\"{x:1002,y:598,t:1512498032644};\\\", \\\"{x:1012,y:593,t:1512498032660};\\\", \\\"{x:1021,y:590,t:1512498032678};\\\", \\\"{x:1026,y:590,t:1512498032694};\\\", \\\"{x:1030,y:590,t:1512498032711};\\\", \\\"{x:1033,y:590,t:1512498032728};\\\", \\\"{x:1044,y:594,t:1512498032744};\\\", \\\"{x:1055,y:604,t:1512498032761};\\\", \\\"{x:1061,y:611,t:1512498032778};\\\", \\\"{x:1065,y:619,t:1512498032794};\\\", \\\"{x:1068,y:630,t:1512498032811};\\\", \\\"{x:1071,y:645,t:1512498032828};\\\", \\\"{x:1074,y:654,t:1512498032844};\\\", \\\"{x:1077,y:668,t:1512498032861};\\\", \\\"{x:1079,y:681,t:1512498032878};\\\", \\\"{x:1079,y:690,t:1512498032894};\\\", \\\"{x:1079,y:702,t:1512498032911};\\\", \\\"{x:1077,y:715,t:1512498032928};\\\", \\\"{x:1075,y:725,t:1512498032945};\\\", \\\"{x:1075,y:731,t:1512498032961};\\\", \\\"{x:1075,y:737,t:1512498032978};\\\", \\\"{x:1075,y:740,t:1512498032995};\\\", \\\"{x:1075,y:745,t:1512498033011};\\\", \\\"{x:1075,y:749,t:1512498033028};\\\", \\\"{x:1075,y:756,t:1512498033044};\\\", \\\"{x:1075,y:760,t:1512498033061};\\\", \\\"{x:1075,y:762,t:1512498033078};\\\", \\\"{x:1075,y:764,t:1512498033095};\\\", \\\"{x:1076,y:767,t:1512498033111};\\\", \\\"{x:1076,y:769,t:1512498033128};\\\", \\\"{x:1076,y:771,t:1512498033145};\\\", \\\"{x:1076,y:774,t:1512498033161};\\\", \\\"{x:1076,y:780,t:1512498033178};\\\", \\\"{x:1076,y:785,t:1512498033195};\\\", \\\"{x:1077,y:794,t:1512498033211};\\\", \\\"{x:1077,y:800,t:1512498033228};\\\", \\\"{x:1078,y:810,t:1512498033244};\\\", \\\"{x:1078,y:816,t:1512498033261};\\\", \\\"{x:1079,y:821,t:1512498033278};\\\", \\\"{x:1079,y:825,t:1512498033295};\\\", \\\"{x:1079,y:829,t:1512498033311};\\\", \\\"{x:1079,y:832,t:1512498033328};\\\", \\\"{x:1079,y:836,t:1512498033345};\\\", \\\"{x:1079,y:842,t:1512498033361};\\\", \\\"{x:1079,y:848,t:1512498033378};\\\", \\\"{x:1079,y:855,t:1512498033395};\\\", \\\"{x:1077,y:864,t:1512498033412};\\\", \\\"{x:1076,y:871,t:1512498033428};\\\", \\\"{x:1076,y:879,t:1512498033444};\\\", \\\"{x:1075,y:883,t:1512498033462};\\\", \\\"{x:1075,y:887,t:1512498033478};\\\", \\\"{x:1075,y:892,t:1512498033495};\\\", \\\"{x:1075,y:896,t:1512498033512};\\\", \\\"{x:1075,y:899,t:1512498033528};\\\", \\\"{x:1075,y:901,t:1512498033545};\\\", \\\"{x:1075,y:904,t:1512498033562};\\\", \\\"{x:1075,y:910,t:1512498033578};\\\", \\\"{x:1075,y:914,t:1512498033595};\\\", \\\"{x:1075,y:918,t:1512498033612};\\\", \\\"{x:1075,y:921,t:1512498033628};\\\", \\\"{x:1075,y:924,t:1512498033645};\\\", \\\"{x:1075,y:925,t:1512498033662};\\\", \\\"{x:1074,y:928,t:1512498033678};\\\", \\\"{x:1073,y:929,t:1512498033695};\\\", \\\"{x:1073,y:930,t:1512498033712};\\\", \\\"{x:1073,y:933,t:1512498033728};\\\", \\\"{x:1073,y:935,t:1512498033745};\\\", \\\"{x:1073,y:937,t:1512498033762};\\\", \\\"{x:1073,y:939,t:1512498033778};\\\", \\\"{x:1073,y:940,t:1512498033795};\\\", \\\"{x:1073,y:943,t:1512498033812};\\\", \\\"{x:1073,y:945,t:1512498033828};\\\", \\\"{x:1073,y:946,t:1512498033845};\\\", \\\"{x:1074,y:947,t:1512498033862};\\\", \\\"{x:1074,y:950,t:1512498033879};\\\", \\\"{x:1074,y:952,t:1512498033895};\\\", \\\"{x:1074,y:953,t:1512498033912};\\\", \\\"{x:1074,y:955,t:1512498033929};\\\", \\\"{x:1074,y:956,t:1512498033945};\\\", \\\"{x:1076,y:957,t:1512498033962};\\\", \\\"{x:1076,y:958,t:1512498033979};\\\", \\\"{x:1076,y:959,t:1512498033995};\\\", \\\"{x:1076,y:960,t:1512498034012};\\\", \\\"{x:1076,y:962,t:1512498034029};\\\", \\\"{x:1076,y:963,t:1512498034045};\\\", \\\"{x:1076,y:964,t:1512498034084};\\\", \\\"{x:1078,y:964,t:1512498034509};\\\", \\\"{x:1079,y:964,t:1512498034524};\\\", \\\"{x:1081,y:964,t:1512498034540};\\\", \\\"{x:1083,y:964,t:1512498034548};\\\", \\\"{x:1085,y:964,t:1512498034564};\\\", \\\"{x:1086,y:964,t:1512498034579};\\\", \\\"{x:1092,y:964,t:1512498034596};\\\", \\\"{x:1095,y:964,t:1512498034612};\\\", \\\"{x:1099,y:964,t:1512498034628};\\\", \\\"{x:1102,y:964,t:1512498034646};\\\", \\\"{x:1107,y:965,t:1512498034662};\\\", \\\"{x:1111,y:965,t:1512498034679};\\\", \\\"{x:1115,y:966,t:1512498034696};\\\", \\\"{x:1120,y:966,t:1512498034712};\\\", \\\"{x:1123,y:966,t:1512498034729};\\\", \\\"{x:1125,y:966,t:1512498034746};\\\", \\\"{x:1128,y:966,t:1512498034763};\\\", \\\"{x:1130,y:966,t:1512498034779};\\\", \\\"{x:1131,y:966,t:1512498034796};\\\", \\\"{x:1134,y:966,t:1512498034812};\\\", \\\"{x:1138,y:967,t:1512498034829};\\\", \\\"{x:1144,y:967,t:1512498034846};\\\", \\\"{x:1148,y:968,t:1512498034863};\\\", \\\"{x:1151,y:968,t:1512498034879};\\\", \\\"{x:1153,y:969,t:1512498034896};\\\", \\\"{x:1153,y:970,t:1512498035214};\\\", \\\"{x:1152,y:971,t:1512498035285};\\\", \\\"{x:1151,y:971,t:1512498035301};\\\", \\\"{x:1151,y:972,t:1512498035389};\\\", \\\"{x:1150,y:972,t:1512498035421};\\\", \\\"{x:1148,y:973,t:1512498035453};\\\", \\\"{x:1147,y:973,t:1512498035477};\\\", \\\"{x:1146,y:973,t:1512498035493};\\\", \\\"{x:1145,y:973,t:1512498035549};\\\", \\\"{x:1144,y:973,t:1512498035564};\\\", \\\"{x:1142,y:973,t:1512498035581};\\\", \\\"{x:1140,y:973,t:1512498035597};\\\", \\\"{x:1139,y:973,t:1512498035613};\\\", \\\"{x:1138,y:973,t:1512498035631};\\\", \\\"{x:1136,y:973,t:1512498036534};\\\", \\\"{x:1132,y:973,t:1512498036548};\\\", \\\"{x:1120,y:973,t:1512498036565};\\\", \\\"{x:1114,y:973,t:1512498036581};\\\", \\\"{x:1110,y:975,t:1512498036598};\\\", \\\"{x:1105,y:975,t:1512498036615};\\\", \\\"{x:1104,y:975,t:1512498036637};\\\", \\\"{x:1103,y:975,t:1512498036653};\\\", \\\"{x:1102,y:975,t:1512498036677};\\\", \\\"{x:1101,y:975,t:1512498036925};\\\", \\\"{x:1100,y:975,t:1512498037069};\\\", \\\"{x:1099,y:975,t:1512498037081};\\\", \\\"{x:1098,y:974,t:1512498037099};\\\", \\\"{x:1097,y:974,t:1512498037156};\\\", \\\"{x:1096,y:974,t:1512498037180};\\\", \\\"{x:1094,y:974,t:1512498037196};\\\", \\\"{x:1093,y:974,t:1512498037204};\\\", \\\"{x:1091,y:974,t:1512498037214};\\\", \\\"{x:1090,y:974,t:1512498037231};\\\", \\\"{x:1087,y:974,t:1512498037248};\\\", \\\"{x:1085,y:974,t:1512498037264};\\\", \\\"{x:1084,y:974,t:1512498037281};\\\", \\\"{x:1083,y:974,t:1512498037298};\\\", \\\"{x:1081,y:974,t:1512498037314};\\\", \\\"{x:1078,y:974,t:1512498037331};\\\", \\\"{x:1077,y:974,t:1512498037349};\\\", \\\"{x:1076,y:974,t:1512498037365};\\\", \\\"{x:1075,y:974,t:1512498037382};\\\", \\\"{x:1077,y:974,t:1512498037677};\\\", \\\"{x:1078,y:974,t:1512498037693};\\\", \\\"{x:1080,y:974,t:1512498037701};\\\", \\\"{x:1081,y:974,t:1512498037716};\\\", \\\"{x:1082,y:974,t:1512498037732};\\\", \\\"{x:1085,y:974,t:1512498037749};\\\", \\\"{x:1088,y:974,t:1512498037765};\\\", \\\"{x:1091,y:974,t:1512498037782};\\\", \\\"{x:1094,y:974,t:1512498037799};\\\", \\\"{x:1098,y:973,t:1512498037816};\\\", \\\"{x:1103,y:972,t:1512498037833};\\\", \\\"{x:1105,y:972,t:1512498037849};\\\", \\\"{x:1109,y:971,t:1512498037866};\\\", \\\"{x:1111,y:971,t:1512498038445};\\\", \\\"{x:1112,y:971,t:1512498038453};\\\", \\\"{x:1115,y:971,t:1512498038466};\\\", \\\"{x:1119,y:971,t:1512498038483};\\\", \\\"{x:1124,y:971,t:1512498038500};\\\", \\\"{x:1127,y:971,t:1512498038516};\\\", \\\"{x:1132,y:972,t:1512498038533};\\\", \\\"{x:1133,y:972,t:1512498038549};\\\", \\\"{x:1134,y:972,t:1512498038621};\\\", \\\"{x:1135,y:972,t:1512498038637};\\\", \\\"{x:1136,y:972,t:1512498038650};\\\", \\\"{x:1137,y:972,t:1512498038666};\\\", \\\"{x:1140,y:972,t:1512498038683};\\\", \\\"{x:1142,y:972,t:1512498038700};\\\", \\\"{x:1146,y:972,t:1512498038717};\\\", \\\"{x:1148,y:972,t:1512498038733};\\\", \\\"{x:1149,y:972,t:1512498038750};\\\", \\\"{x:1151,y:972,t:1512498038767};\\\", \\\"{x:1152,y:972,t:1512498038783};\\\", \\\"{x:1153,y:972,t:1512498038800};\\\", \\\"{x:1154,y:972,t:1512498038817};\\\", \\\"{x:1155,y:971,t:1512498038833};\\\", \\\"{x:1156,y:971,t:1512498038850};\\\", \\\"{x:1157,y:971,t:1512498038877};\\\", \\\"{x:1158,y:971,t:1512498038893};\\\", \\\"{x:1159,y:971,t:1512498038909};\\\", \\\"{x:1161,y:971,t:1512498038917};\\\", \\\"{x:1163,y:970,t:1512498038933};\\\", \\\"{x:1164,y:969,t:1512498038949};\\\", \\\"{x:1165,y:969,t:1512498038967};\\\", \\\"{x:1167,y:969,t:1512498039053};\\\", \\\"{x:1168,y:969,t:1512498039077};\\\", \\\"{x:1170,y:969,t:1512498039117};\\\", \\\"{x:1171,y:968,t:1512498039165};\\\", \\\"{x:1173,y:968,t:1512498039173};\\\", \\\"{x:1176,y:968,t:1512498039189};\\\", \\\"{x:1177,y:968,t:1512498039200};\\\", \\\"{x:1179,y:968,t:1512498039217};\\\", \\\"{x:1180,y:968,t:1512498039233};\\\", \\\"{x:1182,y:968,t:1512498039452};\\\", \\\"{x:1183,y:968,t:1512498039466};\\\", \\\"{x:1186,y:968,t:1512498039483};\\\", \\\"{x:1190,y:968,t:1512498039499};\\\", \\\"{x:1197,y:970,t:1512498039516};\\\", \\\"{x:1202,y:970,t:1512498039533};\\\", \\\"{x:1206,y:970,t:1512498039549};\\\", \\\"{x:1211,y:970,t:1512498039566};\\\", \\\"{x:1215,y:970,t:1512498039583};\\\", \\\"{x:1217,y:971,t:1512498039599};\\\", \\\"{x:1220,y:971,t:1512498039616};\\\", \\\"{x:1222,y:971,t:1512498039633};\\\", \\\"{x:1223,y:971,t:1512498039650};\\\", \\\"{x:1226,y:971,t:1512498039666};\\\", \\\"{x:1228,y:971,t:1512498039683};\\\", \\\"{x:1231,y:971,t:1512498039700};\\\", \\\"{x:1233,y:971,t:1512498039724};\\\", \\\"{x:1234,y:971,t:1512498039741};\\\", \\\"{x:1235,y:971,t:1512498039757};\\\", \\\"{x:1236,y:971,t:1512498039789};\\\", \\\"{x:1237,y:971,t:1512498039801};\\\", \\\"{x:1238,y:971,t:1512498039837};\\\", \\\"{x:1239,y:971,t:1512498039860};\\\", \\\"{x:1240,y:971,t:1512498039868};\\\", \\\"{x:1241,y:971,t:1512498039883};\\\", \\\"{x:1242,y:971,t:1512498039916};\\\", \\\"{x:1244,y:971,t:1512498041485};\\\", \\\"{x:1245,y:972,t:1512498041502};\\\", \\\"{x:1248,y:972,t:1512498041519};\\\", \\\"{x:1251,y:972,t:1512498041535};\\\", \\\"{x:1254,y:973,t:1512498041552};\\\", \\\"{x:1258,y:974,t:1512498041569};\\\", \\\"{x:1261,y:974,t:1512498041585};\\\", \\\"{x:1262,y:974,t:1512498041602};\\\", \\\"{x:1265,y:974,t:1512498041619};\\\", \\\"{x:1268,y:974,t:1512498041635};\\\", \\\"{x:1269,y:974,t:1512498041669};\\\", \\\"{x:1270,y:974,t:1512498041693};\\\", \\\"{x:1271,y:974,t:1512498041709};\\\", \\\"{x:1272,y:974,t:1512498041719};\\\", \\\"{x:1273,y:974,t:1512498041735};\\\", \\\"{x:1275,y:974,t:1512498041752};\\\", \\\"{x:1276,y:974,t:1512498041769};\\\", \\\"{x:1278,y:974,t:1512498041785};\\\", \\\"{x:1280,y:974,t:1512498041802};\\\", \\\"{x:1282,y:974,t:1512498041819};\\\", \\\"{x:1284,y:974,t:1512498041836};\\\", \\\"{x:1286,y:974,t:1512498041852};\\\", \\\"{x:1290,y:974,t:1512498041869};\\\", \\\"{x:1294,y:974,t:1512498041885};\\\", \\\"{x:1296,y:974,t:1512498041902};\\\", \\\"{x:1299,y:974,t:1512498041919};\\\", \\\"{x:1301,y:974,t:1512498041936};\\\", \\\"{x:1302,y:974,t:1512498041952};\\\", \\\"{x:1303,y:974,t:1512498041989};\\\", \\\"{x:1304,y:974,t:1512498042005};\\\", \\\"{x:1305,y:974,t:1512498042019};\\\", \\\"{x:1307,y:974,t:1512498042036};\\\", \\\"{x:1308,y:974,t:1512498042093};\\\", \\\"{x:1309,y:974,t:1512498042429};\\\", \\\"{x:1310,y:974,t:1512498042461};\\\", \\\"{x:1311,y:973,t:1512498042485};\\\", \\\"{x:1312,y:973,t:1512498042503};\\\", \\\"{x:1312,y:972,t:1512498043413};\\\", \\\"{x:1310,y:972,t:1512498044912};\\\", \\\"{x:1305,y:970,t:1512498044924};\\\", \\\"{x:1285,y:963,t:1512498044941};\\\", \\\"{x:1250,y:954,t:1512498044958};\\\", \\\"{x:1192,y:938,t:1512498044974};\\\", \\\"{x:1088,y:901,t:1512498044991};\\\", \\\"{x:988,y:869,t:1512498045007};\\\", \\\"{x:834,y:812,t:1512498045023};\\\", \\\"{x:721,y:764,t:1512498045041};\\\", \\\"{x:614,y:703,t:1512498045058};\\\", \\\"{x:520,y:657,t:1512498045073};\\\", \\\"{x:445,y:623,t:1512498045091};\\\", \\\"{x:390,y:600,t:1512498045108};\\\", \\\"{x:356,y:585,t:1512498045124};\\\", \\\"{x:338,y:576,t:1512498045140};\\\", \\\"{x:328,y:571,t:1512498045158};\\\", \\\"{x:325,y:569,t:1512498045173};\\\", \\\"{x:325,y:572,t:1512498045288};\\\", \\\"{x:325,y:575,t:1512498045296};\\\", \\\"{x:328,y:580,t:1512498045308};\\\", \\\"{x:337,y:590,t:1512498045323};\\\", \\\"{x:351,y:604,t:1512498045340};\\\", \\\"{x:370,y:620,t:1512498045357};\\\", \\\"{x:386,y:631,t:1512498045374};\\\", \\\"{x:398,y:641,t:1512498045390};\\\", \\\"{x:414,y:653,t:1512498045406};\\\", \\\"{x:422,y:659,t:1512498045424};\\\", \\\"{x:430,y:665,t:1512498045440};\\\", \\\"{x:437,y:672,t:1512498045457};\\\", \\\"{x:439,y:674,t:1512498045474};\\\", \\\"{x:439,y:676,t:1512498045490};\\\", \\\"{x:439,y:677,t:1512498045551};\\\", \\\"{x:438,y:679,t:1512498045558};\\\", \\\"{x:437,y:680,t:1512498045583};\\\", \\\"{x:436,y:680,t:1512498045599};\\\", \\\"{x:435,y:680,t:1512498045615};\\\", \\\"{x:435,y:681,t:1512498045631};\\\", \\\"{x:434,y:682,t:1512498045641};\\\", \\\"{x:433,y:682,t:1512498045662};\\\", \\\"{x:432,y:682,t:1512498045695};\\\" ] }, { \\\"rt\\\": 17170, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 500198, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:431,y:682,t:1512498049056};\\\", \\\"{x:429,y:682,t:1512498049070};\\\", \\\"{x:429,y:679,t:1512498049080};\\\", \\\"{x:427,y:673,t:1512498049097};\\\", \\\"{x:426,y:667,t:1512498049113};\\\", \\\"{x:426,y:662,t:1512498049127};\\\", \\\"{x:426,y:656,t:1512498049144};\\\", \\\"{x:426,y:651,t:1512498049161};\\\", \\\"{x:426,y:640,t:1512498049178};\\\", \\\"{x:426,y:630,t:1512498049194};\\\", \\\"{x:426,y:619,t:1512498049211};\\\", \\\"{x:426,y:606,t:1512498049228};\\\", \\\"{x:426,y:596,t:1512498049244};\\\", \\\"{x:426,y:583,t:1512498049261};\\\", \\\"{x:426,y:568,t:1512498049278};\\\", \\\"{x:426,y:554,t:1512498049294};\\\", \\\"{x:425,y:534,t:1512498049311};\\\", \\\"{x:424,y:526,t:1512498049328};\\\", \\\"{x:422,y:519,t:1512498049344};\\\", \\\"{x:422,y:514,t:1512498049361};\\\", \\\"{x:422,y:510,t:1512498049378};\\\", \\\"{x:421,y:509,t:1512498049394};\\\", \\\"{x:421,y:506,t:1512498049411};\\\", \\\"{x:421,y:504,t:1512498049428};\\\", \\\"{x:421,y:503,t:1512498049444};\\\", \\\"{x:421,y:502,t:1512498049639};\\\", \\\"{x:421,y:501,t:1512498049646};\\\", \\\"{x:421,y:500,t:1512498049661};\\\", \\\"{x:419,y:499,t:1512498049678};\\\", \\\"{x:419,y:498,t:1512498049702};\\\", \\\"{x:419,y:497,t:1512498049735};\\\", \\\"{x:418,y:497,t:1512498049751};\\\", \\\"{x:418,y:496,t:1512498050696};\\\", \\\"{x:417,y:496,t:1512498050712};\\\", \\\"{x:416,y:496,t:1512498052166};\\\", \\\"{x:415,y:496,t:1512498052182};\\\", \\\"{x:414,y:497,t:1512498052197};\\\", \\\"{x:413,y:498,t:1512498052213};\\\", \\\"{x:411,y:499,t:1512498052230};\\\", \\\"{x:411,y:500,t:1512498052246};\\\", \\\"{x:410,y:503,t:1512498052263};\\\", \\\"{x:410,y:508,t:1512498052280};\\\", \\\"{x:410,y:513,t:1512498052297};\\\", \\\"{x:410,y:518,t:1512498052313};\\\", \\\"{x:410,y:525,t:1512498052330};\\\", \\\"{x:410,y:535,t:1512498052347};\\\", \\\"{x:411,y:545,t:1512498052363};\\\", \\\"{x:419,y:555,t:1512498052380};\\\", \\\"{x:425,y:558,t:1512498052397};\\\", \\\"{x:434,y:564,t:1512498052413};\\\", \\\"{x:469,y:578,t:1512498052431};\\\", \\\"{x:500,y:592,t:1512498052447};\\\", \\\"{x:534,y:608,t:1512498052464};\\\", \\\"{x:579,y:628,t:1512498052481};\\\", \\\"{x:626,y:648,t:1512498052498};\\\", \\\"{x:636,y:659,t:1512498052514};\\\", \\\"{x:640,y:665,t:1512498052531};\\\", \\\"{x:639,y:666,t:1512498053776};\\\", \\\"{x:638,y:666,t:1512498054096};\\\", \\\"{x:639,y:666,t:1512498059160};\\\", \\\"{x:640,y:666,t:1512498059169};\\\", \\\"{x:645,y:664,t:1512498059186};\\\", \\\"{x:648,y:662,t:1512498059202};\\\", \\\"{x:651,y:660,t:1512498059219};\\\", \\\"{x:654,y:658,t:1512498059236};\\\", \\\"{x:657,y:657,t:1512498059252};\\\", \\\"{x:658,y:657,t:1512498059270};\\\", \\\"{x:658,y:656,t:1512498059287};\\\", \\\"{x:659,y:656,t:1512498059352};\\\", \\\"{x:660,y:656,t:1512498059370};\\\", \\\"{x:662,y:655,t:1512498059399};\\\", \\\"{x:663,y:654,t:1512498059424};\\\", \\\"{x:664,y:654,t:1512498059436};\\\", \\\"{x:668,y:652,t:1512498059452};\\\", \\\"{x:670,y:651,t:1512498059469};\\\", \\\"{x:671,y:650,t:1512498059486};\\\", \\\"{x:672,y:650,t:1512498059502};\\\", \\\"{x:674,y:649,t:1512498059519};\\\", \\\"{x:675,y:648,t:1512498059537};\\\", \\\"{x:676,y:647,t:1512498060048};\\\", \\\"{x:677,y:646,t:1512498060055};\\\", \\\"{x:681,y:644,t:1512498060070};\\\", \\\"{x:691,y:640,t:1512498060087};\\\", \\\"{x:724,y:629,t:1512498060103};\\\", \\\"{x:753,y:624,t:1512498060120};\\\", \\\"{x:797,y:618,t:1512498060137};\\\", \\\"{x:831,y:618,t:1512498060154};\\\", \\\"{x:861,y:618,t:1512498060170};\\\", \\\"{x:891,y:618,t:1512498060187};\\\", \\\"{x:918,y:618,t:1512498060204};\\\", \\\"{x:939,y:618,t:1512498060221};\\\", \\\"{x:953,y:619,t:1512498060237};\\\", \\\"{x:961,y:623,t:1512498060254};\\\", \\\"{x:966,y:626,t:1512498060271};\\\", \\\"{x:967,y:627,t:1512498060287};\\\", \\\"{x:970,y:632,t:1512498060304};\\\", \\\"{x:970,y:635,t:1512498060320};\\\", \\\"{x:970,y:639,t:1512498060337};\\\", \\\"{x:970,y:642,t:1512498060354};\\\", \\\"{x:970,y:644,t:1512498060371};\\\", \\\"{x:971,y:645,t:1512498060440};\\\", \\\"{x:973,y:645,t:1512498060453};\\\", \\\"{x:976,y:645,t:1512498060470};\\\", \\\"{x:980,y:643,t:1512498060486};\\\", \\\"{x:985,y:640,t:1512498060503};\\\", \\\"{x:989,y:637,t:1512498060520};\\\", \\\"{x:994,y:633,t:1512498060536};\\\", \\\"{x:1001,y:628,t:1512498060553};\\\", \\\"{x:1009,y:623,t:1512498060570};\\\", \\\"{x:1013,y:619,t:1512498060587};\\\", \\\"{x:1014,y:618,t:1512498060603};\\\", \\\"{x:1018,y:616,t:1512498060620};\\\", \\\"{x:1019,y:614,t:1512498060637};\\\", \\\"{x:1021,y:613,t:1512498060653};\\\", \\\"{x:1023,y:611,t:1512498060670};\\\", \\\"{x:1031,y:607,t:1512498060687};\\\", \\\"{x:1035,y:605,t:1512498060703};\\\", \\\"{x:1045,y:599,t:1512498060720};\\\", \\\"{x:1050,y:595,t:1512498060737};\\\", \\\"{x:1057,y:590,t:1512498060753};\\\", \\\"{x:1066,y:583,t:1512498060770};\\\", \\\"{x:1072,y:579,t:1512498060787};\\\", \\\"{x:1078,y:573,t:1512498060804};\\\", \\\"{x:1082,y:571,t:1512498060821};\\\", \\\"{x:1084,y:569,t:1512498060838};\\\", \\\"{x:1085,y:569,t:1512498060854};\\\", \\\"{x:1083,y:569,t:1512498061576};\\\", \\\"{x:1077,y:569,t:1512498061588};\\\", \\\"{x:1057,y:569,t:1512498061605};\\\", \\\"{x:1034,y:569,t:1512498061622};\\\", \\\"{x:1013,y:569,t:1512498061638};\\\", \\\"{x:1000,y:569,t:1512498061654};\\\", \\\"{x:987,y:569,t:1512498061672};\\\", \\\"{x:980,y:566,t:1512498061687};\\\", \\\"{x:968,y:564,t:1512498061705};\\\", \\\"{x:952,y:559,t:1512498061722};\\\", \\\"{x:943,y:556,t:1512498061738};\\\", \\\"{x:938,y:556,t:1512498061755};\\\", \\\"{x:933,y:554,t:1512498061772};\\\", \\\"{x:927,y:553,t:1512498061788};\\\", \\\"{x:919,y:553,t:1512498061805};\\\", \\\"{x:903,y:551,t:1512498061822};\\\", \\\"{x:864,y:547,t:1512498061837};\\\", \\\"{x:789,y:547,t:1512498061855};\\\", \\\"{x:664,y:557,t:1512498061871};\\\", \\\"{x:586,y:557,t:1512498061887};\\\", \\\"{x:542,y:557,t:1512498061905};\\\", \\\"{x:508,y:557,t:1512498061922};\\\", \\\"{x:482,y:557,t:1512498061938};\\\", \\\"{x:459,y:557,t:1512498061954};\\\", \\\"{x:441,y:557,t:1512498061972};\\\", \\\"{x:433,y:557,t:1512498061989};\\\", \\\"{x:435,y:557,t:1512498062055};\\\", \\\"{x:437,y:556,t:1512498062072};\\\", \\\"{x:441,y:554,t:1512498062089};\\\", \\\"{x:443,y:553,t:1512498062105};\\\", \\\"{x:450,y:551,t:1512498062122};\\\", \\\"{x:454,y:549,t:1512498062139};\\\", \\\"{x:456,y:549,t:1512498062156};\\\", \\\"{x:457,y:549,t:1512498062224};\\\", \\\"{x:459,y:549,t:1512498062239};\\\", \\\"{x:459,y:548,t:1512498062256};\\\", \\\"{x:458,y:548,t:1512498062352};\\\", \\\"{x:455,y:547,t:1512498062360};\\\", \\\"{x:452,y:546,t:1512498062372};\\\", \\\"{x:446,y:544,t:1512498062389};\\\", \\\"{x:442,y:543,t:1512498062407};\\\", \\\"{x:437,y:541,t:1512498062423};\\\", \\\"{x:427,y:541,t:1512498062439};\\\", \\\"{x:422,y:539,t:1512498062456};\\\", \\\"{x:419,y:538,t:1512498062473};\\\", \\\"{x:418,y:537,t:1512498062489};\\\", \\\"{x:417,y:537,t:1512498062506};\\\", \\\"{x:416,y:537,t:1512498062523};\\\", \\\"{x:414,y:537,t:1512498062575};\\\", \\\"{x:413,y:537,t:1512498062591};\\\", \\\"{x:412,y:536,t:1512498062606};\\\", \\\"{x:405,y:535,t:1512498062623};\\\", \\\"{x:400,y:535,t:1512498062639};\\\", \\\"{x:398,y:535,t:1512498062655};\\\", \\\"{x:397,y:534,t:1512498062848};\\\", \\\"{x:397,y:533,t:1512498062863};\\\", \\\"{x:398,y:533,t:1512498062879};\\\", \\\"{x:398,y:534,t:1512498063183};\\\", \\\"{x:398,y:537,t:1512498063191};\\\", \\\"{x:398,y:539,t:1512498063206};\\\", \\\"{x:398,y:544,t:1512498063223};\\\", \\\"{x:398,y:549,t:1512498063239};\\\", \\\"{x:398,y:552,t:1512498063256};\\\", \\\"{x:399,y:555,t:1512498063273};\\\", \\\"{x:399,y:557,t:1512498063290};\\\", \\\"{x:399,y:560,t:1512498063306};\\\", \\\"{x:400,y:562,t:1512498063323};\\\", \\\"{x:400,y:565,t:1512498063340};\\\", \\\"{x:402,y:567,t:1512498063356};\\\", \\\"{x:402,y:566,t:1512498063504};\\\", \\\"{x:402,y:565,t:1512498063519};\\\", \\\"{x:402,y:564,t:1512498063527};\\\", \\\"{x:402,y:563,t:1512498063543};\\\", \\\"{x:402,y:562,t:1512498063575};\\\", \\\"{x:404,y:565,t:1512498063895};\\\", \\\"{x:406,y:574,t:1512498063908};\\\", \\\"{x:411,y:588,t:1512498063923};\\\", \\\"{x:413,y:600,t:1512498063940};\\\", \\\"{x:416,y:614,t:1512498063957};\\\", \\\"{x:416,y:623,t:1512498063974};\\\", \\\"{x:417,y:631,t:1512498063990};\\\", \\\"{x:417,y:644,t:1512498064006};\\\", \\\"{x:418,y:653,t:1512498064024};\\\", \\\"{x:422,y:663,t:1512498064040};\\\", \\\"{x:423,y:673,t:1512498064057};\\\", \\\"{x:423,y:678,t:1512498064074};\\\", \\\"{x:423,y:679,t:1512498064090};\\\", \\\"{x:425,y:682,t:1512498064107};\\\", \\\"{x:425,y:684,t:1512498064151};\\\", \\\"{x:426,y:686,t:1512498064159};\\\", \\\"{x:426,y:688,t:1512498064174};\\\", \\\"{x:426,y:690,t:1512498064191};\\\", \\\"{x:427,y:692,t:1512498064208};\\\", \\\"{x:427,y:693,t:1512498065143};\\\", \\\"{x:426,y:693,t:1512498065159};\\\", \\\"{x:425,y:693,t:1512498065183};\\\", \\\"{x:424,y:693,t:1512498065191};\\\", \\\"{x:423,y:693,t:1512498065208};\\\", \\\"{x:421,y:693,t:1512498065224};\\\", \\\"{x:420,y:693,t:1512498065241};\\\", \\\"{x:417,y:693,t:1512498065258};\\\", \\\"{x:416,y:693,t:1512498065274};\\\", \\\"{x:413,y:694,t:1512498065291};\\\", \\\"{x:411,y:694,t:1512498065308};\\\", \\\"{x:410,y:694,t:1512498065325};\\\", \\\"{x:408,y:694,t:1512498065341};\\\", \\\"{x:407,y:694,t:1512498065359};\\\", \\\"{x:405,y:694,t:1512498065383};\\\", \\\"{x:404,y:694,t:1512498065432};\\\" ] }, { \\\"rt\\\": 30470, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 531958, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-I -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:402,y:694,t:1512498067191};\\\", \\\"{x:400,y:695,t:1512498067214};\\\", \\\"{x:398,y:695,t:1512498067238};\\\", \\\"{x:397,y:695,t:1512498067246};\\\", \\\"{x:396,y:695,t:1512498067261};\\\", \\\"{x:392,y:696,t:1512498067278};\\\", \\\"{x:388,y:697,t:1512498067294};\\\", \\\"{x:385,y:697,t:1512498067311};\\\", \\\"{x:384,y:697,t:1512498067335};\\\", \\\"{x:382,y:697,t:1512498067375};\\\", \\\"{x:381,y:697,t:1512498067471};\\\", \\\"{x:380,y:697,t:1512498067512};\\\", \\\"{x:379,y:697,t:1512498067535};\\\", \\\"{x:378,y:697,t:1512498067551};\\\", \\\"{x:378,y:698,t:1512498067562};\\\", \\\"{x:377,y:698,t:1512498067591};\\\", \\\"{x:376,y:698,t:1512498067679};\\\", \\\"{x:375,y:698,t:1512498068078};\\\", \\\"{x:374,y:698,t:1512498068135};\\\", \\\"{x:373,y:699,t:1512498068147};\\\", \\\"{x:372,y:699,t:1512498068223};\\\", \\\"{x:371,y:699,t:1512498068271};\\\", \\\"{x:370,y:699,t:1512498068535};\\\", \\\"{x:369,y:699,t:1512498068548};\\\", \\\"{x:368,y:700,t:1512498068575};\\\", \\\"{x:367,y:700,t:1512498068623};\\\", \\\"{x:366,y:700,t:1512498068631};\\\", \\\"{x:365,y:700,t:1512498068671};\\\", \\\"{x:364,y:700,t:1512498068695};\\\", \\\"{x:363,y:700,t:1512498068983};\\\", \\\"{x:362,y:700,t:1512498070888};\\\", \\\"{x:361,y:700,t:1512498070904};\\\", \\\"{x:360,y:700,t:1512498070922};\\\", \\\"{x:359,y:700,t:1512498070984};\\\", \\\"{x:358,y:700,t:1512498071040};\\\", \\\"{x:357,y:700,t:1512498071113};\\\", \\\"{x:357,y:701,t:1512498071144};\\\", \\\"{x:356,y:701,t:1512498071160};\\\", \\\"{x:355,y:701,t:1512498071736};\\\", \\\"{x:355,y:702,t:1512498074832};\\\", \\\"{x:370,y:707,t:1512498074848};\\\", \\\"{x:391,y:711,t:1512498074864};\\\", \\\"{x:408,y:717,t:1512498074880};\\\", \\\"{x:431,y:722,t:1512498074897};\\\", \\\"{x:449,y:728,t:1512498074916};\\\", \\\"{x:469,y:733,t:1512498074933};\\\", \\\"{x:495,y:740,t:1512498074950};\\\", \\\"{x:523,y:747,t:1512498074966};\\\", \\\"{x:567,y:758,t:1512498074983};\\\", \\\"{x:595,y:764,t:1512498075000};\\\", \\\"{x:618,y:770,t:1512498075016};\\\", \\\"{x:636,y:772,t:1512498075033};\\\", \\\"{x:652,y:775,t:1512498075050};\\\", \\\"{x:678,y:783,t:1512498075066};\\\", \\\"{x:711,y:793,t:1512498075083};\\\", \\\"{x:744,y:798,t:1512498075100};\\\", \\\"{x:784,y:805,t:1512498075117};\\\", \\\"{x:823,y:809,t:1512498075134};\\\", \\\"{x:857,y:809,t:1512498075150};\\\", \\\"{x:889,y:811,t:1512498075167};\\\", \\\"{x:929,y:811,t:1512498075184};\\\", \\\"{x:950,y:811,t:1512498075201};\\\", \\\"{x:967,y:812,t:1512498075218};\\\", \\\"{x:981,y:812,t:1512498075233};\\\", \\\"{x:988,y:812,t:1512498075250};\\\", \\\"{x:991,y:812,t:1512498075267};\\\", \\\"{x:991,y:813,t:1512498075392};\\\", \\\"{x:991,y:814,t:1512498075408};\\\", \\\"{x:989,y:815,t:1512498075441};\\\", \\\"{x:988,y:815,t:1512498075451};\\\", \\\"{x:985,y:817,t:1512498075468};\\\", \\\"{x:981,y:817,t:1512498075485};\\\", \\\"{x:974,y:819,t:1512498075501};\\\", \\\"{x:971,y:820,t:1512498075518};\\\", \\\"{x:965,y:822,t:1512498075535};\\\", \\\"{x:963,y:822,t:1512498075551};\\\", \\\"{x:962,y:823,t:1512498075568};\\\", \\\"{x:961,y:823,t:1512498075585};\\\", \\\"{x:960,y:823,t:1512498075601};\\\", \\\"{x:959,y:823,t:1512498075624};\\\", \\\"{x:958,y:824,t:1512498075648};\\\", \\\"{x:957,y:824,t:1512498075688};\\\", \\\"{x:956,y:824,t:1512498075714};\\\", \\\"{x:955,y:824,t:1512498075727};\\\", \\\"{x:954,y:824,t:1512498075743};\\\", \\\"{x:953,y:824,t:1512498075791};\\\", \\\"{x:952,y:824,t:1512498075815};\\\", \\\"{x:951,y:824,t:1512498075831};\\\", \\\"{x:950,y:825,t:1512498075920};\\\", \\\"{x:949,y:825,t:1512498076464};\\\", \\\"{x:948,y:825,t:1512498076472};\\\", \\\"{x:947,y:825,t:1512498076504};\\\", \\\"{x:946,y:825,t:1512498076520};\\\", \\\"{x:945,y:825,t:1512498076536};\\\", \\\"{x:944,y:825,t:1512498076552};\\\", \\\"{x:943,y:825,t:1512498076569};\\\", \\\"{x:942,y:825,t:1512498076600};\\\", \\\"{x:941,y:825,t:1512498076632};\\\", \\\"{x:940,y:825,t:1512498076648};\\\", \\\"{x:939,y:825,t:1512498076680};\\\", \\\"{x:938,y:825,t:1512498076704};\\\", \\\"{x:937,y:825,t:1512498076719};\\\", \\\"{x:936,y:825,t:1512498076735};\\\", \\\"{x:934,y:825,t:1512498076752};\\\", \\\"{x:933,y:825,t:1512498076768};\\\", \\\"{x:932,y:825,t:1512498076785};\\\", \\\"{x:931,y:825,t:1512498076802};\\\", \\\"{x:930,y:825,t:1512498076831};\\\", \\\"{x:929,y:825,t:1512498077151};\\\", \\\"{x:928,y:825,t:1512498077175};\\\", \\\"{x:928,y:823,t:1512498079520};\\\", \\\"{x:929,y:822,t:1512498079528};\\\", \\\"{x:932,y:818,t:1512498079539};\\\", \\\"{x:940,y:809,t:1512498079556};\\\", \\\"{x:950,y:801,t:1512498079572};\\\", \\\"{x:961,y:790,t:1512498079589};\\\", \\\"{x:971,y:784,t:1512498079606};\\\", \\\"{x:979,y:779,t:1512498079623};\\\", \\\"{x:986,y:774,t:1512498079639};\\\", \\\"{x:994,y:766,t:1512498079658};\\\", \\\"{x:1002,y:760,t:1512498079672};\\\", \\\"{x:1005,y:755,t:1512498079688};\\\", \\\"{x:1007,y:750,t:1512498079705};\\\", \\\"{x:1009,y:748,t:1512498079722};\\\", \\\"{x:1010,y:746,t:1512498079738};\\\", \\\"{x:1012,y:744,t:1512498079759};\\\", \\\"{x:1012,y:743,t:1512498079772};\\\", \\\"{x:1013,y:738,t:1512498079788};\\\", \\\"{x:1016,y:731,t:1512498079805};\\\", \\\"{x:1018,y:725,t:1512498079822};\\\", \\\"{x:1023,y:718,t:1512498079838};\\\", \\\"{x:1028,y:706,t:1512498079855};\\\", \\\"{x:1032,y:694,t:1512498079872};\\\", \\\"{x:1037,y:681,t:1512498079888};\\\", \\\"{x:1043,y:666,t:1512498079905};\\\", \\\"{x:1049,y:654,t:1512498079922};\\\", \\\"{x:1051,y:647,t:1512498079940};\\\", \\\"{x:1053,y:642,t:1512498079955};\\\", \\\"{x:1055,y:638,t:1512498079973};\\\", \\\"{x:1055,y:636,t:1512498079989};\\\", \\\"{x:1057,y:634,t:1512498080006};\\\", \\\"{x:1057,y:633,t:1512498080023};\\\", \\\"{x:1057,y:632,t:1512498080048};\\\", \\\"{x:1057,y:631,t:1512498080063};\\\", \\\"{x:1058,y:630,t:1512498080073};\\\", \\\"{x:1059,y:630,t:1512498083896};\\\", \\\"{x:1071,y:634,t:1512498083912};\\\", \\\"{x:1077,y:637,t:1512498083927};\\\", \\\"{x:1097,y:648,t:1512498083943};\\\", \\\"{x:1113,y:657,t:1512498083961};\\\", \\\"{x:1129,y:663,t:1512498083977};\\\", \\\"{x:1145,y:671,t:1512498083994};\\\", \\\"{x:1158,y:676,t:1512498084011};\\\", \\\"{x:1171,y:681,t:1512498084027};\\\", \\\"{x:1177,y:683,t:1512498084044};\\\", \\\"{x:1179,y:685,t:1512498084061};\\\", \\\"{x:1179,y:686,t:1512498084176};\\\", \\\"{x:1178,y:687,t:1512498084191};\\\", \\\"{x:1177,y:688,t:1512498084199};\\\", \\\"{x:1176,y:688,t:1512498084215};\\\", \\\"{x:1175,y:689,t:1512498084228};\\\", \\\"{x:1171,y:689,t:1512498084244};\\\", \\\"{x:1166,y:692,t:1512498084261};\\\", \\\"{x:1162,y:693,t:1512498084278};\\\", \\\"{x:1158,y:695,t:1512498084294};\\\", \\\"{x:1155,y:697,t:1512498084312};\\\", \\\"{x:1154,y:697,t:1512498084328};\\\", \\\"{x:1153,y:698,t:1512498084343};\\\", \\\"{x:1152,y:698,t:1512498088879};\\\", \\\"{x:1151,y:701,t:1512498088928};\\\", \\\"{x:1150,y:701,t:1512498088951};\\\", \\\"{x:1149,y:702,t:1512498088966};\\\", \\\"{x:1148,y:702,t:1512498088983};\\\", \\\"{x:1147,y:702,t:1512498088999};\\\", \\\"{x:1148,y:702,t:1512498091024};\\\", \\\"{x:1150,y:701,t:1512498091064};\\\", \\\"{x:1151,y:701,t:1512498091096};\\\", \\\"{x:1152,y:701,t:1512498091104};\\\", \\\"{x:1153,y:701,t:1512498091128};\\\", \\\"{x:1154,y:700,t:1512498091216};\\\", \\\"{x:1150,y:700,t:1512498092465};\\\", \\\"{x:1144,y:700,t:1512498092472};\\\", \\\"{x:1128,y:702,t:1512498092488};\\\", \\\"{x:1107,y:702,t:1512498092504};\\\", \\\"{x:1077,y:703,t:1512498092521};\\\", \\\"{x:1043,y:705,t:1512498092538};\\\", \\\"{x:998,y:705,t:1512498092555};\\\", \\\"{x:959,y:705,t:1512498092571};\\\", \\\"{x:868,y:696,t:1512498092588};\\\", \\\"{x:819,y:688,t:1512498092605};\\\", \\\"{x:816,y:687,t:1512498093032};\\\", \\\"{x:816,y:686,t:1512498093040};\\\", \\\"{x:815,y:686,t:1512498093055};\\\", \\\"{x:744,y:691,t:1512498093072};\\\", \\\"{x:685,y:691,t:1512498093088};\\\", \\\"{x:638,y:691,t:1512498093105};\\\", \\\"{x:587,y:685,t:1512498093121};\\\", \\\"{x:551,y:675,t:1512498093138};\\\", \\\"{x:530,y:671,t:1512498093154};\\\", \\\"{x:524,y:669,t:1512498093171};\\\", \\\"{x:524,y:668,t:1512498093188};\\\", \\\"{x:523,y:667,t:1512498093204};\\\", \\\"{x:523,y:665,t:1512498093221};\\\", \\\"{x:522,y:663,t:1512498093238};\\\", \\\"{x:522,y:661,t:1512498093255};\\\", \\\"{x:522,y:656,t:1512498093271};\\\", \\\"{x:522,y:651,t:1512498093288};\\\", \\\"{x:522,y:646,t:1512498093304};\\\", \\\"{x:525,y:634,t:1512498093322};\\\", \\\"{x:528,y:623,t:1512498093338};\\\", \\\"{x:532,y:615,t:1512498093354};\\\", \\\"{x:539,y:605,t:1512498093371};\\\", \\\"{x:540,y:599,t:1512498093389};\\\", \\\"{x:543,y:593,t:1512498093405};\\\", \\\"{x:543,y:592,t:1512498093421};\\\", \\\"{x:544,y:589,t:1512498093439};\\\", \\\"{x:544,y:586,t:1512498093455};\\\", \\\"{x:544,y:584,t:1512498093471};\\\", \\\"{x:543,y:580,t:1512498093488};\\\", \\\"{x:541,y:577,t:1512498093505};\\\", \\\"{x:536,y:573,t:1512498093522};\\\", \\\"{x:529,y:567,t:1512498093539};\\\", \\\"{x:523,y:564,t:1512498093555};\\\", \\\"{x:521,y:563,t:1512498093572};\\\", \\\"{x:521,y:562,t:1512498093588};\\\", \\\"{x:520,y:561,t:1512498093605};\\\", \\\"{x:520,y:558,t:1512498093621};\\\", \\\"{x:519,y:557,t:1512498093639};\\\", \\\"{x:518,y:554,t:1512498093655};\\\", \\\"{x:518,y:552,t:1512498093687};\\\", \\\"{x:518,y:551,t:1512498093719};\\\", \\\"{x:518,y:550,t:1512498093735};\\\", \\\"{x:518,y:549,t:1512498093749};\\\", \\\"{x:518,y:548,t:1512498093767};\\\", \\\"{x:518,y:546,t:1512498093783};\\\", \\\"{x:518,y:543,t:1512498093799};\\\", \\\"{x:518,y:542,t:1512498093815};\\\", \\\"{x:518,y:540,t:1512498093832};\\\", \\\"{x:518,y:538,t:1512498093849};\\\", \\\"{x:517,y:537,t:1512498093895};\\\", \\\"{x:520,y:535,t:1512498094191};\\\", \\\"{x:522,y:535,t:1512498094199};\\\", \\\"{x:531,y:530,t:1512498094216};\\\", \\\"{x:540,y:527,t:1512498094232};\\\", \\\"{x:544,y:526,t:1512498094249};\\\", \\\"{x:549,y:524,t:1512498094266};\\\", \\\"{x:555,y:524,t:1512498094283};\\\", \\\"{x:561,y:524,t:1512498094299};\\\", \\\"{x:567,y:524,t:1512498094316};\\\", \\\"{x:575,y:524,t:1512498094333};\\\", \\\"{x:583,y:524,t:1512498094349};\\\", \\\"{x:586,y:524,t:1512498094366};\\\", \\\"{x:589,y:524,t:1512498094383};\\\", \\\"{x:591,y:524,t:1512498094399};\\\", \\\"{x:593,y:525,t:1512498094416};\\\", \\\"{x:597,y:526,t:1512498094433};\\\", \\\"{x:600,y:527,t:1512498094449};\\\", \\\"{x:604,y:528,t:1512498094466};\\\", \\\"{x:608,y:529,t:1512498094483};\\\", \\\"{x:610,y:530,t:1512498094500};\\\", \\\"{x:613,y:530,t:1512498094516};\\\", \\\"{x:616,y:530,t:1512498094533};\\\", \\\"{x:622,y:531,t:1512498094550};\\\", \\\"{x:627,y:531,t:1512498094566};\\\", \\\"{x:635,y:533,t:1512498094584};\\\", \\\"{x:636,y:533,t:1512498094599};\\\", \\\"{x:636,y:534,t:1512498094824};\\\", \\\"{x:636,y:535,t:1512498094840};\\\", \\\"{x:635,y:535,t:1512498094856};\\\", \\\"{x:634,y:535,t:1512498094872};\\\", \\\"{x:632,y:536,t:1512498094883};\\\", \\\"{x:631,y:537,t:1512498095072};\\\", \\\"{x:630,y:537,t:1512498095096};\\\", \\\"{x:629,y:537,t:1512498095120};\\\", \\\"{x:627,y:537,t:1512498095133};\\\", \\\"{x:626,y:537,t:1512498095149};\\\", \\\"{x:625,y:537,t:1512498095167};\\\", \\\"{x:623,y:540,t:1512498095511};\\\", \\\"{x:615,y:543,t:1512498095519};\\\", \\\"{x:609,y:548,t:1512498095533};\\\", \\\"{x:597,y:558,t:1512498095550};\\\", \\\"{x:578,y:577,t:1512498095567};\\\", \\\"{x:566,y:592,t:1512498095584};\\\", \\\"{x:556,y:602,t:1512498095600};\\\", \\\"{x:546,y:610,t:1512498095617};\\\", \\\"{x:539,y:617,t:1512498095633};\\\", \\\"{x:533,y:621,t:1512498095650};\\\", \\\"{x:529,y:625,t:1512498095667};\\\", \\\"{x:526,y:628,t:1512498095683};\\\", \\\"{x:523,y:632,t:1512498095700};\\\", \\\"{x:517,y:635,t:1512498095717};\\\", \\\"{x:514,y:638,t:1512498095733};\\\", \\\"{x:510,y:641,t:1512498095750};\\\", \\\"{x:503,y:646,t:1512498095767};\\\", \\\"{x:499,y:648,t:1512498095783};\\\", \\\"{x:496,y:649,t:1512498095800};\\\", \\\"{x:493,y:651,t:1512498095817};\\\", \\\"{x:491,y:652,t:1512498095834};\\\", \\\"{x:489,y:654,t:1512498095850};\\\", \\\"{x:486,y:655,t:1512498095867};\\\", \\\"{x:483,y:657,t:1512498095884};\\\", \\\"{x:480,y:658,t:1512498095900};\\\", \\\"{x:478,y:660,t:1512498095917};\\\", \\\"{x:473,y:665,t:1512498095934};\\\", \\\"{x:469,y:668,t:1512498095950};\\\", \\\"{x:463,y:675,t:1512498095967};\\\", \\\"{x:458,y:679,t:1512498095984};\\\", \\\"{x:452,y:684,t:1512498096001};\\\", \\\"{x:444,y:688,t:1512498096017};\\\", \\\"{x:441,y:690,t:1512498096034};\\\", \\\"{x:438,y:691,t:1512498096050};\\\", \\\"{x:437,y:692,t:1512498096067};\\\", \\\"{x:435,y:692,t:1512498096084};\\\", \\\"{x:434,y:693,t:1512498096100};\\\", \\\"{x:432,y:693,t:1512498096127};\\\", \\\"{x:431,y:693,t:1512498096191};\\\", \\\"{x:429,y:693,t:1512498096367};\\\", \\\"{x:429,y:693,t:1512498096455};\\\", \\\"{x:428,y:693,t:1512498096519};\\\", \\\"{x:426,y:693,t:1512498096575};\\\", \\\"{x:425,y:693,t:1512498096607};\\\", \\\"{x:424,y:693,t:1512498096623};\\\", \\\"{x:423,y:693,t:1512498096639};\\\", \\\"{x:422,y:693,t:1512498096720};\\\" ] }, { \\\"rt\\\": 97963, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 631219, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"J\\\", \\\"E\\\", \\\"G\\\", \\\"C\\\", \\\"H\\\", \\\"Z\\\", \\\"N\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-B -X -X -04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:421,y:692,t:1512498098191};\\\", \\\"{x:420,y:692,t:1512498098203};\\\", \\\"{x:419,y:692,t:1512498098247};\\\", \\\"{x:418,y:692,t:1512498098255};\\\", \\\"{x:417,y:692,t:1512498098270};\\\", \\\"{x:415,y:690,t:1512498098286};\\\", \\\"{x:413,y:689,t:1512498098303};\\\", \\\"{x:409,y:687,t:1512498098320};\\\", \\\"{x:407,y:683,t:1512498098336};\\\", \\\"{x:404,y:679,t:1512498098353};\\\", \\\"{x:401,y:676,t:1512498098370};\\\", \\\"{x:399,y:674,t:1512498098387};\\\", \\\"{x:397,y:671,t:1512498098403};\\\", \\\"{x:396,y:668,t:1512498098419};\\\", \\\"{x:395,y:667,t:1512498098436};\\\", \\\"{x:392,y:665,t:1512498098452};\\\", \\\"{x:391,y:663,t:1512498098469};\\\", \\\"{x:391,y:662,t:1512498098486};\\\", \\\"{x:390,y:661,t:1512498098502};\\\", \\\"{x:389,y:659,t:1512498098519};\\\", \\\"{x:388,y:658,t:1512498098543};\\\", \\\"{x:388,y:657,t:1512498098559};\\\", \\\"{x:387,y:657,t:1512498098569};\\\", \\\"{x:387,y:656,t:1512498098599};\\\", \\\"{x:387,y:655,t:1512498098607};\\\", \\\"{x:386,y:655,t:1512498098623};\\\", \\\"{x:386,y:654,t:1512498098647};\\\", \\\"{x:386,y:653,t:1512498098696};\\\", \\\"{x:386,y:652,t:1512498099288};\\\", \\\"{x:395,y:647,t:1512498099303};\\\", \\\"{x:432,y:637,t:1512498099321};\\\", \\\"{x:482,y:622,t:1512498099337};\\\", \\\"{x:527,y:609,t:1512498099353};\\\", \\\"{x:565,y:593,t:1512498099371};\\\", \\\"{x:597,y:578,t:1512498099387};\\\", \\\"{x:622,y:565,t:1512498099404};\\\", \\\"{x:649,y:554,t:1512498099421};\\\", \\\"{x:687,y:542,t:1512498099436};\\\", \\\"{x:724,y:529,t:1512498099453};\\\", \\\"{x:750,y:524,t:1512498099470};\\\", \\\"{x:788,y:511,t:1512498099487};\\\", \\\"{x:818,y:500,t:1512498099503};\\\", \\\"{x:836,y:493,t:1512498099520};\\\", \\\"{x:851,y:488,t:1512498099537};\\\", \\\"{x:855,y:487,t:1512498099553};\\\", \\\"{x:857,y:486,t:1512498099570};\\\", \\\"{x:857,y:485,t:1512498099587};\\\", \\\"{x:858,y:485,t:1512498099640};\\\", \\\"{x:859,y:485,t:1512498099671};\\\", \\\"{x:860,y:486,t:1512498100040};\\\", \\\"{x:863,y:486,t:1512498100054};\\\", \\\"{x:872,y:490,t:1512498100071};\\\", \\\"{x:889,y:491,t:1512498100087};\\\", \\\"{x:899,y:494,t:1512498100105};\\\", \\\"{x:920,y:496,t:1512498100121};\\\", \\\"{x:938,y:499,t:1512498100138};\\\", \\\"{x:949,y:499,t:1512498100155};\\\", \\\"{x:960,y:498,t:1512498100171};\\\", \\\"{x:970,y:494,t:1512498100188};\\\", \\\"{x:981,y:489,t:1512498100205};\\\", \\\"{x:993,y:484,t:1512498100221};\\\", \\\"{x:1005,y:479,t:1512498100238};\\\", \\\"{x:1017,y:475,t:1512498100255};\\\", \\\"{x:1028,y:472,t:1512498100271};\\\", \\\"{x:1033,y:470,t:1512498100287};\\\", \\\"{x:1035,y:469,t:1512498100305};\\\", \\\"{x:1038,y:469,t:1512498100321};\\\", \\\"{x:1041,y:469,t:1512498100338};\\\", \\\"{x:1046,y:469,t:1512498100355};\\\", \\\"{x:1052,y:470,t:1512498100371};\\\", \\\"{x:1057,y:472,t:1512498100388};\\\", \\\"{x:1064,y:477,t:1512498100405};\\\", \\\"{x:1075,y:482,t:1512498100421};\\\", \\\"{x:1081,y:485,t:1512498100438};\\\", \\\"{x:1085,y:487,t:1512498100454};\\\", \\\"{x:1087,y:488,t:1512498100470};\\\", \\\"{x:1088,y:489,t:1512498100510};\\\", \\\"{x:1091,y:490,t:1512498100526};\\\", \\\"{x:1092,y:491,t:1512498100542};\\\", \\\"{x:1093,y:491,t:1512498100554};\\\", \\\"{x:1094,y:492,t:1512498100575};\\\", \\\"{x:1097,y:492,t:1512498100817};\\\", \\\"{x:1098,y:492,t:1512498100896};\\\", \\\"{x:1099,y:492,t:1512498100905};\\\", \\\"{x:1100,y:492,t:1512498100922};\\\", \\\"{x:1101,y:492,t:1512498100939};\\\", \\\"{x:1102,y:492,t:1512498100955};\\\", \\\"{x:1103,y:492,t:1512498101168};\\\", \\\"{x:1104,y:492,t:1512498101175};\\\", \\\"{x:1105,y:492,t:1512498101189};\\\", \\\"{x:1106,y:492,t:1512498101205};\\\", \\\"{x:1109,y:493,t:1512498101222};\\\", \\\"{x:1109,y:494,t:1512498101239};\\\", \\\"{x:1111,y:495,t:1512498101255};\\\", \\\"{x:1112,y:495,t:1512498101272};\\\", \\\"{x:1113,y:495,t:1512498101289};\\\", \\\"{x:1115,y:495,t:1512498101306};\\\", \\\"{x:1116,y:495,t:1512498101322};\\\", \\\"{x:1117,y:495,t:1512498101351};\\\", \\\"{x:1118,y:496,t:1512498106076};\\\", \\\"{x:1118,y:497,t:1512498106083};\\\", \\\"{x:1117,y:499,t:1512498106096};\\\", \\\"{x:1115,y:502,t:1512498106113};\\\", \\\"{x:1114,y:503,t:1512498106129};\\\", \\\"{x:1112,y:506,t:1512498106146};\\\", \\\"{x:1111,y:507,t:1512498106163};\\\", \\\"{x:1110,y:510,t:1512498106179};\\\", \\\"{x:1108,y:512,t:1512498106196};\\\", \\\"{x:1107,y:513,t:1512498106213};\\\", \\\"{x:1105,y:517,t:1512498106245};\\\", \\\"{x:1105,y:519,t:1512498106250};\\\", \\\"{x:1105,y:520,t:1512498106263};\\\", \\\"{x:1103,y:523,t:1512498106279};\\\", \\\"{x:1103,y:525,t:1512498106296};\\\", \\\"{x:1101,y:531,t:1512498106313};\\\", \\\"{x:1100,y:535,t:1512498106329};\\\", \\\"{x:1099,y:539,t:1512498106346};\\\", \\\"{x:1098,y:542,t:1512498106362};\\\", \\\"{x:1098,y:544,t:1512498106379};\\\", \\\"{x:1098,y:547,t:1512498106396};\\\", \\\"{x:1098,y:548,t:1512498106413};\\\", \\\"{x:1098,y:551,t:1512498106429};\\\", \\\"{x:1098,y:553,t:1512498106446};\\\", \\\"{x:1098,y:554,t:1512498106463};\\\", \\\"{x:1098,y:556,t:1512498106481};\\\", \\\"{x:1098,y:558,t:1512498106496};\\\", \\\"{x:1098,y:559,t:1512498106513};\\\", \\\"{x:1098,y:560,t:1512498106530};\\\", \\\"{x:1098,y:561,t:1512498106547};\\\", \\\"{x:1098,y:563,t:1512498106564};\\\", \\\"{x:1098,y:564,t:1512498106628};\\\", \\\"{x:1099,y:564,t:1512498107563};\\\", \\\"{x:1100,y:564,t:1512498107570};\\\", \\\"{x:1102,y:563,t:1512498107580};\\\", \\\"{x:1106,y:562,t:1512498107597};\\\", \\\"{x:1109,y:562,t:1512498107614};\\\", \\\"{x:1112,y:562,t:1512498107630};\\\", \\\"{x:1114,y:562,t:1512498107647};\\\", \\\"{x:1116,y:562,t:1512498107664};\\\", \\\"{x:1119,y:562,t:1512498107681};\\\", \\\"{x:1122,y:562,t:1512498107698};\\\", \\\"{x:1129,y:562,t:1512498107715};\\\", \\\"{x:1137,y:562,t:1512498107731};\\\", \\\"{x:1145,y:562,t:1512498107747};\\\", \\\"{x:1152,y:562,t:1512498107765};\\\", \\\"{x:1158,y:562,t:1512498107782};\\\", \\\"{x:1166,y:562,t:1512498107798};\\\", \\\"{x:1173,y:563,t:1512498107815};\\\", \\\"{x:1181,y:564,t:1512498107832};\\\", \\\"{x:1185,y:565,t:1512498107848};\\\", \\\"{x:1189,y:565,t:1512498107865};\\\", \\\"{x:1192,y:566,t:1512498107881};\\\", \\\"{x:1193,y:566,t:1512498107898};\\\", \\\"{x:1195,y:566,t:1512498107915};\\\", \\\"{x:1192,y:566,t:1512498108099};\\\", \\\"{x:1182,y:566,t:1512498108115};\\\", \\\"{x:1175,y:566,t:1512498108131};\\\", \\\"{x:1171,y:566,t:1512498108148};\\\", \\\"{x:1164,y:566,t:1512498108165};\\\", \\\"{x:1161,y:566,t:1512498108182};\\\", \\\"{x:1160,y:566,t:1512498108199};\\\", \\\"{x:1159,y:566,t:1512498108219};\\\", \\\"{x:1158,y:566,t:1512498108243};\\\", \\\"{x:1158,y:567,t:1512498108267};\\\", \\\"{x:1157,y:567,t:1512498113252};\\\", \\\"{x:1156,y:567,t:1512498113269};\\\", \\\"{x:1155,y:567,t:1512498113315};\\\", \\\"{x:1154,y:568,t:1512498113323};\\\", \\\"{x:1153,y:568,t:1512498113355};\\\", \\\"{x:1152,y:568,t:1512498113379};\\\", \\\"{x:1151,y:568,t:1512498113435};\\\", \\\"{x:1151,y:567,t:1512498113851};\\\", \\\"{x:1151,y:566,t:1512498113875};\\\", \\\"{x:1151,y:565,t:1512498113886};\\\", \\\"{x:1151,y:564,t:1512498113903};\\\", \\\"{x:1152,y:563,t:1512498113923};\\\", \\\"{x:1152,y:562,t:1512498113939};\\\", \\\"{x:1152,y:561,t:1512498113953};\\\", \\\"{x:1153,y:560,t:1512498113979};\\\", \\\"{x:1153,y:559,t:1512498114011};\\\", \\\"{x:1154,y:558,t:1512498114027};\\\", \\\"{x:1155,y:558,t:1512498114067};\\\", \\\"{x:1155,y:559,t:1512498114579};\\\", \\\"{x:1155,y:560,t:1512498114635};\\\", \\\"{x:1155,y:561,t:1512498127163};\\\", \\\"{x:1155,y:565,t:1512498127171};\\\", \\\"{x:1156,y:566,t:1512498127181};\\\", \\\"{x:1160,y:577,t:1512498127197};\\\", \\\"{x:1164,y:588,t:1512498127214};\\\", \\\"{x:1169,y:598,t:1512498127231};\\\", \\\"{x:1172,y:607,t:1512498127247};\\\", \\\"{x:1175,y:615,t:1512498127264};\\\", \\\"{x:1180,y:626,t:1512498127281};\\\", \\\"{x:1183,y:639,t:1512498127297};\\\", \\\"{x:1187,y:655,t:1512498127314};\\\", \\\"{x:1188,y:667,t:1512498127331};\\\", \\\"{x:1190,y:678,t:1512498127347};\\\", \\\"{x:1192,y:688,t:1512498127364};\\\", \\\"{x:1192,y:693,t:1512498127381};\\\", \\\"{x:1192,y:697,t:1512498127397};\\\", \\\"{x:1192,y:700,t:1512498127414};\\\", \\\"{x:1192,y:702,t:1512498127431};\\\", \\\"{x:1192,y:704,t:1512498127447};\\\", \\\"{x:1190,y:706,t:1512498127464};\\\", \\\"{x:1188,y:708,t:1512498127481};\\\", \\\"{x:1186,y:710,t:1512498127498};\\\", \\\"{x:1184,y:712,t:1512498127514};\\\", \\\"{x:1182,y:716,t:1512498127531};\\\", \\\"{x:1179,y:720,t:1512498127548};\\\", \\\"{x:1174,y:726,t:1512498127564};\\\", \\\"{x:1171,y:730,t:1512498127581};\\\", \\\"{x:1168,y:734,t:1512498127598};\\\", \\\"{x:1165,y:739,t:1512498127614};\\\", \\\"{x:1163,y:743,t:1512498127631};\\\", \\\"{x:1162,y:746,t:1512498127648};\\\", \\\"{x:1160,y:748,t:1512498127665};\\\", \\\"{x:1159,y:751,t:1512498127681};\\\", \\\"{x:1159,y:752,t:1512498127698};\\\", \\\"{x:1159,y:753,t:1512498127715};\\\", \\\"{x:1159,y:754,t:1512498127859};\\\", \\\"{x:1159,y:755,t:1512498127875};\\\", \\\"{x:1159,y:756,t:1512498127883};\\\", \\\"{x:1159,y:757,t:1512498127899};\\\", \\\"{x:1159,y:758,t:1512498127942};\\\", \\\"{x:1157,y:758,t:1512498132451};\\\", \\\"{x:1152,y:758,t:1512498132460};\\\", \\\"{x:1147,y:757,t:1512498132469};\\\", \\\"{x:1137,y:753,t:1512498132486};\\\", \\\"{x:1122,y:750,t:1512498132503};\\\", \\\"{x:1108,y:746,t:1512498132519};\\\", \\\"{x:1073,y:736,t:1512498132536};\\\", \\\"{x:1018,y:716,t:1512498132553};\\\", \\\"{x:956,y:693,t:1512498132569};\\\", \\\"{x:879,y:663,t:1512498132586};\\\", \\\"{x:754,y:626,t:1512498132603};\\\", \\\"{x:688,y:599,t:1512498132618};\\\", \\\"{x:641,y:585,t:1512498132636};\\\", \\\"{x:613,y:578,t:1512498132653};\\\", \\\"{x:592,y:568,t:1512498132669};\\\", \\\"{x:579,y:561,t:1512498132686};\\\", \\\"{x:569,y:557,t:1512498132703};\\\", \\\"{x:560,y:552,t:1512498132718};\\\", \\\"{x:553,y:548,t:1512498132736};\\\", \\\"{x:547,y:543,t:1512498132753};\\\", \\\"{x:539,y:537,t:1512498132769};\\\", \\\"{x:526,y:527,t:1512498132786};\\\", \\\"{x:502,y:512,t:1512498132803};\\\", \\\"{x:490,y:505,t:1512498132818};\\\", \\\"{x:485,y:503,t:1512498132836};\\\", \\\"{x:478,y:502,t:1512498132853};\\\", \\\"{x:474,y:501,t:1512498132870};\\\", \\\"{x:471,y:501,t:1512498132886};\\\", \\\"{x:468,y:501,t:1512498132903};\\\", \\\"{x:465,y:501,t:1512498132920};\\\", \\\"{x:464,y:501,t:1512498132938};\\\", \\\"{x:462,y:501,t:1512498132953};\\\", \\\"{x:456,y:505,t:1512498132970};\\\", \\\"{x:452,y:508,t:1512498132986};\\\", \\\"{x:444,y:512,t:1512498133002};\\\", \\\"{x:439,y:515,t:1512498133020};\\\", \\\"{x:438,y:517,t:1512498133035};\\\", \\\"{x:435,y:519,t:1512498133053};\\\", \\\"{x:434,y:519,t:1512498133069};\\\", \\\"{x:433,y:520,t:1512498133086};\\\", \\\"{x:431,y:521,t:1512498133130};\\\", \\\"{x:431,y:522,t:1512498133146};\\\", \\\"{x:430,y:522,t:1512498133162};\\\", \\\"{x:429,y:522,t:1512498133178};\\\", \\\"{x:428,y:523,t:1512498133186};\\\", \\\"{x:425,y:523,t:1512498133202};\\\", \\\"{x:421,y:525,t:1512498133220};\\\", \\\"{x:417,y:526,t:1512498133236};\\\", \\\"{x:413,y:527,t:1512498133253};\\\", \\\"{x:408,y:528,t:1512498133270};\\\", \\\"{x:404,y:528,t:1512498133286};\\\", \\\"{x:401,y:528,t:1512498133302};\\\", \\\"{x:400,y:528,t:1512498133314};\\\", \\\"{x:399,y:528,t:1512498133331};\\\", \\\"{x:398,y:528,t:1512498133730};\\\", \\\"{x:396,y:529,t:1512498133738};\\\", \\\"{x:393,y:530,t:1512498133751};\\\", \\\"{x:386,y:531,t:1512498133768};\\\", \\\"{x:377,y:533,t:1512498133785};\\\", \\\"{x:361,y:534,t:1512498133801};\\\", \\\"{x:339,y:534,t:1512498133818};\\\", \\\"{x:325,y:534,t:1512498133835};\\\", \\\"{x:316,y:534,t:1512498133851};\\\", \\\"{x:307,y:534,t:1512498133868};\\\", \\\"{x:301,y:534,t:1512498133885};\\\", \\\"{x:300,y:534,t:1512498133902};\\\", \\\"{x:298,y:534,t:1512498133987};\\\", \\\"{x:297,y:534,t:1512498134018};\\\", \\\"{x:295,y:534,t:1512498134058};\\\", \\\"{x:294,y:534,t:1512498134090};\\\", \\\"{x:292,y:535,t:1512498134402};\\\", \\\"{x:289,y:536,t:1512498134419};\\\", \\\"{x:283,y:536,t:1512498134435};\\\", \\\"{x:274,y:536,t:1512498134452};\\\", \\\"{x:260,y:536,t:1512498134469};\\\", \\\"{x:245,y:536,t:1512498134485};\\\", \\\"{x:230,y:536,t:1512498134502};\\\", \\\"{x:213,y:534,t:1512498134519};\\\", \\\"{x:193,y:531,t:1512498134535};\\\", \\\"{x:178,y:530,t:1512498134552};\\\", \\\"{x:163,y:527,t:1512498134569};\\\", \\\"{x:156,y:526,t:1512498134586};\\\", \\\"{x:155,y:526,t:1512498134602};\\\", \\\"{x:155,y:525,t:1512498134619};\\\", \\\"{x:157,y:525,t:1512498134747};\\\", \\\"{x:158,y:525,t:1512498134754};\\\", \\\"{x:161,y:525,t:1512498134770};\\\", \\\"{x:166,y:525,t:1512498134786};\\\", \\\"{x:169,y:525,t:1512498134802};\\\", \\\"{x:170,y:526,t:1512498134820};\\\", \\\"{x:172,y:527,t:1512498134836};\\\", \\\"{x:172,y:528,t:1512498134853};\\\", \\\"{x:174,y:530,t:1512498134870};\\\", \\\"{x:175,y:530,t:1512498134887};\\\", \\\"{x:176,y:531,t:1512498134904};\\\", \\\"{x:178,y:531,t:1512498134920};\\\", \\\"{x:179,y:531,t:1512498134937};\\\", \\\"{x:180,y:531,t:1512498135011};\\\", \\\"{x:181,y:531,t:1512498135019};\\\", \\\"{x:183,y:531,t:1512498135036};\\\", \\\"{x:185,y:531,t:1512498135053};\\\", \\\"{x:186,y:531,t:1512498135069};\\\", \\\"{x:188,y:531,t:1512498135515};\\\", \\\"{x:192,y:531,t:1512498135522};\\\", \\\"{x:195,y:531,t:1512498135537};\\\", \\\"{x:205,y:530,t:1512498135554};\\\", \\\"{x:225,y:523,t:1512498135570};\\\", \\\"{x:240,y:519,t:1512498135587};\\\", \\\"{x:255,y:518,t:1512498135604};\\\", \\\"{x:272,y:516,t:1512498135621};\\\", \\\"{x:286,y:512,t:1512498135636};\\\", \\\"{x:302,y:508,t:1512498135654};\\\", \\\"{x:316,y:503,t:1512498135671};\\\", \\\"{x:329,y:500,t:1512498135687};\\\", \\\"{x:338,y:498,t:1512498135704};\\\", \\\"{x:342,y:498,t:1512498135721};\\\", \\\"{x:344,y:498,t:1512498135737};\\\", \\\"{x:347,y:498,t:1512498135754};\\\", \\\"{x:356,y:497,t:1512498135770};\\\", \\\"{x:370,y:497,t:1512498135787};\\\", \\\"{x:389,y:497,t:1512498135804};\\\", \\\"{x:412,y:497,t:1512498135820};\\\", \\\"{x:434,y:497,t:1512498135838};\\\", \\\"{x:450,y:497,t:1512498135854};\\\", \\\"{x:470,y:497,t:1512498135871};\\\", \\\"{x:492,y:497,t:1512498135888};\\\", \\\"{x:515,y:497,t:1512498135903};\\\", \\\"{x:537,y:497,t:1512498135921};\\\", \\\"{x:557,y:497,t:1512498135938};\\\", \\\"{x:575,y:497,t:1512498135954};\\\", \\\"{x:589,y:497,t:1512498135970};\\\", \\\"{x:592,y:497,t:1512498135988};\\\", \\\"{x:593,y:497,t:1512498136004};\\\", \\\"{x:594,y:497,t:1512498136034};\\\", \\\"{x:595,y:497,t:1512498136042};\\\", \\\"{x:597,y:497,t:1512498136055};\\\", \\\"{x:598,y:497,t:1512498136070};\\\", \\\"{x:601,y:497,t:1512498136088};\\\", \\\"{x:602,y:497,t:1512498136459};\\\", \\\"{x:604,y:497,t:1512498136471};\\\", \\\"{x:613,y:499,t:1512498136488};\\\", \\\"{x:626,y:503,t:1512498136505};\\\", \\\"{x:645,y:509,t:1512498136522};\\\", \\\"{x:668,y:517,t:1512498136538};\\\", \\\"{x:703,y:533,t:1512498136555};\\\", \\\"{x:734,y:546,t:1512498136571};\\\", \\\"{x:761,y:563,t:1512498136588};\\\", \\\"{x:785,y:580,t:1512498136604};\\\", \\\"{x:808,y:597,t:1512498136622};\\\", \\\"{x:828,y:611,t:1512498136638};\\\", \\\"{x:853,y:625,t:1512498136656};\\\", \\\"{x:877,y:639,t:1512498136672};\\\", \\\"{x:907,y:658,t:1512498136689};\\\", \\\"{x:940,y:678,t:1512498136705};\\\", \\\"{x:977,y:707,t:1512498136722};\\\", \\\"{x:1043,y:756,t:1512498136738};\\\", \\\"{x:1089,y:782,t:1512498136755};\\\", \\\"{x:1135,y:807,t:1512498136772};\\\", \\\"{x:1182,y:827,t:1512498136789};\\\", \\\"{x:1232,y:850,t:1512498136805};\\\", \\\"{x:1282,y:864,t:1512498136822};\\\", \\\"{x:1311,y:872,t:1512498136839};\\\", \\\"{x:1331,y:878,t:1512498136855};\\\", \\\"{x:1341,y:880,t:1512498136872};\\\", \\\"{x:1344,y:880,t:1512498136889};\\\", \\\"{x:1345,y:880,t:1512498136987};\\\", \\\"{x:1345,y:879,t:1512498137003};\\\", \\\"{x:1346,y:875,t:1512498137010};\\\", \\\"{x:1346,y:872,t:1512498137022};\\\", \\\"{x:1346,y:867,t:1512498137039};\\\", \\\"{x:1346,y:864,t:1512498137056};\\\", \\\"{x:1346,y:860,t:1512498137072};\\\", \\\"{x:1346,y:856,t:1512498137089};\\\", \\\"{x:1346,y:850,t:1512498137106};\\\", \\\"{x:1346,y:846,t:1512498137122};\\\", \\\"{x:1344,y:830,t:1512498137138};\\\", \\\"{x:1344,y:823,t:1512498137156};\\\", \\\"{x:1344,y:810,t:1512498137172};\\\", \\\"{x:1344,y:800,t:1512498137189};\\\", \\\"{x:1345,y:794,t:1512498137206};\\\", \\\"{x:1346,y:791,t:1512498137222};\\\", \\\"{x:1347,y:787,t:1512498137239};\\\", \\\"{x:1348,y:784,t:1512498137256};\\\", \\\"{x:1348,y:781,t:1512498137273};\\\", \\\"{x:1349,y:777,t:1512498137289};\\\", \\\"{x:1351,y:774,t:1512498137306};\\\", \\\"{x:1351,y:772,t:1512498137323};\\\", \\\"{x:1351,y:771,t:1512498137610};\\\", \\\"{x:1350,y:771,t:1512498137634};\\\", \\\"{x:1348,y:771,t:1512498137642};\\\", \\\"{x:1347,y:772,t:1512498137658};\\\", \\\"{x:1346,y:772,t:1512498137672};\\\", \\\"{x:1344,y:772,t:1512498137689};\\\", \\\"{x:1341,y:773,t:1512498137705};\\\", \\\"{x:1336,y:777,t:1512498137722};\\\", \\\"{x:1331,y:779,t:1512498137740};\\\", \\\"{x:1329,y:781,t:1512498137756};\\\", \\\"{x:1327,y:783,t:1512498137772};\\\", \\\"{x:1325,y:784,t:1512498137794};\\\", \\\"{x:1325,y:785,t:1512498137818};\\\", \\\"{x:1324,y:786,t:1512498137826};\\\", \\\"{x:1323,y:787,t:1512498137858};\\\", \\\"{x:1322,y:787,t:1512498137873};\\\", \\\"{x:1320,y:789,t:1512498137890};\\\", \\\"{x:1319,y:791,t:1512498137906};\\\", \\\"{x:1317,y:793,t:1512498137923};\\\", \\\"{x:1316,y:795,t:1512498137940};\\\", \\\"{x:1313,y:798,t:1512498137957};\\\", \\\"{x:1313,y:799,t:1512498137973};\\\", \\\"{x:1313,y:800,t:1512498137989};\\\", \\\"{x:1312,y:802,t:1512498138007};\\\", \\\"{x:1311,y:802,t:1512498138023};\\\", \\\"{x:1311,y:803,t:1512498138042};\\\", \\\"{x:1310,y:803,t:1512498138082};\\\", \\\"{x:1310,y:804,t:1512498138203};\\\", \\\"{x:1309,y:804,t:1512498138210};\\\", \\\"{x:1308,y:804,t:1512498138226};\\\", \\\"{x:1307,y:805,t:1512498138250};\\\", \\\"{x:1306,y:806,t:1512498138282};\\\", \\\"{x:1305,y:807,t:1512498138298};\\\", \\\"{x:1304,y:808,t:1512498138330};\\\", \\\"{x:1303,y:808,t:1512498138355};\\\", \\\"{x:1303,y:809,t:1512498138386};\\\", \\\"{x:1303,y:810,t:1512498138394};\\\", \\\"{x:1302,y:811,t:1512498138410};\\\", \\\"{x:1301,y:811,t:1512498138426};\\\", \\\"{x:1300,y:813,t:1512498138466};\\\", \\\"{x:1299,y:814,t:1512498138490};\\\", \\\"{x:1296,y:817,t:1512498143324};\\\", \\\"{x:1294,y:818,t:1512498143331};\\\", \\\"{x:1289,y:820,t:1512498143347};\\\", \\\"{x:1288,y:820,t:1512498143363};\\\", \\\"{x:1287,y:820,t:1512498143379};\\\", \\\"{x:1285,y:820,t:1512498143443};\\\", \\\"{x:1284,y:820,t:1512498143860};\\\", \\\"{x:1281,y:820,t:1512498143867};\\\", \\\"{x:1278,y:820,t:1512498143880};\\\", \\\"{x:1271,y:815,t:1512498143897};\\\", \\\"{x:1266,y:811,t:1512498143913};\\\", \\\"{x:1255,y:806,t:1512498143930};\\\", \\\"{x:1253,y:805,t:1512498143947};\\\", \\\"{x:1248,y:803,t:1512498143963};\\\", \\\"{x:1245,y:801,t:1512498143980};\\\", \\\"{x:1242,y:800,t:1512498143997};\\\", \\\"{x:1239,y:798,t:1512498144013};\\\", \\\"{x:1230,y:795,t:1512498144030};\\\", \\\"{x:1219,y:792,t:1512498144047};\\\", \\\"{x:1214,y:791,t:1512498144063};\\\", \\\"{x:1213,y:791,t:1512498144081};\\\", \\\"{x:1210,y:789,t:1512498144097};\\\", \\\"{x:1208,y:789,t:1512498144113};\\\", \\\"{x:1207,y:789,t:1512498144131};\\\", \\\"{x:1206,y:788,t:1512498144147};\\\", \\\"{x:1205,y:788,t:1512498144179};\\\", \\\"{x:1204,y:787,t:1512498144195};\\\", \\\"{x:1203,y:786,t:1512498144227};\\\", \\\"{x:1203,y:785,t:1512498144275};\\\", \\\"{x:1203,y:784,t:1512498144428};\\\", \\\"{x:1203,y:783,t:1512498144443};\\\", \\\"{x:1203,y:782,t:1512498144467};\\\", \\\"{x:1204,y:782,t:1512498144482};\\\", \\\"{x:1206,y:781,t:1512498144498};\\\", \\\"{x:1209,y:780,t:1512498144515};\\\", \\\"{x:1210,y:779,t:1512498144531};\\\", \\\"{x:1212,y:778,t:1512498144548};\\\", \\\"{x:1213,y:778,t:1512498144565};\\\", \\\"{x:1215,y:778,t:1512498144582};\\\", \\\"{x:1217,y:776,t:1512498144598};\\\", \\\"{x:1218,y:776,t:1512498144615};\\\", \\\"{x:1219,y:775,t:1512498144632};\\\", \\\"{x:1221,y:774,t:1512498144648};\\\", \\\"{x:1222,y:773,t:1512498144691};\\\", \\\"{x:1224,y:772,t:1512498144707};\\\", \\\"{x:1225,y:772,t:1512498144732};\\\", \\\"{x:1226,y:771,t:1512498144748};\\\", \\\"{x:1228,y:770,t:1512498144765};\\\", \\\"{x:1229,y:769,t:1512498144782};\\\", \\\"{x:1230,y:768,t:1512498144811};\\\", \\\"{x:1232,y:768,t:1512498144835};\\\", \\\"{x:1232,y:767,t:1512498144851};\\\", \\\"{x:1233,y:766,t:1512498144867};\\\", \\\"{x:1234,y:766,t:1512498145187};\\\", \\\"{x:1235,y:766,t:1512498145467};\\\", \\\"{x:1236,y:767,t:1512498145483};\\\", \\\"{x:1237,y:769,t:1512498145499};\\\", \\\"{x:1237,y:771,t:1512498145515};\\\", \\\"{x:1238,y:773,t:1512498145533};\\\", \\\"{x:1241,y:778,t:1512498145549};\\\", \\\"{x:1241,y:781,t:1512498145566};\\\", \\\"{x:1243,y:785,t:1512498145583};\\\", \\\"{x:1245,y:788,t:1512498145599};\\\", \\\"{x:1247,y:794,t:1512498145616};\\\", \\\"{x:1250,y:800,t:1512498145633};\\\", \\\"{x:1253,y:807,t:1512498145649};\\\", \\\"{x:1256,y:812,t:1512498145666};\\\", \\\"{x:1258,y:817,t:1512498145683};\\\", \\\"{x:1259,y:820,t:1512498145699};\\\", \\\"{x:1259,y:821,t:1512498145716};\\\", \\\"{x:1261,y:823,t:1512498145733};\\\", \\\"{x:1263,y:826,t:1512498145750};\\\", \\\"{x:1265,y:828,t:1512498145766};\\\", \\\"{x:1266,y:829,t:1512498145783};\\\", \\\"{x:1267,y:830,t:1512498145800};\\\", \\\"{x:1268,y:830,t:1512498145882};\\\", \\\"{x:1270,y:830,t:1512498145899};\\\", \\\"{x:1272,y:830,t:1512498145915};\\\", \\\"{x:1275,y:830,t:1512498145932};\\\", \\\"{x:1279,y:830,t:1512498145949};\\\", \\\"{x:1280,y:830,t:1512498145966};\\\", \\\"{x:1283,y:830,t:1512498145982};\\\", \\\"{x:1286,y:830,t:1512498145999};\\\", \\\"{x:1288,y:830,t:1512498146016};\\\", \\\"{x:1289,y:830,t:1512498146032};\\\", \\\"{x:1291,y:830,t:1512498146049};\\\", \\\"{x:1292,y:830,t:1512498146066};\\\", \\\"{x:1293,y:830,t:1512498147730};\\\", \\\"{x:1295,y:830,t:1512498147738};\\\", \\\"{x:1297,y:830,t:1512498147751};\\\", \\\"{x:1302,y:830,t:1512498147767};\\\", \\\"{x:1307,y:832,t:1512498147784};\\\", \\\"{x:1313,y:833,t:1512498147802};\\\", \\\"{x:1324,y:837,t:1512498147818};\\\", \\\"{x:1329,y:837,t:1512498147834};\\\", \\\"{x:1334,y:840,t:1512498147851};\\\", \\\"{x:1344,y:843,t:1512498147868};\\\", \\\"{x:1360,y:848,t:1512498147884};\\\", \\\"{x:1376,y:853,t:1512498147901};\\\", \\\"{x:1384,y:857,t:1512498147918};\\\", \\\"{x:1388,y:860,t:1512498147935};\\\", \\\"{x:1391,y:861,t:1512498147951};\\\", \\\"{x:1391,y:862,t:1512498147968};\\\", \\\"{x:1392,y:866,t:1512498147984};\\\", \\\"{x:1396,y:872,t:1512498148001};\\\", \\\"{x:1403,y:893,t:1512498148018};\\\", \\\"{x:1410,y:908,t:1512498148035};\\\", \\\"{x:1416,y:921,t:1512498148052};\\\", \\\"{x:1420,y:932,t:1512498148069};\\\", \\\"{x:1421,y:939,t:1512498148086};\\\", \\\"{x:1424,y:947,t:1512498148102};\\\", \\\"{x:1426,y:956,t:1512498148119};\\\", \\\"{x:1429,y:965,t:1512498148136};\\\", \\\"{x:1429,y:972,t:1512498148152};\\\", \\\"{x:1429,y:975,t:1512498148169};\\\", \\\"{x:1430,y:979,t:1512498148186};\\\", \\\"{x:1430,y:981,t:1512498148202};\\\", \\\"{x:1430,y:979,t:1512498148475};\\\", \\\"{x:1430,y:978,t:1512498148499};\\\", \\\"{x:1430,y:976,t:1512498148539};\\\", \\\"{x:1430,y:975,t:1512498148603};\\\", \\\"{x:1430,y:974,t:1512498148627};\\\", \\\"{x:1430,y:972,t:1512498148651};\\\", \\\"{x:1430,y:970,t:1512498148675};\\\", \\\"{x:1430,y:969,t:1512498148699};\\\", \\\"{x:1430,y:967,t:1512498148715};\\\", \\\"{x:1430,y:966,t:1512498148771};\\\", \\\"{x:1429,y:965,t:1512498148915};\\\", \\\"{x:1428,y:964,t:1512498148939};\\\", \\\"{x:1427,y:964,t:1512498148953};\\\", \\\"{x:1426,y:964,t:1512498148972};\\\", \\\"{x:1423,y:964,t:1512498148985};\\\", \\\"{x:1420,y:964,t:1512498149002};\\\", \\\"{x:1416,y:964,t:1512498149019};\\\", \\\"{x:1414,y:964,t:1512498149036};\\\", \\\"{x:1411,y:964,t:1512498149052};\\\", \\\"{x:1410,y:964,t:1512498149069};\\\", \\\"{x:1410,y:963,t:1512498149235};\\\", \\\"{x:1411,y:963,t:1512498149371};\\\", \\\"{x:1412,y:963,t:1512498149387};\\\", \\\"{x:1414,y:962,t:1512498149403};\\\", \\\"{x:1415,y:962,t:1512498149426};\\\", \\\"{x:1416,y:962,t:1512498149483};\\\", \\\"{x:1418,y:962,t:1512498149506};\\\", \\\"{x:1419,y:962,t:1512498149634};\\\", \\\"{x:1421,y:962,t:1512498149642};\\\", \\\"{x:1422,y:962,t:1512498149658};\\\", \\\"{x:1422,y:960,t:1512498182686};\\\", \\\"{x:1398,y:945,t:1512498182695};\\\", \\\"{x:1306,y:893,t:1512498182711};\\\", \\\"{x:1166,y:813,t:1512498182728};\\\", \\\"{x:998,y:709,t:1512498182745};\\\", \\\"{x:799,y:609,t:1512498182761};\\\", \\\"{x:590,y:527,t:1512498182778};\\\", \\\"{x:407,y:460,t:1512498182795};\\\", \\\"{x:257,y:416,t:1512498182811};\\\", \\\"{x:128,y:389,t:1512498182827};\\\", \\\"{x:0,y:344,t:1512498182845};\\\", \\\"{x:0,y:319,t:1512498182860};\\\", \\\"{x:0,y:305,t:1512498182878};\\\", \\\"{x:0,y:301,t:1512498182894};\\\", \\\"{x:0,y:297,t:1512498182910};\\\", \\\"{x:0,y:294,t:1512498182928};\\\", \\\"{x:0,y:290,t:1512498182944};\\\", \\\"{x:0,y:289,t:1512498182962};\\\", \\\"{x:5,y:290,t:1512498183013};\\\", \\\"{x:12,y:303,t:1512498183028};\\\", \\\"{x:64,y:388,t:1512498183045};\\\", \\\"{x:96,y:434,t:1512498183061};\\\", \\\"{x:126,y:460,t:1512498183078};\\\", \\\"{x:164,y:480,t:1512498183095};\\\", \\\"{x:201,y:500,t:1512498183112};\\\", \\\"{x:248,y:519,t:1512498183128};\\\", \\\"{x:303,y:542,t:1512498183145};\\\", \\\"{x:367,y:561,t:1512498183162};\\\", \\\"{x:407,y:574,t:1512498183178};\\\", \\\"{x:424,y:577,t:1512498183195};\\\", \\\"{x:431,y:577,t:1512498183212};\\\", \\\"{x:433,y:577,t:1512498183228};\\\", \\\"{x:435,y:575,t:1512498183245};\\\", \\\"{x:435,y:571,t:1512498183262};\\\", \\\"{x:437,y:567,t:1512498183278};\\\", \\\"{x:440,y:562,t:1512498183295};\\\", \\\"{x:443,y:558,t:1512498183312};\\\", \\\"{x:447,y:554,t:1512498183329};\\\", \\\"{x:448,y:551,t:1512498183344};\\\", \\\"{x:452,y:547,t:1512498183362};\\\", \\\"{x:454,y:544,t:1512498183379};\\\", \\\"{x:455,y:544,t:1512498183395};\\\", \\\"{x:454,y:544,t:1512498183461};\\\", \\\"{x:451,y:545,t:1512498183479};\\\", \\\"{x:448,y:549,t:1512498183494};\\\", \\\"{x:446,y:552,t:1512498183511};\\\", \\\"{x:446,y:555,t:1512498183528};\\\", \\\"{x:442,y:557,t:1512498183544};\\\", \\\"{x:436,y:560,t:1512498183561};\\\", \\\"{x:432,y:562,t:1512498183578};\\\", \\\"{x:430,y:563,t:1512498183595};\\\", \\\"{x:429,y:564,t:1512498183611};\\\", \\\"{x:428,y:564,t:1512498183677};\\\", \\\"{x:427,y:562,t:1512498183692};\\\", \\\"{x:425,y:561,t:1512498183700};\\\", \\\"{x:425,y:560,t:1512498183711};\\\", \\\"{x:425,y:559,t:1512498183729};\\\", \\\"{x:424,y:558,t:1512498183745};\\\", \\\"{x:424,y:557,t:1512498183762};\\\", \\\"{x:423,y:556,t:1512498183778};\\\", \\\"{x:422,y:554,t:1512498183795};\\\", \\\"{x:422,y:553,t:1512498183821};\\\", \\\"{x:422,y:552,t:1512498183885};\\\", \\\"{x:422,y:551,t:1512498183901};\\\", \\\"{x:421,y:551,t:1512498183917};\\\", \\\"{x:421,y:550,t:1512498183997};\\\", \\\"{x:420,y:550,t:1512498184013};\\\", \\\"{x:419,y:550,t:1512498184157};\\\", \\\"{x:417,y:551,t:1512498184181};\\\", \\\"{x:416,y:551,t:1512498184205};\\\", \\\"{x:416,y:552,t:1512498184221};\\\", \\\"{x:416,y:553,t:1512498184229};\\\", \\\"{x:415,y:554,t:1512498184246};\\\", \\\"{x:414,y:556,t:1512498184263};\\\", \\\"{x:412,y:556,t:1512498184279};\\\", \\\"{x:412,y:557,t:1512498184296};\\\", \\\"{x:411,y:557,t:1512498184313};\\\", \\\"{x:410,y:557,t:1512498184341};\\\", \\\"{x:409,y:558,t:1512498184349};\\\", \\\"{x:408,y:559,t:1512498184362};\\\", \\\"{x:407,y:560,t:1512498184379};\\\", \\\"{x:406,y:561,t:1512498184391};\\\", \\\"{x:404,y:563,t:1512498184407};\\\", \\\"{x:403,y:564,t:1512498184424};\\\", \\\"{x:402,y:564,t:1512498184452};\\\", \\\"{x:401,y:564,t:1512498184540};\\\", \\\"{x:401,y:563,t:1512498184693};\\\", \\\"{x:401,y:562,t:1512498184725};\\\", \\\"{x:400,y:561,t:1512498185573};\\\", \\\"{x:397,y:561,t:1512498185581};\\\", \\\"{x:389,y:561,t:1512498185598};\\\", \\\"{x:384,y:561,t:1512498185614};\\\", \\\"{x:381,y:561,t:1512498185630};\\\", \\\"{x:379,y:561,t:1512498185647};\\\", \\\"{x:378,y:562,t:1512498185805};\\\", \\\"{x:378,y:563,t:1512498185820};\\\", \\\"{x:378,y:564,t:1512498185844};\\\", \\\"{x:379,y:564,t:1512498185868};\\\", \\\"{x:381,y:565,t:1512498185880};\\\", \\\"{x:384,y:567,t:1512498185898};\\\", \\\"{x:386,y:569,t:1512498185915};\\\", \\\"{x:389,y:571,t:1512498185931};\\\", \\\"{x:395,y:574,t:1512498185948};\\\", \\\"{x:403,y:580,t:1512498185965};\\\", \\\"{x:406,y:584,t:1512498185981};\\\", \\\"{x:409,y:585,t:1512498185997};\\\", \\\"{x:411,y:587,t:1512498186014};\\\", \\\"{x:413,y:588,t:1512498186030};\\\", \\\"{x:414,y:588,t:1512498186100};\\\", \\\"{x:415,y:588,t:1512498186114};\\\", \\\"{x:416,y:588,t:1512498186132};\\\", \\\"{x:417,y:588,t:1512498186147};\\\", \\\"{x:420,y:588,t:1512498186164};\\\", \\\"{x:421,y:588,t:1512498186181};\\\", \\\"{x:426,y:586,t:1512498186197};\\\", \\\"{x:433,y:585,t:1512498186214};\\\", \\\"{x:447,y:584,t:1512498186231};\\\", \\\"{x:460,y:582,t:1512498186247};\\\", \\\"{x:471,y:580,t:1512498186264};\\\", \\\"{x:484,y:577,t:1512498186281};\\\", \\\"{x:492,y:575,t:1512498186297};\\\", \\\"{x:495,y:574,t:1512498186314};\\\", \\\"{x:496,y:574,t:1512498186365};\\\", \\\"{x:497,y:574,t:1512498186469};\\\", \\\"{x:498,y:572,t:1512498186485};\\\", \\\"{x:498,y:570,t:1512498186508};\\\", \\\"{x:499,y:570,t:1512498186516};\\\", \\\"{x:499,y:569,t:1512498186532};\\\", \\\"{x:500,y:568,t:1512498186597};\\\", \\\"{x:501,y:567,t:1512498186604};\\\", \\\"{x:503,y:566,t:1512498186628};\\\", \\\"{x:505,y:565,t:1512498186644};\\\", \\\"{x:506,y:563,t:1512498186669};\\\", \\\"{x:507,y:563,t:1512498186691};\\\", \\\"{x:507,y:562,t:1512498186716};\\\", \\\"{x:508,y:562,t:1512498186732};\\\", \\\"{x:509,y:562,t:1512498186748};\\\", \\\"{x:510,y:561,t:1512498186852};\\\", \\\"{x:510,y:560,t:1512498186864};\\\", \\\"{x:511,y:560,t:1512498186881};\\\", \\\"{x:514,y:560,t:1512498187188};\\\", \\\"{x:516,y:560,t:1512498187198};\\\", \\\"{x:521,y:562,t:1512498187215};\\\", \\\"{x:529,y:565,t:1512498187231};\\\", \\\"{x:543,y:566,t:1512498187248};\\\", \\\"{x:559,y:571,t:1512498187265};\\\", \\\"{x:571,y:572,t:1512498187283};\\\", \\\"{x:583,y:573,t:1512498187298};\\\", \\\"{x:588,y:574,t:1512498187315};\\\", \\\"{x:592,y:575,t:1512498187332};\\\", \\\"{x:593,y:575,t:1512498187389};\\\", \\\"{x:594,y:575,t:1512498187398};\\\", \\\"{x:595,y:575,t:1512498187415};\\\", \\\"{x:597,y:576,t:1512498187433};\\\", \\\"{x:599,y:577,t:1512498187448};\\\", \\\"{x:600,y:577,t:1512498187465};\\\", \\\"{x:601,y:577,t:1512498187484};\\\", \\\"{x:601,y:578,t:1512498187516};\\\", \\\"{x:604,y:580,t:1512498187532};\\\", \\\"{x:607,y:582,t:1512498187549};\\\", \\\"{x:611,y:585,t:1512498187566};\\\", \\\"{x:615,y:586,t:1512498187582};\\\", \\\"{x:617,y:588,t:1512498187600};\\\", \\\"{x:618,y:588,t:1512498187627};\\\", \\\"{x:619,y:588,t:1512498187652};\\\", \\\"{x:620,y:588,t:1512498187665};\\\", \\\"{x:621,y:588,t:1512498187682};\\\", \\\"{x:620,y:588,t:1512498189373};\\\", \\\"{x:618,y:588,t:1512498189383};\\\", \\\"{x:615,y:588,t:1512498189401};\\\", \\\"{x:612,y:588,t:1512498189417};\\\", \\\"{x:610,y:587,t:1512498189433};\\\", \\\"{x:606,y:586,t:1512498189450};\\\", \\\"{x:603,y:586,t:1512498189467};\\\", \\\"{x:594,y:584,t:1512498189484};\\\", \\\"{x:590,y:584,t:1512498189500};\\\", \\\"{x:586,y:583,t:1512498189517};\\\", \\\"{x:580,y:583,t:1512498189533};\\\", \\\"{x:572,y:583,t:1512498189551};\\\", \\\"{x:564,y:583,t:1512498189568};\\\", \\\"{x:558,y:583,t:1512498189584};\\\", \\\"{x:554,y:583,t:1512498189600};\\\", \\\"{x:549,y:583,t:1512498189618};\\\", \\\"{x:541,y:583,t:1512498189633};\\\", \\\"{x:526,y:581,t:1512498189650};\\\", \\\"{x:512,y:581,t:1512498189667};\\\", \\\"{x:486,y:581,t:1512498189684};\\\", \\\"{x:472,y:581,t:1512498189700};\\\", \\\"{x:463,y:581,t:1512498189717};\\\", \\\"{x:452,y:584,t:1512498189734};\\\", \\\"{x:444,y:586,t:1512498189750};\\\", \\\"{x:439,y:588,t:1512498189767};\\\", \\\"{x:437,y:589,t:1512498189784};\\\", \\\"{x:436,y:589,t:1512498189820};\\\", \\\"{x:434,y:589,t:1512498189836};\\\", \\\"{x:433,y:589,t:1512498189850};\\\", \\\"{x:430,y:590,t:1512498189868};\\\", \\\"{x:421,y:593,t:1512498189884};\\\", \\\"{x:409,y:597,t:1512498189900};\\\", \\\"{x:399,y:599,t:1512498189918};\\\", \\\"{x:384,y:603,t:1512498189935};\\\", \\\"{x:368,y:608,t:1512498189951};\\\", \\\"{x:354,y:611,t:1512498189967};\\\", \\\"{x:342,y:612,t:1512498189984};\\\", \\\"{x:329,y:613,t:1512498190000};\\\", \\\"{x:317,y:613,t:1512498190017};\\\", \\\"{x:308,y:613,t:1512498190034};\\\", \\\"{x:299,y:613,t:1512498190050};\\\", \\\"{x:289,y:613,t:1512498190067};\\\", \\\"{x:277,y:613,t:1512498190083};\\\", \\\"{x:272,y:613,t:1512498190100};\\\", \\\"{x:267,y:613,t:1512498190117};\\\", \\\"{x:260,y:613,t:1512498190134};\\\", \\\"{x:255,y:613,t:1512498190150};\\\", \\\"{x:248,y:613,t:1512498190167};\\\", \\\"{x:242,y:612,t:1512498190184};\\\", \\\"{x:240,y:612,t:1512498190200};\\\", \\\"{x:239,y:611,t:1512498190217};\\\", \\\"{x:237,y:611,t:1512498190234};\\\", \\\"{x:234,y:611,t:1512498190250};\\\", \\\"{x:231,y:611,t:1512498190267};\\\", \\\"{x:225,y:611,t:1512498190283};\\\", \\\"{x:222,y:611,t:1512498190300};\\\", \\\"{x:220,y:611,t:1512498190317};\\\", \\\"{x:217,y:611,t:1512498190334};\\\", \\\"{x:215,y:612,t:1512498190356};\\\", \\\"{x:214,y:612,t:1512498190380};\\\", \\\"{x:212,y:612,t:1512498190412};\\\", \\\"{x:211,y:612,t:1512498190436};\\\", \\\"{x:209,y:612,t:1512498190460};\\\", \\\"{x:208,y:612,t:1512498190476};\\\", \\\"{x:205,y:612,t:1512498190485};\\\", \\\"{x:202,y:612,t:1512498190502};\\\", \\\"{x:198,y:612,t:1512498190517};\\\", \\\"{x:194,y:613,t:1512498190534};\\\", \\\"{x:190,y:614,t:1512498190551};\\\", \\\"{x:188,y:614,t:1512498190567};\\\", \\\"{x:186,y:615,t:1512498190661};\\\", \\\"{x:186,y:616,t:1512498190676};\\\", \\\"{x:185,y:616,t:1512498190692};\\\", \\\"{x:184,y:617,t:1512498190716};\\\", \\\"{x:185,y:617,t:1512498192301};\\\", \\\"{x:192,y:615,t:1512498192309};\\\", \\\"{x:199,y:614,t:1512498192320};\\\", \\\"{x:223,y:613,t:1512498192337};\\\", \\\"{x:253,y:612,t:1512498192354};\\\", \\\"{x:278,y:610,t:1512498192370};\\\", \\\"{x:297,y:608,t:1512498192387};\\\", \\\"{x:310,y:607,t:1512498192403};\\\", \\\"{x:321,y:605,t:1512498192420};\\\", \\\"{x:323,y:605,t:1512498192437};\\\", \\\"{x:322,y:605,t:1512498192581};\\\", \\\"{x:320,y:605,t:1512498192589};\\\", \\\"{x:320,y:606,t:1512498192603};\\\", \\\"{x:316,y:607,t:1512498192620};\\\", \\\"{x:311,y:609,t:1512498192637};\\\", \\\"{x:309,y:611,t:1512498192653};\\\", \\\"{x:305,y:612,t:1512498192670};\\\", \\\"{x:304,y:612,t:1512498192687};\\\", \\\"{x:302,y:613,t:1512498192703};\\\", \\\"{x:301,y:614,t:1512498192845};\\\", \\\"{x:299,y:615,t:1512498192894};\\\", \\\"{x:298,y:615,t:1512498192925};\\\", \\\"{x:297,y:615,t:1512498192955};\\\", \\\"{x:296,y:615,t:1512498192971};\\\", \\\"{x:295,y:615,t:1512498192987};\\\", \\\"{x:294,y:615,t:1512498193004};\\\", \\\"{x:297,y:615,t:1512498193317};\\\", \\\"{x:300,y:614,t:1512498193325};\\\", \\\"{x:305,y:612,t:1512498193337};\\\", \\\"{x:313,y:608,t:1512498193354};\\\", \\\"{x:324,y:607,t:1512498193371};\\\", \\\"{x:337,y:607,t:1512498193387};\\\", \\\"{x:347,y:606,t:1512498193404};\\\", \\\"{x:358,y:606,t:1512498193421};\\\", \\\"{x:368,y:606,t:1512498193437};\\\", \\\"{x:376,y:606,t:1512498193454};\\\", \\\"{x:379,y:606,t:1512498193471};\\\", \\\"{x:381,y:606,t:1512498193487};\\\", \\\"{x:382,y:606,t:1512498193525};\\\", \\\"{x:383,y:606,t:1512498193557};\\\", \\\"{x:384,y:606,t:1512498193589};\\\", \\\"{x:386,y:606,t:1512498193605};\\\", \\\"{x:387,y:606,t:1512498193629};\\\", \\\"{x:388,y:606,t:1512498193638};\\\", \\\"{x:390,y:607,t:1512498193654};\\\", \\\"{x:397,y:611,t:1512498193672};\\\", \\\"{x:401,y:613,t:1512498193688};\\\", \\\"{x:406,y:614,t:1512498193704};\\\", \\\"{x:408,y:614,t:1512498193721};\\\", \\\"{x:409,y:614,t:1512498193737};\\\", \\\"{x:410,y:614,t:1512498193754};\\\", \\\"{x:411,y:616,t:1512498194213};\\\", \\\"{x:412,y:618,t:1512498194221};\\\", \\\"{x:412,y:619,t:1512498194238};\\\", \\\"{x:413,y:620,t:1512498194254};\\\", \\\"{x:412,y:618,t:1512498194349};\\\", \\\"{x:410,y:616,t:1512498194357};\\\", \\\"{x:409,y:614,t:1512498194372};\\\", \\\"{x:404,y:611,t:1512498194388};\\\", \\\"{x:401,y:611,t:1512498194404};\\\", \\\"{x:400,y:611,t:1512498194421};\\\", \\\"{x:398,y:611,t:1512498194438};\\\", \\\"{x:396,y:611,t:1512498194455};\\\", \\\"{x:396,y:612,t:1512498194637};\\\", \\\"{x:396,y:614,t:1512498194653};\\\", \\\"{x:398,y:615,t:1512498194661};\\\", \\\"{x:398,y:616,t:1512498194672};\\\", \\\"{x:399,y:616,t:1512498194688};\\\", \\\"{x:401,y:617,t:1512498194705};\\\", \\\"{x:404,y:620,t:1512498195149};\\\", \\\"{x:406,y:624,t:1512498195157};\\\", \\\"{x:411,y:633,t:1512498195172};\\\", \\\"{x:414,y:641,t:1512498195188};\\\", \\\"{x:417,y:647,t:1512498195205};\\\", \\\"{x:419,y:650,t:1512498195222};\\\", \\\"{x:419,y:652,t:1512498195239};\\\", \\\"{x:419,y:653,t:1512498195255};\\\", \\\"{x:420,y:654,t:1512498195316};\\\", \\\"{x:421,y:655,t:1512498195332};\\\", \\\"{x:421,y:656,t:1512498195356};\\\", \\\"{x:421,y:658,t:1512498195372};\\\", \\\"{x:421,y:662,t:1512498195388};\\\", \\\"{x:421,y:665,t:1512498195405};\\\", \\\"{x:422,y:669,t:1512498195422};\\\", \\\"{x:422,y:671,t:1512498195439};\\\", \\\"{x:423,y:674,t:1512498195456};\\\", \\\"{x:425,y:680,t:1512498195473};\\\", \\\"{x:425,y:681,t:1512498195489};\\\", \\\"{x:426,y:682,t:1512498195505};\\\", \\\"{x:427,y:682,t:1512498196485};\\\", \\\"{x:433,y:682,t:1512498196493};\\\", \\\"{x:449,y:679,t:1512498196507};\\\", \\\"{x:505,y:671,t:1512498196524};\\\", \\\"{x:558,y:662,t:1512498196541};\\\" ] }, { \\\"rt\\\": 20605, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 653435, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -J -J -11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:558,y:661,t:1512498197319};\\\", \\\"{x:557,y:661,t:1512498198181};\\\", \\\"{x:556,y:661,t:1512498198191};\\\", \\\"{x:555,y:661,t:1512498198208};\\\", \\\"{x:554,y:661,t:1512498198245};\\\", \\\"{x:552,y:661,t:1512498198413};\\\", \\\"{x:551,y:661,t:1512498200397};\\\", \\\"{x:550,y:661,t:1512498200437};\\\", \\\"{x:549,y:661,t:1512498202645};\\\", \\\"{x:548,y:661,t:1512498202789};\\\", \\\"{x:547,y:661,t:1512498202796};\\\", \\\"{x:546,y:661,t:1512498204213};\\\", \\\"{x:547,y:660,t:1512498204229};\\\", \\\"{x:549,y:659,t:1512498204246};\\\", \\\"{x:554,y:657,t:1512498204262};\\\", \\\"{x:562,y:654,t:1512498204279};\\\", \\\"{x:570,y:651,t:1512498204295};\\\", \\\"{x:579,y:647,t:1512498204313};\\\", \\\"{x:594,y:644,t:1512498204328};\\\", \\\"{x:604,y:640,t:1512498204346};\\\", \\\"{x:619,y:634,t:1512498204363};\\\", \\\"{x:634,y:628,t:1512498204379};\\\", \\\"{x:652,y:621,t:1512498204395};\\\", \\\"{x:692,y:607,t:1512498204412};\\\", \\\"{x:732,y:594,t:1512498204429};\\\", \\\"{x:779,y:583,t:1512498204445};\\\", \\\"{x:835,y:575,t:1512498204463};\\\", \\\"{x:894,y:571,t:1512498204480};\\\", \\\"{x:953,y:571,t:1512498204496};\\\", \\\"{x:1001,y:571,t:1512498204513};\\\", \\\"{x:1056,y:571,t:1512498204530};\\\", \\\"{x:1103,y:575,t:1512498204546};\\\", \\\"{x:1145,y:582,t:1512498204563};\\\", \\\"{x:1196,y:598,t:1512498204580};\\\", \\\"{x:1243,y:617,t:1512498204596};\\\", \\\"{x:1275,y:633,t:1512498204613};\\\", \\\"{x:1289,y:642,t:1512498204630};\\\", \\\"{x:1293,y:650,t:1512498204646};\\\", \\\"{x:1298,y:661,t:1512498204663};\\\", \\\"{x:1303,y:671,t:1512498204680};\\\", \\\"{x:1307,y:682,t:1512498204696};\\\", \\\"{x:1307,y:688,t:1512498204713};\\\", \\\"{x:1306,y:694,t:1512498204730};\\\", \\\"{x:1304,y:697,t:1512498204746};\\\", \\\"{x:1300,y:700,t:1512498204763};\\\", \\\"{x:1294,y:701,t:1512498204780};\\\", \\\"{x:1290,y:701,t:1512498204796};\\\", \\\"{x:1283,y:701,t:1512498204812};\\\", \\\"{x:1277,y:701,t:1512498204830};\\\", \\\"{x:1271,y:701,t:1512498204846};\\\", \\\"{x:1264,y:701,t:1512498204863};\\\", \\\"{x:1254,y:701,t:1512498204880};\\\", \\\"{x:1240,y:701,t:1512498204896};\\\", \\\"{x:1228,y:701,t:1512498204913};\\\", \\\"{x:1215,y:701,t:1512498204930};\\\", \\\"{x:1203,y:701,t:1512498204947};\\\", \\\"{x:1189,y:701,t:1512498204963};\\\", \\\"{x:1177,y:699,t:1512498204980};\\\", \\\"{x:1163,y:695,t:1512498204996};\\\", \\\"{x:1156,y:693,t:1512498205015};\\\", \\\"{x:1152,y:692,t:1512498205029};\\\", \\\"{x:1149,y:692,t:1512498205046};\\\", \\\"{x:1148,y:691,t:1512498205062};\\\", \\\"{x:1149,y:691,t:1512498205261};\\\", \\\"{x:1152,y:691,t:1512498205268};\\\", \\\"{x:1156,y:693,t:1512498205280};\\\", \\\"{x:1159,y:697,t:1512498205296};\\\", \\\"{x:1161,y:699,t:1512498205313};\\\", \\\"{x:1164,y:702,t:1512498205331};\\\", \\\"{x:1169,y:706,t:1512498205347};\\\", \\\"{x:1176,y:710,t:1512498205363};\\\", \\\"{x:1180,y:711,t:1512498205380};\\\", \\\"{x:1181,y:712,t:1512498205397};\\\", \\\"{x:1183,y:714,t:1512498205445};\\\", \\\"{x:1184,y:715,t:1512498205453};\\\", \\\"{x:1186,y:718,t:1512498205464};\\\", \\\"{x:1189,y:725,t:1512498205480};\\\", \\\"{x:1192,y:732,t:1512498205497};\\\", \\\"{x:1192,y:734,t:1512498205514};\\\", \\\"{x:1192,y:737,t:1512498205530};\\\", \\\"{x:1192,y:740,t:1512498205547};\\\", \\\"{x:1192,y:741,t:1512498205564};\\\", \\\"{x:1192,y:742,t:1512498205580};\\\", \\\"{x:1191,y:744,t:1512498205597};\\\", \\\"{x:1191,y:746,t:1512498205614};\\\", \\\"{x:1191,y:749,t:1512498205630};\\\", \\\"{x:1190,y:753,t:1512498205647};\\\", \\\"{x:1187,y:757,t:1512498205664};\\\", \\\"{x:1183,y:762,t:1512498205680};\\\", \\\"{x:1179,y:765,t:1512498205697};\\\", \\\"{x:1174,y:769,t:1512498205714};\\\", \\\"{x:1172,y:771,t:1512498205730};\\\", \\\"{x:1169,y:773,t:1512498205747};\\\", \\\"{x:1168,y:773,t:1512498205789};\\\", \\\"{x:1167,y:773,t:1512498205804};\\\", \\\"{x:1166,y:773,t:1512498205821};\\\", \\\"{x:1165,y:773,t:1512498205837};\\\", \\\"{x:1163,y:773,t:1512498205853};\\\", \\\"{x:1162,y:773,t:1512498205868};\\\", \\\"{x:1160,y:773,t:1512498205880};\\\", \\\"{x:1158,y:773,t:1512498205896};\\\", \\\"{x:1153,y:776,t:1512498205913};\\\", \\\"{x:1149,y:777,t:1512498205930};\\\", \\\"{x:1144,y:780,t:1512498205946};\\\", \\\"{x:1139,y:780,t:1512498205963};\\\", \\\"{x:1127,y:781,t:1512498205979};\\\", \\\"{x:1120,y:782,t:1512498205996};\\\", \\\"{x:1112,y:784,t:1512498206013};\\\", \\\"{x:1103,y:786,t:1512498206030};\\\", \\\"{x:1093,y:791,t:1512498206046};\\\", \\\"{x:1076,y:797,t:1512498206063};\\\", \\\"{x:1059,y:802,t:1512498206080};\\\", \\\"{x:1043,y:806,t:1512498206096};\\\", \\\"{x:1027,y:812,t:1512498206113};\\\", \\\"{x:1017,y:814,t:1512498206130};\\\", \\\"{x:1011,y:816,t:1512498206146};\\\", \\\"{x:1010,y:816,t:1512498206163};\\\", \\\"{x:1010,y:817,t:1512498206301};\\\", \\\"{x:1010,y:819,t:1512498206316};\\\", \\\"{x:1011,y:819,t:1512498206332};\\\", \\\"{x:1012,y:819,t:1512498206347};\\\", \\\"{x:1013,y:819,t:1512498206364};\\\", \\\"{x:1016,y:819,t:1512498206380};\\\", \\\"{x:1018,y:819,t:1512498206398};\\\", \\\"{x:1019,y:819,t:1512498206413};\\\", \\\"{x:1020,y:820,t:1512498206430};\\\", \\\"{x:1021,y:821,t:1512498206448};\\\", \\\"{x:1021,y:822,t:1512498206468};\\\", \\\"{x:1021,y:823,t:1512498206480};\\\", \\\"{x:1021,y:825,t:1512498206498};\\\", \\\"{x:1022,y:827,t:1512498206513};\\\", \\\"{x:1023,y:829,t:1512498206531};\\\", \\\"{x:1023,y:830,t:1512498211677};\\\", \\\"{x:1022,y:831,t:1512498211685};\\\", \\\"{x:1020,y:834,t:1512498211701};\\\", \\\"{x:1017,y:838,t:1512498211720};\\\", \\\"{x:1012,y:846,t:1512498211736};\\\", \\\"{x:1005,y:857,t:1512498211752};\\\", \\\"{x:994,y:875,t:1512498211769};\\\", \\\"{x:990,y:893,t:1512498211786};\\\", \\\"{x:985,y:910,t:1512498211802};\\\", \\\"{x:981,y:920,t:1512498211819};\\\", \\\"{x:978,y:927,t:1512498211836};\\\", \\\"{x:978,y:931,t:1512498211852};\\\", \\\"{x:976,y:933,t:1512498211869};\\\", \\\"{x:976,y:936,t:1512498211885};\\\", \\\"{x:981,y:940,t:1512498211902};\\\", \\\"{x:989,y:943,t:1512498211919};\\\", \\\"{x:995,y:945,t:1512498211936};\\\", \\\"{x:1002,y:948,t:1512498211952};\\\", \\\"{x:1008,y:949,t:1512498211969};\\\", \\\"{x:1013,y:950,t:1512498211986};\\\", \\\"{x:1016,y:951,t:1512498212002};\\\", \\\"{x:1021,y:952,t:1512498212019};\\\", \\\"{x:1024,y:953,t:1512498212036};\\\", \\\"{x:1024,y:954,t:1512498212052};\\\", \\\"{x:1024,y:956,t:1512498212069};\\\", \\\"{x:1024,y:957,t:1512498212093};\\\", \\\"{x:1024,y:958,t:1512498212117};\\\", \\\"{x:1023,y:958,t:1512498212166};\\\", \\\"{x:1022,y:959,t:1512498212173};\\\", \\\"{x:1021,y:959,t:1512498212186};\\\", \\\"{x:1020,y:959,t:1512498212203};\\\", \\\"{x:1017,y:961,t:1512498212219};\\\", \\\"{x:1013,y:962,t:1512498212236};\\\", \\\"{x:1010,y:963,t:1512498212252};\\\", \\\"{x:1006,y:966,t:1512498212269};\\\", \\\"{x:1004,y:966,t:1512498212286};\\\", \\\"{x:1003,y:966,t:1512498212374};\\\", \\\"{x:1002,y:966,t:1512498212389};\\\", \\\"{x:1001,y:966,t:1512498212403};\\\", \\\"{x:1000,y:968,t:1512498212419};\\\", \\\"{x:999,y:968,t:1512498212436};\\\", \\\"{x:998,y:969,t:1512498212452};\\\", \\\"{x:997,y:970,t:1512498212661};\\\", \\\"{x:997,y:971,t:1512498212669};\\\", \\\"{x:999,y:971,t:1512498212765};\\\", \\\"{x:1000,y:971,t:1512498212773};\\\", \\\"{x:1003,y:971,t:1512498212789};\\\", \\\"{x:1004,y:971,t:1512498212803};\\\", \\\"{x:1006,y:972,t:1512498212820};\\\", \\\"{x:1008,y:972,t:1512498212836};\\\", \\\"{x:1012,y:975,t:1512498212853};\\\", \\\"{x:1014,y:975,t:1512498212869};\\\", \\\"{x:1015,y:975,t:1512498212886};\\\", \\\"{x:1017,y:975,t:1512498212903};\\\", \\\"{x:1019,y:975,t:1512498212920};\\\", \\\"{x:1022,y:975,t:1512498212936};\\\", \\\"{x:1026,y:975,t:1512498212953};\\\", \\\"{x:1027,y:975,t:1512498212969};\\\", \\\"{x:1030,y:975,t:1512498212985};\\\", \\\"{x:1033,y:975,t:1512498213002};\\\", \\\"{x:1034,y:975,t:1512498213019};\\\", \\\"{x:1036,y:975,t:1512498213035};\\\", \\\"{x:1037,y:975,t:1512498213052};\\\", \\\"{x:1038,y:975,t:1512498213068};\\\", \\\"{x:1040,y:975,t:1512498213100};\\\", \\\"{x:1041,y:975,t:1512498213117};\\\", \\\"{x:1042,y:975,t:1512498213124};\\\", \\\"{x:1043,y:975,t:1512498213136};\\\", \\\"{x:1044,y:974,t:1512498213152};\\\", \\\"{x:1045,y:974,t:1512498213285};\\\", \\\"{x:1046,y:974,t:1512498213325};\\\", \\\"{x:1047,y:974,t:1512498213381};\\\", \\\"{x:1048,y:974,t:1512498213397};\\\", \\\"{x:1049,y:974,t:1512498213429};\\\", \\\"{x:1050,y:974,t:1512498213445};\\\", \\\"{x:1052,y:974,t:1512498213461};\\\", \\\"{x:1052,y:975,t:1512498213469};\\\", \\\"{x:1060,y:975,t:1512498213487};\\\", \\\"{x:1067,y:978,t:1512498213503};\\\", \\\"{x:1077,y:979,t:1512498213520};\\\", \\\"{x:1089,y:979,t:1512498213537};\\\", \\\"{x:1098,y:979,t:1512498213553};\\\", \\\"{x:1108,y:980,t:1512498213570};\\\", \\\"{x:1115,y:981,t:1512498213587};\\\", \\\"{x:1122,y:983,t:1512498213603};\\\", \\\"{x:1127,y:985,t:1512498213620};\\\", \\\"{x:1131,y:987,t:1512498213637};\\\", \\\"{x:1133,y:987,t:1512498213653};\\\", \\\"{x:1134,y:987,t:1512498213670};\\\", \\\"{x:1135,y:987,t:1512498213693};\\\", \\\"{x:1136,y:986,t:1512498213717};\\\", \\\"{x:1138,y:985,t:1512498213966};\\\", \\\"{x:1140,y:985,t:1512498214005};\\\", \\\"{x:1141,y:985,t:1512498214020};\\\", \\\"{x:1142,y:985,t:1512498214037};\\\", \\\"{x:1144,y:985,t:1512498214053};\\\", \\\"{x:1145,y:984,t:1512498214070};\\\", \\\"{x:1146,y:983,t:1512498214101};\\\", \\\"{x:1148,y:982,t:1512498214109};\\\", \\\"{x:1150,y:982,t:1512498214125};\\\", \\\"{x:1152,y:982,t:1512498214137};\\\", \\\"{x:1155,y:980,t:1512498214154};\\\", \\\"{x:1156,y:980,t:1512498214173};\\\", \\\"{x:1157,y:980,t:1512498214187};\\\", \\\"{x:1160,y:980,t:1512498214204};\\\", \\\"{x:1161,y:980,t:1512498214221};\\\", \\\"{x:1165,y:980,t:1512498214237};\\\", \\\"{x:1166,y:980,t:1512498214253};\\\", \\\"{x:1167,y:980,t:1512498214271};\\\", \\\"{x:1168,y:979,t:1512498214287};\\\", \\\"{x:1171,y:978,t:1512498214304};\\\", \\\"{x:1173,y:978,t:1512498214321};\\\", \\\"{x:1175,y:978,t:1512498214337};\\\", \\\"{x:1175,y:977,t:1512498214354};\\\", \\\"{x:1176,y:977,t:1512498214389};\\\", \\\"{x:1177,y:976,t:1512498214405};\\\", \\\"{x:1178,y:976,t:1512498214421};\\\", \\\"{x:1181,y:976,t:1512498214437};\\\", \\\"{x:1182,y:976,t:1512498214453};\\\", \\\"{x:1183,y:975,t:1512498214471};\\\", \\\"{x:1184,y:975,t:1512498214487};\\\", \\\"{x:1185,y:974,t:1512498214504};\\\", \\\"{x:1184,y:974,t:1512498215189};\\\", \\\"{x:1183,y:973,t:1512498215204};\\\", \\\"{x:1180,y:973,t:1512498215221};\\\", \\\"{x:1178,y:973,t:1512498215237};\\\", \\\"{x:1176,y:973,t:1512498215255};\\\", \\\"{x:1174,y:972,t:1512498215271};\\\", \\\"{x:1169,y:970,t:1512498215288};\\\", \\\"{x:1165,y:968,t:1512498215305};\\\", \\\"{x:1160,y:965,t:1512498215321};\\\", \\\"{x:1152,y:961,t:1512498215338};\\\", \\\"{x:1140,y:956,t:1512498215355};\\\", \\\"{x:1123,y:950,t:1512498215371};\\\", \\\"{x:1076,y:929,t:1512498215388};\\\", \\\"{x:1017,y:905,t:1512498215405};\\\", \\\"{x:991,y:893,t:1512498215421};\\\", \\\"{x:976,y:884,t:1512498215438};\\\", \\\"{x:968,y:873,t:1512498215455};\\\", \\\"{x:964,y:863,t:1512498215471};\\\", \\\"{x:964,y:855,t:1512498215488};\\\", \\\"{x:965,y:846,t:1512498215505};\\\", \\\"{x:968,y:837,t:1512498215521};\\\", \\\"{x:969,y:831,t:1512498215538};\\\", \\\"{x:970,y:826,t:1512498215555};\\\", \\\"{x:974,y:821,t:1512498215572};\\\", \\\"{x:978,y:818,t:1512498215588};\\\", \\\"{x:982,y:816,t:1512498215605};\\\", \\\"{x:984,y:815,t:1512498215622};\\\", \\\"{x:984,y:814,t:1512498215638};\\\", \\\"{x:984,y:813,t:1512498215655};\\\", \\\"{x:984,y:811,t:1512498215672};\\\", \\\"{x:984,y:808,t:1512498215688};\\\", \\\"{x:984,y:803,t:1512498215705};\\\", \\\"{x:982,y:793,t:1512498215722};\\\", \\\"{x:970,y:775,t:1512498215738};\\\", \\\"{x:934,y:732,t:1512498215755};\\\", \\\"{x:878,y:692,t:1512498215772};\\\", \\\"{x:815,y:656,t:1512498215788};\\\", \\\"{x:710,y:603,t:1512498215805};\\\", \\\"{x:658,y:572,t:1512498215821};\\\", \\\"{x:619,y:547,t:1512498215838};\\\", \\\"{x:603,y:534,t:1512498215854};\\\", \\\"{x:592,y:524,t:1512498215872};\\\", \\\"{x:589,y:519,t:1512498215888};\\\", \\\"{x:587,y:517,t:1512498215904};\\\", \\\"{x:586,y:516,t:1512498215921};\\\", \\\"{x:582,y:514,t:1512498215938};\\\", \\\"{x:581,y:514,t:1512498215954};\\\", \\\"{x:578,y:514,t:1512498215972};\\\", \\\"{x:575,y:519,t:1512498215988};\\\", \\\"{x:575,y:531,t:1512498216005};\\\", \\\"{x:571,y:539,t:1512498216021};\\\", \\\"{x:566,y:547,t:1512498216039};\\\", \\\"{x:562,y:553,t:1512498216055};\\\", \\\"{x:553,y:558,t:1512498216071};\\\", \\\"{x:532,y:562,t:1512498216089};\\\", \\\"{x:502,y:563,t:1512498216104};\\\", \\\"{x:473,y:563,t:1512498216121};\\\", \\\"{x:439,y:563,t:1512498216139};\\\", \\\"{x:368,y:548,t:1512498216154};\\\", \\\"{x:286,y:529,t:1512498216172};\\\", \\\"{x:215,y:510,t:1512498216189};\\\", \\\"{x:201,y:504,t:1512498216205};\\\", \\\"{x:193,y:503,t:1512498216221};\\\", \\\"{x:190,y:503,t:1512498216239};\\\", \\\"{x:190,y:504,t:1512498216261};\\\", \\\"{x:191,y:504,t:1512498216277};\\\", \\\"{x:192,y:504,t:1512498216288};\\\", \\\"{x:197,y:504,t:1512498216304};\\\", \\\"{x:202,y:504,t:1512498216321};\\\", \\\"{x:209,y:508,t:1512498216339};\\\", \\\"{x:218,y:512,t:1512498216354};\\\", \\\"{x:234,y:519,t:1512498216372};\\\", \\\"{x:246,y:523,t:1512498216389};\\\", \\\"{x:247,y:525,t:1512498216405};\\\", \\\"{x:247,y:526,t:1512498216437};\\\", \\\"{x:247,y:527,t:1512498216453};\\\", \\\"{x:245,y:528,t:1512498216469};\\\", \\\"{x:244,y:529,t:1512498216477};\\\", \\\"{x:243,y:529,t:1512498216489};\\\", \\\"{x:239,y:529,t:1512498216505};\\\", \\\"{x:237,y:529,t:1512498216522};\\\", \\\"{x:224,y:530,t:1512498216538};\\\", \\\"{x:212,y:533,t:1512498216556};\\\", \\\"{x:202,y:534,t:1512498216572};\\\", \\\"{x:194,y:535,t:1512498216589};\\\", \\\"{x:187,y:535,t:1512498216605};\\\", \\\"{x:180,y:537,t:1512498216621};\\\", \\\"{x:179,y:537,t:1512498216638};\\\", \\\"{x:182,y:537,t:1512498216740};\\\", \\\"{x:186,y:537,t:1512498216758};\\\", \\\"{x:187,y:537,t:1512498216773};\\\", \\\"{x:192,y:539,t:1512498217300};\\\", \\\"{x:199,y:545,t:1512498217308};\\\", \\\"{x:217,y:566,t:1512498217324};\\\", \\\"{x:257,y:606,t:1512498217340};\\\", \\\"{x:299,y:644,t:1512498217357};\\\", \\\"{x:338,y:691,t:1512498217374};\\\", \\\"{x:375,y:725,t:1512498217390};\\\", \\\"{x:397,y:738,t:1512498217407};\\\", \\\"{x:415,y:746,t:1512498217424};\\\", \\\"{x:422,y:749,t:1512498217440};\\\", \\\"{x:424,y:749,t:1512498217457};\\\", \\\"{x:425,y:749,t:1512498217549};\\\", \\\"{x:426,y:749,t:1512498217565};\\\", \\\"{x:426,y:746,t:1512498217589};\\\", \\\"{x:426,y:742,t:1512498217597};\\\", \\\"{x:426,y:740,t:1512498217607};\\\", \\\"{x:423,y:731,t:1512498217624};\\\", \\\"{x:419,y:722,t:1512498217640};\\\", \\\"{x:416,y:715,t:1512498217657};\\\", \\\"{x:415,y:711,t:1512498217674};\\\", \\\"{x:413,y:704,t:1512498217691};\\\", \\\"{x:412,y:703,t:1512498217707};\\\", \\\"{x:411,y:701,t:1512498217723};\\\" ] }, { \\\"rt\\\": 22895, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 677630, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O -01 PM-02 PM-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:411,y:699,t:1512498224744};\\\", \\\"{x:411,y:694,t:1512498224755};\\\", \\\"{x:417,y:683,t:1512498224771};\\\", \\\"{x:421,y:676,t:1512498224789};\\\", \\\"{x:429,y:663,t:1512498224806};\\\", \\\"{x:435,y:653,t:1512498224822};\\\", \\\"{x:442,y:645,t:1512498224838};\\\", \\\"{x:449,y:636,t:1512498224849};\\\", \\\"{x:459,y:626,t:1512498224866};\\\", \\\"{x:467,y:618,t:1512498224882};\\\", \\\"{x:474,y:612,t:1512498224899};\\\", \\\"{x:481,y:605,t:1512498224916};\\\", \\\"{x:485,y:600,t:1512498224932};\\\", \\\"{x:488,y:594,t:1512498224949};\\\", \\\"{x:492,y:588,t:1512498224966};\\\", \\\"{x:497,y:579,t:1512498224982};\\\", \\\"{x:500,y:575,t:1512498224999};\\\", \\\"{x:500,y:573,t:1512498225016};\\\", \\\"{x:500,y:572,t:1512498225033};\\\", \\\"{x:500,y:570,t:1512498225071};\\\", \\\"{x:500,y:569,t:1512498225087};\\\", \\\"{x:501,y:567,t:1512498225103};\\\", \\\"{x:501,y:566,t:1512498225116};\\\", \\\"{x:503,y:560,t:1512498225133};\\\", \\\"{x:504,y:555,t:1512498225149};\\\", \\\"{x:506,y:550,t:1512498225166};\\\", \\\"{x:507,y:544,t:1512498225183};\\\", \\\"{x:508,y:540,t:1512498225200};\\\", \\\"{x:509,y:539,t:1512498225217};\\\", \\\"{x:509,y:537,t:1512498225233};\\\", \\\"{x:510,y:537,t:1512498225249};\\\", \\\"{x:511,y:536,t:1512498225266};\\\", \\\"{x:512,y:536,t:1512498225294};\\\", \\\"{x:512,y:535,t:1512498225310};\\\", \\\"{x:513,y:534,t:1512498225318};\\\", \\\"{x:514,y:534,t:1512498225334};\\\", \\\"{x:515,y:533,t:1512498225351};\\\", \\\"{x:516,y:533,t:1512498225374};\\\", \\\"{x:517,y:532,t:1512498225391};\\\", \\\"{x:516,y:532,t:1512498226072};\\\", \\\"{x:516,y:533,t:1512498226111};\\\", \\\"{x:515,y:534,t:1512498226240};\\\", \\\"{x:514,y:534,t:1512498226888};\\\", \\\"{x:513,y:534,t:1512498226944};\\\", \\\"{x:513,y:535,t:1512498227937};\\\", \\\"{x:538,y:547,t:1512498227953};\\\", \\\"{x:613,y:583,t:1512498227969};\\\", \\\"{x:743,y:644,t:1512498227986};\\\", \\\"{x:890,y:715,t:1512498228003};\\\", \\\"{x:1041,y:779,t:1512498228019};\\\", \\\"{x:1184,y:837,t:1512498228036};\\\", \\\"{x:1299,y:879,t:1512498228053};\\\", \\\"{x:1392,y:900,t:1512498228069};\\\", \\\"{x:1445,y:908,t:1512498228086};\\\", \\\"{x:1485,y:908,t:1512498228103};\\\", \\\"{x:1488,y:908,t:1512498228119};\\\", \\\"{x:1490,y:907,t:1512498228136};\\\", \\\"{x:1490,y:906,t:1512498228153};\\\", \\\"{x:1482,y:893,t:1512498228169};\\\", \\\"{x:1462,y:878,t:1512498228186};\\\", \\\"{x:1446,y:863,t:1512498228204};\\\", \\\"{x:1432,y:848,t:1512498228220};\\\", \\\"{x:1408,y:822,t:1512498228237};\\\", \\\"{x:1383,y:803,t:1512498228254};\\\", \\\"{x:1365,y:790,t:1512498228270};\\\", \\\"{x:1351,y:780,t:1512498228287};\\\", \\\"{x:1338,y:770,t:1512498228303};\\\", \\\"{x:1326,y:761,t:1512498228322};\\\", \\\"{x:1318,y:752,t:1512498228336};\\\", \\\"{x:1317,y:750,t:1512498228353};\\\", \\\"{x:1315,y:746,t:1512498228370};\\\", \\\"{x:1313,y:741,t:1512498228386};\\\", \\\"{x:1306,y:734,t:1512498228403};\\\", \\\"{x:1296,y:726,t:1512498228419};\\\", \\\"{x:1278,y:720,t:1512498228436};\\\", \\\"{x:1246,y:714,t:1512498228453};\\\", \\\"{x:1197,y:703,t:1512498228470};\\\", \\\"{x:1164,y:699,t:1512498228486};\\\", \\\"{x:1129,y:695,t:1512498228503};\\\", \\\"{x:1123,y:694,t:1512498228519};\\\", \\\"{x:1122,y:694,t:1512498228536};\\\", \\\"{x:1121,y:693,t:1512498228600};\\\", \\\"{x:1122,y:692,t:1512498228624};\\\", \\\"{x:1126,y:690,t:1512498228637};\\\", \\\"{x:1132,y:690,t:1512498228654};\\\", \\\"{x:1137,y:690,t:1512498228671};\\\", \\\"{x:1144,y:690,t:1512498228687};\\\", \\\"{x:1146,y:692,t:1512498228704};\\\", \\\"{x:1147,y:692,t:1512498228720};\\\", \\\"{x:1148,y:692,t:1512498228737};\\\", \\\"{x:1149,y:695,t:1512498229433};\\\", \\\"{x:1149,y:696,t:1512498229440};\\\", \\\"{x:1149,y:700,t:1512498229455};\\\", \\\"{x:1149,y:708,t:1512498229471};\\\", \\\"{x:1149,y:725,t:1512498229488};\\\", \\\"{x:1149,y:736,t:1512498229504};\\\", \\\"{x:1149,y:750,t:1512498229521};\\\", \\\"{x:1149,y:764,t:1512498229538};\\\", \\\"{x:1149,y:774,t:1512498229555};\\\", \\\"{x:1149,y:782,t:1512498229571};\\\", \\\"{x:1149,y:796,t:1512498229588};\\\", \\\"{x:1149,y:804,t:1512498229605};\\\", \\\"{x:1149,y:808,t:1512498229621};\\\", \\\"{x:1147,y:812,t:1512498229638};\\\", \\\"{x:1147,y:815,t:1512498229655};\\\", \\\"{x:1147,y:817,t:1512498229671};\\\", \\\"{x:1147,y:819,t:1512498229688};\\\", \\\"{x:1147,y:821,t:1512498229705};\\\", \\\"{x:1147,y:822,t:1512498229721};\\\", \\\"{x:1147,y:824,t:1512498229785};\\\", \\\"{x:1147,y:825,t:1512498229800};\\\", \\\"{x:1147,y:827,t:1512498229808};\\\", \\\"{x:1147,y:828,t:1512498229822};\\\", \\\"{x:1147,y:832,t:1512498229838};\\\", \\\"{x:1147,y:838,t:1512498229855};\\\", \\\"{x:1147,y:843,t:1512498229872};\\\", \\\"{x:1147,y:845,t:1512498229888};\\\", \\\"{x:1147,y:850,t:1512498229904};\\\", \\\"{x:1147,y:852,t:1512498229922};\\\", \\\"{x:1147,y:855,t:1512498229938};\\\", \\\"{x:1148,y:857,t:1512498229955};\\\", \\\"{x:1148,y:861,t:1512498229972};\\\", \\\"{x:1148,y:865,t:1512498229988};\\\", \\\"{x:1148,y:871,t:1512498230005};\\\", \\\"{x:1148,y:877,t:1512498230022};\\\", \\\"{x:1150,y:881,t:1512498230038};\\\", \\\"{x:1150,y:886,t:1512498230055};\\\", \\\"{x:1150,y:892,t:1512498230072};\\\", \\\"{x:1151,y:895,t:1512498230088};\\\", \\\"{x:1151,y:896,t:1512498230112};\\\", \\\"{x:1151,y:897,t:1512498230128};\\\", \\\"{x:1151,y:898,t:1512498230138};\\\", \\\"{x:1151,y:900,t:1512498230155};\\\", \\\"{x:1155,y:906,t:1512498230172};\\\", \\\"{x:1160,y:917,t:1512498230189};\\\", \\\"{x:1168,y:932,t:1512498230205};\\\", \\\"{x:1177,y:945,t:1512498230222};\\\", \\\"{x:1188,y:959,t:1512498230239};\\\", \\\"{x:1201,y:971,t:1512498230255};\\\", \\\"{x:1218,y:981,t:1512498230272};\\\", \\\"{x:1230,y:986,t:1512498230288};\\\", \\\"{x:1240,y:987,t:1512498230304};\\\", \\\"{x:1248,y:987,t:1512498230322};\\\", \\\"{x:1257,y:987,t:1512498230339};\\\", \\\"{x:1263,y:987,t:1512498230355};\\\", \\\"{x:1268,y:987,t:1512498230372};\\\", \\\"{x:1272,y:987,t:1512498230389};\\\", \\\"{x:1277,y:987,t:1512498230405};\\\", \\\"{x:1283,y:987,t:1512498230422};\\\", \\\"{x:1287,y:987,t:1512498230438};\\\", \\\"{x:1292,y:987,t:1512498230455};\\\", \\\"{x:1295,y:987,t:1512498230472};\\\", \\\"{x:1305,y:985,t:1512498230488};\\\", \\\"{x:1314,y:981,t:1512498230505};\\\", \\\"{x:1327,y:979,t:1512498230522};\\\", \\\"{x:1346,y:976,t:1512498230539};\\\", \\\"{x:1364,y:974,t:1512498230555};\\\", \\\"{x:1385,y:973,t:1512498230572};\\\", \\\"{x:1398,y:973,t:1512498230589};\\\", \\\"{x:1408,y:973,t:1512498230605};\\\", \\\"{x:1415,y:973,t:1512498230622};\\\", \\\"{x:1418,y:973,t:1512498230639};\\\", \\\"{x:1421,y:973,t:1512498230656};\\\", \\\"{x:1422,y:973,t:1512498230672};\\\", \\\"{x:1423,y:973,t:1512498230777};\\\", \\\"{x:1424,y:973,t:1512498230905};\\\", \\\"{x:1425,y:971,t:1512498230922};\\\", \\\"{x:1426,y:971,t:1512498230939};\\\", \\\"{x:1427,y:969,t:1512498230956};\\\", \\\"{x:1428,y:967,t:1512498230971};\\\", \\\"{x:1428,y:966,t:1512498231160};\\\", \\\"{x:1427,y:965,t:1512498231192};\\\", \\\"{x:1426,y:965,t:1512498231208};\\\", \\\"{x:1425,y:965,t:1512498231264};\\\", \\\"{x:1423,y:965,t:1512498231304};\\\", \\\"{x:1422,y:965,t:1512498231328};\\\", \\\"{x:1420,y:964,t:1512498231353};\\\", \\\"{x:1419,y:963,t:1512498231368};\\\", \\\"{x:1419,y:962,t:1512498234297};\\\", \\\"{x:1419,y:959,t:1512498234308};\\\", \\\"{x:1419,y:958,t:1512498234325};\\\", \\\"{x:1419,y:956,t:1512498234368};\\\", \\\"{x:1419,y:955,t:1512498234480};\\\", \\\"{x:1419,y:953,t:1512498234504};\\\", \\\"{x:1419,y:952,t:1512498234520};\\\", \\\"{x:1420,y:950,t:1512498234712};\\\", \\\"{x:1421,y:949,t:1512498234736};\\\", \\\"{x:1422,y:949,t:1512498234825};\\\", \\\"{x:1422,y:948,t:1512498234864};\\\", \\\"{x:1423,y:947,t:1512498234888};\\\", \\\"{x:1424,y:946,t:1512498234896};\\\", \\\"{x:1414,y:945,t:1512498239768};\\\", \\\"{x:1391,y:945,t:1512498239779};\\\", \\\"{x:1331,y:940,t:1512498239796};\\\", \\\"{x:1267,y:922,t:1512498239812};\\\", \\\"{x:1175,y:887,t:1512498239829};\\\", \\\"{x:974,y:810,t:1512498239846};\\\", \\\"{x:784,y:759,t:1512498239862};\\\", \\\"{x:628,y:726,t:1512498239879};\\\", \\\"{x:484,y:699,t:1512498239895};\\\", \\\"{x:414,y:690,t:1512498239912};\\\", \\\"{x:380,y:683,t:1512498239928};\\\", \\\"{x:363,y:679,t:1512498239945};\\\", \\\"{x:361,y:678,t:1512498239962};\\\", \\\"{x:359,y:676,t:1512498239979};\\\", \\\"{x:358,y:672,t:1512498239995};\\\", \\\"{x:358,y:665,t:1512498240012};\\\", \\\"{x:357,y:658,t:1512498240029};\\\", \\\"{x:357,y:654,t:1512498240045};\\\", \\\"{x:357,y:652,t:1512498240062};\\\", \\\"{x:356,y:645,t:1512498240078};\\\", \\\"{x:352,y:640,t:1512498240095};\\\", \\\"{x:348,y:635,t:1512498240112};\\\", \\\"{x:345,y:631,t:1512498240129};\\\", \\\"{x:337,y:624,t:1512498240145};\\\", \\\"{x:330,y:618,t:1512498240162};\\\", \\\"{x:324,y:611,t:1512498240179};\\\", \\\"{x:323,y:609,t:1512498240195};\\\", \\\"{x:321,y:607,t:1512498240212};\\\", \\\"{x:317,y:604,t:1512498240229};\\\", \\\"{x:308,y:601,t:1512498240245};\\\", \\\"{x:293,y:600,t:1512498240262};\\\", \\\"{x:261,y:600,t:1512498240278};\\\", \\\"{x:242,y:600,t:1512498240295};\\\", \\\"{x:227,y:600,t:1512498240312};\\\", \\\"{x:219,y:600,t:1512498240329};\\\", \\\"{x:216,y:600,t:1512498240345};\\\", \\\"{x:215,y:600,t:1512498240362};\\\", \\\"{x:213,y:600,t:1512498240503};\\\", \\\"{x:212,y:600,t:1512498240512};\\\", \\\"{x:208,y:601,t:1512498240529};\\\", \\\"{x:203,y:602,t:1512498240546};\\\", \\\"{x:200,y:602,t:1512498240562};\\\", \\\"{x:198,y:602,t:1512498240579};\\\", \\\"{x:195,y:602,t:1512498240596};\\\", \\\"{x:194,y:601,t:1512498240612};\\\", \\\"{x:193,y:600,t:1512498240629};\\\", \\\"{x:192,y:600,t:1512498240671};\\\", \\\"{x:191,y:600,t:1512498240687};\\\", \\\"{x:190,y:600,t:1512498240696};\\\", \\\"{x:189,y:600,t:1512498240727};\\\", \\\"{x:188,y:600,t:1512498240735};\\\", \\\"{x:188,y:601,t:1512498240746};\\\", \\\"{x:186,y:601,t:1512498240840};\\\", \\\"{x:186,y:600,t:1512498240847};\\\", \\\"{x:184,y:597,t:1512498240863};\\\", \\\"{x:184,y:596,t:1512498240879};\\\", \\\"{x:183,y:596,t:1512498240919};\\\", \\\"{x:183,y:595,t:1512498240952};\\\", \\\"{x:183,y:594,t:1512498240990};\\\", \\\"{x:183,y:593,t:1512498241031};\\\", \\\"{x:183,y:592,t:1512498241046};\\\", \\\"{x:183,y:591,t:1512498241062};\\\", \\\"{x:185,y:591,t:1512498241512};\\\", \\\"{x:188,y:591,t:1512498241519};\\\", \\\"{x:191,y:593,t:1512498241531};\\\", \\\"{x:201,y:599,t:1512498241546};\\\", \\\"{x:217,y:610,t:1512498241563};\\\", \\\"{x:236,y:620,t:1512498241580};\\\", \\\"{x:266,y:632,t:1512498241596};\\\", \\\"{x:299,y:646,t:1512498241613};\\\", \\\"{x:333,y:656,t:1512498241630};\\\", \\\"{x:355,y:662,t:1512498241646};\\\", \\\"{x:387,y:672,t:1512498241663};\\\", \\\"{x:401,y:678,t:1512498241680};\\\", \\\"{x:405,y:679,t:1512498241696};\\\", \\\"{x:409,y:682,t:1512498241713};\\\", \\\"{x:412,y:682,t:1512498241730};\\\", \\\"{x:412,y:683,t:1512498241746};\\\" ] }, { \\\"rt\\\": 13263, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 692190, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:412,y:682,t:1512498244720};\\\", \\\"{x:412,y:678,t:1512498244737};\\\", \\\"{x:412,y:673,t:1512498244752};\\\", \\\"{x:410,y:667,t:1512498244768};\\\", \\\"{x:409,y:662,t:1512498244783};\\\", \\\"{x:409,y:659,t:1512498244800};\\\", \\\"{x:409,y:657,t:1512498244817};\\\", \\\"{x:408,y:656,t:1512498244833};\\\", \\\"{x:408,y:655,t:1512498244896};\\\", \\\"{x:408,y:654,t:1512498244903};\\\", \\\"{x:408,y:653,t:1512498244917};\\\", \\\"{x:408,y:650,t:1512498244933};\\\", \\\"{x:408,y:647,t:1512498244950};\\\", \\\"{x:408,y:644,t:1512498244967};\\\", \\\"{x:408,y:642,t:1512498244983};\\\", \\\"{x:408,y:641,t:1512498245000};\\\", \\\"{x:408,y:640,t:1512498245017};\\\", \\\"{x:411,y:638,t:1512498246648};\\\", \\\"{x:416,y:637,t:1512498246656};\\\", \\\"{x:422,y:637,t:1512498246668};\\\", \\\"{x:442,y:637,t:1512498246685};\\\", \\\"{x:463,y:635,t:1512498246702};\\\", \\\"{x:485,y:635,t:1512498246719};\\\", \\\"{x:510,y:635,t:1512498246735};\\\", \\\"{x:543,y:635,t:1512498246751};\\\", \\\"{x:600,y:637,t:1512498246768};\\\", \\\"{x:666,y:657,t:1512498246786};\\\", \\\"{x:748,y:687,t:1512498246802};\\\", \\\"{x:832,y:728,t:1512498246819};\\\", \\\"{x:912,y:764,t:1512498246836};\\\", \\\"{x:971,y:796,t:1512498246852};\\\", \\\"{x:1026,y:826,t:1512498246872};\\\", \\\"{x:1067,y:851,t:1512498246885};\\\", \\\"{x:1094,y:867,t:1512498246901};\\\", \\\"{x:1117,y:880,t:1512498246918};\\\", \\\"{x:1149,y:896,t:1512498246935};\\\", \\\"{x:1179,y:907,t:1512498246951};\\\", \\\"{x:1222,y:922,t:1512498246968};\\\", \\\"{x:1262,y:935,t:1512498246985};\\\", \\\"{x:1292,y:940,t:1512498247001};\\\", \\\"{x:1311,y:942,t:1512498247018};\\\", \\\"{x:1322,y:942,t:1512498247035};\\\", \\\"{x:1325,y:942,t:1512498247051};\\\", \\\"{x:1326,y:942,t:1512498247104};\\\", \\\"{x:1326,y:941,t:1512498247119};\\\", \\\"{x:1326,y:940,t:1512498247136};\\\", \\\"{x:1326,y:938,t:1512498247153};\\\", \\\"{x:1326,y:937,t:1512498247288};\\\", \\\"{x:1326,y:936,t:1512498247302};\\\", \\\"{x:1326,y:935,t:1512498247318};\\\", \\\"{x:1324,y:934,t:1512498247336};\\\", \\\"{x:1321,y:932,t:1512498247352};\\\", \\\"{x:1319,y:931,t:1512498247376};\\\", \\\"{x:1317,y:931,t:1512498249104};\\\", \\\"{x:1313,y:931,t:1512498249120};\\\", \\\"{x:1305,y:931,t:1512498249137};\\\", \\\"{x:1300,y:931,t:1512498249154};\\\", \\\"{x:1292,y:931,t:1512498249170};\\\", \\\"{x:1279,y:932,t:1512498249187};\\\", \\\"{x:1271,y:932,t:1512498249204};\\\", \\\"{x:1265,y:932,t:1512498249221};\\\", \\\"{x:1259,y:932,t:1512498249237};\\\", \\\"{x:1255,y:932,t:1512498249253};\\\", \\\"{x:1251,y:932,t:1512498249271};\\\", \\\"{x:1248,y:932,t:1512498249287};\\\", \\\"{x:1240,y:932,t:1512498249304};\\\", \\\"{x:1238,y:932,t:1512498249320};\\\", \\\"{x:1229,y:932,t:1512498249337};\\\", \\\"{x:1222,y:932,t:1512498249354};\\\", \\\"{x:1216,y:933,t:1512498249371};\\\", \\\"{x:1212,y:934,t:1512498249387};\\\", \\\"{x:1209,y:935,t:1512498249404};\\\", \\\"{x:1207,y:936,t:1512498249421};\\\", \\\"{x:1206,y:936,t:1512498249437};\\\", \\\"{x:1204,y:936,t:1512498249454};\\\", \\\"{x:1203,y:937,t:1512498249471};\\\", \\\"{x:1201,y:937,t:1512498249488};\\\", \\\"{x:1200,y:937,t:1512498249504};\\\", \\\"{x:1198,y:938,t:1512498249520};\\\", \\\"{x:1197,y:939,t:1512498249538};\\\", \\\"{x:1196,y:940,t:1512498249554};\\\", \\\"{x:1195,y:941,t:1512498249571};\\\", \\\"{x:1194,y:942,t:1512498249587};\\\", \\\"{x:1193,y:943,t:1512498249604};\\\", \\\"{x:1191,y:944,t:1512498249621};\\\", \\\"{x:1188,y:944,t:1512498249638};\\\", \\\"{x:1185,y:946,t:1512498249654};\\\", \\\"{x:1183,y:947,t:1512498249671};\\\", \\\"{x:1181,y:948,t:1512498249688};\\\", \\\"{x:1179,y:949,t:1512498249704};\\\", \\\"{x:1178,y:950,t:1512498249721};\\\", \\\"{x:1177,y:952,t:1512498249738};\\\", \\\"{x:1176,y:953,t:1512498249754};\\\", \\\"{x:1175,y:956,t:1512498249771};\\\", \\\"{x:1174,y:957,t:1512498249788};\\\", \\\"{x:1173,y:959,t:1512498249804};\\\", \\\"{x:1172,y:960,t:1512498249821};\\\", \\\"{x:1171,y:961,t:1512498249838};\\\", \\\"{x:1170,y:962,t:1512498249856};\\\", \\\"{x:1169,y:962,t:1512498249871};\\\", \\\"{x:1166,y:962,t:1512498249888};\\\", \\\"{x:1157,y:962,t:1512498249904};\\\", \\\"{x:1150,y:964,t:1512498249921};\\\", \\\"{x:1145,y:964,t:1512498249938};\\\", \\\"{x:1141,y:966,t:1512498249954};\\\", \\\"{x:1140,y:967,t:1512498249971};\\\", \\\"{x:1140,y:966,t:1512498250064};\\\", \\\"{x:1140,y:965,t:1512498250096};\\\", \\\"{x:1140,y:964,t:1512498250104};\\\", \\\"{x:1141,y:963,t:1512498250121};\\\", \\\"{x:1143,y:963,t:1512498250138};\\\", \\\"{x:1144,y:963,t:1512498250155};\\\", \\\"{x:1144,y:962,t:1512498250176};\\\", \\\"{x:1145,y:962,t:1512498250200};\\\", \\\"{x:1147,y:961,t:1512498250208};\\\", \\\"{x:1148,y:960,t:1512498250224};\\\", \\\"{x:1150,y:960,t:1512498250238};\\\", \\\"{x:1151,y:959,t:1512498250255};\\\", \\\"{x:1154,y:958,t:1512498250271};\\\", \\\"{x:1154,y:956,t:1512498252560};\\\", \\\"{x:1153,y:955,t:1512498252573};\\\", \\\"{x:1145,y:947,t:1512498252590};\\\", \\\"{x:1135,y:940,t:1512498252606};\\\", \\\"{x:1120,y:925,t:1512498252623};\\\", \\\"{x:1063,y:889,t:1512498252640};\\\", \\\"{x:1018,y:857,t:1512498252656};\\\", \\\"{x:963,y:824,t:1512498252673};\\\", \\\"{x:909,y:798,t:1512498252690};\\\", \\\"{x:853,y:769,t:1512498252706};\\\", \\\"{x:797,y:741,t:1512498252723};\\\", \\\"{x:746,y:713,t:1512498252740};\\\", \\\"{x:702,y:686,t:1512498252756};\\\", \\\"{x:663,y:654,t:1512498252773};\\\", \\\"{x:626,y:626,t:1512498252790};\\\", \\\"{x:600,y:607,t:1512498252806};\\\", \\\"{x:562,y:585,t:1512498252823};\\\", \\\"{x:526,y:569,t:1512498252840};\\\", \\\"{x:504,y:560,t:1512498252855};\\\", \\\"{x:481,y:555,t:1512498252872};\\\", \\\"{x:464,y:550,t:1512498252889};\\\", \\\"{x:450,y:545,t:1512498252906};\\\", \\\"{x:437,y:542,t:1512498252922};\\\", \\\"{x:429,y:539,t:1512498252939};\\\", \\\"{x:422,y:536,t:1512498252956};\\\", \\\"{x:418,y:535,t:1512498252972};\\\", \\\"{x:413,y:533,t:1512498252989};\\\", \\\"{x:409,y:532,t:1512498253006};\\\", \\\"{x:402,y:532,t:1512498253022};\\\", \\\"{x:394,y:532,t:1512498253039};\\\", \\\"{x:391,y:532,t:1512498253056};\\\", \\\"{x:389,y:532,t:1512498253073};\\\", \\\"{x:387,y:533,t:1512498253090};\\\", \\\"{x:386,y:533,t:1512498253106};\\\", \\\"{x:385,y:533,t:1512498253123};\\\", \\\"{x:384,y:534,t:1512498253140};\\\", \\\"{x:381,y:535,t:1512498253156};\\\", \\\"{x:380,y:536,t:1512498253191};\\\", \\\"{x:379,y:536,t:1512498253206};\\\", \\\"{x:377,y:536,t:1512498253223};\\\", \\\"{x:375,y:538,t:1512498253240};\\\", \\\"{x:373,y:543,t:1512498253256};\\\", \\\"{x:370,y:547,t:1512498253273};\\\", \\\"{x:366,y:551,t:1512498253290};\\\", \\\"{x:362,y:554,t:1512498253307};\\\", \\\"{x:359,y:557,t:1512498253323};\\\", \\\"{x:356,y:559,t:1512498253340};\\\", \\\"{x:355,y:559,t:1512498253356};\\\", \\\"{x:353,y:561,t:1512498253373};\\\", \\\"{x:351,y:561,t:1512498253408};\\\", \\\"{x:351,y:562,t:1512498253423};\\\", \\\"{x:350,y:562,t:1512498253440};\\\", \\\"{x:348,y:564,t:1512498253457};\\\", \\\"{x:347,y:565,t:1512498253473};\\\", \\\"{x:346,y:565,t:1512498253490};\\\", \\\"{x:344,y:567,t:1512498253507};\\\", \\\"{x:343,y:567,t:1512498253523};\\\", \\\"{x:341,y:567,t:1512498253540};\\\", \\\"{x:339,y:567,t:1512498253560};\\\", \\\"{x:338,y:567,t:1512498253574};\\\", \\\"{x:337,y:568,t:1512498253590};\\\", \\\"{x:335,y:570,t:1512498253608};\\\", \\\"{x:333,y:572,t:1512498253623};\\\", \\\"{x:332,y:574,t:1512498253640};\\\", \\\"{x:331,y:578,t:1512498253658};\\\", \\\"{x:331,y:581,t:1512498253674};\\\", \\\"{x:331,y:588,t:1512498253690};\\\", \\\"{x:332,y:592,t:1512498253707};\\\", \\\"{x:335,y:596,t:1512498253724};\\\", \\\"{x:336,y:597,t:1512498253740};\\\", \\\"{x:337,y:599,t:1512498253757};\\\", \\\"{x:339,y:599,t:1512498253774};\\\", \\\"{x:339,y:600,t:1512498253791};\\\", \\\"{x:342,y:603,t:1512498253808};\\\", \\\"{x:343,y:605,t:1512498253824};\\\", \\\"{x:346,y:609,t:1512498253840};\\\", \\\"{x:349,y:613,t:1512498253857};\\\", \\\"{x:350,y:614,t:1512498253874};\\\", \\\"{x:351,y:616,t:1512498253890};\\\", \\\"{x:352,y:616,t:1512498253936};\\\", \\\"{x:353,y:616,t:1512498253960};\\\", \\\"{x:355,y:616,t:1512498253975};\\\", \\\"{x:358,y:612,t:1512498253991};\\\", \\\"{x:367,y:605,t:1512498254007};\\\", \\\"{x:376,y:599,t:1512498254024};\\\", \\\"{x:385,y:593,t:1512498254040};\\\", \\\"{x:391,y:588,t:1512498254057};\\\", \\\"{x:396,y:583,t:1512498254074};\\\", \\\"{x:399,y:579,t:1512498254091};\\\", \\\"{x:400,y:574,t:1512498254108};\\\", \\\"{x:400,y:570,t:1512498254124};\\\", \\\"{x:400,y:565,t:1512498254142};\\\", \\\"{x:400,y:563,t:1512498254157};\\\", \\\"{x:400,y:560,t:1512498254174};\\\", \\\"{x:400,y:558,t:1512498254191};\\\", \\\"{x:400,y:557,t:1512498254303};\\\", \\\"{x:402,y:556,t:1512498254311};\\\", \\\"{x:404,y:554,t:1512498254324};\\\", \\\"{x:411,y:551,t:1512498254341};\\\", \\\"{x:417,y:546,t:1512498254357};\\\", \\\"{x:421,y:542,t:1512498254374};\\\", \\\"{x:427,y:540,t:1512498254391};\\\", \\\"{x:435,y:537,t:1512498254407};\\\", \\\"{x:454,y:536,t:1512498254424};\\\", \\\"{x:466,y:536,t:1512498254441};\\\", \\\"{x:478,y:536,t:1512498254458};\\\", \\\"{x:481,y:536,t:1512498254474};\\\", \\\"{x:482,y:536,t:1512498254552};\\\", \\\"{x:484,y:535,t:1512498254575};\\\", \\\"{x:484,y:534,t:1512498254591};\\\", \\\"{x:486,y:534,t:1512498254648};\\\", \\\"{x:488,y:534,t:1512498254664};\\\", \\\"{x:489,y:534,t:1512498254674};\\\", \\\"{x:490,y:534,t:1512498254691};\\\", \\\"{x:492,y:534,t:1512498254768};\\\", \\\"{x:493,y:534,t:1512498254775};\\\", \\\"{x:497,y:533,t:1512498254791};\\\", \\\"{x:500,y:532,t:1512498254808};\\\", \\\"{x:501,y:531,t:1512498254825};\\\", \\\"{x:502,y:531,t:1512498254841};\\\", \\\"{x:503,y:531,t:1512498254896};\\\", \\\"{x:505,y:531,t:1512498254909};\\\", \\\"{x:507,y:530,t:1512498254925};\\\", \\\"{x:509,y:530,t:1512498254941};\\\", \\\"{x:510,y:530,t:1512498254958};\\\", \\\"{x:511,y:530,t:1512498255255};\\\", \\\"{x:515,y:530,t:1512498255263};\\\", \\\"{x:521,y:532,t:1512498255275};\\\", \\\"{x:532,y:535,t:1512498255291};\\\", \\\"{x:543,y:536,t:1512498255308};\\\", \\\"{x:555,y:537,t:1512498255325};\\\", \\\"{x:564,y:537,t:1512498255341};\\\", \\\"{x:572,y:537,t:1512498255358};\\\", \\\"{x:590,y:537,t:1512498255375};\\\", \\\"{x:604,y:537,t:1512498255392};\\\", \\\"{x:614,y:537,t:1512498255408};\\\", \\\"{x:619,y:537,t:1512498255425};\\\", \\\"{x:622,y:537,t:1512498255442};\\\", \\\"{x:622,y:538,t:1512498256055};\\\", \\\"{x:619,y:540,t:1512498256062};\\\", \\\"{x:613,y:542,t:1512498256075};\\\", \\\"{x:596,y:550,t:1512498256092};\\\", \\\"{x:571,y:563,t:1512498256109};\\\", \\\"{x:522,y:582,t:1512498256125};\\\", \\\"{x:467,y:608,t:1512498256143};\\\", \\\"{x:440,y:622,t:1512498256158};\\\", \\\"{x:428,y:630,t:1512498256175};\\\", \\\"{x:424,y:632,t:1512498256192};\\\", \\\"{x:421,y:635,t:1512498256209};\\\", \\\"{x:420,y:636,t:1512498256225};\\\", \\\"{x:419,y:638,t:1512498256242};\\\", \\\"{x:417,y:640,t:1512498256259};\\\", \\\"{x:417,y:641,t:1512498256279};\\\", \\\"{x:416,y:641,t:1512498256292};\\\", \\\"{x:416,y:642,t:1512498256309};\\\", \\\"{x:415,y:644,t:1512498256326};\\\", \\\"{x:415,y:646,t:1512498256343};\\\", \\\"{x:415,y:649,t:1512498256359};\\\", \\\"{x:416,y:657,t:1512498256376};\\\", \\\"{x:421,y:667,t:1512498256392};\\\", \\\"{x:424,y:675,t:1512498256409};\\\", \\\"{x:424,y:679,t:1512498256426};\\\", \\\"{x:424,y:680,t:1512498256512};\\\" ] }, { \\\"rt\\\": 14002, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 707495, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:431,y:680,t:1512498260488};\\\", \\\"{x:445,y:678,t:1512498260497};\\\", \\\"{x:485,y:667,t:1512498260515};\\\", \\\"{x:526,y:655,t:1512498260531};\\\", \\\"{x:550,y:647,t:1512498260547};\\\", \\\"{x:574,y:638,t:1512498260562};\\\", \\\"{x:593,y:631,t:1512498260579};\\\", \\\"{x:603,y:626,t:1512498260596};\\\", \\\"{x:620,y:623,t:1512498260612};\\\", \\\"{x:655,y:620,t:1512498260629};\\\", \\\"{x:692,y:619,t:1512498260646};\\\", \\\"{x:724,y:619,t:1512498260662};\\\", \\\"{x:771,y:619,t:1512498260679};\\\", \\\"{x:798,y:619,t:1512498260696};\\\", \\\"{x:818,y:620,t:1512498260713};\\\", \\\"{x:832,y:622,t:1512498260729};\\\", \\\"{x:839,y:624,t:1512498260746};\\\", \\\"{x:843,y:625,t:1512498260763};\\\", \\\"{x:844,y:625,t:1512498260779};\\\", \\\"{x:847,y:628,t:1512498260796};\\\", \\\"{x:855,y:632,t:1512498260813};\\\", \\\"{x:869,y:639,t:1512498260829};\\\", \\\"{x:888,y:650,t:1512498260846};\\\", \\\"{x:919,y:660,t:1512498260863};\\\", \\\"{x:950,y:665,t:1512498260879};\\\", \\\"{x:990,y:666,t:1512498260896};\\\", \\\"{x:1035,y:666,t:1512498260913};\\\", \\\"{x:1091,y:666,t:1512498260929};\\\", \\\"{x:1154,y:660,t:1512498260946};\\\", \\\"{x:1222,y:646,t:1512498260964};\\\", \\\"{x:1281,y:628,t:1512498260980};\\\", \\\"{x:1331,y:603,t:1512498260997};\\\", \\\"{x:1361,y:587,t:1512498261014};\\\", \\\"{x:1386,y:573,t:1512498261030};\\\", \\\"{x:1402,y:566,t:1512498261047};\\\", \\\"{x:1409,y:564,t:1512498261063};\\\", \\\"{x:1410,y:564,t:1512498261111};\\\", \\\"{x:1410,y:565,t:1512498261135};\\\", \\\"{x:1408,y:565,t:1512498261159};\\\", \\\"{x:1407,y:565,t:1512498261167};\\\", \\\"{x:1406,y:565,t:1512498261181};\\\", \\\"{x:1403,y:567,t:1512498261197};\\\", \\\"{x:1400,y:568,t:1512498261214};\\\", \\\"{x:1397,y:571,t:1512498261231};\\\", \\\"{x:1395,y:573,t:1512498261247};\\\", \\\"{x:1389,y:579,t:1512498261264};\\\", \\\"{x:1385,y:583,t:1512498261281};\\\", \\\"{x:1380,y:586,t:1512498261297};\\\", \\\"{x:1376,y:587,t:1512498261314};\\\", \\\"{x:1373,y:589,t:1512498261331};\\\", \\\"{x:1371,y:590,t:1512498261347};\\\", \\\"{x:1366,y:590,t:1512498261364};\\\", \\\"{x:1364,y:591,t:1512498261381};\\\", \\\"{x:1361,y:592,t:1512498261398};\\\", \\\"{x:1358,y:594,t:1512498261414};\\\", \\\"{x:1353,y:598,t:1512498261431};\\\", \\\"{x:1344,y:610,t:1512498261447};\\\", \\\"{x:1341,y:618,t:1512498261464};\\\", \\\"{x:1333,y:633,t:1512498261481};\\\", \\\"{x:1326,y:649,t:1512498261498};\\\", \\\"{x:1316,y:663,t:1512498261514};\\\", \\\"{x:1310,y:671,t:1512498261531};\\\", \\\"{x:1304,y:681,t:1512498261548};\\\", \\\"{x:1298,y:689,t:1512498261564};\\\", \\\"{x:1292,y:697,t:1512498261581};\\\", \\\"{x:1288,y:702,t:1512498261598};\\\", \\\"{x:1283,y:709,t:1512498261614};\\\", \\\"{x:1280,y:713,t:1512498261631};\\\", \\\"{x:1277,y:718,t:1512498261647};\\\", \\\"{x:1276,y:719,t:1512498261664};\\\", \\\"{x:1274,y:721,t:1512498261681};\\\", \\\"{x:1272,y:726,t:1512498261698};\\\", \\\"{x:1268,y:730,t:1512498261715};\\\", \\\"{x:1263,y:734,t:1512498261731};\\\", \\\"{x:1259,y:739,t:1512498261748};\\\", \\\"{x:1255,y:744,t:1512498261765};\\\", \\\"{x:1254,y:747,t:1512498261781};\\\", \\\"{x:1251,y:751,t:1512498261798};\\\", \\\"{x:1249,y:753,t:1512498261815};\\\", \\\"{x:1248,y:757,t:1512498261831};\\\", \\\"{x:1247,y:761,t:1512498261847};\\\", \\\"{x:1245,y:763,t:1512498261865};\\\", \\\"{x:1244,y:764,t:1512498261881};\\\", \\\"{x:1244,y:765,t:1512498261898};\\\", \\\"{x:1245,y:763,t:1512498262008};\\\", \\\"{x:1246,y:763,t:1512498262015};\\\", \\\"{x:1253,y:758,t:1512498262031};\\\", \\\"{x:1260,y:753,t:1512498262048};\\\", \\\"{x:1270,y:744,t:1512498262065};\\\", \\\"{x:1280,y:736,t:1512498262082};\\\", \\\"{x:1292,y:725,t:1512498262097};\\\", \\\"{x:1307,y:713,t:1512498262115};\\\", \\\"{x:1317,y:704,t:1512498262132};\\\", \\\"{x:1329,y:695,t:1512498262148};\\\", \\\"{x:1335,y:689,t:1512498262165};\\\", \\\"{x:1340,y:685,t:1512498262182};\\\", \\\"{x:1344,y:682,t:1512498262198};\\\", \\\"{x:1345,y:682,t:1512498262809};\\\", \\\"{x:1345,y:684,t:1512498262824};\\\", \\\"{x:1345,y:685,t:1512498262840};\\\", \\\"{x:1343,y:688,t:1512498262850};\\\", \\\"{x:1343,y:689,t:1512498262867};\\\", \\\"{x:1342,y:691,t:1512498262883};\\\", \\\"{x:1341,y:694,t:1512498262901};\\\", \\\"{x:1340,y:695,t:1512498263001};\\\", \\\"{x:1340,y:696,t:1512498263040};\\\", \\\"{x:1340,y:695,t:1512498263161};\\\", \\\"{x:1340,y:691,t:1512498263168};\\\", \\\"{x:1340,y:687,t:1512498263183};\\\", \\\"{x:1337,y:677,t:1512498263199};\\\", \\\"{x:1336,y:666,t:1512498263216};\\\", \\\"{x:1336,y:661,t:1512498263233};\\\", \\\"{x:1336,y:653,t:1512498263249};\\\", \\\"{x:1335,y:648,t:1512498263266};\\\", \\\"{x:1335,y:643,t:1512498263284};\\\", \\\"{x:1335,y:638,t:1512498263300};\\\", \\\"{x:1335,y:634,t:1512498263316};\\\", \\\"{x:1335,y:631,t:1512498263333};\\\", \\\"{x:1334,y:626,t:1512498263350};\\\", \\\"{x:1334,y:625,t:1512498263366};\\\", \\\"{x:1333,y:623,t:1512498263383};\\\", \\\"{x:1332,y:622,t:1512498263424};\\\", \\\"{x:1332,y:621,t:1512498263440};\\\", \\\"{x:1332,y:620,t:1512498263451};\\\", \\\"{x:1332,y:617,t:1512498263467};\\\", \\\"{x:1330,y:613,t:1512498263484};\\\", \\\"{x:1329,y:610,t:1512498263500};\\\", \\\"{x:1328,y:607,t:1512498263517};\\\", \\\"{x:1326,y:606,t:1512498263534};\\\", \\\"{x:1325,y:605,t:1512498263568};\\\", \\\"{x:1325,y:604,t:1512498263673};\\\", \\\"{x:1324,y:604,t:1512498263684};\\\", \\\"{x:1323,y:603,t:1512498263701};\\\", \\\"{x:1321,y:603,t:1512498263717};\\\", \\\"{x:1320,y:602,t:1512498263743};\\\", \\\"{x:1319,y:601,t:1512498263759};\\\", \\\"{x:1317,y:603,t:1512498264313};\\\", \\\"{x:1314,y:607,t:1512498264320};\\\", \\\"{x:1311,y:610,t:1512498264335};\\\", \\\"{x:1301,y:622,t:1512498264352};\\\", \\\"{x:1285,y:638,t:1512498264368};\\\", \\\"{x:1272,y:649,t:1512498264384};\\\", \\\"{x:1259,y:661,t:1512498264402};\\\", \\\"{x:1249,y:669,t:1512498264418};\\\", \\\"{x:1242,y:676,t:1512498264435};\\\", \\\"{x:1238,y:680,t:1512498264452};\\\", \\\"{x:1235,y:681,t:1512498264468};\\\", \\\"{x:1232,y:683,t:1512498264485};\\\", \\\"{x:1231,y:683,t:1512498264502};\\\", \\\"{x:1230,y:683,t:1512498264518};\\\", \\\"{x:1229,y:683,t:1512498264535};\\\", \\\"{x:1229,y:684,t:1512498264552};\\\", \\\"{x:1225,y:686,t:1512498264568};\\\", \\\"{x:1224,y:687,t:1512498264585};\\\", \\\"{x:1219,y:689,t:1512498264602};\\\", \\\"{x:1214,y:690,t:1512498264618};\\\", \\\"{x:1209,y:691,t:1512498264635};\\\", \\\"{x:1203,y:691,t:1512498264652};\\\", \\\"{x:1199,y:691,t:1512498264669};\\\", \\\"{x:1194,y:691,t:1512498264685};\\\", \\\"{x:1191,y:691,t:1512498264702};\\\", \\\"{x:1187,y:691,t:1512498264719};\\\", \\\"{x:1181,y:692,t:1512498264735};\\\", \\\"{x:1178,y:693,t:1512498264752};\\\", \\\"{x:1173,y:694,t:1512498264769};\\\", \\\"{x:1171,y:695,t:1512498264785};\\\", \\\"{x:1170,y:695,t:1512498264881};\\\", \\\"{x:1167,y:695,t:1512498264888};\\\", \\\"{x:1166,y:695,t:1512498264902};\\\", \\\"{x:1163,y:695,t:1512498264918};\\\", \\\"{x:1162,y:695,t:1512498264935};\\\", \\\"{x:1161,y:695,t:1512498264960};\\\", \\\"{x:1160,y:696,t:1512498264985};\\\", \\\"{x:1159,y:697,t:1512498265007};\\\", \\\"{x:1158,y:697,t:1512498265039};\\\", \\\"{x:1157,y:697,t:1512498265304};\\\", \\\"{x:1156,y:697,t:1512498265400};\\\", \\\"{x:1155,y:697,t:1512498265408};\\\", \\\"{x:1154,y:697,t:1512498265418};\\\", \\\"{x:1152,y:697,t:1512498265435};\\\", \\\"{x:1148,y:697,t:1512498265454};\\\", \\\"{x:1146,y:697,t:1512498265472};\\\", \\\"{x:1145,y:697,t:1512498265488};\\\", \\\"{x:1144,y:697,t:1512498265503};\\\", \\\"{x:1143,y:697,t:1512498265569};\\\", \\\"{x:1144,y:697,t:1512498266680};\\\", \\\"{x:1145,y:696,t:1512498266688};\\\", \\\"{x:1149,y:695,t:1512498266704};\\\", \\\"{x:1152,y:693,t:1512498266720};\\\", \\\"{x:1154,y:692,t:1512498266736};\\\", \\\"{x:1155,y:692,t:1512498266753};\\\", \\\"{x:1155,y:695,t:1512498267488};\\\", \\\"{x:1148,y:704,t:1512498267505};\\\", \\\"{x:1139,y:713,t:1512498267521};\\\", \\\"{x:1129,y:719,t:1512498267537};\\\", \\\"{x:1113,y:724,t:1512498267554};\\\", \\\"{x:1097,y:725,t:1512498267571};\\\", \\\"{x:1080,y:725,t:1512498267588};\\\", \\\"{x:1055,y:725,t:1512498267605};\\\", \\\"{x:1008,y:713,t:1512498267622};\\\", \\\"{x:952,y:704,t:1512498267637};\\\", \\\"{x:882,y:693,t:1512498267655};\\\", \\\"{x:784,y:663,t:1512498267672};\\\", \\\"{x:696,y:638,t:1512498267688};\\\", \\\"{x:646,y:617,t:1512498267704};\\\", \\\"{x:631,y:604,t:1512498267721};\\\", \\\"{x:630,y:599,t:1512498267737};\\\", \\\"{x:630,y:594,t:1512498267754};\\\", \\\"{x:635,y:584,t:1512498267771};\\\", \\\"{x:640,y:575,t:1512498267788};\\\", \\\"{x:643,y:565,t:1512498267804};\\\", \\\"{x:644,y:559,t:1512498267821};\\\", \\\"{x:644,y:554,t:1512498267838};\\\", \\\"{x:641,y:548,t:1512498267854};\\\", \\\"{x:637,y:544,t:1512498267871};\\\", \\\"{x:635,y:541,t:1512498267887};\\\", \\\"{x:630,y:535,t:1512498267904};\\\", \\\"{x:620,y:525,t:1512498267921};\\\", \\\"{x:601,y:517,t:1512498267938};\\\", \\\"{x:579,y:508,t:1512498267954};\\\", \\\"{x:555,y:501,t:1512498267971};\\\", \\\"{x:532,y:492,t:1512498267988};\\\", \\\"{x:527,y:487,t:1512498268004};\\\", \\\"{x:525,y:489,t:1512498268021};\\\", \\\"{x:525,y:490,t:1512498268360};\\\", \\\"{x:526,y:492,t:1512498268376};\\\", \\\"{x:534,y:493,t:1512498268388};\\\", \\\"{x:549,y:497,t:1512498268405};\\\", \\\"{x:557,y:497,t:1512498268423};\\\", \\\"{x:565,y:497,t:1512498268438};\\\", \\\"{x:579,y:498,t:1512498268456};\\\", \\\"{x:583,y:500,t:1512498268472};\\\", \\\"{x:587,y:501,t:1512498268488};\\\", \\\"{x:593,y:504,t:1512498268506};\\\", \\\"{x:595,y:505,t:1512498268522};\\\", \\\"{x:597,y:506,t:1512498268538};\\\", \\\"{x:598,y:507,t:1512498268555};\\\", \\\"{x:600,y:509,t:1512498268572};\\\", \\\"{x:601,y:510,t:1512498268588};\\\", \\\"{x:605,y:513,t:1512498268605};\\\", \\\"{x:609,y:517,t:1512498268622};\\\", \\\"{x:612,y:522,t:1512498268638};\\\", \\\"{x:617,y:530,t:1512498268655};\\\", \\\"{x:620,y:535,t:1512498268672};\\\", \\\"{x:620,y:538,t:1512498268688};\\\", \\\"{x:621,y:539,t:1512498268703};\\\", \\\"{x:621,y:538,t:1512498268815};\\\", \\\"{x:620,y:537,t:1512498268823};\\\", \\\"{x:620,y:536,t:1512498268839};\\\", \\\"{x:619,y:535,t:1512498268853};\\\", \\\"{x:619,y:534,t:1512498268871};\\\", \\\"{x:618,y:534,t:1512498268895};\\\", \\\"{x:618,y:532,t:1512498269144};\\\", \\\"{x:620,y:531,t:1512498269168};\\\", \\\"{x:621,y:531,t:1512498269184};\\\", \\\"{x:623,y:530,t:1512498269192};\\\", \\\"{x:623,y:529,t:1512498269208};\\\", \\\"{x:618,y:529,t:1512498270455};\\\", \\\"{x:599,y:541,t:1512498270471};\\\", \\\"{x:575,y:554,t:1512498270488};\\\", \\\"{x:546,y:566,t:1512498270504};\\\", \\\"{x:517,y:581,t:1512498270521};\\\", \\\"{x:494,y:591,t:1512498270538};\\\", \\\"{x:480,y:597,t:1512498270554};\\\", \\\"{x:466,y:604,t:1512498270571};\\\", \\\"{x:453,y:609,t:1512498270589};\\\", \\\"{x:445,y:614,t:1512498270604};\\\", \\\"{x:439,y:618,t:1512498270621};\\\", \\\"{x:434,y:621,t:1512498270639};\\\", \\\"{x:433,y:622,t:1512498270655};\\\", \\\"{x:432,y:623,t:1512498270672};\\\", \\\"{x:432,y:625,t:1512498270696};\\\", \\\"{x:432,y:626,t:1512498270705};\\\", \\\"{x:432,y:629,t:1512498270721};\\\", \\\"{x:432,y:635,t:1512498270739};\\\", \\\"{x:432,y:648,t:1512498270755};\\\", \\\"{x:429,y:658,t:1512498270771};\\\", \\\"{x:428,y:665,t:1512498270788};\\\", \\\"{x:428,y:670,t:1512498270805};\\\", \\\"{x:428,y:673,t:1512498270821};\\\", \\\"{x:427,y:677,t:1512498270839};\\\", \\\"{x:426,y:679,t:1512498270855};\\\", \\\"{x:425,y:680,t:1512498270871};\\\", \\\"{x:424,y:681,t:1512498270888};\\\" ] }, { \\\"rt\\\": 69547, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 778337, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -Z -O -C -G -G -A -E -6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:424,y:682,t:1512498274408};\\\", \\\"{x:426,y:682,t:1512498277232};\\\", \\\"{x:438,y:679,t:1512498277243};\\\", \\\"{x:466,y:668,t:1512498277259};\\\", \\\"{x:511,y:655,t:1512498277275};\\\", \\\"{x:596,y:634,t:1512498277292};\\\", \\\"{x:713,y:618,t:1512498277310};\\\", \\\"{x:820,y:606,t:1512498277326};\\\", \\\"{x:990,y:602,t:1512498277343};\\\", \\\"{x:1082,y:602,t:1512498277360};\\\", \\\"{x:1141,y:602,t:1512498277376};\\\", \\\"{x:1166,y:608,t:1512498277393};\\\", \\\"{x:1188,y:616,t:1512498277410};\\\", \\\"{x:1206,y:625,t:1512498277426};\\\", \\\"{x:1219,y:634,t:1512498277443};\\\", \\\"{x:1229,y:648,t:1512498277460};\\\", \\\"{x:1240,y:665,t:1512498277476};\\\", \\\"{x:1253,y:685,t:1512498277493};\\\", \\\"{x:1272,y:704,t:1512498277510};\\\", \\\"{x:1277,y:705,t:1512498277526};\\\", \\\"{x:1290,y:709,t:1512498277543};\\\", \\\"{x:1302,y:709,t:1512498277560};\\\", \\\"{x:1318,y:709,t:1512498277576};\\\", \\\"{x:1335,y:703,t:1512498277593};\\\", \\\"{x:1356,y:697,t:1512498277610};\\\", \\\"{x:1377,y:692,t:1512498277626};\\\", \\\"{x:1395,y:690,t:1512498277643};\\\", \\\"{x:1410,y:687,t:1512498277660};\\\", \\\"{x:1420,y:686,t:1512498277676};\\\", \\\"{x:1421,y:685,t:1512498277693};\\\", \\\"{x:1421,y:686,t:1512498277792};\\\", \\\"{x:1421,y:687,t:1512498277800};\\\", \\\"{x:1419,y:688,t:1512498277810};\\\", \\\"{x:1416,y:688,t:1512498277827};\\\", \\\"{x:1416,y:690,t:1512498277843};\\\", \\\"{x:1415,y:691,t:1512498277860};\\\", \\\"{x:1414,y:693,t:1512498277877};\\\", \\\"{x:1414,y:695,t:1512498277893};\\\", \\\"{x:1414,y:696,t:1512498277919};\\\", \\\"{x:1414,y:697,t:1512498277959};\\\", \\\"{x:1415,y:697,t:1512498278072};\\\", \\\"{x:1416,y:697,t:1512498278079};\\\", \\\"{x:1417,y:697,t:1512498278146};\\\", \\\"{x:1418,y:697,t:1512498278160};\\\", \\\"{x:1420,y:696,t:1512498278177};\\\", \\\"{x:1421,y:695,t:1512498278193};\\\", \\\"{x:1421,y:696,t:1512498278840};\\\", \\\"{x:1421,y:699,t:1512498278847};\\\", \\\"{x:1421,y:702,t:1512498278861};\\\", \\\"{x:1421,y:706,t:1512498278879};\\\", \\\"{x:1421,y:709,t:1512498278895};\\\", \\\"{x:1421,y:713,t:1512498278911};\\\", \\\"{x:1421,y:714,t:1512498278928};\\\", \\\"{x:1421,y:716,t:1512498278945};\\\", \\\"{x:1421,y:718,t:1512498278962};\\\", \\\"{x:1421,y:722,t:1512498278978};\\\", \\\"{x:1421,y:727,t:1512498278995};\\\", \\\"{x:1421,y:735,t:1512498279012};\\\", \\\"{x:1421,y:743,t:1512498279028};\\\", \\\"{x:1421,y:752,t:1512498279045};\\\", \\\"{x:1421,y:761,t:1512498279062};\\\", \\\"{x:1421,y:768,t:1512498279078};\\\", \\\"{x:1421,y:772,t:1512498279095};\\\", \\\"{x:1421,y:779,t:1512498279111};\\\", \\\"{x:1421,y:783,t:1512498279129};\\\", \\\"{x:1421,y:790,t:1512498279145};\\\", \\\"{x:1423,y:799,t:1512498279162};\\\", \\\"{x:1424,y:806,t:1512498279179};\\\", \\\"{x:1425,y:814,t:1512498279195};\\\", \\\"{x:1426,y:825,t:1512498279212};\\\", \\\"{x:1427,y:832,t:1512498279229};\\\", \\\"{x:1428,y:839,t:1512498279245};\\\", \\\"{x:1428,y:846,t:1512498279262};\\\", \\\"{x:1430,y:852,t:1512498279279};\\\", \\\"{x:1430,y:857,t:1512498279295};\\\", \\\"{x:1430,y:864,t:1512498279311};\\\", \\\"{x:1431,y:868,t:1512498279329};\\\", \\\"{x:1431,y:873,t:1512498279345};\\\", \\\"{x:1431,y:880,t:1512498279362};\\\", \\\"{x:1431,y:885,t:1512498279379};\\\", \\\"{x:1430,y:888,t:1512498279395};\\\", \\\"{x:1429,y:894,t:1512498279412};\\\", \\\"{x:1429,y:897,t:1512498279429};\\\", \\\"{x:1428,y:901,t:1512498279445};\\\", \\\"{x:1427,y:904,t:1512498279462};\\\", \\\"{x:1427,y:908,t:1512498279479};\\\", \\\"{x:1427,y:911,t:1512498279495};\\\", \\\"{x:1426,y:916,t:1512498279512};\\\", \\\"{x:1426,y:918,t:1512498279529};\\\", \\\"{x:1426,y:920,t:1512498279545};\\\", \\\"{x:1426,y:923,t:1512498279562};\\\", \\\"{x:1426,y:927,t:1512498279579};\\\", \\\"{x:1426,y:931,t:1512498279596};\\\", \\\"{x:1426,y:936,t:1512498279612};\\\", \\\"{x:1425,y:937,t:1512498279629};\\\", \\\"{x:1425,y:939,t:1512498279646};\\\", \\\"{x:1425,y:940,t:1512498279662};\\\", \\\"{x:1425,y:942,t:1512498279679};\\\", \\\"{x:1425,y:943,t:1512498279720};\\\", \\\"{x:1424,y:945,t:1512498279753};\\\", \\\"{x:1424,y:946,t:1512498279768};\\\", \\\"{x:1423,y:947,t:1512498279780};\\\", \\\"{x:1422,y:948,t:1512498279797};\\\", \\\"{x:1422,y:950,t:1512498279813};\\\", \\\"{x:1420,y:951,t:1512498279830};\\\", \\\"{x:1420,y:952,t:1512498279847};\\\", \\\"{x:1420,y:955,t:1512498283697};\\\", \\\"{x:1420,y:956,t:1512498283704};\\\", \\\"{x:1421,y:958,t:1512498283716};\\\", \\\"{x:1422,y:960,t:1512498283733};\\\", \\\"{x:1422,y:962,t:1512498283750};\\\", \\\"{x:1423,y:959,t:1512498314618};\\\", \\\"{x:1423,y:958,t:1512498314633};\\\", \\\"{x:1423,y:956,t:1512498314642};\\\", \\\"{x:1423,y:950,t:1512498314659};\\\", \\\"{x:1425,y:942,t:1512498314676};\\\", \\\"{x:1435,y:933,t:1512498314694};\\\", \\\"{x:1442,y:926,t:1512498314710};\\\", \\\"{x:1447,y:912,t:1512498314727};\\\", \\\"{x:1450,y:897,t:1512498314744};\\\", \\\"{x:1455,y:877,t:1512498314760};\\\", \\\"{x:1459,y:858,t:1512498314777};\\\", \\\"{x:1461,y:840,t:1512498314794};\\\", \\\"{x:1465,y:824,t:1512498314810};\\\", \\\"{x:1463,y:798,t:1512498314826};\\\", \\\"{x:1462,y:787,t:1512498314844};\\\", \\\"{x:1462,y:778,t:1512498314860};\\\", \\\"{x:1459,y:772,t:1512498314877};\\\", \\\"{x:1458,y:769,t:1512498314894};\\\", \\\"{x:1455,y:764,t:1512498314910};\\\", \\\"{x:1451,y:755,t:1512498314927};\\\", \\\"{x:1447,y:747,t:1512498314944};\\\", \\\"{x:1441,y:739,t:1512498314960};\\\", \\\"{x:1436,y:732,t:1512498314977};\\\", \\\"{x:1431,y:727,t:1512498314994};\\\", \\\"{x:1425,y:723,t:1512498315010};\\\", \\\"{x:1419,y:720,t:1512498315027};\\\", \\\"{x:1417,y:720,t:1512498315044};\\\", \\\"{x:1417,y:719,t:1512498315060};\\\", \\\"{x:1415,y:718,t:1512498315077};\\\", \\\"{x:1414,y:717,t:1512498315094};\\\", \\\"{x:1414,y:715,t:1512498315110};\\\", \\\"{x:1414,y:713,t:1512498315127};\\\", \\\"{x:1413,y:710,t:1512498315144};\\\", \\\"{x:1413,y:708,t:1512498315161};\\\", \\\"{x:1413,y:707,t:1512498315177};\\\", \\\"{x:1413,y:705,t:1512498315194};\\\", \\\"{x:1413,y:704,t:1512498315211};\\\", \\\"{x:1413,y:702,t:1512498315227};\\\", \\\"{x:1414,y:701,t:1512498315250};\\\", \\\"{x:1415,y:701,t:1512498315290};\\\", \\\"{x:1416,y:701,t:1512498315459};\\\", \\\"{x:1417,y:700,t:1512498315474};\\\", \\\"{x:1418,y:699,t:1512498315499};\\\", \\\"{x:1419,y:699,t:1512498315526};\\\", \\\"{x:1420,y:698,t:1512498315543};\\\", \\\"{x:1421,y:698,t:1512498315561};\\\", \\\"{x:1422,y:698,t:1512498315659};\\\", \\\"{x:1423,y:697,t:1512498315699};\\\", \\\"{x:1422,y:697,t:1512498316626};\\\", \\\"{x:1412,y:700,t:1512498316635};\\\", \\\"{x:1402,y:703,t:1512498316645};\\\", \\\"{x:1375,y:710,t:1512498316662};\\\", \\\"{x:1349,y:717,t:1512498316678};\\\", \\\"{x:1303,y:717,t:1512498316695};\\\", \\\"{x:1250,y:717,t:1512498316712};\\\", \\\"{x:1166,y:712,t:1512498316728};\\\", \\\"{x:1025,y:673,t:1512498316745};\\\", \\\"{x:909,y:640,t:1512498316762};\\\", \\\"{x:814,y:608,t:1512498316778};\\\", \\\"{x:752,y:585,t:1512498316795};\\\", \\\"{x:732,y:580,t:1512498316812};\\\", \\\"{x:720,y:576,t:1512498316827};\\\", \\\"{x:713,y:573,t:1512498316845};\\\", \\\"{x:710,y:570,t:1512498316862};\\\", \\\"{x:708,y:564,t:1512498316878};\\\", \\\"{x:703,y:557,t:1512498316894};\\\", \\\"{x:696,y:551,t:1512498316911};\\\", \\\"{x:686,y:547,t:1512498316929};\\\", \\\"{x:673,y:544,t:1512498316945};\\\", \\\"{x:663,y:544,t:1512498316962};\\\", \\\"{x:655,y:544,t:1512498316978};\\\", \\\"{x:652,y:544,t:1512498316994};\\\", \\\"{x:645,y:544,t:1512498317012};\\\", \\\"{x:635,y:544,t:1512498317028};\\\", \\\"{x:627,y:544,t:1512498317044};\\\", \\\"{x:619,y:544,t:1512498317061};\\\", \\\"{x:606,y:540,t:1512498317078};\\\", \\\"{x:591,y:538,t:1512498317095};\\\", \\\"{x:572,y:535,t:1512498317112};\\\", \\\"{x:553,y:535,t:1512498317128};\\\", \\\"{x:534,y:535,t:1512498317145};\\\", \\\"{x:519,y:535,t:1512498317162};\\\", \\\"{x:492,y:542,t:1512498317178};\\\", \\\"{x:476,y:547,t:1512498317194};\\\", \\\"{x:468,y:553,t:1512498317213};\\\", \\\"{x:455,y:563,t:1512498317229};\\\", \\\"{x:446,y:568,t:1512498317246};\\\", \\\"{x:443,y:570,t:1512498317263};\\\", \\\"{x:441,y:571,t:1512498317279};\\\", \\\"{x:438,y:572,t:1512498317296};\\\", \\\"{x:429,y:572,t:1512498317313};\\\", \\\"{x:419,y:574,t:1512498317329};\\\", \\\"{x:408,y:575,t:1512498317346};\\\", \\\"{x:394,y:577,t:1512498317363};\\\", \\\"{x:378,y:579,t:1512498317379};\\\", \\\"{x:362,y:579,t:1512498317396};\\\", \\\"{x:339,y:581,t:1512498317413};\\\", \\\"{x:308,y:583,t:1512498317429};\\\", \\\"{x:283,y:588,t:1512498317446};\\\", \\\"{x:259,y:593,t:1512498317463};\\\", \\\"{x:234,y:596,t:1512498317479};\\\", \\\"{x:214,y:602,t:1512498317496};\\\", \\\"{x:195,y:607,t:1512498317513};\\\", \\\"{x:191,y:609,t:1512498317529};\\\", \\\"{x:182,y:611,t:1512498317546};\\\", \\\"{x:177,y:611,t:1512498317563};\\\", \\\"{x:176,y:611,t:1512498317579};\\\", \\\"{x:176,y:609,t:1512498317618};\\\", \\\"{x:175,y:608,t:1512498317629};\\\", \\\"{x:173,y:604,t:1512498317646};\\\", \\\"{x:171,y:600,t:1512498317664};\\\", \\\"{x:169,y:597,t:1512498317679};\\\", \\\"{x:167,y:594,t:1512498317696};\\\", \\\"{x:166,y:593,t:1512498317714};\\\", \\\"{x:166,y:592,t:1512498317754};\\\", \\\"{x:166,y:591,t:1512498317778};\\\", \\\"{x:165,y:590,t:1512498317786};\\\", \\\"{x:165,y:589,t:1512498317796};\\\", \\\"{x:165,y:587,t:1512498317813};\\\", \\\"{x:165,y:586,t:1512498317850};\\\", \\\"{x:164,y:585,t:1512498317863};\\\", \\\"{x:166,y:585,t:1512498317954};\\\", \\\"{x:167,y:585,t:1512498317970};\\\", \\\"{x:168,y:585,t:1512498318050};\\\", \\\"{x:169,y:585,t:1512498318063};\\\", \\\"{x:171,y:585,t:1512498318080};\\\", \\\"{x:172,y:585,t:1512498318098};\\\", \\\"{x:173,y:585,t:1512498318114};\\\", \\\"{x:174,y:585,t:1512498318130};\\\", \\\"{x:175,y:585,t:1512498318186};\\\", \\\"{x:176,y:585,t:1512498318426};\\\", \\\"{x:177,y:585,t:1512498318442};\\\", \\\"{x:178,y:585,t:1512498318458};\\\", \\\"{x:178,y:586,t:1512498318466};\\\", \\\"{x:180,y:586,t:1512498318480};\\\", \\\"{x:183,y:588,t:1512498318497};\\\", \\\"{x:185,y:588,t:1512498318513};\\\", \\\"{x:190,y:590,t:1512498318530};\\\", \\\"{x:191,y:591,t:1512498318923};\\\", \\\"{x:191,y:592,t:1512498318948};\\\", \\\"{x:190,y:592,t:1512498318978};\\\", \\\"{x:189,y:592,t:1512498319010};\\\", \\\"{x:188,y:592,t:1512498319018};\\\", \\\"{x:199,y:594,t:1512498320115};\\\", \\\"{x:256,y:604,t:1512498320131};\\\", \\\"{x:341,y:625,t:1512498320148};\\\", \\\"{x:452,y:643,t:1512498320165};\\\", \\\"{x:574,y:662,t:1512498320181};\\\", \\\"{x:694,y:683,t:1512498320198};\\\", \\\"{x:814,y:707,t:1512498320215};\\\", \\\"{x:926,y:730,t:1512498320231};\\\", \\\"{x:1023,y:753,t:1512498320248};\\\", \\\"{x:1128,y:784,t:1512498320265};\\\", \\\"{x:1170,y:795,t:1512498320281};\\\", \\\"{x:1191,y:798,t:1512498320298};\\\", \\\"{x:1208,y:803,t:1512498320315};\\\", \\\"{x:1226,y:804,t:1512498320331};\\\", \\\"{x:1241,y:806,t:1512498320348};\\\", \\\"{x:1260,y:806,t:1512498320365};\\\", \\\"{x:1284,y:807,t:1512498320381};\\\", \\\"{x:1312,y:807,t:1512498320398};\\\", \\\"{x:1346,y:807,t:1512498320415};\\\", \\\"{x:1385,y:807,t:1512498320432};\\\", \\\"{x:1424,y:807,t:1512498320448};\\\", \\\"{x:1459,y:807,t:1512498320466};\\\", \\\"{x:1469,y:807,t:1512498320482};\\\", \\\"{x:1472,y:807,t:1512498320499};\\\", \\\"{x:1473,y:807,t:1512498320538};\\\", \\\"{x:1473,y:804,t:1512498320562};\\\", \\\"{x:1471,y:802,t:1512498320570};\\\", \\\"{x:1469,y:799,t:1512498320583};\\\", \\\"{x:1458,y:795,t:1512498320599};\\\", \\\"{x:1443,y:792,t:1512498320616};\\\", \\\"{x:1427,y:789,t:1512498320633};\\\", \\\"{x:1415,y:788,t:1512498320649};\\\", \\\"{x:1401,y:788,t:1512498320666};\\\", \\\"{x:1392,y:788,t:1512498320682};\\\", \\\"{x:1387,y:786,t:1512498320699};\\\", \\\"{x:1383,y:784,t:1512498320716};\\\", \\\"{x:1381,y:782,t:1512498320733};\\\", \\\"{x:1380,y:781,t:1512498320749};\\\", \\\"{x:1379,y:781,t:1512498320851};\\\", \\\"{x:1377,y:780,t:1512498320866};\\\", \\\"{x:1376,y:779,t:1512498320883};\\\", \\\"{x:1372,y:777,t:1512498320900};\\\", \\\"{x:1369,y:777,t:1512498320916};\\\", \\\"{x:1363,y:773,t:1512498320933};\\\", \\\"{x:1356,y:771,t:1512498320950};\\\", \\\"{x:1351,y:769,t:1512498320966};\\\", \\\"{x:1345,y:769,t:1512498320983};\\\", \\\"{x:1342,y:767,t:1512498321000};\\\", \\\"{x:1338,y:767,t:1512498321015};\\\", \\\"{x:1336,y:767,t:1512498321032};\\\", \\\"{x:1335,y:767,t:1512498321162};\\\", \\\"{x:1333,y:767,t:1512498321177};\\\", \\\"{x:1332,y:767,t:1512498321226};\\\", \\\"{x:1330,y:767,t:1512498321283};\\\", \\\"{x:1329,y:767,t:1512498321314};\\\", \\\"{x:1327,y:766,t:1512498321330};\\\", \\\"{x:1325,y:765,t:1512498321349};\\\", \\\"{x:1324,y:765,t:1512498321366};\\\", \\\"{x:1323,y:765,t:1512498321382};\\\", \\\"{x:1322,y:765,t:1512498321399};\\\", \\\"{x:1321,y:765,t:1512498321416};\\\", \\\"{x:1320,y:765,t:1512498321434};\\\", \\\"{x:1319,y:765,t:1512498321450};\\\", \\\"{x:1318,y:765,t:1512498321466};\\\", \\\"{x:1316,y:765,t:1512498321627};\\\", \\\"{x:1315,y:766,t:1512498321642};\\\", \\\"{x:1313,y:766,t:1512498322441};\\\", \\\"{x:1311,y:766,t:1512498322450};\\\", \\\"{x:1304,y:765,t:1512498322466};\\\", \\\"{x:1301,y:763,t:1512498322483};\\\", \\\"{x:1296,y:760,t:1512498322500};\\\", \\\"{x:1293,y:758,t:1512498322516};\\\", \\\"{x:1290,y:757,t:1512498322533};\\\", \\\"{x:1290,y:756,t:1512498322550};\\\", \\\"{x:1288,y:756,t:1512498322566};\\\", \\\"{x:1288,y:755,t:1512498322706};\\\", \\\"{x:1288,y:754,t:1512498322718};\\\", \\\"{x:1288,y:753,t:1512498322734};\\\", \\\"{x:1288,y:752,t:1512498322754};\\\", \\\"{x:1288,y:751,t:1512498322778};\\\", \\\"{x:1288,y:749,t:1512498322803};\\\", \\\"{x:1288,y:748,t:1512498322826};\\\", \\\"{x:1288,y:747,t:1512498322834};\\\", \\\"{x:1288,y:744,t:1512498322851};\\\", \\\"{x:1288,y:741,t:1512498322868};\\\", \\\"{x:1288,y:737,t:1512498322884};\\\", \\\"{x:1289,y:733,t:1512498322901};\\\", \\\"{x:1289,y:725,t:1512498322918};\\\", \\\"{x:1289,y:717,t:1512498322934};\\\", \\\"{x:1289,y:708,t:1512498322951};\\\", \\\"{x:1288,y:706,t:1512498322968};\\\", \\\"{x:1288,y:705,t:1512498322984};\\\", \\\"{x:1287,y:703,t:1512498323001};\\\", \\\"{x:1286,y:699,t:1512498323017};\\\", \\\"{x:1284,y:693,t:1512498323033};\\\", \\\"{x:1282,y:688,t:1512498323050};\\\", \\\"{x:1280,y:680,t:1512498323067};\\\", \\\"{x:1278,y:677,t:1512498323084};\\\", \\\"{x:1278,y:674,t:1512498323100};\\\", \\\"{x:1276,y:671,t:1512498323117};\\\", \\\"{x:1274,y:669,t:1512498323153};\\\", \\\"{x:1273,y:666,t:1512498323167};\\\", \\\"{x:1268,y:659,t:1512498323184};\\\", \\\"{x:1266,y:656,t:1512498323200};\\\", \\\"{x:1264,y:651,t:1512498323217};\\\", \\\"{x:1263,y:648,t:1512498323234};\\\", \\\"{x:1262,y:645,t:1512498323250};\\\", \\\"{x:1262,y:641,t:1512498323267};\\\", \\\"{x:1262,y:638,t:1512498323284};\\\", \\\"{x:1262,y:636,t:1512498323300};\\\", \\\"{x:1262,y:635,t:1512498323317};\\\", \\\"{x:1262,y:634,t:1512498323386};\\\", \\\"{x:1261,y:632,t:1512498323482};\\\", \\\"{x:1260,y:632,t:1512498323501};\\\", \\\"{x:1259,y:631,t:1512498323517};\\\", \\\"{x:1258,y:631,t:1512498323534};\\\", \\\"{x:1255,y:631,t:1512498323551};\\\", \\\"{x:1252,y:631,t:1512498323567};\\\", \\\"{x:1251,y:631,t:1512498323585};\\\", \\\"{x:1250,y:631,t:1512498323603};\\\", \\\"{x:1248,y:629,t:1512498323618};\\\", \\\"{x:1246,y:629,t:1512498323642};\\\", \\\"{x:1245,y:629,t:1512498323652};\\\", \\\"{x:1244,y:629,t:1512498323668};\\\", \\\"{x:1244,y:628,t:1512498323685};\\\", \\\"{x:1243,y:628,t:1512498323962};\\\", \\\"{x:1243,y:629,t:1512498324178};\\\", \\\"{x:1242,y:629,t:1512498324922};\\\", \\\"{x:1239,y:629,t:1512498324978};\\\", \\\"{x:1239,y:628,t:1512498324986};\\\", \\\"{x:1237,y:625,t:1512498325003};\\\", \\\"{x:1233,y:620,t:1512498325019};\\\", \\\"{x:1230,y:612,t:1512498325036};\\\", \\\"{x:1227,y:609,t:1512498325053};\\\", \\\"{x:1225,y:606,t:1512498325069};\\\", \\\"{x:1223,y:603,t:1512498325086};\\\", \\\"{x:1222,y:602,t:1512498325103};\\\", \\\"{x:1220,y:601,t:1512498325119};\\\", \\\"{x:1219,y:600,t:1512498325136};\\\", \\\"{x:1219,y:598,t:1512498325153};\\\", \\\"{x:1217,y:594,t:1512498325169};\\\", \\\"{x:1216,y:591,t:1512498325186};\\\", \\\"{x:1215,y:587,t:1512498325203};\\\", \\\"{x:1215,y:586,t:1512498325219};\\\", \\\"{x:1214,y:584,t:1512498325236};\\\", \\\"{x:1214,y:582,t:1512498325253};\\\", \\\"{x:1214,y:581,t:1512498325314};\\\", \\\"{x:1214,y:580,t:1512498325354};\\\", \\\"{x:1214,y:578,t:1512498325370};\\\", \\\"{x:1214,y:577,t:1512498325386};\\\", \\\"{x:1214,y:575,t:1512498325403};\\\", \\\"{x:1216,y:571,t:1512498325420};\\\", \\\"{x:1217,y:570,t:1512498325436};\\\", \\\"{x:1217,y:569,t:1512498325453};\\\", \\\"{x:1218,y:568,t:1512498325470};\\\", \\\"{x:1218,y:567,t:1512498325486};\\\", \\\"{x:1219,y:567,t:1512498325514};\\\", \\\"{x:1220,y:566,t:1512498325562};\\\", \\\"{x:1220,y:565,t:1512498325578};\\\", \\\"{x:1221,y:565,t:1512498325586};\\\", \\\"{x:1221,y:564,t:1512498325603};\\\", \\\"{x:1221,y:563,t:1512498325620};\\\", \\\"{x:1221,y:562,t:1512498332723};\\\", \\\"{x:1221,y:559,t:1512498332730};\\\", \\\"{x:1221,y:557,t:1512498332743};\\\", \\\"{x:1221,y:552,t:1512498332758};\\\", \\\"{x:1221,y:546,t:1512498332775};\\\", \\\"{x:1221,y:541,t:1512498332792};\\\", \\\"{x:1220,y:539,t:1512498332808};\\\", \\\"{x:1220,y:538,t:1512498332825};\\\", \\\"{x:1220,y:536,t:1512498332842};\\\", \\\"{x:1220,y:535,t:1512498332858};\\\", \\\"{x:1220,y:532,t:1512498332875};\\\", \\\"{x:1220,y:530,t:1512498332892};\\\", \\\"{x:1220,y:525,t:1512498332909};\\\", \\\"{x:1220,y:519,t:1512498332925};\\\", \\\"{x:1220,y:506,t:1512498332942};\\\", \\\"{x:1220,y:492,t:1512498332959};\\\", \\\"{x:1224,y:478,t:1512498332975};\\\", \\\"{x:1227,y:466,t:1512498332992};\\\", \\\"{x:1230,y:459,t:1512498333009};\\\", \\\"{x:1230,y:453,t:1512498333026};\\\", \\\"{x:1231,y:449,t:1512498333042};\\\", \\\"{x:1232,y:448,t:1512498333066};\\\", \\\"{x:1232,y:447,t:1512498333083};\\\", \\\"{x:1232,y:446,t:1512498333092};\\\", \\\"{x:1232,y:445,t:1512498333109};\\\", \\\"{x:1232,y:441,t:1512498333125};\\\", \\\"{x:1232,y:440,t:1512498333142};\\\", \\\"{x:1232,y:437,t:1512498333159};\\\", \\\"{x:1232,y:436,t:1512498333185};\\\", \\\"{x:1232,y:435,t:1512498333290};\\\", \\\"{x:1232,y:434,t:1512498333298};\\\", \\\"{x:1232,y:432,t:1512498333314};\\\", \\\"{x:1232,y:431,t:1512498333330};\\\", \\\"{x:1231,y:431,t:1512498333343};\\\", \\\"{x:1230,y:429,t:1512498333360};\\\", \\\"{x:1230,y:428,t:1512498333377};\\\", \\\"{x:1229,y:428,t:1512498333393};\\\", \\\"{x:1228,y:428,t:1512498333411};\\\", \\\"{x:1227,y:428,t:1512498333426};\\\", \\\"{x:1226,y:428,t:1512498333443};\\\", \\\"{x:1225,y:428,t:1512498333459};\\\", \\\"{x:1223,y:428,t:1512498333477};\\\", \\\"{x:1221,y:428,t:1512498333514};\\\", \\\"{x:1220,y:429,t:1512498335682};\\\", \\\"{x:1219,y:429,t:1512498335695};\\\", \\\"{x:1210,y:435,t:1512498335713};\\\", \\\"{x:1196,y:447,t:1512498335728};\\\", \\\"{x:1182,y:460,t:1512498335745};\\\", \\\"{x:1169,y:474,t:1512498335762};\\\", \\\"{x:1153,y:494,t:1512498335778};\\\", \\\"{x:1148,y:501,t:1512498335795};\\\", \\\"{x:1144,y:506,t:1512498335812};\\\", \\\"{x:1142,y:509,t:1512498335828};\\\", \\\"{x:1141,y:511,t:1512498335845};\\\", \\\"{x:1140,y:512,t:1512498335862};\\\", \\\"{x:1138,y:516,t:1512498335878};\\\", \\\"{x:1137,y:522,t:1512498335895};\\\", \\\"{x:1136,y:526,t:1512498335912};\\\", \\\"{x:1134,y:530,t:1512498335928};\\\", \\\"{x:1133,y:534,t:1512498335945};\\\", \\\"{x:1131,y:539,t:1512498335962};\\\", \\\"{x:1129,y:543,t:1512498335978};\\\", \\\"{x:1128,y:547,t:1512498335995};\\\", \\\"{x:1127,y:548,t:1512498336012};\\\", \\\"{x:1126,y:550,t:1512498336029};\\\", \\\"{x:1125,y:551,t:1512498336045};\\\", \\\"{x:1124,y:553,t:1512498336062};\\\", \\\"{x:1122,y:554,t:1512498336079};\\\", \\\"{x:1118,y:557,t:1512498336095};\\\", \\\"{x:1113,y:559,t:1512498336112};\\\", \\\"{x:1110,y:562,t:1512498336129};\\\", \\\"{x:1106,y:562,t:1512498336145};\\\", \\\"{x:1103,y:564,t:1512498336162};\\\", \\\"{x:1102,y:565,t:1512498336179};\\\", \\\"{x:1101,y:565,t:1512498336195};\\\", \\\"{x:1100,y:565,t:1512498336218};\\\", \\\"{x:1099,y:565,t:1512498336234};\\\", \\\"{x:1097,y:565,t:1512498336250};\\\", \\\"{x:1096,y:565,t:1512498336266};\\\", \\\"{x:1095,y:565,t:1512498336419};\\\", \\\"{x:1094,y:565,t:1512498336434};\\\", \\\"{x:1093,y:565,t:1512498336445};\\\", \\\"{x:1092,y:565,t:1512498336482};\\\", \\\"{x:1091,y:565,t:1512498336496};\\\", \\\"{x:1089,y:565,t:1512498336511};\\\", \\\"{x:1088,y:565,t:1512498336528};\\\", \\\"{x:1086,y:565,t:1512498336545};\\\", \\\"{x:1085,y:565,t:1512498338186};\\\", \\\"{x:1085,y:564,t:1512498338394};\\\", \\\"{x:1087,y:564,t:1512498338434};\\\", \\\"{x:1089,y:562,t:1512498338482};\\\", \\\"{x:1090,y:562,t:1512498338522};\\\", \\\"{x:1091,y:562,t:1512498338546};\\\", \\\"{x:1092,y:562,t:1512498338563};\\\", \\\"{x:1093,y:561,t:1512498338580};\\\", \\\"{x:1092,y:561,t:1512498340106};\\\", \\\"{x:1088,y:561,t:1512498340114};\\\", \\\"{x:1075,y:561,t:1512498340132};\\\", \\\"{x:1055,y:561,t:1512498340148};\\\", \\\"{x:1033,y:561,t:1512498340165};\\\", \\\"{x:1009,y:561,t:1512498340182};\\\", \\\"{x:982,y:561,t:1512498340198};\\\", \\\"{x:955,y:561,t:1512498340215};\\\", \\\"{x:926,y:561,t:1512498340232};\\\", \\\"{x:900,y:561,t:1512498340248};\\\", \\\"{x:879,y:561,t:1512498340265};\\\", \\\"{x:855,y:561,t:1512498340282};\\\", \\\"{x:846,y:561,t:1512498340298};\\\", \\\"{x:842,y:560,t:1512498340315};\\\", \\\"{x:833,y:557,t:1512498340332};\\\", \\\"{x:807,y:546,t:1512498340348};\\\", \\\"{x:783,y:545,t:1512498340365};\\\", \\\"{x:757,y:544,t:1512498340381};\\\", \\\"{x:730,y:542,t:1512498340398};\\\", \\\"{x:700,y:542,t:1512498340415};\\\", \\\"{x:674,y:542,t:1512498340432};\\\", \\\"{x:655,y:540,t:1512498340449};\\\", \\\"{x:646,y:540,t:1512498340465};\\\", \\\"{x:632,y:537,t:1512498340482};\\\", \\\"{x:631,y:537,t:1512498340498};\\\", \\\"{x:626,y:536,t:1512498340515};\\\", \\\"{x:625,y:536,t:1512498340531};\\\", \\\"{x:619,y:532,t:1512498340922};\\\", \\\"{x:582,y:531,t:1512498340933};\\\", \\\"{x:536,y:531,t:1512498340948};\\\", \\\"{x:511,y:531,t:1512498340965};\\\", \\\"{x:509,y:531,t:1512498340985};\\\", \\\"{x:508,y:531,t:1512498340999};\\\", \\\"{x:497,y:532,t:1512498341015};\\\", \\\"{x:487,y:532,t:1512498341032};\\\", \\\"{x:474,y:532,t:1512498341049};\\\", \\\"{x:468,y:532,t:1512498341065};\\\", \\\"{x:462,y:532,t:1512498341082};\\\", \\\"{x:453,y:531,t:1512498341099};\\\", \\\"{x:451,y:531,t:1512498341115};\\\", \\\"{x:447,y:530,t:1512498341132};\\\", \\\"{x:444,y:530,t:1512498341149};\\\", \\\"{x:443,y:530,t:1512498341165};\\\", \\\"{x:440,y:530,t:1512498341182};\\\", \\\"{x:439,y:530,t:1512498341199};\\\", \\\"{x:436,y:530,t:1512498341215};\\\", \\\"{x:433,y:530,t:1512498341232};\\\", \\\"{x:427,y:530,t:1512498341249};\\\", \\\"{x:420,y:527,t:1512498341265};\\\", \\\"{x:413,y:527,t:1512498341282};\\\", \\\"{x:402,y:526,t:1512498341299};\\\", \\\"{x:391,y:525,t:1512498341315};\\\", \\\"{x:384,y:525,t:1512498341332};\\\", \\\"{x:379,y:525,t:1512498341349};\\\", \\\"{x:377,y:525,t:1512498341365};\\\", \\\"{x:375,y:526,t:1512498341385};\\\", \\\"{x:377,y:527,t:1512498341506};\\\", \\\"{x:379,y:528,t:1512498341522};\\\", \\\"{x:380,y:529,t:1512498341532};\\\", \\\"{x:383,y:530,t:1512498341549};\\\", \\\"{x:384,y:530,t:1512498341594};\\\", \\\"{x:385,y:530,t:1512498341618};\\\", \\\"{x:386,y:530,t:1512498341634};\\\", \\\"{x:387,y:530,t:1512498341658};\\\", \\\"{x:388,y:530,t:1512498341666};\\\", \\\"{x:389,y:530,t:1512498341690};\\\", \\\"{x:391,y:530,t:1512498341722};\\\", \\\"{x:394,y:528,t:1512498341746};\\\", \\\"{x:395,y:528,t:1512498341754};\\\", \\\"{x:396,y:528,t:1512498341766};\\\", \\\"{x:399,y:528,t:1512498341783};\\\", \\\"{x:400,y:528,t:1512498341799};\\\", \\\"{x:402,y:528,t:1512498341858};\\\", \\\"{x:403,y:532,t:1512498342145};\\\", \\\"{x:405,y:540,t:1512498342153};\\\", \\\"{x:410,y:551,t:1512498342166};\\\", \\\"{x:414,y:567,t:1512498342183};\\\", \\\"{x:418,y:581,t:1512498342199};\\\", \\\"{x:421,y:592,t:1512498342216};\\\", \\\"{x:430,y:607,t:1512498342233};\\\", \\\"{x:435,y:617,t:1512498342249};\\\", \\\"{x:439,y:625,t:1512498342266};\\\", \\\"{x:443,y:633,t:1512498342283};\\\", \\\"{x:445,y:640,t:1512498342300};\\\", \\\"{x:447,y:644,t:1512498342316};\\\", \\\"{x:447,y:646,t:1512498342333};\\\", \\\"{x:447,y:649,t:1512498342350};\\\", \\\"{x:448,y:649,t:1512498342366};\\\", \\\"{x:448,y:650,t:1512498342383};\\\", \\\"{x:448,y:652,t:1512498342400};\\\", \\\"{x:449,y:653,t:1512498342416};\\\", \\\"{x:450,y:653,t:1512498342433};\\\", \\\"{x:450,y:654,t:1512498342466};\\\", \\\"{x:450,y:657,t:1512498342483};\\\", \\\"{x:451,y:662,t:1512498342500};\\\", \\\"{x:451,y:669,t:1512498342516};\\\", \\\"{x:451,y:674,t:1512498342533};\\\", \\\"{x:451,y:678,t:1512498342551};\\\", \\\"{x:451,y:680,t:1512498342567};\\\", \\\"{x:450,y:680,t:1512498343634};\\\", \\\"{x:449,y:680,t:1512498343651};\\\", \\\"{x:448,y:680,t:1512498343667};\\\", \\\"{x:447,y:679,t:1512498343684};\\\" ] }, { \\\"rt\\\": 17375, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 797092, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:447,y:678,t:1512498344585};\\\", \\\"{x:446,y:677,t:1512498344602};\\\", \\\"{x:446,y:675,t:1512498344622};\\\", \\\"{x:445,y:675,t:1512498344638};\\\", \\\"{x:445,y:674,t:1512498344756};\\\", \\\"{x:444,y:672,t:1512498344772};\\\", \\\"{x:443,y:669,t:1512498344788};\\\", \\\"{x:443,y:665,t:1512498344804};\\\", \\\"{x:443,y:661,t:1512498344821};\\\", \\\"{x:443,y:656,t:1512498344838};\\\", \\\"{x:443,y:649,t:1512498344854};\\\", \\\"{x:443,y:643,t:1512498344871};\\\", \\\"{x:443,y:638,t:1512498344888};\\\", \\\"{x:443,y:634,t:1512498344905};\\\", \\\"{x:443,y:630,t:1512498344921};\\\", \\\"{x:443,y:626,t:1512498344938};\\\", \\\"{x:443,y:623,t:1512498344955};\\\", \\\"{x:443,y:621,t:1512498344971};\\\", \\\"{x:443,y:617,t:1512498344988};\\\", \\\"{x:442,y:616,t:1512498345012};\\\", \\\"{x:441,y:616,t:1512498345221};\\\", \\\"{x:440,y:616,t:1512498345238};\\\", \\\"{x:439,y:616,t:1512498345260};\\\", \\\"{x:439,y:615,t:1512498345300};\\\", \\\"{x:438,y:614,t:1512498350021};\\\", \\\"{x:437,y:614,t:1512498350036};\\\", \\\"{x:436,y:614,t:1512498350068};\\\", \\\"{x:435,y:614,t:1512498350133};\\\", \\\"{x:434,y:614,t:1512498350149};\\\", \\\"{x:433,y:614,t:1512498350159};\\\", \\\"{x:432,y:614,t:1512498350189};\\\", \\\"{x:431,y:614,t:1512498350197};\\\", \\\"{x:431,y:615,t:1512498350213};\\\", \\\"{x:430,y:615,t:1512498350226};\\\", \\\"{x:427,y:615,t:1512498355038};\\\", \\\"{x:426,y:615,t:1512498355046};\\\", \\\"{x:423,y:618,t:1512498355062};\\\", \\\"{x:421,y:618,t:1512498355079};\\\", \\\"{x:416,y:620,t:1512498355095};\\\", \\\"{x:415,y:620,t:1512498355117};\\\", \\\"{x:414,y:620,t:1512498358693};\\\", \\\"{x:413,y:620,t:1512498358709};\\\", \\\"{x:413,y:619,t:1512498358717};\\\", \\\"{x:411,y:618,t:1512498359429};\\\", \\\"{x:411,y:617,t:1512498359437};\\\", \\\"{x:411,y:616,t:1512498359448};\\\", \\\"{x:411,y:614,t:1512498359466};\\\", \\\"{x:411,y:611,t:1512498359482};\\\", \\\"{x:410,y:608,t:1512498359499};\\\", \\\"{x:410,y:607,t:1512498359515};\\\", \\\"{x:410,y:606,t:1512498359531};\\\", \\\"{x:410,y:604,t:1512498359548};\\\", \\\"{x:411,y:602,t:1512498359565};\\\", \\\"{x:413,y:599,t:1512498359581};\\\", \\\"{x:414,y:597,t:1512498359599};\\\", \\\"{x:417,y:592,t:1512498359615};\\\", \\\"{x:419,y:587,t:1512498359631};\\\", \\\"{x:430,y:579,t:1512498359648};\\\", \\\"{x:441,y:571,t:1512498359666};\\\", \\\"{x:457,y:564,t:1512498359682};\\\", \\\"{x:474,y:554,t:1512498359699};\\\", \\\"{x:487,y:548,t:1512498359716};\\\", \\\"{x:498,y:542,t:1512498359733};\\\", \\\"{x:505,y:541,t:1512498359748};\\\", \\\"{x:508,y:540,t:1512498359766};\\\", \\\"{x:509,y:540,t:1512498359782};\\\", \\\"{x:511,y:540,t:1512498359799};\\\", \\\"{x:512,y:540,t:1512498359861};\\\", \\\"{x:515,y:540,t:1512498359869};\\\", \\\"{x:521,y:540,t:1512498359882};\\\", \\\"{x:541,y:540,t:1512498359898};\\\", \\\"{x:568,y:540,t:1512498359915};\\\", \\\"{x:607,y:535,t:1512498359933};\\\", \\\"{x:625,y:534,t:1512498359949};\\\", \\\"{x:636,y:532,t:1512498359966};\\\", \\\"{x:640,y:531,t:1512498359998};\\\", \\\"{x:641,y:531,t:1512498360140};\\\", \\\"{x:641,y:532,t:1512498360164};\\\", \\\"{x:640,y:532,t:1512498360172};\\\", \\\"{x:639,y:532,t:1512498360183};\\\", \\\"{x:635,y:534,t:1512498360199};\\\", \\\"{x:634,y:535,t:1512498360216};\\\", \\\"{x:633,y:535,t:1512498360292};\\\", \\\"{x:631,y:536,t:1512498360300};\\\", \\\"{x:630,y:537,t:1512498360324};\\\", \\\"{x:629,y:537,t:1512498360341};\\\", \\\"{x:629,y:538,t:1512498360356};\\\", \\\"{x:628,y:538,t:1512498360437};\\\", \\\"{x:628,y:537,t:1512498360452};\\\", \\\"{x:627,y:535,t:1512498360468};\\\", \\\"{x:626,y:533,t:1512498360484};\\\", \\\"{x:625,y:531,t:1512498360502};\\\", \\\"{x:625,y:530,t:1512498360557};\\\", \\\"{x:625,y:529,t:1512498360597};\\\", \\\"{x:622,y:528,t:1512498360852};\\\", \\\"{x:606,y:535,t:1512498360868};\\\", \\\"{x:589,y:545,t:1512498360885};\\\", \\\"{x:567,y:558,t:1512498360901};\\\", \\\"{x:547,y:573,t:1512498360918};\\\", \\\"{x:534,y:584,t:1512498360935};\\\", \\\"{x:522,y:593,t:1512498360951};\\\", \\\"{x:515,y:597,t:1512498360968};\\\", \\\"{x:510,y:599,t:1512498360985};\\\", \\\"{x:506,y:602,t:1512498361001};\\\", \\\"{x:502,y:605,t:1512498361018};\\\", \\\"{x:498,y:608,t:1512498361035};\\\", \\\"{x:496,y:610,t:1512498361051};\\\", \\\"{x:491,y:617,t:1512498361068};\\\", \\\"{x:488,y:622,t:1512498361085};\\\", \\\"{x:483,y:628,t:1512498361101};\\\", \\\"{x:475,y:635,t:1512498361118};\\\", \\\"{x:471,y:642,t:1512498361135};\\\", \\\"{x:467,y:649,t:1512498361152};\\\", \\\"{x:464,y:656,t:1512498361168};\\\", \\\"{x:461,y:664,t:1512498361185};\\\", \\\"{x:460,y:668,t:1512498361202};\\\", \\\"{x:459,y:673,t:1512498361218};\\\", \\\"{x:457,y:676,t:1512498361236};\\\", \\\"{x:453,y:680,t:1512498361252};\\\", \\\"{x:452,y:681,t:1512498361268};\\\", \\\"{x:448,y:683,t:1512498361285};\\\", \\\"{x:447,y:683,t:1512498361302};\\\", \\\"{x:445,y:683,t:1512498361319};\\\", \\\"{x:444,y:683,t:1512498361404};\\\" ] }, { \\\"rt\\\": 36372, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 834766, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-3-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:442,y:682,t:1512498362881};\\\", \\\"{x:442,y:681,t:1512498369246};\\\", \\\"{x:450,y:677,t:1512498369260};\\\", \\\"{x:472,y:671,t:1512498369276};\\\", \\\"{x:508,y:667,t:1512498369292};\\\", \\\"{x:539,y:667,t:1512498369308};\\\", \\\"{x:584,y:667,t:1512498369325};\\\", \\\"{x:632,y:667,t:1512498369342};\\\", \\\"{x:682,y:667,t:1512498369359};\\\", \\\"{x:751,y:675,t:1512498369375};\\\", \\\"{x:814,y:686,t:1512498369392};\\\", \\\"{x:878,y:705,t:1512498369409};\\\", \\\"{x:945,y:725,t:1512498369425};\\\", \\\"{x:1006,y:742,t:1512498369442};\\\", \\\"{x:1059,y:758,t:1512498369459};\\\", \\\"{x:1104,y:771,t:1512498369476};\\\", \\\"{x:1144,y:786,t:1512498369492};\\\", \\\"{x:1197,y:820,t:1512498369509};\\\", \\\"{x:1233,y:851,t:1512498369526};\\\", \\\"{x:1269,y:881,t:1512498369543};\\\", \\\"{x:1298,y:917,t:1512498369559};\\\", \\\"{x:1314,y:932,t:1512498369576};\\\", \\\"{x:1320,y:939,t:1512498369592};\\\", \\\"{x:1321,y:942,t:1512498369609};\\\", \\\"{x:1322,y:943,t:1512498369629};\\\", \\\"{x:1323,y:944,t:1512498369645};\\\", \\\"{x:1324,y:945,t:1512498369660};\\\", \\\"{x:1327,y:950,t:1512498369676};\\\", \\\"{x:1330,y:954,t:1512498369693};\\\", \\\"{x:1333,y:957,t:1512498369710};\\\", \\\"{x:1332,y:957,t:1512498369822};\\\", \\\"{x:1329,y:957,t:1512498369829};\\\", \\\"{x:1324,y:956,t:1512498369843};\\\", \\\"{x:1319,y:954,t:1512498369860};\\\", \\\"{x:1313,y:953,t:1512498369877};\\\", \\\"{x:1307,y:953,t:1512498369893};\\\", \\\"{x:1303,y:953,t:1512498369910};\\\", \\\"{x:1302,y:953,t:1512498369933};\\\", \\\"{x:1300,y:953,t:1512498369957};\\\", \\\"{x:1299,y:953,t:1512498369981};\\\", \\\"{x:1297,y:953,t:1512498369997};\\\", \\\"{x:1296,y:954,t:1512498370010};\\\", \\\"{x:1293,y:954,t:1512498370027};\\\", \\\"{x:1289,y:954,t:1512498370044};\\\", \\\"{x:1285,y:954,t:1512498370060};\\\", \\\"{x:1281,y:954,t:1512498370077};\\\", \\\"{x:1279,y:954,t:1512498370093};\\\", \\\"{x:1278,y:954,t:1512498370110};\\\", \\\"{x:1277,y:954,t:1512498370127};\\\", \\\"{x:1276,y:955,t:1512498370144};\\\", \\\"{x:1277,y:955,t:1512498370238};\\\", \\\"{x:1278,y:955,t:1512498370245};\\\", \\\"{x:1279,y:956,t:1512498370260};\\\", \\\"{x:1282,y:956,t:1512498370277};\\\", \\\"{x:1283,y:957,t:1512498370301};\\\", \\\"{x:1284,y:957,t:1512498370630};\\\", \\\"{x:1285,y:957,t:1512498370686};\\\", \\\"{x:1286,y:957,t:1512498370838};\\\", \\\"{x:1287,y:957,t:1512498370862};\\\", \\\"{x:1288,y:957,t:1512498370885};\\\", \\\"{x:1289,y:957,t:1512498370917};\\\", \\\"{x:1291,y:957,t:1512498370966};\\\", \\\"{x:1293,y:956,t:1512498370989};\\\", \\\"{x:1293,y:955,t:1512498370997};\\\", \\\"{x:1294,y:955,t:1512498371011};\\\", \\\"{x:1294,y:954,t:1512498371028};\\\", \\\"{x:1295,y:954,t:1512498371886};\\\", \\\"{x:1295,y:955,t:1512498372070};\\\", \\\"{x:1295,y:956,t:1512498372085};\\\", \\\"{x:1295,y:957,t:1512498372095};\\\", \\\"{x:1294,y:957,t:1512498372238};\\\", \\\"{x:1294,y:958,t:1512498372245};\\\", \\\"{x:1293,y:958,t:1512498372269};\\\", \\\"{x:1292,y:958,t:1512498372293};\\\", \\\"{x:1291,y:958,t:1512498372317};\\\", \\\"{x:1291,y:959,t:1512498372382};\\\", \\\"{x:1290,y:959,t:1512498372446};\\\", \\\"{x:1279,y:959,t:1512498384766};\\\", \\\"{x:1264,y:953,t:1512498384773};\\\", \\\"{x:1246,y:944,t:1512498384789};\\\", \\\"{x:1116,y:856,t:1512498384806};\\\", \\\"{x:975,y:762,t:1512498384822};\\\", \\\"{x:839,y:689,t:1512498384839};\\\", \\\"{x:728,y:641,t:1512498384856};\\\", \\\"{x:641,y:610,t:1512498384872};\\\", \\\"{x:591,y:594,t:1512498384889};\\\", \\\"{x:563,y:586,t:1512498384906};\\\", \\\"{x:548,y:579,t:1512498384921};\\\", \\\"{x:541,y:576,t:1512498384939};\\\", \\\"{x:539,y:571,t:1512498384956};\\\", \\\"{x:538,y:569,t:1512498384972};\\\", \\\"{x:537,y:569,t:1512498384997};\\\", \\\"{x:536,y:567,t:1512498385013};\\\", \\\"{x:535,y:567,t:1512498385062};\\\", \\\"{x:534,y:567,t:1512498385072};\\\", \\\"{x:534,y:565,t:1512498385108};\\\", \\\"{x:533,y:564,t:1512498385124};\\\", \\\"{x:531,y:564,t:1512498385138};\\\", \\\"{x:528,y:562,t:1512498385155};\\\", \\\"{x:525,y:559,t:1512498385172};\\\", \\\"{x:519,y:557,t:1512498385188};\\\", \\\"{x:513,y:553,t:1512498385205};\\\", \\\"{x:508,y:552,t:1512498385222};\\\", \\\"{x:506,y:552,t:1512498385238};\\\", \\\"{x:506,y:550,t:1512498385389};\\\", \\\"{x:508,y:548,t:1512498385406};\\\", \\\"{x:513,y:546,t:1512498385423};\\\", \\\"{x:515,y:545,t:1512498385439};\\\", \\\"{x:516,y:545,t:1512498385456};\\\", \\\"{x:517,y:545,t:1512498385917};\\\", \\\"{x:518,y:545,t:1512498385924};\\\", \\\"{x:519,y:545,t:1512498385939};\\\", \\\"{x:526,y:548,t:1512498385956};\\\", \\\"{x:549,y:568,t:1512498385973};\\\", \\\"{x:579,y:589,t:1512498385990};\\\", \\\"{x:619,y:617,t:1512498386006};\\\", \\\"{x:655,y:640,t:1512498386023};\\\", \\\"{x:698,y:663,t:1512498386040};\\\", \\\"{x:751,y:688,t:1512498386056};\\\", \\\"{x:800,y:707,t:1512498386073};\\\", \\\"{x:845,y:728,t:1512498386090};\\\", \\\"{x:887,y:741,t:1512498386106};\\\", \\\"{x:925,y:748,t:1512498386123};\\\", \\\"{x:955,y:755,t:1512498386140};\\\", \\\"{x:984,y:759,t:1512498386157};\\\", \\\"{x:1021,y:762,t:1512498386173};\\\", \\\"{x:1037,y:762,t:1512498386191};\\\", \\\"{x:1045,y:762,t:1512498386207};\\\", \\\"{x:1046,y:762,t:1512498386223};\\\", \\\"{x:1048,y:762,t:1512498386241};\\\", \\\"{x:1050,y:761,t:1512498386257};\\\", \\\"{x:1051,y:761,t:1512498386273};\\\", \\\"{x:1052,y:761,t:1512498386291};\\\", \\\"{x:1055,y:759,t:1512498386308};\\\", \\\"{x:1058,y:756,t:1512498386323};\\\", \\\"{x:1063,y:752,t:1512498386340};\\\", \\\"{x:1067,y:749,t:1512498386356};\\\", \\\"{x:1077,y:738,t:1512498386374};\\\", \\\"{x:1087,y:732,t:1512498386390};\\\", \\\"{x:1096,y:726,t:1512498386407};\\\", \\\"{x:1103,y:722,t:1512498386423};\\\", \\\"{x:1106,y:721,t:1512498386440};\\\", \\\"{x:1109,y:718,t:1512498386457};\\\", \\\"{x:1111,y:718,t:1512498386473};\\\", \\\"{x:1115,y:715,t:1512498386491};\\\", \\\"{x:1117,y:715,t:1512498386508};\\\", \\\"{x:1119,y:714,t:1512498386524};\\\", \\\"{x:1122,y:710,t:1512498386541};\\\", \\\"{x:1125,y:707,t:1512498386557};\\\", \\\"{x:1129,y:705,t:1512498386581};\\\", \\\"{x:1131,y:704,t:1512498386605};\\\", \\\"{x:1133,y:703,t:1512498386613};\\\", \\\"{x:1134,y:703,t:1512498386624};\\\", \\\"{x:1136,y:703,t:1512498386641};\\\", \\\"{x:1139,y:701,t:1512498386658};\\\", \\\"{x:1141,y:700,t:1512498386674};\\\", \\\"{x:1142,y:699,t:1512498386691};\\\", \\\"{x:1144,y:698,t:1512498386708};\\\", \\\"{x:1145,y:697,t:1512498386724};\\\", \\\"{x:1146,y:696,t:1512498386741};\\\", \\\"{x:1147,y:695,t:1512498386758};\\\", \\\"{x:1149,y:694,t:1512498386775};\\\", \\\"{x:1150,y:693,t:1512498386797};\\\", \\\"{x:1152,y:693,t:1512498386969};\\\", \\\"{x:1156,y:694,t:1512498386975};\\\", \\\"{x:1165,y:706,t:1512498386990};\\\", \\\"{x:1177,y:718,t:1512498387007};\\\", \\\"{x:1192,y:728,t:1512498387024};\\\", \\\"{x:1203,y:736,t:1512498387040};\\\", \\\"{x:1214,y:743,t:1512498387057};\\\", \\\"{x:1220,y:746,t:1512498387074};\\\", \\\"{x:1224,y:747,t:1512498387090};\\\", \\\"{x:1225,y:747,t:1512498387108};\\\", \\\"{x:1225,y:748,t:1512498387124};\\\", \\\"{x:1228,y:750,t:1512498387140};\\\", \\\"{x:1233,y:753,t:1512498387157};\\\", \\\"{x:1238,y:758,t:1512498387174};\\\", \\\"{x:1244,y:763,t:1512498387191};\\\", \\\"{x:1250,y:768,t:1512498387207};\\\", \\\"{x:1252,y:770,t:1512498387225};\\\", \\\"{x:1254,y:773,t:1512498387241};\\\", \\\"{x:1256,y:777,t:1512498387257};\\\", \\\"{x:1258,y:781,t:1512498387274};\\\", \\\"{x:1260,y:786,t:1512498387291};\\\", \\\"{x:1261,y:790,t:1512498387307};\\\", \\\"{x:1264,y:796,t:1512498387324};\\\", \\\"{x:1266,y:814,t:1512498387341};\\\", \\\"{x:1269,y:831,t:1512498387357};\\\", \\\"{x:1271,y:854,t:1512498387374};\\\", \\\"{x:1271,y:871,t:1512498387392};\\\", \\\"{x:1271,y:886,t:1512498387408};\\\", \\\"{x:1271,y:900,t:1512498387425};\\\", \\\"{x:1271,y:906,t:1512498387442};\\\", \\\"{x:1271,y:908,t:1512498387458};\\\", \\\"{x:1271,y:910,t:1512498387474};\\\", \\\"{x:1273,y:914,t:1512498387492};\\\", \\\"{x:1273,y:915,t:1512498387508};\\\", \\\"{x:1274,y:918,t:1512498387525};\\\", \\\"{x:1276,y:923,t:1512498387541};\\\", \\\"{x:1278,y:927,t:1512498387559};\\\", \\\"{x:1278,y:929,t:1512498387575};\\\", \\\"{x:1281,y:933,t:1512498387592};\\\", \\\"{x:1281,y:934,t:1512498387608};\\\", \\\"{x:1281,y:935,t:1512498387626};\\\", \\\"{x:1281,y:937,t:1512498387642};\\\", \\\"{x:1281,y:938,t:1512498387718};\\\", \\\"{x:1281,y:940,t:1512498387733};\\\", \\\"{x:1281,y:941,t:1512498387742};\\\", \\\"{x:1281,y:944,t:1512498387759};\\\", \\\"{x:1281,y:947,t:1512498387775};\\\", \\\"{x:1281,y:949,t:1512498387792};\\\", \\\"{x:1281,y:951,t:1512498387809};\\\", \\\"{x:1281,y:952,t:1512498387942};\\\", \\\"{x:1281,y:953,t:1512498387965};\\\", \\\"{x:1282,y:954,t:1512498388118};\\\", \\\"{x:1283,y:955,t:1512498388141};\\\", \\\"{x:1284,y:955,t:1512498388159};\\\", \\\"{x:1284,y:956,t:1512498388176};\\\", \\\"{x:1285,y:957,t:1512498388192};\\\", \\\"{x:1286,y:957,t:1512498388262};\\\", \\\"{x:1287,y:957,t:1512498388285};\\\", \\\"{x:1288,y:957,t:1512498388334};\\\", \\\"{x:1289,y:957,t:1512498388349};\\\", \\\"{x:1290,y:957,t:1512498388359};\\\", \\\"{x:1288,y:956,t:1512498397021};\\\", \\\"{x:1283,y:953,t:1512498397033};\\\", \\\"{x:1274,y:947,t:1512498397050};\\\", \\\"{x:1261,y:936,t:1512498397066};\\\", \\\"{x:1246,y:924,t:1512498397083};\\\", \\\"{x:1234,y:912,t:1512498397100};\\\", \\\"{x:1212,y:893,t:1512498397116};\\\", \\\"{x:1183,y:865,t:1512498397133};\\\", \\\"{x:1161,y:840,t:1512498397149};\\\", \\\"{x:1129,y:808,t:1512498397166};\\\", \\\"{x:1096,y:779,t:1512498397183};\\\", \\\"{x:1069,y:757,t:1512498397200};\\\", \\\"{x:1042,y:736,t:1512498397216};\\\", \\\"{x:1024,y:718,t:1512498397233};\\\", \\\"{x:1009,y:702,t:1512498397250};\\\", \\\"{x:999,y:691,t:1512498397266};\\\", \\\"{x:990,y:680,t:1512498397285};\\\", \\\"{x:985,y:672,t:1512498397299};\\\", \\\"{x:980,y:657,t:1512498397315};\\\", \\\"{x:970,y:625,t:1512498397332};\\\", \\\"{x:957,y:583,t:1512498397349};\\\", \\\"{x:948,y:552,t:1512498397366};\\\", \\\"{x:943,y:532,t:1512498397382};\\\", \\\"{x:931,y:514,t:1512498397399};\\\", \\\"{x:916,y:500,t:1512498397416};\\\", \\\"{x:890,y:497,t:1512498397432};\\\", \\\"{x:860,y:497,t:1512498397449};\\\", \\\"{x:809,y:498,t:1512498397466};\\\", \\\"{x:753,y:506,t:1512498397482};\\\", \\\"{x:696,y:519,t:1512498397499};\\\", \\\"{x:574,y:534,t:1512498397516};\\\", \\\"{x:552,y:541,t:1512498397532};\\\", \\\"{x:528,y:553,t:1512498397549};\\\", \\\"{x:507,y:560,t:1512498397566};\\\", \\\"{x:486,y:568,t:1512498397582};\\\", \\\"{x:462,y:572,t:1512498397599};\\\", \\\"{x:448,y:577,t:1512498397616};\\\", \\\"{x:438,y:580,t:1512498397632};\\\", \\\"{x:434,y:580,t:1512498397649};\\\", \\\"{x:436,y:579,t:1512498397757};\\\", \\\"{x:439,y:575,t:1512498397767};\\\", \\\"{x:448,y:571,t:1512498397783};\\\", \\\"{x:457,y:565,t:1512498397800};\\\", \\\"{x:472,y:559,t:1512498397817};\\\", \\\"{x:486,y:557,t:1512498397834};\\\", \\\"{x:502,y:557,t:1512498397849};\\\", \\\"{x:516,y:557,t:1512498397866};\\\", \\\"{x:526,y:557,t:1512498397884};\\\", \\\"{x:530,y:557,t:1512498397900};\\\", \\\"{x:531,y:557,t:1512498397917};\\\", \\\"{x:529,y:557,t:1512498397957};\\\", \\\"{x:526,y:557,t:1512498397967};\\\", \\\"{x:517,y:558,t:1512498397984};\\\", \\\"{x:509,y:558,t:1512498398000};\\\", \\\"{x:499,y:558,t:1512498398017};\\\", \\\"{x:484,y:558,t:1512498398034};\\\", \\\"{x:470,y:558,t:1512498398050};\\\", \\\"{x:462,y:558,t:1512498398067};\\\", \\\"{x:454,y:558,t:1512498398084};\\\", \\\"{x:453,y:558,t:1512498398100};\\\", \\\"{x:450,y:558,t:1512498398116};\\\", \\\"{x:448,y:558,t:1512498398140};\\\", \\\"{x:448,y:557,t:1512498398156};\\\", \\\"{x:447,y:555,t:1512498398167};\\\", \\\"{x:446,y:554,t:1512498398183};\\\", \\\"{x:442,y:552,t:1512498398201};\\\", \\\"{x:434,y:549,t:1512498398217};\\\", \\\"{x:427,y:549,t:1512498398233};\\\", \\\"{x:420,y:549,t:1512498398250};\\\", \\\"{x:412,y:549,t:1512498398266};\\\", \\\"{x:408,y:549,t:1512498398283};\\\", \\\"{x:407,y:549,t:1512498398300};\\\", \\\"{x:405,y:549,t:1512498398316};\\\", \\\"{x:404,y:552,t:1512498398685};\\\", \\\"{x:404,y:559,t:1512498398700};\\\", \\\"{x:406,y:589,t:1512498398717};\\\", \\\"{x:409,y:602,t:1512498398734};\\\", \\\"{x:416,y:618,t:1512498398750};\\\", \\\"{x:422,y:633,t:1512498398767};\\\", \\\"{x:427,y:644,t:1512498398783};\\\", \\\"{x:430,y:655,t:1512498398801};\\\", \\\"{x:431,y:664,t:1512498398817};\\\", \\\"{x:431,y:668,t:1512498398833};\\\", \\\"{x:432,y:672,t:1512498398850};\\\", \\\"{x:432,y:673,t:1512498398866};\\\", \\\"{x:433,y:674,t:1512498398883};\\\", \\\"{x:434,y:676,t:1512498398900};\\\", \\\"{x:434,y:678,t:1512498398924};\\\", \\\"{x:434,y:679,t:1512498398933};\\\", \\\"{x:434,y:682,t:1512498398950};\\\", \\\"{x:435,y:685,t:1512498398966};\\\", \\\"{x:435,y:688,t:1512498398983};\\\", \\\"{x:435,y:689,t:1512498399005};\\\", \\\"{x:435,y:691,t:1512498399020};\\\", \\\"{x:435,y:692,t:1512498399033};\\\", \\\"{x:435,y:694,t:1512498399050};\\\", \\\"{x:435,y:696,t:1512498399067};\\\", \\\"{x:435,y:698,t:1512498399083};\\\", \\\"{x:435,y:700,t:1512498399100};\\\", \\\"{x:435,y:698,t:1512498400757};\\\", \\\"{x:437,y:693,t:1512498400768};\\\", \\\"{x:451,y:679,t:1512498400784};\\\", \\\"{x:474,y:658,t:1512498400801};\\\", \\\"{x:517,y:629,t:1512498400818};\\\", \\\"{x:561,y:600,t:1512498400834};\\\", \\\"{x:613,y:570,t:1512498400851};\\\", \\\"{x:689,y:545,t:1512498400867};\\\", \\\"{x:737,y:539,t:1512498400884};\\\", \\\"{x:770,y:539,t:1512498400901};\\\", \\\"{x:799,y:540,t:1512498400918};\\\", \\\"{x:832,y:549,t:1512498400934};\\\", \\\"{x:860,y:556,t:1512498400951};\\\", \\\"{x:883,y:559,t:1512498400968};\\\", \\\"{x:902,y:563,t:1512498400984};\\\", \\\"{x:917,y:565,t:1512498401001};\\\", \\\"{x:920,y:565,t:1512498401018};\\\", \\\"{x:921,y:566,t:1512498401035};\\\", \\\"{x:926,y:572,t:1512498401051};\\\", \\\"{x:934,y:581,t:1512498401068};\\\", \\\"{x:938,y:584,t:1512498401085};\\\", \\\"{x:940,y:585,t:1512498401101};\\\", \\\"{x:941,y:585,t:1512498401285};\\\", \\\"{x:941,y:584,t:1512498401332};\\\", \\\"{x:941,y:582,t:1512498401356};\\\", \\\"{x:941,y:581,t:1512498401372};\\\", \\\"{x:941,y:579,t:1512498401385};\\\", \\\"{x:940,y:578,t:1512498401402};\\\", \\\"{x:940,y:577,t:1512498401557};\\\", \\\"{x:938,y:573,t:1512498401569};\\\", \\\"{x:937,y:570,t:1512498401585};\\\", \\\"{x:935,y:566,t:1512498401602};\\\", \\\"{x:934,y:565,t:1512498401619};\\\", \\\"{x:934,y:567,t:1512498403686};\\\", \\\"{x:934,y:570,t:1512498403693};\\\", \\\"{x:937,y:577,t:1512498403705};\\\", \\\"{x:947,y:593,t:1512498403721};\\\", \\\"{x:957,y:614,t:1512498403738};\\\", \\\"{x:966,y:630,t:1512498403755};\\\", \\\"{x:973,y:644,t:1512498403771};\\\", \\\"{x:976,y:652,t:1512498403789};\\\", \\\"{x:977,y:659,t:1512498403804};\\\", \\\"{x:978,y:661,t:1512498403821};\\\", \\\"{x:978,y:662,t:1512498403844};\\\", \\\"{x:978,y:663,t:1512498403855};\\\", \\\"{x:978,y:664,t:1512498403871};\\\", \\\"{x:979,y:665,t:1512498408687};\\\", \\\"{x:980,y:665,t:1512498408799};\\\", \\\"{x:980,y:666,t:1512498408811};\\\", \\\"{x:978,y:668,t:1512498408828};\\\", \\\"{x:976,y:670,t:1512498408844};\\\", \\\"{x:976,y:672,t:1512498408861};\\\", \\\"{x:976,y:673,t:1512498408877};\\\", \\\"{x:976,y:674,t:1512498408895};\\\", \\\"{x:976,y:675,t:1512498408911};\\\", \\\"{x:976,y:676,t:1512498408928};\\\", \\\"{x:976,y:677,t:1512498408951};\\\", \\\"{x:976,y:678,t:1512498408967};\\\", \\\"{x:977,y:678,t:1512498408999};\\\", \\\"{x:977,y:679,t:1512498409079};\\\", \\\"{x:978,y:681,t:1512498409095};\\\", \\\"{x:979,y:685,t:1512498409111};\\\", \\\"{x:980,y:688,t:1512498409127};\\\", \\\"{x:980,y:687,t:1512498411119};\\\", \\\"{x:981,y:680,t:1512498411130};\\\", \\\"{x:985,y:665,t:1512498411145};\\\", \\\"{x:986,y:645,t:1512498411162};\\\", \\\"{x:998,y:606,t:1512498411179};\\\", \\\"{x:1010,y:559,t:1512498411196};\\\", \\\"{x:1014,y:527,t:1512498411212};\\\", \\\"{x:1019,y:501,t:1512498411229};\\\", \\\"{x:1020,y:461,t:1512498411246};\\\", \\\"{x:1020,y:434,t:1512498411262};\\\", \\\"{x:1020,y:413,t:1512498411279};\\\", \\\"{x:1014,y:395,t:1512498411296};\\\", \\\"{x:1009,y:383,t:1512498411312};\\\", \\\"{x:1005,y:374,t:1512498411329};\\\", \\\"{x:998,y:366,t:1512498411346};\\\", \\\"{x:989,y:354,t:1512498411362};\\\", \\\"{x:974,y:344,t:1512498411379};\\\", \\\"{x:969,y:336,t:1512498411396};\\\", \\\"{x:965,y:332,t:1512498411412};\\\", \\\"{x:963,y:327,t:1512498411429};\\\", \\\"{x:959,y:312,t:1512498411446};\\\", \\\"{x:955,y:292,t:1512498411462};\\\", \\\"{x:953,y:267,t:1512498411479};\\\", \\\"{x:950,y:245,t:1512498411496};\\\", \\\"{x:946,y:225,t:1512498411512};\\\", \\\"{x:941,y:212,t:1512498411529};\\\", \\\"{x:941,y:209,t:1512498411546};\\\", \\\"{x:941,y:208,t:1512498411562};\\\", \\\"{x:941,y:207,t:1512498411815};\\\", \\\"{x:940,y:207,t:1512498411855};\\\", \\\"{x:939,y:208,t:1512498411863};\\\", \\\"{x:936,y:210,t:1512498411879};\\\", \\\"{x:934,y:210,t:1512498411903};\\\", \\\"{x:934,y:211,t:1512498411912};\\\", \\\"{x:933,y:212,t:1512498411929};\\\", \\\"{x:932,y:213,t:1512498411946};\\\", \\\"{x:929,y:216,t:1512498411963};\\\", \\\"{x:923,y:220,t:1512498411980};\\\", \\\"{x:919,y:223,t:1512498411996};\\\", \\\"{x:912,y:224,t:1512498412012};\\\", \\\"{x:907,y:226,t:1512498412030};\\\", \\\"{x:902,y:229,t:1512498412047};\\\", \\\"{x:900,y:230,t:1512498412063};\\\", \\\"{x:898,y:230,t:1512498412080};\\\", \\\"{x:894,y:233,t:1512498412096};\\\", \\\"{x:891,y:234,t:1512498412113};\\\", \\\"{x:886,y:237,t:1512498412130};\\\", \\\"{x:881,y:240,t:1512498412146};\\\", \\\"{x:877,y:242,t:1512498412164};\\\", \\\"{x:876,y:242,t:1512498412183};\\\", \\\"{x:875,y:242,t:1512498412196};\\\", \\\"{x:872,y:242,t:1512498412214};\\\", \\\"{x:867,y:242,t:1512498412230};\\\", \\\"{x:862,y:242,t:1512498412246};\\\", \\\"{x:856,y:242,t:1512498412263};\\\", \\\"{x:854,y:242,t:1512498412280};\\\", \\\"{x:853,y:242,t:1512498412297};\\\", \\\"{x:852,y:242,t:1512498412313};\\\", \\\"{x:851,y:242,t:1512498412351};\\\", \\\"{x:850,y:242,t:1512498412363};\\\", \\\"{x:848,y:242,t:1512498412380};\\\", \\\"{x:847,y:241,t:1512498412397};\\\", \\\"{x:844,y:241,t:1512498412413};\\\", \\\"{x:843,y:241,t:1512498412430};\\\", \\\"{x:842,y:240,t:1512498412455};\\\", \\\"{x:841,y:240,t:1512498412574};\\\", \\\"{x:840,y:240,t:1512498412590};\\\", \\\"{x:839,y:240,t:1512498412703};\\\", \\\"{x:837,y:240,t:1512498413079};\\\", \\\"{x:835,y:240,t:1512498413159};\\\", \\\"{x:834,y:240,t:1512498413175};\\\", \\\"{x:833,y:240,t:1512498413183};\\\", \\\"{x:832,y:240,t:1512498413198};\\\", \\\"{x:832,y:239,t:1512498413213};\\\", \\\"{x:831,y:238,t:1512498413230};\\\", \\\"{x:831,y:239,t:1512498413703};\\\", \\\"{x:831,y:240,t:1512498413714};\\\", \\\"{x:830,y:244,t:1512498413731};\\\", \\\"{x:830,y:249,t:1512498413749};\\\", \\\"{x:830,y:253,t:1512498413764};\\\", \\\"{x:830,y:260,t:1512498413781};\\\", \\\"{x:830,y:270,t:1512498413797};\\\", \\\"{x:830,y:278,t:1512498413814};\\\", \\\"{x:830,y:289,t:1512498413831};\\\", \\\"{x:830,y:301,t:1512498413848};\\\", \\\"{x:832,y:314,t:1512498413864};\\\", \\\"{x:833,y:328,t:1512498413881};\\\", \\\"{x:833,y:342,t:1512498413898};\\\", \\\"{x:833,y:353,t:1512498413914};\\\", \\\"{x:833,y:361,t:1512498413931};\\\", \\\"{x:833,y:369,t:1512498413947};\\\", \\\"{x:833,y:373,t:1512498413964};\\\", \\\"{x:833,y:377,t:1512498413981};\\\", \\\"{x:833,y:381,t:1512498413997};\\\", \\\"{x:833,y:386,t:1512498414014};\\\", \\\"{x:833,y:389,t:1512498414031};\\\", \\\"{x:833,y:392,t:1512498414047};\\\", \\\"{x:833,y:394,t:1512498414064};\\\", \\\"{x:833,y:397,t:1512498414080};\\\", \\\"{x:833,y:399,t:1512498414102};\\\", \\\"{x:833,y:400,t:1512498414189};\\\", \\\"{x:833,y:402,t:1512498414205};\\\", \\\"{x:833,y:403,t:1512498414221};\\\", \\\"{x:833,y:405,t:1512498414230};\\\", \\\"{x:833,y:406,t:1512498414247};\\\", \\\"{x:833,y:407,t:1512498414265};\\\", \\\"{x:833,y:408,t:1512498414281};\\\", \\\"{x:833,y:410,t:1512498415215};\\\", \\\"{x:833,y:411,t:1512498415232};\\\", \\\"{x:833,y:412,t:1512498415343};\\\", \\\"{x:833,y:414,t:1512498415350};\\\", \\\"{x:833,y:415,t:1512498415366};\\\", \\\"{x:833,y:419,t:1512498415382};\\\", \\\"{x:833,y:422,t:1512498415400};\\\", \\\"{x:833,y:425,t:1512498415417};\\\", \\\"{x:833,y:427,t:1512498415432};\\\", \\\"{x:833,y:428,t:1512498415449};\\\", \\\"{x:833,y:429,t:1512498415465};\\\", \\\"{x:833,y:431,t:1512498415482};\\\", \\\"{x:833,y:432,t:1512498415499};\\\", \\\"{x:833,y:433,t:1512498415515};\\\", \\\"{x:833,y:434,t:1512498415532};\\\", \\\"{x:833,y:436,t:1512498415549};\\\", \\\"{x:833,y:437,t:1512498415598};\\\", \\\"{x:832,y:437,t:1512498415614};\\\", \\\"{x:832,y:437,t:1512498415794};\\\", \\\"{x:832,y:440,t:1512498416126};\\\", \\\"{x:832,y:441,t:1512498416134};\\\", \\\"{x:831,y:446,t:1512498416149};\\\", \\\"{x:828,y:462,t:1512498416166};\\\", \\\"{x:827,y:474,t:1512498416183};\\\", \\\"{x:827,y:489,t:1512498416199};\\\", \\\"{x:827,y:502,t:1512498416216};\\\", \\\"{x:826,y:512,t:1512498416233};\\\", \\\"{x:826,y:520,t:1512498416250};\\\", \\\"{x:824,y:526,t:1512498416266};\\\", \\\"{x:823,y:531,t:1512498416283};\\\", \\\"{x:823,y:534,t:1512498416299};\\\", \\\"{x:823,y:538,t:1512498416316};\\\", \\\"{x:823,y:542,t:1512498416333};\\\", \\\"{x:824,y:547,t:1512498416350};\\\", \\\"{x:824,y:550,t:1512498416366};\\\", \\\"{x:825,y:553,t:1512498416383};\\\", \\\"{x:825,y:556,t:1512498416400};\\\", \\\"{x:825,y:560,t:1512498416416};\\\", \\\"{x:825,y:563,t:1512498416433};\\\", \\\"{x:825,y:566,t:1512498416450};\\\", \\\"{x:825,y:570,t:1512498416466};\\\", \\\"{x:826,y:572,t:1512498416483};\\\", \\\"{x:827,y:578,t:1512498416500};\\\", \\\"{x:828,y:590,t:1512498416517};\\\", \\\"{x:829,y:603,t:1512498416533};\\\", \\\"{x:833,y:627,t:1512498416550};\\\", \\\"{x:836,y:641,t:1512498416566};\\\", \\\"{x:837,y:652,t:1512498416583};\\\", \\\"{x:838,y:656,t:1512498416600};\\\", \\\"{x:838,y:658,t:1512498416616};\\\", \\\"{x:838,y:659,t:1512498416633};\\\", \\\"{x:838,y:662,t:1512498416650};\\\", \\\"{x:838,y:665,t:1512498416666};\\\", \\\"{x:838,y:669,t:1512498416683};\\\", \\\"{x:838,y:671,t:1512498416700};\\\", \\\"{x:838,y:672,t:1512498416967};\\\", \\\"{x:838,y:673,t:1512498417534};\\\", \\\"{x:838,y:675,t:1512498417542};\\\", \\\"{x:838,y:676,t:1512498417558};\\\", \\\"{x:838,y:678,t:1512498417598};\\\", \\\"{x:837,y:679,t:1512498417614};\\\", \\\"{x:837,y:681,t:1512498417630};\\\", \\\"{x:837,y:684,t:1512498417646};\\\", \\\"{x:837,y:685,t:1512498417654};\\\", \\\"{x:837,y:687,t:1512498417667};\\\", \\\"{x:837,y:692,t:1512498417684};\\\", \\\"{x:837,y:697,t:1512498417701};\\\", \\\"{x:837,y:701,t:1512498417717};\\\", \\\"{x:834,y:707,t:1512498417734};\\\", \\\"{x:832,y:710,t:1512498417751};\\\", \\\"{x:831,y:711,t:1512498417767};\\\", \\\"{x:827,y:715,t:1512498417784};\\\", \\\"{x:824,y:717,t:1512498417800};\\\", \\\"{x:820,y:720,t:1512498417817};\\\", \\\"{x:813,y:725,t:1512498417834};\\\", \\\"{x:807,y:729,t:1512498417851};\\\", \\\"{x:803,y:733,t:1512498417867};\\\", \\\"{x:799,y:737,t:1512498417884};\\\", \\\"{x:798,y:738,t:1512498417902};\\\", \\\"{x:798,y:739,t:1512498417918};\\\", \\\"{x:797,y:739,t:1512498418191};\\\", \\\"{x:796,y:739,t:1512498418222};\\\", \\\"{x:795,y:739,t:1512498418246};\\\", \\\"{x:794,y:739,t:1512498418278};\\\", \\\"{x:794,y:740,t:1512498418294};\\\", \\\"{x:794,y:741,t:1512498418423};\\\", \\\"{x:794,y:742,t:1512498418446};\\\", \\\"{x:794,y:743,t:1512498418470};\\\", \\\"{x:794,y:744,t:1512498418486};\\\", \\\"{x:794,y:745,t:1512498418502};\\\", \\\"{x:794,y:746,t:1512498418599};\\\", \\\"{x:794,y:747,t:1512498418614};\\\", \\\"{x:794,y:748,t:1512498418638};\\\", \\\"{x:794,y:749,t:1512498418651};\\\", \\\"{x:794,y:750,t:1512498418669};\\\", \\\"{x:795,y:752,t:1512498418685};\\\", \\\"{x:796,y:753,t:1512498418702};\\\", \\\"{x:797,y:753,t:1512498418807};\\\", \\\"{x:799,y:755,t:1512498418822};\\\", \\\"{x:800,y:757,t:1512498418835};\\\", \\\"{x:801,y:760,t:1512498418853};\\\", \\\"{x:804,y:763,t:1512498418868};\\\", \\\"{x:804,y:765,t:1512498418885};\\\", \\\"{x:804,y:767,t:1512498418902};\\\", \\\"{x:804,y:769,t:1512498418999};\\\", \\\"{x:804,y:770,t:1512498419006};\\\", \\\"{x:804,y:772,t:1512498419022};\\\", \\\"{x:804,y:773,t:1512498419035};\\\", \\\"{x:804,y:775,t:1512498419052};\\\", \\\"{x:804,y:776,t:1512498419068};\\\", \\\"{x:804,y:777,t:1512498419119};\\\", \\\"{x:804,y:778,t:1512498419199};\\\", \\\"{x:804,y:779,t:1512498419206};\\\", \\\"{x:803,y:780,t:1512498419222};\\\", \\\"{x:803,y:781,t:1512498419238};\\\", \\\"{x:803,y:782,t:1512498419253};\\\", \\\"{x:803,y:784,t:1512498419270};\\\", \\\"{x:803,y:785,t:1512498419391};\\\", \\\"{x:802,y:787,t:1512498419406};\\\", \\\"{x:801,y:787,t:1512498419422};\\\", \\\"{x:801,y:788,t:1512498419435};\\\", \\\"{x:801,y:786,t:1512498419904};\\\", \\\"{x:800,y:784,t:1512498419920};\\\", \\\"{x:800,y:782,t:1512498419937};\\\", \\\"{x:800,y:780,t:1512498419954};\\\", \\\"{x:798,y:779,t:1512498419970};\\\", \\\"{x:798,y:778,t:1512498420064};\\\", \\\"{x:798,y:777,t:1512498420071};\\\", \\\"{x:798,y:775,t:1512498420087};\\\", \\\"{x:798,y:774,t:1512498420127};\\\", \\\"{x:798,y:773,t:1512498420159};\\\", \\\"{x:798,y:772,t:1512498420303};\\\", \\\"{x:798,y:771,t:1512498420310};\\\", \\\"{x:798,y:769,t:1512498420320};\\\", \\\"{x:799,y:767,t:1512498420448};\\\", \\\"{x:799,y:766,t:1512498420455};\\\", \\\"{x:801,y:762,t:1512498420470};\\\", \\\"{x:805,y:753,t:1512498420487};\\\", \\\"{x:808,y:747,t:1512498420504};\\\", \\\"{x:811,y:741,t:1512498420520};\\\", \\\"{x:814,y:733,t:1512498420537};\\\", \\\"{x:819,y:729,t:1512498420554};\\\", \\\"{x:823,y:722,t:1512498420571};\\\", \\\"{x:827,y:718,t:1512498420588};\\\", \\\"{x:830,y:715,t:1512498420607};\\\", \\\"{x:834,y:712,t:1512498420621};\\\", \\\"{x:835,y:710,t:1512498420637};\\\", \\\"{x:837,y:707,t:1512498420654};\\\", \\\"{x:838,y:706,t:1512498420670};\\\", \\\"{x:838,y:705,t:1512498420687};\\\", \\\"{x:839,y:704,t:1512498420704};\\\", \\\"{x:838,y:704,t:1512498421016};\\\", \\\"{x:838,y:704,t:1512498421323};\\\", \\\"{x:837,y:706,t:1512498421632};\\\", \\\"{x:837,y:709,t:1512498421639};\\\", \\\"{x:836,y:718,t:1512498421656};\\\", \\\"{x:835,y:729,t:1512498421672};\\\", \\\"{x:832,y:742,t:1512498421689};\\\", \\\"{x:831,y:756,t:1512498421706};\\\", \\\"{x:828,y:773,t:1512498421722};\\\", \\\"{x:825,y:788,t:1512498421738};\\\", \\\"{x:823,y:801,t:1512498421755};\\\", \\\"{x:819,y:814,t:1512498421771};\\\", \\\"{x:817,y:819,t:1512498421788};\\\", \\\"{x:816,y:823,t:1512498421805};\\\", \\\"{x:816,y:825,t:1512498421895};\\\", \\\"{x:816,y:827,t:1512498421910};\\\", \\\"{x:816,y:828,t:1512498421922};\\\", \\\"{x:816,y:831,t:1512498421938};\\\", \\\"{x:816,y:833,t:1512498421955};\\\", \\\"{x:816,y:835,t:1512498421972};\\\", \\\"{x:816,y:836,t:1512498421988};\\\", \\\"{x:816,y:838,t:1512498422005};\\\", \\\"{x:816,y:839,t:1512498422022};\\\", \\\"{x:816,y:841,t:1512498422038};\\\", \\\"{x:816,y:846,t:1512498422055};\\\", \\\"{x:817,y:851,t:1512498422072};\\\", \\\"{x:818,y:858,t:1512498422088};\\\", \\\"{x:819,y:866,t:1512498422105};\\\", \\\"{x:819,y:875,t:1512498422122};\\\", \\\"{x:821,y:882,t:1512498422138};\\\", \\\"{x:822,y:887,t:1512498422155};\\\", \\\"{x:822,y:891,t:1512498422172};\\\", \\\"{x:822,y:893,t:1512498422188};\\\", \\\"{x:822,y:894,t:1512498422205};\\\", \\\"{x:822,y:895,t:1512498422256};\\\", \\\"{x:822,y:896,t:1512498422272};\\\", \\\"{x:822,y:898,t:1512498422289};\\\", \\\"{x:823,y:900,t:1512498422305};\\\", \\\"{x:823,y:904,t:1512498422323};\\\", \\\"{x:825,y:905,t:1512498422339};\\\", \\\"{x:825,y:906,t:1512498422367};\\\", \\\"{x:826,y:906,t:1512498422479};\\\", \\\"{x:828,y:907,t:1512498422489};\\\", \\\"{x:829,y:909,t:1512498422505};\\\", \\\"{x:833,y:913,t:1512498422522};\\\", \\\"{x:835,y:916,t:1512498422539};\\\", \\\"{x:836,y:917,t:1512498422555};\\\", \\\"{x:837,y:918,t:1512498422572};\\\", \\\"{x:838,y:918,t:1512498422615};\\\", \\\"{x:838,y:919,t:1512498422631};\\\", \\\"{x:839,y:920,t:1512498422655};\\\", \\\"{x:839,y:922,t:1512498422673};\\\", \\\"{x:839,y:924,t:1512498422689};\\\", \\\"{x:839,y:926,t:1512498422706};\\\", \\\"{x:839,y:929,t:1512498422722};\\\", \\\"{x:839,y:930,t:1512498422738};\\\", \\\"{x:839,y:931,t:1512498422755};\\\", \\\"{x:839,y:932,t:1512498422863};\\\", \\\"{x:839,y:933,t:1512498422895};\\\", \\\"{x:839,y:937,t:1512498423431};\\\", \\\"{x:846,y:945,t:1512498423440};\\\", \\\"{x:858,y:955,t:1512498423457};\\\", \\\"{x:872,y:966,t:1512498423473};\\\", \\\"{x:882,y:974,t:1512498423490};\\\", \\\"{x:892,y:983,t:1512498423506};\\\", \\\"{x:900,y:990,t:1512498423523};\\\", \\\"{x:903,y:992,t:1512498423539};\\\", \\\"{x:905,y:995,t:1512498423556};\\\", \\\"{x:907,y:996,t:1512498423573};\\\", \\\"{x:910,y:1000,t:1512498423590};\\\", \\\"{x:911,y:1002,t:1512498423606};\\\", \\\"{x:911,y:1004,t:1512498423623};\\\", \\\"{x:911,y:1005,t:1512498423640};\\\", \\\"{x:911,y:1007,t:1512498423656};\\\", \\\"{x:911,y:1008,t:1512498423679};\\\", \\\"{x:911,y:1009,t:1512498423690};\\\", \\\"{x:911,y:1010,t:1512498423710};\\\", \\\"{x:911,y:1010,t:1512498423963};\\\", \\\"{x:909,y:1005,t:1512498426664};\\\", \\\"{x:903,y:1001,t:1512498426677};\\\", \\\"{x:892,y:996,t:1512498426693};\\\", \\\"{x:882,y:990,t:1512498426710};\\\", \\\"{x:870,y:985,t:1512498426726};\\\", \\\"{x:849,y:976,t:1512498426743};\\\", \\\"{x:837,y:970,t:1512498426759};\\\", \\\"{x:828,y:964,t:1512498426777};\\\", \\\"{x:816,y:954,t:1512498426793};\\\", \\\"{x:804,y:946,t:1512498426810};\\\", \\\"{x:789,y:935,t:1512498426826};\\\", \\\"{x:765,y:921,t:1512498426842};\\\", \\\"{x:756,y:914,t:1512498426859};\\\", \\\"{x:752,y:912,t:1512498426876};\\\", \\\"{x:748,y:910,t:1512498426892};\\\", \\\"{x:748,y:909,t:1512498427087};\\\", \\\"{x:749,y:909,t:1512498427095};\\\", \\\"{x:752,y:909,t:1512498427110};\\\", \\\"{x:771,y:913,t:1512498427127};\\\", \\\"{x:788,y:921,t:1512498427143};\\\", \\\"{x:811,y:930,t:1512498427160};\\\", \\\"{x:828,y:935,t:1512498427176};\\\", \\\"{x:844,y:945,t:1512498427194};\\\", \\\"{x:859,y:953,t:1512498427210};\\\", \\\"{x:868,y:960,t:1512498427226};\\\", \\\"{x:875,y:967,t:1512498427244};\\\", \\\"{x:883,y:977,t:1512498427260};\\\", \\\"{x:888,y:988,t:1512498427277};\\\", \\\"{x:893,y:997,t:1512498427294};\\\", \\\"{x:899,y:1008,t:1512498427309};\\\", \\\"{x:906,y:1020,t:1512498427326};\\\", \\\"{x:914,y:1034,t:1512498427343};\\\", \\\"{x:918,y:1040,t:1512498427359};\\\", \\\"{x:920,y:1044,t:1512498427376};\\\", \\\"{x:920,y:1046,t:1512498427394};\\\", \\\"{x:923,y:1049,t:1512498427409};\\\", \\\"{x:925,y:1052,t:1512498427426};\\\", \\\"{x:931,y:1059,t:1512498427444};\\\", \\\"{x:934,y:1063,t:1512498427460};\\\", \\\"{x:937,y:1067,t:1512498427476};\\\", \\\"{x:937,y:1069,t:1512498427493};\\\", \\\"{x:939,y:1072,t:1512498427510};\\\", \\\"{x:939,y:1073,t:1512498427526};\\\", \\\"{x:940,y:1075,t:1512498427543};\\\", \\\"{x:941,y:1075,t:1512498427559};\\\", \\\"{x:941,y:1076,t:1512498427598};\\\", \\\"{x:942,y:1077,t:1512498427614};\\\", \\\"{x:942,y:1078,t:1512498427662};\\\", \\\"{x:943,y:1078,t:1512498427702};\\\", \\\"{x:944,y:1079,t:1512498427863};\\\", \\\"{x:945,y:1080,t:1512498427895};\\\", \\\"{x:946,y:1080,t:1512498427935};\\\", \\\"{x:947,y:1081,t:1512498427943};\\\", \\\"{x:948,y:1081,t:1512498428031};\\\", \\\"{x:949,y:1081,t:1512498428055};\\\" ] }, { \\\"rt\\\": 9030, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 844803, \\\"internal_node_id\\\": \\\"0.0-7.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 13766, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 859580, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 18992, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 879826, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"WLDKB\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":1740}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":1,\"id\":53,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":8,\"id\":57},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\"WLDKB\"}]},{\"nodeType\":3,\"id\":75,\"textContent\":\" \"},{\"nodeType\":1,\"id\":76,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":8,\"id\":78},{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":1,\"id\":80,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\"Hint: hover your mouse over the data points for help\"}]},{\"nodeType\":3,\"id\":84,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":85,\"textContent\":\" \"},{\"nodeType\":8,\"id\":86},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":1,\"id\":90,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":96,\"textContent\":\" \"},{\"nodeType\":1,\"id\":97,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":100,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":101,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":103,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":106,\"textContent\":\" \"},{\"nodeType\":1,\"id\":107,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":108,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":109,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":111,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":114,\"textContent\":\" \"},{\"nodeType\":1,\"id\":115,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":116,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":117,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":118,\"textContent\":\" \"},{\"nodeType\":1,\"id\":119,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":122,\"textContent\":\" \"},{\"nodeType\":1,\"id\":123,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":124,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":125,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":127,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":130,\"textContent\":\" \"},{\"nodeType\":1,\"id\":131,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":132,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":133,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":135,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":138,\"textContent\":\" \"},{\"nodeType\":1,\"id\":139,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":140,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":141,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":143,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":146,\"textContent\":\" \"},{\"nodeType\":1,\"id\":147,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":148,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":149,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":151,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":154,\"textContent\":\" \"},{\"nodeType\":1,\"id\":155,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":156,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":157,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":158,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":159,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":161,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":162,\"textContent\":\" \"},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":164,\"textContent\":\"Which shift(s) start with D?\"}]},{\"nodeType\":3,\"id\":165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":166,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":170,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"},{\"nodeType\":1,\"id\":172,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":173,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":174,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":178,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"},{\"nodeType\":1,\"id\":180,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":181,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":182,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":186,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"},{\"nodeType\":1,\"id\":188,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":189,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":190,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":194,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"},{\"nodeType\":1,\"id\":196,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":197,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":198,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":201,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":202,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"},{\"nodeType\":1,\"id\":204,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":205,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":206,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":209,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":210,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"},{\"nodeType\":1,\"id\":212,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":213,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":214,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":217,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":218,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"},{\"nodeType\":1,\"id\":220,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":221,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":222,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":223,\"textContent\":\" \"},{\"nodeType\":1,\"id\":224,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":225,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":226,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":228,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":231,\"textContent\":\" \"},{\"nodeType\":1,\"id\":232,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":233,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":234,\"textContent\":\" \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":236,\"textContent\":\" \"},{\"nodeType\":1,\"id\":237,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":238,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":239,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":243,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"},{\"nodeType\":1,\"id\":245,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":246,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":247,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":251,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"},{\"nodeType\":1,\"id\":253,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":254,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":255,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":259,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"},{\"nodeType\":1,\"id\":261,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":262,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":263,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":267,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"},{\"nodeType\":1,\"id\":269,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":270,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":271,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":275,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"},{\"nodeType\":1,\"id\":277,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":278,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":279,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":283,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"},{\"nodeType\":1,\"id\":285,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":286,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":287,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":291,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"},{\"nodeType\":1,\"id\":293,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":294,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":295,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":296,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":297,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":298,\"textContent\":\" \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":300,\"textContent\":\" \"},{\"nodeType\":1,\"id\":301,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":302,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":303,\"textContent\":\" \"},{\"nodeType\":1,\"id\":304,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":306,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":307,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":312,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":314,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":315,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":320,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":322,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":323,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":328,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":330,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":331,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":336,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":338,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":339,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":344,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":346,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":347,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"},{\"nodeType\":1,\"id\":350,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":351,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":352,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":355,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":356,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":358,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":359,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":360,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":364,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":368,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":371,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":372,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":373,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":376,\"textContent\":\" \"},{\"nodeType\":1,\"id\":377,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":380,\"textContent\":\" \"},{\"nodeType\":1,\"id\":381,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":382,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":383,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":384,\"textContent\":\" \"},{\"nodeType\":1,\"id\":385,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":388,\"textContent\":\" \"},{\"nodeType\":1,\"id\":389,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":390,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":391,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":392,\"textContent\":\" \"},{\"nodeType\":1,\"id\":393,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":396,\"textContent\":\" \"},{\"nodeType\":1,\"id\":397,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":398,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":399,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":400,\"textContent\":\" \"},{\"nodeType\":1,\"id\":401,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":404,\"textContent\":\" \"},{\"nodeType\":1,\"id\":405,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":406,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":407,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":408,\"textContent\":\" \"},{\"nodeType\":1,\"id\":409,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":412,\"textContent\":\" \"},{\"nodeType\":1,\"id\":413,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":414,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":415,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":416,\"textContent\":\" \"},{\"nodeType\":1,\"id\":417,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"U\"}]},{\"nodeType\":3,\"id\":420,\"textContent\":\" \"},{\"nodeType\":1,\"id\":421,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":422,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":423,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":424,\"textContent\":\" \"},{\"nodeType\":1,\"id\":425,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":428,\"textContent\":\" \"},{\"nodeType\":1,\"id\":429,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":430,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":431,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":432,\"textContent\":\" \"},{\"nodeType\":1,\"id\":433,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":436,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":440,\"textContent\":\" \"},{\"nodeType\":1,\"id\":441,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":442,\"textContent\":\"Which shifts are six hours long?\"}]},{\"nodeType\":3,\"id\":443,\"textContent\":\" \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":445,\"textContent\":\" \"},{\"nodeType\":1,\"id\":446,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":447,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":448,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":452,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"},{\"nodeType\":1,\"id\":454,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":455,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":456,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":460,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"},{\"nodeType\":1,\"id\":462,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":463,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":464,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":468,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"},{\"nodeType\":1,\"id\":470,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":471,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":472,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":476,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"},{\"nodeType\":1,\"id\":478,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":479,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":480,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":481,\"textContent\":\" \"},{\"nodeType\":1,\"id\":482,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":484,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":487,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":488,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":489,\"textContent\":\" \"},{\"nodeType\":1,\"id\":490,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":493,\"textContent\":\" \"},{\"nodeType\":1,\"id\":494,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":495,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":496,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":497,\"textContent\":\" \"},{\"nodeType\":1,\"id\":498,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":501,\"textContent\":\" \"},{\"nodeType\":1,\"id\":502,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":503,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":504,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":506,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":509,\"textContent\":\" \"},{\"nodeType\":1,\"id\":510,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":511,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":512,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":513,\"textContent\":\" \"},{\"nodeType\":1,\"id\":514,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":517,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":521,\"textContent\":\" \"},{\"nodeType\":1,\"id\":522,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":523,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":524,\"textContent\":\" \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":526,\"textContent\":\" \"},{\"nodeType\":1,\"id\":527,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":528,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":529,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":533,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"},{\"nodeType\":1,\"id\":535,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":536,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":537,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":541,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"},{\"nodeType\":1,\"id\":543,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":544,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":545,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":549,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"},{\"nodeType\":1,\"id\":551,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":552,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":553,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":557,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"},{\"nodeType\":1,\"id\":559,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":560,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":561,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":565,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"},{\"nodeType\":1,\"id\":567,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":568,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":569,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":573,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"},{\"nodeType\":1,\"id\":575,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":576,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":577,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":581,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"},{\"nodeType\":1,\"id\":583,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":584,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":585,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":589,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"},{\"nodeType\":1,\"id\":591,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":592,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":593,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":597,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":601,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":604,\"textContent\":\"Which shift under 7 hours long starts before B and ends after X?\"}]},{\"nodeType\":3,\"id\":605,\"textContent\":\" \"},{\"nodeType\":1,\"id\":606,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":607,\"textContent\":\" \"},{\"nodeType\":1,\"id\":608,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":609,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":610,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":613,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":614,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":615,\"textContent\":\" \"},{\"nodeType\":1,\"id\":616,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":617,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":618,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":620,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":621,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":622,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":623,\"textContent\":\" \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":625,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":626,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":628,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":629,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":630,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":631,\"textContent\":\" \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":634,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":636,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":637,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":638,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":639,\"textContent\":\" \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":642,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":644,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":645,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":646,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":647,\"textContent\":\" \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":649,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":650,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":652,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":654,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":655,\"textContent\":\" \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":657,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":658,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":659,\"textContent\":\" \"},{\"nodeType\":1,\"id\":660,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":662,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":666,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":667,\"textContent\":\" \"},{\"nodeType\":1,\"id\":668,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":670,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":671,\"textContent\":\" \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":674,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":675,\"textContent\":\" \"},{\"nodeType\":1,\"id\":676,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":678,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":679,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":680,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":682,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":683,\"textContent\":\" \"},{\"nodeType\":1,\"id\":684,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\"Which shift begins before J and ends during B?\"}]},{\"nodeType\":3,\"id\":686,\"textContent\":\" \"},{\"nodeType\":1,\"id\":687,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":688,\"textContent\":\" \"},{\"nodeType\":1,\"id\":689,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":691,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":693,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":696,\"textContent\":\" \"},{\"nodeType\":1,\"id\":697,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":698,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":699,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":701,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":704,\"textContent\":\" \"},{\"nodeType\":1,\"id\":705,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":706,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":707,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":709,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":712,\"textContent\":\" \"},{\"nodeType\":1,\"id\":713,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":714,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":715,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":717,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":720,\"textContent\":\" \"},{\"nodeType\":1,\"id\":721,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":722,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":723,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":725,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":728,\"textContent\":\" \"},{\"nodeType\":1,\"id\":729,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":730,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":731,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":733,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":736,\"textContent\":\" \"},{\"nodeType\":1,\"id\":737,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":738,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":739,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":742,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":743,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":744,\"textContent\":\" \"},{\"nodeType\":1,\"id\":745,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":746,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":747,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":749,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":750,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":751,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":752,\"textContent\":\" \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":754,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":755,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":757,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":758,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":759,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":760,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":761,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"},{\"nodeType\":1,\"id\":763,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":765,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\"Which shift ends with F?\"}]},{\"nodeType\":3,\"id\":767,\"textContent\":\" \"},{\"nodeType\":1,\"id\":768,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":770,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":771,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":772,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":773,\"textContent\":\" \"},{\"nodeType\":1,\"id\":774,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":778,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":779,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":780,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":781,\"textContent\":\" \"},{\"nodeType\":1,\"id\":782,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":786,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":787,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":788,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":789,\"textContent\":\" \"},{\"nodeType\":1,\"id\":790,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":794,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":795,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":796,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":797,\"textContent\":\" \"},{\"nodeType\":1,\"id\":798,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":802,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":803,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":804,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":805,\"textContent\":\" \"},{\"nodeType\":1,\"id\":806,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":809,\"textContent\":\" \"},{\"nodeType\":1,\"id\":810,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":811,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":812,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":814,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":817,\"textContent\":\" \"},{\"nodeType\":1,\"id\":818,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":819,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":820,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":822,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":825,\"textContent\":\" \"},{\"nodeType\":1,\"id\":826,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":827,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":828,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":830,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":833,\"textContent\":\" \"},{\"nodeType\":1,\"id\":834,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":835,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":836,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":838,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":841,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":846,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":847,\"textContent\":\"Which shifts start at 12pm?\"}]},{\"nodeType\":3,\"id\":848,\"textContent\":\" \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":851,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":852,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":853,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":856,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":857,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":859,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":860,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":861,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":864,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":865,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":867,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":868,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":869,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":872,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":873,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":875,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":876,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":877,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":880,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":881,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":883,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":884,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":885,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":888,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":889,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":891,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":892,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":893,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":894,\"textContent\":\" \"},{\"nodeType\":1,\"id\":895,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":896,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":897,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":900,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":901,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":902,\"textContent\":\" \"},{\"nodeType\":1,\"id\":903,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":907,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":908,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":909,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":910,\"textContent\":\" \"},{\"nodeType\":1,\"id\":911,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":915,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":916,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":917,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":918,\"textContent\":\" \"},{\"nodeType\":1,\"id\":919,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":922,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":926,\"textContent\":\" \"},{\"nodeType\":1,\"id\":927,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":928,\"textContent\":\"Which shift starts with F?\"}]},{\"nodeType\":3,\"id\":929,\"textContent\":\" \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":931,\"textContent\":\" \"},{\"nodeType\":1,\"id\":932,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":933,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":934,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":937,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":938,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"},{\"nodeType\":1,\"id\":940,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":941,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":942,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":945,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":946,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"},{\"nodeType\":1,\"id\":948,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":949,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":950,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":953,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":954,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"},{\"nodeType\":1,\"id\":956,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":957,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":958,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":961,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":962,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"},{\"nodeType\":1,\"id\":964,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":965,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":966,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":969,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":970,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":972,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":973,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":974,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":977,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":978,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":980,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":981,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":982,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":985,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":986,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":988,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":989,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":990,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":993,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":994,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":996,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":997,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":998,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1001,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1002,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1005,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1006,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1009,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1010,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1011,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1015,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1016,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1017,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1018,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1023,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1024,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1025,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1026,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1031,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1032,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1033,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1034,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1039,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1040,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1041,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1042,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1045,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1046,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1047,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1050,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1051,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1052,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1053,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1054,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1055,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1058,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1059,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1061,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1062,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1063,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1066,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1067,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1069,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1070,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1071,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1074,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1075,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1077,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1078,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1079,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1082,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1083,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1087,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1090,\"textContent\":\"Which shift ends at 3pm?\"}]},{\"nodeType\":3,\"id\":1091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1092,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1096,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1097,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1098,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1099,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1104,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1105,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1106,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1107,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1112,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1113,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1114,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1115,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1120,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1121,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1122,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1123,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1128,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1130,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1131,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1136,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1138,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1139,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1144,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1146,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1147,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1152,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1154,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1155,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1160,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1162,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1163,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1166,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1168,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1170,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1171,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":1172,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":1173,\"textContent\":\"Which 2 shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":1174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1175,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1179,\"textContent\":\"I\"}]},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1181,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1182,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1183,\"textContent\":\"J\"}]},{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1187,\"textContent\":\"E\"}]},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1189,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1190,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1191,\"textContent\":\"F\"}]},{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1195,\"textContent\":\"B\"}]},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1197,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1198,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1199,\"textContent\":\"M\"}]},{\"nodeType\":3,\"id\":1200,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1201,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1203,\"textContent\":\"A\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1206,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1207,\"textContent\":\"G\"}]},{\"nodeType\":3,\"id\":1208,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1209,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"C\"}]},{\"nodeType\":3,\"id\":1212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1213,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1214,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1215,\"textContent\":\"K\"}]},{\"nodeType\":3,\"id\":1216,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1217,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"X\"}]},{\"nodeType\":3,\"id\":1220,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1221,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1222,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1223,\"textContent\":\"O\"}]},{\"nodeType\":3,\"id\":1224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1225,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"P\"}]},{\"nodeType\":3,\"id\":1228,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1229,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1230,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1231,\"textContent\":\"L\"}]},{\"nodeType\":3,\"id\":1232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1233,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"H\"}]},{\"nodeType\":3,\"id\":1236,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1237,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1238,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1239,\"textContent\":\"Z\"}]},{\"nodeType\":3,\"id\":1240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1241,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"N\"}]},{\"nodeType\":3,\"id\":1244,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1245,\"tagName\":\"LI\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1246,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1247,\"textContent\":\"D\"}]},{\"nodeType\":3,\"id\":1248,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1250,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1251,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1252},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1254},{\"nodeType\":3,\"id\":1255,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1256,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"start\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":1259,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":1260,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1263},{\"nodeType\":3,\"id\":1264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1265,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":1266,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":1267,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1268,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":1269,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":1270,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":1271,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":1272,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1273,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1274,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1275,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":1276,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1277,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1278,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1279,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":1280,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1281,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1282,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1283,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":1284,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1285,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1286,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1287,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":1288,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1289,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1290,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1291,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":1292,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1293,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1294,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1295,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":1296,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1297,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1298,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1299,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":1300,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1301,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1302,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1303,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":1304,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1305,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1306,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1307,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":1308,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1309,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1310,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1311,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":1312,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1313,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1314,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1315,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":1316,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1317,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1318,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1319,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":1320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1321,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1322,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1323,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":1324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1325,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1326,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1327,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":1328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1329,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1330,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1331,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":1332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1333,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1334,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1335,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":1336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1337,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1338,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1339,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":1340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1341,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1342,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1343,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":1344,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1347,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":1348,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1351,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":1352,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1355,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":1356,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":1360,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1363,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":1364,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1367,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":1368,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":1370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1371,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":1372,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":1373,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1374,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":1375,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1376,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":1377,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":1378,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":1379,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":1380,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":1381,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":1382,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":1383,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":1384,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":1385,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":1386,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":1387,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":1388,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":1389,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":1390,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":1391,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":1392,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":1393,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":1394,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":1395,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":1396,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":1397,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":1398,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":1399,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":1400,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":1402,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":1403,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":1404,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":1405,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1406,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":1407,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":1408,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":1410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1411,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1412,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":1413,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1414,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":1415,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1416,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":1417,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":1418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1419,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":1420,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1421,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":1422,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":1423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1424,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":1425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1426,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":1427,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":1428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1429,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":1430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1431,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":1432,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":1433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1434,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":1435,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1436,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":1437,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":1438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1439,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":1440,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":1443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1444,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":1445,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1446,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":1447,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":1448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":1450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1451,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":1452,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":1453,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1454,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":1455,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1456,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":1457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":1458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1459,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":1460,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1461,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":1462,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":1463,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":1464,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":1465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":1468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":1470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":1472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":1474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":1476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":1478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":1480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":1482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":1484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":1486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":1488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":1490,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":1491,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1492,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1493,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":1494,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":1495,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1496,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1497,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":1499,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1500,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1501,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":1502,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":1503,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1504,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1505,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1506,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":1507,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1508,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1509,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":1510,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":1511,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1512,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1513,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":1514,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":1515,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1516,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1517,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":1518,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":1519,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1520,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1521,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":1522,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":1523,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1524,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1525,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":1526,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":1527,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1528,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1529,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1530,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":1531,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1532,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1533,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":1534,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":1535,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1536,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1537,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":1538,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":1539,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1540,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1541,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":1542,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":1543,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1546,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":1547,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":1550,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":1551,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":1554,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":1555,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":1558,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":1559,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":1560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":1561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":1562,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1564,\"textContent\":\" \"},{\"nodeType\":8,\"id\":1565},{\"nodeType\":3,\"id\":1566,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1567,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":1570,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 140, dom: 662, initialDom: 708",
  "javascriptErrors": []
}