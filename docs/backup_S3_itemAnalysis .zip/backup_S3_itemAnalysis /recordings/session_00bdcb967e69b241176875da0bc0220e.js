var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d5da7f93e80b0be35f80b01b0bdcf20e",
  "created": "2017-11-28T10:15:24.2349585-08:00",
  "lastActivity": "2017-11-28T10:15:49.9569585-08:00",
  "pageViews": [
    {
      "id": "1128242229b7c83bb4f9b2ab4e04638705d9f6eb",
      "startTime": "2017-11-28T10:15:24.2349585-08:00",
      "endTime": "2017-11-28T10:15:49.9569585-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 25722,
      "engagementTime": 25722,
      "scroll": 100.0,
      "tags": [
        "click-rage",
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 25722,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "click-rage",
    "form-interact"
  ],
  "variables": [
    "SID=HH4FP",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "00bdcb967e69b241176875da0bc0220e",
  "gdpr": false
}