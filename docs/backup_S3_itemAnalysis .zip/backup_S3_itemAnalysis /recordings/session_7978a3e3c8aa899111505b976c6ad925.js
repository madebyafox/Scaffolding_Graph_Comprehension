var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f91017d05982c4588d26774b68fc8937",
  "created": "2017-11-21T10:15:07.9227087-08:00",
  "lastActivity": "2017-11-21T10:15:35.7917087-08:00",
  "pageViews": [
    {
      "id": "112108820cb896ec97351eec87adb784c9d68aa7",
      "startTime": "2017-11-21T10:15:07.9227087-08:00",
      "endTime": "2017-11-21T10:15:35.7917087-08:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 27869,
      "engagementTime": 27869,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "annotations": []
    }
  ],
  "duration": 27869,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.94 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "62.0.3202.94",
  "screenRes": "1920x1200",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=EN7PB",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7978a3e3c8aa899111505b976c6ad925",
  "gdpr": false
}