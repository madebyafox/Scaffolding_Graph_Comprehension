var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052120853aa59c5b4500c93edd695582e1c8ed9d"] = {
  "startTime": "2018-05-21T19:24:20.8146099Z",
  "websitePageUrl": "/",
  "visitTime": 928055,
  "engagementTime": 57534,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1356,
  "viewportHeight": 752,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "fba4fa51f4664214534b6b510c474c5d",
    "created": "2018-05-21T19:24:20.8146099+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-us",
    "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/604.5.6 (KHTML, like Gecko) Version/11.0.3 Safari/604.5.6",
    "browser": "Safari",
    "browserVersion": "11.0.3",
    "os": "OS X",
    "osVersion": "10.11 El Capitan",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1440x900",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "1f46675781f746c1c4bd42fb9d208c4c",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/fba4fa51f4664214534b6b510c474c5d/play"
  },
  "events": [
    {
      "t": 103,
      "e": 103,
      "ty": 0,
      "x": 1356,
      "y": 752
    },
    {
      "t": 341,
      "e": 341,
      "ty": 14,
      "x": 0,
      "y": 760
    },
    {
      "t": 10002,
      "e": 5103,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 853270,
      "e": 5103,
      "ty": 2,
      "x": 974,
      "y": 13
    },
    {
      "t": 853371,
      "e": 5204,
      "ty": 2,
      "x": 856,
      "y": 8
    },
    {
      "t": 853420,
      "e": 5253,
      "ty": 41,
      "x": 41560,
      "y": 2129,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 853471,
      "e": 5304,
      "ty": 2,
      "x": 840,
      "y": 11
    },
    {
      "t": 853549,
      "e": 5382,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 853571,
      "e": 5404,
      "ty": 2,
      "x": 835,
      "y": 2
    },
    {
      "t": 853669,
      "e": 5502,
      "ty": 41,
      "x": 40904,
      "y": 1474,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 856262,
      "e": 8095,
      "ty": 41,
      "x": 42761,
      "y": 1884,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 856262,
      "e": 8095,
      "ty": 2,
      "x": 869,
      "y": 7
    },
    {
      "t": 856363,
      "e": 8196,
      "ty": 2,
      "x": 810,
      "y": 7
    },
    {
      "t": 856465,
      "e": 8298,
      "ty": 2,
      "x": 816,
      "y": 9
    },
    {
      "t": 856513,
      "e": 8346,
      "ty": 41,
      "x": 39867,
      "y": 2047,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 856565,
      "e": 8398,
      "ty": 2,
      "x": 810,
      "y": 0
    },
    {
      "t": 856573,
      "e": 8406,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 856764,
      "e": 8597,
      "ty": 41,
      "x": 39539,
      "y": 1310,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 862668,
      "e": 13597,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 883289,
      "e": 13597,
      "ty": 2,
      "x": 1029,
      "y": 72
    },
    {
      "t": 883390,
      "e": 13698,
      "ty": 2,
      "x": 895,
      "y": 289
    },
    {
      "t": 883438,
      "e": 13746,
      "ty": 41,
      "x": 43034,
      "y": 28671,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 883490,
      "e": 13798,
      "ty": 2,
      "x": 864,
      "y": 354
    },
    {
      "t": 883550,
      "e": 13858,
      "ty": 3,
      "x": 863,
      "y": 359,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 883590,
      "e": 13898,
      "ty": 2,
      "x": 863,
      "y": 359
    },
    {
      "t": 883653,
      "e": 13961,
      "ty": 4,
      "x": 42433,
      "y": 30719,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 883654,
      "e": 13962,
      "ty": 5,
      "x": 863,
      "y": 359,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 883689,
      "e": 13997,
      "ty": 41,
      "x": 42433,
      "y": 30719,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 884443,
      "e": 14751,
      "ty": 41,
      "x": 42433,
      "y": 30883,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 884496,
      "e": 14804,
      "ty": 2,
      "x": 868,
      "y": 387
    },
    {
      "t": 884597,
      "e": 14905,
      "ty": 2,
      "x": 884,
      "y": 449
    },
    {
      "t": 884693,
      "e": 15001,
      "ty": 41,
      "x": 43799,
      "y": 38829,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 884697,
      "e": 15005,
      "ty": 2,
      "x": 888,
      "y": 458
    },
    {
      "t": 884799,
      "e": 15107,
      "ty": 2,
      "x": 896,
      "y": 442
    },
    {
      "t": 884945,
      "e": 15253,
      "ty": 41,
      "x": 44236,
      "y": 37518,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 884976,
      "e": 15284,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 885698,
      "e": 16006,
      "ty": 41,
      "x": 42916,
      "y": 37996,
      "ta": "html > body"
    },
    {
      "t": 885706,
      "e": 16014,
      "ty": 2,
      "x": 896,
      "y": 444
    },
    {
      "t": 885807,
      "e": 16115,
      "ty": 2,
      "x": 876,
      "y": 457
    },
    {
      "t": 885908,
      "e": 16216,
      "ty": 2,
      "x": 864,
      "y": 464
    },
    {
      "t": 885950,
      "e": 16258,
      "ty": 41,
      "x": 41370,
      "y": 39739,
      "ta": "html > body"
    },
    {
      "t": 886201,
      "e": 16509,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 886360,
      "e": 16668,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 886916,
      "e": 17224,
      "ty": 2,
      "x": 863,
      "y": 464
    },
    {
      "t": 886952,
      "e": 17260,
      "ty": 41,
      "x": 43952,
      "y": 65084,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 887017,
      "e": 17325,
      "ty": 2,
      "x": 808,
      "y": 513
    },
    {
      "t": 887118,
      "e": 17426,
      "ty": 2,
      "x": 703,
      "y": 616
    },
    {
      "t": 887203,
      "e": 17511,
      "ty": 41,
      "x": 33388,
      "y": 52467,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 887218,
      "e": 17526,
      "ty": 2,
      "x": 695,
      "y": 634
    },
    {
      "t": 887319,
      "e": 17627,
      "ty": 2,
      "x": 695,
      "y": 638
    },
    {
      "t": 887421,
      "e": 17729,
      "ty": 2,
      "x": 699,
      "y": 656
    },
    {
      "t": 887454,
      "e": 17762,
      "ty": 41,
      "x": 33803,
      "y": 61439,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 887521,
      "e": 17829,
      "ty": 2,
      "x": 711,
      "y": 666
    },
    {
      "t": 887565,
      "e": 17873,
      "ty": 6,
      "x": 717,
      "y": 686,
      "ta": "#start"
    },
    {
      "t": 887622,
      "e": 17930,
      "ty": 2,
      "x": 719,
      "y": 700
    },
    {
      "t": 887702,
      "e": 18010,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 887704,
      "e": 18012,
      "ty": 41,
      "x": 45328,
      "y": 40869,
      "ta": "#start"
    },
    {
      "t": 887722,
      "e": 18030,
      "ty": 2,
      "x": 719,
      "y": 706
    },
    {
      "t": 887823,
      "e": 18131,
      "ty": 2,
      "x": 720,
      "y": 707
    },
    {
      "t": 887830,
      "e": 18138,
      "ty": 3,
      "x": 720,
      "y": 707,
      "ta": "#start"
    },
    {
      "t": 887934,
      "e": 18242,
      "ty": 4,
      "x": 45874,
      "y": 42796,
      "ta": "#start"
    },
    {
      "t": 890454,
      "e": 20762,
      "ty": 5,
      "x": 720,
      "y": 707,
      "ta": "#start"
    },
    {
      "t": 890473,
      "e": 20781,
      "ty": 41,
      "x": 45874,
      "y": 42796,
      "ta": "#start"
    },
    {
      "t": 890698,
      "e": 21006,
      "ty": 39,
      "x": 0,
      "y": 245,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 890801,
      "e": 21109,
      "ty": 39,
      "x": 0,
      "y": 262,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 890902,
      "e": 21210,
      "ty": 39,
      "x": 0,
      "y": 256,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 891003,
      "e": 21311,
      "ty": 39,
      "x": 0,
      "y": 250,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 891064,
      "e": 21372,
      "ty": 7,
      "x": 853,
      "y": 384,
      "ta": "#start"
    },
    {
      "t": 891104,
      "e": 21412,
      "ty": 39,
      "x": 0,
      "y": 247,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 891153,
      "e": 21461,
      "ty": 2,
      "x": 727,
      "y": 489
    },
    {
      "t": 891205,
      "e": 21513,
      "ty": 39,
      "x": 0,
      "y": 246,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 891226,
      "e": 21534,
      "ty": 41,
      "x": 26760,
      "y": 5649,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 891254,
      "e": 21562,
      "ty": 2,
      "x": 573,
      "y": 552
    },
    {
      "t": 891306,
      "e": 21614,
      "ty": 39,
      "x": 0,
      "y": 245,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 891355,
      "e": 21663,
      "ty": 2,
      "x": 553,
      "y": 557
    },
    {
      "t": 891457,
      "e": 21765,
      "ty": 2,
      "x": 545,
      "y": 563
    },
    {
      "t": 891477,
      "e": 21785,
      "ty": 41,
      "x": 39525,
      "y": 50789,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 891558,
      "e": 21866,
      "ty": 2,
      "x": 538,
      "y": 565
    },
    {
      "t": 891674,
      "e": 21982,
      "ty": 3,
      "x": 538,
      "y": 565,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 891728,
      "e": 22036,
      "ty": 41,
      "x": 26418,
      "y": 54066,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 891777,
      "e": 22085,
      "ty": 4,
      "x": 26418,
      "y": 54066,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 891778,
      "e": 22086,
      "ty": 5,
      "x": 538,
      "y": 565,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 891780,
      "e": 22088,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 891883,
      "e": 22191,
      "ty": 39,
      "x": 0,
      "y": 131,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 892061,
      "e": 22369,
      "ty": 2,
      "x": 539,
      "y": 565
    },
    {
      "t": 892162,
      "e": 22470,
      "ty": 2,
      "x": 685,
      "y": 639
    },
    {
      "t": 892223,
      "e": 22531,
      "ty": 6,
      "x": 721,
      "y": 687,
      "ta": "#start"
    },
    {
      "t": 892229,
      "e": 22537,
      "ty": 41,
      "x": 46420,
      "y": 4246,
      "ta": "#start"
    },
    {
      "t": 892263,
      "e": 22571,
      "ty": 2,
      "x": 724,
      "y": 696
    },
    {
      "t": 892365,
      "e": 22673,
      "ty": 2,
      "x": 725,
      "y": 699
    },
    {
      "t": 892465,
      "e": 22773,
      "ty": 2,
      "x": 723,
      "y": 700
    },
    {
      "t": 892480,
      "e": 22788,
      "ty": 41,
      "x": 46966,
      "y": 29304,
      "ta": "#start"
    },
    {
      "t": 892564,
      "e": 22872,
      "ty": 3,
      "x": 722,
      "y": 701,
      "ta": "#start"
    },
    {
      "t": 892565,
      "e": 22873,
      "ty": 2,
      "x": 722,
      "y": 701
    },
    {
      "t": 892659,
      "e": 22967,
      "ty": 4,
      "x": 46966,
      "y": 31231,
      "ta": "#start"
    },
    {
      "t": 892661,
      "e": 22969,
      "ty": 5,
      "x": 722,
      "y": 701,
      "ta": "#start"
    },
    {
      "t": 892663,
      "e": 22971,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 892731,
      "e": 23039,
      "ty": 41,
      "x": 34507,
      "y": 60393,
      "ta": "html > body"
    },
    {
      "t": 893223,
      "e": 23531,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 893477,
      "e": 23785,
      "ty": 2,
      "x": 739,
      "y": 630
    },
    {
      "t": 893485,
      "e": 23793,
      "ty": 41,
      "x": 35328,
      "y": 54205,
      "ta": "html > body"
    },
    {
      "t": 893578,
      "e": 23886,
      "ty": 2,
      "x": 855,
      "y": 383
    },
    {
      "t": 893669,
      "e": 23977,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 893685,
      "e": 23993,
      "ty": 2,
      "x": 888,
      "y": 343
    },
    {
      "t": 893735,
      "e": 24043,
      "ty": 41,
      "x": 42578,
      "y": 29194,
      "ta": "html > body"
    },
    {
      "t": 893786,
      "e": 24094,
      "ty": 2,
      "x": 889,
      "y": 343
    },
    {
      "t": 894237,
      "e": 24545,
      "ty": 41,
      "x": 42481,
      "y": 29194,
      "ta": "html > body"
    },
    {
      "t": 894291,
      "e": 24599,
      "ty": 2,
      "x": 850,
      "y": 355
    },
    {
      "t": 894338,
      "e": 24646,
      "ty": 6,
      "x": 789,
      "y": 373,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 894391,
      "e": 24699,
      "ty": 2,
      "x": 758,
      "y": 380
    },
    {
      "t": 894488,
      "e": 24796,
      "ty": 41,
      "x": 42966,
      "y": 39665,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 894492,
      "e": 24800,
      "ty": 2,
      "x": 733,
      "y": 382
    },
    {
      "t": 894593,
      "e": 24901,
      "ty": 2,
      "x": 731,
      "y": 383
    },
    {
      "t": 894627,
      "e": 24935,
      "ty": 3,
      "x": 731,
      "y": 384,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 894629,
      "e": 24937,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 894693,
      "e": 25001,
      "ty": 2,
      "x": 731,
      "y": 384
    },
    {
      "t": 894739,
      "e": 25047,
      "ty": 41,
      "x": 42532,
      "y": 46564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 894740,
      "e": 25048,
      "ty": 4,
      "x": 42532,
      "y": 46564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 894740,
      "e": 25048,
      "ty": 5,
      "x": 731,
      "y": 384,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 894949,
      "e": 25257,
      "ty": 7,
      "x": 731,
      "y": 363,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 894990,
      "e": 25298,
      "ty": 41,
      "x": 38430,
      "y": 52735,
      "ta": "#jspsych-survey-text-preamble"
    },
    {
      "t": 894997,
      "e": 25305,
      "ty": 2,
      "x": 730,
      "y": 292
    },
    {
      "t": 895054,
      "e": 25362,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 895097,
      "e": 25405,
      "ty": 2,
      "x": 720,
      "y": 4
    },
    {
      "t": 895241,
      "e": 25549,
      "ty": 41,
      "x": 34797,
      "y": 348,
      "ta": "html"
    },
    {
      "t": 895653,
      "e": 25961,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 898038,
      "e": 28346,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 898040,
      "e": 28348,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 898542,
      "e": 28850,
      "ty": 41,
      "x": 48764,
      "y": 1394,
      "ta": "html > body"
    },
    {
      "t": 898543,
      "e": 28851,
      "ty": 2,
      "x": 1017,
      "y": 24
    },
    {
      "t": 898644,
      "e": 28952,
      "ty": 6,
      "x": 662,
      "y": 371,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 898645,
      "e": 28953,
      "ty": 2,
      "x": 662,
      "y": 371
    },
    {
      "t": 898744,
      "e": 29052,
      "ty": 2,
      "x": 648,
      "y": 388
    },
    {
      "t": 898793,
      "e": 29101,
      "ty": 41,
      "x": 24521,
      "y": 63810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 898809,
      "e": 29117,
      "ty": 7,
      "x": 648,
      "y": 390,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 898845,
      "e": 29153,
      "ty": 2,
      "x": 648,
      "y": 394
    },
    {
      "t": 898947,
      "e": 29255,
      "ty": 2,
      "x": 645,
      "y": 426
    },
    {
      "t": 899043,
      "e": 29351,
      "ty": 41,
      "x": 23130,
      "y": 32077,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 899047,
      "e": 29355,
      "ty": 2,
      "x": 641,
      "y": 446
    },
    {
      "t": 899148,
      "e": 29456,
      "ty": 2,
      "x": 641,
      "y": 456
    },
    {
      "t": 899175,
      "e": 29483,
      "ty": 6,
      "x": 641,
      "y": 468,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 899249,
      "e": 29557,
      "ty": 2,
      "x": 641,
      "y": 479
    },
    {
      "t": 899294,
      "e": 29602,
      "ty": 41,
      "x": 23002,
      "y": 50013,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 899350,
      "e": 29658,
      "ty": 2,
      "x": 641,
      "y": 480
    },
    {
      "t": 899544,
      "e": 29852,
      "ty": 41,
      "x": 22785,
      "y": 43115,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 899551,
      "e": 29859,
      "ty": 2,
      "x": 640,
      "y": 478
    },
    {
      "t": 899569,
      "e": 29877,
      "ty": 3,
      "x": 640,
      "y": 478,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 899570,
      "e": 29878,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 899570,
      "e": 29878,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 899697,
      "e": 30005,
      "ty": 4,
      "x": 22785,
      "y": 43115,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 899697,
      "e": 30005,
      "ty": 5,
      "x": 640,
      "y": 478,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 899923,
      "e": 30231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 899924,
      "e": 30232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 900012,
      "e": 30320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 900030,
      "e": 30338,
      "ty": 7,
      "x": 639,
      "y": 464,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 900045,
      "e": 30353,
      "ty": 41,
      "x": 22701,
      "y": 44494,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 900056,
      "e": 30364,
      "ty": 2,
      "x": 637,
      "y": 458
    },
    {
      "t": 900136,
      "e": 30444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 900137,
      "e": 30445,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 900157,
      "e": 30465,
      "ty": 2,
      "x": 619,
      "y": 406
    },
    {
      "t": 900220,
      "e": 30528,
      "ty": 6,
      "x": 614,
      "y": 388,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 900248,
      "e": 30556,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 900252,
      "e": 30560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 900258,
      "e": 30566,
      "ty": 2,
      "x": 614,
      "y": 385
    },
    {
      "t": 900296,
      "e": 30604,
      "ty": 41,
      "x": 17794,
      "y": 32767,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 900309,
      "e": 30617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 900309,
      "e": 30617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 900359,
      "e": 30667,
      "ty": 2,
      "x": 624,
      "y": 370
    },
    {
      "t": 900448,
      "e": 30756,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 900496,
      "e": 30804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 900546,
      "e": 30854,
      "ty": 41,
      "x": 19530,
      "y": 1724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 900560,
      "e": 30868,
      "ty": 2,
      "x": 625,
      "y": 371
    },
    {
      "t": 900650,
      "e": 30958,
      "ty": 7,
      "x": 625,
      "y": 390,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 900661,
      "e": 30969,
      "ty": 2,
      "x": 625,
      "y": 390
    },
    {
      "t": 900761,
      "e": 31069,
      "ty": 2,
      "x": 625,
      "y": 391
    },
    {
      "t": 900789,
      "e": 31097,
      "ty": 6,
      "x": 625,
      "y": 388,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 900797,
      "e": 31105,
      "ty": 41,
      "x": 19530,
      "y": 60361,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 900863,
      "e": 31171,
      "ty": 2,
      "x": 625,
      "y": 382
    },
    {
      "t": 900891,
      "e": 31199,
      "ty": 3,
      "x": 625,
      "y": 382,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 900892,
      "e": 31200,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 900893,
      "e": 31201,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 900893,
      "e": 31201,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 901011,
      "e": 31319,
      "ty": 4,
      "x": 19530,
      "y": 39665,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 901012,
      "e": 31320,
      "ty": 5,
      "x": 625,
      "y": 382,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 901048,
      "e": 31356,
      "ty": 41,
      "x": 19530,
      "y": 46564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 901065,
      "e": 31373,
      "ty": 2,
      "x": 625,
      "y": 384
    },
    {
      "t": 901223,
      "e": 31531,
      "ty": 7,
      "x": 639,
      "y": 347,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 901266,
      "e": 31574,
      "ty": 2,
      "x": 705,
      "y": 236
    },
    {
      "t": 901298,
      "e": 31606,
      "ty": 41,
      "x": 37068,
      "y": 10370,
      "ta": "html > body"
    },
    {
      "t": 901368,
      "e": 31676,
      "ty": 2,
      "x": 815,
      "y": 58
    },
    {
      "t": 901468,
      "e": 31776,
      "ty": 2,
      "x": 816,
      "y": 30
    },
    {
      "t": 901550,
      "e": 31858,
      "ty": 41,
      "x": 39098,
      "y": 0,
      "ta": "html > body"
    },
    {
      "t": 901569,
      "e": 31877,
      "ty": 2,
      "x": 820,
      "y": 4
    },
    {
      "t": 901572,
      "e": 31880,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 901800,
      "e": 32108,
      "ty": 41,
      "x": 39630,
      "y": 348,
      "ta": "html"
    },
    {
      "t": 901929,
      "e": 32237,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 903862,
      "e": 34170,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 903863,
      "e": 34171,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 904265,
      "e": 34573,
      "ty": 2,
      "x": 806,
      "y": 261
    },
    {
      "t": 904317,
      "e": 34625,
      "ty": 6,
      "x": 752,
      "y": 373,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 904365,
      "e": 34673,
      "ty": 41,
      "x": 47089,
      "y": 39665,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 904366,
      "e": 34674,
      "ty": 2,
      "x": 752,
      "y": 382
    },
    {
      "t": 904466,
      "e": 34774,
      "ty": 2,
      "x": 760,
      "y": 388
    },
    {
      "t": 904616,
      "e": 34924,
      "ty": 41,
      "x": 48825,
      "y": 60361,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 905220,
      "e": 35528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 905479,
      "e": 35787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 905480,
      "e": 35788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 905668,
      "e": 35976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "S"
    },
    {
      "t": 905827,
      "e": 36135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 905828,
      "e": 36136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 905943,
      "e": 36251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ST"
    },
    {
      "t": 906319,
      "e": 36627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 906319,
      "e": 36627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 906443,
      "e": 36751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 906444,
      "e": 36752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 906449,
      "e": 36757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRA"
    },
    {
      "t": 906571,
      "e": 36879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 906571,
      "e": 36879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 906615,
      "e": 36923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||T"
    },
    {
      "t": 906707,
      "e": 37015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 906707,
      "e": 37015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 906743,
      "e": 37051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 906859,
      "e": 37167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "71"
    },
    {
      "t": 906859,
      "e": 37167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 906871,
      "e": 37179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||G"
    },
    {
      "t": 907043,
      "e": 37351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 907060,
      "e": 37368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 907061,
      "e": 37369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 907212,
      "e": 37520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||Y"
    },
    {
      "t": 907677,
      "e": 37985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "189"
    },
    {
      "t": 907677,
      "e": 37985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 907797,
      "e": 38105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 907798,
      "e": 38106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 907821,
      "e": 38129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||-S"
    },
    {
      "t": 907969,
      "e": 38277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 907970,
      "e": 38278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 908057,
      "e": 38365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||A"
    },
    {
      "t": 908081,
      "e": 38389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "84"
    },
    {
      "t": 908081,
      "e": 38389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 908105,
      "e": 38413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||T"
    },
    {
      "t": 908285,
      "e": 38593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 908285,
      "e": 38593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 908313,
      "e": 38621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||S"
    },
    {
      "t": 908397,
      "e": 38705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 908630,
      "e": 38938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 908718,
      "e": 39026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRATEGY-SAT"
    },
    {
      "t": 908864,
      "e": 39172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 908864,
      "e": 39172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 909000,
      "e": 39308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 909000,
      "e": 39308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 909024,
      "e": 39332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||IS"
    },
    {
      "t": 909196,
      "e": 39504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 909204,
      "e": 39512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "70"
    },
    {
      "t": 909204,
      "e": 39512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 909348,
      "e": 39656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||F"
    },
    {
      "t": 909452,
      "e": 39760,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 909622,
      "e": 39930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 909622,
      "e": 39930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 909750,
      "e": 40058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||I"
    },
    {
      "t": 909758,
      "e": 40066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 909758,
      "e": 40066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 909882,
      "e": 40190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||C"
    },
    {
      "t": 909894,
      "e": 40202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 909894,
      "e": 40202,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 910058,
      "e": 40366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 910058,
      "e": 40366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 910130,
      "e": 40438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||IN"
    },
    {
      "t": 910170,
      "e": 40478,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "71"
    },
    {
      "t": 910171,
      "e": 40479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 910175,
      "e": 40483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||G"
    },
    {
      "t": 910298,
      "e": 40606,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRATEGY-SATISFICING"
    },
    {
      "t": 910335,
      "e": 40643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 910342,
      "e": 40650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 910524,
      "e": 40832,
      "ty": 7,
      "x": 772,
      "y": 349,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 910526,
      "e": 40834,
      "ty": 2,
      "x": 772,
      "y": 349
    },
    {
      "t": 910626,
      "e": 40934,
      "ty": 2,
      "x": 788,
      "y": 92
    },
    {
      "t": 910638,
      "e": 40946,
      "ty": 41,
      "x": 37648,
      "y": 5228,
      "ta": "html > body"
    },
    {
      "t": 910728,
      "e": 41036,
      "ty": 2,
      "x": 773,
      "y": 41
    },
    {
      "t": 910829,
      "e": 41137,
      "ty": 2,
      "x": 767,
      "y": 68
    },
    {
      "t": 910889,
      "e": 41197,
      "ty": 41,
      "x": 37117,
      "y": 2091,
      "ta": "html > body"
    },
    {
      "t": 910930,
      "e": 41238,
      "ty": 2,
      "x": 788,
      "y": 1
    },
    {
      "t": 910942,
      "e": 41250,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 911139,
      "e": 41447,
      "ty": 41,
      "x": 38083,
      "y": 87,
      "ta": "html"
    },
    {
      "t": 911201,
      "e": 41509,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 917030,
      "e": 46509,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 917031,
      "e": 46510,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 917392,
      "e": 46871,
      "ty": 2,
      "x": 1036,
      "y": 14
    },
    {
      "t": 917491,
      "e": 46970,
      "ty": 41,
      "x": 52470,
      "y": 7243,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 917492,
      "e": 46971,
      "ty": 2,
      "x": 778,
      "y": 315
    },
    {
      "t": 917593,
      "e": 47072,
      "ty": 2,
      "x": 763,
      "y": 357
    },
    {
      "t": 917620,
      "e": 47099,
      "ty": 6,
      "x": 765,
      "y": 377,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 917637,
      "e": 47116,
      "ty": 7,
      "x": 765,
      "y": 392,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 917694,
      "e": 47173,
      "ty": 2,
      "x": 757,
      "y": 451
    },
    {
      "t": 917707,
      "e": 47186,
      "ty": 6,
      "x": 754,
      "y": 465,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 917742,
      "e": 47221,
      "ty": 41,
      "x": 45787,
      "y": 60361,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 917759,
      "e": 47238,
      "ty": 7,
      "x": 743,
      "y": 488,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 917794,
      "e": 47273,
      "ty": 2,
      "x": 739,
      "y": 493
    },
    {
      "t": 917812,
      "e": 47291,
      "ty": 6,
      "x": 737,
      "y": 494,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 917895,
      "e": 47374,
      "ty": 2,
      "x": 733,
      "y": 497
    },
    {
      "t": 917993,
      "e": 47472,
      "ty": 41,
      "x": 52352,
      "y": 16880,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 917996,
      "e": 47475,
      "ty": 2,
      "x": 724,
      "y": 503
    },
    {
      "t": 918096,
      "e": 47575,
      "ty": 2,
      "x": 720,
      "y": 506
    },
    {
      "t": 918179,
      "e": 47658,
      "ty": 3,
      "x": 716,
      "y": 506,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 918180,
      "e": 47659,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRATEGY-SATISFICING"
    },
    {
      "t": 918180,
      "e": 47659,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 918196,
      "e": 47675,
      "ty": 2,
      "x": 715,
      "y": 506
    },
    {
      "t": 918244,
      "e": 47723,
      "ty": 41,
      "x": 47713,
      "y": 22837,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 918315,
      "e": 47794,
      "ty": 4,
      "x": 47713,
      "y": 22837,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 918318,
      "e": 47797,
      "ty": 5,
      "x": 715,
      "y": 506,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 918319,
      "e": 47798,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 918491,
      "e": 47970,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 919453,
      "e": 48932,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 919657,
      "e": 49136,
      "ty": 38,
      "x": 10,
      "y": 0
    },
    {
      "t": 919992,
      "e": 49471,
      "ty": 38,
      "x": 11,
      "y": 0
    },
    {
      "t": 921327,
      "e": 50806,
      "ty": 1,
      "x": 0,
      "y": 12
    },
    {
      "t": 921427,
      "e": 50906,
      "ty": 1,
      "x": 0,
      "y": 18
    },
    {
      "t": 921528,
      "e": 51007,
      "ty": 1,
      "x": 0,
      "y": 17
    },
    {
      "t": 921619,
      "e": 51098,
      "ty": 6,
      "x": 715,
      "y": 522,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 921629,
      "e": 51108,
      "ty": 2,
      "x": 715,
      "y": 521
    },
    {
      "t": 921629,
      "e": 51108,
      "ty": 1,
      "x": 0,
      "y": 12
    },
    {
      "t": 921640,
      "e": 51119,
      "ty": 7,
      "x": 708,
      "y": 532,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 921641,
      "e": 51120,
      "ty": 6,
      "x": 708,
      "y": 532,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 921675,
      "e": 51154,
      "ty": 7,
      "x": 701,
      "y": 561,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 921676,
      "e": 51155,
      "ty": 6,
      "x": 701,
      "y": 561,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 921709,
      "e": 51188,
      "ty": 7,
      "x": 694,
      "y": 603,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 921730,
      "e": 51209,
      "ty": 2,
      "x": 693,
      "y": 625
    },
    {
      "t": 921730,
      "e": 51209,
      "ty": 1,
      "x": 0,
      "y": 10
    },
    {
      "t": 921755,
      "e": 51234,
      "ty": 41,
      "x": 33250,
      "y": 60872,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 921830,
      "e": 51309,
      "ty": 2,
      "x": 696,
      "y": 676
    },
    {
      "t": 921830,
      "e": 51309,
      "ty": 1,
      "x": 0,
      "y": 9
    },
    {
      "t": 921896,
      "e": 51375,
      "ty": 6,
      "x": 700,
      "y": 684,
      "ta": "#start"
    },
    {
      "t": 921930,
      "e": 51409,
      "ty": 2,
      "x": 701,
      "y": 686
    },
    {
      "t": 921930,
      "e": 51409,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 922006,
      "e": 51485,
      "ty": 41,
      "x": 37682,
      "y": 25449,
      "ta": "#start"
    },
    {
      "t": 922032,
      "e": 51511,
      "ty": 2,
      "x": 706,
      "y": 700
    },
    {
      "t": 922133,
      "e": 51612,
      "ty": 2,
      "x": 707,
      "y": 706
    },
    {
      "t": 922157,
      "e": 51636,
      "ty": 3,
      "x": 707,
      "y": 707,
      "ta": "#start"
    },
    {
      "t": 922234,
      "e": 51713,
      "ty": 2,
      "x": 707,
      "y": 707
    },
    {
      "t": 922257,
      "e": 51736,
      "ty": 41,
      "x": 38774,
      "y": 42796,
      "ta": "#start"
    },
    {
      "t": 922277,
      "e": 51756,
      "ty": 4,
      "x": 38774,
      "y": 42796,
      "ta": "#start"
    },
    {
      "t": 922278,
      "e": 51757,
      "ty": 5,
      "x": 707,
      "y": 707,
      "ta": "#start"
    },
    {
      "t": 922280,
      "e": 51759,
      "ty": 38,
      "x": 12,
      "y": 0
    },
    {
      "t": 922739,
      "e": 52218,
      "ty": 2,
      "x": 722,
      "y": 646
    },
    {
      "t": 922758,
      "e": 52237,
      "ty": 41,
      "x": 35280,
      "y": 50458,
      "ta": "html > body"
    },
    {
      "t": 922839,
      "e": 52318,
      "ty": 2,
      "x": 828,
      "y": 307
    },
    {
      "t": 922940,
      "e": 52419,
      "ty": 2,
      "x": 868,
      "y": 254
    },
    {
      "t": 922994,
      "e": 52473,
      "ty": 38,
      "x": 13,
      "y": 0
    },
    {
      "t": 923009,
      "e": 52488,
      "ty": 41,
      "x": 41611,
      "y": 21438,
      "ta": "html > body"
    },
    {
      "t": 923042,
      "e": 52521,
      "ty": 2,
      "x": 869,
      "y": 254
    },
    {
      "t": 923282,
      "e": 52761,
      "ty": 38,
      "x": 14,
      "y": 0
    },
    {
      "t": 924154,
      "e": 53633,
      "ty": 2,
      "x": 787,
      "y": 319
    },
    {
      "t": 924255,
      "e": 53734,
      "ty": 2,
      "x": 726,
      "y": 380
    },
    {
      "t": 924264,
      "e": 53743,
      "ty": 41,
      "x": 34709,
      "y": 34941,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 924356,
      "e": 53835,
      "ty": 2,
      "x": 715,
      "y": 403
    },
    {
      "t": 924457,
      "e": 53936,
      "ty": 2,
      "x": 715,
      "y": 405
    },
    {
      "t": 924516,
      "e": 53995,
      "ty": 41,
      "x": 34175,
      "y": 36882,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 924860,
      "e": 54339,
      "ty": 2,
      "x": 716,
      "y": 404
    },
    {
      "t": 924960,
      "e": 54439,
      "ty": 2,
      "x": 717,
      "y": 404
    },
    {
      "t": 925017,
      "e": 54496,
      "ty": 41,
      "x": 34272,
      "y": 36805,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 925062,
      "e": 54541,
      "ty": 2,
      "x": 717,
      "y": 405
    },
    {
      "t": 925163,
      "e": 54642,
      "ty": 2,
      "x": 711,
      "y": 416
    },
    {
      "t": 925264,
      "e": 54743,
      "ty": 2,
      "x": 708,
      "y": 425
    },
    {
      "t": 925267,
      "e": 54746,
      "ty": 41,
      "x": 33835,
      "y": 38435,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 925365,
      "e": 54844,
      "ty": 2,
      "x": 707,
      "y": 426
    },
    {
      "t": 925466,
      "e": 54945,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 925518,
      "e": 54997,
      "ty": 41,
      "x": 33786,
      "y": 38513,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 925567,
      "e": 55046,
      "ty": 1,
      "x": 0,
      "y": 69
    },
    {
      "t": 925667,
      "e": 55146,
      "ty": 1,
      "x": 0,
      "y": 72
    },
    {
      "t": 925767,
      "e": 55246,
      "ty": 2,
      "x": 707,
      "y": 490
    },
    {
      "t": 925767,
      "e": 55246,
      "ty": 41,
      "x": 33786,
      "y": 43482,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 925868,
      "e": 55347,
      "ty": 1,
      "x": 0,
      "y": 70
    },
    {
      "t": 925968,
      "e": 55447,
      "ty": 1,
      "x": 0,
      "y": 69
    },
    {
      "t": 926069,
      "e": 55548,
      "ty": 2,
      "x": 704,
      "y": 491
    },
    {
      "t": 926069,
      "e": 55548,
      "ty": 1,
      "x": 0,
      "y": 68
    },
    {
      "t": 926169,
      "e": 55648,
      "ty": 2,
      "x": 670,
      "y": 621
    },
    {
      "t": 926269,
      "e": 55748,
      "ty": 41,
      "x": 33010,
      "y": 58236,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 926269,
      "e": 55748,
      "ty": 2,
      "x": 691,
      "y": 680
    },
    {
      "t": 926370,
      "e": 55849,
      "ty": 2,
      "x": 709,
      "y": 680
    },
    {
      "t": 926470,
      "e": 55949,
      "ty": 2,
      "x": 711,
      "y": 673
    },
    {
      "t": 926520,
      "e": 55999,
      "ty": 41,
      "x": 33981,
      "y": 57692,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 927046,
      "e": 56525,
      "ty": 38,
      "x": 15,
      "y": 0
    },
    {
      "t": 927077,
      "e": 56556,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 927178,
      "e": 56657,
      "ty": 2,
      "x": 711,
      "y": 613
    },
    {
      "t": 927274,
      "e": 56753,
      "ty": 41,
      "x": 33975,
      "y": 52724,
      "ta": "html > body"
    },
    {
      "t": 927498,
      "e": 56977,
      "ty": 38,
      "x": 16,
      "y": 0
    },
    {
      "t": 927776,
      "e": 57255,
      "ty": 41,
      "x": 40790,
      "y": 40175,
      "ta": "html > body"
    },
    {
      "t": 927783,
      "e": 57262,
      "ty": 2,
      "x": 905,
      "y": 423
    },
    {
      "t": 927883,
      "e": 57362,
      "ty": 2,
      "x": 1040,
      "y": 350
    },
    {
      "t": 927984,
      "e": 57463,
      "ty": 2,
      "x": 1046,
      "y": 346
    },
    {
      "t": 928026,
      "e": 57505,
      "ty": 41,
      "x": 50069,
      "y": 29368,
      "ta": "html > body"
    },
    {
      "t": 928055,
      "e": 57534,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":61}],[{\"nodeType\":1,\"id\":62,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":63,\"previousSibling\":{\"id\":62},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":64,\"textContent\":\" \",\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"parentNode\":{\"id\":62}},{\"nodeType\":1,\"id\":66,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":62}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":62}},{\"nodeType\":8,\"id\":68,\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":62}},{\"nodeType\":3,\"id\":69,\"textContent\":\" \",\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":62}},{\"nodeType\":1,\"id\":70,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":62}},{\"nodeType\":8,\"id\":71,\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":62}},{\"nodeType\":3,\"id\":72,\"textContent\":\" \",\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":62}},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":62}},{\"nodeType\":8,\"id\":74,\"previousSibling\":{\"id\":73},\"parentNode\":{\"id\":62}},{\"nodeType\":3,\"id\":75,\"textContent\":\" \",\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":62}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"parentNode\":{\"id\":66}},{\"nodeType\":1,\"id\":77,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":76},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":78,\"textContent\":\" \",\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"parentNode\":{\"id\":77}},{\"nodeType\":1,\"id\":80,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":79},\"parentNode\":{\"id\":77}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"previousSibling\":{\"id\":80},\"parentNode\":{\"id\":77}},{\"nodeType\":3,\"id\":82,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":80}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"parentNode\":{\"id\":70}},{\"nodeType\":1,\"id\":84,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":83},\"parentNode\":{\"id\":70}},{\"nodeType\":3,\"id\":85,\"textContent\":\" \",\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":70}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"parentNode\":{\"id\":84}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":84}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":84}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":84}},{\"nodeType\":1,\"id\":93,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":84}},{\"nodeType\":8,\"id\":95,\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":84}},{\"nodeType\":1,\"id\":97,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":96},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":98,\"textContent\":\" \",\"previousSibling\":{\"id\":97},\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":99,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":100,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":101,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":102,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":93}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"parentNode\":{\"id\":97}},{\"nodeType\":1,\"id\":104,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":103},\"parentNode\":{\"id\":97}},{\"nodeType\":3,\"id\":105,\"textContent\":\" \",\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":97}},{\"nodeType\":3,\"id\":106,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":104}},{\"nodeType\":1,\"id\":107,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":104}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":104}},{\"nodeType\":1,\"id\":109,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":108},\"parentNode\":{\"id\":104}},{\"nodeType\":3,\"id\":110,\"textContent\":\" \",\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":104}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"parentNode\":{\"id\":73}},{\"nodeType\":1,\"id\":112,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":111},\"parentNode\":{\"id\":73}},{\"nodeType\":3,\"id\":113,\"textContent\":\" \",\"previousSibling\":{\"id\":112},\"parentNode\":{\"id\":73}},{\"nodeType\":3,\"id\":114,\"textContent\":\"START\",\"parentNode\":{\"id\":112}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":115,\"tagName\":\"SCRIPT\",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":62},{\"id\":65},{\"id\":66},{\"id\":76},{\"id\":77},{\"id\":79},{\"id\":80},{\"id\":82},{\"id\":81},{\"id\":78},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":83},{\"id\":84},{\"id\":86},{\"id\":87},{\"id\":99},{\"id\":88},{\"id\":89},{\"id\":100},{\"id\":90},{\"id\":91},{\"id\":101},{\"id\":92},{\"id\":93},{\"id\":102},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":103},{\"id\":104},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":105},{\"id\":98},{\"id\":85},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":111},{\"id\":112},{\"id\":114},{\"id\":113},{\"id\":74},{\"id\":75},{\"id\":63},{\"id\":64},{\"id\":115}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":116,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":117,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"previousSibling\":{\"id\":116},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":118,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":117},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":119,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":118},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":120,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":121,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":117}},{\"nodeType\":3,\"id\":122,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":121}},{\"nodeType\":1,\"id\":123,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":118}},{\"nodeType\":1,\"id\":124,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":123},\"parentNode\":{\"id\":118}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":123}},{\"nodeType\":1,\"id\":126,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":127,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":119}},{\"nodeType\":3,\"id\":128,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":129,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":120}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":116},{\"id\":117},{\"id\":121},{\"id\":122},{\"id\":118},{\"id\":123},{\"id\":125},{\"id\":124},{\"id\":119},{\"id\":126},{\"id\":128},{\"id\":127},{\"id\":120},{\"id\":129}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":130,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 10,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":130}],[{\"nodeType\":1,\"id\":131,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"previousSibling\":{\"id\":131},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":136,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":131}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":133}},{\"nodeType\":8,\"id\":139,\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":140,\"textContent\":\" \",\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":141,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":133}},{\"nodeType\":8,\"id\":143,\"previousSibling\":{\"id\":142},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":144,\"textContent\":\" \",\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":145,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":8,\"id\":146,\"previousSibling\":{\"id\":145},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \",\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"parentNode\":{\"id\":138}},{\"nodeType\":1,\"id\":149,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":148},\"parentNode\":{\"id\":138}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"previousSibling\":{\"id\":149},\"parentNode\":{\"id\":138}},{\"nodeType\":3,\"id\":151,\"textContent\":\" \",\"parentNode\":{\"id\":149}},{\"nodeType\":1,\"id\":152,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":149}},{\"nodeType\":3,\"id\":153,\"textContent\":\" \",\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":149}},{\"nodeType\":3,\"id\":154,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":152}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":141}},{\"nodeType\":1,\"id\":156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":141}},{\"nodeType\":3,\"id\":157,\"textContent\":\" \",\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":141}},{\"nodeType\":8,\"id\":158,\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":141}},{\"nodeType\":3,\"id\":159,\"textContent\":\" \",\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":141}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":161,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":162,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \",\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":164,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":165,\"textContent\":\" \",\"previousSibling\":{\"id\":164},\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":168,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":167},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"previousSibling\":{\"id\":168},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":170,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":171,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":170},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":172,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":173,\"textContent\":\"all\",\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \",\"parentNode\":{\"id\":162}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":162}},{\"nodeType\":1,\"id\":176,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":177,\"textContent\":\" \",\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":175}},{\"nodeType\":1,\"id\":178,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":175}},{\"nodeType\":1,\"id\":180,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":180},\"parentNode\":{\"id\":175}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":175}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":175}},{\"nodeType\":3,\"id\":186,\"textContent\":\" \",\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":187,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":186},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"previousSibling\":{\"id\":187},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":187}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":178}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":178}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":178}},{\"nodeType\":1,\"id\":196,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":197,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":198,\"textContent\":\" \",\"parentNode\":{\"id\":182}},{\"nodeType\":1,\"id\":199,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":198},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"previousSibling\":{\"id\":199},\"parentNode\":{\"id\":182}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":182}},{\"nodeType\":1,\"id\":203,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":199}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":205,\"textContent\":\" \",\"parentNode\":{\"id\":184}},{\"nodeType\":1,\"id\":206,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":207,\"textContent\":\" \",\"previousSibling\":{\"id\":206},\"parentNode\":{\"id\":184}},{\"nodeType\":1,\"id\":208,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":206}},{\"nodeType\":3,\"id\":209,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":208}},{\"nodeType\":1,\"id\":210,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":164}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \",\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":164}},{\"nodeType\":3,\"id\":212,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":210}},{\"nodeType\":3,\"id\":213,\"textContent\":\" \\t\",\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":214,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":215,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":216,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":217,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":216},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":218,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":220,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":221,\"textContent\":\" \",\"previousSibling\":{\"id\":220},\"parentNode\":{\"id\":166}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":214}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":214}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":223},\"parentNode\":{\"id\":214}},{\"nodeType\":3,\"id\":225,\"textContent\":\" \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":214}},{\"nodeType\":3,\"id\":226,\"textContent\":\"carefully\",\"parentNode\":{\"id\":224}},{\"nodeType\":1,\"id\":227,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":216}},{\"nodeType\":3,\"id\":228,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":227},\"parentNode\":{\"id\":216}},{\"nodeType\":1,\"id\":229,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":218}},{\"nodeType\":3,\"id\":230,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":218}},{\"nodeType\":1,\"id\":231,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":220}},{\"nodeType\":3,\"id\":232,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":231},\"parentNode\":{\"id\":220}},{\"nodeType\":3,\"id\":233,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":168}},{\"nodeType\":3,\"id\":234,\"textContent\":\" \\t\",\"parentNode\":{\"id\":145}},{\"nodeType\":1,\"id\":235,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":234},\"parentNode\":{\"id\":145}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \",\"previousSibling\":{\"id\":235},\"parentNode\":{\"id\":145}},{\"nodeType\":3,\"id\":237,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":235}}],[],[]]}"
    },
    {
      "sequence": 11,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":238,\"tagName\":\"SCRIPT\",\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 12,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":131},{\"id\":136},{\"id\":132},{\"id\":133},{\"id\":137},{\"id\":138},{\"id\":148},{\"id\":149},{\"id\":151},{\"id\":152},{\"id\":154},{\"id\":153},{\"id\":150},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":155},{\"id\":156},{\"id\":160},{\"id\":161},{\"id\":170},{\"id\":171},{\"id\":173},{\"id\":172},{\"id\":162},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":186},{\"id\":187},{\"id\":191},{\"id\":188},{\"id\":189},{\"id\":192},{\"id\":190},{\"id\":177},{\"id\":178},{\"id\":193},{\"id\":194},{\"id\":196},{\"id\":197},{\"id\":195},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":198},{\"id\":199},{\"id\":203},{\"id\":200},{\"id\":201},{\"id\":204},{\"id\":202},{\"id\":183},{\"id\":184},{\"id\":205},{\"id\":206},{\"id\":208},{\"id\":209},{\"id\":207},{\"id\":185},{\"id\":163},{\"id\":164},{\"id\":210},{\"id\":212},{\"id\":211},{\"id\":165},{\"id\":166},{\"id\":213},{\"id\":214},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":226},{\"id\":225},{\"id\":215},{\"id\":216},{\"id\":227},{\"id\":228},{\"id\":217},{\"id\":218},{\"id\":229},{\"id\":230},{\"id\":219},{\"id\":220},{\"id\":231},{\"id\":232},{\"id\":221},{\"id\":167},{\"id\":168},{\"id\":233},{\"id\":169},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":234},{\"id\":235},{\"id\":237},{\"id\":236},{\"id\":146},{\"id\":147},{\"id\":134},{\"id\":135},{\"id\":238}],[],[],[]]}"
    },
    {
      "sequence": 13,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":239,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}}],[],[]]}"
    },
    {
      "sequence": 14,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":240,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"previousSibling\":{\"id\":239},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":241,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":240},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":242,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":241}}],[],[]]}"
    },
    {
      "sequence": 15,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242}],[],[],[]]}"
    },
    {
      "sequence": 16,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":243,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\",\"style\":\"\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":60,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 254, dom: 1355, initialDom: 1359",
  "javascriptErrors": []
}