var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fba4fa51f4664214534b6b510c474c5d",
  "created": "2018-05-21T12:24:20.8146099-07:00",
  "lastActivity": "2018-05-21T12:39:48.8696099-07:00",
  "pageViews": [
    {
      "id": "052120853aa59c5b4500c93edd695582e1c8ed9d",
      "startTime": "2018-05-21T12:24:20.8146099-07:00",
      "endTime": "2018-05-21T12:39:48.8696099-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 928055,
      "engagementTime": 57534,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 928055,
  "engagementTime": 57534,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.9.204",
  "lang": "en-us",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/604.5.6 (KHTML, like Gecko) Version/11.0.3 Safari/604.5.6",
  "browser": "Safari",
  "browserVersion": "11.0.3",
  "os": "OS X",
  "osVersion": "10.11 El Capitan",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1f46675781f746c1c4bd42fb9d208c4c",
  "gdpr": false
}