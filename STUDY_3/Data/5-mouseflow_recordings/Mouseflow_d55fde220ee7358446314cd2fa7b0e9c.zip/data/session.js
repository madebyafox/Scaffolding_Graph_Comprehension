var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d55fde220ee7358446314cd2fa7b0e9c",
  "created": "2018-05-29T12:01:35.721929-07:00",
  "lastActivity": "2018-05-29T12:05:37.1569439-07:00",
  "pageViews": [
    {
      "id": "0529350140fab716ca4854574681b1f02b521b56",
      "startTime": "2018-05-29T12:01:36.0029955-07:00",
      "endTime": "2018-05-29T12:05:37.1569439-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 241377,
      "engagementTime": 45350,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 241377,
  "engagementTime": 45350,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2920c46d7d9cc53ec012fe2ba9c0cf24",
  "gdpr": false
}