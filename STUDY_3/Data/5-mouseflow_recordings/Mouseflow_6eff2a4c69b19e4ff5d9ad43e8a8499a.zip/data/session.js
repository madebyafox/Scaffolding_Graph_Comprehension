var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6eff2a4c69b19e4ff5d9ad43e8a8499a",
  "created": "2018-05-16T11:06:15.3478524-07:00",
  "lastActivity": "2018-05-16T11:06:49.5672939-07:00",
  "pageViews": [
    {
      "id": "05161518c1962048ac2bb97b9e693b54046e8834",
      "startTime": "2018-05-16T11:06:15.3478524-07:00",
      "endTime": "2018-05-16T11:06:49.5672939-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 34231,
      "engagementTime": 34231,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 34231,
  "engagementTime": 34231,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=HJ5O5",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a2cbc937807318c9e6dd4036b0dd518f",
  "gdpr": false
}