var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "bf86024f379195a5c6a12d22bb7387c1",
  "created": "2018-05-18T11:13:21.3590486-07:00",
  "lastActivity": "2018-05-18T11:14:13.2398175-07:00",
  "pageViews": [
    {
      "id": "05182191d6e9449d0b81b757fe6b7a3a3f8fde33",
      "startTime": "2018-05-18T11:13:21.4503747-07:00",
      "endTime": "2018-05-18T11:14:13.2398175-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 51843,
      "engagementTime": 48076,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 51843,
  "engagementTime": 48076,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8U980",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "eb760eee877a0d20b1a0ad111db35471",
  "gdpr": false
}