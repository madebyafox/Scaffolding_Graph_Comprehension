var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d70c4c39fe93440a9622a1aeb22bf593",
  "created": "2018-06-01T10:09:52.9106941-07:00",
  "lastActivity": "2018-06-01T10:10:08.150051-07:00",
  "pageViews": [
    {
      "id": "06015274343ee92c5ffb45fcea8501f1c6e202c6",
      "startTime": "2018-06-01T10:09:52.9106941-07:00",
      "endTime": "2018-06-01T10:10:08.150051-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 15254,
      "engagementTime": 14608,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15254,
  "engagementTime": 14608,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=GZ705",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "96dd1bb9622a145a2aa7b89d0fccfd15",
  "gdpr": false
}