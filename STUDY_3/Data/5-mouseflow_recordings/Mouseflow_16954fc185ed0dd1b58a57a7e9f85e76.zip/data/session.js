var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "16954fc185ed0dd1b58a57a7e9f85e76",
  "created": "2018-06-04T13:17:12.8975138-07:00",
  "lastActivity": "2018-06-04T13:17:47.6079323-07:00",
  "pageViews": [
    {
      "id": "06041357cde92202d5fc3751f8900c5f2cdc058b",
      "startTime": "2018-06-04T13:17:12.9149323-07:00",
      "endTime": "2018-06-04T13:17:47.6079323-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 34693,
      "engagementTime": 34592,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 34693,
  "engagementTime": 34592,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=BHZYG",
    "CONDITION=211",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "67a651afc3058e594b24cc9da26877b6",
  "gdpr": false
}