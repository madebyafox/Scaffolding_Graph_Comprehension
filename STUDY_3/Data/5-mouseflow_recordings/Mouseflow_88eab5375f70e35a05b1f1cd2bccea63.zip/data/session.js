var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "88eab5375f70e35a05b1f1cd2bccea63",
  "created": "2018-06-01T09:18:39.4924307-07:00",
  "lastActivity": "2018-06-01T09:19:11.3674307-07:00",
  "pageViews": [
    {
      "id": "06013917c138b3628674659317e2e2eba68376e0",
      "startTime": "2018-06-01T09:18:39.4924307-07:00",
      "endTime": "2018-06-01T09:19:11.3674307-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 31875,
      "engagementTime": 31126,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 31875,
  "engagementTime": 31126,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DZD6F",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d19d5ae2948fbae09deb7ee405d22ca7",
  "gdpr": false
}