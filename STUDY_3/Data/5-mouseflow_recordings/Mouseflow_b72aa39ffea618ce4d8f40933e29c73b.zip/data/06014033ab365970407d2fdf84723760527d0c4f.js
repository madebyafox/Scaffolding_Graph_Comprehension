var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06014033ab365970407d2fdf84723760527d0c4f"] = {
  "startTime": "2018-06-01T18:18:40.6217339Z",
  "websitePageUrl": "/16",
  "visitTime": 273013,
  "engagementTime": 167216,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "b72aa39ffea618ce4d8f40933e29c73b",
    "created": "2018-06-01T18:18:40.6217339+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=F9531",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "97a2ceef14545e8f7ec13befec208193",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/b72aa39ffea618ce4d8f40933e29c73b/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 251,
      "e": 251,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 6500,
      "e": 5251,
      "ty": 2,
      "x": 518,
      "y": 754
    },
    {
      "t": 6500,
      "e": 5251,
      "ty": 41,
      "x": 47314,
      "y": 41326,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 8704,
      "e": 7455,
      "ty": 2,
      "x": 535,
      "y": 760
    },
    {
      "t": 8754,
      "e": 7505,
      "ty": 41,
      "x": 51135,
      "y": 41769,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 8856,
      "e": 7607,
      "ty": 2,
      "x": 788,
      "y": 781
    },
    {
      "t": 8904,
      "e": 7655,
      "ty": 2,
      "x": 863,
      "y": 785
    },
    {
      "t": 9003,
      "e": 7754,
      "ty": 2,
      "x": 1096,
      "y": 817
    },
    {
      "t": 9004,
      "e": 7755,
      "ty": 41,
      "x": 21846,
      "y": 48631,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9103,
      "e": 7854,
      "ty": 2,
      "x": 1266,
      "y": 821
    },
    {
      "t": 9204,
      "e": 7955,
      "ty": 2,
      "x": 1314,
      "y": 834
    },
    {
      "t": 9254,
      "e": 8005,
      "ty": 41,
      "x": 37630,
      "y": 50136,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9303,
      "e": 8054,
      "ty": 2,
      "x": 1328,
      "y": 845
    },
    {
      "t": 9403,
      "e": 8154,
      "ty": 2,
      "x": 1315,
      "y": 864
    },
    {
      "t": 9504,
      "e": 8255,
      "ty": 2,
      "x": 1307,
      "y": 888
    },
    {
      "t": 9504,
      "e": 8255,
      "ty": 41,
      "x": 36714,
      "y": 53717,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9604,
      "e": 8355,
      "ty": 2,
      "x": 1290,
      "y": 902
    },
    {
      "t": 9704,
      "e": 8455,
      "ty": 2,
      "x": 1250,
      "y": 927
    },
    {
      "t": 9753,
      "e": 8504,
      "ty": 41,
      "x": 29456,
      "y": 57584,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9804,
      "e": 8555,
      "ty": 2,
      "x": 1189,
      "y": 951
    },
    {
      "t": 9904,
      "e": 8655,
      "ty": 2,
      "x": 1176,
      "y": 956
    },
    {
      "t": 10004,
      "e": 8755,
      "ty": 2,
      "x": 1170,
      "y": 962
    },
    {
      "t": 10004,
      "e": 8755,
      "ty": 41,
      "x": 27060,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10005,
      "e": 8756,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10104,
      "e": 8855,
      "ty": 2,
      "x": 1162,
      "y": 966
    },
    {
      "t": 10254,
      "e": 9005,
      "ty": 41,
      "x": 26496,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10404,
      "e": 9155,
      "ty": 2,
      "x": 1162,
      "y": 965
    },
    {
      "t": 10503,
      "e": 9254,
      "ty": 2,
      "x": 1162,
      "y": 960
    },
    {
      "t": 10504,
      "e": 9255,
      "ty": 41,
      "x": 26496,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10603,
      "e": 9354,
      "ty": 2,
      "x": 1162,
      "y": 956
    },
    {
      "t": 10754,
      "e": 9505,
      "ty": 41,
      "x": 26496,
      "y": 58587,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11403,
      "e": 10154,
      "ty": 2,
      "x": 1162,
      "y": 952
    },
    {
      "t": 11503,
      "e": 10254,
      "ty": 2,
      "x": 1164,
      "y": 950
    },
    {
      "t": 11503,
      "e": 10254,
      "ty": 41,
      "x": 26637,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11603,
      "e": 10354,
      "ty": 2,
      "x": 1168,
      "y": 948
    },
    {
      "t": 11703,
      "e": 10454,
      "ty": 2,
      "x": 1168,
      "y": 943
    },
    {
      "t": 11754,
      "e": 10505,
      "ty": 41,
      "x": 26919,
      "y": 57656,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 13904,
      "e": 12655,
      "ty": 2,
      "x": 1015,
      "y": 739
    },
    {
      "t": 13993,
      "e": 12744,
      "ty": 6,
      "x": 665,
      "y": 529,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14003,
      "e": 12754,
      "ty": 2,
      "x": 665,
      "y": 529
    },
    {
      "t": 14003,
      "e": 12754,
      "ty": 41,
      "x": 63838,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14026,
      "e": 12777,
      "ty": 7,
      "x": 626,
      "y": 517,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14104,
      "e": 12855,
      "ty": 2,
      "x": 584,
      "y": 507
    },
    {
      "t": 14176,
      "e": 12927,
      "ty": 6,
      "x": 542,
      "y": 528,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14204,
      "e": 12955,
      "ty": 2,
      "x": 527,
      "y": 539
    },
    {
      "t": 14254,
      "e": 13005,
      "ty": 41,
      "x": 41019,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14304,
      "e": 13055,
      "ty": 2,
      "x": 448,
      "y": 592
    },
    {
      "t": 14404,
      "e": 13155,
      "ty": 2,
      "x": 448,
      "y": 595
    },
    {
      "t": 14504,
      "e": 13255,
      "ty": 41,
      "x": 39445,
      "y": 58468,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16187,
      "e": 14938,
      "ty": 3,
      "x": 448,
      "y": 595,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16189,
      "e": 14940,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16297,
      "e": 15048,
      "ty": 4,
      "x": 39445,
      "y": 58468,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16298,
      "e": 15049,
      "ty": 5,
      "x": 448,
      "y": 595,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20004,
      "e": 18755,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 32104,
      "e": 20049,
      "ty": 2,
      "x": 448,
      "y": 584
    },
    {
      "t": 32203,
      "e": 20148,
      "ty": 2,
      "x": 450,
      "y": 565
    },
    {
      "t": 32254,
      "e": 20199,
      "ty": 41,
      "x": 39670,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32604,
      "e": 20549,
      "ty": 2,
      "x": 456,
      "y": 565
    },
    {
      "t": 32691,
      "e": 20636,
      "ty": 3,
      "x": 456,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32753,
      "e": 20698,
      "ty": 41,
      "x": 40344,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32777,
      "e": 20722,
      "ty": 4,
      "x": 40344,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32777,
      "e": 20722,
      "ty": 5,
      "x": 456,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32804,
      "e": 20749,
      "ty": 2,
      "x": 460,
      "y": 566
    },
    {
      "t": 32904,
      "e": 20849,
      "ty": 2,
      "x": 562,
      "y": 600
    },
    {
      "t": 32908,
      "e": 20853,
      "ty": 7,
      "x": 579,
      "y": 615,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33003,
      "e": 20948,
      "ty": 2,
      "x": 850,
      "y": 751
    },
    {
      "t": 33004,
      "e": 20949,
      "ty": 41,
      "x": 4511,
      "y": 43904,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 33104,
      "e": 21049,
      "ty": 2,
      "x": 1016,
      "y": 994
    },
    {
      "t": 33204,
      "e": 21149,
      "ty": 2,
      "x": 1034,
      "y": 1019
    },
    {
      "t": 33254,
      "e": 21199,
      "ty": 41,
      "x": 17477,
      "y": 63099,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 34511,
      "e": 22456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 34694,
      "e": 22639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34694,
      "e": 22639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34749,
      "e": 22694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 34821,
      "e": 22766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 35070,
      "e": 23015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 35070,
      "e": 23015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35165,
      "e": 23110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If"
    },
    {
      "t": 35262,
      "e": 23207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35262,
      "e": 23207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35374,
      "e": 23319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ifi"
    },
    {
      "t": 35526,
      "e": 23471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35526,
      "e": 23471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35637,
      "e": 23582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ifin"
    },
    {
      "t": 35717,
      "e": 23662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35717,
      "e": 23662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35813,
      "e": 23758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 35885,
      "e": 23830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35885,
      "e": 23830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35981,
      "e": 23926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37190,
      "e": 25135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 37191,
      "e": 25136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37277,
      "e": 25222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 37406,
      "e": 25351,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 37406,
      "e": 25351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37485,
      "e": 25430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 37541,
      "e": 25486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37541,
      "e": 25486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37669,
      "e": 25614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37886,
      "e": 25831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 37886,
      "e": 25831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37997,
      "e": 25942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 38206,
      "e": 26151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38207,
      "e": 26152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38333,
      "e": 26278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38918,
      "e": 26863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38997,
      "e": 26942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ifind 12 p"
    },
    {
      "t": 39110,
      "e": 27055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39165,
      "e": 27110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ifind 12 "
    },
    {
      "t": 39261,
      "e": 27206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39333,
      "e": 27278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ifind 12"
    },
    {
      "t": 39413,
      "e": 27358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39493,
      "e": 27438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ifind 1"
    },
    {
      "t": 39581,
      "e": 27526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39645,
      "e": 27590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ifind "
    },
    {
      "t": 39741,
      "e": 27686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39797,
      "e": 27742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ifind"
    },
    {
      "t": 39909,
      "e": 27854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39964,
      "e": 27909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ifin"
    },
    {
      "t": 40004,
      "e": 27949,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40069,
      "e": 28014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40133,
      "e": 28078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ifi"
    },
    {
      "t": 40229,
      "e": 28174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40293,
      "e": 28238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If"
    },
    {
      "t": 40389,
      "e": 28334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40454,
      "e": 28399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 40550,
      "e": 28495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40613,
      "e": 28558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 42334,
      "e": 30279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42534,
      "e": 30479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 42535,
      "e": 30480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42597,
      "e": 30542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 42645,
      "e": 30590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 42653,
      "e": 30598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42653,
      "e": 30598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42766,
      "e": 30711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I "
    },
    {
      "t": 42902,
      "e": 30847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 42903,
      "e": 30848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43005,
      "e": 30950,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I f"
    },
    {
      "t": 43005,
      "e": 30950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I f"
    },
    {
      "t": 43045,
      "e": 30990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43045,
      "e": 30990,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43053,
      "e": 30998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43053,
      "e": 30998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43101,
      "e": 31046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I foi"
    },
    {
      "t": 43117,
      "e": 31062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44086,
      "e": 32031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44173,
      "e": 32118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I fo"
    },
    {
      "t": 44438,
      "e": 32383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44533,
      "e": 32478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I f"
    },
    {
      "t": 45278,
      "e": 33223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 45279,
      "e": 33224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45381,
      "e": 33326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I fi"
    },
    {
      "t": 45421,
      "e": 33366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 45422,
      "e": 33367,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45558,
      "e": 33503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 45678,
      "e": 33623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 45679,
      "e": 33624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45773,
      "e": 33718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 45885,
      "e": 33830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45886,
      "e": 33831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46004,
      "e": 33949,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find "
    },
    {
      "t": 46005,
      "e": 33950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47085,
      "e": 35030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 47087,
      "e": 35032,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47189,
      "e": 35134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 47285,
      "e": 35230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 47286,
      "e": 35231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47405,
      "e": 35350,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12"
    },
    {
      "t": 47407,
      "e": 35352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 47773,
      "e": 35718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 47773,
      "e": 35718,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47877,
      "e": 35822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 47901,
      "e": 35846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47901,
      "e": 35846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48006,
      "e": 35951,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p "
    },
    {
      "t": 48022,
      "e": 35967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48157,
      "e": 36102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48157,
      "e": 36102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48318,
      "e": 36263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 48350,
      "e": 36295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 48350,
      "e": 36295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48461,
      "e": 36406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 48558,
      "e": 36503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48558,
      "e": 36503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48677,
      "e": 36622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48774,
      "e": 36719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48774,
      "e": 36719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48852,
      "e": 36797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48885,
      "e": 36830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 48885,
      "e": 36830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48981,
      "e": 36926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 49046,
      "e": 36991,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49047,
      "e": 36992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49149,
      "e": 37094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 49214,
      "e": 37159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49216,
      "e": 37161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49325,
      "e": 37270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49638,
      "e": 37583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 49638,
      "e": 37583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49741,
      "e": 37686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 49806,
      "e": 37751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49806,
      "e": 37751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49893,
      "e": 37838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 50004,
      "e": 37949,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50006,
      "e": 37951,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bo"
    },
    {
      "t": 50037,
      "e": 37982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50037,
      "e": 37982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50093,
      "e": 38038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50190,
      "e": 38135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50190,
      "e": 38135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50270,
      "e": 38215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 50517,
      "e": 38462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 50518,
      "e": 38463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50661,
      "e": 38606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 50734,
      "e": 38679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 50735,
      "e": 38680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50853,
      "e": 38798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 50934,
      "e": 38879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50934,
      "e": 38879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51045,
      "e": 38990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51662,
      "e": 39607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 51663,
      "e": 39608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51757,
      "e": 39702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 51797,
      "e": 39742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 51798,
      "e": 39743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51909,
      "e": 39854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 52062,
      "e": 40007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52062,
      "e": 40007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52181,
      "e": 40126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52197,
      "e": 40142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52197,
      "e": 40142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52286,
      "e": 40231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 52350,
      "e": 40295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52350,
      "e": 40295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52444,
      "e": 40389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 52509,
      "e": 40454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52510,
      "e": 40455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52614,
      "e": 40559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 52676,
      "e": 40621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52676,
      "e": 40621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52805,
      "e": 40750,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the "
    },
    {
      "t": 52806,
      "e": 40751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55078,
      "e": 43023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 55080,
      "e": 43025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55173,
      "e": 43118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 55246,
      "e": 43191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 55246,
      "e": 43191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55333,
      "e": 43278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 55390,
      "e": 43335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 55391,
      "e": 43336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55510,
      "e": 43455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 55574,
      "e": 43519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 55575,
      "e": 43520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55661,
      "e": 43606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 55733,
      "e": 43678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55734,
      "e": 43679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55830,
      "e": 43775,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 55948,
      "e": 43893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55949,
      "e": 43894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56069,
      "e": 44014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56158,
      "e": 44103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 56158,
      "e": 44103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56301,
      "e": 44246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 56359,
      "e": 44304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56359,
      "e": 44304,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56477,
      "e": 44422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 56525,
      "e": 44470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 56526,
      "e": 44471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56637,
      "e": 44582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 56685,
      "e": 44630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56686,
      "e": 44631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56804,
      "e": 44749,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and "
    },
    {
      "t": 56837,
      "e": 44782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57904,
      "e": 45849,
      "ty": 2,
      "x": 1077,
      "y": 974
    },
    {
      "t": 58004,
      "e": 45949,
      "ty": 2,
      "x": 1663,
      "y": 93
    },
    {
      "t": 58005,
      "e": 45950,
      "ty": 41,
      "x": 56994,
      "y": 4708,
      "ta": "> div.stimulus"
    },
    {
      "t": 58104,
      "e": 46049,
      "ty": 2,
      "x": 1631,
      "y": 72
    },
    {
      "t": 58203,
      "e": 46148,
      "ty": 2,
      "x": 1743,
      "y": 0
    },
    {
      "t": 58254,
      "e": 46199,
      "ty": 41,
      "x": 59680,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 58304,
      "e": 46249,
      "ty": 2,
      "x": 1727,
      "y": 0
    },
    {
      "t": 58403,
      "e": 46348,
      "ty": 2,
      "x": 1709,
      "y": 5
    },
    {
      "t": 58504,
      "e": 46449,
      "ty": 2,
      "x": 1532,
      "y": 195
    },
    {
      "t": 58504,
      "e": 46449,
      "ty": 41,
      "x": 52570,
      "y": 4082,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 58604,
      "e": 46549,
      "ty": 2,
      "x": 1373,
      "y": 227
    },
    {
      "t": 58703,
      "e": 46648,
      "ty": 2,
      "x": 1119,
      "y": 255
    },
    {
      "t": 58754,
      "e": 46699,
      "ty": 41,
      "x": 17124,
      "y": 9740,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 58804,
      "e": 46749,
      "ty": 2,
      "x": 1012,
      "y": 279
    },
    {
      "t": 58904,
      "e": 46849,
      "ty": 2,
      "x": 934,
      "y": 343
    },
    {
      "t": 59004,
      "e": 46949,
      "ty": 2,
      "x": 850,
      "y": 449
    },
    {
      "t": 59004,
      "e": 46949,
      "ty": 41,
      "x": 4511,
      "y": 22274,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 59103,
      "e": 47048,
      "ty": 2,
      "x": 824,
      "y": 492
    },
    {
      "t": 59204,
      "e": 47149,
      "ty": 2,
      "x": 786,
      "y": 517
    },
    {
      "t": 59255,
      "e": 47200,
      "ty": 41,
      "x": 5332,
      "y": 27548,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 59304,
      "e": 47249,
      "ty": 2,
      "x": 773,
      "y": 526
    },
    {
      "t": 59404,
      "e": 47349,
      "ty": 2,
      "x": 769,
      "y": 528
    },
    {
      "t": 59504,
      "e": 47449,
      "ty": 2,
      "x": 766,
      "y": 529
    },
    {
      "t": 59504,
      "e": 47449,
      "ty": 41,
      "x": 4930,
      "y": 27761,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 60005,
      "e": 47950,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60703,
      "e": 48648,
      "ty": 2,
      "x": 892,
      "y": 565
    },
    {
      "t": 60753,
      "e": 48698,
      "ty": 41,
      "x": 12403,
      "y": 31872,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 60803,
      "e": 48748,
      "ty": 2,
      "x": 1117,
      "y": 634
    },
    {
      "t": 60903,
      "e": 48848,
      "ty": 2,
      "x": 1493,
      "y": 859
    },
    {
      "t": 61003,
      "e": 48948,
      "ty": 2,
      "x": 1541,
      "y": 917
    },
    {
      "t": 61004,
      "e": 48949,
      "ty": 41,
      "x": 53204,
      "y": 55794,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 61103,
      "e": 49048,
      "ty": 2,
      "x": 1493,
      "y": 977
    },
    {
      "t": 61203,
      "e": 49148,
      "ty": 2,
      "x": 1411,
      "y": 991
    },
    {
      "t": 61253,
      "e": 49198,
      "ty": 41,
      "x": 39533,
      "y": 61166,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 61303,
      "e": 49248,
      "ty": 2,
      "x": 1254,
      "y": 1003
    },
    {
      "t": 61403,
      "e": 49348,
      "ty": 2,
      "x": 1156,
      "y": 1003
    },
    {
      "t": 61503,
      "e": 49448,
      "ty": 2,
      "x": 1151,
      "y": 1003
    },
    {
      "t": 61504,
      "e": 49449,
      "ty": 41,
      "x": 25721,
      "y": 61953,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 61703,
      "e": 49648,
      "ty": 2,
      "x": 1151,
      "y": 996
    },
    {
      "t": 61754,
      "e": 49699,
      "ty": 41,
      "x": 34130,
      "y": 49407,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 61803,
      "e": 49748,
      "ty": 2,
      "x": 1157,
      "y": 976
    },
    {
      "t": 61902,
      "e": 49847,
      "ty": 2,
      "x": 1162,
      "y": 968
    },
    {
      "t": 62003,
      "e": 49948,
      "ty": 41,
      "x": 26496,
      "y": 59447,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 66903,
      "e": 54848,
      "ty": 2,
      "x": 1371,
      "y": 892
    },
    {
      "t": 67004,
      "e": 54949,
      "ty": 2,
      "x": 1533,
      "y": 863
    },
    {
      "t": 67004,
      "e": 54949,
      "ty": 41,
      "x": 52640,
      "y": 51926,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 67103,
      "e": 55048,
      "ty": 2,
      "x": 1656,
      "y": 870
    },
    {
      "t": 67203,
      "e": 55148,
      "ty": 2,
      "x": 1919,
      "y": 1008
    },
    {
      "t": 67303,
      "e": 55248,
      "ty": 2,
      "x": 1919,
      "y": 1161
    },
    {
      "t": 67403,
      "e": 55348,
      "ty": 2,
      "x": 1919,
      "y": 1199
    },
    {
      "t": 67503,
      "e": 55448,
      "ty": 2,
      "x": 1917,
      "y": 1199
    },
    {
      "t": 67603,
      "e": 55548,
      "ty": 2,
      "x": 1919,
      "y": 1199
    },
    {
      "t": 69945,
      "e": 57890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 69946,
      "e": 57891,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70007,
      "e": 57952,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70048,
      "e": 57993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 70096,
      "e": 58041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 70097,
      "e": 58042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70191,
      "e": 58136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 70304,
      "e": 58249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 70304,
      "e": 58249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70392,
      "e": 58337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 70464,
      "e": 58409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 70465,
      "e": 58410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70535,
      "e": 58480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 71337,
      "e": 59282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 71337,
      "e": 59282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71440,
      "e": 59385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 71471,
      "e": 59416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 71473,
      "e": 59418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71607,
      "e": 59552,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow"
    },
    {
      "t": 71616,
      "e": 59561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 71624,
      "e": 59569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71624,
      "e": 59569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71768,
      "e": 59713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 72448,
      "e": 60393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 72449,
      "e": 60394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72560,
      "e": 60505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 72664,
      "e": 60609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 72665,
      "e": 60610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72775,
      "e": 60720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 72783,
      "e": 60728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 72784,
      "e": 60729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72928,
      "e": 60873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 72952,
      "e": 60897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72953,
      "e": 60898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73080,
      "e": 61025,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74115,
      "e": 62060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 74115,
      "e": 62060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74223,
      "e": 62168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 74304,
      "e": 62249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 74305,
      "e": 62250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74400,
      "e": 62345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 74496,
      "e": 62441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 74497,
      "e": 62442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74567,
      "e": 62512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 74640,
      "e": 62585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 74640,
      "e": 62585,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74760,
      "e": 62705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 74761,
      "e": 62706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 74762,
      "e": 62707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74880,
      "e": 62825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 75048,
      "e": 62993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75049,
      "e": 62994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75167,
      "e": 63112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80007,
      "e": 67952,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 83305,
      "e": 68112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 83306,
      "e": 68113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83376,
      "e": 68183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 83456,
      "e": 68263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 83456,
      "e": 68263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83568,
      "e": 68375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 83664,
      "e": 68471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 83665,
      "e": 68472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83775,
      "e": 68582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 84009,
      "e": 68816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 84009,
      "e": 68816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84127,
      "e": 68934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 84583,
      "e": 69390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 84584,
      "e": 69391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84728,
      "e": 69535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 84752,
      "e": 69559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 84753,
      "e": 69560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84864,
      "e": 69671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 84992,
      "e": 69799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 84993,
      "e": 69800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85104,
      "e": 69911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 85176,
      "e": 69983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 85176,
      "e": 69983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85319,
      "e": 70126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 87177,
      "e": 71984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 87248,
      "e": 72055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right tilting"
    },
    {
      "t": 90006,
      "e": 74813,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90872,
      "e": 75679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91008,
      "e": 75815,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right tiltin"
    },
    {
      "t": 91372,
      "e": 76179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91405,
      "e": 76212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91436,
      "e": 76243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91470,
      "e": 76277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91503,
      "e": 76310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91511,
      "e": 76318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right t"
    },
    {
      "t": 91768,
      "e": 76575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 91847,
      "e": 76654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right "
    },
    {
      "t": 92631,
      "e": 77438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 92631,
      "e": 77438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92744,
      "e": 77551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 92856,
      "e": 77663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 92856,
      "e": 77663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92888,
      "e": 77695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 93008,
      "e": 77815,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right sk"
    },
    {
      "t": 93224,
      "e": 78031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 93344,
      "e": 78151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right s"
    },
    {
      "t": 93489,
      "e": 78296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 93490,
      "e": 78297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93584,
      "e": 78391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 93656,
      "e": 78463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 93656,
      "e": 78463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93761,
      "e": 78568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 93800,
      "e": 78607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 93801,
      "e": 78608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93896,
      "e": 78703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 94072,
      "e": 78879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 94074,
      "e": 78881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94167,
      "e": 78974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 94320,
      "e": 79127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 94321,
      "e": 79128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94432,
      "e": 79239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 94520,
      "e": 79327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 94522,
      "e": 79329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94631,
      "e": 79438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 94704,
      "e": 79511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 94705,
      "e": 79512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94809,
      "e": 79616,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted "
    },
    {
      "t": 94809,
      "e": 79616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 95064,
      "e": 79871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 95065,
      "e": 79872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95143,
      "e": 79950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 95496,
      "e": 80303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 95607,
      "e": 80414,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted "
    },
    {
      "t": 95632,
      "e": 80439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted "
    },
    {
      "t": 95792,
      "e": 80599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 95794,
      "e": 80601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95879,
      "e": 80686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 95984,
      "e": 80791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 95984,
      "e": 80791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96048,
      "e": 80855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 96160,
      "e": 80967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 96161,
      "e": 80968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96271,
      "e": 81078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 96320,
      "e": 81127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 96320,
      "e": 81127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96472,
      "e": 81279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 100007,
      "e": 84814,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 101448,
      "e": 86255,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 101448,
      "e": 86255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101592,
      "e": 86399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 101793,
      "e": 86600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 101793,
      "e": 86600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101888,
      "e": 86695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 102737,
      "e": 87544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 102737,
      "e": 87544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102855,
      "e": 87662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 105185,
      "e": 89992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "220"
    },
    {
      "t": 105185,
      "e": 89992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105188,
      "e": 89995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 105255,
      "e": 90062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 105263,
      "e": 90070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 105537,
      "e": 90344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 105640,
      "e": 90447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted line. "
    },
    {
      "t": 106735,
      "e": 91542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 106912,
      "e": 91719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 106912,
      "e": 91719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106983,
      "e": 91790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 106999,
      "e": 91806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 107136,
      "e": 91943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 107137,
      "e": 91944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107215,
      "e": 92022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 107215,
      "e": 92022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107231,
      "e": 92038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 107352,
      "e": 92159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 107376,
      "e": 92183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 107377,
      "e": 92184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107528,
      "e": 92335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 108688,
      "e": 93495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 108688,
      "e": 93495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108808,
      "e": 93615,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted line. The s"
    },
    {
      "t": 108810,
      "e": 93617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 108888,
      "e": 93695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 108889,
      "e": 93696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109007,
      "e": 93814,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted line. The sh"
    },
    {
      "t": 109008,
      "e": 93815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 109071,
      "e": 93878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 109072,
      "e": 93879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109209,
      "e": 94016,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted line. The shi"
    },
    {
      "t": 109216,
      "e": 94023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 109256,
      "e": 94063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 109257,
      "e": 94064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109359,
      "e": 94166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 109543,
      "e": 94350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 109544,
      "e": 94351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109632,
      "e": 94439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 109864,
      "e": 94671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 109864,
      "e": 94671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109975,
      "e": 94782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 110006,
      "e": 94813,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110039,
      "e": 94846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 110039,
      "e": 94846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110176,
      "e": 94983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 110768,
      "e": 95575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 110769,
      "e": 95576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 110864,
      "e": 95671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 111128,
      "e": 95935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 111129,
      "e": 95936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111207,
      "e": 96014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 111304,
      "e": 96111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 111304,
      "e": 96111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111367,
      "e": 96174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 111455,
      "e": 96262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 111456,
      "e": 96263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111544,
      "e": 96351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 111592,
      "e": 96399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 111593,
      "e": 96400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111703,
      "e": 96510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 111735,
      "e": 96542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 111735,
      "e": 96542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 111887,
      "e": 96694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 111951,
      "e": 96758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 111951,
      "e": 96758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112064,
      "e": 96871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 112128,
      "e": 96935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 112128,
      "e": 96935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112256,
      "e": 97063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 112424,
      "e": 97231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 112425,
      "e": 97232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112536,
      "e": 97343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 112641,
      "e": 97448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 112642,
      "e": 97449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 112743,
      "e": 97550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 112896,
      "e": 97703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 112897,
      "e": 97704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113008,
      "e": 97815,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted line. The shifts on this lin"
    },
    {
      "t": 113024,
      "e": 97831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 113096,
      "e": 97903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 113096,
      "e": 97903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113192,
      "e": 97999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 113248,
      "e": 98055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 113248,
      "e": 98055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113376,
      "e": 98183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 113488,
      "e": 98295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 113489,
      "e": 98296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113584,
      "e": 98391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 113616,
      "e": 98423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 113617,
      "e": 98424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113735,
      "e": 98542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 114385,
      "e": 99192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 114385,
      "e": 99192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114496,
      "e": 99303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 114583,
      "e": 99390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 114584,
      "e": 99391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114736,
      "e": 99543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 114760,
      "e": 99567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 114761,
      "e": 99568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114864,
      "e": 99671,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 114967,
      "e": 99774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 114968,
      "e": 99775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115064,
      "e": 99871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 115119,
      "e": 99926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 115119,
      "e": 99926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115240,
      "e": 100047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 115296,
      "e": 100103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 115297,
      "e": 100104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115383,
      "e": 100190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 115912,
      "e": 100719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 115913,
      "e": 100720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115999,
      "e": 100806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 116056,
      "e": 100863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 116056,
      "e": 100863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116207,
      "e": 101014,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted line. The shifts on this line begina at "
    },
    {
      "t": 116208,
      "e": 101015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 117831,
      "e": 102638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 117920,
      "e": 102727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 118024,
      "e": 102831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 118111,
      "e": 102918,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 118216,
      "e": 103023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 118287,
      "e": 103094,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 118392,
      "e": 103199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 118480,
      "e": 103287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 118568,
      "e": 103375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 118631,
      "e": 103438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 118936,
      "e": 103743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 119072,
      "e": 103879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 119712,
      "e": 104519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 119775,
      "e": 104582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted line. The shifts on this line begin at "
    },
    {
      "t": 120007,
      "e": 104814,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120183,
      "e": 104990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 120312,
      "e": 105119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 120424,
      "e": 105231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 120487,
      "e": 105294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 120600,
      "e": 105407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 120664,
      "e": 105471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 120760,
      "e": 105567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 120847,
      "e": 105654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 123136,
      "e": 107943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 123136,
      "e": 107943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123240,
      "e": 108047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 123319,
      "e": 108126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 123320,
      "e": 108127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123424,
      "e": 108231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 124096,
      "e": 108903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 124097,
      "e": 108904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124160,
      "e": 108967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 124304,
      "e": 109111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 124304,
      "e": 109111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124408,
      "e": 109215,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted line. The shifts on this line begin at 12p."
    },
    {
      "t": 124410,
      "e": 109217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 125406,
      "e": 110213,
      "ty": 2,
      "x": 1826,
      "y": 0
    },
    {
      "t": 125506,
      "e": 110313,
      "ty": 2,
      "x": 1919,
      "y": 0
    },
    {
      "t": 125706,
      "e": 110513,
      "ty": 2,
      "x": 1865,
      "y": 98
    },
    {
      "t": 125757,
      "e": 110564,
      "ty": 41,
      "x": 64680,
      "y": 4189,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 125807,
      "e": 110614,
      "ty": 2,
      "x": 1789,
      "y": 263
    },
    {
      "t": 125907,
      "e": 110714,
      "ty": 2,
      "x": 1739,
      "y": 380
    },
    {
      "t": 126006,
      "e": 110813,
      "ty": 2,
      "x": 1571,
      "y": 553
    },
    {
      "t": 126006,
      "e": 110813,
      "ty": 41,
      "x": 55318,
      "y": 29723,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 126106,
      "e": 110913,
      "ty": 2,
      "x": 1454,
      "y": 608
    },
    {
      "t": 126206,
      "e": 111013,
      "ty": 2,
      "x": 1150,
      "y": 620
    },
    {
      "t": 126257,
      "e": 111064,
      "ty": 41,
      "x": 10853,
      "y": 34379,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 126307,
      "e": 111114,
      "ty": 2,
      "x": 792,
      "y": 618
    },
    {
      "t": 126389,
      "e": 111196,
      "ty": 6,
      "x": 642,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126406,
      "e": 111213,
      "ty": 2,
      "x": 623,
      "y": 599
    },
    {
      "t": 126506,
      "e": 111313,
      "ty": 2,
      "x": 541,
      "y": 575
    },
    {
      "t": 126506,
      "e": 111313,
      "ty": 41,
      "x": 49899,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126606,
      "e": 111413,
      "ty": 2,
      "x": 528,
      "y": 566
    },
    {
      "t": 126757,
      "e": 111564,
      "ty": 41,
      "x": 48438,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127406,
      "e": 112213,
      "ty": 2,
      "x": 532,
      "y": 563
    },
    {
      "t": 127506,
      "e": 112313,
      "ty": 2,
      "x": 538,
      "y": 560
    },
    {
      "t": 127506,
      "e": 112313,
      "ty": 41,
      "x": 49562,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129759,
      "e": 114566,
      "ty": 41,
      "x": 48887,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129809,
      "e": 114616,
      "ty": 2,
      "x": 520,
      "y": 572
    },
    {
      "t": 129910,
      "e": 114717,
      "ty": 2,
      "x": 499,
      "y": 584
    },
    {
      "t": 129977,
      "e": 114784,
      "ty": 7,
      "x": 471,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130009,
      "e": 114816,
      "ty": 2,
      "x": 470,
      "y": 608
    },
    {
      "t": 130009,
      "e": 114816,
      "ty": 41,
      "x": 41918,
      "y": 63443,
      "ta": "#.strategy"
    },
    {
      "t": 130009,
      "e": 114816,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130110,
      "e": 114917,
      "ty": 2,
      "x": 461,
      "y": 619
    },
    {
      "t": 130209,
      "e": 115016,
      "ty": 2,
      "x": 455,
      "y": 626
    },
    {
      "t": 130259,
      "e": 115066,
      "ty": 41,
      "x": 59639,
      "y": 9348,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 130309,
      "e": 115116,
      "ty": 2,
      "x": 446,
      "y": 636
    },
    {
      "t": 130709,
      "e": 115516,
      "ty": 2,
      "x": 470,
      "y": 627
    },
    {
      "t": 130760,
      "e": 115567,
      "ty": 41,
      "x": 43941,
      "y": 63841,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 130810,
      "e": 115617,
      "ty": 2,
      "x": 508,
      "y": 610
    },
    {
      "t": 130910,
      "e": 115717,
      "ty": 2,
      "x": 516,
      "y": 606
    },
    {
      "t": 131010,
      "e": 115817,
      "ty": 41,
      "x": 47089,
      "y": 62323,
      "ta": "#.strategy"
    },
    {
      "t": 131310,
      "e": 116117,
      "ty": 2,
      "x": 501,
      "y": 613
    },
    {
      "t": 131347,
      "e": 116154,
      "ty": 6,
      "x": 423,
      "y": 663,
      "ta": "#strategyButton"
    },
    {
      "t": 131409,
      "e": 116216,
      "ty": 2,
      "x": 393,
      "y": 683
    },
    {
      "t": 131479,
      "e": 116286,
      "ty": 7,
      "x": 386,
      "y": 690,
      "ta": "#strategyButton"
    },
    {
      "t": 131509,
      "e": 116316,
      "ty": 2,
      "x": 385,
      "y": 691
    },
    {
      "t": 131509,
      "e": 116316,
      "ty": 41,
      "x": 31085,
      "y": 45393,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 131909,
      "e": 116716,
      "ty": 2,
      "x": 388,
      "y": 690
    },
    {
      "t": 131920,
      "e": 116727,
      "ty": 6,
      "x": 390,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 132009,
      "e": 116816,
      "ty": 2,
      "x": 391,
      "y": 687
    },
    {
      "t": 132010,
      "e": 116817,
      "ty": 41,
      "x": 28620,
      "y": 62191,
      "ta": "#strategyButton"
    },
    {
      "t": 132109,
      "e": 116916,
      "ty": 2,
      "x": 394,
      "y": 685
    },
    {
      "t": 132260,
      "e": 117067,
      "ty": 41,
      "x": 30258,
      "y": 58336,
      "ta": "#strategyButton"
    },
    {
      "t": 133910,
      "e": 118717,
      "ty": 2,
      "x": 409,
      "y": 676
    },
    {
      "t": 134009,
      "e": 118816,
      "ty": 41,
      "x": 38450,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 134161,
      "e": 118968,
      "ty": 3,
      "x": 409,
      "y": 676,
      "ta": "#strategyButton"
    },
    {
      "t": 134162,
      "e": 118969,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I find 12p on the bottom of the chart and follow the right slanted line. The shifts on this line begin at 12p."
    },
    {
      "t": 134162,
      "e": 118969,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134163,
      "e": 118970,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 134246,
      "e": 119053,
      "ty": 4,
      "x": 38450,
      "y": 40989,
      "ta": "#strategyButton"
    },
    {
      "t": 134256,
      "e": 119063,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 134258,
      "e": 119065,
      "ty": 5,
      "x": 409,
      "y": 676,
      "ta": "#strategyButton"
    },
    {
      "t": 134265,
      "e": 119072,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 134310,
      "e": 119117,
      "ty": 2,
      "x": 410,
      "y": 675
    },
    {
      "t": 134409,
      "e": 119216,
      "ty": 2,
      "x": 435,
      "y": 663
    },
    {
      "t": 134509,
      "e": 119316,
      "ty": 2,
      "x": 516,
      "y": 638
    },
    {
      "t": 134509,
      "e": 119316,
      "ty": 41,
      "x": 17494,
      "y": 34900,
      "ta": "html > body"
    },
    {
      "t": 134610,
      "e": 119417,
      "ty": 2,
      "x": 583,
      "y": 628
    },
    {
      "t": 134709,
      "e": 119516,
      "ty": 2,
      "x": 584,
      "y": 628
    },
    {
      "t": 134760,
      "e": 119567,
      "ty": 41,
      "x": 19836,
      "y": 34346,
      "ta": "html > body"
    },
    {
      "t": 135264,
      "e": 120071,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 136209,
      "e": 121016,
      "ty": 2,
      "x": 648,
      "y": 608
    },
    {
      "t": 136260,
      "e": 121067,
      "ty": 41,
      "x": 24347,
      "y": 32185,
      "ta": "html > body"
    },
    {
      "t": 136309,
      "e": 121116,
      "ty": 2,
      "x": 789,
      "y": 567
    },
    {
      "t": 136316,
      "e": 121123,
      "ty": 6,
      "x": 811,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136350,
      "e": 121157,
      "ty": 7,
      "x": 869,
      "y": 546,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136409,
      "e": 121216,
      "ty": 2,
      "x": 911,
      "y": 539
    },
    {
      "t": 136509,
      "e": 121316,
      "ty": 2,
      "x": 912,
      "y": 538
    },
    {
      "t": 136510,
      "e": 121317,
      "ty": 41,
      "x": 22493,
      "y": 33824,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 136610,
      "e": 121417,
      "ty": 2,
      "x": 906,
      "y": 543
    },
    {
      "t": 136617,
      "e": 121424,
      "ty": 6,
      "x": 902,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136710,
      "e": 121517,
      "ty": 2,
      "x": 899,
      "y": 564
    },
    {
      "t": 136759,
      "e": 121566,
      "ty": 41,
      "x": 19465,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136810,
      "e": 121617,
      "ty": 2,
      "x": 898,
      "y": 569
    },
    {
      "t": 136935,
      "e": 121742,
      "ty": 3,
      "x": 898,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 136936,
      "e": 121743,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 137014,
      "e": 121821,
      "ty": 4,
      "x": 19465,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 137015,
      "e": 121822,
      "ty": 5,
      "x": 898,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 137210,
      "e": 122017,
      "ty": 2,
      "x": 951,
      "y": 565
    },
    {
      "t": 137251,
      "e": 122058,
      "ty": 7,
      "x": 1123,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 137260,
      "e": 122067,
      "ty": 41,
      "x": 38398,
      "y": 30856,
      "ta": "html > body"
    },
    {
      "t": 137309,
      "e": 122116,
      "ty": 2,
      "x": 1313,
      "y": 565
    },
    {
      "t": 137410,
      "e": 122217,
      "ty": 2,
      "x": 1469,
      "y": 565
    },
    {
      "t": 137510,
      "e": 122317,
      "ty": 41,
      "x": 50313,
      "y": 30856,
      "ta": "html > body"
    },
    {
      "t": 139035,
      "e": 123842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 139036,
      "e": 123843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 139090,
      "e": 123897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 139122,
      "e": 123929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 139123,
      "e": 123930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 139227,
      "e": 124034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 140010,
      "e": 124817,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140710,
      "e": 125517,
      "ty": 2,
      "x": 1470,
      "y": 564
    },
    {
      "t": 140759,
      "e": 125566,
      "ty": 41,
      "x": 49865,
      "y": 29748,
      "ta": "html > body"
    },
    {
      "t": 140809,
      "e": 125616,
      "ty": 2,
      "x": 1427,
      "y": 572
    },
    {
      "t": 140866,
      "e": 125673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 140867,
      "e": 125674,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 140867,
      "e": 125674,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 140867,
      "e": 125674,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 140909,
      "e": 125716,
      "ty": 2,
      "x": 1265,
      "y": 682
    },
    {
      "t": 140995,
      "e": 125802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 141010,
      "e": 125817,
      "ty": 2,
      "x": 1236,
      "y": 743
    },
    {
      "t": 141010,
      "e": 125817,
      "ty": 41,
      "x": 42289,
      "y": 40717,
      "ta": "html > body"
    },
    {
      "t": 141109,
      "e": 125916,
      "ty": 2,
      "x": 1267,
      "y": 831
    },
    {
      "t": 141210,
      "e": 126017,
      "ty": 2,
      "x": 1388,
      "y": 966
    },
    {
      "t": 141259,
      "e": 126066,
      "ty": 41,
      "x": 47627,
      "y": 53181,
      "ta": "html > body"
    },
    {
      "t": 141309,
      "e": 126116,
      "ty": 2,
      "x": 1391,
      "y": 968
    },
    {
      "t": 142827,
      "e": 127634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 143203,
      "e": 128010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 143203,
      "e": 128010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 143314,
      "e": 128121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 143314,
      "e": 128121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 143314,
      "e": 128121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 143427,
      "e": 128234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 143499,
      "e": 128306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 143499,
      "e": 128306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 143602,
      "e": 128409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 143618,
      "e": 128425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 144609,
      "e": 129416,
      "ty": 2,
      "x": 1717,
      "y": 833
    },
    {
      "t": 144709,
      "e": 129516,
      "ty": 2,
      "x": 1701,
      "y": 182
    },
    {
      "t": 144759,
      "e": 129566,
      "ty": 41,
      "x": 60713,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 144809,
      "e": 129616,
      "ty": 2,
      "x": 1763,
      "y": 0
    },
    {
      "t": 144909,
      "e": 129716,
      "ty": 2,
      "x": 1637,
      "y": 51
    },
    {
      "t": 145009,
      "e": 129816,
      "ty": 2,
      "x": 1228,
      "y": 298
    },
    {
      "t": 145010,
      "e": 129817,
      "ty": 41,
      "x": 42014,
      "y": 16065,
      "ta": "html > body"
    },
    {
      "t": 145109,
      "e": 129916,
      "ty": 2,
      "x": 1142,
      "y": 508
    },
    {
      "t": 145209,
      "e": 130016,
      "ty": 2,
      "x": 1140,
      "y": 574
    },
    {
      "t": 145260,
      "e": 130067,
      "ty": 41,
      "x": 38604,
      "y": 33238,
      "ta": "html > body"
    },
    {
      "t": 145291,
      "e": 130098,
      "ty": 6,
      "x": 1102,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145309,
      "e": 130116,
      "ty": 2,
      "x": 1083,
      "y": 666
    },
    {
      "t": 145325,
      "e": 130132,
      "ty": 7,
      "x": 1068,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145409,
      "e": 130216,
      "ty": 2,
      "x": 1011,
      "y": 735
    },
    {
      "t": 145509,
      "e": 130316,
      "ty": 2,
      "x": 998,
      "y": 735
    },
    {
      "t": 145509,
      "e": 130316,
      "ty": 41,
      "x": 34093,
      "y": 40273,
      "ta": "html > body"
    },
    {
      "t": 145558,
      "e": 130365,
      "ty": 6,
      "x": 983,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 145607,
      "e": 130414,
      "ty": 7,
      "x": 954,
      "y": 668,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 145609,
      "e": 130416,
      "ty": 2,
      "x": 954,
      "y": 668
    },
    {
      "t": 145624,
      "e": 130431,
      "ty": 6,
      "x": 952,
      "y": 664,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145709,
      "e": 130516,
      "ty": 2,
      "x": 950,
      "y": 663
    },
    {
      "t": 145760,
      "e": 130567,
      "ty": 41,
      "x": 29847,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145809,
      "e": 130616,
      "ty": 2,
      "x": 941,
      "y": 667
    },
    {
      "t": 145825,
      "e": 130632,
      "ty": 7,
      "x": 939,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145891,
      "e": 130698,
      "ty": 6,
      "x": 933,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 145909,
      "e": 130716,
      "ty": 2,
      "x": 932,
      "y": 682
    },
    {
      "t": 146009,
      "e": 130816,
      "ty": 2,
      "x": 928,
      "y": 697
    },
    {
      "t": 146009,
      "e": 130816,
      "ty": 41,
      "x": 16532,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 147184,
      "e": 131991,
      "ty": 3,
      "x": 928,
      "y": 697,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 147185,
      "e": 131992,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 147185,
      "e": 131992,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 147186,
      "e": 131993,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 147255,
      "e": 132062,
      "ty": 4,
      "x": 16532,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 147257,
      "e": 132064,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 147258,
      "e": 132065,
      "ty": 5,
      "x": 928,
      "y": 697,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 147259,
      "e": 132066,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 148272,
      "e": 133079,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 149209,
      "e": 134016,
      "ty": 2,
      "x": 1114,
      "y": 630
    },
    {
      "t": 149259,
      "e": 134066,
      "ty": 41,
      "x": 50347,
      "y": 26978,
      "ta": "html > body"
    },
    {
      "t": 149310,
      "e": 134117,
      "ty": 2,
      "x": 1919,
      "y": 343
    },
    {
      "t": 149410,
      "e": 134217,
      "ty": 2,
      "x": 1919,
      "y": 76
    },
    {
      "t": 149509,
      "e": 134316,
      "ty": 2,
      "x": 1919,
      "y": 0
    },
    {
      "t": 149609,
      "e": 134416,
      "ty": 2,
      "x": 1917,
      "y": 0
    },
    {
      "t": 149709,
      "e": 134516,
      "ty": 2,
      "x": 1419,
      "y": 0
    },
    {
      "t": 149759,
      "e": 134566,
      "ty": 41,
      "x": 34575,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 149809,
      "e": 134616,
      "ty": 2,
      "x": 782,
      "y": 12
    },
    {
      "t": 149909,
      "e": 134716,
      "ty": 2,
      "x": 615,
      "y": 79
    },
    {
      "t": 150009,
      "e": 134816,
      "ty": 2,
      "x": 594,
      "y": 86
    },
    {
      "t": 150009,
      "e": 134816,
      "ty": 41,
      "x": 20180,
      "y": 4320,
      "ta": "html > body"
    },
    {
      "t": 150009,
      "e": 134816,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 150110,
      "e": 134917,
      "ty": 2,
      "x": 712,
      "y": 175
    },
    {
      "t": 150209,
      "e": 135016,
      "ty": 2,
      "x": 769,
      "y": 235
    },
    {
      "t": 150259,
      "e": 135066,
      "ty": 41,
      "x": 26207,
      "y": 12575,
      "ta": "html > body"
    },
    {
      "t": 150309,
      "e": 135116,
      "ty": 2,
      "x": 771,
      "y": 235
    },
    {
      "t": 150409,
      "e": 135216,
      "ty": 2,
      "x": 828,
      "y": 217
    },
    {
      "t": 150509,
      "e": 135316,
      "ty": 2,
      "x": 846,
      "y": 209
    },
    {
      "t": 150510,
      "e": 135317,
      "ty": 41,
      "x": 5832,
      "y": 12443,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 150709,
      "e": 135516,
      "ty": 2,
      "x": 846,
      "y": 208
    },
    {
      "t": 150760,
      "e": 135567,
      "ty": 41,
      "x": 6307,
      "y": 17005,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 150809,
      "e": 135616,
      "ty": 2,
      "x": 853,
      "y": 228
    },
    {
      "t": 151010,
      "e": 135817,
      "ty": 41,
      "x": 7494,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 151109,
      "e": 135916,
      "ty": 2,
      "x": 853,
      "y": 232
    },
    {
      "t": 151143,
      "e": 135950,
      "ty": 3,
      "x": 854,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 151209,
      "e": 136016,
      "ty": 2,
      "x": 857,
      "y": 235
    },
    {
      "t": 151246,
      "e": 136053,
      "ty": 4,
      "x": 29133,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 151246,
      "e": 136053,
      "ty": 5,
      "x": 857,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 151247,
      "e": 136054,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 151248,
      "e": 136055,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 151259,
      "e": 136066,
      "ty": 41,
      "x": 29133,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 151310,
      "e": 136117,
      "ty": 2,
      "x": 860,
      "y": 235
    },
    {
      "t": 151510,
      "e": 136317,
      "ty": 41,
      "x": 31590,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 151609,
      "e": 136416,
      "ty": 2,
      "x": 865,
      "y": 238
    },
    {
      "t": 151709,
      "e": 136516,
      "ty": 2,
      "x": 910,
      "y": 262
    },
    {
      "t": 151759,
      "e": 136566,
      "ty": 41,
      "x": 27192,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 151810,
      "e": 136617,
      "ty": 2,
      "x": 945,
      "y": 271
    },
    {
      "t": 151909,
      "e": 136716,
      "ty": 2,
      "x": 958,
      "y": 294
    },
    {
      "t": 152010,
      "e": 136817,
      "ty": 2,
      "x": 961,
      "y": 318
    },
    {
      "t": 152010,
      "e": 136817,
      "ty": 41,
      "x": 33125,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 152109,
      "e": 136916,
      "ty": 2,
      "x": 961,
      "y": 338
    },
    {
      "t": 152210,
      "e": 137017,
      "ty": 2,
      "x": 961,
      "y": 345
    },
    {
      "t": 152259,
      "e": 137066,
      "ty": 41,
      "x": 33125,
      "y": 13749,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 152910,
      "e": 137717,
      "ty": 2,
      "x": 928,
      "y": 395
    },
    {
      "t": 153009,
      "e": 137816,
      "ty": 2,
      "x": 901,
      "y": 442
    },
    {
      "t": 153010,
      "e": 137817,
      "ty": 41,
      "x": 63563,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 153110,
      "e": 137917,
      "ty": 2,
      "x": 890,
      "y": 456
    },
    {
      "t": 153260,
      "e": 138067,
      "ty": 41,
      "x": 16275,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 153409,
      "e": 138216,
      "ty": 2,
      "x": 887,
      "y": 456
    },
    {
      "t": 153510,
      "e": 138317,
      "ty": 2,
      "x": 886,
      "y": 454
    },
    {
      "t": 153510,
      "e": 138317,
      "ty": 41,
      "x": 15325,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 153609,
      "e": 138416,
      "ty": 2,
      "x": 885,
      "y": 446
    },
    {
      "t": 153709,
      "e": 138516,
      "ty": 2,
      "x": 886,
      "y": 444
    },
    {
      "t": 153751,
      "e": 138558,
      "ty": 3,
      "x": 886,
      "y": 444,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 153753,
      "e": 138560,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 153759,
      "e": 138566,
      "ty": 41,
      "x": 51581,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 153830,
      "e": 138637,
      "ty": 4,
      "x": 51581,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 153830,
      "e": 138637,
      "ty": 5,
      "x": 886,
      "y": 444,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 153831,
      "e": 138638,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 153831,
      "e": 138638,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 153909,
      "e": 138716,
      "ty": 2,
      "x": 887,
      "y": 440
    },
    {
      "t": 154009,
      "e": 138816,
      "ty": 2,
      "x": 918,
      "y": 489
    },
    {
      "t": 154009,
      "e": 138816,
      "ty": 41,
      "x": 22920,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 154110,
      "e": 138917,
      "ty": 2,
      "x": 962,
      "y": 526
    },
    {
      "t": 154260,
      "e": 139067,
      "ty": 41,
      "x": 33362,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 154410,
      "e": 139217,
      "ty": 2,
      "x": 963,
      "y": 526
    },
    {
      "t": 154510,
      "e": 139217,
      "ty": 41,
      "x": 33599,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 155610,
      "e": 140317,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 155709,
      "e": 140416,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 157109,
      "e": 141816,
      "ty": 2,
      "x": 960,
      "y": 576
    },
    {
      "t": 157209,
      "e": 141916,
      "ty": 2,
      "x": 958,
      "y": 586
    },
    {
      "t": 157260,
      "e": 141967,
      "ty": 41,
      "x": 32176,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 157310,
      "e": 142017,
      "ty": 2,
      "x": 954,
      "y": 591
    },
    {
      "t": 157410,
      "e": 142117,
      "ty": 2,
      "x": 946,
      "y": 608
    },
    {
      "t": 157509,
      "e": 142216,
      "ty": 2,
      "x": 939,
      "y": 624
    },
    {
      "t": 157509,
      "e": 142216,
      "ty": 41,
      "x": 27904,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 157609,
      "e": 142316,
      "ty": 2,
      "x": 931,
      "y": 642
    },
    {
      "t": 157710,
      "e": 142417,
      "ty": 2,
      "x": 926,
      "y": 661
    },
    {
      "t": 157760,
      "e": 142467,
      "ty": 41,
      "x": 24581,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 157810,
      "e": 142517,
      "ty": 2,
      "x": 925,
      "y": 669
    },
    {
      "t": 157910,
      "e": 142617,
      "ty": 2,
      "x": 920,
      "y": 695
    },
    {
      "t": 158010,
      "e": 142717,
      "ty": 2,
      "x": 918,
      "y": 704
    },
    {
      "t": 158010,
      "e": 142717,
      "ty": 41,
      "x": 24335,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 158410,
      "e": 143117,
      "ty": 2,
      "x": 918,
      "y": 702
    },
    {
      "t": 158510,
      "e": 143217,
      "ty": 2,
      "x": 921,
      "y": 690
    },
    {
      "t": 158510,
      "e": 143217,
      "ty": 41,
      "x": 23632,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 158610,
      "e": 143317,
      "ty": 2,
      "x": 926,
      "y": 683
    },
    {
      "t": 158710,
      "e": 143417,
      "ty": 2,
      "x": 928,
      "y": 681
    },
    {
      "t": 158760,
      "e": 143467,
      "ty": 41,
      "x": 29690,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 158809,
      "e": 143516,
      "ty": 2,
      "x": 936,
      "y": 673
    },
    {
      "t": 159009,
      "e": 143716,
      "ty": 2,
      "x": 936,
      "y": 672
    },
    {
      "t": 159011,
      "e": 143718,
      "ty": 41,
      "x": 30764,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 159810,
      "e": 144517,
      "ty": 2,
      "x": 935,
      "y": 672
    },
    {
      "t": 159910,
      "e": 144617,
      "ty": 2,
      "x": 931,
      "y": 674
    },
    {
      "t": 160010,
      "e": 144717,
      "ty": 2,
      "x": 929,
      "y": 690
    },
    {
      "t": 160010,
      "e": 144717,
      "ty": 41,
      "x": 25530,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 160010,
      "e": 144717,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 160109,
      "e": 144816,
      "ty": 2,
      "x": 929,
      "y": 702
    },
    {
      "t": 160210,
      "e": 144917,
      "ty": 2,
      "x": 931,
      "y": 708
    },
    {
      "t": 160260,
      "e": 144967,
      "ty": 41,
      "x": 27611,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 160310,
      "e": 145017,
      "ty": 2,
      "x": 931,
      "y": 709
    },
    {
      "t": 165909,
      "e": 150017,
      "ty": 2,
      "x": 930,
      "y": 711
    },
    {
      "t": 166009,
      "e": 150117,
      "ty": 2,
      "x": 926,
      "y": 712
    },
    {
      "t": 166010,
      "e": 150118,
      "ty": 41,
      "x": 26351,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 166109,
      "e": 150217,
      "ty": 2,
      "x": 925,
      "y": 715
    },
    {
      "t": 166209,
      "e": 150317,
      "ty": 2,
      "x": 925,
      "y": 721
    },
    {
      "t": 166259,
      "e": 150367,
      "ty": 41,
      "x": 25996,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 166310,
      "e": 150418,
      "ty": 2,
      "x": 925,
      "y": 724
    },
    {
      "t": 166409,
      "e": 150517,
      "ty": 2,
      "x": 925,
      "y": 726
    },
    {
      "t": 166509,
      "e": 150617,
      "ty": 2,
      "x": 925,
      "y": 732
    },
    {
      "t": 166509,
      "e": 150617,
      "ty": 41,
      "x": 25996,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 166609,
      "e": 150717,
      "ty": 2,
      "x": 925,
      "y": 737
    },
    {
      "t": 166710,
      "e": 150818,
      "ty": 2,
      "x": 925,
      "y": 740
    },
    {
      "t": 166759,
      "e": 150867,
      "ty": 41,
      "x": 24581,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 166809,
      "e": 150917,
      "ty": 2,
      "x": 925,
      "y": 742
    },
    {
      "t": 166909,
      "e": 151017,
      "ty": 2,
      "x": 925,
      "y": 747
    },
    {
      "t": 167009,
      "e": 151117,
      "ty": 2,
      "x": 924,
      "y": 752
    },
    {
      "t": 167009,
      "e": 151117,
      "ty": 41,
      "x": 42801,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 167109,
      "e": 151217,
      "ty": 2,
      "x": 921,
      "y": 760
    },
    {
      "t": 167209,
      "e": 151317,
      "ty": 2,
      "x": 920,
      "y": 766
    },
    {
      "t": 167259,
      "e": 151367,
      "ty": 41,
      "x": 41132,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 167309,
      "e": 151417,
      "ty": 2,
      "x": 919,
      "y": 767
    },
    {
      "t": 167410,
      "e": 151518,
      "ty": 2,
      "x": 915,
      "y": 776
    },
    {
      "t": 167509,
      "e": 151617,
      "ty": 2,
      "x": 906,
      "y": 789
    },
    {
      "t": 167509,
      "e": 151617,
      "ty": 41,
      "x": 47349,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 167609,
      "e": 151717,
      "ty": 2,
      "x": 903,
      "y": 794
    },
    {
      "t": 167709,
      "e": 151817,
      "ty": 2,
      "x": 901,
      "y": 799
    },
    {
      "t": 167759,
      "e": 151867,
      "ty": 41,
      "x": 18885,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 168009,
      "e": 152117,
      "ty": 2,
      "x": 900,
      "y": 799
    },
    {
      "t": 168009,
      "e": 152117,
      "ty": 41,
      "x": 18648,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 168509,
      "e": 152617,
      "ty": 2,
      "x": 900,
      "y": 794
    },
    {
      "t": 168509,
      "e": 152617,
      "ty": 41,
      "x": 43990,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 168609,
      "e": 152717,
      "ty": 2,
      "x": 896,
      "y": 780
    },
    {
      "t": 168710,
      "e": 152818,
      "ty": 2,
      "x": 896,
      "y": 771
    },
    {
      "t": 168759,
      "e": 152867,
      "ty": 41,
      "x": 31118,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 168809,
      "e": 152917,
      "ty": 2,
      "x": 896,
      "y": 765
    },
    {
      "t": 168910,
      "e": 153018,
      "ty": 2,
      "x": 896,
      "y": 758
    },
    {
      "t": 169008,
      "e": 153116,
      "ty": 3,
      "x": 896,
      "y": 758,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 169009,
      "e": 153117,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 169010,
      "e": 153118,
      "ty": 41,
      "x": 31118,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 169118,
      "e": 153226,
      "ty": 4,
      "x": 31118,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 169121,
      "e": 153229,
      "ty": 5,
      "x": 896,
      "y": 758,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 169122,
      "e": 153230,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 169124,
      "e": 153232,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf",
      "v": "Natural Sciences"
    },
    {
      "t": 169259,
      "e": 153367,
      "ty": 41,
      "x": 29866,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 169309,
      "e": 153417,
      "ty": 2,
      "x": 890,
      "y": 776
    },
    {
      "t": 169409,
      "e": 153517,
      "ty": 2,
      "x": 890,
      "y": 791
    },
    {
      "t": 169509,
      "e": 153617,
      "ty": 41,
      "x": 38392,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 169609,
      "e": 153717,
      "ty": 2,
      "x": 939,
      "y": 806
    },
    {
      "t": 169710,
      "e": 153818,
      "ty": 2,
      "x": 1011,
      "y": 781
    },
    {
      "t": 169760,
      "e": 153868,
      "ty": 41,
      "x": 63502,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 169809,
      "e": 153917,
      "ty": 2,
      "x": 1223,
      "y": 723
    },
    {
      "t": 169909,
      "e": 154017,
      "ty": 2,
      "x": 1259,
      "y": 699
    },
    {
      "t": 170009,
      "e": 154117,
      "ty": 41,
      "x": 43081,
      "y": 38279,
      "ta": "html > body"
    },
    {
      "t": 170009,
      "e": 154117,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 170509,
      "e": 154617,
      "ty": 2,
      "x": 1243,
      "y": 707
    },
    {
      "t": 170509,
      "e": 154617,
      "ty": 41,
      "x": 42530,
      "y": 38722,
      "ta": "html > body"
    },
    {
      "t": 170610,
      "e": 154718,
      "ty": 2,
      "x": 1181,
      "y": 757
    },
    {
      "t": 170709,
      "e": 154817,
      "ty": 2,
      "x": 1116,
      "y": 799
    },
    {
      "t": 170759,
      "e": 154867,
      "ty": 41,
      "x": 60655,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 170809,
      "e": 154917,
      "ty": 2,
      "x": 1021,
      "y": 857
    },
    {
      "t": 170909,
      "e": 155017,
      "ty": 2,
      "x": 968,
      "y": 891
    },
    {
      "t": 171010,
      "e": 155118,
      "ty": 2,
      "x": 950,
      "y": 916
    },
    {
      "t": 171010,
      "e": 155118,
      "ty": 41,
      "x": 30514,
      "y": 20668,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 171109,
      "e": 155217,
      "ty": 2,
      "x": 934,
      "y": 933
    },
    {
      "t": 171210,
      "e": 155318,
      "ty": 2,
      "x": 916,
      "y": 948
    },
    {
      "t": 171260,
      "e": 155368,
      "ty": 41,
      "x": 21733,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 171310,
      "e": 155418,
      "ty": 2,
      "x": 912,
      "y": 951
    },
    {
      "t": 171409,
      "e": 155517,
      "ty": 2,
      "x": 885,
      "y": 953
    },
    {
      "t": 171509,
      "e": 155617,
      "ty": 2,
      "x": 823,
      "y": 950
    },
    {
      "t": 171510,
      "e": 155618,
      "ty": 41,
      "x": 374,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 171610,
      "e": 155718,
      "ty": 2,
      "x": 814,
      "y": 946
    },
    {
      "t": 171709,
      "e": 155817,
      "ty": 2,
      "x": 817,
      "y": 941
    },
    {
      "t": 171760,
      "e": 155868,
      "ty": 41,
      "x": 0,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 171809,
      "e": 155917,
      "ty": 2,
      "x": 825,
      "y": 938
    },
    {
      "t": 171811,
      "e": 155919,
      "ty": 6,
      "x": 826,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 171861,
      "e": 155969,
      "ty": 7,
      "x": 840,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 171909,
      "e": 156017,
      "ty": 2,
      "x": 843,
      "y": 936
    },
    {
      "t": 172010,
      "e": 156118,
      "ty": 2,
      "x": 845,
      "y": 936
    },
    {
      "t": 172010,
      "e": 156118,
      "ty": 41,
      "x": 25753,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 172063,
      "e": 156171,
      "ty": 3,
      "x": 845,
      "y": 936,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 172065,
      "e": 156173,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 172142,
      "e": 156250,
      "ty": 4,
      "x": 25753,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 172142,
      "e": 156250,
      "ty": 5,
      "x": 845,
      "y": 936,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 172142,
      "e": 156250,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 172143,
      "e": 156251,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 172209,
      "e": 156317,
      "ty": 2,
      "x": 849,
      "y": 942
    },
    {
      "t": 172259,
      "e": 156367,
      "ty": 41,
      "x": 48224,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 172262,
      "e": 156370,
      "ty": 6,
      "x": 881,
      "y": 1012,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 172309,
      "e": 156417,
      "ty": 2,
      "x": 885,
      "y": 1019
    },
    {
      "t": 172410,
      "e": 156518,
      "ty": 2,
      "x": 884,
      "y": 1036
    },
    {
      "t": 172510,
      "e": 156618,
      "ty": 2,
      "x": 884,
      "y": 1037
    },
    {
      "t": 172510,
      "e": 156618,
      "ty": 41,
      "x": 28128,
      "y": 63549,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 172609,
      "e": 156717,
      "ty": 2,
      "x": 883,
      "y": 1032
    },
    {
      "t": 172703,
      "e": 156811,
      "ty": 3,
      "x": 883,
      "y": 1031,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 172703,
      "e": 156811,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 172703,
      "e": 156811,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 172710,
      "e": 156818,
      "ty": 2,
      "x": 883,
      "y": 1031
    },
    {
      "t": 172759,
      "e": 156867,
      "ty": 41,
      "x": 27613,
      "y": 51633,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 172782,
      "e": 156890,
      "ty": 4,
      "x": 27613,
      "y": 51633,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 172782,
      "e": 156890,
      "ty": 5,
      "x": 883,
      "y": 1031,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 172784,
      "e": 156892,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 172786,
      "e": 156894,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 172786,
      "e": 156894,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 173009,
      "e": 157117,
      "ty": 2,
      "x": 885,
      "y": 1019
    },
    {
      "t": 173010,
      "e": 157118,
      "ty": 41,
      "x": 30201,
      "y": 56006,
      "ta": "html > body"
    },
    {
      "t": 173109,
      "e": 157217,
      "ty": 2,
      "x": 941,
      "y": 950
    },
    {
      "t": 173209,
      "e": 157317,
      "ty": 2,
      "x": 1015,
      "y": 870
    },
    {
      "t": 173260,
      "e": 157368,
      "ty": 41,
      "x": 35505,
      "y": 46256,
      "ta": "html > body"
    },
    {
      "t": 173309,
      "e": 157417,
      "ty": 2,
      "x": 1055,
      "y": 829
    },
    {
      "t": 173410,
      "e": 157518,
      "ty": 2,
      "x": 1084,
      "y": 806
    },
    {
      "t": 173509,
      "e": 157617,
      "ty": 2,
      "x": 1109,
      "y": 790
    },
    {
      "t": 173510,
      "e": 157618,
      "ty": 41,
      "x": 37915,
      "y": 43320,
      "ta": "html > body"
    },
    {
      "t": 173610,
      "e": 157718,
      "ty": 2,
      "x": 1110,
      "y": 790
    },
    {
      "t": 173759,
      "e": 157867,
      "ty": 41,
      "x": 37950,
      "y": 43320,
      "ta": "html > body"
    },
    {
      "t": 173909,
      "e": 158017,
      "ty": 2,
      "x": 1113,
      "y": 790
    },
    {
      "t": 174010,
      "e": 158118,
      "ty": 41,
      "x": 38053,
      "y": 43320,
      "ta": "html > body"
    },
    {
      "t": 174186,
      "e": 158294,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 180010,
      "e": 163118,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 268915,
      "e": 163118,
      "ty": 2,
      "x": 1195,
      "y": 736
    },
    {
      "t": 269016,
      "e": 163219,
      "ty": 2,
      "x": 1492,
      "y": 730
    },
    {
      "t": 269016,
      "e": 163219,
      "ty": 41,
      "x": 58964,
      "y": 35994,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 269116,
      "e": 163319,
      "ty": 2,
      "x": 1504,
      "y": 723
    },
    {
      "t": 269216,
      "e": 163419,
      "ty": 2,
      "x": 1496,
      "y": 676
    },
    {
      "t": 269266,
      "e": 163469,
      "ty": 41,
      "x": 59014,
      "y": 4397,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 269316,
      "e": 163519,
      "ty": 2,
      "x": 1347,
      "y": 864
    },
    {
      "t": 269416,
      "e": 163619,
      "ty": 2,
      "x": 1083,
      "y": 1215
    },
    {
      "t": 269515,
      "e": 163718,
      "ty": 2,
      "x": 1080,
      "y": 1215
    },
    {
      "t": 269616,
      "e": 163819,
      "ty": 2,
      "x": 1058,
      "y": 1213
    },
    {
      "t": 269716,
      "e": 163919,
      "ty": 2,
      "x": 945,
      "y": 1154
    },
    {
      "t": 269766,
      "e": 163969,
      "ty": 41,
      "x": 24575,
      "y": 36736,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 269816,
      "e": 164019,
      "ty": 2,
      "x": 933,
      "y": 1124
    },
    {
      "t": 269916,
      "e": 164119,
      "ty": 2,
      "x": 947,
      "y": 1107
    },
    {
      "t": 269917,
      "e": 164120,
      "ty": 6,
      "x": 947,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 270016,
      "e": 164219,
      "ty": 2,
      "x": 950,
      "y": 1105
    },
    {
      "t": 270016,
      "e": 164219,
      "ty": 41,
      "x": 22118,
      "y": 62282,
      "ta": "#start"
    },
    {
      "t": 270116,
      "e": 164319,
      "ty": 2,
      "x": 957,
      "y": 1101
    },
    {
      "t": 270215,
      "e": 164418,
      "ty": 2,
      "x": 961,
      "y": 1098
    },
    {
      "t": 270266,
      "e": 164469,
      "ty": 41,
      "x": 28125,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 270294,
      "e": 164497,
      "ty": 3,
      "x": 961,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 270295,
      "e": 164498,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 270340,
      "e": 164543,
      "ty": 4,
      "x": 28125,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 270341,
      "e": 164544,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 270342,
      "e": 164545,
      "ty": 5,
      "x": 961,
      "y": 1098,
      "ta": "#start"
    },
    {
      "t": 270343,
      "e": 164546,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 271382,
      "e": 165585,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 273013,
      "e": 167216,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 104445, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 104452, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 73431, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 179257, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 27959, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"XRAY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 208225, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 43625, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 253227, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 13531, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 267760, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 97683, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 367132, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1078,y:1008,t:1527876724816};\\\", \\\"{x:970,y:851,t:1527876724832};\\\", \\\"{x:812,y:664,t:1527876724849};\\\", \\\"{x:628,y:473,t:1527876724864};\\\", \\\"{x:419,y:252,t:1527876724882};\\\", \\\"{x:173,y:8,t:1527876724898};\\\", \\\"{x:0,y:0,t:1527876724914};\\\", \\\"{x:0,y:6,t:1527876725407};\\\", \\\"{x:0,y:16,t:1527876725415};\\\", \\\"{x:0,y:29,t:1527876725432};\\\", \\\"{x:0,y:39,t:1527876725448};\\\", \\\"{x:0,y:48,t:1527876725466};\\\", \\\"{x:0,y:56,t:1527876725482};\\\", \\\"{x:0,y:63,t:1527876725499};\\\", \\\"{x:0,y:73,t:1527876725515};\\\", \\\"{x:0,y:83,t:1527876725531};\\\", \\\"{x:0,y:91,t:1527876725549};\\\", \\\"{x:0,y:92,t:1527876725565};\\\", \\\"{x:1,y:93,t:1527876725582};\\\", \\\"{x:3,y:93,t:1527876725598};\\\", \\\"{x:4,y:93,t:1527876725615};\\\", \\\"{x:5,y:93,t:1527876725631};\\\", \\\"{x:8,y:93,t:1527876725649};\\\", \\\"{x:9,y:93,t:1527876725666};\\\", \\\"{x:12,y:93,t:1527876728447};\\\", \\\"{x:20,y:89,t:1527876728455};\\\", \\\"{x:28,y:85,t:1527876728468};\\\", \\\"{x:45,y:78,t:1527876728484};\\\", \\\"{x:61,y:70,t:1527876728501};\\\", \\\"{x:84,y:68,t:1527876728518};\\\", \\\"{x:106,y:68,t:1527876728533};\\\", \\\"{x:136,y:70,t:1527876728551};\\\", \\\"{x:158,y:77,t:1527876728568};\\\", \\\"{x:184,y:83,t:1527876728583};\\\", \\\"{x:210,y:92,t:1527876728601};\\\", \\\"{x:250,y:101,t:1527876728617};\\\", \\\"{x:284,y:113,t:1527876728635};\\\", \\\"{x:316,y:125,t:1527876728651};\\\", \\\"{x:348,y:142,t:1527876728668};\\\", \\\"{x:368,y:165,t:1527876728685};\\\", \\\"{x:378,y:192,t:1527876728701};\\\", \\\"{x:380,y:229,t:1527876728718};\\\", \\\"{x:388,y:321,t:1527876728735};\\\", \\\"{x:390,y:388,t:1527876728751};\\\", \\\"{x:390,y:442,t:1527876728768};\\\", \\\"{x:385,y:469,t:1527876728785};\\\", \\\"{x:375,y:490,t:1527876728801};\\\", \\\"{x:364,y:507,t:1527876728818};\\\", \\\"{x:352,y:519,t:1527876728835};\\\", \\\"{x:348,y:525,t:1527876728851};\\\", \\\"{x:347,y:529,t:1527876728868};\\\", \\\"{x:347,y:535,t:1527876728885};\\\", \\\"{x:348,y:541,t:1527876728901};\\\", \\\"{x:358,y:551,t:1527876728919};\\\", \\\"{x:363,y:555,t:1527876728934};\\\", \\\"{x:364,y:555,t:1527876729013};\\\", \\\"{x:367,y:555,t:1527876729022};\\\", \\\"{x:370,y:555,t:1527876729038};\\\", \\\"{x:372,y:554,t:1527876729056};\\\", \\\"{x:373,y:553,t:1527876729072};\\\", \\\"{x:377,y:550,t:1527876729088};\\\", \\\"{x:381,y:549,t:1527876729106};\\\", \\\"{x:386,y:546,t:1527876729122};\\\", \\\"{x:390,y:544,t:1527876729139};\\\", \\\"{x:391,y:544,t:1527876729155};\\\", \\\"{x:390,y:544,t:1527876729374};\\\", \\\"{x:389,y:544,t:1527876729389};\\\", \\\"{x:387,y:545,t:1527876729407};\\\", \\\"{x:384,y:547,t:1527876729421};\\\", \\\"{x:383,y:547,t:1527876729439};\\\", \\\"{x:382,y:549,t:1527876729455};\\\", \\\"{x:382,y:551,t:1527876729472};\\\", \\\"{x:381,y:552,t:1527876729488};\\\", \\\"{x:381,y:553,t:1527876729526};\\\", \\\"{x:380,y:554,t:1527876729566};\\\", \\\"{x:380,y:555,t:1527876729573};\\\", \\\"{x:380,y:556,t:1527876729588};\\\", \\\"{x:382,y:556,t:1527876736279};\\\", \\\"{x:390,y:556,t:1527876736291};\\\", \\\"{x:417,y:563,t:1527876736308};\\\", \\\"{x:440,y:565,t:1527876736325};\\\", \\\"{x:461,y:570,t:1527876736341};\\\", \\\"{x:470,y:570,t:1527876736356};\\\", \\\"{x:484,y:574,t:1527876736378};\\\", \\\"{x:500,y:581,t:1527876736395};\\\", \\\"{x:513,y:582,t:1527876736411};\\\", \\\"{x:525,y:585,t:1527876736428};\\\", \\\"{x:536,y:587,t:1527876736445};\\\", \\\"{x:558,y:594,t:1527876736461};\\\", \\\"{x:579,y:599,t:1527876736478};\\\", \\\"{x:597,y:601,t:1527876736494};\\\", \\\"{x:607,y:605,t:1527876736511};\\\", \\\"{x:615,y:608,t:1527876736528};\\\", \\\"{x:616,y:608,t:1527876736550};\\\", \\\"{x:617,y:608,t:1527876736574};\\\", \\\"{x:618,y:608,t:1527876736582};\\\", \\\"{x:622,y:608,t:1527876736593};\\\", \\\"{x:630,y:608,t:1527876736610};\\\", \\\"{x:635,y:606,t:1527876736627};\\\", \\\"{x:635,y:605,t:1527876736711};\\\", \\\"{x:633,y:603,t:1527876736727};\\\", \\\"{x:627,y:601,t:1527876736744};\\\", \\\"{x:610,y:598,t:1527876736760};\\\", \\\"{x:588,y:594,t:1527876736778};\\\", \\\"{x:566,y:591,t:1527876736793};\\\", \\\"{x:551,y:591,t:1527876736812};\\\", \\\"{x:534,y:590,t:1527876736828};\\\", \\\"{x:512,y:589,t:1527876736845};\\\", \\\"{x:480,y:584,t:1527876736862};\\\", \\\"{x:465,y:583,t:1527876736879};\\\", \\\"{x:458,y:582,t:1527876736894};\\\", \\\"{x:456,y:581,t:1527876736912};\\\", \\\"{x:454,y:581,t:1527876736929};\\\", \\\"{x:453,y:581,t:1527876736945};\\\", \\\"{x:450,y:581,t:1527876736962};\\\", \\\"{x:447,y:581,t:1527876736979};\\\", \\\"{x:442,y:584,t:1527876736995};\\\", \\\"{x:439,y:587,t:1527876737012};\\\", \\\"{x:437,y:589,t:1527876737030};\\\", \\\"{x:434,y:591,t:1527876737045};\\\", \\\"{x:430,y:593,t:1527876737063};\\\", \\\"{x:426,y:595,t:1527876737078};\\\", \\\"{x:420,y:597,t:1527876737095};\\\", \\\"{x:411,y:603,t:1527876737113};\\\", \\\"{x:403,y:608,t:1527876737128};\\\", \\\"{x:400,y:609,t:1527876737145};\\\", \\\"{x:399,y:610,t:1527876737161};\\\", \\\"{x:398,y:610,t:1527876737179};\\\", \\\"{x:397,y:610,t:1527876737195};\\\", \\\"{x:396,y:611,t:1527876737359};\\\", \\\"{x:395,y:610,t:1527876737379};\\\", \\\"{x:394,y:608,t:1527876737405};\\\", \\\"{x:393,y:608,t:1527876737413};\\\", \\\"{x:393,y:606,t:1527876737428};\\\", \\\"{x:391,y:604,t:1527876737445};\\\", \\\"{x:389,y:601,t:1527876737461};\\\", \\\"{x:387,y:598,t:1527876737479};\\\", \\\"{x:386,y:598,t:1527876746271};\\\", \\\"{x:384,y:598,t:1527876746288};\\\", \\\"{x:383,y:598,t:1527876746305};\\\", \\\"{x:386,y:603,t:1527876746454};\\\", \\\"{x:403,y:621,t:1527876746474};\\\", \\\"{x:425,y:638,t:1527876746487};\\\", \\\"{x:457,y:654,t:1527876746504};\\\", \\\"{x:547,y:689,t:1527876746536};\\\", \\\"{x:565,y:698,t:1527876746552};\\\", \\\"{x:574,y:704,t:1527876746569};\\\", \\\"{x:578,y:708,t:1527876746586};\\\", \\\"{x:579,y:717,t:1527876746602};\\\", \\\"{x:579,y:722,t:1527876746618};\\\", \\\"{x:579,y:726,t:1527876746637};\\\", \\\"{x:579,y:727,t:1527876746686};\\\", \\\"{x:579,y:729,t:1527876746702};\\\", \\\"{x:579,y:737,t:1527876746719};\\\", \\\"{x:579,y:744,t:1527876746737};\\\", \\\"{x:579,y:748,t:1527876746753};\\\", \\\"{x:570,y:754,t:1527876746769};\\\", \\\"{x:553,y:760,t:1527876746787};\\\", \\\"{x:533,y:761,t:1527876746804};\\\", \\\"{x:512,y:761,t:1527876746820};\\\", \\\"{x:494,y:758,t:1527876746837};\\\", \\\"{x:481,y:756,t:1527876746853};\\\", \\\"{x:461,y:750,t:1527876746870};\\\", \\\"{x:453,y:747,t:1527876746887};\\\", \\\"{x:449,y:744,t:1527876746903};\\\", \\\"{x:443,y:740,t:1527876746921};\\\", \\\"{x:441,y:738,t:1527876746938};\\\", \\\"{x:441,y:737,t:1527876747087};\\\", \\\"{x:446,y:737,t:1527876747104};\\\", \\\"{x:450,y:737,t:1527876747122};\\\", \\\"{x:454,y:738,t:1527876747136};\\\", \\\"{x:459,y:739,t:1527876747153};\\\", \\\"{x:465,y:740,t:1527876747170};\\\", \\\"{x:473,y:744,t:1527876747187};\\\", \\\"{x:482,y:748,t:1527876747203};\\\", \\\"{x:490,y:749,t:1527876747220};\\\", \\\"{x:497,y:749,t:1527876747237};\\\", \\\"{x:498,y:751,t:1527876747253};\\\", \\\"{x:507,y:747,t:1527876749799};\\\", \\\"{x:529,y:744,t:1527876749808};\\\", \\\"{x:579,y:738,t:1527876749825};\\\", \\\"{x:652,y:722,t:1527876749840};\\\", \\\"{x:740,y:689,t:1527876749856};\\\", \\\"{x:821,y:644,t:1527876749873};\\\", \\\"{x:890,y:615,t:1527876749889};\\\", \\\"{x:941,y:599,t:1527876749906};\\\", \\\"{x:986,y:584,t:1527876749922};\\\", \\\"{x:1065,y:574,t:1527876749939};\\\", \\\"{x:1116,y:573,t:1527876749956};\\\", \\\"{x:1139,y:572,t:1527876749972};\\\", \\\"{x:1160,y:572,t:1527876749989};\\\", \\\"{x:1181,y:575,t:1527876750006};\\\", \\\"{x:1195,y:577,t:1527876750023};\\\", \\\"{x:1213,y:582,t:1527876750039};\\\", \\\"{x:1235,y:588,t:1527876750055};\\\", \\\"{x:1254,y:592,t:1527876750072};\\\", \\\"{x:1267,y:601,t:1527876750089};\\\", \\\"{x:1283,y:621,t:1527876750106};\\\", \\\"{x:1293,y:643,t:1527876750122};\\\", \\\"{x:1302,y:664,t:1527876750140};\\\", \\\"{x:1308,y:680,t:1527876750156};\\\", \\\"{x:1312,y:695,t:1527876750173};\\\", \\\"{x:1321,y:726,t:1527876750190};\\\", \\\"{x:1337,y:767,t:1527876750206};\\\", \\\"{x:1354,y:793,t:1527876750223};\\\", \\\"{x:1371,y:808,t:1527876750240};\\\", \\\"{x:1381,y:815,t:1527876750257};\\\", \\\"{x:1384,y:817,t:1527876750273};\\\", \\\"{x:1385,y:817,t:1527876750290};\\\", \\\"{x:1386,y:817,t:1527876750374};\\\", \\\"{x:1387,y:817,t:1527876750390};\\\", \\\"{x:1388,y:817,t:1527876750423};\\\", \\\"{x:1389,y:813,t:1527876750440};\\\", \\\"{x:1389,y:809,t:1527876750457};\\\", \\\"{x:1389,y:807,t:1527876750473};\\\", \\\"{x:1391,y:802,t:1527876750490};\\\", \\\"{x:1391,y:800,t:1527876750507};\\\", \\\"{x:1391,y:798,t:1527876750523};\\\", \\\"{x:1391,y:796,t:1527876750541};\\\", \\\"{x:1390,y:792,t:1527876750557};\\\", \\\"{x:1388,y:789,t:1527876750573};\\\", \\\"{x:1387,y:789,t:1527876750615};\\\", \\\"{x:1385,y:788,t:1527876750630};\\\", \\\"{x:1384,y:787,t:1527876750662};\\\", \\\"{x:1383,y:786,t:1527876750673};\\\", \\\"{x:1378,y:782,t:1527876750690};\\\", \\\"{x:1374,y:779,t:1527876750707};\\\", \\\"{x:1374,y:778,t:1527876750727};\\\", \\\"{x:1374,y:777,t:1527876750740};\\\", \\\"{x:1374,y:773,t:1527876750758};\\\", \\\"{x:1374,y:769,t:1527876750774};\\\", \\\"{x:1374,y:765,t:1527876750790};\\\", \\\"{x:1374,y:762,t:1527876750806};\\\", \\\"{x:1374,y:760,t:1527876750824};\\\", \\\"{x:1377,y:759,t:1527876750849};\\\", \\\"{x:1378,y:758,t:1527876750874};\\\", \\\"{x:1379,y:758,t:1527876750901};\\\", \\\"{x:1380,y:758,t:1527876750917};\\\", \\\"{x:1381,y:757,t:1527876750934};\\\", \\\"{x:1382,y:757,t:1527876750941};\\\", \\\"{x:1383,y:757,t:1527876750973};\\\", \\\"{x:1381,y:757,t:1527876751294};\\\", \\\"{x:1380,y:757,t:1527876751343};\\\", \\\"{x:1379,y:758,t:1527876751395};\\\", \\\"{x:1378,y:759,t:1527876751470};\\\", \\\"{x:1377,y:759,t:1527876751566};\\\", \\\"{x:1377,y:760,t:1527876757671};\\\", \\\"{x:1377,y:761,t:1527876757678};\\\", \\\"{x:1369,y:765,t:1527876757698};\\\", \\\"{x:1365,y:770,t:1527876757712};\\\", \\\"{x:1364,y:785,t:1527876757727};\\\", \\\"{x:1363,y:795,t:1527876757745};\\\", \\\"{x:1363,y:801,t:1527876757762};\\\", \\\"{x:1363,y:806,t:1527876757778};\\\", \\\"{x:1363,y:810,t:1527876757796};\\\", \\\"{x:1365,y:818,t:1527876757812};\\\", \\\"{x:1367,y:824,t:1527876757829};\\\", \\\"{x:1369,y:835,t:1527876757845};\\\", \\\"{x:1370,y:843,t:1527876757862};\\\", \\\"{x:1371,y:846,t:1527876757879};\\\", \\\"{x:1371,y:848,t:1527876757896};\\\", \\\"{x:1373,y:853,t:1527876757912};\\\", \\\"{x:1373,y:856,t:1527876757929};\\\", \\\"{x:1374,y:860,t:1527876757946};\\\", \\\"{x:1375,y:862,t:1527876757963};\\\", \\\"{x:1375,y:864,t:1527876757980};\\\", \\\"{x:1375,y:865,t:1527876757996};\\\", \\\"{x:1375,y:867,t:1527876758013};\\\", \\\"{x:1375,y:871,t:1527876758029};\\\", \\\"{x:1375,y:874,t:1527876758047};\\\", \\\"{x:1375,y:877,t:1527876758062};\\\", \\\"{x:1375,y:880,t:1527876758080};\\\", \\\"{x:1375,y:883,t:1527876758096};\\\", \\\"{x:1374,y:885,t:1527876758113};\\\", \\\"{x:1373,y:887,t:1527876758130};\\\", \\\"{x:1372,y:889,t:1527876758146};\\\", \\\"{x:1371,y:891,t:1527876758163};\\\", \\\"{x:1370,y:893,t:1527876758180};\\\", \\\"{x:1367,y:896,t:1527876758197};\\\", \\\"{x:1364,y:901,t:1527876758214};\\\", \\\"{x:1362,y:903,t:1527876758230};\\\", \\\"{x:1359,y:905,t:1527876758246};\\\", \\\"{x:1358,y:906,t:1527876758270};\\\", \\\"{x:1357,y:907,t:1527876758351};\\\", \\\"{x:1356,y:907,t:1527876758391};\\\", \\\"{x:1355,y:907,t:1527876758398};\\\", \\\"{x:1354,y:907,t:1527876758414};\\\", \\\"{x:1353,y:907,t:1527876758447};\\\", \\\"{x:1352,y:907,t:1527876758464};\\\", \\\"{x:1351,y:906,t:1527876758480};\\\", \\\"{x:1349,y:905,t:1527876758496};\\\", \\\"{x:1347,y:904,t:1527876758513};\\\", \\\"{x:1345,y:902,t:1527876758530};\\\", \\\"{x:1344,y:901,t:1527876758547};\\\", \\\"{x:1344,y:900,t:1527876758579};\\\", \\\"{x:1344,y:898,t:1527876758595};\\\", \\\"{x:1343,y:897,t:1527876758613};\\\", \\\"{x:1343,y:895,t:1527876758637};\\\", \\\"{x:1343,y:894,t:1527876758661};\\\", \\\"{x:1343,y:892,t:1527876758687};\\\", \\\"{x:1343,y:891,t:1527876759086};\\\", \\\"{x:1344,y:891,t:1527876759151};\\\", \\\"{x:1344,y:890,t:1527876759318};\\\", \\\"{x:1345,y:890,t:1527876759365};\\\", \\\"{x:1346,y:890,t:1527876759390};\\\", \\\"{x:1348,y:889,t:1527876759406};\\\", \\\"{x:1349,y:888,t:1527876759599};\\\", \\\"{x:1349,y:889,t:1527876759783};\\\", \\\"{x:1349,y:890,t:1527876759798};\\\", \\\"{x:1348,y:891,t:1527876759813};\\\", \\\"{x:1348,y:892,t:1527876759832};\\\", \\\"{x:1348,y:893,t:1527876759846};\\\", \\\"{x:1348,y:894,t:1527876759864};\\\", \\\"{x:1348,y:895,t:1527876759881};\\\", \\\"{x:1348,y:896,t:1527876759896};\\\", \\\"{x:1348,y:897,t:1527876759998};\\\", \\\"{x:1349,y:893,t:1527876762383};\\\", \\\"{x:1352,y:878,t:1527876762401};\\\", \\\"{x:1355,y:862,t:1527876762415};\\\", \\\"{x:1358,y:843,t:1527876762432};\\\", \\\"{x:1360,y:830,t:1527876762449};\\\", \\\"{x:1362,y:817,t:1527876762466};\\\", \\\"{x:1362,y:814,t:1527876762483};\\\", \\\"{x:1363,y:806,t:1527876762499};\\\", \\\"{x:1363,y:798,t:1527876762516};\\\", \\\"{x:1365,y:790,t:1527876762533};\\\", \\\"{x:1366,y:783,t:1527876762549};\\\", \\\"{x:1368,y:771,t:1527876762566};\\\", \\\"{x:1369,y:764,t:1527876762583};\\\", \\\"{x:1371,y:748,t:1527876762599};\\\", \\\"{x:1372,y:744,t:1527876762616};\\\", \\\"{x:1372,y:738,t:1527876762633};\\\", \\\"{x:1372,y:733,t:1527876762649};\\\", \\\"{x:1374,y:729,t:1527876762666};\\\", \\\"{x:1375,y:726,t:1527876762683};\\\", \\\"{x:1376,y:725,t:1527876762699};\\\", \\\"{x:1377,y:725,t:1527876762727};\\\", \\\"{x:1378,y:724,t:1527876762734};\\\", \\\"{x:1381,y:722,t:1527876762758};\\\", \\\"{x:1383,y:721,t:1527876762766};\\\", \\\"{x:1387,y:718,t:1527876762784};\\\", \\\"{x:1389,y:716,t:1527876762801};\\\", \\\"{x:1391,y:714,t:1527876762817};\\\", \\\"{x:1391,y:712,t:1527876762833};\\\", \\\"{x:1392,y:712,t:1527876762877};\\\", \\\"{x:1393,y:711,t:1527876762893};\\\", \\\"{x:1395,y:710,t:1527876763031};\\\", \\\"{x:1396,y:710,t:1527876763062};\\\", \\\"{x:1397,y:709,t:1527876763070};\\\", \\\"{x:1398,y:708,t:1527876763094};\\\", \\\"{x:1400,y:706,t:1527876763102};\\\", \\\"{x:1401,y:704,t:1527876763117};\\\", \\\"{x:1404,y:700,t:1527876763134};\\\", \\\"{x:1408,y:694,t:1527876763150};\\\", \\\"{x:1409,y:693,t:1527876763168};\\\", \\\"{x:1410,y:693,t:1527876763184};\\\", \\\"{x:1410,y:692,t:1527876763231};\\\", \\\"{x:1410,y:691,t:1527876763343};\\\", \\\"{x:1410,y:690,t:1527876763351};\\\", \\\"{x:1410,y:688,t:1527876763368};\\\", \\\"{x:1413,y:684,t:1527876763384};\\\", \\\"{x:1414,y:681,t:1527876763401};\\\", \\\"{x:1416,y:676,t:1527876763418};\\\", \\\"{x:1420,y:669,t:1527876763433};\\\", \\\"{x:1424,y:663,t:1527876763451};\\\", \\\"{x:1427,y:660,t:1527876763468};\\\", \\\"{x:1428,y:658,t:1527876763483};\\\", \\\"{x:1429,y:657,t:1527876763501};\\\", \\\"{x:1429,y:656,t:1527876763534};\\\", \\\"{x:1429,y:655,t:1527876763550};\\\", \\\"{x:1430,y:654,t:1527876763568};\\\", \\\"{x:1431,y:653,t:1527876763584};\\\", \\\"{x:1432,y:652,t:1527876763600};\\\", \\\"{x:1433,y:650,t:1527876763618};\\\", \\\"{x:1433,y:648,t:1527876763635};\\\", \\\"{x:1434,y:647,t:1527876763651};\\\", \\\"{x:1434,y:646,t:1527876763667};\\\", \\\"{x:1430,y:646,t:1527876763742};\\\", \\\"{x:1424,y:648,t:1527876763750};\\\", \\\"{x:1411,y:654,t:1527876763767};\\\", \\\"{x:1400,y:659,t:1527876763784};\\\", \\\"{x:1391,y:663,t:1527876763800};\\\", \\\"{x:1381,y:669,t:1527876763817};\\\", \\\"{x:1370,y:679,t:1527876763834};\\\", \\\"{x:1357,y:691,t:1527876763850};\\\", \\\"{x:1340,y:703,t:1527876763867};\\\", \\\"{x:1318,y:714,t:1527876763884};\\\", \\\"{x:1287,y:725,t:1527876763900};\\\", \\\"{x:1248,y:736,t:1527876763917};\\\", \\\"{x:1179,y:756,t:1527876763933};\\\", \\\"{x:1126,y:770,t:1527876763949};\\\", \\\"{x:1056,y:781,t:1527876763967};\\\", \\\"{x:988,y:793,t:1527876763984};\\\", \\\"{x:943,y:802,t:1527876764000};\\\", \\\"{x:873,y:811,t:1527876764017};\\\", \\\"{x:782,y:820,t:1527876764034};\\\", \\\"{x:700,y:828,t:1527876764050};\\\", \\\"{x:619,y:828,t:1527876764067};\\\", \\\"{x:544,y:828,t:1527876764084};\\\", \\\"{x:491,y:828,t:1527876764101};\\\", \\\"{x:451,y:829,t:1527876764117};\\\", \\\"{x:423,y:833,t:1527876764134};\\\", \\\"{x:418,y:834,t:1527876764151};\\\", \\\"{x:418,y:833,t:1527876764239};\\\", \\\"{x:418,y:825,t:1527876764252};\\\", \\\"{x:423,y:816,t:1527876764268};\\\", \\\"{x:433,y:802,t:1527876764285};\\\", \\\"{x:441,y:791,t:1527876764302};\\\", \\\"{x:453,y:783,t:1527876764318};\\\", \\\"{x:469,y:772,t:1527876764334};\\\", \\\"{x:480,y:764,t:1527876764353};\\\", \\\"{x:490,y:758,t:1527876764367};\\\", \\\"{x:498,y:754,t:1527876764384};\\\", \\\"{x:503,y:749,t:1527876764401};\\\", \\\"{x:507,y:747,t:1527876764416};\\\", \\\"{x:508,y:745,t:1527876764433};\\\", \\\"{x:509,y:744,t:1527876764454};\\\", \\\"{x:510,y:743,t:1527876764470};\\\", \\\"{x:509,y:744,t:1527876765245};\\\", \\\"{x:507,y:744,t:1527876765390};\\\", \\\"{x:506,y:745,t:1527876765414};\\\", \\\"{x:505,y:746,t:1527876765470};\\\", \\\"{x:504,y:746,t:1527876765662};\\\", \\\"{x:503,y:747,t:1527876770705};\\\", \\\"{x:503,y:751,t:1527876770729};\\\", \\\"{x:502,y:753,t:1527876770742};\\\", \\\"{x:502,y:754,t:1527876770759};\\\", \\\"{x:502,y:756,t:1527876770775};\\\", \\\"{x:501,y:751,t:1527876777296};\\\", \\\"{x:498,y:740,t:1527876777304};\\\", \\\"{x:497,y:733,t:1527876777315};\\\", \\\"{x:496,y:716,t:1527876777330};\\\", \\\"{x:492,y:701,t:1527876777348};\\\", \\\"{x:491,y:690,t:1527876777365};\\\", \\\"{x:488,y:674,t:1527876777382};\\\", \\\"{x:488,y:667,t:1527876777398};\\\", \\\"{x:487,y:657,t:1527876777415};\\\", \\\"{x:486,y:648,t:1527876777431};\\\", \\\"{x:484,y:639,t:1527876777447};\\\", \\\"{x:482,y:629,t:1527876777465};\\\", \\\"{x:481,y:625,t:1527876777482};\\\", \\\"{x:480,y:623,t:1527876777497};\\\" ] }, { \\\"rt\\\": 15819, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 384545, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -D -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:480,y:622,t:1527876781649};\\\", \\\"{x:484,y:622,t:1527876781664};\\\", \\\"{x:544,y:638,t:1527876781683};\\\", \\\"{x:583,y:648,t:1527876781698};\\\", \\\"{x:633,y:648,t:1527876781714};\\\", \\\"{x:675,y:648,t:1527876781734};\\\", \\\"{x:728,y:648,t:1527876781752};\\\", \\\"{x:823,y:648,t:1527876781767};\\\", \\\"{x:887,y:638,t:1527876781784};\\\", \\\"{x:967,y:620,t:1527876781802};\\\", \\\"{x:1053,y:607,t:1527876781817};\\\", \\\"{x:1139,y:593,t:1527876781834};\\\", \\\"{x:1213,y:579,t:1527876781851};\\\", \\\"{x:1276,y:565,t:1527876781867};\\\", \\\"{x:1345,y:546,t:1527876781885};\\\", \\\"{x:1413,y:523,t:1527876781902};\\\", \\\"{x:1474,y:493,t:1527876781918};\\\", \\\"{x:1531,y:464,t:1527876781935};\\\", \\\"{x:1564,y:442,t:1527876781952};\\\", \\\"{x:1584,y:425,t:1527876781967};\\\", \\\"{x:1594,y:414,t:1527876781984};\\\", \\\"{x:1598,y:411,t:1527876782001};\\\", \\\"{x:1601,y:408,t:1527876782018};\\\", \\\"{x:1604,y:403,t:1527876782035};\\\", \\\"{x:1605,y:401,t:1527876782051};\\\", \\\"{x:1605,y:397,t:1527876782068};\\\", \\\"{x:1605,y:392,t:1527876782085};\\\", \\\"{x:1605,y:389,t:1527876782100};\\\", \\\"{x:1605,y:387,t:1527876782161};\\\", \\\"{x:1605,y:385,t:1527876782176};\\\", \\\"{x:1603,y:381,t:1527876782184};\\\", \\\"{x:1602,y:377,t:1527876782202};\\\", \\\"{x:1599,y:373,t:1527876782218};\\\", \\\"{x:1599,y:371,t:1527876782249};\\\", \\\"{x:1598,y:370,t:1527876782257};\\\", \\\"{x:1596,y:368,t:1527876782268};\\\", \\\"{x:1594,y:361,t:1527876782285};\\\", \\\"{x:1590,y:353,t:1527876782302};\\\", \\\"{x:1590,y:350,t:1527876782318};\\\", \\\"{x:1589,y:347,t:1527876782335};\\\", \\\"{x:1588,y:347,t:1527876782425};\\\", \\\"{x:1588,y:348,t:1527876782609};\\\", \\\"{x:1590,y:357,t:1527876782617};\\\", \\\"{x:1600,y:379,t:1527876782634};\\\", \\\"{x:1610,y:399,t:1527876782652};\\\", \\\"{x:1616,y:412,t:1527876782667};\\\", \\\"{x:1624,y:423,t:1527876782685};\\\", \\\"{x:1627,y:427,t:1527876782700};\\\", \\\"{x:1628,y:428,t:1527876782717};\\\", \\\"{x:1629,y:431,t:1527876782735};\\\", \\\"{x:1630,y:436,t:1527876782751};\\\", \\\"{x:1633,y:441,t:1527876782767};\\\", \\\"{x:1633,y:445,t:1527876782785};\\\", \\\"{x:1633,y:446,t:1527876782849};\\\", \\\"{x:1633,y:447,t:1527876782872};\\\", \\\"{x:1633,y:448,t:1527876782885};\\\", \\\"{x:1632,y:448,t:1527876782901};\\\", \\\"{x:1629,y:447,t:1527876783009};\\\", \\\"{x:1628,y:444,t:1527876783018};\\\", \\\"{x:1627,y:440,t:1527876783034};\\\", \\\"{x:1624,y:435,t:1527876783050};\\\", \\\"{x:1622,y:431,t:1527876783067};\\\", \\\"{x:1621,y:428,t:1527876783084};\\\", \\\"{x:1621,y:427,t:1527876783100};\\\", \\\"{x:1621,y:426,t:1527876783117};\\\", \\\"{x:1621,y:425,t:1527876783272};\\\", \\\"{x:1618,y:425,t:1527876783290};\\\", \\\"{x:1614,y:425,t:1527876783300};\\\", \\\"{x:1608,y:427,t:1527876783318};\\\", \\\"{x:1606,y:429,t:1527876783335};\\\", \\\"{x:1604,y:429,t:1527876783352};\\\", \\\"{x:1603,y:429,t:1527876783370};\\\", \\\"{x:1603,y:430,t:1527876783472};\\\", \\\"{x:1604,y:430,t:1527876783545};\\\", \\\"{x:1606,y:430,t:1527876783553};\\\", \\\"{x:1608,y:429,t:1527876783570};\\\", \\\"{x:1610,y:428,t:1527876783588};\\\", \\\"{x:1613,y:428,t:1527876783602};\\\", \\\"{x:1613,y:427,t:1527876783619};\\\", \\\"{x:1615,y:426,t:1527876785896};\\\", \\\"{x:1614,y:426,t:1527876785920};\\\", \\\"{x:1612,y:428,t:1527876785937};\\\", \\\"{x:1611,y:432,t:1527876785944};\\\", \\\"{x:1611,y:434,t:1527876785955};\\\", \\\"{x:1610,y:437,t:1527876785975};\\\", \\\"{x:1609,y:440,t:1527876785988};\\\", \\\"{x:1608,y:444,t:1527876786004};\\\", \\\"{x:1608,y:451,t:1527876786021};\\\", \\\"{x:1606,y:457,t:1527876786038};\\\", \\\"{x:1605,y:465,t:1527876786054};\\\", \\\"{x:1604,y:473,t:1527876786072};\\\", \\\"{x:1602,y:478,t:1527876786088};\\\", \\\"{x:1601,y:484,t:1527876786105};\\\", \\\"{x:1600,y:493,t:1527876786122};\\\", \\\"{x:1598,y:503,t:1527876786137};\\\", \\\"{x:1596,y:513,t:1527876786155};\\\", \\\"{x:1592,y:523,t:1527876786171};\\\", \\\"{x:1587,y:533,t:1527876786187};\\\", \\\"{x:1582,y:545,t:1527876786205};\\\", \\\"{x:1578,y:553,t:1527876786222};\\\", \\\"{x:1576,y:562,t:1527876786238};\\\", \\\"{x:1573,y:571,t:1527876786255};\\\", \\\"{x:1571,y:584,t:1527876786272};\\\", \\\"{x:1569,y:591,t:1527876786287};\\\", \\\"{x:1567,y:598,t:1527876786305};\\\", \\\"{x:1565,y:604,t:1527876786322};\\\", \\\"{x:1564,y:610,t:1527876786338};\\\", \\\"{x:1562,y:615,t:1527876786355};\\\", \\\"{x:1560,y:620,t:1527876786372};\\\", \\\"{x:1558,y:626,t:1527876786388};\\\", \\\"{x:1556,y:629,t:1527876786406};\\\", \\\"{x:1556,y:631,t:1527876786422};\\\", \\\"{x:1556,y:632,t:1527876786438};\\\", \\\"{x:1554,y:633,t:1527876786456};\\\", \\\"{x:1552,y:636,t:1527876786472};\\\", \\\"{x:1549,y:638,t:1527876786487};\\\", \\\"{x:1546,y:640,t:1527876786504};\\\", \\\"{x:1543,y:642,t:1527876786521};\\\", \\\"{x:1541,y:643,t:1527876786538};\\\", \\\"{x:1539,y:645,t:1527876786555};\\\", \\\"{x:1538,y:645,t:1527876786571};\\\", \\\"{x:1536,y:645,t:1527876786616};\\\", \\\"{x:1534,y:645,t:1527876786624};\\\", \\\"{x:1533,y:645,t:1527876786639};\\\", \\\"{x:1527,y:645,t:1527876786655};\\\", \\\"{x:1521,y:645,t:1527876786672};\\\", \\\"{x:1519,y:645,t:1527876786688};\\\", \\\"{x:1518,y:645,t:1527876786705};\\\", \\\"{x:1517,y:645,t:1527876786722};\\\", \\\"{x:1516,y:644,t:1527876786739};\\\", \\\"{x:1515,y:643,t:1527876786755};\\\", \\\"{x:1515,y:642,t:1527876786772};\\\", \\\"{x:1514,y:640,t:1527876786789};\\\", \\\"{x:1514,y:638,t:1527876786809};\\\", \\\"{x:1513,y:638,t:1527876786822};\\\", \\\"{x:1513,y:637,t:1527876786839};\\\", \\\"{x:1513,y:636,t:1527876786897};\\\", \\\"{x:1513,y:635,t:1527876786910};\\\", \\\"{x:1513,y:634,t:1527876786922};\\\", \\\"{x:1512,y:632,t:1527876786939};\\\", \\\"{x:1512,y:631,t:1527876786968};\\\", \\\"{x:1482,y:627,t:1527876788524};\\\", \\\"{x:1404,y:618,t:1527876788540};\\\", \\\"{x:1306,y:614,t:1527876788556};\\\", \\\"{x:1201,y:614,t:1527876788572};\\\", \\\"{x:1035,y:614,t:1527876788590};\\\", \\\"{x:888,y:614,t:1527876788607};\\\", \\\"{x:717,y:614,t:1527876788623};\\\", \\\"{x:444,y:592,t:1527876788641};\\\", \\\"{x:273,y:574,t:1527876788657};\\\", \\\"{x:128,y:567,t:1527876788675};\\\", \\\"{x:31,y:565,t:1527876788690};\\\", \\\"{x:0,y:565,t:1527876788706};\\\", \\\"{x:0,y:563,t:1527876788825};\\\", \\\"{x:0,y:562,t:1527876788840};\\\", \\\"{x:1,y:561,t:1527876788857};\\\", \\\"{x:2,y:560,t:1527876788889};\\\", \\\"{x:5,y:559,t:1527876788896};\\\", \\\"{x:6,y:559,t:1527876788912};\\\", \\\"{x:8,y:558,t:1527876788924};\\\", \\\"{x:13,y:556,t:1527876788941};\\\", \\\"{x:22,y:552,t:1527876788957};\\\", \\\"{x:34,y:550,t:1527876788974};\\\", \\\"{x:53,y:550,t:1527876788991};\\\", \\\"{x:79,y:550,t:1527876789007};\\\", \\\"{x:142,y:559,t:1527876789023};\\\", \\\"{x:201,y:569,t:1527876789040};\\\", \\\"{x:284,y:580,t:1527876789058};\\\", \\\"{x:357,y:591,t:1527876789073};\\\", \\\"{x:411,y:596,t:1527876789091};\\\", \\\"{x:449,y:597,t:1527876789107};\\\", \\\"{x:468,y:598,t:1527876789124};\\\", \\\"{x:470,y:598,t:1527876789140};\\\", \\\"{x:471,y:599,t:1527876789216};\\\", \\\"{x:470,y:600,t:1527876789224};\\\", \\\"{x:465,y:603,t:1527876789240};\\\", \\\"{x:458,y:606,t:1527876789257};\\\", \\\"{x:446,y:611,t:1527876789275};\\\", \\\"{x:433,y:614,t:1527876789291};\\\", \\\"{x:414,y:616,t:1527876789306};\\\", \\\"{x:396,y:620,t:1527876789324};\\\", \\\"{x:382,y:624,t:1527876789340};\\\", \\\"{x:373,y:629,t:1527876789357};\\\", \\\"{x:368,y:629,t:1527876789373};\\\", \\\"{x:365,y:630,t:1527876789391};\\\", \\\"{x:364,y:632,t:1527876789407};\\\", \\\"{x:363,y:632,t:1527876789423};\\\", \\\"{x:363,y:633,t:1527876789479};\\\", \\\"{x:363,y:634,t:1527876789552};\\\", \\\"{x:364,y:635,t:1527876789568};\\\", \\\"{x:366,y:635,t:1527876789584};\\\", \\\"{x:367,y:635,t:1527876789601};\\\", \\\"{x:368,y:635,t:1527876789616};\\\", \\\"{x:369,y:635,t:1527876789672};\\\", \\\"{x:371,y:635,t:1527876789688};\\\", \\\"{x:373,y:635,t:1527876789696};\\\", \\\"{x:375,y:635,t:1527876789709};\\\", \\\"{x:377,y:635,t:1527876789723};\\\", \\\"{x:378,y:635,t:1527876789741};\\\", \\\"{x:382,y:635,t:1527876790079};\\\", \\\"{x:389,y:635,t:1527876790090};\\\", \\\"{x:410,y:636,t:1527876790107};\\\", \\\"{x:428,y:640,t:1527876790125};\\\", \\\"{x:450,y:642,t:1527876790141};\\\", \\\"{x:469,y:646,t:1527876790158};\\\", \\\"{x:481,y:649,t:1527876790175};\\\", \\\"{x:488,y:658,t:1527876790192};\\\", \\\"{x:489,y:660,t:1527876790208};\\\", \\\"{x:493,y:663,t:1527876790225};\\\", \\\"{x:496,y:668,t:1527876790240};\\\", \\\"{x:499,y:672,t:1527876790259};\\\", \\\"{x:500,y:674,t:1527876790275};\\\", \\\"{x:501,y:674,t:1527876790292};\\\", \\\"{x:503,y:677,t:1527876790307};\\\", \\\"{x:503,y:678,t:1527876790325};\\\", \\\"{x:505,y:678,t:1527876790344};\\\", \\\"{x:506,y:678,t:1527876790358};\\\", \\\"{x:507,y:682,t:1527876790375};\\\", \\\"{x:509,y:688,t:1527876790393};\\\", \\\"{x:509,y:691,t:1527876790407};\\\", \\\"{x:510,y:692,t:1527876790425};\\\", \\\"{x:511,y:693,t:1527876790504};\\\", \\\"{x:511,y:695,t:1527876790519};\\\", \\\"{x:511,y:696,t:1527876790544};\\\", \\\"{x:511,y:697,t:1527876790558};\\\", \\\"{x:511,y:698,t:1527876790574};\\\", \\\"{x:512,y:698,t:1527876792097};\\\", \\\"{x:515,y:698,t:1527876792109};\\\", \\\"{x:520,y:698,t:1527876792127};\\\", \\\"{x:524,y:701,t:1527876792143};\\\", \\\"{x:528,y:702,t:1527876792160};\\\", \\\"{x:534,y:705,t:1527876792177};\\\", \\\"{x:546,y:707,t:1527876792193};\\\", \\\"{x:572,y:709,t:1527876792210};\\\", \\\"{x:615,y:694,t:1527876792226};\\\", \\\"{x:639,y:681,t:1527876792244};\\\", \\\"{x:657,y:675,t:1527876792260};\\\", \\\"{x:680,y:672,t:1527876792276};\\\", \\\"{x:740,y:672,t:1527876792293};\\\", \\\"{x:839,y:672,t:1527876792310};\\\", \\\"{x:951,y:666,t:1527876792327};\\\", \\\"{x:1082,y:647,t:1527876792343};\\\", \\\"{x:1288,y:617,t:1527876792359};\\\", \\\"{x:1448,y:597,t:1527876792376};\\\", \\\"{x:1600,y:575,t:1527876792393};\\\", \\\"{x:1734,y:550,t:1527876792410};\\\", \\\"{x:1828,y:522,t:1527876792426};\\\", \\\"{x:1874,y:507,t:1527876792443};\\\", \\\"{x:1899,y:498,t:1527876792460};\\\", \\\"{x:1906,y:495,t:1527876792477};\\\", \\\"{x:1907,y:494,t:1527876792493};\\\", \\\"{x:1907,y:492,t:1527876792561};\\\", \\\"{x:1901,y:480,t:1527876792577};\\\", \\\"{x:1891,y:473,t:1527876792593};\\\", \\\"{x:1883,y:468,t:1527876792610};\\\", \\\"{x:1879,y:466,t:1527876792628};\\\", \\\"{x:1876,y:466,t:1527876792643};\\\", \\\"{x:1867,y:464,t:1527876792660};\\\", \\\"{x:1855,y:463,t:1527876792677};\\\", \\\"{x:1831,y:460,t:1527876792694};\\\", \\\"{x:1800,y:460,t:1527876792710};\\\", \\\"{x:1752,y:460,t:1527876792727};\\\", \\\"{x:1673,y:468,t:1527876792744};\\\", \\\"{x:1612,y:476,t:1527876792760};\\\", \\\"{x:1543,y:485,t:1527876792777};\\\", \\\"{x:1462,y:496,t:1527876792795};\\\", \\\"{x:1361,y:514,t:1527876792811};\\\", \\\"{x:1246,y:543,t:1527876792827};\\\", \\\"{x:1140,y:575,t:1527876792844};\\\", \\\"{x:1035,y:620,t:1527876792860};\\\", \\\"{x:955,y:656,t:1527876792877};\\\", \\\"{x:889,y:683,t:1527876792894};\\\", \\\"{x:852,y:703,t:1527876792910};\\\", \\\"{x:830,y:721,t:1527876792928};\\\", \\\"{x:816,y:742,t:1527876792944};\\\", \\\"{x:811,y:758,t:1527876792960};\\\", \\\"{x:804,y:775,t:1527876792978};\\\", \\\"{x:796,y:793,t:1527876792994};\\\", \\\"{x:785,y:818,t:1527876793010};\\\", \\\"{x:780,y:840,t:1527876793027};\\\", \\\"{x:773,y:863,t:1527876793045};\\\", \\\"{x:763,y:887,t:1527876793060};\\\", \\\"{x:752,y:907,t:1527876793077};\\\", \\\"{x:744,y:918,t:1527876793094};\\\", \\\"{x:741,y:922,t:1527876793110};\\\", \\\"{x:739,y:923,t:1527876793127};\\\", \\\"{x:732,y:926,t:1527876793144};\\\", \\\"{x:725,y:926,t:1527876793161};\\\", \\\"{x:718,y:925,t:1527876793177};\\\", \\\"{x:702,y:918,t:1527876793195};\\\", \\\"{x:690,y:908,t:1527876793211};\\\", \\\"{x:680,y:898,t:1527876793227};\\\", \\\"{x:671,y:888,t:1527876793245};\\\", \\\"{x:655,y:868,t:1527876793261};\\\", \\\"{x:634,y:842,t:1527876793278};\\\", \\\"{x:618,y:820,t:1527876793294};\\\", \\\"{x:610,y:810,t:1527876793311};\\\", \\\"{x:605,y:800,t:1527876793327};\\\", \\\"{x:600,y:789,t:1527876793344};\\\", \\\"{x:599,y:786,t:1527876793361};\\\", \\\"{x:594,y:782,t:1527876793377};\\\", \\\"{x:591,y:782,t:1527876793488};\\\", \\\"{x:590,y:782,t:1527876793497};\\\", \\\"{x:588,y:782,t:1527876793512};\\\", \\\"{x:580,y:782,t:1527876793528};\\\", \\\"{x:574,y:783,t:1527876793544};\\\", \\\"{x:561,y:783,t:1527876793561};\\\", \\\"{x:557,y:783,t:1527876793579};\\\", \\\"{x:552,y:782,t:1527876793594};\\\", \\\"{x:549,y:781,t:1527876793611};\\\", \\\"{x:546,y:778,t:1527876793628};\\\", \\\"{x:545,y:776,t:1527876793644};\\\", \\\"{x:542,y:772,t:1527876793661};\\\", \\\"{x:541,y:770,t:1527876793679};\\\", \\\"{x:541,y:768,t:1527876793693};\\\", \\\"{x:541,y:767,t:1527876793710};\\\", \\\"{x:544,y:762,t:1527876793727};\\\", \\\"{x:544,y:760,t:1527876793744};\\\", \\\"{x:545,y:759,t:1527876793761};\\\", \\\"{x:546,y:758,t:1527876793857};\\\" ] }, { \\\"rt\\\": 25056, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 410851, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -K -A -C -F -C -C -C -C -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:550,y:758,t:1527876799225};\\\", \\\"{x:572,y:759,t:1527876799242};\\\", \\\"{x:585,y:759,t:1527876799250};\\\", \\\"{x:610,y:763,t:1527876799266};\\\", \\\"{x:630,y:765,t:1527876799280};\\\", \\\"{x:645,y:768,t:1527876799297};\\\", \\\"{x:651,y:769,t:1527876799314};\\\", \\\"{x:663,y:771,t:1527876799330};\\\", \\\"{x:672,y:771,t:1527876799347};\\\", \\\"{x:683,y:771,t:1527876799364};\\\", \\\"{x:701,y:773,t:1527876799380};\\\", \\\"{x:727,y:773,t:1527876799397};\\\", \\\"{x:761,y:775,t:1527876799415};\\\", \\\"{x:791,y:775,t:1527876799430};\\\", \\\"{x:811,y:775,t:1527876799448};\\\", \\\"{x:825,y:775,t:1527876799464};\\\", \\\"{x:834,y:775,t:1527876804448};\\\", \\\"{x:855,y:775,t:1527876804455};\\\", \\\"{x:889,y:778,t:1527876804466};\\\", \\\"{x:954,y:780,t:1527876804482};\\\", \\\"{x:1023,y:780,t:1527876804500};\\\", \\\"{x:1104,y:780,t:1527876804515};\\\", \\\"{x:1173,y:780,t:1527876804533};\\\", \\\"{x:1227,y:780,t:1527876804550};\\\", \\\"{x:1258,y:780,t:1527876804566};\\\", \\\"{x:1291,y:777,t:1527876804583};\\\", \\\"{x:1339,y:770,t:1527876804599};\\\", \\\"{x:1364,y:765,t:1527876804615};\\\", \\\"{x:1384,y:759,t:1527876804635};\\\", \\\"{x:1405,y:753,t:1527876804650};\\\", \\\"{x:1424,y:748,t:1527876804665};\\\", \\\"{x:1442,y:740,t:1527876804687};\\\", \\\"{x:1454,y:734,t:1527876804704};\\\", \\\"{x:1460,y:730,t:1527876804719};\\\", \\\"{x:1461,y:729,t:1527876804737};\\\", \\\"{x:1462,y:727,t:1527876804768};\\\", \\\"{x:1463,y:725,t:1527876804775};\\\", \\\"{x:1464,y:723,t:1527876804786};\\\", \\\"{x:1470,y:713,t:1527876804803};\\\", \\\"{x:1484,y:690,t:1527876804821};\\\", \\\"{x:1496,y:669,t:1527876804837};\\\", \\\"{x:1503,y:660,t:1527876804854};\\\", \\\"{x:1507,y:652,t:1527876804870};\\\", \\\"{x:1508,y:649,t:1527876804886};\\\", \\\"{x:1509,y:644,t:1527876804903};\\\", \\\"{x:1511,y:639,t:1527876804920};\\\", \\\"{x:1512,y:635,t:1527876804937};\\\", \\\"{x:1513,y:629,t:1527876804954};\\\", \\\"{x:1515,y:625,t:1527876804971};\\\", \\\"{x:1520,y:614,t:1527876804988};\\\", \\\"{x:1525,y:605,t:1527876805004};\\\", \\\"{x:1529,y:593,t:1527876805021};\\\", \\\"{x:1533,y:583,t:1527876805037};\\\", \\\"{x:1537,y:575,t:1527876805054};\\\", \\\"{x:1538,y:569,t:1527876805070};\\\", \\\"{x:1540,y:565,t:1527876805086};\\\", \\\"{x:1543,y:560,t:1527876805103};\\\", \\\"{x:1547,y:555,t:1527876805121};\\\", \\\"{x:1547,y:551,t:1527876805137};\\\", \\\"{x:1550,y:548,t:1527876805154};\\\", \\\"{x:1550,y:546,t:1527876805171};\\\", \\\"{x:1551,y:544,t:1527876805187};\\\", \\\"{x:1552,y:540,t:1527876805203};\\\", \\\"{x:1554,y:537,t:1527876805220};\\\", \\\"{x:1555,y:533,t:1527876805236};\\\", \\\"{x:1557,y:528,t:1527876805253};\\\", \\\"{x:1559,y:523,t:1527876805270};\\\", \\\"{x:1562,y:518,t:1527876805286};\\\", \\\"{x:1564,y:513,t:1527876805303};\\\", \\\"{x:1566,y:510,t:1527876805320};\\\", \\\"{x:1567,y:508,t:1527876805337};\\\", \\\"{x:1569,y:504,t:1527876805354};\\\", \\\"{x:1572,y:501,t:1527876805370};\\\", \\\"{x:1574,y:499,t:1527876805386};\\\", \\\"{x:1576,y:496,t:1527876805404};\\\", \\\"{x:1580,y:492,t:1527876805420};\\\", \\\"{x:1582,y:489,t:1527876805437};\\\", \\\"{x:1582,y:488,t:1527876805512};\\\", \\\"{x:1582,y:487,t:1527876805528};\\\", \\\"{x:1579,y:485,t:1527876805537};\\\", \\\"{x:1570,y:484,t:1527876805554};\\\", \\\"{x:1562,y:483,t:1527876805571};\\\", \\\"{x:1553,y:481,t:1527876805588};\\\", \\\"{x:1544,y:480,t:1527876805604};\\\", \\\"{x:1536,y:480,t:1527876805621};\\\", \\\"{x:1527,y:480,t:1527876805638};\\\", \\\"{x:1516,y:480,t:1527876805654};\\\", \\\"{x:1502,y:479,t:1527876805670};\\\", \\\"{x:1475,y:479,t:1527876805688};\\\", \\\"{x:1455,y:479,t:1527876805704};\\\", \\\"{x:1438,y:479,t:1527876805720};\\\", \\\"{x:1424,y:479,t:1527876805737};\\\", \\\"{x:1415,y:479,t:1527876805754};\\\", \\\"{x:1411,y:479,t:1527876805771};\\\", \\\"{x:1409,y:479,t:1527876805788};\\\", \\\"{x:1409,y:478,t:1527876805928};\\\", \\\"{x:1409,y:477,t:1527876805952};\\\", \\\"{x:1409,y:476,t:1527876805968};\\\", \\\"{x:1410,y:476,t:1527876806183};\\\", \\\"{x:1410,y:477,t:1527876806191};\\\", \\\"{x:1410,y:479,t:1527876806205};\\\", \\\"{x:1410,y:483,t:1527876806220};\\\", \\\"{x:1410,y:484,t:1527876806239};\\\", \\\"{x:1410,y:485,t:1527876806254};\\\", \\\"{x:1410,y:487,t:1527876806271};\\\", \\\"{x:1410,y:489,t:1527876806287};\\\", \\\"{x:1408,y:494,t:1527876806305};\\\", \\\"{x:1407,y:499,t:1527876806320};\\\", \\\"{x:1405,y:505,t:1527876806338};\\\", \\\"{x:1403,y:510,t:1527876806355};\\\", \\\"{x:1401,y:518,t:1527876806371};\\\", \\\"{x:1399,y:526,t:1527876806387};\\\", \\\"{x:1397,y:532,t:1527876806405};\\\", \\\"{x:1395,y:536,t:1527876806422};\\\", \\\"{x:1395,y:538,t:1527876806472};\\\", \\\"{x:1395,y:546,t:1527876806487};\\\", \\\"{x:1395,y:556,t:1527876806504};\\\", \\\"{x:1395,y:569,t:1527876806522};\\\", \\\"{x:1395,y:580,t:1527876806538};\\\", \\\"{x:1396,y:590,t:1527876806554};\\\", \\\"{x:1399,y:602,t:1527876806571};\\\", \\\"{x:1404,y:613,t:1527876806588};\\\", \\\"{x:1414,y:631,t:1527876806605};\\\", \\\"{x:1425,y:651,t:1527876806621};\\\", \\\"{x:1441,y:672,t:1527876806638};\\\", \\\"{x:1455,y:692,t:1527876806655};\\\", \\\"{x:1477,y:717,t:1527876806671};\\\", \\\"{x:1496,y:732,t:1527876806687};\\\", \\\"{x:1510,y:741,t:1527876806705};\\\", \\\"{x:1526,y:751,t:1527876806721};\\\", \\\"{x:1542,y:760,t:1527876806737};\\\", \\\"{x:1557,y:767,t:1527876806755};\\\", \\\"{x:1573,y:774,t:1527876806771};\\\", \\\"{x:1588,y:780,t:1527876806787};\\\", \\\"{x:1600,y:788,t:1527876806804};\\\", \\\"{x:1610,y:791,t:1527876806822};\\\", \\\"{x:1618,y:794,t:1527876806838};\\\", \\\"{x:1625,y:797,t:1527876806854};\\\", \\\"{x:1628,y:798,t:1527876806871};\\\", \\\"{x:1628,y:794,t:1527876806983};\\\", \\\"{x:1626,y:785,t:1527876806992};\\\", \\\"{x:1622,y:778,t:1527876807005};\\\", \\\"{x:1613,y:759,t:1527876807022};\\\", \\\"{x:1601,y:740,t:1527876807039};\\\", \\\"{x:1587,y:721,t:1527876807054};\\\", \\\"{x:1560,y:692,t:1527876807072};\\\", \\\"{x:1541,y:678,t:1527876807088};\\\", \\\"{x:1520,y:663,t:1527876807105};\\\", \\\"{x:1503,y:651,t:1527876807121};\\\", \\\"{x:1489,y:641,t:1527876807138};\\\", \\\"{x:1478,y:633,t:1527876807155};\\\", \\\"{x:1469,y:627,t:1527876807171};\\\", \\\"{x:1464,y:623,t:1527876807189};\\\", \\\"{x:1456,y:619,t:1527876807205};\\\", \\\"{x:1446,y:613,t:1527876807222};\\\", \\\"{x:1440,y:609,t:1527876807238};\\\", \\\"{x:1435,y:605,t:1527876807254};\\\", \\\"{x:1428,y:602,t:1527876807272};\\\", \\\"{x:1422,y:601,t:1527876807289};\\\", \\\"{x:1416,y:600,t:1527876807305};\\\", \\\"{x:1408,y:598,t:1527876807322};\\\", \\\"{x:1401,y:597,t:1527876807339};\\\", \\\"{x:1393,y:595,t:1527876807355};\\\", \\\"{x:1388,y:594,t:1527876807371};\\\", \\\"{x:1383,y:594,t:1527876807389};\\\", \\\"{x:1382,y:594,t:1527876807404};\\\", \\\"{x:1379,y:594,t:1527876807422};\\\", \\\"{x:1376,y:594,t:1527876807439};\\\", \\\"{x:1374,y:594,t:1527876807455};\\\", \\\"{x:1373,y:595,t:1527876807472};\\\", \\\"{x:1369,y:596,t:1527876807489};\\\", \\\"{x:1367,y:597,t:1527876807504};\\\", \\\"{x:1363,y:600,t:1527876807522};\\\", \\\"{x:1358,y:604,t:1527876807539};\\\", \\\"{x:1353,y:612,t:1527876807556};\\\", \\\"{x:1346,y:619,t:1527876807571};\\\", \\\"{x:1340,y:626,t:1527876807589};\\\", \\\"{x:1331,y:638,t:1527876807606};\\\", \\\"{x:1325,y:647,t:1527876807622};\\\", \\\"{x:1319,y:658,t:1527876807639};\\\", \\\"{x:1310,y:676,t:1527876807655};\\\", \\\"{x:1305,y:688,t:1527876807672};\\\", \\\"{x:1301,y:701,t:1527876807689};\\\", \\\"{x:1299,y:713,t:1527876807706};\\\", \\\"{x:1299,y:728,t:1527876807722};\\\", \\\"{x:1298,y:742,t:1527876807739};\\\", \\\"{x:1298,y:751,t:1527876807756};\\\", \\\"{x:1298,y:764,t:1527876807772};\\\", \\\"{x:1298,y:772,t:1527876807789};\\\", \\\"{x:1298,y:781,t:1527876807805};\\\", \\\"{x:1298,y:791,t:1527876807822};\\\", \\\"{x:1298,y:799,t:1527876807838};\\\", \\\"{x:1298,y:810,t:1527876807856};\\\", \\\"{x:1297,y:816,t:1527876807871};\\\", \\\"{x:1296,y:821,t:1527876807888};\\\", \\\"{x:1292,y:826,t:1527876807906};\\\", \\\"{x:1287,y:831,t:1527876807922};\\\", \\\"{x:1279,y:833,t:1527876807940};\\\", \\\"{x:1271,y:836,t:1527876807957};\\\", \\\"{x:1260,y:840,t:1527876807972};\\\", \\\"{x:1248,y:842,t:1527876807989};\\\", \\\"{x:1233,y:845,t:1527876808005};\\\", \\\"{x:1213,y:847,t:1527876808023};\\\", \\\"{x:1193,y:851,t:1527876808039};\\\", \\\"{x:1186,y:851,t:1527876808056};\\\", \\\"{x:1184,y:851,t:1527876808073};\\\", \\\"{x:1183,y:851,t:1527876808103};\\\", \\\"{x:1183,y:850,t:1527876808152};\\\", \\\"{x:1185,y:849,t:1527876808160};\\\", \\\"{x:1189,y:846,t:1527876808172};\\\", \\\"{x:1195,y:842,t:1527876808189};\\\", \\\"{x:1204,y:838,t:1527876808207};\\\", \\\"{x:1212,y:833,t:1527876808223};\\\", \\\"{x:1217,y:830,t:1527876808239};\\\", \\\"{x:1219,y:830,t:1527876808257};\\\", \\\"{x:1219,y:829,t:1527876808272};\\\", \\\"{x:1222,y:831,t:1527876809680};\\\", \\\"{x:1228,y:835,t:1527876809693};\\\", \\\"{x:1244,y:842,t:1527876809708};\\\", \\\"{x:1262,y:845,t:1527876809723};\\\", \\\"{x:1288,y:846,t:1527876809741};\\\", \\\"{x:1310,y:846,t:1527876809757};\\\", \\\"{x:1326,y:846,t:1527876809774};\\\", \\\"{x:1339,y:846,t:1527876809791};\\\", \\\"{x:1354,y:844,t:1527876809807};\\\", \\\"{x:1359,y:843,t:1527876809824};\\\", \\\"{x:1365,y:841,t:1527876809841};\\\", \\\"{x:1371,y:838,t:1527876809858};\\\", \\\"{x:1374,y:836,t:1527876809873};\\\", \\\"{x:1377,y:832,t:1527876809891};\\\", \\\"{x:1378,y:829,t:1527876809908};\\\", \\\"{x:1380,y:824,t:1527876809923};\\\", \\\"{x:1381,y:817,t:1527876809941};\\\", \\\"{x:1382,y:810,t:1527876809958};\\\", \\\"{x:1383,y:803,t:1527876809974};\\\", \\\"{x:1383,y:797,t:1527876809991};\\\", \\\"{x:1383,y:790,t:1527876810008};\\\", \\\"{x:1383,y:787,t:1527876810024};\\\", \\\"{x:1383,y:784,t:1527876810041};\\\", \\\"{x:1383,y:780,t:1527876810058};\\\", \\\"{x:1383,y:774,t:1527876810074};\\\", \\\"{x:1382,y:768,t:1527876810092};\\\", \\\"{x:1381,y:765,t:1527876810107};\\\", \\\"{x:1381,y:764,t:1527876810207};\\\", \\\"{x:1378,y:764,t:1527876812255};\\\", \\\"{x:1373,y:766,t:1527876812264};\\\", \\\"{x:1364,y:768,t:1527876812275};\\\", \\\"{x:1341,y:772,t:1527876812292};\\\", \\\"{x:1310,y:777,t:1527876812309};\\\", \\\"{x:1276,y:782,t:1527876812326};\\\", \\\"{x:1247,y:786,t:1527876812343};\\\", \\\"{x:1204,y:788,t:1527876812359};\\\", \\\"{x:1162,y:788,t:1527876812376};\\\", \\\"{x:1115,y:785,t:1527876812393};\\\", \\\"{x:1078,y:782,t:1527876812410};\\\", \\\"{x:1044,y:778,t:1527876812426};\\\", \\\"{x:1013,y:775,t:1527876812443};\\\", \\\"{x:994,y:774,t:1527876812460};\\\", \\\"{x:975,y:772,t:1527876812475};\\\", \\\"{x:957,y:769,t:1527876812493};\\\", \\\"{x:939,y:767,t:1527876812510};\\\", \\\"{x:916,y:759,t:1527876812527};\\\", \\\"{x:894,y:754,t:1527876812543};\\\", \\\"{x:858,y:745,t:1527876812559};\\\", \\\"{x:830,y:742,t:1527876812576};\\\", \\\"{x:800,y:742,t:1527876812592};\\\", \\\"{x:764,y:742,t:1527876812610};\\\", \\\"{x:739,y:738,t:1527876812627};\\\", \\\"{x:712,y:734,t:1527876812643};\\\", \\\"{x:693,y:729,t:1527876812660};\\\", \\\"{x:673,y:722,t:1527876812677};\\\", \\\"{x:664,y:719,t:1527876812693};\\\", \\\"{x:657,y:718,t:1527876812710};\\\", \\\"{x:651,y:715,t:1527876812726};\\\", \\\"{x:646,y:711,t:1527876812743};\\\", \\\"{x:631,y:695,t:1527876812760};\\\", \\\"{x:622,y:680,t:1527876812777};\\\", \\\"{x:608,y:662,t:1527876812793};\\\", \\\"{x:594,y:644,t:1527876812810};\\\", \\\"{x:572,y:630,t:1527876812827};\\\", \\\"{x:555,y:619,t:1527876812843};\\\", \\\"{x:537,y:611,t:1527876812860};\\\", \\\"{x:520,y:603,t:1527876812877};\\\", \\\"{x:499,y:591,t:1527876812893};\\\", \\\"{x:486,y:585,t:1527876812910};\\\", \\\"{x:479,y:581,t:1527876812927};\\\", \\\"{x:470,y:577,t:1527876812943};\\\", \\\"{x:460,y:576,t:1527876812960};\\\", \\\"{x:456,y:574,t:1527876812976};\\\", \\\"{x:450,y:573,t:1527876812994};\\\", \\\"{x:447,y:573,t:1527876813010};\\\", \\\"{x:445,y:573,t:1527876813064};\\\", \\\"{x:442,y:573,t:1527876813077};\\\", \\\"{x:437,y:574,t:1527876813094};\\\", \\\"{x:430,y:578,t:1527876813109};\\\", \\\"{x:424,y:582,t:1527876813127};\\\", \\\"{x:418,y:586,t:1527876813143};\\\", \\\"{x:415,y:588,t:1527876813160};\\\", \\\"{x:409,y:592,t:1527876813177};\\\", \\\"{x:403,y:596,t:1527876813193};\\\", \\\"{x:394,y:600,t:1527876813210};\\\", \\\"{x:388,y:604,t:1527876813227};\\\", \\\"{x:383,y:606,t:1527876813244};\\\", \\\"{x:382,y:607,t:1527876813260};\\\", \\\"{x:381,y:608,t:1527876813276};\\\", \\\"{x:383,y:607,t:1527876813376};\\\", \\\"{x:385,y:606,t:1527876813391};\\\", \\\"{x:386,y:606,t:1527876813399};\\\", \\\"{x:387,y:605,t:1527876813410};\\\", \\\"{x:390,y:605,t:1527876813427};\\\", \\\"{x:391,y:603,t:1527876813444};\\\", \\\"{x:393,y:603,t:1527876813461};\\\", \\\"{x:395,y:603,t:1527876813477};\\\", \\\"{x:396,y:602,t:1527876813494};\\\", \\\"{x:397,y:601,t:1527876813511};\\\", \\\"{x:398,y:601,t:1527876813527};\\\", \\\"{x:399,y:600,t:1527876813808};\\\", \\\"{x:400,y:600,t:1527876814095};\\\", \\\"{x:402,y:601,t:1527876814111};\\\", \\\"{x:409,y:605,t:1527876814127};\\\", \\\"{x:421,y:616,t:1527876814144};\\\", \\\"{x:431,y:631,t:1527876814162};\\\", \\\"{x:442,y:647,t:1527876814178};\\\", \\\"{x:449,y:663,t:1527876814195};\\\", \\\"{x:459,y:679,t:1527876814211};\\\", \\\"{x:471,y:695,t:1527876814228};\\\", \\\"{x:482,y:710,t:1527876814245};\\\", \\\"{x:491,y:724,t:1527876814261};\\\", \\\"{x:503,y:740,t:1527876814278};\\\", \\\"{x:513,y:755,t:1527876814294};\\\", \\\"{x:516,y:762,t:1527876814311};\\\", \\\"{x:518,y:767,t:1527876814327};\\\", \\\"{x:518,y:770,t:1527876814345};\\\", \\\"{x:518,y:771,t:1527876814361};\\\", \\\"{x:518,y:772,t:1527876814392};\\\", \\\"{x:518,y:773,t:1527876814407};\\\", \\\"{x:518,y:774,t:1527876814432};\\\", \\\"{x:518,y:775,t:1527876814445};\\\", \\\"{x:516,y:775,t:1527876814461};\\\", \\\"{x:515,y:776,t:1527876814478};\\\", \\\"{x:514,y:776,t:1527876814495};\\\", \\\"{x:515,y:774,t:1527876814687};\\\", \\\"{x:516,y:771,t:1527876814696};\\\", \\\"{x:522,y:764,t:1527876814711};\\\", \\\"{x:529,y:757,t:1527876814728};\\\", \\\"{x:538,y:750,t:1527876814745};\\\", \\\"{x:545,y:748,t:1527876814761};\\\", \\\"{x:556,y:742,t:1527876814778};\\\", \\\"{x:569,y:735,t:1527876814796};\\\", \\\"{x:593,y:729,t:1527876814811};\\\", \\\"{x:632,y:724,t:1527876814828};\\\", \\\"{x:714,y:720,t:1527876814845};\\\", \\\"{x:800,y:718,t:1527876814862};\\\", \\\"{x:903,y:718,t:1527876814878};\\\", \\\"{x:1002,y:718,t:1527876814895};\\\", \\\"{x:1160,y:718,t:1527876814912};\\\", \\\"{x:1271,y:729,t:1527876814928};\\\", \\\"{x:1373,y:739,t:1527876814945};\\\", \\\"{x:1428,y:747,t:1527876814962};\\\", \\\"{x:1457,y:751,t:1527876814978};\\\", \\\"{x:1474,y:754,t:1527876814995};\\\", \\\"{x:1482,y:756,t:1527876815011};\\\", \\\"{x:1483,y:757,t:1527876815028};\\\", \\\"{x:1484,y:757,t:1527876815045};\\\", \\\"{x:1484,y:758,t:1527876815127};\\\", \\\"{x:1482,y:760,t:1527876815145};\\\", \\\"{x:1473,y:763,t:1527876815162};\\\", \\\"{x:1463,y:768,t:1527876815179};\\\", \\\"{x:1450,y:777,t:1527876815195};\\\", \\\"{x:1433,y:787,t:1527876815212};\\\", \\\"{x:1416,y:795,t:1527876815228};\\\", \\\"{x:1394,y:810,t:1527876815245};\\\", \\\"{x:1370,y:824,t:1527876815262};\\\", \\\"{x:1348,y:831,t:1527876815279};\\\", \\\"{x:1320,y:838,t:1527876815295};\\\", \\\"{x:1293,y:848,t:1527876815312};\\\", \\\"{x:1281,y:854,t:1527876815329};\\\", \\\"{x:1274,y:859,t:1527876815345};\\\", \\\"{x:1269,y:861,t:1527876815362};\\\", \\\"{x:1267,y:863,t:1527876815379};\\\", \\\"{x:1263,y:865,t:1527876815395};\\\", \\\"{x:1261,y:866,t:1527876815412};\\\", \\\"{x:1259,y:866,t:1527876815429};\\\", \\\"{x:1258,y:866,t:1527876815456};\\\", \\\"{x:1257,y:866,t:1527876815497};\\\", \\\"{x:1256,y:865,t:1527876815512};\\\", \\\"{x:1252,y:861,t:1527876815530};\\\", \\\"{x:1248,y:859,t:1527876815546};\\\", \\\"{x:1232,y:853,t:1527876815563};\\\", \\\"{x:1223,y:850,t:1527876815579};\\\", \\\"{x:1219,y:848,t:1527876815595};\\\", \\\"{x:1217,y:848,t:1527876815613};\\\", \\\"{x:1216,y:848,t:1527876815629};\\\", \\\"{x:1214,y:847,t:1527876815646};\\\", \\\"{x:1214,y:846,t:1527876815662};\\\", \\\"{x:1212,y:844,t:1527876815679};\\\", \\\"{x:1212,y:840,t:1527876815696};\\\", \\\"{x:1209,y:837,t:1527876815712};\\\", \\\"{x:1208,y:835,t:1527876815729};\\\", \\\"{x:1205,y:833,t:1527876815747};\\\", \\\"{x:1204,y:831,t:1527876815762};\\\", \\\"{x:1204,y:830,t:1527876815799};\\\", \\\"{x:1204,y:828,t:1527876815812};\\\", \\\"{x:1204,y:827,t:1527876815840};\\\", \\\"{x:1204,y:826,t:1527876815864};\\\", \\\"{x:1204,y:824,t:1527876815880};\\\", \\\"{x:1207,y:822,t:1527876815896};\\\", \\\"{x:1208,y:821,t:1527876815912};\\\", \\\"{x:1209,y:821,t:1527876815930};\\\", \\\"{x:1213,y:819,t:1527876815947};\\\", \\\"{x:1215,y:818,t:1527876815963};\\\", \\\"{x:1216,y:817,t:1527876815979};\\\", \\\"{x:1217,y:817,t:1527876816057};\\\", \\\"{x:1216,y:818,t:1527876816145};\\\", \\\"{x:1215,y:818,t:1527876816168};\\\", \\\"{x:1214,y:819,t:1527876816179};\\\", \\\"{x:1213,y:819,t:1527876816217};\\\", \\\"{x:1213,y:820,t:1527876816230};\\\", \\\"{x:1212,y:826,t:1527876816250};\\\", \\\"{x:1210,y:830,t:1527876816263};\\\", \\\"{x:1209,y:837,t:1527876816296};\\\", \\\"{x:1209,y:838,t:1527876816384};\\\", \\\"{x:1210,y:838,t:1527876816569};\\\", \\\"{x:1210,y:837,t:1527876816584};\\\", \\\"{x:1211,y:836,t:1527876816625};\\\", \\\"{x:1212,y:835,t:1527876816668};\\\", \\\"{x:1213,y:834,t:1527876816680};\\\", \\\"{x:1215,y:830,t:1527876816696};\\\", \\\"{x:1216,y:828,t:1527876816713};\\\", \\\"{x:1216,y:827,t:1527876816730};\\\", \\\"{x:1217,y:825,t:1527876816746};\\\", \\\"{x:1217,y:824,t:1527876817154};\\\", \\\"{x:1218,y:823,t:1527876817164};\\\", \\\"{x:1222,y:822,t:1527876817180};\\\", \\\"{x:1225,y:820,t:1527876817198};\\\", \\\"{x:1230,y:819,t:1527876817213};\\\", \\\"{x:1245,y:818,t:1527876817231};\\\", \\\"{x:1258,y:818,t:1527876817247};\\\", \\\"{x:1269,y:816,t:1527876817263};\\\", \\\"{x:1288,y:814,t:1527876817281};\\\", \\\"{x:1306,y:814,t:1527876817297};\\\", \\\"{x:1319,y:811,t:1527876817313};\\\", \\\"{x:1328,y:810,t:1527876817330};\\\", \\\"{x:1336,y:807,t:1527876817347};\\\", \\\"{x:1338,y:806,t:1527876817365};\\\", \\\"{x:1340,y:804,t:1527876817381};\\\", \\\"{x:1342,y:803,t:1527876817397};\\\", \\\"{x:1346,y:801,t:1527876817414};\\\", \\\"{x:1348,y:800,t:1527876817430};\\\", \\\"{x:1351,y:798,t:1527876817447};\\\", \\\"{x:1357,y:793,t:1527876817464};\\\", \\\"{x:1361,y:790,t:1527876817481};\\\", \\\"{x:1363,y:786,t:1527876817497};\\\", \\\"{x:1365,y:784,t:1527876817514};\\\", \\\"{x:1366,y:783,t:1527876817531};\\\", \\\"{x:1367,y:782,t:1527876817548};\\\", \\\"{x:1369,y:779,t:1527876817564};\\\", \\\"{x:1370,y:778,t:1527876817581};\\\", \\\"{x:1372,y:776,t:1527876817597};\\\", \\\"{x:1373,y:775,t:1527876817615};\\\", \\\"{x:1374,y:775,t:1527876817631};\\\", \\\"{x:1374,y:773,t:1527876817649};\\\", \\\"{x:1376,y:772,t:1527876817665};\\\", \\\"{x:1378,y:768,t:1527876817684};\\\", \\\"{x:1379,y:767,t:1527876817697};\\\", \\\"{x:1381,y:765,t:1527876817714};\\\", \\\"{x:1382,y:765,t:1527876817730};\\\", \\\"{x:1383,y:764,t:1527876817747};\\\", \\\"{x:1385,y:763,t:1527876817764};\\\", \\\"{x:1385,y:762,t:1527876817783};\\\", \\\"{x:1384,y:762,t:1527876818048};\\\", \\\"{x:1376,y:764,t:1527876818064};\\\", \\\"{x:1368,y:768,t:1527876818085};\\\", \\\"{x:1361,y:771,t:1527876818098};\\\", \\\"{x:1349,y:776,t:1527876818114};\\\", \\\"{x:1334,y:782,t:1527876818131};\\\", \\\"{x:1300,y:790,t:1527876818149};\\\", \\\"{x:1250,y:805,t:1527876818164};\\\", \\\"{x:1184,y:820,t:1527876818182};\\\", \\\"{x:1099,y:841,t:1527876818198};\\\", \\\"{x:1032,y:851,t:1527876818214};\\\", \\\"{x:958,y:858,t:1527876818231};\\\", \\\"{x:837,y:864,t:1527876818248};\\\", \\\"{x:791,y:871,t:1527876818264};\\\", \\\"{x:746,y:878,t:1527876818281};\\\", \\\"{x:713,y:882,t:1527876818299};\\\", \\\"{x:695,y:885,t:1527876818315};\\\", \\\"{x:683,y:886,t:1527876818331};\\\", \\\"{x:673,y:887,t:1527876818348};\\\", \\\"{x:666,y:890,t:1527876818365};\\\", \\\"{x:658,y:891,t:1527876818382};\\\", \\\"{x:648,y:891,t:1527876818399};\\\", \\\"{x:637,y:891,t:1527876818415};\\\", \\\"{x:626,y:891,t:1527876818432};\\\", \\\"{x:623,y:891,t:1527876818448};\\\", \\\"{x:623,y:890,t:1527876818464};\\\", \\\"{x:623,y:888,t:1527876818482};\\\", \\\"{x:621,y:887,t:1527876818504};\\\", \\\"{x:620,y:883,t:1527876818515};\\\", \\\"{x:616,y:875,t:1527876818532};\\\", \\\"{x:616,y:874,t:1527876818549};\\\", \\\"{x:616,y:873,t:1527876818565};\\\", \\\"{x:615,y:872,t:1527876818581};\\\", \\\"{x:614,y:871,t:1527876818599};\\\", \\\"{x:614,y:870,t:1527876818849};\\\", \\\"{x:614,y:869,t:1527876818865};\\\", \\\"{x:614,y:867,t:1527876818882};\\\", \\\"{x:614,y:866,t:1527876818944};\\\", \\\"{x:615,y:865,t:1527876819040};\\\", \\\"{x:617,y:864,t:1527876819056};\\\", \\\"{x:630,y:860,t:1527876819066};\\\", \\\"{x:663,y:845,t:1527876819082};\\\", \\\"{x:681,y:838,t:1527876819099};\\\", \\\"{x:693,y:834,t:1527876819116};\\\", \\\"{x:706,y:829,t:1527876819133};\\\", \\\"{x:741,y:825,t:1527876819149};\\\", \\\"{x:818,y:825,t:1527876819165};\\\", \\\"{x:919,y:826,t:1527876819183};\\\", \\\"{x:1051,y:826,t:1527876819200};\\\", \\\"{x:1195,y:826,t:1527876819215};\\\", \\\"{x:1396,y:799,t:1527876819232};\\\", \\\"{x:1540,y:776,t:1527876819248};\\\", \\\"{x:1653,y:749,t:1527876819266};\\\", \\\"{x:1695,y:738,t:1527876819283};\\\", \\\"{x:1700,y:735,t:1527876819299};\\\", \\\"{x:1701,y:732,t:1527876819316};\\\", \\\"{x:1690,y:725,t:1527876819333};\\\", \\\"{x:1660,y:710,t:1527876819349};\\\", \\\"{x:1598,y:690,t:1527876819366};\\\", \\\"{x:1496,y:668,t:1527876819383};\\\", \\\"{x:1385,y:652,t:1527876819400};\\\", \\\"{x:1256,y:644,t:1527876819416};\\\", \\\"{x:1184,y:644,t:1527876819432};\\\", \\\"{x:1103,y:644,t:1527876819449};\\\", \\\"{x:1011,y:644,t:1527876819466};\\\", \\\"{x:909,y:644,t:1527876819486};\\\", \\\"{x:820,y:644,t:1527876819499};\\\", \\\"{x:748,y:644,t:1527876819515};\\\", \\\"{x:695,y:644,t:1527876819532};\\\", \\\"{x:634,y:648,t:1527876819549};\\\", \\\"{x:579,y:656,t:1527876819565};\\\", \\\"{x:536,y:661,t:1527876819582};\\\", \\\"{x:499,y:668,t:1527876819600};\\\", \\\"{x:481,y:674,t:1527876819615};\\\", \\\"{x:462,y:682,t:1527876819632};\\\", \\\"{x:443,y:688,t:1527876819650};\\\", \\\"{x:426,y:693,t:1527876819665};\\\", \\\"{x:416,y:699,t:1527876819682};\\\", \\\"{x:414,y:701,t:1527876819699};\\\", \\\"{x:413,y:702,t:1527876819715};\\\", \\\"{x:413,y:705,t:1527876819732};\\\", \\\"{x:421,y:709,t:1527876819750};\\\", \\\"{x:428,y:712,t:1527876819766};\\\", \\\"{x:429,y:713,t:1527876819782};\\\", \\\"{x:434,y:715,t:1527876819799};\\\", \\\"{x:437,y:717,t:1527876819815};\\\", \\\"{x:450,y:725,t:1527876819832};\\\", \\\"{x:457,y:731,t:1527876819849};\\\", \\\"{x:459,y:734,t:1527876819866};\\\", \\\"{x:462,y:738,t:1527876819883};\\\", \\\"{x:466,y:743,t:1527876819899};\\\", \\\"{x:468,y:747,t:1527876819916};\\\", \\\"{x:473,y:750,t:1527876819933};\\\", \\\"{x:476,y:750,t:1527876819950};\\\", \\\"{x:480,y:753,t:1527876819967};\\\" ] }, { \\\"rt\\\": 16344, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 428414, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -H -H -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:481,y:753,t:1527876824632};\\\", \\\"{x:485,y:753,t:1527876824643};\\\", \\\"{x:498,y:758,t:1527876824657};\\\", \\\"{x:511,y:759,t:1527876824673};\\\", \\\"{x:521,y:760,t:1527876824691};\\\", \\\"{x:531,y:760,t:1527876824707};\\\", \\\"{x:544,y:763,t:1527876824724};\\\", \\\"{x:565,y:763,t:1527876824741};\\\", \\\"{x:602,y:763,t:1527876824757};\\\", \\\"{x:655,y:763,t:1527876824775};\\\", \\\"{x:705,y:763,t:1527876824787};\\\", \\\"{x:758,y:763,t:1527876824803};\\\", \\\"{x:822,y:763,t:1527876824819};\\\", \\\"{x:886,y:763,t:1527876824836};\\\", \\\"{x:936,y:763,t:1527876824853};\\\", \\\"{x:978,y:763,t:1527876824869};\\\", \\\"{x:1008,y:763,t:1527876824887};\\\", \\\"{x:1044,y:763,t:1527876824904};\\\", \\\"{x:1070,y:763,t:1527876824920};\\\", \\\"{x:1094,y:763,t:1527876824937};\\\", \\\"{x:1119,y:763,t:1527876824953};\\\", \\\"{x:1149,y:763,t:1527876824970};\\\", \\\"{x:1175,y:763,t:1527876824986};\\\", \\\"{x:1195,y:763,t:1527876825004};\\\", \\\"{x:1208,y:763,t:1527876825020};\\\", \\\"{x:1214,y:763,t:1527876825037};\\\", \\\"{x:1215,y:763,t:1527876825054};\\\", \\\"{x:1218,y:764,t:1527876825849};\\\", \\\"{x:1228,y:765,t:1527876825856};\\\", \\\"{x:1240,y:769,t:1527876825871};\\\", \\\"{x:1274,y:773,t:1527876825888};\\\", \\\"{x:1297,y:776,t:1527876825904};\\\", \\\"{x:1325,y:780,t:1527876825921};\\\", \\\"{x:1351,y:784,t:1527876825938};\\\", \\\"{x:1370,y:787,t:1527876825955};\\\", \\\"{x:1390,y:790,t:1527876825971};\\\", \\\"{x:1401,y:791,t:1527876825988};\\\", \\\"{x:1410,y:792,t:1527876826005};\\\", \\\"{x:1416,y:793,t:1527876826021};\\\", \\\"{x:1425,y:795,t:1527876826038};\\\", \\\"{x:1434,y:797,t:1527876826056};\\\", \\\"{x:1444,y:799,t:1527876826071};\\\", \\\"{x:1466,y:801,t:1527876826089};\\\", \\\"{x:1480,y:802,t:1527876826104};\\\", \\\"{x:1498,y:805,t:1527876826121};\\\", \\\"{x:1517,y:807,t:1527876826138};\\\", \\\"{x:1535,y:811,t:1527876826155};\\\", \\\"{x:1551,y:811,t:1527876826172};\\\", \\\"{x:1566,y:811,t:1527876826188};\\\", \\\"{x:1579,y:811,t:1527876826205};\\\", \\\"{x:1586,y:812,t:1527876826221};\\\", \\\"{x:1594,y:814,t:1527876826238};\\\", \\\"{x:1603,y:816,t:1527876826256};\\\", \\\"{x:1607,y:819,t:1527876826271};\\\", \\\"{x:1613,y:822,t:1527876826288};\\\", \\\"{x:1615,y:823,t:1527876826305};\\\", \\\"{x:1617,y:825,t:1527876826328};\\\", \\\"{x:1617,y:827,t:1527876826339};\\\", \\\"{x:1617,y:830,t:1527876826356};\\\", \\\"{x:1617,y:833,t:1527876826371};\\\", \\\"{x:1617,y:837,t:1527876826389};\\\", \\\"{x:1617,y:841,t:1527876826405};\\\", \\\"{x:1618,y:844,t:1527876826422};\\\", \\\"{x:1619,y:850,t:1527876826438};\\\", \\\"{x:1620,y:855,t:1527876826456};\\\", \\\"{x:1622,y:859,t:1527876826471};\\\", \\\"{x:1623,y:866,t:1527876826488};\\\", \\\"{x:1623,y:878,t:1527876826505};\\\", \\\"{x:1623,y:883,t:1527876826522};\\\", \\\"{x:1623,y:888,t:1527876826538};\\\", \\\"{x:1623,y:891,t:1527876826555};\\\", \\\"{x:1623,y:895,t:1527876826572};\\\", \\\"{x:1622,y:898,t:1527876826588};\\\", \\\"{x:1620,y:907,t:1527876826606};\\\", \\\"{x:1616,y:922,t:1527876826622};\\\", \\\"{x:1614,y:935,t:1527876826638};\\\", \\\"{x:1613,y:940,t:1527876826656};\\\", \\\"{x:1612,y:942,t:1527876826672};\\\", \\\"{x:1612,y:943,t:1527876826736};\\\", \\\"{x:1612,y:944,t:1527876826745};\\\", \\\"{x:1612,y:945,t:1527876826755};\\\", \\\"{x:1612,y:946,t:1527876826776};\\\", \\\"{x:1611,y:947,t:1527876826788};\\\", \\\"{x:1611,y:948,t:1527876826805};\\\", \\\"{x:1611,y:949,t:1527876826833};\\\", \\\"{x:1610,y:950,t:1527876826873};\\\", \\\"{x:1608,y:950,t:1527876826889};\\\", \\\"{x:1607,y:950,t:1527876826906};\\\", \\\"{x:1605,y:950,t:1527876826923};\\\", \\\"{x:1600,y:945,t:1527876826940};\\\", \\\"{x:1590,y:933,t:1527876826956};\\\", \\\"{x:1582,y:922,t:1527876826973};\\\", \\\"{x:1577,y:910,t:1527876826989};\\\", \\\"{x:1571,y:896,t:1527876827005};\\\", \\\"{x:1564,y:882,t:1527876827022};\\\", \\\"{x:1559,y:871,t:1527876827039};\\\", \\\"{x:1556,y:863,t:1527876827055};\\\", \\\"{x:1551,y:853,t:1527876827073};\\\", \\\"{x:1548,y:848,t:1527876827088};\\\", \\\"{x:1543,y:842,t:1527876827106};\\\", \\\"{x:1536,y:832,t:1527876827123};\\\", \\\"{x:1531,y:826,t:1527876827140};\\\", \\\"{x:1531,y:823,t:1527876827155};\\\", \\\"{x:1530,y:820,t:1527876827172};\\\", \\\"{x:1527,y:816,t:1527876827189};\\\", \\\"{x:1521,y:808,t:1527876827205};\\\", \\\"{x:1507,y:795,t:1527876827222};\\\", \\\"{x:1493,y:781,t:1527876827239};\\\", \\\"{x:1479,y:769,t:1527876827255};\\\", \\\"{x:1472,y:763,t:1527876827272};\\\", \\\"{x:1470,y:758,t:1527876827290};\\\", \\\"{x:1469,y:749,t:1527876827305};\\\", \\\"{x:1464,y:740,t:1527876827322};\\\", \\\"{x:1460,y:732,t:1527876827339};\\\", \\\"{x:1455,y:727,t:1527876827357};\\\", \\\"{x:1454,y:725,t:1527876827376};\\\", \\\"{x:1453,y:724,t:1527876827389};\\\", \\\"{x:1452,y:722,t:1527876827416};\\\", \\\"{x:1452,y:721,t:1527876827465};\\\", \\\"{x:1452,y:719,t:1527876827473};\\\", \\\"{x:1451,y:715,t:1527876827489};\\\", \\\"{x:1451,y:712,t:1527876827512};\\\", \\\"{x:1452,y:709,t:1527876827528};\\\", \\\"{x:1453,y:707,t:1527876827539};\\\", \\\"{x:1453,y:703,t:1527876827557};\\\", \\\"{x:1453,y:693,t:1527876827572};\\\", \\\"{x:1453,y:690,t:1527876827589};\\\", \\\"{x:1453,y:686,t:1527876827606};\\\", \\\"{x:1453,y:681,t:1527876827622};\\\", \\\"{x:1453,y:678,t:1527876827639};\\\", \\\"{x:1453,y:675,t:1527876827656};\\\", \\\"{x:1453,y:674,t:1527876827689};\\\", \\\"{x:1453,y:673,t:1527876827706};\\\", \\\"{x:1453,y:670,t:1527876827722};\\\", \\\"{x:1452,y:667,t:1527876827739};\\\", \\\"{x:1450,y:660,t:1527876827756};\\\", \\\"{x:1450,y:652,t:1527876827773};\\\", \\\"{x:1450,y:644,t:1527876827790};\\\", \\\"{x:1447,y:636,t:1527876827806};\\\", \\\"{x:1446,y:631,t:1527876827823};\\\", \\\"{x:1446,y:626,t:1527876827839};\\\", \\\"{x:1445,y:619,t:1527876827857};\\\", \\\"{x:1445,y:616,t:1527876827873};\\\", \\\"{x:1445,y:615,t:1527876827889};\\\", \\\"{x:1444,y:614,t:1527876827907};\\\", \\\"{x:1443,y:613,t:1527876827924};\\\", \\\"{x:1439,y:610,t:1527876827938};\\\", \\\"{x:1431,y:605,t:1527876827955};\\\", \\\"{x:1421,y:600,t:1527876827972};\\\", \\\"{x:1420,y:599,t:1527876827989};\\\", \\\"{x:1419,y:598,t:1527876828006};\\\", \\\"{x:1418,y:596,t:1527876828022};\\\", \\\"{x:1416,y:596,t:1527876828039};\\\", \\\"{x:1414,y:594,t:1527876828056};\\\", \\\"{x:1412,y:593,t:1527876828073};\\\", \\\"{x:1409,y:591,t:1527876828089};\\\", \\\"{x:1409,y:590,t:1527876828128};\\\", \\\"{x:1409,y:588,t:1527876828160};\\\", \\\"{x:1410,y:587,t:1527876828174};\\\", \\\"{x:1412,y:586,t:1527876828189};\\\", \\\"{x:1413,y:583,t:1527876828206};\\\", \\\"{x:1413,y:581,t:1527876828222};\\\", \\\"{x:1415,y:580,t:1527876828239};\\\", \\\"{x:1415,y:579,t:1527876828256};\\\", \\\"{x:1416,y:579,t:1527876828279};\\\", \\\"{x:1416,y:578,t:1527876828289};\\\", \\\"{x:1416,y:577,t:1527876828311};\\\", \\\"{x:1416,y:576,t:1527876828322};\\\", \\\"{x:1416,y:575,t:1527876828340};\\\", \\\"{x:1416,y:574,t:1527876828562};\\\", \\\"{x:1416,y:572,t:1527876828573};\\\", \\\"{x:1416,y:571,t:1527876828591};\\\", \\\"{x:1416,y:569,t:1527876828607};\\\", \\\"{x:1416,y:568,t:1527876828628};\\\", \\\"{x:1415,y:567,t:1527876828640};\\\", \\\"{x:1411,y:570,t:1527876829966};\\\", \\\"{x:1389,y:584,t:1527876829977};\\\", \\\"{x:1341,y:610,t:1527876829993};\\\", \\\"{x:1232,y:656,t:1527876830010};\\\", \\\"{x:1149,y:692,t:1527876830027};\\\", \\\"{x:1064,y:725,t:1527876830044};\\\", \\\"{x:989,y:749,t:1527876830060};\\\", \\\"{x:903,y:776,t:1527876830077};\\\", \\\"{x:826,y:794,t:1527876830093};\\\", \\\"{x:767,y:804,t:1527876830111};\\\", \\\"{x:705,y:814,t:1527876830127};\\\", \\\"{x:638,y:823,t:1527876830143};\\\", \\\"{x:585,y:829,t:1527876830160};\\\", \\\"{x:537,y:836,t:1527876830176};\\\", \\\"{x:495,y:842,t:1527876830194};\\\", \\\"{x:437,y:851,t:1527876830210};\\\", \\\"{x:404,y:855,t:1527876830227};\\\", \\\"{x:379,y:856,t:1527876830243};\\\", \\\"{x:355,y:856,t:1527876830261};\\\", \\\"{x:330,y:856,t:1527876830277};\\\", \\\"{x:318,y:856,t:1527876830294};\\\", \\\"{x:311,y:856,t:1527876830310};\\\", \\\"{x:311,y:854,t:1527876830420};\\\", \\\"{x:311,y:852,t:1527876830428};\\\", \\\"{x:312,y:844,t:1527876830444};\\\", \\\"{x:322,y:833,t:1527876830461};\\\", \\\"{x:328,y:823,t:1527876830478};\\\", \\\"{x:338,y:809,t:1527876830494};\\\", \\\"{x:352,y:790,t:1527876830511};\\\", \\\"{x:371,y:766,t:1527876830528};\\\", \\\"{x:397,y:738,t:1527876830544};\\\", \\\"{x:418,y:715,t:1527876830561};\\\", \\\"{x:433,y:701,t:1527876830579};\\\", \\\"{x:442,y:690,t:1527876830594};\\\", \\\"{x:445,y:686,t:1527876830612};\\\", \\\"{x:447,y:685,t:1527876830628};\\\", \\\"{x:449,y:682,t:1527876830643};\\\", \\\"{x:451,y:676,t:1527876830661};\\\", \\\"{x:453,y:672,t:1527876830677};\\\", \\\"{x:454,y:669,t:1527876830693};\\\", \\\"{x:455,y:668,t:1527876830710};\\\", \\\"{x:457,y:664,t:1527876830727};\\\", \\\"{x:457,y:662,t:1527876830745};\\\", \\\"{x:457,y:661,t:1527876830795};\\\", \\\"{x:455,y:658,t:1527876830811};\\\", \\\"{x:451,y:654,t:1527876830832};\\\", \\\"{x:447,y:648,t:1527876830845};\\\", \\\"{x:443,y:644,t:1527876830860};\\\", \\\"{x:441,y:642,t:1527876830878};\\\", \\\"{x:439,y:640,t:1527876830895};\\\", \\\"{x:438,y:639,t:1527876830910};\\\", \\\"{x:435,y:638,t:1527876830927};\\\", \\\"{x:434,y:637,t:1527876830944};\\\", \\\"{x:431,y:635,t:1527876830961};\\\", \\\"{x:427,y:631,t:1527876830978};\\\", \\\"{x:422,y:624,t:1527876830994};\\\", \\\"{x:422,y:617,t:1527876831011};\\\", \\\"{x:421,y:606,t:1527876831029};\\\", \\\"{x:421,y:598,t:1527876831045};\\\", \\\"{x:421,y:589,t:1527876831060};\\\", \\\"{x:423,y:581,t:1527876831078};\\\", \\\"{x:429,y:570,t:1527876831095};\\\", \\\"{x:439,y:561,t:1527876831112};\\\", \\\"{x:453,y:553,t:1527876831127};\\\", \\\"{x:465,y:545,t:1527876831145};\\\", \\\"{x:476,y:538,t:1527876831163};\\\", \\\"{x:482,y:535,t:1527876831177};\\\", \\\"{x:486,y:533,t:1527876831194};\\\", \\\"{x:489,y:532,t:1527876831211};\\\", \\\"{x:492,y:532,t:1527876831227};\\\", \\\"{x:496,y:529,t:1527876831245};\\\", \\\"{x:501,y:529,t:1527876831262};\\\", \\\"{x:515,y:529,t:1527876831278};\\\", \\\"{x:526,y:529,t:1527876831295};\\\", \\\"{x:539,y:529,t:1527876831311};\\\", \\\"{x:555,y:532,t:1527876831327};\\\", \\\"{x:587,y:536,t:1527876831345};\\\", \\\"{x:628,y:539,t:1527876831362};\\\", \\\"{x:657,y:539,t:1527876831378};\\\", \\\"{x:681,y:543,t:1527876831396};\\\", \\\"{x:683,y:544,t:1527876831411};\\\", \\\"{x:684,y:545,t:1527876831427};\\\", \\\"{x:684,y:547,t:1527876831444};\\\", \\\"{x:681,y:549,t:1527876831462};\\\", \\\"{x:678,y:554,t:1527876831477};\\\", \\\"{x:675,y:559,t:1527876831494};\\\", \\\"{x:668,y:565,t:1527876831511};\\\", \\\"{x:655,y:573,t:1527876831528};\\\", \\\"{x:646,y:578,t:1527876831545};\\\", \\\"{x:635,y:584,t:1527876831563};\\\", \\\"{x:625,y:590,t:1527876831578};\\\", \\\"{x:622,y:591,t:1527876831594};\\\", \\\"{x:620,y:592,t:1527876831612};\\\", \\\"{x:618,y:593,t:1527876831629};\\\", \\\"{x:616,y:594,t:1527876831644};\\\", \\\"{x:615,y:594,t:1527876831666};\\\", \\\"{x:614,y:594,t:1527876832018};\\\", \\\"{x:612,y:597,t:1527876832028};\\\", \\\"{x:601,y:604,t:1527876832045};\\\", \\\"{x:584,y:615,t:1527876832062};\\\", \\\"{x:563,y:628,t:1527876832079};\\\", \\\"{x:544,y:641,t:1527876832095};\\\", \\\"{x:524,y:654,t:1527876832112};\\\", \\\"{x:506,y:666,t:1527876832129};\\\", \\\"{x:492,y:676,t:1527876832147};\\\", \\\"{x:484,y:683,t:1527876832161};\\\", \\\"{x:477,y:692,t:1527876832179};\\\", \\\"{x:473,y:700,t:1527876832196};\\\", \\\"{x:470,y:709,t:1527876832212};\\\", \\\"{x:469,y:718,t:1527876832228};\\\", \\\"{x:466,y:726,t:1527876832245};\\\", \\\"{x:465,y:731,t:1527876832261};\\\", \\\"{x:465,y:737,t:1527876832279};\\\", \\\"{x:465,y:742,t:1527876832295};\\\", \\\"{x:467,y:750,t:1527876832311};\\\", \\\"{x:471,y:760,t:1527876832328};\\\", \\\"{x:474,y:765,t:1527876832345};\\\", \\\"{x:476,y:769,t:1527876832362};\\\", \\\"{x:479,y:773,t:1527876832379};\\\", \\\"{x:481,y:776,t:1527876832396};\\\", \\\"{x:482,y:778,t:1527876832412};\\\", \\\"{x:483,y:779,t:1527876832429};\\\", \\\"{x:483,y:781,t:1527876832446};\\\", \\\"{x:484,y:781,t:1527876832571};\\\", \\\"{x:485,y:781,t:1527876832587};\\\", \\\"{x:486,y:780,t:1527876832596};\\\", \\\"{x:488,y:777,t:1527876832613};\\\", \\\"{x:491,y:775,t:1527876832630};\\\", \\\"{x:494,y:772,t:1527876832645};\\\", \\\"{x:497,y:768,t:1527876832663};\\\", \\\"{x:499,y:766,t:1527876832680};\\\", \\\"{x:501,y:764,t:1527876832696};\\\", \\\"{x:501,y:763,t:1527876832712};\\\", \\\"{x:502,y:763,t:1527876832729};\\\", \\\"{x:503,y:761,t:1527876832779};\\\", \\\"{x:508,y:759,t:1527876833756};\\\", \\\"{x:518,y:754,t:1527876833764};\\\", \\\"{x:557,y:741,t:1527876833780};\\\", \\\"{x:659,y:713,t:1527876833798};\\\", \\\"{x:815,y:677,t:1527876833813};\\\", \\\"{x:1033,y:617,t:1527876833829};\\\", \\\"{x:1260,y:548,t:1527876833847};\\\", \\\"{x:1442,y:500,t:1527876833864};\\\", \\\"{x:1589,y:450,t:1527876833879};\\\", \\\"{x:1681,y:418,t:1527876833897};\\\", \\\"{x:1732,y:404,t:1527876833914};\\\", \\\"{x:1743,y:399,t:1527876833930};\\\", \\\"{x:1742,y:399,t:1527876834020};\\\", \\\"{x:1741,y:399,t:1527876834031};\\\", \\\"{x:1736,y:399,t:1527876834048};\\\", \\\"{x:1730,y:396,t:1527876834064};\\\", \\\"{x:1722,y:394,t:1527876834082};\\\", \\\"{x:1719,y:394,t:1527876834097};\\\", \\\"{x:1712,y:394,t:1527876834114};\\\", \\\"{x:1700,y:397,t:1527876834131};\\\", \\\"{x:1690,y:401,t:1527876834147};\\\", \\\"{x:1677,y:405,t:1527876834164};\\\", \\\"{x:1658,y:410,t:1527876834181};\\\", \\\"{x:1634,y:417,t:1527876834198};\\\", \\\"{x:1619,y:422,t:1527876834215};\\\", \\\"{x:1598,y:428,t:1527876834232};\\\", \\\"{x:1574,y:435,t:1527876834247};\\\", \\\"{x:1548,y:446,t:1527876834263};\\\", \\\"{x:1522,y:458,t:1527876834281};\\\", \\\"{x:1500,y:468,t:1527876834297};\\\", \\\"{x:1465,y:483,t:1527876834314};\\\", \\\"{x:1422,y:498,t:1527876834330};\\\", \\\"{x:1407,y:506,t:1527876834347};\\\", \\\"{x:1396,y:511,t:1527876834364};\\\", \\\"{x:1387,y:517,t:1527876834381};\\\", \\\"{x:1373,y:523,t:1527876834398};\\\", \\\"{x:1366,y:530,t:1527876834414};\\\", \\\"{x:1359,y:536,t:1527876834431};\\\", \\\"{x:1354,y:542,t:1527876834448};\\\", \\\"{x:1351,y:547,t:1527876834464};\\\", \\\"{x:1351,y:549,t:1527876834481};\\\", \\\"{x:1351,y:552,t:1527876834498};\\\", \\\"{x:1351,y:553,t:1527876834515};\\\", \\\"{x:1357,y:556,t:1527876834530};\\\", \\\"{x:1366,y:560,t:1527876834548};\\\", \\\"{x:1377,y:563,t:1527876834566};\\\", \\\"{x:1385,y:563,t:1527876834581};\\\", \\\"{x:1392,y:563,t:1527876834598};\\\", \\\"{x:1396,y:563,t:1527876834615};\\\", \\\"{x:1397,y:563,t:1527876834659};\\\", \\\"{x:1398,y:563,t:1527876834667};\\\", \\\"{x:1400,y:563,t:1527876834681};\\\", \\\"{x:1403,y:561,t:1527876834698};\\\", \\\"{x:1406,y:560,t:1527876834715};\\\", \\\"{x:1407,y:560,t:1527876834732};\\\", \\\"{x:1411,y:559,t:1527876834807};\\\", \\\"{x:1411,y:558,t:1527876834815};\\\", \\\"{x:1412,y:558,t:1527876834832};\\\", \\\"{x:1413,y:558,t:1527876834979};\\\", \\\"{x:1414,y:558,t:1527876835035};\\\", \\\"{x:1414,y:561,t:1527876835050};\\\", \\\"{x:1414,y:565,t:1527876835064};\\\", \\\"{x:1414,y:568,t:1527876835081};\\\", \\\"{x:1414,y:568,t:1527876835622};\\\", \\\"{x:1414,y:567,t:1527876835631};\\\", \\\"{x:1413,y:566,t:1527876836099};\\\", \\\"{x:1406,y:567,t:1527876836117};\\\", \\\"{x:1390,y:572,t:1527876836132};\\\", \\\"{x:1365,y:581,t:1527876836149};\\\", \\\"{x:1324,y:591,t:1527876836165};\\\", \\\"{x:1268,y:608,t:1527876836182};\\\", \\\"{x:1207,y:625,t:1527876836199};\\\", \\\"{x:1135,y:645,t:1527876836215};\\\", \\\"{x:1049,y:669,t:1527876836232};\\\", \\\"{x:970,y:696,t:1527876836249};\\\", \\\"{x:890,y:716,t:1527876836265};\\\", \\\"{x:809,y:734,t:1527876836282};\\\", \\\"{x:775,y:743,t:1527876836298};\\\", \\\"{x:758,y:751,t:1527876836316};\\\", \\\"{x:744,y:761,t:1527876836332};\\\", \\\"{x:734,y:768,t:1527876836349};\\\", \\\"{x:727,y:776,t:1527876836366};\\\", \\\"{x:724,y:786,t:1527876836382};\\\", \\\"{x:721,y:795,t:1527876836399};\\\", \\\"{x:717,y:804,t:1527876836416};\\\", \\\"{x:712,y:810,t:1527876836432};\\\", \\\"{x:706,y:816,t:1527876836449};\\\", \\\"{x:701,y:818,t:1527876836467};\\\", \\\"{x:698,y:819,t:1527876836482};\\\", \\\"{x:694,y:820,t:1527876836499};\\\", \\\"{x:685,y:817,t:1527876836517};\\\", \\\"{x:676,y:809,t:1527876836532};\\\", \\\"{x:665,y:802,t:1527876836549};\\\", \\\"{x:654,y:796,t:1527876836566};\\\", \\\"{x:646,y:791,t:1527876836582};\\\", \\\"{x:636,y:786,t:1527876836600};\\\", \\\"{x:627,y:782,t:1527876836616};\\\", \\\"{x:612,y:778,t:1527876836632};\\\", \\\"{x:597,y:773,t:1527876836649};\\\", \\\"{x:576,y:765,t:1527876836667};\\\", \\\"{x:566,y:758,t:1527876836683};\\\", \\\"{x:561,y:757,t:1527876836700};\\\", \\\"{x:547,y:752,t:1527876836716};\\\", \\\"{x:540,y:752,t:1527876836733};\\\", \\\"{x:530,y:750,t:1527876836749};\\\", \\\"{x:520,y:750,t:1527876836766};\\\", \\\"{x:516,y:750,t:1527876836783};\\\", \\\"{x:514,y:750,t:1527876836799};\\\", \\\"{x:513,y:749,t:1527876836816};\\\" ] }, { \\\"rt\\\": 32759, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 462390, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 3, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:749,t:1527876844564};\\\", \\\"{x:516,y:749,t:1527876844573};\\\", \\\"{x:517,y:749,t:1527876844589};\\\", \\\"{x:519,y:747,t:1527876844605};\\\", \\\"{x:523,y:746,t:1527876844623};\\\", \\\"{x:526,y:744,t:1527876844639};\\\", \\\"{x:530,y:743,t:1527876844656};\\\", \\\"{x:540,y:739,t:1527876844672};\\\", \\\"{x:553,y:732,t:1527876844689};\\\", \\\"{x:573,y:724,t:1527876844705};\\\", \\\"{x:618,y:710,t:1527876844722};\\\", \\\"{x:654,y:699,t:1527876844740};\\\", \\\"{x:701,y:687,t:1527876844755};\\\", \\\"{x:744,y:674,t:1527876844773};\\\", \\\"{x:783,y:663,t:1527876844789};\\\", \\\"{x:815,y:653,t:1527876844807};\\\", \\\"{x:847,y:641,t:1527876844823};\\\", \\\"{x:889,y:624,t:1527876844839};\\\", \\\"{x:928,y:611,t:1527876844857};\\\", \\\"{x:988,y:590,t:1527876844873};\\\", \\\"{x:1055,y:571,t:1527876844890};\\\", \\\"{x:1114,y:551,t:1527876844905};\\\", \\\"{x:1185,y:519,t:1527876844922};\\\", \\\"{x:1205,y:509,t:1527876844939};\\\", \\\"{x:1219,y:503,t:1527876844956};\\\", \\\"{x:1232,y:496,t:1527876844972};\\\", \\\"{x:1243,y:489,t:1527876844989};\\\", \\\"{x:1258,y:478,t:1527876845007};\\\", \\\"{x:1270,y:468,t:1527876845023};\\\", \\\"{x:1282,y:457,t:1527876845040};\\\", \\\"{x:1294,y:447,t:1527876845056};\\\", \\\"{x:1312,y:435,t:1527876845072};\\\", \\\"{x:1327,y:425,t:1527876845090};\\\", \\\"{x:1355,y:411,t:1527876845107};\\\", \\\"{x:1371,y:403,t:1527876845122};\\\", \\\"{x:1381,y:398,t:1527876845140};\\\", \\\"{x:1382,y:398,t:1527876845156};\\\", \\\"{x:1379,y:400,t:1527876845234};\\\", \\\"{x:1375,y:401,t:1527876845241};\\\", \\\"{x:1373,y:403,t:1527876845256};\\\", \\\"{x:1365,y:409,t:1527876845273};\\\", \\\"{x:1355,y:421,t:1527876845289};\\\", \\\"{x:1345,y:439,t:1527876845306};\\\", \\\"{x:1340,y:450,t:1527876845323};\\\", \\\"{x:1336,y:458,t:1527876845340};\\\", \\\"{x:1329,y:468,t:1527876845356};\\\", \\\"{x:1325,y:474,t:1527876845373};\\\", \\\"{x:1320,y:479,t:1527876845390};\\\", \\\"{x:1317,y:483,t:1527876845407};\\\", \\\"{x:1317,y:484,t:1527876845423};\\\", \\\"{x:1316,y:486,t:1527876845439};\\\", \\\"{x:1316,y:487,t:1527876845457};\\\", \\\"{x:1315,y:488,t:1527876845474};\\\", \\\"{x:1315,y:489,t:1527876845499};\\\", \\\"{x:1313,y:490,t:1527876845531};\\\", \\\"{x:1311,y:491,t:1527876845547};\\\", \\\"{x:1310,y:493,t:1527876845564};\\\", \\\"{x:1309,y:496,t:1527876845573};\\\", \\\"{x:1308,y:498,t:1527876845590};\\\", \\\"{x:1308,y:499,t:1527876845605};\\\", \\\"{x:1309,y:499,t:1527876845895};\\\", \\\"{x:1311,y:497,t:1527876845923};\\\", \\\"{x:1312,y:497,t:1527876845941};\\\", \\\"{x:1313,y:496,t:1527876845962};\\\", \\\"{x:1314,y:500,t:1527876850091};\\\", \\\"{x:1316,y:515,t:1527876850101};\\\", \\\"{x:1319,y:539,t:1527876850115};\\\", \\\"{x:1320,y:551,t:1527876850132};\\\", \\\"{x:1320,y:554,t:1527876850143};\\\", \\\"{x:1322,y:559,t:1527876850161};\\\", \\\"{x:1323,y:562,t:1527876850176};\\\", \\\"{x:1323,y:563,t:1527876850202};\\\", \\\"{x:1323,y:565,t:1527876850210};\\\", \\\"{x:1324,y:569,t:1527876850226};\\\", \\\"{x:1325,y:576,t:1527876850243};\\\", \\\"{x:1325,y:578,t:1527876850261};\\\", \\\"{x:1326,y:583,t:1527876850277};\\\", \\\"{x:1327,y:585,t:1527876850294};\\\", \\\"{x:1327,y:589,t:1527876850311};\\\", \\\"{x:1327,y:591,t:1527876850328};\\\", \\\"{x:1327,y:592,t:1527876850344};\\\", \\\"{x:1327,y:594,t:1527876850361};\\\", \\\"{x:1327,y:597,t:1527876850378};\\\", \\\"{x:1327,y:598,t:1527876850394};\\\", \\\"{x:1327,y:601,t:1527876850411};\\\", \\\"{x:1327,y:604,t:1527876850428};\\\", \\\"{x:1325,y:608,t:1527876850444};\\\", \\\"{x:1325,y:610,t:1527876850461};\\\", \\\"{x:1323,y:614,t:1527876850478};\\\", \\\"{x:1322,y:616,t:1527876850494};\\\", \\\"{x:1320,y:620,t:1527876850511};\\\", \\\"{x:1320,y:623,t:1527876850528};\\\", \\\"{x:1318,y:627,t:1527876850546};\\\", \\\"{x:1315,y:632,t:1527876850561};\\\", \\\"{x:1313,y:635,t:1527876850577};\\\", \\\"{x:1310,y:638,t:1527876850594};\\\", \\\"{x:1308,y:639,t:1527876850611};\\\", \\\"{x:1310,y:637,t:1527876850883};\\\", \\\"{x:1310,y:636,t:1527876850894};\\\", \\\"{x:1312,y:634,t:1527876850912};\\\", \\\"{x:1312,y:633,t:1527876850928};\\\", \\\"{x:1313,y:632,t:1527876850970};\\\", \\\"{x:1302,y:632,t:1527876858262};\\\", \\\"{x:1274,y:632,t:1527876858278};\\\", \\\"{x:1241,y:632,t:1527876858295};\\\", \\\"{x:1199,y:635,t:1527876858316};\\\", \\\"{x:1175,y:635,t:1527876858333};\\\", \\\"{x:1153,y:635,t:1527876858350};\\\", \\\"{x:1130,y:635,t:1527876858366};\\\", \\\"{x:1108,y:635,t:1527876858383};\\\", \\\"{x:1084,y:635,t:1527876858400};\\\", \\\"{x:1048,y:635,t:1527876858417};\\\", \\\"{x:1010,y:633,t:1527876858433};\\\", \\\"{x:947,y:632,t:1527876858451};\\\", \\\"{x:888,y:628,t:1527876858467};\\\", \\\"{x:845,y:621,t:1527876858485};\\\", \\\"{x:814,y:618,t:1527876858500};\\\", \\\"{x:797,y:614,t:1527876858518};\\\", \\\"{x:783,y:608,t:1527876858534};\\\", \\\"{x:772,y:608,t:1527876858550};\\\", \\\"{x:767,y:606,t:1527876858567};\\\", \\\"{x:765,y:606,t:1527876858584};\\\", \\\"{x:763,y:605,t:1527876858600};\\\", \\\"{x:762,y:604,t:1527876858643};\\\", \\\"{x:761,y:603,t:1527876858651};\\\", \\\"{x:759,y:602,t:1527876858668};\\\", \\\"{x:755,y:601,t:1527876858685};\\\", \\\"{x:750,y:599,t:1527876858701};\\\", \\\"{x:745,y:598,t:1527876858717};\\\", \\\"{x:741,y:598,t:1527876858734};\\\", \\\"{x:737,y:598,t:1527876858751};\\\", \\\"{x:730,y:598,t:1527876858768};\\\", \\\"{x:720,y:596,t:1527876858786};\\\", \\\"{x:700,y:592,t:1527876858801};\\\", \\\"{x:684,y:589,t:1527876858817};\\\", \\\"{x:661,y:583,t:1527876858834};\\\", \\\"{x:651,y:579,t:1527876858851};\\\", \\\"{x:644,y:577,t:1527876858867};\\\", \\\"{x:635,y:573,t:1527876858884};\\\", \\\"{x:633,y:573,t:1527876858901};\\\", \\\"{x:632,y:573,t:1527876858930};\\\", \\\"{x:632,y:572,t:1527876858954};\\\", \\\"{x:632,y:571,t:1527876858994};\\\", \\\"{x:632,y:570,t:1527876859002};\\\", \\\"{x:632,y:568,t:1527876859018};\\\", \\\"{x:632,y:567,t:1527876859035};\\\", \\\"{x:631,y:568,t:1527876859178};\\\", \\\"{x:628,y:569,t:1527876859186};\\\", \\\"{x:625,y:571,t:1527876859201};\\\", \\\"{x:621,y:573,t:1527876859218};\\\", \\\"{x:620,y:573,t:1527876859234};\\\", \\\"{x:618,y:574,t:1527876859251};\\\", \\\"{x:617,y:575,t:1527876859268};\\\", \\\"{x:615,y:575,t:1527876859339};\\\", \\\"{x:614,y:575,t:1527876859370};\\\", \\\"{x:618,y:575,t:1527876859551};\\\", \\\"{x:632,y:571,t:1527876859568};\\\", \\\"{x:645,y:566,t:1527876859585};\\\", \\\"{x:651,y:563,t:1527876859601};\\\", \\\"{x:656,y:561,t:1527876859617};\\\", \\\"{x:658,y:560,t:1527876859635};\\\", \\\"{x:664,y:557,t:1527876859651};\\\", \\\"{x:671,y:554,t:1527876859669};\\\", \\\"{x:675,y:552,t:1527876859685};\\\", \\\"{x:679,y:550,t:1527876859701};\\\", \\\"{x:682,y:550,t:1527876859718};\\\", \\\"{x:683,y:550,t:1527876859735};\\\", \\\"{x:685,y:550,t:1527876859754};\\\", \\\"{x:690,y:550,t:1527876859768};\\\", \\\"{x:704,y:550,t:1527876859785};\\\", \\\"{x:725,y:553,t:1527876859801};\\\", \\\"{x:764,y:555,t:1527876859818};\\\", \\\"{x:794,y:555,t:1527876859835};\\\", \\\"{x:819,y:555,t:1527876859851};\\\", \\\"{x:839,y:556,t:1527876859870};\\\", \\\"{x:854,y:556,t:1527876859885};\\\", \\\"{x:860,y:556,t:1527876859901};\\\", \\\"{x:861,y:556,t:1527876859918};\\\", \\\"{x:861,y:557,t:1527876860107};\\\", \\\"{x:861,y:558,t:1527876860119};\\\", \\\"{x:859,y:561,t:1527876860136};\\\", \\\"{x:854,y:563,t:1527876860152};\\\", \\\"{x:846,y:568,t:1527876860168};\\\", \\\"{x:840,y:571,t:1527876860185};\\\", \\\"{x:835,y:574,t:1527876860202};\\\", \\\"{x:835,y:575,t:1527876860218};\\\", \\\"{x:833,y:576,t:1527876860250};\\\", \\\"{x:832,y:577,t:1527876860299};\\\", \\\"{x:830,y:578,t:1527876860562};\\\", \\\"{x:826,y:579,t:1527876860570};\\\", \\\"{x:820,y:582,t:1527876860586};\\\", \\\"{x:794,y:592,t:1527876860603};\\\", \\\"{x:776,y:601,t:1527876860620};\\\", \\\"{x:756,y:609,t:1527876860635};\\\", \\\"{x:733,y:618,t:1527876860652};\\\", \\\"{x:708,y:627,t:1527876860670};\\\", \\\"{x:684,y:634,t:1527876860685};\\\", \\\"{x:658,y:644,t:1527876860702};\\\", \\\"{x:632,y:652,t:1527876860719};\\\", \\\"{x:611,y:662,t:1527876860736};\\\", \\\"{x:595,y:669,t:1527876860753};\\\", \\\"{x:581,y:677,t:1527876860769};\\\", \\\"{x:567,y:686,t:1527876860786};\\\", \\\"{x:560,y:692,t:1527876860802};\\\", \\\"{x:556,y:695,t:1527876860819};\\\", \\\"{x:552,y:699,t:1527876860836};\\\", \\\"{x:547,y:703,t:1527876860852};\\\", \\\"{x:544,y:707,t:1527876860869};\\\", \\\"{x:543,y:708,t:1527876860886};\\\", \\\"{x:543,y:710,t:1527876860903};\\\", \\\"{x:542,y:710,t:1527876860919};\\\", \\\"{x:541,y:713,t:1527876860936};\\\", \\\"{x:540,y:718,t:1527876860952};\\\", \\\"{x:539,y:721,t:1527876860970};\\\", \\\"{x:538,y:724,t:1527876860986};\\\", \\\"{x:537,y:725,t:1527876861002};\\\", \\\"{x:537,y:726,t:1527876861019};\\\", \\\"{x:534,y:729,t:1527876861037};\\\", \\\"{x:533,y:735,t:1527876861053};\\\", \\\"{x:531,y:741,t:1527876861069};\\\", \\\"{x:528,y:749,t:1527876861087};\\\", \\\"{x:526,y:755,t:1527876861104};\\\", \\\"{x:524,y:759,t:1527876861120};\\\", \\\"{x:521,y:764,t:1527876861136};\\\", \\\"{x:518,y:768,t:1527876861153};\\\", \\\"{x:517,y:772,t:1527876861170};\\\", \\\"{x:514,y:775,t:1527876861186};\\\", \\\"{x:514,y:777,t:1527876861204};\\\", \\\"{x:513,y:777,t:1527876861219};\\\", \\\"{x:513,y:778,t:1527876861242};\\\", \\\"{x:512,y:778,t:1527876861682};\\\", \\\"{x:512,y:777,t:1527876861706};\\\", \\\"{x:512,y:776,t:1527876861720};\\\", \\\"{x:512,y:775,t:1527876861737};\\\", \\\"{x:512,y:774,t:1527876861763};\\\", \\\"{x:512,y:773,t:1527876861771};\\\", \\\"{x:512,y:772,t:1527876861795};\\\", \\\"{x:511,y:770,t:1527876861899};\\\", \\\"{x:511,y:769,t:1527876861923};\\\", \\\"{x:511,y:767,t:1527876862451};\\\", \\\"{x:511,y:765,t:1527876862459};\\\", \\\"{x:511,y:763,t:1527876862471};\\\", \\\"{x:513,y:759,t:1527876862487};\\\", \\\"{x:516,y:752,t:1527876862505};\\\", \\\"{x:525,y:743,t:1527876862523};\\\", \\\"{x:537,y:733,t:1527876862537};\\\", \\\"{x:568,y:706,t:1527876862554};\\\", \\\"{x:590,y:688,t:1527876862570};\\\", \\\"{x:616,y:670,t:1527876862587};\\\", \\\"{x:639,y:654,t:1527876862604};\\\", \\\"{x:660,y:639,t:1527876862620};\\\", \\\"{x:677,y:628,t:1527876862638};\\\", \\\"{x:690,y:619,t:1527876862654};\\\", \\\"{x:696,y:613,t:1527876862670};\\\", \\\"{x:699,y:610,t:1527876862687};\\\", \\\"{x:700,y:610,t:1527876862770};\\\", \\\"{x:700,y:606,t:1527876862788};\\\", \\\"{x:700,y:604,t:1527876862804};\\\", \\\"{x:700,y:602,t:1527876862826};\\\", \\\"{x:699,y:601,t:1527876862837};\\\", \\\"{x:699,y:599,t:1527876862853};\\\", \\\"{x:696,y:594,t:1527876862871};\\\", \\\"{x:694,y:588,t:1527876862889};\\\", \\\"{x:690,y:584,t:1527876862904};\\\", \\\"{x:687,y:580,t:1527876862920};\\\", \\\"{x:687,y:579,t:1527876862937};\\\", \\\"{x:686,y:579,t:1527876862994};\\\", \\\"{x:685,y:578,t:1527876863004};\\\", \\\"{x:679,y:573,t:1527876863022};\\\", \\\"{x:679,y:572,t:1527876863051};\\\", \\\"{x:677,y:571,t:1527876863267};\\\", \\\"{x:676,y:571,t:1527876863275};\\\", \\\"{x:674,y:571,t:1527876863288};\\\", \\\"{x:670,y:571,t:1527876863305};\\\", \\\"{x:668,y:572,t:1527876863322};\\\", \\\"{x:667,y:572,t:1527876863338};\\\", \\\"{x:663,y:572,t:1527876863355};\\\", \\\"{x:660,y:572,t:1527876863371};\\\", \\\"{x:651,y:573,t:1527876863388};\\\", \\\"{x:644,y:573,t:1527876863405};\\\", \\\"{x:642,y:573,t:1527876863422};\\\", \\\"{x:641,y:573,t:1527876863439};\\\", \\\"{x:638,y:573,t:1527876863456};\\\", \\\"{x:637,y:573,t:1527876863471};\\\", \\\"{x:636,y:573,t:1527876863490};\\\", \\\"{x:635,y:573,t:1527876863504};\\\", \\\"{x:633,y:573,t:1527876863521};\\\", \\\"{x:628,y:573,t:1527876863538};\\\", \\\"{x:624,y:573,t:1527876863555};\\\", \\\"{x:623,y:573,t:1527876863571};\\\", \\\"{x:622,y:573,t:1527876863651};\\\", \\\"{x:621,y:573,t:1527876863659};\\\", \\\"{x:619,y:573,t:1527876863672};\\\", \\\"{x:617,y:573,t:1527876863688};\\\", \\\"{x:615,y:573,t:1527876863705};\\\", \\\"{x:614,y:573,t:1527876863875};\\\", \\\"{x:612,y:573,t:1527876863947};\\\", \\\"{x:611,y:573,t:1527876863979};\\\", \\\"{x:608,y:577,t:1527876866962};\\\", \\\"{x:607,y:577,t:1527876866974};\\\", \\\"{x:603,y:585,t:1527876866991};\\\", \\\"{x:595,y:594,t:1527876867008};\\\", \\\"{x:589,y:601,t:1527876867025};\\\", \\\"{x:584,y:609,t:1527876867040};\\\", \\\"{x:580,y:615,t:1527876867058};\\\", \\\"{x:575,y:627,t:1527876867074};\\\", \\\"{x:570,y:639,t:1527876867090};\\\", \\\"{x:567,y:649,t:1527876867107};\\\", \\\"{x:563,y:665,t:1527876867125};\\\", \\\"{x:557,y:677,t:1527876867142};\\\", \\\"{x:550,y:690,t:1527876867157};\\\", \\\"{x:546,y:698,t:1527876867174};\\\", \\\"{x:542,y:708,t:1527876867192};\\\", \\\"{x:540,y:713,t:1527876867207};\\\", \\\"{x:538,y:719,t:1527876867224};\\\", \\\"{x:536,y:722,t:1527876867240};\\\", \\\"{x:533,y:727,t:1527876867257};\\\", \\\"{x:528,y:736,t:1527876867274};\\\", \\\"{x:525,y:742,t:1527876867292};\\\", \\\"{x:522,y:746,t:1527876867308};\\\", \\\"{x:520,y:751,t:1527876867325};\\\", \\\"{x:518,y:754,t:1527876867342};\\\", \\\"{x:518,y:756,t:1527876867357};\\\", \\\"{x:517,y:757,t:1527876867374};\\\", \\\"{x:517,y:758,t:1527876867392};\\\", \\\"{x:517,y:764,t:1527876867407};\\\", \\\"{x:515,y:769,t:1527876867425};\\\", \\\"{x:514,y:775,t:1527876867441};\\\", \\\"{x:514,y:777,t:1527876867457};\\\", \\\"{x:512,y:782,t:1527876867475};\\\", \\\"{x:512,y:784,t:1527876867547};\\\", \\\"{x:511,y:785,t:1527876867558};\\\", \\\"{x:511,y:786,t:1527876867576};\\\", \\\"{x:510,y:788,t:1527876867592};\\\", \\\"{x:509,y:789,t:1527876867698};\\\", \\\"{x:509,y:788,t:1527876867883};\\\", \\\"{x:509,y:786,t:1527876867892};\\\", \\\"{x:509,y:783,t:1527876867909};\\\", \\\"{x:509,y:782,t:1527876867924};\\\", \\\"{x:509,y:779,t:1527876867942};\\\", \\\"{x:510,y:776,t:1527876867959};\\\", \\\"{x:511,y:774,t:1527876867986};\\\", \\\"{x:511,y:773,t:1527876867994};\\\", \\\"{x:512,y:772,t:1527876868008};\\\", \\\"{x:512,y:771,t:1527876868026};\\\", \\\"{x:512,y:770,t:1527876868041};\\\", \\\"{x:512,y:769,t:1527876868058};\\\", \\\"{x:512,y:768,t:1527876868123};\\\", \\\"{x:512,y:766,t:1527876868554};\\\", \\\"{x:513,y:764,t:1527876868570};\\\", \\\"{x:514,y:762,t:1527876868586};\\\", \\\"{x:514,y:761,t:1527876868603};\\\", \\\"{x:515,y:761,t:1527876868611};\\\" ] }, { \\\"rt\\\": 18985, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 482607, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -C -E -E -E -E -E -E -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:758,t:1527876875642};\\\", \\\"{x:524,y:752,t:1527876875658};\\\", \\\"{x:529,y:750,t:1527876875666};\\\", \\\"{x:532,y:749,t:1527876875681};\\\", \\\"{x:540,y:745,t:1527876875698};\\\", \\\"{x:560,y:742,t:1527876875715};\\\", \\\"{x:606,y:741,t:1527876875733};\\\", \\\"{x:695,y:741,t:1527876875748};\\\", \\\"{x:797,y:733,t:1527876875765};\\\", \\\"{x:904,y:721,t:1527876875781};\\\", \\\"{x:1006,y:713,t:1527876875798};\\\", \\\"{x:1099,y:706,t:1527876875815};\\\", \\\"{x:1174,y:706,t:1527876875831};\\\", \\\"{x:1241,y:704,t:1527876875848};\\\", \\\"{x:1286,y:704,t:1527876875865};\\\", \\\"{x:1330,y:703,t:1527876875882};\\\", \\\"{x:1353,y:699,t:1527876875899};\\\", \\\"{x:1379,y:697,t:1527876875916};\\\", \\\"{x:1411,y:692,t:1527876875932};\\\", \\\"{x:1444,y:687,t:1527876875948};\\\", \\\"{x:1475,y:683,t:1527876875965};\\\", \\\"{x:1496,y:679,t:1527876875982};\\\", \\\"{x:1509,y:676,t:1527876875998};\\\", \\\"{x:1511,y:676,t:1527876876016};\\\", \\\"{x:1512,y:676,t:1527876876033};\\\", \\\"{x:1513,y:675,t:1527876876211};\\\", \\\"{x:1513,y:673,t:1527876876219};\\\", \\\"{x:1511,y:670,t:1527876876232};\\\", \\\"{x:1504,y:666,t:1527876876249};\\\", \\\"{x:1492,y:656,t:1527876876265};\\\", \\\"{x:1472,y:643,t:1527876876282};\\\", \\\"{x:1457,y:635,t:1527876876299};\\\", \\\"{x:1446,y:629,t:1527876876316};\\\", \\\"{x:1433,y:620,t:1527876876333};\\\", \\\"{x:1418,y:609,t:1527876876349};\\\", \\\"{x:1404,y:599,t:1527876876366};\\\", \\\"{x:1389,y:587,t:1527876876382};\\\", \\\"{x:1385,y:581,t:1527876876400};\\\", \\\"{x:1368,y:568,t:1527876876416};\\\", \\\"{x:1358,y:556,t:1527876876432};\\\", \\\"{x:1354,y:555,t:1527876876449};\\\", \\\"{x:1352,y:554,t:1527876876466};\\\", \\\"{x:1348,y:554,t:1527876876483};\\\", \\\"{x:1345,y:553,t:1527876876499};\\\", \\\"{x:1343,y:553,t:1527876876516};\\\", \\\"{x:1342,y:553,t:1527876876533};\\\", \\\"{x:1340,y:553,t:1527876876549};\\\", \\\"{x:1339,y:553,t:1527876876565};\\\", \\\"{x:1336,y:553,t:1527876876582};\\\", \\\"{x:1334,y:553,t:1527876876599};\\\", \\\"{x:1329,y:553,t:1527876876615};\\\", \\\"{x:1323,y:553,t:1527876876632};\\\", \\\"{x:1313,y:556,t:1527876876649};\\\", \\\"{x:1309,y:557,t:1527876876665};\\\", \\\"{x:1304,y:559,t:1527876876683};\\\", \\\"{x:1301,y:559,t:1527876876699};\\\", \\\"{x:1299,y:561,t:1527876876715};\\\", \\\"{x:1298,y:561,t:1527876876732};\\\", \\\"{x:1297,y:561,t:1527876876749};\\\", \\\"{x:1293,y:562,t:1527876876767};\\\", \\\"{x:1291,y:563,t:1527876876782};\\\", \\\"{x:1290,y:563,t:1527876876800};\\\", \\\"{x:1288,y:564,t:1527876876817};\\\", \\\"{x:1287,y:565,t:1527876877139};\\\", \\\"{x:1287,y:566,t:1527876877171};\\\", \\\"{x:1286,y:566,t:1527876877187};\\\", \\\"{x:1285,y:566,t:1527876877200};\\\", \\\"{x:1284,y:566,t:1527876877267};\\\", \\\"{x:1284,y:567,t:1527876877284};\\\", \\\"{x:1282,y:567,t:1527876877299};\\\", \\\"{x:1281,y:568,t:1527876877316};\\\", \\\"{x:1281,y:569,t:1527876877395};\\\", \\\"{x:1279,y:569,t:1527876877412};\\\", \\\"{x:1278,y:569,t:1527876877419};\\\", \\\"{x:1277,y:569,t:1527876877563};\\\", \\\"{x:1278,y:568,t:1527876877571};\\\", \\\"{x:1278,y:567,t:1527876877584};\\\", \\\"{x:1278,y:566,t:1527876877599};\\\", \\\"{x:1279,y:565,t:1527876877723};\\\", \\\"{x:1280,y:564,t:1527876877747};\\\", \\\"{x:1281,y:564,t:1527876877755};\\\", \\\"{x:1281,y:563,t:1527876877987};\\\", \\\"{x:1281,y:562,t:1527876878187};\\\", \\\"{x:1280,y:562,t:1527876878201};\\\", \\\"{x:1278,y:562,t:1527876878218};\\\", \\\"{x:1277,y:561,t:1527876878275};\\\", \\\"{x:1277,y:560,t:1527876878290};\\\", \\\"{x:1277,y:559,t:1527876878314};\\\", \\\"{x:1277,y:558,t:1527876878331};\\\", \\\"{x:1278,y:558,t:1527876878347};\\\", \\\"{x:1278,y:556,t:1527876878368};\\\", \\\"{x:1280,y:555,t:1527876878383};\\\", \\\"{x:1284,y:552,t:1527876878401};\\\", \\\"{x:1288,y:550,t:1527876878418};\\\", \\\"{x:1291,y:548,t:1527876878434};\\\", \\\"{x:1295,y:545,t:1527876878450};\\\", \\\"{x:1296,y:544,t:1527876878467};\\\", \\\"{x:1293,y:544,t:1527876878579};\\\", \\\"{x:1287,y:544,t:1527876878587};\\\", \\\"{x:1281,y:544,t:1527876878602};\\\", \\\"{x:1267,y:546,t:1527876878618};\\\", \\\"{x:1241,y:549,t:1527876878635};\\\", \\\"{x:1219,y:553,t:1527876878651};\\\", \\\"{x:1188,y:557,t:1527876878668};\\\", \\\"{x:1156,y:562,t:1527876878685};\\\", \\\"{x:1115,y:567,t:1527876878701};\\\", \\\"{x:1065,y:573,t:1527876878718};\\\", \\\"{x:1022,y:581,t:1527876878735};\\\", \\\"{x:966,y:589,t:1527876878750};\\\", \\\"{x:908,y:597,t:1527876878768};\\\", \\\"{x:849,y:605,t:1527876878786};\\\", \\\"{x:793,y:613,t:1527876878800};\\\", \\\"{x:753,y:614,t:1527876878817};\\\", \\\"{x:704,y:615,t:1527876878835};\\\", \\\"{x:680,y:619,t:1527876878851};\\\", \\\"{x:665,y:619,t:1527876878867};\\\", \\\"{x:657,y:620,t:1527876878884};\\\", \\\"{x:654,y:620,t:1527876878901};\\\", \\\"{x:650,y:620,t:1527876878917};\\\", \\\"{x:648,y:620,t:1527876878934};\\\", \\\"{x:649,y:620,t:1527876879082};\\\", \\\"{x:651,y:619,t:1527876879090};\\\", \\\"{x:653,y:618,t:1527876879101};\\\", \\\"{x:655,y:618,t:1527876879116};\\\", \\\"{x:656,y:616,t:1527876879134};\\\", \\\"{x:658,y:616,t:1527876879151};\\\", \\\"{x:661,y:614,t:1527876879167};\\\", \\\"{x:672,y:601,t:1527876879184};\\\", \\\"{x:699,y:578,t:1527876879203};\\\", \\\"{x:741,y:547,t:1527876879217};\\\", \\\"{x:812,y:494,t:1527876879234};\\\", \\\"{x:843,y:468,t:1527876879251};\\\", \\\"{x:854,y:456,t:1527876879267};\\\", \\\"{x:857,y:452,t:1527876879284};\\\", \\\"{x:857,y:451,t:1527876879338};\\\", \\\"{x:856,y:451,t:1527876879351};\\\", \\\"{x:845,y:451,t:1527876879367};\\\", \\\"{x:827,y:451,t:1527876879384};\\\", \\\"{x:812,y:451,t:1527876879401};\\\", \\\"{x:797,y:451,t:1527876879417};\\\", \\\"{x:775,y:451,t:1527876879434};\\\", \\\"{x:761,y:451,t:1527876879451};\\\", \\\"{x:745,y:454,t:1527876879468};\\\", \\\"{x:726,y:459,t:1527876879484};\\\", \\\"{x:700,y:462,t:1527876879502};\\\", \\\"{x:674,y:467,t:1527876879519};\\\", \\\"{x:650,y:473,t:1527876879534};\\\", \\\"{x:630,y:479,t:1527876879551};\\\", \\\"{x:618,y:483,t:1527876879568};\\\", \\\"{x:611,y:487,t:1527876879585};\\\", \\\"{x:606,y:488,t:1527876879602};\\\", \\\"{x:605,y:489,t:1527876879617};\\\", \\\"{x:603,y:490,t:1527876879635};\\\", \\\"{x:602,y:491,t:1527876879674};\\\", \\\"{x:601,y:491,t:1527876879684};\\\", \\\"{x:596,y:496,t:1527876879702};\\\", \\\"{x:591,y:501,t:1527876879718};\\\", \\\"{x:591,y:502,t:1527876879778};\\\", \\\"{x:591,y:503,t:1527876879786};\\\", \\\"{x:592,y:503,t:1527876879802};\\\", \\\"{x:595,y:505,t:1527876879818};\\\", \\\"{x:596,y:505,t:1527876879835};\\\", \\\"{x:597,y:505,t:1527876879851};\\\", \\\"{x:598,y:505,t:1527876880123};\\\", \\\"{x:602,y:505,t:1527876880132};\\\", \\\"{x:602,y:505,t:1527876880134};\\\", \\\"{x:609,y:505,t:1527876880151};\\\", \\\"{x:613,y:505,t:1527876880168};\\\", \\\"{x:615,y:505,t:1527876880185};\\\", \\\"{x:616,y:505,t:1527876880202};\\\", \\\"{x:619,y:506,t:1527876880218};\\\", \\\"{x:628,y:508,t:1527876880236};\\\", \\\"{x:640,y:509,t:1527876880252};\\\", \\\"{x:665,y:509,t:1527876880268};\\\", \\\"{x:687,y:510,t:1527876880285};\\\", \\\"{x:703,y:514,t:1527876880302};\\\", \\\"{x:720,y:516,t:1527876880318};\\\", \\\"{x:735,y:518,t:1527876880336};\\\", \\\"{x:751,y:520,t:1527876880352};\\\", \\\"{x:769,y:521,t:1527876880368};\\\", \\\"{x:781,y:521,t:1527876880385};\\\", \\\"{x:801,y:521,t:1527876880402};\\\", \\\"{x:821,y:522,t:1527876880418};\\\", \\\"{x:844,y:524,t:1527876880435};\\\", \\\"{x:892,y:527,t:1527876880452};\\\", \\\"{x:959,y:527,t:1527876880469};\\\", \\\"{x:1026,y:527,t:1527876880486};\\\", \\\"{x:1081,y:527,t:1527876880502};\\\", \\\"{x:1132,y:527,t:1527876880520};\\\", \\\"{x:1165,y:527,t:1527876880535};\\\", \\\"{x:1197,y:527,t:1527876880552};\\\", \\\"{x:1218,y:527,t:1527876880569};\\\", \\\"{x:1233,y:527,t:1527876880586};\\\", \\\"{x:1240,y:527,t:1527876880602};\\\", \\\"{x:1241,y:527,t:1527876880619};\\\", \\\"{x:1242,y:527,t:1527876880691};\\\", \\\"{x:1244,y:527,t:1527876880703};\\\", \\\"{x:1249,y:527,t:1527876880719};\\\", \\\"{x:1256,y:527,t:1527876880736};\\\", \\\"{x:1259,y:527,t:1527876880753};\\\", \\\"{x:1260,y:527,t:1527876880770};\\\", \\\"{x:1263,y:529,t:1527876880787};\\\", \\\"{x:1265,y:531,t:1527876880802};\\\", \\\"{x:1267,y:534,t:1527876880819};\\\", \\\"{x:1267,y:535,t:1527876880837};\\\", \\\"{x:1268,y:536,t:1527876880853};\\\", \\\"{x:1269,y:537,t:1527876880870};\\\", \\\"{x:1270,y:538,t:1527876880887};\\\", \\\"{x:1273,y:543,t:1527876880902};\\\", \\\"{x:1275,y:545,t:1527876880919};\\\", \\\"{x:1278,y:548,t:1527876880937};\\\", \\\"{x:1278,y:550,t:1527876880952};\\\", \\\"{x:1280,y:553,t:1527876880979};\\\", \\\"{x:1281,y:555,t:1527876880995};\\\", \\\"{x:1281,y:556,t:1527876881010};\\\", \\\"{x:1281,y:559,t:1527876881020};\\\", \\\"{x:1282,y:560,t:1527876881036};\\\", \\\"{x:1282,y:562,t:1527876881054};\\\", \\\"{x:1282,y:563,t:1527876881075};\\\", \\\"{x:1283,y:564,t:1527876881087};\\\", \\\"{x:1281,y:564,t:1527876881419};\\\", \\\"{x:1278,y:564,t:1527876881426};\\\", \\\"{x:1273,y:564,t:1527876881438};\\\", \\\"{x:1257,y:564,t:1527876881454};\\\", \\\"{x:1233,y:564,t:1527876881471};\\\", \\\"{x:1194,y:558,t:1527876881487};\\\", \\\"{x:1143,y:550,t:1527876881504};\\\", \\\"{x:1079,y:542,t:1527876881521};\\\", \\\"{x:1004,y:533,t:1527876881537};\\\", \\\"{x:939,y:521,t:1527876881553};\\\", \\\"{x:858,y:511,t:1527876881570};\\\", \\\"{x:810,y:505,t:1527876881587};\\\", \\\"{x:790,y:504,t:1527876881600};\\\", \\\"{x:760,y:499,t:1527876881618};\\\", \\\"{x:739,y:497,t:1527876881634};\\\", \\\"{x:718,y:493,t:1527876881650};\\\", \\\"{x:712,y:493,t:1527876881666};\\\", \\\"{x:708,y:492,t:1527876881686};\\\", \\\"{x:707,y:492,t:1527876881795};\\\", \\\"{x:705,y:491,t:1527876881811};\\\", \\\"{x:704,y:491,t:1527876881820};\\\", \\\"{x:699,y:490,t:1527876881836};\\\", \\\"{x:692,y:490,t:1527876881854};\\\", \\\"{x:678,y:490,t:1527876881871};\\\", \\\"{x:666,y:490,t:1527876881888};\\\", \\\"{x:653,y:490,t:1527876881904};\\\", \\\"{x:645,y:490,t:1527876881921};\\\", \\\"{x:639,y:490,t:1527876881937};\\\", \\\"{x:636,y:490,t:1527876881953};\\\", \\\"{x:634,y:490,t:1527876881970};\\\", \\\"{x:632,y:490,t:1527876882029};\\\", \\\"{x:631,y:490,t:1527876882036};\\\", \\\"{x:630,y:490,t:1527876882057};\\\", \\\"{x:629,y:491,t:1527876882070};\\\", \\\"{x:628,y:491,t:1527876882090};\\\", \\\"{x:627,y:492,t:1527876882122};\\\", \\\"{x:625,y:493,t:1527876882136};\\\", \\\"{x:615,y:497,t:1527876882154};\\\", \\\"{x:597,y:504,t:1527876882171};\\\", \\\"{x:590,y:507,t:1527876882186};\\\", \\\"{x:589,y:508,t:1527876882203};\\\", \\\"{x:588,y:508,t:1527876882220};\\\", \\\"{x:590,y:508,t:1527876882411};\\\", \\\"{x:592,y:507,t:1527876882418};\\\", \\\"{x:606,y:502,t:1527876882506};\\\", \\\"{x:606,y:501,t:1527876882520};\\\", \\\"{x:610,y:499,t:1527876882787};\\\", \\\"{x:611,y:499,t:1527876882804};\\\", \\\"{x:612,y:499,t:1527876882820};\\\", \\\"{x:613,y:499,t:1527876882955};\\\", \\\"{x:616,y:499,t:1527876882971};\\\", \\\"{x:622,y:509,t:1527876882988};\\\", \\\"{x:629,y:525,t:1527876883007};\\\", \\\"{x:634,y:537,t:1527876883021};\\\", \\\"{x:638,y:546,t:1527876883037};\\\", \\\"{x:643,y:557,t:1527876883054};\\\", \\\"{x:649,y:568,t:1527876883070};\\\", \\\"{x:657,y:585,t:1527876883087};\\\", \\\"{x:663,y:602,t:1527876883104};\\\", \\\"{x:668,y:611,t:1527876883120};\\\", \\\"{x:673,y:617,t:1527876883138};\\\", \\\"{x:673,y:618,t:1527876883153};\\\", \\\"{x:673,y:619,t:1527876883194};\\\", \\\"{x:673,y:620,t:1527876883204};\\\", \\\"{x:673,y:627,t:1527876883221};\\\", \\\"{x:673,y:648,t:1527876883238};\\\", \\\"{x:682,y:659,t:1527876883254};\\\", \\\"{x:685,y:663,t:1527876883271};\\\", \\\"{x:687,y:664,t:1527876883287};\\\", \\\"{x:688,y:664,t:1527876883867};\\\", \\\"{x:693,y:663,t:1527876883874};\\\", \\\"{x:696,y:662,t:1527876883889};\\\", \\\"{x:701,y:660,t:1527876883904};\\\", \\\"{x:713,y:654,t:1527876883922};\\\", \\\"{x:778,y:640,t:1527876883938};\\\", \\\"{x:847,y:619,t:1527876883956};\\\", \\\"{x:943,y:599,t:1527876883972};\\\", \\\"{x:1042,y:577,t:1527876883988};\\\", \\\"{x:1135,y:558,t:1527876884005};\\\", \\\"{x:1219,y:541,t:1527876884021};\\\", \\\"{x:1279,y:528,t:1527876884039};\\\", \\\"{x:1319,y:515,t:1527876884055};\\\", \\\"{x:1347,y:507,t:1527876884071};\\\", \\\"{x:1370,y:499,t:1527876884088};\\\", \\\"{x:1379,y:495,t:1527876884106};\\\", \\\"{x:1379,y:494,t:1527876884121};\\\", \\\"{x:1378,y:494,t:1527876884252};\\\", \\\"{x:1375,y:494,t:1527876884259};\\\", \\\"{x:1372,y:496,t:1527876884273};\\\", \\\"{x:1362,y:501,t:1527876884289};\\\", \\\"{x:1356,y:504,t:1527876884306};\\\", \\\"{x:1346,y:508,t:1527876884323};\\\", \\\"{x:1339,y:512,t:1527876884339};\\\", \\\"{x:1333,y:517,t:1527876884356};\\\", \\\"{x:1329,y:520,t:1527876884373};\\\", \\\"{x:1327,y:522,t:1527876884389};\\\", \\\"{x:1322,y:525,t:1527876884406};\\\", \\\"{x:1315,y:531,t:1527876884423};\\\", \\\"{x:1310,y:534,t:1527876884439};\\\", \\\"{x:1305,y:538,t:1527876884455};\\\", \\\"{x:1303,y:539,t:1527876884473};\\\", \\\"{x:1301,y:540,t:1527876884498};\\\", \\\"{x:1301,y:541,t:1527876884506};\\\", \\\"{x:1297,y:544,t:1527876884523};\\\", \\\"{x:1293,y:548,t:1527876884539};\\\", \\\"{x:1287,y:553,t:1527876884555};\\\", \\\"{x:1283,y:556,t:1527876884573};\\\", \\\"{x:1282,y:556,t:1527876884588};\\\", \\\"{x:1281,y:558,t:1527876884651};\\\", \\\"{x:1279,y:560,t:1527876884672};\\\", \\\"{x:1278,y:562,t:1527876884690};\\\", \\\"{x:1279,y:562,t:1527876884859};\\\", \\\"{x:1281,y:562,t:1527876884875};\\\", \\\"{x:1283,y:561,t:1527876884890};\\\", \\\"{x:1285,y:561,t:1527876884906};\\\", \\\"{x:1289,y:558,t:1527876884923};\\\", \\\"{x:1293,y:556,t:1527876884940};\\\", \\\"{x:1296,y:555,t:1527876884956};\\\", \\\"{x:1298,y:554,t:1527876884973};\\\", \\\"{x:1300,y:553,t:1527876884990};\\\", \\\"{x:1302,y:553,t:1527876885010};\\\", \\\"{x:1303,y:553,t:1527876885022};\\\", \\\"{x:1312,y:553,t:1527876885040};\\\", \\\"{x:1327,y:553,t:1527876885057};\\\", \\\"{x:1335,y:551,t:1527876885073};\\\", \\\"{x:1345,y:550,t:1527876885090};\\\", \\\"{x:1356,y:550,t:1527876885107};\\\", \\\"{x:1359,y:550,t:1527876885123};\\\", \\\"{x:1360,y:550,t:1527876885140};\\\", \\\"{x:1362,y:550,t:1527876885157};\\\", \\\"{x:1363,y:549,t:1527876885173};\\\", \\\"{x:1364,y:549,t:1527876885211};\\\", \\\"{x:1365,y:549,t:1527876885227};\\\", \\\"{x:1366,y:549,t:1527876885240};\\\", \\\"{x:1370,y:549,t:1527876885257};\\\", \\\"{x:1378,y:549,t:1527876885273};\\\", \\\"{x:1385,y:549,t:1527876885291};\\\", \\\"{x:1392,y:549,t:1527876885307};\\\", \\\"{x:1395,y:549,t:1527876885323};\\\", \\\"{x:1396,y:549,t:1527876885346};\\\", \\\"{x:1397,y:550,t:1527876885491};\\\", \\\"{x:1398,y:550,t:1527876885514};\\\", \\\"{x:1398,y:551,t:1527876885579};\\\", \\\"{x:1398,y:552,t:1527876885595};\\\", \\\"{x:1398,y:553,t:1527876885607};\\\", \\\"{x:1399,y:555,t:1527876885667};\\\", \\\"{x:1399,y:556,t:1527876885683};\\\", \\\"{x:1399,y:557,t:1527876885699};\\\", \\\"{x:1400,y:558,t:1527876885715};\\\", \\\"{x:1400,y:559,t:1527876885731};\\\", \\\"{x:1400,y:560,t:1527876885746};\\\", \\\"{x:1400,y:559,t:1527876887330};\\\", \\\"{x:1399,y:559,t:1527876887483};\\\", \\\"{x:1396,y:559,t:1527876887492};\\\", \\\"{x:1388,y:559,t:1527876887509};\\\", \\\"{x:1371,y:559,t:1527876887525};\\\", \\\"{x:1347,y:559,t:1527876887542};\\\", \\\"{x:1317,y:559,t:1527876887559};\\\", \\\"{x:1286,y:559,t:1527876887575};\\\", \\\"{x:1241,y:559,t:1527876887592};\\\", \\\"{x:1161,y:559,t:1527876887609};\\\", \\\"{x:1108,y:559,t:1527876887625};\\\", \\\"{x:1068,y:559,t:1527876887642};\\\", \\\"{x:1028,y:559,t:1527876887657};\\\", \\\"{x:1007,y:559,t:1527876887675};\\\", \\\"{x:992,y:559,t:1527876887692};\\\", \\\"{x:977,y:559,t:1527876887708};\\\", \\\"{x:962,y:559,t:1527876887725};\\\", \\\"{x:946,y:559,t:1527876887741};\\\", \\\"{x:933,y:559,t:1527876887759};\\\", \\\"{x:921,y:559,t:1527876887775};\\\", \\\"{x:909,y:561,t:1527876887792};\\\", \\\"{x:898,y:561,t:1527876887809};\\\", \\\"{x:887,y:561,t:1527876887826};\\\", \\\"{x:871,y:562,t:1527876887842};\\\", \\\"{x:855,y:562,t:1527876887858};\\\", \\\"{x:851,y:562,t:1527876887876};\\\", \\\"{x:850,y:562,t:1527876887892};\\\", \\\"{x:849,y:562,t:1527876887930};\\\", \\\"{x:847,y:564,t:1527876887943};\\\", \\\"{x:842,y:565,t:1527876887959};\\\", \\\"{x:827,y:565,t:1527876887976};\\\", \\\"{x:815,y:565,t:1527876887991};\\\", \\\"{x:807,y:565,t:1527876888009};\\\", \\\"{x:793,y:565,t:1527876888024};\\\", \\\"{x:781,y:565,t:1527876888041};\\\", \\\"{x:768,y:565,t:1527876888058};\\\", \\\"{x:759,y:565,t:1527876888074};\\\", \\\"{x:755,y:565,t:1527876888091};\\\", \\\"{x:751,y:565,t:1527876888108};\\\", \\\"{x:746,y:565,t:1527876888124};\\\", \\\"{x:734,y:565,t:1527876888142};\\\", \\\"{x:726,y:565,t:1527876888159};\\\", \\\"{x:715,y:565,t:1527876888176};\\\", \\\"{x:697,y:565,t:1527876888192};\\\", \\\"{x:681,y:565,t:1527876888208};\\\", \\\"{x:657,y:561,t:1527876888225};\\\", \\\"{x:644,y:559,t:1527876888242};\\\", \\\"{x:618,y:554,t:1527876888258};\\\", \\\"{x:616,y:553,t:1527876888276};\\\", \\\"{x:606,y:550,t:1527876888292};\\\", \\\"{x:601,y:550,t:1527876888309};\\\", \\\"{x:600,y:550,t:1527876888324};\\\", \\\"{x:599,y:550,t:1527876888363};\\\", \\\"{x:600,y:549,t:1527876888377};\\\", \\\"{x:606,y:546,t:1527876888391};\\\", \\\"{x:609,y:545,t:1527876888408};\\\", \\\"{x:613,y:544,t:1527876888425};\\\", \\\"{x:618,y:541,t:1527876888441};\\\", \\\"{x:625,y:537,t:1527876888459};\\\", \\\"{x:631,y:535,t:1527876888475};\\\", \\\"{x:637,y:532,t:1527876888491};\\\", \\\"{x:639,y:530,t:1527876888508};\\\", \\\"{x:639,y:529,t:1527876888562};\\\", \\\"{x:637,y:529,t:1527876888575};\\\", \\\"{x:629,y:528,t:1527876888591};\\\", \\\"{x:625,y:527,t:1527876888609};\\\", \\\"{x:615,y:527,t:1527876888626};\\\", \\\"{x:600,y:527,t:1527876888642};\\\", \\\"{x:579,y:527,t:1527876888659};\\\", \\\"{x:572,y:527,t:1527876888676};\\\", \\\"{x:569,y:526,t:1527876888692};\\\", \\\"{x:564,y:525,t:1527876888709};\\\", \\\"{x:556,y:528,t:1527876888726};\\\", \\\"{x:545,y:529,t:1527876888743};\\\", \\\"{x:537,y:536,t:1527876888758};\\\", \\\"{x:523,y:541,t:1527876888776};\\\", \\\"{x:507,y:543,t:1527876888793};\\\", \\\"{x:505,y:544,t:1527876888809};\\\", \\\"{x:502,y:545,t:1527876888826};\\\", \\\"{x:490,y:546,t:1527876888844};\\\", \\\"{x:483,y:548,t:1527876888858};\\\", \\\"{x:474,y:548,t:1527876888876};\\\", \\\"{x:465,y:550,t:1527876888893};\\\", \\\"{x:455,y:551,t:1527876888908};\\\", \\\"{x:447,y:554,t:1527876888926};\\\", \\\"{x:431,y:557,t:1527876888943};\\\", \\\"{x:410,y:560,t:1527876888958};\\\", \\\"{x:386,y:565,t:1527876888976};\\\", \\\"{x:363,y:567,t:1527876888992};\\\", \\\"{x:337,y:572,t:1527876889009};\\\", \\\"{x:314,y:573,t:1527876889026};\\\", \\\"{x:292,y:577,t:1527876889042};\\\", \\\"{x:280,y:579,t:1527876889059};\\\", \\\"{x:261,y:583,t:1527876889077};\\\", \\\"{x:239,y:589,t:1527876889092};\\\", \\\"{x:217,y:594,t:1527876889110};\\\", \\\"{x:198,y:597,t:1527876889126};\\\", \\\"{x:182,y:599,t:1527876889142};\\\", \\\"{x:170,y:600,t:1527876889159};\\\", \\\"{x:156,y:603,t:1527876889176};\\\", \\\"{x:148,y:604,t:1527876889193};\\\", \\\"{x:141,y:605,t:1527876889210};\\\", \\\"{x:135,y:607,t:1527876889225};\\\", \\\"{x:132,y:608,t:1527876889243};\\\", \\\"{x:132,y:609,t:1527876889305};\\\", \\\"{x:132,y:610,t:1527876889321};\\\", \\\"{x:132,y:611,t:1527876889330};\\\", \\\"{x:132,y:613,t:1527876889343};\\\", \\\"{x:132,y:616,t:1527876889359};\\\", \\\"{x:131,y:618,t:1527876889379};\\\", \\\"{x:131,y:619,t:1527876889396};\\\", \\\"{x:132,y:624,t:1527876889412};\\\", \\\"{x:136,y:628,t:1527876889429};\\\", \\\"{x:142,y:632,t:1527876889447};\\\", \\\"{x:149,y:636,t:1527876889462};\\\", \\\"{x:156,y:637,t:1527876889478};\\\", \\\"{x:173,y:638,t:1527876889495};\\\", \\\"{x:196,y:640,t:1527876889513};\\\", \\\"{x:225,y:640,t:1527876889528};\\\", \\\"{x:251,y:640,t:1527876889545};\\\", \\\"{x:275,y:640,t:1527876889563};\\\", \\\"{x:303,y:638,t:1527876889580};\\\", \\\"{x:333,y:633,t:1527876889596};\\\", \\\"{x:449,y:615,t:1527876889613};\\\", \\\"{x:552,y:597,t:1527876889629};\\\", \\\"{x:675,y:575,t:1527876889646};\\\", \\\"{x:778,y:557,t:1527876889663};\\\", \\\"{x:869,y:535,t:1527876889680};\\\", \\\"{x:948,y:521,t:1527876889696};\\\", \\\"{x:1004,y:503,t:1527876889713};\\\", \\\"{x:1036,y:494,t:1527876889730};\\\", \\\"{x:1055,y:488,t:1527876889746};\\\", \\\"{x:1060,y:487,t:1527876889763};\\\", \\\"{x:1062,y:485,t:1527876889780};\\\", \\\"{x:1063,y:485,t:1527876889871};\\\", \\\"{x:1062,y:486,t:1527876889881};\\\", \\\"{x:1054,y:490,t:1527876889897};\\\", \\\"{x:1044,y:495,t:1527876889914};\\\", \\\"{x:1036,y:496,t:1527876889930};\\\", \\\"{x:1021,y:498,t:1527876889947};\\\", \\\"{x:1003,y:502,t:1527876889964};\\\", \\\"{x:982,y:506,t:1527876889981};\\\", \\\"{x:958,y:513,t:1527876889997};\\\", \\\"{x:929,y:522,t:1527876890014};\\\", \\\"{x:906,y:528,t:1527876890032};\\\", \\\"{x:881,y:532,t:1527876890048};\\\", \\\"{x:862,y:534,t:1527876890062};\\\", \\\"{x:848,y:536,t:1527876890078};\\\", \\\"{x:843,y:538,t:1527876890096};\\\", \\\"{x:842,y:539,t:1527876890113};\\\", \\\"{x:841,y:539,t:1527876890130};\\\", \\\"{x:839,y:539,t:1527876890147};\\\", \\\"{x:832,y:541,t:1527876890162};\\\", \\\"{x:828,y:543,t:1527876890180};\\\", \\\"{x:827,y:543,t:1527876890197};\\\", \\\"{x:830,y:543,t:1527876890245};\\\", \\\"{x:831,y:542,t:1527876890262};\\\", \\\"{x:832,y:542,t:1527876890277};\\\", \\\"{x:835,y:541,t:1527876890294};\\\", \\\"{x:836,y:541,t:1527876890613};\\\", \\\"{x:832,y:541,t:1527876890717};\\\", \\\"{x:827,y:541,t:1527876890729};\\\", \\\"{x:815,y:549,t:1527876890747};\\\", \\\"{x:793,y:561,t:1527876890764};\\\", \\\"{x:760,y:573,t:1527876890780};\\\", \\\"{x:709,y:589,t:1527876890797};\\\", \\\"{x:678,y:604,t:1527876890814};\\\", \\\"{x:652,y:618,t:1527876890831};\\\", \\\"{x:628,y:627,t:1527876890847};\\\", \\\"{x:603,y:635,t:1527876890864};\\\", \\\"{x:586,y:640,t:1527876890879};\\\", \\\"{x:569,y:647,t:1527876890897};\\\", \\\"{x:549,y:653,t:1527876890914};\\\", \\\"{x:535,y:662,t:1527876890931};\\\", \\\"{x:521,y:672,t:1527876890947};\\\", \\\"{x:510,y:686,t:1527876890964};\\\", \\\"{x:494,y:714,t:1527876890982};\\\", \\\"{x:486,y:734,t:1527876890997};\\\", \\\"{x:481,y:753,t:1527876891013};\\\", \\\"{x:477,y:764,t:1527876891032};\\\", \\\"{x:476,y:767,t:1527876891046};\\\", \\\"{x:476,y:768,t:1527876891063};\\\", \\\"{x:476,y:771,t:1527876891080};\\\", \\\"{x:474,y:773,t:1527876891096};\\\", \\\"{x:474,y:774,t:1527876891125};\\\", \\\"{x:474,y:776,t:1527876891141};\\\", \\\"{x:474,y:777,t:1527876891278};\\\", \\\"{x:476,y:777,t:1527876891294};\\\", \\\"{x:477,y:777,t:1527876891301};\\\", \\\"{x:479,y:777,t:1527876891314};\\\", \\\"{x:480,y:776,t:1527876891332};\\\", \\\"{x:481,y:775,t:1527876891347};\\\", \\\"{x:481,y:773,t:1527876891374};\\\", \\\"{x:482,y:772,t:1527876891381};\\\", \\\"{x:482,y:771,t:1527876891398};\\\", \\\"{x:484,y:768,t:1527876891414};\\\", \\\"{x:485,y:766,t:1527876891438};\\\", \\\"{x:485,y:764,t:1527876891462};\\\", \\\"{x:486,y:763,t:1527876891470};\\\", \\\"{x:487,y:763,t:1527876891482};\\\", \\\"{x:487,y:761,t:1527876891497};\\\", \\\"{x:487,y:760,t:1527876891526};\\\", \\\"{x:487,y:758,t:1527876891542};\\\", \\\"{x:488,y:757,t:1527876891550};\\\", \\\"{x:488,y:756,t:1527876891565};\\\", \\\"{x:489,y:751,t:1527876891583};\\\", \\\"{x:490,y:750,t:1527876891597};\\\", \\\"{x:490,y:747,t:1527876891615};\\\", \\\"{x:491,y:745,t:1527876891631};\\\", \\\"{x:493,y:743,t:1527876891648};\\\", \\\"{x:494,y:740,t:1527876891665};\\\", \\\"{x:496,y:737,t:1527876891680};\\\", \\\"{x:500,y:732,t:1527876891698};\\\", \\\"{x:503,y:729,t:1527876891715};\\\", \\\"{x:503,y:728,t:1527876891731};\\\" ] }, { \\\"rt\\\": 35607, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 519486, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:723,t:1527876896527};\\\", \\\"{x:503,y:705,t:1527876896545};\\\", \\\"{x:500,y:692,t:1527876896560};\\\", \\\"{x:491,y:665,t:1527876896577};\\\", \\\"{x:423,y:563,t:1527876896602};\\\", \\\"{x:394,y:537,t:1527876896618};\\\", \\\"{x:341,y:512,t:1527876896636};\\\", \\\"{x:297,y:494,t:1527876896652};\\\", \\\"{x:262,y:473,t:1527876896669};\\\", \\\"{x:203,y:425,t:1527876896685};\\\", \\\"{x:167,y:391,t:1527876896702};\\\", \\\"{x:149,y:374,t:1527876896719};\\\", \\\"{x:138,y:366,t:1527876896735};\\\", \\\"{x:132,y:362,t:1527876896752};\\\", \\\"{x:129,y:358,t:1527876896770};\\\", \\\"{x:129,y:357,t:1527876896789};\\\", \\\"{x:128,y:356,t:1527876896802};\\\", \\\"{x:129,y:353,t:1527876896918};\\\", \\\"{x:130,y:352,t:1527876896926};\\\", \\\"{x:132,y:352,t:1527876896937};\\\", \\\"{x:137,y:350,t:1527876896953};\\\", \\\"{x:140,y:349,t:1527876896969};\\\", \\\"{x:142,y:348,t:1527876896986};\\\", \\\"{x:147,y:345,t:1527876897003};\\\", \\\"{x:158,y:340,t:1527876897019};\\\", \\\"{x:171,y:335,t:1527876897037};\\\", \\\"{x:192,y:325,t:1527876897053};\\\", \\\"{x:202,y:321,t:1527876897069};\\\", \\\"{x:208,y:319,t:1527876897086};\\\", \\\"{x:211,y:317,t:1527876897103};\\\", \\\"{x:213,y:316,t:1527876897119};\\\", \\\"{x:214,y:316,t:1527876897136};\\\", \\\"{x:215,y:316,t:1527876897153};\\\", \\\"{x:216,y:316,t:1527876897170};\\\", \\\"{x:218,y:316,t:1527876897186};\\\", \\\"{x:224,y:318,t:1527876897203};\\\", \\\"{x:235,y:325,t:1527876897220};\\\", \\\"{x:247,y:331,t:1527876897236};\\\", \\\"{x:264,y:340,t:1527876897254};\\\", \\\"{x:268,y:342,t:1527876897270};\\\", \\\"{x:271,y:343,t:1527876897286};\\\", \\\"{x:272,y:343,t:1527876897304};\\\", \\\"{x:272,y:344,t:1527876897334};\\\", \\\"{x:274,y:345,t:1527876897342};\\\", \\\"{x:275,y:347,t:1527876897354};\\\", \\\"{x:279,y:350,t:1527876897370};\\\", \\\"{x:286,y:354,t:1527876897388};\\\", \\\"{x:291,y:357,t:1527876897404};\\\", \\\"{x:297,y:361,t:1527876897421};\\\", \\\"{x:304,y:364,t:1527876897438};\\\", \\\"{x:308,y:367,t:1527876897454};\\\", \\\"{x:313,y:370,t:1527876897471};\\\", \\\"{x:319,y:374,t:1527876897487};\\\", \\\"{x:327,y:378,t:1527876897505};\\\", \\\"{x:338,y:384,t:1527876897521};\\\", \\\"{x:353,y:392,t:1527876897538};\\\", \\\"{x:362,y:397,t:1527876897555};\\\", \\\"{x:372,y:403,t:1527876897570};\\\", \\\"{x:381,y:408,t:1527876897587};\\\", \\\"{x:386,y:411,t:1527876897605};\\\", \\\"{x:389,y:413,t:1527876897621};\\\", \\\"{x:390,y:415,t:1527876897637};\\\", \\\"{x:390,y:416,t:1527876897662};\\\", \\\"{x:390,y:417,t:1527876897671};\\\", \\\"{x:390,y:419,t:1527876897687};\\\", \\\"{x:390,y:420,t:1527876897705};\\\", \\\"{x:390,y:422,t:1527876897722};\\\", \\\"{x:390,y:424,t:1527876897739};\\\", \\\"{x:390,y:425,t:1527876897755};\\\", \\\"{x:390,y:429,t:1527876897772};\\\", \\\"{x:390,y:431,t:1527876897789};\\\", \\\"{x:387,y:433,t:1527876897805};\\\", \\\"{x:383,y:437,t:1527876897822};\\\", \\\"{x:380,y:440,t:1527876897839};\\\", \\\"{x:378,y:442,t:1527876897855};\\\", \\\"{x:375,y:444,t:1527876897871};\\\", \\\"{x:374,y:445,t:1527876897888};\\\", \\\"{x:371,y:448,t:1527876897906};\\\", \\\"{x:367,y:451,t:1527876897922};\\\", \\\"{x:364,y:452,t:1527876897939};\\\", \\\"{x:360,y:455,t:1527876897955};\\\", \\\"{x:359,y:456,t:1527876897974};\\\", \\\"{x:358,y:457,t:1527876897998};\\\", \\\"{x:357,y:457,t:1527876898013};\\\", \\\"{x:356,y:458,t:1527876898030};\\\", \\\"{x:355,y:458,t:1527876898045};\\\", \\\"{x:354,y:459,t:1527876898056};\\\", \\\"{x:352,y:460,t:1527876898073};\\\", \\\"{x:352,y:461,t:1527876898093};\\\", \\\"{x:353,y:461,t:1527876898478};\\\", \\\"{x:354,y:461,t:1527876898494};\\\", \\\"{x:355,y:460,t:1527876898509};\\\", \\\"{x:357,y:459,t:1527876898541};\\\", \\\"{x:359,y:458,t:1527876898557};\\\", \\\"{x:365,y:456,t:1527876898574};\\\", \\\"{x:366,y:456,t:1527876898590};\\\", \\\"{x:366,y:455,t:1527876898646};\\\", \\\"{x:368,y:455,t:1527876898656};\\\", \\\"{x:375,y:452,t:1527876898674};\\\", \\\"{x:387,y:449,t:1527876898691};\\\", \\\"{x:398,y:448,t:1527876898707};\\\", \\\"{x:408,y:445,t:1527876898723};\\\", \\\"{x:417,y:444,t:1527876898741};\\\", \\\"{x:430,y:443,t:1527876898757};\\\", \\\"{x:446,y:441,t:1527876898773};\\\", \\\"{x:461,y:441,t:1527876898791};\\\", \\\"{x:471,y:441,t:1527876898807};\\\", \\\"{x:479,y:441,t:1527876898824};\\\", \\\"{x:489,y:441,t:1527876898841};\\\", \\\"{x:497,y:441,t:1527876898858};\\\", \\\"{x:506,y:444,t:1527876898875};\\\", \\\"{x:511,y:446,t:1527876898891};\\\", \\\"{x:516,y:446,t:1527876898908};\\\", \\\"{x:517,y:446,t:1527876898982};\\\", \\\"{x:521,y:446,t:1527876898991};\\\", \\\"{x:528,y:446,t:1527876899008};\\\", \\\"{x:533,y:448,t:1527876899025};\\\", \\\"{x:538,y:448,t:1527876899042};\\\", \\\"{x:540,y:448,t:1527876899058};\\\", \\\"{x:542,y:448,t:1527876899075};\\\", \\\"{x:543,y:448,t:1527876899101};\\\", \\\"{x:544,y:448,t:1527876899206};\\\", \\\"{x:545,y:449,t:1527876899221};\\\", \\\"{x:547,y:449,t:1527876899245};\\\", \\\"{x:549,y:449,t:1527876899258};\\\", \\\"{x:553,y:449,t:1527876899275};\\\", \\\"{x:558,y:450,t:1527876899291};\\\", \\\"{x:563,y:452,t:1527876899308};\\\", \\\"{x:564,y:452,t:1527876899325};\\\", \\\"{x:565,y:452,t:1527876899453};\\\", \\\"{x:566,y:452,t:1527876899461};\\\", \\\"{x:568,y:452,t:1527876899476};\\\", \\\"{x:570,y:452,t:1527876899492};\\\", \\\"{x:574,y:453,t:1527876899510};\\\", \\\"{x:575,y:453,t:1527876900270};\\\", \\\"{x:577,y:453,t:1527876900278};\\\", \\\"{x:581,y:452,t:1527876900295};\\\", \\\"{x:591,y:452,t:1527876900310};\\\", \\\"{x:597,y:452,t:1527876900328};\\\", \\\"{x:601,y:452,t:1527876900344};\\\", \\\"{x:605,y:452,t:1527876900362};\\\", \\\"{x:609,y:452,t:1527876900378};\\\", \\\"{x:615,y:451,t:1527876900394};\\\", \\\"{x:626,y:448,t:1527876900412};\\\", \\\"{x:637,y:447,t:1527876900428};\\\", \\\"{x:655,y:445,t:1527876900445};\\\", \\\"{x:688,y:442,t:1527876900461};\\\", \\\"{x:715,y:439,t:1527876900478};\\\", \\\"{x:744,y:435,t:1527876900495};\\\", \\\"{x:769,y:434,t:1527876900512};\\\", \\\"{x:791,y:430,t:1527876900529};\\\", \\\"{x:812,y:428,t:1527876900545};\\\", \\\"{x:832,y:425,t:1527876900561};\\\", \\\"{x:855,y:420,t:1527876900578};\\\", \\\"{x:878,y:418,t:1527876900595};\\\", \\\"{x:900,y:415,t:1527876900612};\\\", \\\"{x:925,y:413,t:1527876900628};\\\", \\\"{x:973,y:411,t:1527876900646};\\\", \\\"{x:1011,y:411,t:1527876900662};\\\", \\\"{x:1052,y:411,t:1527876900678};\\\", \\\"{x:1088,y:413,t:1527876900696};\\\", \\\"{x:1130,y:420,t:1527876900712};\\\", \\\"{x:1192,y:439,t:1527876900729};\\\", \\\"{x:1244,y:451,t:1527876900746};\\\", \\\"{x:1280,y:459,t:1527876900763};\\\", \\\"{x:1319,y:465,t:1527876900779};\\\", \\\"{x:1367,y:472,t:1527876900796};\\\", \\\"{x:1404,y:479,t:1527876900813};\\\", \\\"{x:1434,y:483,t:1527876900829};\\\", \\\"{x:1465,y:485,t:1527876900846};\\\", \\\"{x:1476,y:485,t:1527876900863};\\\", \\\"{x:1481,y:486,t:1527876900879};\\\", \\\"{x:1481,y:487,t:1527876901095};\\\", \\\"{x:1481,y:489,t:1527876901102};\\\", \\\"{x:1479,y:492,t:1527876901113};\\\", \\\"{x:1475,y:497,t:1527876901130};\\\", \\\"{x:1471,y:501,t:1527876901147};\\\", \\\"{x:1467,y:508,t:1527876901163};\\\", \\\"{x:1463,y:513,t:1527876901180};\\\", \\\"{x:1459,y:519,t:1527876901197};\\\", \\\"{x:1452,y:529,t:1527876901215};\\\", \\\"{x:1447,y:537,t:1527876901230};\\\", \\\"{x:1442,y:542,t:1527876901247};\\\", \\\"{x:1435,y:550,t:1527876901264};\\\", \\\"{x:1425,y:560,t:1527876901280};\\\", \\\"{x:1420,y:567,t:1527876901297};\\\", \\\"{x:1412,y:578,t:1527876901314};\\\", \\\"{x:1407,y:585,t:1527876901331};\\\", \\\"{x:1406,y:590,t:1527876901348};\\\", \\\"{x:1404,y:593,t:1527876901364};\\\", \\\"{x:1404,y:599,t:1527876901380};\\\", \\\"{x:1404,y:611,t:1527876901396};\\\", \\\"{x:1404,y:627,t:1527876901413};\\\", \\\"{x:1404,y:633,t:1527876901430};\\\", \\\"{x:1404,y:635,t:1527876901447};\\\", \\\"{x:1404,y:637,t:1527876901463};\\\", \\\"{x:1404,y:638,t:1527876901509};\\\", \\\"{x:1404,y:640,t:1527876901558};\\\", \\\"{x:1404,y:641,t:1527876901565};\\\", \\\"{x:1404,y:642,t:1527876901581};\\\", \\\"{x:1402,y:644,t:1527876901598};\\\", \\\"{x:1401,y:647,t:1527876901615};\\\", \\\"{x:1403,y:646,t:1527876901798};\\\", \\\"{x:1409,y:643,t:1527876901815};\\\", \\\"{x:1410,y:643,t:1527876901832};\\\", \\\"{x:1412,y:642,t:1527876901848};\\\", \\\"{x:1413,y:642,t:1527876901910};\\\", \\\"{x:1415,y:642,t:1527876901918};\\\", \\\"{x:1417,y:642,t:1527876901932};\\\", \\\"{x:1418,y:641,t:1527876901949};\\\", \\\"{x:1419,y:640,t:1527876902070};\\\", \\\"{x:1422,y:639,t:1527876902086};\\\", \\\"{x:1425,y:638,t:1527876902102};\\\", \\\"{x:1427,y:638,t:1527876902118};\\\", \\\"{x:1427,y:637,t:1527876902133};\\\", \\\"{x:1430,y:636,t:1527876902149};\\\", \\\"{x:1433,y:635,t:1527876902165};\\\", \\\"{x:1435,y:633,t:1527876902183};\\\", \\\"{x:1436,y:632,t:1527876902199};\\\", \\\"{x:1438,y:632,t:1527876902216};\\\", \\\"{x:1440,y:630,t:1527876902233};\\\", \\\"{x:1440,y:631,t:1527876902399};\\\", \\\"{x:1440,y:634,t:1527876902406};\\\", \\\"{x:1438,y:638,t:1527876902417};\\\", \\\"{x:1436,y:648,t:1527876902433};\\\", \\\"{x:1434,y:656,t:1527876902450};\\\", \\\"{x:1431,y:664,t:1527876902467};\\\", \\\"{x:1428,y:669,t:1527876902483};\\\", \\\"{x:1424,y:673,t:1527876902500};\\\", \\\"{x:1420,y:675,t:1527876902517};\\\", \\\"{x:1413,y:677,t:1527876902533};\\\", \\\"{x:1402,y:683,t:1527876902550};\\\", \\\"{x:1394,y:686,t:1527876902567};\\\", \\\"{x:1389,y:688,t:1527876902584};\\\", \\\"{x:1383,y:690,t:1527876902601};\\\", \\\"{x:1380,y:691,t:1527876902617};\\\", \\\"{x:1376,y:691,t:1527876902634};\\\", \\\"{x:1369,y:692,t:1527876902651};\\\", \\\"{x:1361,y:693,t:1527876902667};\\\", \\\"{x:1358,y:693,t:1527876902684};\\\", \\\"{x:1357,y:693,t:1527876902701};\\\", \\\"{x:1355,y:693,t:1527876902718};\\\", \\\"{x:1354,y:693,t:1527876902734};\\\", \\\"{x:1354,y:694,t:1527876902752};\\\", \\\"{x:1352,y:694,t:1527876902777};\\\", \\\"{x:1351,y:694,t:1527876902800};\\\", \\\"{x:1348,y:694,t:1527876902818};\\\", \\\"{x:1347,y:694,t:1527876902837};\\\", \\\"{x:1346,y:694,t:1527876902851};\\\", \\\"{x:1345,y:696,t:1527876902933};\\\", \\\"{x:1344,y:696,t:1527876902951};\\\", \\\"{x:1342,y:697,t:1527876902973};\\\", \\\"{x:1343,y:697,t:1527876903478};\\\", \\\"{x:1345,y:696,t:1527876903501};\\\", \\\"{x:1348,y:695,t:1527876903519};\\\", \\\"{x:1348,y:694,t:1527876906198};\\\", \\\"{x:1348,y:693,t:1527876906209};\\\", \\\"{x:1348,y:691,t:1527876906227};\\\", \\\"{x:1348,y:690,t:1527876906241};\\\", \\\"{x:1348,y:689,t:1527876906259};\\\", \\\"{x:1348,y:691,t:1527876907502};\\\", \\\"{x:1347,y:690,t:1527876908038};\\\", \\\"{x:1346,y:687,t:1527876908047};\\\", \\\"{x:1346,y:683,t:1527876908064};\\\", \\\"{x:1346,y:679,t:1527876908081};\\\", \\\"{x:1346,y:674,t:1527876908098};\\\", \\\"{x:1346,y:668,t:1527876908114};\\\", \\\"{x:1348,y:664,t:1527876908131};\\\", \\\"{x:1348,y:662,t:1527876908148};\\\", \\\"{x:1348,y:660,t:1527876908165};\\\", \\\"{x:1348,y:659,t:1527876908182};\\\", \\\"{x:1348,y:657,t:1527876908197};\\\", \\\"{x:1348,y:656,t:1527876908215};\\\", \\\"{x:1348,y:654,t:1527876908232};\\\", \\\"{x:1348,y:652,t:1527876908248};\\\", \\\"{x:1347,y:650,t:1527876908265};\\\", \\\"{x:1347,y:649,t:1527876908310};\\\", \\\"{x:1347,y:648,t:1527876908326};\\\", \\\"{x:1347,y:646,t:1527876908342};\\\", \\\"{x:1349,y:645,t:1527876908350};\\\", \\\"{x:1351,y:644,t:1527876908364};\\\", \\\"{x:1358,y:641,t:1527876908382};\\\", \\\"{x:1360,y:640,t:1527876908398};\\\", \\\"{x:1362,y:640,t:1527876908415};\\\", \\\"{x:1363,y:639,t:1527876908438};\\\", \\\"{x:1366,y:638,t:1527876908462};\\\", \\\"{x:1368,y:637,t:1527876908478};\\\", \\\"{x:1370,y:637,t:1527876908485};\\\", \\\"{x:1376,y:637,t:1527876908499};\\\", \\\"{x:1390,y:638,t:1527876908516};\\\", \\\"{x:1405,y:642,t:1527876908531};\\\", \\\"{x:1426,y:645,t:1527876908549};\\\", \\\"{x:1450,y:649,t:1527876908565};\\\", \\\"{x:1485,y:649,t:1527876908582};\\\", \\\"{x:1507,y:649,t:1527876908599};\\\", \\\"{x:1523,y:648,t:1527876908616};\\\", \\\"{x:1541,y:648,t:1527876908632};\\\", \\\"{x:1553,y:646,t:1527876908649};\\\", \\\"{x:1566,y:646,t:1527876908665};\\\", \\\"{x:1580,y:646,t:1527876908682};\\\", \\\"{x:1593,y:648,t:1527876908699};\\\", \\\"{x:1602,y:648,t:1527876908716};\\\", \\\"{x:1610,y:649,t:1527876908733};\\\", \\\"{x:1620,y:650,t:1527876908750};\\\", \\\"{x:1625,y:653,t:1527876908766};\\\", \\\"{x:1627,y:653,t:1527876908783};\\\", \\\"{x:1629,y:654,t:1527876908800};\\\", \\\"{x:1629,y:655,t:1527876908894};\\\", \\\"{x:1629,y:656,t:1527876908902};\\\", \\\"{x:1628,y:657,t:1527876908917};\\\", \\\"{x:1627,y:657,t:1527876908933};\\\", \\\"{x:1623,y:664,t:1527876908949};\\\", \\\"{x:1622,y:668,t:1527876908966};\\\", \\\"{x:1622,y:671,t:1527876908983};\\\", \\\"{x:1620,y:677,t:1527876909000};\\\", \\\"{x:1619,y:682,t:1527876909017};\\\", \\\"{x:1618,y:687,t:1527876909033};\\\", \\\"{x:1618,y:692,t:1527876909050};\\\", \\\"{x:1618,y:696,t:1527876909066};\\\", \\\"{x:1618,y:697,t:1527876909083};\\\", \\\"{x:1618,y:699,t:1527876909099};\\\", \\\"{x:1618,y:700,t:1527876909117};\\\", \\\"{x:1617,y:700,t:1527876911237};\\\", \\\"{x:1616,y:701,t:1527876911911};\\\", \\\"{x:1614,y:702,t:1527876911924};\\\", \\\"{x:1613,y:702,t:1527876911942};\\\", \\\"{x:1612,y:703,t:1527876911959};\\\", \\\"{x:1611,y:703,t:1527876912006};\\\", \\\"{x:1609,y:704,t:1527876912024};\\\", \\\"{x:1604,y:707,t:1527876912041};\\\", \\\"{x:1597,y:711,t:1527876912057};\\\", \\\"{x:1588,y:715,t:1527876912074};\\\", \\\"{x:1576,y:719,t:1527876912090};\\\", \\\"{x:1564,y:725,t:1527876912107};\\\", \\\"{x:1556,y:727,t:1527876912124};\\\", \\\"{x:1549,y:731,t:1527876912141};\\\", \\\"{x:1542,y:735,t:1527876912157};\\\", \\\"{x:1537,y:739,t:1527876912174};\\\", \\\"{x:1533,y:743,t:1527876912190};\\\", \\\"{x:1530,y:747,t:1527876912208};\\\", \\\"{x:1527,y:751,t:1527876912224};\\\", \\\"{x:1525,y:754,t:1527876912240};\\\", \\\"{x:1525,y:755,t:1527876912258};\\\", \\\"{x:1524,y:755,t:1527876912275};\\\", \\\"{x:1524,y:756,t:1527876912294};\\\", \\\"{x:1524,y:757,t:1527876912326};\\\", \\\"{x:1523,y:760,t:1527876912342};\\\", \\\"{x:1522,y:762,t:1527876912358};\\\", \\\"{x:1521,y:764,t:1527876912375};\\\", \\\"{x:1520,y:766,t:1527876912391};\\\", \\\"{x:1519,y:768,t:1527876912454};\\\", \\\"{x:1518,y:769,t:1527876920054};\\\", \\\"{x:1516,y:769,t:1527876921806};\\\", \\\"{x:1506,y:769,t:1527876921814};\\\", \\\"{x:1491,y:770,t:1527876921831};\\\", \\\"{x:1470,y:774,t:1527876921847};\\\", \\\"{x:1448,y:774,t:1527876921865};\\\", \\\"{x:1426,y:775,t:1527876921881};\\\", \\\"{x:1374,y:775,t:1527876921898};\\\", \\\"{x:1288,y:775,t:1527876921915};\\\", \\\"{x:1182,y:775,t:1527876921931};\\\", \\\"{x:1066,y:775,t:1527876921948};\\\", \\\"{x:966,y:775,t:1527876921965};\\\", \\\"{x:827,y:775,t:1527876921981};\\\", \\\"{x:763,y:775,t:1527876921998};\\\", \\\"{x:699,y:775,t:1527876922015};\\\", \\\"{x:633,y:769,t:1527876922032};\\\", \\\"{x:584,y:758,t:1527876922048};\\\", \\\"{x:560,y:750,t:1527876922065};\\\", \\\"{x:541,y:745,t:1527876922082};\\\", \\\"{x:530,y:738,t:1527876922098};\\\", \\\"{x:520,y:730,t:1527876922115};\\\", \\\"{x:507,y:721,t:1527876922133};\\\", \\\"{x:481,y:708,t:1527876922149};\\\", \\\"{x:470,y:701,t:1527876922165};\\\", \\\"{x:462,y:690,t:1527876922189};\\\", \\\"{x:462,y:682,t:1527876922207};\\\", \\\"{x:463,y:666,t:1527876922223};\\\", \\\"{x:465,y:653,t:1527876922240};\\\", \\\"{x:467,y:637,t:1527876922257};\\\", \\\"{x:469,y:623,t:1527876922274};\\\", \\\"{x:470,y:611,t:1527876922289};\\\", \\\"{x:470,y:597,t:1527876922307};\\\", \\\"{x:470,y:582,t:1527876922324};\\\", \\\"{x:465,y:566,t:1527876922340};\\\", \\\"{x:458,y:557,t:1527876922357};\\\", \\\"{x:451,y:550,t:1527876922373};\\\", \\\"{x:448,y:548,t:1527876922389};\\\", \\\"{x:446,y:548,t:1527876922407};\\\", \\\"{x:442,y:548,t:1527876922423};\\\", \\\"{x:438,y:548,t:1527876922440};\\\", \\\"{x:436,y:548,t:1527876922456};\\\", \\\"{x:435,y:548,t:1527876922473};\\\", \\\"{x:434,y:548,t:1527876922493};\\\", \\\"{x:433,y:548,t:1527876922507};\\\", \\\"{x:430,y:549,t:1527876922524};\\\", \\\"{x:425,y:552,t:1527876922541};\\\", \\\"{x:423,y:552,t:1527876922557};\\\", \\\"{x:410,y:553,t:1527876922573};\\\", \\\"{x:401,y:554,t:1527876922590};\\\", \\\"{x:391,y:554,t:1527876922606};\\\", \\\"{x:387,y:554,t:1527876922624};\\\", \\\"{x:384,y:554,t:1527876922641};\\\", \\\"{x:383,y:555,t:1527876922798};\\\", \\\"{x:384,y:555,t:1527876922814};\\\", \\\"{x:386,y:555,t:1527876922824};\\\", \\\"{x:396,y:555,t:1527876922841};\\\", \\\"{x:409,y:550,t:1527876922858};\\\", \\\"{x:417,y:546,t:1527876922874};\\\", \\\"{x:419,y:545,t:1527876922891};\\\", \\\"{x:420,y:545,t:1527876922933};\\\", \\\"{x:422,y:545,t:1527876922957};\\\", \\\"{x:423,y:545,t:1527876922973};\\\", \\\"{x:427,y:542,t:1527876922991};\\\", \\\"{x:429,y:541,t:1527876923046};\\\", \\\"{x:430,y:541,t:1527876923057};\\\", \\\"{x:432,y:541,t:1527876923074};\\\", \\\"{x:433,y:541,t:1527876923093};\\\", \\\"{x:436,y:541,t:1527876923107};\\\", \\\"{x:444,y:541,t:1527876923124};\\\", \\\"{x:459,y:540,t:1527876923141};\\\", \\\"{x:459,y:538,t:1527876923286};\\\", \\\"{x:458,y:534,t:1527876923293};\\\", \\\"{x:451,y:530,t:1527876923308};\\\", \\\"{x:437,y:524,t:1527876923326};\\\", \\\"{x:410,y:517,t:1527876923341};\\\", \\\"{x:357,y:511,t:1527876923357};\\\", \\\"{x:325,y:508,t:1527876923373};\\\", \\\"{x:299,y:508,t:1527876923390};\\\", \\\"{x:281,y:508,t:1527876923408};\\\", \\\"{x:261,y:508,t:1527876923424};\\\", \\\"{x:247,y:509,t:1527876923441};\\\", \\\"{x:231,y:510,t:1527876923458};\\\", \\\"{x:220,y:513,t:1527876923475};\\\", \\\"{x:211,y:513,t:1527876923491};\\\", \\\"{x:208,y:514,t:1527876923507};\\\", \\\"{x:206,y:514,t:1527876923525};\\\", \\\"{x:205,y:514,t:1527876923574};\\\", \\\"{x:203,y:516,t:1527876923582};\\\", \\\"{x:201,y:517,t:1527876923591};\\\", \\\"{x:197,y:518,t:1527876923609};\\\", \\\"{x:194,y:521,t:1527876923625};\\\", \\\"{x:190,y:523,t:1527876923640};\\\", \\\"{x:189,y:524,t:1527876923657};\\\", \\\"{x:188,y:524,t:1527876923674};\\\", \\\"{x:187,y:525,t:1527876923701};\\\", \\\"{x:185,y:527,t:1527876923717};\\\", \\\"{x:185,y:528,t:1527876923725};\\\", \\\"{x:183,y:530,t:1527876923740};\\\", \\\"{x:177,y:535,t:1527876923758};\\\", \\\"{x:175,y:537,t:1527876923774};\\\", \\\"{x:173,y:539,t:1527876923791};\\\", \\\"{x:171,y:541,t:1527876923808};\\\", \\\"{x:169,y:543,t:1527876923825};\\\", \\\"{x:167,y:545,t:1527876923840};\\\", \\\"{x:164,y:549,t:1527876923858};\\\", \\\"{x:161,y:553,t:1527876923875};\\\", \\\"{x:158,y:558,t:1527876923892};\\\", \\\"{x:154,y:563,t:1527876923908};\\\", \\\"{x:151,y:567,t:1527876923924};\\\", \\\"{x:149,y:569,t:1527876923941};\\\", \\\"{x:148,y:571,t:1527876923958};\\\", \\\"{x:148,y:573,t:1527876923975};\\\", \\\"{x:147,y:577,t:1527876923992};\\\", \\\"{x:145,y:580,t:1527876924007};\\\", \\\"{x:145,y:583,t:1527876924024};\\\", \\\"{x:145,y:584,t:1527876924041};\\\", \\\"{x:145,y:585,t:1527876924061};\\\", \\\"{x:145,y:586,t:1527876924075};\\\", \\\"{x:145,y:588,t:1527876924091};\\\", \\\"{x:145,y:590,t:1527876924107};\\\", \\\"{x:145,y:592,t:1527876924124};\\\", \\\"{x:145,y:593,t:1527876924141};\\\", \\\"{x:145,y:595,t:1527876924190};\\\", \\\"{x:145,y:598,t:1527876924208};\\\", \\\"{x:145,y:600,t:1527876924225};\\\", \\\"{x:145,y:604,t:1527876924243};\\\", \\\"{x:145,y:606,t:1527876924258};\\\", \\\"{x:146,y:609,t:1527876924274};\\\", \\\"{x:146,y:611,t:1527876924291};\\\", \\\"{x:148,y:612,t:1527876924308};\\\", \\\"{x:151,y:614,t:1527876924325};\\\", \\\"{x:171,y:619,t:1527876924341};\\\", \\\"{x:198,y:619,t:1527876924358};\\\", \\\"{x:238,y:619,t:1527876924375};\\\", \\\"{x:299,y:619,t:1527876924392};\\\", \\\"{x:365,y:613,t:1527876924408};\\\", \\\"{x:435,y:603,t:1527876924425};\\\", \\\"{x:512,y:594,t:1527876924442};\\\", \\\"{x:566,y:584,t:1527876924459};\\\", \\\"{x:614,y:577,t:1527876924476};\\\", \\\"{x:642,y:572,t:1527876924492};\\\", \\\"{x:667,y:566,t:1527876924509};\\\", \\\"{x:683,y:563,t:1527876924524};\\\", \\\"{x:686,y:562,t:1527876924542};\\\", \\\"{x:687,y:562,t:1527876924557};\\\", \\\"{x:688,y:562,t:1527876924581};\\\", \\\"{x:689,y:561,t:1527876924592};\\\", \\\"{x:692,y:559,t:1527876924608};\\\", \\\"{x:697,y:558,t:1527876924625};\\\", \\\"{x:703,y:555,t:1527876924643};\\\", \\\"{x:712,y:554,t:1527876924659};\\\", \\\"{x:717,y:552,t:1527876924674};\\\", \\\"{x:721,y:552,t:1527876924691};\\\", \\\"{x:723,y:552,t:1527876924709};\\\", \\\"{x:724,y:552,t:1527876924726};\\\", \\\"{x:728,y:552,t:1527876924741};\\\", \\\"{x:731,y:552,t:1527876924758};\\\", \\\"{x:739,y:552,t:1527876924775};\\\", \\\"{x:746,y:552,t:1527876924792};\\\", \\\"{x:750,y:552,t:1527876924808};\\\", \\\"{x:754,y:552,t:1527876924824};\\\", \\\"{x:758,y:552,t:1527876924842};\\\", \\\"{x:764,y:552,t:1527876924859};\\\", \\\"{x:773,y:552,t:1527876924874};\\\", \\\"{x:780,y:551,t:1527876924892};\\\", \\\"{x:790,y:550,t:1527876924908};\\\", \\\"{x:795,y:549,t:1527876924924};\\\", \\\"{x:802,y:547,t:1527876924942};\\\", \\\"{x:804,y:547,t:1527876924959};\\\", \\\"{x:805,y:547,t:1527876924975};\\\", \\\"{x:808,y:548,t:1527876924992};\\\", \\\"{x:814,y:550,t:1527876925009};\\\", \\\"{x:818,y:551,t:1527876925025};\\\", \\\"{x:823,y:552,t:1527876925042};\\\", \\\"{x:826,y:555,t:1527876925059};\\\", \\\"{x:828,y:556,t:1527876925077};\\\", \\\"{x:828,y:557,t:1527876925091};\\\", \\\"{x:828,y:558,t:1527876925109};\\\", \\\"{x:831,y:565,t:1527876925126};\\\", \\\"{x:831,y:567,t:1527876925142};\\\", \\\"{x:832,y:569,t:1527876925159};\\\", \\\"{x:832,y:570,t:1527876925175};\\\", \\\"{x:832,y:571,t:1527876925192};\\\", \\\"{x:832,y:572,t:1527876925209};\\\", \\\"{x:832,y:573,t:1527876925226};\\\", \\\"{x:831,y:574,t:1527876925625};\\\", \\\"{x:814,y:574,t:1527876925643};\\\", \\\"{x:783,y:576,t:1527876925659};\\\", \\\"{x:725,y:581,t:1527876925675};\\\", \\\"{x:622,y:593,t:1527876925693};\\\", \\\"{x:560,y:602,t:1527876925709};\\\", \\\"{x:533,y:606,t:1527876925725};\\\", \\\"{x:518,y:607,t:1527876925742};\\\", \\\"{x:512,y:607,t:1527876925760};\\\", \\\"{x:511,y:607,t:1527876925776};\\\", \\\"{x:512,y:607,t:1527876925894};\\\", \\\"{x:516,y:605,t:1527876925909};\\\", \\\"{x:522,y:601,t:1527876925926};\\\", \\\"{x:529,y:597,t:1527876925944};\\\", \\\"{x:532,y:595,t:1527876925960};\\\", \\\"{x:534,y:593,t:1527876925976};\\\", \\\"{x:537,y:592,t:1527876925992};\\\", \\\"{x:544,y:589,t:1527876926009};\\\", \\\"{x:550,y:585,t:1527876926025};\\\", \\\"{x:561,y:580,t:1527876926043};\\\", \\\"{x:566,y:578,t:1527876926060};\\\", \\\"{x:574,y:575,t:1527876926075};\\\", \\\"{x:577,y:573,t:1527876926093};\\\", \\\"{x:579,y:573,t:1527876926110};\\\", \\\"{x:580,y:573,t:1527876926126};\\\", \\\"{x:581,y:573,t:1527876926143};\\\", \\\"{x:582,y:573,t:1527876926159};\\\", \\\"{x:584,y:573,t:1527876926176};\\\", \\\"{x:585,y:573,t:1527876926193};\\\", \\\"{x:586,y:573,t:1527876926210};\\\", \\\"{x:587,y:573,t:1527876926229};\\\", \\\"{x:588,y:573,t:1527876926422};\\\", \\\"{x:589,y:573,t:1527876926477};\\\", \\\"{x:591,y:573,t:1527876926501};\\\", \\\"{x:592,y:573,t:1527876926517};\\\", \\\"{x:593,y:573,t:1527876926527};\\\", \\\"{x:594,y:573,t:1527876926543};\\\", \\\"{x:596,y:573,t:1527876926560};\\\", \\\"{x:599,y:574,t:1527876926577};\\\", \\\"{x:601,y:575,t:1527876926594};\\\", \\\"{x:602,y:575,t:1527876926610};\\\", \\\"{x:603,y:575,t:1527876926806};\\\", \\\"{x:604,y:575,t:1527876926822};\\\", \\\"{x:605,y:575,t:1527876926844};\\\", \\\"{x:606,y:575,t:1527876926860};\\\", \\\"{x:606,y:575,t:1527876926929};\\\", \\\"{x:607,y:576,t:1527876926989};\\\", \\\"{x:607,y:578,t:1527876926997};\\\", \\\"{x:607,y:581,t:1527876927010};\\\", \\\"{x:607,y:589,t:1527876927026};\\\", \\\"{x:607,y:598,t:1527876927044};\\\", \\\"{x:607,y:603,t:1527876927062};\\\", \\\"{x:607,y:604,t:1527876927077};\\\", \\\"{x:609,y:606,t:1527876927100};\\\", \\\"{x:609,y:612,t:1527876927319};\\\", \\\"{x:608,y:619,t:1527876927327};\\\", \\\"{x:598,y:632,t:1527876927346};\\\", \\\"{x:594,y:641,t:1527876927360};\\\", \\\"{x:587,y:651,t:1527876927377};\\\", \\\"{x:584,y:654,t:1527876927393};\\\", \\\"{x:581,y:661,t:1527876927410};\\\", \\\"{x:577,y:666,t:1527876927427};\\\", \\\"{x:577,y:669,t:1527876927443};\\\", \\\"{x:576,y:673,t:1527876927460};\\\", \\\"{x:571,y:682,t:1527876927477};\\\", \\\"{x:569,y:687,t:1527876927493};\\\", \\\"{x:568,y:689,t:1527876927510};\\\", \\\"{x:568,y:691,t:1527876927526};\\\", \\\"{x:567,y:692,t:1527876927543};\\\", \\\"{x:567,y:694,t:1527876927560};\\\", \\\"{x:567,y:695,t:1527876927576};\\\", \\\"{x:566,y:697,t:1527876927594};\\\", \\\"{x:566,y:699,t:1527876927610};\\\", \\\"{x:566,y:701,t:1527876927627};\\\", \\\"{x:566,y:702,t:1527876927643};\\\", \\\"{x:566,y:705,t:1527876927660};\\\", \\\"{x:566,y:706,t:1527876927676};\\\", \\\"{x:566,y:711,t:1527876927693};\\\", \\\"{x:565,y:712,t:1527876927709};\\\", \\\"{x:565,y:714,t:1527876927726};\\\", \\\"{x:565,y:715,t:1527876927743};\\\", \\\"{x:565,y:716,t:1527876927766};\\\", \\\"{x:565,y:717,t:1527876927806};\\\", \\\"{x:564,y:717,t:1527876927814};\\\", \\\"{x:564,y:718,t:1527876927862};\\\", \\\"{x:564,y:719,t:1527876927876};\\\", \\\"{x:563,y:723,t:1527876927895};\\\", \\\"{x:562,y:724,t:1527876927917};\\\", \\\"{x:562,y:725,t:1527876927927};\\\", \\\"{x:562,y:727,t:1527876927944};\\\", \\\"{x:562,y:729,t:1527876927973};\\\", \\\"{x:561,y:729,t:1527876927981};\\\", \\\"{x:561,y:730,t:1527876927997};\\\", \\\"{x:559,y:732,t:1527876928158};\\\", \\\"{x:558,y:733,t:1527876928174};\\\", \\\"{x:557,y:734,t:1527876928189};\\\", \\\"{x:555,y:735,t:1527876928206};\\\", \\\"{x:554,y:736,t:1527876928221};\\\", \\\"{x:553,y:736,t:1527876928245};\\\", \\\"{x:551,y:736,t:1527876928261};\\\", \\\"{x:550,y:736,t:1527876928278};\\\", \\\"{x:549,y:736,t:1527876928373};\\\", \\\"{x:548,y:737,t:1527876928381};\\\", \\\"{x:547,y:737,t:1527876928396};\\\", \\\"{x:546,y:737,t:1527876928412};\\\", \\\"{x:544,y:737,t:1527876928429};\\\", \\\"{x:543,y:737,t:1527876928445};\\\", \\\"{x:542,y:737,t:1527876929509};\\\", \\\"{x:541,y:737,t:1527876930197};\\\", \\\"{x:537,y:737,t:1527876930213};\\\", \\\"{x:532,y:737,t:1527876930230};\\\", \\\"{x:527,y:737,t:1527876930246};\\\", \\\"{x:523,y:737,t:1527876930262};\\\" ] }, { \\\"rt\\\": 57760, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 578527, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-P -B -F -G -C -C -G -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:737,t:1527876930440};\\\", \\\"{x:521,y:737,t:1527876933661};\\\", \\\"{x:522,y:736,t:1527876933741};\\\", \\\"{x:523,y:735,t:1527876933757};\\\", \\\"{x:525,y:735,t:1527876933773};\\\", \\\"{x:526,y:734,t:1527876933821};\\\", \\\"{x:527,y:733,t:1527876933837};\\\", \\\"{x:528,y:733,t:1527876933853};\\\", \\\"{x:530,y:732,t:1527876933877};\\\", \\\"{x:531,y:731,t:1527876933885};\\\", \\\"{x:532,y:731,t:1527876933901};\\\", \\\"{x:533,y:730,t:1527876933917};\\\", \\\"{x:534,y:730,t:1527876933933};\\\", \\\"{x:538,y:728,t:1527876933950};\\\", \\\"{x:543,y:726,t:1527876933965};\\\", \\\"{x:545,y:725,t:1527876933982};\\\", \\\"{x:549,y:721,t:1527876933999};\\\", \\\"{x:553,y:718,t:1527876934016};\\\", \\\"{x:555,y:716,t:1527876934032};\\\", \\\"{x:557,y:714,t:1527876934049};\\\", \\\"{x:561,y:709,t:1527876934066};\\\", \\\"{x:567,y:702,t:1527876934083};\\\", \\\"{x:576,y:688,t:1527876934099};\\\", \\\"{x:581,y:676,t:1527876934116};\\\", \\\"{x:590,y:646,t:1527876934133};\\\", \\\"{x:595,y:632,t:1527876934150};\\\", \\\"{x:598,y:611,t:1527876934167};\\\", \\\"{x:603,y:593,t:1527876934183};\\\", \\\"{x:609,y:571,t:1527876934200};\\\", \\\"{x:612,y:552,t:1527876934217};\\\", \\\"{x:614,y:538,t:1527876934234};\\\", \\\"{x:618,y:524,t:1527876934249};\\\", \\\"{x:619,y:513,t:1527876934266};\\\", \\\"{x:623,y:500,t:1527876934283};\\\", \\\"{x:625,y:494,t:1527876934299};\\\", \\\"{x:627,y:489,t:1527876934316};\\\", \\\"{x:632,y:482,t:1527876934333};\\\", \\\"{x:633,y:480,t:1527876934350};\\\", \\\"{x:633,y:479,t:1527876934366};\\\", \\\"{x:633,y:478,t:1527876934383};\\\", \\\"{x:633,y:476,t:1527876934401};\\\", \\\"{x:633,y:475,t:1527876934416};\\\", \\\"{x:633,y:470,t:1527876934433};\\\", \\\"{x:633,y:468,t:1527876934450};\\\", \\\"{x:633,y:467,t:1527876934467};\\\", \\\"{x:635,y:462,t:1527876934558};\\\", \\\"{x:635,y:460,t:1527876934566};\\\", \\\"{x:639,y:455,t:1527876934583};\\\", \\\"{x:643,y:450,t:1527876934600};\\\", \\\"{x:645,y:448,t:1527876934618};\\\", \\\"{x:645,y:447,t:1527876934634};\\\", \\\"{x:646,y:446,t:1527876934678};\\\", \\\"{x:647,y:445,t:1527876934685};\\\", \\\"{x:649,y:445,t:1527876934701};\\\", \\\"{x:651,y:443,t:1527876934717};\\\", \\\"{x:655,y:440,t:1527876934734};\\\", \\\"{x:656,y:440,t:1527876935102};\\\", \\\"{x:658,y:438,t:1527876935182};\\\", \\\"{x:667,y:438,t:1527876935190};\\\", \\\"{x:677,y:438,t:1527876935200};\\\", \\\"{x:707,y:441,t:1527876935217};\\\", \\\"{x:746,y:451,t:1527876935235};\\\", \\\"{x:770,y:456,t:1527876935252};\\\", \\\"{x:792,y:459,t:1527876935268};\\\", \\\"{x:809,y:459,t:1527876935285};\\\", \\\"{x:847,y:459,t:1527876935302};\\\", \\\"{x:882,y:457,t:1527876935318};\\\", \\\"{x:940,y:451,t:1527876935334};\\\", \\\"{x:1036,y:443,t:1527876935352};\\\", \\\"{x:1149,y:431,t:1527876935368};\\\", \\\"{x:1273,y:419,t:1527876935385};\\\", \\\"{x:1387,y:400,t:1527876935402};\\\", \\\"{x:1490,y:382,t:1527876935418};\\\", \\\"{x:1568,y:372,t:1527876935434};\\\", \\\"{x:1618,y:365,t:1527876935451};\\\", \\\"{x:1653,y:364,t:1527876935468};\\\", \\\"{x:1682,y:363,t:1527876935484};\\\", \\\"{x:1714,y:363,t:1527876935501};\\\", \\\"{x:1721,y:363,t:1527876935517};\\\", \\\"{x:1726,y:362,t:1527876935534};\\\", \\\"{x:1727,y:362,t:1527876935551};\\\", \\\"{x:1727,y:360,t:1527876935774};\\\", \\\"{x:1726,y:359,t:1527876935784};\\\", \\\"{x:1704,y:359,t:1527876935802};\\\", \\\"{x:1677,y:359,t:1527876935818};\\\", \\\"{x:1646,y:359,t:1527876935834};\\\", \\\"{x:1620,y:359,t:1527876935851};\\\", \\\"{x:1598,y:359,t:1527876935869};\\\", \\\"{x:1580,y:361,t:1527876935887};\\\", \\\"{x:1558,y:363,t:1527876935901};\\\", \\\"{x:1535,y:367,t:1527876935918};\\\", \\\"{x:1523,y:368,t:1527876935935};\\\", \\\"{x:1514,y:372,t:1527876935951};\\\", \\\"{x:1509,y:373,t:1527876935968};\\\", \\\"{x:1506,y:373,t:1527876935985};\\\", \\\"{x:1505,y:373,t:1527876936001};\\\", \\\"{x:1503,y:374,t:1527876936018};\\\", \\\"{x:1497,y:376,t:1527876936034};\\\", \\\"{x:1489,y:381,t:1527876936051};\\\", \\\"{x:1482,y:386,t:1527876936068};\\\", \\\"{x:1472,y:394,t:1527876936084};\\\", \\\"{x:1466,y:398,t:1527876936101};\\\", \\\"{x:1459,y:405,t:1527876936118};\\\", \\\"{x:1453,y:411,t:1527876936135};\\\", \\\"{x:1449,y:417,t:1527876936151};\\\", \\\"{x:1443,y:424,t:1527876936168};\\\", \\\"{x:1436,y:432,t:1527876936185};\\\", \\\"{x:1432,y:436,t:1527876936202};\\\", \\\"{x:1427,y:443,t:1527876936219};\\\", \\\"{x:1423,y:449,t:1527876936236};\\\", \\\"{x:1420,y:452,t:1527876936252};\\\", \\\"{x:1415,y:457,t:1527876936269};\\\", \\\"{x:1412,y:461,t:1527876936286};\\\", \\\"{x:1410,y:462,t:1527876936303};\\\", \\\"{x:1412,y:462,t:1527876936439};\\\", \\\"{x:1418,y:460,t:1527876936453};\\\", \\\"{x:1427,y:455,t:1527876936469};\\\", \\\"{x:1441,y:448,t:1527876936486};\\\", \\\"{x:1455,y:440,t:1527876936503};\\\", \\\"{x:1468,y:434,t:1527876936520};\\\", \\\"{x:1483,y:429,t:1527876936536};\\\", \\\"{x:1499,y:421,t:1527876936553};\\\", \\\"{x:1512,y:414,t:1527876936569};\\\", \\\"{x:1523,y:410,t:1527876936586};\\\", \\\"{x:1530,y:405,t:1527876936603};\\\", \\\"{x:1533,y:404,t:1527876936619};\\\", \\\"{x:1535,y:402,t:1527876936635};\\\", \\\"{x:1537,y:400,t:1527876936652};\\\", \\\"{x:1539,y:398,t:1527876936669};\\\", \\\"{x:1539,y:397,t:1527876936733};\\\", \\\"{x:1538,y:395,t:1527876936741};\\\", \\\"{x:1536,y:395,t:1527876936752};\\\", \\\"{x:1531,y:394,t:1527876936770};\\\", \\\"{x:1527,y:394,t:1527876936786};\\\", \\\"{x:1521,y:395,t:1527876936803};\\\", \\\"{x:1514,y:397,t:1527876936819};\\\", \\\"{x:1499,y:401,t:1527876936836};\\\", \\\"{x:1483,y:411,t:1527876936852};\\\", \\\"{x:1455,y:427,t:1527876936869};\\\", \\\"{x:1436,y:438,t:1527876936886};\\\", \\\"{x:1416,y:452,t:1527876936903};\\\", \\\"{x:1400,y:465,t:1527876936920};\\\", \\\"{x:1388,y:475,t:1527876936936};\\\", \\\"{x:1381,y:484,t:1527876936953};\\\", \\\"{x:1376,y:491,t:1527876936970};\\\", \\\"{x:1375,y:494,t:1527876936987};\\\", \\\"{x:1375,y:497,t:1527876937003};\\\", \\\"{x:1375,y:500,t:1527876937020};\\\", \\\"{x:1374,y:502,t:1527876937037};\\\", \\\"{x:1374,y:504,t:1527876937053};\\\", \\\"{x:1374,y:509,t:1527876937069};\\\", \\\"{x:1374,y:512,t:1527876937087};\\\", \\\"{x:1374,y:516,t:1527876937103};\\\", \\\"{x:1374,y:518,t:1527876937120};\\\", \\\"{x:1374,y:521,t:1527876937137};\\\", \\\"{x:1374,y:523,t:1527876937154};\\\", \\\"{x:1374,y:526,t:1527876937169};\\\", \\\"{x:1374,y:529,t:1527876937187};\\\", \\\"{x:1374,y:531,t:1527876937204};\\\", \\\"{x:1374,y:534,t:1527876937220};\\\", \\\"{x:1374,y:535,t:1527876937245};\\\", \\\"{x:1374,y:536,t:1527876937254};\\\", \\\"{x:1374,y:537,t:1527876937270};\\\", \\\"{x:1375,y:539,t:1527876937287};\\\", \\\"{x:1376,y:543,t:1527876937304};\\\", \\\"{x:1378,y:548,t:1527876937320};\\\", \\\"{x:1379,y:552,t:1527876937336};\\\", \\\"{x:1381,y:554,t:1527876937353};\\\", \\\"{x:1381,y:555,t:1527876937478};\\\", \\\"{x:1381,y:556,t:1527876937487};\\\", \\\"{x:1381,y:557,t:1527876937504};\\\", \\\"{x:1381,y:558,t:1527876937750};\\\", \\\"{x:1381,y:560,t:1527876937757};\\\", \\\"{x:1381,y:562,t:1527876937770};\\\", \\\"{x:1382,y:566,t:1527876937788};\\\", \\\"{x:1382,y:571,t:1527876937804};\\\", \\\"{x:1384,y:576,t:1527876937821};\\\", \\\"{x:1386,y:584,t:1527876937837};\\\", \\\"{x:1386,y:591,t:1527876937853};\\\", \\\"{x:1389,y:602,t:1527876937871};\\\", \\\"{x:1391,y:618,t:1527876937888};\\\", \\\"{x:1396,y:638,t:1527876937904};\\\", \\\"{x:1398,y:653,t:1527876937921};\\\", \\\"{x:1398,y:669,t:1527876937938};\\\", \\\"{x:1395,y:686,t:1527876937954};\\\", \\\"{x:1391,y:696,t:1527876937971};\\\", \\\"{x:1388,y:703,t:1527876937988};\\\", \\\"{x:1386,y:707,t:1527876938005};\\\", \\\"{x:1386,y:710,t:1527876938021};\\\", \\\"{x:1386,y:713,t:1527876938038};\\\", \\\"{x:1385,y:716,t:1527876938055};\\\", \\\"{x:1384,y:717,t:1527876938071};\\\", \\\"{x:1383,y:718,t:1527876938088};\\\", \\\"{x:1381,y:720,t:1527876938105};\\\", \\\"{x:1379,y:720,t:1527876938121};\\\", \\\"{x:1378,y:723,t:1527876938138};\\\", \\\"{x:1377,y:724,t:1527876938155};\\\", \\\"{x:1376,y:727,t:1527876938171};\\\", \\\"{x:1374,y:727,t:1527876938191};\\\", \\\"{x:1373,y:728,t:1527876938205};\\\", \\\"{x:1368,y:731,t:1527876938221};\\\", \\\"{x:1364,y:737,t:1527876938238};\\\", \\\"{x:1359,y:743,t:1527876938255};\\\", \\\"{x:1355,y:747,t:1527876938272};\\\", \\\"{x:1353,y:750,t:1527876938288};\\\", \\\"{x:1353,y:751,t:1527876938305};\\\", \\\"{x:1352,y:751,t:1527876938322};\\\", \\\"{x:1352,y:752,t:1527876938338};\\\", \\\"{x:1352,y:753,t:1527876938355};\\\", \\\"{x:1352,y:755,t:1527876938372};\\\", \\\"{x:1352,y:756,t:1527876938388};\\\", \\\"{x:1352,y:757,t:1527876938405};\\\", \\\"{x:1352,y:758,t:1527876938646};\\\", \\\"{x:1352,y:759,t:1527876938671};\\\", \\\"{x:1352,y:760,t:1527876938718};\\\", \\\"{x:1351,y:761,t:1527876938725};\\\", \\\"{x:1350,y:762,t:1527876938739};\\\", \\\"{x:1349,y:762,t:1527876938755};\\\", \\\"{x:1347,y:762,t:1527876938772};\\\", \\\"{x:1346,y:762,t:1527876939334};\\\", \\\"{x:1345,y:763,t:1527876940220};\\\", \\\"{x:1345,y:770,t:1527876940229};\\\", \\\"{x:1342,y:781,t:1527876940239};\\\", \\\"{x:1341,y:790,t:1527876940257};\\\", \\\"{x:1339,y:792,t:1527876940273};\\\", \\\"{x:1339,y:796,t:1527876940289};\\\", \\\"{x:1337,y:801,t:1527876940306};\\\", \\\"{x:1337,y:804,t:1527876940323};\\\", \\\"{x:1336,y:812,t:1527876940339};\\\", \\\"{x:1328,y:839,t:1527876940356};\\\", \\\"{x:1319,y:870,t:1527876940373};\\\", \\\"{x:1315,y:879,t:1527876940391};\\\", \\\"{x:1315,y:883,t:1527876940407};\\\", \\\"{x:1315,y:884,t:1527876940430};\\\", \\\"{x:1315,y:885,t:1527876940440};\\\", \\\"{x:1313,y:889,t:1527876940456};\\\", \\\"{x:1311,y:894,t:1527876940474};\\\", \\\"{x:1309,y:898,t:1527876940491};\\\", \\\"{x:1307,y:902,t:1527876940507};\\\", \\\"{x:1305,y:906,t:1527876940524};\\\", \\\"{x:1302,y:910,t:1527876940541};\\\", \\\"{x:1300,y:912,t:1527876940557};\\\", \\\"{x:1295,y:916,t:1527876940573};\\\", \\\"{x:1291,y:917,t:1527876940591};\\\", \\\"{x:1286,y:920,t:1527876940607};\\\", \\\"{x:1282,y:923,t:1527876940624};\\\", \\\"{x:1280,y:924,t:1527876940640};\\\", \\\"{x:1279,y:924,t:1527876940676};\\\", \\\"{x:1279,y:926,t:1527876940700};\\\", \\\"{x:1278,y:927,t:1527876940709};\\\", \\\"{x:1276,y:930,t:1527876940724};\\\", \\\"{x:1274,y:933,t:1527876940740};\\\", \\\"{x:1271,y:938,t:1527876940757};\\\", \\\"{x:1271,y:942,t:1527876940773};\\\", \\\"{x:1269,y:947,t:1527876940791};\\\", \\\"{x:1269,y:952,t:1527876940808};\\\", \\\"{x:1269,y:953,t:1527876940829};\\\", \\\"{x:1269,y:955,t:1527876940841};\\\", \\\"{x:1267,y:959,t:1527876940858};\\\", \\\"{x:1266,y:962,t:1527876940873};\\\", \\\"{x:1265,y:963,t:1527876940990};\\\", \\\"{x:1263,y:964,t:1527876941014};\\\", \\\"{x:1262,y:964,t:1527876941029};\\\", \\\"{x:1261,y:965,t:1527876941102};\\\", \\\"{x:1260,y:966,t:1527876941110};\\\", \\\"{x:1260,y:965,t:1527876941326};\\\", \\\"{x:1260,y:963,t:1527876941350};\\\", \\\"{x:1260,y:962,t:1527876941358};\\\", \\\"{x:1260,y:960,t:1527876941375};\\\", \\\"{x:1261,y:959,t:1527876941392};\\\", \\\"{x:1261,y:957,t:1527876941408};\\\", \\\"{x:1263,y:954,t:1527876941425};\\\", \\\"{x:1265,y:951,t:1527876941442};\\\", \\\"{x:1266,y:948,t:1527876941458};\\\", \\\"{x:1270,y:942,t:1527876941475};\\\", \\\"{x:1270,y:938,t:1527876941492};\\\", \\\"{x:1271,y:933,t:1527876941508};\\\", \\\"{x:1274,y:920,t:1527876941525};\\\", \\\"{x:1279,y:907,t:1527876941541};\\\", \\\"{x:1283,y:895,t:1527876941558};\\\", \\\"{x:1290,y:882,t:1527876941575};\\\", \\\"{x:1298,y:863,t:1527876941592};\\\", \\\"{x:1306,y:849,t:1527876941609};\\\", \\\"{x:1310,y:838,t:1527876941625};\\\", \\\"{x:1315,y:821,t:1527876941641};\\\", \\\"{x:1320,y:805,t:1527876941659};\\\", \\\"{x:1325,y:792,t:1527876941675};\\\", \\\"{x:1332,y:777,t:1527876941692};\\\", \\\"{x:1338,y:763,t:1527876941709};\\\", \\\"{x:1343,y:742,t:1527876941725};\\\", \\\"{x:1349,y:702,t:1527876941742};\\\", \\\"{x:1357,y:679,t:1527876941760};\\\", \\\"{x:1360,y:669,t:1527876941774};\\\", \\\"{x:1361,y:662,t:1527876941792};\\\", \\\"{x:1363,y:655,t:1527876941810};\\\", \\\"{x:1366,y:648,t:1527876941825};\\\", \\\"{x:1370,y:639,t:1527876941842};\\\", \\\"{x:1373,y:632,t:1527876941859};\\\", \\\"{x:1377,y:623,t:1527876941875};\\\", \\\"{x:1379,y:616,t:1527876941892};\\\", \\\"{x:1381,y:611,t:1527876941909};\\\", \\\"{x:1383,y:606,t:1527876941926};\\\", \\\"{x:1386,y:602,t:1527876941942};\\\", \\\"{x:1390,y:598,t:1527876941959};\\\", \\\"{x:1396,y:594,t:1527876941976};\\\", \\\"{x:1399,y:591,t:1527876941992};\\\", \\\"{x:1399,y:589,t:1527876942009};\\\", \\\"{x:1400,y:586,t:1527876942026};\\\", \\\"{x:1402,y:584,t:1527876942042};\\\", \\\"{x:1403,y:581,t:1527876942059};\\\", \\\"{x:1407,y:577,t:1527876942077};\\\", \\\"{x:1414,y:570,t:1527876942093};\\\", \\\"{x:1420,y:564,t:1527876942109};\\\", \\\"{x:1425,y:560,t:1527876942126};\\\", \\\"{x:1426,y:560,t:1527876942143};\\\", \\\"{x:1426,y:559,t:1527876942206};\\\", \\\"{x:1427,y:558,t:1527876942214};\\\", \\\"{x:1428,y:558,t:1527876942226};\\\", \\\"{x:1429,y:557,t:1527876942243};\\\", \\\"{x:1430,y:556,t:1527876942774};\\\", \\\"{x:1432,y:554,t:1527876942782};\\\", \\\"{x:1434,y:551,t:1527876942793};\\\", \\\"{x:1438,y:546,t:1527876942811};\\\", \\\"{x:1440,y:542,t:1527876942828};\\\", \\\"{x:1442,y:540,t:1527876942844};\\\", \\\"{x:1442,y:539,t:1527876942860};\\\", \\\"{x:1442,y:538,t:1527876942877};\\\", \\\"{x:1445,y:536,t:1527876942893};\\\", \\\"{x:1447,y:532,t:1527876942910};\\\", \\\"{x:1449,y:529,t:1527876942927};\\\", \\\"{x:1451,y:527,t:1527876942943};\\\", \\\"{x:1451,y:526,t:1527876942960};\\\", \\\"{x:1451,y:525,t:1527876942978};\\\", \\\"{x:1453,y:522,t:1527876942994};\\\", \\\"{x:1455,y:516,t:1527876943010};\\\", \\\"{x:1457,y:512,t:1527876943027};\\\", \\\"{x:1459,y:508,t:1527876943043};\\\", \\\"{x:1460,y:505,t:1527876943061};\\\", \\\"{x:1461,y:504,t:1527876943077};\\\", \\\"{x:1462,y:503,t:1527876943094};\\\", \\\"{x:1463,y:502,t:1527876943110};\\\", \\\"{x:1465,y:501,t:1527876943127};\\\", \\\"{x:1466,y:500,t:1527876943145};\\\", \\\"{x:1468,y:499,t:1527876943160};\\\", \\\"{x:1472,y:495,t:1527876943177};\\\", \\\"{x:1473,y:493,t:1527876943194};\\\", \\\"{x:1475,y:491,t:1527876943210};\\\", \\\"{x:1476,y:490,t:1527876943227};\\\", \\\"{x:1478,y:488,t:1527876943244};\\\", \\\"{x:1479,y:487,t:1527876943260};\\\", \\\"{x:1481,y:485,t:1527876943277};\\\", \\\"{x:1484,y:482,t:1527876943294};\\\", \\\"{x:1485,y:481,t:1527876943333};\\\", \\\"{x:1486,y:481,t:1527876943391};\\\", \\\"{x:1490,y:496,t:1527876953689};\\\", \\\"{x:1490,y:509,t:1527876953697};\\\", \\\"{x:1490,y:521,t:1527876953708};\\\", \\\"{x:1487,y:541,t:1527876953725};\\\", \\\"{x:1483,y:564,t:1527876953742};\\\", \\\"{x:1480,y:581,t:1527876953758};\\\", \\\"{x:1476,y:588,t:1527876953776};\\\", \\\"{x:1476,y:593,t:1527876953792};\\\", \\\"{x:1476,y:595,t:1527876953808};\\\", \\\"{x:1476,y:604,t:1527876953825};\\\", \\\"{x:1476,y:611,t:1527876953843};\\\", \\\"{x:1473,y:621,t:1527876953858};\\\", \\\"{x:1473,y:624,t:1527876953875};\\\", \\\"{x:1472,y:627,t:1527876953952};\\\", \\\"{x:1472,y:638,t:1527876953960};\\\", \\\"{x:1474,y:646,t:1527876953975};\\\", \\\"{x:1479,y:657,t:1527876953993};\\\", \\\"{x:1480,y:661,t:1527876954009};\\\", \\\"{x:1480,y:666,t:1527876954025};\\\", \\\"{x:1480,y:671,t:1527876954043};\\\", \\\"{x:1480,y:678,t:1527876954060};\\\", \\\"{x:1480,y:685,t:1527876954075};\\\", \\\"{x:1480,y:691,t:1527876954093};\\\", \\\"{x:1480,y:699,t:1527876954109};\\\", \\\"{x:1479,y:707,t:1527876954126};\\\", \\\"{x:1478,y:717,t:1527876954143};\\\", \\\"{x:1474,y:730,t:1527876954159};\\\", \\\"{x:1471,y:740,t:1527876954175};\\\", \\\"{x:1468,y:749,t:1527876954192};\\\", \\\"{x:1468,y:752,t:1527876954210};\\\", \\\"{x:1467,y:753,t:1527876954227};\\\", \\\"{x:1465,y:756,t:1527876954243};\\\", \\\"{x:1463,y:759,t:1527876954259};\\\", \\\"{x:1462,y:760,t:1527876954276};\\\", \\\"{x:1459,y:762,t:1527876954293};\\\", \\\"{x:1456,y:763,t:1527876954310};\\\", \\\"{x:1450,y:766,t:1527876954327};\\\", \\\"{x:1443,y:768,t:1527876954342};\\\", \\\"{x:1435,y:770,t:1527876954359};\\\", \\\"{x:1430,y:770,t:1527876954376};\\\", \\\"{x:1430,y:768,t:1527876954497};\\\", \\\"{x:1430,y:767,t:1527876954509};\\\", \\\"{x:1430,y:762,t:1527876954527};\\\", \\\"{x:1430,y:760,t:1527876954543};\\\", \\\"{x:1431,y:757,t:1527876954560};\\\", \\\"{x:1432,y:753,t:1527876954576};\\\", \\\"{x:1432,y:751,t:1527876954593};\\\", \\\"{x:1432,y:747,t:1527876954609};\\\", \\\"{x:1432,y:741,t:1527876954626};\\\", \\\"{x:1432,y:734,t:1527876954644};\\\", \\\"{x:1432,y:727,t:1527876954660};\\\", \\\"{x:1432,y:723,t:1527876954676};\\\", \\\"{x:1432,y:718,t:1527876954693};\\\", \\\"{x:1436,y:708,t:1527876954710};\\\", \\\"{x:1437,y:701,t:1527876954726};\\\", \\\"{x:1438,y:693,t:1527876954744};\\\", \\\"{x:1440,y:689,t:1527876954759};\\\", \\\"{x:1440,y:688,t:1527876954776};\\\", \\\"{x:1440,y:687,t:1527876954793};\\\", \\\"{x:1441,y:686,t:1527876954817};\\\", \\\"{x:1441,y:685,t:1527876954826};\\\", \\\"{x:1441,y:682,t:1527876954843};\\\", \\\"{x:1441,y:678,t:1527876954861};\\\", \\\"{x:1441,y:673,t:1527876954877};\\\", \\\"{x:1441,y:671,t:1527876954893};\\\", \\\"{x:1441,y:669,t:1527876954910};\\\", \\\"{x:1441,y:666,t:1527876954926};\\\", \\\"{x:1441,y:665,t:1527876954944};\\\", \\\"{x:1441,y:664,t:1527876954960};\\\", \\\"{x:1441,y:663,t:1527876954976};\\\", \\\"{x:1441,y:662,t:1527876954994};\\\", \\\"{x:1441,y:659,t:1527876955011};\\\", \\\"{x:1441,y:657,t:1527876955026};\\\", \\\"{x:1440,y:653,t:1527876955044};\\\", \\\"{x:1439,y:649,t:1527876955060};\\\", \\\"{x:1438,y:644,t:1527876955076};\\\", \\\"{x:1435,y:640,t:1527876955093};\\\", \\\"{x:1433,y:633,t:1527876955110};\\\", \\\"{x:1432,y:628,t:1527876955127};\\\", \\\"{x:1432,y:624,t:1527876955144};\\\", \\\"{x:1431,y:619,t:1527876955161};\\\", \\\"{x:1430,y:617,t:1527876955178};\\\", \\\"{x:1430,y:616,t:1527876955194};\\\", \\\"{x:1429,y:614,t:1527876955210};\\\", \\\"{x:1429,y:612,t:1527876955228};\\\", \\\"{x:1429,y:610,t:1527876955244};\\\", \\\"{x:1429,y:609,t:1527876955289};\\\", \\\"{x:1428,y:609,t:1527876955305};\\\", \\\"{x:1427,y:609,t:1527876955449};\\\", \\\"{x:1426,y:609,t:1527876955481};\\\", \\\"{x:1424,y:609,t:1527876955520};\\\", \\\"{x:1423,y:609,t:1527876955609};\\\", \\\"{x:1421,y:609,t:1527876955737};\\\", \\\"{x:1420,y:609,t:1527876955825};\\\", \\\"{x:1420,y:610,t:1527876955832};\\\", \\\"{x:1419,y:610,t:1527876955864};\\\", \\\"{x:1418,y:610,t:1527876955880};\\\", \\\"{x:1417,y:610,t:1527876955894};\\\", \\\"{x:1417,y:611,t:1527876955912};\\\", \\\"{x:1416,y:611,t:1527876955936};\\\", \\\"{x:1415,y:611,t:1527876955952};\\\", \\\"{x:1415,y:612,t:1527876955961};\\\", \\\"{x:1414,y:612,t:1527876955978};\\\", \\\"{x:1413,y:612,t:1527876956040};\\\", \\\"{x:1412,y:612,t:1527876956056};\\\", \\\"{x:1410,y:613,t:1527876956073};\\\", \\\"{x:1410,y:614,t:1527876956201};\\\", \\\"{x:1409,y:614,t:1527876956232};\\\", \\\"{x:1408,y:614,t:1527876956256};\\\", \\\"{x:1407,y:615,t:1527876956288};\\\", \\\"{x:1406,y:615,t:1527876956352};\\\", \\\"{x:1405,y:616,t:1527876956808};\\\", \\\"{x:1404,y:617,t:1527876956873};\\\", \\\"{x:1402,y:618,t:1527876956904};\\\", \\\"{x:1401,y:619,t:1527876956976};\\\", \\\"{x:1399,y:619,t:1527876957081};\\\", \\\"{x:1398,y:620,t:1527876957112};\\\", \\\"{x:1397,y:621,t:1527876957152};\\\", \\\"{x:1396,y:621,t:1527876957169};\\\", \\\"{x:1395,y:621,t:1527876957208};\\\", \\\"{x:1395,y:622,t:1527876957216};\\\", \\\"{x:1393,y:622,t:1527876957240};\\\", \\\"{x:1392,y:622,t:1527876957288};\\\", \\\"{x:1392,y:623,t:1527876957296};\\\", \\\"{x:1390,y:623,t:1527876957320};\\\", \\\"{x:1389,y:624,t:1527876957336};\\\", \\\"{x:1388,y:624,t:1527876957346};\\\", \\\"{x:1388,y:625,t:1527876957362};\\\", \\\"{x:1386,y:627,t:1527876957379};\\\", \\\"{x:1385,y:627,t:1527876957397};\\\", \\\"{x:1385,y:628,t:1527876957413};\\\", \\\"{x:1384,y:628,t:1527876957430};\\\", \\\"{x:1383,y:628,t:1527876957505};\\\", \\\"{x:1383,y:629,t:1527876957521};\\\", \\\"{x:1381,y:629,t:1527876957552};\\\", \\\"{x:1381,y:630,t:1527876957563};\\\", \\\"{x:1380,y:631,t:1527876957580};\\\", \\\"{x:1379,y:631,t:1527876957600};\\\", \\\"{x:1378,y:632,t:1527876957665};\\\", \\\"{x:1377,y:632,t:1527876957752};\\\", \\\"{x:1377,y:633,t:1527876957784};\\\", \\\"{x:1377,y:634,t:1527876957797};\\\", \\\"{x:1376,y:634,t:1527876957832};\\\", \\\"{x:1375,y:634,t:1527876957847};\\\", \\\"{x:1375,y:635,t:1527876957864};\\\", \\\"{x:1374,y:636,t:1527876957881};\\\", \\\"{x:1372,y:637,t:1527876957897};\\\", \\\"{x:1372,y:638,t:1527876957913};\\\", \\\"{x:1371,y:639,t:1527876957931};\\\", \\\"{x:1372,y:639,t:1527876958241};\\\", \\\"{x:1373,y:639,t:1527876958256};\\\", \\\"{x:1374,y:639,t:1527876958264};\\\", \\\"{x:1376,y:638,t:1527876958280};\\\", \\\"{x:1378,y:637,t:1527876958297};\\\", \\\"{x:1380,y:635,t:1527876958314};\\\", \\\"{x:1381,y:635,t:1527876958331};\\\", \\\"{x:1385,y:633,t:1527876958348};\\\", \\\"{x:1389,y:631,t:1527876958363};\\\", \\\"{x:1394,y:629,t:1527876958381};\\\", \\\"{x:1396,y:628,t:1527876958398};\\\", \\\"{x:1397,y:628,t:1527876958414};\\\", \\\"{x:1399,y:626,t:1527876958431};\\\", \\\"{x:1401,y:626,t:1527876958447};\\\", \\\"{x:1402,y:625,t:1527876958464};\\\", \\\"{x:1405,y:624,t:1527876958480};\\\", \\\"{x:1408,y:623,t:1527876958497};\\\", \\\"{x:1410,y:621,t:1527876958515};\\\", \\\"{x:1412,y:619,t:1527876958531};\\\", \\\"{x:1414,y:619,t:1527876958547};\\\", \\\"{x:1415,y:619,t:1527876958565};\\\", \\\"{x:1415,y:618,t:1527876958592};\\\", \\\"{x:1416,y:618,t:1527876958609};\\\", \\\"{x:1419,y:617,t:1527876958624};\\\", \\\"{x:1419,y:616,t:1527876958632};\\\", \\\"{x:1421,y:616,t:1527876958647};\\\", \\\"{x:1423,y:615,t:1527876958664};\\\", \\\"{x:1424,y:615,t:1527876958680};\\\", \\\"{x:1425,y:614,t:1527876958776};\\\", \\\"{x:1426,y:613,t:1527876958809};\\\", \\\"{x:1428,y:613,t:1527876958985};\\\", \\\"{x:1432,y:613,t:1527876958997};\\\", \\\"{x:1437,y:615,t:1527876959015};\\\", \\\"{x:1439,y:615,t:1527876959032};\\\", \\\"{x:1442,y:616,t:1527876959048};\\\", \\\"{x:1443,y:616,t:1527876959064};\\\", \\\"{x:1446,y:620,t:1527876959249};\\\", \\\"{x:1448,y:622,t:1527876959265};\\\", \\\"{x:1450,y:625,t:1527876959282};\\\", \\\"{x:1450,y:627,t:1527876959298};\\\", \\\"{x:1451,y:628,t:1527876959315};\\\", \\\"{x:1452,y:630,t:1527876959336};\\\", \\\"{x:1452,y:631,t:1527876959360};\\\", \\\"{x:1453,y:631,t:1527876959425};\\\", \\\"{x:1452,y:632,t:1527876959617};\\\", \\\"{x:1452,y:633,t:1527876959632};\\\", \\\"{x:1451,y:633,t:1527876959648};\\\", \\\"{x:1450,y:633,t:1527876959672};\\\", \\\"{x:1449,y:633,t:1527876959688};\\\", \\\"{x:1448,y:633,t:1527876959698};\\\", \\\"{x:1446,y:630,t:1527876959715};\\\", \\\"{x:1442,y:627,t:1527876959733};\\\", \\\"{x:1440,y:623,t:1527876959748};\\\", \\\"{x:1438,y:620,t:1527876959765};\\\", \\\"{x:1435,y:616,t:1527876959783};\\\", \\\"{x:1435,y:613,t:1527876959799};\\\", \\\"{x:1432,y:608,t:1527876959815};\\\", \\\"{x:1432,y:603,t:1527876959832};\\\", \\\"{x:1432,y:600,t:1527876959849};\\\", \\\"{x:1431,y:598,t:1527876959866};\\\", \\\"{x:1429,y:594,t:1527876959883};\\\", \\\"{x:1427,y:590,t:1527876959899};\\\", \\\"{x:1425,y:587,t:1527876959916};\\\", \\\"{x:1424,y:583,t:1527876959933};\\\", \\\"{x:1424,y:580,t:1527876959950};\\\", \\\"{x:1424,y:578,t:1527876959966};\\\", \\\"{x:1424,y:577,t:1527876960096};\\\", \\\"{x:1424,y:575,t:1527876960104};\\\", \\\"{x:1423,y:575,t:1527876960115};\\\", \\\"{x:1422,y:574,t:1527876960132};\\\", \\\"{x:1421,y:573,t:1527876960149};\\\", \\\"{x:1419,y:573,t:1527876960240};\\\", \\\"{x:1418,y:573,t:1527876960255};\\\", \\\"{x:1417,y:572,t:1527876960784};\\\", \\\"{x:1412,y:569,t:1527876960800};\\\", \\\"{x:1407,y:566,t:1527876960817};\\\", \\\"{x:1393,y:560,t:1527876960833};\\\", \\\"{x:1390,y:559,t:1527876960850};\\\", \\\"{x:1389,y:558,t:1527876960867};\\\", \\\"{x:1390,y:558,t:1527876961160};\\\", \\\"{x:1391,y:557,t:1527876961168};\\\", \\\"{x:1392,y:557,t:1527876961184};\\\", \\\"{x:1394,y:556,t:1527876961201};\\\", \\\"{x:1396,y:555,t:1527876961224};\\\", \\\"{x:1397,y:555,t:1527876961264};\\\", \\\"{x:1399,y:554,t:1527876961280};\\\", \\\"{x:1400,y:553,t:1527876961361};\\\", \\\"{x:1401,y:553,t:1527876961416};\\\", \\\"{x:1402,y:552,t:1527876961849};\\\", \\\"{x:1404,y:552,t:1527876961880};\\\", \\\"{x:1405,y:552,t:1527876961904};\\\", \\\"{x:1406,y:551,t:1527876961920};\\\", \\\"{x:1407,y:551,t:1527876962001};\\\", \\\"{x:1410,y:553,t:1527876962018};\\\", \\\"{x:1412,y:554,t:1527876962035};\\\", \\\"{x:1413,y:555,t:1527876962052};\\\", \\\"{x:1413,y:556,t:1527876962088};\\\", \\\"{x:1413,y:557,t:1527876962184};\\\", \\\"{x:1412,y:558,t:1527876962202};\\\", \\\"{x:1412,y:559,t:1527876962329};\\\", \\\"{x:1411,y:559,t:1527876962360};\\\", \\\"{x:1409,y:560,t:1527876962490};\\\", \\\"{x:1408,y:561,t:1527876962521};\\\", \\\"{x:1407,y:561,t:1527876962544};\\\", \\\"{x:1407,y:562,t:1527876962560};\\\", \\\"{x:1407,y:564,t:1527876962568};\\\", \\\"{x:1407,y:565,t:1527876962585};\\\", \\\"{x:1400,y:568,t:1527876976129};\\\", \\\"{x:1384,y:568,t:1527876976136};\\\", \\\"{x:1361,y:568,t:1527876976151};\\\", \\\"{x:1294,y:568,t:1527876976167};\\\", \\\"{x:1156,y:568,t:1527876976184};\\\", \\\"{x:1094,y:568,t:1527876976202};\\\", \\\"{x:1014,y:568,t:1527876976218};\\\", \\\"{x:966,y:569,t:1527876976234};\\\", \\\"{x:917,y:571,t:1527876976253};\\\", \\\"{x:875,y:571,t:1527876976267};\\\", \\\"{x:848,y:571,t:1527876976284};\\\", \\\"{x:823,y:571,t:1527876976298};\\\", \\\"{x:793,y:571,t:1527876976314};\\\", \\\"{x:766,y:568,t:1527876976330};\\\", \\\"{x:736,y:564,t:1527876976348};\\\", \\\"{x:707,y:562,t:1527876976365};\\\", \\\"{x:672,y:561,t:1527876976381};\\\", \\\"{x:619,y:557,t:1527876976404};\\\", \\\"{x:584,y:555,t:1527876976420};\\\", \\\"{x:558,y:550,t:1527876976436};\\\", \\\"{x:530,y:546,t:1527876976453};\\\", \\\"{x:508,y:544,t:1527876976470};\\\", \\\"{x:478,y:537,t:1527876976488};\\\", \\\"{x:463,y:532,t:1527876976503};\\\", \\\"{x:457,y:529,t:1527876976520};\\\", \\\"{x:454,y:529,t:1527876976537};\\\", \\\"{x:451,y:528,t:1527876976554};\\\", \\\"{x:449,y:526,t:1527876976571};\\\", \\\"{x:448,y:526,t:1527876976633};\\\", \\\"{x:448,y:524,t:1527876976656};\\\", \\\"{x:448,y:523,t:1527876976671};\\\", \\\"{x:450,y:523,t:1527876976686};\\\", \\\"{x:451,y:522,t:1527876976704};\\\", \\\"{x:453,y:522,t:1527876976727};\\\", \\\"{x:453,y:521,t:1527876976736};\\\", \\\"{x:454,y:520,t:1527876976753};\\\", \\\"{x:456,y:520,t:1527876976771};\\\", \\\"{x:457,y:520,t:1527876976787};\\\", \\\"{x:459,y:519,t:1527876976804};\\\", \\\"{x:461,y:518,t:1527876976821};\\\", \\\"{x:462,y:518,t:1527876976837};\\\", \\\"{x:463,y:517,t:1527876976855};\\\", \\\"{x:464,y:516,t:1527876976871};\\\", \\\"{x:465,y:516,t:1527876978121};\\\", \\\"{x:466,y:516,t:1527876978128};\\\", \\\"{x:468,y:516,t:1527876978138};\\\", \\\"{x:474,y:523,t:1527876978156};\\\", \\\"{x:478,y:526,t:1527876978173};\\\", \\\"{x:482,y:528,t:1527876978189};\\\", \\\"{x:485,y:530,t:1527876978205};\\\", \\\"{x:486,y:530,t:1527876978222};\\\", \\\"{x:489,y:533,t:1527876978239};\\\", \\\"{x:494,y:537,t:1527876978255};\\\", \\\"{x:497,y:538,t:1527876978272};\\\", \\\"{x:499,y:540,t:1527876978290};\\\", \\\"{x:499,y:541,t:1527876978305};\\\", \\\"{x:500,y:541,t:1527876978321};\\\", \\\"{x:500,y:542,t:1527876978338};\\\", \\\"{x:500,y:543,t:1527876978355};\\\", \\\"{x:500,y:544,t:1527876978371};\\\", \\\"{x:500,y:546,t:1527876978388};\\\", \\\"{x:500,y:548,t:1527876978404};\\\", \\\"{x:497,y:551,t:1527876978423};\\\", \\\"{x:495,y:553,t:1527876978438};\\\", \\\"{x:488,y:557,t:1527876978456};\\\", \\\"{x:484,y:559,t:1527876978472};\\\", \\\"{x:481,y:560,t:1527876978489};\\\", \\\"{x:479,y:561,t:1527876978505};\\\", \\\"{x:474,y:564,t:1527876978523};\\\", \\\"{x:472,y:565,t:1527876978539};\\\", \\\"{x:466,y:568,t:1527876978555};\\\", \\\"{x:465,y:568,t:1527876978572};\\\", \\\"{x:463,y:569,t:1527876978589};\\\", \\\"{x:461,y:569,t:1527876978608};\\\", \\\"{x:460,y:570,t:1527876978623};\\\", \\\"{x:459,y:570,t:1527876978647};\\\", \\\"{x:459,y:571,t:1527876978656};\\\", \\\"{x:457,y:572,t:1527876978672};\\\", \\\"{x:455,y:572,t:1527876978689};\\\", \\\"{x:454,y:573,t:1527876978705};\\\", \\\"{x:453,y:573,t:1527876978722};\\\", \\\"{x:451,y:575,t:1527876978739};\\\", \\\"{x:450,y:575,t:1527876978755};\\\", \\\"{x:445,y:577,t:1527876978772};\\\", \\\"{x:440,y:578,t:1527876978790};\\\", \\\"{x:436,y:579,t:1527876978805};\\\", \\\"{x:429,y:582,t:1527876978823};\\\", \\\"{x:422,y:583,t:1527876978840};\\\", \\\"{x:417,y:584,t:1527876978856};\\\", \\\"{x:415,y:584,t:1527876978872};\\\", \\\"{x:414,y:584,t:1527876979024};\\\", \\\"{x:418,y:583,t:1527876979041};\\\", \\\"{x:423,y:581,t:1527876979056};\\\", \\\"{x:427,y:579,t:1527876979073};\\\", \\\"{x:432,y:576,t:1527876979089};\\\", \\\"{x:439,y:573,t:1527876979106};\\\", \\\"{x:446,y:570,t:1527876979123};\\\", \\\"{x:453,y:567,t:1527876979139};\\\", \\\"{x:462,y:562,t:1527876979157};\\\", \\\"{x:468,y:560,t:1527876979173};\\\", \\\"{x:475,y:557,t:1527876979189};\\\", \\\"{x:484,y:553,t:1527876979208};\\\", \\\"{x:499,y:547,t:1527876979223};\\\", \\\"{x:511,y:543,t:1527876979239};\\\", \\\"{x:525,y:539,t:1527876979256};\\\", \\\"{x:542,y:534,t:1527876979273};\\\", \\\"{x:556,y:532,t:1527876979289};\\\", \\\"{x:571,y:529,t:1527876979306};\\\", \\\"{x:583,y:528,t:1527876979323};\\\", \\\"{x:596,y:526,t:1527876979339};\\\", \\\"{x:602,y:526,t:1527876979356};\\\", \\\"{x:605,y:526,t:1527876979373};\\\", \\\"{x:608,y:526,t:1527876979389};\\\", \\\"{x:609,y:526,t:1527876979480};\\\", \\\"{x:610,y:526,t:1527876979490};\\\", \\\"{x:612,y:526,t:1527876979506};\\\", \\\"{x:619,y:526,t:1527876979523};\\\", \\\"{x:628,y:526,t:1527876979539};\\\", \\\"{x:637,y:526,t:1527876979557};\\\", \\\"{x:643,y:526,t:1527876979574};\\\", \\\"{x:648,y:526,t:1527876979589};\\\", \\\"{x:651,y:526,t:1527876979607};\\\", \\\"{x:652,y:526,t:1527876979623};\\\", \\\"{x:658,y:526,t:1527876979640};\\\", \\\"{x:661,y:527,t:1527876979656};\\\", \\\"{x:667,y:527,t:1527876979674};\\\", \\\"{x:678,y:529,t:1527876979690};\\\", \\\"{x:688,y:530,t:1527876979706};\\\", \\\"{x:696,y:532,t:1527876979723};\\\", \\\"{x:703,y:533,t:1527876979741};\\\", \\\"{x:712,y:536,t:1527876979756};\\\", \\\"{x:723,y:539,t:1527876979773};\\\", \\\"{x:734,y:544,t:1527876979792};\\\", \\\"{x:750,y:550,t:1527876979805};\\\", \\\"{x:765,y:557,t:1527876979822};\\\", \\\"{x:789,y:565,t:1527876979840};\\\", \\\"{x:804,y:569,t:1527876979855};\\\", \\\"{x:822,y:572,t:1527876979873};\\\", \\\"{x:835,y:572,t:1527876979890};\\\", \\\"{x:843,y:572,t:1527876979906};\\\", \\\"{x:848,y:572,t:1527876979923};\\\", \\\"{x:850,y:572,t:1527876979940};\\\", \\\"{x:858,y:571,t:1527876979957};\\\", \\\"{x:862,y:569,t:1527876979973};\\\", \\\"{x:864,y:567,t:1527876979990};\\\", \\\"{x:865,y:566,t:1527876980006};\\\", \\\"{x:870,y:560,t:1527876980023};\\\", \\\"{x:874,y:556,t:1527876980040};\\\", \\\"{x:880,y:548,t:1527876980057};\\\", \\\"{x:885,y:542,t:1527876980072};\\\", \\\"{x:889,y:539,t:1527876980090};\\\", \\\"{x:890,y:538,t:1527876980106};\\\", \\\"{x:891,y:536,t:1527876980135};\\\", \\\"{x:891,y:535,t:1527876980151};\\\", \\\"{x:891,y:534,t:1527876980159};\\\", \\\"{x:887,y:533,t:1527876980173};\\\", \\\"{x:881,y:530,t:1527876980191};\\\", \\\"{x:876,y:527,t:1527876980207};\\\", \\\"{x:875,y:527,t:1527876980223};\\\", \\\"{x:873,y:527,t:1527876980264};\\\", \\\"{x:870,y:527,t:1527876980273};\\\", \\\"{x:860,y:528,t:1527876980291};\\\", \\\"{x:850,y:530,t:1527876980307};\\\", \\\"{x:843,y:532,t:1527876980324};\\\", \\\"{x:840,y:533,t:1527876980340};\\\", \\\"{x:839,y:534,t:1527876980727};\\\", \\\"{x:840,y:534,t:1527876980823};\\\", \\\"{x:845,y:535,t:1527876980840};\\\", \\\"{x:857,y:544,t:1527876980857};\\\", \\\"{x:875,y:554,t:1527876980874};\\\", \\\"{x:895,y:562,t:1527876980891};\\\", \\\"{x:913,y:570,t:1527876980908};\\\", \\\"{x:937,y:577,t:1527876980924};\\\", \\\"{x:974,y:583,t:1527876980941};\\\", \\\"{x:1013,y:589,t:1527876980957};\\\", \\\"{x:1046,y:594,t:1527876980974};\\\", \\\"{x:1084,y:594,t:1527876980991};\\\", \\\"{x:1100,y:594,t:1527876981007};\\\", \\\"{x:1112,y:594,t:1527876981024};\\\", \\\"{x:1116,y:594,t:1527876981041};\\\", \\\"{x:1117,y:594,t:1527876981057};\\\", \\\"{x:1119,y:594,t:1527876981075};\\\", \\\"{x:1121,y:594,t:1527876981092};\\\", \\\"{x:1123,y:594,t:1527876981107};\\\", \\\"{x:1126,y:594,t:1527876981124};\\\", \\\"{x:1129,y:593,t:1527876981141};\\\", \\\"{x:1130,y:593,t:1527876981158};\\\", \\\"{x:1131,y:593,t:1527876981174};\\\", \\\"{x:1132,y:592,t:1527876981193};\\\", \\\"{x:1131,y:592,t:1527876981897};\\\", \\\"{x:1127,y:599,t:1527876981908};\\\", \\\"{x:1121,y:622,t:1527876981925};\\\", \\\"{x:1118,y:635,t:1527876981942};\\\", \\\"{x:1119,y:642,t:1527876981958};\\\", \\\"{x:1123,y:647,t:1527876981975};\\\", \\\"{x:1136,y:649,t:1527876981993};\\\", \\\"{x:1148,y:649,t:1527876982008};\\\", \\\"{x:1173,y:648,t:1527876982025};\\\", \\\"{x:1213,y:643,t:1527876982041};\\\", \\\"{x:1267,y:635,t:1527876982057};\\\", \\\"{x:1301,y:631,t:1527876982074};\\\", \\\"{x:1336,y:626,t:1527876982092};\\\", \\\"{x:1366,y:622,t:1527876982108};\\\", \\\"{x:1385,y:620,t:1527876982125};\\\", \\\"{x:1388,y:620,t:1527876982142};\\\", \\\"{x:1389,y:620,t:1527876982247};\\\", \\\"{x:1389,y:619,t:1527876982303};\\\", \\\"{x:1389,y:617,t:1527876982319};\\\", \\\"{x:1389,y:612,t:1527876982327};\\\", \\\"{x:1390,y:609,t:1527876982342};\\\", \\\"{x:1395,y:602,t:1527876982358};\\\", \\\"{x:1400,y:596,t:1527876982375};\\\", \\\"{x:1403,y:590,t:1527876982391};\\\", \\\"{x:1405,y:589,t:1527876982407};\\\", \\\"{x:1406,y:588,t:1527876982424};\\\", \\\"{x:1407,y:587,t:1527876982513};\\\", \\\"{x:1408,y:586,t:1527876982528};\\\", \\\"{x:1409,y:584,t:1527876982544};\\\", \\\"{x:1409,y:583,t:1527876982560};\\\", \\\"{x:1409,y:581,t:1527876982575};\\\", \\\"{x:1409,y:576,t:1527876982593};\\\", \\\"{x:1409,y:572,t:1527876982608};\\\", \\\"{x:1409,y:569,t:1527876982625};\\\", \\\"{x:1409,y:567,t:1527876982641};\\\", \\\"{x:1410,y:567,t:1527876982659};\\\", \\\"{x:1411,y:566,t:1527876982744};\\\", \\\"{x:1411,y:567,t:1527876984409};\\\", \\\"{x:1401,y:571,t:1527876984427};\\\", \\\"{x:1390,y:577,t:1527876984442};\\\", \\\"{x:1382,y:581,t:1527876984458};\\\", \\\"{x:1370,y:588,t:1527876984476};\\\", \\\"{x:1356,y:596,t:1527876984491};\\\", \\\"{x:1339,y:603,t:1527876984508};\\\", \\\"{x:1317,y:615,t:1527876984526};\\\", \\\"{x:1285,y:628,t:1527876984542};\\\", \\\"{x:1225,y:641,t:1527876984559};\\\", \\\"{x:1112,y:657,t:1527876984576};\\\", \\\"{x:1029,y:668,t:1527876984592};\\\", \\\"{x:962,y:679,t:1527876984609};\\\", \\\"{x:895,y:687,t:1527876984626};\\\", \\\"{x:824,y:702,t:1527876984642};\\\", \\\"{x:760,y:710,t:1527876984658};\\\", \\\"{x:712,y:717,t:1527876984676};\\\", \\\"{x:662,y:725,t:1527876984692};\\\", \\\"{x:626,y:729,t:1527876984708};\\\", \\\"{x:592,y:734,t:1527876984726};\\\", \\\"{x:568,y:737,t:1527876984741};\\\", \\\"{x:546,y:741,t:1527876984760};\\\", \\\"{x:518,y:745,t:1527876984775};\\\", \\\"{x:504,y:746,t:1527876984791};\\\", \\\"{x:494,y:748,t:1527876984810};\\\", \\\"{x:490,y:749,t:1527876984827};\\\", \\\"{x:484,y:749,t:1527876984844};\\\", \\\"{x:480,y:749,t:1527876984861};\\\", \\\"{x:477,y:749,t:1527876984878};\\\", \\\"{x:474,y:749,t:1527876984894};\\\", \\\"{x:474,y:748,t:1527876985040};\\\", \\\"{x:475,y:747,t:1527876985055};\\\", \\\"{x:476,y:746,t:1527876985064};\\\", \\\"{x:477,y:746,t:1527876985080};\\\", \\\"{x:479,y:745,t:1527876985095};\\\", \\\"{x:480,y:745,t:1527876985112};\\\", \\\"{x:482,y:744,t:1527876985128};\\\", \\\"{x:483,y:743,t:1527876985151};\\\", \\\"{x:485,y:742,t:1527876985193};\\\", \\\"{x:486,y:742,t:1527876985208};\\\", \\\"{x:486,y:741,t:1527876985224};\\\" ] }, { \\\"rt\\\": 32508, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 612356, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:488,y:741,t:1527876992176};\\\", \\\"{x:492,y:741,t:1527876992184};\\\", \\\"{x:513,y:751,t:1527876992200};\\\", \\\"{x:533,y:755,t:1527876992217};\\\", \\\"{x:556,y:760,t:1527876992233};\\\", \\\"{x:580,y:762,t:1527876992250};\\\", \\\"{x:618,y:763,t:1527876992267};\\\", \\\"{x:698,y:770,t:1527876992284};\\\", \\\"{x:804,y:772,t:1527876992299};\\\", \\\"{x:912,y:772,t:1527876992317};\\\", \\\"{x:1028,y:772,t:1527876992333};\\\", \\\"{x:1131,y:772,t:1527876992351};\\\", \\\"{x:1225,y:772,t:1527876992367};\\\", \\\"{x:1337,y:759,t:1527876992383};\\\", \\\"{x:1377,y:758,t:1527876992401};\\\", \\\"{x:1403,y:753,t:1527876992417};\\\", \\\"{x:1416,y:752,t:1527876992433};\\\", \\\"{x:1422,y:752,t:1527876992451};\\\", \\\"{x:1426,y:752,t:1527876992467};\\\", \\\"{x:1430,y:751,t:1527876992484};\\\", \\\"{x:1434,y:750,t:1527876992501};\\\", \\\"{x:1433,y:750,t:1527876993849};\\\", \\\"{x:1432,y:750,t:1527876993880};\\\", \\\"{x:1431,y:750,t:1527876993904};\\\", \\\"{x:1428,y:750,t:1527876993920};\\\", \\\"{x:1420,y:750,t:1527876993936};\\\", \\\"{x:1407,y:750,t:1527876993952};\\\", \\\"{x:1395,y:750,t:1527876993970};\\\", \\\"{x:1387,y:750,t:1527876993987};\\\", \\\"{x:1383,y:750,t:1527876994003};\\\", \\\"{x:1377,y:750,t:1527876994019};\\\", \\\"{x:1375,y:750,t:1527876994036};\\\", \\\"{x:1372,y:750,t:1527876994051};\\\", \\\"{x:1369,y:752,t:1527876994068};\\\", \\\"{x:1368,y:753,t:1527876994086};\\\", \\\"{x:1367,y:753,t:1527876994102};\\\", \\\"{x:1366,y:753,t:1527876994119};\\\", \\\"{x:1361,y:753,t:1527876994135};\\\", \\\"{x:1357,y:753,t:1527876994151};\\\", \\\"{x:1354,y:753,t:1527876994169};\\\", \\\"{x:1351,y:753,t:1527876994186};\\\", \\\"{x:1348,y:753,t:1527876994203};\\\", \\\"{x:1347,y:753,t:1527876994219};\\\", \\\"{x:1345,y:753,t:1527876994248};\\\", \\\"{x:1344,y:754,t:1527876994272};\\\", \\\"{x:1342,y:754,t:1527876994287};\\\", \\\"{x:1338,y:754,t:1527876994304};\\\", \\\"{x:1322,y:754,t:1527876994320};\\\", \\\"{x:1297,y:756,t:1527876994336};\\\", \\\"{x:1281,y:757,t:1527876994354};\\\", \\\"{x:1262,y:761,t:1527876994370};\\\", \\\"{x:1251,y:764,t:1527876994386};\\\", \\\"{x:1242,y:767,t:1527876994404};\\\", \\\"{x:1238,y:768,t:1527876994419};\\\", \\\"{x:1234,y:768,t:1527876994437};\\\", \\\"{x:1232,y:770,t:1527876994453};\\\", \\\"{x:1228,y:770,t:1527876994469};\\\", \\\"{x:1224,y:771,t:1527876994486};\\\", \\\"{x:1216,y:772,t:1527876994504};\\\", \\\"{x:1205,y:777,t:1527876994520};\\\", \\\"{x:1200,y:782,t:1527876994536};\\\", \\\"{x:1196,y:787,t:1527876994553};\\\", \\\"{x:1191,y:791,t:1527876994570};\\\", \\\"{x:1190,y:793,t:1527876994586};\\\", \\\"{x:1189,y:795,t:1527876994603};\\\", \\\"{x:1188,y:796,t:1527876994620};\\\", \\\"{x:1187,y:797,t:1527876994655};\\\", \\\"{x:1187,y:798,t:1527876994695};\\\", \\\"{x:1186,y:800,t:1527876994702};\\\", \\\"{x:1186,y:805,t:1527876994720};\\\", \\\"{x:1186,y:810,t:1527876994736};\\\", \\\"{x:1184,y:811,t:1527876994753};\\\", \\\"{x:1184,y:812,t:1527876994840};\\\", \\\"{x:1184,y:813,t:1527876994853};\\\", \\\"{x:1184,y:815,t:1527876994870};\\\", \\\"{x:1185,y:816,t:1527876994888};\\\", \\\"{x:1185,y:817,t:1527876994903};\\\", \\\"{x:1186,y:817,t:1527876994960};\\\", \\\"{x:1187,y:817,t:1527876994971};\\\", \\\"{x:1188,y:817,t:1527876994991};\\\", \\\"{x:1189,y:818,t:1527876995008};\\\", \\\"{x:1190,y:818,t:1527876995032};\\\", \\\"{x:1191,y:818,t:1527876995192};\\\", \\\"{x:1193,y:818,t:1527876995204};\\\", \\\"{x:1195,y:818,t:1527876995224};\\\", \\\"{x:1196,y:818,t:1527876998064};\\\", \\\"{x:1200,y:817,t:1527876998074};\\\", \\\"{x:1206,y:815,t:1527876998090};\\\", \\\"{x:1209,y:814,t:1527876998107};\\\", \\\"{x:1213,y:812,t:1527876998124};\\\", \\\"{x:1218,y:810,t:1527876998142};\\\", \\\"{x:1221,y:808,t:1527876998158};\\\", \\\"{x:1226,y:806,t:1527876998175};\\\", \\\"{x:1231,y:804,t:1527876998191};\\\", \\\"{x:1243,y:804,t:1527876998208};\\\", \\\"{x:1250,y:802,t:1527876998224};\\\", \\\"{x:1255,y:802,t:1527876998241};\\\", \\\"{x:1260,y:802,t:1527876998258};\\\", \\\"{x:1262,y:802,t:1527876998274};\\\", \\\"{x:1265,y:802,t:1527876998291};\\\", \\\"{x:1267,y:803,t:1527876998308};\\\", \\\"{x:1270,y:803,t:1527876998324};\\\", \\\"{x:1272,y:803,t:1527876998341};\\\", \\\"{x:1275,y:803,t:1527876998358};\\\", \\\"{x:1277,y:803,t:1527876998375};\\\", \\\"{x:1278,y:803,t:1527876998391};\\\", \\\"{x:1280,y:803,t:1527876998408};\\\", \\\"{x:1283,y:803,t:1527876998425};\\\", \\\"{x:1288,y:803,t:1527876998442};\\\", \\\"{x:1292,y:803,t:1527876998457};\\\", \\\"{x:1295,y:803,t:1527876998474};\\\", \\\"{x:1297,y:802,t:1527876998491};\\\", \\\"{x:1299,y:801,t:1527876998508};\\\", \\\"{x:1301,y:800,t:1527876998525};\\\", \\\"{x:1302,y:800,t:1527876998560};\\\", \\\"{x:1303,y:799,t:1527876998574};\\\", \\\"{x:1304,y:799,t:1527876998592};\\\", \\\"{x:1305,y:798,t:1527876998608};\\\", \\\"{x:1307,y:797,t:1527876998624};\\\", \\\"{x:1308,y:797,t:1527876998642};\\\", \\\"{x:1309,y:797,t:1527876998657};\\\", \\\"{x:1312,y:795,t:1527876998675};\\\", \\\"{x:1314,y:792,t:1527876998691};\\\", \\\"{x:1315,y:791,t:1527876998709};\\\", \\\"{x:1317,y:789,t:1527876998725};\\\", \\\"{x:1320,y:788,t:1527876998741};\\\", \\\"{x:1321,y:787,t:1527876998759};\\\", \\\"{x:1324,y:786,t:1527876998774};\\\", \\\"{x:1326,y:785,t:1527876998792};\\\", \\\"{x:1327,y:784,t:1527876998808};\\\", \\\"{x:1329,y:783,t:1527876998824};\\\", \\\"{x:1330,y:782,t:1527876998841};\\\", \\\"{x:1331,y:780,t:1527876998859};\\\", \\\"{x:1332,y:780,t:1527876998874};\\\", \\\"{x:1333,y:779,t:1527876998920};\\\", \\\"{x:1334,y:779,t:1527876998952};\\\", \\\"{x:1335,y:782,t:1527876999096};\\\", \\\"{x:1338,y:786,t:1527876999108};\\\", \\\"{x:1339,y:789,t:1527876999126};\\\", \\\"{x:1341,y:791,t:1527876999142};\\\", \\\"{x:1342,y:791,t:1527876999158};\\\", \\\"{x:1342,y:792,t:1527876999208};\\\", \\\"{x:1342,y:793,t:1527876999226};\\\", \\\"{x:1343,y:794,t:1527876999242};\\\", \\\"{x:1343,y:797,t:1527876999258};\\\", \\\"{x:1344,y:798,t:1527876999275};\\\", \\\"{x:1344,y:799,t:1527876999303};\\\", \\\"{x:1343,y:799,t:1527876999311};\\\", \\\"{x:1342,y:799,t:1527876999327};\\\", \\\"{x:1341,y:799,t:1527876999342};\\\", \\\"{x:1340,y:800,t:1527876999367};\\\", \\\"{x:1339,y:800,t:1527876999375};\\\", \\\"{x:1338,y:801,t:1527876999415};\\\", \\\"{x:1336,y:799,t:1527876999456};\\\", \\\"{x:1334,y:798,t:1527876999464};\\\", \\\"{x:1333,y:797,t:1527876999476};\\\", \\\"{x:1328,y:791,t:1527876999492};\\\", \\\"{x:1324,y:788,t:1527876999509};\\\", \\\"{x:1322,y:787,t:1527876999526};\\\", \\\"{x:1322,y:786,t:1527876999542};\\\", \\\"{x:1322,y:785,t:1527876999576};\\\", \\\"{x:1322,y:783,t:1527876999600};\\\", \\\"{x:1322,y:780,t:1527876999610};\\\", \\\"{x:1319,y:776,t:1527876999626};\\\", \\\"{x:1316,y:771,t:1527876999643};\\\", \\\"{x:1316,y:766,t:1527876999659};\\\", \\\"{x:1315,y:759,t:1527876999676};\\\", \\\"{x:1315,y:757,t:1527876999693};\\\", \\\"{x:1315,y:755,t:1527876999709};\\\", \\\"{x:1314,y:755,t:1527876999726};\\\", \\\"{x:1314,y:752,t:1527876999743};\\\", \\\"{x:1314,y:748,t:1527876999760};\\\", \\\"{x:1312,y:743,t:1527876999776};\\\", \\\"{x:1307,y:736,t:1527876999793};\\\", \\\"{x:1298,y:723,t:1527876999810};\\\", \\\"{x:1290,y:710,t:1527876999825};\\\", \\\"{x:1284,y:701,t:1527876999843};\\\", \\\"{x:1281,y:698,t:1527876999859};\\\", \\\"{x:1278,y:695,t:1527876999876};\\\", \\\"{x:1278,y:694,t:1527876999912};\\\", \\\"{x:1277,y:691,t:1527876999944};\\\", \\\"{x:1274,y:688,t:1527876999960};\\\", \\\"{x:1273,y:686,t:1527876999976};\\\", \\\"{x:1269,y:686,t:1527876999992};\\\", \\\"{x:1268,y:686,t:1527877000010};\\\", \\\"{x:1267,y:686,t:1527877000296};\\\", \\\"{x:1265,y:686,t:1527877000310};\\\", \\\"{x:1263,y:686,t:1527877000328};\\\", \\\"{x:1262,y:686,t:1527877000344};\\\", \\\"{x:1261,y:687,t:1527877000359};\\\", \\\"{x:1257,y:689,t:1527877000377};\\\", \\\"{x:1256,y:689,t:1527877000394};\\\", \\\"{x:1254,y:690,t:1527877000409};\\\", \\\"{x:1248,y:697,t:1527877000426};\\\", \\\"{x:1242,y:704,t:1527877000443};\\\", \\\"{x:1237,y:711,t:1527877000460};\\\", \\\"{x:1231,y:722,t:1527877000477};\\\", \\\"{x:1225,y:735,t:1527877000493};\\\", \\\"{x:1220,y:747,t:1527877000511};\\\", \\\"{x:1216,y:760,t:1527877000527};\\\", \\\"{x:1211,y:783,t:1527877000544};\\\", \\\"{x:1210,y:796,t:1527877000559};\\\", \\\"{x:1208,y:802,t:1527877000576};\\\", \\\"{x:1207,y:806,t:1527877000593};\\\", \\\"{x:1206,y:809,t:1527877000611};\\\", \\\"{x:1206,y:812,t:1527877000627};\\\", \\\"{x:1206,y:814,t:1527877000643};\\\", \\\"{x:1206,y:816,t:1527877000660};\\\", \\\"{x:1207,y:817,t:1527877000676};\\\", \\\"{x:1207,y:818,t:1527877000693};\\\", \\\"{x:1207,y:819,t:1527877000710};\\\", \\\"{x:1207,y:820,t:1527877000726};\\\", \\\"{x:1208,y:820,t:1527877001000};\\\", \\\"{x:1211,y:820,t:1527877001011};\\\", \\\"{x:1214,y:818,t:1527877001027};\\\", \\\"{x:1216,y:810,t:1527877001044};\\\", \\\"{x:1218,y:803,t:1527877001060};\\\", \\\"{x:1219,y:796,t:1527877001078};\\\", \\\"{x:1219,y:789,t:1527877001094};\\\", \\\"{x:1219,y:784,t:1527877001110};\\\", \\\"{x:1219,y:782,t:1527877001128};\\\", \\\"{x:1219,y:781,t:1527877001145};\\\", \\\"{x:1219,y:780,t:1527877001161};\\\", \\\"{x:1219,y:779,t:1527877001178};\\\", \\\"{x:1220,y:778,t:1527877001195};\\\", \\\"{x:1220,y:776,t:1527877001210};\\\", \\\"{x:1220,y:771,t:1527877001228};\\\", \\\"{x:1217,y:766,t:1527877001244};\\\", \\\"{x:1213,y:761,t:1527877001260};\\\", \\\"{x:1206,y:758,t:1527877001277};\\\", \\\"{x:1204,y:757,t:1527877001294};\\\", \\\"{x:1203,y:757,t:1527877001310};\\\", \\\"{x:1202,y:756,t:1527877001425};\\\", \\\"{x:1200,y:756,t:1527877001560};\\\", \\\"{x:1199,y:756,t:1527877001568};\\\", \\\"{x:1198,y:756,t:1527877001672};\\\", \\\"{x:1197,y:756,t:1527877001679};\\\", \\\"{x:1196,y:756,t:1527877001711};\\\", \\\"{x:1194,y:756,t:1527877001728};\\\", \\\"{x:1192,y:757,t:1527877001745};\\\", \\\"{x:1191,y:757,t:1527877002688};\\\", \\\"{x:1190,y:758,t:1527877002704};\\\", \\\"{x:1189,y:759,t:1527877002752};\\\", \\\"{x:1189,y:762,t:1527877002792};\\\", \\\"{x:1189,y:765,t:1527877002800};\\\", \\\"{x:1189,y:766,t:1527877002812};\\\", \\\"{x:1189,y:768,t:1527877002831};\\\", \\\"{x:1189,y:769,t:1527877002846};\\\", \\\"{x:1187,y:772,t:1527877002862};\\\", \\\"{x:1187,y:774,t:1527877002880};\\\", \\\"{x:1187,y:775,t:1527877002896};\\\", \\\"{x:1187,y:776,t:1527877002927};\\\", \\\"{x:1187,y:782,t:1527877004697};\\\", \\\"{x:1190,y:789,t:1527877004704};\\\", \\\"{x:1199,y:797,t:1527877004715};\\\", \\\"{x:1217,y:818,t:1527877004732};\\\", \\\"{x:1245,y:848,t:1527877004749};\\\", \\\"{x:1263,y:873,t:1527877004765};\\\", \\\"{x:1275,y:894,t:1527877004782};\\\", \\\"{x:1283,y:901,t:1527877004799};\\\", \\\"{x:1291,y:910,t:1527877004815};\\\", \\\"{x:1296,y:914,t:1527877004831};\\\", \\\"{x:1296,y:915,t:1527877004849};\\\", \\\"{x:1296,y:916,t:1527877004905};\\\", \\\"{x:1297,y:918,t:1527877004915};\\\", \\\"{x:1298,y:922,t:1527877004932};\\\", \\\"{x:1298,y:925,t:1527877004949};\\\", \\\"{x:1299,y:926,t:1527877004965};\\\", \\\"{x:1299,y:929,t:1527877004982};\\\", \\\"{x:1299,y:931,t:1527877004999};\\\", \\\"{x:1297,y:936,t:1527877005015};\\\", \\\"{x:1292,y:939,t:1527877005031};\\\", \\\"{x:1291,y:941,t:1527877005049};\\\", \\\"{x:1290,y:941,t:1527877005240};\\\", \\\"{x:1290,y:942,t:1527877005272};\\\", \\\"{x:1289,y:943,t:1527877005377};\\\", \\\"{x:1288,y:943,t:1527877005969};\\\", \\\"{x:1285,y:943,t:1527877005992};\\\", \\\"{x:1284,y:943,t:1527877006000};\\\", \\\"{x:1280,y:938,t:1527877006017};\\\", \\\"{x:1276,y:933,t:1527877006033};\\\", \\\"{x:1274,y:929,t:1527877006050};\\\", \\\"{x:1270,y:922,t:1527877006066};\\\", \\\"{x:1268,y:918,t:1527877006083};\\\", \\\"{x:1266,y:914,t:1527877006100};\\\", \\\"{x:1265,y:912,t:1527877006117};\\\", \\\"{x:1265,y:909,t:1527877006133};\\\", \\\"{x:1263,y:903,t:1527877006150};\\\", \\\"{x:1261,y:899,t:1527877006167};\\\", \\\"{x:1260,y:897,t:1527877006183};\\\", \\\"{x:1260,y:896,t:1527877006200};\\\", \\\"{x:1259,y:894,t:1527877006217};\\\", \\\"{x:1259,y:893,t:1527877006304};\\\", \\\"{x:1257,y:890,t:1527877006317};\\\", \\\"{x:1255,y:886,t:1527877006334};\\\", \\\"{x:1253,y:882,t:1527877006350};\\\", \\\"{x:1245,y:874,t:1527877006367};\\\", \\\"{x:1226,y:857,t:1527877006383};\\\", \\\"{x:1215,y:848,t:1527877006400};\\\", \\\"{x:1204,y:837,t:1527877006417};\\\", \\\"{x:1198,y:828,t:1527877006434};\\\", \\\"{x:1188,y:813,t:1527877006450};\\\", \\\"{x:1179,y:799,t:1527877006467};\\\", \\\"{x:1172,y:789,t:1527877006484};\\\", \\\"{x:1164,y:777,t:1527877006500};\\\", \\\"{x:1157,y:770,t:1527877006517};\\\", \\\"{x:1157,y:769,t:1527877006534};\\\", \\\"{x:1155,y:767,t:1527877006551};\\\", \\\"{x:1154,y:767,t:1527877006871};\\\", \\\"{x:1153,y:767,t:1527877006884};\\\", \\\"{x:1152,y:767,t:1527877006900};\\\", \\\"{x:1152,y:771,t:1527877006918};\\\", \\\"{x:1152,y:776,t:1527877006934};\\\", \\\"{x:1152,y:779,t:1527877006950};\\\", \\\"{x:1152,y:787,t:1527877006967};\\\", \\\"{x:1152,y:788,t:1527877006984};\\\", \\\"{x:1152,y:789,t:1527877007001};\\\", \\\"{x:1151,y:790,t:1527877007055};\\\", \\\"{x:1151,y:791,t:1527877007068};\\\", \\\"{x:1150,y:793,t:1527877007084};\\\", \\\"{x:1149,y:795,t:1527877007100};\\\", \\\"{x:1149,y:796,t:1527877007118};\\\", \\\"{x:1148,y:797,t:1527877007135};\\\", \\\"{x:1148,y:798,t:1527877007151};\\\", \\\"{x:1146,y:800,t:1527877008161};\\\", \\\"{x:1145,y:800,t:1527877008184};\\\", \\\"{x:1144,y:801,t:1527877008232};\\\", \\\"{x:1143,y:801,t:1527877008240};\\\", \\\"{x:1143,y:802,t:1527877008252};\\\", \\\"{x:1142,y:802,t:1527877008269};\\\", \\\"{x:1141,y:803,t:1527877008286};\\\", \\\"{x:1139,y:803,t:1527877008302};\\\", \\\"{x:1137,y:803,t:1527877008319};\\\", \\\"{x:1132,y:804,t:1527877008336};\\\", \\\"{x:1126,y:805,t:1527877008353};\\\", \\\"{x:1120,y:807,t:1527877008369};\\\", \\\"{x:1114,y:808,t:1527877008386};\\\", \\\"{x:1109,y:811,t:1527877008403};\\\", \\\"{x:1103,y:814,t:1527877008419};\\\", \\\"{x:1097,y:816,t:1527877008436};\\\", \\\"{x:1092,y:819,t:1527877008453};\\\", \\\"{x:1084,y:821,t:1527877008469};\\\", \\\"{x:1073,y:823,t:1527877008486};\\\", \\\"{x:1065,y:825,t:1527877008504};\\\", \\\"{x:1054,y:826,t:1527877008519};\\\", \\\"{x:1040,y:828,t:1527877008535};\\\", \\\"{x:1030,y:831,t:1527877008553};\\\", \\\"{x:1017,y:832,t:1527877008569};\\\", \\\"{x:1008,y:832,t:1527877008587};\\\", \\\"{x:995,y:835,t:1527877008603};\\\", \\\"{x:980,y:835,t:1527877008620};\\\", \\\"{x:965,y:835,t:1527877008636};\\\", \\\"{x:943,y:835,t:1527877008653};\\\", \\\"{x:923,y:835,t:1527877008670};\\\", \\\"{x:900,y:835,t:1527877008685};\\\", \\\"{x:882,y:835,t:1527877008703};\\\", \\\"{x:857,y:835,t:1527877008720};\\\", \\\"{x:843,y:830,t:1527877008736};\\\", \\\"{x:835,y:819,t:1527877008753};\\\", \\\"{x:828,y:800,t:1527877008770};\\\", \\\"{x:815,y:781,t:1527877008786};\\\", \\\"{x:798,y:768,t:1527877008803};\\\", \\\"{x:773,y:751,t:1527877008820};\\\", \\\"{x:726,y:711,t:1527877008836};\\\", \\\"{x:689,y:684,t:1527877008853};\\\", \\\"{x:665,y:673,t:1527877008870};\\\", \\\"{x:640,y:661,t:1527877008886};\\\", \\\"{x:623,y:657,t:1527877008903};\\\", \\\"{x:594,y:649,t:1527877008920};\\\", \\\"{x:579,y:647,t:1527877008937};\\\", \\\"{x:562,y:645,t:1527877008953};\\\", \\\"{x:547,y:642,t:1527877008970};\\\", \\\"{x:530,y:640,t:1527877008987};\\\", \\\"{x:518,y:640,t:1527877009002};\\\", \\\"{x:508,y:640,t:1527877009020};\\\", \\\"{x:499,y:640,t:1527877009038};\\\", \\\"{x:492,y:640,t:1527877009053};\\\", \\\"{x:487,y:640,t:1527877009069};\\\", \\\"{x:484,y:640,t:1527877009080};\\\", \\\"{x:482,y:640,t:1527877009096};\\\", \\\"{x:479,y:640,t:1527877009113};\\\", \\\"{x:471,y:640,t:1527877009130};\\\", \\\"{x:459,y:637,t:1527877009147};\\\", \\\"{x:448,y:634,t:1527877009163};\\\", \\\"{x:437,y:629,t:1527877009181};\\\", \\\"{x:431,y:626,t:1527877009197};\\\", \\\"{x:421,y:621,t:1527877009213};\\\", \\\"{x:400,y:616,t:1527877009232};\\\", \\\"{x:384,y:610,t:1527877009247};\\\", \\\"{x:361,y:599,t:1527877009265};\\\", \\\"{x:333,y:583,t:1527877009281};\\\", \\\"{x:314,y:573,t:1527877009298};\\\", \\\"{x:312,y:572,t:1527877009314};\\\", \\\"{x:308,y:569,t:1527877009331};\\\", \\\"{x:308,y:568,t:1527877009347};\\\", \\\"{x:305,y:567,t:1527877009364};\\\", \\\"{x:300,y:564,t:1527877009380};\\\", \\\"{x:298,y:563,t:1527877009401};\\\", \\\"{x:298,y:562,t:1527877009418};\\\", \\\"{x:297,y:561,t:1527877009434};\\\", \\\"{x:294,y:557,t:1527877009450};\\\", \\\"{x:292,y:552,t:1527877009467};\\\", \\\"{x:288,y:547,t:1527877009484};\\\", \\\"{x:284,y:542,t:1527877009501};\\\", \\\"{x:270,y:538,t:1527877009519};\\\", \\\"{x:253,y:537,t:1527877009534};\\\", \\\"{x:241,y:536,t:1527877009551};\\\", \\\"{x:227,y:534,t:1527877009568};\\\", \\\"{x:220,y:533,t:1527877009585};\\\", \\\"{x:212,y:532,t:1527877009602};\\\", \\\"{x:198,y:528,t:1527877009618};\\\", \\\"{x:184,y:523,t:1527877009636};\\\", \\\"{x:176,y:523,t:1527877009651};\\\", \\\"{x:169,y:522,t:1527877009668};\\\", \\\"{x:163,y:521,t:1527877009685};\\\", \\\"{x:162,y:521,t:1527877009701};\\\", \\\"{x:162,y:520,t:1527877009795};\\\", \\\"{x:162,y:518,t:1527877009802};\\\", \\\"{x:162,y:517,t:1527877009819};\\\", \\\"{x:162,y:509,t:1527877009835};\\\", \\\"{x:162,y:502,t:1527877009851};\\\", \\\"{x:163,y:499,t:1527877009868};\\\", \\\"{x:163,y:496,t:1527877009885};\\\", \\\"{x:163,y:495,t:1527877009901};\\\", \\\"{x:163,y:493,t:1527877009923};\\\", \\\"{x:163,y:492,t:1527877009947};\\\", \\\"{x:164,y:490,t:1527877009963};\\\", \\\"{x:165,y:488,t:1527877009972};\\\", \\\"{x:166,y:487,t:1527877010003};\\\", \\\"{x:166,y:486,t:1527877010468};\\\", \\\"{x:168,y:487,t:1527877010500};\\\", \\\"{x:171,y:489,t:1527877010519};\\\", \\\"{x:173,y:492,t:1527877010535};\\\", \\\"{x:174,y:498,t:1527877010552};\\\", \\\"{x:177,y:505,t:1527877010569};\\\", \\\"{x:180,y:511,t:1527877010584};\\\", \\\"{x:180,y:513,t:1527877010602};\\\", \\\"{x:180,y:515,t:1527877010618};\\\", \\\"{x:181,y:515,t:1527877010674};\\\", \\\"{x:182,y:516,t:1527877010685};\\\", \\\"{x:182,y:518,t:1527877010702};\\\", \\\"{x:182,y:519,t:1527877010796};\\\", \\\"{x:183,y:519,t:1527877010803};\\\", \\\"{x:184,y:524,t:1527877010819};\\\", \\\"{x:186,y:529,t:1527877010836};\\\", \\\"{x:187,y:531,t:1527877010851};\\\", \\\"{x:190,y:534,t:1527877010869};\\\", \\\"{x:192,y:535,t:1527877010885};\\\", \\\"{x:194,y:536,t:1527877010901};\\\", \\\"{x:196,y:537,t:1527877010919};\\\", \\\"{x:197,y:537,t:1527877010938};\\\", \\\"{x:200,y:540,t:1527877010952};\\\", \\\"{x:208,y:545,t:1527877010968};\\\", \\\"{x:227,y:551,t:1527877010985};\\\", \\\"{x:247,y:560,t:1527877011002};\\\", \\\"{x:270,y:566,t:1527877011019};\\\", \\\"{x:283,y:570,t:1527877011036};\\\", \\\"{x:288,y:571,t:1527877011052};\\\", \\\"{x:289,y:572,t:1527877011107};\\\", \\\"{x:289,y:573,t:1527877011123};\\\", \\\"{x:289,y:574,t:1527877011135};\\\", \\\"{x:288,y:574,t:1527877011152};\\\", \\\"{x:282,y:575,t:1527877011169};\\\", \\\"{x:277,y:577,t:1527877011186};\\\", \\\"{x:267,y:577,t:1527877011204};\\\", \\\"{x:254,y:575,t:1527877011219};\\\", \\\"{x:242,y:567,t:1527877011236};\\\", \\\"{x:233,y:560,t:1527877011253};\\\", \\\"{x:222,y:552,t:1527877011270};\\\", \\\"{x:211,y:546,t:1527877011286};\\\", \\\"{x:205,y:542,t:1527877011302};\\\", \\\"{x:199,y:539,t:1527877011319};\\\", \\\"{x:195,y:538,t:1527877011336};\\\", \\\"{x:192,y:537,t:1527877011353};\\\", \\\"{x:190,y:536,t:1527877011370};\\\", \\\"{x:190,y:535,t:1527877011386};\\\", \\\"{x:190,y:533,t:1527877011403};\\\", \\\"{x:186,y:529,t:1527877011419};\\\", \\\"{x:184,y:526,t:1527877011436};\\\", \\\"{x:184,y:523,t:1527877011453};\\\", \\\"{x:184,y:519,t:1527877011469};\\\", \\\"{x:183,y:514,t:1527877011486};\\\", \\\"{x:180,y:511,t:1527877011503};\\\", \\\"{x:178,y:510,t:1527877011519};\\\", \\\"{x:176,y:510,t:1527877011875};\\\", \\\"{x:176,y:510,t:1527877011889};\\\", \\\"{x:175,y:510,t:1527877011903};\\\", \\\"{x:174,y:510,t:1527877011920};\\\", \\\"{x:172,y:510,t:1527877011936};\\\", \\\"{x:171,y:511,t:1527877011954};\\\", \\\"{x:170,y:511,t:1527877011970};\\\", \\\"{x:168,y:512,t:1527877011985};\\\", \\\"{x:165,y:513,t:1527877012003};\\\", \\\"{x:164,y:513,t:1527877012020};\\\", \\\"{x:169,y:513,t:1527877012242};\\\", \\\"{x:176,y:510,t:1527877012253};\\\", \\\"{x:187,y:505,t:1527877012270};\\\", \\\"{x:191,y:505,t:1527877012286};\\\", \\\"{x:197,y:506,t:1527877012303};\\\", \\\"{x:213,y:515,t:1527877012320};\\\", \\\"{x:242,y:533,t:1527877012337};\\\", \\\"{x:301,y:553,t:1527877012354};\\\", \\\"{x:389,y:574,t:1527877012371};\\\", \\\"{x:521,y:591,t:1527877012388};\\\", \\\"{x:592,y:597,t:1527877012403};\\\", \\\"{x:636,y:597,t:1527877012420};\\\", \\\"{x:667,y:598,t:1527877012437};\\\", \\\"{x:685,y:602,t:1527877012456};\\\", \\\"{x:691,y:604,t:1527877012470};\\\", \\\"{x:692,y:605,t:1527877012487};\\\", \\\"{x:692,y:607,t:1527877012867};\\\", \\\"{x:687,y:609,t:1527877012875};\\\", \\\"{x:681,y:612,t:1527877012886};\\\", \\\"{x:673,y:616,t:1527877012903};\\\", \\\"{x:666,y:618,t:1527877012920};\\\", \\\"{x:665,y:620,t:1527877012936};\\\", \\\"{x:663,y:620,t:1527877012952};\\\", \\\"{x:661,y:621,t:1527877012969};\\\", \\\"{x:656,y:627,t:1527877012986};\\\", \\\"{x:653,y:631,t:1527877013002};\\\", \\\"{x:652,y:632,t:1527877013020};\\\", \\\"{x:651,y:633,t:1527877013059};\\\", \\\"{x:650,y:633,t:1527877013071};\\\", \\\"{x:649,y:635,t:1527877013087};\\\", \\\"{x:644,y:639,t:1527877013104};\\\", \\\"{x:639,y:647,t:1527877013121};\\\", \\\"{x:635,y:655,t:1527877013137};\\\", \\\"{x:629,y:662,t:1527877013154};\\\", \\\"{x:623,y:670,t:1527877013171};\\\", \\\"{x:618,y:675,t:1527877013187};\\\", \\\"{x:615,y:677,t:1527877013204};\\\", \\\"{x:613,y:679,t:1527877013221};\\\", \\\"{x:610,y:681,t:1527877013238};\\\", \\\"{x:609,y:681,t:1527877013396};\\\", \\\"{x:609,y:682,t:1527877013405};\\\", \\\"{x:609,y:683,t:1527877013421};\\\", \\\"{x:607,y:684,t:1527877013438};\\\", \\\"{x:602,y:692,t:1527877013454};\\\", \\\"{x:595,y:703,t:1527877013471};\\\", \\\"{x:590,y:713,t:1527877013488};\\\", \\\"{x:586,y:721,t:1527877013506};\\\", \\\"{x:583,y:727,t:1527877013521};\\\", \\\"{x:581,y:729,t:1527877013539};\\\", \\\"{x:579,y:732,t:1527877013555};\\\", \\\"{x:578,y:734,t:1527877013572};\\\", \\\"{x:578,y:735,t:1527877013588};\\\", \\\"{x:576,y:737,t:1527877013605};\\\", \\\"{x:576,y:741,t:1527877013622};\\\", \\\"{x:576,y:745,t:1527877013638};\\\", \\\"{x:576,y:748,t:1527877013655};\\\", \\\"{x:575,y:749,t:1527877013672};\\\", \\\"{x:575,y:750,t:1527877013724};\\\", \\\"{x:574,y:751,t:1527877013739};\\\", \\\"{x:573,y:754,t:1527877013755};\\\", \\\"{x:573,y:755,t:1527877013772};\\\", \\\"{x:573,y:756,t:1527877013788};\\\", \\\"{x:573,y:757,t:1527877013806};\\\", \\\"{x:572,y:758,t:1527877013939};\\\", \\\"{x:572,y:759,t:1527877013955};\\\", \\\"{x:571,y:759,t:1527877013972};\\\", \\\"{x:571,y:761,t:1527877013989};\\\", \\\"{x:569,y:756,t:1527877021259};\\\", \\\"{x:569,y:754,t:1527877021266};\\\", \\\"{x:569,y:752,t:1527877021282};\\\", \\\"{x:569,y:750,t:1527877021306};\\\", \\\"{x:568,y:750,t:1527877021475};\\\", \\\"{x:567,y:750,t:1527877021483};\\\", \\\"{x:566,y:750,t:1527877021515};\\\", \\\"{x:565,y:750,t:1527877021539};\\\", \\\"{x:564,y:750,t:1527877021550};\\\", \\\"{x:563,y:751,t:1527877021567};\\\", \\\"{x:560,y:753,t:1527877021584};\\\", \\\"{x:558,y:753,t:1527877021601};\\\", \\\"{x:557,y:753,t:1527877021619};\\\", \\\"{x:555,y:753,t:1527877021682};\\\", \\\"{x:553,y:753,t:1527877021695};\\\", \\\"{x:553,y:752,t:1527877021710};\\\", \\\"{x:553,y:750,t:1527877021728};\\\", \\\"{x:551,y:748,t:1527877021745};\\\", \\\"{x:549,y:747,t:1527877021819};\\\", \\\"{x:548,y:746,t:1527877021828};\\\", \\\"{x:544,y:745,t:1527877021845};\\\", \\\"{x:540,y:744,t:1527877021861};\\\", \\\"{x:539,y:744,t:1527877021878};\\\", \\\"{x:538,y:744,t:1527877022082};\\\", \\\"{x:538,y:743,t:1527877022098};\\\", \\\"{x:538,y:740,t:1527877022187};\\\", \\\"{x:538,y:737,t:1527877022194};\\\", \\\"{x:540,y:732,t:1527877022212};\\\", \\\"{x:544,y:725,t:1527877022229};\\\", \\\"{x:550,y:716,t:1527877022244};\\\", \\\"{x:562,y:705,t:1527877022261};\\\", \\\"{x:576,y:692,t:1527877022279};\\\", \\\"{x:587,y:679,t:1527877022295};\\\", \\\"{x:607,y:664,t:1527877022312};\\\", \\\"{x:627,y:652,t:1527877022329};\\\", \\\"{x:650,y:639,t:1527877022345};\\\", \\\"{x:681,y:624,t:1527877022361};\\\", \\\"{x:755,y:597,t:1527877022379};\\\", \\\"{x:816,y:580,t:1527877022394};\\\", \\\"{x:869,y:566,t:1527877022412};\\\", \\\"{x:914,y:550,t:1527877022429};\\\", \\\"{x:950,y:541,t:1527877022445};\\\", \\\"{x:973,y:532,t:1527877022461};\\\", \\\"{x:983,y:530,t:1527877022479};\\\", \\\"{x:984,y:530,t:1527877022495};\\\", \\\"{x:985,y:529,t:1527877022555};\\\", \\\"{x:986,y:529,t:1527877022571};\\\" ] }, { \\\"rt\\\": 11218, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 624795, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:984,y:529,t:1527877026115};\\\", \\\"{x:983,y:529,t:1527877026141};\\\", \\\"{x:982,y:530,t:1527877026243};\\\", \\\"{x:981,y:531,t:1527877026266};\\\", \\\"{x:980,y:531,t:1527877026307};\\\", \\\"{x:978,y:532,t:1527877026323};\\\", \\\"{x:977,y:532,t:1527877026338};\\\", \\\"{x:974,y:534,t:1527877026355};\\\", \\\"{x:974,y:535,t:1527877026387};\\\", \\\"{x:973,y:535,t:1527877026411};\\\", \\\"{x:972,y:535,t:1527877026434};\\\", \\\"{x:971,y:536,t:1527877026451};\\\", \\\"{x:970,y:536,t:1527877026483};\\\", \\\"{x:970,y:538,t:1527877026523};\\\", \\\"{x:967,y:541,t:1527877026532};\\\", \\\"{x:962,y:546,t:1527877026548};\\\", \\\"{x:958,y:551,t:1527877026565};\\\", \\\"{x:955,y:553,t:1527877026582};\\\", \\\"{x:952,y:557,t:1527877026599};\\\", \\\"{x:951,y:558,t:1527877026615};\\\", \\\"{x:951,y:559,t:1527877026632};\\\", \\\"{x:949,y:561,t:1527877026699};\\\", \\\"{x:948,y:565,t:1527877026715};\\\", \\\"{x:948,y:570,t:1527877026731};\\\", \\\"{x:948,y:573,t:1527877026748};\\\", \\\"{x:948,y:575,t:1527877026765};\\\", \\\"{x:948,y:576,t:1527877026781};\\\", \\\"{x:948,y:578,t:1527877026798};\\\", \\\"{x:960,y:581,t:1527877026816};\\\", \\\"{x:981,y:584,t:1527877026832};\\\", \\\"{x:1009,y:589,t:1527877026848};\\\", \\\"{x:1054,y:595,t:1527877026865};\\\", \\\"{x:1121,y:595,t:1527877026881};\\\", \\\"{x:1223,y:595,t:1527877026899};\\\", \\\"{x:1293,y:595,t:1527877026914};\\\", \\\"{x:1345,y:591,t:1527877026932};\\\", \\\"{x:1395,y:585,t:1527877026949};\\\", \\\"{x:1428,y:581,t:1527877026964};\\\", \\\"{x:1450,y:577,t:1527877026982};\\\", \\\"{x:1463,y:575,t:1527877026999};\\\", \\\"{x:1465,y:575,t:1527877027015};\\\", \\\"{x:1466,y:575,t:1527877027043};\\\", \\\"{x:1467,y:575,t:1527877027050};\\\", \\\"{x:1471,y:578,t:1527877027066};\\\", \\\"{x:1478,y:585,t:1527877027082};\\\", \\\"{x:1486,y:592,t:1527877027098};\\\", \\\"{x:1487,y:594,t:1527877027116};\\\", \\\"{x:1490,y:599,t:1527877027132};\\\", \\\"{x:1490,y:601,t:1527877027149};\\\", \\\"{x:1490,y:605,t:1527877027167};\\\", \\\"{x:1484,y:612,t:1527877027182};\\\", \\\"{x:1479,y:617,t:1527877027200};\\\", \\\"{x:1462,y:627,t:1527877027217};\\\", \\\"{x:1446,y:634,t:1527877027234};\\\", \\\"{x:1444,y:639,t:1527877027249};\\\", \\\"{x:1438,y:645,t:1527877027265};\\\", \\\"{x:1429,y:647,t:1527877027281};\\\", \\\"{x:1426,y:647,t:1527877027298};\\\", \\\"{x:1425,y:647,t:1527877027346};\\\", \\\"{x:1424,y:647,t:1527877027579};\\\", \\\"{x:1421,y:647,t:1527877027587};\\\", \\\"{x:1419,y:647,t:1527877027698};\\\", \\\"{x:1419,y:649,t:1527877027714};\\\", \\\"{x:1418,y:653,t:1527877027722};\\\", \\\"{x:1417,y:659,t:1527877027733};\\\", \\\"{x:1411,y:671,t:1527877027748};\\\", \\\"{x:1405,y:679,t:1527877027766};\\\", \\\"{x:1402,y:682,t:1527877027782};\\\", \\\"{x:1397,y:686,t:1527877027798};\\\", \\\"{x:1391,y:692,t:1527877027816};\\\", \\\"{x:1382,y:702,t:1527877027833};\\\", \\\"{x:1371,y:717,t:1527877027849};\\\", \\\"{x:1364,y:731,t:1527877027865};\\\", \\\"{x:1351,y:747,t:1527877027882};\\\", \\\"{x:1344,y:752,t:1527877027900};\\\", \\\"{x:1340,y:755,t:1527877027917};\\\", \\\"{x:1339,y:755,t:1527877027933};\\\", \\\"{x:1338,y:755,t:1527877028059};\\\", \\\"{x:1337,y:754,t:1527877028067};\\\", \\\"{x:1336,y:750,t:1527877028083};\\\", \\\"{x:1335,y:746,t:1527877028100};\\\", \\\"{x:1334,y:739,t:1527877028116};\\\", \\\"{x:1332,y:732,t:1527877028133};\\\", \\\"{x:1332,y:725,t:1527877028150};\\\", \\\"{x:1332,y:722,t:1527877028167};\\\", \\\"{x:1332,y:718,t:1527877028183};\\\", \\\"{x:1332,y:715,t:1527877028200};\\\", \\\"{x:1332,y:713,t:1527877028216};\\\", \\\"{x:1332,y:711,t:1527877028234};\\\", \\\"{x:1335,y:708,t:1527877028250};\\\", \\\"{x:1341,y:705,t:1527877028266};\\\", \\\"{x:1346,y:702,t:1527877028283};\\\", \\\"{x:1347,y:701,t:1527877028300};\\\", \\\"{x:1347,y:700,t:1527877028331};\\\", \\\"{x:1348,y:699,t:1527877028347};\\\", \\\"{x:1349,y:698,t:1527877028363};\\\", \\\"{x:1351,y:697,t:1527877028370};\\\", \\\"{x:1352,y:697,t:1527877028383};\\\", \\\"{x:1353,y:696,t:1527877028400};\\\", \\\"{x:1354,y:695,t:1527877028418};\\\", \\\"{x:1353,y:695,t:1527877028556};\\\", \\\"{x:1351,y:696,t:1527877028567};\\\", \\\"{x:1350,y:696,t:1527877028583};\\\", \\\"{x:1349,y:696,t:1527877028600};\\\", \\\"{x:1348,y:696,t:1527877028652};\\\", \\\"{x:1347,y:696,t:1527877028667};\\\", \\\"{x:1346,y:696,t:1527877028731};\\\", \\\"{x:1341,y:695,t:1527877030573};\\\", \\\"{x:1331,y:693,t:1527877030585};\\\", \\\"{x:1313,y:690,t:1527877030601};\\\", \\\"{x:1281,y:686,t:1527877030618};\\\", \\\"{x:1229,y:682,t:1527877030635};\\\", \\\"{x:1192,y:682,t:1527877030652};\\\", \\\"{x:1164,y:682,t:1527877030668};\\\", \\\"{x:1136,y:682,t:1527877030685};\\\", \\\"{x:1106,y:682,t:1527877030701};\\\", \\\"{x:1076,y:682,t:1527877030718};\\\", \\\"{x:1049,y:682,t:1527877030735};\\\", \\\"{x:1027,y:682,t:1527877030751};\\\", \\\"{x:1004,y:682,t:1527877030768};\\\", \\\"{x:983,y:682,t:1527877030785};\\\", \\\"{x:964,y:682,t:1527877030802};\\\", \\\"{x:946,y:682,t:1527877030818};\\\", \\\"{x:922,y:682,t:1527877030834};\\\", \\\"{x:903,y:682,t:1527877030851};\\\", \\\"{x:885,y:682,t:1527877030868};\\\", \\\"{x:862,y:682,t:1527877030885};\\\", \\\"{x:841,y:682,t:1527877030902};\\\", \\\"{x:816,y:682,t:1527877030918};\\\", \\\"{x:792,y:680,t:1527877030935};\\\", \\\"{x:769,y:675,t:1527877030953};\\\", \\\"{x:751,y:666,t:1527877030969};\\\", \\\"{x:735,y:654,t:1527877030985};\\\", \\\"{x:723,y:646,t:1527877031003};\\\", \\\"{x:707,y:629,t:1527877031019};\\\", \\\"{x:680,y:607,t:1527877031035};\\\", \\\"{x:660,y:588,t:1527877031052};\\\", \\\"{x:644,y:574,t:1527877031069};\\\", \\\"{x:624,y:559,t:1527877031086};\\\", \\\"{x:619,y:549,t:1527877031102};\\\", \\\"{x:606,y:543,t:1527877031118};\\\", \\\"{x:604,y:541,t:1527877031135};\\\", \\\"{x:601,y:541,t:1527877031152};\\\", \\\"{x:593,y:536,t:1527877031169};\\\", \\\"{x:591,y:536,t:1527877031186};\\\", \\\"{x:588,y:535,t:1527877031202};\\\", \\\"{x:587,y:534,t:1527877031283};\\\", \\\"{x:586,y:533,t:1527877031403};\\\", \\\"{x:580,y:533,t:1527877031420};\\\", \\\"{x:569,y:538,t:1527877031436};\\\", \\\"{x:559,y:543,t:1527877031452};\\\", \\\"{x:542,y:548,t:1527877031468};\\\", \\\"{x:533,y:551,t:1527877031486};\\\", \\\"{x:527,y:554,t:1527877031503};\\\", \\\"{x:526,y:554,t:1527877031519};\\\", \\\"{x:531,y:553,t:1527877031546};\\\", \\\"{x:536,y:549,t:1527877031554};\\\", \\\"{x:545,y:541,t:1527877031569};\\\", \\\"{x:562,y:526,t:1527877031586};\\\", \\\"{x:588,y:505,t:1527877031603};\\\", \\\"{x:604,y:493,t:1527877031619};\\\", \\\"{x:618,y:484,t:1527877031636};\\\", \\\"{x:622,y:481,t:1527877031653};\\\", \\\"{x:624,y:479,t:1527877031669};\\\", \\\"{x:622,y:479,t:1527877031762};\\\", \\\"{x:621,y:479,t:1527877031770};\\\", \\\"{x:618,y:480,t:1527877031786};\\\", \\\"{x:611,y:483,t:1527877031808};\\\", \\\"{x:607,y:484,t:1527877031847};\\\", \\\"{x:606,y:485,t:1527877031858};\\\", \\\"{x:605,y:485,t:1527877031868};\\\", \\\"{x:601,y:488,t:1527877031886};\\\", \\\"{x:598,y:489,t:1527877031903};\\\", \\\"{x:597,y:490,t:1527877031919};\\\", \\\"{x:596,y:490,t:1527877031936};\\\", \\\"{x:595,y:491,t:1527877031954};\\\", \\\"{x:595,y:493,t:1527877031970};\\\", \\\"{x:595,y:497,t:1527877031986};\\\", \\\"{x:594,y:498,t:1527877032003};\\\", \\\"{x:594,y:499,t:1527877032020};\\\", \\\"{x:594,y:500,t:1527877032036};\\\", \\\"{x:595,y:503,t:1527877032053};\\\", \\\"{x:599,y:508,t:1527877032070};\\\", \\\"{x:601,y:510,t:1527877032086};\\\", \\\"{x:602,y:513,t:1527877032103};\\\", \\\"{x:604,y:515,t:1527877032120};\\\", \\\"{x:605,y:515,t:1527877032587};\\\", \\\"{x:607,y:515,t:1527877032602};\\\", \\\"{x:608,y:515,t:1527877032620};\\\", \\\"{x:610,y:515,t:1527877032636};\\\", \\\"{x:610,y:512,t:1527877032654};\\\", \\\"{x:610,y:510,t:1527877032670};\\\", \\\"{x:610,y:508,t:1527877032687};\\\", \\\"{x:610,y:507,t:1527877032771};\\\", \\\"{x:611,y:508,t:1527877033106};\\\", \\\"{x:611,y:512,t:1527877033122};\\\", \\\"{x:609,y:513,t:1527877033137};\\\", \\\"{x:601,y:521,t:1527877033154};\\\", \\\"{x:592,y:533,t:1527877033171};\\\", \\\"{x:584,y:550,t:1527877033187};\\\", \\\"{x:575,y:572,t:1527877033204};\\\", \\\"{x:568,y:595,t:1527877033221};\\\", \\\"{x:559,y:624,t:1527877033237};\\\", \\\"{x:546,y:643,t:1527877033255};\\\", \\\"{x:538,y:651,t:1527877033271};\\\", \\\"{x:530,y:659,t:1527877033287};\\\", \\\"{x:526,y:665,t:1527877033304};\\\", \\\"{x:523,y:674,t:1527877033321};\\\", \\\"{x:523,y:684,t:1527877033337};\\\", \\\"{x:520,y:701,t:1527877033355};\\\", \\\"{x:519,y:713,t:1527877033370};\\\", \\\"{x:518,y:725,t:1527877033388};\\\", \\\"{x:514,y:741,t:1527877033404};\\\", \\\"{x:513,y:752,t:1527877033421};\\\", \\\"{x:512,y:759,t:1527877033438};\\\", \\\"{x:512,y:760,t:1527877033454};\\\", \\\"{x:512,y:761,t:1527877033516};\\\", \\\"{x:510,y:763,t:1527877033523};\\\", \\\"{x:510,y:766,t:1527877033537};\\\", \\\"{x:510,y:773,t:1527877033554};\\\", \\\"{x:509,y:774,t:1527877033571};\\\", \\\"{x:509,y:773,t:1527877033755};\\\", \\\"{x:510,y:764,t:1527877033771};\\\", \\\"{x:511,y:758,t:1527877033787};\\\", \\\"{x:511,y:755,t:1527877033804};\\\", \\\"{x:511,y:752,t:1527877033822};\\\", \\\"{x:512,y:752,t:1527877033859};\\\", \\\"{x:513,y:751,t:1527877033871};\\\", \\\"{x:514,y:751,t:1527877033888};\\\", \\\"{x:516,y:749,t:1527877033904};\\\", \\\"{x:519,y:746,t:1527877033921};\\\", \\\"{x:523,y:737,t:1527877033938};\\\", \\\"{x:525,y:732,t:1527877033955};\\\", \\\"{x:526,y:731,t:1527877033972};\\\", \\\"{x:526,y:730,t:1527877034019};\\\" ] }, { \\\"rt\\\": 15247, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 641353, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L -L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:525,y:729,t:1527877038180};\\\", \\\"{x:518,y:732,t:1527877038211};\\\", \\\"{x:517,y:733,t:1527877038346};\\\", \\\"{x:516,y:733,t:1527877038362};\\\", \\\"{x:515,y:733,t:1527877038370};\\\", \\\"{x:514,y:733,t:1527877038394};\\\", \\\"{x:516,y:733,t:1527877038675};\\\", \\\"{x:518,y:733,t:1527877038687};\\\", \\\"{x:523,y:731,t:1527877038703};\\\", \\\"{x:527,y:730,t:1527877038721};\\\", \\\"{x:533,y:726,t:1527877038736};\\\", \\\"{x:541,y:723,t:1527877038754};\\\", \\\"{x:555,y:717,t:1527877038772};\\\", \\\"{x:566,y:714,t:1527877038788};\\\", \\\"{x:595,y:714,t:1527877038803};\\\", \\\"{x:627,y:712,t:1527877038821};\\\", \\\"{x:671,y:711,t:1527877038841};\\\", \\\"{x:747,y:711,t:1527877038858};\\\", \\\"{x:801,y:708,t:1527877038875};\\\", \\\"{x:857,y:700,t:1527877038891};\\\", \\\"{x:913,y:690,t:1527877038908};\\\", \\\"{x:953,y:685,t:1527877038926};\\\", \\\"{x:982,y:681,t:1527877038942};\\\", \\\"{x:1009,y:679,t:1527877038959};\\\", \\\"{x:1036,y:679,t:1527877038976};\\\", \\\"{x:1059,y:679,t:1527877038992};\\\", \\\"{x:1083,y:679,t:1527877039009};\\\", \\\"{x:1112,y:682,t:1527877039025};\\\", \\\"{x:1150,y:687,t:1527877039042};\\\", \\\"{x:1171,y:692,t:1527877039058};\\\", \\\"{x:1187,y:697,t:1527877039075};\\\", \\\"{x:1200,y:701,t:1527877039092};\\\", \\\"{x:1207,y:702,t:1527877039109};\\\", \\\"{x:1210,y:702,t:1527877039126};\\\", \\\"{x:1211,y:702,t:1527877039142};\\\", \\\"{x:1212,y:703,t:1527877039159};\\\", \\\"{x:1213,y:705,t:1527877039175};\\\", \\\"{x:1214,y:709,t:1527877039193};\\\", \\\"{x:1218,y:714,t:1527877039209};\\\", \\\"{x:1223,y:720,t:1527877039226};\\\", \\\"{x:1225,y:722,t:1527877039243};\\\", \\\"{x:1226,y:726,t:1527877039308};\\\", \\\"{x:1227,y:732,t:1527877039315};\\\", \\\"{x:1228,y:742,t:1527877039326};\\\", \\\"{x:1233,y:764,t:1527877039343};\\\", \\\"{x:1241,y:790,t:1527877039359};\\\", \\\"{x:1253,y:818,t:1527877039376};\\\", \\\"{x:1265,y:845,t:1527877039392};\\\", \\\"{x:1278,y:868,t:1527877039410};\\\", \\\"{x:1288,y:884,t:1527877039425};\\\", \\\"{x:1295,y:900,t:1527877039443};\\\", \\\"{x:1299,y:906,t:1527877039459};\\\", \\\"{x:1300,y:908,t:1527877039476};\\\", \\\"{x:1302,y:911,t:1527877039493};\\\", \\\"{x:1304,y:914,t:1527877039510};\\\", \\\"{x:1306,y:916,t:1527877039525};\\\", \\\"{x:1309,y:919,t:1527877039543};\\\", \\\"{x:1313,y:921,t:1527877039560};\\\", \\\"{x:1316,y:922,t:1527877039575};\\\", \\\"{x:1319,y:922,t:1527877039593};\\\", \\\"{x:1321,y:922,t:1527877039611};\\\", \\\"{x:1323,y:922,t:1527877039626};\\\", \\\"{x:1330,y:924,t:1527877039643};\\\", \\\"{x:1336,y:926,t:1527877039660};\\\", \\\"{x:1341,y:928,t:1527877039676};\\\", \\\"{x:1345,y:928,t:1527877039693};\\\", \\\"{x:1347,y:928,t:1527877039710};\\\", \\\"{x:1348,y:928,t:1527877039726};\\\", \\\"{x:1349,y:928,t:1527877039743};\\\", \\\"{x:1350,y:928,t:1527877039760};\\\", \\\"{x:1351,y:928,t:1527877039776};\\\", \\\"{x:1353,y:928,t:1527877039811};\\\", \\\"{x:1354,y:928,t:1527877039827};\\\", \\\"{x:1356,y:927,t:1527877039851};\\\", \\\"{x:1357,y:926,t:1527877039875};\\\", \\\"{x:1358,y:925,t:1527877039891};\\\", \\\"{x:1359,y:925,t:1527877039899};\\\", \\\"{x:1361,y:922,t:1527877039910};\\\", \\\"{x:1365,y:919,t:1527877039927};\\\", \\\"{x:1372,y:915,t:1527877039943};\\\", \\\"{x:1378,y:910,t:1527877039961};\\\", \\\"{x:1382,y:907,t:1527877039977};\\\", \\\"{x:1386,y:903,t:1527877039993};\\\", \\\"{x:1391,y:899,t:1527877040010};\\\", \\\"{x:1394,y:896,t:1527877040027};\\\", \\\"{x:1399,y:889,t:1527877040043};\\\", \\\"{x:1405,y:880,t:1527877040060};\\\", \\\"{x:1409,y:870,t:1527877040077};\\\", \\\"{x:1413,y:852,t:1527877040093};\\\", \\\"{x:1420,y:836,t:1527877040110};\\\", \\\"{x:1426,y:825,t:1527877040128};\\\", \\\"{x:1435,y:812,t:1527877040143};\\\", \\\"{x:1438,y:800,t:1527877040160};\\\", \\\"{x:1441,y:790,t:1527877040177};\\\", \\\"{x:1442,y:782,t:1527877040193};\\\", \\\"{x:1445,y:775,t:1527877040210};\\\", \\\"{x:1446,y:766,t:1527877040228};\\\", \\\"{x:1447,y:759,t:1527877040243};\\\", \\\"{x:1449,y:754,t:1527877040260};\\\", \\\"{x:1450,y:747,t:1527877040277};\\\", \\\"{x:1454,y:738,t:1527877040294};\\\", \\\"{x:1461,y:729,t:1527877040310};\\\", \\\"{x:1466,y:723,t:1527877040327};\\\", \\\"{x:1468,y:718,t:1527877040344};\\\", \\\"{x:1468,y:709,t:1527877040360};\\\", \\\"{x:1471,y:700,t:1527877040377};\\\", \\\"{x:1475,y:691,t:1527877040394};\\\", \\\"{x:1481,y:681,t:1527877040410};\\\", \\\"{x:1490,y:668,t:1527877040427};\\\", \\\"{x:1492,y:665,t:1527877040443};\\\", \\\"{x:1495,y:661,t:1527877040460};\\\", \\\"{x:1498,y:656,t:1527877040477};\\\", \\\"{x:1502,y:650,t:1527877040494};\\\", \\\"{x:1506,y:643,t:1527877040509};\\\", \\\"{x:1509,y:634,t:1527877040527};\\\", \\\"{x:1511,y:626,t:1527877040545};\\\", \\\"{x:1511,y:620,t:1527877040560};\\\", \\\"{x:1513,y:615,t:1527877040577};\\\", \\\"{x:1515,y:611,t:1527877040594};\\\", \\\"{x:1518,y:606,t:1527877040610};\\\", \\\"{x:1519,y:602,t:1527877040627};\\\", \\\"{x:1520,y:599,t:1527877040644};\\\", \\\"{x:1522,y:594,t:1527877040660};\\\", \\\"{x:1523,y:589,t:1527877040677};\\\", \\\"{x:1526,y:580,t:1527877040694};\\\", \\\"{x:1529,y:571,t:1527877040711};\\\", \\\"{x:1531,y:566,t:1527877040727};\\\", \\\"{x:1534,y:561,t:1527877040744};\\\", \\\"{x:1536,y:555,t:1527877040761};\\\", \\\"{x:1542,y:545,t:1527877040777};\\\", \\\"{x:1549,y:537,t:1527877040794};\\\", \\\"{x:1560,y:522,t:1527877040811};\\\", \\\"{x:1565,y:514,t:1527877040827};\\\", \\\"{x:1567,y:510,t:1527877040844};\\\", \\\"{x:1569,y:506,t:1527877040861};\\\", \\\"{x:1571,y:502,t:1527877040877};\\\", \\\"{x:1574,y:497,t:1527877040894};\\\", \\\"{x:1575,y:495,t:1527877040911};\\\", \\\"{x:1577,y:493,t:1527877040930};\\\", \\\"{x:1578,y:492,t:1527877040944};\\\", \\\"{x:1578,y:490,t:1527877040963};\\\", \\\"{x:1579,y:490,t:1527877040979};\\\", \\\"{x:1580,y:490,t:1527877040995};\\\", \\\"{x:1582,y:487,t:1527877041010};\\\", \\\"{x:1582,y:486,t:1527877041043};\\\", \\\"{x:1579,y:486,t:1527877042435};\\\", \\\"{x:1573,y:490,t:1527877042445};\\\", \\\"{x:1563,y:499,t:1527877042461};\\\", \\\"{x:1549,y:512,t:1527877042478};\\\", \\\"{x:1534,y:529,t:1527877042494};\\\", \\\"{x:1519,y:547,t:1527877042511};\\\", \\\"{x:1506,y:566,t:1527877042528};\\\", \\\"{x:1498,y:587,t:1527877042545};\\\", \\\"{x:1488,y:611,t:1527877042562};\\\", \\\"{x:1473,y:643,t:1527877042578};\\\", \\\"{x:1465,y:667,t:1527877042594};\\\", \\\"{x:1455,y:696,t:1527877042612};\\\", \\\"{x:1448,y:719,t:1527877042629};\\\", \\\"{x:1439,y:737,t:1527877042644};\\\", \\\"{x:1433,y:750,t:1527877042661};\\\", \\\"{x:1426,y:769,t:1527877042679};\\\", \\\"{x:1417,y:789,t:1527877042694};\\\", \\\"{x:1412,y:801,t:1527877042712};\\\", \\\"{x:1409,y:812,t:1527877042730};\\\", \\\"{x:1407,y:818,t:1527877042745};\\\", \\\"{x:1405,y:821,t:1527877042762};\\\", \\\"{x:1403,y:825,t:1527877042779};\\\", \\\"{x:1402,y:828,t:1527877042795};\\\", \\\"{x:1399,y:833,t:1527877042812};\\\", \\\"{x:1397,y:836,t:1527877042829};\\\", \\\"{x:1395,y:839,t:1527877042845};\\\", \\\"{x:1391,y:844,t:1527877042862};\\\", \\\"{x:1389,y:847,t:1527877042879};\\\", \\\"{x:1387,y:851,t:1527877042895};\\\", \\\"{x:1386,y:854,t:1527877042912};\\\", \\\"{x:1385,y:855,t:1527877042930};\\\", \\\"{x:1384,y:857,t:1527877042945};\\\", \\\"{x:1382,y:859,t:1527877042963};\\\", \\\"{x:1379,y:862,t:1527877042979};\\\", \\\"{x:1377,y:863,t:1527877042996};\\\", \\\"{x:1377,y:864,t:1527877043012};\\\", \\\"{x:1375,y:866,t:1527877043029};\\\", \\\"{x:1373,y:867,t:1527877044948};\\\", \\\"{x:1329,y:854,t:1527877044965};\\\", \\\"{x:1270,y:829,t:1527877044980};\\\", \\\"{x:1185,y:792,t:1527877044997};\\\", \\\"{x:1085,y:760,t:1527877045014};\\\", \\\"{x:993,y:732,t:1527877045031};\\\", \\\"{x:907,y:707,t:1527877045048};\\\", \\\"{x:816,y:684,t:1527877045064};\\\", \\\"{x:740,y:660,t:1527877045080};\\\", \\\"{x:676,y:648,t:1527877045097};\\\", \\\"{x:636,y:642,t:1527877045114};\\\", \\\"{x:605,y:635,t:1527877045131};\\\", \\\"{x:581,y:629,t:1527877045148};\\\", \\\"{x:570,y:625,t:1527877045163};\\\", \\\"{x:564,y:623,t:1527877045179};\\\", \\\"{x:550,y:619,t:1527877045197};\\\", \\\"{x:531,y:614,t:1527877045214};\\\", \\\"{x:511,y:608,t:1527877045231};\\\", \\\"{x:483,y:599,t:1527877045247};\\\", \\\"{x:455,y:592,t:1527877045264};\\\", \\\"{x:440,y:589,t:1527877045280};\\\", \\\"{x:431,y:584,t:1527877045296};\\\", \\\"{x:424,y:583,t:1527877045314};\\\", \\\"{x:424,y:581,t:1527877045330};\\\", \\\"{x:425,y:580,t:1527877045347};\\\", \\\"{x:426,y:579,t:1527877045370};\\\", \\\"{x:428,y:578,t:1527877045395};\\\", \\\"{x:428,y:577,t:1527877045403};\\\", \\\"{x:429,y:576,t:1527877045413};\\\", \\\"{x:431,y:574,t:1527877045435};\\\", \\\"{x:432,y:574,t:1527877045450};\\\", \\\"{x:432,y:573,t:1527877045464};\\\", \\\"{x:432,y:571,t:1527877045481};\\\", \\\"{x:432,y:570,t:1527877045497};\\\", \\\"{x:432,y:567,t:1527877045514};\\\", \\\"{x:430,y:564,t:1527877045533};\\\", \\\"{x:424,y:560,t:1527877045548};\\\", \\\"{x:420,y:554,t:1527877045564};\\\", \\\"{x:411,y:542,t:1527877045581};\\\", \\\"{x:408,y:538,t:1527877045597};\\\", \\\"{x:408,y:537,t:1527877045613};\\\", \\\"{x:406,y:537,t:1527877045843};\\\", \\\"{x:403,y:537,t:1527877045851};\\\", \\\"{x:403,y:539,t:1527877046451};\\\", \\\"{x:403,y:547,t:1527877046465};\\\", \\\"{x:402,y:560,t:1527877046482};\\\", \\\"{x:401,y:569,t:1527877046498};\\\", \\\"{x:400,y:576,t:1527877046514};\\\", \\\"{x:399,y:580,t:1527877046531};\\\", \\\"{x:399,y:583,t:1527877046548};\\\", \\\"{x:399,y:588,t:1527877046565};\\\", \\\"{x:399,y:595,t:1527877046582};\\\", \\\"{x:399,y:600,t:1527877046599};\\\", \\\"{x:398,y:605,t:1527877046615};\\\", \\\"{x:397,y:608,t:1527877046632};\\\", \\\"{x:396,y:610,t:1527877046648};\\\", \\\"{x:395,y:611,t:1527877046699};\\\", \\\"{x:391,y:614,t:1527877046715};\\\", \\\"{x:390,y:618,t:1527877046732};\\\", \\\"{x:386,y:622,t:1527877046748};\\\", \\\"{x:384,y:625,t:1527877046765};\\\", \\\"{x:385,y:625,t:1527877047050};\\\", \\\"{x:386,y:625,t:1527877047066};\\\", \\\"{x:388,y:625,t:1527877047082};\\\", \\\"{x:395,y:625,t:1527877047098};\\\", \\\"{x:406,y:626,t:1527877047116};\\\", \\\"{x:415,y:627,t:1527877047132};\\\", \\\"{x:421,y:628,t:1527877047149};\\\", \\\"{x:429,y:631,t:1527877047165};\\\", \\\"{x:439,y:636,t:1527877047182};\\\", \\\"{x:447,y:641,t:1527877047199};\\\", \\\"{x:458,y:651,t:1527877047215};\\\", \\\"{x:468,y:661,t:1527877047232};\\\", \\\"{x:478,y:666,t:1527877047248};\\\", \\\"{x:486,y:672,t:1527877047267};\\\", \\\"{x:492,y:675,t:1527877047282};\\\", \\\"{x:502,y:677,t:1527877047299};\\\", \\\"{x:503,y:678,t:1527877047316};\\\", \\\"{x:506,y:679,t:1527877047332};\\\", \\\"{x:507,y:680,t:1527877047349};\\\", \\\"{x:509,y:682,t:1527877047395};\\\", \\\"{x:511,y:685,t:1527877047403};\\\", \\\"{x:516,y:690,t:1527877047417};\\\", \\\"{x:520,y:697,t:1527877047433};\\\", \\\"{x:521,y:701,t:1527877047449};\\\", \\\"{x:521,y:702,t:1527877047499};\\\", \\\"{x:521,y:705,t:1527877047516};\\\", \\\"{x:521,y:706,t:1527877047533};\\\", \\\"{x:521,y:707,t:1527877047550};\\\", \\\"{x:520,y:708,t:1527877047566};\\\", \\\"{x:519,y:709,t:1527877050068};\\\", \\\"{x:519,y:711,t:1527877050083};\\\", \\\"{x:515,y:713,t:1527877050091};\\\", \\\"{x:510,y:718,t:1527877050103};\\\", \\\"{x:503,y:725,t:1527877050120};\\\", \\\"{x:497,y:730,t:1527877050136};\\\", \\\"{x:492,y:732,t:1527877050153};\\\", \\\"{x:492,y:733,t:1527877050166};\\\", \\\"{x:490,y:734,t:1527877050183};\\\", \\\"{x:489,y:736,t:1527877050200};\\\", \\\"{x:489,y:737,t:1527877050218};\\\", \\\"{x:489,y:738,t:1527877050233};\\\", \\\"{x:488,y:740,t:1527877050250};\\\", \\\"{x:487,y:740,t:1527877051403};\\\" ] }, { \\\"rt\\\": 11758, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 654340, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:742,t:1527877053268};\\\", \\\"{x:481,y:742,t:1527877053275};\\\", \\\"{x:475,y:742,t:1527877053289};\\\", \\\"{x:464,y:744,t:1527877053305};\\\", \\\"{x:445,y:748,t:1527877053322};\\\", \\\"{x:437,y:749,t:1527877053340};\\\", \\\"{x:429,y:749,t:1527877053356};\\\", \\\"{x:421,y:749,t:1527877053370};\\\", \\\"{x:414,y:749,t:1527877053387};\\\", \\\"{x:409,y:749,t:1527877053404};\\\", \\\"{x:395,y:749,t:1527877053421};\\\", \\\"{x:386,y:750,t:1527877053438};\\\", \\\"{x:374,y:753,t:1527877053455};\\\", \\\"{x:368,y:755,t:1527877053472};\\\", \\\"{x:366,y:755,t:1527877053487};\\\", \\\"{x:364,y:755,t:1527877054028};\\\", \\\"{x:364,y:754,t:1527877054039};\\\", \\\"{x:364,y:753,t:1527877054899};\\\", \\\"{x:364,y:752,t:1527877054906};\\\", \\\"{x:365,y:750,t:1527877054922};\\\", \\\"{x:367,y:749,t:1527877054938};\\\", \\\"{x:368,y:749,t:1527877054956};\\\", \\\"{x:371,y:747,t:1527877054973};\\\", \\\"{x:374,y:745,t:1527877054990};\\\", \\\"{x:379,y:743,t:1527877055006};\\\", \\\"{x:380,y:742,t:1527877055023};\\\", \\\"{x:384,y:740,t:1527877055040};\\\", \\\"{x:386,y:739,t:1527877055056};\\\", \\\"{x:389,y:738,t:1527877055072};\\\", \\\"{x:393,y:736,t:1527877055089};\\\", \\\"{x:400,y:736,t:1527877055105};\\\", \\\"{x:417,y:736,t:1527877055121};\\\", \\\"{x:429,y:736,t:1527877055139};\\\", \\\"{x:446,y:736,t:1527877055155};\\\", \\\"{x:462,y:734,t:1527877055172};\\\", \\\"{x:477,y:730,t:1527877055188};\\\", \\\"{x:497,y:728,t:1527877055205};\\\", \\\"{x:524,y:723,t:1527877055222};\\\", \\\"{x:555,y:722,t:1527877055238};\\\", \\\"{x:591,y:716,t:1527877055256};\\\", \\\"{x:636,y:709,t:1527877055272};\\\", \\\"{x:704,y:696,t:1527877055288};\\\", \\\"{x:781,y:686,t:1527877055305};\\\", \\\"{x:929,y:652,t:1527877055322};\\\", \\\"{x:1013,y:627,t:1527877055339};\\\", \\\"{x:1088,y:605,t:1527877055356};\\\", \\\"{x:1143,y:592,t:1527877055372};\\\", \\\"{x:1194,y:581,t:1527877055389};\\\", \\\"{x:1230,y:575,t:1527877055405};\\\", \\\"{x:1257,y:571,t:1527877055423};\\\", \\\"{x:1278,y:569,t:1527877055438};\\\", \\\"{x:1292,y:566,t:1527877055456};\\\", \\\"{x:1302,y:564,t:1527877055473};\\\", \\\"{x:1311,y:564,t:1527877055490};\\\", \\\"{x:1319,y:560,t:1527877055506};\\\", \\\"{x:1324,y:559,t:1527877055522};\\\", \\\"{x:1324,y:558,t:1527877055540};\\\", \\\"{x:1326,y:558,t:1527877055674};\\\", \\\"{x:1330,y:559,t:1527877055689};\\\", \\\"{x:1336,y:564,t:1527877055705};\\\", \\\"{x:1346,y:571,t:1527877055722};\\\", \\\"{x:1355,y:578,t:1527877055739};\\\", \\\"{x:1364,y:584,t:1527877055756};\\\", \\\"{x:1368,y:587,t:1527877055773};\\\", \\\"{x:1370,y:589,t:1527877055789};\\\", \\\"{x:1371,y:589,t:1527877055807};\\\", \\\"{x:1372,y:590,t:1527877055822};\\\", \\\"{x:1373,y:590,t:1527877055850};\\\", \\\"{x:1374,y:591,t:1527877055867};\\\", \\\"{x:1375,y:592,t:1527877055875};\\\", \\\"{x:1375,y:594,t:1527877055889};\\\", \\\"{x:1377,y:598,t:1527877055907};\\\", \\\"{x:1377,y:602,t:1527877055922};\\\", \\\"{x:1378,y:605,t:1527877055939};\\\", \\\"{x:1378,y:607,t:1527877055957};\\\", \\\"{x:1378,y:608,t:1527877055973};\\\", \\\"{x:1378,y:609,t:1527877055990};\\\", \\\"{x:1378,y:611,t:1527877056019};\\\", \\\"{x:1379,y:612,t:1527877056027};\\\", \\\"{x:1379,y:615,t:1527877056040};\\\", \\\"{x:1380,y:622,t:1527877056056};\\\", \\\"{x:1382,y:630,t:1527877056072};\\\", \\\"{x:1381,y:636,t:1527877056090};\\\", \\\"{x:1380,y:637,t:1527877056107};\\\", \\\"{x:1379,y:638,t:1527877056123};\\\", \\\"{x:1378,y:639,t:1527877056187};\\\", \\\"{x:1377,y:640,t:1527877056611};\\\", \\\"{x:1377,y:638,t:1527877056624};\\\", \\\"{x:1377,y:629,t:1527877056641};\\\", \\\"{x:1377,y:616,t:1527877056657};\\\", \\\"{x:1377,y:602,t:1527877056674};\\\", \\\"{x:1377,y:591,t:1527877056691};\\\", \\\"{x:1373,y:578,t:1527877056707};\\\", \\\"{x:1368,y:572,t:1527877056724};\\\", \\\"{x:1368,y:569,t:1527877056741};\\\", \\\"{x:1368,y:568,t:1527877057242};\\\", \\\"{x:1367,y:574,t:1527877057266};\\\", \\\"{x:1364,y:579,t:1527877057275};\\\", \\\"{x:1362,y:586,t:1527877057290};\\\", \\\"{x:1357,y:594,t:1527877057307};\\\", \\\"{x:1355,y:601,t:1527877057324};\\\", \\\"{x:1353,y:605,t:1527877057340};\\\", \\\"{x:1352,y:610,t:1527877057358};\\\", \\\"{x:1352,y:619,t:1527877057374};\\\", \\\"{x:1351,y:632,t:1527877057391};\\\", \\\"{x:1350,y:647,t:1527877057408};\\\", \\\"{x:1347,y:658,t:1527877057424};\\\", \\\"{x:1345,y:666,t:1527877057441};\\\", \\\"{x:1343,y:673,t:1527877057458};\\\", \\\"{x:1341,y:678,t:1527877057473};\\\", \\\"{x:1340,y:682,t:1527877057491};\\\", \\\"{x:1339,y:688,t:1527877057508};\\\", \\\"{x:1338,y:695,t:1527877057524};\\\", \\\"{x:1337,y:702,t:1527877057541};\\\", \\\"{x:1336,y:710,t:1527877057558};\\\", \\\"{x:1335,y:715,t:1527877057574};\\\", \\\"{x:1335,y:716,t:1527877057591};\\\", \\\"{x:1336,y:716,t:1527877057780};\\\", \\\"{x:1339,y:716,t:1527877057791};\\\", \\\"{x:1342,y:715,t:1527877057807};\\\", \\\"{x:1344,y:714,t:1527877057824};\\\", \\\"{x:1345,y:713,t:1527877057841};\\\", \\\"{x:1346,y:713,t:1527877057858};\\\", \\\"{x:1346,y:712,t:1527877057923};\\\", \\\"{x:1346,y:710,t:1527877057931};\\\", \\\"{x:1346,y:706,t:1527877057941};\\\", \\\"{x:1346,y:700,t:1527877057960};\\\", \\\"{x:1348,y:694,t:1527877057975};\\\", \\\"{x:1348,y:693,t:1527877057990};\\\", \\\"{x:1348,y:692,t:1527877058007};\\\", \\\"{x:1348,y:691,t:1527877058036};\\\", \\\"{x:1348,y:690,t:1527877058067};\\\", \\\"{x:1348,y:688,t:1527877058075};\\\", \\\"{x:1348,y:686,t:1527877058091};\\\", \\\"{x:1348,y:685,t:1527877058107};\\\", \\\"{x:1348,y:684,t:1527877058125};\\\", \\\"{x:1348,y:683,t:1527877058142};\\\", \\\"{x:1347,y:682,t:1527877058267};\\\", \\\"{x:1346,y:682,t:1527877059059};\\\", \\\"{x:1345,y:682,t:1527877059139};\\\", \\\"{x:1342,y:682,t:1527877059148};\\\", \\\"{x:1341,y:683,t:1527877059159};\\\", \\\"{x:1339,y:683,t:1527877059176};\\\", \\\"{x:1338,y:684,t:1527877059192};\\\", \\\"{x:1335,y:685,t:1527877059209};\\\", \\\"{x:1331,y:687,t:1527877059226};\\\", \\\"{x:1323,y:687,t:1527877059242};\\\", \\\"{x:1298,y:687,t:1527877059259};\\\", \\\"{x:1268,y:684,t:1527877059276};\\\", \\\"{x:1196,y:677,t:1527877059292};\\\", \\\"{x:1106,y:672,t:1527877059309};\\\", \\\"{x:1017,y:672,t:1527877059327};\\\", \\\"{x:914,y:672,t:1527877059343};\\\", \\\"{x:817,y:672,t:1527877059358};\\\", \\\"{x:714,y:668,t:1527877059375};\\\", \\\"{x:615,y:656,t:1527877059392};\\\", \\\"{x:534,y:645,t:1527877059409};\\\", \\\"{x:462,y:636,t:1527877059425};\\\", \\\"{x:395,y:636,t:1527877059443};\\\", \\\"{x:362,y:629,t:1527877059460};\\\", \\\"{x:346,y:625,t:1527877059475};\\\", \\\"{x:343,y:622,t:1527877059493};\\\", \\\"{x:344,y:617,t:1527877059508};\\\", \\\"{x:346,y:612,t:1527877059526};\\\", \\\"{x:346,y:606,t:1527877059543};\\\", \\\"{x:347,y:598,t:1527877059559};\\\", \\\"{x:347,y:589,t:1527877059576};\\\", \\\"{x:345,y:581,t:1527877059592};\\\", \\\"{x:332,y:558,t:1527877059610};\\\", \\\"{x:327,y:544,t:1527877059626};\\\", \\\"{x:325,y:527,t:1527877059642};\\\", \\\"{x:325,y:521,t:1527877059660};\\\", \\\"{x:328,y:514,t:1527877059676};\\\", \\\"{x:329,y:506,t:1527877059693};\\\", \\\"{x:329,y:504,t:1527877059709};\\\", \\\"{x:328,y:501,t:1527877059725};\\\", \\\"{x:326,y:500,t:1527877059743};\\\", \\\"{x:316,y:497,t:1527877059759};\\\", \\\"{x:311,y:496,t:1527877059777};\\\", \\\"{x:305,y:496,t:1527877059793};\\\", \\\"{x:300,y:496,t:1527877059810};\\\", \\\"{x:292,y:496,t:1527877059826};\\\", \\\"{x:285,y:497,t:1527877059843};\\\", \\\"{x:276,y:502,t:1527877059860};\\\", \\\"{x:263,y:507,t:1527877059879};\\\", \\\"{x:254,y:510,t:1527877059893};\\\", \\\"{x:248,y:511,t:1527877059909};\\\", \\\"{x:242,y:513,t:1527877059925};\\\", \\\"{x:240,y:514,t:1527877059942};\\\", \\\"{x:240,y:515,t:1527877059962};\\\", \\\"{x:241,y:516,t:1527877059978};\\\", \\\"{x:241,y:517,t:1527877059992};\\\", \\\"{x:242,y:518,t:1527877060009};\\\", \\\"{x:244,y:519,t:1527877060026};\\\", \\\"{x:253,y:521,t:1527877060042};\\\", \\\"{x:266,y:521,t:1527877060060};\\\", \\\"{x:283,y:515,t:1527877060077};\\\", \\\"{x:304,y:508,t:1527877060092};\\\", \\\"{x:329,y:504,t:1527877060109};\\\", \\\"{x:355,y:502,t:1527877060126};\\\", \\\"{x:378,y:499,t:1527877060143};\\\", \\\"{x:406,y:499,t:1527877060160};\\\", \\\"{x:434,y:499,t:1527877060176};\\\", \\\"{x:461,y:494,t:1527877060192};\\\", \\\"{x:490,y:492,t:1527877060209};\\\", \\\"{x:512,y:488,t:1527877060227};\\\", \\\"{x:524,y:488,t:1527877060242};\\\", \\\"{x:529,y:488,t:1527877060260};\\\", \\\"{x:533,y:488,t:1527877060277};\\\", \\\"{x:534,y:488,t:1527877060294};\\\", \\\"{x:535,y:489,t:1527877060310};\\\", \\\"{x:540,y:492,t:1527877060326};\\\", \\\"{x:553,y:497,t:1527877060344};\\\", \\\"{x:569,y:500,t:1527877060360};\\\", \\\"{x:581,y:502,t:1527877060376};\\\", \\\"{x:588,y:503,t:1527877060394};\\\", \\\"{x:591,y:503,t:1527877060409};\\\", \\\"{x:592,y:503,t:1527877060426};\\\", \\\"{x:594,y:506,t:1527877060443};\\\", \\\"{x:600,y:509,t:1527877060462};\\\", \\\"{x:609,y:512,t:1527877060477};\\\", \\\"{x:615,y:513,t:1527877060494};\\\", \\\"{x:620,y:514,t:1527877060510};\\\", \\\"{x:622,y:514,t:1527877060526};\\\", \\\"{x:623,y:514,t:1527877060610};\\\", \\\"{x:624,y:514,t:1527877060634};\\\", \\\"{x:625,y:514,t:1527877060650};\\\", \\\"{x:626,y:514,t:1527877060659};\\\", \\\"{x:632,y:517,t:1527877060676};\\\", \\\"{x:646,y:517,t:1527877060694};\\\", \\\"{x:663,y:517,t:1527877060710};\\\", \\\"{x:683,y:515,t:1527877060727};\\\", \\\"{x:702,y:509,t:1527877060744};\\\", \\\"{x:721,y:505,t:1527877060759};\\\", \\\"{x:737,y:504,t:1527877060777};\\\", \\\"{x:750,y:504,t:1527877060794};\\\", \\\"{x:758,y:504,t:1527877060810};\\\", \\\"{x:768,y:504,t:1527877060826};\\\", \\\"{x:770,y:504,t:1527877060843};\\\", \\\"{x:773,y:504,t:1527877060899};\\\", \\\"{x:774,y:504,t:1527877060910};\\\", \\\"{x:776,y:505,t:1527877060927};\\\", \\\"{x:780,y:506,t:1527877060943};\\\", \\\"{x:784,y:510,t:1527877060960};\\\", \\\"{x:789,y:515,t:1527877060976};\\\", \\\"{x:796,y:521,t:1527877060994};\\\", \\\"{x:798,y:525,t:1527877061010};\\\", \\\"{x:798,y:527,t:1527877061027};\\\", \\\"{x:798,y:528,t:1527877061043};\\\", \\\"{x:798,y:531,t:1527877061060};\\\", \\\"{x:799,y:536,t:1527877061076};\\\", \\\"{x:800,y:540,t:1527877061093};\\\", \\\"{x:801,y:545,t:1527877061110};\\\", \\\"{x:801,y:549,t:1527877061126};\\\", \\\"{x:803,y:552,t:1527877061143};\\\", \\\"{x:803,y:553,t:1527877061160};\\\", \\\"{x:805,y:555,t:1527877061177};\\\", \\\"{x:807,y:555,t:1527877061194};\\\", \\\"{x:808,y:555,t:1527877061267};\\\", \\\"{x:810,y:555,t:1527877061278};\\\", \\\"{x:812,y:554,t:1527877061298};\\\", \\\"{x:814,y:553,t:1527877061310};\\\", \\\"{x:817,y:552,t:1527877061328};\\\", \\\"{x:821,y:549,t:1527877061343};\\\", \\\"{x:823,y:546,t:1527877061360};\\\", \\\"{x:825,y:545,t:1527877061378};\\\", \\\"{x:825,y:543,t:1527877061436};\\\", \\\"{x:826,y:543,t:1527877061450};\\\", \\\"{x:827,y:543,t:1527877061722};\\\", \\\"{x:829,y:543,t:1527877061730};\\\", \\\"{x:833,y:543,t:1527877061744};\\\", \\\"{x:852,y:543,t:1527877061761};\\\", \\\"{x:886,y:543,t:1527877061778};\\\", \\\"{x:950,y:543,t:1527877061793};\\\", \\\"{x:1006,y:543,t:1527877061811};\\\", \\\"{x:1074,y:539,t:1527877061828};\\\", \\\"{x:1141,y:529,t:1527877061844};\\\", \\\"{x:1200,y:521,t:1527877061861};\\\", \\\"{x:1250,y:513,t:1527877061877};\\\", \\\"{x:1289,y:510,t:1527877061895};\\\", \\\"{x:1319,y:510,t:1527877061910};\\\", \\\"{x:1348,y:510,t:1527877061928};\\\", \\\"{x:1370,y:511,t:1527877061944};\\\", \\\"{x:1404,y:526,t:1527877061961};\\\", \\\"{x:1484,y:560,t:1527877061978};\\\", \\\"{x:1558,y:625,t:1527877061995};\\\", \\\"{x:1566,y:633,t:1527877062010};\\\", \\\"{x:1569,y:635,t:1527877062028};\\\", \\\"{x:1570,y:637,t:1527877062044};\\\", \\\"{x:1572,y:639,t:1527877062061};\\\", \\\"{x:1572,y:641,t:1527877062115};\\\", \\\"{x:1572,y:642,t:1527877062130};\\\", \\\"{x:1570,y:642,t:1527877062145};\\\", \\\"{x:1569,y:643,t:1527877062161};\\\", \\\"{x:1567,y:643,t:1527877062178};\\\", \\\"{x:1561,y:646,t:1527877062195};\\\", \\\"{x:1551,y:647,t:1527877062212};\\\", \\\"{x:1532,y:647,t:1527877062228};\\\", \\\"{x:1513,y:647,t:1527877062245};\\\", \\\"{x:1500,y:649,t:1527877062262};\\\", \\\"{x:1489,y:650,t:1527877062278};\\\", \\\"{x:1479,y:652,t:1527877062296};\\\", \\\"{x:1469,y:652,t:1527877062312};\\\", \\\"{x:1457,y:652,t:1527877062328};\\\", \\\"{x:1447,y:652,t:1527877062345};\\\", \\\"{x:1436,y:652,t:1527877062362};\\\", \\\"{x:1423,y:652,t:1527877062378};\\\", \\\"{x:1411,y:652,t:1527877062395};\\\", \\\"{x:1405,y:652,t:1527877062412};\\\", \\\"{x:1402,y:652,t:1527877062428};\\\", \\\"{x:1397,y:652,t:1527877062445};\\\", \\\"{x:1386,y:653,t:1527877062462};\\\", \\\"{x:1366,y:653,t:1527877062479};\\\", \\\"{x:1341,y:653,t:1527877062495};\\\", \\\"{x:1314,y:653,t:1527877062512};\\\", \\\"{x:1284,y:653,t:1527877062528};\\\", \\\"{x:1250,y:653,t:1527877062545};\\\", \\\"{x:1211,y:653,t:1527877062562};\\\", \\\"{x:1153,y:653,t:1527877062578};\\\", \\\"{x:1039,y:662,t:1527877062595};\\\", \\\"{x:986,y:670,t:1527877062612};\\\", \\\"{x:935,y:678,t:1527877062628};\\\", \\\"{x:894,y:682,t:1527877062645};\\\", \\\"{x:855,y:686,t:1527877062662};\\\", \\\"{x:817,y:689,t:1527877062679};\\\", \\\"{x:790,y:693,t:1527877062695};\\\", \\\"{x:761,y:698,t:1527877062712};\\\", \\\"{x:735,y:706,t:1527877062729};\\\", \\\"{x:715,y:714,t:1527877062745};\\\", \\\"{x:692,y:719,t:1527877062762};\\\", \\\"{x:660,y:728,t:1527877062779};\\\", \\\"{x:626,y:738,t:1527877062795};\\\", \\\"{x:593,y:748,t:1527877062812};\\\", \\\"{x:559,y:758,t:1527877062829};\\\", \\\"{x:539,y:765,t:1527877062845};\\\", \\\"{x:525,y:768,t:1527877062862};\\\", \\\"{x:516,y:769,t:1527877062879};\\\", \\\"{x:512,y:769,t:1527877062895};\\\", \\\"{x:511,y:769,t:1527877062912};\\\", \\\"{x:513,y:769,t:1527877063139};\\\", \\\"{x:513,y:768,t:1527877063146};\\\", \\\"{x:513,y:765,t:1527877063162};\\\", \\\"{x:515,y:759,t:1527877063179};\\\", \\\"{x:515,y:755,t:1527877063196};\\\", \\\"{x:515,y:754,t:1527877063213};\\\", \\\"{x:515,y:752,t:1527877063228};\\\", \\\"{x:513,y:751,t:1527877063290};\\\", \\\"{x:512,y:749,t:1527877063298};\\\", \\\"{x:510,y:746,t:1527877063311};\\\", \\\"{x:507,y:742,t:1527877063329};\\\", \\\"{x:500,y:735,t:1527877063345};\\\", \\\"{x:498,y:732,t:1527877063361};\\\", \\\"{x:494,y:728,t:1527877063378};\\\", \\\"{x:494,y:725,t:1527877063395};\\\", \\\"{x:494,y:724,t:1527877063412};\\\", \\\"{x:494,y:723,t:1527877063675};\\\", \\\"{x:496,y:723,t:1527877063691};\\\", \\\"{x:498,y:723,t:1527877063698};\\\", \\\"{x:499,y:724,t:1527877063712};\\\", \\\"{x:500,y:728,t:1527877063729};\\\", \\\"{x:501,y:733,t:1527877063746};\\\", \\\"{x:502,y:737,t:1527877063762};\\\", \\\"{x:502,y:738,t:1527877063779};\\\", \\\"{x:503,y:738,t:1527877064074};\\\", \\\"{x:504,y:738,t:1527877064090};\\\", \\\"{x:505,y:738,t:1527877064098};\\\", \\\"{x:506,y:738,t:1527877064226};\\\", \\\"{x:508,y:738,t:1527877064235};\\\", \\\"{x:509,y:737,t:1527877064245};\\\", \\\"{x:511,y:736,t:1527877064263};\\\", \\\"{x:512,y:736,t:1527877064280};\\\", \\\"{x:514,y:735,t:1527877064296};\\\", \\\"{x:517,y:734,t:1527877064313};\\\", \\\"{x:521,y:733,t:1527877064329};\\\", \\\"{x:529,y:729,t:1527877064347};\\\", \\\"{x:541,y:727,t:1527877064363};\\\", \\\"{x:555,y:726,t:1527877064379};\\\", \\\"{x:572,y:726,t:1527877064397};\\\", \\\"{x:598,y:726,t:1527877064412};\\\", \\\"{x:626,y:723,t:1527877064429};\\\", \\\"{x:652,y:721,t:1527877064446};\\\", \\\"{x:676,y:718,t:1527877064463};\\\", \\\"{x:693,y:716,t:1527877064479};\\\", \\\"{x:703,y:715,t:1527877064497};\\\", \\\"{x:710,y:712,t:1527877064513};\\\", \\\"{x:707,y:713,t:1527877065043};\\\", \\\"{x:706,y:713,t:1527877065050};\\\", \\\"{x:705,y:713,t:1527877065064};\\\" ] }, { \\\"rt\\\": 14422, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 670029, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:707,y:713,t:1527877068459};\\\", \\\"{x:745,y:706,t:1527877068492};\\\", \\\"{x:758,y:703,t:1527877068500};\\\", \\\"{x:787,y:700,t:1527877068516};\\\", \\\"{x:818,y:697,t:1527877068532};\\\", \\\"{x:851,y:697,t:1527877068550};\\\", \\\"{x:910,y:697,t:1527877068565};\\\", \\\"{x:974,y:697,t:1527877068583};\\\", \\\"{x:1039,y:694,t:1527877068600};\\\", \\\"{x:1104,y:684,t:1527877068615};\\\", \\\"{x:1165,y:676,t:1527877068633};\\\", \\\"{x:1228,y:667,t:1527877068650};\\\", \\\"{x:1259,y:662,t:1527877068666};\\\", \\\"{x:1282,y:660,t:1527877068683};\\\", \\\"{x:1301,y:657,t:1527877068701};\\\", \\\"{x:1318,y:655,t:1527877068716};\\\", \\\"{x:1332,y:655,t:1527877068733};\\\", \\\"{x:1347,y:653,t:1527877068750};\\\", \\\"{x:1359,y:652,t:1527877068767};\\\", \\\"{x:1372,y:648,t:1527877068784};\\\", \\\"{x:1385,y:643,t:1527877068801};\\\", \\\"{x:1392,y:638,t:1527877068816};\\\", \\\"{x:1393,y:637,t:1527877068833};\\\", \\\"{x:1396,y:634,t:1527877068850};\\\", \\\"{x:1399,y:630,t:1527877068867};\\\", \\\"{x:1403,y:626,t:1527877068884};\\\", \\\"{x:1405,y:622,t:1527877068900};\\\", \\\"{x:1407,y:619,t:1527877068917};\\\", \\\"{x:1410,y:615,t:1527877068933};\\\", \\\"{x:1414,y:612,t:1527877068950};\\\", \\\"{x:1418,y:605,t:1527877068967};\\\", \\\"{x:1422,y:595,t:1527877068983};\\\", \\\"{x:1429,y:587,t:1527877069000};\\\", \\\"{x:1435,y:580,t:1527877069017};\\\", \\\"{x:1439,y:575,t:1527877069033};\\\", \\\"{x:1442,y:568,t:1527877069051};\\\", \\\"{x:1444,y:566,t:1527877069066};\\\", \\\"{x:1445,y:562,t:1527877069083};\\\", \\\"{x:1448,y:558,t:1527877069100};\\\", \\\"{x:1449,y:555,t:1527877069117};\\\", \\\"{x:1451,y:551,t:1527877069133};\\\", \\\"{x:1452,y:544,t:1527877069150};\\\", \\\"{x:1457,y:528,t:1527877069167};\\\", \\\"{x:1463,y:518,t:1527877069183};\\\", \\\"{x:1467,y:512,t:1527877069200};\\\", \\\"{x:1469,y:510,t:1527877069217};\\\", \\\"{x:1470,y:510,t:1527877069332};\\\", \\\"{x:1473,y:510,t:1527877069878};\\\", \\\"{x:1483,y:517,t:1527877069887};\\\", \\\"{x:1510,y:533,t:1527877069905};\\\", \\\"{x:1537,y:545,t:1527877069920};\\\", \\\"{x:1567,y:558,t:1527877069937};\\\", \\\"{x:1594,y:569,t:1527877069955};\\\", \\\"{x:1622,y:577,t:1527877069970};\\\", \\\"{x:1645,y:590,t:1527877069987};\\\", \\\"{x:1658,y:597,t:1527877070004};\\\", \\\"{x:1661,y:599,t:1527877070020};\\\", \\\"{x:1662,y:599,t:1527877070037};\\\", \\\"{x:1662,y:604,t:1527877070054};\\\", \\\"{x:1662,y:609,t:1527877070070};\\\", \\\"{x:1662,y:616,t:1527877070087};\\\", \\\"{x:1662,y:621,t:1527877070104};\\\", \\\"{x:1660,y:632,t:1527877070121};\\\", \\\"{x:1656,y:640,t:1527877070138};\\\", \\\"{x:1649,y:646,t:1527877070154};\\\", \\\"{x:1639,y:648,t:1527877070172};\\\", \\\"{x:1624,y:652,t:1527877070188};\\\", \\\"{x:1612,y:657,t:1527877070205};\\\", \\\"{x:1599,y:669,t:1527877070222};\\\", \\\"{x:1596,y:672,t:1527877070237};\\\", \\\"{x:1594,y:675,t:1527877070254};\\\", \\\"{x:1593,y:678,t:1527877070271};\\\", \\\"{x:1593,y:681,t:1527877070358};\\\", \\\"{x:1597,y:686,t:1527877070371};\\\", \\\"{x:1613,y:700,t:1527877070390};\\\", \\\"{x:1621,y:710,t:1527877070404};\\\", \\\"{x:1623,y:714,t:1527877070420};\\\", \\\"{x:1623,y:710,t:1527877070751};\\\", \\\"{x:1623,y:707,t:1527877070758};\\\", \\\"{x:1622,y:707,t:1527877070771};\\\", \\\"{x:1622,y:706,t:1527877070789};\\\", \\\"{x:1622,y:704,t:1527877070804};\\\", \\\"{x:1621,y:701,t:1527877070821};\\\", \\\"{x:1619,y:696,t:1527877070838};\\\", \\\"{x:1618,y:694,t:1527877070854};\\\", \\\"{x:1617,y:693,t:1527877071069};\\\", \\\"{x:1616,y:693,t:1527877071078};\\\", \\\"{x:1615,y:693,t:1527877071088};\\\", \\\"{x:1611,y:694,t:1527877071105};\\\", \\\"{x:1609,y:694,t:1527877071121};\\\", \\\"{x:1607,y:695,t:1527877071231};\\\", \\\"{x:1607,y:696,t:1527877071254};\\\", \\\"{x:1605,y:699,t:1527877071262};\\\", \\\"{x:1604,y:703,t:1527877071271};\\\", \\\"{x:1603,y:709,t:1527877071288};\\\", \\\"{x:1600,y:712,t:1527877071305};\\\", \\\"{x:1598,y:718,t:1527877071321};\\\", \\\"{x:1595,y:722,t:1527877071339};\\\", \\\"{x:1593,y:727,t:1527877071355};\\\", \\\"{x:1591,y:732,t:1527877071371};\\\", \\\"{x:1589,y:739,t:1527877071389};\\\", \\\"{x:1588,y:744,t:1527877071405};\\\", \\\"{x:1586,y:749,t:1527877071422};\\\", \\\"{x:1585,y:754,t:1527877071438};\\\", \\\"{x:1583,y:759,t:1527877071456};\\\", \\\"{x:1581,y:765,t:1527877071472};\\\", \\\"{x:1579,y:769,t:1527877071488};\\\", \\\"{x:1577,y:771,t:1527877071505};\\\", \\\"{x:1576,y:775,t:1527877071522};\\\", \\\"{x:1574,y:778,t:1527877071538};\\\", \\\"{x:1573,y:780,t:1527877071555};\\\", \\\"{x:1573,y:783,t:1527877071572};\\\", \\\"{x:1571,y:785,t:1527877071587};\\\", \\\"{x:1569,y:788,t:1527877071605};\\\", \\\"{x:1567,y:790,t:1527877071622};\\\", \\\"{x:1567,y:791,t:1527877071638};\\\", \\\"{x:1566,y:791,t:1527877071669};\\\", \\\"{x:1566,y:793,t:1527877071686};\\\", \\\"{x:1566,y:795,t:1527877071693};\\\", \\\"{x:1565,y:797,t:1527877071705};\\\", \\\"{x:1561,y:803,t:1527877071722};\\\", \\\"{x:1552,y:815,t:1527877071738};\\\", \\\"{x:1547,y:827,t:1527877071755};\\\", \\\"{x:1539,y:843,t:1527877071772};\\\", \\\"{x:1532,y:853,t:1527877071788};\\\", \\\"{x:1526,y:862,t:1527877071805};\\\", \\\"{x:1525,y:864,t:1527877071822};\\\", \\\"{x:1525,y:865,t:1527877071838};\\\", \\\"{x:1525,y:871,t:1527877071855};\\\", \\\"{x:1525,y:879,t:1527877071872};\\\", \\\"{x:1527,y:887,t:1527877071890};\\\", \\\"{x:1528,y:892,t:1527877071905};\\\", \\\"{x:1530,y:900,t:1527877071922};\\\", \\\"{x:1530,y:904,t:1527877071939};\\\", \\\"{x:1530,y:909,t:1527877071955};\\\", \\\"{x:1529,y:915,t:1527877071972};\\\", \\\"{x:1525,y:921,t:1527877071989};\\\", \\\"{x:1521,y:925,t:1527877072006};\\\", \\\"{x:1518,y:927,t:1527877072022};\\\", \\\"{x:1509,y:933,t:1527877072039};\\\", \\\"{x:1498,y:938,t:1527877072055};\\\", \\\"{x:1487,y:944,t:1527877072072};\\\", \\\"{x:1479,y:948,t:1527877072089};\\\", \\\"{x:1471,y:952,t:1527877072104};\\\", \\\"{x:1465,y:955,t:1527877072122};\\\", \\\"{x:1462,y:958,t:1527877072139};\\\", \\\"{x:1461,y:959,t:1527877072155};\\\", \\\"{x:1459,y:961,t:1527877072172};\\\", \\\"{x:1455,y:967,t:1527877072188};\\\", \\\"{x:1454,y:969,t:1527877072204};\\\", \\\"{x:1453,y:969,t:1527877072221};\\\", \\\"{x:1456,y:969,t:1527877072397};\\\", \\\"{x:1457,y:969,t:1527877072405};\\\", \\\"{x:1460,y:968,t:1527877072422};\\\", \\\"{x:1461,y:967,t:1527877072439};\\\", \\\"{x:1462,y:967,t:1527877072477};\\\", \\\"{x:1462,y:965,t:1527877072502};\\\", \\\"{x:1462,y:962,t:1527877072510};\\\", \\\"{x:1462,y:960,t:1527877072522};\\\", \\\"{x:1462,y:955,t:1527877072539};\\\", \\\"{x:1462,y:951,t:1527877072556};\\\", \\\"{x:1462,y:945,t:1527877072572};\\\", \\\"{x:1462,y:931,t:1527877072589};\\\", \\\"{x:1454,y:917,t:1527877072606};\\\", \\\"{x:1447,y:904,t:1527877072622};\\\", \\\"{x:1444,y:898,t:1527877072639};\\\", \\\"{x:1440,y:885,t:1527877072656};\\\", \\\"{x:1438,y:872,t:1527877072672};\\\", \\\"{x:1435,y:852,t:1527877072689};\\\", \\\"{x:1431,y:832,t:1527877072707};\\\", \\\"{x:1424,y:813,t:1527877072722};\\\", \\\"{x:1416,y:798,t:1527877072739};\\\", \\\"{x:1409,y:782,t:1527877072757};\\\", \\\"{x:1403,y:774,t:1527877072772};\\\", \\\"{x:1397,y:758,t:1527877072789};\\\", \\\"{x:1390,y:744,t:1527877072806};\\\", \\\"{x:1382,y:728,t:1527877072823};\\\", \\\"{x:1371,y:711,t:1527877072839};\\\", \\\"{x:1361,y:699,t:1527877072856};\\\", \\\"{x:1356,y:694,t:1527877072873};\\\", \\\"{x:1356,y:692,t:1527877072889};\\\", \\\"{x:1351,y:685,t:1527877072906};\\\", \\\"{x:1345,y:678,t:1527877072923};\\\", \\\"{x:1343,y:675,t:1527877072940};\\\", \\\"{x:1341,y:670,t:1527877072956};\\\", \\\"{x:1337,y:663,t:1527877072973};\\\", \\\"{x:1336,y:661,t:1527877072990};\\\", \\\"{x:1335,y:660,t:1527877073006};\\\", \\\"{x:1334,y:656,t:1527877073023};\\\", \\\"{x:1331,y:648,t:1527877073039};\\\", \\\"{x:1327,y:640,t:1527877073057};\\\", \\\"{x:1324,y:635,t:1527877073073};\\\", \\\"{x:1321,y:627,t:1527877073089};\\\", \\\"{x:1318,y:621,t:1527877073106};\\\", \\\"{x:1315,y:615,t:1527877073123};\\\", \\\"{x:1311,y:608,t:1527877073140};\\\", \\\"{x:1310,y:600,t:1527877073156};\\\", \\\"{x:1306,y:590,t:1527877073174};\\\", \\\"{x:1304,y:587,t:1527877073189};\\\", \\\"{x:1303,y:582,t:1527877073206};\\\", \\\"{x:1300,y:578,t:1527877073223};\\\", \\\"{x:1290,y:571,t:1527877073910};\\\", \\\"{x:1271,y:560,t:1527877073924};\\\", \\\"{x:1217,y:543,t:1527877073940};\\\", \\\"{x:1082,y:518,t:1527877073958};\\\", \\\"{x:985,y:506,t:1527877073974};\\\", \\\"{x:880,y:494,t:1527877073991};\\\", \\\"{x:797,y:485,t:1527877074007};\\\", \\\"{x:722,y:476,t:1527877074022};\\\", \\\"{x:658,y:474,t:1527877074039};\\\", \\\"{x:594,y:466,t:1527877074057};\\\", \\\"{x:549,y:458,t:1527877074074};\\\", \\\"{x:517,y:453,t:1527877074090};\\\", \\\"{x:499,y:451,t:1527877074106};\\\", \\\"{x:493,y:449,t:1527877074123};\\\", \\\"{x:492,y:449,t:1527877074221};\\\", \\\"{x:491,y:449,t:1527877074229};\\\", \\\"{x:490,y:449,t:1527877074294};\\\", \\\"{x:488,y:450,t:1527877074307};\\\", \\\"{x:486,y:450,t:1527877074324};\\\", \\\"{x:487,y:450,t:1527877074382};\\\", \\\"{x:491,y:448,t:1527877074391};\\\", \\\"{x:493,y:448,t:1527877074408};\\\", \\\"{x:490,y:448,t:1527877074510};\\\", \\\"{x:488,y:448,t:1527877074525};\\\", \\\"{x:479,y:451,t:1527877074541};\\\", \\\"{x:468,y:455,t:1527877074557};\\\", \\\"{x:453,y:460,t:1527877074574};\\\", \\\"{x:432,y:465,t:1527877074591};\\\", \\\"{x:411,y:467,t:1527877074607};\\\", \\\"{x:391,y:473,t:1527877074624};\\\", \\\"{x:364,y:477,t:1527877074642};\\\", \\\"{x:342,y:481,t:1527877074657};\\\", \\\"{x:328,y:483,t:1527877074675};\\\", \\\"{x:311,y:484,t:1527877074691};\\\", \\\"{x:297,y:487,t:1527877074710};\\\", \\\"{x:285,y:491,t:1527877074724};\\\", \\\"{x:269,y:496,t:1527877074741};\\\", \\\"{x:262,y:498,t:1527877074757};\\\", \\\"{x:254,y:501,t:1527877074773};\\\", \\\"{x:247,y:503,t:1527877074791};\\\", \\\"{x:240,y:505,t:1527877074808};\\\", \\\"{x:237,y:506,t:1527877074824};\\\", \\\"{x:234,y:508,t:1527877074840};\\\", \\\"{x:231,y:510,t:1527877074858};\\\", \\\"{x:226,y:513,t:1527877074874};\\\", \\\"{x:224,y:514,t:1527877074891};\\\", \\\"{x:224,y:515,t:1527877074917};\\\", \\\"{x:224,y:516,t:1527877074925};\\\", \\\"{x:224,y:517,t:1527877074941};\\\", \\\"{x:227,y:518,t:1527877074959};\\\", \\\"{x:238,y:519,t:1527877074974};\\\", \\\"{x:256,y:520,t:1527877074990};\\\", \\\"{x:286,y:521,t:1527877075007};\\\", \\\"{x:331,y:521,t:1527877075025};\\\", \\\"{x:384,y:521,t:1527877075041};\\\", \\\"{x:437,y:521,t:1527877075058};\\\", \\\"{x:493,y:513,t:1527877075074};\\\", \\\"{x:533,y:506,t:1527877075092};\\\", \\\"{x:559,y:502,t:1527877075108};\\\", \\\"{x:579,y:498,t:1527877075124};\\\", \\\"{x:599,y:496,t:1527877075141};\\\", \\\"{x:604,y:495,t:1527877075158};\\\", \\\"{x:605,y:495,t:1527877075175};\\\", \\\"{x:604,y:495,t:1527877075301};\\\", \\\"{x:603,y:495,t:1527877075309};\\\", \\\"{x:605,y:495,t:1527877075677};\\\", \\\"{x:609,y:494,t:1527877075692};\\\", \\\"{x:623,y:493,t:1527877075708};\\\", \\\"{x:653,y:495,t:1527877075724};\\\", \\\"{x:676,y:498,t:1527877075742};\\\", \\\"{x:702,y:501,t:1527877075758};\\\", \\\"{x:731,y:505,t:1527877075775};\\\", \\\"{x:761,y:505,t:1527877075792};\\\", \\\"{x:787,y:505,t:1527877075808};\\\", \\\"{x:803,y:505,t:1527877075825};\\\", \\\"{x:810,y:505,t:1527877075842};\\\", \\\"{x:813,y:505,t:1527877075857};\\\", \\\"{x:814,y:505,t:1527877075875};\\\", \\\"{x:817,y:505,t:1527877075892};\\\", \\\"{x:821,y:505,t:1527877075909};\\\", \\\"{x:824,y:505,t:1527877075926};\\\", \\\"{x:825,y:505,t:1527877076189};\\\", \\\"{x:828,y:505,t:1527877076198};\\\", \\\"{x:831,y:505,t:1527877076209};\\\", \\\"{x:835,y:504,t:1527877076225};\\\", \\\"{x:831,y:504,t:1527877076533};\\\", \\\"{x:826,y:505,t:1527877076542};\\\", \\\"{x:810,y:512,t:1527877076559};\\\", \\\"{x:792,y:521,t:1527877076576};\\\", \\\"{x:773,y:529,t:1527877076593};\\\", \\\"{x:751,y:539,t:1527877076609};\\\", \\\"{x:722,y:551,t:1527877076626};\\\", \\\"{x:684,y:573,t:1527877076643};\\\", \\\"{x:657,y:593,t:1527877076658};\\\", \\\"{x:640,y:614,t:1527877076676};\\\", \\\"{x:624,y:648,t:1527877076693};\\\", \\\"{x:610,y:688,t:1527877076709};\\\", \\\"{x:603,y:704,t:1527877076726};\\\", \\\"{x:598,y:715,t:1527877076742};\\\", \\\"{x:592,y:724,t:1527877076759};\\\", \\\"{x:587,y:730,t:1527877076776};\\\", \\\"{x:578,y:739,t:1527877076792};\\\", \\\"{x:565,y:745,t:1527877076809};\\\", \\\"{x:549,y:749,t:1527877076827};\\\", \\\"{x:532,y:756,t:1527877076844};\\\", \\\"{x:515,y:759,t:1527877076858};\\\", \\\"{x:500,y:761,t:1527877076876};\\\", \\\"{x:484,y:764,t:1527877076892};\\\", \\\"{x:472,y:766,t:1527877076908};\\\", \\\"{x:468,y:766,t:1527877076926};\\\", \\\"{x:467,y:766,t:1527877076944};\\\", \\\"{x:465,y:766,t:1527877076959};\\\", \\\"{x:465,y:765,t:1527877076976};\\\", \\\"{x:465,y:763,t:1527877076997};\\\", \\\"{x:465,y:761,t:1527877077009};\\\", \\\"{x:465,y:758,t:1527877077026};\\\", \\\"{x:465,y:753,t:1527877077045};\\\", \\\"{x:465,y:750,t:1527877077059};\\\", \\\"{x:466,y:746,t:1527877077076};\\\", \\\"{x:468,y:743,t:1527877077092};\\\", \\\"{x:471,y:739,t:1527877077109};\\\", \\\"{x:474,y:737,t:1527877077126};\\\", \\\"{x:477,y:734,t:1527877077143};\\\", \\\"{x:478,y:733,t:1527877077160};\\\", \\\"{x:479,y:732,t:1527877079852};\\\", \\\"{x:479,y:731,t:1527877080005};\\\", \\\"{x:479,y:730,t:1527877080013};\\\", \\\"{x:478,y:727,t:1527877080133};\\\", \\\"{x:478,y:725,t:1527877080149};\\\", \\\"{x:478,y:724,t:1527877080165};\\\", \\\"{x:478,y:723,t:1527877080181};\\\", \\\"{x:478,y:721,t:1527877080478};\\\", \\\"{x:477,y:721,t:1527877080485};\\\", \\\"{x:477,y:720,t:1527877080501};\\\" ] }, { \\\"rt\\\": 12419, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 683757, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:477,y:718,t:1527877081566};\\\", \\\"{x:478,y:718,t:1527877084630};\\\", \\\"{x:484,y:716,t:1527877084638};\\\", \\\"{x:490,y:711,t:1527877084648};\\\", \\\"{x:494,y:708,t:1527877084666};\\\", \\\"{x:506,y:713,t:1527877084838};\\\", \\\"{x:515,y:715,t:1527877084849};\\\", \\\"{x:531,y:719,t:1527877084865};\\\", \\\"{x:549,y:727,t:1527877084884};\\\", \\\"{x:578,y:735,t:1527877084900};\\\", \\\"{x:618,y:742,t:1527877084916};\\\", \\\"{x:726,y:742,t:1527877084932};\\\", \\\"{x:829,y:742,t:1527877084950};\\\", \\\"{x:953,y:742,t:1527877084967};\\\", \\\"{x:1078,y:742,t:1527877084983};\\\", \\\"{x:1191,y:742,t:1527877084999};\\\", \\\"{x:1272,y:742,t:1527877085016};\\\", \\\"{x:1319,y:746,t:1527877085033};\\\", \\\"{x:1340,y:750,t:1527877085049};\\\", \\\"{x:1350,y:755,t:1527877085067};\\\", \\\"{x:1356,y:760,t:1527877085083};\\\", \\\"{x:1363,y:768,t:1527877085099};\\\", \\\"{x:1371,y:774,t:1527877085116};\\\", \\\"{x:1382,y:780,t:1527877085132};\\\", \\\"{x:1403,y:789,t:1527877085150};\\\", \\\"{x:1439,y:801,t:1527877085166};\\\", \\\"{x:1481,y:812,t:1527877085182};\\\", \\\"{x:1509,y:821,t:1527877085199};\\\", \\\"{x:1529,y:830,t:1527877085216};\\\", \\\"{x:1537,y:835,t:1527877085234};\\\", \\\"{x:1543,y:844,t:1527877085249};\\\", \\\"{x:1545,y:854,t:1527877085266};\\\", \\\"{x:1545,y:866,t:1527877085284};\\\", \\\"{x:1545,y:876,t:1527877085299};\\\", \\\"{x:1539,y:908,t:1527877085316};\\\", \\\"{x:1538,y:930,t:1527877085332};\\\", \\\"{x:1538,y:948,t:1527877085349};\\\", \\\"{x:1538,y:957,t:1527877085367};\\\", \\\"{x:1538,y:961,t:1527877085384};\\\", \\\"{x:1538,y:962,t:1527877085470};\\\", \\\"{x:1537,y:959,t:1527877086061};\\\", \\\"{x:1536,y:957,t:1527877086069};\\\", \\\"{x:1534,y:954,t:1527877086083};\\\", \\\"{x:1530,y:943,t:1527877086101};\\\", \\\"{x:1526,y:935,t:1527877086117};\\\", \\\"{x:1523,y:930,t:1527877086134};\\\", \\\"{x:1517,y:920,t:1527877086151};\\\", \\\"{x:1506,y:905,t:1527877086168};\\\", \\\"{x:1494,y:889,t:1527877086184};\\\", \\\"{x:1481,y:871,t:1527877086201};\\\", \\\"{x:1469,y:852,t:1527877086218};\\\", \\\"{x:1463,y:845,t:1527877086234};\\\", \\\"{x:1461,y:839,t:1527877086251};\\\", \\\"{x:1458,y:830,t:1527877086268};\\\", \\\"{x:1455,y:824,t:1527877086284};\\\", \\\"{x:1445,y:803,t:1527877086301};\\\", \\\"{x:1441,y:796,t:1527877086318};\\\", \\\"{x:1436,y:789,t:1527877086334};\\\", \\\"{x:1431,y:781,t:1527877086351};\\\", \\\"{x:1428,y:775,t:1527877086368};\\\", \\\"{x:1427,y:771,t:1527877086384};\\\", \\\"{x:1424,y:768,t:1527877086401};\\\", \\\"{x:1424,y:765,t:1527877086418};\\\", \\\"{x:1423,y:764,t:1527877086434};\\\", \\\"{x:1421,y:761,t:1527877086451};\\\", \\\"{x:1418,y:756,t:1527877086468};\\\", \\\"{x:1413,y:747,t:1527877086485};\\\", \\\"{x:1410,y:741,t:1527877086501};\\\", \\\"{x:1407,y:736,t:1527877086517};\\\", \\\"{x:1406,y:733,t:1527877086535};\\\", \\\"{x:1405,y:731,t:1527877086551};\\\", \\\"{x:1404,y:729,t:1527877086568};\\\", \\\"{x:1401,y:723,t:1527877086585};\\\", \\\"{x:1401,y:720,t:1527877086601};\\\", \\\"{x:1397,y:714,t:1527877086618};\\\", \\\"{x:1395,y:708,t:1527877086635};\\\", \\\"{x:1392,y:704,t:1527877086651};\\\", \\\"{x:1390,y:698,t:1527877086668};\\\", \\\"{x:1387,y:693,t:1527877086685};\\\", \\\"{x:1386,y:692,t:1527877086701};\\\", \\\"{x:1386,y:691,t:1527877086726};\\\", \\\"{x:1385,y:688,t:1527877086741};\\\", \\\"{x:1385,y:687,t:1527877086750};\\\", \\\"{x:1384,y:685,t:1527877086767};\\\", \\\"{x:1384,y:683,t:1527877086785};\\\", \\\"{x:1383,y:681,t:1527877086800};\\\", \\\"{x:1383,y:680,t:1527877086817};\\\", \\\"{x:1382,y:680,t:1527877088238};\\\", \\\"{x:1372,y:681,t:1527877088254};\\\", \\\"{x:1358,y:686,t:1527877088268};\\\", \\\"{x:1339,y:690,t:1527877088286};\\\", \\\"{x:1319,y:693,t:1527877088303};\\\", \\\"{x:1294,y:694,t:1527877088319};\\\", \\\"{x:1270,y:694,t:1527877088336};\\\", \\\"{x:1249,y:694,t:1527877088353};\\\", \\\"{x:1228,y:694,t:1527877088369};\\\", \\\"{x:1204,y:696,t:1527877088386};\\\", \\\"{x:1181,y:696,t:1527877088403};\\\", \\\"{x:1159,y:696,t:1527877088419};\\\", \\\"{x:1144,y:698,t:1527877088436};\\\", \\\"{x:1123,y:701,t:1527877088452};\\\", \\\"{x:1115,y:702,t:1527877088470};\\\", \\\"{x:1108,y:702,t:1527877088485};\\\", \\\"{x:1101,y:702,t:1527877088502};\\\", \\\"{x:1092,y:702,t:1527877088520};\\\", \\\"{x:1082,y:702,t:1527877088536};\\\", \\\"{x:1070,y:702,t:1527877088553};\\\", \\\"{x:1053,y:703,t:1527877088570};\\\", \\\"{x:1036,y:704,t:1527877088586};\\\", \\\"{x:1020,y:707,t:1527877088603};\\\", \\\"{x:999,y:709,t:1527877088620};\\\", \\\"{x:975,y:714,t:1527877088636};\\\", \\\"{x:951,y:714,t:1527877088654};\\\", \\\"{x:932,y:714,t:1527877088670};\\\", \\\"{x:915,y:714,t:1527877088686};\\\", \\\"{x:896,y:714,t:1527877088703};\\\", \\\"{x:877,y:717,t:1527877088720};\\\", \\\"{x:868,y:718,t:1527877088736};\\\", \\\"{x:860,y:722,t:1527877088753};\\\", \\\"{x:855,y:723,t:1527877088770};\\\", \\\"{x:854,y:724,t:1527877088785};\\\", \\\"{x:853,y:724,t:1527877088803};\\\", \\\"{x:853,y:725,t:1527877088893};\\\", \\\"{x:855,y:725,t:1527877088903};\\\", \\\"{x:859,y:726,t:1527877088920};\\\", \\\"{x:860,y:722,t:1527877088937};\\\", \\\"{x:857,y:716,t:1527877088953};\\\", \\\"{x:856,y:715,t:1527877088970};\\\", \\\"{x:856,y:714,t:1527877089046};\\\", \\\"{x:851,y:711,t:1527877089053};\\\", \\\"{x:838,y:706,t:1527877089069};\\\", \\\"{x:821,y:706,t:1527877089087};\\\", \\\"{x:806,y:706,t:1527877089103};\\\", \\\"{x:788,y:706,t:1527877089120};\\\", \\\"{x:769,y:703,t:1527877089137};\\\", \\\"{x:747,y:699,t:1527877089153};\\\", \\\"{x:719,y:693,t:1527877089170};\\\", \\\"{x:692,y:692,t:1527877089187};\\\", \\\"{x:669,y:691,t:1527877089203};\\\", \\\"{x:650,y:691,t:1527877089219};\\\", \\\"{x:632,y:691,t:1527877089237};\\\", \\\"{x:624,y:691,t:1527877089253};\\\", \\\"{x:620,y:691,t:1527877089270};\\\", \\\"{x:613,y:691,t:1527877089287};\\\", \\\"{x:603,y:691,t:1527877089303};\\\", \\\"{x:588,y:691,t:1527877089320};\\\", \\\"{x:571,y:690,t:1527877089337};\\\", \\\"{x:556,y:688,t:1527877089354};\\\", \\\"{x:544,y:688,t:1527877089370};\\\", \\\"{x:532,y:688,t:1527877089387};\\\", \\\"{x:519,y:688,t:1527877089404};\\\", \\\"{x:510,y:688,t:1527877089420};\\\", \\\"{x:489,y:687,t:1527877089437};\\\", \\\"{x:475,y:683,t:1527877089454};\\\", \\\"{x:470,y:680,t:1527877089470};\\\", \\\"{x:463,y:679,t:1527877089487};\\\", \\\"{x:454,y:677,t:1527877089504};\\\", \\\"{x:451,y:676,t:1527877089520};\\\", \\\"{x:450,y:676,t:1527877089537};\\\", \\\"{x:449,y:675,t:1527877089573};\\\", \\\"{x:452,y:672,t:1527877089587};\\\", \\\"{x:457,y:668,t:1527877089606};\\\", \\\"{x:459,y:664,t:1527877089619};\\\", \\\"{x:459,y:656,t:1527877089637};\\\", \\\"{x:453,y:645,t:1527877089653};\\\", \\\"{x:452,y:634,t:1527877089670};\\\", \\\"{x:452,y:626,t:1527877089687};\\\", \\\"{x:456,y:615,t:1527877089702};\\\", \\\"{x:463,y:611,t:1527877089720};\\\", \\\"{x:467,y:608,t:1527877089735};\\\", \\\"{x:468,y:607,t:1527877089752};\\\", \\\"{x:468,y:606,t:1527877089769};\\\", \\\"{x:468,y:605,t:1527877089788};\\\", \\\"{x:468,y:604,t:1527877089803};\\\", \\\"{x:468,y:601,t:1527877089819};\\\", \\\"{x:466,y:596,t:1527877089836};\\\", \\\"{x:461,y:589,t:1527877089853};\\\", \\\"{x:458,y:586,t:1527877089870};\\\", \\\"{x:455,y:584,t:1527877089887};\\\", \\\"{x:454,y:576,t:1527877089903};\\\", \\\"{x:452,y:561,t:1527877089921};\\\", \\\"{x:452,y:541,t:1527877089936};\\\", \\\"{x:450,y:525,t:1527877089953};\\\", \\\"{x:449,y:513,t:1527877089970};\\\", \\\"{x:442,y:507,t:1527877089987};\\\", \\\"{x:441,y:507,t:1527877090004};\\\", \\\"{x:439,y:507,t:1527877090019};\\\", \\\"{x:436,y:507,t:1527877090037};\\\", \\\"{x:432,y:507,t:1527877090054};\\\", \\\"{x:429,y:508,t:1527877090069};\\\", \\\"{x:419,y:510,t:1527877090087};\\\", \\\"{x:405,y:511,t:1527877090105};\\\", \\\"{x:391,y:515,t:1527877090120};\\\", \\\"{x:378,y:516,t:1527877090136};\\\", \\\"{x:363,y:519,t:1527877090155};\\\", \\\"{x:346,y:521,t:1527877090171};\\\", \\\"{x:328,y:524,t:1527877090187};\\\", \\\"{x:310,y:529,t:1527877090204};\\\", \\\"{x:283,y:537,t:1527877090221};\\\", \\\"{x:265,y:544,t:1527877090238};\\\", \\\"{x:247,y:548,t:1527877090254};\\\", \\\"{x:231,y:553,t:1527877090271};\\\", \\\"{x:213,y:558,t:1527877090288};\\\", \\\"{x:197,y:562,t:1527877090304};\\\", \\\"{x:184,y:566,t:1527877090322};\\\", \\\"{x:178,y:568,t:1527877090336};\\\", \\\"{x:173,y:572,t:1527877090353};\\\", \\\"{x:172,y:572,t:1527877090370};\\\", \\\"{x:171,y:573,t:1527877090413};\\\", \\\"{x:170,y:574,t:1527877090421};\\\", \\\"{x:167,y:575,t:1527877090438};\\\", \\\"{x:163,y:578,t:1527877090453};\\\", \\\"{x:159,y:581,t:1527877090470};\\\", \\\"{x:157,y:584,t:1527877090487};\\\", \\\"{x:156,y:585,t:1527877090504};\\\", \\\"{x:154,y:589,t:1527877090521};\\\", \\\"{x:152,y:594,t:1527877090538};\\\", \\\"{x:150,y:598,t:1527877090554};\\\", \\\"{x:149,y:600,t:1527877090571};\\\", \\\"{x:149,y:602,t:1527877090590};\\\", \\\"{x:149,y:603,t:1527877090603};\\\", \\\"{x:149,y:604,t:1527877090629};\\\", \\\"{x:149,y:605,t:1527877090660};\\\", \\\"{x:149,y:606,t:1527877090670};\\\", \\\"{x:158,y:606,t:1527877090688};\\\", \\\"{x:173,y:606,t:1527877090704};\\\", \\\"{x:191,y:599,t:1527877090721};\\\", \\\"{x:214,y:594,t:1527877090738};\\\", \\\"{x:236,y:587,t:1527877090754};\\\", \\\"{x:266,y:573,t:1527877090770};\\\", \\\"{x:299,y:560,t:1527877090788};\\\", \\\"{x:340,y:542,t:1527877090804};\\\", \\\"{x:407,y:516,t:1527877090822};\\\", \\\"{x:452,y:502,t:1527877090838};\\\", \\\"{x:490,y:493,t:1527877090854};\\\", \\\"{x:526,y:483,t:1527877090871};\\\", \\\"{x:553,y:475,t:1527877090887};\\\", \\\"{x:570,y:471,t:1527877090904};\\\", \\\"{x:579,y:468,t:1527877090921};\\\", \\\"{x:581,y:468,t:1527877090938};\\\", \\\"{x:582,y:468,t:1527877090955};\\\", \\\"{x:583,y:467,t:1527877090971};\\\", \\\"{x:584,y:467,t:1527877090988};\\\", \\\"{x:587,y:467,t:1527877091005};\\\", \\\"{x:590,y:467,t:1527877091021};\\\", \\\"{x:595,y:467,t:1527877091038};\\\", \\\"{x:606,y:472,t:1527877091055};\\\", \\\"{x:622,y:480,t:1527877091072};\\\", \\\"{x:634,y:489,t:1527877091089};\\\", \\\"{x:641,y:496,t:1527877091105};\\\", \\\"{x:647,y:505,t:1527877091121};\\\", \\\"{x:651,y:514,t:1527877091137};\\\", \\\"{x:652,y:521,t:1527877091155};\\\", \\\"{x:652,y:529,t:1527877091171};\\\", \\\"{x:652,y:535,t:1527877091187};\\\", \\\"{x:650,y:545,t:1527877091205};\\\", \\\"{x:643,y:553,t:1527877091220};\\\", \\\"{x:637,y:559,t:1527877091238};\\\", \\\"{x:628,y:564,t:1527877091255};\\\", \\\"{x:620,y:569,t:1527877091271};\\\", \\\"{x:616,y:571,t:1527877091288};\\\", \\\"{x:615,y:572,t:1527877091305};\\\", \\\"{x:614,y:572,t:1527877091320};\\\", \\\"{x:613,y:573,t:1527877091338};\\\", \\\"{x:612,y:573,t:1527877091354};\\\", \\\"{x:610,y:574,t:1527877091371};\\\", \\\"{x:610,y:575,t:1527877091387};\\\", \\\"{x:608,y:575,t:1527877091405};\\\", \\\"{x:608,y:576,t:1527877091678};\\\", \\\"{x:606,y:579,t:1527877092053};\\\", \\\"{x:602,y:582,t:1527877092061};\\\", \\\"{x:595,y:586,t:1527877092072};\\\", \\\"{x:580,y:596,t:1527877092089};\\\", \\\"{x:563,y:608,t:1527877092105};\\\", \\\"{x:545,y:620,t:1527877092121};\\\", \\\"{x:529,y:632,t:1527877092139};\\\", \\\"{x:511,y:645,t:1527877092154};\\\", \\\"{x:497,y:656,t:1527877092172};\\\", \\\"{x:480,y:672,t:1527877092188};\\\", \\\"{x:472,y:679,t:1527877092205};\\\", \\\"{x:466,y:687,t:1527877092222};\\\", \\\"{x:461,y:696,t:1527877092238};\\\", \\\"{x:457,y:704,t:1527877092254};\\\", \\\"{x:454,y:710,t:1527877092271};\\\", \\\"{x:454,y:716,t:1527877092288};\\\", \\\"{x:454,y:721,t:1527877092306};\\\", \\\"{x:453,y:729,t:1527877092322};\\\", \\\"{x:453,y:742,t:1527877092338};\\\", \\\"{x:453,y:755,t:1527877092356};\\\", \\\"{x:453,y:760,t:1527877092371};\\\", \\\"{x:453,y:761,t:1527877092389};\\\", \\\"{x:453,y:763,t:1527877092462};\\\", \\\"{x:454,y:764,t:1527877092477};\\\", \\\"{x:457,y:764,t:1527877092605};\\\", \\\"{x:459,y:764,t:1527877092623};\\\", \\\"{x:463,y:763,t:1527877092639};\\\", \\\"{x:465,y:763,t:1527877092656};\\\", \\\"{x:468,y:762,t:1527877092673};\\\", \\\"{x:469,y:760,t:1527877092690};\\\", \\\"{x:470,y:760,t:1527877092706};\\\", \\\"{x:471,y:759,t:1527877092805};\\\", \\\"{x:475,y:758,t:1527877092823};\\\", \\\"{x:476,y:756,t:1527877092839};\\\", \\\"{x:478,y:755,t:1527877092856};\\\", \\\"{x:481,y:754,t:1527877092874};\\\", \\\"{x:483,y:753,t:1527877092900};\\\", \\\"{x:484,y:753,t:1527877092964};\\\", \\\"{x:486,y:752,t:1527877092981};\\\", \\\"{x:488,y:751,t:1527877093021};\\\" ] }, { \\\"rt\\\": 25252, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 710238, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:490,y:750,t:1527877104941};\\\", \\\"{x:493,y:748,t:1527877104954};\\\", \\\"{x:498,y:746,t:1527877104971};\\\", \\\"{x:502,y:745,t:1527877104987};\\\", \\\"{x:504,y:743,t:1527877105003};\\\", \\\"{x:508,y:742,t:1527877105020};\\\", \\\"{x:510,y:741,t:1527877105037};\\\", \\\"{x:513,y:740,t:1527877105053};\\\", \\\"{x:516,y:738,t:1527877105070};\\\", \\\"{x:520,y:736,t:1527877105088};\\\", \\\"{x:526,y:735,t:1527877105104};\\\", \\\"{x:543,y:735,t:1527877105120};\\\", \\\"{x:571,y:735,t:1527877105138};\\\", \\\"{x:604,y:734,t:1527877105154};\\\", \\\"{x:649,y:727,t:1527877105170};\\\", \\\"{x:697,y:720,t:1527877105182};\\\", \\\"{x:753,y:713,t:1527877105199};\\\", \\\"{x:798,y:706,t:1527877105215};\\\", \\\"{x:840,y:701,t:1527877105232};\\\", \\\"{x:871,y:698,t:1527877105249};\\\", \\\"{x:909,y:692,t:1527877105267};\\\", \\\"{x:935,y:687,t:1527877105282};\\\", \\\"{x:964,y:682,t:1527877105300};\\\", \\\"{x:1024,y:668,t:1527877105317};\\\", \\\"{x:1066,y:657,t:1527877105333};\\\", \\\"{x:1098,y:645,t:1527877105350};\\\", \\\"{x:1125,y:638,t:1527877105366};\\\", \\\"{x:1146,y:632,t:1527877105383};\\\", \\\"{x:1159,y:629,t:1527877105399};\\\", \\\"{x:1164,y:629,t:1527877105416};\\\", \\\"{x:1173,y:629,t:1527877105433};\\\", \\\"{x:1181,y:629,t:1527877105449};\\\", \\\"{x:1195,y:629,t:1527877105466};\\\", \\\"{x:1206,y:629,t:1527877105483};\\\", \\\"{x:1216,y:628,t:1527877105500};\\\", \\\"{x:1224,y:627,t:1527877105517};\\\", \\\"{x:1224,y:626,t:1527877105532};\\\", \\\"{x:1225,y:626,t:1527877105557};\\\", \\\"{x:1229,y:626,t:1527877105612};\\\", \\\"{x:1231,y:626,t:1527877105617};\\\", \\\"{x:1233,y:626,t:1527877105636};\\\", \\\"{x:1235,y:626,t:1527877105649};\\\", \\\"{x:1239,y:627,t:1527877105667};\\\", \\\"{x:1245,y:630,t:1527877105683};\\\", \\\"{x:1249,y:631,t:1527877105700};\\\", \\\"{x:1253,y:633,t:1527877105716};\\\", \\\"{x:1256,y:636,t:1527877105732};\\\", \\\"{x:1258,y:638,t:1527877105750};\\\", \\\"{x:1261,y:644,t:1527877105766};\\\", \\\"{x:1263,y:648,t:1527877105783};\\\", \\\"{x:1265,y:655,t:1527877105799};\\\", \\\"{x:1268,y:661,t:1527877105817};\\\", \\\"{x:1270,y:667,t:1527877105834};\\\", \\\"{x:1271,y:672,t:1527877105850};\\\", \\\"{x:1273,y:680,t:1527877105866};\\\", \\\"{x:1275,y:688,t:1527877105883};\\\", \\\"{x:1279,y:699,t:1527877105899};\\\", \\\"{x:1286,y:714,t:1527877105916};\\\", \\\"{x:1287,y:718,t:1527877105933};\\\", \\\"{x:1289,y:725,t:1527877105950};\\\", \\\"{x:1291,y:734,t:1527877105966};\\\", \\\"{x:1293,y:744,t:1527877105983};\\\", \\\"{x:1296,y:756,t:1527877106000};\\\", \\\"{x:1298,y:769,t:1527877106017};\\\", \\\"{x:1302,y:777,t:1527877106034};\\\", \\\"{x:1305,y:787,t:1527877106050};\\\", \\\"{x:1306,y:795,t:1527877106067};\\\", \\\"{x:1307,y:806,t:1527877106084};\\\", \\\"{x:1310,y:820,t:1527877106100};\\\", \\\"{x:1315,y:839,t:1527877106117};\\\", \\\"{x:1315,y:848,t:1527877106134};\\\", \\\"{x:1316,y:855,t:1527877106151};\\\", \\\"{x:1316,y:858,t:1527877106167};\\\", \\\"{x:1316,y:863,t:1527877106184};\\\", \\\"{x:1315,y:870,t:1527877106201};\\\", \\\"{x:1315,y:879,t:1527877106217};\\\", \\\"{x:1315,y:887,t:1527877106234};\\\", \\\"{x:1317,y:895,t:1527877106251};\\\", \\\"{x:1319,y:900,t:1527877106266};\\\", \\\"{x:1321,y:903,t:1527877106283};\\\", \\\"{x:1321,y:904,t:1527877106310};\\\", \\\"{x:1323,y:907,t:1527877106325};\\\", \\\"{x:1325,y:909,t:1527877106333};\\\", \\\"{x:1329,y:920,t:1527877106351};\\\", \\\"{x:1337,y:932,t:1527877106367};\\\", \\\"{x:1340,y:940,t:1527877106384};\\\", \\\"{x:1343,y:943,t:1527877106401};\\\", \\\"{x:1344,y:946,t:1527877106417};\\\", \\\"{x:1345,y:947,t:1527877106434};\\\", \\\"{x:1346,y:948,t:1527877106451};\\\", \\\"{x:1346,y:952,t:1527877106550};\\\", \\\"{x:1348,y:954,t:1527877106567};\\\", \\\"{x:1349,y:957,t:1527877106584};\\\", \\\"{x:1350,y:958,t:1527877106601};\\\", \\\"{x:1350,y:959,t:1527877106702};\\\", \\\"{x:1351,y:959,t:1527877107590};\\\", \\\"{x:1355,y:959,t:1527877107602};\\\", \\\"{x:1363,y:959,t:1527877107618};\\\", \\\"{x:1373,y:959,t:1527877107635};\\\", \\\"{x:1387,y:959,t:1527877107652};\\\", \\\"{x:1398,y:960,t:1527877107668};\\\", \\\"{x:1418,y:963,t:1527877107686};\\\", \\\"{x:1426,y:966,t:1527877107702};\\\", \\\"{x:1429,y:966,t:1527877107718};\\\", \\\"{x:1430,y:966,t:1527877107741};\\\", \\\"{x:1431,y:966,t:1527877107838};\\\", \\\"{x:1433,y:967,t:1527877107852};\\\", \\\"{x:1435,y:967,t:1527877107868};\\\", \\\"{x:1439,y:969,t:1527877107885};\\\", \\\"{x:1440,y:969,t:1527877107942};\\\", \\\"{x:1442,y:969,t:1527877107957};\\\", \\\"{x:1443,y:969,t:1527877107969};\\\", \\\"{x:1448,y:969,t:1527877107985};\\\", \\\"{x:1454,y:969,t:1527877108002};\\\", \\\"{x:1458,y:969,t:1527877108020};\\\", \\\"{x:1465,y:970,t:1527877108035};\\\", \\\"{x:1470,y:971,t:1527877108052};\\\", \\\"{x:1473,y:971,t:1527877108069};\\\", \\\"{x:1475,y:971,t:1527877108085};\\\", \\\"{x:1478,y:971,t:1527877108166};\\\", \\\"{x:1479,y:971,t:1527877108173};\\\", \\\"{x:1481,y:971,t:1527877108185};\\\", \\\"{x:1485,y:971,t:1527877108202};\\\", \\\"{x:1486,y:971,t:1527877108219};\\\", \\\"{x:1487,y:971,t:1527877108342};\\\", \\\"{x:1488,y:971,t:1527877108357};\\\", \\\"{x:1488,y:969,t:1527877108758};\\\", \\\"{x:1488,y:967,t:1527877108771};\\\", \\\"{x:1488,y:962,t:1527877108786};\\\", \\\"{x:1489,y:960,t:1527877108803};\\\", \\\"{x:1490,y:958,t:1527877108819};\\\", \\\"{x:1490,y:955,t:1527877108836};\\\", \\\"{x:1490,y:952,t:1527877108854};\\\", \\\"{x:1490,y:946,t:1527877108869};\\\", \\\"{x:1490,y:934,t:1527877108887};\\\", \\\"{x:1490,y:921,t:1527877108903};\\\", \\\"{x:1490,y:914,t:1527877108919};\\\", \\\"{x:1490,y:907,t:1527877108936};\\\", \\\"{x:1490,y:900,t:1527877108953};\\\", \\\"{x:1490,y:893,t:1527877108969};\\\", \\\"{x:1490,y:889,t:1527877108986};\\\", \\\"{x:1490,y:882,t:1527877109003};\\\", \\\"{x:1490,y:877,t:1527877109019};\\\", \\\"{x:1490,y:870,t:1527877109037};\\\", \\\"{x:1489,y:858,t:1527877109053};\\\", \\\"{x:1489,y:853,t:1527877109069};\\\", \\\"{x:1488,y:848,t:1527877109086};\\\", \\\"{x:1487,y:843,t:1527877109103};\\\", \\\"{x:1487,y:842,t:1527877109119};\\\", \\\"{x:1485,y:839,t:1527877109137};\\\", \\\"{x:1485,y:834,t:1527877109156};\\\", \\\"{x:1484,y:825,t:1527877109169};\\\", \\\"{x:1483,y:816,t:1527877109188};\\\", \\\"{x:1480,y:811,t:1527877109203};\\\", \\\"{x:1480,y:808,t:1527877109220};\\\", \\\"{x:1479,y:805,t:1527877109236};\\\", \\\"{x:1479,y:802,t:1527877109253};\\\", \\\"{x:1477,y:798,t:1527877109269};\\\", \\\"{x:1477,y:795,t:1527877109287};\\\", \\\"{x:1477,y:791,t:1527877109303};\\\", \\\"{x:1476,y:787,t:1527877109321};\\\", \\\"{x:1476,y:784,t:1527877109337};\\\", \\\"{x:1475,y:780,t:1527877109353};\\\", \\\"{x:1474,y:776,t:1527877109370};\\\", \\\"{x:1474,y:771,t:1527877109386};\\\", \\\"{x:1473,y:769,t:1527877109403};\\\", \\\"{x:1473,y:765,t:1527877109420};\\\", \\\"{x:1472,y:762,t:1527877109436};\\\", \\\"{x:1472,y:756,t:1527877109453};\\\", \\\"{x:1472,y:752,t:1527877109469};\\\", \\\"{x:1472,y:749,t:1527877109486};\\\", \\\"{x:1472,y:745,t:1527877109503};\\\", \\\"{x:1472,y:741,t:1527877109520};\\\", \\\"{x:1472,y:736,t:1527877109537};\\\", \\\"{x:1472,y:731,t:1527877109553};\\\", \\\"{x:1472,y:727,t:1527877109571};\\\", \\\"{x:1472,y:723,t:1527877109586};\\\", \\\"{x:1472,y:720,t:1527877109603};\\\", \\\"{x:1472,y:719,t:1527877109620};\\\", \\\"{x:1472,y:716,t:1527877109636};\\\", \\\"{x:1472,y:713,t:1527877109653};\\\", \\\"{x:1472,y:710,t:1527877109670};\\\", \\\"{x:1472,y:707,t:1527877109688};\\\", \\\"{x:1472,y:704,t:1527877109703};\\\", \\\"{x:1472,y:699,t:1527877109720};\\\", \\\"{x:1472,y:696,t:1527877109737};\\\", \\\"{x:1472,y:692,t:1527877109753};\\\", \\\"{x:1472,y:690,t:1527877109770};\\\", \\\"{x:1472,y:689,t:1527877109787};\\\", \\\"{x:1472,y:686,t:1527877109804};\\\", \\\"{x:1472,y:685,t:1527877109820};\\\", \\\"{x:1472,y:682,t:1527877109837};\\\", \\\"{x:1472,y:680,t:1527877109853};\\\", \\\"{x:1472,y:679,t:1527877109870};\\\", \\\"{x:1472,y:677,t:1527877109887};\\\", \\\"{x:1472,y:676,t:1527877109903};\\\", \\\"{x:1472,y:674,t:1527877109920};\\\", \\\"{x:1472,y:673,t:1527877111836};\\\", \\\"{x:1481,y:695,t:1527877111844};\\\", \\\"{x:1493,y:726,t:1527877111854};\\\", \\\"{x:1497,y:760,t:1527877111871};\\\", \\\"{x:1500,y:779,t:1527877111887};\\\", \\\"{x:1503,y:792,t:1527877111905};\\\", \\\"{x:1504,y:805,t:1527877111922};\\\", \\\"{x:1506,y:815,t:1527877111937};\\\", \\\"{x:1507,y:822,t:1527877111955};\\\", \\\"{x:1508,y:832,t:1527877111971};\\\", \\\"{x:1508,y:836,t:1527877111988};\\\", \\\"{x:1508,y:842,t:1527877112005};\\\", \\\"{x:1508,y:843,t:1527877112118};\\\", \\\"{x:1506,y:842,t:1527877112125};\\\", \\\"{x:1503,y:834,t:1527877112138};\\\", \\\"{x:1500,y:821,t:1527877112155};\\\", \\\"{x:1492,y:805,t:1527877112172};\\\", \\\"{x:1487,y:786,t:1527877112188};\\\", \\\"{x:1479,y:760,t:1527877112205};\\\", \\\"{x:1475,y:744,t:1527877112223};\\\", \\\"{x:1471,y:729,t:1527877112238};\\\", \\\"{x:1469,y:716,t:1527877112256};\\\", \\\"{x:1467,y:705,t:1527877112272};\\\", \\\"{x:1467,y:698,t:1527877112288};\\\", \\\"{x:1466,y:692,t:1527877112305};\\\", \\\"{x:1465,y:687,t:1527877112323};\\\", \\\"{x:1464,y:684,t:1527877112339};\\\", \\\"{x:1464,y:682,t:1527877112355};\\\", \\\"{x:1464,y:679,t:1527877112372};\\\", \\\"{x:1464,y:671,t:1527877112389};\\\", \\\"{x:1464,y:666,t:1527877112406};\\\", \\\"{x:1464,y:662,t:1527877112422};\\\", \\\"{x:1464,y:660,t:1527877112440};\\\", \\\"{x:1464,y:658,t:1527877112469};\\\", \\\"{x:1464,y:657,t:1527877112478};\\\", \\\"{x:1464,y:655,t:1527877112490};\\\", \\\"{x:1466,y:648,t:1527877112506};\\\", \\\"{x:1467,y:643,t:1527877112522};\\\", \\\"{x:1468,y:638,t:1527877112539};\\\", \\\"{x:1468,y:634,t:1527877112555};\\\", \\\"{x:1470,y:630,t:1527877112572};\\\", \\\"{x:1470,y:626,t:1527877112590};\\\", \\\"{x:1470,y:622,t:1527877112605};\\\", \\\"{x:1470,y:620,t:1527877112623};\\\", \\\"{x:1470,y:618,t:1527877112640};\\\", \\\"{x:1470,y:617,t:1527877112656};\\\", \\\"{x:1470,y:616,t:1527877112677};\\\", \\\"{x:1470,y:615,t:1527877112690};\\\", \\\"{x:1470,y:614,t:1527877112705};\\\", \\\"{x:1470,y:612,t:1527877112722};\\\", \\\"{x:1470,y:610,t:1527877112740};\\\", \\\"{x:1470,y:608,t:1527877112755};\\\", \\\"{x:1470,y:606,t:1527877112772};\\\", \\\"{x:1470,y:601,t:1527877112789};\\\", \\\"{x:1470,y:600,t:1527877112806};\\\", \\\"{x:1470,y:597,t:1527877112822};\\\", \\\"{x:1470,y:594,t:1527877112840};\\\", \\\"{x:1470,y:592,t:1527877112856};\\\", \\\"{x:1470,y:588,t:1527877112872};\\\", \\\"{x:1470,y:587,t:1527877112890};\\\", \\\"{x:1470,y:584,t:1527877112907};\\\", \\\"{x:1471,y:581,t:1527877112923};\\\", \\\"{x:1471,y:578,t:1527877112940};\\\", \\\"{x:1471,y:572,t:1527877112956};\\\", \\\"{x:1474,y:565,t:1527877112973};\\\", \\\"{x:1474,y:561,t:1527877112989};\\\", \\\"{x:1474,y:560,t:1527877113006};\\\", \\\"{x:1474,y:559,t:1527877113022};\\\", \\\"{x:1475,y:556,t:1527877113039};\\\", \\\"{x:1475,y:555,t:1527877113056};\\\", \\\"{x:1476,y:551,t:1527877113073};\\\", \\\"{x:1477,y:548,t:1527877113090};\\\", \\\"{x:1478,y:545,t:1527877113107};\\\", \\\"{x:1479,y:543,t:1527877113122};\\\", \\\"{x:1479,y:541,t:1527877113139};\\\", \\\"{x:1479,y:538,t:1527877113156};\\\", \\\"{x:1479,y:535,t:1527877113173};\\\", \\\"{x:1481,y:527,t:1527877113190};\\\", \\\"{x:1481,y:520,t:1527877113206};\\\", \\\"{x:1482,y:514,t:1527877113224};\\\", \\\"{x:1482,y:509,t:1527877113239};\\\", \\\"{x:1483,y:505,t:1527877113256};\\\", \\\"{x:1483,y:502,t:1527877113274};\\\", \\\"{x:1483,y:501,t:1527877113289};\\\", \\\"{x:1484,y:499,t:1527877113306};\\\", \\\"{x:1484,y:496,t:1527877113323};\\\", \\\"{x:1484,y:490,t:1527877113340};\\\", \\\"{x:1484,y:483,t:1527877113356};\\\", \\\"{x:1484,y:475,t:1527877113373};\\\", \\\"{x:1484,y:467,t:1527877113389};\\\", \\\"{x:1484,y:459,t:1527877113407};\\\", \\\"{x:1484,y:455,t:1527877113423};\\\", \\\"{x:1484,y:451,t:1527877113439};\\\", \\\"{x:1484,y:445,t:1527877113456};\\\", \\\"{x:1484,y:440,t:1527877113473};\\\", \\\"{x:1484,y:433,t:1527877113490};\\\", \\\"{x:1483,y:424,t:1527877113506};\\\", \\\"{x:1480,y:412,t:1527877113523};\\\", \\\"{x:1479,y:400,t:1527877113540};\\\", \\\"{x:1478,y:393,t:1527877113556};\\\", \\\"{x:1477,y:387,t:1527877113573};\\\", \\\"{x:1476,y:384,t:1527877113589};\\\", \\\"{x:1475,y:380,t:1527877113605};\\\", \\\"{x:1473,y:373,t:1527877113623};\\\", \\\"{x:1470,y:362,t:1527877113640};\\\", \\\"{x:1467,y:348,t:1527877113655};\\\", \\\"{x:1465,y:334,t:1527877113673};\\\", \\\"{x:1463,y:324,t:1527877113690};\\\", \\\"{x:1462,y:315,t:1527877113706};\\\", \\\"{x:1461,y:308,t:1527877113723};\\\", \\\"{x:1460,y:301,t:1527877113740};\\\", \\\"{x:1459,y:294,t:1527877113756};\\\", \\\"{x:1457,y:275,t:1527877113773};\\\", \\\"{x:1457,y:263,t:1527877113790};\\\", \\\"{x:1457,y:256,t:1527877113806};\\\", \\\"{x:1457,y:251,t:1527877113823};\\\", \\\"{x:1457,y:250,t:1527877113840};\\\", \\\"{x:1456,y:251,t:1527877114038};\\\", \\\"{x:1452,y:255,t:1527877114045};\\\", \\\"{x:1447,y:260,t:1527877114056};\\\", \\\"{x:1437,y:276,t:1527877114073};\\\", \\\"{x:1421,y:305,t:1527877114090};\\\", \\\"{x:1394,y:346,t:1527877114106};\\\", \\\"{x:1347,y:406,t:1527877114123};\\\", \\\"{x:1287,y:468,t:1527877114140};\\\", \\\"{x:1213,y:528,t:1527877114156};\\\", \\\"{x:1086,y:595,t:1527877114173};\\\", \\\"{x:990,y:631,t:1527877114190};\\\", \\\"{x:893,y:659,t:1527877114208};\\\", \\\"{x:802,y:672,t:1527877114223};\\\", \\\"{x:705,y:684,t:1527877114240};\\\", \\\"{x:590,y:690,t:1527877114257};\\\", \\\"{x:487,y:687,t:1527877114273};\\\", \\\"{x:366,y:658,t:1527877114290};\\\", \\\"{x:244,y:637,t:1527877114308};\\\", \\\"{x:144,y:625,t:1527877114322};\\\", \\\"{x:75,y:625,t:1527877114340};\\\", \\\"{x:23,y:625,t:1527877114357};\\\", \\\"{x:0,y:625,t:1527877114372};\\\", \\\"{x:11,y:614,t:1527877114500};\\\", \\\"{x:26,y:601,t:1527877114508};\\\", \\\"{x:36,y:593,t:1527877114523};\\\", \\\"{x:59,y:574,t:1527877114539};\\\", \\\"{x:79,y:556,t:1527877114557};\\\", \\\"{x:89,y:547,t:1527877114574};\\\", \\\"{x:99,y:540,t:1527877114590};\\\", \\\"{x:106,y:537,t:1527877114607};\\\", \\\"{x:115,y:531,t:1527877114624};\\\", \\\"{x:125,y:527,t:1527877114640};\\\", \\\"{x:135,y:522,t:1527877114657};\\\", \\\"{x:151,y:516,t:1527877114674};\\\", \\\"{x:171,y:511,t:1527877114691};\\\", \\\"{x:191,y:503,t:1527877114707};\\\", \\\"{x:211,y:496,t:1527877114724};\\\", \\\"{x:226,y:495,t:1527877114740};\\\", \\\"{x:233,y:495,t:1527877114757};\\\", \\\"{x:239,y:495,t:1527877114774};\\\", \\\"{x:249,y:495,t:1527877114791};\\\", \\\"{x:263,y:496,t:1527877114807};\\\", \\\"{x:273,y:497,t:1527877114824};\\\", \\\"{x:279,y:501,t:1527877114842};\\\", \\\"{x:286,y:505,t:1527877114856};\\\", \\\"{x:287,y:507,t:1527877114873};\\\", \\\"{x:287,y:512,t:1527877114890};\\\", \\\"{x:287,y:517,t:1527877114908};\\\", \\\"{x:282,y:522,t:1527877114924};\\\", \\\"{x:269,y:531,t:1527877114940};\\\", \\\"{x:258,y:539,t:1527877114958};\\\", \\\"{x:247,y:546,t:1527877114974};\\\", \\\"{x:233,y:556,t:1527877114990};\\\", \\\"{x:220,y:566,t:1527877115007};\\\", \\\"{x:210,y:573,t:1527877115024};\\\", \\\"{x:203,y:577,t:1527877115041};\\\", \\\"{x:198,y:580,t:1527877115057};\\\", \\\"{x:194,y:582,t:1527877115073};\\\", \\\"{x:193,y:582,t:1527877115091};\\\", \\\"{x:192,y:583,t:1527877115108};\\\", \\\"{x:191,y:584,t:1527877115123};\\\", \\\"{x:191,y:589,t:1527877115140};\\\", \\\"{x:189,y:594,t:1527877115157};\\\", \\\"{x:186,y:602,t:1527877115173};\\\", \\\"{x:184,y:611,t:1527877115192};\\\", \\\"{x:183,y:619,t:1527877115209};\\\", \\\"{x:182,y:626,t:1527877115223};\\\", \\\"{x:180,y:637,t:1527877115241};\\\", \\\"{x:179,y:648,t:1527877115258};\\\", \\\"{x:178,y:662,t:1527877115274};\\\", \\\"{x:177,y:676,t:1527877115291};\\\", \\\"{x:177,y:685,t:1527877115308};\\\", \\\"{x:177,y:690,t:1527877115324};\\\", \\\"{x:179,y:695,t:1527877115341};\\\", \\\"{x:181,y:698,t:1527877115358};\\\", \\\"{x:187,y:700,t:1527877115373};\\\", \\\"{x:192,y:700,t:1527877115391};\\\", \\\"{x:203,y:700,t:1527877115408};\\\", \\\"{x:220,y:700,t:1527877115424};\\\", \\\"{x:246,y:693,t:1527877115441};\\\", \\\"{x:279,y:685,t:1527877115457};\\\", \\\"{x:318,y:667,t:1527877115475};\\\", \\\"{x:361,y:651,t:1527877115492};\\\", \\\"{x:412,y:635,t:1527877115509};\\\", \\\"{x:467,y:612,t:1527877115524};\\\", \\\"{x:534,y:576,t:1527877115541};\\\", \\\"{x:570,y:559,t:1527877115558};\\\", \\\"{x:599,y:547,t:1527877115574};\\\", \\\"{x:622,y:535,t:1527877115591};\\\", \\\"{x:645,y:526,t:1527877115609};\\\", \\\"{x:667,y:516,t:1527877115625};\\\", \\\"{x:686,y:508,t:1527877115641};\\\", \\\"{x:698,y:502,t:1527877115658};\\\", \\\"{x:700,y:502,t:1527877115675};\\\", \\\"{x:696,y:502,t:1527877115765};\\\", \\\"{x:688,y:506,t:1527877115775};\\\", \\\"{x:678,y:511,t:1527877115791};\\\", \\\"{x:669,y:517,t:1527877115808};\\\", \\\"{x:668,y:524,t:1527877115825};\\\", \\\"{x:664,y:530,t:1527877115841};\\\", \\\"{x:655,y:541,t:1527877115859};\\\", \\\"{x:646,y:551,t:1527877115875};\\\", \\\"{x:633,y:561,t:1527877115892};\\\", \\\"{x:623,y:570,t:1527877115908};\\\", \\\"{x:615,y:579,t:1527877115925};\\\", \\\"{x:613,y:581,t:1527877115942};\\\", \\\"{x:613,y:582,t:1527877116013};\\\", \\\"{x:613,y:583,t:1527877116029};\\\", \\\"{x:613,y:585,t:1527877116413};\\\", \\\"{x:613,y:587,t:1527877116437};\\\", \\\"{x:612,y:589,t:1527877116453};\\\", \\\"{x:612,y:590,t:1527877116461};\\\", \\\"{x:609,y:595,t:1527877116477};\\\", \\\"{x:608,y:597,t:1527877116494};\\\", \\\"{x:607,y:598,t:1527877116517};\\\", \\\"{x:605,y:598,t:1527877117093};\\\", \\\"{x:588,y:598,t:1527877117109};\\\", \\\"{x:562,y:598,t:1527877117126};\\\", \\\"{x:536,y:598,t:1527877117142};\\\", \\\"{x:508,y:598,t:1527877117158};\\\", \\\"{x:472,y:598,t:1527877117177};\\\", \\\"{x:448,y:598,t:1527877117192};\\\", \\\"{x:430,y:598,t:1527877117209};\\\", \\\"{x:420,y:599,t:1527877117226};\\\", \\\"{x:415,y:599,t:1527877117243};\\\", \\\"{x:411,y:599,t:1527877117259};\\\", \\\"{x:409,y:600,t:1527877117276};\\\", \\\"{x:408,y:600,t:1527877117293};\\\", \\\"{x:411,y:600,t:1527877117373};\\\", \\\"{x:412,y:600,t:1527877117405};\\\", \\\"{x:413,y:600,t:1527877117460};\\\", \\\"{x:414,y:599,t:1527877117476};\\\", \\\"{x:412,y:599,t:1527877117581};\\\", \\\"{x:409,y:599,t:1527877117596};\\\", \\\"{x:406,y:599,t:1527877117610};\\\", \\\"{x:402,y:599,t:1527877117626};\\\", \\\"{x:399,y:599,t:1527877117643};\\\", \\\"{x:397,y:599,t:1527877117659};\\\", \\\"{x:395,y:599,t:1527877117676};\\\", \\\"{x:394,y:599,t:1527877117693};\\\", \\\"{x:393,y:598,t:1527877117943};\\\", \\\"{x:396,y:595,t:1527877117960};\\\", \\\"{x:398,y:594,t:1527877117975};\\\", \\\"{x:399,y:594,t:1527877117993};\\\", \\\"{x:402,y:594,t:1527877118010};\\\", \\\"{x:409,y:601,t:1527877118025};\\\", \\\"{x:415,y:610,t:1527877118044};\\\", \\\"{x:424,y:624,t:1527877118061};\\\", \\\"{x:426,y:628,t:1527877118076};\\\", \\\"{x:430,y:648,t:1527877118094};\\\", \\\"{x:431,y:668,t:1527877118110};\\\", \\\"{x:432,y:674,t:1527877118126};\\\", \\\"{x:433,y:676,t:1527877118164};\\\", \\\"{x:433,y:677,t:1527877118176};\\\", \\\"{x:433,y:678,t:1527877118193};\\\", \\\"{x:433,y:680,t:1527877118485};\\\", \\\"{x:433,y:682,t:1527877118493};\\\", \\\"{x:433,y:684,t:1527877118510};\\\", \\\"{x:433,y:686,t:1527877118526};\\\", \\\"{x:433,y:687,t:1527877118604};\\\", \\\"{x:434,y:687,t:1527877118845};\\\", \\\"{x:434,y:689,t:1527877118861};\\\", \\\"{x:435,y:689,t:1527877118877};\\\", \\\"{x:435,y:690,t:1527877118909};\\\", \\\"{x:437,y:695,t:1527877118917};\\\", \\\"{x:439,y:697,t:1527877118928};\\\", \\\"{x:451,y:708,t:1527877118944};\\\", \\\"{x:471,y:724,t:1527877118962};\\\", \\\"{x:490,y:739,t:1527877118979};\\\", \\\"{x:506,y:753,t:1527877118995};\\\", \\\"{x:512,y:759,t:1527877119010};\\\", \\\"{x:513,y:760,t:1527877119062};\\\", \\\"{x:513,y:762,t:1527877119078};\\\", \\\"{x:515,y:763,t:1527877119094};\\\", \\\"{x:515,y:764,t:1527877119112};\\\", \\\"{x:518,y:763,t:1527877119286};\\\", \\\"{x:519,y:763,t:1527877119301};\\\", \\\"{x:520,y:762,t:1527877119317};\\\", \\\"{x:521,y:761,t:1527877119327};\\\", \\\"{x:522,y:761,t:1527877119344};\\\", \\\"{x:522,y:760,t:1527877119361};\\\", \\\"{x:524,y:757,t:1527877119377};\\\", \\\"{x:525,y:755,t:1527877119394};\\\", \\\"{x:525,y:754,t:1527877119411};\\\", \\\"{x:525,y:753,t:1527877119427};\\\", \\\"{x:526,y:752,t:1527877119445};\\\", \\\"{x:527,y:751,t:1527877119461};\\\", \\\"{x:528,y:750,t:1527877119478};\\\" ] }, { \\\"rt\\\": 133999, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 845510, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"I find 12p on the bottom of the chart and follow the right slanted line. The shifts on this line begin at 12p.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 11994, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 858511, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 24513, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Natural Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 884039, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 96160, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 981595, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"F9531\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"F9531\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 295, dom: 811, initialDom: 857",
  "javascriptErrors": []
}