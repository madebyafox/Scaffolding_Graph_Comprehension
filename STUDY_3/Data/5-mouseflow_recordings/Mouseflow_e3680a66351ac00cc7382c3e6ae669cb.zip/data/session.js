var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e3680a66351ac00cc7382c3e6ae669cb",
  "created": "2018-06-01T10:15:52.6779004-07:00",
  "lastActivity": "2018-06-01T10:16:27.8238488-07:00",
  "pageViews": [
    {
      "id": "06015258fe5e9a362fbce9740dfcafe19932d51f",
      "startTime": "2018-06-01T10:15:52.9007414-07:00",
      "endTime": "2018-06-01T10:16:27.8238488-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 35105,
      "engagementTime": 35055,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 35105,
  "engagementTime": 35055,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=1Z2H9",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ac4a6b7cac1e0c690e6a8ba17c935f4d",
  "gdpr": false
}