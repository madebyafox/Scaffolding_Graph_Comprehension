var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "61d6a5b6a1d2284169cce81a67d5bfc9",
  "created": "2018-06-01T11:14:30.6245846-07:00",
  "lastActivity": "2018-06-01T11:14:40.2425846-07:00",
  "pageViews": [
    {
      "id": "06013040f9fe46ba28e106aa932c0c5b4c374806",
      "startTime": "2018-06-01T11:14:30.6245846-07:00",
      "endTime": "2018-06-01T11:14:40.2425846-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 9618,
      "engagementTime": 9618,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 9618,
  "engagementTime": 9618,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.46",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=JPN18",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "76716f929e6adff4397a35a3d39a7f60",
  "gdpr": false
}