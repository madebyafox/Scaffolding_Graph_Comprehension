var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052234899f7af46d1f57d21e2957f35e19fddf52"] = {
  "startTime": "2018-05-22T17:21:34.0513541Z",
  "websitePageUrl": "/16",
  "visitTime": 79837,
  "engagementTime": 76722,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "b248faffdaac654f97b4a1815a3979c7",
    "created": "2018-05-22T17:21:34.0513541+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=VSHHA",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "a757b4edc6725bf330d16c7c6c3317b5",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/b248faffdaac654f97b4a1815a3979c7/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 100,
      "e": 100,
      "ty": 2,
      "x": 1353,
      "y": 309
    },
    {
      "t": 100,
      "e": 100,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 200,
      "e": 200,
      "ty": 2,
      "x": 1310,
      "y": 309
    },
    {
      "t": 250,
      "e": 250,
      "ty": 41,
      "x": 44837,
      "y": 16674,
      "ta": "html > body"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 935,
      "y": 506
    },
    {
      "t": 1241,
      "e": 1241,
      "ty": 6,
      "x": 384,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 24797,
      "y": 17859,
      "ta": "#strategyButton"
    },
    {
      "t": 1256,
      "e": 1256,
      "ty": 7,
      "x": 254,
      "y": 703,
      "ta": "#strategyButton"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 92,
      "y": 749
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 73,
      "y": 755
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 158,
      "y": 636
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 6846,
      "y": 34789,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 230,
      "y": 610
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 3,
      "x": 236,
      "y": 605,
      "ta": "#.strategy"
    },
    {
      "t": 1702,
      "e": 1702,
      "ty": 2,
      "x": 236,
      "y": 605
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 15614,
      "y": 61762,
      "ta": "#.strategy"
    },
    {
      "t": 1804,
      "e": 1804,
      "ty": 4,
      "x": 15614,
      "y": 61762,
      "ta": "#.strategy"
    },
    {
      "t": 1805,
      "e": 1805,
      "ty": 5,
      "x": 236,
      "y": 605,
      "ta": "#.strategy"
    },
    {
      "t": 1886,
      "e": 1886,
      "ty": 6,
      "x": 237,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 237,
      "y": 601
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 241,
      "y": 585
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 16176,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2004,
      "e": 2004,
      "ty": 3,
      "x": 241,
      "y": 585,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2004,
      "e": 2004,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2124,
      "e": 2124,
      "ty": 4,
      "x": 16176,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2124,
      "e": 2124,
      "ty": 5,
      "x": 241,
      "y": 585,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5494,
      "e": 5494,
      "ty": 7,
      "x": 296,
      "y": 646,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 296,
      "y": 646
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 41,
      "x": 22359,
      "y": 35343,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1131,
      "y": 931
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 1147,
      "y": 949
    },
    {
      "t": 5750,
      "e": 5750,
      "ty": 41,
      "x": 25299,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 1145,
      "y": 954
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 2,
      "x": 1219,
      "y": 976
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 1288,
      "y": 978
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 35210,
      "y": 37119,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[13] > text"
    },
    {
      "t": 6100,
      "e": 6100,
      "ty": 2,
      "x": 1273,
      "y": 986
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1171,
      "y": 965
    },
    {
      "t": 6252,
      "e": 6252,
      "ty": 41,
      "x": 21564,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1090,
      "y": 954
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1163,
      "y": 936
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 2,
      "x": 1180,
      "y": 931
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 27765,
      "y": 56797,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1177,
      "y": 940
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1175,
      "y": 946
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 27060,
      "y": 58157,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1166,
      "y": 950
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 1163,
      "y": 950
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 2,
      "x": 1152,
      "y": 956
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 25792,
      "y": 58587,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 1136,
      "y": 960
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 24664,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7300,
      "e": 7300,
      "ty": 2,
      "x": 1137,
      "y": 963
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1145,
      "y": 965
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1149,
      "y": 965
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 25580,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1152,
      "y": 966
    },
    {
      "t": 7700,
      "e": 7700,
      "ty": 2,
      "x": 1155,
      "y": 967
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 26074,
      "y": 59375,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 1156,
      "y": 967
    },
    {
      "t": 7900,
      "e": 7900,
      "ty": 2,
      "x": 1159,
      "y": 969
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 41,
      "x": 42230,
      "y": 255,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 1155,
      "y": 967
    },
    {
      "t": 8251,
      "e": 8251,
      "ty": 41,
      "x": 85,
      "y": 65412,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[9]"
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 2,
      "x": 1152,
      "y": 959
    },
    {
      "t": 8400,
      "e": 8400,
      "ty": 2,
      "x": 1150,
      "y": 955
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 41,
      "x": 25651,
      "y": 58515,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 1156,
      "y": 956
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 823,
      "y": 64674,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[9]"
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 2,
      "x": 1154,
      "y": 944
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 2,
      "x": 1172,
      "y": 892
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 27201,
      "y": 54003,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9100,
      "e": 9100,
      "ty": 2,
      "x": 1183,
      "y": 868
    },
    {
      "t": 9200,
      "e": 9200,
      "ty": 2,
      "x": 1223,
      "y": 802
    },
    {
      "t": 9251,
      "e": 9251,
      "ty": 41,
      "x": 32486,
      "y": 44907,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9300,
      "e": 9300,
      "ty": 2,
      "x": 1274,
      "y": 720
    },
    {
      "t": 9399,
      "e": 9399,
      "ty": 2,
      "x": 1375,
      "y": 577
    },
    {
      "t": 9500,
      "e": 9500,
      "ty": 2,
      "x": 1390,
      "y": 542
    },
    {
      "t": 9500,
      "e": 9500,
      "ty": 41,
      "x": 42563,
      "y": 28935,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9600,
      "e": 9600,
      "ty": 2,
      "x": 1423,
      "y": 469
    },
    {
      "t": 9700,
      "e": 9700,
      "ty": 2,
      "x": 1449,
      "y": 419
    },
    {
      "t": 9750,
      "e": 9750,
      "ty": 41,
      "x": 46862,
      "y": 19767,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9800,
      "e": 9800,
      "ty": 2,
      "x": 1451,
      "y": 414
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 2,
      "x": 1414,
      "y": 491
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 41,
      "x": 44254,
      "y": 25282,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10100,
      "e": 10100,
      "ty": 2,
      "x": 1389,
      "y": 550
    },
    {
      "t": 10200,
      "e": 10200,
      "ty": 2,
      "x": 1364,
      "y": 598
    },
    {
      "t": 10250,
      "e": 10250,
      "ty": 41,
      "x": 39956,
      "y": 34020,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10299,
      "e": 10299,
      "ty": 2,
      "x": 1333,
      "y": 646
    },
    {
      "t": 10400,
      "e": 10400,
      "ty": 2,
      "x": 1137,
      "y": 941
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 2,
      "x": 1086,
      "y": 1058
    },
    {
      "t": 10500,
      "e": 10500,
      "ty": 41,
      "x": 23297,
      "y": 65321,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 10600,
      "e": 10600,
      "ty": 2,
      "x": 1092,
      "y": 1062
    },
    {
      "t": 10700,
      "e": 10700,
      "ty": 2,
      "x": 1091,
      "y": 1046
    },
    {
      "t": 10751,
      "e": 10751,
      "ty": 41,
      "x": 23255,
      "y": 60521,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10800,
      "e": 10800,
      "ty": 2,
      "x": 1168,
      "y": 922
    },
    {
      "t": 10899,
      "e": 10899,
      "ty": 2,
      "x": 1174,
      "y": 918
    },
    {
      "t": 10999,
      "e": 10999,
      "ty": 2,
      "x": 1178,
      "y": 936
    },
    {
      "t": 11000,
      "e": 11000,
      "ty": 41,
      "x": 27624,
      "y": 57155,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11100,
      "e": 11100,
      "ty": 2,
      "x": 1169,
      "y": 947
    },
    {
      "t": 11200,
      "e": 11200,
      "ty": 2,
      "x": 1152,
      "y": 959
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 41,
      "x": 25651,
      "y": 58945,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11300,
      "e": 11300,
      "ty": 2,
      "x": 1150,
      "y": 964
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 41,
      "x": 21586,
      "y": 5957,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 19251,
      "e": 16501,
      "ty": 41,
      "x": 25651,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 19300,
      "e": 16550,
      "ty": 2,
      "x": 1150,
      "y": 965
    },
    {
      "t": 19400,
      "e": 16650,
      "ty": 2,
      "x": 1153,
      "y": 966
    },
    {
      "t": 20001,
      "e": 17251,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20700,
      "e": 17950,
      "ty": 2,
      "x": 1104,
      "y": 943
    },
    {
      "t": 20750,
      "e": 18000,
      "ty": 41,
      "x": 62916,
      "y": 4106,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 20756,
      "e": 18006,
      "ty": 6,
      "x": 273,
      "y": 594,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20789,
      "e": 18039,
      "ty": 7,
      "x": 16,
      "y": 558,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20800,
      "e": 18050,
      "ty": 2,
      "x": 16,
      "y": 558
    },
    {
      "t": 20900,
      "e": 18150,
      "ty": 2,
      "x": 61,
      "y": 568
    },
    {
      "t": 20940,
      "e": 18190,
      "ty": 6,
      "x": 115,
      "y": 583,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21000,
      "e": 18250,
      "ty": 2,
      "x": 136,
      "y": 580
    },
    {
      "t": 21000,
      "e": 18250,
      "ty": 41,
      "x": 4373,
      "y": 46332,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21100,
      "e": 18350,
      "ty": 2,
      "x": 249,
      "y": 602
    },
    {
      "t": 21107,
      "e": 18357,
      "ty": 7,
      "x": 283,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21123,
      "e": 18373,
      "ty": 6,
      "x": 315,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21200,
      "e": 18450,
      "ty": 2,
      "x": 357,
      "y": 579
    },
    {
      "t": 21250,
      "e": 18500,
      "ty": 41,
      "x": 29103,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21284,
      "e": 18534,
      "ty": 3,
      "x": 356,
      "y": 577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21300,
      "e": 18550,
      "ty": 2,
      "x": 356,
      "y": 577
    },
    {
      "t": 21396,
      "e": 18646,
      "ty": 4,
      "x": 29103,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21396,
      "e": 18646,
      "ty": 5,
      "x": 356,
      "y": 577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23200,
      "e": 20450,
      "ty": 2,
      "x": 343,
      "y": 573
    },
    {
      "t": 23250,
      "e": 20500,
      "ty": 41,
      "x": 27305,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23301,
      "e": 20551,
      "ty": 2,
      "x": 340,
      "y": 571
    },
    {
      "t": 25385,
      "e": 22635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 25392,
      "e": 22642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 25432,
      "e": 22682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 25576,
      "e": 22826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 25753,
      "e": 23003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 25753,
      "e": 23003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25832,
      "e": 23082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "W"
    },
    {
      "t": 25952,
      "e": 23202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 26065,
      "e": 23315,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "W"
    },
    {
      "t": 26080,
      "e": 23330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26081,
      "e": 23331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26199,
      "e": 23449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Wo"
    },
    {
      "t": 27400,
      "e": 24650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27448,
      "e": 24698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "W"
    },
    {
      "t": 27552,
      "e": 24802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27632,
      "e": 24882,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 27696,
      "e": 24946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 27800,
      "e": 25050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 27960,
      "e": 25210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27961,
      "e": 25211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28031,
      "e": 25281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "D"
    },
    {
      "t": 28039,
      "e": 25289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 28151,
      "e": 25401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "D"
    },
    {
      "t": 28320,
      "e": 25570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 28321,
      "e": 25571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28432,
      "e": 25682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Du"
    },
    {
      "t": 28488,
      "e": 25738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28488,
      "e": 25738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28585,
      "e": 25835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Dur"
    },
    {
      "t": 28728,
      "e": 25978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28729,
      "e": 25979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28743,
      "e": 25993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "81"
    },
    {
      "t": 28743,
      "e": 25993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28792,
      "e": 26042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duraq"
    },
    {
      "t": 28799,
      "e": 26049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28799,
      "e": 26049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28823,
      "e": 26073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28887,
      "e": 26137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29144,
      "e": 26394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29144,
      "e": 26394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29232,
      "e": 26482,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 29336,
      "e": 26586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29336,
      "e": 26586,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29415,
      "e": 26665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29768,
      "e": 27018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29816,
      "e": 27066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duraqti"
    },
    {
      "t": 29920,
      "e": 27170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29952,
      "e": 27202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duraqt"
    },
    {
      "t": 30001,
      "e": 27251,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30047,
      "e": 27297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30095,
      "e": 27345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duraq"
    },
    {
      "t": 30201,
      "e": 27451,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duraq"
    },
    {
      "t": 30424,
      "e": 27674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30495,
      "e": 27745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Dura"
    },
    {
      "t": 30602,
      "e": 27852,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Dura"
    },
    {
      "t": 31072,
      "e": 28322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31073,
      "e": 28323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31144,
      "e": 28394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31329,
      "e": 28579,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31329,
      "e": 28579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31400,
      "e": 28650,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31496,
      "e": 28746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31496,
      "e": 28746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31568,
      "e": 28818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31711,
      "e": 28961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31712,
      "e": 28962,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31856,
      "e": 29106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 31880,
      "e": 29130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31881,
      "e": 29131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31959,
      "e": 29209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32103,
      "e": 29353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32103,
      "e": 29353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32199,
      "e": 29449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32200,
      "e": 29450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32223,
      "e": 29473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||le"
    },
    {
      "t": 32255,
      "e": 29505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32376,
      "e": 29626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32377,
      "e": 29627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32456,
      "e": 29706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32536,
      "e": 29786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32536,
      "e": 29786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32607,
      "e": 29857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32632,
      "e": 29882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32632,
      "e": 29882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32784,
      "e": 30034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33032,
      "e": 30282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33033,
      "e": 30283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33104,
      "e": 30354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33280,
      "e": 30530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33281,
      "e": 30531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33359,
      "e": 30609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 33463,
      "e": 30713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33464,
      "e": 30714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33567,
      "e": 30817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 33575,
      "e": 30825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33575,
      "e": 30825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33695,
      "e": 30945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33736,
      "e": 30986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33737,
      "e": 30987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33871,
      "e": 31121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34096,
      "e": 31346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 34097,
      "e": 31347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34175,
      "e": 31425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 34368,
      "e": 31618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34369,
      "e": 31619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34455,
      "e": 31705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 34560,
      "e": 31810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 34560,
      "e": 31810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34679,
      "e": 31929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 34679,
      "e": 31929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 34679,
      "e": 31929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34801,
      "e": 32051,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duration less than foru"
    },
    {
      "t": 34807,
      "e": 32057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 34823,
      "e": 32073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34823,
      "e": 32073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34952,
      "e": 32202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34975,
      "e": 32225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34975,
      "e": 32225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35096,
      "e": 32346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35097,
      "e": 32347,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35104,
      "e": 32354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 35223,
      "e": 32473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35408,
      "e": 32658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35471,
      "e": 32721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duration less than foru a"
    },
    {
      "t": 35568,
      "e": 32818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35615,
      "e": 32865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duration less than foru "
    },
    {
      "t": 35719,
      "e": 32969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35759,
      "e": 33009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duration less than foru"
    },
    {
      "t": 35864,
      "e": 33114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35911,
      "e": 33161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duration less than for"
    },
    {
      "t": 36015,
      "e": 33265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 36105,
      "e": 33355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duration less than fo"
    },
    {
      "t": 36568,
      "e": 33818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 36568,
      "e": 33818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36648,
      "e": 33898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 36696,
      "e": 33946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 36697,
      "e": 33947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36802,
      "e": 34052,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Duration less than four"
    },
    {
      "t": 36808,
      "e": 34058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 37600,
      "e": 34850,
      "ty": 2,
      "x": 182,
      "y": 526
    },
    {
      "t": 37605,
      "e": 34855,
      "ty": 7,
      "x": 106,
      "y": 516,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37700,
      "e": 34950,
      "ty": 2,
      "x": 29,
      "y": 508
    },
    {
      "t": 37750,
      "e": 35000,
      "ty": 41,
      "x": 723,
      "y": 27033,
      "ta": "> div.stimulus"
    },
    {
      "t": 37800,
      "e": 35050,
      "ty": 2,
      "x": 30,
      "y": 491
    },
    {
      "t": 37900,
      "e": 35150,
      "ty": 2,
      "x": 55,
      "y": 500
    },
    {
      "t": 38000,
      "e": 35250,
      "ty": 2,
      "x": 57,
      "y": 500
    },
    {
      "t": 38001,
      "e": 35251,
      "ty": 41,
      "x": 1687,
      "y": 27255,
      "ta": "> div.stimulus"
    },
    {
      "t": 38099,
      "e": 35349,
      "ty": 2,
      "x": 81,
      "y": 526
    },
    {
      "t": 38121,
      "e": 35371,
      "ty": 6,
      "x": 101,
      "y": 547,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38200,
      "e": 35450,
      "ty": 2,
      "x": 101,
      "y": 547
    },
    {
      "t": 38250,
      "e": 35500,
      "ty": 41,
      "x": 439,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38300,
      "e": 35550,
      "ty": 2,
      "x": 101,
      "y": 543
    },
    {
      "t": 38321,
      "e": 35571,
      "ty": 7,
      "x": 94,
      "y": 519,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38400,
      "e": 35650,
      "ty": 2,
      "x": 94,
      "y": 519
    },
    {
      "t": 38501,
      "e": 35751,
      "ty": 41,
      "x": 2961,
      "y": 28308,
      "ta": "> div.stimulus"
    },
    {
      "t": 38600,
      "e": 35850,
      "ty": 2,
      "x": 95,
      "y": 518
    },
    {
      "t": 38604,
      "e": 35854,
      "ty": 6,
      "x": 100,
      "y": 528,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38700,
      "e": 35950,
      "ty": 2,
      "x": 104,
      "y": 536
    },
    {
      "t": 38750,
      "e": 36000,
      "ty": 41,
      "x": 776,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38800,
      "e": 36050,
      "ty": 2,
      "x": 100,
      "y": 535
    },
    {
      "t": 38900,
      "e": 36050,
      "ty": 2,
      "x": 99,
      "y": 534
    },
    {
      "t": 38965,
      "e": 36115,
      "ty": 3,
      "x": 99,
      "y": 534,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39000,
      "e": 36150,
      "ty": 41,
      "x": 214,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39083,
      "e": 36233,
      "ty": 4,
      "x": 214,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39083,
      "e": 36233,
      "ty": 5,
      "x": 99,
      "y": 534,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39200,
      "e": 36350,
      "ty": 2,
      "x": 128,
      "y": 561
    },
    {
      "t": 39205,
      "e": 36355,
      "ty": 7,
      "x": 211,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39238,
      "e": 36388,
      "ty": 6,
      "x": 427,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 39250,
      "e": 36400,
      "ty": 41,
      "x": 48280,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 39255,
      "e": 36405,
      "ty": 7,
      "x": 512,
      "y": 684,
      "ta": "#strategyButton"
    },
    {
      "t": 39299,
      "e": 36449,
      "ty": 2,
      "x": 567,
      "y": 729
    },
    {
      "t": 39400,
      "e": 36550,
      "ty": 2,
      "x": 568,
      "y": 735
    },
    {
      "t": 39480,
      "e": 36630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 39501,
      "e": 36651,
      "ty": 41,
      "x": 52934,
      "y": 40273,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 39679,
      "e": 36829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39800,
      "e": 36950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 39801,
      "e": 36951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39847,
      "e": 36997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "MDuration less than four"
    },
    {
      "t": 39895,
      "e": 37045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 39967,
      "e": 37117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39984,
      "e": 37134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 39984,
      "e": 37134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39991,
      "e": 37141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 39992,
      "e": 37142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40031,
      "e": 37181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "MujDuration less than four"
    },
    {
      "t": 40079,
      "e": 37229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40127,
      "e": 37277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 40127,
      "e": 37277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40199,
      "e": 37349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "MujsDuration less than four"
    },
    {
      "t": 40248,
      "e": 37398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40248,
      "e": 37398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40399,
      "e": 37549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "MujstDuration less than four"
    },
    {
      "t": 40415,
      "e": 37565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40416,
      "e": 37566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40511,
      "e": 37661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Mujst Duration less than four"
    },
    {
      "t": 40712,
      "e": 37862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40767,
      "e": 37917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "MujstDuration less than four"
    },
    {
      "t": 40880,
      "e": 38030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40928,
      "e": 38078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "MujsDuration less than four"
    },
    {
      "t": 41032,
      "e": 38182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41080,
      "e": 38230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "MujDuration less than four"
    },
    {
      "t": 41200,
      "e": 38350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41287,
      "e": 38437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "MuDuration less than four"
    },
    {
      "t": 41801,
      "e": 38951,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 41802,
      "e": 38952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41919,
      "e": 39069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "MusDuration less than four"
    },
    {
      "t": 41936,
      "e": 39086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 41936,
      "e": 39086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42048,
      "e": 39198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "MustDuration less than four"
    },
    {
      "t": 42087,
      "e": 39237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42087,
      "e": 39237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42203,
      "e": 39353,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must Duration less than four"
    },
    {
      "t": 42207,
      "e": 39357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must Duration less than four"
    },
    {
      "t": 42311,
      "e": 39461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 42314,
      "e": 39464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42375,
      "e": 39525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must iDuration less than four"
    },
    {
      "t": 42496,
      "e": 39646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 42496,
      "e": 39646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42592,
      "e": 39742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must inDuration less than four"
    },
    {
      "t": 42600,
      "e": 39750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42600,
      "e": 39750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42695,
      "e": 39845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in Duration less than four"
    },
    {
      "t": 42807,
      "e": 39957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 42808,
      "e": 39958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42871,
      "e": 40021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in tDuration less than four"
    },
    {
      "t": 42959,
      "e": 40109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 42960,
      "e": 40110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43096,
      "e": 40246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in thDuration less than four"
    },
    {
      "t": 43104,
      "e": 40254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43105,
      "e": 40255,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43111,
      "e": 40261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43113,
      "e": 40263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43215,
      "e": 40263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the Duration less than four"
    },
    {
      "t": 43231,
      "e": 40279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43431,
      "e": 40479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 43431,
      "e": 40479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43495,
      "e": 40543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the lDuration less than four"
    },
    {
      "t": 43603,
      "e": 40651,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the lDuration less than four"
    },
    {
      "t": 43607,
      "e": 40655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43608,
      "e": 40656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43671,
      "e": 40719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the liDuration less than four"
    },
    {
      "t": 43783,
      "e": 40831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43784,
      "e": 40832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43888,
      "e": 40936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43889,
      "e": 40937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43903,
      "e": 40951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the lineDuration less than four"
    },
    {
      "t": 43927,
      "e": 40975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43927,
      "e": 40975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43999,
      "e": 41047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line Duration less than four"
    },
    {
      "t": 44007,
      "e": 41055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44144,
      "e": 41192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 44145,
      "e": 41193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44215,
      "e": 41263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line fDuration less than four"
    },
    {
      "t": 44400,
      "e": 41448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44401,
      "e": 41449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44504,
      "e": 41552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line foDuration less than four"
    },
    {
      "t": 44688,
      "e": 41736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 44688,
      "e": 41736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44802,
      "e": 41850,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line forDuration less than four"
    },
    {
      "t": 44831,
      "e": 41879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line forDuration less than four"
    },
    {
      "t": 44879,
      "e": 41927,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44880,
      "e": 41928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45003,
      "e": 42051,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line for Duration less than four"
    },
    {
      "t": 45032,
      "e": 42080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line for Duration less than four"
    },
    {
      "t": 45816,
      "e": 42864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 45816,
      "e": 42864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45912,
      "e": 42960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line for 1Duration less than four"
    },
    {
      "t": 46039,
      "e": 43087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 46041,
      "e": 43089,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46160,
      "e": 43208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line for 12Duration less than four"
    },
    {
      "t": 46232,
      "e": 43280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46233,
      "e": 43281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46375,
      "e": 43423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line for 12 Duration less than four"
    },
    {
      "t": 46424,
      "e": 43472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 46424,
      "e": 43472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46527,
      "e": 43575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line for 12 aDuration less than four"
    },
    {
      "t": 46535,
      "e": 43583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 46535,
      "e": 43583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46680,
      "e": 43728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 46683,
      "e": 43731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46695,
      "e": 43731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line for 12 andDuration less than four"
    },
    {
      "t": 46775,
      "e": 43811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46799,
      "e": 43835,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46799,
      "e": 43835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46904,
      "e": 43940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line for 12 and Duration less than four"
    },
    {
      "t": 47600,
      "e": 44636,
      "ty": 2,
      "x": 504,
      "y": 715
    },
    {
      "t": 47700,
      "e": 44736,
      "ty": 2,
      "x": 500,
      "y": 714
    },
    {
      "t": 47750,
      "e": 44786,
      "ty": 41,
      "x": 45290,
      "y": 39110,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 47800,
      "e": 44836,
      "ty": 2,
      "x": 479,
      "y": 698
    },
    {
      "t": 47812,
      "e": 44848,
      "ty": 6,
      "x": 453,
      "y": 681,
      "ta": "#strategyButton"
    },
    {
      "t": 47901,
      "e": 44937,
      "ty": 2,
      "x": 435,
      "y": 675
    },
    {
      "t": 47980,
      "e": 45016,
      "ty": 3,
      "x": 429,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 47980,
      "e": 45016,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Must in the line for 12 and Duration less than four"
    },
    {
      "t": 47981,
      "e": 45017,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47982,
      "e": 45018,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 48000,
      "e": 45036,
      "ty": 2,
      "x": 429,
      "y": 673
    },
    {
      "t": 48000,
      "e": 45036,
      "ty": 41,
      "x": 49373,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 48059,
      "e": 45095,
      "ty": 4,
      "x": 49373,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 48069,
      "e": 45105,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 48070,
      "e": 45106,
      "ty": 5,
      "x": 429,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 48078,
      "e": 45114,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 48200,
      "e": 45236,
      "ty": 2,
      "x": 416,
      "y": 675
    },
    {
      "t": 48251,
      "e": 45287,
      "ty": 41,
      "x": 12948,
      "y": 38390,
      "ta": "html > body"
    },
    {
      "t": 48300,
      "e": 45336,
      "ty": 2,
      "x": 374,
      "y": 715
    },
    {
      "t": 48400,
      "e": 45436,
      "ty": 2,
      "x": 345,
      "y": 778
    },
    {
      "t": 48500,
      "e": 45536,
      "ty": 2,
      "x": 61,
      "y": 960
    },
    {
      "t": 48501,
      "e": 45537,
      "ty": 41,
      "x": 1825,
      "y": 52738,
      "ta": "html > body"
    },
    {
      "t": 48600,
      "e": 45636,
      "ty": 2,
      "x": 0,
      "y": 1215
    },
    {
      "t": 48800,
      "e": 45836,
      "ty": 2,
      "x": 0,
      "y": 1212
    },
    {
      "t": 48901,
      "e": 45937,
      "ty": 2,
      "x": 0,
      "y": 1210
    },
    {
      "t": 49074,
      "e": 46110,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 49100,
      "e": 46136,
      "ty": 2,
      "x": 0,
      "y": 1209
    },
    {
      "t": 49700,
      "e": 46736,
      "ty": 2,
      "x": 0,
      "y": 1205
    },
    {
      "t": 49750,
      "e": 46786,
      "ty": 41,
      "x": 12053,
      "y": 55785,
      "ta": "html > body"
    },
    {
      "t": 49801,
      "e": 46837,
      "ty": 2,
      "x": 717,
      "y": 752
    },
    {
      "t": 49900,
      "e": 46936,
      "ty": 2,
      "x": 738,
      "y": 683
    },
    {
      "t": 50001,
      "e": 47037,
      "ty": 2,
      "x": 711,
      "y": 711
    },
    {
      "t": 50001,
      "e": 47037,
      "ty": 41,
      "x": 24209,
      "y": 38944,
      "ta": "html > body"
    },
    {
      "t": 50101,
      "e": 47137,
      "ty": 2,
      "x": 1044,
      "y": 588
    },
    {
      "t": 50200,
      "e": 47236,
      "ty": 2,
      "x": 1039,
      "y": 578
    },
    {
      "t": 50228,
      "e": 47264,
      "ty": 6,
      "x": 1036,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50250,
      "e": 47286,
      "ty": 41,
      "x": 49097,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50300,
      "e": 47336,
      "ty": 2,
      "x": 1032,
      "y": 564
    },
    {
      "t": 50364,
      "e": 47400,
      "ty": 3,
      "x": 1030,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50365,
      "e": 47401,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50400,
      "e": 47436,
      "ty": 2,
      "x": 1030,
      "y": 564
    },
    {
      "t": 50467,
      "e": 47503,
      "ty": 4,
      "x": 48015,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50468,
      "e": 47504,
      "ty": 5,
      "x": 1030,
      "y": 564,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50501,
      "e": 47537,
      "ty": 41,
      "x": 48015,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51384,
      "e": 48420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 51384,
      "e": 48420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51447,
      "e": 48483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 51656,
      "e": 48692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 51656,
      "e": 48692,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51759,
      "e": 48795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 52251,
      "e": 49287,
      "ty": 41,
      "x": 50611,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52265,
      "e": 49301,
      "ty": 7,
      "x": 1046,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 52301,
      "e": 49337,
      "ty": 2,
      "x": 1060,
      "y": 586
    },
    {
      "t": 52400,
      "e": 49436,
      "ty": 2,
      "x": 1079,
      "y": 616
    },
    {
      "t": 52500,
      "e": 49536,
      "ty": 2,
      "x": 1088,
      "y": 624
    },
    {
      "t": 52500,
      "e": 49536,
      "ty": 41,
      "x": 60560,
      "y": 53832,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 52583,
      "e": 49619,
      "ty": 6,
      "x": 1096,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52600,
      "e": 49636,
      "ty": 2,
      "x": 1097,
      "y": 650
    },
    {
      "t": 52700,
      "e": 49736,
      "ty": 2,
      "x": 1096,
      "y": 661
    },
    {
      "t": 52750,
      "e": 49786,
      "ty": 41,
      "x": 62290,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52781,
      "e": 49817,
      "ty": 3,
      "x": 1096,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52875,
      "e": 49911,
      "ty": 4,
      "x": 62290,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52876,
      "e": 49912,
      "ty": 5,
      "x": 1096,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53000,
      "e": 50036,
      "ty": 2,
      "x": 1093,
      "y": 661
    },
    {
      "t": 53001,
      "e": 50037,
      "ty": 41,
      "x": 61641,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53100,
      "e": 50136,
      "ty": 2,
      "x": 1080,
      "y": 656
    },
    {
      "t": 53200,
      "e": 50236,
      "ty": 2,
      "x": 1068,
      "y": 651
    },
    {
      "t": 53220,
      "e": 50256,
      "ty": 3,
      "x": 1068,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53222,
      "e": 50258,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 53222,
      "e": 50258,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53223,
      "e": 50259,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53251,
      "e": 50287,
      "ty": 41,
      "x": 56234,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53323,
      "e": 50359,
      "ty": 4,
      "x": 56234,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53323,
      "e": 50359,
      "ty": 5,
      "x": 1068,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53616,
      "e": 50652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 53736,
      "e": 50772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 54008,
      "e": 51044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 54008,
      "e": 51044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54080,
      "e": 51116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 54096,
      "e": 51132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 54176,
      "e": 51212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 54376,
      "e": 51412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 54376,
      "e": 51412,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54447,
      "e": 51483,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ch"
    },
    {
      "t": 54567,
      "e": 51603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 54568,
      "e": 51604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54638,
      "e": 51674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 54767,
      "e": 51803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 54768,
      "e": 51804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54855,
      "e": 51891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 54976,
      "e": 52012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 54976,
      "e": 52012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55086,
      "e": 52122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 55318,
      "e": 52354,
      "ty": 7,
      "x": 1096,
      "y": 631,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55401,
      "e": 52437,
      "ty": 2,
      "x": 1117,
      "y": 607
    },
    {
      "t": 55501,
      "e": 52537,
      "ty": 2,
      "x": 1156,
      "y": 616
    },
    {
      "t": 55501,
      "e": 52537,
      "ty": 41,
      "x": 39534,
      "y": 33681,
      "ta": "html > body"
    },
    {
      "t": 55600,
      "e": 52636,
      "ty": 2,
      "x": 1165,
      "y": 620
    },
    {
      "t": 55701,
      "e": 52737,
      "ty": 2,
      "x": 1104,
      "y": 672
    },
    {
      "t": 55751,
      "e": 52787,
      "ty": 41,
      "x": 54936,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 55769,
      "e": 52805,
      "ty": 6,
      "x": 1010,
      "y": 681,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 55801,
      "e": 52837,
      "ty": 2,
      "x": 988,
      "y": 688
    },
    {
      "t": 55901,
      "e": 52937,
      "ty": 2,
      "x": 956,
      "y": 696
    },
    {
      "t": 56001,
      "e": 53037,
      "ty": 2,
      "x": 956,
      "y": 700
    },
    {
      "t": 56001,
      "e": 53037,
      "ty": 41,
      "x": 30963,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56101,
      "e": 53137,
      "ty": 2,
      "x": 968,
      "y": 692
    },
    {
      "t": 56188,
      "e": 53224,
      "ty": 3,
      "x": 969,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56190,
      "e": 53225,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 56192,
      "e": 53227,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56192,
      "e": 53227,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56200,
      "e": 53235,
      "ty": 2,
      "x": 969,
      "y": 692
    },
    {
      "t": 56251,
      "e": 53286,
      "ty": 41,
      "x": 37663,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56275,
      "e": 53310,
      "ty": 4,
      "x": 37663,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56275,
      "e": 53310,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56275,
      "e": 53310,
      "ty": 5,
      "x": 969,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56276,
      "e": 53311,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 56901,
      "e": 53936,
      "ty": 2,
      "x": 969,
      "y": 690
    },
    {
      "t": 56999,
      "e": 54034,
      "ty": 2,
      "x": 955,
      "y": 685
    },
    {
      "t": 57000,
      "e": 54035,
      "ty": 41,
      "x": 32612,
      "y": 37503,
      "ta": "html > body"
    },
    {
      "t": 57296,
      "e": 54331,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 58000,
      "e": 55035,
      "ty": 2,
      "x": 955,
      "y": 681
    },
    {
      "t": 58001,
      "e": 55036,
      "ty": 41,
      "x": 35865,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 58100,
      "e": 55135,
      "ty": 2,
      "x": 947,
      "y": 277
    },
    {
      "t": 58199,
      "e": 55234,
      "ty": 2,
      "x": 933,
      "y": 219
    },
    {
      "t": 58250,
      "e": 55285,
      "ty": 41,
      "x": 26005,
      "y": 17835,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 58299,
      "e": 55334,
      "ty": 2,
      "x": 927,
      "y": 245
    },
    {
      "t": 58399,
      "e": 55434,
      "ty": 2,
      "x": 904,
      "y": 262
    },
    {
      "t": 58499,
      "e": 55534,
      "ty": 2,
      "x": 878,
      "y": 252
    },
    {
      "t": 58500,
      "e": 55535,
      "ty": 41,
      "x": 13427,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 58700,
      "e": 55735,
      "ty": 2,
      "x": 878,
      "y": 255
    },
    {
      "t": 58750,
      "e": 55785,
      "ty": 41,
      "x": 44614,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 58800,
      "e": 55835,
      "ty": 2,
      "x": 883,
      "y": 268
    },
    {
      "t": 58900,
      "e": 55935,
      "ty": 2,
      "x": 885,
      "y": 295
    },
    {
      "t": 59000,
      "e": 56035,
      "ty": 2,
      "x": 883,
      "y": 304
    },
    {
      "t": 59000,
      "e": 56035,
      "ty": 41,
      "x": 19298,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 59100,
      "e": 56135,
      "ty": 2,
      "x": 877,
      "y": 305
    },
    {
      "t": 59200,
      "e": 56235,
      "ty": 2,
      "x": 873,
      "y": 306
    },
    {
      "t": 59250,
      "e": 56285,
      "ty": 41,
      "x": 17104,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 59291,
      "e": 56326,
      "ty": 3,
      "x": 876,
      "y": 290,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 59300,
      "e": 56335,
      "ty": 2,
      "x": 876,
      "y": 290
    },
    {
      "t": 59395,
      "e": 56430,
      "ty": 4,
      "x": 17104,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 59395,
      "e": 56430,
      "ty": 5,
      "x": 876,
      "y": 290,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 59395,
      "e": 56430,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 59397,
      "e": 56432,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 59500,
      "e": 56535,
      "ty": 2,
      "x": 876,
      "y": 296
    },
    {
      "t": 59500,
      "e": 56535,
      "ty": 41,
      "x": 17104,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 59600,
      "e": 56635,
      "ty": 2,
      "x": 900,
      "y": 379
    },
    {
      "t": 59703,
      "e": 56738,
      "ty": 2,
      "x": 892,
      "y": 371
    },
    {
      "t": 59753,
      "e": 56788,
      "ty": 41,
      "x": 12715,
      "y": 11373,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 59803,
      "e": 56838,
      "ty": 2,
      "x": 859,
      "y": 474
    },
    {
      "t": 59903,
      "e": 56938,
      "ty": 2,
      "x": 857,
      "y": 488
    },
    {
      "t": 60003,
      "e": 57038,
      "ty": 41,
      "x": 8443,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 60103,
      "e": 57138,
      "ty": 2,
      "x": 856,
      "y": 488
    },
    {
      "t": 60203,
      "e": 57238,
      "ty": 2,
      "x": 858,
      "y": 488
    },
    {
      "t": 60254,
      "e": 57289,
      "ty": 41,
      "x": 9155,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 60303,
      "e": 57338,
      "ty": 2,
      "x": 860,
      "y": 488
    },
    {
      "t": 60603,
      "e": 57638,
      "ty": 2,
      "x": 849,
      "y": 481
    },
    {
      "t": 60703,
      "e": 57738,
      "ty": 2,
      "x": 845,
      "y": 444
    },
    {
      "t": 60753,
      "e": 57788,
      "ty": 41,
      "x": 4883,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 60804,
      "e": 57839,
      "ty": 2,
      "x": 842,
      "y": 425
    },
    {
      "t": 61003,
      "e": 58038,
      "ty": 2,
      "x": 847,
      "y": 436
    },
    {
      "t": 61004,
      "e": 58039,
      "ty": 41,
      "x": 20430,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 61103,
      "e": 58138,
      "ty": 2,
      "x": 849,
      "y": 443
    },
    {
      "t": 61203,
      "e": 58238,
      "ty": 2,
      "x": 849,
      "y": 445
    },
    {
      "t": 61255,
      "e": 58239,
      "ty": 41,
      "x": 6070,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 61303,
      "e": 58287,
      "ty": 2,
      "x": 847,
      "y": 470
    },
    {
      "t": 61403,
      "e": 58387,
      "ty": 2,
      "x": 847,
      "y": 486
    },
    {
      "t": 61504,
      "e": 58488,
      "ty": 41,
      "x": 6070,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 61603,
      "e": 58587,
      "ty": 2,
      "x": 846,
      "y": 476
    },
    {
      "t": 61703,
      "e": 58687,
      "ty": 2,
      "x": 846,
      "y": 464
    },
    {
      "t": 61754,
      "e": 58738,
      "ty": 41,
      "x": 25979,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 61803,
      "e": 58787,
      "ty": 2,
      "x": 846,
      "y": 462
    },
    {
      "t": 61903,
      "e": 58887,
      "ty": 2,
      "x": 846,
      "y": 455
    },
    {
      "t": 62004,
      "e": 58988,
      "ty": 2,
      "x": 849,
      "y": 445
    },
    {
      "t": 62004,
      "e": 58988,
      "ty": 41,
      "x": 22028,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 62103,
      "e": 59087,
      "ty": 3,
      "x": 849,
      "y": 445,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 62104,
      "e": 59088,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 62198,
      "e": 59182,
      "ty": 4,
      "x": 22028,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 62198,
      "e": 59182,
      "ty": 5,
      "x": 849,
      "y": 445,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 62199,
      "e": 59183,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 62199,
      "e": 59183,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 62403,
      "e": 59387,
      "ty": 2,
      "x": 894,
      "y": 577
    },
    {
      "t": 62503,
      "e": 59487,
      "ty": 2,
      "x": 942,
      "y": 729
    },
    {
      "t": 62504,
      "e": 59488,
      "ty": 41,
      "x": 30263,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 62603,
      "e": 59587,
      "ty": 2,
      "x": 948,
      "y": 747
    },
    {
      "t": 62754,
      "e": 59738,
      "ty": 41,
      "x": 30040,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 63103,
      "e": 60087,
      "ty": 2,
      "x": 927,
      "y": 743
    },
    {
      "t": 63204,
      "e": 60188,
      "ty": 2,
      "x": 924,
      "y": 743
    },
    {
      "t": 63253,
      "e": 60237,
      "ty": 41,
      "x": 24344,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 63503,
      "e": 60487,
      "ty": 2,
      "x": 922,
      "y": 743
    },
    {
      "t": 63503,
      "e": 60487,
      "ty": 41,
      "x": 23869,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 63603,
      "e": 60587,
      "ty": 2,
      "x": 915,
      "y": 730
    },
    {
      "t": 63703,
      "e": 60687,
      "ty": 2,
      "x": 911,
      "y": 713
    },
    {
      "t": 63753,
      "e": 60737,
      "ty": 41,
      "x": 22572,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 63803,
      "e": 60787,
      "ty": 2,
      "x": 911,
      "y": 707
    },
    {
      "t": 64103,
      "e": 61087,
      "ty": 2,
      "x": 915,
      "y": 709
    },
    {
      "t": 64203,
      "e": 61187,
      "ty": 2,
      "x": 913,
      "y": 739
    },
    {
      "t": 64253,
      "e": 61237,
      "ty": 41,
      "x": 22984,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 64303,
      "e": 61287,
      "ty": 2,
      "x": 913,
      "y": 740
    },
    {
      "t": 64403,
      "e": 61387,
      "ty": 2,
      "x": 911,
      "y": 738
    },
    {
      "t": 64503,
      "e": 61487,
      "ty": 2,
      "x": 911,
      "y": 737
    },
    {
      "t": 64503,
      "e": 61487,
      "ty": 41,
      "x": 22482,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 64535,
      "e": 61519,
      "ty": 3,
      "x": 911,
      "y": 737,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 64536,
      "e": 61520,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 64653,
      "e": 61637,
      "ty": 4,
      "x": 22482,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 64654,
      "e": 61638,
      "ty": 5,
      "x": 911,
      "y": 737,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 64655,
      "e": 61639,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 64655,
      "e": 61639,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 65003,
      "e": 61987,
      "ty": 2,
      "x": 914,
      "y": 744
    },
    {
      "t": 65003,
      "e": 61987,
      "ty": 41,
      "x": 21971,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 65104,
      "e": 62088,
      "ty": 2,
      "x": 915,
      "y": 753
    },
    {
      "t": 65203,
      "e": 62187,
      "ty": 2,
      "x": 917,
      "y": 759
    },
    {
      "t": 65253,
      "e": 62237,
      "ty": 41,
      "x": 39880,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 65303,
      "e": 62287,
      "ty": 2,
      "x": 917,
      "y": 769
    },
    {
      "t": 65403,
      "e": 62387,
      "ty": 2,
      "x": 915,
      "y": 780
    },
    {
      "t": 65504,
      "e": 62488,
      "ty": 2,
      "x": 913,
      "y": 793
    },
    {
      "t": 65505,
      "e": 62489,
      "ty": 41,
      "x": 51268,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 65603,
      "e": 62587,
      "ty": 2,
      "x": 913,
      "y": 795
    },
    {
      "t": 65703,
      "e": 62687,
      "ty": 2,
      "x": 910,
      "y": 795
    },
    {
      "t": 65753,
      "e": 62737,
      "ty": 41,
      "x": 49028,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 65803,
      "e": 62787,
      "ty": 2,
      "x": 909,
      "y": 773
    },
    {
      "t": 65904,
      "e": 62888,
      "ty": 2,
      "x": 907,
      "y": 709
    },
    {
      "t": 66003,
      "e": 62987,
      "ty": 2,
      "x": 905,
      "y": 700
    },
    {
      "t": 66003,
      "e": 62987,
      "ty": 41,
      "x": 21060,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 66103,
      "e": 63087,
      "ty": 2,
      "x": 906,
      "y": 690
    },
    {
      "t": 66203,
      "e": 63187,
      "ty": 2,
      "x": 925,
      "y": 720
    },
    {
      "t": 66254,
      "e": 63238,
      "ty": 41,
      "x": 25996,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 66303,
      "e": 63287,
      "ty": 2,
      "x": 925,
      "y": 738
    },
    {
      "t": 66503,
      "e": 63487,
      "ty": 2,
      "x": 926,
      "y": 744
    },
    {
      "t": 66503,
      "e": 63487,
      "ty": 41,
      "x": 24818,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 66603,
      "e": 63587,
      "ty": 2,
      "x": 926,
      "y": 761
    },
    {
      "t": 66703,
      "e": 63687,
      "ty": 2,
      "x": 926,
      "y": 765
    },
    {
      "t": 66753,
      "e": 63737,
      "ty": 41,
      "x": 43635,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 67203,
      "e": 64187,
      "ty": 2,
      "x": 924,
      "y": 765
    },
    {
      "t": 67253,
      "e": 64237,
      "ty": 41,
      "x": 41549,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 67303,
      "e": 64287,
      "ty": 2,
      "x": 921,
      "y": 765
    },
    {
      "t": 67463,
      "e": 64447,
      "ty": 3,
      "x": 921,
      "y": 765,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 67464,
      "e": 64448,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 67559,
      "e": 64543,
      "ty": 4,
      "x": 41549,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 67559,
      "e": 64543,
      "ty": 5,
      "x": 921,
      "y": 765,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 67560,
      "e": 64544,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 67562,
      "e": 64546,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf",
      "v": "Natural Sciences"
    },
    {
      "t": 67703,
      "e": 64687,
      "ty": 2,
      "x": 932,
      "y": 794
    },
    {
      "t": 67754,
      "e": 64738,
      "ty": 41,
      "x": 26480,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 67803,
      "e": 64787,
      "ty": 2,
      "x": 934,
      "y": 802
    },
    {
      "t": 68004,
      "e": 64988,
      "ty": 41,
      "x": 26717,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 68104,
      "e": 65088,
      "ty": 2,
      "x": 930,
      "y": 803
    },
    {
      "t": 68204,
      "e": 65188,
      "ty": 2,
      "x": 927,
      "y": 804
    },
    {
      "t": 68253,
      "e": 65237,
      "ty": 41,
      "x": 24818,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 68303,
      "e": 65287,
      "ty": 2,
      "x": 924,
      "y": 804
    },
    {
      "t": 68504,
      "e": 65488,
      "ty": 41,
      "x": 24344,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 69003,
      "e": 65987,
      "ty": 2,
      "x": 929,
      "y": 814
    },
    {
      "t": 69003,
      "e": 65987,
      "ty": 41,
      "x": 63496,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 69104,
      "e": 66088,
      "ty": 2,
      "x": 936,
      "y": 827
    },
    {
      "t": 69204,
      "e": 66188,
      "ty": 2,
      "x": 936,
      "y": 829
    },
    {
      "t": 69253,
      "e": 66237,
      "ty": 41,
      "x": 27192,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 69303,
      "e": 66287,
      "ty": 2,
      "x": 932,
      "y": 843
    },
    {
      "t": 69403,
      "e": 66387,
      "ty": 2,
      "x": 928,
      "y": 845
    },
    {
      "t": 69503,
      "e": 66487,
      "ty": 41,
      "x": 25293,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 69603,
      "e": 66587,
      "ty": 2,
      "x": 928,
      "y": 848
    },
    {
      "t": 69703,
      "e": 66687,
      "ty": 2,
      "x": 927,
      "y": 859
    },
    {
      "t": 69753,
      "e": 66737,
      "ty": 41,
      "x": 25056,
      "y": 52158,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 69903,
      "e": 66887,
      "ty": 2,
      "x": 927,
      "y": 867
    },
    {
      "t": 70003,
      "e": 66987,
      "ty": 2,
      "x": 926,
      "y": 874
    },
    {
      "t": 70004,
      "e": 66988,
      "ty": 41,
      "x": 24818,
      "y": 53279,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 70104,
      "e": 67088,
      "ty": 2,
      "x": 918,
      "y": 909
    },
    {
      "t": 70204,
      "e": 67188,
      "ty": 2,
      "x": 916,
      "y": 915
    },
    {
      "t": 70253,
      "e": 67237,
      "ty": 41,
      "x": 22208,
      "y": 22685,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 70304,
      "e": 67288,
      "ty": 2,
      "x": 912,
      "y": 922
    },
    {
      "t": 70403,
      "e": 67387,
      "ty": 2,
      "x": 900,
      "y": 920
    },
    {
      "t": 70503,
      "e": 67487,
      "ty": 2,
      "x": 891,
      "y": 909
    },
    {
      "t": 70503,
      "e": 67487,
      "ty": 41,
      "x": 16512,
      "y": 17139,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 70603,
      "e": 67587,
      "ty": 2,
      "x": 884,
      "y": 797
    },
    {
      "t": 70703,
      "e": 67687,
      "ty": 2,
      "x": 884,
      "y": 767
    },
    {
      "t": 70754,
      "e": 67738,
      "ty": 41,
      "x": 26110,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 70804,
      "e": 67788,
      "ty": 2,
      "x": 886,
      "y": 756
    },
    {
      "t": 70903,
      "e": 67887,
      "ty": 2,
      "x": 891,
      "y": 741
    },
    {
      "t": 71004,
      "e": 67988,
      "ty": 2,
      "x": 891,
      "y": 739
    },
    {
      "t": 71004,
      "e": 67988,
      "ty": 41,
      "x": 17463,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 71104,
      "e": 68088,
      "ty": 2,
      "x": 891,
      "y": 738
    },
    {
      "t": 71204,
      "e": 68188,
      "ty": 2,
      "x": 892,
      "y": 732
    },
    {
      "t": 71254,
      "e": 68238,
      "ty": 41,
      "x": 17714,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 71255,
      "e": 68239,
      "ty": 3,
      "x": 892,
      "y": 731,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 71256,
      "e": 68240,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 71303,
      "e": 68287,
      "ty": 2,
      "x": 892,
      "y": 731
    },
    {
      "t": 71374,
      "e": 68358,
      "ty": 4,
      "x": 17714,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 71374,
      "e": 68358,
      "ty": 5,
      "x": 892,
      "y": 731,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 71374,
      "e": 68358,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 71375,
      "e": 68359,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 71503,
      "e": 68487,
      "ty": 2,
      "x": 898,
      "y": 841
    },
    {
      "t": 71503,
      "e": 68487,
      "ty": 41,
      "x": 53953,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 71604,
      "e": 68588,
      "ty": 2,
      "x": 898,
      "y": 896
    },
    {
      "t": 71704,
      "e": 68688,
      "ty": 2,
      "x": 897,
      "y": 913
    },
    {
      "t": 71754,
      "e": 68689,
      "ty": 41,
      "x": 16037,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 71804,
      "e": 68739,
      "ty": 2,
      "x": 885,
      "y": 933
    },
    {
      "t": 71903,
      "e": 68838,
      "ty": 2,
      "x": 883,
      "y": 935
    },
    {
      "t": 72003,
      "e": 68938,
      "ty": 2,
      "x": 876,
      "y": 935
    },
    {
      "t": 72003,
      "e": 68938,
      "ty": 41,
      "x": 59612,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 72103,
      "e": 69038,
      "ty": 2,
      "x": 873,
      "y": 941
    },
    {
      "t": 72203,
      "e": 69138,
      "ty": 2,
      "x": 865,
      "y": 954
    },
    {
      "t": 72254,
      "e": 69189,
      "ty": 41,
      "x": 35251,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 72311,
      "e": 69246,
      "ty": 3,
      "x": 865,
      "y": 954,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 72312,
      "e": 69247,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 72406,
      "e": 69341,
      "ty": 4,
      "x": 35251,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 72407,
      "e": 69342,
      "ty": 5,
      "x": 865,
      "y": 954,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 72408,
      "e": 69343,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 72409,
      "e": 69344,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 72503,
      "e": 69438,
      "ty": 2,
      "x": 868,
      "y": 957
    },
    {
      "t": 72503,
      "e": 69438,
      "ty": 41,
      "x": 37677,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 72604,
      "e": 69539,
      "ty": 2,
      "x": 871,
      "y": 962
    },
    {
      "t": 72704,
      "e": 69639,
      "ty": 2,
      "x": 873,
      "y": 965
    },
    {
      "t": 72753,
      "e": 69688,
      "ty": 41,
      "x": 41722,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 72803,
      "e": 69738,
      "ty": 2,
      "x": 875,
      "y": 974
    },
    {
      "t": 72904,
      "e": 69839,
      "ty": 2,
      "x": 877,
      "y": 990
    },
    {
      "t": 73004,
      "e": 69939,
      "ty": 2,
      "x": 877,
      "y": 992
    },
    {
      "t": 73004,
      "e": 69939,
      "ty": 41,
      "x": 55173,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 73403,
      "e": 70338,
      "ty": 2,
      "x": 878,
      "y": 993
    },
    {
      "t": 73504,
      "e": 70439,
      "ty": 2,
      "x": 878,
      "y": 998
    },
    {
      "t": 73504,
      "e": 70439,
      "ty": 41,
      "x": 56166,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 73586,
      "e": 70521,
      "ty": 6,
      "x": 877,
      "y": 1006,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 73603,
      "e": 70538,
      "ty": 2,
      "x": 875,
      "y": 1011
    },
    {
      "t": 73703,
      "e": 70638,
      "ty": 2,
      "x": 875,
      "y": 1031
    },
    {
      "t": 73753,
      "e": 70688,
      "ty": 41,
      "x": 24521,
      "y": 61563,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 73759,
      "e": 70694,
      "ty": 3,
      "x": 877,
      "y": 1036,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 73760,
      "e": 70695,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 73761,
      "e": 70696,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 73803,
      "e": 70738,
      "ty": 2,
      "x": 877,
      "y": 1036
    },
    {
      "t": 73838,
      "e": 70773,
      "ty": 4,
      "x": 25036,
      "y": 63549,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 73838,
      "e": 70773,
      "ty": 5,
      "x": 878,
      "y": 1037,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 73840,
      "e": 70775,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 73841,
      "e": 70776,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 73842,
      "e": 70777,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 73904,
      "e": 70839,
      "ty": 2,
      "x": 878,
      "y": 1037
    },
    {
      "t": 74003,
      "e": 70938,
      "ty": 41,
      "x": 29960,
      "y": 57003,
      "ta": "html > body"
    },
    {
      "t": 74103,
      "e": 71038,
      "ty": 2,
      "x": 784,
      "y": 858
    },
    {
      "t": 74203,
      "e": 71138,
      "ty": 2,
      "x": 556,
      "y": 513
    },
    {
      "t": 74253,
      "e": 71188,
      "ty": 41,
      "x": 18561,
      "y": 26590,
      "ta": "html > body"
    },
    {
      "t": 74303,
      "e": 71238,
      "ty": 2,
      "x": 547,
      "y": 487
    },
    {
      "t": 74404,
      "e": 71339,
      "ty": 2,
      "x": 542,
      "y": 486
    },
    {
      "t": 74503,
      "e": 71438,
      "ty": 2,
      "x": 538,
      "y": 484
    },
    {
      "t": 74503,
      "e": 71438,
      "ty": 41,
      "x": 18251,
      "y": 26369,
      "ta": "html > body"
    },
    {
      "t": 75185,
      "e": 72120,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 75703,
      "e": 72638,
      "ty": 2,
      "x": 537,
      "y": 484
    },
    {
      "t": 75754,
      "e": 72689,
      "ty": 41,
      "x": 20935,
      "y": 58714,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 75804,
      "e": 72739,
      "ty": 2,
      "x": 1012,
      "y": 768
    },
    {
      "t": 75904,
      "e": 72839,
      "ty": 2,
      "x": 1157,
      "y": 835
    },
    {
      "t": 76004,
      "e": 72939,
      "ty": 2,
      "x": 1060,
      "y": 934
    },
    {
      "t": 76005,
      "e": 72940,
      "ty": 41,
      "x": 37711,
      "y": 55931,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76103,
      "e": 73038,
      "ty": 2,
      "x": 1117,
      "y": 1004
    },
    {
      "t": 76203,
      "e": 73138,
      "ty": 2,
      "x": 1124,
      "y": 1011
    },
    {
      "t": 76254,
      "e": 73189,
      "ty": 41,
      "x": 40860,
      "y": 61471,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76304,
      "e": 73239,
      "ty": 2,
      "x": 1124,
      "y": 1015
    },
    {
      "t": 76404,
      "e": 73339,
      "ty": 2,
      "x": 1124,
      "y": 1016
    },
    {
      "t": 76503,
      "e": 73438,
      "ty": 2,
      "x": 1065,
      "y": 1082
    },
    {
      "t": 76505,
      "e": 73440,
      "ty": 41,
      "x": 36400,
      "y": 59496,
      "ta": "> div.masterdiv"
    },
    {
      "t": 76522,
      "e": 73457,
      "ty": 6,
      "x": 1013,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 76603,
      "e": 73538,
      "ty": 2,
      "x": 950,
      "y": 1083
    },
    {
      "t": 76703,
      "e": 73638,
      "ty": 2,
      "x": 950,
      "y": 1085
    },
    {
      "t": 76754,
      "e": 73689,
      "ty": 41,
      "x": 22118,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 76760,
      "e": 73695,
      "ty": 3,
      "x": 950,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 76761,
      "e": 73696,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 76845,
      "e": 73780,
      "ty": 4,
      "x": 22118,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 76847,
      "e": 73782,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 76847,
      "e": 73782,
      "ty": 5,
      "x": 950,
      "y": 1085,
      "ta": "#start"
    },
    {
      "t": 76847,
      "e": 73782,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 77003,
      "e": 73938,
      "ty": 2,
      "x": 947,
      "y": 1071
    },
    {
      "t": 77004,
      "e": 73939,
      "ty": 41,
      "x": 32337,
      "y": 58887,
      "ta": "html > body"
    },
    {
      "t": 77103,
      "e": 74038,
      "ty": 2,
      "x": 1057,
      "y": 731
    },
    {
      "t": 77204,
      "e": 74139,
      "ty": 2,
      "x": 1132,
      "y": 603
    },
    {
      "t": 77255,
      "e": 74140,
      "ty": 41,
      "x": 38708,
      "y": 32961,
      "ta": "html > body"
    },
    {
      "t": 77890,
      "e": 74775,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 79837,
      "e": 76722,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 57586, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 57589, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 3540, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 62215, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 14468, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"ECHO\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 77689, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 19794, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 98574, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 18393, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 117968, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 26807, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 145983, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-03 PM-02 PM-12 PM-O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:956,y:1017,t:1527008985072};\\\", \\\"{x:955,y:1010,t:1527008985086};\\\", \\\"{x:962,y:989,t:1527008985103};\\\", \\\"{x:973,y:973,t:1527008985120};\\\", \\\"{x:987,y:969,t:1527008985136};\\\", \\\"{x:1017,y:979,t:1527008985153};\\\", \\\"{x:1095,y:1031,t:1527008985170};\\\", \\\"{x:1232,y:1109,t:1527008985187};\\\", \\\"{x:1416,y:1177,t:1527008985203};\\\", \\\"{x:1657,y:1215,t:1527008985220};\\\", \\\"{x:1880,y:1215,t:1527008985237};\\\", \\\"{x:1919,y:1215,t:1527008985254};\\\", \\\"{x:1919,y:1186,t:1527008985271};\\\", \\\"{x:1919,y:1172,t:1527008985288};\\\", \\\"{x:1919,y:1154,t:1527008985304};\\\", \\\"{x:1916,y:1133,t:1527008985321};\\\", \\\"{x:1899,y:1108,t:1527008985338};\\\", \\\"{x:1862,y:1073,t:1527008985354};\\\", \\\"{x:1801,y:1033,t:1527008985371};\\\", \\\"{x:1708,y:996,t:1527008985388};\\\", \\\"{x:1594,y:965,t:1527008985405};\\\", \\\"{x:1476,y:953,t:1527008985421};\\\", \\\"{x:1375,y:949,t:1527008985439};\\\", \\\"{x:1308,y:947,t:1527008985454};\\\", \\\"{x:1273,y:947,t:1527008985471};\\\", \\\"{x:1274,y:947,t:1527008985648};\\\", \\\"{x:1278,y:947,t:1527008985655};\\\", \\\"{x:1284,y:949,t:1527008985672};\\\", \\\"{x:1330,y:963,t:1527008985688};\\\", \\\"{x:1378,y:969,t:1527008985704};\\\", \\\"{x:1433,y:975,t:1527008985722};\\\", \\\"{x:1476,y:983,t:1527008985738};\\\", \\\"{x:1505,y:987,t:1527008985754};\\\", \\\"{x:1520,y:990,t:1527008985771};\\\", \\\"{x:1522,y:991,t:1527008985787};\\\", \\\"{x:1523,y:991,t:1527008985806};\\\", \\\"{x:1524,y:992,t:1527008985821};\\\", \\\"{x:1525,y:993,t:1527008985837};\\\", \\\"{x:1527,y:993,t:1527008986056};\\\", \\\"{x:1531,y:993,t:1527008986070};\\\", \\\"{x:1550,y:993,t:1527008986088};\\\", \\\"{x:1557,y:993,t:1527008986103};\\\", \\\"{x:1561,y:993,t:1527008986120};\\\", \\\"{x:1564,y:991,t:1527008986408};\\\", \\\"{x:1566,y:991,t:1527008986420};\\\", \\\"{x:1572,y:987,t:1527008986438};\\\", \\\"{x:1574,y:987,t:1527008986453};\\\", \\\"{x:1577,y:986,t:1527008986471};\\\", \\\"{x:1578,y:986,t:1527008986496};\\\", \\\"{x:1581,y:984,t:1527008986503};\\\", \\\"{x:1583,y:983,t:1527008986520};\\\", \\\"{x:1585,y:982,t:1527008986544};\\\", \\\"{x:1586,y:982,t:1527008986568};\\\", \\\"{x:1586,y:981,t:1527008986576};\\\", \\\"{x:1586,y:980,t:1527008986592};\\\", \\\"{x:1586,y:979,t:1527008986603};\\\", \\\"{x:1586,y:978,t:1527008986620};\\\", \\\"{x:1586,y:977,t:1527008986637};\\\", \\\"{x:1586,y:976,t:1527008986653};\\\", \\\"{x:1586,y:975,t:1527008986680};\\\", \\\"{x:1584,y:974,t:1527008986728};\\\", \\\"{x:1584,y:973,t:1527008986738};\\\", \\\"{x:1583,y:973,t:1527008986753};\\\", \\\"{x:1582,y:972,t:1527008986770};\\\", \\\"{x:1581,y:971,t:1527008986787};\\\", \\\"{x:1580,y:971,t:1527008986824};\\\", \\\"{x:1578,y:971,t:1527008986837};\\\", \\\"{x:1574,y:971,t:1527008986853};\\\", \\\"{x:1564,y:971,t:1527008986870};\\\", \\\"{x:1547,y:973,t:1527008986886};\\\", \\\"{x:1516,y:977,t:1527008986904};\\\", \\\"{x:1501,y:982,t:1527008986920};\\\", \\\"{x:1486,y:984,t:1527008986936};\\\", \\\"{x:1481,y:985,t:1527008986954};\\\", \\\"{x:1478,y:985,t:1527008986970};\\\", \\\"{x:1477,y:985,t:1527008986987};\\\", \\\"{x:1475,y:985,t:1527008988152};\\\", \\\"{x:1471,y:985,t:1527008988159};\\\", \\\"{x:1467,y:985,t:1527008988169};\\\", \\\"{x:1454,y:987,t:1527008988185};\\\", \\\"{x:1447,y:987,t:1527008988202};\\\", \\\"{x:1439,y:988,t:1527008988220};\\\", \\\"{x:1430,y:991,t:1527008988236};\\\", \\\"{x:1426,y:992,t:1527008988252};\\\", \\\"{x:1423,y:993,t:1527008988270};\\\", \\\"{x:1422,y:993,t:1527008988328};\\\", \\\"{x:1418,y:993,t:1527008988343};\\\", \\\"{x:1414,y:993,t:1527008988352};\\\", \\\"{x:1406,y:991,t:1527008988370};\\\", \\\"{x:1399,y:991,t:1527008988385};\\\", \\\"{x:1392,y:990,t:1527008988402};\\\", \\\"{x:1385,y:990,t:1527008988419};\\\", \\\"{x:1378,y:990,t:1527008988436};\\\", \\\"{x:1376,y:990,t:1527008988452};\\\", \\\"{x:1375,y:990,t:1527008988591};\\\", \\\"{x:1374,y:990,t:1527008988624};\\\", \\\"{x:1372,y:989,t:1527008988639};\\\", \\\"{x:1372,y:988,t:1527008988655};\\\", \\\"{x:1371,y:988,t:1527008988668};\\\", \\\"{x:1369,y:988,t:1527008988685};\\\", \\\"{x:1368,y:988,t:1527008988702};\\\", \\\"{x:1365,y:987,t:1527008988718};\\\", \\\"{x:1358,y:987,t:1527008988736};\\\", \\\"{x:1351,y:986,t:1527008988752};\\\", \\\"{x:1344,y:984,t:1527008988769};\\\", \\\"{x:1336,y:980,t:1527008988785};\\\", \\\"{x:1333,y:978,t:1527008988803};\\\", \\\"{x:1329,y:976,t:1527008988818};\\\", \\\"{x:1326,y:973,t:1527008988836};\\\", \\\"{x:1323,y:970,t:1527008988852};\\\", \\\"{x:1322,y:968,t:1527008988868};\\\", \\\"{x:1319,y:966,t:1527008988885};\\\", \\\"{x:1317,y:965,t:1527008988902};\\\", \\\"{x:1315,y:964,t:1527008988919};\\\", \\\"{x:1313,y:964,t:1527008988935};\\\", \\\"{x:1312,y:964,t:1527008988951};\\\", \\\"{x:1311,y:964,t:1527008988968};\\\", \\\"{x:1309,y:964,t:1527008988985};\\\", \\\"{x:1305,y:964,t:1527008989001};\\\", \\\"{x:1303,y:965,t:1527008989019};\\\", \\\"{x:1298,y:966,t:1527008989035};\\\", \\\"{x:1291,y:966,t:1527008989051};\\\", \\\"{x:1288,y:966,t:1527008989068};\\\", \\\"{x:1287,y:966,t:1527008989085};\\\", \\\"{x:1285,y:967,t:1527008989175};\\\", \\\"{x:1284,y:967,t:1527008989256};\\\", \\\"{x:1282,y:967,t:1527008989288};\\\", \\\"{x:1281,y:967,t:1527008989360};\\\", \\\"{x:1279,y:967,t:1527008989376};\\\", \\\"{x:1278,y:966,t:1527008989400};\\\", \\\"{x:1277,y:966,t:1527008989408};\\\", \\\"{x:1277,y:965,t:1527008989424};\\\", \\\"{x:1276,y:965,t:1527008989440};\\\", \\\"{x:1275,y:963,t:1527008989452};\\\", \\\"{x:1274,y:961,t:1527008989469};\\\", \\\"{x:1274,y:957,t:1527008989485};\\\", \\\"{x:1274,y:949,t:1527008989502};\\\", \\\"{x:1274,y:934,t:1527008989518};\\\", \\\"{x:1274,y:919,t:1527008989534};\\\", \\\"{x:1271,y:890,t:1527008989551};\\\", \\\"{x:1268,y:870,t:1527008989569};\\\", \\\"{x:1263,y:847,t:1527008989584};\\\", \\\"{x:1258,y:819,t:1527008989601};\\\", \\\"{x:1247,y:780,t:1527008989618};\\\", \\\"{x:1237,y:744,t:1527008989635};\\\", \\\"{x:1232,y:720,t:1527008989652};\\\", \\\"{x:1227,y:706,t:1527008989669};\\\", \\\"{x:1227,y:697,t:1527008989684};\\\", \\\"{x:1227,y:694,t:1527008989701};\\\", \\\"{x:1227,y:693,t:1527008989718};\\\", \\\"{x:1227,y:692,t:1527008989735};\\\", \\\"{x:1227,y:690,t:1527008989752};\\\", \\\"{x:1226,y:684,t:1527008989767};\\\", \\\"{x:1223,y:672,t:1527008989785};\\\", \\\"{x:1222,y:662,t:1527008989801};\\\", \\\"{x:1222,y:654,t:1527008989818};\\\", \\\"{x:1222,y:648,t:1527008989834};\\\", \\\"{x:1224,y:638,t:1527008989851};\\\", \\\"{x:1231,y:626,t:1527008989868};\\\", \\\"{x:1234,y:623,t:1527008989885};\\\", \\\"{x:1236,y:618,t:1527008989902};\\\", \\\"{x:1237,y:615,t:1527008989918};\\\", \\\"{x:1238,y:613,t:1527008989934};\\\", \\\"{x:1239,y:612,t:1527008989952};\\\", \\\"{x:1239,y:611,t:1527008990160};\\\", \\\"{x:1240,y:611,t:1527008990167};\\\", \\\"{x:1241,y:612,t:1527008990208};\\\", \\\"{x:1241,y:613,t:1527008990223};\\\", \\\"{x:1243,y:614,t:1527008990248};\\\", \\\"{x:1243,y:615,t:1527008990263};\\\", \\\"{x:1243,y:616,t:1527008990280};\\\", \\\"{x:1243,y:617,t:1527008990320};\\\", \\\"{x:1244,y:618,t:1527008990335};\\\", \\\"{x:1245,y:620,t:1527008990351};\\\", \\\"{x:1245,y:621,t:1527008990368};\\\", \\\"{x:1245,y:623,t:1527008990384};\\\", \\\"{x:1246,y:623,t:1527008990400};\\\", \\\"{x:1246,y:624,t:1527008990417};\\\", \\\"{x:1246,y:625,t:1527008990441};\\\", \\\"{x:1246,y:626,t:1527008990467};\\\", \\\"{x:1246,y:627,t:1527008990484};\\\", \\\"{x:1246,y:628,t:1527008990501};\\\", \\\"{x:1246,y:629,t:1527008990518};\\\", \\\"{x:1246,y:630,t:1527008990535};\\\", \\\"{x:1247,y:630,t:1527008990568};\\\", \\\"{x:1241,y:630,t:1527008997872};\\\", \\\"{x:1236,y:628,t:1527008997880};\\\", \\\"{x:1229,y:624,t:1527008997894};\\\", \\\"{x:1219,y:620,t:1527008997911};\\\", \\\"{x:1216,y:618,t:1527008997929};\\\", \\\"{x:1214,y:618,t:1527008997944};\\\", \\\"{x:1212,y:617,t:1527008998040};\\\", \\\"{x:1206,y:617,t:1527008998048};\\\", \\\"{x:1195,y:618,t:1527008998062};\\\", \\\"{x:1166,y:623,t:1527008998078};\\\", \\\"{x:1130,y:628,t:1527008998095};\\\", \\\"{x:1082,y:632,t:1527008998111};\\\", \\\"{x:1026,y:632,t:1527008998128};\\\", \\\"{x:984,y:627,t:1527008998145};\\\", \\\"{x:951,y:618,t:1527008998162};\\\", \\\"{x:928,y:609,t:1527008998179};\\\", \\\"{x:918,y:602,t:1527008998194};\\\", \\\"{x:914,y:598,t:1527008998211};\\\", \\\"{x:910,y:591,t:1527008998225};\\\", \\\"{x:907,y:582,t:1527008998243};\\\", \\\"{x:905,y:574,t:1527008998259};\\\", \\\"{x:902,y:565,t:1527008998275};\\\", \\\"{x:896,y:546,t:1527008998299};\\\", \\\"{x:885,y:528,t:1527008998317};\\\", \\\"{x:872,y:516,t:1527008998332};\\\", \\\"{x:863,y:505,t:1527008998349};\\\", \\\"{x:859,y:500,t:1527008998366};\\\", \\\"{x:858,y:498,t:1527008998382};\\\", \\\"{x:857,y:498,t:1527008998399};\\\", \\\"{x:856,y:498,t:1527008998455};\\\", \\\"{x:855,y:498,t:1527008998466};\\\", \\\"{x:853,y:498,t:1527008998483};\\\", \\\"{x:849,y:500,t:1527008998499};\\\", \\\"{x:846,y:502,t:1527008998516};\\\", \\\"{x:843,y:505,t:1527008998532};\\\", \\\"{x:843,y:510,t:1527008998549};\\\", \\\"{x:841,y:514,t:1527008998566};\\\", \\\"{x:839,y:516,t:1527008998582};\\\", \\\"{x:838,y:519,t:1527008998598};\\\", \\\"{x:837,y:521,t:1527008998615};\\\", \\\"{x:837,y:523,t:1527008998633};\\\", \\\"{x:836,y:524,t:1527008998648};\\\", \\\"{x:836,y:526,t:1527008998671};\\\", \\\"{x:836,y:527,t:1527008998727};\\\", \\\"{x:836,y:529,t:1527008998751};\\\", \\\"{x:836,y:530,t:1527008998767};\\\", \\\"{x:836,y:534,t:1527008999087};\\\", \\\"{x:832,y:539,t:1527008999100};\\\", \\\"{x:820,y:550,t:1527008999116};\\\", \\\"{x:806,y:560,t:1527008999133};\\\", \\\"{x:789,y:575,t:1527008999150};\\\", \\\"{x:764,y:587,t:1527008999166};\\\", \\\"{x:733,y:603,t:1527008999182};\\\", \\\"{x:674,y:629,t:1527008999200};\\\", \\\"{x:630,y:647,t:1527008999216};\\\", \\\"{x:586,y:665,t:1527008999233};\\\", \\\"{x:557,y:680,t:1527008999250};\\\", \\\"{x:517,y:699,t:1527008999265};\\\", \\\"{x:479,y:715,t:1527008999283};\\\", \\\"{x:449,y:728,t:1527008999300};\\\", \\\"{x:434,y:733,t:1527008999316};\\\", \\\"{x:425,y:737,t:1527008999333};\\\", \\\"{x:422,y:739,t:1527008999350};\\\", \\\"{x:422,y:740,t:1527008999365};\\\", \\\"{x:423,y:740,t:1527008999439};\\\", \\\"{x:424,y:739,t:1527008999455};\\\", \\\"{x:425,y:737,t:1527008999467};\\\", \\\"{x:432,y:732,t:1527008999483};\\\", \\\"{x:445,y:726,t:1527008999500};\\\", \\\"{x:461,y:718,t:1527008999517};\\\", \\\"{x:474,y:713,t:1527008999532};\\\", \\\"{x:480,y:713,t:1527008999550};\\\", \\\"{x:484,y:713,t:1527008999567};\\\", \\\"{x:486,y:713,t:1527008999583};\\\", \\\"{x:488,y:714,t:1527008999600};\\\", \\\"{x:490,y:714,t:1527008999617};\\\", \\\"{x:491,y:714,t:1527008999700};\\\", \\\"{x:491,y:714,t:1527008999820};\\\", \\\"{x:492,y:715,t:1527008999919};\\\", \\\"{x:494,y:716,t:1527008999934};\\\", \\\"{x:495,y:716,t:1527008999950};\\\", \\\"{x:497,y:717,t:1527008999967};\\\", \\\"{x:501,y:718,t:1527008999983};\\\", \\\"{x:502,y:719,t:1527008999999};\\\", \\\"{x:504,y:719,t:1527009000017};\\\", \\\"{x:505,y:720,t:1527009000034};\\\", \\\"{x:506,y:721,t:1527009000050};\\\", \\\"{x:510,y:722,t:1527009000067};\\\", \\\"{x:534,y:725,t:1527009000084};\\\", \\\"{x:606,y:725,t:1527009000100};\\\", \\\"{x:714,y:725,t:1527009000117};\\\", \\\"{x:835,y:717,t:1527009000133};\\\", \\\"{x:946,y:701,t:1527009000150};\\\", \\\"{x:1043,y:687,t:1527009000166};\\\", \\\"{x:1151,y:668,t:1527009000184};\\\", \\\"{x:1186,y:661,t:1527009000200};\\\", \\\"{x:1199,y:656,t:1527009000217};\\\", \\\"{x:1200,y:656,t:1527009000234};\\\", \\\"{x:1201,y:655,t:1527009000377};\\\" ] }, { \\\"rt\\\": 41819, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 189063, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -D -D -D -11 AM-11 AM-F -U -01 PM-D -K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1204,y:655,t:1527009005495};\\\", \\\"{x:1210,y:655,t:1527009005505};\\\", \\\"{x:1258,y:655,t:1527009005521};\\\", \\\"{x:1321,y:646,t:1527009005538};\\\", \\\"{x:1386,y:646,t:1527009005555};\\\", \\\"{x:1453,y:645,t:1527009005571};\\\", \\\"{x:1510,y:641,t:1527009005588};\\\", \\\"{x:1543,y:639,t:1527009005605};\\\", \\\"{x:1561,y:639,t:1527009005620};\\\", \\\"{x:1567,y:637,t:1527009005638};\\\", \\\"{x:1567,y:640,t:1527009005783};\\\", \\\"{x:1563,y:645,t:1527009005791};\\\", \\\"{x:1559,y:651,t:1527009005805};\\\", \\\"{x:1552,y:664,t:1527009005821};\\\", \\\"{x:1543,y:676,t:1527009005838};\\\", \\\"{x:1526,y:696,t:1527009005855};\\\", \\\"{x:1516,y:707,t:1527009005871};\\\", \\\"{x:1507,y:716,t:1527009005888};\\\", \\\"{x:1493,y:728,t:1527009005905};\\\", \\\"{x:1477,y:739,t:1527009005922};\\\", \\\"{x:1458,y:751,t:1527009005938};\\\", \\\"{x:1441,y:762,t:1527009005955};\\\", \\\"{x:1415,y:788,t:1527009005972};\\\", \\\"{x:1398,y:812,t:1527009005988};\\\", \\\"{x:1392,y:835,t:1527009006005};\\\", \\\"{x:1391,y:855,t:1527009006022};\\\", \\\"{x:1391,y:870,t:1527009006038};\\\", \\\"{x:1394,y:884,t:1527009006056};\\\", \\\"{x:1398,y:890,t:1527009006071};\\\", \\\"{x:1401,y:897,t:1527009006088};\\\", \\\"{x:1402,y:899,t:1527009006105};\\\", \\\"{x:1404,y:901,t:1527009006122};\\\", \\\"{x:1405,y:903,t:1527009006138};\\\", \\\"{x:1406,y:903,t:1527009006159};\\\", \\\"{x:1407,y:904,t:1527009006183};\\\", \\\"{x:1409,y:904,t:1527009006232};\\\", \\\"{x:1411,y:905,t:1527009006247};\\\", \\\"{x:1414,y:905,t:1527009006263};\\\", \\\"{x:1417,y:907,t:1527009006272};\\\", \\\"{x:1427,y:908,t:1527009006288};\\\", \\\"{x:1436,y:908,t:1527009006305};\\\", \\\"{x:1447,y:909,t:1527009006322};\\\", \\\"{x:1454,y:909,t:1527009006339};\\\", \\\"{x:1456,y:909,t:1527009006356};\\\", \\\"{x:1459,y:909,t:1527009006372};\\\", \\\"{x:1460,y:909,t:1527009006389};\\\", \\\"{x:1461,y:909,t:1527009006414};\\\", \\\"{x:1462,y:909,t:1527009006439};\\\", \\\"{x:1464,y:909,t:1527009006455};\\\", \\\"{x:1468,y:909,t:1527009006472};\\\", \\\"{x:1480,y:904,t:1527009006489};\\\", \\\"{x:1495,y:893,t:1527009006505};\\\", \\\"{x:1513,y:879,t:1527009006522};\\\", \\\"{x:1536,y:860,t:1527009006539};\\\", \\\"{x:1558,y:842,t:1527009006555};\\\", \\\"{x:1577,y:821,t:1527009006572};\\\", \\\"{x:1594,y:786,t:1527009006589};\\\", \\\"{x:1614,y:739,t:1527009006605};\\\", \\\"{x:1629,y:675,t:1527009006622};\\\", \\\"{x:1669,y:570,t:1527009006639};\\\", \\\"{x:1680,y:544,t:1527009006655};\\\", \\\"{x:1685,y:530,t:1527009006673};\\\", \\\"{x:1686,y:527,t:1527009006689};\\\", \\\"{x:1686,y:526,t:1527009006705};\\\", \\\"{x:1686,y:524,t:1527009006722};\\\", \\\"{x:1686,y:520,t:1527009006739};\\\", \\\"{x:1683,y:513,t:1527009006756};\\\", \\\"{x:1677,y:501,t:1527009006772};\\\", \\\"{x:1669,y:487,t:1527009006789};\\\", \\\"{x:1663,y:474,t:1527009006806};\\\", \\\"{x:1657,y:464,t:1527009006822};\\\", \\\"{x:1647,y:446,t:1527009006838};\\\", \\\"{x:1640,y:441,t:1527009006855};\\\", \\\"{x:1631,y:439,t:1527009006872};\\\", \\\"{x:1626,y:438,t:1527009006889};\\\", \\\"{x:1623,y:437,t:1527009006906};\\\", \\\"{x:1622,y:437,t:1527009006922};\\\", \\\"{x:1621,y:437,t:1527009006940};\\\", \\\"{x:1620,y:437,t:1527009007088};\\\", \\\"{x:1619,y:436,t:1527009007096};\\\", \\\"{x:1617,y:433,t:1527009007107};\\\", \\\"{x:1613,y:430,t:1527009007122};\\\", \\\"{x:1612,y:428,t:1527009007139};\\\", \\\"{x:1608,y:426,t:1527009007157};\\\", \\\"{x:1607,y:426,t:1527009007173};\\\", \\\"{x:1606,y:426,t:1527009007199};\\\", \\\"{x:1605,y:425,t:1527009007223};\\\", \\\"{x:1604,y:424,t:1527009007255};\\\", \\\"{x:1603,y:424,t:1527009007295};\\\", \\\"{x:1606,y:424,t:1527009007376};\\\", \\\"{x:1607,y:425,t:1527009007391};\\\", \\\"{x:1608,y:425,t:1527009007407};\\\", \\\"{x:1609,y:425,t:1527009007424};\\\", \\\"{x:1611,y:426,t:1527009007439};\\\", \\\"{x:1612,y:427,t:1527009007575};\\\", \\\"{x:1612,y:428,t:1527009009575};\\\", \\\"{x:1612,y:430,t:1527009009591};\\\", \\\"{x:1611,y:430,t:1527009009609};\\\", \\\"{x:1610,y:432,t:1527009009624};\\\", \\\"{x:1609,y:432,t:1527009009641};\\\", \\\"{x:1608,y:433,t:1527009010160};\\\", \\\"{x:1608,y:436,t:1527009010175};\\\", \\\"{x:1606,y:438,t:1527009010191};\\\", \\\"{x:1605,y:439,t:1527009010208};\\\", \\\"{x:1605,y:437,t:1527009010911};\\\", \\\"{x:1605,y:434,t:1527009010925};\\\", \\\"{x:1605,y:432,t:1527009010942};\\\", \\\"{x:1605,y:429,t:1527009010959};\\\", \\\"{x:1605,y:427,t:1527009010975};\\\", \\\"{x:1607,y:427,t:1527009011007};\\\", \\\"{x:1609,y:427,t:1527009011015};\\\", \\\"{x:1610,y:427,t:1527009011025};\\\", \\\"{x:1612,y:427,t:1527009011042};\\\", \\\"{x:1614,y:427,t:1527009011059};\\\", \\\"{x:1615,y:427,t:1527009011075};\\\", \\\"{x:1617,y:428,t:1527009011092};\\\", \\\"{x:1616,y:428,t:1527009011544};\\\", \\\"{x:1615,y:427,t:1527009011568};\\\", \\\"{x:1614,y:427,t:1527009011576};\\\", \\\"{x:1613,y:427,t:1527009011593};\\\", \\\"{x:1613,y:426,t:1527009011610};\\\", \\\"{x:1612,y:426,t:1527009013192};\\\", \\\"{x:1611,y:426,t:1527009034793};\\\", \\\"{x:1609,y:427,t:1527009034825};\\\", \\\"{x:1609,y:428,t:1527009034834};\\\", \\\"{x:1607,y:429,t:1527009034847};\\\", \\\"{x:1607,y:430,t:1527009034864};\\\", \\\"{x:1606,y:430,t:1527009034881};\\\", \\\"{x:1606,y:431,t:1527009034898};\\\", \\\"{x:1604,y:431,t:1527009035467};\\\", \\\"{x:1592,y:435,t:1527009035482};\\\", \\\"{x:1580,y:438,t:1527009035498};\\\", \\\"{x:1570,y:441,t:1527009035516};\\\", \\\"{x:1561,y:445,t:1527009035531};\\\", \\\"{x:1542,y:457,t:1527009035548};\\\", \\\"{x:1504,y:483,t:1527009035566};\\\", \\\"{x:1461,y:516,t:1527009035581};\\\", \\\"{x:1420,y:559,t:1527009035599};\\\", \\\"{x:1396,y:591,t:1527009035615};\\\", \\\"{x:1374,y:629,t:1527009035631};\\\", \\\"{x:1328,y:693,t:1527009035648};\\\", \\\"{x:1270,y:776,t:1527009035665};\\\", \\\"{x:1220,y:866,t:1527009035681};\\\", \\\"{x:1163,y:1000,t:1527009035698};\\\", \\\"{x:1136,y:1067,t:1527009035715};\\\", \\\"{x:1113,y:1092,t:1527009035731};\\\", \\\"{x:1106,y:1097,t:1527009035748};\\\", \\\"{x:1104,y:1097,t:1527009035765};\\\", \\\"{x:1103,y:1097,t:1527009035825};\\\", \\\"{x:1103,y:1096,t:1527009035865};\\\", \\\"{x:1106,y:1092,t:1527009035881};\\\", \\\"{x:1121,y:1081,t:1527009035898};\\\", \\\"{x:1143,y:1069,t:1527009035915};\\\", \\\"{x:1181,y:1048,t:1527009035932};\\\", \\\"{x:1208,y:1034,t:1527009035948};\\\", \\\"{x:1232,y:1024,t:1527009035965};\\\", \\\"{x:1253,y:1016,t:1527009035982};\\\", \\\"{x:1268,y:1011,t:1527009035998};\\\", \\\"{x:1272,y:1009,t:1527009036015};\\\", \\\"{x:1273,y:1008,t:1527009036032};\\\", \\\"{x:1273,y:1007,t:1527009036048};\\\", \\\"{x:1274,y:1006,t:1527009036066};\\\", \\\"{x:1275,y:1006,t:1527009036082};\\\", \\\"{x:1276,y:1002,t:1527009036099};\\\", \\\"{x:1279,y:998,t:1527009036115};\\\", \\\"{x:1284,y:991,t:1527009036133};\\\", \\\"{x:1290,y:981,t:1527009036148};\\\", \\\"{x:1292,y:974,t:1527009036165};\\\", \\\"{x:1293,y:967,t:1527009036183};\\\", \\\"{x:1293,y:963,t:1527009036199};\\\", \\\"{x:1293,y:962,t:1527009036216};\\\", \\\"{x:1293,y:961,t:1527009036232};\\\", \\\"{x:1293,y:960,t:1527009036250};\\\", \\\"{x:1293,y:959,t:1527009036265};\\\", \\\"{x:1293,y:958,t:1527009036281};\\\", \\\"{x:1293,y:956,t:1527009036300};\\\", \\\"{x:1293,y:954,t:1527009036321};\\\", \\\"{x:1293,y:953,t:1527009036332};\\\", \\\"{x:1294,y:950,t:1527009036350};\\\", \\\"{x:1294,y:949,t:1527009036365};\\\", \\\"{x:1295,y:948,t:1527009036382};\\\", \\\"{x:1296,y:952,t:1527009036481};\\\", \\\"{x:1297,y:957,t:1527009036499};\\\", \\\"{x:1298,y:963,t:1527009036515};\\\", \\\"{x:1298,y:965,t:1527009036532};\\\", \\\"{x:1298,y:967,t:1527009036549};\\\", \\\"{x:1297,y:969,t:1527009036565};\\\", \\\"{x:1295,y:972,t:1527009036582};\\\", \\\"{x:1293,y:975,t:1527009036599};\\\", \\\"{x:1290,y:976,t:1527009036615};\\\", \\\"{x:1288,y:978,t:1527009036633};\\\", \\\"{x:1287,y:978,t:1527009036649};\\\", \\\"{x:1285,y:980,t:1527009036665};\\\", \\\"{x:1283,y:980,t:1527009036682};\\\", \\\"{x:1282,y:980,t:1527009036699};\\\", \\\"{x:1280,y:980,t:1527009036716};\\\", \\\"{x:1278,y:980,t:1527009036732};\\\", \\\"{x:1277,y:980,t:1527009036749};\\\", \\\"{x:1277,y:979,t:1527009036766};\\\", \\\"{x:1277,y:978,t:1527009036782};\\\", \\\"{x:1277,y:977,t:1527009036818};\\\", \\\"{x:1277,y:975,t:1527009036842};\\\", \\\"{x:1277,y:974,t:1527009036858};\\\", \\\"{x:1277,y:972,t:1527009036874};\\\", \\\"{x:1277,y:971,t:1527009036897};\\\", \\\"{x:1277,y:970,t:1527009036914};\\\", \\\"{x:1277,y:969,t:1527009036921};\\\", \\\"{x:1277,y:967,t:1527009037074};\\\", \\\"{x:1277,y:966,t:1527009037082};\\\", \\\"{x:1278,y:962,t:1527009037099};\\\", \\\"{x:1284,y:951,t:1527009037116};\\\", \\\"{x:1290,y:940,t:1527009037133};\\\", \\\"{x:1298,y:925,t:1527009037149};\\\", \\\"{x:1309,y:914,t:1527009037167};\\\", \\\"{x:1317,y:904,t:1527009037183};\\\", \\\"{x:1320,y:900,t:1527009037199};\\\", \\\"{x:1324,y:897,t:1527009037216};\\\", \\\"{x:1329,y:892,t:1527009037234};\\\", \\\"{x:1331,y:890,t:1527009037249};\\\", \\\"{x:1334,y:886,t:1527009037266};\\\", \\\"{x:1336,y:884,t:1527009037284};\\\", \\\"{x:1337,y:882,t:1527009037299};\\\", \\\"{x:1339,y:877,t:1527009037317};\\\", \\\"{x:1343,y:872,t:1527009037334};\\\", \\\"{x:1347,y:862,t:1527009037349};\\\", \\\"{x:1351,y:857,t:1527009037366};\\\", \\\"{x:1352,y:854,t:1527009037383};\\\", \\\"{x:1354,y:850,t:1527009037400};\\\", \\\"{x:1356,y:846,t:1527009037417};\\\", \\\"{x:1358,y:841,t:1527009037433};\\\", \\\"{x:1359,y:835,t:1527009037449};\\\", \\\"{x:1364,y:817,t:1527009037466};\\\", \\\"{x:1368,y:806,t:1527009037483};\\\", \\\"{x:1369,y:799,t:1527009037499};\\\", \\\"{x:1370,y:791,t:1527009037516};\\\", \\\"{x:1372,y:787,t:1527009037534};\\\", \\\"{x:1374,y:781,t:1527009037549};\\\", \\\"{x:1376,y:775,t:1527009037566};\\\", \\\"{x:1377,y:771,t:1527009037583};\\\", \\\"{x:1379,y:765,t:1527009037601};\\\", \\\"{x:1380,y:760,t:1527009037617};\\\", \\\"{x:1384,y:749,t:1527009037634};\\\", \\\"{x:1388,y:736,t:1527009037650};\\\", \\\"{x:1391,y:729,t:1527009037666};\\\", \\\"{x:1395,y:721,t:1527009037684};\\\", \\\"{x:1399,y:712,t:1527009037700};\\\", \\\"{x:1405,y:700,t:1527009037716};\\\", \\\"{x:1412,y:685,t:1527009037733};\\\", \\\"{x:1420,y:668,t:1527009037750};\\\", \\\"{x:1429,y:650,t:1527009037766};\\\", \\\"{x:1436,y:633,t:1527009037784};\\\", \\\"{x:1443,y:618,t:1527009037801};\\\", \\\"{x:1453,y:598,t:1527009037816};\\\", \\\"{x:1464,y:581,t:1527009037833};\\\", \\\"{x:1480,y:553,t:1527009037850};\\\", \\\"{x:1489,y:538,t:1527009037866};\\\", \\\"{x:1496,y:526,t:1527009037883};\\\", \\\"{x:1502,y:511,t:1527009037900};\\\", \\\"{x:1511,y:495,t:1527009037916};\\\", \\\"{x:1519,y:479,t:1527009037933};\\\", \\\"{x:1528,y:463,t:1527009037950};\\\", \\\"{x:1536,y:452,t:1527009037966};\\\", \\\"{x:1543,y:443,t:1527009037983};\\\", \\\"{x:1547,y:434,t:1527009038000};\\\", \\\"{x:1550,y:429,t:1527009038016};\\\", \\\"{x:1554,y:423,t:1527009038033};\\\", \\\"{x:1560,y:414,t:1527009038050};\\\", \\\"{x:1563,y:409,t:1527009038067};\\\", \\\"{x:1565,y:405,t:1527009038083};\\\", \\\"{x:1567,y:403,t:1527009038100};\\\", \\\"{x:1567,y:401,t:1527009038117};\\\", \\\"{x:1568,y:400,t:1527009038133};\\\", \\\"{x:1569,y:398,t:1527009038150};\\\", \\\"{x:1570,y:397,t:1527009038168};\\\", \\\"{x:1570,y:396,t:1527009038184};\\\", \\\"{x:1570,y:395,t:1527009038200};\\\", \\\"{x:1572,y:393,t:1527009038217};\\\", \\\"{x:1573,y:390,t:1527009038233};\\\", \\\"{x:1577,y:387,t:1527009038250};\\\", \\\"{x:1579,y:385,t:1527009038268};\\\", \\\"{x:1580,y:383,t:1527009038283};\\\", \\\"{x:1582,y:380,t:1527009038300};\\\", \\\"{x:1583,y:379,t:1527009038318};\\\", \\\"{x:1585,y:377,t:1527009038334};\\\", \\\"{x:1586,y:377,t:1527009038643};\\\", \\\"{x:1586,y:376,t:1527009038650};\\\", \\\"{x:1585,y:375,t:1527009038668};\\\", \\\"{x:1584,y:374,t:1527009038723};\\\", \\\"{x:1583,y:375,t:1527009039186};\\\", \\\"{x:1581,y:376,t:1527009039202};\\\", \\\"{x:1579,y:379,t:1527009039217};\\\", \\\"{x:1578,y:380,t:1527009039234};\\\", \\\"{x:1577,y:385,t:1527009039610};\\\", \\\"{x:1576,y:396,t:1527009039619};\\\", \\\"{x:1568,y:423,t:1527009039634};\\\", \\\"{x:1559,y:457,t:1527009039652};\\\", \\\"{x:1551,y:510,t:1527009039668};\\\", \\\"{x:1540,y:599,t:1527009039685};\\\", \\\"{x:1522,y:696,t:1527009039701};\\\", \\\"{x:1498,y:780,t:1527009039718};\\\", \\\"{x:1471,y:846,t:1527009039735};\\\", \\\"{x:1445,y:897,t:1527009039751};\\\", \\\"{x:1433,y:923,t:1527009039769};\\\", \\\"{x:1422,y:945,t:1527009039785};\\\", \\\"{x:1422,y:952,t:1527009039802};\\\", \\\"{x:1424,y:960,t:1527009039818};\\\", \\\"{x:1429,y:967,t:1527009039834};\\\", \\\"{x:1435,y:972,t:1527009039851};\\\", \\\"{x:1441,y:975,t:1527009039868};\\\", \\\"{x:1452,y:975,t:1527009039885};\\\", \\\"{x:1461,y:969,t:1527009039902};\\\", \\\"{x:1480,y:950,t:1527009039918};\\\", \\\"{x:1503,y:929,t:1527009039936};\\\", \\\"{x:1525,y:913,t:1527009039952};\\\", \\\"{x:1547,y:897,t:1527009039969};\\\", \\\"{x:1568,y:875,t:1527009039986};\\\", \\\"{x:1573,y:863,t:1527009040002};\\\", \\\"{x:1578,y:848,t:1527009040019};\\\", \\\"{x:1582,y:827,t:1527009040035};\\\", \\\"{x:1587,y:791,t:1527009040051};\\\", \\\"{x:1596,y:722,t:1527009040068};\\\", \\\"{x:1605,y:645,t:1527009040085};\\\", \\\"{x:1618,y:569,t:1527009040102};\\\", \\\"{x:1631,y:509,t:1527009040118};\\\", \\\"{x:1640,y:468,t:1527009040136};\\\", \\\"{x:1642,y:445,t:1527009040152};\\\", \\\"{x:1642,y:430,t:1527009040169};\\\", \\\"{x:1640,y:419,t:1527009040186};\\\", \\\"{x:1639,y:413,t:1527009040202};\\\", \\\"{x:1638,y:407,t:1527009040218};\\\", \\\"{x:1636,y:397,t:1527009040235};\\\", \\\"{x:1636,y:384,t:1527009040252};\\\", \\\"{x:1642,y:370,t:1527009040268};\\\", \\\"{x:1642,y:369,t:1527009040305};\\\", \\\"{x:1643,y:369,t:1527009040318};\\\", \\\"{x:1644,y:371,t:1527009040335};\\\", \\\"{x:1642,y:385,t:1527009040353};\\\", \\\"{x:1635,y:399,t:1527009040368};\\\", \\\"{x:1627,y:417,t:1527009040386};\\\", \\\"{x:1620,y:425,t:1527009040402};\\\", \\\"{x:1616,y:429,t:1527009040419};\\\", \\\"{x:1613,y:430,t:1527009040435};\\\", \\\"{x:1612,y:431,t:1527009040452};\\\", \\\"{x:1610,y:431,t:1527009040468};\\\", \\\"{x:1608,y:431,t:1527009040486};\\\", \\\"{x:1606,y:430,t:1527009040502};\\\", \\\"{x:1604,y:430,t:1527009040569};\\\", \\\"{x:1601,y:433,t:1527009040585};\\\", \\\"{x:1597,y:448,t:1527009040602};\\\", \\\"{x:1582,y:470,t:1527009040619};\\\", \\\"{x:1563,y:496,t:1527009040635};\\\", \\\"{x:1548,y:518,t:1527009040653};\\\", \\\"{x:1532,y:540,t:1527009040669};\\\", \\\"{x:1517,y:561,t:1527009040685};\\\", \\\"{x:1501,y:583,t:1527009040702};\\\", \\\"{x:1492,y:599,t:1527009040720};\\\", \\\"{x:1483,y:614,t:1527009040735};\\\", \\\"{x:1476,y:626,t:1527009040752};\\\", \\\"{x:1472,y:635,t:1527009040769};\\\", \\\"{x:1470,y:638,t:1527009040786};\\\", \\\"{x:1470,y:642,t:1527009040802};\\\", \\\"{x:1470,y:645,t:1527009040819};\\\", \\\"{x:1470,y:648,t:1527009040835};\\\", \\\"{x:1470,y:649,t:1527009040852};\\\", \\\"{x:1471,y:651,t:1527009040874};\\\", \\\"{x:1473,y:651,t:1527009040890};\\\", \\\"{x:1474,y:651,t:1527009040902};\\\", \\\"{x:1480,y:651,t:1527009040919};\\\", \\\"{x:1490,y:651,t:1527009040936};\\\", \\\"{x:1501,y:649,t:1527009040952};\\\", \\\"{x:1512,y:635,t:1527009040970};\\\", \\\"{x:1520,y:620,t:1527009040985};\\\", \\\"{x:1524,y:611,t:1527009041003};\\\", \\\"{x:1526,y:607,t:1527009041019};\\\", \\\"{x:1526,y:603,t:1527009041036};\\\", \\\"{x:1527,y:603,t:1527009041052};\\\", \\\"{x:1526,y:603,t:1527009041129};\\\", \\\"{x:1523,y:607,t:1527009041137};\\\", \\\"{x:1522,y:611,t:1527009041152};\\\", \\\"{x:1511,y:631,t:1527009041169};\\\", \\\"{x:1499,y:646,t:1527009041186};\\\", \\\"{x:1487,y:663,t:1527009041202};\\\", \\\"{x:1475,y:678,t:1527009041220};\\\", \\\"{x:1465,y:689,t:1527009041236};\\\", \\\"{x:1456,y:698,t:1527009041253};\\\", \\\"{x:1447,y:703,t:1527009041269};\\\", \\\"{x:1431,y:707,t:1527009041286};\\\", \\\"{x:1399,y:707,t:1527009041302};\\\", \\\"{x:1310,y:707,t:1527009041320};\\\", \\\"{x:1186,y:707,t:1527009041337};\\\", \\\"{x:1022,y:709,t:1527009041352};\\\", \\\"{x:766,y:690,t:1527009041370};\\\", \\\"{x:594,y:688,t:1527009041385};\\\", \\\"{x:458,y:684,t:1527009041402};\\\", \\\"{x:359,y:678,t:1527009041420};\\\", \\\"{x:309,y:670,t:1527009041436};\\\", \\\"{x:297,y:665,t:1527009041453};\\\", \\\"{x:296,y:665,t:1527009041469};\\\", \\\"{x:296,y:662,t:1527009041486};\\\", \\\"{x:300,y:660,t:1527009041502};\\\", \\\"{x:305,y:658,t:1527009041519};\\\", \\\"{x:309,y:655,t:1527009041536};\\\", \\\"{x:322,y:651,t:1527009041553};\\\", \\\"{x:338,y:645,t:1527009041570};\\\", \\\"{x:356,y:640,t:1527009041586};\\\", \\\"{x:393,y:632,t:1527009041604};\\\", \\\"{x:448,y:621,t:1527009041620};\\\", \\\"{x:510,y:609,t:1527009041638};\\\", \\\"{x:568,y:601,t:1527009041654};\\\", \\\"{x:616,y:595,t:1527009041670};\\\", \\\"{x:639,y:591,t:1527009041687};\\\", \\\"{x:647,y:590,t:1527009041705};\\\", \\\"{x:646,y:590,t:1527009041761};\\\", \\\"{x:644,y:590,t:1527009041771};\\\", \\\"{x:633,y:590,t:1527009041788};\\\", \\\"{x:613,y:590,t:1527009041804};\\\", \\\"{x:573,y:593,t:1527009041822};\\\", \\\"{x:519,y:601,t:1527009041838};\\\", \\\"{x:472,y:606,t:1527009041855};\\\", \\\"{x:441,y:608,t:1527009041871};\\\", \\\"{x:417,y:608,t:1527009041887};\\\", \\\"{x:410,y:608,t:1527009041904};\\\", \\\"{x:409,y:608,t:1527009041921};\\\", \\\"{x:412,y:608,t:1527009041945};\\\", \\\"{x:415,y:608,t:1527009041955};\\\", \\\"{x:418,y:608,t:1527009041971};\\\", \\\"{x:419,y:608,t:1527009041988};\\\", \\\"{x:416,y:608,t:1527009042050};\\\", \\\"{x:412,y:608,t:1527009042058};\\\", \\\"{x:409,y:608,t:1527009042071};\\\", \\\"{x:400,y:607,t:1527009042088};\\\", \\\"{x:396,y:605,t:1527009042105};\\\", \\\"{x:394,y:604,t:1527009042121};\\\", \\\"{x:393,y:606,t:1527009042362};\\\", \\\"{x:393,y:610,t:1527009042372};\\\", \\\"{x:394,y:620,t:1527009042388};\\\", \\\"{x:402,y:635,t:1527009042404};\\\", \\\"{x:409,y:652,t:1527009042422};\\\", \\\"{x:420,y:670,t:1527009042438};\\\", \\\"{x:430,y:685,t:1527009042455};\\\", \\\"{x:438,y:695,t:1527009042472};\\\", \\\"{x:444,y:702,t:1527009042488};\\\", \\\"{x:448,y:707,t:1527009042505};\\\", \\\"{x:451,y:707,t:1527009042521};\\\", \\\"{x:453,y:708,t:1527009042539};\\\", \\\"{x:454,y:708,t:1527009042561};\\\", \\\"{x:456,y:708,t:1527009042577};\\\", \\\"{x:457,y:708,t:1527009042588};\\\", \\\"{x:460,y:708,t:1527009042605};\\\", \\\"{x:464,y:708,t:1527009042622};\\\", \\\"{x:468,y:709,t:1527009042638};\\\", \\\"{x:474,y:709,t:1527009042656};\\\", \\\"{x:481,y:709,t:1527009042672};\\\", \\\"{x:485,y:709,t:1527009042689};\\\", \\\"{x:486,y:709,t:1527009042793};\\\", \\\"{x:486,y:709,t:1527009042903};\\\", \\\"{x:487,y:709,t:1527009042930};\\\", \\\"{x:488,y:709,t:1527009042945};\\\", \\\"{x:488,y:708,t:1527009042955};\\\", \\\"{x:490,y:706,t:1527009042972};\\\", \\\"{x:491,y:704,t:1527009042993};\\\", \\\"{x:492,y:704,t:1527009043005};\\\", \\\"{x:494,y:703,t:1527009043023};\\\", \\\"{x:501,y:702,t:1527009043038};\\\", \\\"{x:513,y:701,t:1527009043055};\\\", \\\"{x:530,y:698,t:1527009043072};\\\", \\\"{x:553,y:694,t:1527009043088};\\\", \\\"{x:630,y:686,t:1527009043105};\\\", \\\"{x:713,y:675,t:1527009043122};\\\", \\\"{x:813,y:661,t:1527009043138};\\\", \\\"{x:915,y:647,t:1527009043155};\\\", \\\"{x:1015,y:636,t:1527009043173};\\\", \\\"{x:1099,y:632,t:1527009043188};\\\", \\\"{x:1164,y:620,t:1527009043205};\\\", \\\"{x:1199,y:612,t:1527009043222};\\\", \\\"{x:1218,y:607,t:1527009043238};\\\", \\\"{x:1221,y:606,t:1527009043256};\\\", \\\"{x:1222,y:605,t:1527009043322};\\\", \\\"{x:1223,y:605,t:1527009043339};\\\", \\\"{x:1223,y:604,t:1527009043355};\\\", \\\"{x:1224,y:603,t:1527009043394};\\\", \\\"{x:1224,y:602,t:1527009043406};\\\", \\\"{x:1225,y:601,t:1527009043635};\\\", \\\"{x:1225,y:600,t:1527009043650};\\\", \\\"{x:1226,y:599,t:1527009043673};\\\", \\\"{x:1226,y:598,t:1527009043689};\\\" ] }, { \\\"rt\\\": 29180, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 219488, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -C -11 AM-C -C -C -02 PM-01 PM-C -11 AM-C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1052,y:573,t:1527009044605};\\\", \\\"{x:1000,y:565,t:1527009044610};\\\", \\\"{x:944,y:559,t:1527009044624};\\\", \\\"{x:816,y:543,t:1527009044640};\\\", \\\"{x:681,y:528,t:1527009044657};\\\", \\\"{x:492,y:520,t:1527009044674};\\\", \\\"{x:408,y:518,t:1527009044691};\\\", \\\"{x:363,y:518,t:1527009044707};\\\", \\\"{x:351,y:518,t:1527009044723};\\\", \\\"{x:350,y:518,t:1527009044740};\\\", \\\"{x:349,y:516,t:1527009044826};\\\", \\\"{x:349,y:513,t:1527009044840};\\\", \\\"{x:350,y:501,t:1527009044857};\\\", \\\"{x:351,y:488,t:1527009044874};\\\", \\\"{x:351,y:473,t:1527009044890};\\\", \\\"{x:351,y:461,t:1527009044907};\\\", \\\"{x:348,y:450,t:1527009044924};\\\", \\\"{x:344,y:445,t:1527009044940};\\\", \\\"{x:341,y:439,t:1527009044957};\\\", \\\"{x:339,y:436,t:1527009044973};\\\", \\\"{x:339,y:435,t:1527009045018};\\\", \\\"{x:341,y:437,t:1527009045026};\\\", \\\"{x:346,y:441,t:1527009045040};\\\", \\\"{x:361,y:450,t:1527009045057};\\\", \\\"{x:401,y:467,t:1527009045074};\\\", \\\"{x:439,y:475,t:1527009045089};\\\", \\\"{x:473,y:477,t:1527009045106};\\\", \\\"{x:506,y:480,t:1527009045123};\\\", \\\"{x:529,y:480,t:1527009045139};\\\", \\\"{x:536,y:480,t:1527009045157};\\\", \\\"{x:538,y:480,t:1527009045173};\\\", \\\"{x:536,y:480,t:1527009045209};\\\", \\\"{x:534,y:480,t:1527009045223};\\\", \\\"{x:529,y:480,t:1527009045239};\\\", \\\"{x:525,y:479,t:1527009045256};\\\", \\\"{x:524,y:479,t:1527009045273};\\\", \\\"{x:522,y:479,t:1527009045298};\\\", \\\"{x:521,y:479,t:1527009045314};\\\", \\\"{x:520,y:479,t:1527009045323};\\\", \\\"{x:519,y:479,t:1527009045340};\\\", \\\"{x:518,y:479,t:1527009045386};\\\", \\\"{x:517,y:479,t:1527009045402};\\\", \\\"{x:516,y:479,t:1527009045409};\\\", \\\"{x:515,y:479,t:1527009045425};\\\", \\\"{x:513,y:479,t:1527009045440};\\\", \\\"{x:510,y:479,t:1527009045456};\\\", \\\"{x:505,y:479,t:1527009045474};\\\", \\\"{x:501,y:477,t:1527009045490};\\\", \\\"{x:500,y:476,t:1527009045513};\\\", \\\"{x:499,y:476,t:1527009045529};\\\", \\\"{x:499,y:475,t:1527009045593};\\\", \\\"{x:500,y:475,t:1527009045618};\\\", \\\"{x:501,y:475,t:1527009045625};\\\", \\\"{x:501,y:474,t:1527009045642};\\\", \\\"{x:499,y:474,t:1527009046178};\\\", \\\"{x:495,y:474,t:1527009046189};\\\", \\\"{x:489,y:474,t:1527009046206};\\\", \\\"{x:476,y:474,t:1527009046222};\\\", \\\"{x:469,y:474,t:1527009046240};\\\", \\\"{x:465,y:474,t:1527009046257};\\\", \\\"{x:463,y:474,t:1527009046272};\\\", \\\"{x:461,y:474,t:1527009046289};\\\", \\\"{x:460,y:474,t:1527009046306};\\\", \\\"{x:459,y:474,t:1527009046323};\\\", \\\"{x:458,y:474,t:1527009046346};\\\", \\\"{x:457,y:474,t:1527009046377};\\\", \\\"{x:458,y:474,t:1527009046482};\\\", \\\"{x:458,y:473,t:1527009046489};\\\", \\\"{x:459,y:473,t:1527009046507};\\\", \\\"{x:460,y:473,t:1527009046523};\\\", \\\"{x:461,y:473,t:1527009046921};\\\", \\\"{x:462,y:473,t:1527009046945};\\\", \\\"{x:463,y:473,t:1527009046955};\\\", \\\"{x:465,y:473,t:1527009046972};\\\", \\\"{x:468,y:473,t:1527009046990};\\\", \\\"{x:473,y:473,t:1527009047006};\\\", \\\"{x:480,y:473,t:1527009047022};\\\", \\\"{x:491,y:473,t:1527009047040};\\\", \\\"{x:507,y:473,t:1527009047056};\\\", \\\"{x:530,y:473,t:1527009047072};\\\", \\\"{x:581,y:473,t:1527009047090};\\\", \\\"{x:639,y:473,t:1527009047105};\\\", \\\"{x:725,y:473,t:1527009047123};\\\", \\\"{x:831,y:473,t:1527009047140};\\\", \\\"{x:933,y:473,t:1527009047155};\\\", \\\"{x:1039,y:473,t:1527009047173};\\\", \\\"{x:1130,y:473,t:1527009047190};\\\", \\\"{x:1208,y:473,t:1527009047205};\\\", \\\"{x:1269,y:473,t:1527009047223};\\\", \\\"{x:1317,y:473,t:1527009047239};\\\", \\\"{x:1351,y:473,t:1527009047255};\\\", \\\"{x:1373,y:473,t:1527009047272};\\\", \\\"{x:1399,y:473,t:1527009047290};\\\", \\\"{x:1409,y:473,t:1527009047306};\\\", \\\"{x:1412,y:473,t:1527009047322};\\\", \\\"{x:1413,y:473,t:1527009047339};\\\", \\\"{x:1414,y:474,t:1527009047356};\\\", \\\"{x:1415,y:474,t:1527009047434};\\\", \\\"{x:1419,y:475,t:1527009047442};\\\", \\\"{x:1421,y:475,t:1527009047456};\\\", \\\"{x:1428,y:476,t:1527009047472};\\\", \\\"{x:1436,y:477,t:1527009047489};\\\", \\\"{x:1448,y:478,t:1527009047505};\\\", \\\"{x:1462,y:479,t:1527009047523};\\\", \\\"{x:1474,y:480,t:1527009047539};\\\", \\\"{x:1484,y:483,t:1527009047556};\\\", \\\"{x:1493,y:484,t:1527009047572};\\\", \\\"{x:1498,y:485,t:1527009047589};\\\", \\\"{x:1501,y:487,t:1527009047606};\\\", \\\"{x:1502,y:487,t:1527009047623};\\\", \\\"{x:1504,y:493,t:1527009047639};\\\", \\\"{x:1508,y:507,t:1527009047656};\\\", \\\"{x:1515,y:524,t:1527009047673};\\\", \\\"{x:1522,y:538,t:1527009047689};\\\", \\\"{x:1535,y:558,t:1527009047705};\\\", \\\"{x:1548,y:568,t:1527009047722};\\\", \\\"{x:1570,y:582,t:1527009047739};\\\", \\\"{x:1601,y:600,t:1527009047756};\\\", \\\"{x:1637,y:623,t:1527009047773};\\\", \\\"{x:1675,y:645,t:1527009047789};\\\", \\\"{x:1704,y:659,t:1527009047806};\\\", \\\"{x:1721,y:667,t:1527009047822};\\\", \\\"{x:1737,y:676,t:1527009047839};\\\", \\\"{x:1749,y:682,t:1527009047856};\\\", \\\"{x:1754,y:686,t:1527009047873};\\\", \\\"{x:1756,y:686,t:1527009047888};\\\", \\\"{x:1757,y:687,t:1527009047913};\\\", \\\"{x:1757,y:686,t:1527009047986};\\\", \\\"{x:1757,y:685,t:1527009047994};\\\", \\\"{x:1757,y:683,t:1527009048006};\\\", \\\"{x:1757,y:682,t:1527009048022};\\\", \\\"{x:1755,y:678,t:1527009048039};\\\", \\\"{x:1753,y:676,t:1527009048056};\\\", \\\"{x:1753,y:675,t:1527009048073};\\\", \\\"{x:1752,y:674,t:1527009048089};\\\", \\\"{x:1752,y:676,t:1527009048146};\\\", \\\"{x:1752,y:683,t:1527009048155};\\\", \\\"{x:1752,y:694,t:1527009048172};\\\", \\\"{x:1750,y:708,t:1527009048189};\\\", \\\"{x:1750,y:723,t:1527009048205};\\\", \\\"{x:1750,y:733,t:1527009048223};\\\", \\\"{x:1750,y:743,t:1527009048239};\\\", \\\"{x:1750,y:750,t:1527009048256};\\\", \\\"{x:1747,y:760,t:1527009048273};\\\", \\\"{x:1745,y:763,t:1527009048289};\\\", \\\"{x:1738,y:767,t:1527009048306};\\\", \\\"{x:1730,y:771,t:1527009048323};\\\", \\\"{x:1722,y:776,t:1527009048339};\\\", \\\"{x:1713,y:779,t:1527009048356};\\\", \\\"{x:1707,y:781,t:1527009048372};\\\", \\\"{x:1705,y:781,t:1527009048388};\\\", \\\"{x:1701,y:782,t:1527009048406};\\\", \\\"{x:1698,y:782,t:1527009048422};\\\", \\\"{x:1694,y:782,t:1527009048438};\\\", \\\"{x:1687,y:782,t:1527009048455};\\\", \\\"{x:1671,y:773,t:1527009048472};\\\", \\\"{x:1653,y:767,t:1527009048489};\\\", \\\"{x:1614,y:761,t:1527009048505};\\\", \\\"{x:1583,y:756,t:1527009048522};\\\", \\\"{x:1545,y:751,t:1527009048539};\\\", \\\"{x:1505,y:749,t:1527009048555};\\\", \\\"{x:1468,y:744,t:1527009048572};\\\", \\\"{x:1450,y:744,t:1527009048589};\\\", \\\"{x:1442,y:744,t:1527009048605};\\\", \\\"{x:1438,y:744,t:1527009048622};\\\", \\\"{x:1438,y:747,t:1527009048639};\\\", \\\"{x:1438,y:756,t:1527009048656};\\\", \\\"{x:1439,y:765,t:1527009048672};\\\", \\\"{x:1441,y:772,t:1527009048688};\\\", \\\"{x:1443,y:782,t:1527009048705};\\\", \\\"{x:1444,y:787,t:1527009048722};\\\", \\\"{x:1445,y:792,t:1527009048739};\\\", \\\"{x:1446,y:797,t:1527009048755};\\\", \\\"{x:1447,y:800,t:1527009048772};\\\", \\\"{x:1447,y:801,t:1527009048789};\\\", \\\"{x:1445,y:801,t:1527009048849};\\\", \\\"{x:1443,y:801,t:1527009048857};\\\", \\\"{x:1441,y:800,t:1527009048872};\\\", \\\"{x:1434,y:791,t:1527009048889};\\\", \\\"{x:1419,y:766,t:1527009048905};\\\", \\\"{x:1405,y:740,t:1527009048921};\\\", \\\"{x:1390,y:706,t:1527009048939};\\\", \\\"{x:1372,y:676,t:1527009048955};\\\", \\\"{x:1355,y:647,t:1527009048971};\\\", \\\"{x:1336,y:616,t:1527009048988};\\\", \\\"{x:1323,y:598,t:1527009049006};\\\", \\\"{x:1314,y:585,t:1527009049022};\\\", \\\"{x:1307,y:572,t:1527009049039};\\\", \\\"{x:1304,y:563,t:1527009049056};\\\", \\\"{x:1301,y:550,t:1527009049072};\\\", \\\"{x:1297,y:541,t:1527009049089};\\\", \\\"{x:1295,y:533,t:1527009049106};\\\", \\\"{x:1293,y:529,t:1527009049122};\\\", \\\"{x:1293,y:527,t:1527009049139};\\\", \\\"{x:1291,y:525,t:1527009049156};\\\", \\\"{x:1289,y:525,t:1527009049305};\\\", \\\"{x:1286,y:542,t:1527009049322};\\\", \\\"{x:1280,y:574,t:1527009049339};\\\", \\\"{x:1280,y:602,t:1527009049355};\\\", \\\"{x:1279,y:630,t:1527009049372};\\\", \\\"{x:1279,y:650,t:1527009049389};\\\", \\\"{x:1279,y:665,t:1527009049405};\\\", \\\"{x:1279,y:680,t:1527009049422};\\\", \\\"{x:1279,y:690,t:1527009049439};\\\", \\\"{x:1279,y:695,t:1527009049455};\\\", \\\"{x:1279,y:701,t:1527009049472};\\\", \\\"{x:1279,y:705,t:1527009049490};\\\", \\\"{x:1279,y:706,t:1527009049578};\\\", \\\"{x:1280,y:708,t:1527009049595};\\\", \\\"{x:1280,y:709,t:1527009049605};\\\", \\\"{x:1284,y:714,t:1527009049622};\\\", \\\"{x:1288,y:726,t:1527009049639};\\\", \\\"{x:1296,y:744,t:1527009049655};\\\", \\\"{x:1306,y:772,t:1527009049673};\\\", \\\"{x:1317,y:796,t:1527009049689};\\\", \\\"{x:1329,y:828,t:1527009049705};\\\", \\\"{x:1341,y:854,t:1527009049723};\\\", \\\"{x:1344,y:860,t:1527009049739};\\\", \\\"{x:1345,y:862,t:1527009049756};\\\", \\\"{x:1346,y:865,t:1527009049772};\\\", \\\"{x:1348,y:868,t:1527009049789};\\\", \\\"{x:1350,y:873,t:1527009049805};\\\", \\\"{x:1353,y:877,t:1527009049822};\\\", \\\"{x:1355,y:881,t:1527009049840};\\\", \\\"{x:1356,y:884,t:1527009049855};\\\", \\\"{x:1357,y:884,t:1527009049872};\\\", \\\"{x:1358,y:884,t:1527009049930};\\\", \\\"{x:1359,y:884,t:1527009049946};\\\", \\\"{x:1362,y:885,t:1527009049955};\\\", \\\"{x:1367,y:887,t:1527009049972};\\\", \\\"{x:1380,y:888,t:1527009049988};\\\", \\\"{x:1390,y:890,t:1527009050005};\\\", \\\"{x:1397,y:893,t:1527009050021};\\\", \\\"{x:1404,y:897,t:1527009050039};\\\", \\\"{x:1405,y:898,t:1527009050055};\\\", \\\"{x:1406,y:899,t:1527009050072};\\\", \\\"{x:1406,y:900,t:1527009050089};\\\", \\\"{x:1406,y:901,t:1527009050105};\\\", \\\"{x:1396,y:902,t:1527009050122};\\\", \\\"{x:1374,y:901,t:1527009050138};\\\", \\\"{x:1337,y:889,t:1527009050155};\\\", \\\"{x:1299,y:873,t:1527009050172};\\\", \\\"{x:1268,y:854,t:1527009050187};\\\", \\\"{x:1253,y:844,t:1527009050204};\\\", \\\"{x:1243,y:836,t:1527009050222};\\\", \\\"{x:1236,y:829,t:1527009050238};\\\", \\\"{x:1234,y:825,t:1527009050255};\\\", \\\"{x:1232,y:823,t:1527009050272};\\\", \\\"{x:1232,y:822,t:1527009050331};\\\", \\\"{x:1230,y:822,t:1527009050346};\\\", \\\"{x:1229,y:822,t:1527009050363};\\\", \\\"{x:1227,y:822,t:1527009050372};\\\", \\\"{x:1224,y:822,t:1527009050388};\\\", \\\"{x:1222,y:822,t:1527009050405};\\\", \\\"{x:1220,y:823,t:1527009050422};\\\", \\\"{x:1219,y:823,t:1527009050438};\\\", \\\"{x:1218,y:823,t:1527009050457};\\\", \\\"{x:1217,y:823,t:1527009050473};\\\", \\\"{x:1216,y:823,t:1527009050488};\\\", \\\"{x:1212,y:820,t:1527009050505};\\\", \\\"{x:1202,y:807,t:1527009050521};\\\", \\\"{x:1196,y:797,t:1527009050537};\\\", \\\"{x:1191,y:790,t:1527009050555};\\\", \\\"{x:1189,y:788,t:1527009050572};\\\", \\\"{x:1189,y:787,t:1527009050594};\\\", \\\"{x:1189,y:786,t:1527009050618};\\\", \\\"{x:1189,y:785,t:1527009050667};\\\", \\\"{x:1187,y:783,t:1527009050699};\\\", \\\"{x:1187,y:782,t:1527009050795};\\\", \\\"{x:1187,y:781,t:1527009050805};\\\", \\\"{x:1187,y:780,t:1527009050822};\\\", \\\"{x:1186,y:778,t:1527009050838};\\\", \\\"{x:1186,y:777,t:1527009050855};\\\", \\\"{x:1186,y:775,t:1527009050881};\\\", \\\"{x:1185,y:774,t:1527009050897};\\\", \\\"{x:1184,y:772,t:1527009050930};\\\", \\\"{x:1184,y:771,t:1527009051457};\\\", \\\"{x:1185,y:771,t:1527009051473};\\\", \\\"{x:1187,y:772,t:1527009051488};\\\", \\\"{x:1190,y:773,t:1527009051505};\\\", \\\"{x:1192,y:775,t:1527009051521};\\\", \\\"{x:1195,y:779,t:1527009051538};\\\", \\\"{x:1197,y:782,t:1527009051555};\\\", \\\"{x:1199,y:784,t:1527009051571};\\\", \\\"{x:1201,y:786,t:1527009051588};\\\", \\\"{x:1201,y:788,t:1527009051605};\\\", \\\"{x:1203,y:790,t:1527009051621};\\\", \\\"{x:1205,y:792,t:1527009051637};\\\", \\\"{x:1205,y:793,t:1527009051655};\\\", \\\"{x:1206,y:795,t:1527009051673};\\\", \\\"{x:1207,y:795,t:1527009051697};\\\", \\\"{x:1208,y:796,t:1527009051705};\\\", \\\"{x:1208,y:797,t:1527009051720};\\\", \\\"{x:1210,y:799,t:1527009051737};\\\", \\\"{x:1210,y:800,t:1527009051755};\\\", \\\"{x:1211,y:801,t:1527009051771};\\\", \\\"{x:1212,y:803,t:1527009051788};\\\", \\\"{x:1213,y:805,t:1527009051805};\\\", \\\"{x:1215,y:807,t:1527009051820};\\\", \\\"{x:1217,y:810,t:1527009051838};\\\", \\\"{x:1217,y:811,t:1527009051854};\\\", \\\"{x:1218,y:811,t:1527009051871};\\\", \\\"{x:1219,y:814,t:1527009051888};\\\", \\\"{x:1220,y:815,t:1527009051904};\\\", \\\"{x:1221,y:817,t:1527009051920};\\\", \\\"{x:1222,y:819,t:1527009051937};\\\", \\\"{x:1223,y:820,t:1527009051955};\\\", \\\"{x:1223,y:821,t:1527009051971};\\\", \\\"{x:1225,y:822,t:1527009051987};\\\", \\\"{x:1226,y:823,t:1527009052003};\\\", \\\"{x:1227,y:824,t:1527009052021};\\\", \\\"{x:1228,y:824,t:1527009052050};\\\", \\\"{x:1228,y:825,t:1527009052057};\\\", \\\"{x:1229,y:825,t:1527009052071};\\\", \\\"{x:1229,y:826,t:1527009052105};\\\", \\\"{x:1229,y:827,t:1527009052121};\\\", \\\"{x:1230,y:829,t:1527009052137};\\\", \\\"{x:1231,y:830,t:1527009052154};\\\", \\\"{x:1231,y:831,t:1527009052171};\\\", \\\"{x:1232,y:832,t:1527009052188};\\\", \\\"{x:1233,y:832,t:1527009052204};\\\", \\\"{x:1233,y:833,t:1527009052220};\\\", \\\"{x:1234,y:834,t:1527009052238};\\\", \\\"{x:1235,y:835,t:1527009052281};\\\", \\\"{x:1236,y:837,t:1527009052313};\\\", \\\"{x:1236,y:839,t:1527009052337};\\\", \\\"{x:1237,y:839,t:1527009052354};\\\", \\\"{x:1237,y:840,t:1527009052371};\\\", \\\"{x:1237,y:841,t:1527009052402};\\\", \\\"{x:1238,y:842,t:1527009052450};\\\", \\\"{x:1238,y:844,t:1527009052481};\\\", \\\"{x:1239,y:844,t:1527009052505};\\\", \\\"{x:1239,y:845,t:1527009052521};\\\", \\\"{x:1239,y:847,t:1527009052545};\\\", \\\"{x:1241,y:848,t:1527009052554};\\\", \\\"{x:1241,y:849,t:1527009052571};\\\", \\\"{x:1241,y:850,t:1527009052588};\\\", \\\"{x:1242,y:852,t:1527009052604};\\\", \\\"{x:1242,y:854,t:1527009052621};\\\", \\\"{x:1243,y:856,t:1527009052637};\\\", \\\"{x:1243,y:860,t:1527009052654};\\\", \\\"{x:1244,y:864,t:1527009052671};\\\", \\\"{x:1245,y:868,t:1527009052687};\\\", \\\"{x:1245,y:871,t:1527009052703};\\\", \\\"{x:1246,y:874,t:1527009052721};\\\", \\\"{x:1246,y:876,t:1527009052737};\\\", \\\"{x:1246,y:878,t:1527009052754};\\\", \\\"{x:1247,y:880,t:1527009052771};\\\", \\\"{x:1247,y:881,t:1527009052794};\\\", \\\"{x:1248,y:882,t:1527009052804};\\\", \\\"{x:1248,y:884,t:1527009052826};\\\", \\\"{x:1249,y:885,t:1527009052842};\\\", \\\"{x:1249,y:887,t:1527009052854};\\\", \\\"{x:1250,y:889,t:1527009052871};\\\", \\\"{x:1252,y:893,t:1527009052887};\\\", \\\"{x:1253,y:895,t:1527009052904};\\\", \\\"{x:1256,y:899,t:1527009052921};\\\", \\\"{x:1256,y:901,t:1527009052938};\\\", \\\"{x:1258,y:904,t:1527009052953};\\\", \\\"{x:1259,y:908,t:1527009052971};\\\", \\\"{x:1260,y:912,t:1527009052987};\\\", \\\"{x:1262,y:918,t:1527009053004};\\\", \\\"{x:1264,y:922,t:1527009053021};\\\", \\\"{x:1265,y:926,t:1527009053037};\\\", \\\"{x:1268,y:931,t:1527009053054};\\\", \\\"{x:1269,y:933,t:1527009053071};\\\", \\\"{x:1271,y:935,t:1527009053087};\\\", \\\"{x:1271,y:938,t:1527009053104};\\\", \\\"{x:1273,y:942,t:1527009053121};\\\", \\\"{x:1274,y:944,t:1527009053137};\\\", \\\"{x:1275,y:946,t:1527009053154};\\\", \\\"{x:1276,y:947,t:1527009053171};\\\", \\\"{x:1276,y:948,t:1527009053187};\\\", \\\"{x:1277,y:949,t:1527009053226};\\\", \\\"{x:1278,y:950,t:1527009053242};\\\", \\\"{x:1278,y:951,t:1527009053258};\\\", \\\"{x:1279,y:951,t:1527009053271};\\\", \\\"{x:1279,y:952,t:1527009053287};\\\", \\\"{x:1280,y:953,t:1527009053304};\\\", \\\"{x:1280,y:954,t:1527009053321};\\\", \\\"{x:1281,y:954,t:1527009053337};\\\", \\\"{x:1282,y:958,t:1527009053354};\\\", \\\"{x:1282,y:959,t:1527009053371};\\\", \\\"{x:1282,y:960,t:1527009053387};\\\", \\\"{x:1282,y:961,t:1527009053409};\\\", \\\"{x:1282,y:958,t:1527009053610};\\\", \\\"{x:1282,y:956,t:1527009053620};\\\", \\\"{x:1280,y:945,t:1527009053637};\\\", \\\"{x:1275,y:932,t:1527009053654};\\\", \\\"{x:1266,y:915,t:1527009053670};\\\", \\\"{x:1259,y:897,t:1527009053687};\\\", \\\"{x:1250,y:884,t:1527009053704};\\\", \\\"{x:1244,y:873,t:1527009053720};\\\", \\\"{x:1240,y:867,t:1527009053737};\\\", \\\"{x:1235,y:857,t:1527009053753};\\\", \\\"{x:1228,y:847,t:1527009053769};\\\", \\\"{x:1226,y:844,t:1527009053786};\\\", \\\"{x:1222,y:836,t:1527009053804};\\\", \\\"{x:1218,y:830,t:1527009053820};\\\", \\\"{x:1213,y:822,t:1527009053838};\\\", \\\"{x:1209,y:815,t:1527009053854};\\\", \\\"{x:1205,y:809,t:1527009053870};\\\", \\\"{x:1202,y:805,t:1527009053887};\\\", \\\"{x:1201,y:800,t:1527009053904};\\\", \\\"{x:1199,y:796,t:1527009053920};\\\", \\\"{x:1197,y:791,t:1527009053937};\\\", \\\"{x:1195,y:787,t:1527009053953};\\\", \\\"{x:1194,y:784,t:1527009053970};\\\", \\\"{x:1193,y:782,t:1527009053987};\\\", \\\"{x:1191,y:779,t:1527009054004};\\\", \\\"{x:1189,y:776,t:1527009054020};\\\", \\\"{x:1187,y:773,t:1527009054037};\\\", \\\"{x:1185,y:769,t:1527009054054};\\\", \\\"{x:1184,y:769,t:1527009054070};\\\", \\\"{x:1184,y:768,t:1527009054087};\\\", \\\"{x:1184,y:767,t:1527009054104};\\\", \\\"{x:1185,y:767,t:1527009054185};\\\", \\\"{x:1188,y:768,t:1527009054201};\\\", \\\"{x:1190,y:769,t:1527009054210};\\\", \\\"{x:1191,y:771,t:1527009054219};\\\", \\\"{x:1192,y:773,t:1527009054237};\\\", \\\"{x:1193,y:775,t:1527009054254};\\\", \\\"{x:1196,y:780,t:1527009054270};\\\", \\\"{x:1199,y:785,t:1527009054287};\\\", \\\"{x:1203,y:792,t:1527009054304};\\\", \\\"{x:1206,y:799,t:1527009054320};\\\", \\\"{x:1210,y:807,t:1527009054337};\\\", \\\"{x:1219,y:823,t:1527009054353};\\\", \\\"{x:1223,y:833,t:1527009054370};\\\", \\\"{x:1229,y:841,t:1527009054387};\\\", \\\"{x:1233,y:849,t:1527009054403};\\\", \\\"{x:1236,y:854,t:1527009054421};\\\", \\\"{x:1240,y:861,t:1527009054437};\\\", \\\"{x:1242,y:866,t:1527009054453};\\\", \\\"{x:1245,y:869,t:1527009054470};\\\", \\\"{x:1247,y:872,t:1527009054487};\\\", \\\"{x:1248,y:875,t:1527009054503};\\\", \\\"{x:1249,y:877,t:1527009054520};\\\", \\\"{x:1251,y:880,t:1527009054537};\\\", \\\"{x:1252,y:883,t:1527009054553};\\\", \\\"{x:1256,y:891,t:1527009054570};\\\", \\\"{x:1258,y:896,t:1527009054587};\\\", \\\"{x:1260,y:904,t:1527009054603};\\\", \\\"{x:1264,y:915,t:1527009054620};\\\", \\\"{x:1269,y:929,t:1527009054637};\\\", \\\"{x:1272,y:942,t:1527009054653};\\\", \\\"{x:1276,y:952,t:1527009054670};\\\", \\\"{x:1279,y:961,t:1527009054687};\\\", \\\"{x:1279,y:965,t:1527009054703};\\\", \\\"{x:1281,y:968,t:1527009054720};\\\", \\\"{x:1281,y:969,t:1527009054737};\\\", \\\"{x:1281,y:970,t:1527009054754};\\\", \\\"{x:1282,y:971,t:1527009054770};\\\", \\\"{x:1283,y:972,t:1527009054786};\\\", \\\"{x:1284,y:977,t:1527009054803};\\\", \\\"{x:1285,y:979,t:1527009054820};\\\", \\\"{x:1285,y:980,t:1527009054837};\\\", \\\"{x:1286,y:982,t:1527009054853};\\\", \\\"{x:1286,y:981,t:1527009055050};\\\", \\\"{x:1285,y:981,t:1527009055073};\\\", \\\"{x:1284,y:980,t:1527009055089};\\\", \\\"{x:1283,y:980,t:1527009055103};\\\", \\\"{x:1281,y:979,t:1527009055120};\\\", \\\"{x:1281,y:978,t:1527009056249};\\\", \\\"{x:1281,y:977,t:1527009056433};\\\", \\\"{x:1281,y:976,t:1527009056441};\\\", \\\"{x:1281,y:974,t:1527009056453};\\\", \\\"{x:1281,y:969,t:1527009056469};\\\", \\\"{x:1278,y:961,t:1527009056487};\\\", \\\"{x:1271,y:949,t:1527009056503};\\\", \\\"{x:1264,y:938,t:1527009056519};\\\", \\\"{x:1259,y:928,t:1527009056536};\\\", \\\"{x:1252,y:915,t:1527009056554};\\\", \\\"{x:1247,y:902,t:1527009056569};\\\", \\\"{x:1241,y:887,t:1527009056586};\\\", \\\"{x:1237,y:871,t:1527009056603};\\\", \\\"{x:1232,y:859,t:1527009056619};\\\", \\\"{x:1229,y:848,t:1527009056636};\\\", \\\"{x:1229,y:843,t:1527009056653};\\\", \\\"{x:1228,y:842,t:1527009056669};\\\", \\\"{x:1225,y:838,t:1527009056686};\\\", \\\"{x:1224,y:836,t:1527009056703};\\\", \\\"{x:1222,y:833,t:1527009056719};\\\", \\\"{x:1220,y:831,t:1527009056737};\\\", \\\"{x:1217,y:827,t:1527009056753};\\\", \\\"{x:1214,y:824,t:1527009056770};\\\", \\\"{x:1213,y:824,t:1527009056786};\\\", \\\"{x:1212,y:824,t:1527009056803};\\\", \\\"{x:1210,y:824,t:1527009056819};\\\", \\\"{x:1208,y:824,t:1527009056836};\\\", \\\"{x:1206,y:824,t:1527009056853};\\\", \\\"{x:1205,y:824,t:1527009056869};\\\", \\\"{x:1202,y:824,t:1527009056886};\\\", \\\"{x:1202,y:826,t:1527009056903};\\\", \\\"{x:1202,y:828,t:1527009056919};\\\", \\\"{x:1202,y:831,t:1527009056936};\\\", \\\"{x:1202,y:832,t:1527009056953};\\\", \\\"{x:1202,y:834,t:1527009056970};\\\", \\\"{x:1202,y:835,t:1527009057017};\\\", \\\"{x:1203,y:835,t:1527009057065};\\\", \\\"{x:1204,y:835,t:1527009057089};\\\", \\\"{x:1206,y:835,t:1527009057105};\\\", \\\"{x:1208,y:835,t:1527009057129};\\\", \\\"{x:1209,y:835,t:1527009057194};\\\", \\\"{x:1211,y:835,t:1527009057202};\\\", \\\"{x:1213,y:835,t:1527009057219};\\\", \\\"{x:1215,y:835,t:1527009057236};\\\", \\\"{x:1216,y:834,t:1527009057602};\\\", \\\"{x:1222,y:834,t:1527009061531};\\\", \\\"{x:1236,y:837,t:1527009061539};\\\", \\\"{x:1265,y:839,t:1527009061552};\\\", \\\"{x:1349,y:853,t:1527009061567};\\\", \\\"{x:1449,y:866,t:1527009061585};\\\", \\\"{x:1591,y:893,t:1527009061602};\\\", \\\"{x:1630,y:912,t:1527009061618};\\\", \\\"{x:1644,y:922,t:1527009061634};\\\", \\\"{x:1646,y:933,t:1527009061652};\\\", \\\"{x:1646,y:940,t:1527009061668};\\\", \\\"{x:1644,y:943,t:1527009061685};\\\", \\\"{x:1637,y:946,t:1527009061702};\\\", \\\"{x:1632,y:947,t:1527009061717};\\\", \\\"{x:1630,y:947,t:1527009061735};\\\", \\\"{x:1629,y:948,t:1527009061777};\\\", \\\"{x:1627,y:948,t:1527009061793};\\\", \\\"{x:1626,y:948,t:1527009061801};\\\", \\\"{x:1619,y:950,t:1527009061817};\\\", \\\"{x:1607,y:953,t:1527009061834};\\\", \\\"{x:1588,y:954,t:1527009061852};\\\", \\\"{x:1565,y:954,t:1527009061867};\\\", \\\"{x:1537,y:954,t:1527009061884};\\\", \\\"{x:1510,y:955,t:1527009061901};\\\", \\\"{x:1488,y:955,t:1527009061917};\\\", \\\"{x:1478,y:957,t:1527009061934};\\\", \\\"{x:1477,y:958,t:1527009062026};\\\", \\\"{x:1477,y:959,t:1527009062049};\\\", \\\"{x:1477,y:960,t:1527009062058};\\\", \\\"{x:1477,y:961,t:1527009062073};\\\", \\\"{x:1477,y:962,t:1527009062084};\\\", \\\"{x:1477,y:964,t:1527009062101};\\\", \\\"{x:1477,y:967,t:1527009062118};\\\", \\\"{x:1477,y:971,t:1527009062134};\\\", \\\"{x:1477,y:973,t:1527009062151};\\\", \\\"{x:1477,y:976,t:1527009062167};\\\", \\\"{x:1477,y:977,t:1527009062184};\\\", \\\"{x:1475,y:979,t:1527009062201};\\\", \\\"{x:1475,y:980,t:1527009062225};\\\", \\\"{x:1474,y:980,t:1527009062257};\\\", \\\"{x:1473,y:980,t:1527009062322};\\\", \\\"{x:1472,y:980,t:1527009062335};\\\", \\\"{x:1471,y:980,t:1527009062353};\\\", \\\"{x:1470,y:980,t:1527009062367};\\\", \\\"{x:1468,y:980,t:1527009062384};\\\", \\\"{x:1465,y:980,t:1527009062400};\\\", \\\"{x:1459,y:978,t:1527009062418};\\\", \\\"{x:1458,y:978,t:1527009062434};\\\", \\\"{x:1458,y:977,t:1527009062450};\\\", \\\"{x:1457,y:977,t:1527009062467};\\\", \\\"{x:1456,y:977,t:1527009062485};\\\", \\\"{x:1456,y:976,t:1527009062553};\\\", \\\"{x:1455,y:975,t:1527009062569};\\\", \\\"{x:1454,y:974,t:1527009062585};\\\", \\\"{x:1453,y:974,t:1527009062600};\\\", \\\"{x:1453,y:973,t:1527009062617};\\\", \\\"{x:1452,y:973,t:1527009062634};\\\", \\\"{x:1451,y:971,t:1527009062651};\\\", \\\"{x:1450,y:969,t:1527009062682};\\\", \\\"{x:1450,y:968,t:1527009062842};\\\", \\\"{x:1450,y:969,t:1527009062961};\\\", \\\"{x:1450,y:970,t:1527009062976};\\\", \\\"{x:1449,y:971,t:1527009063009};\\\", \\\"{x:1448,y:971,t:1527009063025};\\\", \\\"{x:1447,y:971,t:1527009063034};\\\", \\\"{x:1446,y:971,t:1527009063050};\\\", \\\"{x:1444,y:971,t:1527009063067};\\\", \\\"{x:1442,y:971,t:1527009063084};\\\", \\\"{x:1437,y:971,t:1527009063100};\\\", \\\"{x:1433,y:971,t:1527009063117};\\\", \\\"{x:1429,y:971,t:1527009063135};\\\", \\\"{x:1426,y:971,t:1527009063150};\\\", \\\"{x:1424,y:971,t:1527009063167};\\\", \\\"{x:1423,y:971,t:1527009063184};\\\", \\\"{x:1422,y:971,t:1527009063306};\\\", \\\"{x:1421,y:971,t:1527009063345};\\\", \\\"{x:1420,y:971,t:1527009063361};\\\", \\\"{x:1419,y:971,t:1527009063378};\\\", \\\"{x:1418,y:971,t:1527009063394};\\\", \\\"{x:1417,y:971,t:1527009063401};\\\", \\\"{x:1416,y:971,t:1527009063417};\\\", \\\"{x:1414,y:971,t:1527009063433};\\\", \\\"{x:1413,y:971,t:1527009063505};\\\", \\\"{x:1412,y:971,t:1527009063517};\\\", \\\"{x:1412,y:970,t:1527009063705};\\\", \\\"{x:1412,y:969,t:1527009063721};\\\", \\\"{x:1410,y:967,t:1527009063733};\\\", \\\"{x:1405,y:962,t:1527009063750};\\\", \\\"{x:1391,y:954,t:1527009063767};\\\", \\\"{x:1369,y:945,t:1527009063784};\\\", \\\"{x:1334,y:929,t:1527009063800};\\\", \\\"{x:1272,y:910,t:1527009063817};\\\", \\\"{x:1244,y:902,t:1527009063833};\\\", \\\"{x:1220,y:894,t:1527009063851};\\\", \\\"{x:1204,y:887,t:1527009063867};\\\", \\\"{x:1198,y:885,t:1527009063883};\\\", \\\"{x:1197,y:884,t:1527009063900};\\\", \\\"{x:1195,y:884,t:1527009063918};\\\", \\\"{x:1195,y:882,t:1527009063933};\\\", \\\"{x:1195,y:880,t:1527009063950};\\\", \\\"{x:1194,y:875,t:1527009063967};\\\", \\\"{x:1194,y:868,t:1527009063983};\\\", \\\"{x:1194,y:863,t:1527009064000};\\\", \\\"{x:1195,y:855,t:1527009064017};\\\", \\\"{x:1198,y:849,t:1527009064033};\\\", \\\"{x:1203,y:842,t:1527009064050};\\\", \\\"{x:1210,y:836,t:1527009064067};\\\", \\\"{x:1218,y:830,t:1527009064083};\\\", \\\"{x:1225,y:826,t:1527009064101};\\\", \\\"{x:1227,y:825,t:1527009064116};\\\", \\\"{x:1228,y:825,t:1527009064133};\\\", \\\"{x:1229,y:825,t:1527009064586};\\\", \\\"{x:1230,y:828,t:1527009064601};\\\", \\\"{x:1235,y:836,t:1527009064616};\\\", \\\"{x:1242,y:854,t:1527009064633};\\\", \\\"{x:1248,y:870,t:1527009064650};\\\", \\\"{x:1253,y:886,t:1527009064666};\\\", \\\"{x:1258,y:902,t:1527009064684};\\\", \\\"{x:1264,y:916,t:1527009064701};\\\", \\\"{x:1266,y:927,t:1527009064717};\\\", \\\"{x:1270,y:933,t:1527009064733};\\\", \\\"{x:1272,y:938,t:1527009064750};\\\", \\\"{x:1274,y:943,t:1527009064766};\\\", \\\"{x:1276,y:946,t:1527009064783};\\\", \\\"{x:1277,y:951,t:1527009064800};\\\", \\\"{x:1279,y:959,t:1527009064817};\\\", \\\"{x:1281,y:966,t:1527009064833};\\\", \\\"{x:1283,y:971,t:1527009064850};\\\", \\\"{x:1283,y:972,t:1527009064866};\\\", \\\"{x:1284,y:973,t:1527009064884};\\\", \\\"{x:1283,y:973,t:1527009065393};\\\", \\\"{x:1282,y:972,t:1527009065401};\\\", \\\"{x:1281,y:970,t:1527009065416};\\\", \\\"{x:1278,y:960,t:1527009065433};\\\", \\\"{x:1274,y:949,t:1527009065449};\\\", \\\"{x:1267,y:938,t:1527009065466};\\\", \\\"{x:1264,y:928,t:1527009065483};\\\", \\\"{x:1261,y:922,t:1527009065500};\\\", \\\"{x:1258,y:916,t:1527009065516};\\\", \\\"{x:1256,y:913,t:1527009065534};\\\", \\\"{x:1253,y:909,t:1527009065549};\\\", \\\"{x:1250,y:903,t:1527009065566};\\\", \\\"{x:1245,y:895,t:1527009065583};\\\", \\\"{x:1243,y:890,t:1527009065599};\\\", \\\"{x:1239,y:881,t:1527009065616};\\\", \\\"{x:1233,y:873,t:1527009065633};\\\", \\\"{x:1232,y:870,t:1527009065649};\\\", \\\"{x:1231,y:866,t:1527009065666};\\\", \\\"{x:1228,y:862,t:1527009065684};\\\", \\\"{x:1228,y:859,t:1527009065699};\\\", \\\"{x:1225,y:854,t:1527009065716};\\\", \\\"{x:1223,y:848,t:1527009065733};\\\", \\\"{x:1221,y:844,t:1527009065749};\\\", \\\"{x:1220,y:840,t:1527009065767};\\\", \\\"{x:1219,y:838,t:1527009065783};\\\", \\\"{x:1217,y:836,t:1527009065799};\\\", \\\"{x:1217,y:834,t:1527009065866};\\\", \\\"{x:1217,y:833,t:1527009066081};\\\", \\\"{x:1217,y:832,t:1527009066090};\\\", \\\"{x:1217,y:831,t:1527009066113};\\\", \\\"{x:1216,y:831,t:1527009066121};\\\", \\\"{x:1217,y:832,t:1527009067330};\\\", \\\"{x:1219,y:833,t:1527009067337};\\\", \\\"{x:1224,y:836,t:1527009067349};\\\", \\\"{x:1231,y:839,t:1527009067366};\\\", \\\"{x:1240,y:844,t:1527009067383};\\\", \\\"{x:1254,y:851,t:1527009067400};\\\", \\\"{x:1272,y:860,t:1527009067416};\\\", \\\"{x:1296,y:868,t:1527009067432};\\\", \\\"{x:1336,y:881,t:1527009067449};\\\", \\\"{x:1357,y:887,t:1527009067466};\\\", \\\"{x:1374,y:894,t:1527009067483};\\\", \\\"{x:1389,y:899,t:1527009067500};\\\", \\\"{x:1393,y:901,t:1527009067515};\\\", \\\"{x:1394,y:901,t:1527009067532};\\\", \\\"{x:1396,y:902,t:1527009067554};\\\", \\\"{x:1397,y:904,t:1527009067570};\\\", \\\"{x:1397,y:906,t:1527009067585};\\\", \\\"{x:1398,y:908,t:1527009067599};\\\", \\\"{x:1400,y:910,t:1527009067615};\\\", \\\"{x:1401,y:913,t:1527009067633};\\\", \\\"{x:1401,y:914,t:1527009067649};\\\", \\\"{x:1403,y:917,t:1527009067665};\\\", \\\"{x:1404,y:918,t:1527009067683};\\\", \\\"{x:1404,y:919,t:1527009067699};\\\", \\\"{x:1406,y:922,t:1527009067715};\\\", \\\"{x:1406,y:923,t:1527009067745};\\\", \\\"{x:1406,y:924,t:1527009067793};\\\", \\\"{x:1406,y:925,t:1527009067817};\\\", \\\"{x:1401,y:925,t:1527009067832};\\\", \\\"{x:1386,y:925,t:1527009067848};\\\", \\\"{x:1335,y:909,t:1527009067865};\\\", \\\"{x:1298,y:897,t:1527009067883};\\\", \\\"{x:1273,y:891,t:1527009067899};\\\", \\\"{x:1249,y:883,t:1527009067915};\\\", \\\"{x:1236,y:879,t:1527009067933};\\\", \\\"{x:1231,y:876,t:1527009067949};\\\", \\\"{x:1230,y:875,t:1527009067966};\\\", \\\"{x:1230,y:873,t:1527009067982};\\\", \\\"{x:1230,y:871,t:1527009067998};\\\", \\\"{x:1230,y:869,t:1527009068015};\\\", \\\"{x:1229,y:865,t:1527009068033};\\\", \\\"{x:1227,y:858,t:1527009068049};\\\", \\\"{x:1225,y:846,t:1527009068065};\\\", \\\"{x:1225,y:842,t:1527009068083};\\\", \\\"{x:1225,y:838,t:1527009068098};\\\", \\\"{x:1225,y:837,t:1527009068116};\\\", \\\"{x:1225,y:836,t:1527009068132};\\\", \\\"{x:1225,y:835,t:1527009068169};\\\", \\\"{x:1225,y:834,t:1527009068186};\\\", \\\"{x:1225,y:833,t:1527009068217};\\\", \\\"{x:1224,y:833,t:1527009068233};\\\", \\\"{x:1223,y:833,t:1527009068298};\\\", \\\"{x:1222,y:833,t:1527009068330};\\\", \\\"{x:1221,y:833,t:1527009068338};\\\", \\\"{x:1220,y:833,t:1527009068350};\\\", \\\"{x:1217,y:833,t:1527009068366};\\\", \\\"{x:1216,y:833,t:1527009068383};\\\", \\\"{x:1215,y:832,t:1527009068402};\\\", \\\"{x:1219,y:837,t:1527009068859};\\\", \\\"{x:1225,y:844,t:1527009068866};\\\", \\\"{x:1246,y:870,t:1527009068882};\\\", \\\"{x:1270,y:900,t:1527009068899};\\\", \\\"{x:1295,y:928,t:1527009068916};\\\", \\\"{x:1317,y:945,t:1527009068932};\\\", \\\"{x:1331,y:955,t:1527009068950};\\\", \\\"{x:1339,y:960,t:1527009068965};\\\", \\\"{x:1343,y:963,t:1527009068982};\\\", \\\"{x:1344,y:964,t:1527009068999};\\\", \\\"{x:1345,y:964,t:1527009069025};\\\", \\\"{x:1346,y:964,t:1527009069033};\\\", \\\"{x:1348,y:960,t:1527009069049};\\\", \\\"{x:1353,y:954,t:1527009069065};\\\", \\\"{x:1355,y:954,t:1527009069081};\\\", \\\"{x:1359,y:953,t:1527009069098};\\\", \\\"{x:1362,y:953,t:1527009069115};\\\", \\\"{x:1367,y:953,t:1527009069132};\\\", \\\"{x:1371,y:953,t:1527009069149};\\\", \\\"{x:1374,y:953,t:1527009069166};\\\", \\\"{x:1376,y:953,t:1527009069181};\\\", \\\"{x:1378,y:954,t:1527009069199};\\\", \\\"{x:1381,y:955,t:1527009069216};\\\", \\\"{x:1383,y:956,t:1527009069232};\\\", \\\"{x:1384,y:956,t:1527009069249};\\\", \\\"{x:1389,y:957,t:1527009069266};\\\", \\\"{x:1391,y:958,t:1527009069282};\\\", \\\"{x:1392,y:959,t:1527009069299};\\\", \\\"{x:1393,y:960,t:1527009069322};\\\", \\\"{x:1394,y:960,t:1527009069353};\\\", \\\"{x:1396,y:960,t:1527009069570};\\\", \\\"{x:1397,y:960,t:1527009069586};\\\", \\\"{x:1400,y:960,t:1527009069599};\\\", \\\"{x:1401,y:960,t:1527009069618};\\\", \\\"{x:1402,y:960,t:1527009069633};\\\", \\\"{x:1406,y:960,t:1527009069650};\\\", \\\"{x:1407,y:960,t:1527009069665};\\\", \\\"{x:1408,y:960,t:1527009069682};\\\", \\\"{x:1409,y:960,t:1527009069699};\\\", \\\"{x:1410,y:960,t:1527009069786};\\\", \\\"{x:1410,y:959,t:1527009069802};\\\", \\\"{x:1409,y:956,t:1527009069815};\\\", \\\"{x:1406,y:951,t:1527009069832};\\\", \\\"{x:1401,y:941,t:1527009069849};\\\", \\\"{x:1397,y:933,t:1527009069865};\\\", \\\"{x:1388,y:916,t:1527009069881};\\\", \\\"{x:1384,y:908,t:1527009069898};\\\", \\\"{x:1380,y:898,t:1527009069914};\\\", \\\"{x:1375,y:886,t:1527009069931};\\\", \\\"{x:1371,y:875,t:1527009069948};\\\", \\\"{x:1367,y:863,t:1527009069964};\\\", \\\"{x:1361,y:850,t:1527009069982};\\\", \\\"{x:1357,y:838,t:1527009069999};\\\", \\\"{x:1352,y:824,t:1527009070014};\\\", \\\"{x:1347,y:809,t:1527009070032};\\\", \\\"{x:1344,y:794,t:1527009070049};\\\", \\\"{x:1339,y:773,t:1527009070065};\\\", \\\"{x:1327,y:742,t:1527009070081};\\\", \\\"{x:1311,y:712,t:1527009070098};\\\", \\\"{x:1279,y:676,t:1527009070114};\\\", \\\"{x:1234,y:623,t:1527009070131};\\\", \\\"{x:1164,y:576,t:1527009070148};\\\", \\\"{x:1074,y:541,t:1527009070164};\\\", \\\"{x:958,y:510,t:1527009070181};\\\", \\\"{x:836,y:491,t:1527009070198};\\\", \\\"{x:711,y:458,t:1527009070215};\\\", \\\"{x:589,y:418,t:1527009070231};\\\", \\\"{x:465,y:384,t:1527009070248};\\\", \\\"{x:349,y:360,t:1527009070265};\\\", \\\"{x:340,y:361,t:1527009070281};\\\", \\\"{x:337,y:365,t:1527009070297};\\\", \\\"{x:342,y:374,t:1527009070315};\\\", \\\"{x:346,y:379,t:1527009070331};\\\", \\\"{x:352,y:394,t:1527009070348};\\\", \\\"{x:359,y:411,t:1527009070364};\\\", \\\"{x:361,y:423,t:1527009070381};\\\", \\\"{x:362,y:437,t:1527009070398};\\\", \\\"{x:367,y:453,t:1527009070415};\\\", \\\"{x:373,y:465,t:1527009070432};\\\", \\\"{x:379,y:477,t:1527009070447};\\\", \\\"{x:384,y:490,t:1527009070465};\\\", \\\"{x:388,y:501,t:1527009070481};\\\", \\\"{x:388,y:505,t:1527009070497};\\\", \\\"{x:388,y:507,t:1527009070515};\\\", \\\"{x:387,y:509,t:1527009070532};\\\", \\\"{x:384,y:510,t:1527009070548};\\\", \\\"{x:376,y:512,t:1527009070562};\\\", \\\"{x:362,y:517,t:1527009070578};\\\", \\\"{x:337,y:524,t:1527009070594};\\\", \\\"{x:305,y:530,t:1527009070612};\\\", \\\"{x:276,y:538,t:1527009070629};\\\", \\\"{x:245,y:541,t:1527009070645};\\\", \\\"{x:215,y:544,t:1527009070662};\\\", \\\"{x:192,y:544,t:1527009070679};\\\", \\\"{x:178,y:545,t:1527009070694};\\\", \\\"{x:185,y:546,t:1527009070729};\\\", \\\"{x:194,y:546,t:1527009070745};\\\", \\\"{x:242,y:546,t:1527009070762};\\\", \\\"{x:279,y:546,t:1527009070779};\\\", \\\"{x:316,y:542,t:1527009070796};\\\", \\\"{x:360,y:536,t:1527009070811};\\\", \\\"{x:400,y:531,t:1527009070828};\\\", \\\"{x:419,y:527,t:1527009070845};\\\", \\\"{x:426,y:527,t:1527009070861};\\\", \\\"{x:424,y:527,t:1527009070953};\\\", \\\"{x:421,y:526,t:1527009070961};\\\", \\\"{x:418,y:525,t:1527009070979};\\\", \\\"{x:412,y:522,t:1527009070995};\\\", \\\"{x:410,y:522,t:1527009071011};\\\", \\\"{x:408,y:521,t:1527009071028};\\\", \\\"{x:405,y:520,t:1527009071046};\\\", \\\"{x:404,y:520,t:1527009071061};\\\", \\\"{x:401,y:520,t:1527009071078};\\\", \\\"{x:399,y:520,t:1527009071095};\\\", \\\"{x:396,y:520,t:1527009071111};\\\", \\\"{x:391,y:520,t:1527009071128};\\\", \\\"{x:390,y:520,t:1527009071145};\\\", \\\"{x:389,y:520,t:1527009071169};\\\", \\\"{x:388,y:520,t:1527009071257};\\\", \\\"{x:387,y:520,t:1527009071273};\\\", \\\"{x:387,y:520,t:1527009071278};\\\", \\\"{x:387,y:521,t:1527009071305};\\\", \\\"{x:390,y:524,t:1527009071321};\\\", \\\"{x:401,y:525,t:1527009071329};\\\", \\\"{x:442,y:530,t:1527009071346};\\\", \\\"{x:517,y:532,t:1527009071364};\\\", \\\"{x:601,y:532,t:1527009071378};\\\", \\\"{x:687,y:532,t:1527009071396};\\\", \\\"{x:751,y:532,t:1527009071414};\\\", \\\"{x:798,y:532,t:1527009071429};\\\", \\\"{x:827,y:532,t:1527009071446};\\\", \\\"{x:843,y:532,t:1527009071462};\\\", \\\"{x:847,y:532,t:1527009071479};\\\", \\\"{x:846,y:533,t:1527009071769};\\\", \\\"{x:844,y:534,t:1527009071785};\\\", \\\"{x:840,y:535,t:1527009071796};\\\", \\\"{x:832,y:539,t:1527009071813};\\\", \\\"{x:819,y:548,t:1527009071830};\\\", \\\"{x:796,y:560,t:1527009071845};\\\", \\\"{x:769,y:576,t:1527009071863};\\\", \\\"{x:740,y:590,t:1527009071880};\\\", \\\"{x:712,y:604,t:1527009071896};\\\", \\\"{x:681,y:619,t:1527009071913};\\\", \\\"{x:657,y:638,t:1527009071930};\\\", \\\"{x:648,y:649,t:1527009071945};\\\", \\\"{x:639,y:657,t:1527009071963};\\\", \\\"{x:636,y:661,t:1527009071980};\\\", \\\"{x:629,y:668,t:1527009071995};\\\", \\\"{x:621,y:671,t:1527009072013};\\\", \\\"{x:615,y:673,t:1527009072030};\\\", \\\"{x:611,y:675,t:1527009072047};\\\", \\\"{x:609,y:675,t:1527009072137};\\\", \\\"{x:609,y:676,t:1527009072169};\\\", \\\"{x:613,y:671,t:1527009072193};\\\", \\\"{x:616,y:664,t:1527009072202};\\\", \\\"{x:632,y:650,t:1527009072214};\\\", \\\"{x:667,y:623,t:1527009072230};\\\", \\\"{x:718,y:589,t:1527009072248};\\\", \\\"{x:775,y:565,t:1527009072264};\\\", \\\"{x:817,y:554,t:1527009072280};\\\", \\\"{x:838,y:546,t:1527009072297};\\\", \\\"{x:842,y:544,t:1527009072313};\\\", \\\"{x:842,y:543,t:1527009072330};\\\", \\\"{x:842,y:542,t:1527009072346};\\\", \\\"{x:842,y:541,t:1527009072362};\\\", \\\"{x:842,y:540,t:1527009072384};\\\", \\\"{x:842,y:539,t:1527009072395};\\\", \\\"{x:841,y:539,t:1527009072413};\\\", \\\"{x:840,y:539,t:1527009072433};\\\", \\\"{x:840,y:537,t:1527009072448};\\\", \\\"{x:840,y:536,t:1527009072462};\\\", \\\"{x:840,y:534,t:1527009072479};\\\", \\\"{x:837,y:531,t:1527009072497};\\\", \\\"{x:836,y:528,t:1527009072512};\\\", \\\"{x:835,y:527,t:1527009072530};\\\", \\\"{x:833,y:525,t:1527009072546};\\\", \\\"{x:832,y:525,t:1527009072641};\\\", \\\"{x:832,y:525,t:1527009072671};\\\", \\\"{x:830,y:525,t:1527009072713};\\\", \\\"{x:825,y:537,t:1527009072730};\\\", \\\"{x:809,y:562,t:1527009072746};\\\", \\\"{x:770,y:602,t:1527009072764};\\\", \\\"{x:718,y:636,t:1527009072780};\\\", \\\"{x:656,y:664,t:1527009072797};\\\", \\\"{x:598,y:683,t:1527009072813};\\\", \\\"{x:571,y:686,t:1527009072830};\\\", \\\"{x:551,y:688,t:1527009072847};\\\", \\\"{x:538,y:691,t:1527009072863};\\\", \\\"{x:536,y:692,t:1527009072880};\\\", \\\"{x:536,y:693,t:1527009072897};\\\", \\\"{x:536,y:694,t:1527009072913};\\\", \\\"{x:536,y:695,t:1527009072937};\\\", \\\"{x:536,y:696,t:1527009072947};\\\", \\\"{x:536,y:698,t:1527009072964};\\\", \\\"{x:534,y:699,t:1527009072980};\\\", \\\"{x:531,y:701,t:1527009072997};\\\", \\\"{x:528,y:704,t:1527009073014};\\\", \\\"{x:527,y:705,t:1527009073031};\\\", \\\"{x:524,y:707,t:1527009073047};\\\", \\\"{x:523,y:707,t:1527009073063};\\\", \\\"{x:523,y:708,t:1527009073089};\\\", \\\"{x:522,y:708,t:1527009073130};\\\", \\\"{x:522,y:710,t:1527009073137};\\\", \\\"{x:521,y:711,t:1527009073149};\\\", \\\"{x:520,y:712,t:1527009073164};\\\", \\\"{x:518,y:712,t:1527009073289};\\\", \\\"{x:516,y:712,t:1527009073305};\\\", \\\"{x:511,y:711,t:1527009073328};\\\", \\\"{x:502,y:709,t:1527009073346};\\\", \\\"{x:500,y:707,t:1527009073363};\\\", \\\"{x:498,y:702,t:1527009073381};\\\", \\\"{x:498,y:694,t:1527009073398};\\\", \\\"{x:504,y:675,t:1527009073413};\\\", \\\"{x:528,y:643,t:1527009073431};\\\", \\\"{x:557,y:604,t:1527009073447};\\\", \\\"{x:610,y:556,t:1527009073463};\\\", \\\"{x:700,y:506,t:1527009073480};\\\", \\\"{x:852,y:445,t:1527009073497};\\\", \\\"{x:954,y:417,t:1527009073513};\\\", \\\"{x:1059,y:391,t:1527009073530};\\\", \\\"{x:1157,y:374,t:1527009073547};\\\", \\\"{x:1232,y:363,t:1527009073564};\\\", \\\"{x:1280,y:355,t:1527009073581};\\\", \\\"{x:1299,y:353,t:1527009073598};\\\", \\\"{x:1307,y:351,t:1527009073614};\\\" ] }, { \\\"rt\\\": 70109, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 290807, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-G -06 PM-04 PM-04 PM-H -H -6-I -I -I -O -O -O -C -Z -U -U -U -U -F -H -A -09 AM-12 PM-11 AM-C -01 PM-A -O -04 PM-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1315,y:350,t:1527009075713};\\\", \\\"{x:1331,y:345,t:1527009075721};\\\", \\\"{x:1352,y:337,t:1527009075732};\\\", \\\"{x:1392,y:324,t:1527009075749};\\\", \\\"{x:1460,y:298,t:1527009075766};\\\", \\\"{x:1554,y:258,t:1527009075782};\\\", \\\"{x:1647,y:221,t:1527009075799};\\\", \\\"{x:1730,y:184,t:1527009075815};\\\", \\\"{x:1798,y:153,t:1527009075833};\\\", \\\"{x:1817,y:141,t:1527009075848};\\\", \\\"{x:1821,y:136,t:1527009075866};\\\", \\\"{x:1822,y:136,t:1527009075883};\\\", \\\"{x:1821,y:135,t:1527009075921};\\\", \\\"{x:1814,y:131,t:1527009075932};\\\", \\\"{x:1799,y:127,t:1527009075949};\\\", \\\"{x:1775,y:120,t:1527009075966};\\\", \\\"{x:1754,y:110,t:1527009075983};\\\", \\\"{x:1729,y:100,t:1527009075999};\\\", \\\"{x:1714,y:92,t:1527009076015};\\\", \\\"{x:1707,y:89,t:1527009076033};\\\", \\\"{x:1703,y:88,t:1527009076049};\\\", \\\"{x:1699,y:88,t:1527009076066};\\\", \\\"{x:1693,y:88,t:1527009076083};\\\", \\\"{x:1682,y:92,t:1527009076099};\\\", \\\"{x:1668,y:97,t:1527009076115};\\\", \\\"{x:1649,y:105,t:1527009076133};\\\", \\\"{x:1623,y:112,t:1527009076149};\\\", \\\"{x:1597,y:114,t:1527009076166};\\\", \\\"{x:1575,y:118,t:1527009076182};\\\", \\\"{x:1562,y:122,t:1527009076199};\\\", \\\"{x:1557,y:122,t:1527009076215};\\\", \\\"{x:1555,y:124,t:1527009076233};\\\", \\\"{x:1555,y:125,t:1527009076257};\\\", \\\"{x:1555,y:126,t:1527009076266};\\\", \\\"{x:1556,y:129,t:1527009076282};\\\", \\\"{x:1558,y:132,t:1527009076300};\\\", \\\"{x:1558,y:138,t:1527009076315};\\\", \\\"{x:1560,y:154,t:1527009076333};\\\", \\\"{x:1564,y:190,t:1527009076350};\\\", \\\"{x:1564,y:290,t:1527009076366};\\\", \\\"{x:1558,y:407,t:1527009076382};\\\", \\\"{x:1556,y:521,t:1527009076400};\\\", \\\"{x:1556,y:621,t:1527009076415};\\\", \\\"{x:1565,y:776,t:1527009076432};\\\", \\\"{x:1584,y:866,t:1527009076449};\\\", \\\"{x:1607,y:934,t:1527009076465};\\\", \\\"{x:1618,y:966,t:1527009076482};\\\", \\\"{x:1622,y:974,t:1527009076499};\\\", \\\"{x:1627,y:979,t:1527009076516};\\\", \\\"{x:1629,y:982,t:1527009076533};\\\", \\\"{x:1629,y:981,t:1527009076625};\\\", \\\"{x:1629,y:980,t:1527009076641};\\\", \\\"{x:1629,y:978,t:1527009076656};\\\", \\\"{x:1629,y:977,t:1527009076667};\\\", \\\"{x:1626,y:972,t:1527009076682};\\\", \\\"{x:1618,y:961,t:1527009076700};\\\", \\\"{x:1607,y:947,t:1527009076716};\\\", \\\"{x:1590,y:930,t:1527009076732};\\\", \\\"{x:1571,y:906,t:1527009076750};\\\", \\\"{x:1544,y:880,t:1527009076766};\\\", \\\"{x:1524,y:859,t:1527009076783};\\\", \\\"{x:1500,y:830,t:1527009076800};\\\", \\\"{x:1473,y:791,t:1527009076816};\\\", \\\"{x:1467,y:780,t:1527009076833};\\\", \\\"{x:1465,y:777,t:1527009076849};\\\", \\\"{x:1465,y:776,t:1527009076937};\\\", \\\"{x:1465,y:768,t:1527009077201};\\\", \\\"{x:1451,y:745,t:1527009077217};\\\", \\\"{x:1439,y:721,t:1527009077234};\\\", \\\"{x:1432,y:692,t:1527009077250};\\\", \\\"{x:1425,y:671,t:1527009077267};\\\", \\\"{x:1421,y:652,t:1527009077284};\\\", \\\"{x:1417,y:634,t:1527009077300};\\\", \\\"{x:1415,y:612,t:1527009077317};\\\", \\\"{x:1412,y:595,t:1527009077334};\\\", \\\"{x:1410,y:579,t:1527009077350};\\\", \\\"{x:1409,y:567,t:1527009077367};\\\", \\\"{x:1405,y:556,t:1527009077384};\\\", \\\"{x:1401,y:546,t:1527009077400};\\\", \\\"{x:1397,y:536,t:1527009077417};\\\", \\\"{x:1396,y:530,t:1527009077434};\\\", \\\"{x:1394,y:525,t:1527009077450};\\\", \\\"{x:1394,y:524,t:1527009077467};\\\", \\\"{x:1398,y:529,t:1527009077730};\\\", \\\"{x:1410,y:538,t:1527009077738};\\\", \\\"{x:1421,y:546,t:1527009077751};\\\", \\\"{x:1446,y:564,t:1527009077767};\\\", \\\"{x:1491,y:597,t:1527009077784};\\\", \\\"{x:1541,y:636,t:1527009077802};\\\", \\\"{x:1564,y:653,t:1527009077817};\\\", \\\"{x:1583,y:666,t:1527009077835};\\\", \\\"{x:1602,y:681,t:1527009077851};\\\", \\\"{x:1616,y:688,t:1527009077867};\\\", \\\"{x:1629,y:695,t:1527009077884};\\\", \\\"{x:1636,y:702,t:1527009077901};\\\", \\\"{x:1639,y:714,t:1527009077916};\\\", \\\"{x:1641,y:728,t:1527009077933};\\\", \\\"{x:1642,y:747,t:1527009077951};\\\", \\\"{x:1644,y:764,t:1527009077968};\\\", \\\"{x:1644,y:782,t:1527009077984};\\\", \\\"{x:1644,y:808,t:1527009078001};\\\", \\\"{x:1644,y:827,t:1527009078017};\\\", \\\"{x:1644,y:846,t:1527009078034};\\\", \\\"{x:1644,y:858,t:1527009078051};\\\", \\\"{x:1646,y:867,t:1527009078067};\\\", \\\"{x:1648,y:873,t:1527009078084};\\\", \\\"{x:1650,y:877,t:1527009078101};\\\", \\\"{x:1653,y:881,t:1527009078118};\\\", \\\"{x:1654,y:884,t:1527009078134};\\\", \\\"{x:1654,y:887,t:1527009078151};\\\", \\\"{x:1654,y:891,t:1527009078168};\\\", \\\"{x:1654,y:894,t:1527009078184};\\\", \\\"{x:1650,y:898,t:1527009078201};\\\", \\\"{x:1645,y:900,t:1527009078218};\\\", \\\"{x:1641,y:900,t:1527009078234};\\\", \\\"{x:1633,y:900,t:1527009078251};\\\", \\\"{x:1623,y:901,t:1527009078268};\\\", \\\"{x:1614,y:902,t:1527009078283};\\\", \\\"{x:1601,y:907,t:1527009078300};\\\", \\\"{x:1592,y:912,t:1527009078318};\\\", \\\"{x:1584,y:918,t:1527009078334};\\\", \\\"{x:1582,y:921,t:1527009078351};\\\", \\\"{x:1582,y:925,t:1527009078368};\\\", \\\"{x:1583,y:929,t:1527009078383};\\\", \\\"{x:1590,y:933,t:1527009078401};\\\", \\\"{x:1599,y:937,t:1527009078417};\\\", \\\"{x:1609,y:939,t:1527009078434};\\\", \\\"{x:1619,y:941,t:1527009078451};\\\", \\\"{x:1634,y:943,t:1527009078468};\\\", \\\"{x:1654,y:946,t:1527009078485};\\\", \\\"{x:1671,y:948,t:1527009078501};\\\", \\\"{x:1689,y:952,t:1527009078518};\\\", \\\"{x:1699,y:953,t:1527009078534};\\\", \\\"{x:1704,y:956,t:1527009078550};\\\", \\\"{x:1705,y:957,t:1527009078585};\\\", \\\"{x:1705,y:956,t:1527009078897};\\\", \\\"{x:1705,y:955,t:1527009078913};\\\", \\\"{x:1705,y:953,t:1527009078977};\\\", \\\"{x:1707,y:953,t:1527009079097};\\\", \\\"{x:1709,y:953,t:1527009079104};\\\", \\\"{x:1712,y:953,t:1527009079118};\\\", \\\"{x:1717,y:953,t:1527009079135};\\\", \\\"{x:1724,y:956,t:1527009079152};\\\", \\\"{x:1735,y:961,t:1527009079168};\\\", \\\"{x:1741,y:966,t:1527009079185};\\\", \\\"{x:1744,y:968,t:1527009079201};\\\", \\\"{x:1745,y:969,t:1527009079218};\\\", \\\"{x:1746,y:969,t:1527009079305};\\\", \\\"{x:1747,y:969,t:1527009079318};\\\", \\\"{x:1749,y:968,t:1527009079337};\\\", \\\"{x:1749,y:966,t:1527009079369};\\\", \\\"{x:1749,y:963,t:1527009079385};\\\", \\\"{x:1749,y:957,t:1527009079402};\\\", \\\"{x:1745,y:947,t:1527009079418};\\\", \\\"{x:1741,y:926,t:1527009079435};\\\", \\\"{x:1727,y:900,t:1527009079452};\\\", \\\"{x:1715,y:862,t:1527009079468};\\\", \\\"{x:1696,y:804,t:1527009079485};\\\", \\\"{x:1666,y:722,t:1527009079502};\\\", \\\"{x:1624,y:648,t:1527009079518};\\\", \\\"{x:1592,y:596,t:1527009079535};\\\", \\\"{x:1576,y:566,t:1527009079552};\\\", \\\"{x:1571,y:539,t:1527009079569};\\\", \\\"{x:1571,y:538,t:1527009079585};\\\", \\\"{x:1576,y:540,t:1527009079713};\\\", \\\"{x:1581,y:548,t:1527009079721};\\\", \\\"{x:1586,y:553,t:1527009079735};\\\", \\\"{x:1604,y:564,t:1527009079752};\\\", \\\"{x:1635,y:578,t:1527009079768};\\\", \\\"{x:1654,y:586,t:1527009079785};\\\", \\\"{x:1668,y:590,t:1527009079802};\\\", \\\"{x:1676,y:591,t:1527009079819};\\\", \\\"{x:1677,y:591,t:1527009079835};\\\", \\\"{x:1678,y:589,t:1527009079865};\\\", \\\"{x:1678,y:585,t:1527009079872};\\\", \\\"{x:1678,y:579,t:1527009079885};\\\", \\\"{x:1670,y:554,t:1527009079902};\\\", \\\"{x:1656,y:525,t:1527009079919};\\\", \\\"{x:1648,y:501,t:1527009079935};\\\", \\\"{x:1640,y:485,t:1527009079952};\\\", \\\"{x:1630,y:464,t:1527009079969};\\\", \\\"{x:1628,y:453,t:1527009079985};\\\", \\\"{x:1627,y:444,t:1527009080002};\\\", \\\"{x:1627,y:441,t:1527009080019};\\\", \\\"{x:1627,y:440,t:1527009080041};\\\", \\\"{x:1627,y:439,t:1527009080065};\\\", \\\"{x:1628,y:439,t:1527009080130};\\\", \\\"{x:1630,y:439,t:1527009080138};\\\", \\\"{x:1635,y:443,t:1527009080152};\\\", \\\"{x:1644,y:453,t:1527009080170};\\\", \\\"{x:1649,y:460,t:1527009080185};\\\", \\\"{x:1653,y:467,t:1527009080203};\\\", \\\"{x:1655,y:471,t:1527009080219};\\\", \\\"{x:1655,y:472,t:1527009080249};\\\", \\\"{x:1652,y:471,t:1527009080385};\\\", \\\"{x:1651,y:471,t:1527009080393};\\\", \\\"{x:1648,y:469,t:1527009080402};\\\", \\\"{x:1644,y:466,t:1527009080419};\\\", \\\"{x:1639,y:463,t:1527009080436};\\\", \\\"{x:1635,y:461,t:1527009080452};\\\", \\\"{x:1634,y:460,t:1527009080469};\\\", \\\"{x:1636,y:460,t:1527009080529};\\\", \\\"{x:1638,y:462,t:1527009080537};\\\", \\\"{x:1641,y:468,t:1527009080552};\\\", \\\"{x:1652,y:493,t:1527009080569};\\\", \\\"{x:1665,y:528,t:1527009080587};\\\", \\\"{x:1691,y:592,t:1527009080603};\\\", \\\"{x:1720,y:663,t:1527009080619};\\\", \\\"{x:1755,y:733,t:1527009080637};\\\", \\\"{x:1783,y:789,t:1527009080653};\\\", \\\"{x:1802,y:824,t:1527009080670};\\\", \\\"{x:1813,y:840,t:1527009080687};\\\", \\\"{x:1815,y:846,t:1527009080704};\\\", \\\"{x:1819,y:858,t:1527009080719};\\\", \\\"{x:1823,y:870,t:1527009080737};\\\", \\\"{x:1826,y:876,t:1527009080754};\\\", \\\"{x:1828,y:878,t:1527009080769};\\\", \\\"{x:1829,y:879,t:1527009080787};\\\", \\\"{x:1831,y:880,t:1527009080803};\\\", \\\"{x:1833,y:882,t:1527009080820};\\\", \\\"{x:1834,y:883,t:1527009080841};\\\", \\\"{x:1835,y:884,t:1527009080857};\\\", \\\"{x:1836,y:885,t:1527009080869};\\\", \\\"{x:1837,y:886,t:1527009080889};\\\", \\\"{x:1838,y:887,t:1527009080903};\\\", \\\"{x:1838,y:888,t:1527009080969};\\\", \\\"{x:1833,y:891,t:1527009080986};\\\", \\\"{x:1822,y:893,t:1527009081003};\\\", \\\"{x:1808,y:896,t:1527009081020};\\\", \\\"{x:1797,y:896,t:1527009081036};\\\", \\\"{x:1792,y:896,t:1527009081053};\\\", \\\"{x:1777,y:896,t:1527009081070};\\\", \\\"{x:1758,y:896,t:1527009081086};\\\", \\\"{x:1749,y:896,t:1527009081103};\\\", \\\"{x:1731,y:900,t:1527009081120};\\\", \\\"{x:1723,y:903,t:1527009081136};\\\", \\\"{x:1721,y:903,t:1527009081154};\\\", \\\"{x:1721,y:905,t:1527009081362};\\\", \\\"{x:1720,y:906,t:1527009081370};\\\", \\\"{x:1719,y:906,t:1527009081418};\\\", \\\"{x:1717,y:907,t:1527009081426};\\\", \\\"{x:1717,y:908,t:1527009081437};\\\", \\\"{x:1715,y:908,t:1527009081454};\\\", \\\"{x:1712,y:907,t:1527009081471};\\\", \\\"{x:1711,y:907,t:1527009081514};\\\", \\\"{x:1709,y:907,t:1527009081539};\\\", \\\"{x:1707,y:906,t:1527009081553};\\\", \\\"{x:1704,y:905,t:1527009081571};\\\", \\\"{x:1702,y:905,t:1527009081588};\\\", \\\"{x:1697,y:905,t:1527009081604};\\\", \\\"{x:1695,y:904,t:1527009081621};\\\", \\\"{x:1685,y:904,t:1527009081638};\\\", \\\"{x:1679,y:906,t:1527009081654};\\\", \\\"{x:1674,y:909,t:1527009081670};\\\", \\\"{x:1673,y:909,t:1527009081687};\\\", \\\"{x:1672,y:910,t:1527009081704};\\\", \\\"{x:1670,y:911,t:1527009081720};\\\", \\\"{x:1669,y:913,t:1527009081746};\\\", \\\"{x:1668,y:915,t:1527009081753};\\\", \\\"{x:1666,y:920,t:1527009081770};\\\", \\\"{x:1663,y:932,t:1527009081788};\\\", \\\"{x:1660,y:942,t:1527009081803};\\\", \\\"{x:1652,y:952,t:1527009081821};\\\", \\\"{x:1646,y:959,t:1527009081838};\\\", \\\"{x:1639,y:963,t:1527009081854};\\\", \\\"{x:1634,y:966,t:1527009081871};\\\", \\\"{x:1628,y:971,t:1527009081887};\\\", \\\"{x:1623,y:974,t:1527009081903};\\\", \\\"{x:1614,y:979,t:1527009081920};\\\", \\\"{x:1607,y:981,t:1527009081937};\\\", \\\"{x:1604,y:981,t:1527009081954};\\\", \\\"{x:1603,y:981,t:1527009081970};\\\", \\\"{x:1604,y:978,t:1527009082017};\\\", \\\"{x:1606,y:975,t:1527009082024};\\\", \\\"{x:1608,y:973,t:1527009082037};\\\", \\\"{x:1612,y:969,t:1527009082054};\\\", \\\"{x:1614,y:966,t:1527009082070};\\\", \\\"{x:1615,y:966,t:1527009082087};\\\", \\\"{x:1616,y:965,t:1527009082177};\\\", \\\"{x:1617,y:964,t:1527009082194};\\\", \\\"{x:1618,y:964,t:1527009082209};\\\", \\\"{x:1619,y:963,t:1527009082266};\\\", \\\"{x:1618,y:963,t:1527009082649};\\\", \\\"{x:1617,y:962,t:1527009082664};\\\", \\\"{x:1616,y:962,t:1527009082689};\\\", \\\"{x:1615,y:961,t:1527009082704};\\\", \\\"{x:1614,y:961,t:1527009082753};\\\", \\\"{x:1613,y:961,t:1527009082785};\\\", \\\"{x:1612,y:960,t:1527009083145};\\\", \\\"{x:1610,y:958,t:1527009083761};\\\", \\\"{x:1609,y:957,t:1527009083771};\\\", \\\"{x:1608,y:954,t:1527009083788};\\\", \\\"{x:1607,y:951,t:1527009083805};\\\", \\\"{x:1606,y:946,t:1527009083821};\\\", \\\"{x:1605,y:943,t:1527009083839};\\\", \\\"{x:1604,y:936,t:1527009083855};\\\", \\\"{x:1603,y:931,t:1527009083872};\\\", \\\"{x:1600,y:924,t:1527009083888};\\\", \\\"{x:1597,y:919,t:1527009083905};\\\", \\\"{x:1596,y:916,t:1527009083923};\\\", \\\"{x:1596,y:914,t:1527009083938};\\\", \\\"{x:1595,y:913,t:1527009083955};\\\", \\\"{x:1595,y:912,t:1527009083976};\\\", \\\"{x:1595,y:911,t:1527009083993};\\\", \\\"{x:1595,y:910,t:1527009084005};\\\", \\\"{x:1595,y:908,t:1527009084022};\\\", \\\"{x:1594,y:905,t:1527009084038};\\\", \\\"{x:1594,y:903,t:1527009084055};\\\", \\\"{x:1593,y:901,t:1527009084072};\\\", \\\"{x:1593,y:899,t:1527009084088};\\\", \\\"{x:1593,y:895,t:1527009084105};\\\", \\\"{x:1593,y:894,t:1527009084122};\\\", \\\"{x:1593,y:892,t:1527009084139};\\\", \\\"{x:1594,y:892,t:1527009084257};\\\", \\\"{x:1596,y:893,t:1527009084272};\\\", \\\"{x:1603,y:899,t:1527009084288};\\\", \\\"{x:1619,y:917,t:1527009084305};\\\", \\\"{x:1627,y:930,t:1527009084322};\\\", \\\"{x:1634,y:943,t:1527009084339};\\\", \\\"{x:1640,y:956,t:1527009084355};\\\", \\\"{x:1646,y:967,t:1527009084372};\\\", \\\"{x:1649,y:972,t:1527009084389};\\\", \\\"{x:1649,y:978,t:1527009084405};\\\", \\\"{x:1649,y:982,t:1527009084422};\\\", \\\"{x:1649,y:984,t:1527009084440};\\\", \\\"{x:1649,y:986,t:1527009084455};\\\", \\\"{x:1649,y:988,t:1527009084473};\\\", \\\"{x:1648,y:988,t:1527009084545};\\\", \\\"{x:1647,y:988,t:1527009084561};\\\", \\\"{x:1646,y:988,t:1527009084572};\\\", \\\"{x:1643,y:987,t:1527009084590};\\\", \\\"{x:1642,y:986,t:1527009084605};\\\", \\\"{x:1641,y:986,t:1527009084622};\\\", \\\"{x:1640,y:985,t:1527009084639};\\\", \\\"{x:1639,y:984,t:1527009084673};\\\", \\\"{x:1638,y:983,t:1527009084698};\\\", \\\"{x:1638,y:982,t:1527009084705};\\\", \\\"{x:1636,y:978,t:1527009084723};\\\", \\\"{x:1635,y:977,t:1527009084740};\\\", \\\"{x:1631,y:975,t:1527009084756};\\\", \\\"{x:1628,y:974,t:1527009084772};\\\", \\\"{x:1623,y:972,t:1527009084789};\\\", \\\"{x:1620,y:971,t:1527009084806};\\\", \\\"{x:1617,y:970,t:1527009084822};\\\", \\\"{x:1617,y:969,t:1527009084839};\\\", \\\"{x:1615,y:968,t:1527009084857};\\\", \\\"{x:1614,y:968,t:1527009084881};\\\", \\\"{x:1613,y:967,t:1527009084890};\\\", \\\"{x:1613,y:966,t:1527009084921};\\\", \\\"{x:1612,y:965,t:1527009085026};\\\", \\\"{x:1611,y:965,t:1527009085058};\\\", \\\"{x:1610,y:965,t:1527009085072};\\\", \\\"{x:1610,y:962,t:1527009085089};\\\", \\\"{x:1608,y:959,t:1527009085107};\\\", \\\"{x:1608,y:956,t:1527009085123};\\\", \\\"{x:1608,y:952,t:1527009085139};\\\", \\\"{x:1607,y:951,t:1527009085157};\\\", \\\"{x:1607,y:950,t:1527009085282};\\\", \\\"{x:1607,y:949,t:1527009085290};\\\", \\\"{x:1607,y:948,t:1527009085306};\\\", \\\"{x:1605,y:945,t:1527009085324};\\\", \\\"{x:1605,y:942,t:1527009085339};\\\", \\\"{x:1604,y:940,t:1527009085356};\\\", \\\"{x:1603,y:938,t:1527009085373};\\\", \\\"{x:1603,y:936,t:1527009085489};\\\", \\\"{x:1602,y:935,t:1527009085506};\\\", \\\"{x:1601,y:931,t:1527009085523};\\\", \\\"{x:1600,y:928,t:1527009085540};\\\", \\\"{x:1598,y:926,t:1527009085556};\\\", \\\"{x:1597,y:924,t:1527009085573};\\\", \\\"{x:1597,y:923,t:1527009085589};\\\", \\\"{x:1596,y:922,t:1527009085642};\\\", \\\"{x:1595,y:922,t:1527009085673};\\\", \\\"{x:1595,y:921,t:1527009085705};\\\", \\\"{x:1594,y:920,t:1527009085713};\\\", \\\"{x:1594,y:919,t:1527009085729};\\\", \\\"{x:1594,y:917,t:1527009085740};\\\", \\\"{x:1592,y:915,t:1527009085756};\\\", \\\"{x:1592,y:912,t:1527009085773};\\\", \\\"{x:1591,y:911,t:1527009085790};\\\", \\\"{x:1591,y:910,t:1527009085806};\\\", \\\"{x:1591,y:909,t:1527009085930};\\\", \\\"{x:1591,y:907,t:1527009085946};\\\", \\\"{x:1590,y:905,t:1527009085961};\\\", \\\"{x:1590,y:904,t:1527009085978};\\\", \\\"{x:1589,y:902,t:1527009085991};\\\", \\\"{x:1588,y:902,t:1527009086006};\\\", \\\"{x:1588,y:901,t:1527009086034};\\\", \\\"{x:1588,y:899,t:1527009086082};\\\", \\\"{x:1587,y:899,t:1527009086105};\\\", \\\"{x:1586,y:897,t:1527009086120};\\\", \\\"{x:1585,y:896,t:1527009086137};\\\", \\\"{x:1585,y:894,t:1527009086153};\\\", \\\"{x:1585,y:893,t:1527009086168};\\\", \\\"{x:1584,y:893,t:1527009086177};\\\", \\\"{x:1584,y:891,t:1527009086190};\\\", \\\"{x:1584,y:890,t:1527009086208};\\\", \\\"{x:1583,y:890,t:1527009086249};\\\", \\\"{x:1583,y:889,t:1527009086257};\\\", \\\"{x:1582,y:888,t:1527009086273};\\\", \\\"{x:1582,y:887,t:1527009086297};\\\", \\\"{x:1581,y:886,t:1527009086307};\\\", \\\"{x:1580,y:884,t:1527009086323};\\\", \\\"{x:1579,y:883,t:1527009086340};\\\", \\\"{x:1579,y:881,t:1527009086362};\\\", \\\"{x:1578,y:881,t:1527009086378};\\\", \\\"{x:1577,y:879,t:1527009086394};\\\", \\\"{x:1576,y:878,t:1527009086418};\\\", \\\"{x:1576,y:877,t:1527009086450};\\\", \\\"{x:1576,y:876,t:1527009086458};\\\", \\\"{x:1575,y:875,t:1527009086474};\\\", \\\"{x:1574,y:874,t:1527009086497};\\\", \\\"{x:1573,y:873,t:1527009086513};\\\", \\\"{x:1572,y:872,t:1527009086530};\\\", \\\"{x:1572,y:870,t:1527009086561};\\\", \\\"{x:1572,y:868,t:1527009086574};\\\", \\\"{x:1570,y:867,t:1527009086591};\\\", \\\"{x:1570,y:866,t:1527009086608};\\\", \\\"{x:1569,y:865,t:1527009086626};\\\", \\\"{x:1569,y:864,t:1527009086640};\\\", \\\"{x:1569,y:862,t:1527009086658};\\\", \\\"{x:1567,y:860,t:1527009086674};\\\", \\\"{x:1566,y:859,t:1527009086691};\\\", \\\"{x:1564,y:855,t:1527009086708};\\\", \\\"{x:1564,y:854,t:1527009086725};\\\", \\\"{x:1563,y:853,t:1527009086741};\\\", \\\"{x:1562,y:850,t:1527009086757};\\\", \\\"{x:1560,y:846,t:1527009086775};\\\", \\\"{x:1556,y:841,t:1527009086791};\\\", \\\"{x:1553,y:838,t:1527009086808};\\\", \\\"{x:1551,y:836,t:1527009086824};\\\", \\\"{x:1549,y:834,t:1527009086841};\\\", \\\"{x:1545,y:831,t:1527009086856};\\\", \\\"{x:1543,y:829,t:1527009086874};\\\", \\\"{x:1539,y:827,t:1527009086890};\\\", \\\"{x:1537,y:824,t:1527009086908};\\\", \\\"{x:1534,y:820,t:1527009086924};\\\", \\\"{x:1534,y:817,t:1527009086941};\\\", \\\"{x:1531,y:813,t:1527009086957};\\\", \\\"{x:1530,y:810,t:1527009086975};\\\", \\\"{x:1528,y:808,t:1527009086991};\\\", \\\"{x:1527,y:804,t:1527009087008};\\\", \\\"{x:1525,y:801,t:1527009087024};\\\", \\\"{x:1523,y:796,t:1527009087040};\\\", \\\"{x:1521,y:791,t:1527009087057};\\\", \\\"{x:1520,y:788,t:1527009087074};\\\", \\\"{x:1518,y:784,t:1527009087090};\\\", \\\"{x:1517,y:782,t:1527009087107};\\\", \\\"{x:1517,y:781,t:1527009087124};\\\", \\\"{x:1514,y:777,t:1527009087140};\\\", \\\"{x:1513,y:774,t:1527009087158};\\\", \\\"{x:1512,y:768,t:1527009087174};\\\", \\\"{x:1510,y:763,t:1527009087192};\\\", \\\"{x:1508,y:758,t:1527009087207};\\\", \\\"{x:1506,y:754,t:1527009087224};\\\", \\\"{x:1503,y:747,t:1527009087241};\\\", \\\"{x:1502,y:745,t:1527009087257};\\\", \\\"{x:1500,y:742,t:1527009087274};\\\", \\\"{x:1497,y:737,t:1527009087291};\\\", \\\"{x:1495,y:733,t:1527009087307};\\\", \\\"{x:1493,y:729,t:1527009087324};\\\", \\\"{x:1490,y:725,t:1527009087341};\\\", \\\"{x:1488,y:723,t:1527009087357};\\\", \\\"{x:1485,y:718,t:1527009087375};\\\", \\\"{x:1483,y:715,t:1527009087391};\\\", \\\"{x:1481,y:712,t:1527009087407};\\\", \\\"{x:1479,y:709,t:1527009087425};\\\", \\\"{x:1475,y:703,t:1527009087441};\\\", \\\"{x:1472,y:695,t:1527009087457};\\\", \\\"{x:1468,y:685,t:1527009087475};\\\", \\\"{x:1462,y:671,t:1527009087492};\\\", \\\"{x:1457,y:661,t:1527009087507};\\\", \\\"{x:1453,y:654,t:1527009087525};\\\", \\\"{x:1451,y:647,t:1527009087542};\\\", \\\"{x:1447,y:641,t:1527009087558};\\\", \\\"{x:1444,y:637,t:1527009087574};\\\", \\\"{x:1441,y:630,t:1527009087591};\\\", \\\"{x:1437,y:621,t:1527009087608};\\\", \\\"{x:1435,y:614,t:1527009087625};\\\", \\\"{x:1428,y:599,t:1527009087641};\\\", \\\"{x:1426,y:592,t:1527009087658};\\\", \\\"{x:1423,y:588,t:1527009087675};\\\", \\\"{x:1419,y:582,t:1527009087691};\\\", \\\"{x:1419,y:580,t:1527009087709};\\\", \\\"{x:1418,y:578,t:1527009087725};\\\", \\\"{x:1417,y:577,t:1527009087742};\\\", \\\"{x:1416,y:575,t:1527009087758};\\\", \\\"{x:1415,y:573,t:1527009087774};\\\", \\\"{x:1413,y:571,t:1527009087791};\\\", \\\"{x:1411,y:566,t:1527009087809};\\\", \\\"{x:1408,y:559,t:1527009087825};\\\", \\\"{x:1405,y:553,t:1527009087841};\\\", \\\"{x:1403,y:548,t:1527009087859};\\\", \\\"{x:1400,y:543,t:1527009087874};\\\", \\\"{x:1396,y:538,t:1527009087892};\\\", \\\"{x:1395,y:536,t:1527009087909};\\\", \\\"{x:1393,y:533,t:1527009087924};\\\", \\\"{x:1392,y:532,t:1527009087941};\\\", \\\"{x:1391,y:530,t:1527009087958};\\\", \\\"{x:1391,y:529,t:1527009087974};\\\", \\\"{x:1390,y:529,t:1527009087993};\\\", \\\"{x:1394,y:535,t:1527009088210};\\\", \\\"{x:1403,y:545,t:1527009088225};\\\", \\\"{x:1426,y:571,t:1527009088242};\\\", \\\"{x:1432,y:577,t:1527009088259};\\\", \\\"{x:1438,y:582,t:1527009088276};\\\", \\\"{x:1441,y:585,t:1527009088291};\\\", \\\"{x:1442,y:586,t:1527009088309};\\\", \\\"{x:1440,y:586,t:1527009088417};\\\", \\\"{x:1437,y:586,t:1527009088425};\\\", \\\"{x:1431,y:583,t:1527009088441};\\\", \\\"{x:1423,y:580,t:1527009088459};\\\", \\\"{x:1416,y:575,t:1527009088476};\\\", \\\"{x:1414,y:573,t:1527009088492};\\\", \\\"{x:1413,y:571,t:1527009088508};\\\", \\\"{x:1412,y:569,t:1527009088526};\\\", \\\"{x:1412,y:567,t:1527009088542};\\\", \\\"{x:1412,y:566,t:1527009088559};\\\", \\\"{x:1412,y:565,t:1527009088577};\\\", \\\"{x:1412,y:563,t:1527009088737};\\\", \\\"{x:1412,y:562,t:1527009088753};\\\", \\\"{x:1412,y:561,t:1527009088761};\\\", \\\"{x:1412,y:560,t:1527009088777};\\\", \\\"{x:1405,y:560,t:1527009089242};\\\", \\\"{x:1387,y:567,t:1527009089248};\\\", \\\"{x:1361,y:575,t:1527009089259};\\\", \\\"{x:1276,y:595,t:1527009089275};\\\", \\\"{x:1185,y:607,t:1527009089292};\\\", \\\"{x:1090,y:622,t:1527009089309};\\\", \\\"{x:985,y:634,t:1527009089325};\\\", \\\"{x:896,y:636,t:1527009089342};\\\", \\\"{x:815,y:636,t:1527009089360};\\\", \\\"{x:748,y:638,t:1527009089375};\\\", \\\"{x:711,y:638,t:1527009089393};\\\", \\\"{x:691,y:638,t:1527009089409};\\\", \\\"{x:690,y:638,t:1527009089425};\\\", \\\"{x:689,y:638,t:1527009089449};\\\", \\\"{x:689,y:639,t:1527009089460};\\\", \\\"{x:688,y:640,t:1527009089513};\\\", \\\"{x:687,y:640,t:1527009089527};\\\", \\\"{x:680,y:639,t:1527009089545};\\\", \\\"{x:671,y:631,t:1527009089560};\\\", \\\"{x:656,y:609,t:1527009089578};\\\", \\\"{x:648,y:590,t:1527009089594};\\\", \\\"{x:639,y:574,t:1527009089611};\\\", \\\"{x:635,y:566,t:1527009089627};\\\", \\\"{x:633,y:563,t:1527009089645};\\\", \\\"{x:632,y:561,t:1527009089660};\\\", \\\"{x:631,y:561,t:1527009089697};\\\", \\\"{x:629,y:561,t:1527009089710};\\\", \\\"{x:628,y:561,t:1527009089728};\\\", \\\"{x:627,y:560,t:1527009089745};\\\", \\\"{x:629,y:560,t:1527009090032};\\\", \\\"{x:634,y:560,t:1527009090044};\\\", \\\"{x:651,y:560,t:1527009090061};\\\", \\\"{x:685,y:560,t:1527009090077};\\\", \\\"{x:766,y:560,t:1527009090094};\\\", \\\"{x:863,y:560,t:1527009090112};\\\", \\\"{x:966,y:560,t:1527009090127};\\\", \\\"{x:1063,y:560,t:1527009090144};\\\", \\\"{x:1185,y:560,t:1527009090160};\\\", \\\"{x:1249,y:560,t:1527009090177};\\\", \\\"{x:1294,y:560,t:1527009090194};\\\", \\\"{x:1326,y:560,t:1527009090211};\\\", \\\"{x:1346,y:557,t:1527009090227};\\\", \\\"{x:1355,y:554,t:1527009090245};\\\", \\\"{x:1356,y:553,t:1527009090261};\\\", \\\"{x:1357,y:553,t:1527009090277};\\\", \\\"{x:1358,y:553,t:1527009090313};\\\", \\\"{x:1358,y:552,t:1527009090329};\\\", \\\"{x:1359,y:551,t:1527009090344};\\\", \\\"{x:1363,y:540,t:1527009090360};\\\", \\\"{x:1364,y:531,t:1527009090377};\\\", \\\"{x:1367,y:522,t:1527009090395};\\\", \\\"{x:1367,y:517,t:1527009090411};\\\", \\\"{x:1367,y:512,t:1527009090427};\\\", \\\"{x:1365,y:506,t:1527009090444};\\\", \\\"{x:1360,y:500,t:1527009090461};\\\", \\\"{x:1358,y:498,t:1527009090477};\\\", \\\"{x:1355,y:496,t:1527009090495};\\\", \\\"{x:1353,y:496,t:1527009090512};\\\", \\\"{x:1350,y:494,t:1527009090528};\\\", \\\"{x:1342,y:494,t:1527009090544};\\\", \\\"{x:1334,y:494,t:1527009090560};\\\", \\\"{x:1326,y:494,t:1527009090578};\\\", \\\"{x:1317,y:494,t:1527009090595};\\\", \\\"{x:1311,y:494,t:1527009090610};\\\", \\\"{x:1306,y:494,t:1527009090627};\\\", \\\"{x:1304,y:494,t:1527009090644};\\\", \\\"{x:1302,y:494,t:1527009090661};\\\", \\\"{x:1303,y:494,t:1527009090890};\\\", \\\"{x:1304,y:494,t:1527009090897};\\\", \\\"{x:1307,y:494,t:1527009090910};\\\", \\\"{x:1308,y:495,t:1527009090927};\\\", \\\"{x:1314,y:495,t:1527009090945};\\\", \\\"{x:1319,y:496,t:1527009090961};\\\", \\\"{x:1321,y:497,t:1527009090979};\\\", \\\"{x:1319,y:497,t:1527009091249};\\\", \\\"{x:1318,y:497,t:1527009091297};\\\", \\\"{x:1317,y:497,t:1527009092257};\\\", \\\"{x:1316,y:497,t:1527009092377};\\\", \\\"{x:1315,y:497,t:1527009092880};\\\", \\\"{x:1315,y:502,t:1527009093290};\\\", \\\"{x:1315,y:506,t:1527009093304};\\\", \\\"{x:1312,y:519,t:1527009093319};\\\", \\\"{x:1310,y:536,t:1527009093336};\\\", \\\"{x:1309,y:556,t:1527009093353};\\\", \\\"{x:1309,y:569,t:1527009093369};\\\", \\\"{x:1307,y:581,t:1527009093386};\\\", \\\"{x:1306,y:585,t:1527009093403};\\\", \\\"{x:1304,y:589,t:1527009093419};\\\", \\\"{x:1301,y:593,t:1527009093436};\\\", \\\"{x:1297,y:599,t:1527009093453};\\\", \\\"{x:1290,y:606,t:1527009093469};\\\", \\\"{x:1283,y:611,t:1527009093486};\\\", \\\"{x:1276,y:617,t:1527009093503};\\\", \\\"{x:1272,y:619,t:1527009093520};\\\", \\\"{x:1270,y:619,t:1527009093536};\\\", \\\"{x:1267,y:621,t:1527009093553};\\\", \\\"{x:1266,y:621,t:1527009093569};\\\", \\\"{x:1259,y:625,t:1527009093586};\\\", \\\"{x:1254,y:628,t:1527009093602};\\\", \\\"{x:1248,y:631,t:1527009093620};\\\", \\\"{x:1244,y:634,t:1527009093636};\\\", \\\"{x:1238,y:637,t:1527009093653};\\\", \\\"{x:1234,y:639,t:1527009093669};\\\", \\\"{x:1231,y:640,t:1527009093686};\\\", \\\"{x:1231,y:641,t:1527009093703};\\\", \\\"{x:1229,y:641,t:1527009093719};\\\", \\\"{x:1228,y:642,t:1527009093738};\\\", \\\"{x:1229,y:641,t:1527009093890};\\\", \\\"{x:1230,y:641,t:1527009093903};\\\", \\\"{x:1230,y:638,t:1527009093919};\\\", \\\"{x:1231,y:637,t:1527009093936};\\\", \\\"{x:1232,y:636,t:1527009093953};\\\", \\\"{x:1234,y:634,t:1527009093969};\\\", \\\"{x:1235,y:633,t:1527009093986};\\\", \\\"{x:1236,y:631,t:1527009094002};\\\", \\\"{x:1238,y:629,t:1527009094019};\\\", \\\"{x:1239,y:628,t:1527009094036};\\\", \\\"{x:1239,y:627,t:1527009094053};\\\", \\\"{x:1241,y:626,t:1527009094069};\\\", \\\"{x:1242,y:625,t:1527009094086};\\\", \\\"{x:1243,y:625,t:1527009094146};\\\", \\\"{x:1244,y:624,t:1527009094194};\\\", \\\"{x:1247,y:624,t:1527009098146};\\\", \\\"{x:1251,y:627,t:1527009098154};\\\", \\\"{x:1257,y:633,t:1527009098168};\\\", \\\"{x:1268,y:642,t:1527009098184};\\\", \\\"{x:1276,y:648,t:1527009098201};\\\", \\\"{x:1286,y:658,t:1527009098218};\\\", \\\"{x:1298,y:671,t:1527009098234};\\\", \\\"{x:1308,y:681,t:1527009098251};\\\", \\\"{x:1316,y:692,t:1527009098268};\\\", \\\"{x:1323,y:703,t:1527009098284};\\\", \\\"{x:1328,y:711,t:1527009098301};\\\", \\\"{x:1332,y:719,t:1527009098318};\\\", \\\"{x:1341,y:733,t:1527009098334};\\\", \\\"{x:1351,y:749,t:1527009098351};\\\", \\\"{x:1358,y:763,t:1527009098368};\\\", \\\"{x:1363,y:773,t:1527009098384};\\\", \\\"{x:1366,y:781,t:1527009098401};\\\", \\\"{x:1370,y:790,t:1527009098417};\\\", \\\"{x:1375,y:804,t:1527009098434};\\\", \\\"{x:1378,y:813,t:1527009098451};\\\", \\\"{x:1379,y:820,t:1527009098467};\\\", \\\"{x:1379,y:824,t:1527009098484};\\\", \\\"{x:1379,y:830,t:1527009098501};\\\", \\\"{x:1374,y:837,t:1527009098517};\\\", \\\"{x:1363,y:845,t:1527009098535};\\\", \\\"{x:1348,y:853,t:1527009098551};\\\", \\\"{x:1329,y:861,t:1527009098567};\\\", \\\"{x:1304,y:868,t:1527009098584};\\\", \\\"{x:1278,y:873,t:1527009098602};\\\", \\\"{x:1253,y:876,t:1527009098618};\\\", \\\"{x:1226,y:878,t:1527009098634};\\\", \\\"{x:1219,y:878,t:1527009098651};\\\", \\\"{x:1218,y:878,t:1527009098690};\\\", \\\"{x:1216,y:876,t:1527009098714};\\\", \\\"{x:1216,y:873,t:1527009098730};\\\", \\\"{x:1216,y:871,t:1527009098739};\\\", \\\"{x:1216,y:869,t:1527009098751};\\\", \\\"{x:1216,y:860,t:1527009098767};\\\", \\\"{x:1216,y:851,t:1527009098784};\\\", \\\"{x:1216,y:842,t:1527009098801};\\\", \\\"{x:1217,y:834,t:1527009098817};\\\", \\\"{x:1222,y:824,t:1527009098835};\\\", \\\"{x:1226,y:817,t:1527009098851};\\\", \\\"{x:1227,y:815,t:1527009098867};\\\", \\\"{x:1228,y:813,t:1527009098884};\\\", \\\"{x:1228,y:812,t:1527009099034};\\\", \\\"{x:1227,y:812,t:1527009099058};\\\", \\\"{x:1226,y:812,t:1527009099067};\\\", \\\"{x:1224,y:812,t:1527009099084};\\\", \\\"{x:1223,y:811,t:1527009099101};\\\", \\\"{x:1222,y:811,t:1527009099117};\\\", \\\"{x:1220,y:810,t:1527009099135};\\\", \\\"{x:1219,y:810,t:1527009099258};\\\", \\\"{x:1220,y:812,t:1527009099267};\\\", \\\"{x:1220,y:816,t:1527009099284};\\\", \\\"{x:1223,y:820,t:1527009099301};\\\", \\\"{x:1224,y:825,t:1527009099317};\\\", \\\"{x:1225,y:827,t:1527009099334};\\\", \\\"{x:1225,y:828,t:1527009099350};\\\", \\\"{x:1225,y:829,t:1527009099490};\\\", \\\"{x:1226,y:829,t:1527009099500};\\\", \\\"{x:1227,y:831,t:1527009099518};\\\", \\\"{x:1231,y:832,t:1527009099534};\\\", \\\"{x:1240,y:836,t:1527009099551};\\\", \\\"{x:1253,y:838,t:1527009099567};\\\", \\\"{x:1273,y:842,t:1527009099585};\\\", \\\"{x:1296,y:846,t:1527009099600};\\\", \\\"{x:1318,y:849,t:1527009099617};\\\", \\\"{x:1350,y:857,t:1527009099634};\\\", \\\"{x:1373,y:864,t:1527009099650};\\\", \\\"{x:1391,y:870,t:1527009099668};\\\", \\\"{x:1403,y:877,t:1527009099685};\\\", \\\"{x:1413,y:883,t:1527009099700};\\\", \\\"{x:1418,y:888,t:1527009099717};\\\", \\\"{x:1423,y:892,t:1527009099734};\\\", \\\"{x:1430,y:897,t:1527009099750};\\\", \\\"{x:1433,y:901,t:1527009099768};\\\", \\\"{x:1440,y:905,t:1527009099784};\\\", \\\"{x:1445,y:908,t:1527009099800};\\\", \\\"{x:1449,y:910,t:1527009099817};\\\", \\\"{x:1451,y:911,t:1527009099834};\\\", \\\"{x:1454,y:912,t:1527009099851};\\\", \\\"{x:1455,y:912,t:1527009099867};\\\", \\\"{x:1456,y:914,t:1527009099884};\\\", \\\"{x:1457,y:915,t:1527009099900};\\\", \\\"{x:1454,y:915,t:1527009099995};\\\", \\\"{x:1453,y:914,t:1527009100003};\\\", \\\"{x:1450,y:910,t:1527009100017};\\\", \\\"{x:1446,y:902,t:1527009100035};\\\", \\\"{x:1445,y:895,t:1527009100050};\\\", \\\"{x:1445,y:893,t:1527009100067};\\\", \\\"{x:1445,y:892,t:1527009100298};\\\", \\\"{x:1446,y:892,t:1527009100539};\\\", \\\"{x:1447,y:894,t:1527009100550};\\\", \\\"{x:1450,y:899,t:1527009100568};\\\", \\\"{x:1454,y:905,t:1527009100584};\\\", \\\"{x:1458,y:911,t:1527009100600};\\\", \\\"{x:1462,y:917,t:1527009100617};\\\", \\\"{x:1462,y:920,t:1527009100633};\\\", \\\"{x:1466,y:924,t:1527009100650};\\\", \\\"{x:1470,y:927,t:1527009100667};\\\", \\\"{x:1473,y:930,t:1527009100684};\\\", \\\"{x:1475,y:932,t:1527009100701};\\\", \\\"{x:1477,y:936,t:1527009100718};\\\", \\\"{x:1480,y:940,t:1527009100734};\\\", \\\"{x:1480,y:945,t:1527009100750};\\\", \\\"{x:1480,y:947,t:1527009100767};\\\", \\\"{x:1481,y:951,t:1527009100783};\\\", \\\"{x:1482,y:952,t:1527009100801};\\\", \\\"{x:1482,y:954,t:1527009100818};\\\", \\\"{x:1483,y:955,t:1527009100833};\\\", \\\"{x:1484,y:956,t:1527009100851};\\\", \\\"{x:1485,y:956,t:1527009100882};\\\", \\\"{x:1486,y:957,t:1527009100901};\\\", \\\"{x:1487,y:957,t:1527009100918};\\\", \\\"{x:1487,y:958,t:1527009100980};\\\", \\\"{x:1486,y:958,t:1527009100995};\\\", \\\"{x:1484,y:958,t:1527009101003};\\\", \\\"{x:1483,y:958,t:1527009101018};\\\", \\\"{x:1480,y:957,t:1527009101033};\\\", \\\"{x:1473,y:945,t:1527009101051};\\\", \\\"{x:1468,y:935,t:1527009101067};\\\", \\\"{x:1464,y:925,t:1527009101084};\\\", \\\"{x:1459,y:912,t:1527009101101};\\\", \\\"{x:1454,y:903,t:1527009101117};\\\", \\\"{x:1450,y:897,t:1527009101134};\\\", \\\"{x:1447,y:893,t:1527009101150};\\\", \\\"{x:1444,y:890,t:1527009101166};\\\", \\\"{x:1443,y:890,t:1527009101186};\\\", \\\"{x:1444,y:890,t:1527009101362};\\\", \\\"{x:1446,y:890,t:1527009101371};\\\", \\\"{x:1447,y:891,t:1527009101383};\\\", \\\"{x:1448,y:896,t:1527009101401};\\\", \\\"{x:1449,y:898,t:1527009101417};\\\", \\\"{x:1449,y:900,t:1527009101433};\\\", \\\"{x:1449,y:901,t:1527009102778};\\\", \\\"{x:1449,y:902,t:1527009102786};\\\", \\\"{x:1450,y:903,t:1527009102799};\\\", \\\"{x:1451,y:905,t:1527009102816};\\\", \\\"{x:1452,y:908,t:1527009102833};\\\", \\\"{x:1453,y:910,t:1527009102849};\\\", \\\"{x:1455,y:912,t:1527009102866};\\\", \\\"{x:1458,y:917,t:1527009102883};\\\", \\\"{x:1461,y:921,t:1527009102900};\\\", \\\"{x:1464,y:929,t:1527009102916};\\\", \\\"{x:1468,y:935,t:1527009102933};\\\", \\\"{x:1470,y:940,t:1527009102949};\\\", \\\"{x:1471,y:942,t:1527009102967};\\\", \\\"{x:1473,y:944,t:1527009102983};\\\", \\\"{x:1475,y:946,t:1527009102999};\\\", \\\"{x:1476,y:948,t:1527009103016};\\\", \\\"{x:1476,y:949,t:1527009103033};\\\", \\\"{x:1477,y:950,t:1527009103050};\\\", \\\"{x:1478,y:951,t:1527009103066};\\\", \\\"{x:1478,y:952,t:1527009103082};\\\", \\\"{x:1479,y:955,t:1527009103258};\\\", \\\"{x:1480,y:955,t:1527009103266};\\\", \\\"{x:1480,y:956,t:1527009103282};\\\", \\\"{x:1480,y:957,t:1527009103299};\\\", \\\"{x:1480,y:958,t:1527009103434};\\\", \\\"{x:1479,y:958,t:1527009103450};\\\", \\\"{x:1472,y:942,t:1527009103466};\\\", \\\"{x:1465,y:925,t:1527009103483};\\\", \\\"{x:1453,y:893,t:1527009103500};\\\", \\\"{x:1443,y:862,t:1527009103517};\\\", \\\"{x:1433,y:842,t:1527009103532};\\\", \\\"{x:1423,y:828,t:1527009103549};\\\", \\\"{x:1415,y:817,t:1527009103566};\\\", \\\"{x:1407,y:808,t:1527009103582};\\\", \\\"{x:1401,y:804,t:1527009103599};\\\", \\\"{x:1400,y:803,t:1527009103617};\\\", \\\"{x:1398,y:801,t:1527009103632};\\\", \\\"{x:1397,y:799,t:1527009103650};\\\", \\\"{x:1396,y:798,t:1527009103666};\\\", \\\"{x:1395,y:795,t:1527009103682};\\\", \\\"{x:1393,y:793,t:1527009103699};\\\", \\\"{x:1392,y:789,t:1527009103715};\\\", \\\"{x:1389,y:785,t:1527009103733};\\\", \\\"{x:1386,y:781,t:1527009103750};\\\", \\\"{x:1382,y:776,t:1527009103765};\\\", \\\"{x:1379,y:772,t:1527009103783};\\\", \\\"{x:1377,y:770,t:1527009103800};\\\", \\\"{x:1375,y:768,t:1527009103815};\\\", \\\"{x:1374,y:766,t:1527009103832};\\\", \\\"{x:1374,y:764,t:1527009103849};\\\", \\\"{x:1372,y:761,t:1527009103866};\\\", \\\"{x:1371,y:759,t:1527009103883};\\\", \\\"{x:1371,y:758,t:1527009103899};\\\", \\\"{x:1371,y:757,t:1527009103916};\\\", \\\"{x:1371,y:756,t:1527009103946};\\\", \\\"{x:1373,y:756,t:1527009104035};\\\", \\\"{x:1375,y:757,t:1527009104050};\\\", \\\"{x:1377,y:758,t:1527009104065};\\\", \\\"{x:1381,y:761,t:1527009104082};\\\", \\\"{x:1382,y:762,t:1527009104100};\\\", \\\"{x:1383,y:763,t:1527009104116};\\\", \\\"{x:1389,y:768,t:1527009111474};\\\", \\\"{x:1399,y:774,t:1527009111481};\\\", \\\"{x:1410,y:780,t:1527009111496};\\\", \\\"{x:1460,y:807,t:1527009111514};\\\", \\\"{x:1491,y:821,t:1527009111529};\\\", \\\"{x:1516,y:836,t:1527009111546};\\\", \\\"{x:1536,y:846,t:1527009111563};\\\", \\\"{x:1545,y:852,t:1527009111579};\\\", \\\"{x:1546,y:853,t:1527009111597};\\\", \\\"{x:1548,y:854,t:1527009111613};\\\", \\\"{x:1549,y:855,t:1527009111630};\\\", \\\"{x:1550,y:855,t:1527009111658};\\\", \\\"{x:1551,y:856,t:1527009111666};\\\", \\\"{x:1552,y:857,t:1527009111680};\\\", \\\"{x:1554,y:861,t:1527009111697};\\\", \\\"{x:1554,y:864,t:1527009111713};\\\", \\\"{x:1556,y:869,t:1527009111730};\\\", \\\"{x:1557,y:875,t:1527009111746};\\\", \\\"{x:1558,y:882,t:1527009111763};\\\", \\\"{x:1560,y:889,t:1527009111779};\\\", \\\"{x:1562,y:894,t:1527009111797};\\\", \\\"{x:1564,y:900,t:1527009111812};\\\", \\\"{x:1566,y:905,t:1527009111830};\\\", \\\"{x:1571,y:913,t:1527009111847};\\\", \\\"{x:1574,y:919,t:1527009111863};\\\", \\\"{x:1579,y:927,t:1527009111880};\\\", \\\"{x:1583,y:932,t:1527009111897};\\\", \\\"{x:1590,y:940,t:1527009111913};\\\", \\\"{x:1593,y:947,t:1527009111929};\\\", \\\"{x:1598,y:952,t:1527009111947};\\\", \\\"{x:1602,y:954,t:1527009111963};\\\", \\\"{x:1605,y:958,t:1527009111980};\\\", \\\"{x:1606,y:958,t:1527009111997};\\\", \\\"{x:1607,y:959,t:1527009112012};\\\", \\\"{x:1607,y:956,t:1527009112098};\\\", \\\"{x:1607,y:952,t:1527009112113};\\\", \\\"{x:1601,y:936,t:1527009112130};\\\", \\\"{x:1594,y:922,t:1527009112145};\\\", \\\"{x:1584,y:900,t:1527009112163};\\\", \\\"{x:1571,y:859,t:1527009112180};\\\", \\\"{x:1545,y:798,t:1527009112197};\\\", \\\"{x:1518,y:740,t:1527009112213};\\\", \\\"{x:1498,y:698,t:1527009112230};\\\", \\\"{x:1482,y:666,t:1527009112247};\\\", \\\"{x:1470,y:645,t:1527009112263};\\\", \\\"{x:1463,y:631,t:1527009112280};\\\", \\\"{x:1457,y:625,t:1527009112296};\\\", \\\"{x:1455,y:622,t:1527009112313};\\\", \\\"{x:1454,y:622,t:1527009112330};\\\", \\\"{x:1453,y:621,t:1527009112346};\\\", \\\"{x:1453,y:620,t:1527009112363};\\\", \\\"{x:1449,y:615,t:1527009112380};\\\", \\\"{x:1445,y:609,t:1527009112396};\\\", \\\"{x:1441,y:602,t:1527009112413};\\\", \\\"{x:1439,y:597,t:1527009112430};\\\", \\\"{x:1435,y:590,t:1527009112445};\\\", \\\"{x:1432,y:582,t:1527009112463};\\\", \\\"{x:1430,y:579,t:1527009112480};\\\", \\\"{x:1428,y:576,t:1527009112496};\\\", \\\"{x:1428,y:575,t:1527009112512};\\\", \\\"{x:1427,y:574,t:1527009112530};\\\", \\\"{x:1426,y:574,t:1527009112595};\\\", \\\"{x:1425,y:573,t:1527009112610};\\\", \\\"{x:1424,y:572,t:1527009112626};\\\", \\\"{x:1423,y:571,t:1527009112641};\\\", \\\"{x:1422,y:570,t:1527009112665};\\\", \\\"{x:1421,y:569,t:1527009112698};\\\", \\\"{x:1420,y:568,t:1527009112722};\\\", \\\"{x:1419,y:568,t:1527009112746};\\\", \\\"{x:1416,y:568,t:1527009112763};\\\", \\\"{x:1415,y:566,t:1527009112796};\\\", \\\"{x:1412,y:565,t:1527009112813};\\\", \\\"{x:1411,y:564,t:1527009112834};\\\", \\\"{x:1409,y:564,t:1527009112850};\\\", \\\"{x:1412,y:563,t:1527009115370};\\\", \\\"{x:1415,y:563,t:1527009115379};\\\", \\\"{x:1428,y:570,t:1527009115397};\\\", \\\"{x:1439,y:575,t:1527009115412};\\\", \\\"{x:1445,y:582,t:1527009115429};\\\", \\\"{x:1452,y:590,t:1527009115445};\\\", \\\"{x:1456,y:603,t:1527009115462};\\\", \\\"{x:1457,y:613,t:1527009115479};\\\", \\\"{x:1456,y:625,t:1527009115495};\\\", \\\"{x:1456,y:638,t:1527009115512};\\\", \\\"{x:1455,y:655,t:1527009115528};\\\", \\\"{x:1450,y:672,t:1527009115545};\\\", \\\"{x:1434,y:698,t:1527009115562};\\\", \\\"{x:1416,y:714,t:1527009115579};\\\", \\\"{x:1383,y:731,t:1527009115595};\\\", \\\"{x:1313,y:754,t:1527009115611};\\\", \\\"{x:1259,y:762,t:1527009115629};\\\", \\\"{x:1229,y:748,t:1527009115645};\\\", \\\"{x:1222,y:743,t:1527009115662};\\\", \\\"{x:1210,y:732,t:1527009115679};\\\", \\\"{x:1209,y:730,t:1527009115695};\\\", \\\"{x:1207,y:728,t:1527009115712};\\\", \\\"{x:1206,y:726,t:1527009115729};\\\", \\\"{x:1205,y:726,t:1527009115745};\\\", \\\"{x:1203,y:725,t:1527009115761};\\\", \\\"{x:1203,y:724,t:1527009115785};\\\", \\\"{x:1206,y:722,t:1527009115802};\\\", \\\"{x:1209,y:719,t:1527009115812};\\\", \\\"{x:1212,y:719,t:1527009115829};\\\", \\\"{x:1196,y:714,t:1527009116130};\\\", \\\"{x:1167,y:711,t:1527009116146};\\\", \\\"{x:1066,y:699,t:1527009116162};\\\", \\\"{x:1018,y:693,t:1527009116178};\\\", \\\"{x:994,y:688,t:1527009116196};\\\", \\\"{x:988,y:687,t:1527009116212};\\\", \\\"{x:985,y:685,t:1527009116228};\\\", \\\"{x:982,y:684,t:1527009116245};\\\", \\\"{x:977,y:682,t:1527009116262};\\\", \\\"{x:971,y:681,t:1527009116278};\\\", \\\"{x:965,y:678,t:1527009116295};\\\", \\\"{x:955,y:672,t:1527009116312};\\\", \\\"{x:942,y:665,t:1527009116328};\\\", \\\"{x:921,y:654,t:1527009116345};\\\", \\\"{x:856,y:628,t:1527009116362};\\\", \\\"{x:781,y:606,t:1527009116378};\\\", \\\"{x:686,y:591,t:1527009116395};\\\", \\\"{x:594,y:577,t:1527009116412};\\\", \\\"{x:556,y:570,t:1527009116423};\\\", \\\"{x:479,y:548,t:1527009116440};\\\", \\\"{x:391,y:513,t:1527009116457};\\\", \\\"{x:284,y:479,t:1527009116476};\\\", \\\"{x:269,y:473,t:1527009116492};\\\", \\\"{x:268,y:472,t:1527009116509};\\\", \\\"{x:267,y:472,t:1527009116525};\\\", \\\"{x:273,y:472,t:1527009116578};\\\", \\\"{x:277,y:474,t:1527009116593};\\\", \\\"{x:304,y:485,t:1527009116609};\\\", \\\"{x:316,y:490,t:1527009116626};\\\", \\\"{x:327,y:492,t:1527009116643};\\\", \\\"{x:340,y:495,t:1527009116660};\\\", \\\"{x:354,y:497,t:1527009116676};\\\", \\\"{x:371,y:501,t:1527009116693};\\\", \\\"{x:381,y:504,t:1527009116710};\\\", \\\"{x:389,y:505,t:1527009116727};\\\", \\\"{x:393,y:508,t:1527009116744};\\\", \\\"{x:403,y:509,t:1527009116760};\\\", \\\"{x:420,y:512,t:1527009116776};\\\", \\\"{x:439,y:516,t:1527009116793};\\\", \\\"{x:452,y:518,t:1527009116809};\\\", \\\"{x:472,y:521,t:1527009116826};\\\", \\\"{x:482,y:524,t:1527009116843};\\\", \\\"{x:495,y:528,t:1527009116858};\\\", \\\"{x:512,y:532,t:1527009116877};\\\", \\\"{x:531,y:539,t:1527009116893};\\\", \\\"{x:549,y:544,t:1527009116910};\\\", \\\"{x:565,y:549,t:1527009116926};\\\", \\\"{x:571,y:551,t:1527009116942};\\\", \\\"{x:575,y:553,t:1527009116960};\\\", \\\"{x:576,y:553,t:1527009116976};\\\", \\\"{x:576,y:554,t:1527009116993};\\\", \\\"{x:576,y:556,t:1527009117010};\\\", \\\"{x:576,y:559,t:1527009117027};\\\", \\\"{x:576,y:561,t:1527009117043};\\\", \\\"{x:578,y:564,t:1527009117060};\\\", \\\"{x:579,y:566,t:1527009117076};\\\", \\\"{x:579,y:567,t:1527009117093};\\\", \\\"{x:580,y:568,t:1527009117110};\\\", \\\"{x:581,y:569,t:1527009117129};\\\", \\\"{x:582,y:570,t:1527009117145};\\\", \\\"{x:583,y:570,t:1527009117162};\\\", \\\"{x:584,y:570,t:1527009117177};\\\", \\\"{x:589,y:571,t:1527009117194};\\\", \\\"{x:591,y:572,t:1527009117210};\\\", \\\"{x:595,y:572,t:1527009117227};\\\", \\\"{x:595,y:573,t:1527009117244};\\\", \\\"{x:598,y:573,t:1527009117261};\\\", \\\"{x:601,y:573,t:1527009117277};\\\", \\\"{x:602,y:573,t:1527009117297};\\\", \\\"{x:604,y:573,t:1527009117321};\\\", \\\"{x:605,y:573,t:1527009117330};\\\", \\\"{x:606,y:573,t:1527009117344};\\\", \\\"{x:609,y:572,t:1527009117361};\\\", \\\"{x:610,y:571,t:1527009117378};\\\", \\\"{x:611,y:572,t:1527009117842};\\\", \\\"{x:612,y:572,t:1527009117914};\\\", \\\"{x:612,y:571,t:1527009117938};\\\", \\\"{x:611,y:568,t:1527009117946};\\\", \\\"{x:610,y:567,t:1527009117961};\\\", \\\"{x:608,y:565,t:1527009117978};\\\", \\\"{x:606,y:564,t:1527009117994};\\\", \\\"{x:605,y:563,t:1527009118010};\\\", \\\"{x:604,y:563,t:1527009118027};\\\", \\\"{x:602,y:562,t:1527009118044};\\\", \\\"{x:601,y:561,t:1527009118060};\\\", \\\"{x:600,y:560,t:1527009118089};\\\", \\\"{x:600,y:558,t:1527009122074};\\\", \\\"{x:597,y:546,t:1527009122082};\\\", \\\"{x:597,y:528,t:1527009122097};\\\", \\\"{x:598,y:471,t:1527009122112};\\\", \\\"{x:627,y:363,t:1527009122131};\\\", \\\"{x:696,y:243,t:1527009122147};\\\", \\\"{x:805,y:91,t:1527009122164};\\\", \\\"{x:949,y:16,t:1527009122180};\\\", \\\"{x:1116,y:16,t:1527009122197};\\\", \\\"{x:1285,y:16,t:1527009122214};\\\", \\\"{x:1438,y:16,t:1527009122230};\\\", \\\"{x:1563,y:16,t:1527009122247};\\\", \\\"{x:1679,y:16,t:1527009122264};\\\", \\\"{x:1785,y:16,t:1527009122280};\\\", \\\"{x:1883,y:16,t:1527009122297};\\\", \\\"{x:1919,y:16,t:1527009122314};\\\", \\\"{x:1917,y:16,t:1527009122361};\\\", \\\"{x:1905,y:16,t:1527009122369};\\\", \\\"{x:1877,y:16,t:1527009122381};\\\", \\\"{x:1810,y:16,t:1527009122398};\\\", \\\"{x:1701,y:16,t:1527009122414};\\\", \\\"{x:1534,y:16,t:1527009122431};\\\", \\\"{x:1337,y:16,t:1527009122447};\\\", \\\"{x:1112,y:16,t:1527009122464};\\\", \\\"{x:861,y:16,t:1527009122481};\\\", \\\"{x:592,y:16,t:1527009122497};\\\", \\\"{x:234,y:16,t:1527009122514};\\\", \\\"{x:20,y:16,t:1527009122531};\\\", \\\"{x:0,y:16,t:1527009122547};\\\", \\\"{x:0,y:63,t:1527009122564};\\\", \\\"{x:0,y:143,t:1527009122581};\\\", \\\"{x:0,y:248,t:1527009122597};\\\", \\\"{x:0,y:342,t:1527009122614};\\\", \\\"{x:0,y:385,t:1527009122632};\\\", \\\"{x:19,y:417,t:1527009122647};\\\", \\\"{x:56,y:449,t:1527009122664};\\\", \\\"{x:119,y:503,t:1527009122681};\\\", \\\"{x:193,y:565,t:1527009122697};\\\", \\\"{x:274,y:672,t:1527009122714};\\\", \\\"{x:296,y:734,t:1527009122731};\\\", \\\"{x:300,y:799,t:1527009122747};\\\", \\\"{x:281,y:889,t:1527009122764};\\\", \\\"{x:207,y:1018,t:1527009122781};\\\", \\\"{x:76,y:1198,t:1527009122797};\\\", \\\"{x:0,y:1215,t:1527009122814};\\\", \\\"{x:2,y:1215,t:1527009122905};\\\", \\\"{x:31,y:1215,t:1527009122915};\\\", \\\"{x:172,y:1177,t:1527009122931};\\\", \\\"{x:399,y:1101,t:1527009122948};\\\", \\\"{x:707,y:986,t:1527009122964};\\\", \\\"{x:1039,y:854,t:1527009122981};\\\", \\\"{x:1419,y:691,t:1527009122998};\\\", \\\"{x:1788,y:525,t:1527009123014};\\\", \\\"{x:1919,y:380,t:1527009123031};\\\", \\\"{x:1919,y:272,t:1527009123048};\\\", \\\"{x:1919,y:205,t:1527009123065};\\\", \\\"{x:1919,y:176,t:1527009123081};\\\", \\\"{x:1894,y:151,t:1527009123098};\\\", \\\"{x:1835,y:118,t:1527009123115};\\\", \\\"{x:1751,y:91,t:1527009123131};\\\", \\\"{x:1687,y:74,t:1527009123148};\\\", \\\"{x:1640,y:69,t:1527009123164};\\\", \\\"{x:1621,y:65,t:1527009123181};\\\", \\\"{x:1613,y:64,t:1527009123198};\\\", \\\"{x:1608,y:60,t:1527009123214};\\\", \\\"{x:1600,y:57,t:1527009123230};\\\", \\\"{x:1585,y:53,t:1527009123248};\\\", \\\"{x:1567,y:48,t:1527009123264};\\\", \\\"{x:1554,y:47,t:1527009123281};\\\", \\\"{x:1545,y:46,t:1527009123298};\\\", \\\"{x:1541,y:46,t:1527009123315};\\\", \\\"{x:1535,y:48,t:1527009123331};\\\", \\\"{x:1524,y:75,t:1527009123348};\\\", \\\"{x:1508,y:123,t:1527009123365};\\\", \\\"{x:1483,y:178,t:1527009123381};\\\", \\\"{x:1459,y:226,t:1527009123398};\\\", \\\"{x:1425,y:279,t:1527009123415};\\\", \\\"{x:1397,y:328,t:1527009123431};\\\", \\\"{x:1381,y:355,t:1527009123448};\\\", \\\"{x:1370,y:375,t:1527009123465};\\\", \\\"{x:1363,y:389,t:1527009123481};\\\", \\\"{x:1349,y:415,t:1527009123498};\\\", \\\"{x:1341,y:427,t:1527009123515};\\\", \\\"{x:1333,y:442,t:1527009123531};\\\", \\\"{x:1325,y:450,t:1527009123548};\\\", \\\"{x:1324,y:453,t:1527009123565};\\\", \\\"{x:1323,y:454,t:1527009123746};\\\", \\\"{x:1322,y:454,t:1527009123786};\\\", \\\"{x:1319,y:456,t:1527009123798};\\\", \\\"{x:1308,y:465,t:1527009123816};\\\", \\\"{x:1295,y:479,t:1527009123832};\\\", \\\"{x:1263,y:521,t:1527009123848};\\\", \\\"{x:1198,y:613,t:1527009123865};\\\", \\\"{x:1165,y:747,t:1527009123882};\\\", \\\"{x:1158,y:819,t:1527009123899};\\\", \\\"{x:1150,y:870,t:1527009123915};\\\", \\\"{x:1139,y:909,t:1527009123933};\\\", \\\"{x:1133,y:934,t:1527009123948};\\\", \\\"{x:1131,y:954,t:1527009123966};\\\", \\\"{x:1131,y:967,t:1527009123982};\\\", \\\"{x:1132,y:977,t:1527009123999};\\\", \\\"{x:1137,y:984,t:1527009124015};\\\", \\\"{x:1142,y:988,t:1527009124033};\\\", \\\"{x:1152,y:991,t:1527009124048};\\\", \\\"{x:1161,y:997,t:1527009124065};\\\", \\\"{x:1184,y:1012,t:1527009124082};\\\", \\\"{x:1202,y:1020,t:1527009124098};\\\", \\\"{x:1219,y:1025,t:1527009124115};\\\", \\\"{x:1240,y:1027,t:1527009124132};\\\", \\\"{x:1262,y:1027,t:1527009124148};\\\", \\\"{x:1286,y:1026,t:1527009124165};\\\", \\\"{x:1315,y:1017,t:1527009124183};\\\", \\\"{x:1339,y:1006,t:1527009124199};\\\", \\\"{x:1354,y:994,t:1527009124215};\\\", \\\"{x:1358,y:987,t:1527009124232};\\\", \\\"{x:1359,y:985,t:1527009124249};\\\", \\\"{x:1359,y:984,t:1527009124265};\\\", \\\"{x:1355,y:983,t:1527009124282};\\\", \\\"{x:1352,y:983,t:1527009124299};\\\", \\\"{x:1349,y:983,t:1527009124315};\\\", \\\"{x:1344,y:983,t:1527009124332};\\\", \\\"{x:1334,y:986,t:1527009124349};\\\", \\\"{x:1321,y:988,t:1527009124365};\\\", \\\"{x:1311,y:989,t:1527009124383};\\\", \\\"{x:1301,y:989,t:1527009124400};\\\", \\\"{x:1293,y:989,t:1527009124415};\\\", \\\"{x:1286,y:989,t:1527009124432};\\\", \\\"{x:1282,y:989,t:1527009124450};\\\", \\\"{x:1278,y:988,t:1527009124465};\\\", \\\"{x:1274,y:984,t:1527009124482};\\\", \\\"{x:1273,y:983,t:1527009124499};\\\", \\\"{x:1272,y:981,t:1527009124561};\\\", \\\"{x:1272,y:980,t:1527009124570};\\\", \\\"{x:1272,y:979,t:1527009124582};\\\", \\\"{x:1272,y:974,t:1527009124599};\\\", \\\"{x:1272,y:971,t:1527009124616};\\\", \\\"{x:1271,y:968,t:1527009124633};\\\", \\\"{x:1271,y:967,t:1527009124650};\\\", \\\"{x:1273,y:967,t:1527009125089};\\\", \\\"{x:1274,y:967,t:1527009125113};\\\", \\\"{x:1275,y:967,t:1527009125154};\\\", \\\"{x:1274,y:966,t:1527009126762};\\\", \\\"{x:1271,y:962,t:1527009126770};\\\", \\\"{x:1268,y:959,t:1527009126784};\\\", \\\"{x:1261,y:952,t:1527009126801};\\\", \\\"{x:1251,y:940,t:1527009126817};\\\", \\\"{x:1242,y:928,t:1527009126834};\\\", \\\"{x:1233,y:918,t:1527009126851};\\\", \\\"{x:1229,y:914,t:1527009126868};\\\", \\\"{x:1223,y:909,t:1527009126884};\\\", \\\"{x:1220,y:905,t:1527009126901};\\\", \\\"{x:1217,y:901,t:1527009126918};\\\", \\\"{x:1216,y:899,t:1527009126934};\\\", \\\"{x:1214,y:898,t:1527009126951};\\\", \\\"{x:1213,y:897,t:1527009126967};\\\", \\\"{x:1213,y:896,t:1527009126984};\\\", \\\"{x:1211,y:894,t:1527009127002};\\\", \\\"{x:1211,y:893,t:1527009127017};\\\", \\\"{x:1210,y:892,t:1527009127034};\\\", \\\"{x:1209,y:890,t:1527009127051};\\\", \\\"{x:1209,y:889,t:1527009127068};\\\", \\\"{x:1209,y:886,t:1527009127084};\\\", \\\"{x:1206,y:878,t:1527009127101};\\\", \\\"{x:1206,y:869,t:1527009127118};\\\", \\\"{x:1206,y:861,t:1527009127134};\\\", \\\"{x:1206,y:853,t:1527009127151};\\\", \\\"{x:1206,y:845,t:1527009127168};\\\", \\\"{x:1206,y:842,t:1527009127184};\\\", \\\"{x:1206,y:832,t:1527009127201};\\\", \\\"{x:1206,y:827,t:1527009127217};\\\", \\\"{x:1206,y:826,t:1527009127234};\\\", \\\"{x:1206,y:825,t:1527009127252};\\\", \\\"{x:1206,y:824,t:1527009127370};\\\", \\\"{x:1207,y:824,t:1527009127594};\\\", \\\"{x:1210,y:825,t:1527009127609};\\\", \\\"{x:1211,y:826,t:1527009127617};\\\", \\\"{x:1214,y:828,t:1527009127634};\\\", \\\"{x:1214,y:829,t:1527009127652};\\\", \\\"{x:1216,y:830,t:1527009127668};\\\", \\\"{x:1217,y:831,t:1527009127684};\\\", \\\"{x:1217,y:832,t:1527009127701};\\\", \\\"{x:1218,y:833,t:1527009127718};\\\", \\\"{x:1219,y:833,t:1527009127736};\\\", \\\"{x:1220,y:829,t:1527009131274};\\\", \\\"{x:1224,y:822,t:1527009131288};\\\", \\\"{x:1227,y:807,t:1527009131305};\\\", \\\"{x:1231,y:783,t:1527009131321};\\\", \\\"{x:1232,y:771,t:1527009131338};\\\", \\\"{x:1236,y:755,t:1527009131354};\\\", \\\"{x:1239,y:741,t:1527009131372};\\\", \\\"{x:1242,y:729,t:1527009131388};\\\", \\\"{x:1245,y:719,t:1527009131404};\\\", \\\"{x:1249,y:708,t:1527009131422};\\\", \\\"{x:1252,y:703,t:1527009131438};\\\", \\\"{x:1253,y:703,t:1527009131455};\\\", \\\"{x:1258,y:703,t:1527009131472};\\\", \\\"{x:1272,y:709,t:1527009131488};\\\", \\\"{x:1288,y:728,t:1527009131505};\\\", \\\"{x:1308,y:762,t:1527009131522};\\\", \\\"{x:1319,y:789,t:1527009131539};\\\", \\\"{x:1340,y:823,t:1527009131555};\\\", \\\"{x:1360,y:856,t:1527009131572};\\\", \\\"{x:1373,y:876,t:1527009131588};\\\", \\\"{x:1381,y:891,t:1527009131605};\\\", \\\"{x:1387,y:902,t:1527009131622};\\\", \\\"{x:1391,y:915,t:1527009131638};\\\", \\\"{x:1394,y:924,t:1527009131655};\\\", \\\"{x:1397,y:932,t:1527009131672};\\\", \\\"{x:1398,y:936,t:1527009131689};\\\", \\\"{x:1399,y:939,t:1527009131705};\\\", \\\"{x:1399,y:940,t:1527009131722};\\\", \\\"{x:1400,y:941,t:1527009131795};\\\", \\\"{x:1401,y:941,t:1527009131843};\\\", \\\"{x:1402,y:942,t:1527009131855};\\\", \\\"{x:1403,y:946,t:1527009131873};\\\", \\\"{x:1406,y:949,t:1527009131889};\\\", \\\"{x:1407,y:953,t:1527009131905};\\\", \\\"{x:1410,y:958,t:1527009131922};\\\", \\\"{x:1412,y:961,t:1527009131939};\\\", \\\"{x:1413,y:962,t:1527009131956};\\\", \\\"{x:1414,y:964,t:1527009131978};\\\", \\\"{x:1416,y:965,t:1527009131989};\\\", \\\"{x:1416,y:966,t:1527009132005};\\\", \\\"{x:1417,y:968,t:1527009132022};\\\", \\\"{x:1417,y:969,t:1527009132211};\\\", \\\"{x:1416,y:969,t:1527009132250};\\\", \\\"{x:1416,y:968,t:1527009132259};\\\", \\\"{x:1415,y:967,t:1527009132273};\\\", \\\"{x:1412,y:961,t:1527009132290};\\\", \\\"{x:1407,y:948,t:1527009132306};\\\", \\\"{x:1401,y:936,t:1527009132323};\\\", \\\"{x:1393,y:922,t:1527009132340};\\\", \\\"{x:1385,y:905,t:1527009132356};\\\", \\\"{x:1377,y:892,t:1527009132372};\\\", \\\"{x:1373,y:884,t:1527009132389};\\\", \\\"{x:1369,y:877,t:1527009132406};\\\", \\\"{x:1366,y:872,t:1527009132422};\\\", \\\"{x:1364,y:868,t:1527009132439};\\\", \\\"{x:1363,y:862,t:1527009132455};\\\", \\\"{x:1359,y:857,t:1527009132472};\\\", \\\"{x:1358,y:848,t:1527009132488};\\\", \\\"{x:1355,y:841,t:1527009132506};\\\", \\\"{x:1355,y:836,t:1527009132522};\\\", \\\"{x:1353,y:833,t:1527009132540};\\\", \\\"{x:1351,y:826,t:1527009132556};\\\", \\\"{x:1348,y:822,t:1527009132572};\\\", \\\"{x:1347,y:818,t:1527009132588};\\\", \\\"{x:1345,y:814,t:1527009132606};\\\", \\\"{x:1343,y:812,t:1527009132622};\\\", \\\"{x:1342,y:810,t:1527009132639};\\\", \\\"{x:1341,y:809,t:1527009132655};\\\", \\\"{x:1340,y:807,t:1527009132673};\\\", \\\"{x:1338,y:804,t:1527009132689};\\\", \\\"{x:1337,y:799,t:1527009132705};\\\", \\\"{x:1337,y:797,t:1527009132722};\\\", \\\"{x:1335,y:793,t:1527009132738};\\\", \\\"{x:1334,y:790,t:1527009132756};\\\", \\\"{x:1334,y:788,t:1527009132772};\\\", \\\"{x:1333,y:785,t:1527009132789};\\\", \\\"{x:1332,y:781,t:1527009132805};\\\", \\\"{x:1331,y:779,t:1527009132822};\\\", \\\"{x:1331,y:775,t:1527009132839};\\\", \\\"{x:1330,y:773,t:1527009132855};\\\", \\\"{x:1330,y:770,t:1527009132872};\\\", \\\"{x:1329,y:769,t:1527009132889};\\\", \\\"{x:1328,y:768,t:1527009132906};\\\", \\\"{x:1328,y:767,t:1527009132923};\\\", \\\"{x:1328,y:766,t:1527009132961};\\\", \\\"{x:1327,y:765,t:1527009132972};\\\", \\\"{x:1327,y:764,t:1527009132989};\\\", \\\"{x:1325,y:761,t:1527009133009};\\\", \\\"{x:1325,y:760,t:1527009133034};\\\", \\\"{x:1324,y:758,t:1527009133042};\\\", \\\"{x:1323,y:758,t:1527009133055};\\\", \\\"{x:1323,y:757,t:1527009133073};\\\", \\\"{x:1322,y:757,t:1527009133170};\\\", \\\"{x:1323,y:757,t:1527009133969};\\\", \\\"{x:1323,y:759,t:1527009133977};\\\", \\\"{x:1326,y:762,t:1527009133989};\\\", \\\"{x:1327,y:763,t:1527009134007};\\\", \\\"{x:1328,y:765,t:1527009134024};\\\", \\\"{x:1327,y:765,t:1527009134330};\\\", \\\"{x:1326,y:765,t:1527009134339};\\\", \\\"{x:1325,y:765,t:1527009134357};\\\", \\\"{x:1323,y:765,t:1527009134373};\\\", \\\"{x:1322,y:764,t:1527009134390};\\\", \\\"{x:1320,y:764,t:1527009134409};\\\", \\\"{x:1319,y:764,t:1527009134442};\\\", \\\"{x:1319,y:763,t:1527009134457};\\\", \\\"{x:1318,y:763,t:1527009134473};\\\", \\\"{x:1317,y:762,t:1527009134513};\\\", \\\"{x:1317,y:763,t:1527009135049};\\\", \\\"{x:1322,y:772,t:1527009135058};\\\", \\\"{x:1337,y:798,t:1527009135074};\\\", \\\"{x:1349,y:836,t:1527009135090};\\\", \\\"{x:1363,y:871,t:1527009135108};\\\", \\\"{x:1372,y:898,t:1527009135124};\\\", \\\"{x:1382,y:920,t:1527009135140};\\\", \\\"{x:1390,y:939,t:1527009135158};\\\", \\\"{x:1394,y:947,t:1527009135174};\\\", \\\"{x:1399,y:953,t:1527009135191};\\\", \\\"{x:1401,y:957,t:1527009135207};\\\", \\\"{x:1402,y:959,t:1527009135225};\\\", \\\"{x:1403,y:960,t:1527009135241};\\\", \\\"{x:1403,y:961,t:1527009135265};\\\", \\\"{x:1405,y:961,t:1527009135274};\\\", \\\"{x:1407,y:963,t:1527009135291};\\\", \\\"{x:1408,y:963,t:1527009135308};\\\", \\\"{x:1409,y:963,t:1527009135385};\\\", \\\"{x:1410,y:962,t:1527009135393};\\\", \\\"{x:1411,y:961,t:1527009135410};\\\", \\\"{x:1412,y:960,t:1527009135458};\\\", \\\"{x:1412,y:959,t:1527009135481};\\\", \\\"{x:1413,y:959,t:1527009135490};\\\", \\\"{x:1416,y:960,t:1527009135508};\\\", \\\"{x:1420,y:961,t:1527009135525};\\\", \\\"{x:1422,y:962,t:1527009135540};\\\", \\\"{x:1423,y:963,t:1527009135557};\\\", \\\"{x:1423,y:964,t:1527009135575};\\\", \\\"{x:1422,y:964,t:1527009135650};\\\", \\\"{x:1419,y:962,t:1527009135657};\\\", \\\"{x:1411,y:956,t:1527009135675};\\\", \\\"{x:1402,y:948,t:1527009135692};\\\", \\\"{x:1392,y:936,t:1527009135708};\\\", \\\"{x:1383,y:923,t:1527009135724};\\\", \\\"{x:1375,y:902,t:1527009135742};\\\", \\\"{x:1367,y:877,t:1527009135758};\\\", \\\"{x:1355,y:843,t:1527009135774};\\\", \\\"{x:1346,y:819,t:1527009135792};\\\", \\\"{x:1336,y:801,t:1527009135808};\\\", \\\"{x:1331,y:791,t:1527009135825};\\\", \\\"{x:1326,y:785,t:1527009135841};\\\", \\\"{x:1325,y:784,t:1527009135857};\\\", \\\"{x:1317,y:778,t:1527009135874};\\\", \\\"{x:1291,y:771,t:1527009135892};\\\", \\\"{x:1236,y:764,t:1527009135908};\\\", \\\"{x:1139,y:762,t:1527009135925};\\\", \\\"{x:1017,y:744,t:1527009135941};\\\", \\\"{x:852,y:711,t:1527009135958};\\\", \\\"{x:665,y:658,t:1527009135975};\\\", \\\"{x:442,y:602,t:1527009135992};\\\", \\\"{x:248,y:567,t:1527009136010};\\\", \\\"{x:118,y:555,t:1527009136024};\\\", \\\"{x:0,y:540,t:1527009136041};\\\", \\\"{x:0,y:537,t:1527009136059};\\\", \\\"{x:0,y:536,t:1527009136074};\\\", \\\"{x:4,y:536,t:1527009136145};\\\", \\\"{x:10,y:537,t:1527009136158};\\\", \\\"{x:26,y:540,t:1527009136176};\\\", \\\"{x:41,y:540,t:1527009136192};\\\", \\\"{x:57,y:540,t:1527009136208};\\\", \\\"{x:76,y:540,t:1527009136225};\\\", \\\"{x:93,y:540,t:1527009136241};\\\", \\\"{x:113,y:540,t:1527009136258};\\\", \\\"{x:135,y:542,t:1527009136276};\\\", \\\"{x:173,y:545,t:1527009136292};\\\", \\\"{x:224,y:546,t:1527009136308};\\\", \\\"{x:261,y:546,t:1527009136324};\\\", \\\"{x:288,y:546,t:1527009136343};\\\", \\\"{x:306,y:546,t:1527009136357};\\\", \\\"{x:314,y:546,t:1527009136376};\\\", \\\"{x:317,y:547,t:1527009136392};\\\", \\\"{x:319,y:548,t:1527009136409};\\\", \\\"{x:322,y:550,t:1527009136425};\\\", \\\"{x:330,y:555,t:1527009136441};\\\", \\\"{x:339,y:555,t:1527009136458};\\\", \\\"{x:351,y:556,t:1527009136475};\\\", \\\"{x:358,y:556,t:1527009136492};\\\", \\\"{x:363,y:554,t:1527009136509};\\\", \\\"{x:364,y:552,t:1527009136526};\\\", \\\"{x:366,y:551,t:1527009136542};\\\", \\\"{x:367,y:550,t:1527009136577};\\\", \\\"{x:368,y:549,t:1527009136592};\\\", \\\"{x:373,y:544,t:1527009136608};\\\", \\\"{x:392,y:531,t:1527009136626};\\\", \\\"{x:402,y:523,t:1527009136643};\\\", \\\"{x:405,y:519,t:1527009136659};\\\", \\\"{x:408,y:515,t:1527009136675};\\\", \\\"{x:408,y:514,t:1527009136713};\\\", \\\"{x:408,y:513,t:1527009136729};\\\", \\\"{x:408,y:512,t:1527009136743};\\\", \\\"{x:407,y:511,t:1527009136758};\\\", \\\"{x:404,y:511,t:1527009136776};\\\", \\\"{x:402,y:510,t:1527009136793};\\\", \\\"{x:400,y:510,t:1527009136809};\\\", \\\"{x:398,y:510,t:1527009136825};\\\", \\\"{x:396,y:510,t:1527009136843};\\\", \\\"{x:393,y:510,t:1527009136860};\\\", \\\"{x:390,y:511,t:1527009136876};\\\", \\\"{x:388,y:511,t:1527009136897};\\\", \\\"{x:387,y:512,t:1527009136921};\\\", \\\"{x:387,y:513,t:1527009137042};\\\", \\\"{x:387,y:514,t:1527009137081};\\\", \\\"{x:387,y:516,t:1527009137092};\\\", \\\"{x:398,y:523,t:1527009137110};\\\", \\\"{x:433,y:534,t:1527009137125};\\\", \\\"{x:515,y:550,t:1527009137143};\\\", \\\"{x:625,y:560,t:1527009137160};\\\", \\\"{x:763,y:560,t:1527009137176};\\\", \\\"{x:907,y:559,t:1527009137193};\\\", \\\"{x:1116,y:534,t:1527009137210};\\\", \\\"{x:1235,y:517,t:1527009137226};\\\", \\\"{x:1337,y:505,t:1527009137243};\\\", \\\"{x:1386,y:502,t:1527009137259};\\\", \\\"{x:1408,y:500,t:1527009137276};\\\", \\\"{x:1417,y:500,t:1527009137293};\\\", \\\"{x:1419,y:501,t:1527009137310};\\\", \\\"{x:1421,y:504,t:1527009137326};\\\", \\\"{x:1426,y:515,t:1527009137342};\\\", \\\"{x:1436,y:535,t:1527009137358};\\\", \\\"{x:1451,y:567,t:1527009137376};\\\", \\\"{x:1469,y:598,t:1527009137393};\\\", \\\"{x:1483,y:625,t:1527009137409};\\\", \\\"{x:1499,y:660,t:1527009137425};\\\", \\\"{x:1512,y:697,t:1527009137442};\\\", \\\"{x:1529,y:738,t:1527009137459};\\\", \\\"{x:1547,y:775,t:1527009137476};\\\", \\\"{x:1558,y:793,t:1527009137492};\\\", \\\"{x:1560,y:801,t:1527009137508};\\\", \\\"{x:1560,y:805,t:1527009137525};\\\", \\\"{x:1560,y:815,t:1527009137542};\\\", \\\"{x:1560,y:830,t:1527009137559};\\\", \\\"{x:1555,y:851,t:1527009137575};\\\", \\\"{x:1545,y:874,t:1527009137592};\\\", \\\"{x:1538,y:890,t:1527009137609};\\\", \\\"{x:1523,y:906,t:1527009137625};\\\", \\\"{x:1514,y:920,t:1527009137641};\\\", \\\"{x:1510,y:926,t:1527009137658};\\\", \\\"{x:1508,y:932,t:1527009137675};\\\", \\\"{x:1506,y:935,t:1527009137692};\\\", \\\"{x:1505,y:936,t:1527009137708};\\\", \\\"{x:1505,y:937,t:1527009137754};\\\", \\\"{x:1504,y:937,t:1527009137761};\\\", \\\"{x:1502,y:937,t:1527009137774};\\\", \\\"{x:1497,y:937,t:1527009137791};\\\", \\\"{x:1491,y:937,t:1527009137808};\\\", \\\"{x:1482,y:937,t:1527009137825};\\\", \\\"{x:1471,y:940,t:1527009137841};\\\", \\\"{x:1458,y:942,t:1527009137857};\\\", \\\"{x:1451,y:944,t:1527009137875};\\\", \\\"{x:1448,y:945,t:1527009137891};\\\", \\\"{x:1444,y:946,t:1527009137908};\\\", \\\"{x:1441,y:947,t:1527009137924};\\\", \\\"{x:1438,y:951,t:1527009137941};\\\", \\\"{x:1435,y:956,t:1527009137958};\\\", \\\"{x:1432,y:961,t:1527009137974};\\\", \\\"{x:1428,y:967,t:1527009137991};\\\", \\\"{x:1424,y:968,t:1527009138008};\\\", \\\"{x:1422,y:968,t:1527009138024};\\\", \\\"{x:1419,y:968,t:1527009138041};\\\", \\\"{x:1418,y:968,t:1527009138056};\\\", \\\"{x:1408,y:958,t:1527009138073};\\\", \\\"{x:1396,y:940,t:1527009138091};\\\", \\\"{x:1379,y:909,t:1527009138106};\\\", \\\"{x:1351,y:857,t:1527009138124};\\\", \\\"{x:1333,y:816,t:1527009138140};\\\", \\\"{x:1317,y:789,t:1527009138157};\\\", \\\"{x:1305,y:771,t:1527009138173};\\\", \\\"{x:1296,y:760,t:1527009138190};\\\", \\\"{x:1291,y:754,t:1527009138207};\\\", \\\"{x:1288,y:750,t:1527009138224};\\\", \\\"{x:1285,y:744,t:1527009138240};\\\", \\\"{x:1283,y:739,t:1527009138257};\\\", \\\"{x:1280,y:728,t:1527009138273};\\\", \\\"{x:1275,y:720,t:1527009138289};\\\", \\\"{x:1269,y:711,t:1527009138307};\\\", \\\"{x:1265,y:700,t:1527009138323};\\\", \\\"{x:1261,y:694,t:1527009138340};\\\", \\\"{x:1259,y:689,t:1527009138357};\\\", \\\"{x:1259,y:685,t:1527009138373};\\\", \\\"{x:1256,y:680,t:1527009138390};\\\", \\\"{x:1254,y:674,t:1527009138407};\\\", \\\"{x:1250,y:665,t:1527009138423};\\\", \\\"{x:1247,y:656,t:1527009138440};\\\", \\\"{x:1247,y:653,t:1527009138456};\\\", \\\"{x:1247,y:651,t:1527009138473};\\\", \\\"{x:1247,y:647,t:1527009138490};\\\", \\\"{x:1247,y:645,t:1527009138515};\\\", \\\"{x:1247,y:643,t:1527009138524};\\\", \\\"{x:1247,y:640,t:1527009138541};\\\", \\\"{x:1247,y:638,t:1527009138557};\\\", \\\"{x:1247,y:637,t:1527009138573};\\\", \\\"{x:1247,y:635,t:1527009138590};\\\", \\\"{x:1247,y:634,t:1527009138606};\\\", \\\"{x:1247,y:633,t:1527009138658};\\\", \\\"{x:1247,y:632,t:1527009138674};\\\", \\\"{x:1247,y:631,t:1527009138690};\\\", \\\"{x:1246,y:630,t:1527009138706};\\\", \\\"{x:1246,y:629,t:1527009140649};\\\", \\\"{x:1246,y:630,t:1527009142793};\\\", \\\"{x:1246,y:634,t:1527009142802};\\\", \\\"{x:1246,y:641,t:1527009142811};\\\", \\\"{x:1256,y:665,t:1527009142828};\\\", \\\"{x:1287,y:712,t:1527009142845};\\\", \\\"{x:1332,y:762,t:1527009142861};\\\", \\\"{x:1394,y:810,t:1527009142878};\\\", \\\"{x:1476,y:859,t:1527009142895};\\\", \\\"{x:1563,y:906,t:1527009142911};\\\", \\\"{x:1619,y:933,t:1527009142928};\\\", \\\"{x:1640,y:946,t:1527009142945};\\\", \\\"{x:1645,y:953,t:1527009142961};\\\", \\\"{x:1645,y:954,t:1527009142978};\\\", \\\"{x:1645,y:958,t:1527009142993};\\\", \\\"{x:1644,y:961,t:1527009143011};\\\", \\\"{x:1638,y:965,t:1527009143028};\\\", \\\"{x:1629,y:970,t:1527009143044};\\\", \\\"{x:1622,y:975,t:1527009143061};\\\", \\\"{x:1611,y:981,t:1527009143077};\\\", \\\"{x:1601,y:988,t:1527009143094};\\\", \\\"{x:1589,y:998,t:1527009143111};\\\", \\\"{x:1574,y:1008,t:1527009143127};\\\", \\\"{x:1562,y:1011,t:1527009143144};\\\", \\\"{x:1557,y:1011,t:1527009143161};\\\", \\\"{x:1555,y:1012,t:1527009143176};\\\", \\\"{x:1548,y:999,t:1527009143193};\\\", \\\"{x:1539,y:988,t:1527009143210};\\\", \\\"{x:1526,y:977,t:1527009143227};\\\", \\\"{x:1517,y:973,t:1527009143244};\\\", \\\"{x:1513,y:972,t:1527009143259};\\\", \\\"{x:1511,y:970,t:1527009143277};\\\", \\\"{x:1510,y:970,t:1527009143345};\\\", \\\"{x:1509,y:970,t:1527009143360};\\\", \\\"{x:1507,y:967,t:1527009143377};\\\", \\\"{x:1506,y:964,t:1527009143393};\\\", \\\"{x:1503,y:955,t:1527009143410};\\\", \\\"{x:1500,y:946,t:1527009143427};\\\", \\\"{x:1499,y:937,t:1527009143443};\\\", \\\"{x:1493,y:925,t:1527009143460};\\\", \\\"{x:1489,y:912,t:1527009143476};\\\", \\\"{x:1486,y:897,t:1527009143493};\\\", \\\"{x:1481,y:885,t:1527009143510};\\\", \\\"{x:1476,y:871,t:1527009143525};\\\", \\\"{x:1468,y:862,t:1527009143543};\\\", \\\"{x:1463,y:853,t:1527009143559};\\\", \\\"{x:1457,y:846,t:1527009143576};\\\", \\\"{x:1451,y:838,t:1527009143593};\\\", \\\"{x:1437,y:825,t:1527009143609};\\\", \\\"{x:1430,y:821,t:1527009143625};\\\", \\\"{x:1422,y:817,t:1527009143643};\\\", \\\"{x:1414,y:813,t:1527009143659};\\\", \\\"{x:1408,y:809,t:1527009143676};\\\", \\\"{x:1403,y:807,t:1527009143692};\\\", \\\"{x:1398,y:805,t:1527009143709};\\\", \\\"{x:1393,y:801,t:1527009143726};\\\", \\\"{x:1385,y:794,t:1527009143742};\\\", \\\"{x:1373,y:786,t:1527009143759};\\\", \\\"{x:1355,y:778,t:1527009143775};\\\", \\\"{x:1342,y:772,t:1527009143792};\\\", \\\"{x:1333,y:768,t:1527009143809};\\\", \\\"{x:1318,y:765,t:1527009143825};\\\", \\\"{x:1312,y:763,t:1527009143842};\\\", \\\"{x:1307,y:762,t:1527009143859};\\\", \\\"{x:1302,y:759,t:1527009143874};\\\", \\\"{x:1297,y:757,t:1527009143892};\\\", \\\"{x:1292,y:755,t:1527009143909};\\\", \\\"{x:1271,y:746,t:1527009143925};\\\", \\\"{x:1211,y:735,t:1527009143942};\\\", \\\"{x:1107,y:729,t:1527009143958};\\\", \\\"{x:992,y:734,t:1527009143975};\\\", \\\"{x:868,y:753,t:1527009143992};\\\", \\\"{x:743,y:771,t:1527009144008};\\\", \\\"{x:638,y:785,t:1527009144025};\\\", \\\"{x:531,y:799,t:1527009144041};\\\", \\\"{x:497,y:803,t:1527009144058};\\\", \\\"{x:483,y:806,t:1527009144075};\\\", \\\"{x:482,y:806,t:1527009144090};\\\", \\\"{x:480,y:806,t:1527009144185};\\\", \\\"{x:478,y:801,t:1527009144194};\\\", \\\"{x:475,y:795,t:1527009144208};\\\", \\\"{x:466,y:778,t:1527009144224};\\\", \\\"{x:457,y:766,t:1527009144241};\\\", \\\"{x:448,y:750,t:1527009144258};\\\", \\\"{x:448,y:744,t:1527009144274};\\\", \\\"{x:448,y:740,t:1527009144291};\\\", \\\"{x:449,y:738,t:1527009144308};\\\", \\\"{x:452,y:736,t:1527009144324};\\\", \\\"{x:457,y:734,t:1527009144341};\\\", \\\"{x:469,y:731,t:1527009144357};\\\", \\\"{x:481,y:728,t:1527009144374};\\\", \\\"{x:500,y:723,t:1527009144395};\\\", \\\"{x:508,y:720,t:1527009144411};\\\", \\\"{x:518,y:715,t:1527009144428};\\\", \\\"{x:522,y:711,t:1527009144444};\\\", \\\"{x:525,y:708,t:1527009144462};\\\", \\\"{x:524,y:708,t:1527009144648};\\\", \\\"{x:523,y:708,t:1527009144697};\\\", \\\"{x:523,y:709,t:1527009144705};\\\", \\\"{x:522,y:709,t:1527009144716};\\\", \\\"{x:520,y:711,t:1527009144732};\\\", \\\"{x:518,y:715,t:1527009144749};\\\", \\\"{x:517,y:717,t:1527009144766};\\\", \\\"{x:516,y:719,t:1527009144782};\\\", \\\"{x:515,y:720,t:1527009144799};\\\", \\\"{x:515,y:721,t:1527009144816};\\\", \\\"{x:514,y:722,t:1527009144832};\\\", \\\"{x:511,y:726,t:1527009144849};\\\", \\\"{x:505,y:734,t:1527009144866};\\\", \\\"{x:493,y:756,t:1527009144882};\\\", \\\"{x:472,y:804,t:1527009144899};\\\", \\\"{x:442,y:904,t:1527009144916};\\\", \\\"{x:419,y:1032,t:1527009144932};\\\", \\\"{x:395,y:1196,t:1527009144949};\\\", \\\"{x:374,y:1215,t:1527009144966};\\\", \\\"{x:382,y:1215,t:1527009144982};\\\", \\\"{x:427,y:1215,t:1527009144999};\\\", \\\"{x:493,y:1215,t:1527009145016};\\\", \\\"{x:602,y:1215,t:1527009145032};\\\", \\\"{x:694,y:1215,t:1527009145048};\\\", \\\"{x:803,y:1215,t:1527009145066};\\\", \\\"{x:935,y:1201,t:1527009145083};\\\", \\\"{x:1099,y:1147,t:1527009145099};\\\", \\\"{x:1280,y:1073,t:1527009145116};\\\", \\\"{x:1465,y:985,t:1527009145133};\\\", \\\"{x:1653,y:866,t:1527009145149};\\\", \\\"{x:1824,y:716,t:1527009145166};\\\", \\\"{x:1919,y:540,t:1527009145183};\\\", \\\"{x:1919,y:393,t:1527009145199};\\\", \\\"{x:1919,y:271,t:1527009145216};\\\", \\\"{x:1919,y:170,t:1527009145233};\\\", \\\"{x:1892,y:127,t:1527009145249};\\\", \\\"{x:1799,y:75,t:1527009145266};\\\", \\\"{x:1650,y:31,t:1527009145283};\\\", \\\"{x:1456,y:16,t:1527009145300};\\\", \\\"{x:1233,y:16,t:1527009145316};\\\", \\\"{x:1017,y:16,t:1527009145333};\\\", \\\"{x:815,y:16,t:1527009145349};\\\", \\\"{x:630,y:16,t:1527009145366};\\\", \\\"{x:483,y:16,t:1527009145383};\\\", \\\"{x:398,y:21,t:1527009145399};\\\", \\\"{x:374,y:26,t:1527009145416};\\\", \\\"{x:370,y:26,t:1527009145432};\\\", \\\"{x:370,y:28,t:1527009145529};\\\", \\\"{x:371,y:33,t:1527009145538};\\\", \\\"{x:376,y:46,t:1527009145549};\\\", \\\"{x:400,y:96,t:1527009145565};\\\", \\\"{x:424,y:177,t:1527009145583};\\\", \\\"{x:445,y:264,t:1527009145600};\\\", \\\"{x:471,y:364,t:1527009145616};\\\", \\\"{x:500,y:472,t:1527009145633};\\\", \\\"{x:512,y:509,t:1527009145650};\\\", \\\"{x:517,y:523,t:1527009145691};\\\", \\\"{x:521,y:533,t:1527009145700};\\\", \\\"{x:521,y:534,t:1527009145729};\\\", \\\"{x:521,y:535,t:1527009145769};\\\", \\\"{x:521,y:536,t:1527009145801};\\\", \\\"{x:520,y:535,t:1527009145817};\\\", \\\"{x:520,y:533,t:1527009145833};\\\", \\\"{x:518,y:530,t:1527009145850};\\\", \\\"{x:515,y:526,t:1527009145867};\\\", \\\"{x:511,y:519,t:1527009145883};\\\", \\\"{x:510,y:514,t:1527009145900};\\\", \\\"{x:509,y:511,t:1527009145917};\\\", \\\"{x:507,y:508,t:1527009145933};\\\" ] }, { \\\"rt\\\": 169183, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 461514, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-03 PM-I -I -02 PM-12 PM-11 AM-11 AM-10 AM-03 PM-I -I -A -I -10 AM-09 AM-11 AM-I -11 AM-10 AM-09 AM-08 AM-09 AM-10 AM-11 AM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:504,t:1527009146149};\\\", \\\"{x:506,y:500,t:1527009146618};\\\", \\\"{x:506,y:483,t:1527009146634};\\\", \\\"{x:508,y:468,t:1527009146651};\\\", \\\"{x:509,y:452,t:1527009146667};\\\", \\\"{x:512,y:442,t:1527009146684};\\\", \\\"{x:512,y:437,t:1527009146701};\\\", \\\"{x:512,y:434,t:1527009146717};\\\", \\\"{x:512,y:433,t:1527009146734};\\\", \\\"{x:512,y:432,t:1527009146889};\\\", \\\"{x:508,y:434,t:1527009146901};\\\", \\\"{x:495,y:439,t:1527009146917};\\\", \\\"{x:480,y:443,t:1527009146934};\\\", \\\"{x:465,y:445,t:1527009146951};\\\", \\\"{x:450,y:445,t:1527009146967};\\\", \\\"{x:435,y:445,t:1527009146984};\\\", \\\"{x:415,y:448,t:1527009147001};\\\", \\\"{x:405,y:449,t:1527009147018};\\\", \\\"{x:398,y:451,t:1527009147034};\\\", \\\"{x:396,y:451,t:1527009147051};\\\", \\\"{x:394,y:451,t:1527009147068};\\\", \\\"{x:392,y:451,t:1527009147083};\\\", \\\"{x:390,y:449,t:1527009147101};\\\", \\\"{x:388,y:448,t:1527009147118};\\\", \\\"{x:386,y:448,t:1527009147134};\\\", \\\"{x:381,y:448,t:1527009147151};\\\", \\\"{x:373,y:448,t:1527009147167};\\\", \\\"{x:367,y:448,t:1527009147184};\\\", \\\"{x:360,y:448,t:1527009147201};\\\", \\\"{x:359,y:448,t:1527009147218};\\\", \\\"{x:357,y:449,t:1527009147234};\\\", \\\"{x:354,y:450,t:1527009147251};\\\", \\\"{x:353,y:451,t:1527009147268};\\\", \\\"{x:352,y:451,t:1527009147313};\\\", \\\"{x:351,y:451,t:1527009147329};\\\", \\\"{x:350,y:451,t:1527009147345};\\\", \\\"{x:349,y:451,t:1527009147362};\\\", \\\"{x:348,y:451,t:1527009147369};\\\", \\\"{x:347,y:451,t:1527009147385};\\\", \\\"{x:345,y:451,t:1527009147401};\\\", \\\"{x:343,y:452,t:1527009147417};\\\", \\\"{x:341,y:453,t:1527009147434};\\\", \\\"{x:340,y:453,t:1527009147451};\\\", \\\"{x:338,y:453,t:1527009147468};\\\", \\\"{x:337,y:453,t:1527009147497};\\\", \\\"{x:336,y:453,t:1527009147513};\\\", \\\"{x:335,y:453,t:1527009147633};\\\", \\\"{x:336,y:453,t:1527009147641};\\\", \\\"{x:341,y:452,t:1527009147651};\\\", \\\"{x:353,y:452,t:1527009147668};\\\", \\\"{x:373,y:450,t:1527009147685};\\\", \\\"{x:396,y:447,t:1527009147702};\\\", \\\"{x:427,y:442,t:1527009147718};\\\", \\\"{x:463,y:438,t:1527009147735};\\\", \\\"{x:497,y:433,t:1527009147752};\\\", \\\"{x:526,y:428,t:1527009147768};\\\", \\\"{x:557,y:424,t:1527009147785};\\\", \\\"{x:564,y:424,t:1527009147801};\\\", \\\"{x:567,y:424,t:1527009147818};\\\", \\\"{x:568,y:424,t:1527009147835};\\\", \\\"{x:570,y:424,t:1527009147994};\\\", \\\"{x:573,y:424,t:1527009148001};\\\", \\\"{x:580,y:430,t:1527009148018};\\\", \\\"{x:585,y:433,t:1527009148035};\\\", \\\"{x:590,y:437,t:1527009148052};\\\", \\\"{x:593,y:439,t:1527009148068};\\\", \\\"{x:596,y:441,t:1527009148085};\\\", \\\"{x:598,y:442,t:1527009148102};\\\", \\\"{x:599,y:444,t:1527009148118};\\\", \\\"{x:601,y:447,t:1527009148135};\\\", \\\"{x:602,y:447,t:1527009148152};\\\", \\\"{x:602,y:448,t:1527009148168};\\\", \\\"{x:604,y:450,t:1527009148185};\\\", \\\"{x:604,y:452,t:1527009148297};\\\", \\\"{x:603,y:452,t:1527009148305};\\\", \\\"{x:603,y:453,t:1527009148318};\\\", \\\"{x:600,y:455,t:1527009148335};\\\", \\\"{x:594,y:457,t:1527009148352};\\\", \\\"{x:571,y:462,t:1527009148369};\\\", \\\"{x:552,y:465,t:1527009148384};\\\", \\\"{x:530,y:468,t:1527009148402};\\\", \\\"{x:510,y:472,t:1527009148419};\\\", \\\"{x:492,y:472,t:1527009148435};\\\", \\\"{x:471,y:472,t:1527009148452};\\\", \\\"{x:460,y:471,t:1527009148469};\\\", \\\"{x:453,y:470,t:1527009148485};\\\", \\\"{x:452,y:470,t:1527009148502};\\\", \\\"{x:451,y:470,t:1527009148519};\\\", \\\"{x:450,y:469,t:1527009148585};\\\", \\\"{x:449,y:468,t:1527009148602};\\\", \\\"{x:447,y:467,t:1527009148634};\\\", \\\"{x:445,y:466,t:1527009148649};\\\", \\\"{x:444,y:464,t:1527009148657};\\\", \\\"{x:442,y:463,t:1527009148668};\\\", \\\"{x:439,y:459,t:1527009148685};\\\", \\\"{x:438,y:457,t:1527009148702};\\\", \\\"{x:437,y:455,t:1527009148722};\\\", \\\"{x:436,y:454,t:1527009148737};\\\", \\\"{x:436,y:453,t:1527009148752};\\\", \\\"{x:438,y:454,t:1527009148946};\\\", \\\"{x:444,y:454,t:1527009148953};\\\", \\\"{x:454,y:455,t:1527009148969};\\\", \\\"{x:470,y:455,t:1527009148986};\\\", \\\"{x:489,y:455,t:1527009149002};\\\", \\\"{x:507,y:455,t:1527009149019};\\\", \\\"{x:526,y:455,t:1527009149036};\\\", \\\"{x:540,y:455,t:1527009149052};\\\", \\\"{x:550,y:455,t:1527009149069};\\\", \\\"{x:557,y:455,t:1527009149086};\\\", \\\"{x:560,y:455,t:1527009149102};\\\", \\\"{x:561,y:455,t:1527009149170};\\\", \\\"{x:562,y:455,t:1527009149186};\\\", \\\"{x:564,y:455,t:1527009149217};\\\", \\\"{x:565,y:455,t:1527009149225};\\\", \\\"{x:567,y:455,t:1527009149237};\\\", \\\"{x:570,y:455,t:1527009149253};\\\", \\\"{x:574,y:455,t:1527009149269};\\\", \\\"{x:576,y:455,t:1527009149286};\\\", \\\"{x:578,y:455,t:1527009149303};\\\", \\\"{x:579,y:455,t:1527009149319};\\\", \\\"{x:580,y:456,t:1527009149336};\\\", \\\"{x:582,y:457,t:1527009149353};\\\", \\\"{x:583,y:458,t:1527009149369};\\\", \\\"{x:585,y:459,t:1527009149386};\\\", \\\"{x:588,y:463,t:1527009149403};\\\", \\\"{x:588,y:468,t:1527009149419};\\\", \\\"{x:588,y:474,t:1527009149436};\\\", \\\"{x:588,y:480,t:1527009149453};\\\", \\\"{x:588,y:483,t:1527009149469};\\\", \\\"{x:588,y:484,t:1527009149486};\\\", \\\"{x:589,y:486,t:1527009149503};\\\", \\\"{x:590,y:488,t:1527009149519};\\\", \\\"{x:590,y:489,t:1527009149537};\\\", \\\"{x:590,y:490,t:1527009149585};\\\", \\\"{x:590,y:491,t:1527009149601};\\\", \\\"{x:590,y:493,t:1527009149610};\\\", \\\"{x:588,y:493,t:1527009149625};\\\", \\\"{x:584,y:493,t:1527009149636};\\\", \\\"{x:574,y:493,t:1527009149653};\\\", \\\"{x:560,y:493,t:1527009149670};\\\", \\\"{x:540,y:493,t:1527009149686};\\\", \\\"{x:516,y:493,t:1527009149703};\\\", \\\"{x:493,y:493,t:1527009149719};\\\", \\\"{x:476,y:493,t:1527009149737};\\\", \\\"{x:470,y:493,t:1527009149753};\\\", \\\"{x:469,y:493,t:1527009149945};\\\", \\\"{x:468,y:493,t:1527009150065};\\\", \\\"{x:469,y:492,t:1527009150081};\\\", \\\"{x:476,y:492,t:1527009150089};\\\", \\\"{x:484,y:491,t:1527009150103};\\\", \\\"{x:504,y:488,t:1527009150120};\\\", \\\"{x:537,y:484,t:1527009150137};\\\", \\\"{x:558,y:484,t:1527009150153};\\\", \\\"{x:574,y:484,t:1527009150171};\\\", \\\"{x:581,y:484,t:1527009150188};\\\", \\\"{x:583,y:484,t:1527009150204};\\\", \\\"{x:585,y:484,t:1527009150220};\\\", \\\"{x:587,y:484,t:1527009150306};\\\", \\\"{x:588,y:484,t:1527009150338};\\\", \\\"{x:590,y:484,t:1527009150353};\\\", \\\"{x:593,y:484,t:1527009150371};\\\", \\\"{x:597,y:485,t:1527009150388};\\\", \\\"{x:602,y:486,t:1527009150403};\\\", \\\"{x:604,y:486,t:1527009150421};\\\", \\\"{x:605,y:487,t:1527009150437};\\\", \\\"{x:606,y:487,t:1527009150454};\\\", \\\"{x:607,y:488,t:1527009150481};\\\", \\\"{x:608,y:488,t:1527009150538};\\\", \\\"{x:609,y:488,t:1527009150585};\\\", \\\"{x:610,y:488,t:1527009150625};\\\", \\\"{x:611,y:489,t:1527009150638};\\\", \\\"{x:611,y:490,t:1527009150654};\\\", \\\"{x:612,y:491,t:1527009150670};\\\", \\\"{x:614,y:491,t:1527009150688};\\\", \\\"{x:615,y:491,t:1527009150721};\\\", \\\"{x:616,y:491,t:1527009150745};\\\", \\\"{x:615,y:491,t:1527009151377};\\\", \\\"{x:614,y:491,t:1527009151585};\\\", \\\"{x:613,y:491,t:1527009151617};\\\", \\\"{x:614,y:491,t:1527009151938};\\\", \\\"{x:615,y:491,t:1527009151976};\\\", \\\"{x:616,y:491,t:1527009152042};\\\", \\\"{x:617,y:491,t:1527009152113};\\\", \\\"{x:618,y:491,t:1527009152137};\\\", \\\"{x:618,y:491,t:1527009152314};\\\", \\\"{x:619,y:491,t:1527009152337};\\\", \\\"{x:620,y:491,t:1527009152353};\\\", \\\"{x:621,y:491,t:1527009152377};\\\", \\\"{x:623,y:492,t:1527009152433};\\\", \\\"{x:623,y:493,t:1527009152450};\\\", \\\"{x:624,y:493,t:1527009152473};\\\", \\\"{x:625,y:493,t:1527009152486};\\\", \\\"{x:629,y:493,t:1527009152504};\\\", \\\"{x:633,y:493,t:1527009152521};\\\", \\\"{x:640,y:493,t:1527009152537};\\\", \\\"{x:653,y:494,t:1527009152554};\\\", \\\"{x:662,y:495,t:1527009152570};\\\", \\\"{x:669,y:497,t:1527009152586};\\\", \\\"{x:672,y:497,t:1527009152603};\\\", \\\"{x:674,y:497,t:1527009152621};\\\", \\\"{x:675,y:497,t:1527009152649};\\\", \\\"{x:677,y:497,t:1527009153203};\\\", \\\"{x:682,y:497,t:1527009153216};\\\", \\\"{x:692,y:499,t:1527009153232};\\\", \\\"{x:709,y:508,t:1527009153249};\\\", \\\"{x:726,y:513,t:1527009153266};\\\", \\\"{x:745,y:518,t:1527009153282};\\\", \\\"{x:766,y:524,t:1527009153300};\\\", \\\"{x:774,y:526,t:1527009153316};\\\", \\\"{x:775,y:526,t:1527009153333};\\\", \\\"{x:774,y:526,t:1527009153395};\\\", \\\"{x:771,y:526,t:1527009153403};\\\", \\\"{x:768,y:526,t:1527009153416};\\\", \\\"{x:763,y:524,t:1527009153433};\\\", \\\"{x:762,y:524,t:1527009153449};\\\", \\\"{x:760,y:523,t:1527009153466};\\\", \\\"{x:759,y:523,t:1527009153483};\\\", \\\"{x:758,y:522,t:1527009153779};\\\", \\\"{x:758,y:521,t:1527009153922};\\\", \\\"{x:757,y:520,t:1527009153933};\\\", \\\"{x:755,y:518,t:1527009153951};\\\", \\\"{x:747,y:514,t:1527009153966};\\\", \\\"{x:739,y:507,t:1527009153983};\\\", \\\"{x:732,y:493,t:1527009154000};\\\", \\\"{x:722,y:476,t:1527009154016};\\\", \\\"{x:716,y:456,t:1527009154033};\\\", \\\"{x:707,y:434,t:1527009154050};\\\", \\\"{x:700,y:391,t:1527009154067};\\\", \\\"{x:696,y:367,t:1527009154083};\\\", \\\"{x:696,y:347,t:1527009154100};\\\", \\\"{x:696,y:330,t:1527009154117};\\\", \\\"{x:696,y:319,t:1527009154132};\\\", \\\"{x:696,y:315,t:1527009154150};\\\", \\\"{x:696,y:314,t:1527009154167};\\\", \\\"{x:696,y:315,t:1527009154787};\\\", \\\"{x:697,y:317,t:1527009154800};\\\", \\\"{x:703,y:324,t:1527009154818};\\\", \\\"{x:722,y:339,t:1527009154834};\\\", \\\"{x:779,y:367,t:1527009154850};\\\", \\\"{x:989,y:430,t:1527009154867};\\\", \\\"{x:1174,y:477,t:1527009154884};\\\", \\\"{x:1378,y:533,t:1527009154901};\\\", \\\"{x:1563,y:583,t:1527009154917};\\\", \\\"{x:1721,y:632,t:1527009154934};\\\", \\\"{x:1835,y:674,t:1527009154951};\\\", \\\"{x:1869,y:694,t:1527009154967};\\\", \\\"{x:1874,y:713,t:1527009154984};\\\", \\\"{x:1852,y:741,t:1527009155001};\\\", \\\"{x:1775,y:790,t:1527009155017};\\\", \\\"{x:1672,y:837,t:1527009155034};\\\", \\\"{x:1522,y:902,t:1527009155054};\\\", \\\"{x:1428,y:941,t:1527009155083};\\\", \\\"{x:1411,y:946,t:1527009155101};\\\", \\\"{x:1407,y:947,t:1527009155117};\\\", \\\"{x:1406,y:947,t:1527009155139};\\\", \\\"{x:1405,y:947,t:1527009155152};\\\", \\\"{x:1403,y:947,t:1527009155167};\\\", \\\"{x:1398,y:947,t:1527009155185};\\\", \\\"{x:1391,y:942,t:1527009155201};\\\", \\\"{x:1377,y:930,t:1527009155217};\\\", \\\"{x:1361,y:913,t:1527009155234};\\\", \\\"{x:1335,y:881,t:1527009155251};\\\", \\\"{x:1319,y:855,t:1527009155267};\\\", \\\"{x:1312,y:830,t:1527009155284};\\\", \\\"{x:1312,y:803,t:1527009155302};\\\", \\\"{x:1324,y:765,t:1527009155319};\\\", \\\"{x:1348,y:684,t:1527009155335};\\\", \\\"{x:1387,y:583,t:1527009155352};\\\", \\\"{x:1433,y:465,t:1527009155369};\\\", \\\"{x:1487,y:338,t:1527009155385};\\\", \\\"{x:1543,y:209,t:1527009155401};\\\", \\\"{x:1596,y:85,t:1527009155418};\\\", \\\"{x:1649,y:16,t:1527009155434};\\\", \\\"{x:1697,y:16,t:1527009155451};\\\", \\\"{x:1712,y:16,t:1527009155468};\\\", \\\"{x:1715,y:16,t:1527009155484};\\\", \\\"{x:1713,y:20,t:1527009155555};\\\", \\\"{x:1710,y:30,t:1527009155568};\\\", \\\"{x:1703,y:48,t:1527009155584};\\\", \\\"{x:1696,y:70,t:1527009155601};\\\", \\\"{x:1681,y:96,t:1527009155618};\\\", \\\"{x:1669,y:118,t:1527009155634};\\\", \\\"{x:1644,y:149,t:1527009155651};\\\", \\\"{x:1626,y:166,t:1527009155668};\\\", \\\"{x:1611,y:179,t:1527009155684};\\\", \\\"{x:1588,y:194,t:1527009155701};\\\", \\\"{x:1550,y:212,t:1527009155718};\\\", \\\"{x:1517,y:225,t:1527009155735};\\\", \\\"{x:1488,y:241,t:1527009155751};\\\", \\\"{x:1454,y:259,t:1527009155768};\\\", \\\"{x:1436,y:277,t:1527009155785};\\\", \\\"{x:1419,y:296,t:1527009155801};\\\", \\\"{x:1405,y:314,t:1527009155818};\\\", \\\"{x:1394,y:333,t:1527009155835};\\\", \\\"{x:1389,y:346,t:1527009155851};\\\", \\\"{x:1389,y:362,t:1527009155868};\\\", \\\"{x:1389,y:375,t:1527009155885};\\\", \\\"{x:1389,y:392,t:1527009155901};\\\", \\\"{x:1389,y:410,t:1527009155918};\\\", \\\"{x:1389,y:423,t:1527009155936};\\\", \\\"{x:1389,y:431,t:1527009155951};\\\", \\\"{x:1389,y:436,t:1527009155968};\\\", \\\"{x:1390,y:446,t:1527009155985};\\\", \\\"{x:1390,y:458,t:1527009156001};\\\", \\\"{x:1389,y:470,t:1527009156018};\\\", \\\"{x:1378,y:487,t:1527009156034};\\\", \\\"{x:1368,y:498,t:1527009156051};\\\", \\\"{x:1358,y:506,t:1527009156068};\\\", \\\"{x:1347,y:514,t:1527009156085};\\\", \\\"{x:1339,y:519,t:1527009156102};\\\", \\\"{x:1335,y:520,t:1527009156118};\\\", \\\"{x:1332,y:522,t:1527009156135};\\\", \\\"{x:1329,y:522,t:1527009156152};\\\", \\\"{x:1324,y:519,t:1527009156168};\\\", \\\"{x:1320,y:515,t:1527009156185};\\\", \\\"{x:1315,y:510,t:1527009156202};\\\", \\\"{x:1312,y:507,t:1527009156218};\\\", \\\"{x:1308,y:502,t:1527009156234};\\\", \\\"{x:1308,y:500,t:1527009156252};\\\", \\\"{x:1307,y:499,t:1527009156268};\\\", \\\"{x:1310,y:502,t:1527009156315};\\\", \\\"{x:1324,y:518,t:1527009156322};\\\", \\\"{x:1351,y:545,t:1527009156335};\\\", \\\"{x:1409,y:616,t:1527009156352};\\\", \\\"{x:1474,y:706,t:1527009156368};\\\", \\\"{x:1524,y:796,t:1527009156385};\\\", \\\"{x:1551,y:867,t:1527009156403};\\\", \\\"{x:1570,y:916,t:1527009156418};\\\", \\\"{x:1583,y:943,t:1527009156435};\\\", \\\"{x:1586,y:947,t:1527009156453};\\\", \\\"{x:1588,y:948,t:1527009156468};\\\", \\\"{x:1589,y:949,t:1527009156485};\\\", \\\"{x:1589,y:950,t:1527009156502};\\\", \\\"{x:1590,y:954,t:1527009156519};\\\", \\\"{x:1593,y:961,t:1527009156536};\\\", \\\"{x:1595,y:966,t:1527009156552};\\\", \\\"{x:1598,y:971,t:1527009156569};\\\", \\\"{x:1599,y:973,t:1527009156585};\\\", \\\"{x:1599,y:975,t:1527009156603};\\\", \\\"{x:1598,y:976,t:1527009156652};\\\", \\\"{x:1597,y:976,t:1527009156659};\\\", \\\"{x:1594,y:976,t:1527009156670};\\\", \\\"{x:1586,y:974,t:1527009156686};\\\", \\\"{x:1582,y:973,t:1527009156702};\\\", \\\"{x:1578,y:972,t:1527009156719};\\\", \\\"{x:1576,y:972,t:1527009156735};\\\", \\\"{x:1574,y:972,t:1527009156752};\\\", \\\"{x:1570,y:972,t:1527009156769};\\\", \\\"{x:1567,y:972,t:1527009156786};\\\", \\\"{x:1564,y:972,t:1527009156802};\\\", \\\"{x:1561,y:972,t:1527009156819};\\\", \\\"{x:1557,y:969,t:1527009156835};\\\", \\\"{x:1554,y:969,t:1527009156852};\\\", \\\"{x:1550,y:967,t:1527009156870};\\\", \\\"{x:1546,y:965,t:1527009156886};\\\", \\\"{x:1545,y:964,t:1527009156903};\\\", \\\"{x:1544,y:964,t:1527009156931};\\\", \\\"{x:1544,y:963,t:1527009157075};\\\", \\\"{x:1544,y:961,t:1527009157107};\\\", \\\"{x:1544,y:960,t:1527009157123};\\\", \\\"{x:1544,y:959,t:1527009157136};\\\", \\\"{x:1544,y:953,t:1527009157152};\\\", \\\"{x:1541,y:940,t:1527009157169};\\\", \\\"{x:1527,y:898,t:1527009157186};\\\", \\\"{x:1503,y:841,t:1527009157203};\\\", \\\"{x:1445,y:732,t:1527009157220};\\\", \\\"{x:1397,y:665,t:1527009157236};\\\", \\\"{x:1363,y:612,t:1527009157252};\\\", \\\"{x:1335,y:578,t:1527009157269};\\\", \\\"{x:1316,y:556,t:1527009157286};\\\", \\\"{x:1305,y:542,t:1527009157302};\\\", \\\"{x:1297,y:532,t:1527009157320};\\\", \\\"{x:1293,y:525,t:1527009157337};\\\", \\\"{x:1292,y:523,t:1527009157353};\\\", \\\"{x:1290,y:518,t:1527009157370};\\\", \\\"{x:1288,y:514,t:1527009157386};\\\", \\\"{x:1285,y:507,t:1527009157403};\\\", \\\"{x:1283,y:500,t:1527009157419};\\\", \\\"{x:1281,y:491,t:1527009157436};\\\", \\\"{x:1281,y:486,t:1527009157453};\\\", \\\"{x:1281,y:483,t:1527009157470};\\\", \\\"{x:1281,y:480,t:1527009157486};\\\", \\\"{x:1283,y:480,t:1527009157523};\\\", \\\"{x:1285,y:480,t:1527009157548};\\\", \\\"{x:1286,y:480,t:1527009157564};\\\", \\\"{x:1288,y:480,t:1527009157572};\\\", \\\"{x:1289,y:480,t:1527009157587};\\\", \\\"{x:1292,y:480,t:1527009157604};\\\", \\\"{x:1293,y:480,t:1527009157619};\\\", \\\"{x:1294,y:480,t:1527009157637};\\\", \\\"{x:1297,y:482,t:1527009157654};\\\", \\\"{x:1300,y:485,t:1527009157670};\\\", \\\"{x:1302,y:487,t:1527009157687};\\\", \\\"{x:1304,y:489,t:1527009157703};\\\", \\\"{x:1306,y:491,t:1527009157719};\\\", \\\"{x:1307,y:491,t:1527009157736};\\\", \\\"{x:1308,y:492,t:1527009157771};\\\", \\\"{x:1309,y:493,t:1527009157795};\\\", \\\"{x:1309,y:494,t:1527009157812};\\\", \\\"{x:1310,y:495,t:1527009157837};\\\", \\\"{x:1312,y:497,t:1527009157854};\\\", \\\"{x:1313,y:497,t:1527009157870};\\\", \\\"{x:1313,y:499,t:1527009157886};\\\", \\\"{x:1314,y:500,t:1527009157923};\\\", \\\"{x:1314,y:505,t:1527009169115};\\\", \\\"{x:1314,y:520,t:1527009169130};\\\", \\\"{x:1350,y:601,t:1527009169146};\\\", \\\"{x:1376,y:662,t:1527009169163};\\\", \\\"{x:1397,y:712,t:1527009169180};\\\", \\\"{x:1419,y:757,t:1527009169197};\\\", \\\"{x:1443,y:791,t:1527009169213};\\\", \\\"{x:1458,y:811,t:1527009169229};\\\", \\\"{x:1469,y:829,t:1527009169247};\\\", \\\"{x:1477,y:842,t:1527009169262};\\\", \\\"{x:1483,y:853,t:1527009169280};\\\", \\\"{x:1486,y:860,t:1527009169297};\\\", \\\"{x:1489,y:865,t:1527009169313};\\\", \\\"{x:1491,y:869,t:1527009169330};\\\", \\\"{x:1495,y:876,t:1527009169346};\\\", \\\"{x:1497,y:879,t:1527009169362};\\\", \\\"{x:1499,y:883,t:1527009169380};\\\", \\\"{x:1502,y:887,t:1527009169397};\\\", \\\"{x:1503,y:890,t:1527009169412};\\\", \\\"{x:1506,y:892,t:1527009169429};\\\", \\\"{x:1507,y:894,t:1527009169447};\\\", \\\"{x:1508,y:897,t:1527009169463};\\\", \\\"{x:1510,y:900,t:1527009169480};\\\", \\\"{x:1514,y:906,t:1527009169496};\\\", \\\"{x:1517,y:911,t:1527009169513};\\\", \\\"{x:1521,y:917,t:1527009169530};\\\", \\\"{x:1523,y:924,t:1527009169547};\\\", \\\"{x:1527,y:930,t:1527009169563};\\\", \\\"{x:1529,y:935,t:1527009169580};\\\", \\\"{x:1531,y:937,t:1527009169597};\\\", \\\"{x:1533,y:940,t:1527009169614};\\\", \\\"{x:1534,y:943,t:1527009169630};\\\", \\\"{x:1536,y:946,t:1527009169647};\\\", \\\"{x:1539,y:951,t:1527009169663};\\\", \\\"{x:1540,y:953,t:1527009169680};\\\", \\\"{x:1542,y:956,t:1527009169697};\\\", \\\"{x:1543,y:957,t:1527009169714};\\\", \\\"{x:1544,y:959,t:1527009169730};\\\", \\\"{x:1545,y:960,t:1527009169747};\\\", \\\"{x:1546,y:960,t:1527009169764};\\\", \\\"{x:1546,y:961,t:1527009169780};\\\", \\\"{x:1548,y:961,t:1527009170036};\\\", \\\"{x:1547,y:961,t:1527009170492};\\\", \\\"{x:1546,y:961,t:1527009170557};\\\", \\\"{x:1545,y:960,t:1527009171244};\\\", \\\"{x:1543,y:959,t:1527009172475};\\\", \\\"{x:1542,y:959,t:1527009172755};\\\", \\\"{x:1542,y:958,t:1527009173291};\\\", \\\"{x:1541,y:958,t:1527009173300};\\\", \\\"{x:1540,y:951,t:1527009173317};\\\", \\\"{x:1538,y:940,t:1527009173334};\\\", \\\"{x:1534,y:920,t:1527009173350};\\\", \\\"{x:1526,y:887,t:1527009173367};\\\", \\\"{x:1518,y:851,t:1527009173384};\\\", \\\"{x:1510,y:803,t:1527009173400};\\\", \\\"{x:1495,y:745,t:1527009173418};\\\", \\\"{x:1483,y:698,t:1527009173434};\\\", \\\"{x:1475,y:663,t:1527009173451};\\\", \\\"{x:1460,y:612,t:1527009173467};\\\", \\\"{x:1450,y:588,t:1527009173483};\\\", \\\"{x:1443,y:567,t:1527009173501};\\\", \\\"{x:1435,y:551,t:1527009173517};\\\", \\\"{x:1427,y:532,t:1527009173533};\\\", \\\"{x:1422,y:519,t:1527009173551};\\\", \\\"{x:1416,y:503,t:1527009173568};\\\", \\\"{x:1411,y:495,t:1527009173583};\\\", \\\"{x:1408,y:490,t:1527009173600};\\\", \\\"{x:1408,y:489,t:1527009173618};\\\", \\\"{x:1406,y:487,t:1527009173634};\\\", \\\"{x:1404,y:484,t:1527009173651};\\\", \\\"{x:1399,y:479,t:1527009173667};\\\", \\\"{x:1396,y:478,t:1527009173684};\\\", \\\"{x:1393,y:477,t:1527009173700};\\\", \\\"{x:1389,y:477,t:1527009173717};\\\", \\\"{x:1383,y:479,t:1527009173735};\\\", \\\"{x:1377,y:486,t:1527009173751};\\\", \\\"{x:1371,y:494,t:1527009173767};\\\", \\\"{x:1365,y:499,t:1527009173784};\\\", \\\"{x:1359,y:503,t:1527009173800};\\\", \\\"{x:1356,y:504,t:1527009173817};\\\", \\\"{x:1354,y:505,t:1527009173834};\\\", \\\"{x:1352,y:506,t:1527009173850};\\\", \\\"{x:1349,y:506,t:1527009173868};\\\", \\\"{x:1344,y:506,t:1527009173884};\\\", \\\"{x:1337,y:506,t:1527009173900};\\\", \\\"{x:1331,y:505,t:1527009173917};\\\", \\\"{x:1322,y:504,t:1527009173934};\\\", \\\"{x:1315,y:502,t:1527009173951};\\\", \\\"{x:1311,y:502,t:1527009173967};\\\", \\\"{x:1309,y:501,t:1527009173984};\\\", \\\"{x:1308,y:501,t:1527009174002};\\\", \\\"{x:1307,y:501,t:1527009174034};\\\", \\\"{x:1306,y:501,t:1527009174267};\\\", \\\"{x:1306,y:502,t:1527009174634};\\\", \\\"{x:1316,y:512,t:1527009174651};\\\", \\\"{x:1330,y:532,t:1527009174668};\\\", \\\"{x:1344,y:557,t:1527009174684};\\\", \\\"{x:1360,y:584,t:1527009174701};\\\", \\\"{x:1371,y:604,t:1527009174718};\\\", \\\"{x:1382,y:621,t:1527009174734};\\\", \\\"{x:1393,y:640,t:1527009174751};\\\", \\\"{x:1403,y:660,t:1527009174768};\\\", \\\"{x:1410,y:683,t:1527009174784};\\\", \\\"{x:1416,y:712,t:1527009174801};\\\", \\\"{x:1424,y:757,t:1527009174818};\\\", \\\"{x:1433,y:798,t:1527009174834};\\\", \\\"{x:1447,y:858,t:1527009174851};\\\", \\\"{x:1456,y:896,t:1527009174868};\\\", \\\"{x:1467,y:924,t:1527009174885};\\\", \\\"{x:1475,y:945,t:1527009174901};\\\", \\\"{x:1480,y:961,t:1527009174918};\\\", \\\"{x:1485,y:971,t:1527009174935};\\\", \\\"{x:1490,y:981,t:1527009174951};\\\", \\\"{x:1493,y:988,t:1527009174968};\\\", \\\"{x:1497,y:992,t:1527009174985};\\\", \\\"{x:1498,y:993,t:1527009175001};\\\", \\\"{x:1499,y:994,t:1527009175017};\\\", \\\"{x:1497,y:994,t:1527009175107};\\\", \\\"{x:1494,y:994,t:1527009175122};\\\", \\\"{x:1490,y:994,t:1527009175135};\\\", \\\"{x:1479,y:994,t:1527009175151};\\\", \\\"{x:1450,y:994,t:1527009175168};\\\", \\\"{x:1398,y:990,t:1527009175185};\\\", \\\"{x:1329,y:981,t:1527009175201};\\\", \\\"{x:1273,y:973,t:1527009175218};\\\", \\\"{x:1202,y:964,t:1527009175234};\\\", \\\"{x:1175,y:959,t:1527009175251};\\\", \\\"{x:1158,y:957,t:1527009175268};\\\", \\\"{x:1151,y:957,t:1527009175285};\\\", \\\"{x:1150,y:957,t:1527009175315};\\\", \\\"{x:1149,y:957,t:1527009175347};\\\", \\\"{x:1148,y:957,t:1527009175354};\\\", \\\"{x:1147,y:957,t:1527009175368};\\\", \\\"{x:1144,y:956,t:1527009175385};\\\", \\\"{x:1141,y:954,t:1527009175403};\\\", \\\"{x:1140,y:954,t:1527009175419};\\\", \\\"{x:1138,y:951,t:1527009175434};\\\", \\\"{x:1137,y:951,t:1527009175458};\\\", \\\"{x:1136,y:949,t:1527009175483};\\\", \\\"{x:1134,y:949,t:1527009175491};\\\", \\\"{x:1131,y:949,t:1527009175502};\\\", \\\"{x:1124,y:949,t:1527009175518};\\\", \\\"{x:1119,y:949,t:1527009175535};\\\", \\\"{x:1110,y:951,t:1527009175552};\\\", \\\"{x:1105,y:953,t:1527009175568};\\\", \\\"{x:1103,y:953,t:1527009175586};\\\", \\\"{x:1102,y:954,t:1527009175603};\\\", \\\"{x:1101,y:954,t:1527009175618};\\\", \\\"{x:1100,y:954,t:1527009175636};\\\", \\\"{x:1099,y:954,t:1527009175652};\\\", \\\"{x:1098,y:956,t:1527009175668};\\\", \\\"{x:1098,y:957,t:1527009175762};\\\", \\\"{x:1097,y:959,t:1527009175779};\\\", \\\"{x:1096,y:959,t:1527009175787};\\\", \\\"{x:1096,y:960,t:1527009175802};\\\", \\\"{x:1094,y:962,t:1527009175819};\\\", \\\"{x:1093,y:962,t:1527009175835};\\\", \\\"{x:1092,y:962,t:1527009175859};\\\", \\\"{x:1091,y:962,t:1527009175869};\\\", \\\"{x:1090,y:962,t:1527009175906};\\\", \\\"{x:1092,y:962,t:1527009175986};\\\", \\\"{x:1093,y:962,t:1527009176002};\\\", \\\"{x:1101,y:962,t:1527009176018};\\\", \\\"{x:1108,y:962,t:1527009176035};\\\", \\\"{x:1118,y:962,t:1527009176053};\\\", \\\"{x:1131,y:962,t:1527009176069};\\\", \\\"{x:1141,y:962,t:1527009176085};\\\", \\\"{x:1159,y:962,t:1527009176102};\\\", \\\"{x:1174,y:962,t:1527009176119};\\\", \\\"{x:1182,y:962,t:1527009176135};\\\", \\\"{x:1186,y:962,t:1527009176152};\\\", \\\"{x:1187,y:962,t:1527009176169};\\\", \\\"{x:1187,y:963,t:1527009176267};\\\", \\\"{x:1186,y:963,t:1527009176275};\\\", \\\"{x:1185,y:964,t:1527009176287};\\\", \\\"{x:1181,y:965,t:1527009176302};\\\", \\\"{x:1178,y:965,t:1527009176320};\\\", \\\"{x:1174,y:965,t:1527009176337};\\\", \\\"{x:1171,y:965,t:1527009176353};\\\", \\\"{x:1170,y:965,t:1527009176369};\\\", \\\"{x:1169,y:965,t:1527009176386};\\\", \\\"{x:1167,y:965,t:1527009176402};\\\", \\\"{x:1164,y:965,t:1527009176419};\\\", \\\"{x:1161,y:965,t:1527009176436};\\\", \\\"{x:1157,y:966,t:1527009176453};\\\", \\\"{x:1155,y:966,t:1527009176469};\\\", \\\"{x:1154,y:966,t:1527009176490};\\\", \\\"{x:1156,y:966,t:1527009176643};\\\", \\\"{x:1160,y:966,t:1527009176653};\\\", \\\"{x:1178,y:966,t:1527009176669};\\\", \\\"{x:1199,y:966,t:1527009176686};\\\", \\\"{x:1225,y:966,t:1527009176703};\\\", \\\"{x:1246,y:968,t:1527009176719};\\\", \\\"{x:1259,y:971,t:1527009176736};\\\", \\\"{x:1263,y:971,t:1527009176753};\\\", \\\"{x:1264,y:972,t:1527009176769};\\\", \\\"{x:1263,y:972,t:1527009176891};\\\", \\\"{x:1262,y:972,t:1527009176903};\\\", \\\"{x:1261,y:972,t:1527009176920};\\\", \\\"{x:1259,y:972,t:1527009176936};\\\", \\\"{x:1258,y:972,t:1527009176955};\\\", \\\"{x:1256,y:972,t:1527009176970};\\\", \\\"{x:1255,y:972,t:1527009176986};\\\", \\\"{x:1249,y:972,t:1527009177002};\\\", \\\"{x:1244,y:972,t:1527009177021};\\\", \\\"{x:1239,y:972,t:1527009177037};\\\", \\\"{x:1233,y:972,t:1527009177053};\\\", \\\"{x:1228,y:972,t:1527009177070};\\\", \\\"{x:1226,y:972,t:1527009177086};\\\", \\\"{x:1224,y:972,t:1527009177103};\\\", \\\"{x:1223,y:972,t:1527009177120};\\\", \\\"{x:1222,y:972,t:1527009177136};\\\", \\\"{x:1223,y:971,t:1527009177235};\\\", \\\"{x:1225,y:971,t:1527009177243};\\\", \\\"{x:1229,y:970,t:1527009177253};\\\", \\\"{x:1247,y:967,t:1527009177271};\\\", \\\"{x:1267,y:965,t:1527009177286};\\\", \\\"{x:1283,y:964,t:1527009177303};\\\", \\\"{x:1296,y:964,t:1527009177320};\\\", \\\"{x:1299,y:964,t:1527009177337};\\\", \\\"{x:1300,y:964,t:1527009177353};\\\", \\\"{x:1300,y:963,t:1527009177458};\\\", \\\"{x:1303,y:963,t:1527009177587};\\\", \\\"{x:1309,y:963,t:1527009177603};\\\", \\\"{x:1314,y:963,t:1527009177620};\\\", \\\"{x:1318,y:963,t:1527009177637};\\\", \\\"{x:1320,y:963,t:1527009177653};\\\", \\\"{x:1321,y:963,t:1527009177682};\\\", \\\"{x:1322,y:963,t:1527009177699};\\\", \\\"{x:1323,y:963,t:1527009177714};\\\", \\\"{x:1324,y:963,t:1527009177723};\\\", \\\"{x:1325,y:963,t:1527009177737};\\\", \\\"{x:1328,y:963,t:1527009177753};\\\", \\\"{x:1331,y:963,t:1527009177770};\\\", \\\"{x:1334,y:963,t:1527009177787};\\\", \\\"{x:1340,y:963,t:1527009177804};\\\", \\\"{x:1346,y:963,t:1527009177820};\\\", \\\"{x:1351,y:963,t:1527009177837};\\\", \\\"{x:1352,y:963,t:1527009177854};\\\", \\\"{x:1354,y:963,t:1527009177870};\\\", \\\"{x:1355,y:963,t:1527009177887};\\\", \\\"{x:1357,y:963,t:1527009177904};\\\", \\\"{x:1360,y:963,t:1527009177921};\\\", \\\"{x:1363,y:963,t:1527009177937};\\\", \\\"{x:1364,y:963,t:1527009177954};\\\", \\\"{x:1365,y:963,t:1527009177970};\\\", \\\"{x:1367,y:963,t:1527009177987};\\\", \\\"{x:1369,y:963,t:1527009178004};\\\", \\\"{x:1373,y:963,t:1527009178020};\\\", \\\"{x:1382,y:963,t:1527009178037};\\\", \\\"{x:1389,y:963,t:1527009178055};\\\", \\\"{x:1393,y:963,t:1527009178070};\\\", \\\"{x:1396,y:963,t:1527009178087};\\\", \\\"{x:1400,y:963,t:1527009178104};\\\", \\\"{x:1404,y:963,t:1527009178121};\\\", \\\"{x:1407,y:963,t:1527009178138};\\\", \\\"{x:1410,y:963,t:1527009178155};\\\", \\\"{x:1411,y:963,t:1527009178171};\\\", \\\"{x:1415,y:963,t:1527009178188};\\\", \\\"{x:1419,y:963,t:1527009178205};\\\", \\\"{x:1422,y:963,t:1527009178222};\\\", \\\"{x:1424,y:963,t:1527009178238};\\\", \\\"{x:1426,y:963,t:1527009178255};\\\", \\\"{x:1427,y:963,t:1527009178272};\\\", \\\"{x:1428,y:963,t:1527009178288};\\\", \\\"{x:1429,y:963,t:1527009178305};\\\", \\\"{x:1430,y:963,t:1527009178321};\\\", \\\"{x:1431,y:963,t:1527009178339};\\\", \\\"{x:1433,y:963,t:1527009178355};\\\", \\\"{x:1435,y:963,t:1527009178372};\\\", \\\"{x:1438,y:963,t:1527009178387};\\\", \\\"{x:1444,y:963,t:1527009178404};\\\", \\\"{x:1446,y:963,t:1527009178421};\\\", \\\"{x:1450,y:963,t:1527009178437};\\\", \\\"{x:1451,y:963,t:1527009178455};\\\", \\\"{x:1453,y:963,t:1527009178471};\\\", \\\"{x:1457,y:963,t:1527009178488};\\\", \\\"{x:1460,y:963,t:1527009178505};\\\", \\\"{x:1466,y:963,t:1527009178522};\\\", \\\"{x:1472,y:963,t:1527009178537};\\\", \\\"{x:1478,y:963,t:1527009178556};\\\", \\\"{x:1482,y:963,t:1527009178572};\\\", \\\"{x:1484,y:963,t:1527009178589};\\\", \\\"{x:1485,y:963,t:1527009178605};\\\", \\\"{x:1487,y:963,t:1527009178628};\\\", \\\"{x:1488,y:963,t:1527009178724};\\\", \\\"{x:1490,y:963,t:1527009178780};\\\", \\\"{x:1491,y:963,t:1527009178803};\\\", \\\"{x:1494,y:963,t:1527009178821};\\\", \\\"{x:1498,y:964,t:1527009178839};\\\", \\\"{x:1502,y:964,t:1527009178855};\\\", \\\"{x:1509,y:965,t:1527009178872};\\\", \\\"{x:1517,y:965,t:1527009178889};\\\", \\\"{x:1524,y:965,t:1527009178905};\\\", \\\"{x:1530,y:965,t:1527009178921};\\\", \\\"{x:1542,y:965,t:1527009178940};\\\", \\\"{x:1546,y:965,t:1527009178955};\\\", \\\"{x:1553,y:965,t:1527009178971};\\\", \\\"{x:1557,y:965,t:1527009178989};\\\", \\\"{x:1559,y:965,t:1527009179108};\\\", \\\"{x:1559,y:966,t:1527009179386};\\\", \\\"{x:1559,y:968,t:1527009179458};\\\", \\\"{x:1556,y:969,t:1527009179474};\\\", \\\"{x:1554,y:969,t:1527009179488};\\\", \\\"{x:1551,y:970,t:1527009179505};\\\", \\\"{x:1547,y:972,t:1527009179523};\\\", \\\"{x:1545,y:972,t:1527009179538};\\\", \\\"{x:1544,y:972,t:1527009179563};\\\", \\\"{x:1543,y:972,t:1527009180003};\\\", \\\"{x:1543,y:971,t:1527009180043};\\\", \\\"{x:1544,y:970,t:1527009180058};\\\", \\\"{x:1545,y:969,t:1527009180083};\\\", \\\"{x:1546,y:969,t:1527009180220};\\\", \\\"{x:1546,y:968,t:1527009180228};\\\", \\\"{x:1547,y:967,t:1527009180251};\\\", \\\"{x:1548,y:967,t:1527009180258};\\\", \\\"{x:1548,y:966,t:1527009180283};\\\", \\\"{x:1548,y:964,t:1527009181058};\\\", \\\"{x:1548,y:959,t:1527009181073};\\\", \\\"{x:1546,y:915,t:1527009181090};\\\", \\\"{x:1531,y:831,t:1527009181106};\\\", \\\"{x:1511,y:730,t:1527009181123};\\\", \\\"{x:1491,y:650,t:1527009181140};\\\", \\\"{x:1467,y:580,t:1527009181156};\\\", \\\"{x:1442,y:524,t:1527009181173};\\\", \\\"{x:1429,y:499,t:1527009181190};\\\", \\\"{x:1417,y:486,t:1527009181206};\\\", \\\"{x:1409,y:481,t:1527009181224};\\\", \\\"{x:1405,y:479,t:1527009181240};\\\", \\\"{x:1402,y:478,t:1527009181256};\\\", \\\"{x:1396,y:476,t:1527009181273};\\\", \\\"{x:1379,y:473,t:1527009181291};\\\", \\\"{x:1357,y:467,t:1527009181306};\\\", \\\"{x:1338,y:461,t:1527009181323};\\\", \\\"{x:1332,y:460,t:1527009181340};\\\", \\\"{x:1330,y:460,t:1527009181357};\\\", \\\"{x:1329,y:461,t:1527009181373};\\\", \\\"{x:1328,y:467,t:1527009181390};\\\", \\\"{x:1323,y:480,t:1527009181407};\\\", \\\"{x:1317,y:496,t:1527009181423};\\\", \\\"{x:1312,y:509,t:1527009181440};\\\", \\\"{x:1308,y:515,t:1527009181457};\\\", \\\"{x:1306,y:517,t:1527009181473};\\\", \\\"{x:1304,y:517,t:1527009181514};\\\", \\\"{x:1303,y:517,t:1527009181523};\\\", \\\"{x:1302,y:517,t:1527009181540};\\\", \\\"{x:1301,y:515,t:1527009181558};\\\", \\\"{x:1301,y:513,t:1527009181573};\\\", \\\"{x:1301,y:511,t:1527009181590};\\\", \\\"{x:1301,y:510,t:1527009181611};\\\", \\\"{x:1302,y:508,t:1527009181667};\\\", \\\"{x:1302,y:506,t:1527009181690};\\\", \\\"{x:1302,y:504,t:1527009181707};\\\", \\\"{x:1303,y:502,t:1527009181723};\\\", \\\"{x:1303,y:501,t:1527009181740};\\\", \\\"{x:1303,y:500,t:1527009181763};\\\", \\\"{x:1303,y:498,t:1527009181802};\\\", \\\"{x:1304,y:497,t:1527009181931};\\\", \\\"{x:1305,y:496,t:1527009181940};\\\", \\\"{x:1308,y:494,t:1527009181957};\\\", \\\"{x:1310,y:494,t:1527009181974};\\\", \\\"{x:1311,y:494,t:1527009181991};\\\", \\\"{x:1312,y:494,t:1527009182018};\\\", \\\"{x:1313,y:494,t:1527009182099};\\\", \\\"{x:1313,y:497,t:1527009182122};\\\", \\\"{x:1313,y:501,t:1527009182130};\\\", \\\"{x:1314,y:503,t:1527009182140};\\\", \\\"{x:1316,y:513,t:1527009182158};\\\", \\\"{x:1316,y:526,t:1527009182174};\\\", \\\"{x:1316,y:541,t:1527009182192};\\\", \\\"{x:1316,y:552,t:1527009182207};\\\", \\\"{x:1316,y:558,t:1527009182224};\\\", \\\"{x:1318,y:564,t:1527009182241};\\\", \\\"{x:1318,y:567,t:1527009182258};\\\", \\\"{x:1320,y:573,t:1527009182274};\\\", \\\"{x:1320,y:575,t:1527009182291};\\\", \\\"{x:1321,y:578,t:1527009182307};\\\", \\\"{x:1321,y:581,t:1527009182324};\\\", \\\"{x:1321,y:585,t:1527009182342};\\\", \\\"{x:1321,y:590,t:1527009182358};\\\", \\\"{x:1322,y:596,t:1527009182374};\\\", \\\"{x:1323,y:603,t:1527009182391};\\\", \\\"{x:1323,y:614,t:1527009182407};\\\", \\\"{x:1323,y:622,t:1527009182424};\\\", \\\"{x:1323,y:627,t:1527009182441};\\\", \\\"{x:1325,y:633,t:1527009182458};\\\", \\\"{x:1325,y:638,t:1527009182475};\\\", \\\"{x:1326,y:643,t:1527009182492};\\\", \\\"{x:1326,y:646,t:1527009182508};\\\", \\\"{x:1326,y:650,t:1527009182524};\\\", \\\"{x:1326,y:653,t:1527009182542};\\\", \\\"{x:1327,y:655,t:1527009182558};\\\", \\\"{x:1328,y:658,t:1527009182574};\\\", \\\"{x:1328,y:659,t:1527009182591};\\\", \\\"{x:1328,y:662,t:1527009182607};\\\", \\\"{x:1328,y:667,t:1527009182624};\\\", \\\"{x:1327,y:672,t:1527009182642};\\\", \\\"{x:1326,y:681,t:1527009182659};\\\", \\\"{x:1326,y:686,t:1527009182674};\\\", \\\"{x:1324,y:690,t:1527009182691};\\\", \\\"{x:1323,y:693,t:1527009182708};\\\", \\\"{x:1323,y:695,t:1527009182724};\\\", \\\"{x:1323,y:696,t:1527009182741};\\\", \\\"{x:1322,y:699,t:1527009182759};\\\", \\\"{x:1322,y:701,t:1527009182774};\\\", \\\"{x:1320,y:705,t:1527009182791};\\\", \\\"{x:1320,y:711,t:1527009182808};\\\", \\\"{x:1319,y:718,t:1527009182824};\\\", \\\"{x:1319,y:723,t:1527009182842};\\\", \\\"{x:1318,y:729,t:1527009182859};\\\", \\\"{x:1318,y:734,t:1527009182875};\\\", \\\"{x:1318,y:737,t:1527009182891};\\\", \\\"{x:1318,y:742,t:1527009182908};\\\", \\\"{x:1318,y:743,t:1527009182925};\\\", \\\"{x:1318,y:745,t:1527009182942};\\\", \\\"{x:1318,y:746,t:1527009182958};\\\", \\\"{x:1318,y:748,t:1527009182974};\\\", \\\"{x:1318,y:752,t:1527009182991};\\\", \\\"{x:1318,y:754,t:1527009183008};\\\", \\\"{x:1318,y:757,t:1527009183025};\\\", \\\"{x:1318,y:761,t:1527009183041};\\\", \\\"{x:1318,y:766,t:1527009183058};\\\", \\\"{x:1318,y:770,t:1527009183074};\\\", \\\"{x:1318,y:773,t:1527009183092};\\\", \\\"{x:1318,y:776,t:1527009183108};\\\", \\\"{x:1318,y:780,t:1527009183125};\\\", \\\"{x:1318,y:781,t:1527009183141};\\\", \\\"{x:1318,y:784,t:1527009183158};\\\", \\\"{x:1318,y:788,t:1527009183176};\\\", \\\"{x:1318,y:790,t:1527009183192};\\\", \\\"{x:1318,y:793,t:1527009183208};\\\", \\\"{x:1318,y:794,t:1527009183225};\\\", \\\"{x:1318,y:797,t:1527009183241};\\\", \\\"{x:1318,y:801,t:1527009183258};\\\", \\\"{x:1318,y:804,t:1527009183275};\\\", \\\"{x:1318,y:806,t:1527009183292};\\\", \\\"{x:1318,y:807,t:1527009183308};\\\", \\\"{x:1318,y:811,t:1527009183326};\\\", \\\"{x:1318,y:813,t:1527009183341};\\\", \\\"{x:1318,y:817,t:1527009183359};\\\", \\\"{x:1318,y:819,t:1527009183376};\\\", \\\"{x:1318,y:820,t:1527009183392};\\\", \\\"{x:1318,y:823,t:1527009183409};\\\", \\\"{x:1318,y:824,t:1527009183426};\\\", \\\"{x:1318,y:827,t:1527009183442};\\\", \\\"{x:1318,y:830,t:1527009183458};\\\", \\\"{x:1318,y:834,t:1527009183475};\\\", \\\"{x:1318,y:840,t:1527009183493};\\\", \\\"{x:1318,y:843,t:1527009183508};\\\", \\\"{x:1319,y:848,t:1527009183526};\\\", \\\"{x:1319,y:850,t:1527009183543};\\\", \\\"{x:1321,y:853,t:1527009183559};\\\", \\\"{x:1321,y:854,t:1527009183576};\\\", \\\"{x:1321,y:856,t:1527009183592};\\\", \\\"{x:1321,y:857,t:1527009183609};\\\", \\\"{x:1321,y:860,t:1527009183626};\\\", \\\"{x:1322,y:862,t:1527009183643};\\\", \\\"{x:1323,y:866,t:1527009183659};\\\", \\\"{x:1324,y:869,t:1527009183676};\\\", \\\"{x:1324,y:874,t:1527009183693};\\\", \\\"{x:1324,y:878,t:1527009183708};\\\", \\\"{x:1324,y:884,t:1527009183726};\\\", \\\"{x:1324,y:889,t:1527009183743};\\\", \\\"{x:1324,y:892,t:1527009183759};\\\", \\\"{x:1324,y:896,t:1527009183776};\\\", \\\"{x:1324,y:899,t:1527009183793};\\\", \\\"{x:1324,y:903,t:1527009183809};\\\", \\\"{x:1324,y:905,t:1527009183826};\\\", \\\"{x:1324,y:910,t:1527009183843};\\\", \\\"{x:1324,y:914,t:1527009183858};\\\", \\\"{x:1324,y:917,t:1527009183876};\\\", \\\"{x:1324,y:921,t:1527009183893};\\\", \\\"{x:1323,y:924,t:1527009183910};\\\", \\\"{x:1322,y:927,t:1527009183925};\\\", \\\"{x:1321,y:931,t:1527009183943};\\\", \\\"{x:1320,y:935,t:1527009183959};\\\", \\\"{x:1320,y:938,t:1527009183975};\\\", \\\"{x:1319,y:943,t:1527009183992};\\\", \\\"{x:1318,y:948,t:1527009184010};\\\", \\\"{x:1318,y:952,t:1527009184026};\\\", \\\"{x:1318,y:955,t:1527009184042};\\\", \\\"{x:1318,y:956,t:1527009184060};\\\", \\\"{x:1318,y:957,t:1527009184076};\\\", \\\"{x:1318,y:958,t:1527009184093};\\\", \\\"{x:1318,y:959,t:1527009184109};\\\", \\\"{x:1318,y:961,t:1527009184126};\\\", \\\"{x:1318,y:965,t:1527009184143};\\\", \\\"{x:1318,y:968,t:1527009184161};\\\", \\\"{x:1318,y:969,t:1527009184175};\\\", \\\"{x:1318,y:970,t:1527009184193};\\\", \\\"{x:1317,y:970,t:1527009184283};\\\", \\\"{x:1316,y:970,t:1527009184306};\\\", \\\"{x:1315,y:970,t:1527009184347};\\\", \\\"{x:1314,y:969,t:1527009184490};\\\", \\\"{x:1313,y:968,t:1527009184530};\\\", \\\"{x:1313,y:967,t:1527009184586};\\\", \\\"{x:1313,y:966,t:1527009184634};\\\", \\\"{x:1313,y:965,t:1527009184842};\\\", \\\"{x:1313,y:964,t:1527009184883};\\\", \\\"{x:1312,y:962,t:1527009185123};\\\", \\\"{x:1312,y:961,t:1527009185172};\\\", \\\"{x:1312,y:960,t:1527009185179};\\\", \\\"{x:1311,y:960,t:1527009185195};\\\", \\\"{x:1310,y:959,t:1527009185211};\\\", \\\"{x:1310,y:958,t:1527009185355};\\\", \\\"{x:1310,y:957,t:1527009185452};\\\", \\\"{x:1310,y:956,t:1527009185596};\\\", \\\"{x:1310,y:955,t:1527009185636};\\\", \\\"{x:1310,y:954,t:1527009185675};\\\", \\\"{x:1310,y:953,t:1527009185706};\\\", \\\"{x:1310,y:952,t:1527009185722};\\\", \\\"{x:1310,y:951,t:1527009185730};\\\", \\\"{x:1311,y:951,t:1527009185746};\\\", \\\"{x:1311,y:950,t:1527009185760};\\\", \\\"{x:1311,y:948,t:1527009185777};\\\", \\\"{x:1311,y:947,t:1527009185795};\\\", \\\"{x:1311,y:945,t:1527009185811};\\\", \\\"{x:1313,y:942,t:1527009185827};\\\", \\\"{x:1313,y:938,t:1527009185843};\\\", \\\"{x:1313,y:935,t:1527009185860};\\\", \\\"{x:1313,y:931,t:1527009185877};\\\", \\\"{x:1313,y:926,t:1527009185894};\\\", \\\"{x:1313,y:923,t:1527009185910};\\\", \\\"{x:1313,y:918,t:1527009185927};\\\", \\\"{x:1313,y:913,t:1527009185943};\\\", \\\"{x:1313,y:909,t:1527009185961};\\\", \\\"{x:1313,y:901,t:1527009185977};\\\", \\\"{x:1314,y:888,t:1527009185994};\\\", \\\"{x:1314,y:880,t:1527009186010};\\\", \\\"{x:1315,y:877,t:1527009186028};\\\", \\\"{x:1315,y:874,t:1527009186045};\\\", \\\"{x:1315,y:871,t:1527009186060};\\\", \\\"{x:1315,y:866,t:1527009186078};\\\", \\\"{x:1315,y:861,t:1527009186095};\\\", \\\"{x:1315,y:855,t:1527009186110};\\\", \\\"{x:1317,y:849,t:1527009186128};\\\", \\\"{x:1317,y:842,t:1527009186145};\\\", \\\"{x:1317,y:836,t:1527009186160};\\\", \\\"{x:1317,y:832,t:1527009186178};\\\", \\\"{x:1317,y:828,t:1527009186194};\\\", \\\"{x:1317,y:824,t:1527009186211};\\\", \\\"{x:1317,y:820,t:1527009186228};\\\", \\\"{x:1317,y:817,t:1527009186245};\\\", \\\"{x:1317,y:813,t:1527009186261};\\\", \\\"{x:1317,y:810,t:1527009186277};\\\", \\\"{x:1317,y:806,t:1527009186294};\\\", \\\"{x:1317,y:801,t:1527009186311};\\\", \\\"{x:1317,y:797,t:1527009186327};\\\", \\\"{x:1317,y:793,t:1527009186345};\\\", \\\"{x:1316,y:789,t:1527009186362};\\\", \\\"{x:1316,y:786,t:1527009186378};\\\", \\\"{x:1315,y:782,t:1527009186395};\\\", \\\"{x:1314,y:780,t:1527009186411};\\\", \\\"{x:1314,y:778,t:1527009186428};\\\", \\\"{x:1314,y:776,t:1527009186446};\\\", \\\"{x:1313,y:775,t:1527009186462};\\\", \\\"{x:1313,y:774,t:1527009186479};\\\", \\\"{x:1313,y:773,t:1527009186495};\\\", \\\"{x:1313,y:772,t:1527009186523};\\\", \\\"{x:1313,y:771,t:1527009186539};\\\", \\\"{x:1312,y:770,t:1527009186547};\\\", \\\"{x:1313,y:770,t:1527009186708};\\\", \\\"{x:1314,y:770,t:1527009186732};\\\", \\\"{x:1316,y:770,t:1527009186747};\\\", \\\"{x:1318,y:773,t:1527009186764};\\\", \\\"{x:1319,y:788,t:1527009186779};\\\", \\\"{x:1319,y:804,t:1527009186795};\\\", \\\"{x:1319,y:813,t:1527009186813};\\\", \\\"{x:1319,y:822,t:1527009186829};\\\", \\\"{x:1319,y:824,t:1527009186845};\\\", \\\"{x:1319,y:829,t:1527009186862};\\\", \\\"{x:1319,y:834,t:1527009186879};\\\", \\\"{x:1319,y:838,t:1527009186895};\\\", \\\"{x:1319,y:841,t:1527009186912};\\\", \\\"{x:1318,y:846,t:1527009186929};\\\", \\\"{x:1317,y:849,t:1527009186945};\\\", \\\"{x:1316,y:852,t:1527009186962};\\\", \\\"{x:1315,y:857,t:1527009186979};\\\", \\\"{x:1315,y:859,t:1527009186995};\\\", \\\"{x:1315,y:862,t:1527009187012};\\\", \\\"{x:1315,y:864,t:1527009187029};\\\", \\\"{x:1315,y:869,t:1527009187045};\\\", \\\"{x:1315,y:871,t:1527009187063};\\\", \\\"{x:1315,y:874,t:1527009187079};\\\", \\\"{x:1315,y:877,t:1527009187095};\\\", \\\"{x:1315,y:879,t:1527009187112};\\\", \\\"{x:1315,y:882,t:1527009187128};\\\", \\\"{x:1315,y:884,t:1527009187145};\\\", \\\"{x:1315,y:886,t:1527009187162};\\\", \\\"{x:1315,y:890,t:1527009187179};\\\", \\\"{x:1315,y:892,t:1527009187196};\\\", \\\"{x:1315,y:893,t:1527009187212};\\\", \\\"{x:1317,y:897,t:1527009187229};\\\", \\\"{x:1317,y:898,t:1527009187251};\\\", \\\"{x:1317,y:899,t:1527009187262};\\\", \\\"{x:1317,y:900,t:1527009187279};\\\", \\\"{x:1317,y:902,t:1527009187295};\\\", \\\"{x:1317,y:903,t:1527009187312};\\\", \\\"{x:1317,y:904,t:1527009187329};\\\", \\\"{x:1317,y:906,t:1527009187346};\\\", \\\"{x:1317,y:908,t:1527009187362};\\\", \\\"{x:1317,y:910,t:1527009187378};\\\", \\\"{x:1317,y:912,t:1527009187396};\\\", \\\"{x:1318,y:913,t:1527009187411};\\\", \\\"{x:1318,y:914,t:1527009187429};\\\", \\\"{x:1318,y:915,t:1527009187446};\\\", \\\"{x:1318,y:916,t:1527009187462};\\\", \\\"{x:1318,y:920,t:1527009187479};\\\", \\\"{x:1318,y:921,t:1527009187496};\\\", \\\"{x:1317,y:923,t:1527009187512};\\\", \\\"{x:1317,y:924,t:1527009187529};\\\", \\\"{x:1317,y:925,t:1527009187546};\\\", \\\"{x:1317,y:927,t:1527009187563};\\\", \\\"{x:1317,y:928,t:1527009187579};\\\", \\\"{x:1317,y:930,t:1527009187596};\\\", \\\"{x:1317,y:932,t:1527009187613};\\\", \\\"{x:1317,y:933,t:1527009187629};\\\", \\\"{x:1317,y:934,t:1527009187646};\\\", \\\"{x:1317,y:936,t:1527009187663};\\\", \\\"{x:1317,y:937,t:1527009187682};\\\", \\\"{x:1317,y:938,t:1527009187698};\\\", \\\"{x:1317,y:939,t:1527009187712};\\\", \\\"{x:1317,y:940,t:1527009187739};\\\", \\\"{x:1317,y:941,t:1527009187762};\\\", \\\"{x:1317,y:942,t:1527009187778};\\\", \\\"{x:1317,y:943,t:1527009187796};\\\", \\\"{x:1317,y:946,t:1527009187812};\\\", \\\"{x:1317,y:947,t:1527009187834};\\\", \\\"{x:1317,y:948,t:1527009187846};\\\", \\\"{x:1317,y:949,t:1527009187863};\\\", \\\"{x:1318,y:950,t:1527009187907};\\\", \\\"{x:1318,y:951,t:1527009188083};\\\", \\\"{x:1318,y:952,t:1527009188098};\\\", \\\"{x:1318,y:953,t:1527009188114};\\\", \\\"{x:1319,y:955,t:1527009188129};\\\", \\\"{x:1319,y:957,t:1527009188146};\\\", \\\"{x:1319,y:958,t:1527009189195};\\\", \\\"{x:1319,y:960,t:1527009189419};\\\", \\\"{x:1318,y:960,t:1527009191779};\\\", \\\"{x:1317,y:960,t:1527009191795};\\\", \\\"{x:1317,y:959,t:1527009191802};\\\", \\\"{x:1316,y:959,t:1527009191816};\\\", \\\"{x:1314,y:948,t:1527009191833};\\\", \\\"{x:1314,y:927,t:1527009191849};\\\", \\\"{x:1311,y:877,t:1527009191866};\\\", \\\"{x:1306,y:770,t:1527009191883};\\\", \\\"{x:1305,y:708,t:1527009191899};\\\", \\\"{x:1305,y:660,t:1527009191916};\\\", \\\"{x:1305,y:631,t:1527009191932};\\\", \\\"{x:1305,y:607,t:1527009191949};\\\", \\\"{x:1305,y:591,t:1527009191965};\\\", \\\"{x:1305,y:587,t:1527009191983};\\\", \\\"{x:1305,y:585,t:1527009192000};\\\", \\\"{x:1305,y:584,t:1527009192015};\\\", \\\"{x:1305,y:583,t:1527009192032};\\\", \\\"{x:1306,y:582,t:1527009192049};\\\", \\\"{x:1308,y:577,t:1527009192066};\\\", \\\"{x:1311,y:565,t:1527009192083};\\\", \\\"{x:1312,y:558,t:1527009192100};\\\", \\\"{x:1314,y:553,t:1527009192116};\\\", \\\"{x:1315,y:548,t:1527009192132};\\\", \\\"{x:1315,y:545,t:1527009192150};\\\", \\\"{x:1315,y:543,t:1527009192166};\\\", \\\"{x:1315,y:541,t:1527009192186};\\\", \\\"{x:1315,y:540,t:1527009192210};\\\", \\\"{x:1316,y:539,t:1527009192226};\\\", \\\"{x:1316,y:538,t:1527009192258};\\\", \\\"{x:1316,y:537,t:1527009192282};\\\", \\\"{x:1316,y:536,t:1527009192299};\\\", \\\"{x:1316,y:535,t:1527009192338};\\\", \\\"{x:1316,y:534,t:1527009192349};\\\", \\\"{x:1316,y:533,t:1527009192365};\\\", \\\"{x:1316,y:532,t:1527009192382};\\\", \\\"{x:1316,y:531,t:1527009192403};\\\", \\\"{x:1316,y:530,t:1527009192419};\\\", \\\"{x:1316,y:529,t:1527009192435};\\\", \\\"{x:1316,y:528,t:1527009192482};\\\", \\\"{x:1316,y:527,t:1527009192500};\\\", \\\"{x:1316,y:526,t:1527009192517};\\\", \\\"{x:1316,y:525,t:1527009192532};\\\", \\\"{x:1316,y:524,t:1527009192550};\\\", \\\"{x:1316,y:523,t:1527009192567};\\\", \\\"{x:1315,y:523,t:1527009192583};\\\", \\\"{x:1315,y:522,t:1527009192600};\\\", \\\"{x:1314,y:522,t:1527009192618};\\\", \\\"{x:1313,y:522,t:1527009192682};\\\", \\\"{x:1312,y:522,t:1527009193395};\\\", \\\"{x:1311,y:520,t:1527009193402};\\\", \\\"{x:1310,y:520,t:1527009193827};\\\", \\\"{x:1309,y:519,t:1527009193835};\\\", \\\"{x:1307,y:516,t:1527009193851};\\\", \\\"{x:1307,y:514,t:1527009193867};\\\", \\\"{x:1307,y:511,t:1527009193884};\\\", \\\"{x:1307,y:510,t:1527009193914};\\\", \\\"{x:1307,y:509,t:1527009193930};\\\", \\\"{x:1307,y:508,t:1527009193947};\\\", \\\"{x:1307,y:507,t:1527009193979};\\\", \\\"{x:1307,y:506,t:1527009193995};\\\", \\\"{x:1306,y:504,t:1527009194010};\\\", \\\"{x:1306,y:503,t:1527009194067};\\\", \\\"{x:1306,y:502,t:1527009194090};\\\", \\\"{x:1306,y:501,t:1527009194147};\\\", \\\"{x:1306,y:500,t:1527009194170};\\\", \\\"{x:1306,y:498,t:1527009194186};\\\", \\\"{x:1306,y:497,t:1527009194202};\\\", \\\"{x:1306,y:496,t:1527009194218};\\\", \\\"{x:1306,y:495,t:1527009194235};\\\", \\\"{x:1307,y:495,t:1527009195978};\\\", \\\"{x:1308,y:495,t:1527009195986};\\\", \\\"{x:1310,y:496,t:1527009196003};\\\", \\\"{x:1312,y:497,t:1527009196018};\\\", \\\"{x:1313,y:497,t:1527009196035};\\\", \\\"{x:1314,y:497,t:1527009196066};\\\", \\\"{x:1317,y:497,t:1527009196074};\\\", \\\"{x:1323,y:497,t:1527009196087};\\\", \\\"{x:1331,y:496,t:1527009196103};\\\", \\\"{x:1338,y:495,t:1527009196120};\\\", \\\"{x:1343,y:495,t:1527009196136};\\\", \\\"{x:1349,y:495,t:1527009196153};\\\", \\\"{x:1353,y:495,t:1527009196169};\\\", \\\"{x:1354,y:495,t:1527009196186};\\\", \\\"{x:1356,y:495,t:1527009196203};\\\", \\\"{x:1358,y:495,t:1527009196220};\\\", \\\"{x:1360,y:495,t:1527009196236};\\\", \\\"{x:1361,y:495,t:1527009196259};\\\", \\\"{x:1363,y:495,t:1527009196270};\\\", \\\"{x:1364,y:495,t:1527009196299};\\\", \\\"{x:1365,y:495,t:1527009196338};\\\", \\\"{x:1366,y:495,t:1527009196362};\\\", \\\"{x:1367,y:495,t:1527009196443};\\\", \\\"{x:1366,y:500,t:1527009197843};\\\", \\\"{x:1361,y:510,t:1527009197854};\\\", \\\"{x:1350,y:530,t:1527009197871};\\\", \\\"{x:1335,y:565,t:1527009197888};\\\", \\\"{x:1319,y:618,t:1527009197904};\\\", \\\"{x:1306,y:699,t:1527009197921};\\\", \\\"{x:1273,y:808,t:1527009197938};\\\", \\\"{x:1253,y:880,t:1527009197954};\\\", \\\"{x:1238,y:925,t:1527009197971};\\\", \\\"{x:1228,y:951,t:1527009197988};\\\", \\\"{x:1218,y:968,t:1527009198004};\\\", \\\"{x:1212,y:976,t:1527009198021};\\\", \\\"{x:1210,y:978,t:1527009198037};\\\", \\\"{x:1209,y:978,t:1527009198054};\\\", \\\"{x:1207,y:978,t:1527009198074};\\\", \\\"{x:1206,y:978,t:1527009198090};\\\", \\\"{x:1202,y:978,t:1527009198104};\\\", \\\"{x:1197,y:979,t:1527009198120};\\\", \\\"{x:1181,y:980,t:1527009198138};\\\", \\\"{x:1172,y:980,t:1527009198154};\\\", \\\"{x:1160,y:979,t:1527009198171};\\\", \\\"{x:1153,y:976,t:1527009198188};\\\", \\\"{x:1148,y:975,t:1527009198205};\\\", \\\"{x:1145,y:974,t:1527009198221};\\\", \\\"{x:1143,y:974,t:1527009198238};\\\", \\\"{x:1142,y:974,t:1527009198255};\\\", \\\"{x:1139,y:974,t:1527009198271};\\\", \\\"{x:1135,y:975,t:1527009198288};\\\", \\\"{x:1131,y:977,t:1527009198305};\\\", \\\"{x:1125,y:977,t:1527009198321};\\\", \\\"{x:1120,y:977,t:1527009198338};\\\", \\\"{x:1112,y:975,t:1527009198354};\\\", \\\"{x:1106,y:971,t:1527009198371};\\\", \\\"{x:1103,y:968,t:1527009198388};\\\", \\\"{x:1099,y:964,t:1527009198405};\\\", \\\"{x:1099,y:962,t:1527009198421};\\\", \\\"{x:1099,y:960,t:1527009198438};\\\", \\\"{x:1099,y:959,t:1527009198466};\\\", \\\"{x:1098,y:959,t:1527009198586};\\\", \\\"{x:1096,y:959,t:1527009198610};\\\", \\\"{x:1095,y:958,t:1527009198622};\\\", \\\"{x:1091,y:958,t:1527009198638};\\\", \\\"{x:1086,y:958,t:1527009198654};\\\", \\\"{x:1083,y:958,t:1527009198672};\\\", \\\"{x:1076,y:959,t:1527009198688};\\\", \\\"{x:1071,y:961,t:1527009198705};\\\", \\\"{x:1067,y:962,t:1527009198722};\\\", \\\"{x:1065,y:963,t:1527009198738};\\\", \\\"{x:1065,y:964,t:1527009198810};\\\", \\\"{x:1067,y:964,t:1527009198874};\\\", \\\"{x:1070,y:964,t:1527009198890};\\\", \\\"{x:1072,y:964,t:1527009198905};\\\", \\\"{x:1085,y:964,t:1527009198922};\\\", \\\"{x:1096,y:964,t:1527009198938};\\\", \\\"{x:1104,y:964,t:1527009198955};\\\", \\\"{x:1111,y:964,t:1527009198972};\\\", \\\"{x:1114,y:964,t:1527009198989};\\\", \\\"{x:1116,y:964,t:1527009199005};\\\", \\\"{x:1117,y:964,t:1527009199026};\\\", \\\"{x:1119,y:964,t:1527009199082};\\\", \\\"{x:1120,y:964,t:1527009199107};\\\", \\\"{x:1122,y:964,t:1527009199122};\\\", \\\"{x:1125,y:964,t:1527009199139};\\\", \\\"{x:1129,y:964,t:1527009199155};\\\", \\\"{x:1132,y:964,t:1527009199172};\\\", \\\"{x:1133,y:964,t:1527009199189};\\\", \\\"{x:1135,y:964,t:1527009199205};\\\", \\\"{x:1135,y:965,t:1527009199222};\\\", \\\"{x:1136,y:965,t:1527009199239};\\\", \\\"{x:1137,y:966,t:1527009199255};\\\", \\\"{x:1138,y:966,t:1527009199283};\\\", \\\"{x:1139,y:966,t:1527009199315};\\\", \\\"{x:1140,y:966,t:1527009199331};\\\", \\\"{x:1141,y:966,t:1527009199346};\\\", \\\"{x:1142,y:966,t:1527009199362};\\\", \\\"{x:1143,y:967,t:1527009199378};\\\", \\\"{x:1144,y:967,t:1527009199418};\\\", \\\"{x:1145,y:967,t:1527009199490};\\\", \\\"{x:1146,y:967,t:1527009199514};\\\", \\\"{x:1147,y:967,t:1527009199530};\\\", \\\"{x:1149,y:967,t:1527009199554};\\\", \\\"{x:1150,y:967,t:1527009199571};\\\", \\\"{x:1152,y:967,t:1527009199578};\\\", \\\"{x:1154,y:967,t:1527009199589};\\\", \\\"{x:1159,y:967,t:1527009199606};\\\", \\\"{x:1167,y:967,t:1527009199621};\\\", \\\"{x:1176,y:967,t:1527009199638};\\\", \\\"{x:1182,y:967,t:1527009199656};\\\", \\\"{x:1186,y:967,t:1527009199673};\\\", \\\"{x:1188,y:967,t:1527009199689};\\\", \\\"{x:1189,y:967,t:1527009199706};\\\", \\\"{x:1190,y:967,t:1527009199762};\\\", \\\"{x:1191,y:967,t:1527009199773};\\\", \\\"{x:1192,y:967,t:1527009199789};\\\", \\\"{x:1194,y:967,t:1527009199806};\\\", \\\"{x:1195,y:967,t:1527009199823};\\\", \\\"{x:1196,y:967,t:1527009199839};\\\", \\\"{x:1197,y:967,t:1527009199856};\\\", \\\"{x:1198,y:967,t:1527009199873};\\\", \\\"{x:1199,y:967,t:1527009199890};\\\", \\\"{x:1202,y:967,t:1527009199907};\\\", \\\"{x:1203,y:966,t:1527009199924};\\\", \\\"{x:1205,y:966,t:1527009199939};\\\", \\\"{x:1207,y:965,t:1527009199956};\\\", \\\"{x:1208,y:965,t:1527009199974};\\\", \\\"{x:1210,y:965,t:1527009200051};\\\", \\\"{x:1211,y:965,t:1527009200147};\\\", \\\"{x:1212,y:965,t:1527009200179};\\\", \\\"{x:1213,y:965,t:1527009200191};\\\", \\\"{x:1214,y:965,t:1527009200207};\\\", \\\"{x:1218,y:966,t:1527009200224};\\\", \\\"{x:1226,y:966,t:1527009200241};\\\", \\\"{x:1234,y:967,t:1527009200257};\\\", \\\"{x:1242,y:969,t:1527009200274};\\\", \\\"{x:1253,y:970,t:1527009200291};\\\", \\\"{x:1256,y:970,t:1527009200306};\\\", \\\"{x:1258,y:970,t:1527009200323};\\\", \\\"{x:1260,y:970,t:1527009200346};\\\", \\\"{x:1261,y:970,t:1527009200451};\\\", \\\"{x:1264,y:970,t:1527009200467};\\\", \\\"{x:1269,y:970,t:1527009200475};\\\", \\\"{x:1279,y:970,t:1527009200491};\\\", \\\"{x:1290,y:970,t:1527009200507};\\\", \\\"{x:1297,y:969,t:1527009200523};\\\", \\\"{x:1299,y:969,t:1527009200540};\\\", \\\"{x:1300,y:969,t:1527009200556};\\\", \\\"{x:1300,y:968,t:1527009200730};\\\", \\\"{x:1300,y:967,t:1527009200762};\\\", \\\"{x:1299,y:967,t:1527009200802};\\\", \\\"{x:1300,y:967,t:1527009200882};\\\", \\\"{x:1305,y:967,t:1527009200890};\\\", \\\"{x:1314,y:967,t:1527009200907};\\\", \\\"{x:1329,y:967,t:1527009200924};\\\", \\\"{x:1347,y:967,t:1527009200940};\\\", \\\"{x:1363,y:967,t:1527009200957};\\\", \\\"{x:1377,y:967,t:1527009200974};\\\", \\\"{x:1384,y:967,t:1527009200990};\\\", \\\"{x:1385,y:967,t:1527009201007};\\\", \\\"{x:1386,y:967,t:1527009201034};\\\", \\\"{x:1386,y:966,t:1527009201298};\\\", \\\"{x:1384,y:966,t:1527009201314};\\\", \\\"{x:1383,y:966,t:1527009201330};\\\", \\\"{x:1382,y:966,t:1527009201340};\\\", \\\"{x:1381,y:966,t:1527009201362};\\\", \\\"{x:1381,y:965,t:1527009201426};\\\", \\\"{x:1382,y:965,t:1527009201457};\\\", \\\"{x:1386,y:965,t:1527009201474};\\\", \\\"{x:1398,y:962,t:1527009201491};\\\", \\\"{x:1415,y:962,t:1527009201507};\\\", \\\"{x:1435,y:962,t:1527009201524};\\\", \\\"{x:1455,y:962,t:1527009201540};\\\", \\\"{x:1464,y:962,t:1527009201557};\\\", \\\"{x:1466,y:962,t:1527009201574};\\\", \\\"{x:1464,y:962,t:1527009201763};\\\", \\\"{x:1461,y:962,t:1527009201774};\\\", \\\"{x:1453,y:963,t:1527009201792};\\\", \\\"{x:1445,y:964,t:1527009201809};\\\", \\\"{x:1440,y:964,t:1527009201825};\\\", \\\"{x:1435,y:965,t:1527009201842};\\\", \\\"{x:1434,y:965,t:1527009201859};\\\", \\\"{x:1433,y:965,t:1527009201923};\\\", \\\"{x:1432,y:965,t:1527009202028};\\\", \\\"{x:1431,y:965,t:1527009202043};\\\", \\\"{x:1430,y:965,t:1527009202059};\\\", \\\"{x:1429,y:966,t:1527009202074};\\\", \\\"{x:1428,y:966,t:1527009202139};\\\", \\\"{x:1429,y:966,t:1527009202171};\\\", \\\"{x:1432,y:966,t:1527009202179};\\\", \\\"{x:1439,y:966,t:1527009202192};\\\", \\\"{x:1454,y:966,t:1527009202209};\\\", \\\"{x:1467,y:966,t:1527009202225};\\\", \\\"{x:1477,y:966,t:1527009202241};\\\", \\\"{x:1482,y:966,t:1527009202258};\\\", \\\"{x:1483,y:966,t:1527009202282};\\\", \\\"{x:1482,y:966,t:1527009202796};\\\", \\\"{x:1481,y:966,t:1527009202811};\\\", \\\"{x:1479,y:966,t:1527009202827};\\\", \\\"{x:1479,y:965,t:1527009202851};\\\", \\\"{x:1480,y:965,t:1527009204155};\\\", \\\"{x:1482,y:965,t:1527009204163};\\\", \\\"{x:1485,y:965,t:1527009204177};\\\", \\\"{x:1491,y:964,t:1527009204195};\\\", \\\"{x:1498,y:963,t:1527009204210};\\\", \\\"{x:1517,y:962,t:1527009204227};\\\", \\\"{x:1526,y:962,t:1527009204244};\\\", \\\"{x:1535,y:962,t:1527009204262};\\\", \\\"{x:1541,y:962,t:1527009204277};\\\", \\\"{x:1545,y:962,t:1527009204294};\\\", \\\"{x:1546,y:962,t:1527009204311};\\\", \\\"{x:1547,y:962,t:1527009204327};\\\", \\\"{x:1548,y:962,t:1527009204347};\\\", \\\"{x:1549,y:962,t:1527009204435};\\\", \\\"{x:1550,y:962,t:1527009204459};\\\", \\\"{x:1551,y:962,t:1527009204467};\\\", \\\"{x:1552,y:962,t:1527009204477};\\\", \\\"{x:1554,y:961,t:1527009204494};\\\", \\\"{x:1555,y:961,t:1527009204511};\\\", \\\"{x:1556,y:961,t:1527009204527};\\\", \\\"{x:1557,y:961,t:1527009204579};\\\", \\\"{x:1555,y:961,t:1527009204842};\\\", \\\"{x:1553,y:961,t:1527009204858};\\\", \\\"{x:1552,y:961,t:1527009204866};\\\", \\\"{x:1551,y:961,t:1527009204891};\\\", \\\"{x:1550,y:960,t:1527009204987};\\\", \\\"{x:1550,y:957,t:1527009206026};\\\", \\\"{x:1546,y:947,t:1527009206035};\\\", \\\"{x:1540,y:931,t:1527009206045};\\\", \\\"{x:1511,y:862,t:1527009206062};\\\", \\\"{x:1458,y:751,t:1527009206079};\\\", \\\"{x:1377,y:637,t:1527009206094};\\\", \\\"{x:1297,y:554,t:1527009206111};\\\", \\\"{x:1250,y:501,t:1527009206128};\\\", \\\"{x:1229,y:476,t:1527009206144};\\\", \\\"{x:1226,y:471,t:1527009206161};\\\", \\\"{x:1225,y:470,t:1527009206178};\\\", \\\"{x:1225,y:471,t:1527009206242};\\\", \\\"{x:1227,y:473,t:1527009206250};\\\", \\\"{x:1229,y:475,t:1527009206266};\\\", \\\"{x:1231,y:476,t:1527009206278};\\\", \\\"{x:1241,y:481,t:1527009206295};\\\", \\\"{x:1263,y:490,t:1527009206311};\\\", \\\"{x:1286,y:498,t:1527009206329};\\\", \\\"{x:1310,y:505,t:1527009206346};\\\", \\\"{x:1327,y:510,t:1527009206362};\\\", \\\"{x:1339,y:513,t:1527009206378};\\\", \\\"{x:1338,y:513,t:1527009206498};\\\", \\\"{x:1337,y:513,t:1527009206514};\\\", \\\"{x:1336,y:513,t:1527009206529};\\\", \\\"{x:1335,y:512,t:1527009206545};\\\", \\\"{x:1332,y:512,t:1527009206562};\\\", \\\"{x:1330,y:510,t:1527009206578};\\\", \\\"{x:1329,y:510,t:1527009206595};\\\", \\\"{x:1328,y:509,t:1527009206611};\\\", \\\"{x:1327,y:509,t:1527009206650};\\\", \\\"{x:1325,y:507,t:1527009206662};\\\", \\\"{x:1324,y:506,t:1527009206678};\\\", \\\"{x:1321,y:506,t:1527009206696};\\\", \\\"{x:1319,y:505,t:1527009206712};\\\", \\\"{x:1317,y:504,t:1527009206763};\\\", \\\"{x:1316,y:503,t:1527009206778};\\\", \\\"{x:1315,y:503,t:1527009206795};\\\", \\\"{x:1314,y:502,t:1527009206812};\\\", \\\"{x:1313,y:501,t:1527009206828};\\\", \\\"{x:1313,y:500,t:1527009206922};\\\", \\\"{x:1316,y:503,t:1527009206939};\\\", \\\"{x:1316,y:507,t:1527009206946};\\\", \\\"{x:1318,y:515,t:1527009206963};\\\", \\\"{x:1320,y:522,t:1527009206978};\\\", \\\"{x:1321,y:529,t:1527009206996};\\\", \\\"{x:1322,y:536,t:1527009207012};\\\", \\\"{x:1324,y:540,t:1527009207028};\\\", \\\"{x:1325,y:543,t:1527009207045};\\\", \\\"{x:1325,y:545,t:1527009207062};\\\", \\\"{x:1325,y:550,t:1527009207078};\\\", \\\"{x:1325,y:556,t:1527009207095};\\\", \\\"{x:1325,y:560,t:1527009207112};\\\", \\\"{x:1325,y:563,t:1527009207130};\\\", \\\"{x:1325,y:566,t:1527009207146};\\\", \\\"{x:1325,y:570,t:1527009207163};\\\", \\\"{x:1324,y:573,t:1527009207180};\\\", \\\"{x:1324,y:575,t:1527009207196};\\\", \\\"{x:1323,y:579,t:1527009207212};\\\", \\\"{x:1323,y:583,t:1527009207230};\\\", \\\"{x:1323,y:588,t:1527009207246};\\\", \\\"{x:1321,y:594,t:1527009207263};\\\", \\\"{x:1320,y:602,t:1527009207279};\\\", \\\"{x:1319,y:607,t:1527009207296};\\\", \\\"{x:1319,y:611,t:1527009207312};\\\", \\\"{x:1316,y:619,t:1527009207329};\\\", \\\"{x:1315,y:628,t:1527009207345};\\\", \\\"{x:1312,y:645,t:1527009207362};\\\", \\\"{x:1307,y:661,t:1527009207379};\\\", \\\"{x:1304,y:674,t:1527009207396};\\\", \\\"{x:1299,y:687,t:1527009207413};\\\", \\\"{x:1295,y:696,t:1527009207430};\\\", \\\"{x:1292,y:702,t:1527009207446};\\\", \\\"{x:1288,y:710,t:1527009207462};\\\", \\\"{x:1285,y:716,t:1527009207479};\\\", \\\"{x:1282,y:724,t:1527009207497};\\\", \\\"{x:1279,y:735,t:1527009207513};\\\", \\\"{x:1275,y:747,t:1527009207529};\\\", \\\"{x:1273,y:759,t:1527009207546};\\\", \\\"{x:1273,y:767,t:1527009207562};\\\", \\\"{x:1273,y:775,t:1527009207580};\\\", \\\"{x:1273,y:780,t:1527009207596};\\\", \\\"{x:1275,y:786,t:1527009207613};\\\", \\\"{x:1276,y:791,t:1527009207630};\\\", \\\"{x:1279,y:797,t:1527009207647};\\\", \\\"{x:1283,y:803,t:1527009207663};\\\", \\\"{x:1284,y:808,t:1527009207679};\\\", \\\"{x:1287,y:811,t:1527009207697};\\\", \\\"{x:1288,y:815,t:1527009207712};\\\", \\\"{x:1290,y:821,t:1527009207729};\\\", \\\"{x:1294,y:830,t:1527009207746};\\\", \\\"{x:1296,y:836,t:1527009207763};\\\", \\\"{x:1298,y:841,t:1527009207779};\\\", \\\"{x:1300,y:846,t:1527009207796};\\\", \\\"{x:1301,y:849,t:1527009207812};\\\", \\\"{x:1302,y:852,t:1527009207829};\\\", \\\"{x:1303,y:853,t:1527009207846};\\\", \\\"{x:1303,y:856,t:1527009207864};\\\", \\\"{x:1304,y:858,t:1527009207880};\\\", \\\"{x:1305,y:859,t:1527009207896};\\\", \\\"{x:1305,y:861,t:1527009207913};\\\", \\\"{x:1305,y:863,t:1527009207930};\\\", \\\"{x:1305,y:869,t:1527009207946};\\\", \\\"{x:1305,y:872,t:1527009207963};\\\", \\\"{x:1305,y:877,t:1527009207979};\\\", \\\"{x:1305,y:882,t:1527009207996};\\\", \\\"{x:1305,y:886,t:1527009208014};\\\", \\\"{x:1305,y:889,t:1527009208029};\\\", \\\"{x:1305,y:892,t:1527009208046};\\\", \\\"{x:1305,y:894,t:1527009208063};\\\", \\\"{x:1305,y:895,t:1527009208079};\\\", \\\"{x:1306,y:895,t:1527009208098};\\\", \\\"{x:1306,y:896,t:1527009208155};\\\", \\\"{x:1306,y:897,t:1527009208164};\\\", \\\"{x:1306,y:899,t:1527009208180};\\\", \\\"{x:1306,y:901,t:1527009208197};\\\", \\\"{x:1306,y:903,t:1527009208214};\\\", \\\"{x:1306,y:904,t:1527009208230};\\\", \\\"{x:1306,y:906,t:1527009208275};\\\", \\\"{x:1306,y:907,t:1527009208516};\\\", \\\"{x:1308,y:908,t:1527009208531};\\\", \\\"{x:1308,y:909,t:1527009208546};\\\", \\\"{x:1308,y:910,t:1527009208564};\\\", \\\"{x:1308,y:912,t:1527009208587};\\\", \\\"{x:1308,y:913,t:1527009208732};\\\", \\\"{x:1306,y:913,t:1527009208747};\\\", \\\"{x:1299,y:915,t:1527009208764};\\\", \\\"{x:1293,y:916,t:1527009208780};\\\", \\\"{x:1282,y:916,t:1527009208798};\\\", \\\"{x:1271,y:916,t:1527009208813};\\\", \\\"{x:1260,y:916,t:1527009208830};\\\", \\\"{x:1240,y:916,t:1527009208847};\\\", \\\"{x:1220,y:916,t:1527009208863};\\\", \\\"{x:1201,y:916,t:1527009208881};\\\", \\\"{x:1190,y:918,t:1527009208897};\\\", \\\"{x:1177,y:924,t:1527009208914};\\\", \\\"{x:1167,y:928,t:1527009208930};\\\", \\\"{x:1164,y:930,t:1527009208948};\\\", \\\"{x:1163,y:930,t:1527009209011};\\\", \\\"{x:1162,y:929,t:1527009209244};\\\", \\\"{x:1161,y:928,t:1527009209251};\\\", \\\"{x:1161,y:927,t:1527009209275};\\\", \\\"{x:1161,y:925,t:1527009209299};\\\", \\\"{x:1160,y:924,t:1527009209331};\\\", \\\"{x:1160,y:922,t:1527009209379};\\\", \\\"{x:1160,y:921,t:1527009209395};\\\", \\\"{x:1159,y:920,t:1527009209419};\\\", \\\"{x:1158,y:919,t:1527009209431};\\\", \\\"{x:1158,y:917,t:1527009209459};\\\", \\\"{x:1158,y:916,t:1527009209507};\\\", \\\"{x:1157,y:915,t:1527009209523};\\\", \\\"{x:1157,y:914,t:1527009209538};\\\", \\\"{x:1157,y:913,t:1527009209619};\\\", \\\"{x:1156,y:913,t:1527009209851};\\\", \\\"{x:1157,y:913,t:1527009209923};\\\", \\\"{x:1161,y:916,t:1527009209932};\\\", \\\"{x:1176,y:929,t:1527009209949};\\\", \\\"{x:1192,y:942,t:1527009209965};\\\", \\\"{x:1210,y:955,t:1527009209982};\\\", \\\"{x:1237,y:969,t:1527009209999};\\\", \\\"{x:1261,y:980,t:1527009210015};\\\", \\\"{x:1269,y:984,t:1527009210032};\\\", \\\"{x:1270,y:984,t:1527009210049};\\\", \\\"{x:1266,y:984,t:1527009210114};\\\", \\\"{x:1244,y:984,t:1527009210132};\\\", \\\"{x:1239,y:983,t:1527009210148};\\\", \\\"{x:1239,y:982,t:1527009210170};\\\", \\\"{x:1235,y:983,t:1527009210226};\\\", \\\"{x:1232,y:983,t:1527009210242};\\\", \\\"{x:1230,y:983,t:1527009210250};\\\", \\\"{x:1229,y:983,t:1527009210264};\\\", \\\"{x:1228,y:983,t:1527009210281};\\\", \\\"{x:1227,y:983,t:1527009210370};\\\", \\\"{x:1226,y:983,t:1527009210382};\\\", \\\"{x:1223,y:983,t:1527009210398};\\\", \\\"{x:1215,y:983,t:1527009210415};\\\", \\\"{x:1209,y:983,t:1527009210432};\\\", \\\"{x:1204,y:983,t:1527009210448};\\\", \\\"{x:1199,y:983,t:1527009210466};\\\", \\\"{x:1195,y:983,t:1527009210481};\\\", \\\"{x:1189,y:983,t:1527009210499};\\\", \\\"{x:1186,y:981,t:1527009210516};\\\", \\\"{x:1181,y:978,t:1527009210531};\\\", \\\"{x:1176,y:973,t:1527009210548};\\\", \\\"{x:1173,y:971,t:1527009210565};\\\", \\\"{x:1171,y:968,t:1527009210582};\\\", \\\"{x:1170,y:966,t:1527009210598};\\\", \\\"{x:1169,y:964,t:1527009210616};\\\", \\\"{x:1169,y:963,t:1527009210634};\\\", \\\"{x:1169,y:961,t:1527009210650};\\\", \\\"{x:1168,y:963,t:1527009211379};\\\", \\\"{x:1161,y:964,t:1527009211386};\\\", \\\"{x:1155,y:967,t:1527009211400};\\\", \\\"{x:1139,y:973,t:1527009211415};\\\", \\\"{x:1123,y:977,t:1527009211433};\\\", \\\"{x:1105,y:982,t:1527009211449};\\\", \\\"{x:1091,y:983,t:1527009211465};\\\", \\\"{x:1082,y:983,t:1527009211482};\\\", \\\"{x:1079,y:984,t:1527009211500};\\\", \\\"{x:1085,y:984,t:1527009211586};\\\", \\\"{x:1094,y:984,t:1527009211600};\\\", \\\"{x:1119,y:984,t:1527009211617};\\\", \\\"{x:1157,y:984,t:1527009211633};\\\", \\\"{x:1205,y:984,t:1527009211650};\\\", \\\"{x:1259,y:984,t:1527009211666};\\\", \\\"{x:1282,y:984,t:1527009211683};\\\", \\\"{x:1289,y:984,t:1527009211699};\\\", \\\"{x:1292,y:984,t:1527009211717};\\\", \\\"{x:1294,y:985,t:1527009211732};\\\", \\\"{x:1294,y:986,t:1527009211754};\\\", \\\"{x:1294,y:985,t:1527009211922};\\\", \\\"{x:1294,y:984,t:1527009211933};\\\", \\\"{x:1294,y:982,t:1527009211949};\\\", \\\"{x:1296,y:979,t:1527009211967};\\\", \\\"{x:1299,y:975,t:1527009211984};\\\", \\\"{x:1307,y:970,t:1527009211999};\\\", \\\"{x:1311,y:967,t:1527009212017};\\\", \\\"{x:1315,y:965,t:1527009212034};\\\", \\\"{x:1318,y:964,t:1527009212050};\\\", \\\"{x:1320,y:964,t:1527009212067};\\\", \\\"{x:1322,y:964,t:1527009212083};\\\", \\\"{x:1324,y:964,t:1527009212106};\\\", \\\"{x:1325,y:964,t:1527009212138};\\\", \\\"{x:1325,y:965,t:1527009212150};\\\", \\\"{x:1324,y:965,t:1527009212330};\\\", \\\"{x:1323,y:965,t:1527009212354};\\\", \\\"{x:1322,y:965,t:1527009212370};\\\", \\\"{x:1321,y:965,t:1527009212418};\\\", \\\"{x:1320,y:964,t:1527009212435};\\\", \\\"{x:1319,y:963,t:1527009212490};\\\", \\\"{x:1318,y:963,t:1527009212531};\\\", \\\"{x:1317,y:963,t:1527009212546};\\\", \\\"{x:1316,y:963,t:1527009212555};\\\", \\\"{x:1315,y:963,t:1527009212594};\\\", \\\"{x:1314,y:962,t:1527009212722};\\\", \\\"{x:1313,y:962,t:1527009218292};\\\", \\\"{x:1314,y:962,t:1527009253435};\\\", \\\"{x:1315,y:962,t:1527009253459};\\\", \\\"{x:1316,y:962,t:1527009253491};\\\", \\\"{x:1318,y:962,t:1527009253523};\\\", \\\"{x:1320,y:963,t:1527009253539};\\\", \\\"{x:1319,y:963,t:1527009253836};\\\", \\\"{x:1317,y:963,t:1527009253852};\\\", \\\"{x:1316,y:963,t:1527009253883};\\\", \\\"{x:1317,y:963,t:1527009270483};\\\", \\\"{x:1318,y:963,t:1527009270548};\\\", \\\"{x:1319,y:963,t:1527009270571};\\\", \\\"{x:1320,y:963,t:1527009270643};\\\", \\\"{x:1319,y:963,t:1527009279317};\\\", \\\"{x:1318,y:963,t:1527009279564};\\\", \\\"{x:1318,y:962,t:1527009279661};\\\", \\\"{x:1317,y:961,t:1527009279693};\\\", \\\"{x:1315,y:961,t:1527009285341};\\\", \\\"{x:1313,y:960,t:1527009285349};\\\", \\\"{x:1309,y:958,t:1527009285366};\\\", \\\"{x:1307,y:956,t:1527009313734};\\\", \\\"{x:1305,y:956,t:1527009313741};\\\", \\\"{x:1288,y:939,t:1527009313757};\\\", \\\"{x:1217,y:715,t:1527009313774};\\\", \\\"{x:1103,y:350,t:1527009313791};\\\", \\\"{x:972,y:56,t:1527009313807};\\\", \\\"{x:850,y:16,t:1527009313823};\\\", \\\"{x:771,y:16,t:1527009313841};\\\", \\\"{x:737,y:16,t:1527009313857};\\\", \\\"{x:720,y:16,t:1527009313873};\\\", \\\"{x:715,y:16,t:1527009313891};\\\", \\\"{x:714,y:16,t:1527009313957};\\\", \\\"{x:714,y:24,t:1527009313973};\\\", \\\"{x:712,y:48,t:1527009313991};\\\", \\\"{x:711,y:101,t:1527009314007};\\\", \\\"{x:696,y:183,t:1527009314024};\\\", \\\"{x:677,y:250,t:1527009314041};\\\", \\\"{x:664,y:288,t:1527009314057};\\\", \\\"{x:649,y:318,t:1527009314074};\\\", \\\"{x:632,y:355,t:1527009314091};\\\", \\\"{x:617,y:390,t:1527009314108};\\\", \\\"{x:609,y:421,t:1527009314124};\\\", \\\"{x:601,y:453,t:1527009314141};\\\", \\\"{x:597,y:465,t:1527009314158};\\\", \\\"{x:594,y:471,t:1527009314174};\\\", \\\"{x:591,y:473,t:1527009314190};\\\", \\\"{x:581,y:477,t:1527009314208};\\\", \\\"{x:561,y:485,t:1527009314224};\\\", \\\"{x:541,y:496,t:1527009314241};\\\", \\\"{x:520,y:511,t:1527009314258};\\\", \\\"{x:499,y:523,t:1527009314274};\\\", \\\"{x:482,y:527,t:1527009314290};\\\", \\\"{x:464,y:527,t:1527009314314};\\\", \\\"{x:453,y:521,t:1527009314331};\\\", \\\"{x:445,y:517,t:1527009314348};\\\", \\\"{x:440,y:516,t:1527009314365};\\\", \\\"{x:435,y:517,t:1527009314387};\\\", \\\"{x:425,y:523,t:1527009314402};\\\", \\\"{x:410,y:529,t:1527009314420};\\\", \\\"{x:400,y:534,t:1527009314435};\\\", \\\"{x:399,y:534,t:1527009314452};\\\", \\\"{x:398,y:536,t:1527009314716};\\\", \\\"{x:399,y:543,t:1527009314724};\\\", \\\"{x:401,y:552,t:1527009314737};\\\", \\\"{x:408,y:580,t:1527009314753};\\\", \\\"{x:421,y:620,t:1527009314769};\\\", \\\"{x:428,y:654,t:1527009314786};\\\", \\\"{x:438,y:667,t:1527009314803};\\\", \\\"{x:438,y:682,t:1527009314820};\\\", \\\"{x:438,y:686,t:1527009314836};\\\", \\\"{x:439,y:685,t:1527009315021};\\\", \\\"{x:440,y:685,t:1527009315037};\\\", \\\"{x:445,y:691,t:1527009315053};\\\", \\\"{x:453,y:697,t:1527009315071};\\\", \\\"{x:459,y:705,t:1527009315088};\\\", \\\"{x:466,y:713,t:1527009315104};\\\", \\\"{x:473,y:722,t:1527009315122};\\\", \\\"{x:474,y:722,t:1527009315137};\\\", \\\"{x:476,y:724,t:1527009315153};\\\", \\\"{x:477,y:724,t:1527009315173};\\\", \\\"{x:478,y:725,t:1527009315254};\\\", \\\"{x:478,y:725,t:1527009315353};\\\", \\\"{x:477,y:725,t:1527009315644};\\\", \\\"{x:475,y:724,t:1527009315660};\\\", \\\"{x:473,y:724,t:1527009315670};\\\", \\\"{x:467,y:721,t:1527009315686};\\\", \\\"{x:466,y:721,t:1527009315703};\\\", \\\"{x:462,y:720,t:1527009315721};\\\", \\\"{x:457,y:718,t:1527009315736};\\\", \\\"{x:456,y:717,t:1527009315753};\\\", \\\"{x:452,y:714,t:1527009315770};\\\", \\\"{x:450,y:713,t:1527009315786};\\\", \\\"{x:449,y:713,t:1527009315803};\\\", \\\"{x:448,y:713,t:1527009315821};\\\", \\\"{x:447,y:713,t:1527009315837};\\\", \\\"{x:446,y:712,t:1527009315854};\\\" ] }, { \\\"rt\\\": 8121, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 471188, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:446,y:701,t:1527009318932};\\\", \\\"{x:452,y:681,t:1527009318940};\\\", \\\"{x:475,y:598,t:1527009318956};\\\", \\\"{x:513,y:518,t:1527009318973};\\\", \\\"{x:578,y:431,t:1527009318990};\\\", \\\"{x:666,y:350,t:1527009319007};\\\", \\\"{x:759,y:294,t:1527009319023};\\\", \\\"{x:833,y:250,t:1527009319040};\\\", \\\"{x:901,y:225,t:1527009319056};\\\", \\\"{x:948,y:220,t:1527009319073};\\\", \\\"{x:980,y:220,t:1527009319089};\\\", \\\"{x:1003,y:225,t:1527009319107};\\\", \\\"{x:1027,y:240,t:1527009319123};\\\", \\\"{x:1057,y:269,t:1527009319140};\\\", \\\"{x:1070,y:287,t:1527009319157};\\\", \\\"{x:1082,y:304,t:1527009319173};\\\", \\\"{x:1087,y:320,t:1527009319192};\\\", \\\"{x:1094,y:343,t:1527009319207};\\\", \\\"{x:1101,y:381,t:1527009319224};\\\", \\\"{x:1109,y:434,t:1527009319240};\\\", \\\"{x:1119,y:499,t:1527009319257};\\\", \\\"{x:1127,y:547,t:1527009319274};\\\", \\\"{x:1136,y:580,t:1527009319290};\\\", \\\"{x:1142,y:604,t:1527009319307};\\\", \\\"{x:1155,y:635,t:1527009319325};\\\", \\\"{x:1159,y:648,t:1527009319340};\\\", \\\"{x:1177,y:688,t:1527009319357};\\\", \\\"{x:1183,y:707,t:1527009319374};\\\", \\\"{x:1190,y:720,t:1527009319390};\\\", \\\"{x:1190,y:726,t:1527009319406};\\\", \\\"{x:1190,y:733,t:1527009319424};\\\", \\\"{x:1187,y:743,t:1527009319439};\\\", \\\"{x:1177,y:758,t:1527009319457};\\\", \\\"{x:1166,y:769,t:1527009319474};\\\", \\\"{x:1152,y:779,t:1527009319490};\\\", \\\"{x:1135,y:786,t:1527009319507};\\\", \\\"{x:1122,y:797,t:1527009319524};\\\", \\\"{x:1112,y:806,t:1527009319540};\\\", \\\"{x:1105,y:819,t:1527009319557};\\\", \\\"{x:1103,y:823,t:1527009319574};\\\", \\\"{x:1104,y:825,t:1527009319596};\\\", \\\"{x:1105,y:826,t:1527009319606};\\\", \\\"{x:1107,y:828,t:1527009319623};\\\", \\\"{x:1109,y:833,t:1527009319640};\\\", \\\"{x:1112,y:843,t:1527009319657};\\\", \\\"{x:1113,y:855,t:1527009319674};\\\", \\\"{x:1113,y:866,t:1527009319691};\\\", \\\"{x:1114,y:873,t:1527009319706};\\\", \\\"{x:1114,y:875,t:1527009319724};\\\", \\\"{x:1115,y:875,t:1527009319740};\\\", \\\"{x:1118,y:874,t:1527009319780};\\\", \\\"{x:1121,y:868,t:1527009319790};\\\", \\\"{x:1126,y:857,t:1527009319806};\\\", \\\"{x:1133,y:837,t:1527009319824};\\\", \\\"{x:1143,y:819,t:1527009319840};\\\", \\\"{x:1161,y:791,t:1527009319857};\\\", \\\"{x:1173,y:767,t:1527009319873};\\\", \\\"{x:1184,y:741,t:1527009319891};\\\", \\\"{x:1191,y:715,t:1527009319907};\\\", \\\"{x:1201,y:681,t:1527009319923};\\\", \\\"{x:1208,y:623,t:1527009319940};\\\", \\\"{x:1210,y:586,t:1527009319956};\\\", \\\"{x:1210,y:547,t:1527009319974};\\\", \\\"{x:1206,y:516,t:1527009319991};\\\", \\\"{x:1200,y:495,t:1527009320007};\\\", \\\"{x:1195,y:486,t:1527009320024};\\\", \\\"{x:1189,y:476,t:1527009320040};\\\", \\\"{x:1187,y:473,t:1527009320057};\\\", \\\"{x:1185,y:471,t:1527009320074};\\\", \\\"{x:1183,y:469,t:1527009320091};\\\", \\\"{x:1179,y:463,t:1527009320107};\\\", \\\"{x:1171,y:452,t:1527009320124};\\\", \\\"{x:1161,y:442,t:1527009320141};\\\", \\\"{x:1156,y:439,t:1527009320158};\\\", \\\"{x:1153,y:437,t:1527009320174};\\\", \\\"{x:1148,y:438,t:1527009320191};\\\", \\\"{x:1142,y:445,t:1527009320208};\\\", \\\"{x:1140,y:463,t:1527009320224};\\\", \\\"{x:1140,y:491,t:1527009320240};\\\", \\\"{x:1140,y:519,t:1527009320258};\\\", \\\"{x:1140,y:538,t:1527009320273};\\\", \\\"{x:1140,y:548,t:1527009320290};\\\", \\\"{x:1140,y:550,t:1527009320308};\\\", \\\"{x:1140,y:552,t:1527009320323};\\\", \\\"{x:1138,y:555,t:1527009320340};\\\", \\\"{x:1137,y:557,t:1527009320357};\\\", \\\"{x:1135,y:558,t:1527009320374};\\\", \\\"{x:1132,y:558,t:1527009320391};\\\", \\\"{x:1128,y:558,t:1527009320407};\\\", \\\"{x:1128,y:559,t:1527009320424};\\\", \\\"{x:1123,y:562,t:1527009320440};\\\", \\\"{x:1114,y:570,t:1527009320458};\\\", \\\"{x:1108,y:574,t:1527009320474};\\\", \\\"{x:1105,y:575,t:1527009320491};\\\", \\\"{x:1103,y:576,t:1527009320508};\\\", \\\"{x:1102,y:576,t:1527009320524};\\\", \\\"{x:1106,y:576,t:1527009320588};\\\", \\\"{x:1114,y:576,t:1527009320596};\\\", \\\"{x:1125,y:576,t:1527009320607};\\\", \\\"{x:1155,y:576,t:1527009320624};\\\", \\\"{x:1192,y:576,t:1527009320641};\\\", \\\"{x:1223,y:576,t:1527009320657};\\\", \\\"{x:1245,y:576,t:1527009320674};\\\", \\\"{x:1261,y:576,t:1527009320690};\\\", \\\"{x:1269,y:576,t:1527009320707};\\\", \\\"{x:1271,y:576,t:1527009320724};\\\", \\\"{x:1272,y:576,t:1527009320740};\\\", \\\"{x:1274,y:576,t:1527009320758};\\\", \\\"{x:1278,y:576,t:1527009320775};\\\", \\\"{x:1289,y:576,t:1527009320791};\\\", \\\"{x:1303,y:576,t:1527009320808};\\\", \\\"{x:1312,y:576,t:1527009320824};\\\", \\\"{x:1316,y:575,t:1527009320841};\\\", \\\"{x:1314,y:574,t:1527009320950};\\\", \\\"{x:1311,y:573,t:1527009320958};\\\", \\\"{x:1288,y:572,t:1527009320975};\\\", \\\"{x:1232,y:567,t:1527009320992};\\\", \\\"{x:1138,y:565,t:1527009321009};\\\", \\\"{x:1030,y:565,t:1527009321025};\\\", \\\"{x:910,y:563,t:1527009321044};\\\", \\\"{x:791,y:563,t:1527009321057};\\\", \\\"{x:691,y:563,t:1527009321075};\\\", \\\"{x:603,y:563,t:1527009321088};\\\", \\\"{x:536,y:563,t:1527009321105};\\\", \\\"{x:492,y:559,t:1527009321122};\\\", \\\"{x:469,y:554,t:1527009321139};\\\", \\\"{x:454,y:553,t:1527009321158};\\\", \\\"{x:447,y:553,t:1527009321174};\\\", \\\"{x:439,y:553,t:1527009321191};\\\", \\\"{x:423,y:553,t:1527009321207};\\\", \\\"{x:406,y:553,t:1527009321224};\\\", \\\"{x:389,y:555,t:1527009321241};\\\", \\\"{x:375,y:557,t:1527009321259};\\\", \\\"{x:360,y:560,t:1527009321275};\\\", \\\"{x:343,y:562,t:1527009321292};\\\", \\\"{x:339,y:562,t:1527009321308};\\\", \\\"{x:338,y:562,t:1527009321324};\\\", \\\"{x:337,y:562,t:1527009321389};\\\", \\\"{x:337,y:561,t:1527009321396};\\\", \\\"{x:337,y:559,t:1527009321409};\\\", \\\"{x:347,y:557,t:1527009321425};\\\", \\\"{x:369,y:554,t:1527009321442};\\\", \\\"{x:391,y:551,t:1527009321459};\\\", \\\"{x:417,y:549,t:1527009321474};\\\", \\\"{x:433,y:549,t:1527009321491};\\\", \\\"{x:437,y:549,t:1527009321509};\\\", \\\"{x:433,y:549,t:1527009321548};\\\", \\\"{x:427,y:549,t:1527009321559};\\\", \\\"{x:405,y:548,t:1527009321575};\\\", \\\"{x:379,y:544,t:1527009321592};\\\", \\\"{x:352,y:543,t:1527009321609};\\\", \\\"{x:328,y:543,t:1527009321625};\\\", \\\"{x:301,y:543,t:1527009321642};\\\", \\\"{x:280,y:543,t:1527009321659};\\\", \\\"{x:268,y:543,t:1527009321676};\\\", \\\"{x:260,y:543,t:1527009321691};\\\", \\\"{x:259,y:543,t:1527009321709};\\\", \\\"{x:257,y:543,t:1527009321780};\\\", \\\"{x:255,y:543,t:1527009321791};\\\", \\\"{x:247,y:543,t:1527009321809};\\\", \\\"{x:235,y:545,t:1527009321826};\\\", \\\"{x:216,y:547,t:1527009321841};\\\", \\\"{x:203,y:550,t:1527009321859};\\\", \\\"{x:198,y:552,t:1527009321875};\\\", \\\"{x:207,y:552,t:1527009321908};\\\", \\\"{x:223,y:552,t:1527009321915};\\\", \\\"{x:246,y:552,t:1527009321926};\\\", \\\"{x:313,y:552,t:1527009321942};\\\", \\\"{x:401,y:552,t:1527009321958};\\\", \\\"{x:460,y:552,t:1527009321975};\\\", \\\"{x:510,y:552,t:1527009321993};\\\", \\\"{x:539,y:552,t:1527009322008};\\\", \\\"{x:555,y:552,t:1527009322025};\\\", \\\"{x:558,y:552,t:1527009322042};\\\", \\\"{x:561,y:551,t:1527009322108};\\\", \\\"{x:565,y:548,t:1527009322126};\\\", \\\"{x:569,y:542,t:1527009322141};\\\", \\\"{x:571,y:535,t:1527009322159};\\\", \\\"{x:577,y:528,t:1527009322175};\\\", \\\"{x:583,y:523,t:1527009322193};\\\", \\\"{x:586,y:520,t:1527009322209};\\\", \\\"{x:587,y:519,t:1527009322226};\\\", \\\"{x:587,y:518,t:1527009322243};\\\", \\\"{x:587,y:516,t:1527009322293};\\\", \\\"{x:587,y:512,t:1527009322308};\\\", \\\"{x:588,y:509,t:1527009322326};\\\", \\\"{x:590,y:508,t:1527009322342};\\\", \\\"{x:591,y:507,t:1527009322359};\\\", \\\"{x:593,y:505,t:1527009322376};\\\", \\\"{x:594,y:504,t:1527009322420};\\\", \\\"{x:594,y:502,t:1527009322461};\\\", \\\"{x:594,y:501,t:1527009322476};\\\", \\\"{x:596,y:500,t:1527009322493};\\\", \\\"{x:596,y:499,t:1527009322509};\\\", \\\"{x:597,y:498,t:1527009322636};\\\", \\\"{x:601,y:499,t:1527009322644};\\\", \\\"{x:610,y:505,t:1527009322659};\\\", \\\"{x:634,y:511,t:1527009322676};\\\", \\\"{x:706,y:523,t:1527009322693};\\\", \\\"{x:758,y:534,t:1527009322710};\\\", \\\"{x:788,y:539,t:1527009322726};\\\", \\\"{x:809,y:542,t:1527009322743};\\\", \\\"{x:823,y:545,t:1527009322759};\\\", \\\"{x:830,y:547,t:1527009322776};\\\", \\\"{x:834,y:548,t:1527009322793};\\\", \\\"{x:836,y:548,t:1527009322812};\\\", \\\"{x:837,y:548,t:1527009322825};\\\", \\\"{x:838,y:548,t:1527009322843};\\\", \\\"{x:839,y:548,t:1527009322860};\\\", \\\"{x:841,y:548,t:1527009322877};\\\", \\\"{x:837,y:548,t:1527009323187};\\\", \\\"{x:829,y:547,t:1527009323196};\\\", \\\"{x:815,y:546,t:1527009323209};\\\", \\\"{x:790,y:540,t:1527009323227};\\\", \\\"{x:762,y:533,t:1527009323243};\\\", \\\"{x:721,y:522,t:1527009323261};\\\", \\\"{x:700,y:514,t:1527009323277};\\\", \\\"{x:688,y:511,t:1527009323293};\\\", \\\"{x:683,y:509,t:1527009323310};\\\", \\\"{x:681,y:509,t:1527009323326};\\\", \\\"{x:679,y:509,t:1527009323372};\\\", \\\"{x:678,y:509,t:1527009323380};\\\", \\\"{x:675,y:509,t:1527009323396};\\\", \\\"{x:674,y:509,t:1527009323410};\\\", \\\"{x:669,y:509,t:1527009323427};\\\", \\\"{x:663,y:509,t:1527009323443};\\\", \\\"{x:656,y:509,t:1527009323460};\\\", \\\"{x:650,y:509,t:1527009323476};\\\", \\\"{x:643,y:509,t:1527009323493};\\\", \\\"{x:637,y:509,t:1527009323510};\\\", \\\"{x:631,y:510,t:1527009323526};\\\", \\\"{x:626,y:510,t:1527009323544};\\\", \\\"{x:623,y:510,t:1527009323561};\\\", \\\"{x:622,y:510,t:1527009323577};\\\", \\\"{x:621,y:510,t:1527009323594};\\\", \\\"{x:620,y:510,t:1527009323611};\\\", \\\"{x:617,y:510,t:1527009323627};\\\", \\\"{x:615,y:509,t:1527009323644};\\\", \\\"{x:615,y:508,t:1527009323693};\\\", \\\"{x:613,y:507,t:1527009323708};\\\", \\\"{x:613,y:506,t:1527009323716};\\\", \\\"{x:613,y:505,t:1527009323732};\\\", \\\"{x:612,y:505,t:1527009323744};\\\", \\\"{x:612,y:504,t:1527009323761};\\\", \\\"{x:612,y:503,t:1527009323780};\\\", \\\"{x:612,y:507,t:1527009324341};\\\", \\\"{x:612,y:521,t:1527009324350};\\\", \\\"{x:612,y:534,t:1527009324362};\\\", \\\"{x:612,y:564,t:1527009324378};\\\", \\\"{x:608,y:585,t:1527009324394};\\\", \\\"{x:599,y:612,t:1527009324411};\\\", \\\"{x:587,y:641,t:1527009324428};\\\", \\\"{x:582,y:650,t:1527009324444};\\\", \\\"{x:581,y:657,t:1527009324461};\\\", \\\"{x:580,y:663,t:1527009324478};\\\", \\\"{x:578,y:667,t:1527009324494};\\\", \\\"{x:576,y:675,t:1527009324511};\\\", \\\"{x:573,y:684,t:1527009324528};\\\", \\\"{x:570,y:692,t:1527009324544};\\\", \\\"{x:567,y:699,t:1527009324561};\\\", \\\"{x:565,y:703,t:1527009324578};\\\", \\\"{x:565,y:705,t:1527009324604};\\\", \\\"{x:565,y:707,t:1527009324636};\\\", \\\"{x:565,y:708,t:1527009324644};\\\", \\\"{x:565,y:713,t:1527009324660};\\\", \\\"{x:565,y:718,t:1527009324678};\\\", \\\"{x:560,y:724,t:1527009324695};\\\", \\\"{x:555,y:731,t:1527009324710};\\\", \\\"{x:551,y:734,t:1527009324728};\\\", \\\"{x:550,y:735,t:1527009324744};\\\", \\\"{x:550,y:736,t:1527009324762};\\\", \\\"{x:549,y:736,t:1527009324803};\\\", \\\"{x:547,y:736,t:1527009324828};\\\", \\\"{x:546,y:736,t:1527009324852};\\\", \\\"{x:544,y:736,t:1527009324862};\\\", \\\"{x:541,y:737,t:1527009324879};\\\", \\\"{x:539,y:738,t:1527009324900};\\\", \\\"{x:537,y:738,t:1527009324989};\\\", \\\"{x:536,y:738,t:1527009324996};\\\", \\\"{x:534,y:738,t:1527009325024};\\\", \\\"{x:533,y:738,t:1527009325027};\\\", \\\"{x:530,y:739,t:1527009325045};\\\", \\\"{x:529,y:739,t:1527009325076};\\\", \\\"{x:527,y:738,t:1527009325092};\\\", \\\"{x:527,y:736,t:1527009325100};\\\", \\\"{x:526,y:732,t:1527009325112};\\\", \\\"{x:525,y:714,t:1527009325128};\\\", \\\"{x:525,y:682,t:1527009325145};\\\", \\\"{x:525,y:650,t:1527009325161};\\\", \\\"{x:525,y:611,t:1527009325177};\\\", \\\"{x:529,y:580,t:1527009325195};\\\", \\\"{x:548,y:530,t:1527009325211};\\\", \\\"{x:558,y:511,t:1527009325228};\\\", \\\"{x:565,y:498,t:1527009325245};\\\", \\\"{x:568,y:492,t:1527009325262};\\\", \\\"{x:570,y:488,t:1527009325278};\\\", \\\"{x:571,y:486,t:1527009325300};\\\" ] }, { \\\"rt\\\": 39810, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 512230, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -C -C -H -C -C -C -C -P -C -C -G -G -G -E -E -A -C -C -G -C -H -O -O -O -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:571,y:485,t:1527009327477};\\\", \\\"{x:570,y:485,t:1527009327494};\\\", \\\"{x:569,y:484,t:1527009327500};\\\", \\\"{x:568,y:484,t:1527009327620};\\\", \\\"{x:567,y:484,t:1527009327652};\\\", \\\"{x:566,y:484,t:1527009327668};\\\", \\\"{x:566,y:483,t:1527009327804};\\\", \\\"{x:565,y:482,t:1527009328228};\\\", \\\"{x:564,y:482,t:1527009328259};\\\", \\\"{x:563,y:481,t:1527009328276};\\\", \\\"{x:562,y:480,t:1527009328316};\\\", \\\"{x:561,y:480,t:1527009328332};\\\", \\\"{x:560,y:480,t:1527009328348};\\\", \\\"{x:560,y:479,t:1527009328363};\\\", \\\"{x:559,y:479,t:1527009328381};\\\", \\\"{x:558,y:479,t:1527009328404};\\\", \\\"{x:557,y:479,t:1527009328420};\\\", \\\"{x:557,y:478,t:1527009328431};\\\", \\\"{x:556,y:478,t:1527009328732};\\\", \\\"{x:555,y:477,t:1527009328748};\\\", \\\"{x:555,y:476,t:1527009328764};\\\", \\\"{x:554,y:476,t:1527009328788};\\\", \\\"{x:553,y:476,t:1527009328798};\\\", \\\"{x:553,y:475,t:1527009333595};\\\", \\\"{x:581,y:440,t:1527009333607};\\\", \\\"{x:785,y:266,t:1527009333625};\\\", \\\"{x:1016,y:71,t:1527009333641};\\\", \\\"{x:1263,y:16,t:1527009333658};\\\", \\\"{x:1688,y:16,t:1527009333674};\\\", \\\"{x:1919,y:16,t:1527009333692};\\\", \\\"{x:1913,y:16,t:1527009333843};\\\", \\\"{x:1901,y:16,t:1527009333857};\\\", \\\"{x:1880,y:16,t:1527009333873};\\\", \\\"{x:1835,y:16,t:1527009333892};\\\", \\\"{x:1813,y:16,t:1527009333908};\\\", \\\"{x:1801,y:16,t:1527009333925};\\\", \\\"{x:1788,y:16,t:1527009333942};\\\", \\\"{x:1777,y:16,t:1527009333958};\\\", \\\"{x:1763,y:16,t:1527009333976};\\\", \\\"{x:1736,y:25,t:1527009333992};\\\", \\\"{x:1682,y:67,t:1527009334008};\\\", \\\"{x:1619,y:119,t:1527009334025};\\\", \\\"{x:1558,y:172,t:1527009334042};\\\", \\\"{x:1480,y:250,t:1527009334058};\\\", \\\"{x:1451,y:288,t:1527009334076};\\\", \\\"{x:1437,y:319,t:1527009334091};\\\", \\\"{x:1431,y:350,t:1527009334109};\\\", \\\"{x:1431,y:381,t:1527009334125};\\\", \\\"{x:1431,y:420,t:1527009334142};\\\", \\\"{x:1430,y:466,t:1527009334158};\\\", \\\"{x:1424,y:501,t:1527009334176};\\\", \\\"{x:1423,y:522,t:1527009334192};\\\", \\\"{x:1421,y:536,t:1527009334209};\\\", \\\"{x:1420,y:546,t:1527009334226};\\\", \\\"{x:1419,y:552,t:1527009334242};\\\", \\\"{x:1415,y:561,t:1527009334261};\\\", \\\"{x:1414,y:570,t:1527009334276};\\\", \\\"{x:1410,y:579,t:1527009334291};\\\", \\\"{x:1403,y:590,t:1527009334309};\\\", \\\"{x:1392,y:597,t:1527009334325};\\\", \\\"{x:1377,y:604,t:1527009334341};\\\", \\\"{x:1363,y:607,t:1527009334358};\\\", \\\"{x:1346,y:607,t:1527009334375};\\\", \\\"{x:1329,y:607,t:1527009334392};\\\", \\\"{x:1298,y:602,t:1527009334408};\\\", \\\"{x:1265,y:588,t:1527009334425};\\\", \\\"{x:1216,y:573,t:1527009334442};\\\", \\\"{x:1207,y:570,t:1527009334458};\\\", \\\"{x:1205,y:569,t:1527009334476};\\\", \\\"{x:1204,y:569,t:1527009334547};\\\", \\\"{x:1204,y:570,t:1527009334562};\\\", \\\"{x:1206,y:571,t:1527009334578};\\\", \\\"{x:1207,y:571,t:1527009334594};\\\", \\\"{x:1209,y:571,t:1527009334618};\\\", \\\"{x:1209,y:572,t:1527009334634};\\\", \\\"{x:1212,y:572,t:1527009334649};\\\", \\\"{x:1213,y:572,t:1527009334658};\\\", \\\"{x:1216,y:572,t:1527009334675};\\\", \\\"{x:1218,y:572,t:1527009334692};\\\", \\\"{x:1219,y:572,t:1527009334708};\\\", \\\"{x:1220,y:572,t:1527009334746};\\\", \\\"{x:1221,y:572,t:1527009334763};\\\", \\\"{x:1222,y:572,t:1527009334776};\\\", \\\"{x:1225,y:572,t:1527009334792};\\\", \\\"{x:1230,y:573,t:1527009334808};\\\", \\\"{x:1234,y:576,t:1527009334825};\\\", \\\"{x:1241,y:578,t:1527009334843};\\\", \\\"{x:1243,y:580,t:1527009334859};\\\", \\\"{x:1245,y:582,t:1527009334875};\\\", \\\"{x:1245,y:585,t:1527009334893};\\\", \\\"{x:1246,y:591,t:1527009334910};\\\", \\\"{x:1248,y:600,t:1527009334925};\\\", \\\"{x:1249,y:604,t:1527009334942};\\\", \\\"{x:1249,y:607,t:1527009334959};\\\", \\\"{x:1249,y:609,t:1527009334975};\\\", \\\"{x:1249,y:611,t:1527009334992};\\\", \\\"{x:1249,y:615,t:1527009335010};\\\", \\\"{x:1249,y:619,t:1527009335025};\\\", \\\"{x:1249,y:626,t:1527009335042};\\\", \\\"{x:1249,y:628,t:1527009335059};\\\", \\\"{x:1250,y:632,t:1527009335076};\\\", \\\"{x:1252,y:636,t:1527009335093};\\\", \\\"{x:1255,y:641,t:1527009335110};\\\", \\\"{x:1257,y:645,t:1527009335125};\\\", \\\"{x:1257,y:646,t:1527009335143};\\\", \\\"{x:1259,y:648,t:1527009335159};\\\", \\\"{x:1260,y:648,t:1527009335217};\\\", \\\"{x:1263,y:647,t:1527009335242};\\\", \\\"{x:1266,y:643,t:1527009335259};\\\", \\\"{x:1270,y:641,t:1527009335276};\\\", \\\"{x:1272,y:639,t:1527009335292};\\\", \\\"{x:1279,y:635,t:1527009335309};\\\", \\\"{x:1291,y:630,t:1527009335326};\\\", \\\"{x:1303,y:626,t:1527009335343};\\\", \\\"{x:1321,y:624,t:1527009335359};\\\", \\\"{x:1339,y:621,t:1527009335376};\\\", \\\"{x:1361,y:621,t:1527009335392};\\\", \\\"{x:1388,y:621,t:1527009335409};\\\", \\\"{x:1423,y:621,t:1527009335426};\\\", \\\"{x:1448,y:622,t:1527009335443};\\\", \\\"{x:1474,y:624,t:1527009335459};\\\", \\\"{x:1496,y:629,t:1527009335476};\\\", \\\"{x:1507,y:630,t:1527009335493};\\\", \\\"{x:1512,y:632,t:1527009335510};\\\", \\\"{x:1510,y:632,t:1527009335649};\\\", \\\"{x:1506,y:632,t:1527009335660};\\\", \\\"{x:1502,y:632,t:1527009335676};\\\", \\\"{x:1497,y:632,t:1527009335693};\\\", \\\"{x:1494,y:632,t:1527009335709};\\\", \\\"{x:1490,y:632,t:1527009335726};\\\", \\\"{x:1485,y:632,t:1527009335743};\\\", \\\"{x:1481,y:632,t:1527009335759};\\\", \\\"{x:1477,y:632,t:1527009335776};\\\", \\\"{x:1470,y:632,t:1527009335793};\\\", \\\"{x:1467,y:632,t:1527009335809};\\\", \\\"{x:1462,y:632,t:1527009335827};\\\", \\\"{x:1460,y:632,t:1527009335843};\\\", \\\"{x:1458,y:632,t:1527009335859};\\\", \\\"{x:1455,y:632,t:1527009335876};\\\", \\\"{x:1453,y:632,t:1527009335893};\\\", \\\"{x:1452,y:632,t:1527009335909};\\\", \\\"{x:1451,y:632,t:1527009335926};\\\", \\\"{x:1451,y:631,t:1527009336059};\\\", \\\"{x:1452,y:631,t:1527009336161};\\\", \\\"{x:1455,y:631,t:1527009336177};\\\", \\\"{x:1461,y:631,t:1527009336193};\\\", \\\"{x:1468,y:631,t:1527009336210};\\\", \\\"{x:1471,y:631,t:1527009336226};\\\", \\\"{x:1473,y:631,t:1527009336244};\\\", \\\"{x:1475,y:631,t:1527009336260};\\\", \\\"{x:1477,y:631,t:1527009336276};\\\", \\\"{x:1479,y:631,t:1527009336294};\\\", \\\"{x:1480,y:631,t:1527009336310};\\\", \\\"{x:1482,y:631,t:1527009336327};\\\", \\\"{x:1485,y:631,t:1527009336343};\\\", \\\"{x:1489,y:631,t:1527009336360};\\\", \\\"{x:1497,y:631,t:1527009336377};\\\", \\\"{x:1510,y:631,t:1527009336394};\\\", \\\"{x:1529,y:631,t:1527009336410};\\\", \\\"{x:1535,y:631,t:1527009336426};\\\", \\\"{x:1538,y:631,t:1527009336443};\\\", \\\"{x:1539,y:631,t:1527009336466};\\\", \\\"{x:1541,y:631,t:1527009336490};\\\", \\\"{x:1542,y:631,t:1527009336498};\\\", \\\"{x:1544,y:631,t:1527009336510};\\\", \\\"{x:1553,y:631,t:1527009336526};\\\", \\\"{x:1562,y:631,t:1527009336544};\\\", \\\"{x:1568,y:631,t:1527009336561};\\\", \\\"{x:1571,y:631,t:1527009336577};\\\", \\\"{x:1572,y:631,t:1527009336593};\\\", \\\"{x:1573,y:631,t:1527009336611};\\\", \\\"{x:1574,y:631,t:1527009336771};\\\", \\\"{x:1575,y:631,t:1527009336811};\\\", \\\"{x:1576,y:631,t:1527009337962};\\\", \\\"{x:1577,y:631,t:1527009338162};\\\", \\\"{x:1576,y:631,t:1527009338642};\\\", \\\"{x:1572,y:634,t:1527009338651};\\\", \\\"{x:1563,y:637,t:1527009338661};\\\", \\\"{x:1546,y:644,t:1527009338678};\\\", \\\"{x:1529,y:650,t:1527009338695};\\\", \\\"{x:1509,y:654,t:1527009338711};\\\", \\\"{x:1498,y:655,t:1527009338728};\\\", \\\"{x:1495,y:655,t:1527009338746};\\\", \\\"{x:1494,y:655,t:1527009338763};\\\", \\\"{x:1493,y:655,t:1527009338779};\\\", \\\"{x:1492,y:655,t:1527009338796};\\\", \\\"{x:1486,y:651,t:1527009338812};\\\", \\\"{x:1480,y:649,t:1527009338829};\\\", \\\"{x:1474,y:649,t:1527009338846};\\\", \\\"{x:1468,y:649,t:1527009338862};\\\", \\\"{x:1467,y:649,t:1527009338879};\\\", \\\"{x:1466,y:649,t:1527009338906};\\\", \\\"{x:1465,y:649,t:1527009338939};\\\", \\\"{x:1464,y:649,t:1527009338955};\\\", \\\"{x:1463,y:649,t:1527009338971};\\\", \\\"{x:1462,y:649,t:1527009338979};\\\", \\\"{x:1460,y:649,t:1527009338996};\\\", \\\"{x:1459,y:649,t:1527009339013};\\\", \\\"{x:1457,y:649,t:1527009339029};\\\", \\\"{x:1455,y:649,t:1527009339046};\\\", \\\"{x:1452,y:649,t:1527009339063};\\\", \\\"{x:1448,y:649,t:1527009339079};\\\", \\\"{x:1446,y:651,t:1527009339096};\\\", \\\"{x:1445,y:651,t:1527009339219};\\\", \\\"{x:1444,y:651,t:1527009339234};\\\", \\\"{x:1443,y:650,t:1527009339323};\\\", \\\"{x:1443,y:648,t:1527009339339};\\\", \\\"{x:1443,y:647,t:1527009339346};\\\", \\\"{x:1443,y:642,t:1527009339362};\\\", \\\"{x:1443,y:639,t:1527009339380};\\\", \\\"{x:1444,y:636,t:1527009339395};\\\", \\\"{x:1444,y:634,t:1527009339412};\\\", \\\"{x:1446,y:632,t:1527009339429};\\\", \\\"{x:1446,y:631,t:1527009339522};\\\", \\\"{x:1446,y:630,t:1527009339554};\\\", \\\"{x:1446,y:629,t:1527009339569};\\\", \\\"{x:1446,y:627,t:1527009339579};\\\", \\\"{x:1447,y:625,t:1527009339596};\\\", \\\"{x:1447,y:624,t:1527009339612};\\\", \\\"{x:1449,y:624,t:1527009339754};\\\", \\\"{x:1450,y:624,t:1527009340098};\\\", \\\"{x:1450,y:625,t:1527009340171};\\\", \\\"{x:1450,y:626,t:1527009341938};\\\", \\\"{x:1450,y:627,t:1527009341954};\\\", \\\"{x:1449,y:628,t:1527009341978};\\\", \\\"{x:1447,y:629,t:1527009342009};\\\", \\\"{x:1446,y:629,t:1527009342025};\\\", \\\"{x:1445,y:630,t:1527009342105};\\\", \\\"{x:1445,y:628,t:1527009344290};\\\", \\\"{x:1445,y:626,t:1527009344299};\\\", \\\"{x:1447,y:622,t:1527009344317};\\\", \\\"{x:1448,y:619,t:1527009344333};\\\", \\\"{x:1451,y:615,t:1527009344349};\\\", \\\"{x:1454,y:610,t:1527009344367};\\\", \\\"{x:1456,y:608,t:1527009344383};\\\", \\\"{x:1458,y:606,t:1527009344400};\\\", \\\"{x:1459,y:602,t:1527009344417};\\\", \\\"{x:1461,y:600,t:1527009344433};\\\", \\\"{x:1465,y:593,t:1527009344451};\\\", \\\"{x:1466,y:590,t:1527009344467};\\\", \\\"{x:1469,y:585,t:1527009344484};\\\", \\\"{x:1474,y:578,t:1527009344500};\\\", \\\"{x:1479,y:571,t:1527009344518};\\\", \\\"{x:1486,y:559,t:1527009344534};\\\", \\\"{x:1489,y:549,t:1527009344551};\\\", \\\"{x:1494,y:538,t:1527009344568};\\\", \\\"{x:1499,y:525,t:1527009344585};\\\", \\\"{x:1507,y:506,t:1527009344601};\\\", \\\"{x:1514,y:486,t:1527009344617};\\\", \\\"{x:1540,y:443,t:1527009344635};\\\", \\\"{x:1557,y:411,t:1527009344650};\\\", \\\"{x:1569,y:391,t:1527009344667};\\\", \\\"{x:1577,y:375,t:1527009344684};\\\", \\\"{x:1584,y:362,t:1527009344700};\\\", \\\"{x:1591,y:348,t:1527009344718};\\\", \\\"{x:1595,y:339,t:1527009344734};\\\", \\\"{x:1601,y:329,t:1527009344751};\\\", \\\"{x:1607,y:320,t:1527009344767};\\\", \\\"{x:1611,y:313,t:1527009344785};\\\", \\\"{x:1616,y:306,t:1527009344800};\\\", \\\"{x:1619,y:300,t:1527009344817};\\\", \\\"{x:1623,y:296,t:1527009344834};\\\", \\\"{x:1625,y:293,t:1527009344851};\\\", \\\"{x:1625,y:294,t:1527009344939};\\\", \\\"{x:1625,y:297,t:1527009344951};\\\", \\\"{x:1623,y:305,t:1527009344967};\\\", \\\"{x:1622,y:308,t:1527009344984};\\\", \\\"{x:1620,y:312,t:1527009345001};\\\", \\\"{x:1620,y:313,t:1527009345017};\\\", \\\"{x:1619,y:313,t:1527009345043};\\\", \\\"{x:1618,y:314,t:1527009345051};\\\", \\\"{x:1618,y:316,t:1527009345178};\\\", \\\"{x:1617,y:316,t:1527009345186};\\\", \\\"{x:1617,y:317,t:1527009345201};\\\", \\\"{x:1617,y:318,t:1527009345217};\\\", \\\"{x:1615,y:319,t:1527009345234};\\\", \\\"{x:1615,y:320,t:1527009345251};\\\", \\\"{x:1614,y:321,t:1527009345267};\\\", \\\"{x:1614,y:323,t:1527009345290};\\\", \\\"{x:1613,y:324,t:1527009345301};\\\", \\\"{x:1612,y:325,t:1527009345317};\\\", \\\"{x:1612,y:327,t:1527009345335};\\\", \\\"{x:1611,y:328,t:1527009345353};\\\", \\\"{x:1610,y:329,t:1527009345370};\\\", \\\"{x:1610,y:330,t:1527009345384};\\\", \\\"{x:1609,y:333,t:1527009345400};\\\", \\\"{x:1607,y:339,t:1527009345417};\\\", \\\"{x:1603,y:347,t:1527009345434};\\\", \\\"{x:1599,y:357,t:1527009345450};\\\", \\\"{x:1593,y:370,t:1527009345467};\\\", \\\"{x:1587,y:383,t:1527009345484};\\\", \\\"{x:1580,y:394,t:1527009345501};\\\", \\\"{x:1575,y:404,t:1527009345518};\\\", \\\"{x:1571,y:409,t:1527009345533};\\\", \\\"{x:1568,y:416,t:1527009345550};\\\", \\\"{x:1566,y:418,t:1527009345567};\\\", \\\"{x:1565,y:422,t:1527009345584};\\\", \\\"{x:1563,y:427,t:1527009345600};\\\", \\\"{x:1558,y:436,t:1527009345618};\\\", \\\"{x:1552,y:447,t:1527009345634};\\\", \\\"{x:1543,y:459,t:1527009345650};\\\", \\\"{x:1533,y:472,t:1527009345667};\\\", \\\"{x:1529,y:479,t:1527009345684};\\\", \\\"{x:1522,y:487,t:1527009345701};\\\", \\\"{x:1516,y:498,t:1527009345718};\\\", \\\"{x:1511,y:505,t:1527009345734};\\\", \\\"{x:1503,y:516,t:1527009345752};\\\", \\\"{x:1496,y:528,t:1527009345768};\\\", \\\"{x:1490,y:538,t:1527009345785};\\\", \\\"{x:1485,y:545,t:1527009345802};\\\", \\\"{x:1483,y:549,t:1527009345818};\\\", \\\"{x:1482,y:551,t:1527009345835};\\\", \\\"{x:1481,y:554,t:1527009345851};\\\", \\\"{x:1478,y:556,t:1527009345869};\\\", \\\"{x:1478,y:558,t:1527009345885};\\\", \\\"{x:1476,y:562,t:1527009345901};\\\", \\\"{x:1475,y:563,t:1527009345919};\\\", \\\"{x:1474,y:564,t:1527009345936};\\\", \\\"{x:1473,y:566,t:1527009345954};\\\", \\\"{x:1473,y:568,t:1527009348034};\\\", \\\"{x:1473,y:569,t:1527009348050};\\\", \\\"{x:1473,y:572,t:1527009348057};\\\", \\\"{x:1473,y:573,t:1527009348074};\\\", \\\"{x:1473,y:574,t:1527009348086};\\\", \\\"{x:1472,y:577,t:1527009348103};\\\", \\\"{x:1470,y:579,t:1527009348120};\\\", \\\"{x:1468,y:581,t:1527009348136};\\\", \\\"{x:1465,y:583,t:1527009348152};\\\", \\\"{x:1464,y:584,t:1527009348170};\\\", \\\"{x:1464,y:585,t:1527009348186};\\\", \\\"{x:1463,y:586,t:1527009348203};\\\", \\\"{x:1462,y:586,t:1527009348226};\\\", \\\"{x:1461,y:586,t:1527009348250};\\\", \\\"{x:1460,y:588,t:1527009348259};\\\", \\\"{x:1459,y:589,t:1527009348299};\\\", \\\"{x:1459,y:590,t:1527009348314};\\\", \\\"{x:1459,y:591,t:1527009348331};\\\", \\\"{x:1458,y:594,t:1527009348338};\\\", \\\"{x:1458,y:596,t:1527009348354};\\\", \\\"{x:1456,y:599,t:1527009348370};\\\", \\\"{x:1455,y:600,t:1527009348386};\\\", \\\"{x:1455,y:603,t:1527009348404};\\\", \\\"{x:1453,y:606,t:1527009348420};\\\", \\\"{x:1452,y:609,t:1527009348438};\\\", \\\"{x:1451,y:612,t:1527009348453};\\\", \\\"{x:1448,y:616,t:1527009348470};\\\", \\\"{x:1447,y:618,t:1527009348487};\\\", \\\"{x:1446,y:620,t:1527009348504};\\\", \\\"{x:1445,y:621,t:1527009348520};\\\", \\\"{x:1445,y:622,t:1527009348554};\\\", \\\"{x:1445,y:624,t:1527009349473};\\\", \\\"{x:1445,y:625,t:1527009349530};\\\", \\\"{x:1446,y:626,t:1527009349554};\\\", \\\"{x:1449,y:628,t:1527009349571};\\\", \\\"{x:1450,y:628,t:1527009349633};\\\", \\\"{x:1451,y:628,t:1527009349642};\\\", \\\"{x:1446,y:631,t:1527009351138};\\\", \\\"{x:1435,y:639,t:1527009351156};\\\", \\\"{x:1423,y:650,t:1527009351172};\\\", \\\"{x:1409,y:663,t:1527009351189};\\\", \\\"{x:1393,y:675,t:1527009351205};\\\", \\\"{x:1382,y:684,t:1527009351222};\\\", \\\"{x:1377,y:689,t:1527009351240};\\\", \\\"{x:1375,y:691,t:1527009351255};\\\", \\\"{x:1375,y:692,t:1527009351282};\\\", \\\"{x:1374,y:692,t:1527009351314};\\\", \\\"{x:1373,y:693,t:1527009351323};\\\", \\\"{x:1371,y:695,t:1527009351340};\\\", \\\"{x:1367,y:699,t:1527009351355};\\\", \\\"{x:1362,y:705,t:1527009351373};\\\", \\\"{x:1354,y:712,t:1527009351389};\\\", \\\"{x:1347,y:718,t:1527009351405};\\\", \\\"{x:1345,y:720,t:1527009351422};\\\", \\\"{x:1344,y:721,t:1527009351439};\\\", \\\"{x:1343,y:721,t:1527009351489};\\\", \\\"{x:1341,y:719,t:1527009351505};\\\", \\\"{x:1341,y:708,t:1527009351522};\\\", \\\"{x:1341,y:691,t:1527009351539};\\\", \\\"{x:1349,y:674,t:1527009351556};\\\", \\\"{x:1354,y:661,t:1527009351572};\\\", \\\"{x:1358,y:652,t:1527009351589};\\\", \\\"{x:1362,y:647,t:1527009351606};\\\", \\\"{x:1366,y:642,t:1527009351623};\\\", \\\"{x:1367,y:639,t:1527009351640};\\\", \\\"{x:1373,y:626,t:1527009351656};\\\", \\\"{x:1382,y:609,t:1527009351672};\\\", \\\"{x:1399,y:586,t:1527009351690};\\\", \\\"{x:1405,y:575,t:1527009351706};\\\", \\\"{x:1412,y:569,t:1527009351723};\\\", \\\"{x:1413,y:565,t:1527009351740};\\\", \\\"{x:1415,y:563,t:1527009351756};\\\", \\\"{x:1416,y:563,t:1527009351772};\\\", \\\"{x:1416,y:562,t:1527009351789};\\\", \\\"{x:1418,y:561,t:1527009351806};\\\", \\\"{x:1419,y:559,t:1527009351824};\\\", \\\"{x:1420,y:558,t:1527009351839};\\\", \\\"{x:1421,y:554,t:1527009351856};\\\", \\\"{x:1422,y:550,t:1527009351873};\\\", \\\"{x:1423,y:545,t:1527009351890};\\\", \\\"{x:1423,y:543,t:1527009351907};\\\", \\\"{x:1423,y:544,t:1527009351995};\\\", \\\"{x:1423,y:546,t:1527009352007};\\\", \\\"{x:1423,y:550,t:1527009352024};\\\", \\\"{x:1422,y:552,t:1527009352040};\\\", \\\"{x:1421,y:553,t:1527009352056};\\\", \\\"{x:1421,y:554,t:1527009352074};\\\", \\\"{x:1420,y:555,t:1527009352115};\\\", \\\"{x:1418,y:557,t:1527009352138};\\\", \\\"{x:1418,y:558,t:1527009352299};\\\", \\\"{x:1417,y:559,t:1527009352347};\\\", \\\"{x:1416,y:561,t:1527009352356};\\\", \\\"{x:1415,y:562,t:1527009352373};\\\", \\\"{x:1414,y:564,t:1527009352563};\\\", \\\"{x:1414,y:567,t:1527009352574};\\\", \\\"{x:1409,y:581,t:1527009352590};\\\", \\\"{x:1403,y:597,t:1527009352605};\\\", \\\"{x:1396,y:612,t:1527009352623};\\\", \\\"{x:1389,y:625,t:1527009352640};\\\", \\\"{x:1386,y:636,t:1527009352656};\\\", \\\"{x:1383,y:644,t:1527009352673};\\\", \\\"{x:1381,y:651,t:1527009352689};\\\", \\\"{x:1380,y:655,t:1527009352706};\\\", \\\"{x:1379,y:659,t:1527009352723};\\\", \\\"{x:1377,y:666,t:1527009352740};\\\", \\\"{x:1373,y:674,t:1527009352756};\\\", \\\"{x:1371,y:684,t:1527009352773};\\\", \\\"{x:1368,y:692,t:1527009352790};\\\", \\\"{x:1365,y:698,t:1527009352807};\\\", \\\"{x:1364,y:700,t:1527009352823};\\\", \\\"{x:1363,y:701,t:1527009352866};\\\", \\\"{x:1362,y:701,t:1527009352890};\\\", \\\"{x:1357,y:705,t:1527009352907};\\\", \\\"{x:1350,y:709,t:1527009352923};\\\", \\\"{x:1337,y:715,t:1527009352940};\\\", \\\"{x:1324,y:720,t:1527009352957};\\\", \\\"{x:1309,y:726,t:1527009352973};\\\", \\\"{x:1295,y:734,t:1527009352990};\\\", \\\"{x:1280,y:740,t:1527009353007};\\\", \\\"{x:1268,y:744,t:1527009353023};\\\", \\\"{x:1260,y:746,t:1527009353040};\\\", \\\"{x:1254,y:748,t:1527009353057};\\\", \\\"{x:1250,y:750,t:1527009353073};\\\", \\\"{x:1245,y:756,t:1527009353090};\\\", \\\"{x:1239,y:765,t:1527009353107};\\\", \\\"{x:1231,y:778,t:1527009353123};\\\", \\\"{x:1224,y:790,t:1527009353140};\\\", \\\"{x:1217,y:799,t:1527009353157};\\\", \\\"{x:1217,y:801,t:1527009353173};\\\", \\\"{x:1217,y:796,t:1527009353393};\\\", \\\"{x:1219,y:790,t:1527009353407};\\\", \\\"{x:1225,y:771,t:1527009353424};\\\", \\\"{x:1241,y:740,t:1527009353440};\\\", \\\"{x:1251,y:694,t:1527009353457};\\\", \\\"{x:1272,y:626,t:1527009353473};\\\", \\\"{x:1277,y:602,t:1527009353490};\\\", \\\"{x:1278,y:582,t:1527009353507};\\\", \\\"{x:1278,y:577,t:1527009353524};\\\", \\\"{x:1278,y:575,t:1527009353540};\\\", \\\"{x:1278,y:574,t:1527009353557};\\\", \\\"{x:1279,y:574,t:1527009353585};\\\", \\\"{x:1279,y:573,t:1527009353626};\\\", \\\"{x:1279,y:570,t:1527009353641};\\\", \\\"{x:1279,y:567,t:1527009353658};\\\", \\\"{x:1278,y:564,t:1527009353674};\\\", \\\"{x:1278,y:563,t:1527009354073};\\\", \\\"{x:1277,y:563,t:1527009354377};\\\", \\\"{x:1277,y:561,t:1527009354393};\\\", \\\"{x:1277,y:557,t:1527009354408};\\\", \\\"{x:1284,y:546,t:1527009354424};\\\", \\\"{x:1296,y:532,t:1527009354441};\\\", \\\"{x:1306,y:523,t:1527009354457};\\\", \\\"{x:1316,y:516,t:1527009354474};\\\", \\\"{x:1323,y:510,t:1527009354491};\\\", \\\"{x:1323,y:509,t:1527009354521};\\\", \\\"{x:1324,y:508,t:1527009354530};\\\", \\\"{x:1324,y:507,t:1527009354561};\\\", \\\"{x:1324,y:506,t:1527009354574};\\\", \\\"{x:1329,y:497,t:1527009354591};\\\", \\\"{x:1342,y:482,t:1527009354608};\\\", \\\"{x:1361,y:462,t:1527009354626};\\\", \\\"{x:1378,y:446,t:1527009354641};\\\", \\\"{x:1404,y:426,t:1527009354657};\\\", \\\"{x:1413,y:418,t:1527009354675};\\\", \\\"{x:1422,y:410,t:1527009354692};\\\", \\\"{x:1427,y:407,t:1527009354708};\\\", \\\"{x:1427,y:411,t:1527009354971};\\\", \\\"{x:1426,y:418,t:1527009354978};\\\", \\\"{x:1424,y:425,t:1527009354991};\\\", \\\"{x:1416,y:442,t:1527009355008};\\\", \\\"{x:1407,y:465,t:1527009355026};\\\", \\\"{x:1392,y:499,t:1527009355042};\\\", \\\"{x:1383,y:519,t:1527009355058};\\\", \\\"{x:1373,y:542,t:1527009355076};\\\", \\\"{x:1364,y:559,t:1527009355093};\\\", \\\"{x:1353,y:580,t:1527009355109};\\\", \\\"{x:1343,y:595,t:1527009355126};\\\", \\\"{x:1339,y:607,t:1527009355143};\\\", \\\"{x:1337,y:617,t:1527009355158};\\\", \\\"{x:1333,y:630,t:1527009355176};\\\", \\\"{x:1331,y:644,t:1527009355193};\\\", \\\"{x:1326,y:662,t:1527009355209};\\\", \\\"{x:1320,y:677,t:1527009355225};\\\", \\\"{x:1307,y:707,t:1527009355242};\\\", \\\"{x:1299,y:726,t:1527009355258};\\\", \\\"{x:1289,y:737,t:1527009355276};\\\", \\\"{x:1283,y:748,t:1527009355292};\\\", \\\"{x:1279,y:754,t:1527009355309};\\\", \\\"{x:1272,y:765,t:1527009355326};\\\", \\\"{x:1270,y:769,t:1527009355342};\\\", \\\"{x:1267,y:773,t:1527009355358};\\\", \\\"{x:1263,y:778,t:1527009355375};\\\", \\\"{x:1260,y:779,t:1527009355392};\\\", \\\"{x:1259,y:780,t:1527009355408};\\\", \\\"{x:1256,y:782,t:1527009355425};\\\", \\\"{x:1251,y:785,t:1527009355441};\\\", \\\"{x:1250,y:787,t:1527009355459};\\\", \\\"{x:1249,y:788,t:1527009355475};\\\", \\\"{x:1249,y:786,t:1527009355625};\\\", \\\"{x:1250,y:786,t:1527009355730};\\\", \\\"{x:1251,y:787,t:1527009355742};\\\", \\\"{x:1254,y:794,t:1527009355759};\\\", \\\"{x:1257,y:799,t:1527009355776};\\\", \\\"{x:1260,y:802,t:1527009355792};\\\", \\\"{x:1261,y:802,t:1527009355809};\\\", \\\"{x:1262,y:802,t:1527009355825};\\\", \\\"{x:1263,y:804,t:1527009355843};\\\", \\\"{x:1265,y:803,t:1527009355891};\\\", \\\"{x:1266,y:801,t:1527009355899};\\\", \\\"{x:1266,y:799,t:1527009355910};\\\", \\\"{x:1274,y:792,t:1527009355926};\\\", \\\"{x:1279,y:787,t:1527009355943};\\\", \\\"{x:1285,y:782,t:1527009355959};\\\", \\\"{x:1292,y:777,t:1527009355977};\\\", \\\"{x:1303,y:770,t:1527009355992};\\\", \\\"{x:1310,y:765,t:1527009356009};\\\", \\\"{x:1322,y:759,t:1527009356026};\\\", \\\"{x:1328,y:756,t:1527009356042};\\\", \\\"{x:1329,y:755,t:1527009356059};\\\", \\\"{x:1331,y:755,t:1527009356076};\\\", \\\"{x:1333,y:755,t:1527009356130};\\\", \\\"{x:1334,y:755,t:1527009356186};\\\", \\\"{x:1335,y:755,t:1527009356345};\\\", \\\"{x:1336,y:753,t:1527009356360};\\\", \\\"{x:1338,y:748,t:1527009356377};\\\", \\\"{x:1348,y:729,t:1527009356394};\\\", \\\"{x:1352,y:723,t:1527009356410};\\\", \\\"{x:1372,y:696,t:1527009356426};\\\", \\\"{x:1381,y:682,t:1527009356443};\\\", \\\"{x:1398,y:663,t:1527009356460};\\\", \\\"{x:1413,y:647,t:1527009356477};\\\", \\\"{x:1427,y:630,t:1527009356494};\\\", \\\"{x:1438,y:619,t:1527009356509};\\\", \\\"{x:1446,y:612,t:1527009356527};\\\", \\\"{x:1447,y:611,t:1527009356544};\\\", \\\"{x:1448,y:610,t:1527009356603};\\\", \\\"{x:1449,y:610,t:1527009356731};\\\", \\\"{x:1451,y:610,t:1527009356743};\\\", \\\"{x:1452,y:612,t:1527009356763};\\\", \\\"{x:1453,y:613,t:1527009356795};\\\", \\\"{x:1453,y:614,t:1527009356811};\\\", \\\"{x:1453,y:615,t:1527009356827};\\\", \\\"{x:1453,y:616,t:1527009356845};\\\", \\\"{x:1453,y:618,t:1527009356861};\\\", \\\"{x:1449,y:622,t:1527009356877};\\\", \\\"{x:1443,y:625,t:1527009356894};\\\", \\\"{x:1438,y:629,t:1527009356910};\\\", \\\"{x:1433,y:631,t:1527009356927};\\\", \\\"{x:1427,y:633,t:1527009356943};\\\", \\\"{x:1421,y:636,t:1527009356960};\\\", \\\"{x:1413,y:639,t:1527009356976};\\\", \\\"{x:1405,y:645,t:1527009356994};\\\", \\\"{x:1400,y:649,t:1527009357009};\\\", \\\"{x:1391,y:655,t:1527009357026};\\\", \\\"{x:1381,y:663,t:1527009357044};\\\", \\\"{x:1374,y:668,t:1527009357060};\\\", \\\"{x:1370,y:670,t:1527009357077};\\\", \\\"{x:1369,y:671,t:1527009357093};\\\", \\\"{x:1368,y:672,t:1527009357111};\\\", \\\"{x:1368,y:670,t:1527009357210};\\\", \\\"{x:1368,y:661,t:1527009357227};\\\", \\\"{x:1368,y:646,t:1527009357244};\\\", \\\"{x:1368,y:628,t:1527009357261};\\\", \\\"{x:1376,y:612,t:1527009357277};\\\", \\\"{x:1383,y:598,t:1527009357294};\\\", \\\"{x:1387,y:589,t:1527009357311};\\\", \\\"{x:1388,y:587,t:1527009357328};\\\", \\\"{x:1388,y:584,t:1527009357344};\\\", \\\"{x:1388,y:582,t:1527009357361};\\\", \\\"{x:1388,y:579,t:1527009357378};\\\", \\\"{x:1388,y:577,t:1527009357394};\\\", \\\"{x:1388,y:576,t:1527009357410};\\\", \\\"{x:1388,y:575,t:1527009357433};\\\", \\\"{x:1389,y:575,t:1527009357443};\\\", \\\"{x:1390,y:574,t:1527009357466};\\\", \\\"{x:1391,y:573,t:1527009357489};\\\", \\\"{x:1391,y:572,t:1527009357498};\\\", \\\"{x:1393,y:570,t:1527009357510};\\\", \\\"{x:1394,y:568,t:1527009357527};\\\", \\\"{x:1396,y:567,t:1527009357544};\\\", \\\"{x:1397,y:567,t:1527009357560};\\\", \\\"{x:1397,y:566,t:1527009357577};\\\", \\\"{x:1400,y:565,t:1527009357594};\\\", \\\"{x:1404,y:564,t:1527009357610};\\\", \\\"{x:1407,y:563,t:1527009357627};\\\", \\\"{x:1409,y:561,t:1527009357645};\\\", \\\"{x:1412,y:559,t:1527009357661};\\\", \\\"{x:1413,y:558,t:1527009357682};\\\", \\\"{x:1414,y:558,t:1527009358249};\\\", \\\"{x:1414,y:559,t:1527009358261};\\\", \\\"{x:1415,y:563,t:1527009358278};\\\", \\\"{x:1415,y:565,t:1527009358294};\\\", \\\"{x:1415,y:566,t:1527009358313};\\\", \\\"{x:1416,y:567,t:1527009358327};\\\", \\\"{x:1417,y:568,t:1527009358361};\\\", \\\"{x:1419,y:569,t:1527009358386};\\\", \\\"{x:1419,y:570,t:1527009358394};\\\", \\\"{x:1424,y:573,t:1527009358411};\\\", \\\"{x:1428,y:577,t:1527009358427};\\\", \\\"{x:1435,y:580,t:1527009358445};\\\", \\\"{x:1440,y:584,t:1527009358461};\\\", \\\"{x:1445,y:587,t:1527009358478};\\\", \\\"{x:1448,y:589,t:1527009358494};\\\", \\\"{x:1452,y:592,t:1527009358511};\\\", \\\"{x:1455,y:596,t:1527009358527};\\\", \\\"{x:1456,y:598,t:1527009358544};\\\", \\\"{x:1459,y:602,t:1527009358561};\\\", \\\"{x:1460,y:606,t:1527009358577};\\\", \\\"{x:1463,y:612,t:1527009358594};\\\", \\\"{x:1463,y:616,t:1527009358611};\\\", \\\"{x:1465,y:618,t:1527009358628};\\\", \\\"{x:1466,y:621,t:1527009358644};\\\", \\\"{x:1467,y:623,t:1527009358661};\\\", \\\"{x:1467,y:625,t:1527009358678};\\\", \\\"{x:1468,y:627,t:1527009358694};\\\", \\\"{x:1468,y:629,t:1527009358712};\\\", \\\"{x:1468,y:630,t:1527009358728};\\\", \\\"{x:1468,y:631,t:1527009358745};\\\", \\\"{x:1468,y:633,t:1527009358761};\\\", \\\"{x:1468,y:637,t:1527009358778};\\\", \\\"{x:1466,y:641,t:1527009358794};\\\", \\\"{x:1463,y:645,t:1527009358811};\\\", \\\"{x:1458,y:649,t:1527009358828};\\\", \\\"{x:1455,y:651,t:1527009358844};\\\", \\\"{x:1453,y:653,t:1527009358861};\\\", \\\"{x:1452,y:653,t:1527009358878};\\\", \\\"{x:1451,y:653,t:1527009358914};\\\", \\\"{x:1450,y:653,t:1527009358938};\\\", \\\"{x:1449,y:653,t:1527009359001};\\\", \\\"{x:1448,y:653,t:1527009359034};\\\", \\\"{x:1447,y:652,t:1527009359046};\\\", \\\"{x:1446,y:652,t:1527009359061};\\\", \\\"{x:1446,y:651,t:1527009359078};\\\", \\\"{x:1444,y:648,t:1527009359095};\\\", \\\"{x:1444,y:647,t:1527009359114};\\\", \\\"{x:1444,y:646,t:1527009359129};\\\", \\\"{x:1444,y:645,t:1527009359145};\\\", \\\"{x:1444,y:644,t:1527009359169};\\\", \\\"{x:1444,y:643,t:1527009359179};\\\", \\\"{x:1443,y:642,t:1527009359195};\\\", \\\"{x:1443,y:641,t:1527009359329};\\\", \\\"{x:1443,y:640,t:1527009359346};\\\", \\\"{x:1443,y:639,t:1527009359361};\\\", \\\"{x:1443,y:638,t:1527009359562};\\\", \\\"{x:1446,y:635,t:1527009359580};\\\", \\\"{x:1453,y:633,t:1527009359596};\\\", \\\"{x:1469,y:632,t:1527009359612};\\\", \\\"{x:1490,y:632,t:1527009359629};\\\", \\\"{x:1512,y:632,t:1527009359645};\\\", \\\"{x:1537,y:632,t:1527009359662};\\\", \\\"{x:1566,y:632,t:1527009359678};\\\", \\\"{x:1595,y:632,t:1527009359696};\\\", \\\"{x:1614,y:631,t:1527009359713};\\\", \\\"{x:1619,y:631,t:1527009359729};\\\", \\\"{x:1619,y:635,t:1527009359833};\\\", \\\"{x:1616,y:637,t:1527009359846};\\\", \\\"{x:1614,y:640,t:1527009359862};\\\", \\\"{x:1612,y:641,t:1527009359879};\\\", \\\"{x:1611,y:641,t:1527009359896};\\\", \\\"{x:1611,y:642,t:1527009359913};\\\", \\\"{x:1609,y:642,t:1527009359929};\\\", \\\"{x:1606,y:642,t:1527009359946};\\\", \\\"{x:1602,y:641,t:1527009359963};\\\", \\\"{x:1599,y:639,t:1527009359980};\\\", \\\"{x:1597,y:639,t:1527009359995};\\\", \\\"{x:1592,y:638,t:1527009360013};\\\", \\\"{x:1590,y:638,t:1527009360030};\\\", \\\"{x:1587,y:637,t:1527009360045};\\\", \\\"{x:1586,y:637,t:1527009360065};\\\", \\\"{x:1584,y:636,t:1527009360081};\\\", \\\"{x:1584,y:635,t:1527009360095};\\\", \\\"{x:1583,y:635,t:1527009360113};\\\", \\\"{x:1582,y:632,t:1527009360129};\\\", \\\"{x:1582,y:631,t:1527009360145};\\\", \\\"{x:1582,y:630,t:1527009360163};\\\", \\\"{x:1582,y:629,t:1527009360179};\\\", \\\"{x:1582,y:628,t:1527009360290};\\\", \\\"{x:1582,y:627,t:1527009360306};\\\", \\\"{x:1582,y:632,t:1527009360386};\\\", \\\"{x:1582,y:639,t:1527009360398};\\\", \\\"{x:1580,y:658,t:1527009360413};\\\", \\\"{x:1572,y:678,t:1527009360430};\\\", \\\"{x:1562,y:700,t:1527009360446};\\\", \\\"{x:1551,y:716,t:1527009360463};\\\", \\\"{x:1545,y:727,t:1527009360480};\\\", \\\"{x:1542,y:734,t:1527009360497};\\\", \\\"{x:1541,y:736,t:1527009360513};\\\", \\\"{x:1541,y:738,t:1527009360530};\\\", \\\"{x:1541,y:740,t:1527009360603};\\\", \\\"{x:1541,y:741,t:1527009360613};\\\", \\\"{x:1541,y:745,t:1527009360629};\\\", \\\"{x:1541,y:746,t:1527009360647};\\\", \\\"{x:1541,y:747,t:1527009360698};\\\", \\\"{x:1541,y:749,t:1527009360713};\\\", \\\"{x:1541,y:752,t:1527009360730};\\\", \\\"{x:1540,y:754,t:1527009360747};\\\", \\\"{x:1535,y:757,t:1527009360764};\\\", \\\"{x:1532,y:759,t:1527009360780};\\\", \\\"{x:1528,y:761,t:1527009360797};\\\", \\\"{x:1527,y:762,t:1527009360814};\\\", \\\"{x:1526,y:762,t:1527009360830};\\\", \\\"{x:1524,y:764,t:1527009360847};\\\", \\\"{x:1523,y:765,t:1527009360864};\\\", \\\"{x:1522,y:765,t:1527009360880};\\\", \\\"{x:1521,y:765,t:1527009360897};\\\", \\\"{x:1518,y:765,t:1527009360915};\\\", \\\"{x:1517,y:765,t:1527009360962};\\\", \\\"{x:1516,y:765,t:1527009360979};\\\", \\\"{x:1515,y:765,t:1527009361002};\\\", \\\"{x:1513,y:765,t:1527009361042};\\\", \\\"{x:1512,y:765,t:1527009361091};\\\", \\\"{x:1510,y:765,t:1527009361131};\\\", \\\"{x:1509,y:765,t:1527009361147};\\\", \\\"{x:1508,y:764,t:1527009361165};\\\", \\\"{x:1506,y:764,t:1527009361181};\\\", \\\"{x:1504,y:764,t:1527009361196};\\\", \\\"{x:1503,y:764,t:1527009361214};\\\", \\\"{x:1502,y:764,t:1527009361230};\\\", \\\"{x:1500,y:764,t:1527009361247};\\\", \\\"{x:1500,y:763,t:1527009361513};\\\", \\\"{x:1502,y:763,t:1527009361530};\\\", \\\"{x:1505,y:761,t:1527009361547};\\\", \\\"{x:1506,y:761,t:1527009361564};\\\", \\\"{x:1507,y:761,t:1527009361586};\\\", \\\"{x:1508,y:761,t:1527009361598};\\\", \\\"{x:1509,y:761,t:1527009361613};\\\", \\\"{x:1510,y:761,t:1527009361630};\\\", \\\"{x:1511,y:761,t:1527009361647};\\\", \\\"{x:1512,y:761,t:1527009361663};\\\", \\\"{x:1513,y:761,t:1527009361681};\\\", \\\"{x:1514,y:761,t:1527009361697};\\\", \\\"{x:1515,y:761,t:1527009361818};\\\", \\\"{x:1503,y:761,t:1527009362178};\\\", \\\"{x:1481,y:761,t:1527009362186};\\\", \\\"{x:1436,y:761,t:1527009362197};\\\", \\\"{x:1325,y:761,t:1527009362214};\\\", \\\"{x:1187,y:761,t:1527009362231};\\\", \\\"{x:1043,y:761,t:1527009362248};\\\", \\\"{x:909,y:752,t:1527009362264};\\\", \\\"{x:798,y:736,t:1527009362280};\\\", \\\"{x:716,y:712,t:1527009362297};\\\", \\\"{x:709,y:703,t:1527009362315};\\\", \\\"{x:710,y:690,t:1527009362330};\\\", \\\"{x:730,y:672,t:1527009362347};\\\", \\\"{x:756,y:660,t:1527009362364};\\\", \\\"{x:782,y:650,t:1527009362380};\\\", \\\"{x:807,y:641,t:1527009362397};\\\", \\\"{x:828,y:637,t:1527009362415};\\\", \\\"{x:842,y:635,t:1527009362430};\\\", \\\"{x:855,y:635,t:1527009362448};\\\", \\\"{x:866,y:635,t:1527009362464};\\\", \\\"{x:883,y:634,t:1527009362482};\\\", \\\"{x:892,y:631,t:1527009362498};\\\", \\\"{x:894,y:629,t:1527009362514};\\\", \\\"{x:894,y:624,t:1527009362531};\\\", \\\"{x:894,y:617,t:1527009362548};\\\", \\\"{x:891,y:611,t:1527009362564};\\\", \\\"{x:886,y:603,t:1527009362581};\\\", \\\"{x:881,y:595,t:1527009362599};\\\", \\\"{x:877,y:588,t:1527009362616};\\\", \\\"{x:875,y:582,t:1527009362631};\\\", \\\"{x:872,y:576,t:1527009362649};\\\", \\\"{x:870,y:574,t:1527009362665};\\\", \\\"{x:868,y:572,t:1527009362682};\\\", \\\"{x:867,y:571,t:1527009362698};\\\", \\\"{x:864,y:571,t:1527009362716};\\\", \\\"{x:862,y:571,t:1527009362731};\\\", \\\"{x:859,y:570,t:1527009362749};\\\", \\\"{x:858,y:570,t:1527009362765};\\\", \\\"{x:853,y:570,t:1527009362954};\\\", \\\"{x:845,y:570,t:1527009362966};\\\", \\\"{x:823,y:574,t:1527009362983};\\\", \\\"{x:792,y:584,t:1527009362998};\\\", \\\"{x:758,y:588,t:1527009363016};\\\", \\\"{x:721,y:593,t:1527009363033};\\\", \\\"{x:694,y:593,t:1527009363048};\\\", \\\"{x:676,y:593,t:1527009363065};\\\", \\\"{x:669,y:593,t:1527009363082};\\\", \\\"{x:663,y:593,t:1527009363098};\\\", \\\"{x:658,y:593,t:1527009363115};\\\", \\\"{x:649,y:592,t:1527009363132};\\\", \\\"{x:635,y:592,t:1527009363149};\\\", \\\"{x:624,y:592,t:1527009363165};\\\", \\\"{x:615,y:591,t:1527009363182};\\\", \\\"{x:611,y:591,t:1527009363198};\\\", \\\"{x:608,y:589,t:1527009363215};\\\", \\\"{x:608,y:588,t:1527009363266};\\\", \\\"{x:608,y:587,t:1527009363283};\\\", \\\"{x:608,y:586,t:1527009363633};\\\", \\\"{x:611,y:587,t:1527009363649};\\\", \\\"{x:623,y:596,t:1527009363667};\\\", \\\"{x:650,y:610,t:1527009363683};\\\", \\\"{x:698,y:634,t:1527009363700};\\\", \\\"{x:779,y:663,t:1527009363716};\\\", \\\"{x:879,y:693,t:1527009363732};\\\", \\\"{x:1003,y:720,t:1527009363750};\\\", \\\"{x:1116,y:734,t:1527009363766};\\\", \\\"{x:1219,y:752,t:1527009363783};\\\", \\\"{x:1302,y:763,t:1527009363799};\\\", \\\"{x:1381,y:778,t:1527009363816};\\\", \\\"{x:1447,y:792,t:1527009363833};\\\", \\\"{x:1466,y:798,t:1527009363849};\\\", \\\"{x:1471,y:799,t:1527009363867};\\\", \\\"{x:1473,y:799,t:1527009363883};\\\", \\\"{x:1475,y:799,t:1527009363900};\\\", \\\"{x:1481,y:799,t:1527009363917};\\\", \\\"{x:1496,y:802,t:1527009363933};\\\", \\\"{x:1519,y:803,t:1527009363950};\\\", \\\"{x:1548,y:803,t:1527009363966};\\\", \\\"{x:1566,y:803,t:1527009363983};\\\", \\\"{x:1569,y:803,t:1527009363999};\\\", \\\"{x:1568,y:803,t:1527009364073};\\\", \\\"{x:1566,y:803,t:1527009364083};\\\", \\\"{x:1560,y:799,t:1527009364099};\\\", \\\"{x:1557,y:797,t:1527009364116};\\\", \\\"{x:1552,y:794,t:1527009364133};\\\", \\\"{x:1546,y:794,t:1527009364149};\\\", \\\"{x:1536,y:791,t:1527009364167};\\\", \\\"{x:1526,y:790,t:1527009364184};\\\", \\\"{x:1516,y:788,t:1527009364200};\\\", \\\"{x:1514,y:788,t:1527009364217};\\\", \\\"{x:1511,y:786,t:1527009364233};\\\", \\\"{x:1511,y:784,t:1527009364274};\\\", \\\"{x:1511,y:782,t:1527009364297};\\\", \\\"{x:1511,y:781,t:1527009364306};\\\", \\\"{x:1511,y:780,t:1527009364316};\\\", \\\"{x:1511,y:777,t:1527009364334};\\\", \\\"{x:1512,y:775,t:1527009364350};\\\", \\\"{x:1512,y:773,t:1527009364366};\\\", \\\"{x:1513,y:768,t:1527009364383};\\\", \\\"{x:1513,y:764,t:1527009364400};\\\", \\\"{x:1514,y:762,t:1527009364417};\\\", \\\"{x:1515,y:760,t:1527009364434};\\\", \\\"{x:1516,y:760,t:1527009364521};\\\", \\\"{x:1517,y:760,t:1527009364533};\\\", \\\"{x:1518,y:762,t:1527009364550};\\\", \\\"{x:1518,y:768,t:1527009364568};\\\", \\\"{x:1518,y:776,t:1527009364583};\\\", \\\"{x:1516,y:784,t:1527009364600};\\\", \\\"{x:1503,y:799,t:1527009364618};\\\", \\\"{x:1497,y:808,t:1527009364633};\\\", \\\"{x:1492,y:814,t:1527009364650};\\\", \\\"{x:1488,y:821,t:1527009364667};\\\", \\\"{x:1486,y:823,t:1527009364683};\\\", \\\"{x:1484,y:827,t:1527009364701};\\\", \\\"{x:1484,y:830,t:1527009364718};\\\", \\\"{x:1484,y:831,t:1527009364733};\\\", \\\"{x:1484,y:832,t:1527009364834};\\\", \\\"{x:1484,y:833,t:1527009364866};\\\", \\\"{x:1484,y:834,t:1527009364873};\\\", \\\"{x:1484,y:836,t:1527009364890};\\\", \\\"{x:1484,y:837,t:1527009364901};\\\", \\\"{x:1484,y:839,t:1527009364917};\\\", \\\"{x:1484,y:841,t:1527009364934};\\\", \\\"{x:1482,y:844,t:1527009364950};\\\", \\\"{x:1481,y:845,t:1527009364967};\\\", \\\"{x:1479,y:848,t:1527009364984};\\\", \\\"{x:1475,y:852,t:1527009365001};\\\", \\\"{x:1466,y:858,t:1527009365018};\\\", \\\"{x:1450,y:865,t:1527009365035};\\\", \\\"{x:1433,y:869,t:1527009365051};\\\", \\\"{x:1407,y:872,t:1527009365068};\\\", \\\"{x:1384,y:874,t:1527009365084};\\\", \\\"{x:1357,y:874,t:1527009365101};\\\", \\\"{x:1333,y:874,t:1527009365118};\\\", \\\"{x:1304,y:874,t:1527009365135};\\\", \\\"{x:1278,y:874,t:1527009365152};\\\", \\\"{x:1255,y:874,t:1527009365168};\\\", \\\"{x:1240,y:874,t:1527009365185};\\\", \\\"{x:1214,y:872,t:1527009365202};\\\", \\\"{x:1192,y:869,t:1527009365218};\\\", \\\"{x:1166,y:867,t:1527009365235};\\\", \\\"{x:1138,y:864,t:1527009365253};\\\", \\\"{x:1107,y:864,t:1527009365268};\\\", \\\"{x:1077,y:862,t:1527009365285};\\\", \\\"{x:1046,y:859,t:1527009365302};\\\", \\\"{x:1017,y:855,t:1527009365318};\\\", \\\"{x:980,y:850,t:1527009365336};\\\", \\\"{x:939,y:843,t:1527009365352};\\\", \\\"{x:897,y:837,t:1527009365368};\\\", \\\"{x:855,y:830,t:1527009365385};\\\", \\\"{x:787,y:815,t:1527009365402};\\\", \\\"{x:739,y:801,t:1527009365419};\\\", \\\"{x:692,y:789,t:1527009365435};\\\", \\\"{x:633,y:771,t:1527009365452};\\\", \\\"{x:578,y:756,t:1527009365469};\\\", \\\"{x:541,y:743,t:1527009365487};\\\", \\\"{x:517,y:737,t:1527009365502};\\\", \\\"{x:500,y:732,t:1527009365517};\\\", \\\"{x:488,y:727,t:1527009365533};\\\", \\\"{x:480,y:724,t:1527009365549};\\\", \\\"{x:473,y:719,t:1527009365567};\\\", \\\"{x:471,y:718,t:1527009365583};\\\", \\\"{x:470,y:716,t:1527009365601};\\\", \\\"{x:469,y:715,t:1527009365617};\\\", \\\"{x:468,y:714,t:1527009365635};\\\", \\\"{x:466,y:714,t:1527009365651};\\\", \\\"{x:466,y:713,t:1527009365667};\\\", \\\"{x:465,y:713,t:1527009365684};\\\", \\\"{x:464,y:713,t:1527009365700};\\\", \\\"{x:466,y:713,t:1527009365778};\\\", \\\"{x:467,y:713,t:1527009365786};\\\", \\\"{x:470,y:715,t:1527009365801};\\\", \\\"{x:471,y:717,t:1527009365817};\\\", \\\"{x:477,y:722,t:1527009365836};\\\", \\\"{x:480,y:729,t:1527009365851};\\\", \\\"{x:481,y:735,t:1527009365867};\\\", \\\"{x:483,y:740,t:1527009365885};\\\", \\\"{x:483,y:741,t:1527009365901};\\\", \\\"{x:483,y:742,t:1527009366041};\\\", \\\"{x:481,y:742,t:1527009366067};\\\", \\\"{x:479,y:742,t:1527009366084};\\\", \\\"{x:478,y:742,t:1527009366101};\\\", \\\"{x:476,y:742,t:1527009366117};\\\", \\\"{x:475,y:742,t:1527009366265};\\\", \\\"{x:474,y:742,t:1527009366274};\\\", \\\"{x:472,y:741,t:1527009366285};\\\", \\\"{x:471,y:741,t:1527009366301};\\\", \\\"{x:466,y:739,t:1527009366318};\\\", \\\"{x:461,y:737,t:1527009366335};\\\", \\\"{x:455,y:735,t:1527009366352};\\\", \\\"{x:447,y:731,t:1527009366367};\\\", \\\"{x:438,y:728,t:1527009366385};\\\", \\\"{x:428,y:724,t:1527009366401};\\\", \\\"{x:424,y:721,t:1527009366419};\\\", \\\"{x:421,y:721,t:1527009366434};\\\", \\\"{x:420,y:720,t:1527009366451};\\\", \\\"{x:418,y:720,t:1527009366467};\\\", \\\"{x:418,y:719,t:1527009366485};\\\", \\\"{x:416,y:719,t:1527009366634};\\\", \\\"{x:410,y:719,t:1527009366651};\\\", \\\"{x:407,y:717,t:1527009366668};\\\", \\\"{x:406,y:716,t:1527009366914};\\\", \\\"{x:404,y:716,t:1527009366922};\\\", \\\"{x:402,y:713,t:1527009366934};\\\", \\\"{x:390,y:690,t:1527009366952};\\\", \\\"{x:360,y:624,t:1527009366968};\\\", \\\"{x:331,y:540,t:1527009366984};\\\", \\\"{x:301,y:437,t:1527009367001};\\\", \\\"{x:287,y:386,t:1527009367018};\\\", \\\"{x:277,y:348,t:1527009367034};\\\", \\\"{x:269,y:325,t:1527009367051};\\\", \\\"{x:268,y:316,t:1527009367070};\\\", \\\"{x:267,y:315,t:1527009367084};\\\" ] }, { \\\"rt\\\": 35831, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 549286, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"C\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -B -X -X -X -B -B -B -X -B -C -P -L -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:267,y:319,t:1527009367561};\\\", \\\"{x:267,y:323,t:1527009367570};\\\", \\\"{x:271,y:341,t:1527009367586};\\\", \\\"{x:278,y:362,t:1527009367602};\\\", \\\"{x:283,y:384,t:1527009367620};\\\", \\\"{x:289,y:404,t:1527009367636};\\\", \\\"{x:310,y:465,t:1527009367705};\\\", \\\"{x:312,y:470,t:1527009367720};\\\", \\\"{x:313,y:472,t:1527009367735};\\\", \\\"{x:313,y:474,t:1527009367857};\\\", \\\"{x:311,y:476,t:1527009367869};\\\", \\\"{x:302,y:479,t:1527009367887};\\\", \\\"{x:291,y:483,t:1527009367902};\\\", \\\"{x:286,y:484,t:1527009367919};\\\", \\\"{x:283,y:484,t:1527009367937};\\\", \\\"{x:282,y:484,t:1527009367953};\\\", \\\"{x:280,y:478,t:1527009367969};\\\", \\\"{x:276,y:470,t:1527009367986};\\\", \\\"{x:272,y:461,t:1527009368002};\\\", \\\"{x:270,y:451,t:1527009368020};\\\", \\\"{x:270,y:447,t:1527009368036};\\\", \\\"{x:270,y:445,t:1527009368052};\\\", \\\"{x:270,y:444,t:1527009368070};\\\", \\\"{x:271,y:444,t:1527009368105};\\\", \\\"{x:274,y:444,t:1527009368120};\\\", \\\"{x:279,y:444,t:1527009368136};\\\", \\\"{x:289,y:444,t:1527009368153};\\\", \\\"{x:307,y:444,t:1527009368169};\\\", \\\"{x:321,y:444,t:1527009368186};\\\", \\\"{x:329,y:444,t:1527009368202};\\\", \\\"{x:335,y:444,t:1527009368219};\\\", \\\"{x:338,y:444,t:1527009368237};\\\", \\\"{x:341,y:444,t:1527009368253};\\\", \\\"{x:342,y:445,t:1527009368270};\\\", \\\"{x:345,y:446,t:1527009368286};\\\", \\\"{x:346,y:448,t:1527009368303};\\\", \\\"{x:347,y:449,t:1527009368320};\\\", \\\"{x:348,y:450,t:1527009368337};\\\", \\\"{x:349,y:450,t:1527009368354};\\\", \\\"{x:349,y:451,t:1527009368369};\\\", \\\"{x:349,y:453,t:1527009368449};\\\", \\\"{x:349,y:454,t:1527009368457};\\\", \\\"{x:349,y:455,t:1527009368470};\\\", \\\"{x:349,y:458,t:1527009368487};\\\", \\\"{x:349,y:459,t:1527009368503};\\\", \\\"{x:348,y:462,t:1527009368519};\\\", \\\"{x:347,y:462,t:1527009368585};\\\", \\\"{x:346,y:462,t:1527009368593};\\\", \\\"{x:344,y:462,t:1527009368609};\\\", \\\"{x:343,y:462,t:1527009368657};\\\", \\\"{x:343,y:461,t:1527009368769};\\\", \\\"{x:343,y:460,t:1527009368777};\\\", \\\"{x:342,y:457,t:1527009368787};\\\", \\\"{x:342,y:456,t:1527009368803};\\\", \\\"{x:342,y:453,t:1527009368821};\\\", \\\"{x:342,y:452,t:1527009368837};\\\", \\\"{x:341,y:451,t:1527009368854};\\\", \\\"{x:342,y:451,t:1527009369089};\\\", \\\"{x:343,y:451,t:1527009369104};\\\", \\\"{x:348,y:450,t:1527009369121};\\\", \\\"{x:352,y:448,t:1527009369136};\\\", \\\"{x:369,y:447,t:1527009369153};\\\", \\\"{x:382,y:446,t:1527009369170};\\\", \\\"{x:394,y:446,t:1527009369187};\\\", \\\"{x:398,y:446,t:1527009369203};\\\", \\\"{x:402,y:446,t:1527009369220};\\\", \\\"{x:404,y:446,t:1527009369237};\\\", \\\"{x:405,y:446,t:1527009369281};\\\", \\\"{x:406,y:446,t:1527009369322};\\\", \\\"{x:407,y:446,t:1527009369337};\\\", \\\"{x:408,y:446,t:1527009369354};\\\", \\\"{x:409,y:446,t:1527009369371};\\\", \\\"{x:410,y:446,t:1527009369388};\\\", \\\"{x:413,y:446,t:1527009369404};\\\", \\\"{x:418,y:446,t:1527009369420};\\\", \\\"{x:424,y:446,t:1527009369438};\\\", \\\"{x:430,y:446,t:1527009369453};\\\", \\\"{x:437,y:446,t:1527009369472};\\\", \\\"{x:442,y:446,t:1527009369488};\\\", \\\"{x:447,y:446,t:1527009369504};\\\", \\\"{x:453,y:446,t:1527009369521};\\\", \\\"{x:459,y:446,t:1527009369537};\\\", \\\"{x:462,y:446,t:1527009369554};\\\", \\\"{x:464,y:446,t:1527009369571};\\\", \\\"{x:465,y:446,t:1527009369587};\\\", \\\"{x:466,y:446,t:1527009369604};\\\", \\\"{x:467,y:446,t:1527009369621};\\\", \\\"{x:468,y:446,t:1527009369637};\\\", \\\"{x:469,y:446,t:1527009369654};\\\", \\\"{x:470,y:446,t:1527009369671};\\\", \\\"{x:472,y:446,t:1527009369688};\\\", \\\"{x:473,y:446,t:1527009369713};\\\", \\\"{x:474,y:446,t:1527009369721};\\\", \\\"{x:475,y:446,t:1527009369738};\\\", \\\"{x:477,y:446,t:1527009369755};\\\", \\\"{x:478,y:446,t:1527009369770};\\\", \\\"{x:480,y:446,t:1527009369787};\\\", \\\"{x:481,y:446,t:1527009369805};\\\", \\\"{x:482,y:446,t:1527009369821};\\\", \\\"{x:485,y:446,t:1527009369838};\\\", \\\"{x:488,y:446,t:1527009369855};\\\", \\\"{x:490,y:446,t:1527009369872};\\\", \\\"{x:494,y:446,t:1527009369888};\\\", \\\"{x:495,y:446,t:1527009369905};\\\", \\\"{x:497,y:446,t:1527009369922};\\\", \\\"{x:498,y:446,t:1527009369938};\\\", \\\"{x:499,y:446,t:1527009370146};\\\", \\\"{x:500,y:446,t:1527009370202};\\\", \\\"{x:501,y:446,t:1527009370210};\\\", \\\"{x:502,y:446,t:1527009370234};\\\", \\\"{x:504,y:446,t:1527009370242};\\\", \\\"{x:506,y:446,t:1527009370255};\\\", \\\"{x:511,y:446,t:1527009370273};\\\", \\\"{x:520,y:446,t:1527009370288};\\\", \\\"{x:524,y:446,t:1527009370305};\\\", \\\"{x:529,y:446,t:1527009370322};\\\", \\\"{x:530,y:446,t:1527009370338};\\\", \\\"{x:531,y:446,t:1527009370370};\\\", \\\"{x:532,y:446,t:1527009370411};\\\", \\\"{x:533,y:446,t:1527009370426};\\\", \\\"{x:535,y:446,t:1527009370442};\\\", \\\"{x:536,y:446,t:1527009370455};\\\", \\\"{x:543,y:446,t:1527009370473};\\\", \\\"{x:550,y:446,t:1527009370489};\\\", \\\"{x:559,y:446,t:1527009370505};\\\", \\\"{x:572,y:446,t:1527009370522};\\\", \\\"{x:578,y:446,t:1527009370539};\\\", \\\"{x:581,y:446,t:1527009370555};\\\", \\\"{x:582,y:446,t:1527009370572};\\\", \\\"{x:584,y:447,t:1527009370589};\\\", \\\"{x:585,y:447,t:1527009370946};\\\", \\\"{x:586,y:447,t:1527009370955};\\\", \\\"{x:589,y:447,t:1527009370972};\\\", \\\"{x:595,y:447,t:1527009370989};\\\", \\\"{x:601,y:447,t:1527009371006};\\\", \\\"{x:607,y:447,t:1527009371022};\\\", \\\"{x:618,y:447,t:1527009371039};\\\", \\\"{x:626,y:447,t:1527009371056};\\\", \\\"{x:632,y:447,t:1527009371072};\\\", \\\"{x:641,y:447,t:1527009371089};\\\", \\\"{x:653,y:447,t:1527009371106};\\\", \\\"{x:665,y:447,t:1527009371122};\\\", \\\"{x:681,y:447,t:1527009371139};\\\", \\\"{x:697,y:447,t:1527009371156};\\\", \\\"{x:714,y:448,t:1527009371172};\\\", \\\"{x:733,y:450,t:1527009371189};\\\", \\\"{x:750,y:453,t:1527009371206};\\\", \\\"{x:769,y:455,t:1527009371222};\\\", \\\"{x:785,y:458,t:1527009371239};\\\", \\\"{x:795,y:459,t:1527009371255};\\\", \\\"{x:799,y:459,t:1527009371272};\\\", \\\"{x:800,y:459,t:1527009371289};\\\", \\\"{x:799,y:460,t:1527009372017};\\\", \\\"{x:795,y:460,t:1527009372025};\\\", \\\"{x:783,y:463,t:1527009372040};\\\", \\\"{x:762,y:465,t:1527009372056};\\\", \\\"{x:731,y:469,t:1527009372072};\\\", \\\"{x:675,y:469,t:1527009372089};\\\", \\\"{x:647,y:469,t:1527009372105};\\\", \\\"{x:625,y:469,t:1527009372123};\\\", \\\"{x:611,y:468,t:1527009372140};\\\", \\\"{x:606,y:466,t:1527009372155};\\\", \\\"{x:606,y:465,t:1527009372177};\\\", \\\"{x:605,y:464,t:1527009372193};\\\", \\\"{x:605,y:463,t:1527009372401};\\\", \\\"{x:604,y:463,t:1527009372442};\\\", \\\"{x:603,y:463,t:1527009372466};\\\", \\\"{x:601,y:463,t:1527009372489};\\\", \\\"{x:600,y:462,t:1527009372507};\\\", \\\"{x:599,y:461,t:1527009372538};\\\", \\\"{x:597,y:461,t:1527009372546};\\\", \\\"{x:597,y:460,t:1527009372557};\\\", \\\"{x:595,y:459,t:1527009372573};\\\", \\\"{x:594,y:458,t:1527009372590};\\\", \\\"{x:592,y:456,t:1527009372607};\\\", \\\"{x:591,y:455,t:1527009372623};\\\", \\\"{x:590,y:454,t:1527009372641};\\\", \\\"{x:588,y:454,t:1527009372810};\\\", \\\"{x:587,y:455,t:1527009373290};\\\", \\\"{x:578,y:457,t:1527009373307};\\\", \\\"{x:564,y:457,t:1527009373324};\\\", \\\"{x:548,y:457,t:1527009373341};\\\", \\\"{x:526,y:457,t:1527009373358};\\\", \\\"{x:500,y:457,t:1527009373374};\\\", \\\"{x:471,y:457,t:1527009373391};\\\", \\\"{x:435,y:457,t:1527009373407};\\\", \\\"{x:405,y:457,t:1527009373423};\\\", \\\"{x:377,y:457,t:1527009373440};\\\", \\\"{x:351,y:459,t:1527009373456};\\\", \\\"{x:324,y:464,t:1527009373474};\\\", \\\"{x:314,y:465,t:1527009373491};\\\", \\\"{x:309,y:465,t:1527009373508};\\\", \\\"{x:306,y:465,t:1527009373524};\\\", \\\"{x:304,y:465,t:1527009373541};\\\", \\\"{x:302,y:465,t:1527009373561};\\\", \\\"{x:300,y:464,t:1527009373577};\\\", \\\"{x:299,y:464,t:1527009373593};\\\", \\\"{x:297,y:463,t:1527009373608};\\\", \\\"{x:292,y:463,t:1527009373624};\\\", \\\"{x:286,y:463,t:1527009373641};\\\", \\\"{x:277,y:464,t:1527009373657};\\\", \\\"{x:271,y:466,t:1527009373674};\\\", \\\"{x:266,y:467,t:1527009373691};\\\", \\\"{x:266,y:466,t:1527009373737};\\\", \\\"{x:266,y:465,t:1527009373745};\\\", \\\"{x:266,y:464,t:1527009373757};\\\", \\\"{x:266,y:462,t:1527009373774};\\\", \\\"{x:266,y:461,t:1527009373791};\\\", \\\"{x:266,y:460,t:1527009373808};\\\", \\\"{x:268,y:458,t:1527009373977};\\\", \\\"{x:269,y:458,t:1527009374001};\\\", \\\"{x:270,y:458,t:1527009374017};\\\", \\\"{x:271,y:458,t:1527009374041};\\\", \\\"{x:273,y:458,t:1527009374057};\\\", \\\"{x:275,y:459,t:1527009374075};\\\", \\\"{x:279,y:461,t:1527009374090};\\\", \\\"{x:283,y:461,t:1527009374108};\\\", \\\"{x:287,y:462,t:1527009374125};\\\", \\\"{x:292,y:462,t:1527009374141};\\\", \\\"{x:295,y:462,t:1527009374158};\\\", \\\"{x:297,y:462,t:1527009374174};\\\", \\\"{x:299,y:462,t:1527009374191};\\\", \\\"{x:300,y:462,t:1527009374207};\\\", \\\"{x:301,y:462,t:1527009374257};\\\", \\\"{x:303,y:462,t:1527009374275};\\\", \\\"{x:304,y:463,t:1527009374291};\\\", \\\"{x:305,y:463,t:1527009374321};\\\", \\\"{x:306,y:463,t:1527009374337};\\\", \\\"{x:307,y:463,t:1527009374426};\\\", \\\"{x:308,y:463,t:1527009374442};\\\", \\\"{x:309,y:463,t:1527009374458};\\\", \\\"{x:310,y:463,t:1527009374475};\\\", \\\"{x:312,y:463,t:1527009374492};\\\", \\\"{x:314,y:463,t:1527009374508};\\\", \\\"{x:319,y:463,t:1527009374526};\\\", \\\"{x:322,y:463,t:1527009374542};\\\", \\\"{x:327,y:462,t:1527009374558};\\\", \\\"{x:334,y:461,t:1527009374575};\\\", \\\"{x:343,y:460,t:1527009374593};\\\", \\\"{x:352,y:460,t:1527009374609};\\\", \\\"{x:369,y:460,t:1527009374625};\\\", \\\"{x:411,y:460,t:1527009374642};\\\", \\\"{x:453,y:460,t:1527009374659};\\\", \\\"{x:512,y:460,t:1527009374675};\\\", \\\"{x:592,y:460,t:1527009374692};\\\", \\\"{x:681,y:460,t:1527009374708};\\\", \\\"{x:767,y:460,t:1527009374725};\\\", \\\"{x:853,y:460,t:1527009374742};\\\", \\\"{x:937,y:460,t:1527009374758};\\\", \\\"{x:1009,y:460,t:1527009374775};\\\", \\\"{x:1062,y:460,t:1527009374792};\\\", \\\"{x:1108,y:462,t:1527009374808};\\\", \\\"{x:1139,y:465,t:1527009374825};\\\", \\\"{x:1180,y:475,t:1527009374841};\\\", \\\"{x:1201,y:480,t:1527009374858};\\\", \\\"{x:1222,y:485,t:1527009374875};\\\", \\\"{x:1244,y:487,t:1527009374892};\\\", \\\"{x:1263,y:488,t:1527009374909};\\\", \\\"{x:1289,y:488,t:1527009374925};\\\", \\\"{x:1316,y:488,t:1527009374941};\\\", \\\"{x:1344,y:488,t:1527009374959};\\\", \\\"{x:1376,y:488,t:1527009374975};\\\", \\\"{x:1420,y:488,t:1527009374992};\\\", \\\"{x:1468,y:488,t:1527009375009};\\\", \\\"{x:1512,y:492,t:1527009375025};\\\", \\\"{x:1572,y:499,t:1527009375042};\\\", \\\"{x:1603,y:505,t:1527009375059};\\\", \\\"{x:1633,y:510,t:1527009375075};\\\", \\\"{x:1655,y:513,t:1527009375092};\\\", \\\"{x:1677,y:516,t:1527009375109};\\\", \\\"{x:1701,y:517,t:1527009375124};\\\", \\\"{x:1726,y:518,t:1527009375142};\\\", \\\"{x:1749,y:518,t:1527009375159};\\\", \\\"{x:1768,y:518,t:1527009375175};\\\", \\\"{x:1782,y:518,t:1527009375192};\\\", \\\"{x:1790,y:518,t:1527009375209};\\\", \\\"{x:1799,y:518,t:1527009375225};\\\", \\\"{x:1801,y:519,t:1527009375241};\\\", \\\"{x:1801,y:520,t:1527009375265};\\\", \\\"{x:1801,y:521,t:1527009375281};\\\", \\\"{x:1801,y:522,t:1527009375292};\\\", \\\"{x:1800,y:523,t:1527009375309};\\\", \\\"{x:1797,y:523,t:1527009375326};\\\", \\\"{x:1790,y:523,t:1527009375342};\\\", \\\"{x:1777,y:524,t:1527009375359};\\\", \\\"{x:1762,y:529,t:1527009375375};\\\", \\\"{x:1743,y:535,t:1527009375393};\\\", \\\"{x:1723,y:542,t:1527009375410};\\\", \\\"{x:1705,y:543,t:1527009375426};\\\", \\\"{x:1692,y:543,t:1527009375443};\\\", \\\"{x:1681,y:543,t:1527009375459};\\\", \\\"{x:1674,y:543,t:1527009375476};\\\", \\\"{x:1668,y:542,t:1527009375493};\\\", \\\"{x:1666,y:542,t:1527009375509};\\\", \\\"{x:1663,y:542,t:1527009375526};\\\", \\\"{x:1659,y:540,t:1527009375542};\\\", \\\"{x:1654,y:540,t:1527009375559};\\\", \\\"{x:1648,y:540,t:1527009375576};\\\", \\\"{x:1643,y:540,t:1527009375591};\\\", \\\"{x:1635,y:540,t:1527009375609};\\\", \\\"{x:1617,y:538,t:1527009375626};\\\", \\\"{x:1602,y:535,t:1527009375642};\\\", \\\"{x:1583,y:533,t:1527009375659};\\\", \\\"{x:1569,y:528,t:1527009375676};\\\", \\\"{x:1553,y:524,t:1527009375691};\\\", \\\"{x:1539,y:516,t:1527009375709};\\\", \\\"{x:1521,y:504,t:1527009375726};\\\", \\\"{x:1503,y:494,t:1527009375743};\\\", \\\"{x:1479,y:480,t:1527009375759};\\\", \\\"{x:1457,y:471,t:1527009375776};\\\", \\\"{x:1436,y:463,t:1527009375793};\\\", \\\"{x:1416,y:454,t:1527009375809};\\\", \\\"{x:1407,y:446,t:1527009375826};\\\", \\\"{x:1400,y:435,t:1527009375843};\\\", \\\"{x:1394,y:427,t:1527009375859};\\\", \\\"{x:1390,y:418,t:1527009375876};\\\", \\\"{x:1387,y:411,t:1527009375893};\\\", \\\"{x:1386,y:408,t:1527009375909};\\\", \\\"{x:1386,y:407,t:1527009375926};\\\", \\\"{x:1384,y:408,t:1527009375970};\\\", \\\"{x:1383,y:410,t:1527009375978};\\\", \\\"{x:1380,y:419,t:1527009375993};\\\", \\\"{x:1375,y:433,t:1527009376010};\\\", \\\"{x:1370,y:450,t:1527009376026};\\\", \\\"{x:1367,y:464,t:1527009376044};\\\", \\\"{x:1363,y:476,t:1527009376060};\\\", \\\"{x:1362,y:481,t:1527009376076};\\\", \\\"{x:1362,y:484,t:1527009376093};\\\", \\\"{x:1362,y:485,t:1527009376109};\\\", \\\"{x:1362,y:487,t:1527009376126};\\\", \\\"{x:1363,y:487,t:1527009376153};\\\", \\\"{x:1364,y:487,t:1527009376233};\\\", \\\"{x:1366,y:489,t:1527009376243};\\\", \\\"{x:1366,y:497,t:1527009376260};\\\", \\\"{x:1366,y:511,t:1527009376276};\\\", \\\"{x:1361,y:526,t:1527009376293};\\\", \\\"{x:1351,y:540,t:1527009376310};\\\", \\\"{x:1339,y:555,t:1527009376326};\\\", \\\"{x:1331,y:562,t:1527009376344};\\\", \\\"{x:1318,y:570,t:1527009376360};\\\", \\\"{x:1312,y:573,t:1527009376376};\\\", \\\"{x:1308,y:576,t:1527009376393};\\\", \\\"{x:1307,y:576,t:1527009376410};\\\", \\\"{x:1307,y:574,t:1527009376465};\\\", \\\"{x:1311,y:570,t:1527009376476};\\\", \\\"{x:1328,y:564,t:1527009376492};\\\", \\\"{x:1352,y:563,t:1527009376511};\\\", \\\"{x:1386,y:563,t:1527009376526};\\\", \\\"{x:1414,y:563,t:1527009376544};\\\", \\\"{x:1436,y:563,t:1527009376561};\\\", \\\"{x:1446,y:563,t:1527009376576};\\\", \\\"{x:1447,y:563,t:1527009376593};\\\", \\\"{x:1446,y:564,t:1527009376649};\\\", \\\"{x:1443,y:566,t:1527009376665};\\\", \\\"{x:1439,y:569,t:1527009376677};\\\", \\\"{x:1429,y:576,t:1527009376693};\\\", \\\"{x:1416,y:586,t:1527009376710};\\\", \\\"{x:1399,y:596,t:1527009376727};\\\", \\\"{x:1379,y:609,t:1527009376743};\\\", \\\"{x:1360,y:621,t:1527009376760};\\\", \\\"{x:1335,y:642,t:1527009376778};\\\", \\\"{x:1323,y:653,t:1527009376794};\\\", \\\"{x:1315,y:662,t:1527009376810};\\\", \\\"{x:1311,y:666,t:1527009376827};\\\", \\\"{x:1310,y:666,t:1527009376843};\\\", \\\"{x:1309,y:666,t:1527009376874};\\\", \\\"{x:1308,y:666,t:1527009376890};\\\", \\\"{x:1307,y:666,t:1527009376914};\\\", \\\"{x:1306,y:666,t:1527009376927};\\\", \\\"{x:1305,y:667,t:1527009376944};\\\", \\\"{x:1303,y:672,t:1527009376961};\\\", \\\"{x:1302,y:685,t:1527009376978};\\\", \\\"{x:1299,y:698,t:1527009376993};\\\", \\\"{x:1296,y:712,t:1527009377010};\\\", \\\"{x:1296,y:720,t:1527009377027};\\\", \\\"{x:1296,y:724,t:1527009377043};\\\", \\\"{x:1296,y:728,t:1527009377061};\\\", \\\"{x:1297,y:731,t:1527009377078};\\\", \\\"{x:1299,y:733,t:1527009377094};\\\", \\\"{x:1300,y:734,t:1527009377110};\\\", \\\"{x:1302,y:734,t:1527009377127};\\\", \\\"{x:1305,y:735,t:1527009377144};\\\", \\\"{x:1308,y:735,t:1527009377160};\\\", \\\"{x:1312,y:735,t:1527009377177};\\\", \\\"{x:1316,y:735,t:1527009377193};\\\", \\\"{x:1323,y:738,t:1527009377210};\\\", \\\"{x:1332,y:740,t:1527009377226};\\\", \\\"{x:1341,y:742,t:1527009377244};\\\", \\\"{x:1348,y:742,t:1527009377260};\\\", \\\"{x:1352,y:743,t:1527009377277};\\\", \\\"{x:1353,y:744,t:1527009377294};\\\", \\\"{x:1354,y:745,t:1527009377313};\\\", \\\"{x:1355,y:745,t:1527009377385};\\\", \\\"{x:1356,y:745,t:1527009377618};\\\", \\\"{x:1357,y:745,t:1527009377650};\\\", \\\"{x:1358,y:745,t:1527009377662};\\\", \\\"{x:1359,y:745,t:1527009377677};\\\", \\\"{x:1360,y:745,t:1527009377697};\\\", \\\"{x:1362,y:745,t:1527009377712};\\\", \\\"{x:1362,y:746,t:1527009377727};\\\", \\\"{x:1363,y:747,t:1527009377745};\\\", \\\"{x:1366,y:750,t:1527009377762};\\\", \\\"{x:1367,y:751,t:1527009377778};\\\", \\\"{x:1367,y:752,t:1527009377794};\\\", \\\"{x:1368,y:753,t:1527009377811};\\\", \\\"{x:1367,y:753,t:1527009378266};\\\", \\\"{x:1366,y:751,t:1527009378289};\\\", \\\"{x:1365,y:751,t:1527009378345};\\\", \\\"{x:1363,y:751,t:1527009378361};\\\", \\\"{x:1362,y:751,t:1527009378378};\\\", \\\"{x:1360,y:752,t:1527009378395};\\\", \\\"{x:1359,y:753,t:1527009378411};\\\", \\\"{x:1359,y:754,t:1527009378449};\\\", \\\"{x:1358,y:754,t:1527009378562};\\\", \\\"{x:1357,y:755,t:1527009378578};\\\", \\\"{x:1356,y:756,t:1527009378610};\\\", \\\"{x:1355,y:756,t:1527009378722};\\\", \\\"{x:1354,y:756,t:1527009378738};\\\", \\\"{x:1353,y:756,t:1527009378762};\\\", \\\"{x:1352,y:757,t:1527009378778};\\\", \\\"{x:1351,y:757,t:1527009378795};\\\", \\\"{x:1350,y:758,t:1527009378812};\\\", \\\"{x:1349,y:758,t:1527009378849};\\\", \\\"{x:1348,y:758,t:1527009378897};\\\", \\\"{x:1347,y:758,t:1527009379082};\\\", \\\"{x:1348,y:758,t:1527009383201};\\\", \\\"{x:1350,y:758,t:1527009383217};\\\", \\\"{x:1351,y:758,t:1527009383233};\\\", \\\"{x:1355,y:762,t:1527009383248};\\\", \\\"{x:1376,y:774,t:1527009383265};\\\", \\\"{x:1397,y:784,t:1527009383282};\\\", \\\"{x:1421,y:791,t:1527009383298};\\\", \\\"{x:1441,y:798,t:1527009383315};\\\", \\\"{x:1452,y:802,t:1527009383332};\\\", \\\"{x:1454,y:804,t:1527009383349};\\\", \\\"{x:1454,y:805,t:1527009383473};\\\", \\\"{x:1454,y:806,t:1527009383482};\\\", \\\"{x:1455,y:807,t:1527009383498};\\\", \\\"{x:1457,y:808,t:1527009383521};\\\", \\\"{x:1459,y:809,t:1527009383532};\\\", \\\"{x:1465,y:814,t:1527009383548};\\\", \\\"{x:1472,y:819,t:1527009383566};\\\", \\\"{x:1479,y:823,t:1527009383582};\\\", \\\"{x:1484,y:826,t:1527009383599};\\\", \\\"{x:1487,y:829,t:1527009383615};\\\", \\\"{x:1488,y:830,t:1527009383649};\\\", \\\"{x:1488,y:831,t:1527009383722};\\\", \\\"{x:1488,y:832,t:1527009383737};\\\", \\\"{x:1489,y:832,t:1527009383750};\\\", \\\"{x:1489,y:833,t:1527009383766};\\\", \\\"{x:1490,y:833,t:1527009383783};\\\", \\\"{x:1489,y:833,t:1527009383873};\\\", \\\"{x:1487,y:833,t:1527009383882};\\\", \\\"{x:1486,y:833,t:1527009383905};\\\", \\\"{x:1484,y:833,t:1527009383915};\\\", \\\"{x:1483,y:831,t:1527009383932};\\\", \\\"{x:1482,y:830,t:1527009383949};\\\", \\\"{x:1481,y:830,t:1527009383965};\\\", \\\"{x:1480,y:830,t:1527009383993};\\\", \\\"{x:1479,y:830,t:1527009384018};\\\", \\\"{x:1478,y:829,t:1527009384033};\\\", \\\"{x:1480,y:829,t:1527009384609};\\\", \\\"{x:1476,y:829,t:1527009385025};\\\", \\\"{x:1467,y:826,t:1527009385033};\\\", \\\"{x:1444,y:820,t:1527009385050};\\\", \\\"{x:1421,y:814,t:1527009385066};\\\", \\\"{x:1392,y:803,t:1527009385083};\\\", \\\"{x:1368,y:793,t:1527009385100};\\\", \\\"{x:1357,y:787,t:1527009385116};\\\", \\\"{x:1351,y:783,t:1527009385133};\\\", \\\"{x:1350,y:783,t:1527009385150};\\\", \\\"{x:1350,y:782,t:1527009385167};\\\", \\\"{x:1349,y:782,t:1527009385233};\\\", \\\"{x:1349,y:781,t:1527009385256};\\\", \\\"{x:1349,y:779,t:1527009385266};\\\", \\\"{x:1349,y:777,t:1527009385283};\\\", \\\"{x:1349,y:773,t:1527009385300};\\\", \\\"{x:1351,y:769,t:1527009385317};\\\", \\\"{x:1352,y:768,t:1527009385333};\\\", \\\"{x:1353,y:768,t:1527009385449};\\\", \\\"{x:1353,y:767,t:1527009385473};\\\", \\\"{x:1353,y:766,t:1527009385497};\\\", \\\"{x:1352,y:765,t:1527009385512};\\\", \\\"{x:1351,y:765,t:1527009385593};\\\", \\\"{x:1349,y:764,t:1527009385649};\\\", \\\"{x:1347,y:763,t:1527009385681};\\\", \\\"{x:1349,y:763,t:1527009389442};\\\", \\\"{x:1354,y:763,t:1527009389454};\\\", \\\"{x:1365,y:763,t:1527009389471};\\\", \\\"{x:1380,y:763,t:1527009389487};\\\", \\\"{x:1393,y:763,t:1527009389503};\\\", \\\"{x:1398,y:763,t:1527009389520};\\\", \\\"{x:1400,y:763,t:1527009389536};\\\", \\\"{x:1401,y:763,t:1527009389953};\\\", \\\"{x:1401,y:762,t:1527009389984};\\\", \\\"{x:1399,y:762,t:1527009389993};\\\", \\\"{x:1395,y:762,t:1527009390003};\\\", \\\"{x:1379,y:759,t:1527009390020};\\\", \\\"{x:1360,y:757,t:1527009390038};\\\", \\\"{x:1344,y:755,t:1527009390053};\\\", \\\"{x:1334,y:754,t:1527009390071};\\\", \\\"{x:1331,y:753,t:1527009390088};\\\", \\\"{x:1330,y:753,t:1527009390129};\\\", \\\"{x:1332,y:754,t:1527009390298};\\\", \\\"{x:1333,y:754,t:1527009390306};\\\", \\\"{x:1335,y:755,t:1527009390321};\\\", \\\"{x:1343,y:758,t:1527009390337};\\\", \\\"{x:1351,y:760,t:1527009390355};\\\", \\\"{x:1361,y:762,t:1527009390371};\\\", \\\"{x:1372,y:766,t:1527009390387};\\\", \\\"{x:1376,y:768,t:1527009390404};\\\", \\\"{x:1381,y:770,t:1527009390420};\\\", \\\"{x:1385,y:771,t:1527009390437};\\\", \\\"{x:1388,y:773,t:1527009390455};\\\", \\\"{x:1389,y:774,t:1527009390471};\\\", \\\"{x:1391,y:775,t:1527009390488};\\\", \\\"{x:1393,y:777,t:1527009390505};\\\", \\\"{x:1396,y:779,t:1527009390520};\\\", \\\"{x:1399,y:781,t:1527009390538};\\\", \\\"{x:1402,y:782,t:1527009390554};\\\", \\\"{x:1406,y:785,t:1527009390570};\\\", \\\"{x:1410,y:788,t:1527009390587};\\\", \\\"{x:1413,y:789,t:1527009390604};\\\", \\\"{x:1421,y:793,t:1527009390620};\\\", \\\"{x:1426,y:795,t:1527009390637};\\\", \\\"{x:1428,y:796,t:1527009390655};\\\", \\\"{x:1433,y:800,t:1527009390671};\\\", \\\"{x:1437,y:801,t:1527009390688};\\\", \\\"{x:1441,y:804,t:1527009390705};\\\", \\\"{x:1444,y:805,t:1527009390721};\\\", \\\"{x:1444,y:806,t:1527009390737};\\\", \\\"{x:1445,y:807,t:1527009390755};\\\", \\\"{x:1446,y:807,t:1527009390772};\\\", \\\"{x:1447,y:808,t:1527009390788};\\\", \\\"{x:1448,y:808,t:1527009390809};\\\", \\\"{x:1451,y:810,t:1527009390822};\\\", \\\"{x:1452,y:811,t:1527009390837};\\\", \\\"{x:1454,y:811,t:1527009390855};\\\", \\\"{x:1455,y:813,t:1527009390871};\\\", \\\"{x:1457,y:814,t:1527009390887};\\\", \\\"{x:1460,y:816,t:1527009390905};\\\", \\\"{x:1464,y:819,t:1527009390921};\\\", \\\"{x:1467,y:821,t:1527009390937};\\\", \\\"{x:1470,y:821,t:1527009390954};\\\", \\\"{x:1471,y:823,t:1527009390971};\\\", \\\"{x:1473,y:825,t:1527009390988};\\\", \\\"{x:1475,y:826,t:1527009391004};\\\", \\\"{x:1478,y:829,t:1527009391022};\\\", \\\"{x:1479,y:830,t:1527009391054};\\\", \\\"{x:1479,y:828,t:1527009391201};\\\", \\\"{x:1476,y:827,t:1527009391209};\\\", \\\"{x:1474,y:825,t:1527009391222};\\\", \\\"{x:1464,y:821,t:1527009391238};\\\", \\\"{x:1449,y:815,t:1527009391254};\\\", \\\"{x:1431,y:810,t:1527009391271};\\\", \\\"{x:1412,y:805,t:1527009391289};\\\", \\\"{x:1409,y:803,t:1527009391305};\\\", \\\"{x:1398,y:801,t:1527009391321};\\\", \\\"{x:1395,y:799,t:1527009391338};\\\", \\\"{x:1393,y:799,t:1527009391354};\\\", \\\"{x:1392,y:798,t:1527009391372};\\\", \\\"{x:1390,y:796,t:1527009391389};\\\", \\\"{x:1387,y:795,t:1527009391405};\\\", \\\"{x:1385,y:794,t:1527009391422};\\\", \\\"{x:1380,y:792,t:1527009391439};\\\", \\\"{x:1376,y:790,t:1527009391454};\\\", \\\"{x:1364,y:788,t:1527009391472};\\\", \\\"{x:1355,y:785,t:1527009391488};\\\", \\\"{x:1352,y:783,t:1527009391504};\\\", \\\"{x:1350,y:780,t:1527009391522};\\\", \\\"{x:1347,y:777,t:1527009391539};\\\", \\\"{x:1347,y:774,t:1527009391556};\\\", \\\"{x:1346,y:772,t:1527009391572};\\\", \\\"{x:1345,y:771,t:1527009391589};\\\", \\\"{x:1345,y:770,t:1527009391617};\\\", \\\"{x:1345,y:769,t:1527009391754};\\\", \\\"{x:1346,y:768,t:1527009391762};\\\", \\\"{x:1346,y:766,t:1527009391772};\\\", \\\"{x:1350,y:761,t:1527009391788};\\\", \\\"{x:1357,y:755,t:1527009391806};\\\", \\\"{x:1361,y:750,t:1527009391821};\\\", \\\"{x:1367,y:744,t:1527009391839};\\\", \\\"{x:1370,y:740,t:1527009391855};\\\", \\\"{x:1376,y:734,t:1527009391872};\\\", \\\"{x:1383,y:725,t:1527009391889};\\\", \\\"{x:1396,y:709,t:1527009391905};\\\", \\\"{x:1408,y:695,t:1527009391922};\\\", \\\"{x:1414,y:688,t:1527009391939};\\\", \\\"{x:1424,y:677,t:1527009391955};\\\", \\\"{x:1429,y:671,t:1527009391972};\\\", \\\"{x:1434,y:665,t:1527009391989};\\\", \\\"{x:1436,y:661,t:1527009392006};\\\", \\\"{x:1437,y:658,t:1527009392022};\\\", \\\"{x:1440,y:652,t:1527009392039};\\\", \\\"{x:1441,y:649,t:1527009392056};\\\", \\\"{x:1444,y:644,t:1527009392073};\\\", \\\"{x:1445,y:641,t:1527009392088};\\\", \\\"{x:1446,y:638,t:1527009392105};\\\", \\\"{x:1447,y:637,t:1527009392123};\\\", \\\"{x:1447,y:636,t:1527009392139};\\\", \\\"{x:1447,y:635,t:1527009392156};\\\", \\\"{x:1447,y:634,t:1527009392173};\\\", \\\"{x:1447,y:633,t:1527009392189};\\\", \\\"{x:1447,y:632,t:1527009392206};\\\", \\\"{x:1448,y:630,t:1527009392223};\\\", \\\"{x:1449,y:629,t:1527009392239};\\\", \\\"{x:1450,y:629,t:1527009393461};\\\", \\\"{x:1455,y:654,t:1527009393478};\\\", \\\"{x:1459,y:728,t:1527009393493};\\\", \\\"{x:1463,y:815,t:1527009393511};\\\", \\\"{x:1463,y:853,t:1527009393528};\\\", \\\"{x:1464,y:858,t:1527009393543};\\\", \\\"{x:1467,y:858,t:1527009393561};\\\", \\\"{x:1467,y:863,t:1527009393578};\\\", \\\"{x:1467,y:865,t:1527009393594};\\\", \\\"{x:1468,y:865,t:1527009393611};\\\", \\\"{x:1467,y:865,t:1527009393774};\\\", \\\"{x:1465,y:865,t:1527009393782};\\\", \\\"{x:1464,y:865,t:1527009393795};\\\", \\\"{x:1455,y:865,t:1527009393811};\\\", \\\"{x:1444,y:867,t:1527009393828};\\\", \\\"{x:1439,y:869,t:1527009393844};\\\", \\\"{x:1432,y:873,t:1527009393860};\\\", \\\"{x:1431,y:874,t:1527009393878};\\\", \\\"{x:1430,y:874,t:1527009393925};\\\", \\\"{x:1430,y:875,t:1527009393933};\\\", \\\"{x:1429,y:876,t:1527009393965};\\\", \\\"{x:1428,y:877,t:1527009394038};\\\", \\\"{x:1427,y:877,t:1527009394085};\\\", \\\"{x:1424,y:877,t:1527009394125};\\\", \\\"{x:1421,y:875,t:1527009394134};\\\", \\\"{x:1417,y:872,t:1527009394145};\\\", \\\"{x:1399,y:862,t:1527009394161};\\\", \\\"{x:1376,y:847,t:1527009394178};\\\", \\\"{x:1362,y:843,t:1527009394195};\\\", \\\"{x:1360,y:843,t:1527009394211};\\\", \\\"{x:1360,y:836,t:1527009394227};\\\", \\\"{x:1359,y:834,t:1527009394244};\\\", \\\"{x:1358,y:832,t:1527009394341};\\\", \\\"{x:1358,y:831,t:1527009394348};\\\", \\\"{x:1356,y:830,t:1527009394381};\\\", \\\"{x:1353,y:830,t:1527009394394};\\\", \\\"{x:1330,y:826,t:1527009394412};\\\", \\\"{x:1312,y:817,t:1527009394427};\\\", \\\"{x:1302,y:813,t:1527009394444};\\\", \\\"{x:1299,y:809,t:1527009394461};\\\", \\\"{x:1215,y:808,t:1527009394477};\\\", \\\"{x:1122,y:804,t:1527009394495};\\\", \\\"{x:1039,y:793,t:1527009394511};\\\", \\\"{x:967,y:782,t:1527009394528};\\\", \\\"{x:913,y:775,t:1527009394544};\\\", \\\"{x:883,y:770,t:1527009394562};\\\", \\\"{x:860,y:763,t:1527009394577};\\\", \\\"{x:840,y:756,t:1527009394594};\\\", \\\"{x:820,y:747,t:1527009394612};\\\", \\\"{x:794,y:736,t:1527009394629};\\\", \\\"{x:741,y:715,t:1527009394644};\\\", \\\"{x:700,y:705,t:1527009394661};\\\", \\\"{x:663,y:700,t:1527009394678};\\\", \\\"{x:621,y:694,t:1527009394694};\\\", \\\"{x:584,y:693,t:1527009394711};\\\", \\\"{x:558,y:690,t:1527009394729};\\\", \\\"{x:546,y:690,t:1527009394745};\\\", \\\"{x:543,y:689,t:1527009394762};\\\", \\\"{x:542,y:688,t:1527009394778};\\\", \\\"{x:540,y:688,t:1527009394794};\\\", \\\"{x:539,y:687,t:1527009394812};\\\", \\\"{x:533,y:679,t:1527009394828};\\\", \\\"{x:529,y:674,t:1527009394845};\\\", \\\"{x:523,y:670,t:1527009394861};\\\", \\\"{x:519,y:667,t:1527009394879};\\\", \\\"{x:516,y:665,t:1527009394894};\\\", \\\"{x:516,y:661,t:1527009394911};\\\", \\\"{x:525,y:649,t:1527009394929};\\\", \\\"{x:542,y:638,t:1527009394944};\\\", \\\"{x:596,y:611,t:1527009394962};\\\", \\\"{x:689,y:571,t:1527009394979};\\\", \\\"{x:821,y:521,t:1527009394996};\\\", \\\"{x:1000,y:471,t:1527009395007};\\\", \\\"{x:1229,y:403,t:1527009395024};\\\", \\\"{x:1505,y:318,t:1527009395042};\\\", \\\"{x:1781,y:238,t:1527009395058};\\\", \\\"{x:1919,y:153,t:1527009395074};\\\", \\\"{x:1919,y:91,t:1527009395092};\\\", \\\"{x:1919,y:31,t:1527009395112};\\\", \\\"{x:1919,y:21,t:1527009395130};\\\", \\\"{x:1919,y:20,t:1527009395172};\\\", \\\"{x:1919,y:19,t:1527009395189};\\\", \\\"{x:1915,y:17,t:1527009395196};\\\", \\\"{x:1905,y:16,t:1527009395212};\\\", \\\"{x:1898,y:16,t:1527009395229};\\\", \\\"{x:1879,y:16,t:1527009395246};\\\", \\\"{x:1830,y:29,t:1527009395262};\\\", \\\"{x:1755,y:77,t:1527009395279};\\\", \\\"{x:1708,y:125,t:1527009395296};\\\", \\\"{x:1688,y:156,t:1527009395312};\\\", \\\"{x:1675,y:175,t:1527009395330};\\\", \\\"{x:1656,y:187,t:1527009395346};\\\", \\\"{x:1640,y:193,t:1527009395362};\\\", \\\"{x:1633,y:193,t:1527009395379};\\\", \\\"{x:1629,y:193,t:1527009395396};\\\", \\\"{x:1628,y:195,t:1527009395452};\\\", \\\"{x:1626,y:196,t:1527009395462};\\\", \\\"{x:1623,y:201,t:1527009395480};\\\", \\\"{x:1621,y:209,t:1527009395496};\\\", \\\"{x:1615,y:222,t:1527009395512};\\\", \\\"{x:1610,y:239,t:1527009395529};\\\", \\\"{x:1603,y:263,t:1527009395546};\\\", \\\"{x:1596,y:294,t:1527009395563};\\\", \\\"{x:1580,y:344,t:1527009395580};\\\", \\\"{x:1563,y:413,t:1527009395596};\\\", \\\"{x:1556,y:438,t:1527009395613};\\\", \\\"{x:1553,y:449,t:1527009395630};\\\", \\\"{x:1553,y:450,t:1527009395647};\\\", \\\"{x:1553,y:448,t:1527009395734};\\\", \\\"{x:1553,y:447,t:1527009395747};\\\", \\\"{x:1555,y:442,t:1527009395763};\\\", \\\"{x:1559,y:436,t:1527009395780};\\\", \\\"{x:1573,y:422,t:1527009395797};\\\", \\\"{x:1608,y:403,t:1527009395813};\\\", \\\"{x:1713,y:358,t:1527009395829};\\\", \\\"{x:1828,y:311,t:1527009395847};\\\", \\\"{x:1919,y:261,t:1527009395864};\\\", \\\"{x:1919,y:208,t:1527009395880};\\\", \\\"{x:1919,y:141,t:1527009395897};\\\", \\\"{x:1919,y:73,t:1527009395913};\\\", \\\"{x:1919,y:16,t:1527009395931};\\\", \\\"{x:1917,y:16,t:1527009396029};\\\", \\\"{x:1910,y:16,t:1527009396037};\\\", \\\"{x:1897,y:16,t:1527009396046};\\\", \\\"{x:1847,y:16,t:1527009396064};\\\", \\\"{x:1750,y:16,t:1527009396080};\\\", \\\"{x:1611,y:16,t:1527009396097};\\\", \\\"{x:1441,y:16,t:1527009396114};\\\", \\\"{x:1234,y:16,t:1527009396130};\\\", \\\"{x:1006,y:16,t:1527009396147};\\\", \\\"{x:829,y:16,t:1527009396163};\\\", \\\"{x:663,y:40,t:1527009396180};\\\", \\\"{x:604,y:79,t:1527009396196};\\\", \\\"{x:589,y:110,t:1527009396214};\\\", \\\"{x:583,y:155,t:1527009396230};\\\", \\\"{x:584,y:228,t:1527009396246};\\\", \\\"{x:605,y:315,t:1527009396263};\\\", \\\"{x:647,y:430,t:1527009396281};\\\", \\\"{x:693,y:540,t:1527009396297};\\\", \\\"{x:741,y:620,t:1527009396314};\\\", \\\"{x:779,y:658,t:1527009396331};\\\", \\\"{x:803,y:672,t:1527009396346};\\\", \\\"{x:821,y:678,t:1527009396364};\\\", \\\"{x:828,y:680,t:1527009396380};\\\", \\\"{x:820,y:680,t:1527009396453};\\\", \\\"{x:807,y:680,t:1527009396464};\\\", \\\"{x:771,y:680,t:1527009396480};\\\", \\\"{x:723,y:680,t:1527009396496};\\\", \\\"{x:696,y:680,t:1527009396514};\\\", \\\"{x:673,y:680,t:1527009396530};\\\", \\\"{x:651,y:680,t:1527009396547};\\\", \\\"{x:644,y:679,t:1527009396564};\\\", \\\"{x:642,y:677,t:1527009396581};\\\", \\\"{x:642,y:674,t:1527009396597};\\\", \\\"{x:652,y:671,t:1527009396614};\\\", \\\"{x:664,y:670,t:1527009396631};\\\", \\\"{x:671,y:669,t:1527009396648};\\\", \\\"{x:675,y:668,t:1527009396664};\\\", \\\"{x:676,y:667,t:1527009396681};\\\", \\\"{x:677,y:665,t:1527009396697};\\\", \\\"{x:679,y:658,t:1527009396714};\\\", \\\"{x:682,y:641,t:1527009396731};\\\", \\\"{x:682,y:617,t:1527009396749};\\\", \\\"{x:659,y:576,t:1527009396765};\\\", \\\"{x:576,y:481,t:1527009396782};\\\", \\\"{x:511,y:429,t:1527009396798};\\\", \\\"{x:451,y:403,t:1527009396814};\\\", \\\"{x:413,y:396,t:1527009396831};\\\", \\\"{x:387,y:392,t:1527009396847};\\\", \\\"{x:369,y:389,t:1527009396864};\\\", \\\"{x:367,y:389,t:1527009396881};\\\", \\\"{x:366,y:389,t:1527009396898};\\\", \\\"{x:366,y:391,t:1527009397221};\\\", \\\"{x:366,y:401,t:1527009397231};\\\", \\\"{x:369,y:423,t:1527009397248};\\\", \\\"{x:369,y:443,t:1527009397265};\\\", \\\"{x:369,y:462,t:1527009397280};\\\", \\\"{x:369,y:475,t:1527009397298};\\\", \\\"{x:369,y:486,t:1527009397315};\\\", \\\"{x:367,y:493,t:1527009397332};\\\", \\\"{x:363,y:500,t:1527009397348};\\\", \\\"{x:349,y:513,t:1527009397364};\\\", \\\"{x:337,y:519,t:1527009397383};\\\", \\\"{x:324,y:525,t:1527009397399};\\\", \\\"{x:302,y:531,t:1527009397415};\\\", \\\"{x:285,y:534,t:1527009397432};\\\", \\\"{x:270,y:538,t:1527009397448};\\\", \\\"{x:255,y:542,t:1527009397465};\\\", \\\"{x:243,y:544,t:1527009397481};\\\", \\\"{x:234,y:545,t:1527009397497};\\\", \\\"{x:224,y:543,t:1527009397515};\\\", \\\"{x:221,y:541,t:1527009397531};\\\", \\\"{x:220,y:541,t:1527009397548};\\\", \\\"{x:219,y:540,t:1527009397565};\\\", \\\"{x:219,y:538,t:1527009397597};\\\", \\\"{x:219,y:537,t:1527009397604};\\\", \\\"{x:218,y:536,t:1527009397614};\\\", \\\"{x:215,y:534,t:1527009397632};\\\", \\\"{x:210,y:530,t:1527009397647};\\\", \\\"{x:206,y:528,t:1527009397665};\\\", \\\"{x:199,y:527,t:1527009397681};\\\", \\\"{x:192,y:527,t:1527009397697};\\\", \\\"{x:186,y:527,t:1527009397714};\\\", \\\"{x:183,y:527,t:1527009397731};\\\", \\\"{x:182,y:526,t:1527009397749};\\\", \\\"{x:183,y:521,t:1527009397782};\\\", \\\"{x:203,y:517,t:1527009397800};\\\", \\\"{x:241,y:510,t:1527009397815};\\\", \\\"{x:276,y:503,t:1527009397832};\\\", \\\"{x:314,y:496,t:1527009397848};\\\", \\\"{x:358,y:491,t:1527009397865};\\\", \\\"{x:379,y:490,t:1527009397882};\\\", \\\"{x:393,y:490,t:1527009397899};\\\", \\\"{x:397,y:490,t:1527009397915};\\\", \\\"{x:398,y:491,t:1527009397932};\\\", \\\"{x:392,y:491,t:1527009397949};\\\", \\\"{x:377,y:492,t:1527009397964};\\\", \\\"{x:355,y:495,t:1527009397982};\\\", \\\"{x:327,y:496,t:1527009397999};\\\", \\\"{x:298,y:496,t:1527009398014};\\\", \\\"{x:271,y:496,t:1527009398031};\\\", \\\"{x:257,y:496,t:1527009398049};\\\", \\\"{x:248,y:496,t:1527009398065};\\\", \\\"{x:244,y:496,t:1527009398081};\\\", \\\"{x:243,y:496,t:1527009398141};\\\", \\\"{x:243,y:497,t:1527009398157};\\\", \\\"{x:243,y:499,t:1527009398164};\\\", \\\"{x:243,y:503,t:1527009398181};\\\", \\\"{x:243,y:508,t:1527009398198};\\\", \\\"{x:238,y:515,t:1527009398216};\\\", \\\"{x:231,y:522,t:1527009398233};\\\", \\\"{x:221,y:531,t:1527009398249};\\\", \\\"{x:212,y:538,t:1527009398266};\\\", \\\"{x:203,y:545,t:1527009398282};\\\", \\\"{x:195,y:552,t:1527009398299};\\\", \\\"{x:191,y:557,t:1527009398316};\\\", \\\"{x:189,y:560,t:1527009398331};\\\", \\\"{x:189,y:562,t:1527009398349};\\\", \\\"{x:189,y:563,t:1527009398367};\\\", \\\"{x:189,y:564,t:1527009398383};\\\", \\\"{x:189,y:566,t:1527009398399};\\\", \\\"{x:189,y:569,t:1527009398416};\\\", \\\"{x:188,y:573,t:1527009398432};\\\", \\\"{x:186,y:577,t:1527009398449};\\\", \\\"{x:186,y:582,t:1527009398466};\\\", \\\"{x:185,y:585,t:1527009398482};\\\", \\\"{x:185,y:587,t:1527009398498};\\\", \\\"{x:185,y:588,t:1527009398515};\\\", \\\"{x:185,y:591,t:1527009398532};\\\", \\\"{x:184,y:591,t:1527009398549};\\\", \\\"{x:184,y:592,t:1527009398589};\\\", \\\"{x:183,y:592,t:1527009398604};\\\", \\\"{x:182,y:592,t:1527009398615};\\\", \\\"{x:180,y:591,t:1527009398632};\\\", \\\"{x:179,y:591,t:1527009398648};\\\", \\\"{x:179,y:590,t:1527009398665};\\\", \\\"{x:178,y:590,t:1527009398682};\\\", \\\"{x:177,y:588,t:1527009398699};\\\", \\\"{x:177,y:585,t:1527009398715};\\\", \\\"{x:177,y:584,t:1527009398733};\\\", \\\"{x:180,y:583,t:1527009398932};\\\", \\\"{x:197,y:583,t:1527009398949};\\\", \\\"{x:224,y:589,t:1527009398966};\\\", \\\"{x:260,y:594,t:1527009398983};\\\", \\\"{x:314,y:604,t:1527009399000};\\\", \\\"{x:362,y:611,t:1527009399016};\\\", \\\"{x:401,y:621,t:1527009399033};\\\", \\\"{x:447,y:621,t:1527009399049};\\\", \\\"{x:477,y:621,t:1527009399066};\\\", \\\"{x:501,y:620,t:1527009399083};\\\", \\\"{x:511,y:616,t:1527009399098};\\\", \\\"{x:510,y:612,t:1527009399115};\\\", \\\"{x:504,y:607,t:1527009399132};\\\", \\\"{x:495,y:602,t:1527009399150};\\\", \\\"{x:489,y:600,t:1527009399166};\\\", \\\"{x:478,y:599,t:1527009399183};\\\", \\\"{x:463,y:599,t:1527009399200};\\\", \\\"{x:441,y:599,t:1527009399215};\\\", \\\"{x:413,y:598,t:1527009399233};\\\", \\\"{x:381,y:598,t:1527009399250};\\\", \\\"{x:363,y:598,t:1527009399266};\\\", \\\"{x:349,y:597,t:1527009399283};\\\", \\\"{x:346,y:595,t:1527009399300};\\\", \\\"{x:345,y:594,t:1527009399316};\\\", \\\"{x:348,y:585,t:1527009399335};\\\", \\\"{x:358,y:575,t:1527009399350};\\\", \\\"{x:373,y:560,t:1527009399366};\\\", \\\"{x:388,y:546,t:1527009399383};\\\", \\\"{x:394,y:539,t:1527009399400};\\\", \\\"{x:397,y:536,t:1527009399416};\\\", \\\"{x:400,y:534,t:1527009399432};\\\", \\\"{x:404,y:535,t:1527009399773};\\\", \\\"{x:421,y:536,t:1527009399782};\\\", \\\"{x:480,y:540,t:1527009399800};\\\", \\\"{x:575,y:540,t:1527009399817};\\\", \\\"{x:697,y:540,t:1527009399832};\\\", \\\"{x:843,y:540,t:1527009399851};\\\", \\\"{x:995,y:540,t:1527009399867};\\\", \\\"{x:1140,y:546,t:1527009399884};\\\", \\\"{x:1268,y:565,t:1527009399900};\\\", \\\"{x:1400,y:586,t:1527009399916};\\\", \\\"{x:1442,y:597,t:1527009399934};\\\", \\\"{x:1462,y:607,t:1527009399950};\\\", \\\"{x:1466,y:613,t:1527009399966};\\\", \\\"{x:1466,y:625,t:1527009399984};\\\", \\\"{x:1466,y:643,t:1527009399999};\\\", \\\"{x:1456,y:666,t:1527009400017};\\\", \\\"{x:1443,y:689,t:1527009400034};\\\", \\\"{x:1426,y:713,t:1527009400050};\\\", \\\"{x:1410,y:739,t:1527009400067};\\\", \\\"{x:1402,y:762,t:1527009400084};\\\", \\\"{x:1394,y:786,t:1527009400099};\\\", \\\"{x:1392,y:818,t:1527009400117};\\\", \\\"{x:1394,y:831,t:1527009400134};\\\", \\\"{x:1395,y:833,t:1527009400150};\\\", \\\"{x:1395,y:834,t:1527009400167};\\\", \\\"{x:1396,y:834,t:1527009400183};\\\", \\\"{x:1397,y:832,t:1527009400199};\\\", \\\"{x:1401,y:820,t:1527009400216};\\\", \\\"{x:1408,y:804,t:1527009400234};\\\", \\\"{x:1421,y:778,t:1527009400250};\\\", \\\"{x:1441,y:741,t:1527009400266};\\\", \\\"{x:1474,y:683,t:1527009400284};\\\", \\\"{x:1509,y:623,t:1527009400300};\\\", \\\"{x:1556,y:539,t:1527009400317};\\\", \\\"{x:1583,y:493,t:1527009400334};\\\", \\\"{x:1592,y:473,t:1527009400350};\\\", \\\"{x:1595,y:463,t:1527009400366};\\\", \\\"{x:1595,y:462,t:1527009400383};\\\", \\\"{x:1596,y:460,t:1527009400400};\\\", \\\"{x:1597,y:460,t:1527009400428};\\\", \\\"{x:1597,y:462,t:1527009400493};\\\", \\\"{x:1597,y:468,t:1527009400500};\\\", \\\"{x:1593,y:488,t:1527009400516};\\\", \\\"{x:1583,y:516,t:1527009400534};\\\", \\\"{x:1568,y:542,t:1527009400550};\\\", \\\"{x:1554,y:566,t:1527009400567};\\\", \\\"{x:1542,y:583,t:1527009400584};\\\", \\\"{x:1534,y:594,t:1527009400600};\\\", \\\"{x:1532,y:597,t:1527009400617};\\\", \\\"{x:1531,y:600,t:1527009400634};\\\", \\\"{x:1530,y:601,t:1527009400693};\\\", \\\"{x:1529,y:597,t:1527009400717};\\\", \\\"{x:1527,y:582,t:1527009400733};\\\", \\\"{x:1527,y:561,t:1527009400751};\\\", \\\"{x:1527,y:538,t:1527009400768};\\\", \\\"{x:1527,y:514,t:1527009400783};\\\", \\\"{x:1528,y:489,t:1527009400801};\\\", \\\"{x:1532,y:472,t:1527009400817};\\\", \\\"{x:1536,y:463,t:1527009400834};\\\", \\\"{x:1538,y:457,t:1527009400851};\\\", \\\"{x:1541,y:453,t:1527009400868};\\\", \\\"{x:1542,y:451,t:1527009400884};\\\", \\\"{x:1545,y:443,t:1527009400901};\\\", \\\"{x:1548,y:435,t:1527009400918};\\\", \\\"{x:1550,y:429,t:1527009400934};\\\", \\\"{x:1550,y:427,t:1527009400951};\\\", \\\"{x:1551,y:425,t:1527009400968};\\\", \\\"{x:1554,y:428,t:1527009401029};\\\", \\\"{x:1557,y:436,t:1527009401037};\\\", \\\"{x:1559,y:447,t:1527009401051};\\\", \\\"{x:1560,y:474,t:1527009401068};\\\", \\\"{x:1557,y:509,t:1527009401084};\\\", \\\"{x:1542,y:555,t:1527009401101};\\\", \\\"{x:1530,y:576,t:1527009401118};\\\", \\\"{x:1516,y:591,t:1527009401133};\\\", \\\"{x:1506,y:600,t:1527009401150};\\\", \\\"{x:1495,y:606,t:1527009401168};\\\", \\\"{x:1489,y:609,t:1527009401184};\\\", \\\"{x:1483,y:613,t:1527009401201};\\\", \\\"{x:1481,y:616,t:1527009401217};\\\", \\\"{x:1477,y:618,t:1527009401235};\\\", \\\"{x:1476,y:620,t:1527009401251};\\\", \\\"{x:1475,y:620,t:1527009401268};\\\", \\\"{x:1474,y:620,t:1527009401284};\\\", \\\"{x:1473,y:620,t:1527009401333};\\\", \\\"{x:1472,y:620,t:1527009401357};\\\", \\\"{x:1471,y:620,t:1527009401368};\\\", \\\"{x:1467,y:621,t:1527009401385};\\\", \\\"{x:1462,y:623,t:1527009401401};\\\", \\\"{x:1450,y:629,t:1527009401419};\\\", \\\"{x:1438,y:635,t:1527009401435};\\\", \\\"{x:1432,y:639,t:1527009401451};\\\", \\\"{x:1431,y:639,t:1527009401469};\\\", \\\"{x:1430,y:639,t:1527009401501};\\\", \\\"{x:1430,y:640,t:1527009401629};\\\", \\\"{x:1430,y:641,t:1527009401669};\\\", \\\"{x:1430,y:642,t:1527009401829};\\\", \\\"{x:1430,y:644,t:1527009401836};\\\", \\\"{x:1433,y:653,t:1527009401852};\\\", \\\"{x:1437,y:677,t:1527009401867};\\\", \\\"{x:1438,y:722,t:1527009401884};\\\", \\\"{x:1438,y:756,t:1527009401902};\\\", \\\"{x:1438,y:788,t:1527009401918};\\\", \\\"{x:1434,y:819,t:1527009401935};\\\", \\\"{x:1428,y:846,t:1527009401952};\\\", \\\"{x:1423,y:861,t:1527009401968};\\\", \\\"{x:1419,y:871,t:1527009401985};\\\", \\\"{x:1415,y:879,t:1527009402002};\\\", \\\"{x:1415,y:880,t:1527009402018};\\\", \\\"{x:1413,y:881,t:1527009402035};\\\", \\\"{x:1412,y:882,t:1527009402174};\\\", \\\"{x:1410,y:882,t:1527009402185};\\\", \\\"{x:1408,y:882,t:1527009402202};\\\", \\\"{x:1405,y:882,t:1527009402219};\\\", \\\"{x:1400,y:883,t:1527009402235};\\\", \\\"{x:1399,y:884,t:1527009402252};\\\", \\\"{x:1397,y:885,t:1527009402269};\\\", \\\"{x:1396,y:885,t:1527009402334};\\\", \\\"{x:1394,y:885,t:1527009402341};\\\", \\\"{x:1390,y:884,t:1527009402352};\\\", \\\"{x:1365,y:872,t:1527009402369};\\\", \\\"{x:1327,y:856,t:1527009402385};\\\", \\\"{x:1257,y:837,t:1527009402402};\\\", \\\"{x:1163,y:825,t:1527009402419};\\\", \\\"{x:1046,y:819,t:1527009402435};\\\", \\\"{x:921,y:819,t:1527009402452};\\\", \\\"{x:773,y:815,t:1527009402469};\\\", \\\"{x:682,y:815,t:1527009402485};\\\", \\\"{x:604,y:815,t:1527009402501};\\\", \\\"{x:549,y:801,t:1527009402518};\\\", \\\"{x:501,y:787,t:1527009402536};\\\", \\\"{x:475,y:775,t:1527009402552};\\\", \\\"{x:453,y:766,t:1527009402569};\\\", \\\"{x:437,y:760,t:1527009402586};\\\", \\\"{x:424,y:757,t:1527009402602};\\\", \\\"{x:412,y:757,t:1527009402619};\\\", \\\"{x:398,y:757,t:1527009402636};\\\", \\\"{x:391,y:757,t:1527009402652};\\\", \\\"{x:387,y:758,t:1527009402669};\\\", \\\"{x:387,y:756,t:1527009402709};\\\", \\\"{x:388,y:754,t:1527009402720};\\\", \\\"{x:395,y:745,t:1527009402736};\\\", \\\"{x:402,y:738,t:1527009402752};\\\", \\\"{x:411,y:732,t:1527009402769};\\\", \\\"{x:420,y:730,t:1527009402786};\\\", \\\"{x:423,y:730,t:1527009402802};\\\", \\\"{x:425,y:730,t:1527009402819};\\\", \\\"{x:428,y:732,t:1527009402836};\\\", \\\"{x:431,y:736,t:1527009402852};\\\", \\\"{x:436,y:740,t:1527009402869};\\\", \\\"{x:439,y:742,t:1527009402886};\\\", \\\"{x:441,y:743,t:1527009402902};\\\", \\\"{x:444,y:743,t:1527009402921};\\\", \\\"{x:448,y:743,t:1527009402936};\\\", \\\"{x:451,y:743,t:1527009402952};\\\", \\\"{x:454,y:742,t:1527009402969};\\\", \\\"{x:456,y:741,t:1527009402986};\\\", \\\"{x:457,y:740,t:1527009403100};\\\", \\\"{x:459,y:740,t:1527009403121};\\\", \\\"{x:460,y:740,t:1527009403136};\\\", \\\"{x:462,y:740,t:1527009403152};\\\", \\\"{x:464,y:740,t:1527009403169};\\\", \\\"{x:466,y:740,t:1527009403186};\\\", \\\"{x:467,y:740,t:1527009403202};\\\", \\\"{x:469,y:742,t:1527009403219};\\\", \\\"{x:471,y:743,t:1527009403236};\\\", \\\"{x:477,y:744,t:1527009403252};\\\", \\\"{x:487,y:745,t:1527009403269};\\\", \\\"{x:502,y:745,t:1527009403286};\\\", \\\"{x:528,y:745,t:1527009403303};\\\", \\\"{x:560,y:744,t:1527009403319};\\\", \\\"{x:613,y:737,t:1527009403336};\\\", \\\"{x:691,y:728,t:1527009403353};\\\", \\\"{x:797,y:710,t:1527009403370};\\\", \\\"{x:920,y:703,t:1527009403386};\\\", \\\"{x:1047,y:701,t:1527009403403};\\\", \\\"{x:1169,y:699,t:1527009403419};\\\", \\\"{x:1286,y:699,t:1527009403436};\\\", \\\"{x:1414,y:699,t:1527009403452};\\\", \\\"{x:1469,y:699,t:1527009403470};\\\", \\\"{x:1497,y:698,t:1527009403486};\\\", \\\"{x:1505,y:696,t:1527009403503};\\\", \\\"{x:1506,y:695,t:1527009403520};\\\", \\\"{x:1507,y:694,t:1527009403548};\\\", \\\"{x:1507,y:693,t:1527009403725};\\\", \\\"{x:1507,y:692,t:1527009403804};\\\" ] }, { \\\"rt\\\": 35049, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 585562, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -J -J -B -B -B -I -I -I -I -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1507,y:691,t:1527009404899};\\\", \\\"{x:1507,y:690,t:1527009404997};\\\", \\\"{x:1507,y:689,t:1527009407661};\\\", \\\"{x:1506,y:688,t:1527009407684};\\\", \\\"{x:1504,y:688,t:1527009407701};\\\", \\\"{x:1504,y:687,t:1527009407708};\\\", \\\"{x:1503,y:687,t:1527009407723};\\\", \\\"{x:1503,y:686,t:1527009407740};\\\", \\\"{x:1502,y:681,t:1527009407989};\\\", \\\"{x:1500,y:654,t:1527009407996};\\\", \\\"{x:1491,y:607,t:1527009408006};\\\", \\\"{x:1463,y:510,t:1527009408023};\\\", \\\"{x:1451,y:419,t:1527009408040};\\\", \\\"{x:1451,y:369,t:1527009408056};\\\", \\\"{x:1451,y:340,t:1527009408073};\\\", \\\"{x:1449,y:318,t:1527009408090};\\\", \\\"{x:1447,y:305,t:1527009408106};\\\", \\\"{x:1446,y:302,t:1527009408123};\\\", \\\"{x:1445,y:304,t:1527009408165};\\\", \\\"{x:1444,y:310,t:1527009408173};\\\", \\\"{x:1440,y:323,t:1527009408190};\\\", \\\"{x:1435,y:341,t:1527009408207};\\\", \\\"{x:1433,y:352,t:1527009408224};\\\", \\\"{x:1432,y:356,t:1527009408240};\\\", \\\"{x:1430,y:359,t:1527009408258};\\\", \\\"{x:1429,y:359,t:1527009408273};\\\", \\\"{x:1431,y:367,t:1527009408290};\\\", \\\"{x:1430,y:372,t:1527009408307};\\\", \\\"{x:1430,y:374,t:1527009408325};\\\", \\\"{x:1426,y:377,t:1527009408382};\\\", \\\"{x:1423,y:379,t:1527009408391};\\\", \\\"{x:1416,y:386,t:1527009408408};\\\", \\\"{x:1409,y:394,t:1527009408423};\\\", \\\"{x:1401,y:401,t:1527009408440};\\\", \\\"{x:1388,y:409,t:1527009408457};\\\", \\\"{x:1372,y:417,t:1527009408473};\\\", \\\"{x:1356,y:426,t:1527009408490};\\\", \\\"{x:1341,y:429,t:1527009408507};\\\", \\\"{x:1322,y:433,t:1527009408523};\\\", \\\"{x:1305,y:436,t:1527009408540};\\\", \\\"{x:1299,y:438,t:1527009408557};\\\", \\\"{x:1298,y:438,t:1527009408573};\\\", \\\"{x:1297,y:439,t:1527009408591};\\\", \\\"{x:1297,y:440,t:1527009408628};\\\", \\\"{x:1297,y:444,t:1527009408640};\\\", \\\"{x:1297,y:463,t:1527009408657};\\\", \\\"{x:1297,y:494,t:1527009408675};\\\", \\\"{x:1304,y:527,t:1527009408691};\\\", \\\"{x:1312,y:556,t:1527009408707};\\\", \\\"{x:1322,y:576,t:1527009408724};\\\", \\\"{x:1334,y:594,t:1527009408741};\\\", \\\"{x:1367,y:621,t:1527009408757};\\\", \\\"{x:1416,y:650,t:1527009408774};\\\", \\\"{x:1473,y:679,t:1527009408790};\\\", \\\"{x:1530,y:703,t:1527009408807};\\\", \\\"{x:1576,y:727,t:1527009408825};\\\", \\\"{x:1601,y:744,t:1527009408841};\\\", \\\"{x:1610,y:757,t:1527009408857};\\\", \\\"{x:1611,y:763,t:1527009408875};\\\", \\\"{x:1611,y:771,t:1527009408891};\\\", \\\"{x:1602,y:783,t:1527009408907};\\\", \\\"{x:1578,y:799,t:1527009408925};\\\", \\\"{x:1562,y:807,t:1527009408941};\\\", \\\"{x:1552,y:810,t:1527009408957};\\\", \\\"{x:1546,y:813,t:1527009408974};\\\", \\\"{x:1545,y:813,t:1527009408997};\\\", \\\"{x:1545,y:810,t:1527009409037};\\\", \\\"{x:1546,y:809,t:1527009409045};\\\", \\\"{x:1547,y:806,t:1527009409058};\\\", \\\"{x:1552,y:798,t:1527009409075};\\\", \\\"{x:1554,y:794,t:1527009409092};\\\", \\\"{x:1555,y:792,t:1527009409108};\\\", \\\"{x:1556,y:791,t:1527009409125};\\\", \\\"{x:1556,y:789,t:1527009409182};\\\", \\\"{x:1557,y:789,t:1527009409197};\\\", \\\"{x:1558,y:788,t:1527009409207};\\\", \\\"{x:1559,y:786,t:1527009409224};\\\", \\\"{x:1560,y:786,t:1527009409245};\\\", \\\"{x:1561,y:786,t:1527009409261};\\\", \\\"{x:1562,y:786,t:1527009409274};\\\", \\\"{x:1565,y:786,t:1527009409292};\\\", \\\"{x:1576,y:792,t:1527009409308};\\\", \\\"{x:1598,y:798,t:1527009409325};\\\", \\\"{x:1631,y:803,t:1527009409342};\\\", \\\"{x:1648,y:805,t:1527009409359};\\\", \\\"{x:1661,y:809,t:1527009409374};\\\", \\\"{x:1664,y:809,t:1527009409391};\\\", \\\"{x:1663,y:809,t:1527009409524};\\\", \\\"{x:1659,y:807,t:1527009409541};\\\", \\\"{x:1655,y:803,t:1527009409558};\\\", \\\"{x:1651,y:795,t:1527009409574};\\\", \\\"{x:1644,y:781,t:1527009409591};\\\", \\\"{x:1636,y:765,t:1527009409608};\\\", \\\"{x:1629,y:748,t:1527009409624};\\\", \\\"{x:1625,y:732,t:1527009409641};\\\", \\\"{x:1622,y:721,t:1527009409658};\\\", \\\"{x:1621,y:708,t:1527009409674};\\\", \\\"{x:1621,y:702,t:1527009409691};\\\", \\\"{x:1621,y:698,t:1527009409708};\\\", \\\"{x:1621,y:697,t:1527009409724};\\\", \\\"{x:1621,y:695,t:1527009409748};\\\", \\\"{x:1621,y:694,t:1527009409781};\\\", \\\"{x:1621,y:693,t:1527009409797};\\\", \\\"{x:1621,y:692,t:1527009409813};\\\", \\\"{x:1621,y:691,t:1527009409825};\\\", \\\"{x:1621,y:690,t:1527009409853};\\\", \\\"{x:1621,y:689,t:1527009409894};\\\", \\\"{x:1621,y:688,t:1527009409908};\\\", \\\"{x:1621,y:687,t:1527009409925};\\\", \\\"{x:1613,y:683,t:1527009409941};\\\", \\\"{x:1599,y:683,t:1527009409959};\\\", \\\"{x:1582,y:683,t:1527009409975};\\\", \\\"{x:1559,y:692,t:1527009409991};\\\", \\\"{x:1533,y:705,t:1527009410008};\\\", \\\"{x:1497,y:728,t:1527009410026};\\\", \\\"{x:1460,y:753,t:1527009410042};\\\", \\\"{x:1427,y:774,t:1527009410059};\\\", \\\"{x:1400,y:789,t:1527009410076};\\\", \\\"{x:1376,y:801,t:1527009410091};\\\", \\\"{x:1359,y:815,t:1527009410109};\\\", \\\"{x:1338,y:827,t:1527009410126};\\\", \\\"{x:1329,y:830,t:1527009410142};\\\", \\\"{x:1323,y:831,t:1527009410158};\\\", \\\"{x:1322,y:831,t:1527009410176};\\\", \\\"{x:1321,y:831,t:1527009410205};\\\", \\\"{x:1321,y:829,t:1527009410214};\\\", \\\"{x:1318,y:825,t:1527009410226};\\\", \\\"{x:1313,y:814,t:1527009410242};\\\", \\\"{x:1306,y:805,t:1527009410259};\\\", \\\"{x:1299,y:799,t:1527009410275};\\\", \\\"{x:1288,y:797,t:1527009410292};\\\", \\\"{x:1275,y:797,t:1527009410309};\\\", \\\"{x:1256,y:798,t:1527009410325};\\\", \\\"{x:1239,y:804,t:1527009410342};\\\", \\\"{x:1224,y:810,t:1527009410361};\\\", \\\"{x:1211,y:816,t:1527009410376};\\\", \\\"{x:1201,y:821,t:1527009410393};\\\", \\\"{x:1195,y:824,t:1527009410408};\\\", \\\"{x:1194,y:824,t:1527009410516};\\\", \\\"{x:1194,y:825,t:1527009410565};\\\", \\\"{x:1195,y:826,t:1527009410589};\\\", \\\"{x:1196,y:827,t:1527009410597};\\\", \\\"{x:1198,y:829,t:1527009410608};\\\", \\\"{x:1202,y:831,t:1527009410626};\\\", \\\"{x:1203,y:832,t:1527009410643};\\\", \\\"{x:1204,y:833,t:1527009410659};\\\", \\\"{x:1205,y:833,t:1527009410675};\\\", \\\"{x:1206,y:834,t:1527009410692};\\\", \\\"{x:1207,y:834,t:1527009410828};\\\", \\\"{x:1207,y:836,t:1527009410957};\\\", \\\"{x:1207,y:837,t:1527009411870};\\\", \\\"{x:1208,y:837,t:1527009412358};\\\", \\\"{x:1210,y:837,t:1527009412381};\\\", \\\"{x:1210,y:836,t:1527009412405};\\\", \\\"{x:1212,y:835,t:1527009412456};\\\", \\\"{x:1212,y:834,t:1527009412533};\\\", \\\"{x:1212,y:833,t:1527009412573};\\\", \\\"{x:1213,y:832,t:1527009412605};\\\", \\\"{x:1213,y:831,t:1527009414052};\\\", \\\"{x:1213,y:829,t:1527009414084};\\\", \\\"{x:1222,y:826,t:1527009414095};\\\", \\\"{x:1249,y:820,t:1527009414111};\\\", \\\"{x:1283,y:811,t:1527009414128};\\\", \\\"{x:1321,y:797,t:1527009414144};\\\", \\\"{x:1368,y:783,t:1527009414162};\\\", \\\"{x:1400,y:773,t:1527009414178};\\\", \\\"{x:1418,y:768,t:1527009414195};\\\", \\\"{x:1425,y:766,t:1527009414211};\\\", \\\"{x:1426,y:765,t:1527009414228};\\\", \\\"{x:1425,y:765,t:1527009414293};\\\", \\\"{x:1422,y:765,t:1527009414300};\\\", \\\"{x:1419,y:765,t:1527009414311};\\\", \\\"{x:1411,y:765,t:1527009414328};\\\", \\\"{x:1398,y:765,t:1527009414345};\\\", \\\"{x:1380,y:765,t:1527009414361};\\\", \\\"{x:1367,y:765,t:1527009414379};\\\", \\\"{x:1356,y:763,t:1527009414395};\\\", \\\"{x:1352,y:761,t:1527009414411};\\\", \\\"{x:1350,y:761,t:1527009414428};\\\", \\\"{x:1349,y:761,t:1527009414549};\\\", \\\"{x:1349,y:760,t:1527009414561};\\\", \\\"{x:1349,y:759,t:1527009414580};\\\", \\\"{x:1348,y:759,t:1527009425213};\\\", \\\"{x:1346,y:758,t:1527009425229};\\\", \\\"{x:1344,y:757,t:1527009425254};\\\", \\\"{x:1345,y:757,t:1527009425893};\\\", \\\"{x:1346,y:757,t:1527009425924};\\\", \\\"{x:1347,y:757,t:1527009426276};\\\", \\\"{x:1348,y:757,t:1527009426287};\\\", \\\"{x:1349,y:757,t:1527009426364};\\\", \\\"{x:1349,y:758,t:1527009426372};\\\", \\\"{x:1354,y:760,t:1527009426388};\\\", \\\"{x:1362,y:764,t:1527009426405};\\\", \\\"{x:1374,y:769,t:1527009426420};\\\", \\\"{x:1376,y:770,t:1527009426438};\\\", \\\"{x:1377,y:770,t:1527009426455};\\\", \\\"{x:1378,y:771,t:1527009426476};\\\", \\\"{x:1378,y:772,t:1527009426488};\\\", \\\"{x:1378,y:773,t:1527009426556};\\\", \\\"{x:1374,y:773,t:1527009426571};\\\", \\\"{x:1363,y:773,t:1527009426588};\\\", \\\"{x:1334,y:770,t:1527009426605};\\\", \\\"{x:1311,y:768,t:1527009426621};\\\", \\\"{x:1288,y:765,t:1527009426638};\\\", \\\"{x:1258,y:765,t:1527009426655};\\\", \\\"{x:1228,y:765,t:1527009426672};\\\", \\\"{x:1202,y:765,t:1527009426688};\\\", \\\"{x:1182,y:765,t:1527009426705};\\\", \\\"{x:1173,y:765,t:1527009426722};\\\", \\\"{x:1171,y:764,t:1527009426738};\\\", \\\"{x:1169,y:764,t:1527009426836};\\\", \\\"{x:1167,y:764,t:1527009426845};\\\", \\\"{x:1165,y:764,t:1527009426854};\\\", \\\"{x:1163,y:764,t:1527009426871};\\\", \\\"{x:1162,y:764,t:1527009426888};\\\", \\\"{x:1163,y:764,t:1527009427133};\\\", \\\"{x:1165,y:764,t:1527009427140};\\\", \\\"{x:1167,y:764,t:1527009427155};\\\", \\\"{x:1172,y:764,t:1527009427173};\\\", \\\"{x:1173,y:764,t:1527009427189};\\\", \\\"{x:1175,y:763,t:1527009427205};\\\", \\\"{x:1176,y:762,t:1527009427261};\\\", \\\"{x:1177,y:762,t:1527009428292};\\\", \\\"{x:1178,y:762,t:1527009428316};\\\", \\\"{x:1168,y:761,t:1527009432757};\\\", \\\"{x:1137,y:760,t:1527009432764};\\\", \\\"{x:1082,y:760,t:1527009432777};\\\", \\\"{x:946,y:758,t:1527009432793};\\\", \\\"{x:768,y:753,t:1527009432810};\\\", \\\"{x:573,y:737,t:1527009432826};\\\", \\\"{x:378,y:691,t:1527009432843};\\\", \\\"{x:123,y:610,t:1527009432860};\\\", \\\"{x:7,y:557,t:1527009432876};\\\", \\\"{x:0,y:519,t:1527009432893};\\\", \\\"{x:0,y:511,t:1527009432910};\\\", \\\"{x:0,y:509,t:1527009432932};\\\", \\\"{x:7,y:506,t:1527009432944};\\\", \\\"{x:36,y:502,t:1527009432961};\\\", \\\"{x:92,y:494,t:1527009432978};\\\", \\\"{x:177,y:486,t:1527009432994};\\\", \\\"{x:252,y:475,t:1527009433011};\\\", \\\"{x:369,y:466,t:1527009433028};\\\", \\\"{x:452,y:466,t:1527009433043};\\\", \\\"{x:533,y:466,t:1527009433061};\\\", \\\"{x:580,y:466,t:1527009433078};\\\", \\\"{x:610,y:470,t:1527009433094};\\\", \\\"{x:623,y:476,t:1527009433111};\\\", \\\"{x:628,y:482,t:1527009433128};\\\", \\\"{x:628,y:486,t:1527009433145};\\\", \\\"{x:628,y:493,t:1527009433162};\\\", \\\"{x:621,y:499,t:1527009433178};\\\", \\\"{x:613,y:504,t:1527009433195};\\\", \\\"{x:601,y:509,t:1527009433211};\\\", \\\"{x:574,y:521,t:1527009433229};\\\", \\\"{x:553,y:527,t:1527009433244};\\\", \\\"{x:533,y:533,t:1527009433261};\\\", \\\"{x:507,y:537,t:1527009433277};\\\", \\\"{x:481,y:543,t:1527009433295};\\\", \\\"{x:456,y:544,t:1527009433311};\\\", \\\"{x:437,y:544,t:1527009433328};\\\", \\\"{x:422,y:544,t:1527009433344};\\\", \\\"{x:411,y:544,t:1527009433362};\\\", \\\"{x:398,y:544,t:1527009433378};\\\", \\\"{x:390,y:544,t:1527009433395};\\\", \\\"{x:381,y:547,t:1527009433411};\\\", \\\"{x:357,y:550,t:1527009433429};\\\", \\\"{x:338,y:552,t:1527009433444};\\\", \\\"{x:314,y:552,t:1527009433462};\\\", \\\"{x:289,y:553,t:1527009433478};\\\", \\\"{x:266,y:553,t:1527009433496};\\\", \\\"{x:246,y:553,t:1527009433511};\\\", \\\"{x:234,y:553,t:1527009433528};\\\", \\\"{x:225,y:553,t:1527009433544};\\\", \\\"{x:221,y:553,t:1527009433561};\\\", \\\"{x:220,y:553,t:1527009433578};\\\", \\\"{x:219,y:553,t:1527009433605};\\\", \\\"{x:218,y:553,t:1527009433612};\\\", \\\"{x:216,y:552,t:1527009433629};\\\", \\\"{x:214,y:551,t:1527009433645};\\\", \\\"{x:209,y:546,t:1527009433662};\\\", \\\"{x:201,y:537,t:1527009433678};\\\", \\\"{x:193,y:529,t:1527009433696};\\\", \\\"{x:189,y:524,t:1527009433713};\\\", \\\"{x:189,y:522,t:1527009433728};\\\", \\\"{x:188,y:519,t:1527009433744};\\\", \\\"{x:187,y:517,t:1527009433762};\\\", \\\"{x:187,y:516,t:1527009433778};\\\", \\\"{x:187,y:514,t:1527009433794};\\\", \\\"{x:187,y:513,t:1527009433811};\\\", \\\"{x:187,y:510,t:1527009433828};\\\", \\\"{x:187,y:509,t:1527009433860};\\\", \\\"{x:187,y:508,t:1527009433876};\\\", \\\"{x:186,y:506,t:1527009433892};\\\", \\\"{x:186,y:505,t:1527009433916};\\\", \\\"{x:186,y:504,t:1527009433929};\\\", \\\"{x:186,y:503,t:1527009433945};\\\", \\\"{x:189,y:503,t:1527009434213};\\\", \\\"{x:198,y:508,t:1527009434228};\\\", \\\"{x:236,y:523,t:1527009434245};\\\", \\\"{x:321,y:546,t:1527009434262};\\\", \\\"{x:437,y:572,t:1527009434278};\\\", \\\"{x:575,y:587,t:1527009434295};\\\", \\\"{x:724,y:609,t:1527009434313};\\\", \\\"{x:880,y:635,t:1527009434329};\\\", \\\"{x:1019,y:659,t:1527009434345};\\\", \\\"{x:1131,y:681,t:1527009434363};\\\", \\\"{x:1205,y:701,t:1527009434379};\\\", \\\"{x:1235,y:715,t:1527009434395};\\\", \\\"{x:1240,y:718,t:1527009434412};\\\", \\\"{x:1240,y:720,t:1527009434429};\\\", \\\"{x:1235,y:726,t:1527009434445};\\\", \\\"{x:1220,y:733,t:1527009434462};\\\", \\\"{x:1206,y:736,t:1527009434479};\\\", \\\"{x:1188,y:745,t:1527009434495};\\\", \\\"{x:1177,y:747,t:1527009434513};\\\", \\\"{x:1164,y:747,t:1527009434529};\\\", \\\"{x:1158,y:747,t:1527009434545};\\\", \\\"{x:1157,y:748,t:1527009434612};\\\", \\\"{x:1158,y:750,t:1527009434636};\\\", \\\"{x:1163,y:753,t:1527009434652};\\\", \\\"{x:1166,y:754,t:1527009434662};\\\", \\\"{x:1175,y:758,t:1527009434679};\\\", \\\"{x:1181,y:761,t:1527009434697};\\\", \\\"{x:1185,y:763,t:1527009434712};\\\", \\\"{x:1185,y:764,t:1527009434729};\\\", \\\"{x:1186,y:762,t:1527009434796};\\\", \\\"{x:1186,y:743,t:1527009434814};\\\", \\\"{x:1188,y:723,t:1527009434829};\\\", \\\"{x:1198,y:694,t:1527009434847};\\\", \\\"{x:1206,y:670,t:1527009434863};\\\", \\\"{x:1217,y:653,t:1527009434879};\\\", \\\"{x:1223,y:639,t:1527009434897};\\\", \\\"{x:1227,y:633,t:1527009434913};\\\", \\\"{x:1230,y:626,t:1527009434929};\\\", \\\"{x:1233,y:621,t:1527009434946};\\\", \\\"{x:1236,y:614,t:1527009434963};\\\", \\\"{x:1244,y:604,t:1527009434981};\\\", \\\"{x:1248,y:599,t:1527009434996};\\\", \\\"{x:1252,y:594,t:1527009435013};\\\", \\\"{x:1255,y:591,t:1527009435030};\\\", \\\"{x:1257,y:588,t:1527009435046};\\\", \\\"{x:1258,y:588,t:1527009435068};\\\", \\\"{x:1259,y:586,t:1527009435080};\\\", \\\"{x:1259,y:585,t:1527009435097};\\\", \\\"{x:1262,y:580,t:1527009435114};\\\", \\\"{x:1265,y:577,t:1527009435131};\\\", \\\"{x:1267,y:571,t:1527009435148};\\\", \\\"{x:1269,y:568,t:1527009435163};\\\", \\\"{x:1270,y:567,t:1527009435181};\\\", \\\"{x:1271,y:566,t:1527009435429};\\\", \\\"{x:1272,y:564,t:1527009435436};\\\", \\\"{x:1274,y:564,t:1527009435447};\\\", \\\"{x:1276,y:564,t:1527009435464};\\\", \\\"{x:1278,y:562,t:1527009435481};\\\", \\\"{x:1279,y:562,t:1527009435508};\\\", \\\"{x:1266,y:565,t:1527009438781};\\\", \\\"{x:1230,y:576,t:1527009438788};\\\", \\\"{x:1122,y:602,t:1527009438804};\\\", \\\"{x:980,y:628,t:1527009438821};\\\", \\\"{x:858,y:647,t:1527009438838};\\\", \\\"{x:745,y:661,t:1527009438854};\\\", \\\"{x:650,y:676,t:1527009438872};\\\", \\\"{x:602,y:684,t:1527009438888};\\\", \\\"{x:584,y:688,t:1527009438905};\\\", \\\"{x:581,y:689,t:1527009438922};\\\", \\\"{x:581,y:690,t:1527009438938};\\\", \\\"{x:585,y:692,t:1527009438954};\\\", \\\"{x:588,y:696,t:1527009438971};\\\", \\\"{x:591,y:713,t:1527009438988};\\\", \\\"{x:592,y:727,t:1527009439004};\\\", \\\"{x:595,y:736,t:1527009439021};\\\", \\\"{x:596,y:738,t:1527009439039};\\\", \\\"{x:596,y:739,t:1527009439055};\\\", \\\"{x:597,y:740,t:1527009439071};\\\", \\\"{x:598,y:740,t:1527009439088};\\\", \\\"{x:598,y:741,t:1527009439105};\\\", \\\"{x:598,y:743,t:1527009439121};\\\", \\\"{x:598,y:744,t:1527009439138};\\\", \\\"{x:598,y:746,t:1527009439156};\\\", \\\"{x:586,y:749,t:1527009439171};\\\", \\\"{x:547,y:751,t:1527009439189};\\\", \\\"{x:517,y:751,t:1527009439205};\\\", \\\"{x:493,y:749,t:1527009439222};\\\", \\\"{x:486,y:745,t:1527009439233};\\\", \\\"{x:483,y:745,t:1527009439249};\\\", \\\"{x:482,y:745,t:1527009439266};\\\", \\\"{x:482,y:743,t:1527009439556};\\\", \\\"{x:484,y:739,t:1527009439566};\\\", \\\"{x:492,y:729,t:1527009439582};\\\", \\\"{x:504,y:715,t:1527009439599};\\\", \\\"{x:528,y:694,t:1527009439616};\\\", \\\"{x:559,y:671,t:1527009439633};\\\", \\\"{x:623,y:627,t:1527009439649};\\\", \\\"{x:722,y:568,t:1527009439666};\\\", \\\"{x:858,y:477,t:1527009439682};\\\", \\\"{x:1045,y:362,t:1527009439699};\\\", \\\"{x:1424,y:136,t:1527009439716};\\\", \\\"{x:1745,y:16,t:1527009439732};\\\", \\\"{x:1919,y:16,t:1527009439750};\\\", \\\"{x:1910,y:16,t:1527009439908};\\\", \\\"{x:1883,y:16,t:1527009439916};\\\", \\\"{x:1759,y:16,t:1527009439933};\\\", \\\"{x:1570,y:16,t:1527009439949};\\\", \\\"{x:1330,y:16,t:1527009439967};\\\", \\\"{x:1015,y:16,t:1527009439983};\\\", \\\"{x:674,y:16,t:1527009439999};\\\", \\\"{x:354,y:16,t:1527009440016};\\\", \\\"{x:65,y:44,t:1527009440034};\\\", \\\"{x:0,y:76,t:1527009440049};\\\", \\\"{x:0,y:107,t:1527009440066};\\\", \\\"{x:0,y:139,t:1527009440084};\\\", \\\"{x:0,y:166,t:1527009440100};\\\", \\\"{x:0,y:198,t:1527009440116};\\\", \\\"{x:6,y:221,t:1527009440134};\\\", \\\"{x:23,y:252,t:1527009440150};\\\", \\\"{x:48,y:291,t:1527009440166};\\\", \\\"{x:69,y:328,t:1527009440183};\\\", \\\"{x:92,y:367,t:1527009440200};\\\", \\\"{x:119,y:411,t:1527009440217};\\\", \\\"{x:143,y:445,t:1527009440233};\\\", \\\"{x:162,y:466,t:1527009440250};\\\", \\\"{x:180,y:478,t:1527009440267};\\\", \\\"{x:192,y:480,t:1527009440283};\\\", \\\"{x:208,y:480,t:1527009440301};\\\", \\\"{x:229,y:476,t:1527009440317};\\\", \\\"{x:256,y:465,t:1527009440334};\\\", \\\"{x:276,y:453,t:1527009440351};\\\", \\\"{x:281,y:448,t:1527009440366};\\\" ] }, { \\\"rt\\\": 33723, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 620522, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -F -F -F -G -F -F -10 AM-F -F -03 PM-Z -Z -Z -F -4-Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:282,y:447,t:1527009440884};\\\", \\\"{x:297,y:453,t:1527009440900};\\\", \\\"{x:316,y:462,t:1527009440917};\\\", \\\"{x:332,y:469,t:1527009440935};\\\", \\\"{x:353,y:475,t:1527009440951};\\\", \\\"{x:370,y:480,t:1527009440967};\\\", \\\"{x:379,y:483,t:1527009440983};\\\", \\\"{x:386,y:486,t:1527009441049};\\\", \\\"{x:385,y:486,t:1527009441188};\\\", \\\"{x:384,y:486,t:1527009441420};\\\", \\\"{x:388,y:486,t:1527009441434};\\\", \\\"{x:432,y:486,t:1527009441451};\\\", \\\"{x:551,y:486,t:1527009441467};\\\", \\\"{x:794,y:486,t:1527009441484};\\\", \\\"{x:985,y:486,t:1527009441502};\\\", \\\"{x:1203,y:486,t:1527009441517};\\\", \\\"{x:1424,y:483,t:1527009441535};\\\", \\\"{x:1637,y:485,t:1527009441551};\\\", \\\"{x:1791,y:504,t:1527009441567};\\\", \\\"{x:1878,y:519,t:1527009441584};\\\", \\\"{x:1899,y:523,t:1527009441601};\\\", \\\"{x:1901,y:525,t:1527009441617};\\\", \\\"{x:1898,y:526,t:1527009441652};\\\", \\\"{x:1895,y:526,t:1527009441668};\\\", \\\"{x:1881,y:526,t:1527009441684};\\\", \\\"{x:1868,y:526,t:1527009441702};\\\", \\\"{x:1858,y:528,t:1527009441718};\\\", \\\"{x:1848,y:533,t:1527009441735};\\\", \\\"{x:1838,y:540,t:1527009441751};\\\", \\\"{x:1825,y:554,t:1527009441768};\\\", \\\"{x:1814,y:572,t:1527009441784};\\\", \\\"{x:1804,y:600,t:1527009441802};\\\", \\\"{x:1802,y:623,t:1527009441818};\\\", \\\"{x:1802,y:640,t:1527009441834};\\\", \\\"{x:1802,y:648,t:1527009441852};\\\", \\\"{x:1808,y:661,t:1527009441868};\\\", \\\"{x:1810,y:666,t:1527009441885};\\\", \\\"{x:1812,y:672,t:1527009441901};\\\", \\\"{x:1814,y:679,t:1527009441919};\\\", \\\"{x:1814,y:681,t:1527009441934};\\\", \\\"{x:1814,y:685,t:1527009441952};\\\", \\\"{x:1814,y:687,t:1527009441968};\\\", \\\"{x:1814,y:691,t:1527009441985};\\\", \\\"{x:1810,y:694,t:1527009442002};\\\", \\\"{x:1800,y:697,t:1527009442018};\\\", \\\"{x:1778,y:699,t:1527009442034};\\\", \\\"{x:1756,y:699,t:1527009442052};\\\", \\\"{x:1717,y:691,t:1527009442068};\\\", \\\"{x:1675,y:661,t:1527009442085};\\\", \\\"{x:1639,y:624,t:1527009442102};\\\", \\\"{x:1614,y:591,t:1527009442118};\\\", \\\"{x:1604,y:573,t:1527009442135};\\\", \\\"{x:1604,y:562,t:1527009442152};\\\", \\\"{x:1604,y:559,t:1527009442169};\\\", \\\"{x:1606,y:555,t:1527009442185};\\\", \\\"{x:1611,y:553,t:1527009442201};\\\", \\\"{x:1614,y:553,t:1527009442219};\\\", \\\"{x:1616,y:553,t:1527009442234};\\\", \\\"{x:1618,y:553,t:1527009442252};\\\", \\\"{x:1619,y:553,t:1527009442269};\\\", \\\"{x:1619,y:556,t:1527009442286};\\\", \\\"{x:1619,y:563,t:1527009442302};\\\", \\\"{x:1619,y:577,t:1527009442319};\\\", \\\"{x:1617,y:594,t:1527009442336};\\\", \\\"{x:1611,y:611,t:1527009442351};\\\", \\\"{x:1608,y:624,t:1527009442368};\\\", \\\"{x:1606,y:634,t:1527009442386};\\\", \\\"{x:1606,y:643,t:1527009442402};\\\", \\\"{x:1604,y:647,t:1527009442418};\\\", \\\"{x:1603,y:651,t:1527009442435};\\\", \\\"{x:1603,y:654,t:1527009442451};\\\", \\\"{x:1601,y:654,t:1527009442492};\\\", \\\"{x:1600,y:654,t:1527009442516};\\\", \\\"{x:1598,y:654,t:1527009442540};\\\", \\\"{x:1596,y:653,t:1527009442551};\\\", \\\"{x:1593,y:650,t:1527009442568};\\\", \\\"{x:1591,y:646,t:1527009442586};\\\", \\\"{x:1589,y:638,t:1527009442602};\\\", \\\"{x:1587,y:628,t:1527009442618};\\\", \\\"{x:1579,y:609,t:1527009442636};\\\", \\\"{x:1576,y:600,t:1527009442652};\\\", \\\"{x:1566,y:585,t:1527009442668};\\\", \\\"{x:1561,y:580,t:1527009442685};\\\", \\\"{x:1557,y:578,t:1527009442702};\\\", \\\"{x:1550,y:578,t:1527009442719};\\\", \\\"{x:1539,y:584,t:1527009442736};\\\", \\\"{x:1527,y:601,t:1527009442753};\\\", \\\"{x:1511,y:627,t:1527009442769};\\\", \\\"{x:1494,y:655,t:1527009442786};\\\", \\\"{x:1480,y:678,t:1527009442803};\\\", \\\"{x:1473,y:694,t:1527009442819};\\\", \\\"{x:1472,y:703,t:1527009442837};\\\", \\\"{x:1474,y:717,t:1527009442853};\\\", \\\"{x:1480,y:730,t:1527009442870};\\\", \\\"{x:1487,y:743,t:1527009442886};\\\", \\\"{x:1495,y:757,t:1527009442903};\\\", \\\"{x:1495,y:766,t:1527009442919};\\\", \\\"{x:1495,y:774,t:1527009442936};\\\", \\\"{x:1494,y:781,t:1527009442953};\\\", \\\"{x:1490,y:789,t:1527009442969};\\\", \\\"{x:1484,y:798,t:1527009442986};\\\", \\\"{x:1476,y:808,t:1527009443003};\\\", \\\"{x:1467,y:817,t:1527009443019};\\\", \\\"{x:1460,y:823,t:1527009443036};\\\", \\\"{x:1451,y:829,t:1527009443053};\\\", \\\"{x:1450,y:830,t:1527009443069};\\\", \\\"{x:1449,y:831,t:1527009443086};\\\", \\\"{x:1448,y:832,t:1527009443103};\\\", \\\"{x:1450,y:832,t:1527009443173};\\\", \\\"{x:1456,y:832,t:1527009443186};\\\", \\\"{x:1474,y:832,t:1527009443203};\\\", \\\"{x:1513,y:832,t:1527009443221};\\\", \\\"{x:1527,y:832,t:1527009443236};\\\", \\\"{x:1569,y:832,t:1527009443253};\\\", \\\"{x:1586,y:832,t:1527009443270};\\\", \\\"{x:1603,y:832,t:1527009443286};\\\", \\\"{x:1612,y:832,t:1527009443303};\\\", \\\"{x:1614,y:833,t:1527009443321};\\\", \\\"{x:1615,y:833,t:1527009443349};\\\", \\\"{x:1616,y:834,t:1527009443357};\\\", \\\"{x:1617,y:834,t:1527009443380};\\\", \\\"{x:1618,y:835,t:1527009443413};\\\", \\\"{x:1618,y:832,t:1527009443468};\\\", \\\"{x:1617,y:822,t:1527009443476};\\\", \\\"{x:1611,y:809,t:1527009443486};\\\", \\\"{x:1589,y:761,t:1527009443503};\\\", \\\"{x:1554,y:689,t:1527009443519};\\\", \\\"{x:1527,y:602,t:1527009443535};\\\", \\\"{x:1509,y:534,t:1527009443553};\\\", \\\"{x:1496,y:473,t:1527009443569};\\\", \\\"{x:1493,y:441,t:1527009443586};\\\", \\\"{x:1495,y:424,t:1527009443602};\\\", \\\"{x:1504,y:412,t:1527009443619};\\\", \\\"{x:1509,y:410,t:1527009443635};\\\", \\\"{x:1512,y:410,t:1527009443653};\\\", \\\"{x:1516,y:410,t:1527009443669};\\\", \\\"{x:1518,y:410,t:1527009443687};\\\", \\\"{x:1520,y:410,t:1527009443702};\\\", \\\"{x:1521,y:410,t:1527009443732};\\\", \\\"{x:1522,y:410,t:1527009443748};\\\", \\\"{x:1524,y:410,t:1527009443756};\\\", \\\"{x:1527,y:407,t:1527009443770};\\\", \\\"{x:1531,y:401,t:1527009443787};\\\", \\\"{x:1535,y:394,t:1527009443803};\\\", \\\"{x:1536,y:390,t:1527009443819};\\\", \\\"{x:1536,y:387,t:1527009443836};\\\", \\\"{x:1536,y:386,t:1527009443853};\\\", \\\"{x:1534,y:386,t:1527009443901};\\\", \\\"{x:1532,y:393,t:1527009443908};\\\", \\\"{x:1527,y:405,t:1527009443920};\\\", \\\"{x:1508,y:445,t:1527009443936};\\\", \\\"{x:1481,y:501,t:1527009443953};\\\", \\\"{x:1447,y:561,t:1527009443969};\\\", \\\"{x:1421,y:609,t:1527009443987};\\\", \\\"{x:1409,y:642,t:1527009444003};\\\", \\\"{x:1407,y:663,t:1527009444020};\\\", \\\"{x:1409,y:678,t:1527009444036};\\\", \\\"{x:1415,y:686,t:1527009444054};\\\", \\\"{x:1419,y:695,t:1527009444070};\\\", \\\"{x:1421,y:701,t:1527009444087};\\\", \\\"{x:1424,y:705,t:1527009444104};\\\", \\\"{x:1424,y:710,t:1527009444120};\\\", \\\"{x:1424,y:711,t:1527009444137};\\\", \\\"{x:1424,y:712,t:1527009444154};\\\", \\\"{x:1424,y:713,t:1527009444170};\\\", \\\"{x:1424,y:714,t:1527009444245};\\\", \\\"{x:1423,y:714,t:1527009444260};\\\", \\\"{x:1423,y:711,t:1527009444276};\\\", \\\"{x:1423,y:708,t:1527009444287};\\\", \\\"{x:1433,y:704,t:1527009444303};\\\", \\\"{x:1443,y:701,t:1527009444320};\\\", \\\"{x:1458,y:699,t:1527009444337};\\\", \\\"{x:1474,y:696,t:1527009444354};\\\", \\\"{x:1486,y:695,t:1527009444370};\\\", \\\"{x:1493,y:694,t:1527009444386};\\\", \\\"{x:1495,y:692,t:1527009444403};\\\", \\\"{x:1495,y:690,t:1527009444420};\\\", \\\"{x:1495,y:678,t:1527009444436};\\\", \\\"{x:1490,y:655,t:1527009444453};\\\", \\\"{x:1477,y:623,t:1527009444471};\\\", \\\"{x:1459,y:579,t:1527009444487};\\\", \\\"{x:1449,y:558,t:1527009444504};\\\", \\\"{x:1442,y:550,t:1527009444521};\\\", \\\"{x:1437,y:548,t:1527009444536};\\\", \\\"{x:1430,y:548,t:1527009444553};\\\", \\\"{x:1419,y:560,t:1527009444571};\\\", \\\"{x:1408,y:581,t:1527009444587};\\\", \\\"{x:1399,y:602,t:1527009444604};\\\", \\\"{x:1379,y:634,t:1527009444620};\\\", \\\"{x:1367,y:649,t:1527009444637};\\\", \\\"{x:1357,y:663,t:1527009444654};\\\", \\\"{x:1354,y:669,t:1527009444671};\\\", \\\"{x:1352,y:672,t:1527009444687};\\\", \\\"{x:1352,y:674,t:1527009444703};\\\", \\\"{x:1350,y:676,t:1527009444721};\\\", \\\"{x:1349,y:679,t:1527009444737};\\\", \\\"{x:1348,y:681,t:1527009444754};\\\", \\\"{x:1347,y:683,t:1527009444771};\\\", \\\"{x:1346,y:685,t:1527009444786};\\\", \\\"{x:1344,y:685,t:1527009444804};\\\", \\\"{x:1344,y:686,t:1527009444893};\\\", \\\"{x:1344,y:687,t:1527009444909};\\\", \\\"{x:1344,y:688,t:1527009444925};\\\", \\\"{x:1344,y:689,t:1527009444941};\\\", \\\"{x:1344,y:690,t:1527009444953};\\\", \\\"{x:1344,y:692,t:1527009444972};\\\", \\\"{x:1344,y:694,t:1527009444988};\\\", \\\"{x:1344,y:695,t:1527009445013};\\\", \\\"{x:1343,y:695,t:1527009445036};\\\", \\\"{x:1342,y:695,t:1527009445045};\\\", \\\"{x:1341,y:695,t:1527009445055};\\\", \\\"{x:1340,y:695,t:1527009445085};\\\", \\\"{x:1340,y:692,t:1527009445093};\\\", \\\"{x:1340,y:689,t:1527009445104};\\\", \\\"{x:1346,y:678,t:1527009445121};\\\", \\\"{x:1353,y:665,t:1527009445139};\\\", \\\"{x:1364,y:650,t:1527009445154};\\\", \\\"{x:1376,y:634,t:1527009445171};\\\", \\\"{x:1388,y:613,t:1527009445188};\\\", \\\"{x:1390,y:608,t:1527009445204};\\\", \\\"{x:1393,y:603,t:1527009445220};\\\", \\\"{x:1393,y:602,t:1527009445238};\\\", \\\"{x:1394,y:600,t:1527009445254};\\\", \\\"{x:1395,y:599,t:1527009445271};\\\", \\\"{x:1396,y:596,t:1527009445288};\\\", \\\"{x:1397,y:594,t:1527009445304};\\\", \\\"{x:1400,y:590,t:1527009445321};\\\", \\\"{x:1404,y:585,t:1527009445338};\\\", \\\"{x:1408,y:577,t:1527009445355};\\\", \\\"{x:1411,y:568,t:1527009445371};\\\", \\\"{x:1414,y:562,t:1527009445388};\\\", \\\"{x:1415,y:560,t:1527009445405};\\\", \\\"{x:1416,y:559,t:1527009445428};\\\", \\\"{x:1414,y:567,t:1527009447868};\\\", \\\"{x:1411,y:576,t:1527009447877};\\\", \\\"{x:1409,y:586,t:1527009447890};\\\", \\\"{x:1397,y:612,t:1527009447906};\\\", \\\"{x:1388,y:631,t:1527009447923};\\\", \\\"{x:1381,y:646,t:1527009447939};\\\", \\\"{x:1376,y:651,t:1527009447956};\\\", \\\"{x:1375,y:652,t:1527009447973};\\\", \\\"{x:1374,y:653,t:1527009447990};\\\", \\\"{x:1371,y:657,t:1527009448006};\\\", \\\"{x:1368,y:662,t:1527009448023};\\\", \\\"{x:1364,y:667,t:1527009448040};\\\", \\\"{x:1361,y:672,t:1527009448057};\\\", \\\"{x:1359,y:673,t:1527009448073};\\\", \\\"{x:1359,y:674,t:1527009448090};\\\", \\\"{x:1359,y:675,t:1527009448107};\\\", \\\"{x:1359,y:680,t:1527009448123};\\\", \\\"{x:1359,y:689,t:1527009448140};\\\", \\\"{x:1359,y:694,t:1527009448156};\\\", \\\"{x:1359,y:695,t:1527009448173};\\\", \\\"{x:1357,y:698,t:1527009448189};\\\", \\\"{x:1357,y:699,t:1527009448207};\\\", \\\"{x:1356,y:699,t:1527009448222};\\\", \\\"{x:1355,y:701,t:1527009448240};\\\", \\\"{x:1354,y:701,t:1527009448260};\\\", \\\"{x:1353,y:701,t:1527009448292};\\\", \\\"{x:1351,y:701,t:1527009448316};\\\", \\\"{x:1350,y:701,t:1527009448340};\\\", \\\"{x:1348,y:701,t:1527009448357};\\\", \\\"{x:1347,y:701,t:1527009448373};\\\", \\\"{x:1345,y:700,t:1527009448390};\\\", \\\"{x:1344,y:700,t:1527009448406};\\\", \\\"{x:1343,y:699,t:1527009448423};\\\", \\\"{x:1342,y:699,t:1527009448440};\\\", \\\"{x:1343,y:699,t:1527009448788};\\\", \\\"{x:1344,y:699,t:1527009448807};\\\", \\\"{x:1344,y:701,t:1527009449765};\\\", \\\"{x:1343,y:701,t:1527009449830};\\\", \\\"{x:1341,y:705,t:1527009449870};\\\", \\\"{x:1340,y:708,t:1527009449884};\\\", \\\"{x:1339,y:712,t:1527009449908};\\\", \\\"{x:1337,y:714,t:1527009449924};\\\", \\\"{x:1337,y:718,t:1527009449941};\\\", \\\"{x:1335,y:721,t:1527009449957};\\\", \\\"{x:1333,y:723,t:1527009449975};\\\", \\\"{x:1332,y:726,t:1527009449991};\\\", \\\"{x:1327,y:732,t:1527009450008};\\\", \\\"{x:1321,y:738,t:1527009450025};\\\", \\\"{x:1315,y:746,t:1527009450041};\\\", \\\"{x:1308,y:754,t:1527009450058};\\\", \\\"{x:1304,y:760,t:1527009450075};\\\", \\\"{x:1300,y:767,t:1527009450091};\\\", \\\"{x:1292,y:782,t:1527009450109};\\\", \\\"{x:1285,y:793,t:1527009450125};\\\", \\\"{x:1280,y:800,t:1527009450142};\\\", \\\"{x:1273,y:810,t:1527009450158};\\\", \\\"{x:1270,y:817,t:1527009450175};\\\", \\\"{x:1268,y:821,t:1527009450192};\\\", \\\"{x:1266,y:824,t:1527009450208};\\\", \\\"{x:1265,y:827,t:1527009450225};\\\", \\\"{x:1264,y:831,t:1527009450242};\\\", \\\"{x:1263,y:837,t:1527009450258};\\\", \\\"{x:1259,y:846,t:1527009450275};\\\", \\\"{x:1253,y:865,t:1527009450293};\\\", \\\"{x:1246,y:877,t:1527009450309};\\\", \\\"{x:1243,y:884,t:1527009450325};\\\", \\\"{x:1239,y:892,t:1527009450343};\\\", \\\"{x:1237,y:902,t:1527009450359};\\\", \\\"{x:1234,y:913,t:1527009450375};\\\", \\\"{x:1230,y:925,t:1527009450392};\\\", \\\"{x:1226,y:936,t:1527009450410};\\\", \\\"{x:1221,y:944,t:1527009450425};\\\", \\\"{x:1218,y:949,t:1527009450442};\\\", \\\"{x:1215,y:955,t:1527009450458};\\\", \\\"{x:1211,y:962,t:1527009450491};\\\", \\\"{x:1210,y:963,t:1527009450492};\\\", \\\"{x:1210,y:964,t:1527009450508};\\\", \\\"{x:1209,y:965,t:1527009450524};\\\", \\\"{x:1209,y:966,t:1527009450579};\\\", \\\"{x:1209,y:967,t:1527009450709};\\\", \\\"{x:1210,y:967,t:1527009450980};\\\", \\\"{x:1211,y:967,t:1527009451004};\\\", \\\"{x:1212,y:967,t:1527009451044};\\\", \\\"{x:1212,y:968,t:1527009451060};\\\", \\\"{x:1213,y:969,t:1527009451205};\\\", \\\"{x:1213,y:968,t:1527009451548};\\\", \\\"{x:1214,y:966,t:1527009451559};\\\", \\\"{x:1216,y:959,t:1527009451576};\\\", \\\"{x:1221,y:947,t:1527009451593};\\\", \\\"{x:1227,y:931,t:1527009451609};\\\", \\\"{x:1232,y:919,t:1527009451626};\\\", \\\"{x:1239,y:905,t:1527009451643};\\\", \\\"{x:1250,y:889,t:1527009451659};\\\", \\\"{x:1263,y:862,t:1527009451676};\\\", \\\"{x:1275,y:835,t:1527009451693};\\\", \\\"{x:1287,y:815,t:1527009451709};\\\", \\\"{x:1294,y:803,t:1527009451726};\\\", \\\"{x:1299,y:796,t:1527009451743};\\\", \\\"{x:1301,y:793,t:1527009451759};\\\", \\\"{x:1302,y:790,t:1527009451776};\\\", \\\"{x:1304,y:786,t:1527009451793};\\\", \\\"{x:1309,y:774,t:1527009451809};\\\", \\\"{x:1315,y:762,t:1527009451826};\\\", \\\"{x:1322,y:749,t:1527009451843};\\\", \\\"{x:1326,y:739,t:1527009451859};\\\", \\\"{x:1335,y:722,t:1527009451876};\\\", \\\"{x:1339,y:714,t:1527009451893};\\\", \\\"{x:1343,y:707,t:1527009451910};\\\", \\\"{x:1346,y:702,t:1527009451926};\\\", \\\"{x:1349,y:697,t:1527009451943};\\\", \\\"{x:1353,y:692,t:1527009451960};\\\", \\\"{x:1356,y:687,t:1527009451976};\\\", \\\"{x:1359,y:684,t:1527009451993};\\\", \\\"{x:1359,y:686,t:1527009452140};\\\", \\\"{x:1359,y:687,t:1527009452148};\\\", \\\"{x:1358,y:689,t:1527009452160};\\\", \\\"{x:1357,y:691,t:1527009452176};\\\", \\\"{x:1355,y:693,t:1527009452193};\\\", \\\"{x:1353,y:695,t:1527009452210};\\\", \\\"{x:1352,y:697,t:1527009452226};\\\", \\\"{x:1352,y:698,t:1527009452252};\\\", \\\"{x:1350,y:698,t:1527009452388};\\\", \\\"{x:1349,y:698,t:1527009452413};\\\", \\\"{x:1349,y:695,t:1527009454056};\\\", \\\"{x:1350,y:693,t:1527009454079};\\\", \\\"{x:1351,y:692,t:1527009454086};\\\", \\\"{x:1352,y:689,t:1527009454098};\\\", \\\"{x:1353,y:686,t:1527009454114};\\\", \\\"{x:1357,y:678,t:1527009454131};\\\", \\\"{x:1359,y:673,t:1527009454148};\\\", \\\"{x:1362,y:666,t:1527009454164};\\\", \\\"{x:1367,y:658,t:1527009454181};\\\", \\\"{x:1369,y:653,t:1527009454198};\\\", \\\"{x:1371,y:649,t:1527009454214};\\\", \\\"{x:1374,y:649,t:1527009454231};\\\", \\\"{x:1376,y:648,t:1527009454248};\\\", \\\"{x:1377,y:648,t:1527009454288};\\\", \\\"{x:1378,y:648,t:1527009454298};\\\", \\\"{x:1379,y:648,t:1527009454315};\\\", \\\"{x:1380,y:648,t:1527009454331};\\\", \\\"{x:1382,y:648,t:1527009454348};\\\", \\\"{x:1383,y:648,t:1527009454392};\\\", \\\"{x:1384,y:648,t:1527009454432};\\\", \\\"{x:1385,y:648,t:1527009454449};\\\", \\\"{x:1386,y:648,t:1527009454480};\\\", \\\"{x:1387,y:648,t:1527009454496};\\\", \\\"{x:1388,y:648,t:1527009454512};\\\", \\\"{x:1389,y:648,t:1527009455041};\\\", \\\"{x:1390,y:648,t:1527009455176};\\\", \\\"{x:1391,y:648,t:1527009455271};\\\", \\\"{x:1394,y:650,t:1527009455991};\\\", \\\"{x:1396,y:662,t:1527009455999};\\\", \\\"{x:1421,y:718,t:1527009456016};\\\", \\\"{x:1460,y:804,t:1527009456033};\\\", \\\"{x:1499,y:895,t:1527009456049};\\\", \\\"{x:1532,y:983,t:1527009456066};\\\", \\\"{x:1563,y:1047,t:1527009456082};\\\", \\\"{x:1589,y:1107,t:1527009456099};\\\", \\\"{x:1597,y:1139,t:1527009456116};\\\", \\\"{x:1603,y:1161,t:1527009456132};\\\", \\\"{x:1603,y:1183,t:1527009456149};\\\", \\\"{x:1598,y:1195,t:1527009456166};\\\", \\\"{x:1590,y:1206,t:1527009456182};\\\", \\\"{x:1583,y:1212,t:1527009456199};\\\", \\\"{x:1582,y:1212,t:1527009456216};\\\", \\\"{x:1580,y:1212,t:1527009456233};\\\", \\\"{x:1577,y:1211,t:1527009456249};\\\", \\\"{x:1570,y:1205,t:1527009456266};\\\", \\\"{x:1557,y:1191,t:1527009456283};\\\", \\\"{x:1545,y:1173,t:1527009456300};\\\", \\\"{x:1533,y:1146,t:1527009456316};\\\", \\\"{x:1517,y:1108,t:1527009456333};\\\", \\\"{x:1506,y:1077,t:1527009456350};\\\", \\\"{x:1496,y:1057,t:1527009456366};\\\", \\\"{x:1490,y:1042,t:1527009456383};\\\", \\\"{x:1490,y:1041,t:1527009456400};\\\", \\\"{x:1490,y:1039,t:1527009456495};\\\", \\\"{x:1490,y:1037,t:1527009456503};\\\", \\\"{x:1490,y:1034,t:1527009456517};\\\", \\\"{x:1490,y:1030,t:1527009456534};\\\", \\\"{x:1490,y:1022,t:1527009456551};\\\", \\\"{x:1495,y:1008,t:1527009456567};\\\", \\\"{x:1501,y:993,t:1527009456583};\\\", \\\"{x:1504,y:984,t:1527009456600};\\\", \\\"{x:1507,y:976,t:1527009456617};\\\", \\\"{x:1509,y:974,t:1527009456633};\\\", \\\"{x:1511,y:971,t:1527009456650};\\\", \\\"{x:1512,y:970,t:1527009456667};\\\", \\\"{x:1512,y:969,t:1527009456687};\\\", \\\"{x:1512,y:967,t:1527009456702};\\\", \\\"{x:1512,y:966,t:1527009456717};\\\", \\\"{x:1512,y:963,t:1527009456733};\\\", \\\"{x:1512,y:962,t:1527009456750};\\\", \\\"{x:1510,y:962,t:1527009456783};\\\", \\\"{x:1508,y:962,t:1527009456800};\\\", \\\"{x:1506,y:962,t:1527009456817};\\\", \\\"{x:1505,y:962,t:1527009456833};\\\", \\\"{x:1504,y:962,t:1527009456879};\\\", \\\"{x:1503,y:962,t:1527009456895};\\\", \\\"{x:1500,y:962,t:1527009456903};\\\", \\\"{x:1498,y:963,t:1527009456917};\\\", \\\"{x:1493,y:964,t:1527009456933};\\\", \\\"{x:1488,y:964,t:1527009456950};\\\", \\\"{x:1484,y:964,t:1527009456966};\\\", \\\"{x:1481,y:964,t:1527009456983};\\\", \\\"{x:1479,y:964,t:1527009457001};\\\", \\\"{x:1478,y:964,t:1527009457023};\\\", \\\"{x:1476,y:964,t:1527009457088};\\\", \\\"{x:1474,y:965,t:1527009457111};\\\", \\\"{x:1477,y:961,t:1527009457344};\\\", \\\"{x:1480,y:956,t:1527009457352};\\\", \\\"{x:1495,y:933,t:1527009457368};\\\", \\\"{x:1539,y:881,t:1527009457385};\\\", \\\"{x:1590,y:820,t:1527009457400};\\\", \\\"{x:1638,y:762,t:1527009457418};\\\", \\\"{x:1676,y:718,t:1527009457434};\\\", \\\"{x:1694,y:696,t:1527009457451};\\\", \\\"{x:1698,y:688,t:1527009457467};\\\", \\\"{x:1698,y:687,t:1527009457484};\\\", \\\"{x:1696,y:687,t:1527009457569};\\\", \\\"{x:1696,y:688,t:1527009457584};\\\", \\\"{x:1694,y:689,t:1527009457647};\\\", \\\"{x:1692,y:689,t:1527009457655};\\\", \\\"{x:1686,y:690,t:1527009457667};\\\", \\\"{x:1677,y:693,t:1527009457684};\\\", \\\"{x:1673,y:694,t:1527009457701};\\\", \\\"{x:1667,y:695,t:1527009457717};\\\", \\\"{x:1666,y:695,t:1527009457734};\\\", \\\"{x:1661,y:695,t:1527009457750};\\\", \\\"{x:1659,y:693,t:1527009457767};\\\", \\\"{x:1656,y:692,t:1527009457784};\\\", \\\"{x:1645,y:687,t:1527009457801};\\\", \\\"{x:1637,y:682,t:1527009457818};\\\", \\\"{x:1630,y:681,t:1527009457835};\\\", \\\"{x:1621,y:680,t:1527009457852};\\\", \\\"{x:1615,y:680,t:1527009457868};\\\", \\\"{x:1611,y:680,t:1527009457884};\\\", \\\"{x:1607,y:680,t:1527009457901};\\\", \\\"{x:1606,y:680,t:1527009457918};\\\", \\\"{x:1604,y:680,t:1527009457935};\\\", \\\"{x:1602,y:682,t:1527009457951};\\\", \\\"{x:1602,y:683,t:1527009457999};\\\", \\\"{x:1602,y:684,t:1527009458007};\\\", \\\"{x:1602,y:685,t:1527009458018};\\\", \\\"{x:1603,y:690,t:1527009458034};\\\", \\\"{x:1605,y:693,t:1527009458051};\\\", \\\"{x:1607,y:695,t:1527009458068};\\\", \\\"{x:1608,y:695,t:1527009458084};\\\", \\\"{x:1610,y:696,t:1527009458101};\\\", \\\"{x:1611,y:697,t:1527009458118};\\\", \\\"{x:1603,y:698,t:1527009458223};\\\", \\\"{x:1580,y:700,t:1527009458234};\\\", \\\"{x:1453,y:717,t:1527009458251};\\\", \\\"{x:1249,y:742,t:1527009458268};\\\", \\\"{x:1031,y:765,t:1527009458285};\\\", \\\"{x:810,y:791,t:1527009458301};\\\", \\\"{x:602,y:800,t:1527009458318};\\\", \\\"{x:359,y:800,t:1527009458334};\\\", \\\"{x:241,y:776,t:1527009458351};\\\", \\\"{x:178,y:748,t:1527009458368};\\\", \\\"{x:157,y:731,t:1527009458385};\\\", \\\"{x:155,y:728,t:1527009458401};\\\", \\\"{x:157,y:728,t:1527009458447};\\\", \\\"{x:158,y:728,t:1527009458454};\\\", \\\"{x:158,y:727,t:1527009458469};\\\", \\\"{x:160,y:726,t:1527009458485};\\\", \\\"{x:162,y:722,t:1527009458502};\\\", \\\"{x:166,y:708,t:1527009458518};\\\", \\\"{x:169,y:672,t:1527009458535};\\\", \\\"{x:178,y:650,t:1527009458551};\\\", \\\"{x:196,y:629,t:1527009458569};\\\", \\\"{x:228,y:618,t:1527009458586};\\\", \\\"{x:278,y:611,t:1527009458602};\\\", \\\"{x:315,y:611,t:1527009458619};\\\", \\\"{x:339,y:611,t:1527009458635};\\\", \\\"{x:354,y:611,t:1527009458651};\\\", \\\"{x:361,y:612,t:1527009458668};\\\", \\\"{x:363,y:613,t:1527009458686};\\\", \\\"{x:363,y:614,t:1527009458703};\\\", \\\"{x:363,y:615,t:1527009458718};\\\", \\\"{x:363,y:617,t:1527009458758};\\\", \\\"{x:363,y:618,t:1527009458782};\\\", \\\"{x:364,y:619,t:1527009458791};\\\", \\\"{x:365,y:621,t:1527009458802};\\\", \\\"{x:367,y:625,t:1527009458818};\\\", \\\"{x:369,y:626,t:1527009458835};\\\", \\\"{x:372,y:626,t:1527009458853};\\\", \\\"{x:374,y:626,t:1527009458868};\\\", \\\"{x:375,y:626,t:1527009458886};\\\", \\\"{x:375,y:625,t:1527009458966};\\\", \\\"{x:375,y:622,t:1527009458974};\\\", \\\"{x:374,y:620,t:1527009458985};\\\", \\\"{x:369,y:612,t:1527009459003};\\\", \\\"{x:361,y:604,t:1527009459018};\\\", \\\"{x:348,y:598,t:1527009459035};\\\", \\\"{x:335,y:595,t:1527009459053};\\\", \\\"{x:323,y:595,t:1527009459069};\\\", \\\"{x:305,y:595,t:1527009459085};\\\", \\\"{x:289,y:595,t:1527009459102};\\\", \\\"{x:261,y:596,t:1527009459119};\\\", \\\"{x:248,y:599,t:1527009459135};\\\", \\\"{x:240,y:603,t:1527009459152};\\\", \\\"{x:236,y:604,t:1527009459169};\\\", \\\"{x:235,y:604,t:1527009459185};\\\", \\\"{x:234,y:604,t:1527009459202};\\\", \\\"{x:233,y:604,t:1527009459238};\\\", \\\"{x:232,y:604,t:1527009459253};\\\", \\\"{x:232,y:603,t:1527009459270};\\\", \\\"{x:242,y:598,t:1527009459285};\\\", \\\"{x:272,y:597,t:1527009459303};\\\", \\\"{x:379,y:593,t:1527009459320};\\\", \\\"{x:462,y:592,t:1527009459335};\\\", \\\"{x:532,y:590,t:1527009459353};\\\", \\\"{x:581,y:588,t:1527009459369};\\\", \\\"{x:606,y:588,t:1527009459386};\\\", \\\"{x:621,y:588,t:1527009459402};\\\", \\\"{x:624,y:588,t:1527009459419};\\\", \\\"{x:624,y:587,t:1527009459624};\\\", \\\"{x:624,y:586,t:1527009459638};\\\", \\\"{x:623,y:586,t:1527009459662};\\\", \\\"{x:623,y:590,t:1527009459751};\\\", \\\"{x:622,y:598,t:1527009459769};\\\", \\\"{x:622,y:608,t:1527009459786};\\\", \\\"{x:622,y:616,t:1527009459802};\\\", \\\"{x:622,y:624,t:1527009459819};\\\", \\\"{x:622,y:626,t:1527009459836};\\\", \\\"{x:622,y:627,t:1527009459852};\\\", \\\"{x:621,y:627,t:1527009459950};\\\", \\\"{x:620,y:625,t:1527009459959};\\\", \\\"{x:620,y:618,t:1527009459969};\\\", \\\"{x:625,y:598,t:1527009459987};\\\", \\\"{x:634,y:580,t:1527009460003};\\\", \\\"{x:648,y:564,t:1527009460019};\\\", \\\"{x:668,y:553,t:1527009460037};\\\", \\\"{x:689,y:546,t:1527009460053};\\\", \\\"{x:716,y:544,t:1527009460069};\\\", \\\"{x:738,y:544,t:1527009460086};\\\", \\\"{x:769,y:547,t:1527009460103};\\\", \\\"{x:781,y:554,t:1527009460120};\\\", \\\"{x:789,y:563,t:1527009460137};\\\", \\\"{x:793,y:571,t:1527009460153};\\\", \\\"{x:794,y:575,t:1527009460169};\\\", \\\"{x:795,y:578,t:1527009460186};\\\", \\\"{x:795,y:581,t:1527009460204};\\\", \\\"{x:795,y:582,t:1527009460219};\\\", \\\"{x:795,y:584,t:1527009460236};\\\", \\\"{x:795,y:585,t:1527009460253};\\\", \\\"{x:794,y:585,t:1527009460269};\\\", \\\"{x:793,y:586,t:1527009462023};\\\", \\\"{x:783,y:590,t:1527009462037};\\\", \\\"{x:751,y:600,t:1527009462054};\\\", \\\"{x:674,y:621,t:1527009462071};\\\", \\\"{x:622,y:640,t:1527009462089};\\\", \\\"{x:589,y:655,t:1527009462105};\\\", \\\"{x:576,y:661,t:1527009462121};\\\", \\\"{x:574,y:663,t:1527009462138};\\\", \\\"{x:573,y:663,t:1527009462207};\\\", \\\"{x:572,y:663,t:1527009462223};\\\", \\\"{x:570,y:663,t:1527009462239};\\\", \\\"{x:570,y:661,t:1527009462255};\\\", \\\"{x:568,y:654,t:1527009462271};\\\", \\\"{x:568,y:648,t:1527009462288};\\\", \\\"{x:568,y:641,t:1527009462304};\\\", \\\"{x:568,y:637,t:1527009462322};\\\", \\\"{x:568,y:634,t:1527009462339};\\\", \\\"{x:568,y:633,t:1527009462354};\\\", \\\"{x:566,y:633,t:1527009462440};\\\", \\\"{x:558,y:633,t:1527009462455};\\\", \\\"{x:525,y:640,t:1527009462471};\\\", \\\"{x:504,y:646,t:1527009462488};\\\", \\\"{x:489,y:648,t:1527009462505};\\\", \\\"{x:479,y:648,t:1527009462522};\\\", \\\"{x:466,y:646,t:1527009462538};\\\", \\\"{x:460,y:643,t:1527009462554};\\\", \\\"{x:454,y:638,t:1527009462571};\\\", \\\"{x:450,y:634,t:1527009462587};\\\", \\\"{x:448,y:631,t:1527009462606};\\\", \\\"{x:448,y:630,t:1527009462621};\\\", \\\"{x:448,y:629,t:1527009462639};\\\", \\\"{x:446,y:627,t:1527009462663};\\\", \\\"{x:443,y:627,t:1527009462671};\\\", \\\"{x:440,y:624,t:1527009462688};\\\", \\\"{x:433,y:619,t:1527009462705};\\\", \\\"{x:427,y:614,t:1527009462721};\\\", \\\"{x:425,y:606,t:1527009462738};\\\", \\\"{x:424,y:599,t:1527009462755};\\\", \\\"{x:424,y:593,t:1527009462773};\\\", \\\"{x:423,y:583,t:1527009462788};\\\", \\\"{x:421,y:572,t:1527009462806};\\\", \\\"{x:421,y:563,t:1527009462822};\\\", \\\"{x:420,y:554,t:1527009462840};\\\", \\\"{x:418,y:544,t:1527009462856};\\\", \\\"{x:417,y:543,t:1527009462871};\\\", \\\"{x:417,y:542,t:1527009462888};\\\", \\\"{x:419,y:542,t:1527009462943};\\\", \\\"{x:425,y:544,t:1527009462955};\\\", \\\"{x:456,y:558,t:1527009462972};\\\", \\\"{x:543,y:583,t:1527009462989};\\\", \\\"{x:671,y:604,t:1527009463006};\\\", \\\"{x:836,y:619,t:1527009463024};\\\", \\\"{x:1027,y:630,t:1527009463039};\\\", \\\"{x:1282,y:637,t:1527009463056};\\\", \\\"{x:1415,y:637,t:1527009463073};\\\", \\\"{x:1493,y:637,t:1527009463088};\\\", \\\"{x:1515,y:638,t:1527009463106};\\\", \\\"{x:1519,y:640,t:1527009463122};\\\", \\\"{x:1518,y:641,t:1527009463143};\\\", \\\"{x:1517,y:642,t:1527009463155};\\\", \\\"{x:1516,y:642,t:1527009463172};\\\", \\\"{x:1515,y:642,t:1527009463190};\\\", \\\"{x:1515,y:643,t:1527009463215};\\\", \\\"{x:1515,y:644,t:1527009463239};\\\", \\\"{x:1515,y:648,t:1527009463257};\\\", \\\"{x:1515,y:658,t:1527009463273};\\\", \\\"{x:1515,y:669,t:1527009463290};\\\", \\\"{x:1515,y:680,t:1527009463306};\\\", \\\"{x:1516,y:695,t:1527009463323};\\\", \\\"{x:1522,y:710,t:1527009463340};\\\", \\\"{x:1523,y:713,t:1527009463357};\\\", \\\"{x:1524,y:714,t:1527009463373};\\\", \\\"{x:1524,y:716,t:1527009463389};\\\", \\\"{x:1526,y:717,t:1527009463464};\\\", \\\"{x:1530,y:717,t:1527009463474};\\\", \\\"{x:1543,y:710,t:1527009463489};\\\", \\\"{x:1558,y:704,t:1527009463507};\\\", \\\"{x:1575,y:699,t:1527009463523};\\\", \\\"{x:1591,y:698,t:1527009463541};\\\", \\\"{x:1601,y:697,t:1527009463556};\\\", \\\"{x:1605,y:696,t:1527009463574};\\\", \\\"{x:1606,y:696,t:1527009463590};\\\", \\\"{x:1607,y:696,t:1527009463648};\\\", \\\"{x:1608,y:696,t:1527009463658};\\\", \\\"{x:1605,y:696,t:1527009463686};\\\", \\\"{x:1593,y:700,t:1527009463696};\\\", \\\"{x:1582,y:701,t:1527009463708};\\\", \\\"{x:1543,y:707,t:1527009463724};\\\", \\\"{x:1502,y:713,t:1527009463740};\\\", \\\"{x:1466,y:717,t:1527009463757};\\\", \\\"{x:1438,y:719,t:1527009463775};\\\", \\\"{x:1395,y:719,t:1527009463790};\\\", \\\"{x:1373,y:719,t:1527009463808};\\\", \\\"{x:1355,y:719,t:1527009463825};\\\", \\\"{x:1343,y:719,t:1527009463841};\\\", \\\"{x:1334,y:719,t:1527009463857};\\\", \\\"{x:1330,y:721,t:1527009463875};\\\", \\\"{x:1326,y:721,t:1527009463892};\\\", \\\"{x:1323,y:721,t:1527009463908};\\\", \\\"{x:1319,y:721,t:1527009463925};\\\", \\\"{x:1317,y:721,t:1527009463942};\\\", \\\"{x:1316,y:720,t:1527009463957};\\\", \\\"{x:1316,y:716,t:1527009463974};\\\", \\\"{x:1317,y:714,t:1527009463992};\\\", \\\"{x:1320,y:710,t:1527009464009};\\\", \\\"{x:1324,y:708,t:1527009464024};\\\", \\\"{x:1333,y:705,t:1527009464041};\\\", \\\"{x:1340,y:703,t:1527009464059};\\\", \\\"{x:1347,y:703,t:1527009464074};\\\", \\\"{x:1354,y:702,t:1527009464091};\\\", \\\"{x:1356,y:702,t:1527009464108};\\\", \\\"{x:1357,y:702,t:1527009464135};\\\", \\\"{x:1358,y:702,t:1527009464182};\\\", \\\"{x:1357,y:703,t:1527009464192};\\\", \\\"{x:1355,y:703,t:1527009464208};\\\", \\\"{x:1353,y:703,t:1527009464226};\\\", \\\"{x:1351,y:703,t:1527009464242};\\\", \\\"{x:1350,y:703,t:1527009464286};\\\", \\\"{x:1349,y:703,t:1527009464311};\\\", \\\"{x:1348,y:703,t:1527009464327};\\\", \\\"{x:1347,y:703,t:1527009464343};\\\", \\\"{x:1348,y:703,t:1527009464687};\\\", \\\"{x:1352,y:701,t:1527009464696};\\\", \\\"{x:1360,y:700,t:1527009464710};\\\", \\\"{x:1381,y:698,t:1527009464728};\\\", \\\"{x:1397,y:695,t:1527009464744};\\\", \\\"{x:1405,y:695,t:1527009464762};\\\", \\\"{x:1412,y:695,t:1527009464777};\\\", \\\"{x:1414,y:695,t:1527009464794};\\\", \\\"{x:1415,y:695,t:1527009464848};\\\", \\\"{x:1416,y:695,t:1527009464904};\\\", \\\"{x:1417,y:695,t:1527009464920};\\\", \\\"{x:1418,y:696,t:1527009464936};\\\", \\\"{x:1420,y:696,t:1527009464952};\\\", \\\"{x:1423,y:697,t:1527009464961};\\\", \\\"{x:1427,y:697,t:1527009464978};\\\", \\\"{x:1436,y:697,t:1527009464995};\\\", \\\"{x:1447,y:697,t:1527009465011};\\\", \\\"{x:1463,y:697,t:1527009465028};\\\", \\\"{x:1486,y:697,t:1527009465045};\\\", \\\"{x:1509,y:697,t:1527009465061};\\\", \\\"{x:1534,y:697,t:1527009465078};\\\", \\\"{x:1557,y:697,t:1527009465095};\\\", \\\"{x:1585,y:697,t:1527009465112};\\\", \\\"{x:1603,y:697,t:1527009465128};\\\", \\\"{x:1616,y:697,t:1527009465146};\\\", \\\"{x:1624,y:697,t:1527009465163};\\\", \\\"{x:1629,y:697,t:1527009465178};\\\", \\\"{x:1631,y:697,t:1527009465195};\\\", \\\"{x:1633,y:697,t:1527009465212};\\\", \\\"{x:1634,y:697,t:1527009465228};\\\", \\\"{x:1636,y:697,t:1527009465256};\\\", \\\"{x:1637,y:697,t:1527009465312};\\\", \\\"{x:1636,y:697,t:1527009465464};\\\", \\\"{x:1626,y:699,t:1527009465479};\\\", \\\"{x:1546,y:699,t:1527009465496};\\\", \\\"{x:1446,y:699,t:1527009465513};\\\", \\\"{x:1343,y:700,t:1527009465530};\\\", \\\"{x:1257,y:700,t:1527009465547};\\\", \\\"{x:1182,y:700,t:1527009465563};\\\", \\\"{x:1135,y:700,t:1527009465580};\\\", \\\"{x:1099,y:700,t:1527009465596};\\\", \\\"{x:1078,y:698,t:1527009465613};\\\", \\\"{x:1066,y:694,t:1527009465630};\\\", \\\"{x:1057,y:693,t:1527009465646};\\\", \\\"{x:1054,y:693,t:1527009465664};\\\", \\\"{x:1052,y:693,t:1527009465681};\\\", \\\"{x:1051,y:693,t:1527009465696};\\\", \\\"{x:1049,y:691,t:1527009465713};\\\", \\\"{x:1045,y:690,t:1527009465730};\\\", \\\"{x:1034,y:685,t:1527009465747};\\\", \\\"{x:1008,y:675,t:1527009465764};\\\", \\\"{x:955,y:658,t:1527009465780};\\\", \\\"{x:883,y:641,t:1527009465797};\\\", \\\"{x:777,y:620,t:1527009465814};\\\", \\\"{x:660,y:602,t:1527009465830};\\\", \\\"{x:519,y:592,t:1527009465847};\\\", \\\"{x:449,y:592,t:1527009465875};\\\", \\\"{x:431,y:592,t:1527009465891};\\\", \\\"{x:422,y:592,t:1527009465907};\\\", \\\"{x:420,y:592,t:1527009465924};\\\", \\\"{x:419,y:592,t:1527009466111};\\\", \\\"{x:418,y:592,t:1527009466127};\\\", \\\"{x:416,y:592,t:1527009466142};\\\", \\\"{x:412,y:595,t:1527009466159};\\\", \\\"{x:396,y:606,t:1527009466176};\\\", \\\"{x:389,y:608,t:1527009466191};\\\", \\\"{x:373,y:613,t:1527009466208};\\\", \\\"{x:359,y:618,t:1527009466225};\\\", \\\"{x:343,y:622,t:1527009466242};\\\", \\\"{x:327,y:628,t:1527009466258};\\\", \\\"{x:310,y:631,t:1527009466275};\\\", \\\"{x:295,y:633,t:1527009466292};\\\", \\\"{x:278,y:635,t:1527009466309};\\\", \\\"{x:259,y:637,t:1527009466325};\\\", \\\"{x:238,y:637,t:1527009466341};\\\", \\\"{x:223,y:637,t:1527009466357};\\\", \\\"{x:214,y:637,t:1527009466375};\\\", \\\"{x:206,y:637,t:1527009466392};\\\", \\\"{x:198,y:634,t:1527009466410};\\\", \\\"{x:195,y:632,t:1527009466425};\\\", \\\"{x:193,y:631,t:1527009466443};\\\", \\\"{x:190,y:629,t:1527009466459};\\\", \\\"{x:184,y:629,t:1527009466475};\\\", \\\"{x:181,y:629,t:1527009466491};\\\", \\\"{x:180,y:629,t:1527009466509};\\\", \\\"{x:178,y:629,t:1527009466525};\\\", \\\"{x:178,y:630,t:1527009466734};\\\", \\\"{x:177,y:630,t:1527009466743};\\\", \\\"{x:179,y:630,t:1527009466887};\\\", \\\"{x:182,y:630,t:1527009466894};\\\", \\\"{x:186,y:629,t:1527009466909};\\\", \\\"{x:199,y:623,t:1527009466926};\\\", \\\"{x:218,y:615,t:1527009466941};\\\", \\\"{x:251,y:607,t:1527009466958};\\\", \\\"{x:276,y:605,t:1527009466976};\\\", \\\"{x:299,y:604,t:1527009466992};\\\", \\\"{x:318,y:604,t:1527009467009};\\\", \\\"{x:332,y:604,t:1527009467026};\\\", \\\"{x:339,y:604,t:1527009467043};\\\", \\\"{x:342,y:606,t:1527009467058};\\\", \\\"{x:343,y:607,t:1527009467076};\\\", \\\"{x:344,y:607,t:1527009467199};\\\", \\\"{x:346,y:607,t:1527009467208};\\\", \\\"{x:351,y:607,t:1527009467226};\\\", \\\"{x:365,y:605,t:1527009467242};\\\", \\\"{x:392,y:600,t:1527009467259};\\\", \\\"{x:434,y:600,t:1527009467275};\\\", \\\"{x:506,y:600,t:1527009467293};\\\", \\\"{x:590,y:598,t:1527009467308};\\\", \\\"{x:682,y:595,t:1527009467326};\\\", \\\"{x:769,y:595,t:1527009467343};\\\", \\\"{x:790,y:595,t:1527009467359};\\\", \\\"{x:796,y:595,t:1527009467375};\\\", \\\"{x:796,y:596,t:1527009467439};\\\", \\\"{x:796,y:598,t:1527009467447};\\\", \\\"{x:796,y:600,t:1527009467459};\\\", \\\"{x:795,y:603,t:1527009467476};\\\", \\\"{x:793,y:605,t:1527009467492};\\\", \\\"{x:790,y:608,t:1527009467508};\\\", \\\"{x:787,y:611,t:1527009467525};\\\", \\\"{x:784,y:614,t:1527009467543};\\\", \\\"{x:784,y:615,t:1527009467631};\\\", \\\"{x:787,y:615,t:1527009467642};\\\", \\\"{x:809,y:615,t:1527009467659};\\\", \\\"{x:832,y:615,t:1527009467676};\\\", \\\"{x:858,y:617,t:1527009467693};\\\", \\\"{x:880,y:619,t:1527009467710};\\\", \\\"{x:891,y:622,t:1527009467726};\\\", \\\"{x:892,y:623,t:1527009467742};\\\", \\\"{x:890,y:623,t:1527009467928};\\\", \\\"{x:886,y:623,t:1527009467942};\\\", \\\"{x:872,y:624,t:1527009467959};\\\", \\\"{x:863,y:626,t:1527009467977};\\\", \\\"{x:850,y:628,t:1527009467993};\\\", \\\"{x:839,y:629,t:1527009468010};\\\", \\\"{x:821,y:633,t:1527009468027};\\\", \\\"{x:802,y:639,t:1527009468043};\\\", \\\"{x:782,y:649,t:1527009468060};\\\", \\\"{x:762,y:660,t:1527009468076};\\\", \\\"{x:742,y:671,t:1527009468092};\\\", \\\"{x:723,y:679,t:1527009468110};\\\", \\\"{x:712,y:683,t:1527009468126};\\\", \\\"{x:711,y:683,t:1527009468142};\\\", \\\"{x:712,y:679,t:1527009468167};\\\", \\\"{x:721,y:670,t:1527009468177};\\\", \\\"{x:741,y:659,t:1527009468193};\\\", \\\"{x:779,y:647,t:1527009468209};\\\", \\\"{x:813,y:638,t:1527009468227};\\\", \\\"{x:826,y:637,t:1527009468243};\\\", \\\"{x:831,y:635,t:1527009468259};\\\", \\\"{x:833,y:635,t:1527009468287};\\\", \\\"{x:833,y:629,t:1527009468543};\\\", \\\"{x:833,y:627,t:1527009468561};\\\", \\\"{x:834,y:626,t:1527009468623};\\\", \\\"{x:835,y:625,t:1527009468950};\\\", \\\"{x:842,y:625,t:1527009469087};\\\", \\\"{x:852,y:631,t:1527009469095};\\\", \\\"{x:904,y:653,t:1527009469111};\\\", \\\"{x:987,y:674,t:1527009469127};\\\", \\\"{x:1087,y:688,t:1527009469143};\\\", \\\"{x:1198,y:692,t:1527009469160};\\\", \\\"{x:1317,y:692,t:1527009469177};\\\", \\\"{x:1436,y:692,t:1527009469194};\\\", \\\"{x:1531,y:693,t:1527009469211};\\\", \\\"{x:1593,y:697,t:1527009469227};\\\", \\\"{x:1618,y:697,t:1527009469244};\\\", \\\"{x:1625,y:697,t:1527009469261};\\\", \\\"{x:1626,y:697,t:1527009469406};\\\", \\\"{x:1629,y:697,t:1527009469422};\\\", \\\"{x:1631,y:697,t:1527009469430};\\\", \\\"{x:1634,y:696,t:1527009469443};\\\", \\\"{x:1643,y:694,t:1527009469461};\\\", \\\"{x:1651,y:694,t:1527009469477};\\\", \\\"{x:1654,y:694,t:1527009469494};\\\", \\\"{x:1655,y:694,t:1527009469511};\\\", \\\"{x:1654,y:696,t:1527009469551};\\\", \\\"{x:1650,y:698,t:1527009469561};\\\", \\\"{x:1645,y:702,t:1527009469578};\\\", \\\"{x:1635,y:706,t:1527009469593};\\\", \\\"{x:1621,y:708,t:1527009469610};\\\", \\\"{x:1611,y:708,t:1527009469627};\\\", \\\"{x:1604,y:708,t:1527009469644};\\\", \\\"{x:1600,y:705,t:1527009469661};\\\", \\\"{x:1599,y:702,t:1527009469678};\\\", \\\"{x:1599,y:700,t:1527009469694};\\\", \\\"{x:1599,y:696,t:1527009469711};\\\", \\\"{x:1604,y:691,t:1527009469728};\\\", \\\"{x:1621,y:686,t:1527009469744};\\\", \\\"{x:1638,y:681,t:1527009469761};\\\", \\\"{x:1650,y:678,t:1527009469778};\\\", \\\"{x:1653,y:677,t:1527009469794};\\\", \\\"{x:1655,y:677,t:1527009469811};\\\", \\\"{x:1656,y:677,t:1527009469831};\\\", \\\"{x:1656,y:679,t:1527009469845};\\\", \\\"{x:1655,y:682,t:1527009469861};\\\", \\\"{x:1651,y:686,t:1527009469878};\\\", \\\"{x:1647,y:691,t:1527009469895};\\\", \\\"{x:1642,y:692,t:1527009469911};\\\", \\\"{x:1636,y:694,t:1527009469928};\\\", \\\"{x:1634,y:694,t:1527009469945};\\\", \\\"{x:1631,y:696,t:1527009469961};\\\", \\\"{x:1629,y:696,t:1527009469978};\\\", \\\"{x:1628,y:696,t:1527009470072};\\\", \\\"{x:1627,y:696,t:1527009470095};\\\", \\\"{x:1626,y:696,t:1527009470152};\\\", \\\"{x:1626,y:695,t:1527009470184};\\\", \\\"{x:1624,y:695,t:1527009470200};\\\", \\\"{x:1624,y:694,t:1527009470212};\\\", \\\"{x:1623,y:694,t:1527009470229};\\\", \\\"{x:1621,y:694,t:1527009470296};\\\", \\\"{x:1622,y:694,t:1527009472070};\\\", \\\"{x:1623,y:694,t:1527009472087};\\\", \\\"{x:1624,y:694,t:1527009472424};\\\", \\\"{x:1626,y:694,t:1527009472447};\\\", \\\"{x:1627,y:695,t:1527009472592};\\\", \\\"{x:1634,y:695,t:1527009472600};\\\", \\\"{x:1641,y:695,t:1527009472613};\\\", \\\"{x:1657,y:695,t:1527009472631};\\\", \\\"{x:1675,y:695,t:1527009472646};\\\", \\\"{x:1690,y:695,t:1527009472664};\\\", \\\"{x:1695,y:695,t:1527009472680};\\\", \\\"{x:1697,y:695,t:1527009472696};\\\", \\\"{x:1702,y:695,t:1527009472714};\\\", \\\"{x:1710,y:695,t:1527009472731};\\\", \\\"{x:1723,y:695,t:1527009472747};\\\", \\\"{x:1731,y:695,t:1527009472763};\\\", \\\"{x:1736,y:695,t:1527009472780};\\\", \\\"{x:1738,y:695,t:1527009472816};\\\", \\\"{x:1739,y:695,t:1527009472992};\\\", \\\"{x:1741,y:695,t:1527009472999};\\\", \\\"{x:1742,y:695,t:1527009473016};\\\", \\\"{x:1744,y:695,t:1527009473056};\\\", \\\"{x:1737,y:695,t:1527009473254};\\\", \\\"{x:1718,y:695,t:1527009473263};\\\", \\\"{x:1618,y:695,t:1527009473280};\\\", \\\"{x:1488,y:694,t:1527009473297};\\\", \\\"{x:1322,y:691,t:1527009473313};\\\", \\\"{x:1147,y:682,t:1527009473329};\\\", \\\"{x:993,y:672,t:1527009473347};\\\", \\\"{x:884,y:668,t:1527009473363};\\\", \\\"{x:812,y:668,t:1527009473380};\\\", \\\"{x:784,y:668,t:1527009473397};\\\", \\\"{x:777,y:668,t:1527009473414};\\\", \\\"{x:779,y:668,t:1527009473454};\\\", \\\"{x:780,y:669,t:1527009473464};\\\", \\\"{x:781,y:672,t:1527009473480};\\\", \\\"{x:783,y:677,t:1527009473497};\\\", \\\"{x:783,y:681,t:1527009473514};\\\", \\\"{x:783,y:686,t:1527009473530};\\\", \\\"{x:778,y:694,t:1527009473547};\\\", \\\"{x:768,y:699,t:1527009473564};\\\", \\\"{x:755,y:704,t:1527009473580};\\\", \\\"{x:739,y:708,t:1527009473597};\\\", \\\"{x:722,y:713,t:1527009473613};\\\", \\\"{x:701,y:717,t:1527009473631};\\\", \\\"{x:663,y:725,t:1527009473647};\\\", \\\"{x:637,y:725,t:1527009473664};\\\", \\\"{x:605,y:725,t:1527009473680};\\\", \\\"{x:578,y:725,t:1527009473697};\\\", \\\"{x:551,y:725,t:1527009473715};\\\", \\\"{x:531,y:725,t:1527009473729};\\\", \\\"{x:514,y:725,t:1527009473747};\\\", \\\"{x:503,y:725,t:1527009473764};\\\", \\\"{x:497,y:725,t:1527009473779};\\\", \\\"{x:492,y:725,t:1527009473797};\\\", \\\"{x:489,y:725,t:1527009473813};\\\", \\\"{x:484,y:725,t:1527009473830};\\\", \\\"{x:471,y:725,t:1527009473847};\\\", \\\"{x:460,y:725,t:1527009473864};\\\", \\\"{x:445,y:725,t:1527009473880};\\\", \\\"{x:431,y:725,t:1527009473898};\\\", \\\"{x:427,y:725,t:1527009473914};\\\", \\\"{x:425,y:725,t:1527009474039};\\\", \\\"{x:424,y:726,t:1527009474071};\\\", \\\"{x:424,y:726,t:1527009474080};\\\", \\\"{x:424,y:727,t:1527009474098};\\\", \\\"{x:424,y:729,t:1527009474114};\\\", \\\"{x:426,y:730,t:1527009474131};\\\", \\\"{x:430,y:732,t:1527009474148};\\\", \\\"{x:436,y:734,t:1527009474165};\\\", \\\"{x:449,y:737,t:1527009474181};\\\", \\\"{x:466,y:742,t:1527009474198};\\\", \\\"{x:476,y:745,t:1527009474215};\\\", \\\"{x:473,y:745,t:1527009474361};\\\", \\\"{x:472,y:745,t:1527009474381};\\\", \\\"{x:470,y:745,t:1527009474398};\\\", \\\"{x:463,y:737,t:1527009474414};\\\", \\\"{x:459,y:728,t:1527009474431};\\\", \\\"{x:455,y:711,t:1527009474447};\\\", \\\"{x:447,y:681,t:1527009474465};\\\", \\\"{x:432,y:635,t:1527009474482};\\\", \\\"{x:420,y:585,t:1527009474497};\\\", \\\"{x:420,y:554,t:1527009474515};\\\", \\\"{x:420,y:514,t:1527009474532};\\\", \\\"{x:428,y:486,t:1527009474548};\\\", \\\"{x:449,y:446,t:1527009474565};\\\", \\\"{x:461,y:428,t:1527009474582};\\\", \\\"{x:464,y:424,t:1527009474597};\\\", \\\"{x:465,y:424,t:1527009474614};\\\" ] }, { \\\"rt\\\": 32141, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 653898, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -02 PM-02 PM-01 PM-12 PM-M -M -L -L -L -12 PM-12 PM-M -M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:484,t:1527009476087};\\\", \\\"{x:497,y:484,t:1527009476278};\\\", \\\"{x:495,y:484,t:1527009476287};\\\", \\\"{x:493,y:483,t:1527009476300};\\\", \\\"{x:490,y:482,t:1527009476316};\\\", \\\"{x:487,y:480,t:1527009476333};\\\", \\\"{x:485,y:480,t:1527009476350};\\\", \\\"{x:484,y:479,t:1527009476366};\\\", \\\"{x:480,y:477,t:1527009476383};\\\", \\\"{x:478,y:476,t:1527009476400};\\\", \\\"{x:477,y:476,t:1527009476416};\\\", \\\"{x:476,y:475,t:1527009476433};\\\", \\\"{x:476,y:473,t:1527009476450};\\\", \\\"{x:476,y:472,t:1527009476470};\\\", \\\"{x:476,y:471,t:1527009476494};\\\", \\\"{x:478,y:470,t:1527009476566};\\\", \\\"{x:497,y:470,t:1527009476583};\\\", \\\"{x:543,y:476,t:1527009476600};\\\", \\\"{x:628,y:482,t:1527009476618};\\\", \\\"{x:737,y:484,t:1527009476633};\\\", \\\"{x:861,y:484,t:1527009476651};\\\", \\\"{x:978,y:484,t:1527009476667};\\\", \\\"{x:1110,y:484,t:1527009476684};\\\", \\\"{x:1240,y:484,t:1527009476701};\\\", \\\"{x:1357,y:484,t:1527009476718};\\\", \\\"{x:1462,y:484,t:1527009476733};\\\", \\\"{x:1512,y:484,t:1527009476750};\\\", \\\"{x:1544,y:485,t:1527009476767};\\\", \\\"{x:1547,y:486,t:1527009476784};\\\", \\\"{x:1549,y:487,t:1527009476801};\\\", \\\"{x:1549,y:488,t:1527009476823};\\\", \\\"{x:1548,y:488,t:1527009476847};\\\", \\\"{x:1548,y:489,t:1527009476920};\\\", \\\"{x:1547,y:490,t:1527009476934};\\\", \\\"{x:1545,y:495,t:1527009476950};\\\", \\\"{x:1531,y:517,t:1527009476967};\\\", \\\"{x:1519,y:536,t:1527009476985};\\\", \\\"{x:1508,y:561,t:1527009477000};\\\", \\\"{x:1499,y:584,t:1527009477017};\\\", \\\"{x:1486,y:603,t:1527009477034};\\\", \\\"{x:1476,y:617,t:1527009477051};\\\", \\\"{x:1468,y:625,t:1527009477068};\\\", \\\"{x:1462,y:632,t:1527009477085};\\\", \\\"{x:1459,y:636,t:1527009477100};\\\", \\\"{x:1457,y:639,t:1527009477118};\\\", \\\"{x:1455,y:639,t:1527009477191};\\\", \\\"{x:1450,y:635,t:1527009477200};\\\", \\\"{x:1446,y:630,t:1527009477217};\\\", \\\"{x:1446,y:625,t:1527009477233};\\\", \\\"{x:1446,y:617,t:1527009477250};\\\", \\\"{x:1445,y:603,t:1527009477268};\\\", \\\"{x:1445,y:591,t:1527009477284};\\\", \\\"{x:1444,y:571,t:1527009477300};\\\", \\\"{x:1440,y:548,t:1527009477317};\\\", \\\"{x:1437,y:522,t:1527009477334};\\\", \\\"{x:1437,y:484,t:1527009477350};\\\", \\\"{x:1437,y:416,t:1527009477367};\\\", \\\"{x:1440,y:388,t:1527009477384};\\\", \\\"{x:1441,y:374,t:1527009477402};\\\", \\\"{x:1443,y:367,t:1527009477417};\\\", \\\"{x:1443,y:366,t:1527009477434};\\\", \\\"{x:1447,y:370,t:1527009477615};\\\", \\\"{x:1451,y:377,t:1527009477623};\\\", \\\"{x:1456,y:384,t:1527009477634};\\\", \\\"{x:1461,y:394,t:1527009477651};\\\", \\\"{x:1465,y:403,t:1527009477667};\\\", \\\"{x:1471,y:406,t:1527009477684};\\\", \\\"{x:1483,y:407,t:1527009477701};\\\", \\\"{x:1505,y:409,t:1527009477717};\\\", \\\"{x:1530,y:409,t:1527009477734};\\\", \\\"{x:1557,y:409,t:1527009477750};\\\", \\\"{x:1565,y:411,t:1527009477767};\\\", \\\"{x:1567,y:412,t:1527009477784};\\\", \\\"{x:1569,y:414,t:1527009477801};\\\", \\\"{x:1569,y:417,t:1527009477818};\\\", \\\"{x:1569,y:423,t:1527009477834};\\\", \\\"{x:1569,y:432,t:1527009477851};\\\", \\\"{x:1568,y:442,t:1527009477868};\\\", \\\"{x:1563,y:451,t:1527009477884};\\\", \\\"{x:1555,y:459,t:1527009477901};\\\", \\\"{x:1547,y:465,t:1527009477918};\\\", \\\"{x:1540,y:467,t:1527009477934};\\\", \\\"{x:1534,y:467,t:1527009477951};\\\", \\\"{x:1531,y:467,t:1527009477968};\\\", \\\"{x:1530,y:467,t:1527009477984};\\\", \\\"{x:1528,y:466,t:1527009478002};\\\", \\\"{x:1526,y:458,t:1527009478018};\\\", \\\"{x:1522,y:438,t:1527009478034};\\\", \\\"{x:1516,y:408,t:1527009478051};\\\", \\\"{x:1515,y:386,t:1527009478068};\\\", \\\"{x:1515,y:373,t:1527009478084};\\\", \\\"{x:1515,y:368,t:1527009478101};\\\", \\\"{x:1515,y:377,t:1527009478143};\\\", \\\"{x:1519,y:397,t:1527009478151};\\\", \\\"{x:1535,y:473,t:1527009478168};\\\", \\\"{x:1553,y:577,t:1527009478184};\\\", \\\"{x:1567,y:668,t:1527009478201};\\\", \\\"{x:1569,y:744,t:1527009478218};\\\", \\\"{x:1569,y:797,t:1527009478235};\\\", \\\"{x:1568,y:840,t:1527009478251};\\\", \\\"{x:1558,y:871,t:1527009478268};\\\", \\\"{x:1546,y:891,t:1527009478284};\\\", \\\"{x:1531,y:909,t:1527009478301};\\\", \\\"{x:1516,y:930,t:1527009478318};\\\", \\\"{x:1491,y:960,t:1527009478335};\\\", \\\"{x:1477,y:977,t:1527009478351};\\\", \\\"{x:1468,y:987,t:1527009478369};\\\", \\\"{x:1464,y:993,t:1527009478385};\\\", \\\"{x:1464,y:996,t:1527009478401};\\\", \\\"{x:1464,y:999,t:1527009478418};\\\", \\\"{x:1463,y:1004,t:1527009478435};\\\", \\\"{x:1462,y:1006,t:1527009478452};\\\", \\\"{x:1460,y:1009,t:1527009478468};\\\", \\\"{x:1458,y:1009,t:1527009478485};\\\", \\\"{x:1456,y:1009,t:1527009478501};\\\", \\\"{x:1452,y:1009,t:1527009478518};\\\", \\\"{x:1451,y:1009,t:1527009478536};\\\", \\\"{x:1449,y:1009,t:1527009478551};\\\", \\\"{x:1447,y:1007,t:1527009478569};\\\", \\\"{x:1447,y:1002,t:1527009478585};\\\", \\\"{x:1447,y:997,t:1527009478601};\\\", \\\"{x:1449,y:991,t:1527009478618};\\\", \\\"{x:1454,y:984,t:1527009478636};\\\", \\\"{x:1465,y:977,t:1527009478652};\\\", \\\"{x:1478,y:972,t:1527009478668};\\\", \\\"{x:1486,y:970,t:1527009478685};\\\", \\\"{x:1489,y:970,t:1527009478702};\\\", \\\"{x:1488,y:970,t:1527009478768};\\\", \\\"{x:1484,y:971,t:1527009478785};\\\", \\\"{x:1479,y:972,t:1527009478803};\\\", \\\"{x:1470,y:973,t:1527009478818};\\\", \\\"{x:1455,y:973,t:1527009478837};\\\", \\\"{x:1438,y:973,t:1527009478852};\\\", \\\"{x:1421,y:973,t:1527009478869};\\\", \\\"{x:1411,y:973,t:1527009478886};\\\", \\\"{x:1404,y:973,t:1527009478903};\\\", \\\"{x:1403,y:973,t:1527009478919};\\\", \\\"{x:1402,y:973,t:1527009478944};\\\", \\\"{x:1401,y:973,t:1527009478953};\\\", \\\"{x:1400,y:973,t:1527009478969};\\\", \\\"{x:1397,y:973,t:1527009478985};\\\", \\\"{x:1392,y:973,t:1527009479002};\\\", \\\"{x:1386,y:973,t:1527009479019};\\\", \\\"{x:1377,y:973,t:1527009479035};\\\", \\\"{x:1374,y:971,t:1527009479052};\\\", \\\"{x:1369,y:971,t:1527009479068};\\\", \\\"{x:1368,y:969,t:1527009479085};\\\", \\\"{x:1368,y:968,t:1527009479143};\\\", \\\"{x:1368,y:966,t:1527009479166};\\\", \\\"{x:1368,y:965,t:1527009479183};\\\", \\\"{x:1368,y:963,t:1527009479198};\\\", \\\"{x:1368,y:961,t:1527009479206};\\\", \\\"{x:1365,y:959,t:1527009479222};\\\", \\\"{x:1365,y:958,t:1527009479238};\\\", \\\"{x:1362,y:958,t:1527009479252};\\\", \\\"{x:1359,y:958,t:1527009479269};\\\", \\\"{x:1357,y:958,t:1527009479285};\\\", \\\"{x:1356,y:958,t:1527009479310};\\\", \\\"{x:1355,y:958,t:1527009479399};\\\", \\\"{x:1355,y:957,t:1527009479479};\\\", \\\"{x:1355,y:956,t:1527009479494};\\\", \\\"{x:1355,y:955,t:1527009479502};\\\", \\\"{x:1355,y:954,t:1527009479527};\\\", \\\"{x:1355,y:951,t:1527009479536};\\\", \\\"{x:1356,y:949,t:1527009479552};\\\", \\\"{x:1356,y:947,t:1527009479570};\\\", \\\"{x:1357,y:943,t:1527009479587};\\\", \\\"{x:1359,y:939,t:1527009479603};\\\", \\\"{x:1362,y:934,t:1527009479620};\\\", \\\"{x:1365,y:929,t:1527009479636};\\\", \\\"{x:1368,y:922,t:1527009479652};\\\", \\\"{x:1374,y:913,t:1527009479670};\\\", \\\"{x:1378,y:907,t:1527009479687};\\\", \\\"{x:1380,y:904,t:1527009479703};\\\", \\\"{x:1387,y:897,t:1527009479720};\\\", \\\"{x:1388,y:896,t:1527009479736};\\\", \\\"{x:1389,y:895,t:1527009479752};\\\", \\\"{x:1389,y:893,t:1527009479807};\\\", \\\"{x:1388,y:893,t:1527009480528};\\\", \\\"{x:1386,y:894,t:1527009480726};\\\", \\\"{x:1385,y:894,t:1527009480759};\\\", \\\"{x:1383,y:894,t:1527009480775};\\\", \\\"{x:1382,y:894,t:1527009480790};\\\", \\\"{x:1382,y:893,t:1527009481583};\\\", \\\"{x:1382,y:892,t:1527009481598};\\\", \\\"{x:1382,y:889,t:1527009481607};\\\", \\\"{x:1383,y:886,t:1527009481621};\\\", \\\"{x:1390,y:873,t:1527009481637};\\\", \\\"{x:1404,y:852,t:1527009481654};\\\", \\\"{x:1411,y:834,t:1527009481670};\\\", \\\"{x:1424,y:799,t:1527009481687};\\\", \\\"{x:1438,y:774,t:1527009481704};\\\", \\\"{x:1453,y:749,t:1527009481721};\\\", \\\"{x:1467,y:719,t:1527009481737};\\\", \\\"{x:1489,y:674,t:1527009481754};\\\", \\\"{x:1511,y:636,t:1527009481771};\\\", \\\"{x:1534,y:600,t:1527009481787};\\\", \\\"{x:1552,y:578,t:1527009481804};\\\", \\\"{x:1564,y:563,t:1527009481821};\\\", \\\"{x:1571,y:554,t:1527009481838};\\\", \\\"{x:1573,y:552,t:1527009481854};\\\", \\\"{x:1575,y:547,t:1527009481895};\\\", \\\"{x:1575,y:544,t:1527009481904};\\\", \\\"{x:1582,y:528,t:1527009481921};\\\", \\\"{x:1590,y:514,t:1527009481937};\\\", \\\"{x:1596,y:504,t:1527009481954};\\\", \\\"{x:1600,y:499,t:1527009481971};\\\", \\\"{x:1600,y:496,t:1527009481987};\\\", \\\"{x:1600,y:495,t:1527009482110};\\\", \\\"{x:1600,y:494,t:1527009482126};\\\", \\\"{x:1600,y:493,t:1527009482137};\\\", \\\"{x:1600,y:492,t:1527009482154};\\\", \\\"{x:1600,y:491,t:1527009482171};\\\", \\\"{x:1600,y:490,t:1527009482188};\\\", \\\"{x:1600,y:489,t:1527009482207};\\\", \\\"{x:1599,y:489,t:1527009482366};\\\", \\\"{x:1598,y:490,t:1527009482374};\\\", \\\"{x:1597,y:490,t:1527009482415};\\\", \\\"{x:1596,y:490,t:1527009482423};\\\", \\\"{x:1595,y:490,t:1527009482446};\\\", \\\"{x:1594,y:490,t:1527009482455};\\\", \\\"{x:1592,y:490,t:1527009482471};\\\", \\\"{x:1589,y:490,t:1527009482489};\\\", \\\"{x:1586,y:490,t:1527009482504};\\\", \\\"{x:1584,y:490,t:1527009482521};\\\", \\\"{x:1583,y:490,t:1527009482543};\\\", \\\"{x:1582,y:490,t:1527009482554};\\\", \\\"{x:1582,y:491,t:1527009482688};\\\", \\\"{x:1583,y:496,t:1527009482704};\\\", \\\"{x:1584,y:498,t:1527009482721};\\\", \\\"{x:1584,y:500,t:1527009482738};\\\", \\\"{x:1585,y:501,t:1527009482756};\\\", \\\"{x:1585,y:502,t:1527009482772};\\\", \\\"{x:1584,y:502,t:1527009483518};\\\", \\\"{x:1583,y:501,t:1527009483551};\\\", \\\"{x:1582,y:500,t:1527009483574};\\\", \\\"{x:1581,y:500,t:1527009483591};\\\", \\\"{x:1581,y:499,t:1527009483606};\\\", \\\"{x:1580,y:499,t:1527009483631};\\\", \\\"{x:1578,y:497,t:1527009483662};\\\", \\\"{x:1577,y:496,t:1527009483718};\\\", \\\"{x:1570,y:497,t:1527009489183};\\\", \\\"{x:1563,y:498,t:1527009489194};\\\", \\\"{x:1548,y:499,t:1527009489210};\\\", \\\"{x:1526,y:503,t:1527009489226};\\\", \\\"{x:1511,y:505,t:1527009489244};\\\", \\\"{x:1504,y:506,t:1527009489260};\\\", \\\"{x:1503,y:506,t:1527009489277};\\\", \\\"{x:1502,y:506,t:1527009489294};\\\", \\\"{x:1501,y:506,t:1527009489311};\\\", \\\"{x:1499,y:506,t:1527009489326};\\\", \\\"{x:1499,y:505,t:1527009489543};\\\", \\\"{x:1499,y:504,t:1527009489551};\\\", \\\"{x:1499,y:503,t:1527009489566};\\\", \\\"{x:1500,y:503,t:1527009489590};\\\", \\\"{x:1502,y:503,t:1527009489623};\\\", \\\"{x:1503,y:503,t:1527009489824};\\\", \\\"{x:1503,y:502,t:1527009489840};\\\", \\\"{x:1503,y:501,t:1527009489847};\\\", \\\"{x:1501,y:500,t:1527009489864};\\\", \\\"{x:1499,y:500,t:1527009489880};\\\", \\\"{x:1496,y:499,t:1527009489895};\\\", \\\"{x:1492,y:497,t:1527009489911};\\\", \\\"{x:1490,y:497,t:1527009489927};\\\", \\\"{x:1489,y:497,t:1527009489944};\\\", \\\"{x:1488,y:497,t:1527009489961};\\\", \\\"{x:1486,y:495,t:1527009489978};\\\", \\\"{x:1484,y:494,t:1527009489994};\\\", \\\"{x:1483,y:494,t:1527009490011};\\\", \\\"{x:1481,y:494,t:1527009490028};\\\", \\\"{x:1480,y:493,t:1527009490044};\\\", \\\"{x:1477,y:493,t:1527009490061};\\\", \\\"{x:1474,y:493,t:1527009490077};\\\", \\\"{x:1473,y:493,t:1527009490095};\\\", \\\"{x:1471,y:493,t:1527009490110};\\\", \\\"{x:1470,y:493,t:1527009490127};\\\", \\\"{x:1468,y:493,t:1527009490145};\\\", \\\"{x:1467,y:493,t:1527009490160};\\\", \\\"{x:1466,y:493,t:1527009490178};\\\", \\\"{x:1465,y:493,t:1527009490194};\\\", \\\"{x:1464,y:493,t:1527009490211};\\\", \\\"{x:1463,y:493,t:1527009490227};\\\", \\\"{x:1462,y:493,t:1527009490246};\\\", \\\"{x:1461,y:493,t:1527009490263};\\\", \\\"{x:1459,y:493,t:1527009490278};\\\", \\\"{x:1450,y:493,t:1527009490295};\\\", \\\"{x:1435,y:496,t:1527009490311};\\\", \\\"{x:1423,y:496,t:1527009490328};\\\", \\\"{x:1409,y:497,t:1527009490345};\\\", \\\"{x:1396,y:498,t:1527009490360};\\\", \\\"{x:1386,y:500,t:1527009490377};\\\", \\\"{x:1379,y:500,t:1527009490395};\\\", \\\"{x:1375,y:500,t:1527009490411};\\\", \\\"{x:1374,y:500,t:1527009490638};\\\", \\\"{x:1372,y:500,t:1527009490646};\\\", \\\"{x:1368,y:500,t:1527009490662};\\\", \\\"{x:1353,y:500,t:1527009490678};\\\", \\\"{x:1331,y:500,t:1527009490694};\\\", \\\"{x:1319,y:500,t:1527009490712};\\\", \\\"{x:1314,y:500,t:1527009490727};\\\", \\\"{x:1313,y:500,t:1527009491558};\\\", \\\"{x:1313,y:501,t:1527009491607};\\\", \\\"{x:1314,y:501,t:1527009491654};\\\", \\\"{x:1315,y:501,t:1527009491734};\\\", \\\"{x:1316,y:501,t:1527009491746};\\\", \\\"{x:1317,y:501,t:1527009491762};\\\", \\\"{x:1319,y:503,t:1527009491779};\\\", \\\"{x:1323,y:503,t:1527009491796};\\\", \\\"{x:1340,y:508,t:1527009491812};\\\", \\\"{x:1363,y:511,t:1527009491829};\\\", \\\"{x:1394,y:516,t:1527009491846};\\\", \\\"{x:1423,y:521,t:1527009491862};\\\", \\\"{x:1484,y:530,t:1527009491878};\\\", \\\"{x:1510,y:533,t:1527009491896};\\\", \\\"{x:1519,y:535,t:1527009491912};\\\", \\\"{x:1524,y:537,t:1527009491928};\\\", \\\"{x:1525,y:537,t:1527009491951};\\\", \\\"{x:1525,y:538,t:1527009492015};\\\", \\\"{x:1526,y:540,t:1527009492030};\\\", \\\"{x:1528,y:551,t:1527009492047};\\\", \\\"{x:1530,y:609,t:1527009492063};\\\", \\\"{x:1530,y:659,t:1527009492079};\\\", \\\"{x:1530,y:704,t:1527009492096};\\\", \\\"{x:1530,y:751,t:1527009492113};\\\", \\\"{x:1526,y:806,t:1527009492129};\\\", \\\"{x:1516,y:853,t:1527009492146};\\\", \\\"{x:1506,y:891,t:1527009492162};\\\", \\\"{x:1498,y:910,t:1527009492178};\\\", \\\"{x:1491,y:921,t:1527009492196};\\\", \\\"{x:1488,y:925,t:1527009492212};\\\", \\\"{x:1488,y:926,t:1527009492229};\\\", \\\"{x:1487,y:927,t:1527009492246};\\\", \\\"{x:1486,y:928,t:1527009492271};\\\", \\\"{x:1484,y:928,t:1527009492286};\\\", \\\"{x:1481,y:927,t:1527009492296};\\\", \\\"{x:1474,y:921,t:1527009492312};\\\", \\\"{x:1470,y:918,t:1527009492330};\\\", \\\"{x:1469,y:917,t:1527009492346};\\\", \\\"{x:1468,y:917,t:1527009492363};\\\", \\\"{x:1467,y:917,t:1527009492380};\\\", \\\"{x:1464,y:918,t:1527009492396};\\\", \\\"{x:1460,y:921,t:1527009492413};\\\", \\\"{x:1453,y:929,t:1527009492430};\\\", \\\"{x:1443,y:937,t:1527009492446};\\\", \\\"{x:1433,y:943,t:1527009492462};\\\", \\\"{x:1432,y:944,t:1527009492479};\\\", \\\"{x:1430,y:946,t:1527009492831};\\\", \\\"{x:1429,y:946,t:1527009492846};\\\", \\\"{x:1410,y:956,t:1527009492864};\\\", \\\"{x:1387,y:962,t:1527009492880};\\\", \\\"{x:1356,y:966,t:1527009492897};\\\", \\\"{x:1330,y:971,t:1527009492913};\\\", \\\"{x:1314,y:973,t:1527009492931};\\\", \\\"{x:1311,y:973,t:1527009492947};\\\", \\\"{x:1310,y:973,t:1527009492963};\\\", \\\"{x:1309,y:972,t:1527009493247};\\\", \\\"{x:1308,y:972,t:1527009493264};\\\", \\\"{x:1308,y:971,t:1527009493344};\\\", \\\"{x:1309,y:969,t:1527009493351};\\\", \\\"{x:1312,y:967,t:1527009493365};\\\", \\\"{x:1316,y:963,t:1527009493381};\\\", \\\"{x:1324,y:958,t:1527009493397};\\\", \\\"{x:1333,y:955,t:1527009493413};\\\", \\\"{x:1340,y:954,t:1527009493430};\\\", \\\"{x:1343,y:954,t:1527009493447};\\\", \\\"{x:1344,y:954,t:1527009493494};\\\", \\\"{x:1346,y:954,t:1527009493510};\\\", \\\"{x:1347,y:954,t:1527009493550};\\\", \\\"{x:1348,y:955,t:1527009493591};\\\", \\\"{x:1349,y:955,t:1527009493606};\\\", \\\"{x:1350,y:957,t:1527009493622};\\\", \\\"{x:1351,y:957,t:1527009493630};\\\", \\\"{x:1351,y:961,t:1527009493647};\\\", \\\"{x:1351,y:964,t:1527009493664};\\\", \\\"{x:1351,y:967,t:1527009493681};\\\", \\\"{x:1351,y:968,t:1527009493697};\\\", \\\"{x:1351,y:969,t:1527009493714};\\\", \\\"{x:1353,y:970,t:1527009494174};\\\", \\\"{x:1353,y:971,t:1527009495710};\\\", \\\"{x:1353,y:970,t:1527009496055};\\\", \\\"{x:1351,y:969,t:1527009496111};\\\", \\\"{x:1350,y:968,t:1527009496152};\\\", \\\"{x:1349,y:967,t:1527009496184};\\\", \\\"{x:1348,y:967,t:1527009496231};\\\", \\\"{x:1346,y:965,t:1527009496320};\\\", \\\"{x:1344,y:965,t:1527009497839};\\\", \\\"{x:1336,y:965,t:1527009497850};\\\", \\\"{x:1310,y:962,t:1527009497867};\\\", \\\"{x:1271,y:962,t:1527009497884};\\\", \\\"{x:1219,y:957,t:1527009497900};\\\", \\\"{x:1171,y:950,t:1527009497917};\\\", \\\"{x:1128,y:944,t:1527009497935};\\\", \\\"{x:1121,y:943,t:1527009497951};\\\", \\\"{x:1113,y:942,t:1527009497967};\\\", \\\"{x:1113,y:940,t:1527009498046};\\\", \\\"{x:1116,y:940,t:1527009498063};\\\", \\\"{x:1117,y:940,t:1527009498071};\\\", \\\"{x:1118,y:940,t:1527009498084};\\\", \\\"{x:1119,y:940,t:1527009498101};\\\", \\\"{x:1123,y:940,t:1527009498117};\\\", \\\"{x:1131,y:940,t:1527009498134};\\\", \\\"{x:1134,y:940,t:1527009498151};\\\", \\\"{x:1134,y:941,t:1527009498215};\\\", \\\"{x:1134,y:943,t:1527009498223};\\\", \\\"{x:1131,y:945,t:1527009498234};\\\", \\\"{x:1124,y:948,t:1527009498251};\\\", \\\"{x:1117,y:949,t:1527009498267};\\\", \\\"{x:1112,y:952,t:1527009498284};\\\", \\\"{x:1109,y:953,t:1527009498301};\\\", \\\"{x:1107,y:953,t:1527009498318};\\\", \\\"{x:1106,y:953,t:1527009498374};\\\", \\\"{x:1103,y:953,t:1527009498390};\\\", \\\"{x:1102,y:953,t:1527009498401};\\\", \\\"{x:1100,y:953,t:1527009498417};\\\", \\\"{x:1102,y:953,t:1527009498654};\\\", \\\"{x:1103,y:953,t:1527009498670};\\\", \\\"{x:1105,y:953,t:1527009498684};\\\", \\\"{x:1110,y:953,t:1527009498700};\\\", \\\"{x:1115,y:953,t:1527009498718};\\\", \\\"{x:1118,y:953,t:1527009498733};\\\", \\\"{x:1123,y:954,t:1527009498751};\\\", \\\"{x:1125,y:954,t:1527009498767};\\\", \\\"{x:1128,y:955,t:1527009498784};\\\", \\\"{x:1130,y:955,t:1527009498801};\\\", \\\"{x:1131,y:956,t:1527009498818};\\\", \\\"{x:1134,y:957,t:1527009498833};\\\", \\\"{x:1136,y:957,t:1527009498851};\\\", \\\"{x:1140,y:959,t:1527009498868};\\\", \\\"{x:1144,y:959,t:1527009498885};\\\", \\\"{x:1147,y:959,t:1527009498901};\\\", \\\"{x:1148,y:960,t:1527009498918};\\\", \\\"{x:1149,y:960,t:1527009498934};\\\", \\\"{x:1151,y:961,t:1527009498951};\\\", \\\"{x:1151,y:962,t:1527009498968};\\\", \\\"{x:1152,y:962,t:1527009499086};\\\", \\\"{x:1153,y:962,t:1527009499101};\\\", \\\"{x:1155,y:962,t:1527009499118};\\\", \\\"{x:1162,y:962,t:1527009499134};\\\", \\\"{x:1169,y:962,t:1527009499151};\\\", \\\"{x:1182,y:962,t:1527009499168};\\\", \\\"{x:1197,y:962,t:1527009499185};\\\", \\\"{x:1215,y:962,t:1527009499202};\\\", \\\"{x:1228,y:962,t:1527009499218};\\\", \\\"{x:1234,y:962,t:1527009499235};\\\", \\\"{x:1236,y:962,t:1527009499250};\\\", \\\"{x:1237,y:963,t:1527009499268};\\\", \\\"{x:1240,y:963,t:1527009499575};\\\", \\\"{x:1246,y:963,t:1527009499585};\\\", \\\"{x:1254,y:963,t:1527009499602};\\\", \\\"{x:1261,y:963,t:1527009499618};\\\", \\\"{x:1269,y:963,t:1527009499635};\\\", \\\"{x:1272,y:963,t:1527009499652};\\\", \\\"{x:1273,y:964,t:1527009499668};\\\", \\\"{x:1274,y:964,t:1527009499686};\\\", \\\"{x:1275,y:964,t:1527009499702};\\\", \\\"{x:1277,y:964,t:1527009500007};\\\", \\\"{x:1281,y:964,t:1527009500019};\\\", \\\"{x:1296,y:964,t:1527009500036};\\\", \\\"{x:1310,y:964,t:1527009500052};\\\", \\\"{x:1318,y:966,t:1527009500069};\\\", \\\"{x:1321,y:966,t:1527009500085};\\\", \\\"{x:1322,y:966,t:1527009500118};\\\", \\\"{x:1323,y:966,t:1527009500206};\\\", \\\"{x:1325,y:966,t:1527009500219};\\\", \\\"{x:1331,y:966,t:1527009500235};\\\", \\\"{x:1337,y:966,t:1527009500252};\\\", \\\"{x:1343,y:966,t:1527009500269};\\\", \\\"{x:1345,y:966,t:1527009500285};\\\", \\\"{x:1346,y:966,t:1527009500302};\\\", \\\"{x:1347,y:966,t:1527009500366};\\\", \\\"{x:1348,y:966,t:1527009500422};\\\", \\\"{x:1349,y:966,t:1527009500436};\\\", \\\"{x:1353,y:966,t:1527009500452};\\\", \\\"{x:1357,y:966,t:1527009500469};\\\", \\\"{x:1370,y:965,t:1527009500486};\\\", \\\"{x:1373,y:965,t:1527009500502};\\\", \\\"{x:1374,y:965,t:1527009500519};\\\", \\\"{x:1376,y:965,t:1527009500537};\\\", \\\"{x:1377,y:965,t:1527009500671};\\\", \\\"{x:1379,y:965,t:1527009500694};\\\", \\\"{x:1380,y:965,t:1527009500726};\\\", \\\"{x:1381,y:964,t:1527009501599};\\\", \\\"{x:1381,y:962,t:1527009501639};\\\", \\\"{x:1381,y:958,t:1527009501654};\\\", \\\"{x:1381,y:930,t:1527009501671};\\\", \\\"{x:1381,y:901,t:1527009501687};\\\", \\\"{x:1381,y:850,t:1527009501704};\\\", \\\"{x:1372,y:785,t:1527009501721};\\\", \\\"{x:1361,y:739,t:1527009501737};\\\", \\\"{x:1361,y:725,t:1527009501753};\\\", \\\"{x:1362,y:724,t:1527009501770};\\\", \\\"{x:1363,y:724,t:1527009501790};\\\", \\\"{x:1370,y:730,t:1527009501803};\\\", \\\"{x:1378,y:757,t:1527009501820};\\\", \\\"{x:1387,y:789,t:1527009501837};\\\", \\\"{x:1395,y:817,t:1527009501853};\\\", \\\"{x:1401,y:840,t:1527009501870};\\\", \\\"{x:1404,y:847,t:1527009501887};\\\", \\\"{x:1404,y:851,t:1527009501903};\\\", \\\"{x:1405,y:853,t:1527009501920};\\\", \\\"{x:1405,y:858,t:1527009501938};\\\", \\\"{x:1405,y:870,t:1527009501953};\\\", \\\"{x:1405,y:879,t:1527009501970};\\\", \\\"{x:1402,y:893,t:1527009501988};\\\", \\\"{x:1399,y:899,t:1527009502004};\\\", \\\"{x:1398,y:903,t:1527009502020};\\\", \\\"{x:1397,y:905,t:1527009502037};\\\", \\\"{x:1397,y:906,t:1527009502062};\\\", \\\"{x:1397,y:907,t:1527009502094};\\\", \\\"{x:1396,y:909,t:1527009502118};\\\", \\\"{x:1395,y:909,t:1527009502126};\\\", \\\"{x:1394,y:909,t:1527009502159};\\\", \\\"{x:1393,y:909,t:1527009502175};\\\", \\\"{x:1391,y:909,t:1527009502187};\\\", \\\"{x:1389,y:908,t:1527009502204};\\\", \\\"{x:1388,y:907,t:1527009502220};\\\", \\\"{x:1387,y:907,t:1527009502238};\\\", \\\"{x:1385,y:906,t:1527009502270};\\\", \\\"{x:1384,y:905,t:1527009502294};\\\", \\\"{x:1384,y:904,t:1527009502310};\\\", \\\"{x:1383,y:904,t:1527009502350};\\\", \\\"{x:1382,y:903,t:1527009502407};\\\", \\\"{x:1382,y:900,t:1527009502421};\\\", \\\"{x:1382,y:887,t:1527009502438};\\\", \\\"{x:1415,y:812,t:1527009502454};\\\", \\\"{x:1453,y:714,t:1527009502471};\\\", \\\"{x:1497,y:607,t:1527009502487};\\\", \\\"{x:1535,y:539,t:1527009502504};\\\", \\\"{x:1554,y:509,t:1527009502521};\\\", \\\"{x:1560,y:498,t:1527009502538};\\\", \\\"{x:1560,y:497,t:1527009502656};\\\", \\\"{x:1565,y:487,t:1527009502672};\\\", \\\"{x:1571,y:477,t:1527009502689};\\\", \\\"{x:1575,y:472,t:1527009502705};\\\", \\\"{x:1577,y:470,t:1527009502721};\\\", \\\"{x:1579,y:468,t:1527009502737};\\\", \\\"{x:1580,y:468,t:1527009502862};\\\", \\\"{x:1581,y:471,t:1527009502879};\\\", \\\"{x:1583,y:475,t:1527009502887};\\\", \\\"{x:1584,y:489,t:1527009502905};\\\", \\\"{x:1584,y:507,t:1527009502921};\\\", \\\"{x:1584,y:530,t:1527009502938};\\\", \\\"{x:1581,y:557,t:1527009502954};\\\", \\\"{x:1574,y:581,t:1527009502971};\\\", \\\"{x:1566,y:607,t:1527009502988};\\\", \\\"{x:1557,y:636,t:1527009503004};\\\", \\\"{x:1541,y:667,t:1527009503021};\\\", \\\"{x:1526,y:701,t:1527009503039};\\\", \\\"{x:1512,y:722,t:1527009503054};\\\", \\\"{x:1502,y:736,t:1527009503071};\\\", \\\"{x:1497,y:744,t:1527009503088};\\\", \\\"{x:1494,y:748,t:1527009503104};\\\", \\\"{x:1493,y:750,t:1527009503121};\\\", \\\"{x:1493,y:744,t:1527009503422};\\\", \\\"{x:1499,y:724,t:1527009503437};\\\", \\\"{x:1512,y:682,t:1527009503455};\\\", \\\"{x:1547,y:597,t:1527009503471};\\\", \\\"{x:1604,y:501,t:1527009503488};\\\", \\\"{x:1663,y:425,t:1527009503504};\\\", \\\"{x:1713,y:362,t:1527009503521};\\\", \\\"{x:1733,y:338,t:1527009503538};\\\", \\\"{x:1740,y:331,t:1527009503555};\\\", \\\"{x:1738,y:335,t:1527009503590};\\\", \\\"{x:1732,y:345,t:1527009503605};\\\", \\\"{x:1722,y:370,t:1527009503621};\\\", \\\"{x:1693,y:434,t:1527009503638};\\\", \\\"{x:1667,y:497,t:1527009503655};\\\", \\\"{x:1633,y:562,t:1527009503671};\\\", \\\"{x:1597,y:615,t:1527009503688};\\\", \\\"{x:1556,y:659,t:1527009503705};\\\", \\\"{x:1528,y:694,t:1527009503721};\\\", \\\"{x:1505,y:720,t:1527009503738};\\\", \\\"{x:1490,y:736,t:1527009503755};\\\", \\\"{x:1482,y:744,t:1527009503773};\\\", \\\"{x:1482,y:745,t:1527009503789};\\\", \\\"{x:1482,y:746,t:1527009503805};\\\", \\\"{x:1483,y:749,t:1527009503823};\\\", \\\"{x:1483,y:756,t:1527009503838};\\\", \\\"{x:1481,y:767,t:1527009503855};\\\", \\\"{x:1473,y:778,t:1527009503873};\\\", \\\"{x:1462,y:792,t:1527009503889};\\\", \\\"{x:1445,y:810,t:1527009503906};\\\", \\\"{x:1430,y:829,t:1527009503923};\\\", \\\"{x:1414,y:851,t:1527009503939};\\\", \\\"{x:1403,y:866,t:1527009503956};\\\", \\\"{x:1396,y:879,t:1527009503972};\\\", \\\"{x:1392,y:884,t:1527009503988};\\\", \\\"{x:1392,y:885,t:1527009504087};\\\", \\\"{x:1392,y:886,t:1527009504110};\\\", \\\"{x:1393,y:886,t:1527009504126};\\\", \\\"{x:1393,y:887,t:1527009504138};\\\", \\\"{x:1393,y:892,t:1527009504155};\\\", \\\"{x:1393,y:900,t:1527009504172};\\\", \\\"{x:1389,y:911,t:1527009504188};\\\", \\\"{x:1383,y:921,t:1527009504205};\\\", \\\"{x:1380,y:927,t:1527009504222};\\\", \\\"{x:1379,y:928,t:1527009504239};\\\", \\\"{x:1379,y:929,t:1527009504302};\\\", \\\"{x:1379,y:930,t:1527009504310};\\\", \\\"{x:1378,y:932,t:1527009504322};\\\", \\\"{x:1376,y:935,t:1527009504339};\\\", \\\"{x:1375,y:937,t:1527009504355};\\\", \\\"{x:1374,y:938,t:1527009504372};\\\", \\\"{x:1373,y:940,t:1527009504389};\\\", \\\"{x:1372,y:941,t:1527009504405};\\\", \\\"{x:1371,y:943,t:1527009504423};\\\", \\\"{x:1370,y:944,t:1527009504439};\\\", \\\"{x:1368,y:947,t:1527009504455};\\\", \\\"{x:1361,y:948,t:1527009504472};\\\", \\\"{x:1348,y:948,t:1527009504490};\\\", \\\"{x:1331,y:948,t:1527009504506};\\\", \\\"{x:1302,y:943,t:1527009504522};\\\", \\\"{x:1222,y:913,t:1527009504539};\\\", \\\"{x:1136,y:874,t:1527009504555};\\\", \\\"{x:1041,y:836,t:1527009504572};\\\", \\\"{x:952,y:797,t:1527009504589};\\\", \\\"{x:856,y:757,t:1527009504605};\\\", \\\"{x:730,y:703,t:1527009504622};\\\", \\\"{x:661,y:672,t:1527009504639};\\\", \\\"{x:600,y:644,t:1527009504656};\\\", \\\"{x:564,y:628,t:1527009504672};\\\", \\\"{x:542,y:619,t:1527009504689};\\\", \\\"{x:526,y:613,t:1527009504706};\\\", \\\"{x:507,y:607,t:1527009504723};\\\", \\\"{x:492,y:602,t:1527009504741};\\\", \\\"{x:479,y:598,t:1527009504757};\\\", \\\"{x:475,y:597,t:1527009504773};\\\", \\\"{x:473,y:595,t:1527009504790};\\\", \\\"{x:473,y:593,t:1527009504807};\\\", \\\"{x:473,y:592,t:1527009504823};\\\", \\\"{x:473,y:589,t:1527009504840};\\\", \\\"{x:472,y:586,t:1527009504856};\\\", \\\"{x:469,y:580,t:1527009504873};\\\", \\\"{x:461,y:571,t:1527009504890};\\\", \\\"{x:444,y:565,t:1527009504905};\\\", \\\"{x:424,y:561,t:1527009504924};\\\", \\\"{x:412,y:560,t:1527009504939};\\\", \\\"{x:402,y:560,t:1527009504957};\\\", \\\"{x:398,y:560,t:1527009504973};\\\", \\\"{x:397,y:559,t:1527009504990};\\\", \\\"{x:397,y:558,t:1527009505046};\\\", \\\"{x:396,y:557,t:1527009505061};\\\", \\\"{x:395,y:557,t:1527009505078};\\\", \\\"{x:394,y:555,t:1527009505090};\\\", \\\"{x:392,y:554,t:1527009505107};\\\", \\\"{x:391,y:552,t:1527009505123};\\\", \\\"{x:391,y:548,t:1527009505140};\\\", \\\"{x:391,y:547,t:1527009505157};\\\", \\\"{x:391,y:545,t:1527009505173};\\\", \\\"{x:391,y:544,t:1527009505190};\\\", \\\"{x:391,y:543,t:1527009505207};\\\", \\\"{x:391,y:542,t:1527009505262};\\\", \\\"{x:391,y:543,t:1527009505445};\\\", \\\"{x:391,y:559,t:1527009505457};\\\", \\\"{x:391,y:590,t:1527009505474};\\\", \\\"{x:396,y:619,t:1527009505490};\\\", \\\"{x:406,y:640,t:1527009505507};\\\", \\\"{x:410,y:652,t:1527009505525};\\\", \\\"{x:413,y:666,t:1527009505540};\\\", \\\"{x:417,y:674,t:1527009505557};\\\", \\\"{x:420,y:680,t:1527009505574};\\\", \\\"{x:421,y:683,t:1527009505590};\\\", \\\"{x:422,y:685,t:1527009505607};\\\", \\\"{x:422,y:686,t:1527009505624};\\\", \\\"{x:423,y:686,t:1527009505646};\\\", \\\"{x:424,y:687,t:1527009505686};\\\", \\\"{x:427,y:689,t:1527009505702};\\\", \\\"{x:427,y:690,t:1527009505710};\\\", \\\"{x:430,y:691,t:1527009505724};\\\", \\\"{x:436,y:696,t:1527009505740};\\\", \\\"{x:441,y:698,t:1527009505757};\\\", \\\"{x:447,y:704,t:1527009505774};\\\", \\\"{x:451,y:706,t:1527009505791};\\\", \\\"{x:457,y:710,t:1527009505807};\\\", \\\"{x:461,y:713,t:1527009505824};\\\", \\\"{x:464,y:715,t:1527009505840};\\\", \\\"{x:465,y:715,t:1527009505857};\\\", \\\"{x:465,y:716,t:1527009505875};\\\", \\\"{x:467,y:716,t:1527009505903};\\\", \\\"{x:468,y:716,t:1527009505927};\\\", \\\"{x:470,y:717,t:1527009505951};\\\", \\\"{x:471,y:718,t:1527009505967};\\\", \\\"{x:472,y:718,t:1527009505975};\\\", \\\"{x:474,y:719,t:1527009505991};\\\", \\\"{x:475,y:719,t:1527009506023};\\\", \\\"{x:475,y:719,t:1527009506087};\\\", \\\"{x:476,y:719,t:1527009506231};\\\", \\\"{x:478,y:719,t:1527009506239};\\\", \\\"{x:485,y:716,t:1527009506256};\\\", \\\"{x:501,y:706,t:1527009506273};\\\", \\\"{x:528,y:691,t:1527009506290};\\\", \\\"{x:574,y:664,t:1527009506307};\\\", \\\"{x:650,y:610,t:1527009506324};\\\", \\\"{x:772,y:522,t:1527009506339};\\\", \\\"{x:1071,y:355,t:1527009506358};\\\", \\\"{x:1306,y:230,t:1527009506374};\\\", \\\"{x:1547,y:100,t:1527009506391};\\\", \\\"{x:1844,y:16,t:1527009506409};\\\", \\\"{x:1919,y:16,t:1527009506425};\\\", \\\"{x:1911,y:16,t:1527009506559};\\\", \\\"{x:1782,y:16,t:1527009506575};\\\", \\\"{x:1521,y:16,t:1527009506592};\\\", \\\"{x:1175,y:16,t:1527009506608};\\\", \\\"{x:790,y:64,t:1527009506625};\\\", \\\"{x:516,y:144,t:1527009506642};\\\", \\\"{x:357,y:235,t:1527009506658};\\\", \\\"{x:258,y:323,t:1527009506675};\\\", \\\"{x:192,y:420,t:1527009506693};\\\", \\\"{x:168,y:522,t:1527009506708};\\\", \\\"{x:171,y:614,t:1527009506726};\\\", \\\"{x:239,y:730,t:1527009506742};\\\", \\\"{x:330,y:801,t:1527009506758};\\\", \\\"{x:443,y:874,t:1527009506775};\\\", \\\"{x:551,y:928,t:1527009506791};\\\", \\\"{x:604,y:951,t:1527009506808};\\\", \\\"{x:617,y:956,t:1527009506826};\\\", \\\"{x:618,y:957,t:1527009506841};\\\", \\\"{x:617,y:956,t:1527009506902};\\\", \\\"{x:611,y:953,t:1527009506910};\\\", \\\"{x:604,y:949,t:1527009506925};\\\", \\\"{x:579,y:931,t:1527009506942};\\\", \\\"{x:562,y:910,t:1527009506958};\\\", \\\"{x:542,y:876,t:1527009506975};\\\", \\\"{x:530,y:847,t:1527009506992};\\\", \\\"{x:518,y:824,t:1527009507008};\\\", \\\"{x:509,y:803,t:1527009507025};\\\", \\\"{x:507,y:790,t:1527009507042};\\\", \\\"{x:507,y:780,t:1527009507059};\\\", \\\"{x:507,y:775,t:1527009507075};\\\", \\\"{x:509,y:773,t:1527009507092};\\\", \\\"{x:509,y:771,t:1527009507108};\\\", \\\"{x:509,y:766,t:1527009507125};\\\", \\\"{x:509,y:758,t:1527009507142};\\\", \\\"{x:510,y:757,t:1527009507158};\\\", \\\"{x:510,y:755,t:1527009507302};\\\", \\\"{x:510,y:754,t:1527009507319};\\\", \\\"{x:510,y:753,t:1527009507326};\\\", \\\"{x:510,y:752,t:1527009507342};\\\", \\\"{x:510,y:750,t:1527009507360};\\\", \\\"{x:509,y:749,t:1527009507376};\\\", \\\"{x:508,y:747,t:1527009507863};\\\", \\\"{x:507,y:747,t:1527009507876};\\\", \\\"{x:506,y:746,t:1527009507892};\\\", \\\"{x:473,y:737,t:1527009507910};\\\", \\\"{x:306,y:679,t:1527009507926};\\\", \\\"{x:180,y:632,t:1527009507942};\\\", \\\"{x:75,y:591,t:1527009507959};\\\", \\\"{x:0,y:563,t:1527009507977};\\\", \\\"{x:0,y:530,t:1527009507992};\\\", \\\"{x:0,y:513,t:1527009508009};\\\", \\\"{x:0,y:510,t:1527009508026};\\\", \\\"{x:0,y:522,t:1527009508798};\\\", \\\"{x:0,y:547,t:1527009508809};\\\" ] }, { \\\"rt\\\": 7969, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 663158, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -A -F -F -F -F -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:235,y:1154,t:1527009509003};\\\", \\\"{x:541,y:1040,t:1527009509025};\\\", \\\"{x:674,y:984,t:1527009509034};\\\", \\\"{x:842,y:932,t:1527009509043};\\\", \\\"{x:1178,y:803,t:1527009509060};\\\", \\\"{x:1496,y:682,t:1527009509077};\\\", \\\"{x:1736,y:567,t:1527009509094};\\\", \\\"{x:1919,y:335,t:1527009509119};\\\", \\\"{x:1919,y:298,t:1527009509128};\\\", \\\"{x:1919,y:262,t:1527009509143};\\\", \\\"{x:1917,y:245,t:1527009509160};\\\", \\\"{x:1831,y:214,t:1527009509177};\\\", \\\"{x:1645,y:180,t:1527009509193};\\\", \\\"{x:1387,y:166,t:1527009509210};\\\", \\\"{x:1114,y:166,t:1527009509227};\\\", \\\"{x:843,y:166,t:1527009509244};\\\", \\\"{x:642,y:163,t:1527009509260};\\\", \\\"{x:502,y:155,t:1527009509277};\\\", \\\"{x:458,y:144,t:1527009509293};\\\", \\\"{x:448,y:142,t:1527009509310};\\\", \\\"{x:447,y:141,t:1527009509387};\\\", \\\"{x:449,y:144,t:1527009509406};\\\", \\\"{x:480,y:180,t:1527009509427};\\\", \\\"{x:524,y:244,t:1527009509444};\\\", \\\"{x:584,y:345,t:1527009509461};\\\", \\\"{x:646,y:445,t:1527009509478};\\\", \\\"{x:752,y:576,t:1527009509494};\\\", \\\"{x:813,y:633,t:1527009509511};\\\", \\\"{x:857,y:671,t:1527009509527};\\\", \\\"{x:869,y:683,t:1527009509544};\\\", \\\"{x:870,y:685,t:1527009509561};\\\", \\\"{x:869,y:688,t:1527009509582};\\\", \\\"{x:863,y:689,t:1527009509594};\\\", \\\"{x:845,y:689,t:1527009509611};\\\", \\\"{x:812,y:689,t:1527009509627};\\\", \\\"{x:739,y:680,t:1527009509645};\\\", \\\"{x:652,y:649,t:1527009509661};\\\", \\\"{x:553,y:589,t:1527009509678};\\\", \\\"{x:436,y:490,t:1527009509695};\\\", \\\"{x:407,y:455,t:1527009509711};\\\", \\\"{x:400,y:443,t:1527009509727};\\\", \\\"{x:400,y:437,t:1527009509745};\\\", \\\"{x:403,y:431,t:1527009509760};\\\", \\\"{x:408,y:427,t:1527009509778};\\\", \\\"{x:409,y:427,t:1527009509983};\\\", \\\"{x:413,y:427,t:1527009509995};\\\", \\\"{x:437,y:436,t:1527009510012};\\\", \\\"{x:491,y:467,t:1527009510028};\\\", \\\"{x:581,y:498,t:1527009510046};\\\", \\\"{x:705,y:532,t:1527009510063};\\\", \\\"{x:854,y:551,t:1527009510078};\\\", \\\"{x:1024,y:562,t:1527009510095};\\\", \\\"{x:1245,y:562,t:1527009510111};\\\", \\\"{x:1329,y:562,t:1527009510127};\\\", \\\"{x:1355,y:565,t:1527009510144};\\\", \\\"{x:1359,y:566,t:1527009510161};\\\", \\\"{x:1360,y:567,t:1527009510177};\\\", \\\"{x:1360,y:568,t:1527009510195};\\\", \\\"{x:1356,y:570,t:1527009510210};\\\", \\\"{x:1350,y:571,t:1527009510228};\\\", \\\"{x:1345,y:571,t:1527009510245};\\\", \\\"{x:1340,y:572,t:1527009510261};\\\", \\\"{x:1333,y:575,t:1527009510278};\\\", \\\"{x:1329,y:576,t:1527009510294};\\\", \\\"{x:1328,y:577,t:1527009510310};\\\", \\\"{x:1328,y:579,t:1527009510327};\\\", \\\"{x:1328,y:582,t:1527009510343};\\\", \\\"{x:1334,y:591,t:1527009510361};\\\", \\\"{x:1345,y:600,t:1527009510378};\\\", \\\"{x:1361,y:611,t:1527009510393};\\\", \\\"{x:1383,y:624,t:1527009510411};\\\", \\\"{x:1405,y:630,t:1527009510426};\\\", \\\"{x:1429,y:638,t:1527009510444};\\\", \\\"{x:1450,y:642,t:1527009510460};\\\", \\\"{x:1468,y:645,t:1527009510476};\\\", \\\"{x:1472,y:646,t:1527009510493};\\\", \\\"{x:1473,y:646,t:1527009510510};\\\", \\\"{x:1472,y:645,t:1527009510558};\\\", \\\"{x:1468,y:641,t:1527009510567};\\\", \\\"{x:1463,y:633,t:1527009510576};\\\", \\\"{x:1450,y:618,t:1527009510594};\\\", \\\"{x:1442,y:608,t:1527009510610};\\\", \\\"{x:1433,y:598,t:1527009510626};\\\", \\\"{x:1430,y:594,t:1527009510642};\\\", \\\"{x:1429,y:593,t:1527009510659};\\\", \\\"{x:1428,y:591,t:1527009510676};\\\", \\\"{x:1429,y:591,t:1527009510799};\\\", \\\"{x:1431,y:592,t:1527009510808};\\\", \\\"{x:1432,y:593,t:1527009510825};\\\", \\\"{x:1434,y:599,t:1527009510843};\\\", \\\"{x:1439,y:607,t:1527009510860};\\\", \\\"{x:1442,y:614,t:1527009510876};\\\", \\\"{x:1444,y:615,t:1527009510893};\\\", \\\"{x:1445,y:616,t:1527009510908};\\\", \\\"{x:1445,y:617,t:1527009510926};\\\", \\\"{x:1446,y:617,t:1527009510943};\\\", \\\"{x:1443,y:611,t:1527009511014};\\\", \\\"{x:1440,y:604,t:1527009511025};\\\", \\\"{x:1432,y:582,t:1527009511042};\\\", \\\"{x:1425,y:561,t:1527009511059};\\\", \\\"{x:1419,y:540,t:1527009511076};\\\", \\\"{x:1413,y:523,t:1527009511091};\\\", \\\"{x:1409,y:507,t:1527009511108};\\\", \\\"{x:1407,y:497,t:1527009511125};\\\", \\\"{x:1406,y:491,t:1527009511142};\\\", \\\"{x:1406,y:487,t:1527009511158};\\\", \\\"{x:1406,y:483,t:1527009511175};\\\", \\\"{x:1406,y:476,t:1527009511191};\\\", \\\"{x:1410,y:464,t:1527009511209};\\\", \\\"{x:1413,y:449,t:1527009511224};\\\", \\\"{x:1417,y:428,t:1527009511242};\\\", \\\"{x:1421,y:411,t:1527009511259};\\\", \\\"{x:1425,y:397,t:1527009511274};\\\", \\\"{x:1430,y:380,t:1527009511292};\\\", \\\"{x:1433,y:371,t:1527009511307};\\\", \\\"{x:1437,y:358,t:1527009511324};\\\", \\\"{x:1442,y:347,t:1527009511342};\\\", \\\"{x:1447,y:336,t:1527009511357};\\\", \\\"{x:1451,y:323,t:1527009511374};\\\", \\\"{x:1454,y:316,t:1527009511391};\\\", \\\"{x:1457,y:310,t:1527009511407};\\\", \\\"{x:1458,y:307,t:1527009511425};\\\", \\\"{x:1459,y:306,t:1527009511440};\\\", \\\"{x:1459,y:305,t:1527009511458};\\\", \\\"{x:1461,y:304,t:1527009511518};\\\", \\\"{x:1464,y:304,t:1527009511526};\\\", \\\"{x:1467,y:304,t:1527009511541};\\\", \\\"{x:1480,y:304,t:1527009511557};\\\", \\\"{x:1505,y:310,t:1527009511573};\\\", \\\"{x:1567,y:344,t:1527009511590};\\\", \\\"{x:1620,y:383,t:1527009511608};\\\", \\\"{x:1666,y:419,t:1527009511624};\\\", \\\"{x:1699,y:454,t:1527009511640};\\\", \\\"{x:1716,y:490,t:1527009511657};\\\", \\\"{x:1723,y:528,t:1527009511673};\\\", \\\"{x:1727,y:574,t:1527009511691};\\\", \\\"{x:1727,y:616,t:1527009511707};\\\", \\\"{x:1724,y:654,t:1527009511724};\\\", \\\"{x:1714,y:685,t:1527009511740};\\\", \\\"{x:1707,y:710,t:1527009511757};\\\", \\\"{x:1703,y:731,t:1527009511775};\\\", \\\"{x:1703,y:750,t:1527009511790};\\\", \\\"{x:1703,y:772,t:1527009511807};\\\", \\\"{x:1704,y:781,t:1527009511824};\\\", \\\"{x:1707,y:791,t:1527009511840};\\\", \\\"{x:1708,y:799,t:1527009511857};\\\", \\\"{x:1711,y:806,t:1527009511873};\\\", \\\"{x:1715,y:816,t:1527009511891};\\\", \\\"{x:1716,y:824,t:1527009511908};\\\", \\\"{x:1716,y:829,t:1527009511923};\\\", \\\"{x:1716,y:832,t:1527009511940};\\\", \\\"{x:1716,y:834,t:1527009511957};\\\", \\\"{x:1716,y:835,t:1527009512166};\\\", \\\"{x:1716,y:836,t:1527009512183};\\\", \\\"{x:1717,y:836,t:1527009512198};\\\", \\\"{x:1716,y:836,t:1527009512254};\\\", \\\"{x:1706,y:835,t:1527009512263};\\\", \\\"{x:1692,y:832,t:1527009512272};\\\", \\\"{x:1629,y:824,t:1527009512289};\\\", \\\"{x:1537,y:809,t:1527009512306};\\\", \\\"{x:1450,y:805,t:1527009512322};\\\", \\\"{x:1371,y:800,t:1527009512338};\\\", \\\"{x:1326,y:795,t:1527009512354};\\\", \\\"{x:1300,y:791,t:1527009512372};\\\", \\\"{x:1294,y:790,t:1527009512389};\\\", \\\"{x:1292,y:788,t:1527009512405};\\\", \\\"{x:1294,y:788,t:1527009512447};\\\", \\\"{x:1295,y:787,t:1527009512455};\\\", \\\"{x:1299,y:783,t:1527009512472};\\\", \\\"{x:1302,y:778,t:1527009512488};\\\", \\\"{x:1305,y:772,t:1527009512505};\\\", \\\"{x:1308,y:767,t:1527009512522};\\\", \\\"{x:1312,y:763,t:1527009512540};\\\", \\\"{x:1315,y:757,t:1527009512555};\\\", \\\"{x:1321,y:750,t:1527009512572};\\\", \\\"{x:1329,y:741,t:1527009512588};\\\", \\\"{x:1336,y:731,t:1527009512605};\\\", \\\"{x:1342,y:724,t:1527009512622};\\\", \\\"{x:1346,y:718,t:1527009512639};\\\", \\\"{x:1351,y:711,t:1527009512654};\\\", \\\"{x:1353,y:705,t:1527009512672};\\\", \\\"{x:1354,y:700,t:1527009512688};\\\", \\\"{x:1354,y:698,t:1527009512705};\\\", \\\"{x:1354,y:697,t:1527009512721};\\\", \\\"{x:1354,y:696,t:1527009512815};\\\", \\\"{x:1354,y:695,t:1527009512823};\\\", \\\"{x:1354,y:694,t:1527009512839};\\\", \\\"{x:1353,y:694,t:1527009512854};\\\", \\\"{x:1352,y:692,t:1527009512902};\\\", \\\"{x:1351,y:692,t:1527009513023};\\\", \\\"{x:1350,y:692,t:1527009513053};\\\", \\\"{x:1349,y:691,t:1527009513070};\\\", \\\"{x:1348,y:691,t:1527009513087};\\\", \\\"{x:1346,y:691,t:1527009513103};\\\", \\\"{x:1345,y:691,t:1527009513120};\\\", \\\"{x:1344,y:691,t:1527009513136};\\\", \\\"{x:1343,y:691,t:1527009513158};\\\", \\\"{x:1342,y:690,t:1527009513296};\\\", \\\"{x:1341,y:690,t:1527009513723};\\\", \\\"{x:1340,y:689,t:1527009513739};\\\", \\\"{x:1339,y:689,t:1527009514187};\\\", \\\"{x:1339,y:690,t:1527009514218};\\\", \\\"{x:1340,y:690,t:1527009514290};\\\", \\\"{x:1341,y:690,t:1527009514322};\\\", \\\"{x:1342,y:691,t:1527009514394};\\\", \\\"{x:1342,y:690,t:1527009514522};\\\", \\\"{x:1343,y:681,t:1527009514537};\\\", \\\"{x:1349,y:661,t:1527009514553};\\\", \\\"{x:1359,y:631,t:1527009514570};\\\", \\\"{x:1367,y:609,t:1527009514586};\\\", \\\"{x:1374,y:601,t:1527009514603};\\\", \\\"{x:1377,y:597,t:1527009514620};\\\", \\\"{x:1378,y:596,t:1527009514642};\\\", \\\"{x:1380,y:595,t:1527009514667};\\\", \\\"{x:1386,y:591,t:1527009514675};\\\", \\\"{x:1393,y:586,t:1527009514685};\\\", \\\"{x:1410,y:574,t:1527009514703};\\\", \\\"{x:1418,y:566,t:1527009514721};\\\", \\\"{x:1424,y:562,t:1527009514736};\\\", \\\"{x:1424,y:561,t:1527009514753};\\\", \\\"{x:1425,y:561,t:1527009515044};\\\", \\\"{x:1424,y:563,t:1527009515052};\\\", \\\"{x:1420,y:568,t:1527009515069};\\\", \\\"{x:1413,y:571,t:1527009515085};\\\", \\\"{x:1404,y:574,t:1527009515102};\\\", \\\"{x:1394,y:575,t:1527009515119};\\\", \\\"{x:1381,y:576,t:1527009515135};\\\", \\\"{x:1365,y:576,t:1527009515152};\\\", \\\"{x:1344,y:576,t:1527009515168};\\\", \\\"{x:1318,y:574,t:1527009515185};\\\", \\\"{x:1277,y:572,t:1527009515202};\\\", \\\"{x:1185,y:572,t:1527009515218};\\\", \\\"{x:1119,y:572,t:1527009515234};\\\", \\\"{x:1035,y:572,t:1527009515252};\\\", \\\"{x:952,y:572,t:1527009515267};\\\", \\\"{x:871,y:572,t:1527009515285};\\\", \\\"{x:801,y:570,t:1527009515302};\\\", \\\"{x:753,y:568,t:1527009515317};\\\", \\\"{x:725,y:567,t:1527009515335};\\\", \\\"{x:701,y:565,t:1527009515353};\\\", \\\"{x:681,y:565,t:1527009515369};\\\", \\\"{x:658,y:565,t:1527009515385};\\\", \\\"{x:648,y:565,t:1527009515403};\\\", \\\"{x:644,y:564,t:1527009515420};\\\", \\\"{x:639,y:562,t:1527009515437};\\\", \\\"{x:630,y:561,t:1527009515453};\\\", \\\"{x:616,y:560,t:1527009515469};\\\", \\\"{x:599,y:558,t:1527009515485};\\\", \\\"{x:584,y:556,t:1527009515502};\\\", \\\"{x:575,y:556,t:1527009515520};\\\", \\\"{x:573,y:555,t:1527009515537};\\\", \\\"{x:573,y:553,t:1527009515602};\\\", \\\"{x:584,y:549,t:1527009515620};\\\", \\\"{x:604,y:542,t:1527009515637};\\\", \\\"{x:632,y:538,t:1527009515654};\\\", \\\"{x:664,y:536,t:1527009515670};\\\", \\\"{x:694,y:536,t:1527009515686};\\\", \\\"{x:719,y:536,t:1527009515703};\\\", \\\"{x:741,y:536,t:1527009515721};\\\", \\\"{x:752,y:538,t:1527009515736};\\\", \\\"{x:755,y:541,t:1527009515753};\\\", \\\"{x:756,y:541,t:1527009515769};\\\", \\\"{x:757,y:542,t:1527009515786};\\\", \\\"{x:758,y:544,t:1527009515803};\\\", \\\"{x:760,y:546,t:1527009515820};\\\", \\\"{x:762,y:548,t:1527009515837};\\\", \\\"{x:764,y:548,t:1527009515858};\\\", \\\"{x:765,y:548,t:1527009515898};\\\", \\\"{x:766,y:548,t:1527009515906};\\\", \\\"{x:768,y:548,t:1527009515919};\\\", \\\"{x:778,y:546,t:1527009515937};\\\", \\\"{x:792,y:544,t:1527009515954};\\\", \\\"{x:806,y:542,t:1527009515970};\\\", \\\"{x:818,y:541,t:1527009515986};\\\", \\\"{x:820,y:541,t:1527009516003};\\\", \\\"{x:821,y:541,t:1527009516020};\\\", \\\"{x:822,y:541,t:1527009516042};\\\", \\\"{x:824,y:540,t:1527009516054};\\\", \\\"{x:825,y:538,t:1527009516074};\\\", \\\"{x:821,y:542,t:1527009516258};\\\", \\\"{x:813,y:547,t:1527009516271};\\\", \\\"{x:790,y:562,t:1527009516287};\\\", \\\"{x:747,y:591,t:1527009516304};\\\", \\\"{x:700,y:622,t:1527009516321};\\\", \\\"{x:652,y:657,t:1527009516337};\\\", \\\"{x:596,y:696,t:1527009516354};\\\", \\\"{x:572,y:710,t:1527009516370};\\\", \\\"{x:557,y:722,t:1527009516387};\\\", \\\"{x:543,y:730,t:1527009516404};\\\", \\\"{x:536,y:738,t:1527009516420};\\\", \\\"{x:530,y:744,t:1527009516437};\\\", \\\"{x:527,y:747,t:1527009516454};\\\", \\\"{x:523,y:751,t:1527009516470};\\\", \\\"{x:522,y:752,t:1527009516487};\\\", \\\"{x:520,y:753,t:1527009516504};\\\", \\\"{x:519,y:754,t:1527009516519};\\\", \\\"{x:516,y:756,t:1527009516537};\\\", \\\"{x:513,y:758,t:1527009516553};\\\", \\\"{x:508,y:760,t:1527009516570};\\\", \\\"{x:506,y:760,t:1527009516704};\\\", \\\"{x:505,y:759,t:1527009516720};\\\", \\\"{x:504,y:759,t:1527009516722};\\\", \\\"{x:503,y:759,t:1527009516737};\\\", \\\"{x:501,y:758,t:1527009516753};\\\", \\\"{x:501,y:757,t:1527009516770};\\\", \\\"{x:499,y:751,t:1527009516788};\\\", \\\"{x:501,y:744,t:1527009516804};\\\", \\\"{x:509,y:734,t:1527009516821};\\\", \\\"{x:510,y:729,t:1527009516837};\\\", \\\"{x:511,y:729,t:1527009516906};\\\", \\\"{x:511,y:729,t:1527009516994};\\\", \\\"{x:512,y:729,t:1527009517042};\\\", \\\"{x:516,y:729,t:1527009517055};\\\", \\\"{x:536,y:728,t:1527009517070};\\\", \\\"{x:562,y:724,t:1527009517088};\\\", \\\"{x:606,y:723,t:1527009517104};\\\", \\\"{x:684,y:721,t:1527009517120};\\\", \\\"{x:812,y:721,t:1527009517137};\\\", \\\"{x:905,y:716,t:1527009517154};\\\", \\\"{x:969,y:716,t:1527009517170};\\\", \\\"{x:1011,y:716,t:1527009517187};\\\", \\\"{x:1026,y:716,t:1527009517204};\\\", \\\"{x:1028,y:716,t:1527009517220};\\\" ] }, { \\\"rt\\\": 49066, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 713456, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -F -I -I -E -E -E -E -E -G -G -K \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1037,y:716,t:1527009519780};\\\", \\\"{x:1059,y:716,t:1527009519790};\\\", \\\"{x:1165,y:716,t:1527009519807};\\\", \\\"{x:1281,y:716,t:1527009519823};\\\", \\\"{x:1417,y:716,t:1527009519840};\\\", \\\"{x:1544,y:716,t:1527009519856};\\\", \\\"{x:1633,y:716,t:1527009519872};\\\", \\\"{x:1689,y:719,t:1527009519890};\\\", \\\"{x:1697,y:721,t:1527009519907};\\\", \\\"{x:1697,y:722,t:1527009519970};\\\", \\\"{x:1697,y:723,t:1527009519979};\\\", \\\"{x:1697,y:724,t:1527009519990};\\\", \\\"{x:1697,y:726,t:1527009520007};\\\", \\\"{x:1695,y:731,t:1527009520024};\\\", \\\"{x:1693,y:736,t:1527009520040};\\\", \\\"{x:1691,y:738,t:1527009520057};\\\", \\\"{x:1690,y:740,t:1527009520074};\\\", \\\"{x:1689,y:742,t:1527009520090};\\\", \\\"{x:1683,y:742,t:1527009520107};\\\", \\\"{x:1673,y:742,t:1527009520124};\\\", \\\"{x:1660,y:742,t:1527009520141};\\\", \\\"{x:1644,y:735,t:1527009520157};\\\", \\\"{x:1629,y:729,t:1527009520175};\\\", \\\"{x:1623,y:724,t:1527009520190};\\\", \\\"{x:1621,y:721,t:1527009520208};\\\", \\\"{x:1621,y:719,t:1527009520224};\\\", \\\"{x:1620,y:717,t:1527009520240};\\\", \\\"{x:1619,y:716,t:1527009520258};\\\", \\\"{x:1618,y:715,t:1527009520315};\\\", \\\"{x:1618,y:714,t:1527009520339};\\\", \\\"{x:1618,y:713,t:1527009520347};\\\", \\\"{x:1618,y:712,t:1527009520362};\\\", \\\"{x:1618,y:711,t:1527009520374};\\\", \\\"{x:1618,y:709,t:1527009520391};\\\", \\\"{x:1619,y:708,t:1527009520408};\\\", \\\"{x:1619,y:707,t:1527009520424};\\\", \\\"{x:1620,y:707,t:1527009520451};\\\", \\\"{x:1620,y:706,t:1527009520500};\\\", \\\"{x:1620,y:705,t:1527009520531};\\\", \\\"{x:1620,y:704,t:1527009520540};\\\", \\\"{x:1620,y:702,t:1527009520557};\\\", \\\"{x:1618,y:700,t:1527009520575};\\\", \\\"{x:1615,y:697,t:1527009520591};\\\", \\\"{x:1613,y:696,t:1527009520607};\\\", \\\"{x:1612,y:695,t:1527009520624};\\\", \\\"{x:1612,y:694,t:1527009520641};\\\", \\\"{x:1610,y:694,t:1527009521483};\\\", \\\"{x:1609,y:694,t:1527009521498};\\\", \\\"{x:1608,y:693,t:1527009521509};\\\", \\\"{x:1607,y:693,t:1527009521579};\\\", \\\"{x:1609,y:693,t:1527009522098};\\\", \\\"{x:1611,y:693,t:1527009522114};\\\", \\\"{x:1612,y:693,t:1527009522125};\\\", \\\"{x:1613,y:694,t:1527009522154};\\\", \\\"{x:1614,y:694,t:1527009522169};\\\", \\\"{x:1615,y:694,t:1527009522202};\\\", \\\"{x:1614,y:694,t:1527009522970};\\\", \\\"{x:1611,y:697,t:1527009526883};\\\", \\\"{x:1609,y:706,t:1527009526897};\\\", \\\"{x:1600,y:724,t:1527009526913};\\\", \\\"{x:1593,y:742,t:1527009526930};\\\", \\\"{x:1583,y:759,t:1527009526946};\\\", \\\"{x:1565,y:784,t:1527009526963};\\\", \\\"{x:1557,y:797,t:1527009526980};\\\", \\\"{x:1551,y:809,t:1527009526996};\\\", \\\"{x:1540,y:825,t:1527009527013};\\\", \\\"{x:1535,y:836,t:1527009527029};\\\", \\\"{x:1528,y:848,t:1527009527046};\\\", \\\"{x:1521,y:860,t:1527009527063};\\\", \\\"{x:1513,y:873,t:1527009527080};\\\", \\\"{x:1508,y:881,t:1527009527096};\\\", \\\"{x:1507,y:884,t:1527009527112};\\\", \\\"{x:1506,y:887,t:1527009527129};\\\", \\\"{x:1503,y:894,t:1527009527146};\\\", \\\"{x:1500,y:902,t:1527009527163};\\\", \\\"{x:1495,y:911,t:1527009527179};\\\", \\\"{x:1491,y:919,t:1527009527197};\\\", \\\"{x:1486,y:928,t:1527009527213};\\\", \\\"{x:1482,y:935,t:1527009527229};\\\", \\\"{x:1477,y:943,t:1527009527247};\\\", \\\"{x:1475,y:949,t:1527009527263};\\\", \\\"{x:1473,y:955,t:1527009527280};\\\", \\\"{x:1473,y:957,t:1527009527296};\\\", \\\"{x:1472,y:960,t:1527009527313};\\\", \\\"{x:1472,y:961,t:1527009527330};\\\", \\\"{x:1471,y:962,t:1527009527347};\\\", \\\"{x:1471,y:964,t:1527009527363};\\\", \\\"{x:1471,y:965,t:1527009527451};\\\", \\\"{x:1471,y:966,t:1527009527491};\\\", \\\"{x:1472,y:966,t:1527009527507};\\\", \\\"{x:1473,y:966,t:1527009527523};\\\", \\\"{x:1474,y:966,t:1527009527554};\\\", \\\"{x:1476,y:966,t:1527009527569};\\\", \\\"{x:1478,y:966,t:1527009527610};\\\", \\\"{x:1479,y:966,t:1527009527641};\\\", \\\"{x:1478,y:966,t:1527009528714};\\\", \\\"{x:1477,y:966,t:1527009528739};\\\", \\\"{x:1477,y:965,t:1527009530490};\\\", \\\"{x:1479,y:964,t:1527009530499};\\\", \\\"{x:1479,y:963,t:1527009530522};\\\", \\\"{x:1479,y:961,t:1527009530546};\\\", \\\"{x:1479,y:960,t:1527009530570};\\\", \\\"{x:1479,y:958,t:1527009530587};\\\", \\\"{x:1480,y:958,t:1527009530818};\\\", \\\"{x:1481,y:958,t:1527009530882};\\\", \\\"{x:1481,y:957,t:1527009547561};\\\", \\\"{x:1465,y:936,t:1527009547579};\\\", \\\"{x:1393,y:856,t:1527009547595};\\\", \\\"{x:1271,y:771,t:1527009547612};\\\", \\\"{x:1129,y:700,t:1527009547629};\\\", \\\"{x:990,y:650,t:1527009547645};\\\", \\\"{x:867,y:627,t:1527009547663};\\\", \\\"{x:779,y:616,t:1527009547679};\\\", \\\"{x:712,y:609,t:1527009547695};\\\", \\\"{x:677,y:607,t:1527009547713};\\\", \\\"{x:658,y:604,t:1527009547729};\\\", \\\"{x:642,y:602,t:1527009547746};\\\", \\\"{x:634,y:600,t:1527009547763};\\\", \\\"{x:625,y:598,t:1527009547779};\\\", \\\"{x:614,y:590,t:1527009547796};\\\", \\\"{x:599,y:582,t:1527009547812};\\\", \\\"{x:586,y:576,t:1527009547830};\\\", \\\"{x:581,y:574,t:1527009547846};\\\", \\\"{x:562,y:570,t:1527009547863};\\\", \\\"{x:551,y:563,t:1527009547880};\\\", \\\"{x:531,y:560,t:1527009547898};\\\", \\\"{x:510,y:560,t:1527009547913};\\\", \\\"{x:418,y:555,t:1527009547930};\\\", \\\"{x:386,y:553,t:1527009547947};\\\", \\\"{x:365,y:551,t:1527009547963};\\\", \\\"{x:352,y:550,t:1527009547980};\\\", \\\"{x:344,y:550,t:1527009547997};\\\", \\\"{x:335,y:550,t:1527009548013};\\\", \\\"{x:320,y:550,t:1527009548030};\\\", \\\"{x:310,y:550,t:1527009548047};\\\", \\\"{x:306,y:550,t:1527009548063};\\\", \\\"{x:301,y:550,t:1527009548079};\\\", \\\"{x:298,y:550,t:1527009548097};\\\", \\\"{x:291,y:551,t:1527009548113};\\\", \\\"{x:270,y:558,t:1527009548130};\\\", \\\"{x:260,y:563,t:1527009548147};\\\", \\\"{x:251,y:569,t:1527009548163};\\\", \\\"{x:242,y:576,t:1527009548180};\\\", \\\"{x:232,y:583,t:1527009548196};\\\", \\\"{x:224,y:587,t:1527009548213};\\\", \\\"{x:214,y:594,t:1527009548231};\\\", \\\"{x:211,y:599,t:1527009548246};\\\", \\\"{x:204,y:608,t:1527009548263};\\\", \\\"{x:201,y:613,t:1527009548280};\\\", \\\"{x:197,y:613,t:1527009548297};\\\", \\\"{x:195,y:618,t:1527009548313};\\\", \\\"{x:195,y:619,t:1527009548330};\\\", \\\"{x:195,y:620,t:1527009548409};\\\", \\\"{x:199,y:620,t:1527009548417};\\\", \\\"{x:203,y:619,t:1527009548429};\\\", \\\"{x:221,y:612,t:1527009548447};\\\", \\\"{x:267,y:598,t:1527009548464};\\\", \\\"{x:358,y:577,t:1527009548480};\\\", \\\"{x:484,y:552,t:1527009548498};\\\", \\\"{x:684,y:526,t:1527009548514};\\\", \\\"{x:790,y:510,t:1527009548531};\\\", \\\"{x:860,y:500,t:1527009548547};\\\", \\\"{x:884,y:495,t:1527009548565};\\\", \\\"{x:887,y:495,t:1527009548580};\\\", \\\"{x:887,y:496,t:1527009548674};\\\", \\\"{x:887,y:497,t:1527009548682};\\\", \\\"{x:887,y:498,t:1527009548697};\\\", \\\"{x:884,y:499,t:1527009548713};\\\", \\\"{x:883,y:500,t:1527009548730};\\\", \\\"{x:882,y:501,t:1527009548747};\\\", \\\"{x:881,y:501,t:1527009548764};\\\", \\\"{x:879,y:501,t:1527009548786};\\\", \\\"{x:877,y:501,t:1527009548797};\\\", \\\"{x:868,y:501,t:1527009548814};\\\", \\\"{x:854,y:501,t:1527009548832};\\\", \\\"{x:839,y:501,t:1527009548847};\\\", \\\"{x:830,y:501,t:1527009548864};\\\", \\\"{x:827,y:501,t:1527009548881};\\\", \\\"{x:826,y:501,t:1527009548897};\\\", \\\"{x:825,y:501,t:1527009548915};\\\", \\\"{x:825,y:502,t:1527009549185};\\\", \\\"{x:830,y:508,t:1527009549198};\\\", \\\"{x:859,y:524,t:1527009549215};\\\", \\\"{x:913,y:549,t:1527009549232};\\\", \\\"{x:983,y:586,t:1527009549248};\\\", \\\"{x:1060,y:618,t:1527009549264};\\\", \\\"{x:1126,y:649,t:1527009549281};\\\", \\\"{x:1185,y:674,t:1527009549297};\\\", \\\"{x:1251,y:700,t:1527009549313};\\\", \\\"{x:1284,y:713,t:1527009549331};\\\", \\\"{x:1309,y:720,t:1527009549347};\\\", \\\"{x:1324,y:722,t:1527009549364};\\\", \\\"{x:1330,y:723,t:1527009549381};\\\", \\\"{x:1331,y:723,t:1527009549410};\\\", \\\"{x:1331,y:722,t:1527009549434};\\\", \\\"{x:1331,y:721,t:1527009549447};\\\", \\\"{x:1331,y:716,t:1527009549464};\\\", \\\"{x:1336,y:710,t:1527009549480};\\\", \\\"{x:1340,y:706,t:1527009549498};\\\", \\\"{x:1346,y:703,t:1527009549514};\\\", \\\"{x:1350,y:700,t:1527009549531};\\\", \\\"{x:1350,y:699,t:1527009549602};\\\", \\\"{x:1350,y:698,t:1527009549613};\\\", \\\"{x:1351,y:696,t:1527009549630};\\\", \\\"{x:1351,y:695,t:1527009549646};\\\", \\\"{x:1351,y:694,t:1527009549663};\\\", \\\"{x:1351,y:697,t:1527009549834};\\\", \\\"{x:1344,y:705,t:1527009549846};\\\", \\\"{x:1334,y:720,t:1527009549863};\\\", \\\"{x:1318,y:735,t:1527009549879};\\\", \\\"{x:1297,y:754,t:1527009549896};\\\", \\\"{x:1276,y:766,t:1527009549912};\\\", \\\"{x:1254,y:782,t:1527009549929};\\\", \\\"{x:1227,y:801,t:1527009549945};\\\", \\\"{x:1215,y:810,t:1527009549962};\\\", \\\"{x:1207,y:818,t:1527009549979};\\\", \\\"{x:1205,y:821,t:1527009549996};\\\", \\\"{x:1204,y:822,t:1527009550012};\\\", \\\"{x:1204,y:823,t:1527009550073};\\\", \\\"{x:1204,y:824,t:1527009550122};\\\", \\\"{x:1204,y:825,t:1527009550345};\\\", \\\"{x:1205,y:825,t:1527009550746};\\\", \\\"{x:1205,y:823,t:1527009550760};\\\", \\\"{x:1205,y:817,t:1527009550777};\\\", \\\"{x:1205,y:811,t:1527009550794};\\\", \\\"{x:1205,y:807,t:1527009550810};\\\", \\\"{x:1202,y:801,t:1527009550827};\\\", \\\"{x:1199,y:795,t:1527009550843};\\\", \\\"{x:1195,y:788,t:1527009550860};\\\", \\\"{x:1190,y:778,t:1527009550877};\\\", \\\"{x:1185,y:767,t:1527009550893};\\\", \\\"{x:1178,y:756,t:1527009550910};\\\", \\\"{x:1174,y:747,t:1527009550927};\\\", \\\"{x:1170,y:742,t:1527009550943};\\\", \\\"{x:1169,y:742,t:1527009550960};\\\", \\\"{x:1168,y:740,t:1527009550976};\\\", \\\"{x:1170,y:740,t:1527009551163};\\\", \\\"{x:1171,y:740,t:1527009551177};\\\", \\\"{x:1172,y:741,t:1527009551194};\\\", \\\"{x:1173,y:741,t:1527009551210};\\\", \\\"{x:1174,y:740,t:1527009551323};\\\", \\\"{x:1175,y:732,t:1527009551330};\\\", \\\"{x:1179,y:720,t:1527009551343};\\\", \\\"{x:1194,y:690,t:1527009551359};\\\", \\\"{x:1223,y:638,t:1527009551376};\\\", \\\"{x:1256,y:595,t:1527009551392};\\\", \\\"{x:1273,y:578,t:1527009551410};\\\", \\\"{x:1289,y:568,t:1527009551426};\\\", \\\"{x:1291,y:568,t:1527009551515};\\\", \\\"{x:1292,y:568,t:1527009551547};\\\", \\\"{x:1291,y:568,t:1527009551690};\\\", \\\"{x:1286,y:564,t:1527009551709};\\\", \\\"{x:1284,y:558,t:1527009551724};\\\", \\\"{x:1282,y:554,t:1527009551743};\\\", \\\"{x:1281,y:553,t:1527009551758};\\\", \\\"{x:1280,y:555,t:1527009554506};\\\", \\\"{x:1280,y:558,t:1527009554517};\\\", \\\"{x:1277,y:568,t:1527009554534};\\\", \\\"{x:1269,y:580,t:1527009554551};\\\", \\\"{x:1263,y:592,t:1527009554567};\\\", \\\"{x:1256,y:604,t:1527009554584};\\\", \\\"{x:1248,y:621,t:1527009554600};\\\", \\\"{x:1237,y:645,t:1527009554618};\\\", \\\"{x:1232,y:667,t:1527009554633};\\\", \\\"{x:1224,y:692,t:1527009554650};\\\", \\\"{x:1214,y:715,t:1527009554667};\\\", \\\"{x:1205,y:734,t:1527009554683};\\\", \\\"{x:1200,y:745,t:1527009554700};\\\", \\\"{x:1194,y:753,t:1527009554717};\\\", \\\"{x:1189,y:764,t:1527009554733};\\\", \\\"{x:1184,y:777,t:1527009554751};\\\", \\\"{x:1177,y:793,t:1527009554766};\\\", \\\"{x:1170,y:805,t:1527009554783};\\\", \\\"{x:1160,y:821,t:1527009554800};\\\", \\\"{x:1153,y:836,t:1527009554816};\\\", \\\"{x:1139,y:855,t:1527009554833};\\\", \\\"{x:1132,y:863,t:1527009554849};\\\", \\\"{x:1126,y:873,t:1527009554866};\\\", \\\"{x:1122,y:879,t:1527009554883};\\\", \\\"{x:1119,y:885,t:1527009554899};\\\", \\\"{x:1117,y:891,t:1527009554916};\\\", \\\"{x:1114,y:896,t:1527009554934};\\\", \\\"{x:1111,y:902,t:1527009554950};\\\", \\\"{x:1108,y:907,t:1527009554967};\\\", \\\"{x:1104,y:912,t:1527009554984};\\\", \\\"{x:1099,y:918,t:1527009554999};\\\", \\\"{x:1093,y:925,t:1527009555016};\\\", \\\"{x:1087,y:930,t:1527009555033};\\\", \\\"{x:1077,y:937,t:1527009555049};\\\", \\\"{x:1071,y:941,t:1527009555066};\\\", \\\"{x:1067,y:943,t:1527009555083};\\\", \\\"{x:1064,y:946,t:1527009555099};\\\", \\\"{x:1062,y:948,t:1527009555116};\\\", \\\"{x:1060,y:950,t:1527009555133};\\\", \\\"{x:1058,y:950,t:1527009555149};\\\", \\\"{x:1056,y:952,t:1527009555166};\\\", \\\"{x:1056,y:953,t:1527009555182};\\\", \\\"{x:1055,y:954,t:1527009555199};\\\", \\\"{x:1054,y:954,t:1527009555216};\\\", \\\"{x:1053,y:954,t:1527009555290};\\\", \\\"{x:1053,y:951,t:1527009555299};\\\", \\\"{x:1053,y:936,t:1527009555315};\\\", \\\"{x:1064,y:906,t:1527009555333};\\\", \\\"{x:1084,y:864,t:1527009555348};\\\", \\\"{x:1135,y:777,t:1527009555365};\\\", \\\"{x:1205,y:684,t:1527009555382};\\\", \\\"{x:1270,y:607,t:1527009555398};\\\", \\\"{x:1317,y:550,t:1527009555415};\\\", \\\"{x:1344,y:515,t:1527009555432};\\\", \\\"{x:1354,y:498,t:1527009555449};\\\", \\\"{x:1355,y:491,t:1527009555465};\\\", \\\"{x:1355,y:492,t:1527009555514};\\\", \\\"{x:1355,y:495,t:1527009555522};\\\", \\\"{x:1355,y:496,t:1527009555532};\\\", \\\"{x:1355,y:497,t:1527009555549};\\\", \\\"{x:1355,y:498,t:1527009555586};\\\", \\\"{x:1354,y:499,t:1527009555598};\\\", \\\"{x:1352,y:508,t:1527009555615};\\\", \\\"{x:1346,y:518,t:1527009555632};\\\", \\\"{x:1339,y:525,t:1527009555648};\\\", \\\"{x:1325,y:531,t:1527009555665};\\\", \\\"{x:1288,y:547,t:1527009555682};\\\", \\\"{x:1268,y:555,t:1527009555697};\\\", \\\"{x:1251,y:562,t:1527009555715};\\\", \\\"{x:1242,y:565,t:1527009555731};\\\", \\\"{x:1241,y:566,t:1527009555786};\\\", \\\"{x:1241,y:564,t:1527009555802};\\\", \\\"{x:1243,y:560,t:1527009555815};\\\", \\\"{x:1252,y:556,t:1527009555831};\\\", \\\"{x:1253,y:555,t:1527009555848};\\\", \\\"{x:1254,y:555,t:1527009555874};\\\", \\\"{x:1255,y:555,t:1527009555905};\\\", \\\"{x:1256,y:555,t:1527009555929};\\\", \\\"{x:1257,y:555,t:1527009555953};\\\", \\\"{x:1258,y:555,t:1527009555963};\\\", \\\"{x:1260,y:555,t:1527009555980};\\\", \\\"{x:1261,y:554,t:1527009555997};\\\", \\\"{x:1262,y:554,t:1527009556017};\\\", \\\"{x:1263,y:554,t:1527009556042};\\\", \\\"{x:1264,y:554,t:1527009556049};\\\", \\\"{x:1266,y:555,t:1527009556063};\\\", \\\"{x:1267,y:555,t:1527009556081};\\\", \\\"{x:1268,y:556,t:1527009556096};\\\", \\\"{x:1270,y:556,t:1527009556114};\\\", \\\"{x:1272,y:557,t:1527009556145};\\\", \\\"{x:1273,y:557,t:1527009556169};\\\", \\\"{x:1274,y:557,t:1527009556180};\\\", \\\"{x:1277,y:557,t:1527009556197};\\\", \\\"{x:1278,y:557,t:1527009556213};\\\", \\\"{x:1281,y:559,t:1527009556229};\\\", \\\"{x:1283,y:559,t:1527009556247};\\\", \\\"{x:1286,y:560,t:1527009556263};\\\", \\\"{x:1287,y:560,t:1527009556280};\\\", \\\"{x:1288,y:560,t:1527009556338};\\\", \\\"{x:1288,y:561,t:1527009556434};\\\", \\\"{x:1288,y:562,t:1527009556490};\\\", \\\"{x:1287,y:562,t:1527009556530};\\\", \\\"{x:1292,y:562,t:1527009556618};\\\", \\\"{x:1302,y:562,t:1527009556629};\\\", \\\"{x:1336,y:562,t:1527009556646};\\\", \\\"{x:1375,y:562,t:1527009556662};\\\", \\\"{x:1409,y:562,t:1527009556679};\\\", \\\"{x:1431,y:562,t:1527009556696};\\\", \\\"{x:1434,y:562,t:1527009556712};\\\", \\\"{x:1433,y:562,t:1527009556803};\\\", \\\"{x:1429,y:562,t:1527009556812};\\\", \\\"{x:1421,y:562,t:1527009556829};\\\", \\\"{x:1408,y:562,t:1527009556845};\\\", \\\"{x:1394,y:562,t:1527009556862};\\\", \\\"{x:1385,y:562,t:1527009556878};\\\", \\\"{x:1376,y:562,t:1527009556894};\\\", \\\"{x:1372,y:562,t:1527009556912};\\\", \\\"{x:1371,y:562,t:1527009556928};\\\", \\\"{x:1370,y:562,t:1527009556945};\\\", \\\"{x:1368,y:562,t:1527009556963};\\\", \\\"{x:1364,y:562,t:1527009556978};\\\", \\\"{x:1357,y:562,t:1527009556994};\\\", \\\"{x:1354,y:562,t:1527009557012};\\\", \\\"{x:1351,y:562,t:1527009557028};\\\", \\\"{x:1350,y:562,t:1527009557045};\\\", \\\"{x:1348,y:562,t:1527009557061};\\\", \\\"{x:1347,y:562,t:1527009557098};\\\", \\\"{x:1346,y:561,t:1527009557147};\\\", \\\"{x:1348,y:561,t:1527009557202};\\\", \\\"{x:1351,y:561,t:1527009557211};\\\", \\\"{x:1363,y:559,t:1527009557228};\\\", \\\"{x:1374,y:559,t:1527009557244};\\\", \\\"{x:1385,y:559,t:1527009557261};\\\", \\\"{x:1389,y:559,t:1527009557278};\\\", \\\"{x:1391,y:559,t:1527009557294};\\\", \\\"{x:1392,y:559,t:1527009557443};\\\", \\\"{x:1393,y:559,t:1527009557490};\\\", \\\"{x:1394,y:559,t:1527009557507};\\\", \\\"{x:1395,y:559,t:1527009557530};\\\", \\\"{x:1397,y:559,t:1527009557546};\\\", \\\"{x:1399,y:559,t:1527009557562};\\\", \\\"{x:1400,y:559,t:1527009557578};\\\", \\\"{x:1401,y:559,t:1527009557602};\\\", \\\"{x:1403,y:559,t:1527009557618};\\\", \\\"{x:1405,y:559,t:1527009557642};\\\", \\\"{x:1406,y:559,t:1527009557660};\\\", \\\"{x:1407,y:559,t:1527009557677};\\\", \\\"{x:1408,y:559,t:1527009557693};\\\", \\\"{x:1409,y:559,t:1527009557710};\\\", \\\"{x:1412,y:559,t:1527009557727};\\\", \\\"{x:1418,y:559,t:1527009557743};\\\", \\\"{x:1426,y:559,t:1527009557761};\\\", \\\"{x:1436,y:559,t:1527009557776};\\\", \\\"{x:1444,y:559,t:1527009557793};\\\", \\\"{x:1451,y:559,t:1527009557810};\\\", \\\"{x:1453,y:559,t:1527009557826};\\\", \\\"{x:1454,y:559,t:1527009557843};\\\", \\\"{x:1456,y:559,t:1527009557866};\\\", \\\"{x:1459,y:560,t:1527009557876};\\\", \\\"{x:1464,y:561,t:1527009557893};\\\", \\\"{x:1468,y:561,t:1527009557909};\\\", \\\"{x:1469,y:561,t:1527009557926};\\\", \\\"{x:1471,y:561,t:1527009557942};\\\", \\\"{x:1472,y:562,t:1527009557962};\\\", \\\"{x:1474,y:562,t:1527009557987};\\\", \\\"{x:1475,y:562,t:1527009557994};\\\", \\\"{x:1477,y:562,t:1527009558009};\\\", \\\"{x:1483,y:562,t:1527009558026};\\\", \\\"{x:1486,y:562,t:1527009558042};\\\", \\\"{x:1487,y:562,t:1527009558074};\\\", \\\"{x:1488,y:562,t:1527009558163};\\\", \\\"{x:1489,y:562,t:1527009558178};\\\", \\\"{x:1491,y:562,t:1527009558194};\\\", \\\"{x:1492,y:562,t:1527009558208};\\\", \\\"{x:1499,y:562,t:1527009558225};\\\", \\\"{x:1517,y:562,t:1527009558241};\\\", \\\"{x:1528,y:562,t:1527009558257};\\\", \\\"{x:1534,y:562,t:1527009558274};\\\", \\\"{x:1536,y:562,t:1527009558345};\\\", \\\"{x:1537,y:562,t:1527009558369};\\\", \\\"{x:1538,y:562,t:1527009558377};\\\", \\\"{x:1539,y:562,t:1527009558441};\\\", \\\"{x:1540,y:562,t:1527009558529};\\\", \\\"{x:1542,y:562,t:1527009558545};\\\", \\\"{x:1544,y:562,t:1527009558569};\\\", \\\"{x:1545,y:562,t:1527009558601};\\\", \\\"{x:1547,y:562,t:1527009558626};\\\", \\\"{x:1549,y:562,t:1527009558640};\\\", \\\"{x:1560,y:563,t:1527009558657};\\\", \\\"{x:1582,y:563,t:1527009558673};\\\", \\\"{x:1601,y:563,t:1527009558691};\\\", \\\"{x:1611,y:563,t:1527009558707};\\\", \\\"{x:1614,y:565,t:1527009558724};\\\", \\\"{x:1615,y:565,t:1527009558858};\\\", \\\"{x:1616,y:565,t:1527009558874};\\\", \\\"{x:1617,y:565,t:1527009559129};\\\", \\\"{x:1617,y:564,t:1527009559162};\\\", \\\"{x:1616,y:564,t:1527009559210};\\\", \\\"{x:1615,y:564,t:1527009559385};\\\", \\\"{x:1613,y:564,t:1527009560651};\\\", \\\"{x:1611,y:562,t:1527009560670};\\\", \\\"{x:1617,y:562,t:1527009560962};\\\", \\\"{x:1628,y:562,t:1527009560969};\\\", \\\"{x:1641,y:562,t:1527009560985};\\\", \\\"{x:1670,y:562,t:1527009561001};\\\", \\\"{x:1704,y:562,t:1527009561017};\\\", \\\"{x:1708,y:562,t:1527009561034};\\\", \\\"{x:1709,y:561,t:1527009561123};\\\", \\\"{x:1709,y:560,t:1527009561170};\\\", \\\"{x:1708,y:560,t:1527009561186};\\\", \\\"{x:1705,y:560,t:1527009561201};\\\", \\\"{x:1703,y:560,t:1527009561217};\\\", \\\"{x:1701,y:562,t:1527009561234};\\\", \\\"{x:1699,y:562,t:1527009561250};\\\", \\\"{x:1698,y:562,t:1527009561274};\\\", \\\"{x:1696,y:562,t:1527009561290};\\\", \\\"{x:1695,y:562,t:1527009561300};\\\", \\\"{x:1691,y:562,t:1527009561317};\\\", \\\"{x:1685,y:562,t:1527009561334};\\\", \\\"{x:1679,y:562,t:1527009561350};\\\", \\\"{x:1673,y:562,t:1527009561367};\\\", \\\"{x:1669,y:562,t:1527009561384};\\\", \\\"{x:1670,y:562,t:1527009561570};\\\", \\\"{x:1671,y:562,t:1527009561583};\\\", \\\"{x:1672,y:562,t:1527009561602};\\\", \\\"{x:1673,y:562,t:1527009561618};\\\", \\\"{x:1674,y:562,t:1527009561659};\\\", \\\"{x:1675,y:562,t:1527009561754};\\\", \\\"{x:1676,y:562,t:1527009561995};\\\", \\\"{x:1677,y:563,t:1527009562058};\\\", \\\"{x:1678,y:563,t:1527009562147};\\\", \\\"{x:1679,y:563,t:1527009562154};\\\", \\\"{x:1680,y:563,t:1527009562402};\\\", \\\"{x:1677,y:563,t:1527009563522};\\\", \\\"{x:1663,y:563,t:1527009563530};\\\", \\\"{x:1639,y:563,t:1527009563545};\\\", \\\"{x:1547,y:563,t:1527009563561};\\\", \\\"{x:1328,y:563,t:1527009563578};\\\", \\\"{x:1146,y:565,t:1527009563594};\\\", \\\"{x:975,y:565,t:1527009563611};\\\", \\\"{x:806,y:567,t:1527009563629};\\\", \\\"{x:681,y:566,t:1527009563644};\\\", \\\"{x:559,y:569,t:1527009563676};\\\", \\\"{x:543,y:569,t:1527009563692};\\\", \\\"{x:539,y:569,t:1527009563710};\\\", \\\"{x:538,y:569,t:1527009563726};\\\", \\\"{x:537,y:569,t:1527009563777};\\\", \\\"{x:534,y:569,t:1527009563792};\\\", \\\"{x:523,y:569,t:1527009563810};\\\", \\\"{x:512,y:569,t:1527009563827};\\\", \\\"{x:499,y:569,t:1527009563842};\\\", \\\"{x:487,y:569,t:1527009563860};\\\", \\\"{x:480,y:569,t:1527009563877};\\\", \\\"{x:475,y:569,t:1527009563893};\\\", \\\"{x:473,y:569,t:1527009563909};\\\", \\\"{x:471,y:570,t:1527009563927};\\\", \\\"{x:468,y:572,t:1527009563943};\\\", \\\"{x:457,y:575,t:1527009563960};\\\", \\\"{x:441,y:579,t:1527009563977};\\\", \\\"{x:419,y:584,t:1527009563992};\\\", \\\"{x:390,y:586,t:1527009564010};\\\", \\\"{x:380,y:586,t:1527009564027};\\\", \\\"{x:377,y:586,t:1527009564044};\\\", \\\"{x:378,y:582,t:1527009564059};\\\", \\\"{x:387,y:573,t:1527009564076};\\\", \\\"{x:412,y:564,t:1527009564097};\\\", \\\"{x:456,y:556,t:1527009564110};\\\", \\\"{x:520,y:547,t:1527009564127};\\\", \\\"{x:578,y:539,t:1527009564144};\\\", \\\"{x:611,y:538,t:1527009564159};\\\", \\\"{x:626,y:538,t:1527009564176};\\\", \\\"{x:629,y:538,t:1527009564193};\\\", \\\"{x:629,y:537,t:1527009564297};\\\", \\\"{x:629,y:536,t:1527009564311};\\\", \\\"{x:629,y:534,t:1527009564326};\\\", \\\"{x:623,y:528,t:1527009564343};\\\", \\\"{x:620,y:524,t:1527009564361};\\\", \\\"{x:619,y:519,t:1527009564378};\\\", \\\"{x:619,y:514,t:1527009564394};\\\", \\\"{x:619,y:512,t:1527009564410};\\\", \\\"{x:619,y:511,t:1527009564427};\\\", \\\"{x:619,y:510,t:1527009564443};\\\", \\\"{x:619,y:509,t:1527009564473};\\\", \\\"{x:619,y:508,t:1527009564481};\\\", \\\"{x:619,y:507,t:1527009564494};\\\", \\\"{x:619,y:506,t:1527009564510};\\\", \\\"{x:618,y:502,t:1527009564526};\\\", \\\"{x:618,y:501,t:1527009564561};\\\", \\\"{x:618,y:500,t:1527009564577};\\\", \\\"{x:619,y:499,t:1527009564849};\\\", \\\"{x:624,y:501,t:1527009564861};\\\", \\\"{x:642,y:507,t:1527009564877};\\\", \\\"{x:681,y:521,t:1527009564894};\\\", \\\"{x:756,y:541,t:1527009564911};\\\", \\\"{x:845,y:566,t:1527009564928};\\\", \\\"{x:954,y:589,t:1527009564944};\\\", \\\"{x:1052,y:608,t:1527009564960};\\\", \\\"{x:1158,y:627,t:1527009564978};\\\", \\\"{x:1201,y:635,t:1527009564993};\\\", \\\"{x:1223,y:639,t:1527009565011};\\\", \\\"{x:1231,y:640,t:1527009565028};\\\", \\\"{x:1234,y:640,t:1527009565045};\\\", \\\"{x:1238,y:637,t:1527009565061};\\\", \\\"{x:1248,y:628,t:1527009565078};\\\", \\\"{x:1274,y:615,t:1527009565095};\\\", \\\"{x:1327,y:590,t:1527009565111};\\\", \\\"{x:1397,y:558,t:1527009565128};\\\", \\\"{x:1486,y:533,t:1527009565145};\\\", \\\"{x:1557,y:517,t:1527009565162};\\\", \\\"{x:1610,y:508,t:1527009565178};\\\", \\\"{x:1616,y:508,t:1527009565195};\\\", \\\"{x:1618,y:506,t:1527009565235};\\\", \\\"{x:1615,y:505,t:1527009565250};\\\", \\\"{x:1610,y:505,t:1527009565263};\\\", \\\"{x:1601,y:500,t:1527009565279};\\\", \\\"{x:1592,y:491,t:1527009565295};\\\", \\\"{x:1581,y:471,t:1527009565313};\\\", \\\"{x:1569,y:437,t:1527009565329};\\\", \\\"{x:1563,y:395,t:1527009565345};\\\", \\\"{x:1567,y:307,t:1527009565362};\\\", \\\"{x:1584,y:251,t:1527009565380};\\\", \\\"{x:1595,y:228,t:1527009565395};\\\", \\\"{x:1601,y:219,t:1527009565412};\\\", \\\"{x:1602,y:219,t:1527009565429};\\\", \\\"{x:1603,y:220,t:1527009565446};\\\", \\\"{x:1603,y:232,t:1527009565462};\\\", \\\"{x:1591,y:257,t:1527009565479};\\\", \\\"{x:1574,y:286,t:1527009565496};\\\", \\\"{x:1557,y:310,t:1527009565512};\\\", \\\"{x:1544,y:324,t:1527009565529};\\\", \\\"{x:1539,y:327,t:1527009565546};\\\", \\\"{x:1538,y:327,t:1527009565586};\\\", \\\"{x:1536,y:327,t:1527009565601};\\\", \\\"{x:1534,y:327,t:1527009565612};\\\", \\\"{x:1524,y:324,t:1527009565629};\\\", \\\"{x:1512,y:316,t:1527009565646};\\\", \\\"{x:1502,y:310,t:1527009565663};\\\", \\\"{x:1496,y:304,t:1527009565680};\\\", \\\"{x:1495,y:301,t:1527009565696};\\\", \\\"{x:1492,y:296,t:1527009565713};\\\", \\\"{x:1491,y:290,t:1527009565729};\\\", \\\"{x:1491,y:285,t:1527009565745};\\\", \\\"{x:1490,y:286,t:1527009566411};\\\", \\\"{x:1487,y:290,t:1527009566418};\\\", \\\"{x:1481,y:299,t:1527009566432};\\\", \\\"{x:1461,y:314,t:1527009566449};\\\", \\\"{x:1413,y:338,t:1527009566466};\\\", \\\"{x:1265,y:388,t:1527009566482};\\\", \\\"{x:1122,y:424,t:1527009566499};\\\", \\\"{x:975,y:464,t:1527009566516};\\\", \\\"{x:815,y:508,t:1527009566534};\\\", \\\"{x:680,y:567,t:1527009566548};\\\", \\\"{x:568,y:613,t:1527009566562};\\\", \\\"{x:507,y:641,t:1527009566579};\\\", \\\"{x:478,y:657,t:1527009566596};\\\", \\\"{x:474,y:663,t:1527009566612};\\\", \\\"{x:481,y:676,t:1527009566629};\\\", \\\"{x:493,y:689,t:1527009566645};\\\", \\\"{x:505,y:706,t:1527009566662};\\\", \\\"{x:512,y:720,t:1527009566679};\\\", \\\"{x:516,y:729,t:1527009566696};\\\", \\\"{x:517,y:735,t:1527009566711};\\\", \\\"{x:519,y:740,t:1527009566728};\\\", \\\"{x:520,y:743,t:1527009566745};\\\", \\\"{x:520,y:745,t:1527009566761};\\\", \\\"{x:520,y:746,t:1527009566779};\\\", \\\"{x:520,y:749,t:1527009566796};\\\", \\\"{x:519,y:750,t:1527009566811};\\\", \\\"{x:519,y:751,t:1527009566834};\\\", \\\"{x:518,y:751,t:1527009566906};\\\", \\\"{x:517,y:751,t:1527009567026};\\\", \\\"{x:516,y:751,t:1527009567058};\\\", \\\"{x:516,y:749,t:1527009567074};\\\", \\\"{x:516,y:747,t:1527009567082};\\\", \\\"{x:516,y:746,t:1527009567095};\\\", \\\"{x:517,y:742,t:1527009567112};\\\", \\\"{x:519,y:739,t:1527009567129};\\\", \\\"{x:519,y:735,t:1527009567145};\\\", \\\"{x:520,y:735,t:1527009567161};\\\", \\\"{x:521,y:735,t:1527009567196};\\\", \\\"{x:521,y:735,t:1527009567293};\\\", \\\"{x:522,y:733,t:1527009567313};\\\", \\\"{x:547,y:726,t:1527009567329};\\\", \\\"{x:584,y:720,t:1527009567346};\\\", \\\"{x:643,y:710,t:1527009567363};\\\", \\\"{x:703,y:705,t:1527009567378};\\\", \\\"{x:808,y:695,t:1527009567395};\\\", \\\"{x:908,y:691,t:1527009567412};\\\", \\\"{x:1019,y:691,t:1527009567429};\\\", \\\"{x:1134,y:681,t:1527009567445};\\\", \\\"{x:1225,y:673,t:1527009567463};\\\", \\\"{x:1294,y:665,t:1527009567479};\\\", \\\"{x:1343,y:656,t:1527009567495};\\\", \\\"{x:1365,y:651,t:1527009567512};\\\", \\\"{x:1369,y:650,t:1527009567530};\\\" ] }, { \\\"rt\\\": 63697, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 778401, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -N \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1368,y:650,t:1527009568617};\\\", \\\"{x:1319,y:643,t:1527009568646};\\\", \\\"{x:1241,y:619,t:1527009568664};\\\", \\\"{x:1137,y:578,t:1527009568680};\\\", \\\"{x:1005,y:524,t:1527009568697};\\\", \\\"{x:825,y:450,t:1527009568713};\\\", \\\"{x:733,y:410,t:1527009568731};\\\", \\\"{x:692,y:385,t:1527009568747};\\\", \\\"{x:676,y:372,t:1527009568764};\\\", \\\"{x:672,y:368,t:1527009568781};\\\", \\\"{x:672,y:367,t:1527009568797};\\\", \\\"{x:673,y:368,t:1527009568849};\\\", \\\"{x:676,y:373,t:1527009568864};\\\", \\\"{x:676,y:450,t:1527009568951};\\\", \\\"{x:673,y:457,t:1527009568963};\\\", \\\"{x:669,y:462,t:1527009568981};\\\", \\\"{x:664,y:466,t:1527009568997};\\\", \\\"{x:658,y:469,t:1527009569014};\\\", \\\"{x:649,y:473,t:1527009569030};\\\", \\\"{x:634,y:478,t:1527009569047};\\\", \\\"{x:615,y:484,t:1527009569064};\\\", \\\"{x:591,y:485,t:1527009569080};\\\", \\\"{x:582,y:485,t:1527009569097};\\\", \\\"{x:561,y:483,t:1527009569114};\\\", \\\"{x:546,y:479,t:1527009569131};\\\", \\\"{x:539,y:474,t:1527009569147};\\\", \\\"{x:535,y:473,t:1527009569163};\\\", \\\"{x:533,y:472,t:1527009569181};\\\", \\\"{x:533,y:471,t:1527009569234};\\\", \\\"{x:532,y:471,t:1527009569313};\\\", \\\"{x:531,y:470,t:1527009569331};\\\", \\\"{x:530,y:470,t:1527009569348};\\\", \\\"{x:530,y:468,t:1527009569364};\\\", \\\"{x:528,y:466,t:1527009569381};\\\", \\\"{x:527,y:464,t:1527009569397};\\\", \\\"{x:526,y:463,t:1527009569414};\\\", \\\"{x:525,y:462,t:1527009569431};\\\", \\\"{x:524,y:461,t:1527009569448};\\\", \\\"{x:522,y:460,t:1527009569464};\\\", \\\"{x:522,y:461,t:1527009569561};\\\", \\\"{x:523,y:462,t:1527009569569};\\\", \\\"{x:524,y:462,t:1527009569580};\\\", \\\"{x:528,y:464,t:1527009569598};\\\", \\\"{x:543,y:467,t:1527009569614};\\\", \\\"{x:583,y:479,t:1527009569631};\\\", \\\"{x:665,y:496,t:1527009569649};\\\", \\\"{x:774,y:518,t:1527009569665};\\\", \\\"{x:902,y:537,t:1527009569681};\\\", \\\"{x:1116,y:567,t:1527009569699};\\\", \\\"{x:1249,y:584,t:1527009569715};\\\", \\\"{x:1352,y:600,t:1527009569731};\\\", \\\"{x:1413,y:610,t:1527009569748};\\\", \\\"{x:1441,y:618,t:1527009569766};\\\", \\\"{x:1450,y:622,t:1527009569781};\\\", \\\"{x:1450,y:623,t:1527009569810};\\\", \\\"{x:1450,y:625,t:1527009569819};\\\", \\\"{x:1450,y:627,t:1527009569831};\\\", \\\"{x:1450,y:636,t:1527009569848};\\\", \\\"{x:1452,y:652,t:1527009569865};\\\", \\\"{x:1455,y:667,t:1527009569881};\\\", \\\"{x:1460,y:688,t:1527009569898};\\\", \\\"{x:1463,y:697,t:1527009569915};\\\", \\\"{x:1465,y:701,t:1527009569931};\\\", \\\"{x:1465,y:702,t:1527009569948};\\\", \\\"{x:1467,y:704,t:1527009569965};\\\", \\\"{x:1468,y:707,t:1527009569981};\\\", \\\"{x:1469,y:710,t:1527009569998};\\\", \\\"{x:1469,y:712,t:1527009570015};\\\", \\\"{x:1469,y:714,t:1527009570031};\\\", \\\"{x:1469,y:715,t:1527009570048};\\\", \\\"{x:1470,y:718,t:1527009570065};\\\", \\\"{x:1475,y:723,t:1527009570082};\\\", \\\"{x:1481,y:726,t:1527009570097};\\\", \\\"{x:1487,y:729,t:1527009570114};\\\", \\\"{x:1492,y:733,t:1527009570131};\\\", \\\"{x:1502,y:737,t:1527009570148};\\\", \\\"{x:1511,y:742,t:1527009570165};\\\", \\\"{x:1521,y:747,t:1527009570181};\\\", \\\"{x:1526,y:751,t:1527009570198};\\\", \\\"{x:1528,y:756,t:1527009570215};\\\", \\\"{x:1528,y:761,t:1527009570231};\\\", \\\"{x:1528,y:762,t:1527009570248};\\\", \\\"{x:1528,y:764,t:1527009570264};\\\", \\\"{x:1528,y:767,t:1527009570282};\\\", \\\"{x:1527,y:770,t:1527009570298};\\\", \\\"{x:1524,y:776,t:1527009570315};\\\", \\\"{x:1524,y:779,t:1527009570332};\\\", \\\"{x:1520,y:784,t:1527009570349};\\\", \\\"{x:1520,y:787,t:1527009570364};\\\", \\\"{x:1520,y:790,t:1527009570382};\\\", \\\"{x:1528,y:796,t:1527009570398};\\\", \\\"{x:1541,y:801,t:1527009570415};\\\", \\\"{x:1564,y:805,t:1527009570431};\\\", \\\"{x:1583,y:810,t:1527009570449};\\\", \\\"{x:1594,y:810,t:1527009570465};\\\", \\\"{x:1617,y:815,t:1527009570482};\\\", \\\"{x:1647,y:818,t:1527009570498};\\\", \\\"{x:1652,y:819,t:1527009570515};\\\", \\\"{x:1652,y:820,t:1527009570531};\\\", \\\"{x:1653,y:820,t:1527009570609};\\\", \\\"{x:1654,y:820,t:1527009570633};\\\", \\\"{x:1654,y:819,t:1527009570658};\\\", \\\"{x:1655,y:819,t:1527009570721};\\\", \\\"{x:1657,y:820,t:1527009570732};\\\", \\\"{x:1664,y:828,t:1527009570748};\\\", \\\"{x:1675,y:847,t:1527009570764};\\\", \\\"{x:1687,y:865,t:1527009570781};\\\", \\\"{x:1695,y:875,t:1527009570798};\\\", \\\"{x:1701,y:879,t:1527009570814};\\\", \\\"{x:1702,y:882,t:1527009570831};\\\", \\\"{x:1703,y:883,t:1527009570847};\\\", \\\"{x:1703,y:884,t:1527009570864};\\\", \\\"{x:1703,y:886,t:1527009570881};\\\", \\\"{x:1700,y:889,t:1527009570897};\\\", \\\"{x:1693,y:894,t:1527009570915};\\\", \\\"{x:1686,y:897,t:1527009570932};\\\", \\\"{x:1676,y:902,t:1527009570948};\\\", \\\"{x:1668,y:906,t:1527009570965};\\\", \\\"{x:1661,y:911,t:1527009570982};\\\", \\\"{x:1656,y:917,t:1527009570997};\\\", \\\"{x:1654,y:921,t:1527009571015};\\\", \\\"{x:1652,y:925,t:1527009571032};\\\", \\\"{x:1651,y:928,t:1527009571047};\\\", \\\"{x:1650,y:933,t:1527009571064};\\\", \\\"{x:1649,y:938,t:1527009571082};\\\", \\\"{x:1648,y:941,t:1527009571098};\\\", \\\"{x:1645,y:946,t:1527009571114};\\\", \\\"{x:1644,y:947,t:1527009571131};\\\", \\\"{x:1641,y:948,t:1527009571147};\\\", \\\"{x:1638,y:950,t:1527009571165};\\\", \\\"{x:1629,y:952,t:1527009571181};\\\", \\\"{x:1622,y:953,t:1527009571198};\\\", \\\"{x:1610,y:954,t:1527009571215};\\\", \\\"{x:1599,y:955,t:1527009571231};\\\", \\\"{x:1590,y:957,t:1527009571247};\\\", \\\"{x:1585,y:957,t:1527009571264};\\\", \\\"{x:1576,y:959,t:1527009571282};\\\", \\\"{x:1573,y:960,t:1527009571298};\\\", \\\"{x:1568,y:961,t:1527009571315};\\\", \\\"{x:1563,y:963,t:1527009571332};\\\", \\\"{x:1558,y:964,t:1527009571348};\\\", \\\"{x:1554,y:965,t:1527009571365};\\\", \\\"{x:1550,y:966,t:1527009571382};\\\", \\\"{x:1548,y:966,t:1527009571397};\\\", \\\"{x:1547,y:966,t:1527009571414};\\\", \\\"{x:1546,y:966,t:1527009571473};\\\", \\\"{x:1545,y:966,t:1527009571489};\\\", \\\"{x:1545,y:965,t:1527009571545};\\\", \\\"{x:1544,y:964,t:1527009571553};\\\", \\\"{x:1544,y:962,t:1527009571577};\\\", \\\"{x:1544,y:961,t:1527009571593};\\\", \\\"{x:1544,y:960,t:1527009571601};\\\", \\\"{x:1544,y:959,t:1527009571614};\\\", \\\"{x:1545,y:953,t:1527009571630};\\\", \\\"{x:1546,y:945,t:1527009571647};\\\", \\\"{x:1551,y:936,t:1527009571664};\\\", \\\"{x:1557,y:927,t:1527009571680};\\\", \\\"{x:1566,y:913,t:1527009571697};\\\", \\\"{x:1572,y:902,t:1527009571714};\\\", \\\"{x:1580,y:893,t:1527009571730};\\\", \\\"{x:1589,y:880,t:1527009571747};\\\", \\\"{x:1596,y:868,t:1527009571765};\\\", \\\"{x:1604,y:858,t:1527009571780};\\\", \\\"{x:1610,y:851,t:1527009571797};\\\", \\\"{x:1613,y:843,t:1527009571814};\\\", \\\"{x:1618,y:835,t:1527009571830};\\\", \\\"{x:1620,y:829,t:1527009571847};\\\", \\\"{x:1626,y:820,t:1527009571864};\\\", \\\"{x:1631,y:808,t:1527009571880};\\\", \\\"{x:1637,y:792,t:1527009571898};\\\", \\\"{x:1642,y:783,t:1527009571913};\\\", \\\"{x:1643,y:781,t:1527009571930};\\\", \\\"{x:1643,y:780,t:1527009571947};\\\", \\\"{x:1643,y:779,t:1527009571964};\\\", \\\"{x:1643,y:776,t:1527009571980};\\\", \\\"{x:1644,y:775,t:1527009571997};\\\", \\\"{x:1645,y:770,t:1527009572014};\\\", \\\"{x:1645,y:768,t:1527009572031};\\\", \\\"{x:1646,y:766,t:1527009572047};\\\", \\\"{x:1648,y:762,t:1527009572064};\\\", \\\"{x:1648,y:760,t:1527009572080};\\\", \\\"{x:1648,y:759,t:1527009572145};\\\", \\\"{x:1649,y:759,t:1527009572354};\\\", \\\"{x:1650,y:759,t:1527009572386};\\\", \\\"{x:1651,y:759,t:1527009572402};\\\", \\\"{x:1651,y:760,t:1527009572413};\\\", \\\"{x:1652,y:761,t:1527009572450};\\\", \\\"{x:1652,y:762,t:1527009572521};\\\", \\\"{x:1651,y:763,t:1527009572587};\\\", \\\"{x:1650,y:764,t:1527009572602};\\\", \\\"{x:1649,y:764,t:1527009572613};\\\", \\\"{x:1648,y:764,t:1527009573161};\\\", \\\"{x:1647,y:764,t:1527009573169};\\\", \\\"{x:1646,y:764,t:1527009573298};\\\", \\\"{x:1645,y:764,t:1527009573345};\\\", \\\"{x:1644,y:764,t:1527009573434};\\\", \\\"{x:1645,y:764,t:1527009573790};\\\", \\\"{x:1646,y:764,t:1527009578830};\\\", \\\"{x:1602,y:758,t:1527009578848};\\\", \\\"{x:1496,y:736,t:1527009578865};\\\", \\\"{x:1360,y:717,t:1527009578881};\\\", \\\"{x:1219,y:696,t:1527009578898};\\\", \\\"{x:1099,y:677,t:1527009578915};\\\", \\\"{x:1016,y:666,t:1527009578931};\\\", \\\"{x:971,y:660,t:1527009578947};\\\", \\\"{x:942,y:657,t:1527009578964};\\\", \\\"{x:941,y:657,t:1527009578980};\\\", \\\"{x:940,y:657,t:1527009578997};\\\", \\\"{x:939,y:657,t:1527009579028};\\\", \\\"{x:938,y:657,t:1527009579044};\\\", \\\"{x:935,y:657,t:1527009579052};\\\", \\\"{x:931,y:657,t:1527009579064};\\\", \\\"{x:918,y:657,t:1527009579081};\\\", \\\"{x:895,y:657,t:1527009579098};\\\", \\\"{x:872,y:657,t:1527009579114};\\\", \\\"{x:834,y:654,t:1527009579130};\\\", \\\"{x:792,y:646,t:1527009579148};\\\", \\\"{x:709,y:636,t:1527009579164};\\\", \\\"{x:653,y:626,t:1527009579182};\\\", \\\"{x:572,y:613,t:1527009579198};\\\", \\\"{x:500,y:604,t:1527009579213};\\\", \\\"{x:468,y:601,t:1527009579226};\\\", \\\"{x:433,y:600,t:1527009579243};\\\", \\\"{x:410,y:596,t:1527009579259};\\\", \\\"{x:403,y:596,t:1527009579275};\\\", \\\"{x:402,y:596,t:1527009579293};\\\", \\\"{x:401,y:596,t:1527009579310};\\\", \\\"{x:398,y:596,t:1527009579325};\\\", \\\"{x:389,y:596,t:1527009579342};\\\", \\\"{x:373,y:598,t:1527009579359};\\\", \\\"{x:357,y:599,t:1527009579375};\\\", \\\"{x:340,y:599,t:1527009579393};\\\", \\\"{x:325,y:599,t:1527009579409};\\\", \\\"{x:314,y:599,t:1527009579425};\\\", \\\"{x:306,y:598,t:1527009579442};\\\", \\\"{x:305,y:597,t:1527009579493};\\\", \\\"{x:305,y:598,t:1527009579557};\\\", \\\"{x:305,y:600,t:1527009579573};\\\", \\\"{x:305,y:601,t:1527009579582};\\\", \\\"{x:305,y:602,t:1527009579596};\\\", \\\"{x:305,y:601,t:1527009579684};\\\", \\\"{x:303,y:600,t:1527009579694};\\\", \\\"{x:294,y:596,t:1527009579710};\\\", \\\"{x:284,y:594,t:1527009579726};\\\", \\\"{x:275,y:591,t:1527009579743};\\\", \\\"{x:267,y:589,t:1527009579760};\\\", \\\"{x:263,y:587,t:1527009579776};\\\", \\\"{x:262,y:587,t:1527009579792};\\\", \\\"{x:262,y:585,t:1527009579809};\\\", \\\"{x:263,y:582,t:1527009579826};\\\", \\\"{x:283,y:578,t:1527009579843};\\\", \\\"{x:306,y:573,t:1527009579859};\\\", \\\"{x:337,y:568,t:1527009579877};\\\", \\\"{x:360,y:567,t:1527009579892};\\\", \\\"{x:383,y:567,t:1527009579910};\\\", \\\"{x:411,y:567,t:1527009579927};\\\", \\\"{x:445,y:567,t:1527009579942};\\\", \\\"{x:484,y:567,t:1527009579959};\\\", \\\"{x:529,y:567,t:1527009579977};\\\", \\\"{x:568,y:567,t:1527009579993};\\\", \\\"{x:600,y:567,t:1527009580010};\\\", \\\"{x:627,y:567,t:1527009580027};\\\", \\\"{x:653,y:567,t:1527009580043};\\\", \\\"{x:673,y:567,t:1527009580059};\\\", \\\"{x:695,y:567,t:1527009580076};\\\", \\\"{x:705,y:567,t:1527009580094};\\\", \\\"{x:716,y:567,t:1527009580110};\\\", \\\"{x:721,y:567,t:1527009580126};\\\", \\\"{x:727,y:565,t:1527009580144};\\\", \\\"{x:728,y:565,t:1527009580159};\\\", \\\"{x:729,y:565,t:1527009580188};\\\", \\\"{x:730,y:565,t:1527009580269};\\\", \\\"{x:730,y:567,t:1527009580276};\\\", \\\"{x:727,y:573,t:1527009580294};\\\", \\\"{x:714,y:581,t:1527009580311};\\\", \\\"{x:695,y:589,t:1527009580326};\\\", \\\"{x:678,y:594,t:1527009580344};\\\", \\\"{x:659,y:599,t:1527009580359};\\\", \\\"{x:643,y:601,t:1527009580377};\\\", \\\"{x:635,y:601,t:1527009580393};\\\", \\\"{x:627,y:601,t:1527009580409};\\\", \\\"{x:624,y:601,t:1527009580427};\\\", \\\"{x:623,y:601,t:1527009580443};\\\", \\\"{x:622,y:601,t:1527009580460};\\\", \\\"{x:620,y:600,t:1527009580476};\\\", \\\"{x:620,y:597,t:1527009580493};\\\", \\\"{x:620,y:594,t:1527009580511};\\\", \\\"{x:618,y:591,t:1527009580527};\\\", \\\"{x:616,y:589,t:1527009580543};\\\", \\\"{x:615,y:586,t:1527009580561};\\\", \\\"{x:613,y:585,t:1527009580576};\\\", \\\"{x:612,y:583,t:1527009580594};\\\", \\\"{x:613,y:582,t:1527009580780};\\\", \\\"{x:620,y:582,t:1527009580794};\\\", \\\"{x:628,y:585,t:1527009580811};\\\", \\\"{x:664,y:592,t:1527009580827};\\\", \\\"{x:789,y:632,t:1527009580844};\\\", \\\"{x:999,y:686,t:1527009580860};\\\", \\\"{x:1142,y:723,t:1527009580877};\\\", \\\"{x:1315,y:763,t:1527009580893};\\\", \\\"{x:1463,y:794,t:1527009580910};\\\", \\\"{x:1579,y:810,t:1527009580928};\\\", \\\"{x:1650,y:815,t:1527009580944};\\\", \\\"{x:1678,y:816,t:1527009580960};\\\", \\\"{x:1689,y:816,t:1527009580977};\\\", \\\"{x:1690,y:816,t:1527009580994};\\\", \\\"{x:1690,y:815,t:1527009581028};\\\", \\\"{x:1690,y:814,t:1527009581043};\\\", \\\"{x:1690,y:810,t:1527009581060};\\\", \\\"{x:1690,y:805,t:1527009581077};\\\", \\\"{x:1693,y:797,t:1527009581093};\\\", \\\"{x:1693,y:791,t:1527009581111};\\\", \\\"{x:1693,y:782,t:1527009581128};\\\", \\\"{x:1693,y:776,t:1527009581144};\\\", \\\"{x:1688,y:771,t:1527009581161};\\\", \\\"{x:1684,y:768,t:1527009581178};\\\", \\\"{x:1680,y:767,t:1527009581194};\\\", \\\"{x:1677,y:766,t:1527009581211};\\\", \\\"{x:1669,y:766,t:1527009581228};\\\", \\\"{x:1660,y:766,t:1527009581244};\\\", \\\"{x:1642,y:766,t:1527009581261};\\\", \\\"{x:1631,y:766,t:1527009581278};\\\", \\\"{x:1628,y:766,t:1527009581295};\\\", \\\"{x:1627,y:766,t:1527009581311};\\\", \\\"{x:1627,y:765,t:1527009581430};\\\", \\\"{x:1627,y:764,t:1527009581485};\\\", \\\"{x:1628,y:764,t:1527009581493};\\\", \\\"{x:1631,y:762,t:1527009581510};\\\", \\\"{x:1632,y:762,t:1527009581527};\\\", \\\"{x:1634,y:762,t:1527009581545};\\\", \\\"{x:1635,y:762,t:1527009581560};\\\", \\\"{x:1637,y:762,t:1527009581578};\\\", \\\"{x:1638,y:762,t:1527009581733};\\\", \\\"{x:1639,y:762,t:1527009581765};\\\", \\\"{x:1640,y:762,t:1527009581805};\\\", \\\"{x:1641,y:762,t:1527009581846};\\\", \\\"{x:1642,y:762,t:1527009581877};\\\", \\\"{x:1643,y:762,t:1527009581895};\\\", \\\"{x:1644,y:762,t:1527009581917};\\\", \\\"{x:1643,y:762,t:1527009591661};\\\", \\\"{x:1642,y:762,t:1527009591669};\\\", \\\"{x:1641,y:762,t:1527009591685};\\\", \\\"{x:1640,y:761,t:1527009591837};\\\", \\\"{x:1638,y:760,t:1527009591851};\\\", \\\"{x:1637,y:760,t:1527009591868};\\\", \\\"{x:1631,y:757,t:1527009591885};\\\", \\\"{x:1623,y:755,t:1527009591901};\\\", \\\"{x:1618,y:753,t:1527009591917};\\\", \\\"{x:1613,y:752,t:1527009591934};\\\", \\\"{x:1610,y:751,t:1527009591951};\\\", \\\"{x:1610,y:749,t:1527009592414};\\\", \\\"{x:1613,y:748,t:1527009592421};\\\", \\\"{x:1618,y:747,t:1527009592435};\\\", \\\"{x:1621,y:746,t:1527009592452};\\\", \\\"{x:1622,y:746,t:1527009592469};\\\", \\\"{x:1623,y:746,t:1527009592542};\\\", \\\"{x:1627,y:746,t:1527009592551};\\\", \\\"{x:1642,y:752,t:1527009592569};\\\", \\\"{x:1651,y:755,t:1527009592585};\\\", \\\"{x:1653,y:756,t:1527009592602};\\\", \\\"{x:1654,y:757,t:1527009592629};\\\", \\\"{x:1655,y:758,t:1527009592861};\\\", \\\"{x:1655,y:759,t:1527009592868};\\\", \\\"{x:1654,y:761,t:1527009592884};\\\", \\\"{x:1651,y:763,t:1527009592901};\\\", \\\"{x:1650,y:763,t:1527009592918};\\\", \\\"{x:1648,y:764,t:1527009592934};\\\", \\\"{x:1646,y:764,t:1527009592951};\\\", \\\"{x:1644,y:766,t:1527009592968};\\\", \\\"{x:1643,y:767,t:1527009592984};\\\", \\\"{x:1643,y:768,t:1527009593429};\\\", \\\"{x:1643,y:769,t:1527009593445};\\\", \\\"{x:1644,y:769,t:1527009593461};\\\", \\\"{x:1645,y:769,t:1527009593469};\\\", \\\"{x:1646,y:769,t:1527009593486};\\\", \\\"{x:1648,y:770,t:1527009593502};\\\", \\\"{x:1649,y:770,t:1527009593549};\\\", \\\"{x:1628,y:762,t:1527009631469};\\\", \\\"{x:1527,y:739,t:1527009631477};\\\", \\\"{x:1229,y:698,t:1527009631492};\\\", \\\"{x:882,y:666,t:1527009631509};\\\", \\\"{x:584,y:667,t:1527009631525};\\\", \\\"{x:448,y:712,t:1527009631541};\\\", \\\"{x:401,y:756,t:1527009631559};\\\", \\\"{x:388,y:779,t:1527009631574};\\\", \\\"{x:387,y:795,t:1527009631592};\\\", \\\"{x:397,y:815,t:1527009631608};\\\", \\\"{x:413,y:834,t:1527009631625};\\\", \\\"{x:420,y:852,t:1527009631641};\\\", \\\"{x:423,y:863,t:1527009631658};\\\", \\\"{x:424,y:871,t:1527009631675};\\\", \\\"{x:424,y:872,t:1527009631716};\\\", \\\"{x:424,y:873,t:1527009631748};\\\", \\\"{x:423,y:873,t:1527009631759};\\\", \\\"{x:423,y:858,t:1527009631775};\\\", \\\"{x:430,y:837,t:1527009631792};\\\", \\\"{x:432,y:831,t:1527009631809};\\\", \\\"{x:433,y:826,t:1527009631826};\\\", \\\"{x:434,y:821,t:1527009631842};\\\", \\\"{x:436,y:817,t:1527009631858};\\\", \\\"{x:439,y:805,t:1527009631876};\\\", \\\"{x:442,y:796,t:1527009631892};\\\", \\\"{x:445,y:784,t:1527009631909};\\\", \\\"{x:447,y:773,t:1527009631925};\\\", \\\"{x:452,y:760,t:1527009631942};\\\", \\\"{x:453,y:754,t:1527009631959};\\\", \\\"{x:454,y:754,t:1527009631977};\\\", \\\"{x:454,y:752,t:1527009632011};\\\", \\\"{x:455,y:752,t:1527009632019};\\\", \\\"{x:457,y:750,t:1527009632036};\\\", \\\"{x:460,y:745,t:1527009632053};\\\", \\\"{x:460,y:743,t:1527009632069};\\\", \\\"{x:461,y:742,t:1527009632085};\\\", \\\"{x:461,y:740,t:1527009632339};\\\", \\\"{x:460,y:740,t:1527009632387};\\\", \\\"{x:457,y:740,t:1527009632403};\\\", \\\"{x:428,y:779,t:1527009632419};\\\", \\\"{x:370,y:888,t:1527009632437};\\\", \\\"{x:298,y:1080,t:1527009632453};\\\", \\\"{x:214,y:1215,t:1527009632470};\\\", \\\"{x:150,y:1215,t:1527009632487};\\\", \\\"{x:130,y:1215,t:1527009632503};\\\", \\\"{x:135,y:1215,t:1527009632520};\\\", \\\"{x:173,y:1215,t:1527009632537};\\\", \\\"{x:237,y:1215,t:1527009632554};\\\", \\\"{x:313,y:1214,t:1527009632570};\\\", \\\"{x:315,y:1215,t:1527009632587};\\\", \\\"{x:414,y:1139,t:1527009632651};\\\", \\\"{x:665,y:965,t:1527009632659};\\\", \\\"{x:905,y:785,t:1527009632669};\\\", \\\"{x:1267,y:446,t:1527009632687};\\\", \\\"{x:1488,y:145,t:1527009632703};\\\", \\\"{x:1579,y:16,t:1527009632720};\\\", \\\"{x:1583,y:16,t:1527009632737};\\\", \\\"{x:1532,y:16,t:1527009632754};\\\", \\\"{x:1426,y:16,t:1527009632769};\\\", \\\"{x:1270,y:16,t:1527009632787};\\\", \\\"{x:943,y:16,t:1527009632804};\\\", \\\"{x:738,y:19,t:1527009632819};\\\", \\\"{x:565,y:62,t:1527009632837};\\\", \\\"{x:435,y:121,t:1527009632854};\\\", \\\"{x:393,y:143,t:1527009632869};\\\", \\\"{x:391,y:145,t:1527009632886};\\\", \\\"{x:390,y:146,t:1527009632904};\\\", \\\"{x:397,y:149,t:1527009632919};\\\", \\\"{x:409,y:159,t:1527009632936};\\\", \\\"{x:416,y:166,t:1527009632954};\\\", \\\"{x:423,y:174,t:1527009632971};\\\", \\\"{x:427,y:184,t:1527009632987};\\\", \\\"{x:430,y:207,t:1527009633003};\\\", \\\"{x:429,y:227,t:1527009633021};\\\", \\\"{x:422,y:253,t:1527009633037};\\\", \\\"{x:407,y:283,t:1527009633054};\\\", \\\"{x:394,y:309,t:1527009633070};\\\", \\\"{x:384,y:327,t:1527009633086};\\\", \\\"{x:378,y:338,t:1527009633103};\\\", \\\"{x:374,y:350,t:1527009633120};\\\", \\\"{x:371,y:359,t:1527009633137};\\\", \\\"{x:369,y:368,t:1527009633153};\\\", \\\"{x:367,y:377,t:1527009633171};\\\", \\\"{x:361,y:391,t:1527009633186};\\\", \\\"{x:355,y:402,t:1527009633203};\\\", \\\"{x:355,y:403,t:1527009633220};\\\", \\\"{x:355,y:404,t:1527009633243};\\\" ] }, { \\\"rt\\\": 59437, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 839348, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -02 PM-03 PM-02 PM-X -O -O -X -M -B -F -C -11 AM-B -C -C -C -G -G -K -K -A -0-J -J -A -A \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:354,y:404,t:1527009633964};\\\", \\\"{x:353,y:404,t:1527009633999};\\\", \\\"{x:350,y:410,t:1527009634008};\\\", \\\"{x:346,y:419,t:1527009634025};\\\", \\\"{x:341,y:430,t:1527009634042};\\\", \\\"{x:336,y:440,t:1527009634058};\\\", \\\"{x:331,y:451,t:1527009634074};\\\", \\\"{x:327,y:463,t:1527009634091};\\\", \\\"{x:322,y:475,t:1527009634108};\\\", \\\"{x:316,y:491,t:1527009634125};\\\", \\\"{x:306,y:512,t:1527009634142};\\\", \\\"{x:297,y:533,t:1527009634159};\\\", \\\"{x:287,y:552,t:1527009634175};\\\", \\\"{x:278,y:570,t:1527009634191};\\\", \\\"{x:276,y:577,t:1527009634209};\\\", \\\"{x:274,y:579,t:1527009634224};\\\", \\\"{x:274,y:580,t:1527009634242};\\\", \\\"{x:274,y:581,t:1527009634258};\\\", \\\"{x:273,y:582,t:1527009634319};\\\", \\\"{x:273,y:583,t:1527009634335};\\\", \\\"{x:272,y:583,t:1527009634344};\\\", \\\"{x:271,y:584,t:1527009634358};\\\", \\\"{x:271,y:585,t:1527009634375};\\\", \\\"{x:270,y:586,t:1527009634392};\\\", \\\"{x:269,y:588,t:1527009634408};\\\", \\\"{x:268,y:588,t:1527009634431};\\\", \\\"{x:266,y:588,t:1527009634791};\\\", \\\"{x:265,y:587,t:1527009634807};\\\", \\\"{x:264,y:586,t:1527009635744};\\\", \\\"{x:263,y:585,t:1527009635760};\\\", \\\"{x:262,y:585,t:1527009635776};\\\", \\\"{x:261,y:584,t:1527009635800};\\\", \\\"{x:260,y:583,t:1527009635928};\\\", \\\"{x:259,y:583,t:1527009635952};\\\", \\\"{x:258,y:582,t:1527009637327};\\\", \\\"{x:258,y:581,t:1527009637343};\\\", \\\"{x:258,y:575,t:1527009637353};\\\", \\\"{x:258,y:561,t:1527009637371};\\\", \\\"{x:265,y:532,t:1527009637394};\\\", \\\"{x:276,y:488,t:1527009637409};\\\", \\\"{x:302,y:415,t:1527009637427};\\\", \\\"{x:346,y:306,t:1527009637445};\\\", \\\"{x:397,y:182,t:1527009637460};\\\", \\\"{x:453,y:52,t:1527009637477};\\\", \\\"{x:521,y:16,t:1527009637495};\\\", \\\"{x:635,y:16,t:1527009637511};\\\", \\\"{x:700,y:16,t:1527009637528};\\\", \\\"{x:728,y:16,t:1527009637544};\\\", \\\"{x:743,y:16,t:1527009637562};\\\", \\\"{x:746,y:16,t:1527009637578};\\\", \\\"{x:747,y:16,t:1527009637595};\\\", \\\"{x:744,y:16,t:1527009637695};\\\", \\\"{x:723,y:26,t:1527009637711};\\\", \\\"{x:714,y:50,t:1527009637728};\\\", \\\"{x:746,y:111,t:1527009637745};\\\", \\\"{x:815,y:198,t:1527009637762};\\\", \\\"{x:896,y:292,t:1527009637777};\\\", \\\"{x:986,y:396,t:1527009637795};\\\", \\\"{x:1084,y:497,t:1527009637811};\\\", \\\"{x:1186,y:581,t:1527009637828};\\\", \\\"{x:1295,y:645,t:1527009637845};\\\", \\\"{x:1416,y:696,t:1527009637861};\\\", \\\"{x:1510,y:719,t:1527009637877};\\\", \\\"{x:1569,y:736,t:1527009637894};\\\", \\\"{x:1625,y:738,t:1527009637911};\\\", \\\"{x:1643,y:741,t:1527009637927};\\\", \\\"{x:1657,y:741,t:1527009637944};\\\", \\\"{x:1665,y:741,t:1527009637961};\\\", \\\"{x:1673,y:741,t:1527009637978};\\\", \\\"{x:1684,y:744,t:1527009637995};\\\", \\\"{x:1700,y:747,t:1527009638011};\\\", \\\"{x:1714,y:747,t:1527009638028};\\\", \\\"{x:1718,y:747,t:1527009638045};\\\", \\\"{x:1720,y:747,t:1527009638061};\\\", \\\"{x:1721,y:747,t:1527009638143};\\\", \\\"{x:1717,y:747,t:1527009638423};\\\", \\\"{x:1714,y:747,t:1527009638431};\\\", \\\"{x:1709,y:747,t:1527009638445};\\\", \\\"{x:1694,y:747,t:1527009638462};\\\", \\\"{x:1676,y:747,t:1527009638479};\\\", \\\"{x:1651,y:746,t:1527009638495};\\\", \\\"{x:1636,y:745,t:1527009638511};\\\", \\\"{x:1622,y:743,t:1527009638528};\\\", \\\"{x:1618,y:743,t:1527009638545};\\\", \\\"{x:1617,y:743,t:1527009638695};\\\", \\\"{x:1617,y:741,t:1527009638799};\\\", \\\"{x:1617,y:737,t:1527009638812};\\\", \\\"{x:1617,y:725,t:1527009638828};\\\", \\\"{x:1617,y:715,t:1527009638846};\\\", \\\"{x:1615,y:707,t:1527009638863};\\\", \\\"{x:1614,y:701,t:1527009638880};\\\", \\\"{x:1609,y:683,t:1527009638896};\\\", \\\"{x:1606,y:675,t:1527009638912};\\\", \\\"{x:1604,y:670,t:1527009638929};\\\", \\\"{x:1602,y:666,t:1527009638946};\\\", \\\"{x:1599,y:663,t:1527009638962};\\\", \\\"{x:1597,y:662,t:1527009638979};\\\", \\\"{x:1594,y:662,t:1527009638997};\\\", \\\"{x:1589,y:661,t:1527009639012};\\\", \\\"{x:1576,y:661,t:1527009639029};\\\", \\\"{x:1555,y:661,t:1527009639046};\\\", \\\"{x:1528,y:661,t:1527009639063};\\\", \\\"{x:1485,y:659,t:1527009639079};\\\", \\\"{x:1467,y:659,t:1527009639096};\\\", \\\"{x:1460,y:659,t:1527009639113};\\\", \\\"{x:1457,y:659,t:1527009639129};\\\", \\\"{x:1456,y:659,t:1527009639146};\\\", \\\"{x:1458,y:660,t:1527009639840};\\\", \\\"{x:1461,y:660,t:1527009639848};\\\", \\\"{x:1464,y:660,t:1527009639863};\\\", \\\"{x:1488,y:643,t:1527009639880};\\\", \\\"{x:1512,y:631,t:1527009639897};\\\", \\\"{x:1530,y:622,t:1527009639913};\\\", \\\"{x:1537,y:616,t:1527009639930};\\\", \\\"{x:1539,y:613,t:1527009639947};\\\", \\\"{x:1541,y:609,t:1527009639963};\\\", \\\"{x:1543,y:606,t:1527009639980};\\\", \\\"{x:1544,y:603,t:1527009639997};\\\", \\\"{x:1543,y:603,t:1527009640063};\\\", \\\"{x:1538,y:601,t:1527009640080};\\\", \\\"{x:1536,y:601,t:1527009640097};\\\", \\\"{x:1535,y:601,t:1527009640199};\\\", \\\"{x:1533,y:601,t:1527009640214};\\\", \\\"{x:1510,y:611,t:1527009640230};\\\", \\\"{x:1490,y:638,t:1527009640247};\\\", \\\"{x:1496,y:652,t:1527009640263};\\\", \\\"{x:1513,y:673,t:1527009640280};\\\", \\\"{x:1527,y:697,t:1527009640297};\\\", \\\"{x:1534,y:717,t:1527009640314};\\\", \\\"{x:1536,y:739,t:1527009640330};\\\", \\\"{x:1539,y:763,t:1527009640347};\\\", \\\"{x:1539,y:779,t:1527009640364};\\\", \\\"{x:1539,y:793,t:1527009640380};\\\", \\\"{x:1539,y:807,t:1527009640397};\\\", \\\"{x:1539,y:827,t:1527009640414};\\\", \\\"{x:1539,y:852,t:1527009640430};\\\", \\\"{x:1533,y:893,t:1527009640447};\\\", \\\"{x:1528,y:911,t:1527009640463};\\\", \\\"{x:1525,y:922,t:1527009640480};\\\", \\\"{x:1522,y:930,t:1527009640497};\\\", \\\"{x:1522,y:934,t:1527009640514};\\\", \\\"{x:1522,y:937,t:1527009640530};\\\", \\\"{x:1522,y:938,t:1527009640547};\\\", \\\"{x:1522,y:940,t:1527009640564};\\\", \\\"{x:1522,y:942,t:1527009640581};\\\", \\\"{x:1528,y:946,t:1527009640597};\\\", \\\"{x:1533,y:950,t:1527009640614};\\\", \\\"{x:1538,y:954,t:1527009640630};\\\", \\\"{x:1541,y:957,t:1527009640647};\\\", \\\"{x:1543,y:959,t:1527009640663};\\\", \\\"{x:1545,y:962,t:1527009640679};\\\", \\\"{x:1546,y:964,t:1527009640697};\\\", \\\"{x:1547,y:964,t:1527009640824};\\\", \\\"{x:1548,y:964,t:1527009640872};\\\", \\\"{x:1549,y:965,t:1527009640895};\\\", \\\"{x:1550,y:965,t:1527009640903};\\\", \\\"{x:1550,y:966,t:1527009640914};\\\", \\\"{x:1551,y:967,t:1527009640931};\\\", \\\"{x:1551,y:968,t:1527009640967};\\\", \\\"{x:1549,y:968,t:1527009640981};\\\", \\\"{x:1548,y:968,t:1527009640997};\\\", \\\"{x:1541,y:968,t:1527009641014};\\\", \\\"{x:1515,y:964,t:1527009641031};\\\", \\\"{x:1501,y:964,t:1527009641048};\\\", \\\"{x:1495,y:964,t:1527009641063};\\\", \\\"{x:1488,y:967,t:1527009641081};\\\", \\\"{x:1487,y:967,t:1527009641097};\\\", \\\"{x:1487,y:968,t:1527009641114};\\\", \\\"{x:1486,y:969,t:1527009641131};\\\", \\\"{x:1485,y:969,t:1527009641151};\\\", \\\"{x:1484,y:969,t:1527009641164};\\\", \\\"{x:1483,y:969,t:1527009641180};\\\", \\\"{x:1481,y:969,t:1527009641198};\\\", \\\"{x:1476,y:967,t:1527009641214};\\\", \\\"{x:1475,y:967,t:1527009641230};\\\", \\\"{x:1476,y:966,t:1527009641527};\\\", \\\"{x:1476,y:965,t:1527009641543};\\\", \\\"{x:1476,y:963,t:1527009641568};\\\", \\\"{x:1476,y:962,t:1527009641600};\\\", \\\"{x:1476,y:960,t:1527009641624};\\\", \\\"{x:1476,y:959,t:1527009641640};\\\", \\\"{x:1477,y:959,t:1527009641648};\\\", \\\"{x:1477,y:958,t:1527009641665};\\\", \\\"{x:1478,y:957,t:1527009641687};\\\", \\\"{x:1478,y:956,t:1527009641865};\\\", \\\"{x:1480,y:956,t:1527009641904};\\\", \\\"{x:1481,y:956,t:1527009641916};\\\", \\\"{x:1482,y:957,t:1527009641932};\\\", \\\"{x:1484,y:957,t:1527009641948};\\\", \\\"{x:1486,y:958,t:1527009641966};\\\", \\\"{x:1487,y:959,t:1527009641992};\\\", \\\"{x:1488,y:959,t:1527009642065};\\\", \\\"{x:1489,y:959,t:1527009642082};\\\", \\\"{x:1490,y:960,t:1527009642120};\\\", \\\"{x:1488,y:960,t:1527009642201};\\\", \\\"{x:1487,y:960,t:1527009642216};\\\", \\\"{x:1485,y:960,t:1527009642232};\\\", \\\"{x:1483,y:960,t:1527009642249};\\\", \\\"{x:1483,y:959,t:1527009643503};\\\", \\\"{x:1481,y:959,t:1527009643516};\\\", \\\"{x:1480,y:959,t:1527009643535};\\\", \\\"{x:1478,y:958,t:1527009643549};\\\", \\\"{x:1477,y:957,t:1527009643568};\\\", \\\"{x:1475,y:956,t:1527009643591};\\\", \\\"{x:1473,y:953,t:1527009652136};\\\", \\\"{x:1440,y:937,t:1527009652143};\\\", \\\"{x:1362,y:911,t:1527009652157};\\\", \\\"{x:1141,y:840,t:1527009652172};\\\", \\\"{x:901,y:778,t:1527009652189};\\\", \\\"{x:687,y:727,t:1527009652206};\\\", \\\"{x:429,y:669,t:1527009652223};\\\", \\\"{x:301,y:648,t:1527009652240};\\\", \\\"{x:216,y:627,t:1527009652257};\\\", \\\"{x:168,y:613,t:1527009652271};\\\", \\\"{x:140,y:600,t:1527009652289};\\\", \\\"{x:128,y:587,t:1527009652306};\\\", \\\"{x:119,y:570,t:1527009652323};\\\", \\\"{x:104,y:550,t:1527009652341};\\\", \\\"{x:91,y:539,t:1527009652356};\\\", \\\"{x:83,y:534,t:1527009652373};\\\", \\\"{x:78,y:531,t:1527009652390};\\\", \\\"{x:78,y:530,t:1527009652415};\\\", \\\"{x:88,y:530,t:1527009652439};\\\", \\\"{x:106,y:530,t:1527009652447};\\\", \\\"{x:138,y:535,t:1527009652458};\\\", \\\"{x:225,y:550,t:1527009652473};\\\", \\\"{x:317,y:563,t:1527009652491};\\\", \\\"{x:379,y:573,t:1527009652507};\\\", \\\"{x:413,y:578,t:1527009652523};\\\", \\\"{x:424,y:579,t:1527009652540};\\\", \\\"{x:424,y:580,t:1527009652557};\\\", \\\"{x:422,y:580,t:1527009652583};\\\", \\\"{x:420,y:580,t:1527009652590};\\\", \\\"{x:401,y:580,t:1527009652607};\\\", \\\"{x:378,y:580,t:1527009652624};\\\", \\\"{x:350,y:580,t:1527009652640};\\\", \\\"{x:330,y:580,t:1527009652657};\\\", \\\"{x:321,y:580,t:1527009652673};\\\", \\\"{x:315,y:582,t:1527009652690};\\\", \\\"{x:314,y:582,t:1527009652707};\\\", \\\"{x:313,y:582,t:1527009652724};\\\", \\\"{x:312,y:583,t:1527009652740};\\\", \\\"{x:309,y:583,t:1527009652757};\\\", \\\"{x:300,y:586,t:1527009652773};\\\", \\\"{x:286,y:587,t:1527009652790};\\\", \\\"{x:251,y:591,t:1527009652807};\\\", \\\"{x:214,y:598,t:1527009652824};\\\", \\\"{x:184,y:601,t:1527009652841};\\\", \\\"{x:152,y:610,t:1527009652857};\\\", \\\"{x:131,y:615,t:1527009652874};\\\", \\\"{x:125,y:617,t:1527009652891};\\\", \\\"{x:123,y:619,t:1527009652907};\\\", \\\"{x:123,y:620,t:1527009652926};\\\", \\\"{x:123,y:622,t:1527009652943};\\\", \\\"{x:123,y:623,t:1527009652975};\\\", \\\"{x:123,y:624,t:1527009652991};\\\", \\\"{x:123,y:630,t:1527009653007};\\\", \\\"{x:123,y:634,t:1527009653024};\\\", \\\"{x:123,y:637,t:1527009653040};\\\", \\\"{x:123,y:640,t:1527009653057};\\\", \\\"{x:123,y:647,t:1527009653074};\\\", \\\"{x:123,y:657,t:1527009653091};\\\", \\\"{x:123,y:661,t:1527009653107};\\\", \\\"{x:123,y:664,t:1527009653124};\\\", \\\"{x:124,y:664,t:1527009653140};\\\", \\\"{x:127,y:662,t:1527009653191};\\\", \\\"{x:137,y:655,t:1527009653208};\\\", \\\"{x:184,y:640,t:1527009653225};\\\", \\\"{x:287,y:608,t:1527009653240};\\\", \\\"{x:408,y:579,t:1527009653258};\\\", \\\"{x:544,y:560,t:1527009653274};\\\", \\\"{x:645,y:550,t:1527009653291};\\\", \\\"{x:713,y:548,t:1527009653307};\\\", \\\"{x:743,y:548,t:1527009653325};\\\", \\\"{x:751,y:548,t:1527009653340};\\\", \\\"{x:752,y:548,t:1527009653357};\\\", \\\"{x:752,y:549,t:1527009653471};\\\", \\\"{x:750,y:552,t:1527009653479};\\\", \\\"{x:745,y:556,t:1527009653491};\\\", \\\"{x:735,y:563,t:1527009653508};\\\", \\\"{x:715,y:575,t:1527009653525};\\\", \\\"{x:696,y:581,t:1527009653542};\\\", \\\"{x:682,y:585,t:1527009653558};\\\", \\\"{x:673,y:585,t:1527009653574};\\\", \\\"{x:656,y:585,t:1527009653591};\\\", \\\"{x:651,y:585,t:1527009653608};\\\", \\\"{x:648,y:584,t:1527009653624};\\\", \\\"{x:647,y:584,t:1527009653704};\\\", \\\"{x:644,y:584,t:1527009653712};\\\", \\\"{x:641,y:585,t:1527009653728};\\\", \\\"{x:640,y:585,t:1527009653741};\\\", \\\"{x:637,y:586,t:1527009653758};\\\", \\\"{x:637,y:587,t:1527009653974};\\\", \\\"{x:646,y:594,t:1527009653992};\\\", \\\"{x:701,y:622,t:1527009654009};\\\", \\\"{x:802,y:659,t:1527009654024};\\\", \\\"{x:916,y:696,t:1527009654042};\\\", \\\"{x:1050,y:728,t:1527009654058};\\\", \\\"{x:1193,y:763,t:1527009654075};\\\", \\\"{x:1323,y:797,t:1527009654092};\\\", \\\"{x:1420,y:826,t:1527009654108};\\\", \\\"{x:1471,y:851,t:1527009654125};\\\", \\\"{x:1496,y:872,t:1527009654141};\\\", \\\"{x:1515,y:890,t:1527009654159};\\\", \\\"{x:1535,y:912,t:1527009654175};\\\", \\\"{x:1540,y:919,t:1527009654191};\\\", \\\"{x:1543,y:923,t:1527009654208};\\\", \\\"{x:1545,y:924,t:1527009654226};\\\", \\\"{x:1547,y:927,t:1527009654242};\\\", \\\"{x:1552,y:933,t:1527009654259};\\\", \\\"{x:1562,y:943,t:1527009654276};\\\", \\\"{x:1572,y:952,t:1527009654292};\\\", \\\"{x:1579,y:957,t:1527009654309};\\\", \\\"{x:1581,y:959,t:1527009654325};\\\", \\\"{x:1582,y:959,t:1527009654344};\\\", \\\"{x:1582,y:960,t:1527009654360};\\\", \\\"{x:1580,y:965,t:1527009654376};\\\", \\\"{x:1572,y:969,t:1527009654393};\\\", \\\"{x:1560,y:973,t:1527009654409};\\\", \\\"{x:1547,y:975,t:1527009654426};\\\", \\\"{x:1533,y:976,t:1527009654442};\\\", \\\"{x:1520,y:978,t:1527009654460};\\\", \\\"{x:1509,y:978,t:1527009654475};\\\", \\\"{x:1496,y:977,t:1527009654492};\\\", \\\"{x:1482,y:974,t:1527009654508};\\\", \\\"{x:1471,y:972,t:1527009654525};\\\", \\\"{x:1455,y:968,t:1527009654542};\\\", \\\"{x:1441,y:968,t:1527009654558};\\\", \\\"{x:1432,y:968,t:1527009654575};\\\", \\\"{x:1430,y:968,t:1527009654592};\\\", \\\"{x:1430,y:967,t:1527009654680};\\\", \\\"{x:1431,y:965,t:1527009654693};\\\", \\\"{x:1434,y:961,t:1527009654709};\\\", \\\"{x:1439,y:956,t:1527009654726};\\\", \\\"{x:1441,y:956,t:1527009654743};\\\", \\\"{x:1445,y:956,t:1527009654759};\\\", \\\"{x:1450,y:956,t:1527009654775};\\\", \\\"{x:1452,y:958,t:1527009654793};\\\", \\\"{x:1454,y:958,t:1527009654809};\\\", \\\"{x:1457,y:959,t:1527009654826};\\\", \\\"{x:1458,y:960,t:1527009654843};\\\", \\\"{x:1461,y:960,t:1527009654859};\\\", \\\"{x:1464,y:961,t:1527009654876};\\\", \\\"{x:1465,y:961,t:1527009654896};\\\", \\\"{x:1466,y:961,t:1527009654910};\\\", \\\"{x:1467,y:961,t:1527009654925};\\\", \\\"{x:1468,y:961,t:1527009654959};\\\", \\\"{x:1469,y:961,t:1527009654983};\\\", \\\"{x:1470,y:961,t:1527009654999};\\\", \\\"{x:1471,y:961,t:1527009655023};\\\", \\\"{x:1472,y:961,t:1527009655031};\\\", \\\"{x:1473,y:961,t:1527009655042};\\\", \\\"{x:1474,y:961,t:1527009655079};\\\", \\\"{x:1475,y:961,t:1527009655103};\\\", \\\"{x:1476,y:961,t:1527009655118};\\\", \\\"{x:1477,y:961,t:1527009655151};\\\", \\\"{x:1478,y:961,t:1527009655159};\\\", \\\"{x:1479,y:961,t:1527009655176};\\\", \\\"{x:1481,y:961,t:1527009655192};\\\", \\\"{x:1482,y:961,t:1527009655210};\\\", \\\"{x:1483,y:961,t:1527009655238};\\\", \\\"{x:1483,y:962,t:1527009655246};\\\", \\\"{x:1483,y:958,t:1527009655359};\\\", \\\"{x:1479,y:939,t:1527009655376};\\\", \\\"{x:1475,y:910,t:1527009655393};\\\", \\\"{x:1468,y:881,t:1527009655410};\\\", \\\"{x:1463,y:852,t:1527009655426};\\\", \\\"{x:1461,y:829,t:1527009655443};\\\", \\\"{x:1461,y:822,t:1527009655460};\\\", \\\"{x:1461,y:821,t:1527009655477};\\\", \\\"{x:1461,y:818,t:1527009655492};\\\", \\\"{x:1461,y:817,t:1527009655509};\\\", \\\"{x:1462,y:817,t:1527009655551};\\\", \\\"{x:1464,y:817,t:1527009655560};\\\", \\\"{x:1468,y:818,t:1527009655577};\\\", \\\"{x:1472,y:822,t:1527009655593};\\\", \\\"{x:1477,y:827,t:1527009655610};\\\", \\\"{x:1479,y:828,t:1527009655627};\\\", \\\"{x:1483,y:828,t:1527009655643};\\\", \\\"{x:1489,y:828,t:1527009655660};\\\", \\\"{x:1494,y:819,t:1527009655677};\\\", \\\"{x:1497,y:804,t:1527009655694};\\\", \\\"{x:1499,y:783,t:1527009655710};\\\", \\\"{x:1502,y:766,t:1527009655727};\\\", \\\"{x:1503,y:760,t:1527009655743};\\\", \\\"{x:1503,y:756,t:1527009655760};\\\", \\\"{x:1503,y:755,t:1527009655777};\\\", \\\"{x:1504,y:753,t:1527009655943};\\\", \\\"{x:1505,y:753,t:1527009655959};\\\", \\\"{x:1506,y:753,t:1527009655976};\\\", \\\"{x:1507,y:753,t:1527009655994};\\\", \\\"{x:1509,y:754,t:1527009656010};\\\", \\\"{x:1512,y:756,t:1527009656027};\\\", \\\"{x:1513,y:759,t:1527009656043};\\\", \\\"{x:1513,y:761,t:1527009656059};\\\", \\\"{x:1514,y:762,t:1527009656076};\\\", \\\"{x:1514,y:763,t:1527009656093};\\\", \\\"{x:1515,y:765,t:1527009657144};\\\", \\\"{x:1516,y:777,t:1527009657162};\\\", \\\"{x:1515,y:796,t:1527009657178};\\\", \\\"{x:1502,y:813,t:1527009657195};\\\", \\\"{x:1484,y:828,t:1527009657212};\\\", \\\"{x:1465,y:845,t:1527009657229};\\\", \\\"{x:1444,y:859,t:1527009657245};\\\", \\\"{x:1425,y:873,t:1527009657261};\\\", \\\"{x:1409,y:885,t:1527009657278};\\\", \\\"{x:1395,y:895,t:1527009657295};\\\", \\\"{x:1379,y:906,t:1527009657312};\\\", \\\"{x:1376,y:909,t:1527009657328};\\\", \\\"{x:1376,y:910,t:1527009657504};\\\", \\\"{x:1376,y:911,t:1527009657519};\\\", \\\"{x:1375,y:911,t:1527009657609};\\\", \\\"{x:1373,y:911,t:1527009657615};\\\", \\\"{x:1372,y:910,t:1527009657632};\\\", \\\"{x:1372,y:908,t:1527009657645};\\\", \\\"{x:1372,y:906,t:1527009657663};\\\", \\\"{x:1372,y:903,t:1527009657678};\\\", \\\"{x:1372,y:901,t:1527009657695};\\\", \\\"{x:1372,y:898,t:1527009657712};\\\", \\\"{x:1373,y:897,t:1527009657736};\\\", \\\"{x:1373,y:896,t:1527009657752};\\\", \\\"{x:1375,y:896,t:1527009657768};\\\", \\\"{x:1376,y:896,t:1527009657785};\\\", \\\"{x:1378,y:896,t:1527009657812};\\\", \\\"{x:1376,y:896,t:1527009659200};\\\", \\\"{x:1372,y:891,t:1527009659214};\\\", \\\"{x:1368,y:877,t:1527009659230};\\\", \\\"{x:1363,y:863,t:1527009659246};\\\", \\\"{x:1354,y:839,t:1527009659262};\\\", \\\"{x:1348,y:822,t:1527009659279};\\\", \\\"{x:1345,y:809,t:1527009659297};\\\", \\\"{x:1341,y:797,t:1527009659313};\\\", \\\"{x:1339,y:788,t:1527009659330};\\\", \\\"{x:1336,y:783,t:1527009659347};\\\", \\\"{x:1334,y:777,t:1527009659363};\\\", \\\"{x:1334,y:774,t:1527009659380};\\\", \\\"{x:1334,y:769,t:1527009659397};\\\", \\\"{x:1334,y:766,t:1527009659412};\\\", \\\"{x:1334,y:761,t:1527009659429};\\\", \\\"{x:1336,y:755,t:1527009659447};\\\", \\\"{x:1338,y:752,t:1527009659463};\\\", \\\"{x:1341,y:748,t:1527009659480};\\\", \\\"{x:1344,y:745,t:1527009659497};\\\", \\\"{x:1345,y:743,t:1527009659513};\\\", \\\"{x:1346,y:742,t:1527009659530};\\\", \\\"{x:1347,y:741,t:1527009659591};\\\", \\\"{x:1348,y:741,t:1527009659607};\\\", \\\"{x:1350,y:742,t:1527009659615};\\\", \\\"{x:1351,y:744,t:1527009659630};\\\", \\\"{x:1354,y:749,t:1527009659648};\\\", \\\"{x:1355,y:752,t:1527009659662};\\\", \\\"{x:1355,y:753,t:1527009659695};\\\", \\\"{x:1355,y:754,t:1527009659719};\\\", \\\"{x:1354,y:753,t:1527009659824};\\\", \\\"{x:1354,y:752,t:1527009659831};\\\", \\\"{x:1351,y:743,t:1527009659847};\\\", \\\"{x:1350,y:729,t:1527009659863};\\\", \\\"{x:1350,y:719,t:1527009659880};\\\", \\\"{x:1348,y:712,t:1527009659897};\\\", \\\"{x:1347,y:708,t:1527009659913};\\\", \\\"{x:1347,y:705,t:1527009659929};\\\", \\\"{x:1347,y:703,t:1527009659947};\\\", \\\"{x:1347,y:702,t:1527009659974};\\\", \\\"{x:1347,y:701,t:1527009660135};\\\", \\\"{x:1347,y:700,t:1527009660150};\\\", \\\"{x:1347,y:699,t:1527009660294};\\\", \\\"{x:1347,y:697,t:1527009660319};\\\", \\\"{x:1347,y:696,t:1527009660330};\\\", \\\"{x:1347,y:694,t:1527009660347};\\\", \\\"{x:1347,y:692,t:1527009660364};\\\", \\\"{x:1348,y:692,t:1527009663487};\\\", \\\"{x:1351,y:692,t:1527009663499};\\\", \\\"{x:1353,y:693,t:1527009663517};\\\", \\\"{x:1355,y:692,t:1527009663559};\\\", \\\"{x:1358,y:691,t:1527009663566};\\\", \\\"{x:1366,y:688,t:1527009663582};\\\", \\\"{x:1372,y:684,t:1527009663600};\\\", \\\"{x:1388,y:675,t:1527009663617};\\\", \\\"{x:1408,y:668,t:1527009663633};\\\", \\\"{x:1424,y:665,t:1527009663650};\\\", \\\"{x:1432,y:661,t:1527009663667};\\\", \\\"{x:1434,y:661,t:1527009663683};\\\", \\\"{x:1435,y:660,t:1527009663699};\\\", \\\"{x:1436,y:658,t:1527009663751};\\\", \\\"{x:1439,y:657,t:1527009663766};\\\", \\\"{x:1444,y:654,t:1527009663783};\\\", \\\"{x:1452,y:651,t:1527009663800};\\\", \\\"{x:1453,y:650,t:1527009663817};\\\", \\\"{x:1455,y:649,t:1527009663833};\\\", \\\"{x:1455,y:648,t:1527009663850};\\\", \\\"{x:1456,y:645,t:1527009663867};\\\", \\\"{x:1458,y:641,t:1527009663884};\\\", \\\"{x:1459,y:637,t:1527009663899};\\\", \\\"{x:1459,y:636,t:1527009663917};\\\", \\\"{x:1459,y:634,t:1527009663933};\\\", \\\"{x:1459,y:631,t:1527009663949};\\\", \\\"{x:1459,y:630,t:1527009663967};\\\", \\\"{x:1459,y:629,t:1527009663983};\\\", \\\"{x:1459,y:628,t:1527009664000};\\\", \\\"{x:1458,y:628,t:1527009664030};\\\", \\\"{x:1458,y:627,t:1527009664038};\\\", \\\"{x:1456,y:627,t:1527009664055};\\\", \\\"{x:1455,y:626,t:1527009664102};\\\", \\\"{x:1453,y:626,t:1527009664207};\\\", \\\"{x:1452,y:626,t:1527009664985};\\\", \\\"{x:1452,y:628,t:1527009665018};\\\", \\\"{x:1452,y:630,t:1527009665035};\\\", \\\"{x:1451,y:632,t:1527009665051};\\\", \\\"{x:1450,y:635,t:1527009665068};\\\", \\\"{x:1449,y:637,t:1527009665087};\\\", \\\"{x:1447,y:646,t:1527009665101};\\\", \\\"{x:1438,y:660,t:1527009665119};\\\", \\\"{x:1423,y:689,t:1527009665136};\\\", \\\"{x:1409,y:711,t:1527009665152};\\\", \\\"{x:1398,y:729,t:1527009665168};\\\", \\\"{x:1388,y:745,t:1527009665186};\\\", \\\"{x:1379,y:763,t:1527009665202};\\\", \\\"{x:1371,y:776,t:1527009665218};\\\", \\\"{x:1365,y:788,t:1527009665235};\\\", \\\"{x:1358,y:799,t:1527009665251};\\\", \\\"{x:1354,y:810,t:1527009665269};\\\", \\\"{x:1348,y:826,t:1527009665285};\\\", \\\"{x:1341,y:838,t:1527009665301};\\\", \\\"{x:1334,y:851,t:1527009665319};\\\", \\\"{x:1326,y:863,t:1527009665335};\\\", \\\"{x:1322,y:873,t:1527009665352};\\\", \\\"{x:1318,y:883,t:1527009665369};\\\", \\\"{x:1316,y:891,t:1527009665385};\\\", \\\"{x:1314,y:899,t:1527009665402};\\\", \\\"{x:1310,y:905,t:1527009665419};\\\", \\\"{x:1308,y:911,t:1527009665435};\\\", \\\"{x:1306,y:915,t:1527009665452};\\\", \\\"{x:1304,y:917,t:1527009665468};\\\", \\\"{x:1302,y:919,t:1527009665486};\\\", \\\"{x:1301,y:921,t:1527009665503};\\\", \\\"{x:1299,y:924,t:1527009665518};\\\", \\\"{x:1298,y:925,t:1527009665536};\\\", \\\"{x:1295,y:928,t:1527009665552};\\\", \\\"{x:1291,y:932,t:1527009665568};\\\", \\\"{x:1287,y:936,t:1527009665586};\\\", \\\"{x:1285,y:941,t:1527009665603};\\\", \\\"{x:1284,y:943,t:1527009665618};\\\", \\\"{x:1283,y:944,t:1527009665636};\\\", \\\"{x:1281,y:948,t:1527009665652};\\\", \\\"{x:1280,y:949,t:1527009665669};\\\", \\\"{x:1278,y:952,t:1527009665686};\\\", \\\"{x:1276,y:955,t:1527009665702};\\\", \\\"{x:1273,y:959,t:1527009665719};\\\", \\\"{x:1270,y:964,t:1527009665736};\\\", \\\"{x:1269,y:967,t:1527009665752};\\\", \\\"{x:1267,y:971,t:1527009665768};\\\", \\\"{x:1266,y:974,t:1527009665786};\\\", \\\"{x:1266,y:978,t:1527009665802};\\\", \\\"{x:1264,y:979,t:1527009665819};\\\", \\\"{x:1264,y:975,t:1527009665936};\\\", \\\"{x:1265,y:960,t:1527009665952};\\\", \\\"{x:1273,y:928,t:1527009665969};\\\", \\\"{x:1291,y:866,t:1527009665986};\\\", \\\"{x:1308,y:820,t:1527009666003};\\\", \\\"{x:1331,y:780,t:1527009666020};\\\", \\\"{x:1345,y:756,t:1527009666035};\\\", \\\"{x:1357,y:738,t:1527009666053};\\\", \\\"{x:1364,y:726,t:1527009666069};\\\", \\\"{x:1370,y:717,t:1527009666085};\\\", \\\"{x:1376,y:705,t:1527009666102};\\\", \\\"{x:1382,y:690,t:1527009666119};\\\", \\\"{x:1385,y:680,t:1527009666136};\\\", \\\"{x:1389,y:672,t:1527009666152};\\\", \\\"{x:1393,y:667,t:1527009666169};\\\", \\\"{x:1395,y:660,t:1527009666184};\\\", \\\"{x:1399,y:653,t:1527009666202};\\\", \\\"{x:1405,y:645,t:1527009666219};\\\", \\\"{x:1413,y:638,t:1527009666235};\\\", \\\"{x:1416,y:635,t:1527009666252};\\\", \\\"{x:1419,y:632,t:1527009666269};\\\", \\\"{x:1423,y:627,t:1527009666286};\\\", \\\"{x:1428,y:621,t:1527009666302};\\\", \\\"{x:1440,y:610,t:1527009666319};\\\", \\\"{x:1446,y:605,t:1527009666336};\\\", \\\"{x:1449,y:603,t:1527009666352};\\\", \\\"{x:1450,y:602,t:1527009666368};\\\", \\\"{x:1451,y:602,t:1527009666385};\\\", \\\"{x:1452,y:602,t:1527009666423};\\\", \\\"{x:1453,y:602,t:1527009666479};\\\", \\\"{x:1453,y:603,t:1527009666494};\\\", \\\"{x:1453,y:605,t:1527009666511};\\\", \\\"{x:1453,y:606,t:1527009666519};\\\", \\\"{x:1451,y:611,t:1527009666536};\\\", \\\"{x:1451,y:614,t:1527009666552};\\\", \\\"{x:1447,y:620,t:1527009666569};\\\", \\\"{x:1447,y:624,t:1527009666585};\\\", \\\"{x:1446,y:626,t:1527009666602};\\\", \\\"{x:1446,y:628,t:1527009666618};\\\", \\\"{x:1446,y:629,t:1527009666636};\\\", \\\"{x:1446,y:631,t:1527009666653};\\\", \\\"{x:1446,y:632,t:1527009666669};\\\", \\\"{x:1445,y:632,t:1527009666686};\\\", \\\"{x:1445,y:633,t:1527009666702};\\\", \\\"{x:1444,y:633,t:1527009667151};\\\", \\\"{x:1444,y:632,t:1527009667190};\\\", \\\"{x:1445,y:631,t:1527009667639};\\\", \\\"{x:1445,y:630,t:1527009667653};\\\", \\\"{x:1443,y:624,t:1527009667670};\\\", \\\"{x:1431,y:597,t:1527009667687};\\\", \\\"{x:1427,y:589,t:1527009667703};\\\", \\\"{x:1424,y:579,t:1527009667720};\\\", \\\"{x:1422,y:572,t:1527009667736};\\\", \\\"{x:1420,y:567,t:1527009667753};\\\", \\\"{x:1420,y:564,t:1527009667770};\\\", \\\"{x:1419,y:561,t:1527009667787};\\\", \\\"{x:1418,y:560,t:1527009667803};\\\", \\\"{x:1417,y:559,t:1527009667820};\\\", \\\"{x:1417,y:558,t:1527009667837};\\\", \\\"{x:1417,y:557,t:1527009667854};\\\", \\\"{x:1416,y:557,t:1527009668118};\\\", \\\"{x:1416,y:552,t:1527009668127};\\\", \\\"{x:1415,y:535,t:1527009668137};\\\", \\\"{x:1415,y:455,t:1527009668154};\\\", \\\"{x:1435,y:330,t:1527009668170};\\\", \\\"{x:1455,y:226,t:1527009668187};\\\", \\\"{x:1469,y:158,t:1527009668204};\\\", \\\"{x:1479,y:119,t:1527009668220};\\\", \\\"{x:1483,y:102,t:1527009668237};\\\", \\\"{x:1484,y:98,t:1527009668254};\\\", \\\"{x:1486,y:99,t:1527009668326};\\\", \\\"{x:1486,y:102,t:1527009668337};\\\", \\\"{x:1491,y:117,t:1527009668353};\\\", \\\"{x:1496,y:145,t:1527009668371};\\\", \\\"{x:1498,y:175,t:1527009668387};\\\", \\\"{x:1498,y:197,t:1527009668403};\\\", \\\"{x:1498,y:214,t:1527009668420};\\\", \\\"{x:1498,y:227,t:1527009668437};\\\", \\\"{x:1498,y:238,t:1527009668453};\\\", \\\"{x:1499,y:254,t:1527009668470};\\\", \\\"{x:1499,y:264,t:1527009668487};\\\", \\\"{x:1499,y:272,t:1527009668504};\\\", \\\"{x:1499,y:281,t:1527009668521};\\\", \\\"{x:1498,y:284,t:1527009668537};\\\", \\\"{x:1497,y:287,t:1527009668554};\\\", \\\"{x:1497,y:288,t:1527009668571};\\\", \\\"{x:1497,y:289,t:1527009668587};\\\", \\\"{x:1496,y:290,t:1527009668604};\\\", \\\"{x:1495,y:290,t:1527009668638};\\\", \\\"{x:1494,y:290,t:1527009668654};\\\", \\\"{x:1488,y:296,t:1527009668670};\\\", \\\"{x:1485,y:300,t:1527009668688};\\\", \\\"{x:1483,y:303,t:1527009668704};\\\", \\\"{x:1483,y:305,t:1527009668721};\\\", \\\"{x:1482,y:306,t:1527009668738};\\\", \\\"{x:1480,y:307,t:1527009668855};\\\", \\\"{x:1479,y:307,t:1527009668870};\\\", \\\"{x:1478,y:306,t:1527009668887};\\\", \\\"{x:1477,y:306,t:1527009668911};\\\", \\\"{x:1476,y:306,t:1527009668926};\\\", \\\"{x:1476,y:305,t:1527009668938};\\\", \\\"{x:1475,y:305,t:1527009668954};\\\", \\\"{x:1474,y:305,t:1527009668972};\\\", \\\"{x:1474,y:304,t:1527009669006};\\\", \\\"{x:1474,y:303,t:1527009669031};\\\", \\\"{x:1474,y:302,t:1527009669048};\\\", \\\"{x:1474,y:300,t:1527009669054};\\\", \\\"{x:1474,y:298,t:1527009669071};\\\", \\\"{x:1474,y:297,t:1527009669103};\\\", \\\"{x:1475,y:297,t:1527009669143};\\\", \\\"{x:1476,y:297,t:1527009669159};\\\", \\\"{x:1477,y:297,t:1527009669171};\\\", \\\"{x:1478,y:297,t:1527009669191};\\\", \\\"{x:1479,y:296,t:1527009669206};\\\", \\\"{x:1480,y:296,t:1527009669231};\\\", \\\"{x:1481,y:298,t:1527009678311};\\\", \\\"{x:1481,y:319,t:1527009678331};\\\", \\\"{x:1481,y:335,t:1527009678346};\\\", \\\"{x:1481,y:349,t:1527009678363};\\\", \\\"{x:1481,y:361,t:1527009678380};\\\", \\\"{x:1477,y:372,t:1527009678396};\\\", \\\"{x:1472,y:381,t:1527009678413};\\\", \\\"{x:1468,y:390,t:1527009678430};\\\", \\\"{x:1464,y:394,t:1527009678446};\\\", \\\"{x:1461,y:398,t:1527009678463};\\\", \\\"{x:1460,y:400,t:1527009678479};\\\", \\\"{x:1458,y:403,t:1527009678497};\\\", \\\"{x:1458,y:404,t:1527009678513};\\\", \\\"{x:1457,y:406,t:1527009678530};\\\", \\\"{x:1454,y:409,t:1527009678548};\\\", \\\"{x:1450,y:414,t:1527009678563};\\\", \\\"{x:1447,y:417,t:1527009678580};\\\", \\\"{x:1442,y:423,t:1527009678597};\\\", \\\"{x:1436,y:427,t:1527009678614};\\\", \\\"{x:1431,y:429,t:1527009678630};\\\", \\\"{x:1425,y:433,t:1527009678647};\\\", \\\"{x:1424,y:433,t:1527009678672};\\\", \\\"{x:1423,y:433,t:1527009678688};\\\", \\\"{x:1422,y:433,t:1527009678703};\\\", \\\"{x:1421,y:433,t:1527009678728};\\\", \\\"{x:1420,y:433,t:1527009678735};\\\", \\\"{x:1419,y:433,t:1527009678784};\\\", \\\"{x:1418,y:433,t:1527009678813};\\\", \\\"{x:1416,y:433,t:1527009678830};\\\", \\\"{x:1415,y:433,t:1527009678848};\\\", \\\"{x:1413,y:433,t:1527009678863};\\\", \\\"{x:1412,y:433,t:1527009678879};\\\", \\\"{x:1409,y:436,t:1527009679489};\\\", \\\"{x:1400,y:451,t:1527009679497};\\\", \\\"{x:1371,y:497,t:1527009679514};\\\", \\\"{x:1321,y:570,t:1527009679531};\\\", \\\"{x:1256,y:664,t:1527009679547};\\\", \\\"{x:1169,y:784,t:1527009679564};\\\", \\\"{x:1102,y:889,t:1527009679581};\\\", \\\"{x:1060,y:965,t:1527009679597};\\\", \\\"{x:1043,y:1008,t:1527009679614};\\\", \\\"{x:1039,y:1022,t:1527009679632};\\\", \\\"{x:1039,y:1025,t:1527009679647};\\\", \\\"{x:1042,y:1027,t:1527009679664};\\\", \\\"{x:1045,y:1028,t:1527009679681};\\\", \\\"{x:1047,y:1029,t:1527009679697};\\\", \\\"{x:1048,y:1030,t:1527009679714};\\\", \\\"{x:1049,y:1030,t:1527009679731};\\\", \\\"{x:1050,y:1030,t:1527009679776};\\\", \\\"{x:1050,y:1031,t:1527009679783};\\\", \\\"{x:1051,y:1031,t:1527009679798};\\\", \\\"{x:1054,y:1032,t:1527009679814};\\\", \\\"{x:1060,y:1034,t:1527009679832};\\\", \\\"{x:1067,y:1032,t:1527009679847};\\\", \\\"{x:1082,y:1019,t:1527009679864};\\\", \\\"{x:1104,y:999,t:1527009679881};\\\", \\\"{x:1123,y:981,t:1527009679898};\\\", \\\"{x:1140,y:964,t:1527009679915};\\\", \\\"{x:1150,y:955,t:1527009679931};\\\", \\\"{x:1151,y:955,t:1527009679948};\\\", \\\"{x:1151,y:956,t:1527009680016};\\\", \\\"{x:1151,y:957,t:1527009680039};\\\", \\\"{x:1149,y:958,t:1527009680049};\\\", \\\"{x:1148,y:960,t:1527009680064};\\\", \\\"{x:1148,y:962,t:1527009680080};\\\", \\\"{x:1148,y:965,t:1527009680098};\\\", \\\"{x:1147,y:965,t:1527009680114};\\\", \\\"{x:1147,y:966,t:1527009680183};\\\", \\\"{x:1147,y:965,t:1527009680359};\\\", \\\"{x:1148,y:962,t:1527009680367};\\\", \\\"{x:1150,y:957,t:1527009680381};\\\", \\\"{x:1155,y:950,t:1527009680398};\\\", \\\"{x:1159,y:941,t:1527009680414};\\\", \\\"{x:1161,y:939,t:1527009680430};\\\", \\\"{x:1162,y:936,t:1527009680448};\\\", \\\"{x:1162,y:934,t:1527009680464};\\\", \\\"{x:1165,y:929,t:1527009680480};\\\", \\\"{x:1166,y:926,t:1527009680498};\\\", \\\"{x:1166,y:925,t:1527009680515};\\\", \\\"{x:1168,y:923,t:1527009680532};\\\", \\\"{x:1169,y:921,t:1527009680548};\\\", \\\"{x:1171,y:919,t:1527009680565};\\\", \\\"{x:1172,y:917,t:1527009680582};\\\", \\\"{x:1172,y:914,t:1527009680598};\\\", \\\"{x:1175,y:908,t:1527009680615};\\\", \\\"{x:1176,y:906,t:1527009680631};\\\", \\\"{x:1177,y:905,t:1527009680650};\\\", \\\"{x:1177,y:903,t:1527009680666};\\\", \\\"{x:1178,y:902,t:1527009680682};\\\", \\\"{x:1179,y:898,t:1527009680698};\\\", \\\"{x:1181,y:894,t:1527009680715};\\\", \\\"{x:1182,y:890,t:1527009680732};\\\", \\\"{x:1186,y:885,t:1527009680749};\\\", \\\"{x:1187,y:880,t:1527009680765};\\\", \\\"{x:1189,y:876,t:1527009680783};\\\", \\\"{x:1191,y:872,t:1527009680798};\\\", \\\"{x:1194,y:865,t:1527009680816};\\\", \\\"{x:1196,y:859,t:1527009680831};\\\", \\\"{x:1202,y:852,t:1527009680849};\\\", \\\"{x:1204,y:848,t:1527009680866};\\\", \\\"{x:1206,y:844,t:1527009680882};\\\", \\\"{x:1207,y:841,t:1527009680900};\\\", \\\"{x:1207,y:840,t:1527009680914};\\\", \\\"{x:1208,y:839,t:1527009680931};\\\", \\\"{x:1208,y:838,t:1527009680991};\\\", \\\"{x:1208,y:837,t:1527009681007};\\\", \\\"{x:1208,y:836,t:1527009681031};\\\", \\\"{x:1208,y:835,t:1527009681039};\\\", \\\"{x:1208,y:834,t:1527009681048};\\\", \\\"{x:1208,y:833,t:1527009681064};\\\", \\\"{x:1208,y:832,t:1527009681082};\\\", \\\"{x:1208,y:831,t:1527009681099};\\\", \\\"{x:1208,y:830,t:1527009681119};\\\", \\\"{x:1208,y:828,t:1527009681132};\\\", \\\"{x:1209,y:828,t:1527009681149};\\\", \\\"{x:1209,y:826,t:1527009681166};\\\", \\\"{x:1209,y:825,t:1527009681182};\\\", \\\"{x:1210,y:823,t:1527009681199};\\\", \\\"{x:1211,y:823,t:1527009681344};\\\", \\\"{x:1211,y:822,t:1527009681432};\\\", \\\"{x:1211,y:818,t:1527009681450};\\\", \\\"{x:1214,y:804,t:1527009681466};\\\", \\\"{x:1226,y:777,t:1527009681482};\\\", \\\"{x:1239,y:741,t:1527009681500};\\\", \\\"{x:1261,y:696,t:1527009681516};\\\", \\\"{x:1295,y:619,t:1527009681532};\\\", \\\"{x:1332,y:551,t:1527009681549};\\\", \\\"{x:1352,y:511,t:1527009681566};\\\", \\\"{x:1374,y:473,t:1527009681582};\\\", \\\"{x:1386,y:447,t:1527009681599};\\\", \\\"{x:1388,y:442,t:1527009681616};\\\", \\\"{x:1389,y:440,t:1527009681632};\\\", \\\"{x:1390,y:439,t:1527009681650};\\\", \\\"{x:1390,y:438,t:1527009681720};\\\", \\\"{x:1390,y:436,t:1527009681732};\\\", \\\"{x:1393,y:432,t:1527009681749};\\\", \\\"{x:1398,y:427,t:1527009681767};\\\", \\\"{x:1407,y:419,t:1527009681783};\\\", \\\"{x:1413,y:415,t:1527009681800};\\\", \\\"{x:1419,y:412,t:1527009681815};\\\", \\\"{x:1423,y:410,t:1527009681832};\\\", \\\"{x:1427,y:409,t:1527009681848};\\\", \\\"{x:1428,y:409,t:1527009681865};\\\", \\\"{x:1430,y:409,t:1527009681882};\\\", \\\"{x:1431,y:409,t:1527009681899};\\\", \\\"{x:1432,y:409,t:1527009681915};\\\", \\\"{x:1433,y:409,t:1527009681933};\\\", \\\"{x:1434,y:409,t:1527009681951};\\\", \\\"{x:1434,y:410,t:1527009681965};\\\", \\\"{x:1434,y:414,t:1527009681982};\\\", \\\"{x:1434,y:417,t:1527009681999};\\\", \\\"{x:1434,y:418,t:1527009682015};\\\", \\\"{x:1434,y:421,t:1527009682033};\\\", \\\"{x:1433,y:422,t:1527009682049};\\\", \\\"{x:1431,y:423,t:1527009682066};\\\", \\\"{x:1430,y:424,t:1527009682083};\\\", \\\"{x:1428,y:425,t:1527009682099};\\\", \\\"{x:1426,y:425,t:1527009682116};\\\", \\\"{x:1424,y:427,t:1527009682134};\\\", \\\"{x:1423,y:427,t:1527009682150};\\\", \\\"{x:1422,y:427,t:1527009682166};\\\", \\\"{x:1421,y:427,t:1527009682208};\\\", \\\"{x:1418,y:426,t:1527009691120};\\\", \\\"{x:1376,y:419,t:1527009691141};\\\", \\\"{x:1174,y:412,t:1527009691158};\\\", \\\"{x:892,y:416,t:1527009691174};\\\", \\\"{x:612,y:438,t:1527009691191};\\\", \\\"{x:293,y:510,t:1527009691208};\\\", \\\"{x:127,y:561,t:1527009691226};\\\", \\\"{x:0,y:601,t:1527009691257};\\\", \\\"{x:0,y:602,t:1527009691272};\\\", \\\"{x:0,y:604,t:1527009691295};\\\", \\\"{x:2,y:604,t:1527009691306};\\\", \\\"{x:16,y:604,t:1527009691322};\\\", \\\"{x:30,y:604,t:1527009691339};\\\", \\\"{x:35,y:604,t:1527009691356};\\\", \\\"{x:36,y:604,t:1527009691373};\\\", \\\"{x:38,y:604,t:1527009691406};\\\", \\\"{x:55,y:605,t:1527009691423};\\\", \\\"{x:104,y:609,t:1527009691439};\\\", \\\"{x:171,y:609,t:1527009691456};\\\", \\\"{x:254,y:609,t:1527009691473};\\\", \\\"{x:349,y:609,t:1527009691489};\\\", \\\"{x:457,y:609,t:1527009691506};\\\", \\\"{x:548,y:609,t:1527009691523};\\\", \\\"{x:601,y:609,t:1527009691539};\\\", \\\"{x:623,y:607,t:1527009691557};\\\", \\\"{x:625,y:607,t:1527009691573};\\\", \\\"{x:623,y:604,t:1527009691589};\\\", \\\"{x:614,y:601,t:1527009691607};\\\", \\\"{x:605,y:599,t:1527009691622};\\\", \\\"{x:603,y:598,t:1527009691639};\\\", \\\"{x:602,y:597,t:1527009691656};\\\", \\\"{x:603,y:592,t:1527009691673};\\\", \\\"{x:610,y:586,t:1527009691690};\\\", \\\"{x:617,y:581,t:1527009691706};\\\", \\\"{x:622,y:580,t:1527009691723};\\\", \\\"{x:623,y:579,t:1527009691739};\\\", \\\"{x:625,y:579,t:1527009691756};\\\", \\\"{x:626,y:577,t:1527009691772};\\\", \\\"{x:628,y:575,t:1527009691791};\\\", \\\"{x:630,y:574,t:1527009691806};\\\", \\\"{x:634,y:568,t:1527009691823};\\\", \\\"{x:635,y:566,t:1527009691840};\\\", \\\"{x:636,y:566,t:1527009691879};\\\", \\\"{x:638,y:566,t:1527009691894};\\\", \\\"{x:639,y:569,t:1527009691906};\\\", \\\"{x:640,y:577,t:1527009691924};\\\", \\\"{x:640,y:589,t:1527009691940};\\\", \\\"{x:640,y:601,t:1527009691956};\\\", \\\"{x:638,y:611,t:1527009691973};\\\", \\\"{x:633,y:621,t:1527009691991};\\\", \\\"{x:630,y:624,t:1527009692006};\\\", \\\"{x:622,y:627,t:1527009692022};\\\", \\\"{x:614,y:629,t:1527009692040};\\\", \\\"{x:603,y:630,t:1527009692056};\\\", \\\"{x:583,y:633,t:1527009692073};\\\", \\\"{x:561,y:635,t:1527009692089};\\\", \\\"{x:540,y:637,t:1527009692106};\\\", \\\"{x:517,y:640,t:1527009692123};\\\", \\\"{x:498,y:646,t:1527009692140};\\\", \\\"{x:485,y:649,t:1527009692156};\\\", \\\"{x:475,y:651,t:1527009692173};\\\", \\\"{x:466,y:655,t:1527009692190};\\\", \\\"{x:458,y:655,t:1527009692206};\\\", \\\"{x:452,y:655,t:1527009692222};\\\", \\\"{x:446,y:655,t:1527009692240};\\\", \\\"{x:436,y:652,t:1527009692258};\\\", \\\"{x:425,y:651,t:1527009692273};\\\", \\\"{x:413,y:650,t:1527009692290};\\\", \\\"{x:401,y:647,t:1527009692307};\\\", \\\"{x:393,y:645,t:1527009692324};\\\", \\\"{x:388,y:641,t:1527009692341};\\\", \\\"{x:388,y:634,t:1527009692357};\\\", \\\"{x:389,y:620,t:1527009692374};\\\", \\\"{x:399,y:600,t:1527009692391};\\\", \\\"{x:403,y:592,t:1527009692407};\\\", \\\"{x:403,y:590,t:1527009692423};\\\", \\\"{x:404,y:588,t:1527009692440};\\\", \\\"{x:405,y:588,t:1527009692671};\\\", \\\"{x:409,y:592,t:1527009692678};\\\", \\\"{x:418,y:611,t:1527009692690};\\\", \\\"{x:433,y:647,t:1527009692707};\\\", \\\"{x:451,y:698,t:1527009692724};\\\", \\\"{x:474,y:744,t:1527009692741};\\\", \\\"{x:487,y:764,t:1527009692757};\\\", \\\"{x:501,y:778,t:1527009692775};\\\", \\\"{x:503,y:780,t:1527009692790};\\\", \\\"{x:505,y:780,t:1527009692814};\\\", \\\"{x:506,y:780,t:1527009692824};\\\", \\\"{x:509,y:780,t:1527009692840};\\\", \\\"{x:512,y:780,t:1527009692857};\\\", \\\"{x:516,y:779,t:1527009692874};\\\", \\\"{x:517,y:778,t:1527009692890};\\\", \\\"{x:517,y:777,t:1527009692968};\\\", \\\"{x:517,y:776,t:1527009692983};\\\", \\\"{x:516,y:774,t:1527009692992};\\\", \\\"{x:515,y:764,t:1527009693007};\\\", \\\"{x:514,y:760,t:1527009693024};\\\", \\\"{x:513,y:759,t:1527009693041};\\\", \\\"{x:513,y:758,t:1527009693167};\\\", \\\"{x:513,y:758,t:1527009693184};\\\", \\\"{x:512,y:758,t:1527009693190};\\\", \\\"{x:499,y:757,t:1527009693206};\\\", \\\"{x:451,y:757,t:1527009693224};\\\", \\\"{x:326,y:753,t:1527009693241};\\\", \\\"{x:134,y:742,t:1527009693258};\\\", \\\"{x:0,y:707,t:1527009693274};\\\", \\\"{x:0,y:672,t:1527009693291};\\\", \\\"{x:0,y:633,t:1527009693307};\\\", \\\"{x:0,y:600,t:1527009693324};\\\", \\\"{x:0,y:571,t:1527009693341};\\\", \\\"{x:0,y:550,t:1527009693358};\\\", \\\"{x:0,y:539,t:1527009693374};\\\", \\\"{x:0,y:538,t:1527009693391};\\\", \\\"{x:1,y:538,t:1527009693415};\\\", \\\"{x:5,y:535,t:1527009693424};\\\", \\\"{x:12,y:531,t:1527009693441};\\\", \\\"{x:14,y:530,t:1527009693457};\\\", \\\"{x:20,y:526,t:1527009693474};\\\", \\\"{x:29,y:517,t:1527009693491};\\\", \\\"{x:41,y:499,t:1527009693508};\\\", \\\"{x:66,y:465,t:1527009693524};\\\", \\\"{x:113,y:408,t:1527009693541};\\\", \\\"{x:201,y:332,t:1527009693558};\\\", \\\"{x:338,y:196,t:1527009693574};\\\", \\\"{x:397,y:99,t:1527009693591};\\\", \\\"{x:433,y:16,t:1527009693608};\\\", \\\"{x:441,y:16,t:1527009693624};\\\", \\\"{x:424,y:16,t:1527009693641};\\\", \\\"{x:393,y:16,t:1527009693658};\\\", \\\"{x:335,y:16,t:1527009693675};\\\", \\\"{x:266,y:16,t:1527009693692};\\\", \\\"{x:167,y:16,t:1527009693708};\\\", \\\"{x:69,y:16,t:1527009693724};\\\", \\\"{x:0,y:16,t:1527009693741};\\\", \\\"{x:33,y:29,t:1527009694067};\\\", \\\"{x:102,y:53,t:1527009694078};\\\", \\\"{x:288,y:110,t:1527009694096};\\\", \\\"{x:517,y:150,t:1527009694112};\\\", \\\"{x:812,y:218,t:1527009694129};\\\", \\\"{x:1104,y:259,t:1527009694145};\\\", \\\"{x:1305,y:280,t:1527009694162};\\\", \\\"{x:1404,y:305,t:1527009694179};\\\", \\\"{x:1408,y:306,t:1527009694196};\\\", \\\"{x:1408,y:307,t:1527009694234};\\\", \\\"{x:1401,y:307,t:1527009694246};\\\", \\\"{x:1377,y:309,t:1527009694262};\\\", \\\"{x:1353,y:309,t:1527009694278};\\\", \\\"{x:1331,y:309,t:1527009694296};\\\", \\\"{x:1316,y:309,t:1527009694311};\\\", \\\"{x:1312,y:309,t:1527009694328};\\\", \\\"{x:1311,y:309,t:1527009694346};\\\", \\\"{x:1310,y:309,t:1527009694378};\\\" ] }, { \\\"rt\\\": 47573, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 888431, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Must in the line for 12 and Duration less than four\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7203, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 896636, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 16544, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 914202, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 1670, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 917208, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"VSHHA\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"echo\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"VSHHA\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 97, dom: 794, initialDom: 909",
  "javascriptErrors": []
}