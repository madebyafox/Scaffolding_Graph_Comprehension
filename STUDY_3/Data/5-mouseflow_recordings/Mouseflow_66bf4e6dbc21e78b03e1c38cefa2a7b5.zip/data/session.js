var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "66bf4e6dbc21e78b03e1c38cefa2a7b5",
  "created": "2018-05-18T10:14:13.0126523-07:00",
  "lastActivity": "2018-05-18T10:14:45.2746523-07:00",
  "pageViews": [
    {
      "id": "051813454ee24fe334499fd1f282580093f6f896",
      "startTime": "2018-05-18T10:14:13.0126523-07:00",
      "endTime": "2018-05-18T10:14:45.2746523-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 32262,
      "engagementTime": 32262,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 32262,
  "engagementTime": 32262,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.35",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=JTARS",
    "CONDITION=111"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ab28f31a31d68e95ae262261794a23f6",
  "gdpr": false
}