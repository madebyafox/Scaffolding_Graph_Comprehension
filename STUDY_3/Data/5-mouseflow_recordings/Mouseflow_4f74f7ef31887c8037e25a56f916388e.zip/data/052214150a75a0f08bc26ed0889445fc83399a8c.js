var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052214150a75a0f08bc26ed0889445fc83399a8c"] = {
  "startTime": "2018-05-22T23:12:14.494852Z",
  "websitePageUrl": "/16",
  "visitTime": 293789,
  "engagementTime": 183392,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "4f74f7ef31887c8037e25a56f916388e",
    "created": "2018-05-22T23:12:14.494852+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=JVUC6",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "325918ae50f2f04932e2fa83700a6aa9",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/4f74f7ef31887c8037e25a56f916388e/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 198,
      "e": 198,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 655,
      "e": 655,
      "ty": 2,
      "x": 520,
      "y": 746
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 47538,
      "y": 40883,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 7201,
      "e": 5751,
      "ty": 2,
      "x": 492,
      "y": 703
    },
    {
      "t": 7225,
      "e": 5775,
      "ty": 6,
      "x": 457,
      "y": 665,
      "ta": "#strategyButton"
    },
    {
      "t": 7242,
      "e": 5792,
      "ty": 7,
      "x": 442,
      "y": 649,
      "ta": "#strategyButton"
    },
    {
      "t": 7251,
      "e": 5801,
      "ty": 41,
      "x": 57767,
      "y": 17868,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 7300,
      "e": 5850,
      "ty": 2,
      "x": 427,
      "y": 633
    },
    {
      "t": 7401,
      "e": 5951,
      "ty": 2,
      "x": 417,
      "y": 629
    },
    {
      "t": 7501,
      "e": 6051,
      "ty": 2,
      "x": 408,
      "y": 626
    },
    {
      "t": 7501,
      "e": 6051,
      "ty": 41,
      "x": 41851,
      "y": 2795,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 7601,
      "e": 6151,
      "ty": 2,
      "x": 369,
      "y": 619
    },
    {
      "t": 7637,
      "e": 6187,
      "ty": 6,
      "x": 350,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7701,
      "e": 6251,
      "ty": 2,
      "x": 322,
      "y": 573
    },
    {
      "t": 7751,
      "e": 6301,
      "ty": 41,
      "x": 24045,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7801,
      "e": 6351,
      "ty": 2,
      "x": 305,
      "y": 546
    },
    {
      "t": 8001,
      "e": 6551,
      "ty": 41,
      "x": 23370,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9999,
      "e": 8549,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 11037,
      "e": 9587,
      "ty": 3,
      "x": 305,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11038,
      "e": 9588,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11139,
      "e": 9689,
      "ty": 4,
      "x": 23370,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11139,
      "e": 9689,
      "ty": 5,
      "x": 305,
      "y": 546,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11499,
      "e": 10049,
      "ty": 2,
      "x": 320,
      "y": 567
    },
    {
      "t": 11499,
      "e": 10049,
      "ty": 41,
      "x": 25056,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11525,
      "e": 10075,
      "ty": 7,
      "x": 374,
      "y": 609,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11577,
      "e": 10127,
      "ty": 6,
      "x": 487,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11598,
      "e": 10148,
      "ty": 2,
      "x": 493,
      "y": 592
    },
    {
      "t": 11698,
      "e": 10248,
      "ty": 2,
      "x": 493,
      "y": 591
    },
    {
      "t": 11748,
      "e": 10298,
      "ty": 41,
      "x": 44841,
      "y": 52804,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11799,
      "e": 10349,
      "ty": 2,
      "x": 515,
      "y": 538
    },
    {
      "t": 11809,
      "e": 10359,
      "ty": 7,
      "x": 525,
      "y": 516,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11899,
      "e": 10449,
      "ty": 2,
      "x": 555,
      "y": 455
    },
    {
      "t": 11999,
      "e": 10549,
      "ty": 2,
      "x": 578,
      "y": 419
    },
    {
      "t": 11999,
      "e": 10549,
      "ty": 41,
      "x": 54058,
      "y": 22768,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 12098,
      "e": 10648,
      "ty": 2,
      "x": 590,
      "y": 390
    },
    {
      "t": 12199,
      "e": 10749,
      "ty": 2,
      "x": 589,
      "y": 373
    },
    {
      "t": 12249,
      "e": 10799,
      "ty": 41,
      "x": 55295,
      "y": 20220,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 14729,
      "e": 13279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 14856,
      "e": 13406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 14856,
      "e": 13406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14983,
      "e": 13533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "G"
    },
    {
      "t": 15015,
      "e": 13565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "G"
    },
    {
      "t": 15728,
      "e": 14278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15729,
      "e": 14279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15824,
      "e": 14374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go"
    },
    {
      "t": 15967,
      "e": 14517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15969,
      "e": 14519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16047,
      "e": 14597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go "
    },
    {
      "t": 16191,
      "e": 14741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16191,
      "e": 14741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16255,
      "e": 14805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go t"
    },
    {
      "t": 16359,
      "e": 14909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16360,
      "e": 14910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16431,
      "e": 14981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 16512,
      "e": 15062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16513,
      "e": 15063,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16607,
      "e": 15157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16727,
      "e": 15277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16729,
      "e": 15279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16783,
      "e": 15333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16863,
      "e": 15413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16863,
      "e": 15413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16919,
      "e": 15469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 16991,
      "e": 15541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16991,
      "e": 15541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17071,
      "e": 15621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 17128,
      "e": 15678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17128,
      "e": 15678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17207,
      "e": 15757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17847,
      "e": 16397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 17952,
      "e": 16502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 17952,
      "e": 16502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18031,
      "e": 16581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 18079,
      "e": 16629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18376,
      "e": 16926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 18376,
      "e": 16926,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18455,
      "e": 17005,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 18696,
      "e": 17246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18696,
      "e": 17246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18775,
      "e": 17325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19048,
      "e": 17598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 19048,
      "e": 17598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19135,
      "e": 17685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 19319,
      "e": 17869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19320,
      "e": 17870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19398,
      "e": 17948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 19471,
      "e": 18021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19471,
      "e": 18021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19535,
      "e": 18085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19998,
      "e": 18548,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20672,
      "e": 19222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20799,
      "e": 19349,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axi"
    },
    {
      "t": 20807,
      "e": 19357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axi"
    },
    {
      "t": 21337,
      "e": 19887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21337,
      "e": 19887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21391,
      "e": 19941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23448,
      "e": 21998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23448,
      "e": 21998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23511,
      "e": 22061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24008,
      "e": 22558,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24008,
      "e": 22558,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24111,
      "e": 22661,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 24247,
      "e": 22797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24248,
      "e": 22798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24319,
      "e": 22869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 24392,
      "e": 22942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 24392,
      "e": 22942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24447,
      "e": 22997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 24519,
      "e": 23069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24519,
      "e": 23069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24599,
      "e": 23149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24808,
      "e": 23358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 24808,
      "e": 23358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24879,
      "e": 23429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 25000,
      "e": 23550,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and f"
    },
    {
      "t": 25023,
      "e": 23573,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25024,
      "e": 23574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25103,
      "e": 23653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25224,
      "e": 23774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25224,
      "e": 23774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25304,
      "e": 23854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 26031,
      "e": 24581,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 26031,
      "e": 24581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26095,
      "e": 24645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 26191,
      "e": 24741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26192,
      "e": 24742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26280,
      "e": 24830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29998,
      "e": 28548,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30576,
      "e": 29126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 30576,
      "e": 29126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30648,
      "e": 29198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 30831,
      "e": 29381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 30832,
      "e": 29382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30887,
      "e": 29437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 31001,
      "e": 29551,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12"
    },
    {
      "t": 31680,
      "e": 30230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31681,
      "e": 30231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31751,
      "e": 30301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32807,
      "e": 31357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32927,
      "e": 31477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12"
    },
    {
      "t": 33471,
      "e": 32021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 33472,
      "e": 32022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33551,
      "e": 32101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 33696,
      "e": 32246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33696,
      "e": 32246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33766,
      "e": 32316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 35056,
      "e": 33606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 35057,
      "e": 33607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35127,
      "e": 33677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 35198,
      "e": 33748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35199,
      "e": 33749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35271,
      "e": 33821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39999,
      "e": 38549,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 44998,
      "e": 38821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44998,
      "e": 38821,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45070,
      "e": 38893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45414,
      "e": 39237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45414,
      "e": 39237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45494,
      "e": 39317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 45599,
      "e": 39422,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, ta"
    },
    {
      "t": 45623,
      "e": 39446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 45623,
      "e": 39446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45711,
      "e": 39534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 45799,
      "e": 39622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 45799,
      "e": 39622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45854,
      "e": 39677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 45902,
      "e": 39725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45902,
      "e": 39725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46006,
      "e": 39829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46151,
      "e": 39974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46151,
      "e": 39974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46215,
      "e": 40038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46326,
      "e": 40149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 46326,
      "e": 40149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46391,
      "e": 40214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 46647,
      "e": 40470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 46647,
      "e": 40470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46718,
      "e": 40541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 46854,
      "e": 40677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46854,
      "e": 40677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46943,
      "e": 40766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48038,
      "e": 41861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 48039,
      "e": 41862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48110,
      "e": 41933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 48231,
      "e": 42054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48231,
      "e": 42054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48327,
      "e": 42150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 48439,
      "e": 42262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 48439,
      "e": 42262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48494,
      "e": 42317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 48599,
      "e": 42422,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the for"
    },
    {
      "t": 48919,
      "e": 42742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 48919,
      "e": 42742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48982,
      "e": 42805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 49143,
      "e": 42966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49143,
      "e": 42966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49230,
      "e": 43053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 49431,
      "e": 43254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49431,
      "e": 43254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49495,
      "e": 43318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 49599,
      "e": 43422,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forwar"
    },
    {
      "t": 49630,
      "e": 43453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 49630,
      "e": 43453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49702,
      "e": 43525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 49799,
      "e": 43622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49799,
      "e": 43622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49878,
      "e": 43701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49998,
      "e": 43821,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50918,
      "e": 44741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 50918,
      "e": 44741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50990,
      "e": 44813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 51119,
      "e": 44942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51119,
      "e": 44942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51198,
      "e": 45021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 51334,
      "e": 45157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 51334,
      "e": 45157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51415,
      "e": 45238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 51862,
      "e": 45685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 51863,
      "e": 45686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51935,
      "e": 45758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 52095,
      "e": 45918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 52095,
      "e": 45918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52166,
      "e": 45989,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 52311,
      "e": 46134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52311,
      "e": 46134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52390,
      "e": 46213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 52494,
      "e": 46317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52495,
      "e": 46318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52566,
      "e": 46389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 52670,
      "e": 46493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 52670,
      "e": 46493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52759,
      "e": 46582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 52846,
      "e": 46669,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52847,
      "e": 46670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52895,
      "e": 46718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53000,
      "e": 46823,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward diagonal "
    },
    {
      "t": 59998,
      "e": 51823,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 67016,
      "e": 51823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 67016,
      "e": 51823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67095,
      "e": 51902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 67200,
      "e": 52007,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward diagonal u"
    },
    {
      "t": 67207,
      "e": 52014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 67207,
      "e": 52014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67271,
      "e": 52078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 67360,
      "e": 52167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67360,
      "e": 52167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67446,
      "e": 52253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67631,
      "e": 52438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 67632,
      "e": 52439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67678,
      "e": 52485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 67783,
      "e": 52590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 67783,
      "e": 52590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67855,
      "e": 52662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 67951,
      "e": 52758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67952,
      "e": 52759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68030,
      "e": 52837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68309,
      "e": 53116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68309,
      "e": 53116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68388,
      "e": 53195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 68604,
      "e": 53411,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 68605,
      "e": 53412,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68692,
      "e": 53499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 68799,
      "e": 53606,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward diagonal up to ea"
    },
    {
      "t": 69036,
      "e": 53843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 69037,
      "e": 53844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69099,
      "e": 53906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 69212,
      "e": 54019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69212,
      "e": 54019,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69276,
      "e": 54083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 69373,
      "e": 54180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69373,
      "e": 54180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69476,
      "e": 54283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69716,
      "e": 54523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 69717,
      "e": 54524,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69812,
      "e": 54619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 69933,
      "e": 54740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 69933,
      "e": 54740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70012,
      "e": 54819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 70148,
      "e": 54955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 70149,
      "e": 54956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70219,
      "e": 55026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 70396,
      "e": 55203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 70397,
      "e": 55204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70484,
      "e": 55291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 70564,
      "e": 55371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70565,
      "e": 55372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70644,
      "e": 55451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 70716,
      "e": 55523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70717,
      "e": 55524,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70812,
      "e": 55619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70867,
      "e": 55674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 70867,
      "e": 55674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70947,
      "e": 55754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 71108,
      "e": 55915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 71109,
      "e": 55916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71171,
      "e": 55978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 71252,
      "e": 56059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71252,
      "e": 56059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71356,
      "e": 56163,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 71404,
      "e": 56211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 71405,
      "e": 56212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71476,
      "e": 56283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 71508,
      "e": 56315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 71508,
      "e": 56315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71579,
      "e": 56386,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 71709,
      "e": 56516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 71709,
      "e": 56516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71779,
      "e": 56586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 71956,
      "e": 56763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 71957,
      "e": 56764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72027,
      "e": 56834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 72107,
      "e": 56914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72108,
      "e": 56915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72196,
      "e": 57003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 72428,
      "e": 57235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 72429,
      "e": 57236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72516,
      "e": 57323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 72644,
      "e": 57451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 72645,
      "e": 57452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72723,
      "e": 57530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 72869,
      "e": 57676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 72869,
      "e": 57676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72947,
      "e": 57754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 73011,
      "e": 57818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 73012,
      "e": 57819,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73084,
      "e": 57891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 73197,
      "e": 58004,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward diagonal up to each point on that line"
    },
    {
      "t": 79746,
      "e": 63004,
      "ty": 41,
      "x": 60690,
      "y": 19222,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 79796,
      "e": 63054,
      "ty": 2,
      "x": 653,
      "y": 350
    },
    {
      "t": 79996,
      "e": 63254,
      "ty": 2,
      "x": 653,
      "y": 352
    },
    {
      "t": 79996,
      "e": 63254,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 79999,
      "e": 63257,
      "ty": 41,
      "x": 62489,
      "y": 19056,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 80096,
      "e": 63354,
      "ty": 2,
      "x": 653,
      "y": 442
    },
    {
      "t": 80179,
      "e": 63437,
      "ty": 6,
      "x": 603,
      "y": 525,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80195,
      "e": 63453,
      "ty": 2,
      "x": 599,
      "y": 528
    },
    {
      "t": 80245,
      "e": 63503,
      "ty": 41,
      "x": 55182,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80295,
      "e": 63553,
      "ty": 2,
      "x": 521,
      "y": 539
    },
    {
      "t": 80395,
      "e": 63653,
      "ty": 2,
      "x": 476,
      "y": 542
    },
    {
      "t": 80496,
      "e": 63754,
      "ty": 2,
      "x": 432,
      "y": 544
    },
    {
      "t": 80496,
      "e": 63754,
      "ty": 41,
      "x": 37646,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80796,
      "e": 64054,
      "ty": 2,
      "x": 432,
      "y": 542
    },
    {
      "t": 80895,
      "e": 64153,
      "ty": 2,
      "x": 438,
      "y": 541
    },
    {
      "t": 80996,
      "e": 64254,
      "ty": 2,
      "x": 450,
      "y": 539
    },
    {
      "t": 80997,
      "e": 64255,
      "ty": 41,
      "x": 39670,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81096,
      "e": 64354,
      "ty": 2,
      "x": 456,
      "y": 539
    },
    {
      "t": 81246,
      "e": 64504,
      "ty": 41,
      "x": 40344,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81296,
      "e": 64554,
      "ty": 2,
      "x": 457,
      "y": 539
    },
    {
      "t": 81396,
      "e": 64654,
      "ty": 2,
      "x": 473,
      "y": 537
    },
    {
      "t": 81496,
      "e": 64754,
      "ty": 2,
      "x": 474,
      "y": 536
    },
    {
      "t": 81497,
      "e": 64755,
      "ty": 41,
      "x": 42368,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81596,
      "e": 64854,
      "ty": 2,
      "x": 481,
      "y": 533
    },
    {
      "t": 81696,
      "e": 64954,
      "ty": 2,
      "x": 507,
      "y": 531
    },
    {
      "t": 81746,
      "e": 65004,
      "ty": 41,
      "x": 46414,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81796,
      "e": 65054,
      "ty": 2,
      "x": 514,
      "y": 531
    },
    {
      "t": 81896,
      "e": 65154,
      "ty": 2,
      "x": 526,
      "y": 532
    },
    {
      "t": 81996,
      "e": 65254,
      "ty": 2,
      "x": 538,
      "y": 534
    },
    {
      "t": 81997,
      "e": 65255,
      "ty": 41,
      "x": 49562,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82096,
      "e": 65354,
      "ty": 2,
      "x": 541,
      "y": 534
    },
    {
      "t": 82196,
      "e": 65454,
      "ty": 2,
      "x": 542,
      "y": 534
    },
    {
      "t": 82246,
      "e": 65504,
      "ty": 41,
      "x": 50011,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83496,
      "e": 66754,
      "ty": 2,
      "x": 534,
      "y": 534
    },
    {
      "t": 83496,
      "e": 66754,
      "ty": 41,
      "x": 49112,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83595,
      "e": 66853,
      "ty": 2,
      "x": 529,
      "y": 534
    },
    {
      "t": 83696,
      "e": 66954,
      "ty": 2,
      "x": 528,
      "y": 534
    },
    {
      "t": 83746,
      "e": 67004,
      "ty": 41,
      "x": 48438,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84496,
      "e": 67754,
      "ty": 2,
      "x": 521,
      "y": 534
    },
    {
      "t": 84496,
      "e": 67754,
      "ty": 41,
      "x": 47651,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84596,
      "e": 67854,
      "ty": 2,
      "x": 515,
      "y": 534
    },
    {
      "t": 84746,
      "e": 68004,
      "ty": 41,
      "x": 46976,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84896,
      "e": 68154,
      "ty": 2,
      "x": 520,
      "y": 534
    },
    {
      "t": 84996,
      "e": 68254,
      "ty": 2,
      "x": 521,
      "y": 534
    },
    {
      "t": 84996,
      "e": 68254,
      "ty": 41,
      "x": 47651,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85096,
      "e": 68354,
      "ty": 2,
      "x": 528,
      "y": 534
    },
    {
      "t": 85196,
      "e": 68454,
      "ty": 2,
      "x": 531,
      "y": 534
    },
    {
      "t": 85246,
      "e": 68504,
      "ty": 41,
      "x": 49000,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85295,
      "e": 68553,
      "ty": 2,
      "x": 536,
      "y": 534
    },
    {
      "t": 85396,
      "e": 68654,
      "ty": 2,
      "x": 539,
      "y": 534
    },
    {
      "t": 85495,
      "e": 68753,
      "ty": 2,
      "x": 540,
      "y": 534
    },
    {
      "t": 85495,
      "e": 68753,
      "ty": 41,
      "x": 49787,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87995,
      "e": 71253,
      "ty": 2,
      "x": 531,
      "y": 534
    },
    {
      "t": 87995,
      "e": 71253,
      "ty": 41,
      "x": 48775,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88095,
      "e": 71353,
      "ty": 2,
      "x": 526,
      "y": 534
    },
    {
      "t": 88245,
      "e": 71503,
      "ty": 41,
      "x": 48213,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88544,
      "e": 71802,
      "ty": 3,
      "x": 526,
      "y": 534,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88672,
      "e": 71930,
      "ty": 4,
      "x": 48213,
      "y": 9114,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88672,
      "e": 71930,
      "ty": 5,
      "x": 526,
      "y": 534,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88995,
      "e": 72253,
      "ty": 2,
      "x": 524,
      "y": 537
    },
    {
      "t": 88995,
      "e": 72253,
      "ty": 41,
      "x": 47988,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89096,
      "e": 72354,
      "ty": 2,
      "x": 506,
      "y": 553
    },
    {
      "t": 89195,
      "e": 72453,
      "ty": 2,
      "x": 501,
      "y": 555
    },
    {
      "t": 89245,
      "e": 72503,
      "ty": 41,
      "x": 45403,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89295,
      "e": 72553,
      "ty": 2,
      "x": 511,
      "y": 553
    },
    {
      "t": 89396,
      "e": 72654,
      "ty": 2,
      "x": 527,
      "y": 547
    },
    {
      "t": 89495,
      "e": 72753,
      "ty": 2,
      "x": 547,
      "y": 544
    },
    {
      "t": 89495,
      "e": 72753,
      "ty": 41,
      "x": 50573,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89595,
      "e": 72853,
      "ty": 2,
      "x": 572,
      "y": 544
    },
    {
      "t": 89695,
      "e": 72953,
      "ty": 2,
      "x": 573,
      "y": 544
    },
    {
      "t": 89746,
      "e": 73004,
      "ty": 41,
      "x": 53496,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 89895,
      "e": 73153,
      "ty": 2,
      "x": 556,
      "y": 547
    },
    {
      "t": 89995,
      "e": 73253,
      "ty": 2,
      "x": 543,
      "y": 547
    },
    {
      "t": 89995,
      "e": 73253,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 89997,
      "e": 73255,
      "ty": 41,
      "x": 50124,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90245,
      "e": 73503,
      "ty": 41,
      "x": 49787,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 90295,
      "e": 73553,
      "ty": 2,
      "x": 540,
      "y": 547
    },
    {
      "t": 90995,
      "e": 74253,
      "ty": 2,
      "x": 546,
      "y": 547
    },
    {
      "t": 90996,
      "e": 74254,
      "ty": 41,
      "x": 50461,
      "y": 19632,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91096,
      "e": 74354,
      "ty": 2,
      "x": 561,
      "y": 548
    },
    {
      "t": 91245,
      "e": 74503,
      "ty": 41,
      "x": 52147,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91295,
      "e": 74553,
      "ty": 2,
      "x": 554,
      "y": 548
    },
    {
      "t": 91396,
      "e": 74654,
      "ty": 2,
      "x": 508,
      "y": 545
    },
    {
      "t": 91495,
      "e": 74753,
      "ty": 2,
      "x": 479,
      "y": 541
    },
    {
      "t": 91496,
      "e": 74754,
      "ty": 41,
      "x": 42930,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91595,
      "e": 74853,
      "ty": 2,
      "x": 463,
      "y": 541
    },
    {
      "t": 91695,
      "e": 74953,
      "ty": 2,
      "x": 452,
      "y": 539
    },
    {
      "t": 91746,
      "e": 75004,
      "ty": 41,
      "x": 39782,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 91795,
      "e": 75053,
      "ty": 2,
      "x": 451,
      "y": 538
    },
    {
      "t": 92113,
      "e": 75371,
      "ty": 3,
      "x": 451,
      "y": 538,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92223,
      "e": 75481,
      "ty": 4,
      "x": 39782,
      "y": 12351,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92223,
      "e": 75481,
      "ty": 5,
      "x": 451,
      "y": 538,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92695,
      "e": 75953,
      "ty": 2,
      "x": 452,
      "y": 546
    },
    {
      "t": 92745,
      "e": 76003,
      "ty": 41,
      "x": 41356,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 92795,
      "e": 76053,
      "ty": 2,
      "x": 471,
      "y": 568
    },
    {
      "t": 92895,
      "e": 76153,
      "ty": 2,
      "x": 473,
      "y": 570
    },
    {
      "t": 92996,
      "e": 76254,
      "ty": 41,
      "x": 42255,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93095,
      "e": 76353,
      "ty": 2,
      "x": 489,
      "y": 569
    },
    {
      "t": 93246,
      "e": 76504,
      "ty": 41,
      "x": 44054,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93628,
      "e": 76886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 93628,
      "e": 76886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 93755,
      "e": 77013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward  diagonal up to each point on that line"
    },
    {
      "t": 94828,
      "e": 78086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 94899,
      "e": 78157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward diagonal up to each point on that line"
    },
    {
      "t": 95164,
      "e": 78422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 95267,
      "e": 78525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 95269,
      "e": 78527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95339,
      "e": 78597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward( diagonal up to each point on that line"
    },
    {
      "t": 95387,
      "e": 78645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 95947,
      "e": 79205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 95947,
      "e": 79205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96012,
      "e": 79270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(r diagonal up to each point on that line"
    },
    {
      "t": 96148,
      "e": 79406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 96149,
      "e": 79407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96211,
      "e": 79469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(ri diagonal up to each point on that line"
    },
    {
      "t": 96596,
      "e": 79854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 96597,
      "e": 79855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96675,
      "e": 79933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(rig diagonal up to each point on that line"
    },
    {
      "t": 96788,
      "e": 80046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 96788,
      "e": 80046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96851,
      "e": 80109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(righ diagonal up to each point on that line"
    },
    {
      "t": 97004,
      "e": 80262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 97004,
      "e": 80262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97059,
      "e": 80262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(right diagonal up to each point on that line"
    },
    {
      "t": 97197,
      "e": 80400,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(right diagonal up to each point on that line"
    },
    {
      "t": 97436,
      "e": 80639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 97588,
      "e": 80791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 97589,
      "e": 80792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97683,
      "e": 80886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(right) diagonal up to each point on that line"
    },
    {
      "t": 97731,
      "e": 80934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 98796,
      "e": 81999,
      "ty": 2,
      "x": 496,
      "y": 569
    },
    {
      "t": 98895,
      "e": 82098,
      "ty": 2,
      "x": 498,
      "y": 569
    },
    {
      "t": 98996,
      "e": 82199,
      "ty": 2,
      "x": 429,
      "y": 528
    },
    {
      "t": 98996,
      "e": 82199,
      "ty": 41,
      "x": 37309,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99096,
      "e": 82299,
      "ty": 2,
      "x": 428,
      "y": 530
    },
    {
      "t": 99144,
      "e": 82347,
      "ty": 7,
      "x": 492,
      "y": 514,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99195,
      "e": 82398,
      "ty": 2,
      "x": 524,
      "y": 505
    },
    {
      "t": 99245,
      "e": 82448,
      "ty": 41,
      "x": 42255,
      "y": 35729,
      "ta": "#.strategy > p"
    },
    {
      "t": 99261,
      "e": 82464,
      "ty": 6,
      "x": 392,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99295,
      "e": 82498,
      "ty": 2,
      "x": 261,
      "y": 548
    },
    {
      "t": 99395,
      "e": 82598,
      "ty": 2,
      "x": 171,
      "y": 576
    },
    {
      "t": 99495,
      "e": 82698,
      "ty": 2,
      "x": 156,
      "y": 576
    },
    {
      "t": 99495,
      "e": 82698,
      "ty": 41,
      "x": 6621,
      "y": 43095,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99596,
      "e": 82799,
      "ty": 2,
      "x": 193,
      "y": 567
    },
    {
      "t": 99695,
      "e": 82898,
      "ty": 2,
      "x": 245,
      "y": 563
    },
    {
      "t": 99744,
      "e": 82947,
      "ty": 41,
      "x": 17300,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99795,
      "e": 82998,
      "ty": 2,
      "x": 258,
      "y": 556
    },
    {
      "t": 99896,
      "e": 83099,
      "ty": 2,
      "x": 261,
      "y": 548
    },
    {
      "t": 99995,
      "e": 83198,
      "ty": 2,
      "x": 260,
      "y": 548
    },
    {
      "t": 99996,
      "e": 83199,
      "ty": 41,
      "x": 18312,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100095,
      "e": 83298,
      "ty": 2,
      "x": 256,
      "y": 549
    },
    {
      "t": 100191,
      "e": 83394,
      "ty": 3,
      "x": 256,
      "y": 549,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100245,
      "e": 83448,
      "ty": 41,
      "x": 17862,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100311,
      "e": 83514,
      "ty": 4,
      "x": 17862,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100312,
      "e": 83515,
      "ty": 5,
      "x": 256,
      "y": 549,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100896,
      "e": 84099,
      "ty": 2,
      "x": 252,
      "y": 553
    },
    {
      "t": 100996,
      "e": 84199,
      "ty": 2,
      "x": 249,
      "y": 554
    },
    {
      "t": 100996,
      "e": 84199,
      "ty": 41,
      "x": 17075,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101196,
      "e": 84399,
      "ty": 2,
      "x": 247,
      "y": 555
    },
    {
      "t": 101246,
      "e": 84449,
      "ty": 41,
      "x": 16850,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101596,
      "e": 84799,
      "ty": 2,
      "x": 252,
      "y": 553
    },
    {
      "t": 101696,
      "e": 84899,
      "ty": 2,
      "x": 255,
      "y": 552
    },
    {
      "t": 101745,
      "e": 84948,
      "ty": 41,
      "x": 18312,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101795,
      "e": 84998,
      "ty": 2,
      "x": 262,
      "y": 549
    },
    {
      "t": 101896,
      "e": 85099,
      "ty": 2,
      "x": 292,
      "y": 544
    },
    {
      "t": 101996,
      "e": 85199,
      "ty": 2,
      "x": 411,
      "y": 528
    },
    {
      "t": 101997,
      "e": 85200,
      "ty": 41,
      "x": 35286,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102031,
      "e": 85234,
      "ty": 7,
      "x": 471,
      "y": 519,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102096,
      "e": 85299,
      "ty": 2,
      "x": 508,
      "y": 513
    },
    {
      "t": 102196,
      "e": 85399,
      "ty": 2,
      "x": 526,
      "y": 511
    },
    {
      "t": 102246,
      "e": 85449,
      "ty": 41,
      "x": 49674,
      "y": 35729,
      "ta": "#.strategy > p"
    },
    {
      "t": 102296,
      "e": 85499,
      "ty": 2,
      "x": 539,
      "y": 510
    },
    {
      "t": 102363,
      "e": 85566,
      "ty": 6,
      "x": 410,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102396,
      "e": 85599,
      "ty": 2,
      "x": 349,
      "y": 530
    },
    {
      "t": 102496,
      "e": 85699,
      "ty": 2,
      "x": 294,
      "y": 539
    },
    {
      "t": 102496,
      "e": 85699,
      "ty": 41,
      "x": 22134,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102596,
      "e": 85799,
      "ty": 2,
      "x": 270,
      "y": 551
    },
    {
      "t": 102746,
      "e": 85949,
      "ty": 41,
      "x": 19436,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104396,
      "e": 87599,
      "ty": 2,
      "x": 271,
      "y": 551
    },
    {
      "t": 104496,
      "e": 87699,
      "ty": 2,
      "x": 277,
      "y": 551
    },
    {
      "t": 104496,
      "e": 87699,
      "ty": 41,
      "x": 20223,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104595,
      "e": 87798,
      "ty": 2,
      "x": 288,
      "y": 552
    },
    {
      "t": 104696,
      "e": 87899,
      "ty": 2,
      "x": 351,
      "y": 552
    },
    {
      "t": 104746,
      "e": 87949,
      "ty": 41,
      "x": 31239,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104795,
      "e": 87998,
      "ty": 2,
      "x": 403,
      "y": 552
    },
    {
      "t": 104896,
      "e": 88099,
      "ty": 2,
      "x": 459,
      "y": 544
    },
    {
      "t": 104996,
      "e": 88199,
      "ty": 2,
      "x": 486,
      "y": 533
    },
    {
      "t": 104996,
      "e": 88199,
      "ty": 41,
      "x": 43716,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105065,
      "e": 88268,
      "ty": 7,
      "x": 511,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 105095,
      "e": 88298,
      "ty": 2,
      "x": 517,
      "y": 517
    },
    {
      "t": 105196,
      "e": 88399,
      "ty": 2,
      "x": 531,
      "y": 510
    },
    {
      "t": 105246,
      "e": 88449,
      "ty": 41,
      "x": 49674,
      "y": 28708,
      "ta": "#.strategy > p"
    },
    {
      "t": 105295,
      "e": 88498,
      "ty": 2,
      "x": 545,
      "y": 505
    },
    {
      "t": 105396,
      "e": 88599,
      "ty": 2,
      "x": 556,
      "y": 503
    },
    {
      "t": 105496,
      "e": 88699,
      "ty": 2,
      "x": 566,
      "y": 503
    },
    {
      "t": 105497,
      "e": 88700,
      "ty": 41,
      "x": 52709,
      "y": 19345,
      "ta": "#.strategy > p"
    },
    {
      "t": 105596,
      "e": 88799,
      "ty": 2,
      "x": 594,
      "y": 501
    },
    {
      "t": 105746,
      "e": 88949,
      "ty": 41,
      "x": 55857,
      "y": 14664,
      "ta": "#.strategy > p"
    },
    {
      "t": 105796,
      "e": 88999,
      "ty": 2,
      "x": 592,
      "y": 501
    },
    {
      "t": 105895,
      "e": 89098,
      "ty": 2,
      "x": 576,
      "y": 503
    },
    {
      "t": 105996,
      "e": 89199,
      "ty": 2,
      "x": 530,
      "y": 504
    },
    {
      "t": 105996,
      "e": 89199,
      "ty": 41,
      "x": 48662,
      "y": 21686,
      "ta": "#.strategy > p"
    },
    {
      "t": 106095,
      "e": 89298,
      "ty": 2,
      "x": 467,
      "y": 506
    },
    {
      "t": 106196,
      "e": 89399,
      "ty": 2,
      "x": 442,
      "y": 512
    },
    {
      "t": 106246,
      "e": 89449,
      "ty": 41,
      "x": 37984,
      "y": 56794,
      "ta": "#.strategy > p"
    },
    {
      "t": 106251,
      "e": 89454,
      "ty": 6,
      "x": 429,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106295,
      "e": 89498,
      "ty": 2,
      "x": 416,
      "y": 539
    },
    {
      "t": 106396,
      "e": 89599,
      "ty": 2,
      "x": 405,
      "y": 548
    },
    {
      "t": 106496,
      "e": 89699,
      "ty": 2,
      "x": 335,
      "y": 572
    },
    {
      "t": 106496,
      "e": 89699,
      "ty": 41,
      "x": 26743,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106596,
      "e": 89799,
      "ty": 2,
      "x": 282,
      "y": 580
    },
    {
      "t": 106696,
      "e": 89899,
      "ty": 2,
      "x": 268,
      "y": 576
    },
    {
      "t": 106746,
      "e": 89949,
      "ty": 41,
      "x": 18424,
      "y": 39859,
      "ta": "#strategyAnswer"
    },
    {
      "t": 106796,
      "e": 89999,
      "ty": 2,
      "x": 260,
      "y": 567
    },
    {
      "t": 106896,
      "e": 90099,
      "ty": 2,
      "x": 258,
      "y": 566
    },
    {
      "t": 106997,
      "e": 90200,
      "ty": 41,
      "x": 18087,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107096,
      "e": 90299,
      "ty": 2,
      "x": 258,
      "y": 561
    },
    {
      "t": 107246,
      "e": 90449,
      "ty": 41,
      "x": 18087,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107296,
      "e": 90499,
      "ty": 2,
      "x": 257,
      "y": 558
    },
    {
      "t": 107396,
      "e": 90599,
      "ty": 2,
      "x": 257,
      "y": 557
    },
    {
      "t": 107497,
      "e": 90700,
      "ty": 41,
      "x": 17975,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109995,
      "e": 93198,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 113420,
      "e": 95700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 113421,
      "e": 95701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113515,
      "e": 95795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 113820,
      "e": 96100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 113820,
      "e": 96100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113923,
      "e": 96203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 116051,
      "e": 98331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 116052,
      "e": 98332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116123,
      "e": 98403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 116332,
      "e": 98612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 116332,
      "e": 98612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116419,
      "e": 98699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 116643,
      "e": 98923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 116645,
      "e": 98925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116699,
      "e": 98979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 116771,
      "e": 99051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 116772,
      "e": 99052,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116843,
      "e": 99123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 116907,
      "e": 99187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 116908,
      "e": 99188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117003,
      "e": 99283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 117252,
      "e": 99532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 117252,
      "e": 99532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117323,
      "e": 99603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 117419,
      "e": 99699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 117419,
      "e": 99699,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117483,
      "e": 99763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 117563,
      "e": 99843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 117564,
      "e": 99844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117651,
      "e": 99931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 118083,
      "e": 100363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 118084,
      "e": 100364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118139,
      "e": 100419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 118228,
      "e": 100508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 118229,
      "e": 100509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118299,
      "e": 100579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 118611,
      "e": 100891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 118613,
      "e": 100893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118691,
      "e": 100971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 118779,
      "e": 101059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 118779,
      "e": 101059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118852,
      "e": 101132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 118980,
      "e": 101260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 118981,
      "e": 101261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119067,
      "e": 101347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 119147,
      "e": 101427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 119147,
      "e": 101427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119235,
      "e": 101515,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 119340,
      "e": 101620,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 119341,
      "e": 101621,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119451,
      "e": 101731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 119556,
      "e": 101836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 119556,
      "e": 101836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119635,
      "e": 101915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 119755,
      "e": 102035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 119756,
      "e": 102036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119819,
      "e": 102099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 119996,
      "e": 102276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 119997,
      "e": 102277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119998,
      "e": 102278,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120074,
      "e": 102354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 120155,
      "e": 102435,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 120155,
      "e": 102435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120219,
      "e": 102499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 120468,
      "e": 102748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 120468,
      "e": 102748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120547,
      "e": 102827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 120620,
      "e": 102900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 120620,
      "e": 102900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120707,
      "e": 102987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 121188,
      "e": 103468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 121188,
      "e": 103468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121268,
      "e": 103548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 121387,
      "e": 103667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 121389,
      "e": 103669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121450,
      "e": 103730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 121708,
      "e": 103988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 121708,
      "e": 103988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121779,
      "e": 104059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 121995,
      "e": 104275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 121997,
      "e": 104277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122075,
      "e": 104355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 122187,
      "e": 104467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 122187,
      "e": 104467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122275,
      "e": 104555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 122460,
      "e": 104740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 122460,
      "e": 104740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122532,
      "e": 104812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 122652,
      "e": 104932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 122652,
      "e": 104932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122739,
      "e": 105019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 122859,
      "e": 105139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 122860,
      "e": 105140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122939,
      "e": 105219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 123051,
      "e": 105331,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 123052,
      "e": 105332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123115,
      "e": 105395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 123211,
      "e": 105491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 123211,
      "e": 105491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123308,
      "e": 105588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 123484,
      "e": 105764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 123485,
      "e": 105765,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123548,
      "e": 105828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 123812,
      "e": 106092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 123812,
      "e": 106092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 123875,
      "e": 106155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 123997,
      "e": 106277,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(right) diagonal up to each point on that line. each of those points denote an ev"
    },
    {
      "t": 124084,
      "e": 106364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 124084,
      "e": 106364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124132,
      "e": 106412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 124236,
      "e": 106516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 124237,
      "e": 106517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124299,
      "e": 106579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 124371,
      "e": 106651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 124371,
      "e": 106651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124435,
      "e": 106715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 124483,
      "e": 106763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 124484,
      "e": 106764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124579,
      "e": 106859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 124675,
      "e": 106955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 124676,
      "e": 106956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124739,
      "e": 107019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 124787,
      "e": 107067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 124787,
      "e": 107067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 124859,
      "e": 107139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 124956,
      "e": 107236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 124957,
      "e": 107237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125067,
      "e": 107347,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 125204,
      "e": 107484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 125205,
      "e": 107485,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125266,
      "e": 107546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 125363,
      "e": 107643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 125364,
      "e": 107644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125451,
      "e": 107731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 125675,
      "e": 107955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 125676,
      "e": 107956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125747,
      "e": 108027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 125924,
      "e": 108204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 125924,
      "e": 108204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125995,
      "e": 108275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 126188,
      "e": 108468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 126188,
      "e": 108468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126291,
      "e": 108571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 126491,
      "e": 108771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 126493,
      "e": 108773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126507,
      "e": 108787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 126507,
      "e": 108787,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126523,
      "e": 108803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rt"
    },
    {
      "t": 126571,
      "e": 108851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 126716,
      "e": 108996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 126716,
      "e": 108996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126771,
      "e": 109051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 126987,
      "e": 109267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 126988,
      "e": 109268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127058,
      "e": 109338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 128513,
      "e": 110793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 128650,
      "e": 110794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(right) diagonal up to each point on that line. each of those points denote an event that startt"
    },
    {
      "t": 128744,
      "e": 110888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 128824,
      "e": 110968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(right) diagonal up to each point on that line. each of those points denote an event that start"
    },
    {
      "t": 129385,
      "e": 111529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 129386,
      "e": 111530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129472,
      "e": 111616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 129552,
      "e": 111696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 129552,
      "e": 111696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 129633,
      "e": 111777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 130673,
      "e": 112817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 130674,
      "e": 112818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130760,
      "e": 112904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 131449,
      "e": 113593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 131449,
      "e": 113593,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131520,
      "e": 113664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 131616,
      "e": 113760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 131616,
      "e": 113760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 131713,
      "e": 113857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 132329,
      "e": 114473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 132330,
      "e": 114474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132408,
      "e": 114552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 132521,
      "e": 114665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 132521,
      "e": 114665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132584,
      "e": 114728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 133024,
      "e": 115168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 133026,
      "e": 115170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133120,
      "e": 115264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 133328,
      "e": 115472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 133329,
      "e": 115473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133408,
      "e": 115552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 139545,
      "e": 120552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 139547,
      "e": 120554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139608,
      "e": 120615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 139993,
      "e": 121000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140225,
      "e": 121232,
      "ty": 7,
      "x": 187,
      "y": 478,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140242,
      "e": 121249,
      "ty": 41,
      "x": 5947,
      "y": 24430,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 140293,
      "e": 121300,
      "ty": 2,
      "x": 95,
      "y": 408
    },
    {
      "t": 140393,
      "e": 121400,
      "ty": 2,
      "x": 123,
      "y": 403
    },
    {
      "t": 140493,
      "e": 121500,
      "ty": 2,
      "x": 171,
      "y": 452
    },
    {
      "t": 140494,
      "e": 121501,
      "ty": 41,
      "x": 8307,
      "y": 24596,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 140592,
      "e": 121599,
      "ty": 2,
      "x": 169,
      "y": 493
    },
    {
      "t": 140693,
      "e": 121700,
      "ty": 2,
      "x": 187,
      "y": 499
    },
    {
      "t": 140743,
      "e": 121750,
      "ty": 41,
      "x": 16176,
      "y": 24027,
      "ta": "#.strategy > p"
    },
    {
      "t": 140793,
      "e": 121800,
      "ty": 2,
      "x": 301,
      "y": 517
    },
    {
      "t": 140877,
      "e": 121884,
      "ty": 6,
      "x": 300,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140892,
      "e": 121899,
      "ty": 2,
      "x": 292,
      "y": 527
    },
    {
      "t": 140992,
      "e": 121999,
      "ty": 2,
      "x": 265,
      "y": 543
    },
    {
      "t": 140992,
      "e": 121999,
      "ty": 41,
      "x": 18874,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141093,
      "e": 122100,
      "ty": 2,
      "x": 262,
      "y": 544
    },
    {
      "t": 141243,
      "e": 122250,
      "ty": 41,
      "x": 18537,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141292,
      "e": 122299,
      "ty": 2,
      "x": 261,
      "y": 545
    },
    {
      "t": 141393,
      "e": 122400,
      "ty": 2,
      "x": 259,
      "y": 545
    },
    {
      "t": 141477,
      "e": 122484,
      "ty": 3,
      "x": 259,
      "y": 545,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141493,
      "e": 122500,
      "ty": 41,
      "x": 18199,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141563,
      "e": 122570,
      "ty": 4,
      "x": 18199,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141565,
      "e": 122572,
      "ty": 5,
      "x": 259,
      "y": 545,
      "ta": "#strategyAnswer"
    },
    {
      "t": 142385,
      "e": 123392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "37"
    },
    {
      "t": 142480,
      "e": 123487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 143313,
      "e": 124320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 143376,
      "e": 124383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(right) diagonal up to each point on that line. ach of those points denote an event that starts at 12pm."
    },
    {
      "t": 144241,
      "e": 125248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 144369,
      "e": 125376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 144369,
      "e": 125376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 144448,
      "e": 125455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(right) diagonal up to each point on that line. Each of those points denote an event that starts at 12pm."
    },
    {
      "t": 144496,
      "e": 125503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 149993,
      "e": 130503,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 150093,
      "e": 130503,
      "ty": 2,
      "x": 274,
      "y": 535
    },
    {
      "t": 150116,
      "e": 130526,
      "ty": 7,
      "x": 308,
      "y": 515,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150193,
      "e": 130603,
      "ty": 2,
      "x": 317,
      "y": 510
    },
    {
      "t": 150243,
      "e": 130653,
      "ty": 41,
      "x": 24719,
      "y": 35729,
      "ta": "#.strategy > p"
    },
    {
      "t": 150293,
      "e": 130703,
      "ty": 2,
      "x": 314,
      "y": 511
    },
    {
      "t": 150334,
      "e": 130744,
      "ty": 6,
      "x": 304,
      "y": 525,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150393,
      "e": 130803,
      "ty": 2,
      "x": 297,
      "y": 532
    },
    {
      "t": 150493,
      "e": 130903,
      "ty": 2,
      "x": 289,
      "y": 548
    },
    {
      "t": 150493,
      "e": 130903,
      "ty": 41,
      "x": 21572,
      "y": 20441,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150593,
      "e": 131003,
      "ty": 2,
      "x": 289,
      "y": 558
    },
    {
      "t": 150693,
      "e": 131103,
      "ty": 2,
      "x": 310,
      "y": 576
    },
    {
      "t": 150743,
      "e": 131153,
      "ty": 41,
      "x": 26293,
      "y": 53613,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150793,
      "e": 131203,
      "ty": 2,
      "x": 343,
      "y": 596
    },
    {
      "t": 150884,
      "e": 131294,
      "ty": 7,
      "x": 361,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 150893,
      "e": 131303,
      "ty": 2,
      "x": 361,
      "y": 604
    },
    {
      "t": 150993,
      "e": 131403,
      "ty": 2,
      "x": 368,
      "y": 609
    },
    {
      "t": 150993,
      "e": 131403,
      "ty": 41,
      "x": 30452,
      "y": 64003,
      "ta": "#.strategy"
    },
    {
      "t": 154493,
      "e": 134903,
      "ty": 2,
      "x": 386,
      "y": 633
    },
    {
      "t": 154493,
      "e": 134903,
      "ty": 41,
      "x": 31553,
      "y": 7382,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 154571,
      "e": 134981,
      "ty": 6,
      "x": 387,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 154592,
      "e": 135002,
      "ty": 2,
      "x": 387,
      "y": 655
    },
    {
      "t": 154692,
      "e": 135102,
      "ty": 2,
      "x": 384,
      "y": 662
    },
    {
      "t": 154742,
      "e": 135152,
      "ty": 41,
      "x": 24797,
      "y": 17859,
      "ta": "#strategyButton"
    },
    {
      "t": 154792,
      "e": 135202,
      "ty": 2,
      "x": 386,
      "y": 672
    },
    {
      "t": 154892,
      "e": 135302,
      "ty": 2,
      "x": 388,
      "y": 674
    },
    {
      "t": 154992,
      "e": 135402,
      "ty": 41,
      "x": 26981,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 155685,
      "e": 136095,
      "ty": 3,
      "x": 388,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 155687,
      "e": 136097,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go to the X-axis and find 12pm, take the forward(right) diagonal up to each point on that line. Each of those points denote an event that starts at 12pm."
    },
    {
      "t": 155688,
      "e": 136098,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 155688,
      "e": 136098,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 155772,
      "e": 136182,
      "ty": 4,
      "x": 26981,
      "y": 37134,
      "ta": "#strategyButton"
    },
    {
      "t": 155780,
      "e": 136190,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 155782,
      "e": 136192,
      "ty": 5,
      "x": 388,
      "y": 674,
      "ta": "#strategyButton"
    },
    {
      "t": 155787,
      "e": 136197,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 156789,
      "e": 137199,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 157692,
      "e": 138102,
      "ty": 2,
      "x": 685,
      "y": 636
    },
    {
      "t": 157743,
      "e": 138153,
      "ty": 41,
      "x": 27205,
      "y": 33238,
      "ta": "html > body"
    },
    {
      "t": 157792,
      "e": 138202,
      "ty": 2,
      "x": 839,
      "y": 591
    },
    {
      "t": 157873,
      "e": 138283,
      "ty": 6,
      "x": 889,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 157893,
      "e": 138303,
      "ty": 2,
      "x": 893,
      "y": 571
    },
    {
      "t": 157993,
      "e": 138403,
      "ty": 2,
      "x": 899,
      "y": 562
    },
    {
      "t": 157993,
      "e": 138403,
      "ty": 41,
      "x": 19682,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158093,
      "e": 138503,
      "ty": 2,
      "x": 899,
      "y": 555
    },
    {
      "t": 158242,
      "e": 138652,
      "ty": 41,
      "x": 19465,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158293,
      "e": 138703,
      "ty": 2,
      "x": 896,
      "y": 556
    },
    {
      "t": 158392,
      "e": 138802,
      "ty": 2,
      "x": 895,
      "y": 565
    },
    {
      "t": 158492,
      "e": 138902,
      "ty": 2,
      "x": 895,
      "y": 566
    },
    {
      "t": 158493,
      "e": 138903,
      "ty": 41,
      "x": 18816,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158573,
      "e": 138983,
      "ty": 3,
      "x": 895,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158574,
      "e": 138984,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158676,
      "e": 139086,
      "ty": 4,
      "x": 18816,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158676,
      "e": 139086,
      "ty": 5,
      "x": 895,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 159993,
      "e": 140403,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 160041,
      "e": 140451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 160041,
      "e": 140451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 160104,
      "e": 140514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 160232,
      "e": 140642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 160233,
      "e": 140643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 160304,
      "e": 140714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 161093,
      "e": 141503,
      "ty": 2,
      "x": 894,
      "y": 568
    },
    {
      "t": 161176,
      "e": 141586,
      "ty": 7,
      "x": 894,
      "y": 576,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161193,
      "e": 141603,
      "ty": 2,
      "x": 894,
      "y": 582
    },
    {
      "t": 161242,
      "e": 141652,
      "ty": 41,
      "x": 18168,
      "y": 9160,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 161292,
      "e": 141702,
      "ty": 2,
      "x": 888,
      "y": 616
    },
    {
      "t": 161342,
      "e": 141752,
      "ty": 6,
      "x": 868,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161392,
      "e": 141802,
      "ty": 2,
      "x": 864,
      "y": 657
    },
    {
      "t": 161493,
      "e": 141903,
      "ty": 2,
      "x": 860,
      "y": 663
    },
    {
      "t": 161493,
      "e": 141903,
      "ty": 41,
      "x": 11246,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161593,
      "e": 142003,
      "ty": 2,
      "x": 857,
      "y": 661
    },
    {
      "t": 161693,
      "e": 142103,
      "ty": 2,
      "x": 853,
      "y": 657
    },
    {
      "t": 161743,
      "e": 142153,
      "ty": 41,
      "x": 9732,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161909,
      "e": 142319,
      "ty": 3,
      "x": 853,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161909,
      "e": 142319,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 161911,
      "e": 142321,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161911,
      "e": 142321,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161995,
      "e": 142405,
      "ty": 4,
      "x": 9732,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161995,
      "e": 142405,
      "ty": 5,
      "x": 853,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 163864,
      "e": 144274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 163961,
      "e": 144371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 163961,
      "e": 144371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 164039,
      "e": 144449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 164103,
      "e": 144513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 164345,
      "e": 144755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 164345,
      "e": 144755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 164440,
      "e": 144850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 164592,
      "e": 145002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 164592,
      "e": 145002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 164672,
      "e": 145082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 164864,
      "e": 145274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 164865,
      "e": 145275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 164928,
      "e": 145338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 165184,
      "e": 145594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 165185,
      "e": 145595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165239,
      "e": 145649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 165400,
      "e": 145810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 165400,
      "e": 145810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165464,
      "e": 145874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 165594,
      "e": 146004,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United"
    },
    {
      "t": 165600,
      "e": 146010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 165601,
      "e": 146011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165672,
      "e": 146082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 165794,
      "e": 146204,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United "
    },
    {
      "t": 166137,
      "e": 146547,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 166305,
      "e": 146715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 166305,
      "e": 146715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 166385,
      "e": 146795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 166416,
      "e": 146826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 166576,
      "e": 146986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 166577,
      "e": 146987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 166640,
      "e": 147050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 166808,
      "e": 147218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 166809,
      "e": 147219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 166927,
      "e": 147337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 167136,
      "e": 147546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 167137,
      "e": 147547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 167215,
      "e": 147625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 167393,
      "e": 147803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 167393,
      "e": 147803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 167463,
      "e": 147873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 167600,
      "e": 148010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 167600,
      "e": 148010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 167664,
      "e": 148074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 167793,
      "e": 148203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 168592,
      "e": 149002,
      "ty": 2,
      "x": 909,
      "y": 666
    },
    {
      "t": 168599,
      "e": 149009,
      "ty": 7,
      "x": 934,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168616,
      "e": 149026,
      "ty": 6,
      "x": 959,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 168693,
      "e": 149103,
      "ty": 2,
      "x": 975,
      "y": 678
    },
    {
      "t": 168743,
      "e": 149153,
      "ty": 41,
      "x": 53125,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 168793,
      "e": 149203,
      "ty": 2,
      "x": 1002,
      "y": 701
    },
    {
      "t": 168893,
      "e": 149303,
      "ty": 2,
      "x": 1002,
      "y": 702
    },
    {
      "t": 168993,
      "e": 149403,
      "ty": 2,
      "x": 1001,
      "y": 702
    },
    {
      "t": 168994,
      "e": 149404,
      "ty": 41,
      "x": 54156,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 169093,
      "e": 149503,
      "ty": 2,
      "x": 998,
      "y": 702
    },
    {
      "t": 169141,
      "e": 149551,
      "ty": 3,
      "x": 998,
      "y": 702,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 169142,
      "e": 149552,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 169142,
      "e": 149552,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 169142,
      "e": 149552,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 169228,
      "e": 149638,
      "ty": 4,
      "x": 52609,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 169228,
      "e": 149638,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 169228,
      "e": 149638,
      "ty": 5,
      "x": 998,
      "y": 702,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 169229,
      "e": 149639,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 169243,
      "e": 149653,
      "ty": 41,
      "x": 34093,
      "y": 38445,
      "ta": "html > body"
    },
    {
      "t": 169993,
      "e": 150403,
      "ty": 2,
      "x": 909,
      "y": 645
    },
    {
      "t": 169993,
      "e": 150403,
      "ty": 41,
      "x": 31028,
      "y": 35288,
      "ta": "html > body"
    },
    {
      "t": 169993,
      "e": 150403,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 170093,
      "e": 150503,
      "ty": 2,
      "x": 808,
      "y": 593
    },
    {
      "t": 170193,
      "e": 150603,
      "ty": 2,
      "x": 772,
      "y": 529
    },
    {
      "t": 170241,
      "e": 150651,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 170246,
      "e": 150656,
      "ty": 41,
      "x": 25242,
      "y": 27421,
      "ta": "html > body"
    },
    {
      "t": 170292,
      "e": 150702,
      "ty": 2,
      "x": 713,
      "y": 478
    },
    {
      "t": 170393,
      "e": 150803,
      "ty": 2,
      "x": 584,
      "y": 417
    },
    {
      "t": 170493,
      "e": 150903,
      "ty": 2,
      "x": 587,
      "y": 410
    },
    {
      "t": 170493,
      "e": 150903,
      "ty": 41,
      "x": 19939,
      "y": 22269,
      "ta": "html > body"
    },
    {
      "t": 170593,
      "e": 151003,
      "ty": 2,
      "x": 644,
      "y": 377
    },
    {
      "t": 170693,
      "e": 151103,
      "ty": 2,
      "x": 748,
      "y": 310
    },
    {
      "t": 170743,
      "e": 151153,
      "ty": 41,
      "x": 26172,
      "y": 15455,
      "ta": "html > body"
    },
    {
      "t": 170792,
      "e": 151202,
      "ty": 2,
      "x": 782,
      "y": 276
    },
    {
      "t": 170893,
      "e": 151303,
      "ty": 2,
      "x": 790,
      "y": 270
    },
    {
      "t": 170993,
      "e": 151403,
      "ty": 2,
      "x": 790,
      "y": 269
    },
    {
      "t": 170993,
      "e": 151403,
      "ty": 41,
      "x": 26930,
      "y": 14458,
      "ta": "html > body"
    },
    {
      "t": 171092,
      "e": 151502,
      "ty": 2,
      "x": 797,
      "y": 262
    },
    {
      "t": 171193,
      "e": 151603,
      "ty": 2,
      "x": 809,
      "y": 251
    },
    {
      "t": 171243,
      "e": 151653,
      "ty": 41,
      "x": 27653,
      "y": 13350,
      "ta": "html > body"
    },
    {
      "t": 171293,
      "e": 151703,
      "ty": 2,
      "x": 817,
      "y": 246
    },
    {
      "t": 171389,
      "e": 151799,
      "ty": 6,
      "x": 826,
      "y": 243,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 171393,
      "e": 151803,
      "ty": 2,
      "x": 826,
      "y": 243
    },
    {
      "t": 171493,
      "e": 151903,
      "ty": 2,
      "x": 832,
      "y": 239
    },
    {
      "t": 171493,
      "e": 151903,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 171629,
      "e": 152039,
      "ty": 3,
      "x": 832,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 171630,
      "e": 152040,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 171716,
      "e": 152126,
      "ty": 4,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 171717,
      "e": 152127,
      "ty": 5,
      "x": 832,
      "y": 239,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 171718,
      "e": 152128,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 171940,
      "e": 152350,
      "ty": 7,
      "x": 839,
      "y": 230,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 171993,
      "e": 152403,
      "ty": 2,
      "x": 851,
      "y": 213
    },
    {
      "t": 171993,
      "e": 152403,
      "ty": 41,
      "x": 7019,
      "y": 14102,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 172093,
      "e": 152503,
      "ty": 2,
      "x": 895,
      "y": 198
    },
    {
      "t": 172193,
      "e": 152603,
      "ty": 2,
      "x": 896,
      "y": 200
    },
    {
      "t": 172243,
      "e": 152653,
      "ty": 41,
      "x": 17936,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 172293,
      "e": 152703,
      "ty": 2,
      "x": 893,
      "y": 264
    },
    {
      "t": 172393,
      "e": 152803,
      "ty": 2,
      "x": 865,
      "y": 379
    },
    {
      "t": 172493,
      "e": 152903,
      "ty": 2,
      "x": 864,
      "y": 392
    },
    {
      "t": 172494,
      "e": 152904,
      "ty": 41,
      "x": 10104,
      "y": 10019,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 172593,
      "e": 153003,
      "ty": 2,
      "x": 855,
      "y": 401
    },
    {
      "t": 172693,
      "e": 153103,
      "ty": 2,
      "x": 854,
      "y": 402
    },
    {
      "t": 172743,
      "e": 153153,
      "ty": 41,
      "x": 9867,
      "y": 11644,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 172794,
      "e": 153204,
      "ty": 2,
      "x": 906,
      "y": 381
    },
    {
      "t": 172893,
      "e": 153303,
      "ty": 2,
      "x": 935,
      "y": 376
    },
    {
      "t": 172993,
      "e": 153403,
      "ty": 41,
      "x": 26954,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 173393,
      "e": 153803,
      "ty": 2,
      "x": 937,
      "y": 376
    },
    {
      "t": 173494,
      "e": 153904,
      "ty": 2,
      "x": 944,
      "y": 376
    },
    {
      "t": 173494,
      "e": 153904,
      "ty": 41,
      "x": 29090,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 173694,
      "e": 154104,
      "ty": 2,
      "x": 947,
      "y": 375
    },
    {
      "t": 173743,
      "e": 154153,
      "ty": 41,
      "x": 29802,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 173793,
      "e": 154203,
      "ty": 2,
      "x": 937,
      "y": 374
    },
    {
      "t": 173892,
      "e": 154302,
      "ty": 2,
      "x": 859,
      "y": 365
    },
    {
      "t": 173994,
      "e": 154404,
      "ty": 2,
      "x": 851,
      "y": 366
    },
    {
      "t": 173994,
      "e": 154404,
      "ty": 41,
      "x": 7019,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 174092,
      "e": 154502,
      "ty": 2,
      "x": 839,
      "y": 371
    },
    {
      "t": 174193,
      "e": 154603,
      "ty": 2,
      "x": 837,
      "y": 372
    },
    {
      "t": 174244,
      "e": 154654,
      "ty": 41,
      "x": 3459,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 174293,
      "e": 154703,
      "ty": 2,
      "x": 836,
      "y": 372
    },
    {
      "t": 174393,
      "e": 154803,
      "ty": 2,
      "x": 844,
      "y": 373
    },
    {
      "t": 174493,
      "e": 154903,
      "ty": 2,
      "x": 846,
      "y": 373
    },
    {
      "t": 174494,
      "e": 154904,
      "ty": 41,
      "x": 5832,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 174693,
      "e": 155103,
      "ty": 2,
      "x": 848,
      "y": 374
    },
    {
      "t": 174744,
      "e": 155154,
      "ty": 41,
      "x": 7494,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 174793,
      "e": 155203,
      "ty": 2,
      "x": 853,
      "y": 375
    },
    {
      "t": 174893,
      "e": 155303,
      "ty": 2,
      "x": 854,
      "y": 381
    },
    {
      "t": 174993,
      "e": 155403,
      "ty": 2,
      "x": 853,
      "y": 410
    },
    {
      "t": 174994,
      "e": 155404,
      "ty": 41,
      "x": 36965,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 175094,
      "e": 155504,
      "ty": 2,
      "x": 852,
      "y": 418
    },
    {
      "t": 175193,
      "e": 155603,
      "ty": 2,
      "x": 845,
      "y": 422
    },
    {
      "t": 175244,
      "e": 155654,
      "ty": 41,
      "x": 22918,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 175294,
      "e": 155704,
      "ty": 2,
      "x": 840,
      "y": 425
    },
    {
      "t": 175394,
      "e": 155804,
      "ty": 2,
      "x": 837,
      "y": 430
    },
    {
      "t": 175493,
      "e": 155903,
      "ty": 41,
      "x": 3697,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 175593,
      "e": 156003,
      "ty": 2,
      "x": 837,
      "y": 431
    },
    {
      "t": 175693,
      "e": 156103,
      "ty": 2,
      "x": 836,
      "y": 432
    },
    {
      "t": 175744,
      "e": 156154,
      "ty": 41,
      "x": 11644,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 175793,
      "e": 156203,
      "ty": 2,
      "x": 834,
      "y": 435
    },
    {
      "t": 175885,
      "e": 156295,
      "ty": 6,
      "x": 834,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 175893,
      "e": 156303,
      "ty": 2,
      "x": 834,
      "y": 436
    },
    {
      "t": 175993,
      "e": 156403,
      "ty": 41,
      "x": 38202,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 176092,
      "e": 156403,
      "ty": 2,
      "x": 834,
      "y": 437
    },
    {
      "t": 176243,
      "e": 156554,
      "ty": 41,
      "x": 38202,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 176292,
      "e": 156603,
      "ty": 3,
      "x": 834,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 176292,
      "e": 156603,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 176292,
      "e": 156603,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 176396,
      "e": 156707,
      "ty": 4,
      "x": 38202,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 176397,
      "e": 156708,
      "ty": 5,
      "x": 834,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 176397,
      "e": 156708,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 176622,
      "e": 156933,
      "ty": 7,
      "x": 850,
      "y": 439,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 176692,
      "e": 157003,
      "ty": 2,
      "x": 916,
      "y": 431
    },
    {
      "t": 176743,
      "e": 157054,
      "ty": 41,
      "x": 22445,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 176793,
      "e": 157104,
      "ty": 2,
      "x": 915,
      "y": 421
    },
    {
      "t": 176892,
      "e": 157203,
      "ty": 2,
      "x": 905,
      "y": 416
    },
    {
      "t": 176992,
      "e": 157303,
      "ty": 2,
      "x": 905,
      "y": 415
    },
    {
      "t": 176993,
      "e": 157304,
      "ty": 41,
      "x": 19835,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 177093,
      "e": 157404,
      "ty": 2,
      "x": 906,
      "y": 415
    },
    {
      "t": 177192,
      "e": 157503,
      "ty": 2,
      "x": 907,
      "y": 433
    },
    {
      "t": 177243,
      "e": 157554,
      "ty": 41,
      "x": 20309,
      "y": 9362,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 177293,
      "e": 157604,
      "ty": 2,
      "x": 905,
      "y": 437
    },
    {
      "t": 177393,
      "e": 157704,
      "ty": 2,
      "x": 904,
      "y": 448
    },
    {
      "t": 177492,
      "e": 157803,
      "ty": 2,
      "x": 912,
      "y": 450
    },
    {
      "t": 177492,
      "e": 157803,
      "ty": 41,
      "x": 21496,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 177592,
      "e": 157903,
      "ty": 2,
      "x": 939,
      "y": 476
    },
    {
      "t": 177693,
      "e": 158004,
      "ty": 2,
      "x": 965,
      "y": 496
    },
    {
      "t": 177742,
      "e": 158053,
      "ty": 41,
      "x": 35261,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 177792,
      "e": 158103,
      "ty": 2,
      "x": 974,
      "y": 500
    },
    {
      "t": 177892,
      "e": 158203,
      "ty": 2,
      "x": 980,
      "y": 500
    },
    {
      "t": 177992,
      "e": 158303,
      "ty": 41,
      "x": 37634,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 178692,
      "e": 159003,
      "ty": 2,
      "x": 996,
      "y": 512
    },
    {
      "t": 178742,
      "e": 159053,
      "ty": 41,
      "x": 42143,
      "y": 11702,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 178793,
      "e": 159104,
      "ty": 2,
      "x": 1003,
      "y": 528
    },
    {
      "t": 178893,
      "e": 159204,
      "ty": 2,
      "x": 1005,
      "y": 558
    },
    {
      "t": 178993,
      "e": 159304,
      "ty": 2,
      "x": 1004,
      "y": 577
    },
    {
      "t": 178993,
      "e": 159304,
      "ty": 41,
      "x": 43330,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 179092,
      "e": 159403,
      "ty": 2,
      "x": 969,
      "y": 585
    },
    {
      "t": 179193,
      "e": 159504,
      "ty": 2,
      "x": 930,
      "y": 585
    },
    {
      "t": 179242,
      "e": 159553,
      "ty": 41,
      "x": 24107,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 179293,
      "e": 159604,
      "ty": 2,
      "x": 921,
      "y": 585
    },
    {
      "t": 179492,
      "e": 159803,
      "ty": 41,
      "x": 23632,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 179742,
      "e": 160053,
      "ty": 41,
      "x": 23395,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 179793,
      "e": 160104,
      "ty": 2,
      "x": 885,
      "y": 599
    },
    {
      "t": 179892,
      "e": 160203,
      "ty": 2,
      "x": 868,
      "y": 610
    },
    {
      "t": 179992,
      "e": 160303,
      "ty": 2,
      "x": 866,
      "y": 611
    },
    {
      "t": 179993,
      "e": 160304,
      "ty": 41,
      "x": 10579,
      "y": 33626,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 180092,
      "e": 160403,
      "ty": 2,
      "x": 859,
      "y": 618
    },
    {
      "t": 180192,
      "e": 160503,
      "ty": 2,
      "x": 858,
      "y": 621
    },
    {
      "t": 180242,
      "e": 160553,
      "ty": 41,
      "x": 8680,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 180692,
      "e": 161003,
      "ty": 2,
      "x": 858,
      "y": 629
    },
    {
      "t": 180743,
      "e": 161054,
      "ty": 41,
      "x": 8680,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 180792,
      "e": 161103,
      "ty": 2,
      "x": 856,
      "y": 640
    },
    {
      "t": 180893,
      "e": 161204,
      "ty": 2,
      "x": 843,
      "y": 648
    },
    {
      "t": 180993,
      "e": 161304,
      "ty": 2,
      "x": 839,
      "y": 652
    },
    {
      "t": 180993,
      "e": 161304,
      "ty": 41,
      "x": 4171,
      "y": 10019,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 181093,
      "e": 161404,
      "ty": 2,
      "x": 837,
      "y": 658
    },
    {
      "t": 181193,
      "e": 161504,
      "ty": 2,
      "x": 832,
      "y": 666
    },
    {
      "t": 181209,
      "e": 161520,
      "ty": 6,
      "x": 831,
      "y": 669,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 181243,
      "e": 161554,
      "ty": 41,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 181292,
      "e": 161603,
      "ty": 7,
      "x": 825,
      "y": 680,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 181292,
      "e": 161603,
      "ty": 2,
      "x": 825,
      "y": 680
    },
    {
      "t": 181392,
      "e": 161703,
      "ty": 2,
      "x": 813,
      "y": 691
    },
    {
      "t": 181492,
      "e": 161803,
      "ty": 2,
      "x": 806,
      "y": 696
    },
    {
      "t": 181493,
      "e": 161804,
      "ty": 41,
      "x": 27481,
      "y": 38113,
      "ta": "html > body"
    },
    {
      "t": 181593,
      "e": 161904,
      "ty": 2,
      "x": 804,
      "y": 698
    },
    {
      "t": 181742,
      "e": 162053,
      "ty": 41,
      "x": 27412,
      "y": 38224,
      "ta": "html > body"
    },
    {
      "t": 182193,
      "e": 162504,
      "ty": 2,
      "x": 804,
      "y": 699
    },
    {
      "t": 182242,
      "e": 162553,
      "ty": 41,
      "x": 27515,
      "y": 38279,
      "ta": "html > body"
    },
    {
      "t": 182292,
      "e": 162603,
      "ty": 2,
      "x": 811,
      "y": 699
    },
    {
      "t": 182393,
      "e": 162704,
      "ty": 2,
      "x": 816,
      "y": 699
    },
    {
      "t": 182492,
      "e": 162803,
      "ty": 2,
      "x": 820,
      "y": 699
    },
    {
      "t": 182493,
      "e": 162804,
      "ty": 41,
      "x": 27963,
      "y": 38279,
      "ta": "html > body"
    },
    {
      "t": 182692,
      "e": 163003,
      "ty": 2,
      "x": 824,
      "y": 701
    },
    {
      "t": 182743,
      "e": 163054,
      "ty": 41,
      "x": 649,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 183093,
      "e": 163404,
      "ty": 2,
      "x": 825,
      "y": 701
    },
    {
      "t": 183094,
      "e": 163405,
      "ty": 6,
      "x": 826,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 183193,
      "e": 163504,
      "ty": 2,
      "x": 827,
      "y": 702
    },
    {
      "t": 183242,
      "e": 163553,
      "ty": 41,
      "x": 2914,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 183392,
      "e": 163703,
      "ty": 2,
      "x": 828,
      "y": 703
    },
    {
      "t": 183493,
      "e": 163804,
      "ty": 2,
      "x": 831,
      "y": 704
    },
    {
      "t": 183493,
      "e": 163804,
      "ty": 41,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 183693,
      "e": 163804,
      "ty": 3,
      "x": 831,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 183696,
      "e": 163807,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 183696,
      "e": 163807,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 183787,
      "e": 163898,
      "ty": 4,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 183787,
      "e": 163898,
      "ty": 5,
      "x": 831,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 183787,
      "e": 163898,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 184060,
      "e": 164171,
      "ty": 7,
      "x": 831,
      "y": 695,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 184093,
      "e": 164204,
      "ty": 2,
      "x": 831,
      "y": 692
    },
    {
      "t": 184192,
      "e": 164303,
      "ty": 2,
      "x": 804,
      "y": 690
    },
    {
      "t": 184242,
      "e": 164353,
      "ty": 41,
      "x": 26482,
      "y": 37780,
      "ta": "html > body"
    },
    {
      "t": 184292,
      "e": 164403,
      "ty": 2,
      "x": 775,
      "y": 690
    },
    {
      "t": 184393,
      "e": 164504,
      "ty": 2,
      "x": 774,
      "y": 708
    },
    {
      "t": 184493,
      "e": 164604,
      "ty": 2,
      "x": 787,
      "y": 735
    },
    {
      "t": 184493,
      "e": 164604,
      "ty": 41,
      "x": 26826,
      "y": 40273,
      "ta": "html > body"
    },
    {
      "t": 184592,
      "e": 164703,
      "ty": 2,
      "x": 819,
      "y": 753
    },
    {
      "t": 184613,
      "e": 164724,
      "ty": 6,
      "x": 834,
      "y": 756,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 184628,
      "e": 164739,
      "ty": 7,
      "x": 843,
      "y": 757,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 184692,
      "e": 164803,
      "ty": 2,
      "x": 855,
      "y": 758
    },
    {
      "t": 184743,
      "e": 164854,
      "ty": 41,
      "x": 17765,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 184792,
      "e": 164903,
      "ty": 2,
      "x": 915,
      "y": 758
    },
    {
      "t": 184893,
      "e": 165004,
      "ty": 2,
      "x": 966,
      "y": 758
    },
    {
      "t": 184993,
      "e": 165104,
      "ty": 2,
      "x": 1010,
      "y": 755
    },
    {
      "t": 184993,
      "e": 165104,
      "ty": 41,
      "x": 44754,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 185093,
      "e": 165204,
      "ty": 2,
      "x": 1027,
      "y": 748
    },
    {
      "t": 185192,
      "e": 165303,
      "ty": 2,
      "x": 1040,
      "y": 743
    },
    {
      "t": 185243,
      "e": 165354,
      "ty": 41,
      "x": 53772,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 185293,
      "e": 165404,
      "ty": 2,
      "x": 1061,
      "y": 741
    },
    {
      "t": 185492,
      "e": 165603,
      "ty": 2,
      "x": 1023,
      "y": 731
    },
    {
      "t": 185493,
      "e": 165604,
      "ty": 41,
      "x": 50593,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 185592,
      "e": 165703,
      "ty": 2,
      "x": 959,
      "y": 725
    },
    {
      "t": 185692,
      "e": 165803,
      "ty": 2,
      "x": 875,
      "y": 740
    },
    {
      "t": 185743,
      "e": 165854,
      "ty": 41,
      "x": 8918,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 185793,
      "e": 165904,
      "ty": 2,
      "x": 846,
      "y": 748
    },
    {
      "t": 185812,
      "e": 165923,
      "ty": 6,
      "x": 838,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 185892,
      "e": 166003,
      "ty": 2,
      "x": 826,
      "y": 760
    },
    {
      "t": 185896,
      "e": 166007,
      "ty": 7,
      "x": 822,
      "y": 762,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 185993,
      "e": 166104,
      "ty": 2,
      "x": 803,
      "y": 774
    },
    {
      "t": 185993,
      "e": 166104,
      "ty": 41,
      "x": 27377,
      "y": 42434,
      "ta": "html > body"
    },
    {
      "t": 186092,
      "e": 166203,
      "ty": 2,
      "x": 793,
      "y": 817
    },
    {
      "t": 186193,
      "e": 166304,
      "ty": 2,
      "x": 810,
      "y": 875
    },
    {
      "t": 186243,
      "e": 166354,
      "ty": 41,
      "x": 27687,
      "y": 48140,
      "ta": "html > body"
    },
    {
      "t": 186292,
      "e": 166403,
      "ty": 2,
      "x": 812,
      "y": 877
    },
    {
      "t": 186393,
      "e": 166504,
      "ty": 2,
      "x": 813,
      "y": 877
    },
    {
      "t": 186493,
      "e": 166604,
      "ty": 2,
      "x": 770,
      "y": 867
    },
    {
      "t": 186495,
      "e": 166606,
      "ty": 41,
      "x": 26241,
      "y": 47586,
      "ta": "html > body"
    },
    {
      "t": 186593,
      "e": 166704,
      "ty": 2,
      "x": 753,
      "y": 865
    },
    {
      "t": 186692,
      "e": 166803,
      "ty": 2,
      "x": 752,
      "y": 867
    },
    {
      "t": 186743,
      "e": 166854,
      "ty": 41,
      "x": 25621,
      "y": 47863,
      "ta": "html > body"
    },
    {
      "t": 186793,
      "e": 166904,
      "ty": 2,
      "x": 752,
      "y": 876
    },
    {
      "t": 186893,
      "e": 167004,
      "ty": 2,
      "x": 752,
      "y": 880
    },
    {
      "t": 186993,
      "e": 167104,
      "ty": 41,
      "x": 25621,
      "y": 48306,
      "ta": "html > body"
    },
    {
      "t": 187093,
      "e": 167204,
      "ty": 2,
      "x": 754,
      "y": 882
    },
    {
      "t": 187243,
      "e": 167354,
      "ty": 41,
      "x": 25793,
      "y": 48583,
      "ta": "html > body"
    },
    {
      "t": 187293,
      "e": 167404,
      "ty": 2,
      "x": 773,
      "y": 891
    },
    {
      "t": 187393,
      "e": 167504,
      "ty": 2,
      "x": 800,
      "y": 906
    },
    {
      "t": 187493,
      "e": 167604,
      "ty": 2,
      "x": 806,
      "y": 916
    },
    {
      "t": 187493,
      "e": 167604,
      "ty": 41,
      "x": 27481,
      "y": 50300,
      "ta": "html > body"
    },
    {
      "t": 187592,
      "e": 167703,
      "ty": 2,
      "x": 814,
      "y": 921
    },
    {
      "t": 187692,
      "e": 167803,
      "ty": 2,
      "x": 824,
      "y": 932
    },
    {
      "t": 187696,
      "e": 167807,
      "ty": 6,
      "x": 827,
      "y": 936,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 187731,
      "e": 167842,
      "ty": 7,
      "x": 829,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 187743,
      "e": 167854,
      "ty": 41,
      "x": 8277,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 187792,
      "e": 167903,
      "ty": 2,
      "x": 831,
      "y": 942
    },
    {
      "t": 187981,
      "e": 168092,
      "ty": 6,
      "x": 831,
      "y": 940,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 187993,
      "e": 168104,
      "ty": 2,
      "x": 831,
      "y": 940
    },
    {
      "t": 187993,
      "e": 168104,
      "ty": 41,
      "x": 23079,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 188092,
      "e": 168203,
      "ty": 2,
      "x": 831,
      "y": 936
    },
    {
      "t": 188193,
      "e": 168304,
      "ty": 2,
      "x": 831,
      "y": 931
    },
    {
      "t": 188243,
      "e": 168354,
      "ty": 41,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 188253,
      "e": 168364,
      "ty": 3,
      "x": 831,
      "y": 931,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 188254,
      "e": 168365,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 188255,
      "e": 168366,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 188348,
      "e": 168459,
      "ty": 4,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 188348,
      "e": 168459,
      "ty": 5,
      "x": 831,
      "y": 931,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 188348,
      "e": 168459,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 188549,
      "e": 168660,
      "ty": 7,
      "x": 849,
      "y": 942,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 188594,
      "e": 168705,
      "ty": 2,
      "x": 880,
      "y": 964
    },
    {
      "t": 188695,
      "e": 168706,
      "ty": 2,
      "x": 906,
      "y": 998
    },
    {
      "t": 188700,
      "e": 168711,
      "ty": 6,
      "x": 913,
      "y": 1010,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 188744,
      "e": 168755,
      "ty": 41,
      "x": 48229,
      "y": 31774,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 188794,
      "e": 168805,
      "ty": 2,
      "x": 925,
      "y": 1027
    },
    {
      "t": 188894,
      "e": 168905,
      "ty": 2,
      "x": 926,
      "y": 1032
    },
    {
      "t": 188994,
      "e": 169005,
      "ty": 41,
      "x": 49775,
      "y": 53619,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 189095,
      "e": 169106,
      "ty": 2,
      "x": 921,
      "y": 1030
    },
    {
      "t": 189194,
      "e": 169205,
      "ty": 2,
      "x": 921,
      "y": 1029
    },
    {
      "t": 189245,
      "e": 169256,
      "ty": 41,
      "x": 47198,
      "y": 43690,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 189295,
      "e": 169306,
      "ty": 2,
      "x": 921,
      "y": 1027
    },
    {
      "t": 189394,
      "e": 169405,
      "ty": 2,
      "x": 921,
      "y": 1024
    },
    {
      "t": 189494,
      "e": 169505,
      "ty": 41,
      "x": 47198,
      "y": 37732,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 190454,
      "e": 170465,
      "ty": 3,
      "x": 921,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 190455,
      "e": 170466,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 190456,
      "e": 170467,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 190556,
      "e": 170567,
      "ty": 4,
      "x": 47198,
      "y": 37732,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 190557,
      "e": 170568,
      "ty": 5,
      "x": 921,
      "y": 1024,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 190559,
      "e": 170570,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 190560,
      "e": 170571,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 190561,
      "e": 170572,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 191899,
      "e": 171910,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 192595,
      "e": 172606,
      "ty": 2,
      "x": 836,
      "y": 964
    },
    {
      "t": 192695,
      "e": 172706,
      "ty": 2,
      "x": 706,
      "y": 656
    },
    {
      "t": 192744,
      "e": 172755,
      "ty": 41,
      "x": 15966,
      "y": 23996,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 192794,
      "e": 172805,
      "ty": 2,
      "x": 591,
      "y": 492
    },
    {
      "t": 192894,
      "e": 172905,
      "ty": 2,
      "x": 431,
      "y": 363
    },
    {
      "t": 192994,
      "e": 173005,
      "ty": 2,
      "x": 343,
      "y": 338
    },
    {
      "t": 192995,
      "e": 173006,
      "ty": 41,
      "x": 2437,
      "y": 8228,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 193094,
      "e": 173105,
      "ty": 2,
      "x": 303,
      "y": 333
    },
    {
      "t": 193195,
      "e": 173206,
      "ty": 2,
      "x": 302,
      "y": 333
    },
    {
      "t": 193244,
      "e": 173255,
      "ty": 41,
      "x": 125,
      "y": 14382,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 193294,
      "e": 173305,
      "ty": 2,
      "x": 289,
      "y": 335
    },
    {
      "t": 193394,
      "e": 173405,
      "ty": 2,
      "x": 281,
      "y": 336
    },
    {
      "t": 193494,
      "e": 173505,
      "ty": 2,
      "x": 264,
      "y": 339
    },
    {
      "t": 193495,
      "e": 173506,
      "ty": 41,
      "x": 8816,
      "y": 18336,
      "ta": "> div.masterdiv"
    },
    {
      "t": 193594,
      "e": 173605,
      "ty": 2,
      "x": 252,
      "y": 343
    },
    {
      "t": 193694,
      "e": 173705,
      "ty": 2,
      "x": 251,
      "y": 343
    },
    {
      "t": 193744,
      "e": 173755,
      "ty": 41,
      "x": 8196,
      "y": 18558,
      "ta": "> div.masterdiv"
    },
    {
      "t": 193795,
      "e": 173806,
      "ty": 2,
      "x": 241,
      "y": 344
    },
    {
      "t": 193895,
      "e": 173906,
      "ty": 2,
      "x": 234,
      "y": 347
    },
    {
      "t": 193995,
      "e": 174006,
      "ty": 41,
      "x": 7782,
      "y": 18779,
      "ta": "> div.masterdiv"
    },
    {
      "t": 199994,
      "e": 179006,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 289403,
      "e": 179006,
      "ty": 2,
      "x": 233,
      "y": 347
    },
    {
      "t": 289503,
      "e": 179106,
      "ty": 2,
      "x": 381,
      "y": 572
    },
    {
      "t": 289504,
      "e": 179107,
      "ty": 41,
      "x": 4307,
      "y": 34919,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 289603,
      "e": 179206,
      "ty": 2,
      "x": 782,
      "y": 890
    },
    {
      "t": 289703,
      "e": 179306,
      "ty": 2,
      "x": 857,
      "y": 933
    },
    {
      "t": 289753,
      "e": 179356,
      "ty": 41,
      "x": 28167,
      "y": 56069,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 289803,
      "e": 179406,
      "ty": 2,
      "x": 874,
      "y": 946
    },
    {
      "t": 289903,
      "e": 179506,
      "ty": 2,
      "x": 879,
      "y": 953
    },
    {
      "t": 290005,
      "e": 179608,
      "ty": 2,
      "x": 943,
      "y": 939
    },
    {
      "t": 290005,
      "e": 179608,
      "ty": 41,
      "x": 31955,
      "y": 56277,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 290103,
      "e": 179706,
      "ty": 2,
      "x": 1051,
      "y": 933
    },
    {
      "t": 290203,
      "e": 179806,
      "ty": 2,
      "x": 1062,
      "y": 933
    },
    {
      "t": 290255,
      "e": 179858,
      "ty": 41,
      "x": 37957,
      "y": 55862,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 290303,
      "e": 179906,
      "ty": 2,
      "x": 1066,
      "y": 958
    },
    {
      "t": 290404,
      "e": 180007,
      "ty": 2,
      "x": 1035,
      "y": 1009
    },
    {
      "t": 290503,
      "e": 180106,
      "ty": 2,
      "x": 1001,
      "y": 1052
    },
    {
      "t": 290503,
      "e": 180106,
      "ty": 41,
      "x": 34809,
      "y": 64102,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 290569,
      "e": 180172,
      "ty": 6,
      "x": 992,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 290603,
      "e": 180206,
      "ty": 2,
      "x": 992,
      "y": 1077
    },
    {
      "t": 290703,
      "e": 180306,
      "ty": 2,
      "x": 992,
      "y": 1079
    },
    {
      "t": 290753,
      "e": 180356,
      "ty": 41,
      "x": 45055,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 290804,
      "e": 180407,
      "ty": 2,
      "x": 991,
      "y": 1083
    },
    {
      "t": 290936,
      "e": 180539,
      "ty": 3,
      "x": 991,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 290936,
      "e": 180539,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 291004,
      "e": 180607,
      "ty": 41,
      "x": 44509,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 291020,
      "e": 180623,
      "ty": 4,
      "x": 44509,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 291021,
      "e": 180624,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 291022,
      "e": 180625,
      "ty": 5,
      "x": 991,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 291022,
      "e": 180625,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 291704,
      "e": 181307,
      "ty": 2,
      "x": 1050,
      "y": 978
    },
    {
      "t": 291753,
      "e": 181356,
      "ty": 41,
      "x": 36503,
      "y": 47974,
      "ta": "html > body"
    },
    {
      "t": 291803,
      "e": 181406,
      "ty": 2,
      "x": 1070,
      "y": 821
    },
    {
      "t": 291903,
      "e": 181506,
      "ty": 2,
      "x": 1053,
      "y": 718
    },
    {
      "t": 292003,
      "e": 181606,
      "ty": 2,
      "x": 1043,
      "y": 678
    },
    {
      "t": 292003,
      "e": 181606,
      "ty": 41,
      "x": 35643,
      "y": 37116,
      "ta": "html > body"
    },
    {
      "t": 292061,
      "e": 181664,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 292881,
      "e": 182484,
      "ty": 2,
      "x": 1076,
      "y": 613
    },
    {
      "t": 292881,
      "e": 182484,
      "ty": 41,
      "x": 37359,
      "y": 32770,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 292942,
      "e": 182545,
      "ty": 2,
      "x": 1088,
      "y": 566
    },
    {
      "t": 293003,
      "e": 182606,
      "ty": 2,
      "x": 1091,
      "y": 552
    },
    {
      "t": 293003,
      "e": 182606,
      "ty": 41,
      "x": 37951,
      "y": 32756,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 293103,
      "e": 182706,
      "ty": 2,
      "x": 1106,
      "y": 531
    },
    {
      "t": 293203,
      "e": 182806,
      "ty": 2,
      "x": 1114,
      "y": 522
    },
    {
      "t": 293253,
      "e": 182856,
      "ty": 41,
      "x": 38897,
      "y": 32749,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 293303,
      "e": 182906,
      "ty": 2,
      "x": 1115,
      "y": 518
    },
    {
      "t": 293789,
      "e": 183392,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 195088, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 195095, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 3761, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 200197, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 11665, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"juliet\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 212869, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 30679, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 244631, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 30138, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 275772, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 62663, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 340035, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -10 AM-11 AM-11 AM-11 AM-F -U -F -F -F -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:291,y:440,t:1527030374964};\\\", \\\"{x:291,y:443,t:1527030374971};\\\", \\\"{x:291,y:446,t:1527030374989};\\\", \\\"{x:291,y:448,t:1527030375005};\\\", \\\"{x:291,y:449,t:1527030375021};\\\", \\\"{x:291,y:448,t:1527030375826};\\\", \\\"{x:291,y:446,t:1527030375839};\\\", \\\"{x:291,y:443,t:1527030375856};\\\", \\\"{x:289,y:439,t:1527030375872};\\\", \\\"{x:288,y:435,t:1527030375889};\\\", \\\"{x:285,y:430,t:1527030375906};\\\", \\\"{x:285,y:427,t:1527030375923};\\\", \\\"{x:285,y:423,t:1527030375939};\\\", \\\"{x:284,y:420,t:1527030375956};\\\", \\\"{x:283,y:418,t:1527030375973};\\\", \\\"{x:281,y:414,t:1527030375990};\\\", \\\"{x:280,y:412,t:1527030376005};\\\", \\\"{x:279,y:410,t:1527030376022};\\\", \\\"{x:277,y:407,t:1527030376039};\\\", \\\"{x:276,y:405,t:1527030376056};\\\", \\\"{x:275,y:403,t:1527030376073};\\\", \\\"{x:275,y:402,t:1527030376090};\\\", \\\"{x:275,y:401,t:1527030376106};\\\", \\\"{x:274,y:399,t:1527030376122};\\\", \\\"{x:274,y:398,t:1527030376186};\\\", \\\"{x:274,y:397,t:1527030376266};\\\", \\\"{x:274,y:396,t:1527030376314};\\\", \\\"{x:274,y:395,t:1527030376331};\\\", \\\"{x:274,y:394,t:1527030376363};\\\", \\\"{x:274,y:393,t:1527030376402};\\\", \\\"{x:274,y:391,t:1527030376410};\\\", \\\"{x:275,y:391,t:1527030376423};\\\", \\\"{x:276,y:390,t:1527030376439};\\\", \\\"{x:277,y:388,t:1527030376456};\\\", \\\"{x:278,y:387,t:1527030385621};\\\", \\\"{x:285,y:387,t:1527030385632};\\\", \\\"{x:299,y:396,t:1527030385649};\\\", \\\"{x:311,y:402,t:1527030385666};\\\", \\\"{x:317,y:406,t:1527030385683};\\\", \\\"{x:320,y:408,t:1527030385699};\\\", \\\"{x:322,y:410,t:1527030385716};\\\", \\\"{x:328,y:413,t:1527030385733};\\\", \\\"{x:336,y:418,t:1527030385749};\\\", \\\"{x:343,y:421,t:1527030385766};\\\", \\\"{x:355,y:426,t:1527030385783};\\\", \\\"{x:365,y:431,t:1527030385800};\\\", \\\"{x:374,y:436,t:1527030385816};\\\", \\\"{x:381,y:440,t:1527030385834};\\\", \\\"{x:391,y:446,t:1527030385849};\\\", \\\"{x:401,y:450,t:1527030385866};\\\", \\\"{x:417,y:455,t:1527030385883};\\\", \\\"{x:441,y:461,t:1527030385899};\\\", \\\"{x:472,y:474,t:1527030385916};\\\", \\\"{x:532,y:503,t:1527030385933};\\\", \\\"{x:570,y:525,t:1527030385950};\\\", \\\"{x:590,y:538,t:1527030385966};\\\", \\\"{x:612,y:553,t:1527030385983};\\\", \\\"{x:643,y:574,t:1527030386000};\\\", \\\"{x:681,y:605,t:1527030386017};\\\", \\\"{x:726,y:635,t:1527030386035};\\\", \\\"{x:776,y:659,t:1527030386050};\\\", \\\"{x:805,y:673,t:1527030386067};\\\", \\\"{x:823,y:686,t:1527030386084};\\\", \\\"{x:837,y:695,t:1527030386102};\\\", \\\"{x:853,y:704,t:1527030386119};\\\", \\\"{x:879,y:710,t:1527030386134};\\\", \\\"{x:906,y:715,t:1527030386152};\\\", \\\"{x:930,y:719,t:1527030386169};\\\", \\\"{x:941,y:721,t:1527030386184};\\\", \\\"{x:949,y:725,t:1527030386201};\\\", \\\"{x:960,y:729,t:1527030386219};\\\", \\\"{x:973,y:733,t:1527030386236};\\\", \\\"{x:992,y:741,t:1527030386252};\\\", \\\"{x:1037,y:749,t:1527030386269};\\\", \\\"{x:1072,y:755,t:1527030386286};\\\", \\\"{x:1102,y:764,t:1527030386302};\\\", \\\"{x:1118,y:767,t:1527030386319};\\\", \\\"{x:1123,y:769,t:1527030386336};\\\", \\\"{x:1127,y:771,t:1527030386354};\\\", \\\"{x:1133,y:775,t:1527030386369};\\\", \\\"{x:1146,y:784,t:1527030386386};\\\", \\\"{x:1168,y:797,t:1527030386403};\\\", \\\"{x:1194,y:806,t:1527030386420};\\\", \\\"{x:1214,y:815,t:1527030386436};\\\", \\\"{x:1225,y:819,t:1527030386454};\\\", \\\"{x:1226,y:819,t:1527030386509};\\\", \\\"{x:1230,y:822,t:1527030386520};\\\", \\\"{x:1244,y:828,t:1527030386537};\\\", \\\"{x:1257,y:833,t:1527030386554};\\\", \\\"{x:1268,y:836,t:1527030386570};\\\", \\\"{x:1270,y:836,t:1527030386587};\\\", \\\"{x:1271,y:836,t:1527030386662};\\\", \\\"{x:1272,y:836,t:1527030386677};\\\", \\\"{x:1273,y:836,t:1527030386701};\\\", \\\"{x:1274,y:836,t:1527030386814};\\\", \\\"{x:1275,y:836,t:1527030386854};\\\", \\\"{x:1276,y:835,t:1527030386871};\\\", \\\"{x:1277,y:835,t:1527030386966};\\\", \\\"{x:1278,y:835,t:1527030387005};\\\", \\\"{x:1277,y:836,t:1527030387470};\\\", \\\"{x:1276,y:839,t:1527030387477};\\\", \\\"{x:1275,y:841,t:1527030387490};\\\", \\\"{x:1273,y:844,t:1527030387507};\\\", \\\"{x:1270,y:850,t:1527030387523};\\\", \\\"{x:1264,y:860,t:1527030387540};\\\", \\\"{x:1254,y:876,t:1527030387557};\\\", \\\"{x:1250,y:885,t:1527030387573};\\\", \\\"{x:1247,y:893,t:1527030387590};\\\", \\\"{x:1245,y:898,t:1527030387607};\\\", \\\"{x:1243,y:903,t:1527030387624};\\\", \\\"{x:1242,y:909,t:1527030387641};\\\", \\\"{x:1239,y:917,t:1527030387657};\\\", \\\"{x:1237,y:925,t:1527030387673};\\\", \\\"{x:1237,y:931,t:1527030387691};\\\", \\\"{x:1235,y:938,t:1527030387706};\\\", \\\"{x:1234,y:943,t:1527030387723};\\\", \\\"{x:1233,y:947,t:1527030387741};\\\", \\\"{x:1233,y:950,t:1527030387756};\\\", \\\"{x:1231,y:954,t:1527030387774};\\\", \\\"{x:1229,y:959,t:1527030387791};\\\", \\\"{x:1225,y:964,t:1527030387807};\\\", \\\"{x:1223,y:967,t:1527030387824};\\\", \\\"{x:1223,y:973,t:1527030387841};\\\", \\\"{x:1221,y:974,t:1527030387858};\\\", \\\"{x:1220,y:974,t:1527030387873};\\\", \\\"{x:1219,y:974,t:1527030387890};\\\", \\\"{x:1219,y:975,t:1527030388486};\\\", \\\"{x:1219,y:976,t:1527030388501};\\\", \\\"{x:1219,y:977,t:1527030388510};\\\", \\\"{x:1219,y:979,t:1527030388527};\\\", \\\"{x:1219,y:980,t:1527030388605};\\\", \\\"{x:1219,y:982,t:1527030388613};\\\", \\\"{x:1219,y:984,t:1527030388629};\\\", \\\"{x:1220,y:985,t:1527030388646};\\\", \\\"{x:1220,y:986,t:1527030388741};\\\", \\\"{x:1221,y:987,t:1527030388749};\\\", \\\"{x:1221,y:988,t:1527030388762};\\\", \\\"{x:1223,y:988,t:1527030388778};\\\", \\\"{x:1225,y:989,t:1527030388794};\\\", \\\"{x:1226,y:990,t:1527030388811};\\\", \\\"{x:1227,y:990,t:1527030388829};\\\", \\\"{x:1228,y:991,t:1527030388844};\\\", \\\"{x:1234,y:995,t:1527030388861};\\\", \\\"{x:1242,y:996,t:1527030388878};\\\", \\\"{x:1250,y:997,t:1527030388895};\\\", \\\"{x:1253,y:997,t:1527030388911};\\\", \\\"{x:1254,y:997,t:1527030388928};\\\", \\\"{x:1255,y:997,t:1527030388981};\\\", \\\"{x:1255,y:998,t:1527030388995};\\\", \\\"{x:1259,y:1000,t:1527030389012};\\\", \\\"{x:1263,y:1002,t:1527030389029};\\\", \\\"{x:1265,y:1002,t:1527030389045};\\\", \\\"{x:1265,y:998,t:1527030392269};\\\", \\\"{x:1263,y:994,t:1527030392277};\\\", \\\"{x:1262,y:992,t:1527030392289};\\\", \\\"{x:1265,y:990,t:1527030392877};\\\", \\\"{x:1266,y:989,t:1527030392891};\\\", \\\"{x:1267,y:989,t:1527030392908};\\\", \\\"{x:1269,y:989,t:1527030392941};\\\", \\\"{x:1270,y:989,t:1527030392965};\\\", \\\"{x:1272,y:989,t:1527030392981};\\\", \\\"{x:1272,y:988,t:1527030392993};\\\", \\\"{x:1273,y:988,t:1527030393038};\\\", \\\"{x:1274,y:988,t:1527030393061};\\\", \\\"{x:1276,y:985,t:1527030393925};\\\", \\\"{x:1278,y:983,t:1527030393933};\\\", \\\"{x:1280,y:980,t:1527030393945};\\\", \\\"{x:1283,y:978,t:1527030393963};\\\", \\\"{x:1285,y:975,t:1527030393978};\\\", \\\"{x:1288,y:972,t:1527030393995};\\\", \\\"{x:1291,y:970,t:1527030394012};\\\", \\\"{x:1293,y:969,t:1527030394029};\\\", \\\"{x:1294,y:969,t:1527030394044};\\\", \\\"{x:1296,y:968,t:1527030394062};\\\", \\\"{x:1297,y:968,t:1527030394079};\\\", \\\"{x:1298,y:968,t:1527030394095};\\\", \\\"{x:1299,y:968,t:1527030394112};\\\", \\\"{x:1300,y:968,t:1527030394129};\\\", \\\"{x:1301,y:968,t:1527030394277};\\\", \\\"{x:1301,y:969,t:1527030394285};\\\", \\\"{x:1301,y:971,t:1527030394301};\\\", \\\"{x:1301,y:972,t:1527030394313};\\\", \\\"{x:1301,y:976,t:1527030394331};\\\", \\\"{x:1301,y:977,t:1527030394347};\\\", \\\"{x:1301,y:978,t:1527030394363};\\\", \\\"{x:1301,y:979,t:1527030394380};\\\", \\\"{x:1301,y:980,t:1527030394485};\\\", \\\"{x:1301,y:981,t:1527030394501};\\\", \\\"{x:1298,y:981,t:1527030396741};\\\", \\\"{x:1288,y:986,t:1527030396755};\\\", \\\"{x:1272,y:995,t:1527030396772};\\\", \\\"{x:1263,y:998,t:1527030396788};\\\", \\\"{x:1263,y:999,t:1527030396806};\\\", \\\"{x:1264,y:999,t:1527030397054};\\\", \\\"{x:1264,y:997,t:1527030397061};\\\", \\\"{x:1264,y:992,t:1527030397072};\\\", \\\"{x:1264,y:970,t:1527030397090};\\\", \\\"{x:1264,y:949,t:1527030397107};\\\", \\\"{x:1266,y:933,t:1527030397123};\\\", \\\"{x:1269,y:923,t:1527030397139};\\\", \\\"{x:1273,y:911,t:1527030397157};\\\", \\\"{x:1276,y:906,t:1527030397173};\\\", \\\"{x:1277,y:902,t:1527030397190};\\\", \\\"{x:1281,y:896,t:1527030397207};\\\", \\\"{x:1282,y:891,t:1527030397223};\\\", \\\"{x:1285,y:883,t:1527030397239};\\\", \\\"{x:1291,y:874,t:1527030397256};\\\", \\\"{x:1294,y:869,t:1527030397273};\\\", \\\"{x:1297,y:862,t:1527030397291};\\\", \\\"{x:1300,y:858,t:1527030397307};\\\", \\\"{x:1305,y:852,t:1527030397324};\\\", \\\"{x:1312,y:843,t:1527030397341};\\\", \\\"{x:1318,y:835,t:1527030397357};\\\", \\\"{x:1325,y:827,t:1527030397373};\\\", \\\"{x:1327,y:826,t:1527030397390};\\\", \\\"{x:1329,y:824,t:1527030397408};\\\", \\\"{x:1331,y:822,t:1527030397424};\\\", \\\"{x:1333,y:821,t:1527030397441};\\\", \\\"{x:1335,y:819,t:1527030397458};\\\", \\\"{x:1339,y:814,t:1527030397475};\\\", \\\"{x:1344,y:806,t:1527030397490};\\\", \\\"{x:1350,y:798,t:1527030397508};\\\", \\\"{x:1356,y:791,t:1527030397524};\\\", \\\"{x:1359,y:789,t:1527030397541};\\\", \\\"{x:1360,y:787,t:1527030397558};\\\", \\\"{x:1362,y:786,t:1527030397581};\\\", \\\"{x:1363,y:785,t:1527030397592};\\\", \\\"{x:1365,y:782,t:1527030397608};\\\", \\\"{x:1371,y:773,t:1527030397625};\\\", \\\"{x:1379,y:764,t:1527030397645};\\\", \\\"{x:1391,y:753,t:1527030397659};\\\", \\\"{x:1398,y:748,t:1527030397674};\\\", \\\"{x:1400,y:746,t:1527030397691};\\\", \\\"{x:1399,y:746,t:1527030398062};\\\", \\\"{x:1399,y:747,t:1527030398085};\\\", \\\"{x:1399,y:748,t:1527030398125};\\\", \\\"{x:1399,y:749,t:1527030398140};\\\", \\\"{x:1398,y:749,t:1527030398149};\\\", \\\"{x:1397,y:751,t:1527030398165};\\\", \\\"{x:1396,y:751,t:1527030398439};\\\", \\\"{x:1395,y:751,t:1527030398445};\\\", \\\"{x:1395,y:752,t:1527030398461};\\\", \\\"{x:1394,y:753,t:1527030398477};\\\", \\\"{x:1393,y:753,t:1527030398525};\\\", \\\"{x:1391,y:754,t:1527030398549};\\\", \\\"{x:1390,y:755,t:1527030398572};\\\", \\\"{x:1388,y:755,t:1527030398645};\\\", \\\"{x:1388,y:756,t:1527030403413};\\\", \\\"{x:1386,y:756,t:1527030403428};\\\", \\\"{x:1386,y:757,t:1527030403445};\\\", \\\"{x:1386,y:754,t:1527030403517};\\\", \\\"{x:1386,y:752,t:1527030403527};\\\", \\\"{x:1386,y:743,t:1527030403545};\\\", \\\"{x:1388,y:724,t:1527030403562};\\\", \\\"{x:1399,y:695,t:1527030403579};\\\", \\\"{x:1412,y:669,t:1527030403595};\\\", \\\"{x:1422,y:647,t:1527030403611};\\\", \\\"{x:1433,y:626,t:1527030403629};\\\", \\\"{x:1438,y:615,t:1527030403645};\\\", \\\"{x:1444,y:601,t:1527030403662};\\\", \\\"{x:1450,y:585,t:1527030403678};\\\", \\\"{x:1457,y:569,t:1527030403696};\\\", \\\"{x:1462,y:558,t:1527030403712};\\\", \\\"{x:1463,y:551,t:1527030403729};\\\", \\\"{x:1463,y:550,t:1527030403790};\\\", \\\"{x:1455,y:550,t:1527030403797};\\\", \\\"{x:1427,y:550,t:1527030403812};\\\", \\\"{x:1363,y:550,t:1527030403829};\\\", \\\"{x:1254,y:565,t:1527030403846};\\\", \\\"{x:1119,y:584,t:1527030403863};\\\", \\\"{x:982,y:610,t:1527030403880};\\\", \\\"{x:864,y:637,t:1527030403896};\\\", \\\"{x:779,y:658,t:1527030403912};\\\", \\\"{x:731,y:665,t:1527030403930};\\\", \\\"{x:711,y:668,t:1527030403947};\\\", \\\"{x:703,y:670,t:1527030403963};\\\", \\\"{x:701,y:670,t:1527030403980};\\\", \\\"{x:698,y:671,t:1527030403997};\\\", \\\"{x:695,y:671,t:1527030404012};\\\", \\\"{x:691,y:671,t:1527030404030};\\\", \\\"{x:689,y:671,t:1527030404047};\\\", \\\"{x:688,y:671,t:1527030404064};\\\", \\\"{x:687,y:670,t:1527030404080};\\\", \\\"{x:685,y:670,t:1527030404096};\\\", \\\"{x:684,y:670,t:1527030404117};\\\", \\\"{x:681,y:669,t:1527030404141};\\\", \\\"{x:681,y:668,t:1527030404149};\\\", \\\"{x:678,y:666,t:1527030404164};\\\", \\\"{x:668,y:660,t:1527030404181};\\\", \\\"{x:656,y:656,t:1527030404196};\\\", \\\"{x:643,y:652,t:1527030404213};\\\", \\\"{x:629,y:650,t:1527030404232};\\\", \\\"{x:612,y:647,t:1527030404247};\\\", \\\"{x:597,y:643,t:1527030404263};\\\", \\\"{x:578,y:641,t:1527030404275};\\\", \\\"{x:563,y:640,t:1527030404292};\\\", \\\"{x:546,y:640,t:1527030404309};\\\", \\\"{x:528,y:637,t:1527030404326};\\\", \\\"{x:513,y:636,t:1527030404343};\\\", \\\"{x:498,y:636,t:1527030404360};\\\", \\\"{x:480,y:634,t:1527030404376};\\\", \\\"{x:453,y:630,t:1527030404399};\\\", \\\"{x:435,y:627,t:1527030404416};\\\", \\\"{x:418,y:625,t:1527030404433};\\\", \\\"{x:402,y:622,t:1527030404449};\\\", \\\"{x:394,y:621,t:1527030404466};\\\", \\\"{x:389,y:620,t:1527030404482};\\\", \\\"{x:384,y:619,t:1527030404500};\\\", \\\"{x:376,y:615,t:1527030404516};\\\", \\\"{x:366,y:612,t:1527030404533};\\\", \\\"{x:355,y:608,t:1527030404549};\\\", \\\"{x:352,y:608,t:1527030404566};\\\", \\\"{x:350,y:608,t:1527030404677};\\\", \\\"{x:347,y:607,t:1527030404684};\\\", \\\"{x:344,y:607,t:1527030404699};\\\", \\\"{x:332,y:606,t:1527030404716};\\\", \\\"{x:323,y:606,t:1527030404733};\\\", \\\"{x:318,y:606,t:1527030404749};\\\", \\\"{x:315,y:606,t:1527030404767};\\\", \\\"{x:311,y:606,t:1527030404784};\\\", \\\"{x:305,y:606,t:1527030404800};\\\", \\\"{x:293,y:606,t:1527030404817};\\\", \\\"{x:286,y:604,t:1527030404834};\\\", \\\"{x:284,y:604,t:1527030404850};\\\", \\\"{x:284,y:603,t:1527030404877};\\\", \\\"{x:285,y:601,t:1527030404885};\\\", \\\"{x:289,y:599,t:1527030404900};\\\", \\\"{x:311,y:593,t:1527030404917};\\\", \\\"{x:328,y:589,t:1527030404934};\\\", \\\"{x:348,y:585,t:1527030404950};\\\", \\\"{x:365,y:582,t:1527030404967};\\\", \\\"{x:373,y:579,t:1527030404984};\\\", \\\"{x:375,y:578,t:1527030405000};\\\", \\\"{x:376,y:577,t:1527030405052};\\\", \\\"{x:376,y:576,t:1527030405067};\\\", \\\"{x:379,y:574,t:1527030405084};\\\", \\\"{x:381,y:572,t:1527030405099};\\\", \\\"{x:382,y:570,t:1527030405117};\\\", \\\"{x:382,y:569,t:1527030405133};\\\", \\\"{x:383,y:567,t:1527030405150};\\\", \\\"{x:383,y:566,t:1527030405166};\\\", \\\"{x:384,y:566,t:1527030405183};\\\", \\\"{x:385,y:565,t:1527030405201};\\\", \\\"{x:386,y:564,t:1527030405217};\\\", \\\"{x:386,y:563,t:1527030405917};\\\", \\\"{x:397,y:563,t:1527030405934};\\\", \\\"{x:421,y:562,t:1527030405952};\\\", \\\"{x:447,y:562,t:1527030405967};\\\", \\\"{x:469,y:562,t:1527030405984};\\\", \\\"{x:489,y:562,t:1527030406000};\\\", \\\"{x:503,y:562,t:1527030406018};\\\", \\\"{x:511,y:562,t:1527030406034};\\\", \\\"{x:519,y:562,t:1527030406050};\\\", \\\"{x:527,y:562,t:1527030406068};\\\", \\\"{x:545,y:562,t:1527030406084};\\\", \\\"{x:562,y:562,t:1527030406100};\\\", \\\"{x:581,y:562,t:1527030406117};\\\", \\\"{x:595,y:562,t:1527030406134};\\\", \\\"{x:602,y:562,t:1527030406150};\\\", \\\"{x:606,y:562,t:1527030406167};\\\", \\\"{x:607,y:562,t:1527030406184};\\\", \\\"{x:612,y:562,t:1527030406201};\\\", \\\"{x:617,y:562,t:1527030406218};\\\", \\\"{x:623,y:560,t:1527030406235};\\\", \\\"{x:635,y:559,t:1527030406252};\\\", \\\"{x:646,y:558,t:1527030406268};\\\", \\\"{x:663,y:555,t:1527030406284};\\\", \\\"{x:674,y:554,t:1527030406301};\\\", \\\"{x:681,y:553,t:1527030406317};\\\", \\\"{x:683,y:553,t:1527030406334};\\\", \\\"{x:677,y:553,t:1527030406420};\\\", \\\"{x:670,y:552,t:1527030406434};\\\", \\\"{x:648,y:550,t:1527030406451};\\\", \\\"{x:622,y:548,t:1527030406468};\\\", \\\"{x:600,y:548,t:1527030406484};\\\", \\\"{x:594,y:548,t:1527030406501};\\\", \\\"{x:587,y:548,t:1527030406517};\\\", \\\"{x:569,y:548,t:1527030406534};\\\", \\\"{x:546,y:547,t:1527030406551};\\\", \\\"{x:521,y:547,t:1527030406568};\\\", \\\"{x:506,y:547,t:1527030406584};\\\", \\\"{x:500,y:547,t:1527030406601};\\\", \\\"{x:496,y:547,t:1527030406619};\\\", \\\"{x:496,y:546,t:1527030406693};\\\", \\\"{x:496,y:545,t:1527030406709};\\\", \\\"{x:498,y:544,t:1527030406718};\\\", \\\"{x:511,y:544,t:1527030406736};\\\", \\\"{x:525,y:544,t:1527030406751};\\\", \\\"{x:540,y:544,t:1527030406768};\\\", \\\"{x:551,y:544,t:1527030406785};\\\", \\\"{x:559,y:544,t:1527030406801};\\\", \\\"{x:564,y:544,t:1527030406818};\\\", \\\"{x:569,y:544,t:1527030406834};\\\", \\\"{x:573,y:544,t:1527030406851};\\\", \\\"{x:583,y:544,t:1527030406868};\\\", \\\"{x:591,y:544,t:1527030406884};\\\", \\\"{x:602,y:544,t:1527030406901};\\\", \\\"{x:612,y:544,t:1527030406918};\\\", \\\"{x:622,y:544,t:1527030406935};\\\", \\\"{x:632,y:544,t:1527030406952};\\\", \\\"{x:640,y:544,t:1527030406969};\\\", \\\"{x:649,y:544,t:1527030406985};\\\", \\\"{x:656,y:544,t:1527030407001};\\\", \\\"{x:663,y:544,t:1527030407019};\\\", \\\"{x:672,y:544,t:1527030407036};\\\", \\\"{x:687,y:546,t:1527030407052};\\\", \\\"{x:717,y:550,t:1527030407069};\\\", \\\"{x:735,y:553,t:1527030407087};\\\", \\\"{x:747,y:554,t:1527030407101};\\\", \\\"{x:754,y:557,t:1527030407118};\\\", \\\"{x:757,y:558,t:1527030407135};\\\", \\\"{x:760,y:561,t:1527030407151};\\\", \\\"{x:764,y:566,t:1527030407168};\\\", \\\"{x:772,y:572,t:1527030407184};\\\", \\\"{x:779,y:579,t:1527030407202};\\\", \\\"{x:786,y:586,t:1527030407218};\\\", \\\"{x:791,y:590,t:1527030407235};\\\", \\\"{x:793,y:591,t:1527030407251};\\\", \\\"{x:793,y:593,t:1527030407267};\\\", \\\"{x:795,y:595,t:1527030407292};\\\", \\\"{x:796,y:595,t:1527030407302};\\\", \\\"{x:799,y:597,t:1527030407318};\\\", \\\"{x:803,y:597,t:1527030407336};\\\", \\\"{x:806,y:598,t:1527030407351};\\\", \\\"{x:810,y:599,t:1527030407369};\\\", \\\"{x:813,y:600,t:1527030407385};\\\", \\\"{x:817,y:601,t:1527030407403};\\\", \\\"{x:820,y:601,t:1527030407419};\\\", \\\"{x:823,y:601,t:1527030407436};\\\", \\\"{x:828,y:601,t:1527030407452};\\\", \\\"{x:831,y:601,t:1527030407468};\\\", \\\"{x:835,y:601,t:1527030407486};\\\", \\\"{x:837,y:601,t:1527030407502};\\\", \\\"{x:838,y:601,t:1527030407519};\\\", \\\"{x:840,y:601,t:1527030407536};\\\", \\\"{x:841,y:606,t:1527030407940};\\\", \\\"{x:847,y:614,t:1527030407954};\\\", \\\"{x:856,y:630,t:1527030407970};\\\", \\\"{x:872,y:648,t:1527030407986};\\\", \\\"{x:888,y:666,t:1527030408002};\\\", \\\"{x:899,y:681,t:1527030408020};\\\", \\\"{x:906,y:690,t:1527030408036};\\\", \\\"{x:911,y:694,t:1527030408052};\\\", \\\"{x:911,y:695,t:1527030408109};\\\", \\\"{x:911,y:696,t:1527030408148};\\\", \\\"{x:911,y:697,t:1527030408180};\\\", \\\"{x:911,y:698,t:1527030408397};\\\", \\\"{x:909,y:698,t:1527030408404};\\\", \\\"{x:902,y:698,t:1527030408420};\\\", \\\"{x:870,y:704,t:1527030408436};\\\", \\\"{x:767,y:704,t:1527030408452};\\\", \\\"{x:703,y:704,t:1527030408470};\\\", \\\"{x:659,y:709,t:1527030408486};\\\", \\\"{x:637,y:712,t:1527030408503};\\\", \\\"{x:633,y:714,t:1527030408520};\\\", \\\"{x:631,y:715,t:1527030408537};\\\", \\\"{x:630,y:716,t:1527030408553};\\\", \\\"{x:628,y:717,t:1527030408570};\\\", \\\"{x:625,y:719,t:1527030408587};\\\", \\\"{x:624,y:719,t:1527030408603};\\\", \\\"{x:623,y:719,t:1527030408621};\\\", \\\"{x:622,y:719,t:1527030408709};\\\", \\\"{x:620,y:718,t:1527030408719};\\\", \\\"{x:618,y:718,t:1527030408749};\\\", \\\"{x:617,y:718,t:1527030408757};\\\", \\\"{x:615,y:718,t:1527030408770};\\\", \\\"{x:612,y:718,t:1527030408787};\\\", \\\"{x:607,y:718,t:1527030408803};\\\", \\\"{x:602,y:718,t:1527030408820};\\\", \\\"{x:596,y:717,t:1527030408836};\\\", \\\"{x:592,y:715,t:1527030408853};\\\", \\\"{x:587,y:713,t:1527030408870};\\\", \\\"{x:581,y:712,t:1527030408887};\\\", \\\"{x:574,y:712,t:1527030408904};\\\", \\\"{x:570,y:711,t:1527030408920};\\\", \\\"{x:569,y:711,t:1527030408937};\\\", \\\"{x:566,y:710,t:1527030408954};\\\", \\\"{x:563,y:709,t:1527030408972};\\\", \\\"{x:559,y:708,t:1527030408986};\\\", \\\"{x:554,y:706,t:1527030409003};\\\", \\\"{x:550,y:706,t:1527030409020};\\\", \\\"{x:542,y:706,t:1527030409036};\\\", \\\"{x:539,y:706,t:1527030409054};\\\", \\\"{x:536,y:706,t:1527030409069};\\\", \\\"{x:534,y:706,t:1527030409165};\\\", \\\"{x:534,y:707,t:1527030409172};\\\", \\\"{x:540,y:712,t:1527030411700};\\\", \\\"{x:596,y:724,t:1527030411709};\\\", \\\"{x:659,y:741,t:1527030411722};\\\", \\\"{x:782,y:760,t:1527030411739};\\\", \\\"{x:906,y:772,t:1527030411755};\\\", \\\"{x:1076,y:780,t:1527030411772};\\\", \\\"{x:1164,y:787,t:1527030411788};\\\", \\\"{x:1258,y:801,t:1527030411806};\\\", \\\"{x:1345,y:814,t:1527030411821};\\\", \\\"{x:1407,y:826,t:1527030411839};\\\", \\\"{x:1449,y:832,t:1527030411856};\\\", \\\"{x:1468,y:832,t:1527030411871};\\\", \\\"{x:1483,y:832,t:1527030411888};\\\", \\\"{x:1502,y:834,t:1527030411906};\\\", \\\"{x:1525,y:838,t:1527030411922};\\\", \\\"{x:1545,y:839,t:1527030411939};\\\", \\\"{x:1555,y:841,t:1527030411955};\\\", \\\"{x:1557,y:841,t:1527030411973};\\\", \\\"{x:1557,y:840,t:1527030411997};\\\", \\\"{x:1551,y:832,t:1527030412006};\\\", \\\"{x:1517,y:811,t:1527030412023};\\\", \\\"{x:1496,y:802,t:1527030412039};\\\", \\\"{x:1482,y:800,t:1527030412056};\\\", \\\"{x:1462,y:797,t:1527030412073};\\\", \\\"{x:1439,y:792,t:1527030412090};\\\", \\\"{x:1415,y:785,t:1527030412106};\\\", \\\"{x:1389,y:780,t:1527030412124};\\\", \\\"{x:1369,y:778,t:1527030412140};\\\", \\\"{x:1359,y:775,t:1527030412157};\\\", \\\"{x:1358,y:775,t:1527030412173};\\\", \\\"{x:1358,y:773,t:1527030412293};\\\", \\\"{x:1359,y:772,t:1527030412309};\\\", \\\"{x:1360,y:772,t:1527030412323};\\\", \\\"{x:1363,y:770,t:1527030412341};\\\", \\\"{x:1364,y:770,t:1527030412357};\\\", \\\"{x:1365,y:769,t:1527030412373};\\\", \\\"{x:1368,y:767,t:1527030412390};\\\", \\\"{x:1373,y:765,t:1527030412406};\\\", \\\"{x:1377,y:763,t:1527030412424};\\\", \\\"{x:1382,y:758,t:1527030412440};\\\", \\\"{x:1386,y:755,t:1527030412457};\\\", \\\"{x:1388,y:754,t:1527030412473};\\\", \\\"{x:1389,y:753,t:1527030412492};\\\", \\\"{x:1389,y:752,t:1527030412517};\\\", \\\"{x:1390,y:752,t:1527030412524};\\\", \\\"{x:1390,y:754,t:1527030412740};\\\", \\\"{x:1388,y:760,t:1527030412755};\\\", \\\"{x:1385,y:765,t:1527030412773};\\\", \\\"{x:1383,y:772,t:1527030412790};\\\", \\\"{x:1380,y:778,t:1527030412807};\\\", \\\"{x:1376,y:792,t:1527030412823};\\\", \\\"{x:1367,y:806,t:1527030412840};\\\", \\\"{x:1355,y:825,t:1527030412857};\\\", \\\"{x:1342,y:843,t:1527030412872};\\\", \\\"{x:1327,y:860,t:1527030412890};\\\", \\\"{x:1310,y:879,t:1527030412907};\\\", \\\"{x:1300,y:893,t:1527030412922};\\\", \\\"{x:1295,y:902,t:1527030412939};\\\", \\\"{x:1290,y:915,t:1527030412956};\\\", \\\"{x:1286,y:924,t:1527030412973};\\\", \\\"{x:1281,y:934,t:1527030412990};\\\", \\\"{x:1275,y:943,t:1527030413007};\\\", \\\"{x:1273,y:946,t:1527030413023};\\\", \\\"{x:1273,y:947,t:1527030413040};\\\", \\\"{x:1273,y:950,t:1527030413061};\\\", \\\"{x:1274,y:951,t:1527030413085};\\\", \\\"{x:1274,y:952,t:1527030413093};\\\", \\\"{x:1274,y:953,t:1527030413107};\\\", \\\"{x:1274,y:954,t:1527030413123};\\\", \\\"{x:1274,y:956,t:1527030413141};\\\", \\\"{x:1274,y:957,t:1527030413158};\\\", \\\"{x:1275,y:957,t:1527030413174};\\\", \\\"{x:1275,y:958,t:1527030413221};\\\", \\\"{x:1275,y:959,t:1527030413229};\\\", \\\"{x:1275,y:960,t:1527030413240};\\\", \\\"{x:1275,y:962,t:1527030413257};\\\", \\\"{x:1276,y:963,t:1527030413274};\\\", \\\"{x:1277,y:965,t:1527030413290};\\\", \\\"{x:1278,y:965,t:1527030413461};\\\", \\\"{x:1279,y:965,t:1527030413565};\\\", \\\"{x:1279,y:963,t:1527030413575};\\\", \\\"{x:1280,y:963,t:1527030413590};\\\", \\\"{x:1282,y:959,t:1527030413608};\\\", \\\"{x:1282,y:958,t:1527030413701};\\\", \\\"{x:1283,y:956,t:1527030413717};\\\", \\\"{x:1284,y:955,t:1527030414205};\\\", \\\"{x:1285,y:953,t:1527030414213};\\\", \\\"{x:1286,y:953,t:1527030414229};\\\", \\\"{x:1286,y:951,t:1527030414241};\\\", \\\"{x:1288,y:949,t:1527030414258};\\\", \\\"{x:1288,y:948,t:1527030414275};\\\", \\\"{x:1289,y:948,t:1527030414291};\\\", \\\"{x:1289,y:947,t:1527030414437};\\\", \\\"{x:1289,y:946,t:1527030414605};\\\", \\\"{x:1290,y:945,t:1527030414621};\\\", \\\"{x:1290,y:944,t:1527030414701};\\\", \\\"{x:1290,y:943,t:1527030414717};\\\", \\\"{x:1291,y:943,t:1527030414725};\\\", \\\"{x:1292,y:942,t:1527030414839};\\\", \\\"{x:1292,y:941,t:1527030414868};\\\", \\\"{x:1292,y:940,t:1527030414933};\\\", \\\"{x:1292,y:939,t:1527030415039};\\\", \\\"{x:1293,y:938,t:1527030415045};\\\", \\\"{x:1294,y:937,t:1527030415084};\\\", \\\"{x:1294,y:936,t:1527030415109};\\\", \\\"{x:1295,y:935,t:1527030415140};\\\", \\\"{x:1295,y:934,t:1527030415173};\\\", \\\"{x:1295,y:933,t:1527030415205};\\\", \\\"{x:1296,y:932,t:1527030415213};\\\", \\\"{x:1297,y:930,t:1527030415229};\\\", \\\"{x:1298,y:930,t:1527030415285};\\\", \\\"{x:1298,y:929,t:1527030415325};\\\", \\\"{x:1299,y:927,t:1527030415469};\\\", \\\"{x:1300,y:926,t:1527030415517};\\\", \\\"{x:1300,y:925,t:1527030415549};\\\", \\\"{x:1301,y:924,t:1527030415589};\\\", \\\"{x:1301,y:923,t:1527030415645};\\\", \\\"{x:1301,y:922,t:1527030415709};\\\", \\\"{x:1302,y:922,t:1527030415797};\\\", \\\"{x:1303,y:921,t:1527030415901};\\\", \\\"{x:1303,y:920,t:1527030415916};\\\", \\\"{x:1303,y:919,t:1527030416005};\\\", \\\"{x:1304,y:919,t:1527030416013};\\\", \\\"{x:1304,y:918,t:1527030416028};\\\", \\\"{x:1304,y:917,t:1527030416042};\\\", \\\"{x:1305,y:916,t:1527030416059};\\\", \\\"{x:1305,y:915,t:1527030416076};\\\", \\\"{x:1306,y:914,t:1527030416091};\\\", \\\"{x:1307,y:913,t:1527030416108};\\\", \\\"{x:1308,y:911,t:1527030416132};\\\", \\\"{x:1309,y:910,t:1527030416148};\\\", \\\"{x:1309,y:909,t:1527030416159};\\\", \\\"{x:1310,y:909,t:1527030416176};\\\", \\\"{x:1311,y:907,t:1527030416192};\\\", \\\"{x:1312,y:906,t:1527030416209};\\\", \\\"{x:1315,y:903,t:1527030416225};\\\", \\\"{x:1316,y:901,t:1527030416242};\\\", \\\"{x:1318,y:899,t:1527030416259};\\\", \\\"{x:1318,y:897,t:1527030416276};\\\", \\\"{x:1320,y:895,t:1527030416292};\\\", \\\"{x:1321,y:892,t:1527030416309};\\\", \\\"{x:1323,y:887,t:1527030416327};\\\", \\\"{x:1324,y:883,t:1527030416343};\\\", \\\"{x:1325,y:879,t:1527030416359};\\\", \\\"{x:1327,y:874,t:1527030416376};\\\", \\\"{x:1329,y:870,t:1527030416393};\\\", \\\"{x:1331,y:866,t:1527030416409};\\\", \\\"{x:1332,y:864,t:1527030416427};\\\", \\\"{x:1334,y:860,t:1527030416443};\\\", \\\"{x:1334,y:858,t:1527030416460};\\\", \\\"{x:1336,y:850,t:1527030416477};\\\", \\\"{x:1338,y:845,t:1527030416492};\\\", \\\"{x:1339,y:841,t:1527030416510};\\\", \\\"{x:1340,y:838,t:1527030416527};\\\", \\\"{x:1341,y:834,t:1527030416544};\\\", \\\"{x:1343,y:828,t:1527030416560};\\\", \\\"{x:1345,y:823,t:1527030416577};\\\", \\\"{x:1347,y:818,t:1527030416593};\\\", \\\"{x:1350,y:813,t:1527030416609};\\\", \\\"{x:1350,y:811,t:1527030416627};\\\", \\\"{x:1351,y:808,t:1527030416643};\\\", \\\"{x:1353,y:801,t:1527030416659};\\\", \\\"{x:1357,y:792,t:1527030416676};\\\", \\\"{x:1361,y:785,t:1527030416693};\\\", \\\"{x:1362,y:781,t:1527030416710};\\\", \\\"{x:1363,y:780,t:1527030416726};\\\", \\\"{x:1364,y:778,t:1527030416744};\\\", \\\"{x:1365,y:777,t:1527030416760};\\\", \\\"{x:1366,y:776,t:1527030416776};\\\", \\\"{x:1368,y:775,t:1527030416793};\\\", \\\"{x:1372,y:770,t:1527030416811};\\\", \\\"{x:1374,y:768,t:1527030416826};\\\", \\\"{x:1376,y:766,t:1527030416844};\\\", \\\"{x:1376,y:765,t:1527030416860};\\\", \\\"{x:1377,y:765,t:1527030416876};\\\", \\\"{x:1378,y:765,t:1527030416900};\\\", \\\"{x:1378,y:764,t:1527030416933};\\\", \\\"{x:1379,y:764,t:1527030416948};\\\", \\\"{x:1381,y:763,t:1527030418517};\\\", \\\"{x:1382,y:762,t:1527030418528};\\\", \\\"{x:1383,y:762,t:1527030418548};\\\", \\\"{x:1384,y:762,t:1527030418562};\\\", \\\"{x:1385,y:762,t:1527030418637};\\\", \\\"{x:1385,y:761,t:1527030418652};\\\", \\\"{x:1386,y:760,t:1527030418676};\\\", \\\"{x:1387,y:760,t:1527030418694};\\\", \\\"{x:1388,y:760,t:1527030418712};\\\", \\\"{x:1389,y:759,t:1527030418765};\\\", \\\"{x:1389,y:758,t:1527030418779};\\\", \\\"{x:1389,y:751,t:1527030418794};\\\", \\\"{x:1392,y:745,t:1527030418811};\\\", \\\"{x:1399,y:734,t:1527030418829};\\\", \\\"{x:1406,y:719,t:1527030418844};\\\", \\\"{x:1415,y:696,t:1527030418861};\\\", \\\"{x:1425,y:669,t:1527030418878};\\\", \\\"{x:1428,y:651,t:1527030418894};\\\", \\\"{x:1430,y:632,t:1527030418911};\\\", \\\"{x:1438,y:616,t:1527030418928};\\\", \\\"{x:1445,y:601,t:1527030418945};\\\", \\\"{x:1455,y:589,t:1527030418961};\\\", \\\"{x:1465,y:575,t:1527030418978};\\\", \\\"{x:1476,y:560,t:1527030418995};\\\", \\\"{x:1483,y:548,t:1527030419011};\\\", \\\"{x:1490,y:528,t:1527030419029};\\\", \\\"{x:1496,y:518,t:1527030419045};\\\", \\\"{x:1502,y:508,t:1527030419061};\\\", \\\"{x:1509,y:500,t:1527030419078};\\\", \\\"{x:1522,y:490,t:1527030419096};\\\", \\\"{x:1537,y:482,t:1527030419111};\\\", \\\"{x:1545,y:475,t:1527030419128};\\\", \\\"{x:1551,y:469,t:1527030419145};\\\", \\\"{x:1555,y:464,t:1527030419161};\\\", \\\"{x:1560,y:456,t:1527030419179};\\\", \\\"{x:1562,y:450,t:1527030419195};\\\", \\\"{x:1562,y:448,t:1527030419211};\\\", \\\"{x:1562,y:447,t:1527030419229};\\\", \\\"{x:1554,y:447,t:1527030419268};\\\", \\\"{x:1542,y:452,t:1527030419279};\\\", \\\"{x:1487,y:473,t:1527030419295};\\\", \\\"{x:1387,y:503,t:1527030419312};\\\", \\\"{x:1246,y:546,t:1527030419329};\\\", \\\"{x:1100,y:583,t:1527030419345};\\\", \\\"{x:962,y:622,t:1527030419361};\\\", \\\"{x:864,y:652,t:1527030419378};\\\", \\\"{x:805,y:674,t:1527030419395};\\\", \\\"{x:758,y:696,t:1527030419412};\\\", \\\"{x:734,y:706,t:1527030419428};\\\", \\\"{x:714,y:715,t:1527030419445};\\\", \\\"{x:701,y:724,t:1527030419462};\\\", \\\"{x:692,y:729,t:1527030419478};\\\", \\\"{x:689,y:731,t:1527030419496};\\\", \\\"{x:687,y:733,t:1527030419512};\\\", \\\"{x:686,y:733,t:1527030419528};\\\", \\\"{x:688,y:733,t:1527030419572};\\\", \\\"{x:699,y:721,t:1527030419581};\\\", \\\"{x:713,y:706,t:1527030419595};\\\", \\\"{x:748,y:677,t:1527030419612};\\\", \\\"{x:768,y:661,t:1527030419629};\\\", \\\"{x:778,y:651,t:1527030419645};\\\", \\\"{x:787,y:643,t:1527030419662};\\\", \\\"{x:805,y:632,t:1527030419679};\\\", \\\"{x:812,y:629,t:1527030419695};\\\", \\\"{x:816,y:626,t:1527030419713};\\\", \\\"{x:816,y:624,t:1527030419728};\\\", \\\"{x:816,y:623,t:1527030419745};\\\", \\\"{x:818,y:621,t:1527030419763};\\\", \\\"{x:819,y:618,t:1527030419829};\\\", \\\"{x:828,y:604,t:1527030419847};\\\", \\\"{x:839,y:589,t:1527030419862};\\\", \\\"{x:847,y:574,t:1527030419879};\\\", \\\"{x:851,y:567,t:1527030419895};\\\", \\\"{x:852,y:566,t:1527030419911};\\\", \\\"{x:852,y:565,t:1527030420028};\\\", \\\"{x:850,y:566,t:1527030420035};\\\", \\\"{x:849,y:567,t:1527030420045};\\\", \\\"{x:845,y:572,t:1527030420062};\\\", \\\"{x:841,y:576,t:1527030420080};\\\", \\\"{x:837,y:581,t:1527030420095};\\\", \\\"{x:834,y:586,t:1527030420112};\\\", \\\"{x:834,y:588,t:1527030420129};\\\", \\\"{x:834,y:589,t:1527030420148};\\\", \\\"{x:834,y:591,t:1527030420163};\\\", \\\"{x:834,y:592,t:1527030420179};\\\", \\\"{x:834,y:594,t:1527030420196};\\\", \\\"{x:834,y:598,t:1527030420213};\\\", \\\"{x:834,y:599,t:1527030420229};\\\", \\\"{x:834,y:600,t:1527030420788};\\\", \\\"{x:834,y:602,t:1527030420796};\\\", \\\"{x:842,y:611,t:1527030420814};\\\", \\\"{x:872,y:619,t:1527030420830};\\\", \\\"{x:933,y:625,t:1527030420846};\\\", \\\"{x:1014,y:638,t:1527030420863};\\\", \\\"{x:1092,y:638,t:1527030420880};\\\", \\\"{x:1164,y:645,t:1527030420896};\\\", \\\"{x:1237,y:651,t:1527030420912};\\\", \\\"{x:1293,y:651,t:1527030420930};\\\", \\\"{x:1328,y:651,t:1527030420946};\\\", \\\"{x:1349,y:652,t:1527030420963};\\\", \\\"{x:1368,y:657,t:1527030420979};\\\", \\\"{x:1372,y:659,t:1527030420996};\\\", \\\"{x:1374,y:662,t:1527030421013};\\\", \\\"{x:1377,y:672,t:1527030421030};\\\", \\\"{x:1381,y:692,t:1527030421047};\\\", \\\"{x:1388,y:717,t:1527030421063};\\\", \\\"{x:1394,y:740,t:1527030421080};\\\", \\\"{x:1397,y:750,t:1527030421097};\\\", \\\"{x:1398,y:754,t:1527030421113};\\\", \\\"{x:1398,y:757,t:1527030421130};\\\", \\\"{x:1398,y:761,t:1527030421147};\\\", \\\"{x:1396,y:764,t:1527030421163};\\\", \\\"{x:1395,y:768,t:1527030421180};\\\", \\\"{x:1394,y:768,t:1527030421269};\\\", \\\"{x:1393,y:769,t:1527030421281};\\\", \\\"{x:1387,y:769,t:1527030421297};\\\", \\\"{x:1379,y:766,t:1527030421313};\\\", \\\"{x:1376,y:766,t:1527030421330};\\\", \\\"{x:1373,y:765,t:1527030421348};\\\", \\\"{x:1372,y:763,t:1527030421364};\\\", \\\"{x:1372,y:760,t:1527030421381};\\\", \\\"{x:1371,y:755,t:1527030421398};\\\", \\\"{x:1371,y:749,t:1527030421415};\\\", \\\"{x:1371,y:746,t:1527030421431};\\\", \\\"{x:1371,y:741,t:1527030421448};\\\", \\\"{x:1371,y:737,t:1527030421465};\\\", \\\"{x:1376,y:729,t:1527030421480};\\\", \\\"{x:1383,y:720,t:1527030421497};\\\", \\\"{x:1393,y:712,t:1527030421514};\\\", \\\"{x:1403,y:703,t:1527030421530};\\\", \\\"{x:1407,y:700,t:1527030421548};\\\", \\\"{x:1411,y:693,t:1527030421564};\\\", \\\"{x:1412,y:686,t:1527030421580};\\\", \\\"{x:1415,y:675,t:1527030421598};\\\", \\\"{x:1421,y:659,t:1527030421614};\\\", \\\"{x:1426,y:639,t:1527030421631};\\\", \\\"{x:1432,y:622,t:1527030421647};\\\", \\\"{x:1438,y:606,t:1527030421665};\\\", \\\"{x:1440,y:592,t:1527030421681};\\\", \\\"{x:1442,y:581,t:1527030421698};\\\", \\\"{x:1444,y:564,t:1527030421715};\\\", \\\"{x:1448,y:550,t:1527030421732};\\\", \\\"{x:1453,y:536,t:1527030421748};\\\", \\\"{x:1466,y:515,t:1527030421765};\\\", \\\"{x:1476,y:502,t:1527030421781};\\\", \\\"{x:1492,y:485,t:1527030421798};\\\", \\\"{x:1502,y:472,t:1527030421815};\\\", \\\"{x:1513,y:460,t:1527030421832};\\\", \\\"{x:1521,y:448,t:1527030421848};\\\", \\\"{x:1528,y:438,t:1527030421864};\\\", \\\"{x:1534,y:428,t:1527030421882};\\\", \\\"{x:1542,y:418,t:1527030421897};\\\", \\\"{x:1548,y:407,t:1527030421915};\\\", \\\"{x:1556,y:400,t:1527030421932};\\\", \\\"{x:1560,y:395,t:1527030421948};\\\", \\\"{x:1561,y:393,t:1527030421964};\\\", \\\"{x:1562,y:391,t:1527030421982};\\\", \\\"{x:1562,y:392,t:1527030422045};\\\", \\\"{x:1561,y:397,t:1527030422052};\\\", \\\"{x:1556,y:405,t:1527030422065};\\\", \\\"{x:1542,y:429,t:1527030422082};\\\", \\\"{x:1516,y:466,t:1527030422099};\\\", \\\"{x:1474,y:530,t:1527030422115};\\\", \\\"{x:1435,y:588,t:1527030422132};\\\", \\\"{x:1369,y:669,t:1527030422149};\\\", \\\"{x:1323,y:724,t:1527030422165};\\\", \\\"{x:1271,y:775,t:1527030422182};\\\", \\\"{x:1222,y:826,t:1527030422198};\\\", \\\"{x:1165,y:872,t:1527030422214};\\\", \\\"{x:1107,y:909,t:1527030422231};\\\", \\\"{x:1049,y:935,t:1527030422248};\\\", \\\"{x:966,y:956,t:1527030422264};\\\", \\\"{x:886,y:965,t:1527030422280};\\\", \\\"{x:823,y:972,t:1527030422298};\\\", \\\"{x:756,y:972,t:1527030422314};\\\", \\\"{x:717,y:972,t:1527030422331};\\\", \\\"{x:684,y:968,t:1527030422347};\\\", \\\"{x:667,y:964,t:1527030422364};\\\", \\\"{x:649,y:960,t:1527030422381};\\\", \\\"{x:632,y:954,t:1527030422398};\\\", \\\"{x:611,y:950,t:1527030422415};\\\", \\\"{x:593,y:939,t:1527030422431};\\\", \\\"{x:581,y:920,t:1527030422449};\\\", \\\"{x:575,y:896,t:1527030422466};\\\", \\\"{x:574,y:877,t:1527030422482};\\\", \\\"{x:574,y:861,t:1527030422499};\\\", \\\"{x:576,y:850,t:1527030422516};\\\", \\\"{x:577,y:838,t:1527030422531};\\\", \\\"{x:576,y:815,t:1527030422548};\\\", \\\"{x:574,y:803,t:1527030422565};\\\", \\\"{x:572,y:791,t:1527030422582};\\\", \\\"{x:572,y:784,t:1527030422599};\\\", \\\"{x:572,y:777,t:1527030422616};\\\", \\\"{x:570,y:768,t:1527030422631};\\\", \\\"{x:567,y:760,t:1527030422648};\\\", \\\"{x:558,y:753,t:1527030422666};\\\", \\\"{x:551,y:748,t:1527030422681};\\\", \\\"{x:543,y:742,t:1527030422699};\\\", \\\"{x:536,y:736,t:1527030422715};\\\", \\\"{x:530,y:733,t:1527030422732};\\\", \\\"{x:528,y:731,t:1527030422748};\\\", \\\"{x:525,y:731,t:1527030422765};\\\", \\\"{x:521,y:729,t:1527030422781};\\\", \\\"{x:518,y:727,t:1527030422798};\\\", \\\"{x:515,y:723,t:1527030422814};\\\", \\\"{x:512,y:720,t:1527030422831};\\\", \\\"{x:511,y:719,t:1527030422848};\\\" ] }, { \\\"rt\\\": 11218, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 352792, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:722,t:1527030425212};\\\", \\\"{x:520,y:728,t:1527030425219};\\\", \\\"{x:524,y:729,t:1527030425231};\\\", \\\"{x:528,y:733,t:1527030425248};\\\", \\\"{x:530,y:733,t:1527030425267};\\\", \\\"{x:536,y:730,t:1527030425281};\\\", \\\"{x:551,y:709,t:1527030425298};\\\", \\\"{x:567,y:661,t:1527030425316};\\\", \\\"{x:564,y:579,t:1527030425331};\\\", \\\"{x:545,y:530,t:1527030425350};\\\", \\\"{x:526,y:497,t:1527030425367};\\\", \\\"{x:512,y:471,t:1527030425383};\\\", \\\"{x:496,y:449,t:1527030425400};\\\", \\\"{x:486,y:437,t:1527030425416};\\\", \\\"{x:480,y:431,t:1527030425433};\\\", \\\"{x:472,y:425,t:1527030425450};\\\", \\\"{x:465,y:423,t:1527030425466};\\\", \\\"{x:460,y:422,t:1527030425483};\\\", \\\"{x:456,y:422,t:1527030425500};\\\", \\\"{x:454,y:422,t:1527030425516};\\\", \\\"{x:453,y:422,t:1527030425533};\\\", \\\"{x:449,y:422,t:1527030425550};\\\", \\\"{x:443,y:430,t:1527030425566};\\\", \\\"{x:437,y:439,t:1527030425583};\\\", \\\"{x:432,y:444,t:1527030425599};\\\", \\\"{x:430,y:446,t:1527030425617};\\\", \\\"{x:429,y:447,t:1527030425633};\\\", \\\"{x:425,y:449,t:1527030425650};\\\", \\\"{x:423,y:449,t:1527030425667};\\\", \\\"{x:422,y:451,t:1527030425683};\\\", \\\"{x:417,y:453,t:1527030425700};\\\", \\\"{x:418,y:453,t:1527030425764};\\\", \\\"{x:424,y:453,t:1527030425771};\\\", \\\"{x:432,y:454,t:1527030425782};\\\", \\\"{x:458,y:458,t:1527030425800};\\\", \\\"{x:487,y:462,t:1527030425817};\\\", \\\"{x:514,y:466,t:1527030425833};\\\", \\\"{x:535,y:470,t:1527030425850};\\\", \\\"{x:544,y:471,t:1527030425867};\\\", \\\"{x:545,y:471,t:1527030425883};\\\", \\\"{x:546,y:472,t:1527030425900};\\\", \\\"{x:547,y:473,t:1527030425931};\\\", \\\"{x:549,y:473,t:1527030425940};\\\", \\\"{x:555,y:473,t:1527030425950};\\\", \\\"{x:565,y:473,t:1527030425967};\\\", \\\"{x:574,y:473,t:1527030425982};\\\", \\\"{x:581,y:473,t:1527030426000};\\\", \\\"{x:582,y:473,t:1527030426323};\\\", \\\"{x:586,y:473,t:1527030426334};\\\", \\\"{x:601,y:473,t:1527030426350};\\\", \\\"{x:628,y:474,t:1527030426367};\\\", \\\"{x:650,y:475,t:1527030426384};\\\", \\\"{x:660,y:475,t:1527030426400};\\\", \\\"{x:663,y:475,t:1527030426417};\\\", \\\"{x:664,y:475,t:1527030426492};\\\", \\\"{x:665,y:475,t:1527030426500};\\\", \\\"{x:666,y:475,t:1527030426540};\\\", \\\"{x:667,y:475,t:1527030426551};\\\", \\\"{x:668,y:475,t:1527030426567};\\\", \\\"{x:669,y:475,t:1527030426584};\\\", \\\"{x:670,y:475,t:1527030426600};\\\", \\\"{x:671,y:475,t:1527030426617};\\\", \\\"{x:672,y:475,t:1527030426634};\\\", \\\"{x:673,y:475,t:1527030426684};\\\", \\\"{x:673,y:474,t:1527030426812};\\\", \\\"{x:680,y:470,t:1527030426819};\\\", \\\"{x:701,y:469,t:1527030426834};\\\", \\\"{x:782,y:467,t:1527030426851};\\\", \\\"{x:807,y:462,t:1527030426867};\\\", \\\"{x:877,y:462,t:1527030426884};\\\", \\\"{x:946,y:462,t:1527030426901};\\\", \\\"{x:1002,y:462,t:1527030426917};\\\", \\\"{x:1052,y:462,t:1527030426934};\\\", \\\"{x:1108,y:462,t:1527030426951};\\\", \\\"{x:1147,y:462,t:1527030426968};\\\", \\\"{x:1187,y:462,t:1527030426984};\\\", \\\"{x:1229,y:462,t:1527030427001};\\\", \\\"{x:1265,y:462,t:1527030427018};\\\", \\\"{x:1302,y:462,t:1527030427034};\\\", \\\"{x:1329,y:462,t:1527030427051};\\\", \\\"{x:1358,y:462,t:1527030427067};\\\", \\\"{x:1369,y:462,t:1527030427084};\\\", \\\"{x:1375,y:462,t:1527030427101};\\\", \\\"{x:1381,y:462,t:1527030427118};\\\", \\\"{x:1386,y:462,t:1527030427134};\\\", \\\"{x:1396,y:462,t:1527030427151};\\\", \\\"{x:1415,y:462,t:1527030427169};\\\", \\\"{x:1435,y:462,t:1527030427184};\\\", \\\"{x:1443,y:462,t:1527030427201};\\\", \\\"{x:1448,y:461,t:1527030427218};\\\", \\\"{x:1452,y:459,t:1527030427234};\\\", \\\"{x:1459,y:458,t:1527030427251};\\\", \\\"{x:1474,y:453,t:1527030427267};\\\", \\\"{x:1489,y:452,t:1527030427284};\\\", \\\"{x:1504,y:449,t:1527030427301};\\\", \\\"{x:1516,y:448,t:1527030427318};\\\", \\\"{x:1529,y:445,t:1527030427334};\\\", \\\"{x:1545,y:442,t:1527030427351};\\\", \\\"{x:1560,y:440,t:1527030427368};\\\", \\\"{x:1565,y:437,t:1527030427385};\\\", \\\"{x:1567,y:437,t:1527030427401};\\\", \\\"{x:1568,y:436,t:1527030427418};\\\", \\\"{x:1569,y:436,t:1527030427523};\\\", \\\"{x:1571,y:435,t:1527030427535};\\\", \\\"{x:1573,y:435,t:1527030427555};\\\", \\\"{x:1574,y:435,t:1527030427568};\\\", \\\"{x:1576,y:435,t:1527030427585};\\\", \\\"{x:1577,y:435,t:1527030427604};\\\", \\\"{x:1578,y:435,t:1527030427618};\\\", \\\"{x:1580,y:435,t:1527030427635};\\\", \\\"{x:1581,y:436,t:1527030427651};\\\", \\\"{x:1584,y:436,t:1527030427668};\\\", \\\"{x:1585,y:437,t:1527030427685};\\\", \\\"{x:1587,y:438,t:1527030427701};\\\", \\\"{x:1592,y:441,t:1527030427718};\\\", \\\"{x:1593,y:441,t:1527030427735};\\\", \\\"{x:1594,y:441,t:1527030427751};\\\", \\\"{x:1595,y:441,t:1527030427768};\\\", \\\"{x:1596,y:441,t:1527030427803};\\\", \\\"{x:1597,y:441,t:1527030427818};\\\", \\\"{x:1598,y:441,t:1527030427835};\\\", \\\"{x:1601,y:441,t:1527030427851};\\\", \\\"{x:1602,y:441,t:1527030427868};\\\", \\\"{x:1604,y:440,t:1527030427891};\\\", \\\"{x:1604,y:442,t:1527030428227};\\\", \\\"{x:1604,y:444,t:1527030428243};\\\", \\\"{x:1603,y:446,t:1527030428251};\\\", \\\"{x:1603,y:449,t:1527030428268};\\\", \\\"{x:1601,y:457,t:1527030428286};\\\", \\\"{x:1599,y:460,t:1527030428302};\\\", \\\"{x:1598,y:465,t:1527030428319};\\\", \\\"{x:1595,y:473,t:1527030428335};\\\", \\\"{x:1594,y:480,t:1527030428352};\\\", \\\"{x:1591,y:488,t:1527030428369};\\\", \\\"{x:1590,y:495,t:1527030428385};\\\", \\\"{x:1588,y:503,t:1527030428402};\\\", \\\"{x:1586,y:513,t:1527030428419};\\\", \\\"{x:1580,y:533,t:1527030428435};\\\", \\\"{x:1575,y:549,t:1527030428452};\\\", \\\"{x:1571,y:562,t:1527030428469};\\\", \\\"{x:1566,y:574,t:1527030428485};\\\", \\\"{x:1561,y:586,t:1527030428502};\\\", \\\"{x:1558,y:593,t:1527030428519};\\\", \\\"{x:1552,y:604,t:1527030428535};\\\", \\\"{x:1546,y:612,t:1527030428552};\\\", \\\"{x:1542,y:617,t:1527030428569};\\\", \\\"{x:1535,y:623,t:1527030428585};\\\", \\\"{x:1530,y:625,t:1527030428602};\\\", \\\"{x:1525,y:628,t:1527030428619};\\\", \\\"{x:1523,y:629,t:1527030428635};\\\", \\\"{x:1521,y:630,t:1527030428652};\\\", \\\"{x:1520,y:631,t:1527030428669};\\\", \\\"{x:1518,y:632,t:1527030428686};\\\", \\\"{x:1516,y:633,t:1527030428702};\\\", \\\"{x:1516,y:634,t:1527030428755};\\\", \\\"{x:1515,y:634,t:1527030429060};\\\", \\\"{x:1511,y:635,t:1527030429072};\\\", \\\"{x:1498,y:643,t:1527030429086};\\\", \\\"{x:1480,y:648,t:1527030429102};\\\", \\\"{x:1460,y:654,t:1527030429119};\\\", \\\"{x:1433,y:661,t:1527030429136};\\\", \\\"{x:1386,y:667,t:1527030429152};\\\", \\\"{x:1314,y:676,t:1527030429170};\\\", \\\"{x:1198,y:688,t:1527030429186};\\\", \\\"{x:1065,y:707,t:1527030429203};\\\", \\\"{x:922,y:720,t:1527030429219};\\\", \\\"{x:758,y:740,t:1527030429236};\\\", \\\"{x:706,y:743,t:1527030429253};\\\", \\\"{x:677,y:745,t:1527030429269};\\\", \\\"{x:658,y:745,t:1527030429286};\\\", \\\"{x:636,y:745,t:1527030429303};\\\", \\\"{x:610,y:739,t:1527030429319};\\\", \\\"{x:571,y:729,t:1527030429336};\\\", \\\"{x:542,y:719,t:1527030429354};\\\", \\\"{x:522,y:712,t:1527030429369};\\\", \\\"{x:514,y:708,t:1527030429386};\\\", \\\"{x:512,y:708,t:1527030429403};\\\", \\\"{x:512,y:705,t:1527030429420};\\\", \\\"{x:512,y:702,t:1527030429436};\\\", \\\"{x:514,y:697,t:1527030429454};\\\", \\\"{x:516,y:689,t:1527030429470};\\\", \\\"{x:518,y:680,t:1527030429485};\\\", \\\"{x:518,y:674,t:1527030429503};\\\", \\\"{x:515,y:669,t:1527030429520};\\\", \\\"{x:508,y:664,t:1527030429536};\\\", \\\"{x:497,y:656,t:1527030429553};\\\", \\\"{x:487,y:652,t:1527030429570};\\\", \\\"{x:472,y:641,t:1527030429587};\\\", \\\"{x:446,y:624,t:1527030429603};\\\", \\\"{x:432,y:617,t:1527030429620};\\\", \\\"{x:422,y:613,t:1527030429636};\\\", \\\"{x:415,y:610,t:1527030429654};\\\", \\\"{x:410,y:608,t:1527030429670};\\\", \\\"{x:404,y:605,t:1527030429686};\\\", \\\"{x:400,y:601,t:1527030429703};\\\", \\\"{x:396,y:595,t:1527030429720};\\\", \\\"{x:392,y:588,t:1527030429736};\\\", \\\"{x:389,y:584,t:1527030429754};\\\", \\\"{x:389,y:581,t:1527030429771};\\\", \\\"{x:388,y:581,t:1527030429786};\\\", \\\"{x:388,y:582,t:1527030429925};\\\", \\\"{x:388,y:583,t:1527030429947};\\\", \\\"{x:388,y:585,t:1527030429956};\\\", \\\"{x:388,y:586,t:1527030429972};\\\", \\\"{x:388,y:587,t:1527030429987};\\\", \\\"{x:388,y:588,t:1527030430004};\\\", \\\"{x:388,y:589,t:1527030430044};\\\", \\\"{x:388,y:590,t:1527030430059};\\\", \\\"{x:389,y:590,t:1527030430771};\\\", \\\"{x:405,y:583,t:1527030430787};\\\", \\\"{x:427,y:569,t:1527030430805};\\\", \\\"{x:447,y:556,t:1527030430821};\\\", \\\"{x:463,y:544,t:1527030430837};\\\", \\\"{x:472,y:536,t:1527030430855};\\\", \\\"{x:477,y:527,t:1527030430871};\\\", \\\"{x:477,y:522,t:1527030430887};\\\", \\\"{x:476,y:515,t:1527030430904};\\\", \\\"{x:475,y:509,t:1527030430921};\\\", \\\"{x:474,y:504,t:1527030430938};\\\", \\\"{x:474,y:501,t:1527030430954};\\\", \\\"{x:476,y:495,t:1527030430971};\\\", \\\"{x:486,y:488,t:1527030430987};\\\", \\\"{x:502,y:482,t:1527030431004};\\\", \\\"{x:531,y:479,t:1527030431021};\\\", \\\"{x:582,y:473,t:1527030431038};\\\", \\\"{x:632,y:473,t:1527030431054};\\\", \\\"{x:669,y:473,t:1527030431071};\\\", \\\"{x:694,y:473,t:1527030431088};\\\", \\\"{x:703,y:473,t:1527030431104};\\\", \\\"{x:709,y:473,t:1527030431121};\\\", \\\"{x:713,y:473,t:1527030431139};\\\", \\\"{x:720,y:473,t:1527030431154};\\\", \\\"{x:732,y:473,t:1527030431171};\\\", \\\"{x:739,y:474,t:1527030431188};\\\", \\\"{x:740,y:475,t:1527030431204};\\\", \\\"{x:741,y:476,t:1527030431221};\\\", \\\"{x:743,y:480,t:1527030431238};\\\", \\\"{x:745,y:487,t:1527030431255};\\\", \\\"{x:745,y:494,t:1527030431272};\\\", \\\"{x:745,y:503,t:1527030431288};\\\", \\\"{x:745,y:510,t:1527030431307};\\\", \\\"{x:745,y:519,t:1527030431321};\\\", \\\"{x:745,y:533,t:1527030431339};\\\", \\\"{x:743,y:550,t:1527030431355};\\\", \\\"{x:743,y:580,t:1527030431372};\\\", \\\"{x:744,y:594,t:1527030431388};\\\", \\\"{x:744,y:600,t:1527030431404};\\\", \\\"{x:744,y:608,t:1527030431421};\\\", \\\"{x:744,y:617,t:1527030431439};\\\", \\\"{x:744,y:631,t:1527030431454};\\\", \\\"{x:744,y:645,t:1527030431471};\\\", \\\"{x:744,y:659,t:1527030431488};\\\", \\\"{x:744,y:669,t:1527030431504};\\\", \\\"{x:744,y:670,t:1527030431521};\\\", \\\"{x:744,y:672,t:1527030431538};\\\", \\\"{x:744,y:674,t:1527030431554};\\\", \\\"{x:744,y:680,t:1527030431571};\\\", \\\"{x:744,y:684,t:1527030431588};\\\", \\\"{x:744,y:689,t:1527030431606};\\\", \\\"{x:746,y:691,t:1527030431621};\\\", \\\"{x:746,y:692,t:1527030431638};\\\", \\\"{x:746,y:694,t:1527030431655};\\\", \\\"{x:746,y:696,t:1527030431811};\\\", \\\"{x:746,y:697,t:1527030431821};\\\", \\\"{x:745,y:698,t:1527030431838};\\\", \\\"{x:745,y:700,t:1527030431855};\\\", \\\"{x:744,y:701,t:1527030431872};\\\", \\\"{x:743,y:702,t:1527030431888};\\\", \\\"{x:743,y:703,t:1527030431905};\\\", \\\"{x:742,y:704,t:1527030431921};\\\", \\\"{x:740,y:707,t:1527030431939};\\\", \\\"{x:740,y:708,t:1527030431955};\\\", \\\"{x:739,y:709,t:1527030431971};\\\", \\\"{x:739,y:710,t:1527030432019};\\\", \\\"{x:739,y:711,t:1527030432027};\\\", \\\"{x:737,y:712,t:1527030432051};\\\", \\\"{x:737,y:713,t:1527030432059};\\\", \\\"{x:735,y:714,t:1527030432072};\\\", \\\"{x:734,y:715,t:1527030432089};\\\", \\\"{x:731,y:718,t:1527030432105};\\\", \\\"{x:730,y:719,t:1527030432123};\\\", \\\"{x:727,y:721,t:1527030432138};\\\", \\\"{x:724,y:723,t:1527030432155};\\\", \\\"{x:721,y:725,t:1527030432171};\\\", \\\"{x:720,y:725,t:1527030432188};\\\", \\\"{x:717,y:727,t:1527030432205};\\\", \\\"{x:716,y:729,t:1527030432222};\\\", \\\"{x:713,y:731,t:1527030432239};\\\", \\\"{x:708,y:734,t:1527030432255};\\\", \\\"{x:704,y:736,t:1527030432272};\\\", \\\"{x:698,y:739,t:1527030432288};\\\", \\\"{x:696,y:741,t:1527030432305};\\\", \\\"{x:691,y:744,t:1527030432323};\\\", \\\"{x:686,y:746,t:1527030432338};\\\", \\\"{x:683,y:747,t:1527030432355};\\\", \\\"{x:680,y:749,t:1527030432373};\\\", \\\"{x:677,y:750,t:1527030432388};\\\", \\\"{x:673,y:751,t:1527030432405};\\\", \\\"{x:666,y:754,t:1527030432422};\\\", \\\"{x:650,y:756,t:1527030432439};\\\", \\\"{x:635,y:758,t:1527030432455};\\\", \\\"{x:621,y:760,t:1527030432472};\\\", \\\"{x:611,y:761,t:1527030432489};\\\", \\\"{x:605,y:764,t:1527030432505};\\\", \\\"{x:602,y:764,t:1527030432522};\\\", \\\"{x:597,y:764,t:1527030432539};\\\", \\\"{x:591,y:765,t:1527030432555};\\\", \\\"{x:583,y:767,t:1527030432572};\\\", \\\"{x:577,y:767,t:1527030432590};\\\", \\\"{x:572,y:768,t:1527030432606};\\\", \\\"{x:572,y:769,t:1527030432623};\\\", \\\"{x:575,y:769,t:1527030433227};\\\", \\\"{x:585,y:772,t:1527030433239};\\\", \\\"{x:610,y:779,t:1527030433256};\\\", \\\"{x:657,y:788,t:1527030433273};\\\", \\\"{x:714,y:801,t:1527030433290};\\\", \\\"{x:777,y:813,t:1527030433307};\\\", \\\"{x:834,y:824,t:1527030433322};\\\", \\\"{x:918,y:832,t:1527030433339};\\\", \\\"{x:976,y:832,t:1527030433357};\\\", \\\"{x:1024,y:832,t:1527030433373};\\\", \\\"{x:1066,y:832,t:1527030433389};\\\", \\\"{x:1093,y:832,t:1527030433406};\\\", \\\"{x:1111,y:832,t:1527030433424};\\\", \\\"{x:1128,y:828,t:1527030433440};\\\", \\\"{x:1139,y:824,t:1527030433457};\\\", \\\"{x:1153,y:816,t:1527030433474};\\\", \\\"{x:1170,y:806,t:1527030433489};\\\", \\\"{x:1190,y:792,t:1527030433506};\\\", \\\"{x:1225,y:764,t:1527030433524};\\\", \\\"{x:1250,y:741,t:1527030433539};\\\", \\\"{x:1272,y:721,t:1527030433557};\\\", \\\"{x:1294,y:700,t:1527030433573};\\\", \\\"{x:1323,y:671,t:1527030433590};\\\", \\\"{x:1358,y:627,t:1527030433606};\\\", \\\"{x:1398,y:580,t:1527030433623};\\\", \\\"{x:1434,y:543,t:1527030433639};\\\", \\\"{x:1457,y:520,t:1527030433657};\\\", \\\"{x:1474,y:506,t:1527030433674};\\\", \\\"{x:1487,y:493,t:1527030433690};\\\", \\\"{x:1502,y:480,t:1527030433707};\\\", \\\"{x:1521,y:468,t:1527030433723};\\\", \\\"{x:1533,y:463,t:1527030433739};\\\", \\\"{x:1543,y:460,t:1527030433756};\\\", \\\"{x:1556,y:455,t:1527030433773};\\\", \\\"{x:1565,y:451,t:1527030433790};\\\", \\\"{x:1570,y:450,t:1527030433806};\\\", \\\"{x:1573,y:449,t:1527030433824};\\\", \\\"{x:1576,y:449,t:1527030433840};\\\", \\\"{x:1579,y:449,t:1527030433875};\\\", \\\"{x:1580,y:449,t:1527030433890};\\\", \\\"{x:1589,y:449,t:1527030433907};\\\", \\\"{x:1603,y:449,t:1527030433924};\\\", \\\"{x:1609,y:446,t:1527030433940};\\\", \\\"{x:1613,y:446,t:1527030433957};\\\", \\\"{x:1615,y:446,t:1527030433974};\\\", \\\"{x:1616,y:446,t:1527030433991};\\\", \\\"{x:1618,y:445,t:1527030434007};\\\", \\\"{x:1619,y:444,t:1527030434024};\\\", \\\"{x:1620,y:443,t:1527030434041};\\\", \\\"{x:1620,y:442,t:1527030434056};\\\", \\\"{x:1621,y:442,t:1527030434073};\\\", \\\"{x:1622,y:441,t:1527030434099};\\\", \\\"{x:1622,y:440,t:1527030434123};\\\", \\\"{x:1622,y:439,t:1527030434155};\\\", \\\"{x:1622,y:438,t:1527030434172};\\\", \\\"{x:1623,y:438,t:1527030434180};\\\", \\\"{x:1623,y:440,t:1527030434363};\\\", \\\"{x:1622,y:440,t:1527030434373};\\\", \\\"{x:1621,y:441,t:1527030434390};\\\", \\\"{x:1618,y:446,t:1527030434408};\\\", \\\"{x:1615,y:450,t:1527030434424};\\\", \\\"{x:1611,y:460,t:1527030434441};\\\", \\\"{x:1603,y:470,t:1527030434457};\\\", \\\"{x:1599,y:479,t:1527030434473};\\\", \\\"{x:1593,y:491,t:1527030434490};\\\", \\\"{x:1580,y:511,t:1527030434508};\\\", \\\"{x:1574,y:525,t:1527030434523};\\\", \\\"{x:1567,y:540,t:1527030434541};\\\", \\\"{x:1556,y:560,t:1527030434558};\\\", \\\"{x:1550,y:577,t:1527030434574};\\\", \\\"{x:1548,y:583,t:1527030434591};\\\", \\\"{x:1547,y:584,t:1527030434608};\\\", \\\"{x:1547,y:586,t:1527030434624};\\\", \\\"{x:1546,y:587,t:1527030434641};\\\", \\\"{x:1545,y:590,t:1527030434658};\\\", \\\"{x:1545,y:593,t:1527030434674};\\\", \\\"{x:1543,y:597,t:1527030434691};\\\", \\\"{x:1541,y:603,t:1527030434708};\\\", \\\"{x:1541,y:604,t:1527030434724};\\\", \\\"{x:1540,y:606,t:1527030434741};\\\", \\\"{x:1539,y:607,t:1527030434758};\\\", \\\"{x:1538,y:608,t:1527030434775};\\\", \\\"{x:1538,y:610,t:1527030434790};\\\", \\\"{x:1535,y:613,t:1527030434808};\\\", \\\"{x:1533,y:617,t:1527030434825};\\\", \\\"{x:1529,y:621,t:1527030434841};\\\", \\\"{x:1529,y:622,t:1527030434858};\\\", \\\"{x:1529,y:623,t:1527030434874};\\\", \\\"{x:1528,y:624,t:1527030434890};\\\", \\\"{x:1528,y:625,t:1527030434971};\\\", \\\"{x:1526,y:625,t:1527030434980};\\\", \\\"{x:1524,y:627,t:1527030434990};\\\", \\\"{x:1520,y:630,t:1527030435008};\\\", \\\"{x:1514,y:633,t:1527030435024};\\\", \\\"{x:1503,y:638,t:1527030435040};\\\", \\\"{x:1478,y:643,t:1527030435058};\\\", \\\"{x:1437,y:648,t:1527030435075};\\\", \\\"{x:1366,y:653,t:1527030435090};\\\", \\\"{x:1242,y:659,t:1527030435107};\\\", \\\"{x:1178,y:667,t:1527030435125};\\\", \\\"{x:1114,y:676,t:1527030435141};\\\", \\\"{x:1056,y:682,t:1527030435157};\\\", \\\"{x:995,y:682,t:1527030435175};\\\", \\\"{x:928,y:682,t:1527030435191};\\\", \\\"{x:875,y:682,t:1527030435207};\\\", \\\"{x:828,y:686,t:1527030435224};\\\", \\\"{x:781,y:692,t:1527030435241};\\\", \\\"{x:741,y:699,t:1527030435257};\\\", \\\"{x:707,y:704,t:1527030435275};\\\", \\\"{x:666,y:705,t:1527030435291};\\\", \\\"{x:651,y:705,t:1527030435307};\\\", \\\"{x:642,y:705,t:1527030435324};\\\", \\\"{x:638,y:705,t:1527030435342};\\\", \\\"{x:634,y:705,t:1527030435357};\\\", \\\"{x:626,y:706,t:1527030435375};\\\", \\\"{x:609,y:710,t:1527030435391};\\\", \\\"{x:588,y:712,t:1527030435407};\\\", \\\"{x:571,y:715,t:1527030435424};\\\", \\\"{x:559,y:716,t:1527030435442};\\\", \\\"{x:550,y:719,t:1527030435457};\\\", \\\"{x:534,y:720,t:1527030435475};\\\", \\\"{x:507,y:722,t:1527030435491};\\\", \\\"{x:490,y:724,t:1527030435509};\\\", \\\"{x:484,y:724,t:1527030435525};\\\", \\\"{x:483,y:724,t:1527030435541};\\\", \\\"{x:481,y:724,t:1527030435558};\\\", \\\"{x:480,y:724,t:1527030435579};\\\", \\\"{x:479,y:722,t:1527030436563};\\\", \\\"{x:477,y:719,t:1527030436575};\\\", \\\"{x:467,y:709,t:1527030436592};\\\", \\\"{x:456,y:697,t:1527030436608};\\\", \\\"{x:452,y:691,t:1527030436626};\\\", \\\"{x:452,y:687,t:1527030436723};\\\", \\\"{x:452,y:684,t:1527030436732};\\\", \\\"{x:452,y:680,t:1527030436742};\\\", \\\"{x:452,y:677,t:1527030436759};\\\", \\\"{x:452,y:675,t:1527030436775};\\\", \\\"{x:452,y:674,t:1527030436793};\\\" ] }, { \\\"rt\\\": 13338, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 367409, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:452,y:672,t:1527030437571};\\\", \\\"{x:453,y:653,t:1527030437579};\\\", \\\"{x:459,y:626,t:1527030437592};\\\", \\\"{x:468,y:519,t:1527030437685};\\\", \\\"{x:467,y:516,t:1527030437747};\\\", \\\"{x:464,y:516,t:1527030437759};\\\", \\\"{x:446,y:512,t:1527030437777};\\\", \\\"{x:423,y:510,t:1527030437794};\\\", \\\"{x:404,y:510,t:1527030437810};\\\", \\\"{x:400,y:510,t:1527030437827};\\\", \\\"{x:399,y:510,t:1527030437843};\\\", \\\"{x:399,y:509,t:1527030437883};\\\", \\\"{x:403,y:507,t:1527030437894};\\\", \\\"{x:420,y:503,t:1527030437910};\\\", \\\"{x:444,y:501,t:1527030437926};\\\", \\\"{x:481,y:501,t:1527030437944};\\\", \\\"{x:517,y:501,t:1527030437960};\\\", \\\"{x:536,y:501,t:1527030437976};\\\", \\\"{x:542,y:501,t:1527030437994};\\\", \\\"{x:543,y:501,t:1527030438009};\\\", \\\"{x:542,y:501,t:1527030438764};\\\", \\\"{x:540,y:501,t:1527030438778};\\\", \\\"{x:539,y:501,t:1527030438794};\\\", \\\"{x:539,y:500,t:1527030438884};\\\", \\\"{x:539,y:499,t:1527030438894};\\\", \\\"{x:542,y:498,t:1527030438910};\\\", \\\"{x:547,y:498,t:1527030438928};\\\", \\\"{x:549,y:498,t:1527030438944};\\\", \\\"{x:552,y:498,t:1527030438960};\\\", \\\"{x:553,y:498,t:1527030438978};\\\", \\\"{x:556,y:498,t:1527030438994};\\\", \\\"{x:562,y:497,t:1527030439011};\\\", \\\"{x:578,y:497,t:1527030439028};\\\", \\\"{x:592,y:496,t:1527030439044};\\\", \\\"{x:607,y:494,t:1527030439060};\\\", \\\"{x:622,y:492,t:1527030439077};\\\", \\\"{x:638,y:491,t:1527030439093};\\\", \\\"{x:660,y:487,t:1527030439110};\\\", \\\"{x:682,y:483,t:1527030439128};\\\", \\\"{x:712,y:480,t:1527030439143};\\\", \\\"{x:743,y:480,t:1527030439161};\\\", \\\"{x:775,y:480,t:1527030439177};\\\", \\\"{x:799,y:480,t:1527030439195};\\\", \\\"{x:820,y:480,t:1527030439210};\\\", \\\"{x:846,y:480,t:1527030439228};\\\", \\\"{x:867,y:480,t:1527030439245};\\\", \\\"{x:892,y:480,t:1527030439260};\\\", \\\"{x:923,y:480,t:1527030439278};\\\", \\\"{x:962,y:480,t:1527030439294};\\\", \\\"{x:1004,y:480,t:1527030439311};\\\", \\\"{x:1033,y:480,t:1527030439328};\\\", \\\"{x:1047,y:480,t:1527030439344};\\\", \\\"{x:1053,y:480,t:1527030439361};\\\", \\\"{x:1058,y:481,t:1527030439378};\\\", \\\"{x:1071,y:483,t:1527030439394};\\\", \\\"{x:1092,y:487,t:1527030439411};\\\", \\\"{x:1129,y:493,t:1527030439427};\\\", \\\"{x:1148,y:495,t:1527030439445};\\\", \\\"{x:1169,y:500,t:1527030439460};\\\", \\\"{x:1184,y:504,t:1527030439477};\\\", \\\"{x:1197,y:508,t:1527030439495};\\\", \\\"{x:1216,y:510,t:1527030439511};\\\", \\\"{x:1233,y:515,t:1527030439527};\\\", \\\"{x:1253,y:521,t:1527030439544};\\\", \\\"{x:1274,y:527,t:1527030439561};\\\", \\\"{x:1294,y:535,t:1527030439578};\\\", \\\"{x:1315,y:542,t:1527030439595};\\\", \\\"{x:1330,y:547,t:1527030439610};\\\", \\\"{x:1348,y:557,t:1527030439627};\\\", \\\"{x:1359,y:565,t:1527030439645};\\\", \\\"{x:1373,y:576,t:1527030439660};\\\", \\\"{x:1389,y:588,t:1527030439677};\\\", \\\"{x:1404,y:597,t:1527030439694};\\\", \\\"{x:1414,y:604,t:1527030439711};\\\", \\\"{x:1419,y:608,t:1527030439727};\\\", \\\"{x:1421,y:610,t:1527030439745};\\\", \\\"{x:1423,y:611,t:1527030439761};\\\", \\\"{x:1426,y:613,t:1527030439778};\\\", \\\"{x:1432,y:614,t:1527030439795};\\\", \\\"{x:1453,y:617,t:1527030439811};\\\", \\\"{x:1466,y:621,t:1527030439827};\\\", \\\"{x:1468,y:621,t:1527030439845};\\\", \\\"{x:1469,y:620,t:1527030439862};\\\", \\\"{x:1469,y:618,t:1527030440620};\\\", \\\"{x:1469,y:617,t:1527030440635};\\\", \\\"{x:1469,y:615,t:1527030440645};\\\", \\\"{x:1472,y:614,t:1527030440662};\\\", \\\"{x:1485,y:613,t:1527030440679};\\\", \\\"{x:1500,y:609,t:1527030440695};\\\", \\\"{x:1511,y:605,t:1527030440712};\\\", \\\"{x:1514,y:603,t:1527030440729};\\\", \\\"{x:1519,y:598,t:1527030440745};\\\", \\\"{x:1521,y:594,t:1527030440762};\\\", \\\"{x:1524,y:589,t:1527030440779};\\\", \\\"{x:1526,y:586,t:1527030440795};\\\", \\\"{x:1529,y:583,t:1527030440811};\\\", \\\"{x:1530,y:581,t:1527030440829};\\\", \\\"{x:1530,y:580,t:1527030440859};\\\", \\\"{x:1530,y:578,t:1527030440867};\\\", \\\"{x:1530,y:576,t:1527030440878};\\\", \\\"{x:1529,y:573,t:1527030440896};\\\", \\\"{x:1521,y:566,t:1527030440912};\\\", \\\"{x:1509,y:560,t:1527030440929};\\\", \\\"{x:1492,y:555,t:1527030440946};\\\", \\\"{x:1472,y:550,t:1527030440962};\\\", \\\"{x:1454,y:546,t:1527030440979};\\\", \\\"{x:1428,y:544,t:1527030440995};\\\", \\\"{x:1412,y:541,t:1527030441012};\\\", \\\"{x:1393,y:541,t:1527030441029};\\\", \\\"{x:1378,y:541,t:1527030441046};\\\", \\\"{x:1369,y:542,t:1527030441061};\\\", \\\"{x:1364,y:545,t:1527030441079};\\\", \\\"{x:1355,y:551,t:1527030441096};\\\", \\\"{x:1341,y:560,t:1527030441112};\\\", \\\"{x:1324,y:568,t:1527030441129};\\\", \\\"{x:1309,y:577,t:1527030441146};\\\", \\\"{x:1294,y:587,t:1527030441162};\\\", \\\"{x:1275,y:599,t:1527030441179};\\\", \\\"{x:1244,y:620,t:1527030441195};\\\", \\\"{x:1230,y:632,t:1527030441212};\\\", \\\"{x:1224,y:641,t:1527030441228};\\\", \\\"{x:1221,y:646,t:1527030441246};\\\", \\\"{x:1221,y:649,t:1527030441261};\\\", \\\"{x:1219,y:656,t:1527030441278};\\\", \\\"{x:1217,y:660,t:1527030441295};\\\", \\\"{x:1217,y:665,t:1527030441312};\\\", \\\"{x:1217,y:672,t:1527030441329};\\\", \\\"{x:1217,y:684,t:1527030441346};\\\", \\\"{x:1217,y:695,t:1527030441363};\\\", \\\"{x:1217,y:708,t:1527030441379};\\\", \\\"{x:1219,y:719,t:1527030441395};\\\", \\\"{x:1221,y:726,t:1527030441413};\\\", \\\"{x:1223,y:734,t:1527030441428};\\\", \\\"{x:1225,y:742,t:1527030441445};\\\", \\\"{x:1227,y:747,t:1527030441463};\\\", \\\"{x:1227,y:751,t:1527030441478};\\\", \\\"{x:1230,y:754,t:1527030441496};\\\", \\\"{x:1230,y:757,t:1527030441513};\\\", \\\"{x:1230,y:759,t:1527030441529};\\\", \\\"{x:1230,y:760,t:1527030441546};\\\", \\\"{x:1230,y:761,t:1527030441563};\\\", \\\"{x:1230,y:764,t:1527030441578};\\\", \\\"{x:1230,y:765,t:1527030441596};\\\", \\\"{x:1230,y:766,t:1527030441613};\\\", \\\"{x:1230,y:767,t:1527030441629};\\\", \\\"{x:1230,y:770,t:1527030441645};\\\", \\\"{x:1230,y:772,t:1527030441663};\\\", \\\"{x:1230,y:773,t:1527030441678};\\\", \\\"{x:1230,y:775,t:1527030441696};\\\", \\\"{x:1230,y:777,t:1527030441715};\\\", \\\"{x:1230,y:778,t:1527030441729};\\\", \\\"{x:1230,y:781,t:1527030441745};\\\", \\\"{x:1228,y:786,t:1527030441762};\\\", \\\"{x:1226,y:794,t:1527030441779};\\\", \\\"{x:1226,y:798,t:1527030441795};\\\", \\\"{x:1225,y:800,t:1527030441812};\\\", \\\"{x:1225,y:801,t:1527030441830};\\\", \\\"{x:1225,y:803,t:1527030441845};\\\", \\\"{x:1222,y:806,t:1527030441863};\\\", \\\"{x:1222,y:808,t:1527030441879};\\\", \\\"{x:1221,y:808,t:1527030441898};\\\", \\\"{x:1221,y:809,t:1527030441924};\\\", \\\"{x:1221,y:810,t:1527030441931};\\\", \\\"{x:1221,y:811,t:1527030441946};\\\", \\\"{x:1221,y:819,t:1527030441963};\\\", \\\"{x:1221,y:837,t:1527030441979};\\\", \\\"{x:1221,y:848,t:1527030441995};\\\", \\\"{x:1221,y:859,t:1527030442013};\\\", \\\"{x:1222,y:864,t:1527030442030};\\\", \\\"{x:1222,y:866,t:1527030442046};\\\", \\\"{x:1222,y:867,t:1527030442063};\\\", \\\"{x:1222,y:868,t:1527030442220};\\\", \\\"{x:1224,y:870,t:1527030442300};\\\", \\\"{x:1225,y:871,t:1527030442317};\\\", \\\"{x:1227,y:871,t:1527030442330};\\\", \\\"{x:1229,y:872,t:1527030442346};\\\", \\\"{x:1233,y:875,t:1527030442363};\\\", \\\"{x:1241,y:878,t:1527030442381};\\\", \\\"{x:1248,y:880,t:1527030442397};\\\", \\\"{x:1256,y:882,t:1527030442414};\\\", \\\"{x:1263,y:884,t:1527030442430};\\\", \\\"{x:1271,y:885,t:1527030442448};\\\", \\\"{x:1274,y:886,t:1527030442463};\\\", \\\"{x:1276,y:888,t:1527030442532};\\\", \\\"{x:1278,y:889,t:1527030442548};\\\", \\\"{x:1282,y:891,t:1527030442563};\\\", \\\"{x:1287,y:894,t:1527030442580};\\\", \\\"{x:1289,y:896,t:1527030442597};\\\", \\\"{x:1289,y:897,t:1527030442614};\\\", \\\"{x:1290,y:899,t:1527030442630};\\\", \\\"{x:1292,y:903,t:1527030442651};\\\", \\\"{x:1295,y:908,t:1527030442668};\\\", \\\"{x:1297,y:911,t:1527030442684};\\\", \\\"{x:1298,y:918,t:1527030442701};\\\", \\\"{x:1299,y:923,t:1527030442717};\\\", \\\"{x:1300,y:930,t:1527030442734};\\\", \\\"{x:1301,y:934,t:1527030442751};\\\", \\\"{x:1301,y:939,t:1527030442768};\\\", \\\"{x:1301,y:944,t:1527030442784};\\\", \\\"{x:1303,y:946,t:1527030442801};\\\", \\\"{x:1303,y:950,t:1527030442818};\\\", \\\"{x:1304,y:955,t:1527030442835};\\\", \\\"{x:1304,y:956,t:1527030442851};\\\", \\\"{x:1304,y:957,t:1527030442867};\\\", \\\"{x:1304,y:958,t:1527030442884};\\\", \\\"{x:1304,y:959,t:1527030442902};\\\", \\\"{x:1304,y:960,t:1527030442918};\\\", \\\"{x:1304,y:961,t:1527030442935};\\\", \\\"{x:1304,y:963,t:1527030442961};\\\", \\\"{x:1303,y:963,t:1527030442968};\\\", \\\"{x:1303,y:964,t:1527030442984};\\\", \\\"{x:1300,y:966,t:1527030443002};\\\", \\\"{x:1298,y:966,t:1527030443018};\\\", \\\"{x:1297,y:967,t:1527030443035};\\\", \\\"{x:1296,y:968,t:1527030443051};\\\", \\\"{x:1297,y:967,t:1527030443384};\\\", \\\"{x:1299,y:966,t:1527030443402};\\\", \\\"{x:1302,y:962,t:1527030443418};\\\", \\\"{x:1306,y:958,t:1527030443436};\\\", \\\"{x:1309,y:955,t:1527030443451};\\\", \\\"{x:1311,y:950,t:1527030443468};\\\", \\\"{x:1314,y:946,t:1527030443485};\\\", \\\"{x:1317,y:940,t:1527030443501};\\\", \\\"{x:1321,y:932,t:1527030443519};\\\", \\\"{x:1327,y:920,t:1527030443536};\\\", \\\"{x:1331,y:910,t:1527030443551};\\\", \\\"{x:1337,y:894,t:1527030443568};\\\", \\\"{x:1342,y:881,t:1527030443586};\\\", \\\"{x:1346,y:870,t:1527030443601};\\\", \\\"{x:1352,y:859,t:1527030443617};\\\", \\\"{x:1360,y:846,t:1527030443635};\\\", \\\"{x:1368,y:831,t:1527030443651};\\\", \\\"{x:1374,y:821,t:1527030443668};\\\", \\\"{x:1377,y:816,t:1527030443685};\\\", \\\"{x:1379,y:811,t:1527030443701};\\\", \\\"{x:1381,y:807,t:1527030443718};\\\", \\\"{x:1383,y:804,t:1527030443735};\\\", \\\"{x:1384,y:801,t:1527030443751};\\\", \\\"{x:1387,y:793,t:1527030443768};\\\", \\\"{x:1388,y:790,t:1527030443786};\\\", \\\"{x:1389,y:787,t:1527030443801};\\\", \\\"{x:1389,y:786,t:1527030443857};\\\", \\\"{x:1389,y:784,t:1527030443872};\\\", \\\"{x:1390,y:782,t:1527030443886};\\\", \\\"{x:1390,y:779,t:1527030443902};\\\", \\\"{x:1391,y:775,t:1527030443918};\\\", \\\"{x:1391,y:774,t:1527030443935};\\\", \\\"{x:1390,y:774,t:1527030445216};\\\", \\\"{x:1381,y:778,t:1527030445224};\\\", \\\"{x:1368,y:784,t:1527030445236};\\\", \\\"{x:1332,y:799,t:1527030445253};\\\", \\\"{x:1297,y:817,t:1527030445269};\\\", \\\"{x:1273,y:829,t:1527030445287};\\\", \\\"{x:1252,y:835,t:1527030445302};\\\", \\\"{x:1240,y:839,t:1527030445319};\\\", \\\"{x:1238,y:839,t:1527030445337};\\\", \\\"{x:1237,y:840,t:1527030445481};\\\", \\\"{x:1237,y:841,t:1527030445488};\\\", \\\"{x:1237,y:842,t:1527030445503};\\\", \\\"{x:1237,y:846,t:1527030445520};\\\", \\\"{x:1237,y:852,t:1527030445537};\\\", \\\"{x:1237,y:856,t:1527030445553};\\\", \\\"{x:1240,y:862,t:1527030445570};\\\", \\\"{x:1243,y:868,t:1527030445587};\\\", \\\"{x:1247,y:877,t:1527030445604};\\\", \\\"{x:1252,y:889,t:1527030445619};\\\", \\\"{x:1259,y:899,t:1527030445637};\\\", \\\"{x:1268,y:911,t:1527030445654};\\\", \\\"{x:1276,y:921,t:1527030445670};\\\", \\\"{x:1280,y:928,t:1527030445687};\\\", \\\"{x:1285,y:936,t:1527030445704};\\\", \\\"{x:1288,y:939,t:1527030445720};\\\", \\\"{x:1291,y:944,t:1527030445737};\\\", \\\"{x:1292,y:946,t:1527030445754};\\\", \\\"{x:1293,y:948,t:1527030445770};\\\", \\\"{x:1294,y:951,t:1527030445787};\\\", \\\"{x:1295,y:953,t:1527030445804};\\\", \\\"{x:1296,y:954,t:1527030445819};\\\", \\\"{x:1296,y:950,t:1527030445928};\\\", \\\"{x:1296,y:944,t:1527030445936};\\\", \\\"{x:1296,y:929,t:1527030445954};\\\", \\\"{x:1296,y:906,t:1527030445969};\\\", \\\"{x:1313,y:880,t:1527030445986};\\\", \\\"{x:1349,y:851,t:1527030446003};\\\", \\\"{x:1391,y:814,t:1527030446020};\\\", \\\"{x:1407,y:797,t:1527030446036};\\\", \\\"{x:1416,y:786,t:1527030446053};\\\", \\\"{x:1419,y:782,t:1527030446070};\\\", \\\"{x:1420,y:782,t:1527030446086};\\\", \\\"{x:1420,y:781,t:1527030446560};\\\", \\\"{x:1420,y:780,t:1527030446571};\\\", \\\"{x:1420,y:779,t:1527030446587};\\\", \\\"{x:1420,y:778,t:1527030446603};\\\", \\\"{x:1419,y:777,t:1527030446655};\\\", \\\"{x:1418,y:777,t:1527030446671};\\\", \\\"{x:1416,y:777,t:1527030446686};\\\", \\\"{x:1410,y:777,t:1527030446703};\\\", \\\"{x:1406,y:777,t:1527030446720};\\\", \\\"{x:1401,y:777,t:1527030446737};\\\", \\\"{x:1399,y:777,t:1527030446753};\\\", \\\"{x:1395,y:777,t:1527030446770};\\\", \\\"{x:1389,y:777,t:1527030446787};\\\", \\\"{x:1380,y:776,t:1527030446803};\\\", \\\"{x:1373,y:775,t:1527030446821};\\\", \\\"{x:1361,y:773,t:1527030446837};\\\", \\\"{x:1339,y:770,t:1527030446854};\\\", \\\"{x:1307,y:765,t:1527030446870};\\\", \\\"{x:1238,y:756,t:1527030446888};\\\", \\\"{x:1133,y:740,t:1527030446903};\\\", \\\"{x:1076,y:727,t:1527030446920};\\\", \\\"{x:1032,y:710,t:1527030446937};\\\", \\\"{x:998,y:698,t:1527030446953};\\\", \\\"{x:958,y:687,t:1527030446970};\\\", \\\"{x:915,y:677,t:1527030446987};\\\", \\\"{x:868,y:665,t:1527030447004};\\\", \\\"{x:836,y:658,t:1527030447020};\\\", \\\"{x:807,y:649,t:1527030447037};\\\", \\\"{x:779,y:642,t:1527030447053};\\\", \\\"{x:758,y:634,t:1527030447070};\\\", \\\"{x:738,y:627,t:1527030447087};\\\", \\\"{x:714,y:622,t:1527030447104};\\\", \\\"{x:703,y:619,t:1527030447121};\\\", \\\"{x:691,y:616,t:1527030447137};\\\", \\\"{x:676,y:614,t:1527030447155};\\\", \\\"{x:655,y:611,t:1527030447172};\\\", \\\"{x:634,y:610,t:1527030447188};\\\", \\\"{x:616,y:607,t:1527030447205};\\\", \\\"{x:601,y:605,t:1527030447221};\\\", \\\"{x:583,y:601,t:1527030447238};\\\", \\\"{x:559,y:598,t:1527030447255};\\\", \\\"{x:539,y:595,t:1527030447271};\\\", \\\"{x:524,y:594,t:1527030447288};\\\", \\\"{x:507,y:591,t:1527030447305};\\\", \\\"{x:492,y:588,t:1527030447323};\\\", \\\"{x:472,y:582,t:1527030447338};\\\", \\\"{x:454,y:577,t:1527030447356};\\\", \\\"{x:437,y:574,t:1527030447373};\\\", \\\"{x:428,y:573,t:1527030447388};\\\", \\\"{x:419,y:572,t:1527030447405};\\\", \\\"{x:414,y:569,t:1527030447422};\\\", \\\"{x:410,y:569,t:1527030447439};\\\", \\\"{x:408,y:568,t:1527030447455};\\\", \\\"{x:407,y:566,t:1527030447471};\\\", \\\"{x:406,y:566,t:1527030447616};\\\", \\\"{x:404,y:566,t:1527030447624};\\\", \\\"{x:403,y:566,t:1527030447639};\\\", \\\"{x:402,y:565,t:1527030447695};\\\", \\\"{x:401,y:565,t:1527030447736};\\\", \\\"{x:400,y:565,t:1527030447743};\\\", \\\"{x:399,y:565,t:1527030447755};\\\", \\\"{x:397,y:565,t:1527030447772};\\\", \\\"{x:396,y:565,t:1527030447789};\\\", \\\"{x:395,y:565,t:1527030447823};\\\", \\\"{x:394,y:565,t:1527030447855};\\\", \\\"{x:393,y:565,t:1527030447872};\\\", \\\"{x:391,y:565,t:1527030447890};\\\", \\\"{x:398,y:567,t:1527030448313};\\\", \\\"{x:419,y:576,t:1527030448324};\\\", \\\"{x:497,y:602,t:1527030448340};\\\", \\\"{x:624,y:639,t:1527030448357};\\\", \\\"{x:766,y:680,t:1527030448373};\\\", \\\"{x:888,y:718,t:1527030448389};\\\", \\\"{x:954,y:748,t:1527030448406};\\\", \\\"{x:1005,y:775,t:1527030448423};\\\", \\\"{x:1022,y:787,t:1527030448439};\\\", \\\"{x:1033,y:800,t:1527030448456};\\\", \\\"{x:1044,y:813,t:1527030448474};\\\", \\\"{x:1057,y:827,t:1527030448490};\\\", \\\"{x:1067,y:838,t:1527030448507};\\\", \\\"{x:1074,y:843,t:1527030448523};\\\", \\\"{x:1079,y:847,t:1527030448540};\\\", \\\"{x:1086,y:852,t:1527030448556};\\\", \\\"{x:1089,y:855,t:1527030448574};\\\", \\\"{x:1090,y:856,t:1527030448589};\\\", \\\"{x:1091,y:857,t:1527030448607};\\\", \\\"{x:1094,y:864,t:1527030448624};\\\", \\\"{x:1096,y:867,t:1527030448639};\\\", \\\"{x:1114,y:878,t:1527030448656};\\\", \\\"{x:1128,y:881,t:1527030448673};\\\", \\\"{x:1148,y:884,t:1527030448691};\\\", \\\"{x:1165,y:887,t:1527030448706};\\\", \\\"{x:1176,y:889,t:1527030448724};\\\", \\\"{x:1190,y:892,t:1527030448740};\\\", \\\"{x:1211,y:895,t:1527030448756};\\\", \\\"{x:1243,y:897,t:1527030448773};\\\", \\\"{x:1296,y:905,t:1527030448790};\\\", \\\"{x:1338,y:911,t:1527030448806};\\\", \\\"{x:1353,y:913,t:1527030448824};\\\", \\\"{x:1353,y:914,t:1527030448848};\\\", \\\"{x:1352,y:915,t:1527030448857};\\\", \\\"{x:1350,y:915,t:1527030448874};\\\", \\\"{x:1346,y:918,t:1527030448891};\\\", \\\"{x:1342,y:920,t:1527030448906};\\\", \\\"{x:1333,y:925,t:1527030448924};\\\", \\\"{x:1328,y:927,t:1527030448941};\\\", \\\"{x:1327,y:927,t:1527030448958};\\\", \\\"{x:1328,y:925,t:1527030449001};\\\", \\\"{x:1333,y:920,t:1527030449008};\\\", \\\"{x:1343,y:903,t:1527030449024};\\\", \\\"{x:1357,y:881,t:1527030449040};\\\", \\\"{x:1367,y:860,t:1527030449057};\\\", \\\"{x:1376,y:841,t:1527030449074};\\\", \\\"{x:1382,y:825,t:1527030449091};\\\", \\\"{x:1388,y:805,t:1527030449107};\\\", \\\"{x:1394,y:783,t:1527030449123};\\\", \\\"{x:1400,y:762,t:1527030449140};\\\", \\\"{x:1406,y:746,t:1527030449157};\\\", \\\"{x:1417,y:731,t:1527030449173};\\\", \\\"{x:1426,y:719,t:1527030449191};\\\", \\\"{x:1441,y:701,t:1527030449207};\\\", \\\"{x:1451,y:685,t:1527030449223};\\\", \\\"{x:1462,y:660,t:1527030449240};\\\", \\\"{x:1469,y:636,t:1527030449257};\\\", \\\"{x:1474,y:617,t:1527030449273};\\\", \\\"{x:1480,y:596,t:1527030449290};\\\", \\\"{x:1485,y:578,t:1527030449307};\\\", \\\"{x:1487,y:569,t:1527030449324};\\\", \\\"{x:1488,y:565,t:1527030449340};\\\", \\\"{x:1489,y:563,t:1527030449357};\\\", \\\"{x:1487,y:570,t:1527030449408};\\\", \\\"{x:1472,y:606,t:1527030449424};\\\", \\\"{x:1432,y:672,t:1527030449441};\\\", \\\"{x:1367,y:761,t:1527030449458};\\\", \\\"{x:1288,y:842,t:1527030449475};\\\", \\\"{x:1215,y:908,t:1527030449491};\\\", \\\"{x:1151,y:956,t:1527030449507};\\\", \\\"{x:1096,y:991,t:1527030449525};\\\", \\\"{x:1035,y:1017,t:1527030449541};\\\", \\\"{x:966,y:1035,t:1527030449557};\\\", \\\"{x:894,y:1042,t:1527030449575};\\\", \\\"{x:809,y:1040,t:1527030449592};\\\", \\\"{x:752,y:1018,t:1527030449607};\\\", \\\"{x:712,y:995,t:1527030449624};\\\", \\\"{x:681,y:976,t:1527030449641};\\\", \\\"{x:662,y:962,t:1527030449657};\\\", \\\"{x:646,y:953,t:1527030449674};\\\", \\\"{x:626,y:946,t:1527030449691};\\\", \\\"{x:607,y:937,t:1527030449707};\\\", \\\"{x:591,y:926,t:1527030449725};\\\", \\\"{x:574,y:913,t:1527030449741};\\\", \\\"{x:561,y:899,t:1527030449758};\\\", \\\"{x:554,y:883,t:1527030449774};\\\", \\\"{x:548,y:870,t:1527030449792};\\\", \\\"{x:543,y:856,t:1527030449808};\\\", \\\"{x:539,y:846,t:1527030449824};\\\", \\\"{x:536,y:838,t:1527030449842};\\\", \\\"{x:535,y:825,t:1527030449857};\\\", \\\"{x:534,y:809,t:1527030449874};\\\", \\\"{x:533,y:796,t:1527030449891};\\\", \\\"{x:532,y:782,t:1527030449909};\\\", \\\"{x:532,y:775,t:1527030449924};\\\", \\\"{x:529,y:771,t:1527030449941};\\\", \\\"{x:527,y:768,t:1527030449958};\\\", \\\"{x:524,y:765,t:1527030449975};\\\", \\\"{x:518,y:755,t:1527030449991};\\\", \\\"{x:515,y:752,t:1527030450008};\\\", \\\"{x:514,y:751,t:1527030450024};\\\", \\\"{x:512,y:750,t:1527030450041};\\\", \\\"{x:512,y:749,t:1527030450080};\\\", \\\"{x:511,y:748,t:1527030450091};\\\", \\\"{x:511,y:744,t:1527030450108};\\\", \\\"{x:510,y:740,t:1527030450124};\\\", \\\"{x:507,y:736,t:1527030450141};\\\", \\\"{x:506,y:734,t:1527030450158};\\\", \\\"{x:505,y:733,t:1527030450175};\\\", \\\"{x:504,y:732,t:1527030450191};\\\", \\\"{x:502,y:730,t:1527030450272};\\\", \\\"{x:501,y:730,t:1527030450288};\\\", \\\"{x:501,y:729,t:1527030450336};\\\" ] }, { \\\"rt\\\": 18325, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 386933, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -04 PM-04 PM-04 PM-H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:504,y:728,t:1527030451703};\\\", \\\"{x:510,y:728,t:1527030451711};\\\", \\\"{x:521,y:730,t:1527030451733};\\\", \\\"{x:526,y:731,t:1527030451742};\\\", \\\"{x:529,y:731,t:1527030451758};\\\", \\\"{x:530,y:731,t:1527030451815};\\\", \\\"{x:533,y:731,t:1527030451825};\\\", \\\"{x:544,y:731,t:1527030451842};\\\", \\\"{x:549,y:731,t:1527030451859};\\\", \\\"{x:550,y:732,t:1527030451903};\\\", \\\"{x:563,y:733,t:1527030452118};\\\", \\\"{x:566,y:733,t:1527030452126};\\\", \\\"{x:571,y:733,t:1527030452142};\\\", \\\"{x:579,y:733,t:1527030452159};\\\", \\\"{x:585,y:733,t:1527030452176};\\\", \\\"{x:590,y:733,t:1527030452192};\\\", \\\"{x:592,y:733,t:1527030452209};\\\", \\\"{x:593,y:732,t:1527030452226};\\\", \\\"{x:600,y:728,t:1527030452242};\\\", \\\"{x:614,y:718,t:1527030452259};\\\", \\\"{x:630,y:703,t:1527030452277};\\\", \\\"{x:639,y:688,t:1527030452292};\\\", \\\"{x:643,y:671,t:1527030452309};\\\", \\\"{x:638,y:650,t:1527030452327};\\\", \\\"{x:624,y:625,t:1527030452342};\\\", \\\"{x:608,y:583,t:1527030452360};\\\", \\\"{x:600,y:556,t:1527030452377};\\\", \\\"{x:586,y:533,t:1527030452392};\\\", \\\"{x:573,y:515,t:1527030452409};\\\", \\\"{x:558,y:500,t:1527030452427};\\\", \\\"{x:548,y:495,t:1527030452442};\\\", \\\"{x:541,y:491,t:1527030452459};\\\", \\\"{x:532,y:488,t:1527030452475};\\\", \\\"{x:525,y:486,t:1527030452492};\\\", \\\"{x:513,y:481,t:1527030452510};\\\", \\\"{x:500,y:477,t:1527030452525};\\\", \\\"{x:487,y:473,t:1527030452542};\\\", \\\"{x:470,y:473,t:1527030452559};\\\", \\\"{x:457,y:473,t:1527030452576};\\\", \\\"{x:449,y:473,t:1527030452592};\\\", \\\"{x:445,y:473,t:1527030452609};\\\", \\\"{x:438,y:473,t:1527030452626};\\\", \\\"{x:434,y:474,t:1527030452643};\\\", \\\"{x:431,y:474,t:1527030452659};\\\", \\\"{x:430,y:474,t:1527030452676};\\\", \\\"{x:429,y:474,t:1527030452704};\\\", \\\"{x:428,y:475,t:1527030452784};\\\", \\\"{x:428,y:477,t:1527030452792};\\\", \\\"{x:446,y:480,t:1527030452808};\\\", \\\"{x:472,y:484,t:1527030452825};\\\", \\\"{x:522,y:489,t:1527030452842};\\\", \\\"{x:578,y:489,t:1527030452859};\\\", \\\"{x:626,y:491,t:1527030452876};\\\", \\\"{x:648,y:494,t:1527030452891};\\\", \\\"{x:656,y:494,t:1527030452909};\\\", \\\"{x:659,y:495,t:1527030453384};\\\", \\\"{x:664,y:497,t:1527030453392};\\\", \\\"{x:668,y:499,t:1527030453407};\\\", \\\"{x:695,y:504,t:1527030453424};\\\", \\\"{x:719,y:510,t:1527030453441};\\\", \\\"{x:744,y:517,t:1527030453458};\\\", \\\"{x:774,y:527,t:1527030453477};\\\", \\\"{x:815,y:535,t:1527030453493};\\\", \\\"{x:882,y:554,t:1527030453511};\\\", \\\"{x:1014,y:589,t:1527030453527};\\\", \\\"{x:1109,y:619,t:1527030453544};\\\", \\\"{x:1193,y:649,t:1527030453560};\\\", \\\"{x:1254,y:677,t:1527030453576};\\\", \\\"{x:1303,y:705,t:1527030453594};\\\", \\\"{x:1333,y:722,t:1527030453610};\\\", \\\"{x:1351,y:733,t:1527030453626};\\\", \\\"{x:1363,y:742,t:1527030453643};\\\", \\\"{x:1368,y:745,t:1527030453661};\\\", \\\"{x:1371,y:749,t:1527030453676};\\\", \\\"{x:1374,y:754,t:1527030453693};\\\", \\\"{x:1377,y:757,t:1527030453711};\\\", \\\"{x:1382,y:766,t:1527030453729};\\\", \\\"{x:1386,y:772,t:1527030453744};\\\", \\\"{x:1388,y:775,t:1527030453761};\\\", \\\"{x:1390,y:780,t:1527030453776};\\\", \\\"{x:1395,y:788,t:1527030453794};\\\", \\\"{x:1401,y:800,t:1527030453811};\\\", \\\"{x:1412,y:815,t:1527030453827};\\\", \\\"{x:1417,y:824,t:1527030453844};\\\", \\\"{x:1421,y:829,t:1527030453861};\\\", \\\"{x:1422,y:832,t:1527030453877};\\\", \\\"{x:1423,y:833,t:1527030453894};\\\", \\\"{x:1424,y:836,t:1527030453911};\\\", \\\"{x:1424,y:839,t:1527030453927};\\\", \\\"{x:1427,y:846,t:1527030453944};\\\", \\\"{x:1431,y:850,t:1527030453960};\\\", \\\"{x:1431,y:852,t:1527030453977};\\\", \\\"{x:1434,y:855,t:1527030453994};\\\", \\\"{x:1436,y:857,t:1527030454011};\\\", \\\"{x:1441,y:861,t:1527030454027};\\\", \\\"{x:1448,y:866,t:1527030454044};\\\", \\\"{x:1458,y:872,t:1527030454061};\\\", \\\"{x:1471,y:878,t:1527030454077};\\\", \\\"{x:1485,y:886,t:1527030454094};\\\", \\\"{x:1495,y:890,t:1527030454111};\\\", \\\"{x:1501,y:893,t:1527030454127};\\\", \\\"{x:1507,y:896,t:1527030454145};\\\", \\\"{x:1510,y:897,t:1527030454161};\\\", \\\"{x:1513,y:899,t:1527030454178};\\\", \\\"{x:1516,y:902,t:1527030454194};\\\", \\\"{x:1526,y:907,t:1527030454211};\\\", \\\"{x:1533,y:912,t:1527030454227};\\\", \\\"{x:1542,y:915,t:1527030454244};\\\", \\\"{x:1548,y:919,t:1527030454261};\\\", \\\"{x:1552,y:921,t:1527030454277};\\\", \\\"{x:1554,y:922,t:1527030454294};\\\", \\\"{x:1554,y:923,t:1527030454311};\\\", \\\"{x:1557,y:925,t:1527030454327};\\\", \\\"{x:1561,y:929,t:1527030454345};\\\", \\\"{x:1568,y:933,t:1527030454360};\\\", \\\"{x:1575,y:937,t:1527030454378};\\\", \\\"{x:1580,y:939,t:1527030454394};\\\", \\\"{x:1587,y:942,t:1527030454411};\\\", \\\"{x:1590,y:943,t:1527030454427};\\\", \\\"{x:1593,y:945,t:1527030454444};\\\", \\\"{x:1595,y:946,t:1527030454461};\\\", \\\"{x:1601,y:948,t:1527030454477};\\\", \\\"{x:1609,y:951,t:1527030454494};\\\", \\\"{x:1618,y:954,t:1527030454510};\\\", \\\"{x:1626,y:956,t:1527030454527};\\\", \\\"{x:1630,y:956,t:1527030454543};\\\", \\\"{x:1632,y:958,t:1527030454608};\\\", \\\"{x:1634,y:958,t:1527030454623};\\\", \\\"{x:1635,y:959,t:1527030454631};\\\", \\\"{x:1636,y:959,t:1527030454643};\\\", \\\"{x:1638,y:961,t:1527030454660};\\\", \\\"{x:1639,y:962,t:1527030454676};\\\", \\\"{x:1640,y:962,t:1527030454695};\\\", \\\"{x:1640,y:963,t:1527030454935};\\\", \\\"{x:1640,y:964,t:1527030454951};\\\", \\\"{x:1640,y:965,t:1527030454967};\\\", \\\"{x:1640,y:967,t:1527030455553};\\\", \\\"{x:1639,y:968,t:1527030455583};\\\", \\\"{x:1637,y:968,t:1527030455665};\\\", \\\"{x:1636,y:968,t:1527030455688};\\\", \\\"{x:1635,y:969,t:1527030455720};\\\", \\\"{x:1634,y:969,t:1527030455744};\\\", \\\"{x:1629,y:969,t:1527030455760};\\\", \\\"{x:1627,y:969,t:1527030455784};\\\", \\\"{x:1626,y:969,t:1527030455848};\\\", \\\"{x:1624,y:969,t:1527030455860};\\\", \\\"{x:1623,y:969,t:1527030455877};\\\", \\\"{x:1621,y:969,t:1527030455920};\\\", \\\"{x:1620,y:969,t:1527030455927};\\\", \\\"{x:1619,y:969,t:1527030455944};\\\", \\\"{x:1617,y:968,t:1527030455961};\\\", \\\"{x:1616,y:968,t:1527030455984};\\\", \\\"{x:1616,y:967,t:1527030455994};\\\", \\\"{x:1615,y:967,t:1527030456011};\\\", \\\"{x:1615,y:966,t:1527030456027};\\\", \\\"{x:1613,y:965,t:1527030456044};\\\", \\\"{x:1612,y:965,t:1527030456080};\\\", \\\"{x:1611,y:964,t:1527030456097};\\\", \\\"{x:1610,y:963,t:1527030456111};\\\", \\\"{x:1610,y:962,t:1527030456128};\\\", \\\"{x:1606,y:957,t:1527030456144};\\\", \\\"{x:1602,y:953,t:1527030456161};\\\", \\\"{x:1596,y:945,t:1527030456177};\\\", \\\"{x:1589,y:937,t:1527030456194};\\\", \\\"{x:1580,y:926,t:1527030456211};\\\", \\\"{x:1572,y:915,t:1527030456227};\\\", \\\"{x:1566,y:904,t:1527030456244};\\\", \\\"{x:1561,y:893,t:1527030456261};\\\", \\\"{x:1556,y:880,t:1527030456277};\\\", \\\"{x:1550,y:864,t:1527030456294};\\\", \\\"{x:1546,y:846,t:1527030456311};\\\", \\\"{x:1538,y:827,t:1527030456327};\\\", \\\"{x:1521,y:794,t:1527030456344};\\\", \\\"{x:1501,y:762,t:1527030456360};\\\", \\\"{x:1480,y:733,t:1527030456377};\\\", \\\"{x:1469,y:712,t:1527030456394};\\\", \\\"{x:1461,y:693,t:1527030456411};\\\", \\\"{x:1458,y:679,t:1527030456427};\\\", \\\"{x:1453,y:662,t:1527030456444};\\\", \\\"{x:1448,y:649,t:1527030456461};\\\", \\\"{x:1441,y:635,t:1527030456478};\\\", \\\"{x:1436,y:627,t:1527030456494};\\\", \\\"{x:1434,y:619,t:1527030456511};\\\", \\\"{x:1432,y:615,t:1527030456527};\\\", \\\"{x:1432,y:611,t:1527030456544};\\\", \\\"{x:1431,y:609,t:1527030456561};\\\", \\\"{x:1431,y:608,t:1527030456577};\\\", \\\"{x:1431,y:606,t:1527030456594};\\\", \\\"{x:1429,y:601,t:1527030456611};\\\", \\\"{x:1428,y:594,t:1527030456627};\\\", \\\"{x:1426,y:590,t:1527030456644};\\\", \\\"{x:1424,y:586,t:1527030456661};\\\", \\\"{x:1423,y:584,t:1527030456677};\\\", \\\"{x:1423,y:583,t:1527030456695};\\\", \\\"{x:1421,y:583,t:1527030456710};\\\", \\\"{x:1420,y:582,t:1527030456727};\\\", \\\"{x:1404,y:580,t:1527030456744};\\\", \\\"{x:1379,y:579,t:1527030456760};\\\", \\\"{x:1340,y:576,t:1527030456777};\\\", \\\"{x:1290,y:570,t:1527030456794};\\\", \\\"{x:1228,y:569,t:1527030456810};\\\", \\\"{x:1155,y:565,t:1527030456827};\\\", \\\"{x:1097,y:565,t:1527030456844};\\\", \\\"{x:1029,y:562,t:1527030456860};\\\", \\\"{x:973,y:562,t:1527030456877};\\\", \\\"{x:933,y:562,t:1527030456894};\\\", \\\"{x:908,y:562,t:1527030456910};\\\", \\\"{x:885,y:562,t:1527030456925};\\\", \\\"{x:865,y:562,t:1527030456941};\\\", \\\"{x:847,y:562,t:1527030456958};\\\", \\\"{x:828,y:562,t:1527030456975};\\\", \\\"{x:802,y:562,t:1527030456996};\\\", \\\"{x:791,y:562,t:1527030457013};\\\", \\\"{x:782,y:563,t:1527030457029};\\\", \\\"{x:775,y:564,t:1527030457046};\\\", \\\"{x:755,y:564,t:1527030457063};\\\", \\\"{x:733,y:564,t:1527030457079};\\\", \\\"{x:706,y:564,t:1527030457098};\\\", \\\"{x:676,y:564,t:1527030457113};\\\", \\\"{x:646,y:564,t:1527030457129};\\\", \\\"{x:620,y:564,t:1527030457147};\\\", \\\"{x:595,y:565,t:1527030457164};\\\", \\\"{x:572,y:565,t:1527030457179};\\\", \\\"{x:549,y:565,t:1527030457196};\\\", \\\"{x:526,y:570,t:1527030457213};\\\", \\\"{x:508,y:573,t:1527030457229};\\\", \\\"{x:488,y:575,t:1527030457247};\\\", \\\"{x:466,y:579,t:1527030457263};\\\", \\\"{x:457,y:580,t:1527030457279};\\\", \\\"{x:448,y:583,t:1527030457298};\\\", \\\"{x:446,y:583,t:1527030457314};\\\", \\\"{x:442,y:583,t:1527030457329};\\\", \\\"{x:437,y:584,t:1527030457346};\\\", \\\"{x:430,y:585,t:1527030457363};\\\", \\\"{x:422,y:585,t:1527030457379};\\\", \\\"{x:419,y:587,t:1527030457396};\\\", \\\"{x:418,y:587,t:1527030457447};\\\", \\\"{x:419,y:587,t:1527030457536};\\\", \\\"{x:427,y:587,t:1527030457547};\\\", \\\"{x:452,y:590,t:1527030457564};\\\", \\\"{x:480,y:592,t:1527030457580};\\\", \\\"{x:507,y:592,t:1527030457598};\\\", \\\"{x:525,y:592,t:1527030457614};\\\", \\\"{x:532,y:592,t:1527030457630};\\\", \\\"{x:535,y:592,t:1527030457647};\\\", \\\"{x:538,y:592,t:1527030457663};\\\", \\\"{x:547,y:592,t:1527030457680};\\\", \\\"{x:570,y:592,t:1527030457697};\\\", \\\"{x:591,y:592,t:1527030457713};\\\", \\\"{x:601,y:592,t:1527030457730};\\\", \\\"{x:604,y:592,t:1527030457748};\\\", \\\"{x:605,y:591,t:1527030457808};\\\", \\\"{x:605,y:590,t:1527030457815};\\\", \\\"{x:606,y:589,t:1527030457831};\\\", \\\"{x:606,y:587,t:1527030457847};\\\", \\\"{x:606,y:585,t:1527030457863};\\\", \\\"{x:607,y:584,t:1527030457881};\\\", \\\"{x:607,y:582,t:1527030457897};\\\", \\\"{x:607,y:581,t:1527030457915};\\\", \\\"{x:607,y:579,t:1527030457931};\\\", \\\"{x:607,y:578,t:1527030457947};\\\", \\\"{x:607,y:575,t:1527030457964};\\\", \\\"{x:607,y:574,t:1527030457982};\\\", \\\"{x:607,y:572,t:1527030457997};\\\", \\\"{x:607,y:571,t:1527030458013};\\\", \\\"{x:608,y:570,t:1527030458032};\\\", \\\"{x:608,y:569,t:1527030458047};\\\", \\\"{x:621,y:569,t:1527030458594};\\\", \\\"{x:690,y:596,t:1527030458616};\\\", \\\"{x:802,y:637,t:1527030458631};\\\", \\\"{x:986,y:696,t:1527030458648};\\\", \\\"{x:1101,y:740,t:1527030458665};\\\", \\\"{x:1188,y:773,t:1527030458682};\\\", \\\"{x:1257,y:814,t:1527030458698};\\\", \\\"{x:1309,y:844,t:1527030458714};\\\", \\\"{x:1344,y:864,t:1527030458732};\\\", \\\"{x:1369,y:881,t:1527030458748};\\\", \\\"{x:1396,y:897,t:1527030458765};\\\", \\\"{x:1416,y:911,t:1527030458782};\\\", \\\"{x:1439,y:924,t:1527030458798};\\\", \\\"{x:1457,y:937,t:1527030458815};\\\", \\\"{x:1467,y:944,t:1527030458832};\\\", \\\"{x:1468,y:946,t:1527030458848};\\\", \\\"{x:1469,y:947,t:1527030458865};\\\", \\\"{x:1470,y:947,t:1527030458882};\\\", \\\"{x:1473,y:950,t:1527030458898};\\\", \\\"{x:1476,y:953,t:1527030458915};\\\", \\\"{x:1479,y:954,t:1527030458932};\\\", \\\"{x:1483,y:955,t:1527030458948};\\\", \\\"{x:1486,y:956,t:1527030458965};\\\", \\\"{x:1490,y:957,t:1527030458982};\\\", \\\"{x:1493,y:958,t:1527030458998};\\\", \\\"{x:1496,y:958,t:1527030459015};\\\", \\\"{x:1504,y:960,t:1527030459032};\\\", \\\"{x:1507,y:960,t:1527030459048};\\\", \\\"{x:1516,y:960,t:1527030459065};\\\", \\\"{x:1528,y:960,t:1527030459082};\\\", \\\"{x:1540,y:959,t:1527030459099};\\\", \\\"{x:1545,y:958,t:1527030459116};\\\", \\\"{x:1548,y:956,t:1527030459133};\\\", \\\"{x:1548,y:955,t:1527030459168};\\\", \\\"{x:1550,y:955,t:1527030459184};\\\", \\\"{x:1551,y:955,t:1527030459199};\\\", \\\"{x:1554,y:955,t:1527030459215};\\\", \\\"{x:1559,y:953,t:1527030459232};\\\", \\\"{x:1561,y:953,t:1527030459249};\\\", \\\"{x:1563,y:953,t:1527030459265};\\\", \\\"{x:1564,y:953,t:1527030459304};\\\", \\\"{x:1566,y:953,t:1527030459320};\\\", \\\"{x:1569,y:953,t:1527030459336};\\\", \\\"{x:1571,y:953,t:1527030459349};\\\", \\\"{x:1578,y:953,t:1527030459365};\\\", \\\"{x:1586,y:953,t:1527030459382};\\\", \\\"{x:1588,y:953,t:1527030459399};\\\", \\\"{x:1589,y:953,t:1527030459415};\\\", \\\"{x:1591,y:953,t:1527030459480};\\\", \\\"{x:1593,y:955,t:1527030459487};\\\", \\\"{x:1594,y:955,t:1527030459499};\\\", \\\"{x:1599,y:957,t:1527030459515};\\\", \\\"{x:1602,y:959,t:1527030459531};\\\", \\\"{x:1603,y:960,t:1527030459548};\\\", \\\"{x:1604,y:961,t:1527030459566};\\\", \\\"{x:1604,y:962,t:1527030459583};\\\", \\\"{x:1605,y:963,t:1527030459599};\\\", \\\"{x:1606,y:965,t:1527030459616};\\\", \\\"{x:1607,y:967,t:1527030459631};\\\", \\\"{x:1608,y:969,t:1527030459649};\\\", \\\"{x:1609,y:970,t:1527030459666};\\\", \\\"{x:1610,y:971,t:1527030459682};\\\", \\\"{x:1611,y:973,t:1527030459698};\\\", \\\"{x:1612,y:973,t:1527030459736};\\\", \\\"{x:1613,y:973,t:1527030459749};\\\", \\\"{x:1614,y:973,t:1527030459766};\\\", \\\"{x:1616,y:973,t:1527030459782};\\\", \\\"{x:1617,y:973,t:1527030459800};\\\", \\\"{x:1619,y:973,t:1527030459816};\\\", \\\"{x:1619,y:972,t:1527030459832};\\\", \\\"{x:1619,y:970,t:1527030459849};\\\", \\\"{x:1619,y:969,t:1527030459866};\\\", \\\"{x:1619,y:967,t:1527030459883};\\\", \\\"{x:1619,y:964,t:1527030459899};\\\", \\\"{x:1619,y:960,t:1527030459916};\\\", \\\"{x:1619,y:956,t:1527030459932};\\\", \\\"{x:1619,y:950,t:1527030459949};\\\", \\\"{x:1616,y:939,t:1527030459965};\\\", \\\"{x:1611,y:930,t:1527030459982};\\\", \\\"{x:1606,y:919,t:1527030459998};\\\", \\\"{x:1599,y:905,t:1527030460016};\\\", \\\"{x:1594,y:898,t:1527030460032};\\\", \\\"{x:1590,y:890,t:1527030460049};\\\", \\\"{x:1583,y:881,t:1527030460066};\\\", \\\"{x:1573,y:867,t:1527030460082};\\\", \\\"{x:1564,y:856,t:1527030460099};\\\", \\\"{x:1556,y:845,t:1527030460116};\\\", \\\"{x:1547,y:835,t:1527030460133};\\\", \\\"{x:1541,y:827,t:1527030460149};\\\", \\\"{x:1537,y:821,t:1527030460166};\\\", \\\"{x:1533,y:815,t:1527030460183};\\\", \\\"{x:1529,y:807,t:1527030460199};\\\", \\\"{x:1519,y:796,t:1527030460216};\\\", \\\"{x:1513,y:787,t:1527030460233};\\\", \\\"{x:1509,y:780,t:1527030460249};\\\", \\\"{x:1505,y:772,t:1527030460266};\\\", \\\"{x:1500,y:763,t:1527030460284};\\\", \\\"{x:1496,y:754,t:1527030460300};\\\", \\\"{x:1492,y:748,t:1527030460317};\\\", \\\"{x:1487,y:740,t:1527030460334};\\\", \\\"{x:1484,y:733,t:1527030460349};\\\", \\\"{x:1481,y:729,t:1527030460367};\\\", \\\"{x:1477,y:723,t:1527030460383};\\\", \\\"{x:1475,y:720,t:1527030460400};\\\", \\\"{x:1475,y:719,t:1527030460473};\\\", \\\"{x:1475,y:718,t:1527030460529};\\\", \\\"{x:1475,y:717,t:1527030460544};\\\", \\\"{x:1473,y:715,t:1527030461800};\\\", \\\"{x:1470,y:709,t:1527030461817};\\\", \\\"{x:1469,y:708,t:1527030461834};\\\", \\\"{x:1469,y:707,t:1527030461851};\\\", \\\"{x:1468,y:706,t:1527030461872};\\\", \\\"{x:1467,y:705,t:1527030461888};\\\", \\\"{x:1467,y:704,t:1527030461904};\\\", \\\"{x:1467,y:703,t:1527030461917};\\\", \\\"{x:1466,y:701,t:1527030461935};\\\", \\\"{x:1465,y:697,t:1527030461951};\\\", \\\"{x:1464,y:693,t:1527030461968};\\\", \\\"{x:1464,y:692,t:1527030461984};\\\", \\\"{x:1463,y:690,t:1527030462002};\\\", \\\"{x:1462,y:687,t:1527030462032};\\\", \\\"{x:1462,y:686,t:1527030462039};\\\", \\\"{x:1461,y:684,t:1527030462051};\\\", \\\"{x:1460,y:679,t:1527030462068};\\\", \\\"{x:1458,y:674,t:1527030462084};\\\", \\\"{x:1457,y:669,t:1527030462101};\\\", \\\"{x:1453,y:664,t:1527030462118};\\\", \\\"{x:1448,y:659,t:1527030462134};\\\", \\\"{x:1445,y:656,t:1527030462151};\\\", \\\"{x:1440,y:649,t:1527030462168};\\\", \\\"{x:1436,y:644,t:1527030462184};\\\", \\\"{x:1434,y:640,t:1527030462201};\\\", \\\"{x:1429,y:635,t:1527030462219};\\\", \\\"{x:1426,y:630,t:1527030462235};\\\", \\\"{x:1424,y:628,t:1527030462252};\\\", \\\"{x:1424,y:626,t:1527030462268};\\\", \\\"{x:1422,y:624,t:1527030462285};\\\", \\\"{x:1420,y:622,t:1527030462301};\\\", \\\"{x:1419,y:622,t:1527030462318};\\\", \\\"{x:1419,y:619,t:1527030462334};\\\", \\\"{x:1416,y:614,t:1527030462352};\\\", \\\"{x:1413,y:606,t:1527030462368};\\\", \\\"{x:1411,y:602,t:1527030462386};\\\", \\\"{x:1409,y:597,t:1527030462401};\\\", \\\"{x:1408,y:595,t:1527030462418};\\\", \\\"{x:1407,y:589,t:1527030462435};\\\", \\\"{x:1404,y:585,t:1527030462452};\\\", \\\"{x:1403,y:580,t:1527030462469};\\\", \\\"{x:1401,y:576,t:1527030462485};\\\", \\\"{x:1400,y:573,t:1527030462502};\\\", \\\"{x:1399,y:571,t:1527030462518};\\\", \\\"{x:1398,y:569,t:1527030462535};\\\", \\\"{x:1397,y:567,t:1527030462560};\\\", \\\"{x:1398,y:567,t:1527030463448};\\\", \\\"{x:1399,y:567,t:1527030463456};\\\", \\\"{x:1400,y:567,t:1527030463504};\\\", \\\"{x:1400,y:569,t:1527030463519};\\\", \\\"{x:1401,y:569,t:1527030463553};\\\", \\\"{x:1401,y:573,t:1527030466977};\\\", \\\"{x:1408,y:584,t:1527030466988};\\\", \\\"{x:1424,y:611,t:1527030467005};\\\", \\\"{x:1435,y:630,t:1527030467022};\\\", \\\"{x:1442,y:645,t:1527030467038};\\\", \\\"{x:1449,y:659,t:1527030467055};\\\", \\\"{x:1449,y:665,t:1527030467072};\\\", \\\"{x:1451,y:673,t:1527030467088};\\\", \\\"{x:1455,y:683,t:1527030467105};\\\", \\\"{x:1460,y:696,t:1527030467122};\\\", \\\"{x:1466,y:707,t:1527030467138};\\\", \\\"{x:1473,y:718,t:1527030467155};\\\", \\\"{x:1479,y:727,t:1527030467173};\\\", \\\"{x:1490,y:738,t:1527030467189};\\\", \\\"{x:1501,y:748,t:1527030467205};\\\", \\\"{x:1510,y:758,t:1527030467223};\\\", \\\"{x:1519,y:769,t:1527030467238};\\\", \\\"{x:1529,y:786,t:1527030467256};\\\", \\\"{x:1534,y:793,t:1527030467272};\\\", \\\"{x:1537,y:798,t:1527030467289};\\\", \\\"{x:1539,y:802,t:1527030467306};\\\", \\\"{x:1542,y:808,t:1527030467322};\\\", \\\"{x:1545,y:817,t:1527030467339};\\\", \\\"{x:1547,y:829,t:1527030467356};\\\", \\\"{x:1548,y:840,t:1527030467373};\\\", \\\"{x:1552,y:851,t:1527030467389};\\\", \\\"{x:1556,y:862,t:1527030467405};\\\", \\\"{x:1560,y:874,t:1527030467422};\\\", \\\"{x:1573,y:894,t:1527030467439};\\\", \\\"{x:1586,y:908,t:1527030467455};\\\", \\\"{x:1599,y:921,t:1527030467472};\\\", \\\"{x:1608,y:933,t:1527030467489};\\\", \\\"{x:1615,y:942,t:1527030467505};\\\", \\\"{x:1625,y:953,t:1527030467522};\\\", \\\"{x:1638,y:966,t:1527030467539};\\\", \\\"{x:1650,y:979,t:1527030467555};\\\", \\\"{x:1662,y:990,t:1527030467572};\\\", \\\"{x:1674,y:1001,t:1527030467589};\\\", \\\"{x:1679,y:1006,t:1527030467605};\\\", \\\"{x:1681,y:1008,t:1527030467623};\\\", \\\"{x:1679,y:1008,t:1527030467727};\\\", \\\"{x:1675,y:1008,t:1527030467739};\\\", \\\"{x:1671,y:1007,t:1527030467756};\\\", \\\"{x:1668,y:1006,t:1527030467772};\\\", \\\"{x:1666,y:1005,t:1527030467791};\\\", \\\"{x:1665,y:1004,t:1527030467807};\\\", \\\"{x:1662,y:1003,t:1527030467822};\\\", \\\"{x:1654,y:998,t:1527030467839};\\\", \\\"{x:1651,y:995,t:1527030467855};\\\", \\\"{x:1648,y:993,t:1527030467872};\\\", \\\"{x:1646,y:992,t:1527030467890};\\\", \\\"{x:1645,y:990,t:1527030467906};\\\", \\\"{x:1644,y:990,t:1527030467922};\\\", \\\"{x:1643,y:989,t:1527030467939};\\\", \\\"{x:1641,y:988,t:1527030467956};\\\", \\\"{x:1639,y:986,t:1527030467973};\\\", \\\"{x:1636,y:983,t:1527030467989};\\\", \\\"{x:1634,y:982,t:1527030468006};\\\", \\\"{x:1632,y:980,t:1527030468022};\\\", \\\"{x:1629,y:977,t:1527030468040};\\\", \\\"{x:1629,y:976,t:1527030468056};\\\", \\\"{x:1626,y:972,t:1527030468072};\\\", \\\"{x:1622,y:965,t:1527030468090};\\\", \\\"{x:1617,y:954,t:1527030468106};\\\", \\\"{x:1613,y:946,t:1527030468123};\\\", \\\"{x:1610,y:940,t:1527030468140};\\\", \\\"{x:1608,y:936,t:1527030468157};\\\", \\\"{x:1607,y:932,t:1527030468174};\\\", \\\"{x:1607,y:930,t:1527030468190};\\\", \\\"{x:1605,y:927,t:1527030468206};\\\", \\\"{x:1604,y:921,t:1527030468224};\\\", \\\"{x:1602,y:916,t:1527030468240};\\\", \\\"{x:1600,y:908,t:1527030468257};\\\", \\\"{x:1596,y:898,t:1527030468274};\\\", \\\"{x:1591,y:884,t:1527030468289};\\\", \\\"{x:1586,y:872,t:1527030468307};\\\", \\\"{x:1577,y:851,t:1527030468324};\\\", \\\"{x:1571,y:832,t:1527030468340};\\\", \\\"{x:1565,y:810,t:1527030468356};\\\", \\\"{x:1554,y:783,t:1527030468374};\\\", \\\"{x:1545,y:759,t:1527030468390};\\\", \\\"{x:1535,y:731,t:1527030468406};\\\", \\\"{x:1510,y:680,t:1527030468424};\\\", \\\"{x:1495,y:657,t:1527030468440};\\\", \\\"{x:1480,y:636,t:1527030468456};\\\", \\\"{x:1467,y:619,t:1527030468474};\\\", \\\"{x:1451,y:601,t:1527030468489};\\\", \\\"{x:1439,y:587,t:1527030468507};\\\", \\\"{x:1424,y:571,t:1527030468523};\\\", \\\"{x:1409,y:564,t:1527030468541};\\\", \\\"{x:1388,y:557,t:1527030468558};\\\", \\\"{x:1358,y:551,t:1527030468573};\\\", \\\"{x:1315,y:548,t:1527030468591};\\\", \\\"{x:1251,y:548,t:1527030468606};\\\", \\\"{x:1133,y:560,t:1527030468624};\\\", \\\"{x:1067,y:580,t:1527030468640};\\\", \\\"{x:997,y:601,t:1527030468657};\\\", \\\"{x:933,y:618,t:1527030468674};\\\", \\\"{x:892,y:636,t:1527030468691};\\\", \\\"{x:852,y:649,t:1527030468706};\\\", \\\"{x:806,y:664,t:1527030468724};\\\", \\\"{x:756,y:689,t:1527030468740};\\\", \\\"{x:704,y:710,t:1527030468756};\\\", \\\"{x:655,y:729,t:1527030468774};\\\", \\\"{x:605,y:743,t:1527030468790};\\\", \\\"{x:573,y:751,t:1527030468806};\\\", \\\"{x:545,y:755,t:1527030468824};\\\", \\\"{x:541,y:755,t:1527030468840};\\\", \\\"{x:540,y:755,t:1527030468857};\\\", \\\"{x:539,y:755,t:1527030468873};\\\", \\\"{x:538,y:755,t:1527030468891};\\\", \\\"{x:537,y:755,t:1527030468906};\\\", \\\"{x:536,y:755,t:1527030468924};\\\", \\\"{x:535,y:755,t:1527030468944};\\\", \\\"{x:534,y:755,t:1527030468956};\\\", \\\"{x:532,y:754,t:1527030468975};\\\", \\\"{x:530,y:752,t:1527030468990};\\\", \\\"{x:530,y:749,t:1527030469008};\\\", \\\"{x:530,y:747,t:1527030469024};\\\", \\\"{x:528,y:744,t:1527030469040};\\\", \\\"{x:527,y:742,t:1527030469057};\\\", \\\"{x:527,y:741,t:1527030469079};\\\", \\\"{x:527,y:740,t:1527030469103};\\\", \\\"{x:527,y:739,t:1527030469136};\\\", \\\"{x:526,y:738,t:1527030469151};\\\", \\\"{x:525,y:738,t:1527030469192};\\\", \\\"{x:525,y:737,t:1527030469207};\\\", \\\"{x:525,y:736,t:1527030469224};\\\", \\\"{x:525,y:733,t:1527030469242};\\\", \\\"{x:524,y:731,t:1527030469257};\\\", \\\"{x:524,y:730,t:1527030469273};\\\", \\\"{x:524,y:729,t:1527030469287};\\\", \\\"{x:524,y:728,t:1527030469327};\\\", \\\"{x:524,y:727,t:1527030469367};\\\", \\\"{x:524,y:726,t:1527030469375};\\\", \\\"{x:524,y:725,t:1527030469388};\\\", \\\"{x:524,y:724,t:1527030469404};\\\", \\\"{x:524,y:723,t:1527030469432};\\\" ] }, { \\\"rt\\\": 21274, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 409438, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -O -O -O -O -O -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:721,t:1527030471584};\\\", \\\"{x:522,y:710,t:1527030471592};\\\", \\\"{x:512,y:550,t:1527030471680};\\\", \\\"{x:508,y:530,t:1527030471691};\\\", \\\"{x:505,y:517,t:1527030471708};\\\", \\\"{x:501,y:504,t:1527030471725};\\\", \\\"{x:498,y:494,t:1527030471742};\\\", \\\"{x:496,y:486,t:1527030471758};\\\", \\\"{x:493,y:479,t:1527030471775};\\\", \\\"{x:492,y:475,t:1527030471792};\\\", \\\"{x:491,y:475,t:1527030471808};\\\", \\\"{x:486,y:472,t:1527030471825};\\\", \\\"{x:480,y:470,t:1527030471842};\\\", \\\"{x:478,y:470,t:1527030471858};\\\", \\\"{x:476,y:469,t:1527030471875};\\\", \\\"{x:473,y:468,t:1527030471893};\\\", \\\"{x:467,y:467,t:1527030471908};\\\", \\\"{x:461,y:467,t:1527030471925};\\\", \\\"{x:456,y:466,t:1527030471943};\\\", \\\"{x:453,y:465,t:1527030471959};\\\", \\\"{x:449,y:464,t:1527030471975};\\\", \\\"{x:444,y:463,t:1527030471993};\\\", \\\"{x:442,y:463,t:1527030472009};\\\", \\\"{x:440,y:463,t:1527030472026};\\\", \\\"{x:439,y:463,t:1527030472105};\\\", \\\"{x:439,y:462,t:1527030472112};\\\", \\\"{x:442,y:461,t:1527030472125};\\\", \\\"{x:461,y:459,t:1527030472143};\\\", \\\"{x:501,y:459,t:1527030472160};\\\", \\\"{x:518,y:459,t:1527030472176};\\\", \\\"{x:525,y:459,t:1527030472192};\\\", \\\"{x:528,y:459,t:1527030472209};\\\", \\\"{x:530,y:459,t:1527030472225};\\\", \\\"{x:535,y:459,t:1527030472242};\\\", \\\"{x:549,y:459,t:1527030472260};\\\", \\\"{x:568,y:459,t:1527030472276};\\\", \\\"{x:582,y:459,t:1527030472293};\\\", \\\"{x:588,y:459,t:1527030472310};\\\", \\\"{x:591,y:459,t:1527030472327};\\\", \\\"{x:592,y:459,t:1527030472342};\\\", \\\"{x:600,y:457,t:1527030472360};\\\", \\\"{x:610,y:456,t:1527030472376};\\\", \\\"{x:630,y:454,t:1527030472392};\\\", \\\"{x:651,y:451,t:1527030472410};\\\", \\\"{x:668,y:449,t:1527030472426};\\\", \\\"{x:681,y:447,t:1527030472442};\\\", \\\"{x:685,y:446,t:1527030472460};\\\", \\\"{x:689,y:445,t:1527030472477};\\\", \\\"{x:696,y:443,t:1527030472492};\\\", \\\"{x:701,y:442,t:1527030472509};\\\", \\\"{x:707,y:441,t:1527030472527};\\\", \\\"{x:708,y:440,t:1527030472542};\\\", \\\"{x:710,y:440,t:1527030472559};\\\", \\\"{x:711,y:440,t:1527030472576};\\\", \\\"{x:711,y:439,t:1527030472592};\\\", \\\"{x:713,y:439,t:1527030472928};\\\", \\\"{x:715,y:439,t:1527030472944};\\\", \\\"{x:717,y:439,t:1527030472961};\\\", \\\"{x:718,y:439,t:1527030472976};\\\", \\\"{x:720,y:439,t:1527030473016};\\\", \\\"{x:719,y:439,t:1527030473392};\\\", \\\"{x:718,y:439,t:1527030473400};\\\", \\\"{x:717,y:439,t:1527030473416};\\\", \\\"{x:714,y:439,t:1527030473428};\\\", \\\"{x:706,y:439,t:1527030473444};\\\", \\\"{x:698,y:439,t:1527030473461};\\\", \\\"{x:684,y:440,t:1527030473477};\\\", \\\"{x:677,y:440,t:1527030473494};\\\", \\\"{x:671,y:440,t:1527030473511};\\\", \\\"{x:669,y:440,t:1527030473527};\\\", \\\"{x:668,y:442,t:1527030473672};\\\", \\\"{x:666,y:443,t:1527030473680};\\\", \\\"{x:665,y:443,t:1527030473695};\\\", \\\"{x:663,y:443,t:1527030473728};\\\", \\\"{x:663,y:444,t:1527030473745};\\\", \\\"{x:661,y:444,t:1527030473768};\\\", \\\"{x:661,y:445,t:1527030473778};\\\", \\\"{x:657,y:446,t:1527030473795};\\\", \\\"{x:653,y:446,t:1527030473811};\\\", \\\"{x:651,y:447,t:1527030473828};\\\", \\\"{x:650,y:448,t:1527030473845};\\\", \\\"{x:649,y:448,t:1527030473861};\\\", \\\"{x:650,y:448,t:1527030475152};\\\", \\\"{x:651,y:448,t:1527030475168};\\\", \\\"{x:652,y:448,t:1527030475184};\\\", \\\"{x:656,y:448,t:1527030475195};\\\", \\\"{x:663,y:448,t:1527030475213};\\\", \\\"{x:671,y:448,t:1527030475230};\\\", \\\"{x:684,y:448,t:1527030475245};\\\", \\\"{x:696,y:448,t:1527030475263};\\\", \\\"{x:714,y:448,t:1527030475280};\\\", \\\"{x:718,y:448,t:1527030475296};\\\", \\\"{x:719,y:448,t:1527030475496};\\\", \\\"{x:721,y:449,t:1527030475512};\\\", \\\"{x:721,y:451,t:1527030475529};\\\", \\\"{x:722,y:453,t:1527030477400};\\\", \\\"{x:729,y:457,t:1527030477415};\\\", \\\"{x:752,y:466,t:1527030477431};\\\", \\\"{x:767,y:469,t:1527030477448};\\\", \\\"{x:783,y:469,t:1527030477465};\\\", \\\"{x:799,y:469,t:1527030477482};\\\", \\\"{x:819,y:469,t:1527030477498};\\\", \\\"{x:848,y:466,t:1527030477515};\\\", \\\"{x:880,y:463,t:1527030477532};\\\", \\\"{x:934,y:460,t:1527030477549};\\\", \\\"{x:1001,y:460,t:1527030477565};\\\", \\\"{x:1057,y:460,t:1527030477582};\\\", \\\"{x:1102,y:460,t:1527030477599};\\\", \\\"{x:1130,y:460,t:1527030477615};\\\", \\\"{x:1155,y:460,t:1527030477632};\\\", \\\"{x:1164,y:460,t:1527030477649};\\\", \\\"{x:1174,y:459,t:1527030477665};\\\", \\\"{x:1195,y:459,t:1527030477682};\\\", \\\"{x:1234,y:459,t:1527030477699};\\\", \\\"{x:1295,y:467,t:1527030477716};\\\", \\\"{x:1336,y:471,t:1527030477732};\\\", \\\"{x:1355,y:471,t:1527030477749};\\\", \\\"{x:1358,y:471,t:1527030477765};\\\", \\\"{x:1358,y:473,t:1527030477976};\\\", \\\"{x:1357,y:473,t:1527030477992};\\\", \\\"{x:1356,y:474,t:1527030478000};\\\", \\\"{x:1354,y:475,t:1527030478024};\\\", \\\"{x:1352,y:475,t:1527030478032};\\\", \\\"{x:1349,y:478,t:1527030478049};\\\", \\\"{x:1344,y:478,t:1527030478065};\\\", \\\"{x:1341,y:480,t:1527030478082};\\\", \\\"{x:1339,y:480,t:1527030478098};\\\", \\\"{x:1338,y:480,t:1527030478116};\\\", \\\"{x:1336,y:480,t:1527030478133};\\\", \\\"{x:1336,y:481,t:1527030478148};\\\", \\\"{x:1335,y:481,t:1527030478165};\\\", \\\"{x:1334,y:481,t:1527030478183};\\\", \\\"{x:1334,y:482,t:1527030478352};\\\", \\\"{x:1333,y:483,t:1527030478366};\\\", \\\"{x:1331,y:484,t:1527030478383};\\\", \\\"{x:1329,y:486,t:1527030478400};\\\", \\\"{x:1328,y:486,t:1527030478440};\\\", \\\"{x:1327,y:487,t:1527030478450};\\\", \\\"{x:1326,y:487,t:1527030478496};\\\", \\\"{x:1325,y:487,t:1527030478528};\\\", \\\"{x:1325,y:488,t:1527030478535};\\\", \\\"{x:1324,y:488,t:1527030478550};\\\", \\\"{x:1323,y:488,t:1527030478566};\\\", \\\"{x:1321,y:489,t:1527030478583};\\\", \\\"{x:1320,y:490,t:1527030479321};\\\", \\\"{x:1318,y:492,t:1527030479658};\\\", \\\"{x:1316,y:494,t:1527030479668};\\\", \\\"{x:1312,y:496,t:1527030479684};\\\", \\\"{x:1310,y:497,t:1527030479701};\\\", \\\"{x:1306,y:497,t:1527030479719};\\\", \\\"{x:1305,y:498,t:1527030479734};\\\", \\\"{x:1302,y:498,t:1527030479751};\\\", \\\"{x:1292,y:500,t:1527030479767};\\\", \\\"{x:1288,y:500,t:1527030479783};\\\", \\\"{x:1279,y:501,t:1527030479801};\\\", \\\"{x:1274,y:502,t:1527030479818};\\\", \\\"{x:1271,y:502,t:1527030479834};\\\", \\\"{x:1269,y:503,t:1527030480240};\\\", \\\"{x:1267,y:504,t:1527030480264};\\\", \\\"{x:1266,y:504,t:1527030480271};\\\", \\\"{x:1262,y:505,t:1527030480284};\\\", \\\"{x:1257,y:505,t:1527030480302};\\\", \\\"{x:1249,y:508,t:1527030480318};\\\", \\\"{x:1241,y:510,t:1527030480335};\\\", \\\"{x:1237,y:512,t:1527030480350};\\\", \\\"{x:1233,y:513,t:1527030480367};\\\", \\\"{x:1232,y:513,t:1527030480385};\\\", \\\"{x:1230,y:515,t:1527030480401};\\\", \\\"{x:1233,y:515,t:1527030480552};\\\", \\\"{x:1234,y:514,t:1527030480569};\\\", \\\"{x:1236,y:514,t:1527030480599};\\\", \\\"{x:1237,y:514,t:1527030480656};\\\", \\\"{x:1239,y:514,t:1527030480669};\\\", \\\"{x:1243,y:514,t:1527030480685};\\\", \\\"{x:1248,y:514,t:1527030480702};\\\", \\\"{x:1259,y:514,t:1527030480719};\\\", \\\"{x:1268,y:514,t:1527030480735};\\\", \\\"{x:1277,y:514,t:1527030480752};\\\", \\\"{x:1281,y:514,t:1527030480769};\\\", \\\"{x:1282,y:514,t:1527030480785};\\\", \\\"{x:1283,y:514,t:1527030480802};\\\", \\\"{x:1284,y:514,t:1527030480819};\\\", \\\"{x:1287,y:512,t:1527030480834};\\\", \\\"{x:1291,y:512,t:1527030480851};\\\", \\\"{x:1292,y:512,t:1527030480871};\\\", \\\"{x:1294,y:510,t:1527030481111};\\\", \\\"{x:1295,y:508,t:1527030481118};\\\", \\\"{x:1297,y:504,t:1527030481135};\\\", \\\"{x:1299,y:502,t:1527030481151};\\\", \\\"{x:1301,y:500,t:1527030481169};\\\", \\\"{x:1302,y:498,t:1527030481185};\\\", \\\"{x:1303,y:497,t:1527030481202};\\\", \\\"{x:1306,y:495,t:1527030481448};\\\", \\\"{x:1308,y:495,t:1527030481456};\\\", \\\"{x:1313,y:493,t:1527030481470};\\\", \\\"{x:1316,y:492,t:1527030481486};\\\", \\\"{x:1319,y:491,t:1527030481505};\\\", \\\"{x:1319,y:495,t:1527030482128};\\\", \\\"{x:1321,y:500,t:1527030482138};\\\", \\\"{x:1324,y:514,t:1527030482154};\\\", \\\"{x:1326,y:529,t:1527030482171};\\\", \\\"{x:1329,y:549,t:1527030482187};\\\", \\\"{x:1331,y:562,t:1527030482205};\\\", \\\"{x:1331,y:575,t:1527030482220};\\\", \\\"{x:1332,y:584,t:1527030482237};\\\", \\\"{x:1332,y:593,t:1527030482254};\\\", \\\"{x:1332,y:600,t:1527030482270};\\\", \\\"{x:1335,y:614,t:1527030482288};\\\", \\\"{x:1335,y:623,t:1527030482304};\\\", \\\"{x:1336,y:628,t:1527030482321};\\\", \\\"{x:1336,y:632,t:1527030482337};\\\", \\\"{x:1336,y:635,t:1527030482354};\\\", \\\"{x:1336,y:636,t:1527030482375};\\\", \\\"{x:1336,y:637,t:1527030482387};\\\", \\\"{x:1336,y:638,t:1527030482404};\\\", \\\"{x:1335,y:639,t:1527030482420};\\\", \\\"{x:1333,y:640,t:1527030482437};\\\", \\\"{x:1332,y:641,t:1527030482454};\\\", \\\"{x:1329,y:641,t:1527030482470};\\\", \\\"{x:1328,y:642,t:1527030482487};\\\", \\\"{x:1326,y:642,t:1527030482528};\\\", \\\"{x:1325,y:642,t:1527030482544};\\\", \\\"{x:1324,y:642,t:1527030482568};\\\", \\\"{x:1323,y:641,t:1527030482576};\\\", \\\"{x:1322,y:641,t:1527030482588};\\\", \\\"{x:1322,y:639,t:1527030482604};\\\", \\\"{x:1322,y:635,t:1527030482621};\\\", \\\"{x:1322,y:632,t:1527030482637};\\\", \\\"{x:1323,y:630,t:1527030482653};\\\", \\\"{x:1324,y:627,t:1527030482670};\\\", \\\"{x:1325,y:626,t:1527030482686};\\\", \\\"{x:1322,y:625,t:1527030482807};\\\", \\\"{x:1316,y:623,t:1527030482821};\\\", \\\"{x:1294,y:621,t:1527030482838};\\\", \\\"{x:1263,y:616,t:1527030482854};\\\", \\\"{x:1227,y:611,t:1527030482871};\\\", \\\"{x:1144,y:600,t:1527030482887};\\\", \\\"{x:1092,y:594,t:1527030482904};\\\", \\\"{x:1052,y:588,t:1527030482921};\\\", \\\"{x:1036,y:586,t:1527030482938};\\\", \\\"{x:1033,y:585,t:1527030482954};\\\", \\\"{x:1032,y:585,t:1527030482983};\\\", \\\"{x:1030,y:585,t:1527030482991};\\\", \\\"{x:1028,y:584,t:1527030483004};\\\", \\\"{x:1017,y:583,t:1527030483021};\\\", \\\"{x:1001,y:579,t:1527030483038};\\\", \\\"{x:989,y:574,t:1527030483055};\\\", \\\"{x:986,y:573,t:1527030483071};\\\", \\\"{x:977,y:569,t:1527030483088};\\\", \\\"{x:967,y:566,t:1527030483104};\\\", \\\"{x:950,y:564,t:1527030483121};\\\", \\\"{x:935,y:560,t:1527030483137};\\\", \\\"{x:925,y:559,t:1527030483154};\\\", \\\"{x:920,y:559,t:1527030483167};\\\", \\\"{x:916,y:559,t:1527030483184};\\\", \\\"{x:903,y:556,t:1527030483202};\\\", \\\"{x:890,y:553,t:1527030483217};\\\", \\\"{x:875,y:549,t:1527030483235};\\\", \\\"{x:859,y:546,t:1527030483252};\\\", \\\"{x:848,y:545,t:1527030483268};\\\", \\\"{x:839,y:544,t:1527030483285};\\\", \\\"{x:838,y:544,t:1527030483300};\\\", \\\"{x:837,y:543,t:1527030483351};\\\", \\\"{x:832,y:543,t:1527030483367};\\\", \\\"{x:829,y:541,t:1527030483385};\\\", \\\"{x:827,y:541,t:1527030483402};\\\", \\\"{x:832,y:541,t:1527030483936};\\\", \\\"{x:907,y:554,t:1527030483953};\\\", \\\"{x:1024,y:570,t:1527030483969};\\\", \\\"{x:1165,y:594,t:1527030483985};\\\", \\\"{x:1280,y:612,t:1527030484001};\\\", \\\"{x:1338,y:620,t:1527030484018};\\\", \\\"{x:1355,y:626,t:1527030484035};\\\", \\\"{x:1357,y:626,t:1527030484052};\\\", \\\"{x:1359,y:626,t:1527030484071};\\\", \\\"{x:1360,y:626,t:1527030484095};\\\", \\\"{x:1362,y:626,t:1527030484103};\\\", \\\"{x:1370,y:622,t:1527030484119};\\\", \\\"{x:1378,y:607,t:1527030484135};\\\", \\\"{x:1379,y:591,t:1527030484152};\\\", \\\"{x:1379,y:573,t:1527030484169};\\\", \\\"{x:1379,y:558,t:1527030484184};\\\", \\\"{x:1370,y:541,t:1527030484202};\\\", \\\"{x:1358,y:525,t:1527030484219};\\\", \\\"{x:1346,y:516,t:1527030484235};\\\", \\\"{x:1338,y:506,t:1527030484252};\\\", \\\"{x:1333,y:495,t:1527030484269};\\\", \\\"{x:1331,y:488,t:1527030484286};\\\", \\\"{x:1329,y:484,t:1527030484302};\\\", \\\"{x:1328,y:481,t:1527030484319};\\\", \\\"{x:1327,y:481,t:1527030484368};\\\", \\\"{x:1326,y:480,t:1527030484376};\\\", \\\"{x:1325,y:479,t:1527030484416};\\\", \\\"{x:1324,y:480,t:1527030484520};\\\", \\\"{x:1324,y:487,t:1527030484535};\\\", \\\"{x:1324,y:494,t:1527030484552};\\\", \\\"{x:1324,y:502,t:1527030484569};\\\", \\\"{x:1324,y:509,t:1527030484586};\\\", \\\"{x:1324,y:516,t:1527030484602};\\\", \\\"{x:1324,y:519,t:1527030484619};\\\", \\\"{x:1325,y:524,t:1527030484635};\\\", \\\"{x:1326,y:533,t:1527030484652};\\\", \\\"{x:1326,y:539,t:1527030484668};\\\", \\\"{x:1326,y:544,t:1527030484686};\\\", \\\"{x:1326,y:552,t:1527030484703};\\\", \\\"{x:1326,y:558,t:1527030484718};\\\", \\\"{x:1326,y:563,t:1527030484736};\\\", \\\"{x:1326,y:569,t:1527030484753};\\\", \\\"{x:1326,y:576,t:1527030484769};\\\", \\\"{x:1326,y:583,t:1527030484786};\\\", \\\"{x:1326,y:587,t:1527030484803};\\\", \\\"{x:1326,y:589,t:1527030484818};\\\", \\\"{x:1326,y:590,t:1527030484836};\\\", \\\"{x:1326,y:594,t:1527030484853};\\\", \\\"{x:1326,y:600,t:1527030484868};\\\", \\\"{x:1326,y:605,t:1527030484886};\\\", \\\"{x:1326,y:612,t:1527030484903};\\\", \\\"{x:1326,y:615,t:1527030484919};\\\", \\\"{x:1326,y:616,t:1527030484936};\\\", \\\"{x:1326,y:617,t:1527030484953};\\\", \\\"{x:1326,y:618,t:1527030484969};\\\", \\\"{x:1326,y:619,t:1527030485031};\\\", \\\"{x:1326,y:620,t:1527030485039};\\\", \\\"{x:1326,y:621,t:1527030485055};\\\", \\\"{x:1326,y:620,t:1527030487216};\\\", \\\"{x:1325,y:618,t:1527030487223};\\\", \\\"{x:1325,y:617,t:1527030487238};\\\", \\\"{x:1325,y:615,t:1527030487253};\\\", \\\"{x:1324,y:612,t:1527030487271};\\\", \\\"{x:1324,y:610,t:1527030487319};\\\", \\\"{x:1324,y:608,t:1527030487335};\\\", \\\"{x:1323,y:606,t:1527030487359};\\\", \\\"{x:1323,y:605,t:1527030487375};\\\", \\\"{x:1323,y:603,t:1527030487391};\\\", \\\"{x:1323,y:601,t:1527030487404};\\\", \\\"{x:1321,y:599,t:1527030487421};\\\", \\\"{x:1321,y:596,t:1527030487438};\\\", \\\"{x:1320,y:592,t:1527030487454};\\\", \\\"{x:1318,y:587,t:1527030487472};\\\", \\\"{x:1317,y:584,t:1527030487488};\\\", \\\"{x:1315,y:578,t:1527030487505};\\\", \\\"{x:1312,y:571,t:1527030487522};\\\", \\\"{x:1310,y:566,t:1527030487539};\\\", \\\"{x:1310,y:564,t:1527030487554};\\\", \\\"{x:1307,y:559,t:1527030487572};\\\", \\\"{x:1307,y:557,t:1527030487589};\\\", \\\"{x:1306,y:557,t:1527030487605};\\\", \\\"{x:1306,y:555,t:1527030487734};\\\", \\\"{x:1306,y:557,t:1527030488143};\\\", \\\"{x:1306,y:558,t:1527030488155};\\\", \\\"{x:1306,y:561,t:1527030488172};\\\", \\\"{x:1306,y:565,t:1527030488188};\\\", \\\"{x:1306,y:569,t:1527030488205};\\\", \\\"{x:1307,y:575,t:1527030488222};\\\", \\\"{x:1307,y:579,t:1527030488238};\\\", \\\"{x:1307,y:587,t:1527030488255};\\\", \\\"{x:1307,y:591,t:1527030488272};\\\", \\\"{x:1307,y:594,t:1527030488289};\\\", \\\"{x:1307,y:599,t:1527030488305};\\\", \\\"{x:1307,y:602,t:1527030488322};\\\", \\\"{x:1308,y:606,t:1527030488339};\\\", \\\"{x:1308,y:612,t:1527030488355};\\\", \\\"{x:1309,y:616,t:1527030488372};\\\", \\\"{x:1310,y:620,t:1527030488388};\\\", \\\"{x:1312,y:625,t:1527030488406};\\\", \\\"{x:1312,y:626,t:1527030488422};\\\", \\\"{x:1312,y:630,t:1527030488438};\\\", \\\"{x:1314,y:633,t:1527030488455};\\\", \\\"{x:1315,y:637,t:1527030488472};\\\", \\\"{x:1315,y:642,t:1527030488489};\\\", \\\"{x:1317,y:648,t:1527030488505};\\\", \\\"{x:1319,y:652,t:1527030488523};\\\", \\\"{x:1319,y:654,t:1527030488539};\\\", \\\"{x:1319,y:656,t:1527030488556};\\\", \\\"{x:1319,y:658,t:1527030488572};\\\", \\\"{x:1319,y:661,t:1527030488590};\\\", \\\"{x:1321,y:664,t:1527030488605};\\\", \\\"{x:1321,y:668,t:1527030488622};\\\", \\\"{x:1322,y:673,t:1527030488639};\\\", \\\"{x:1322,y:675,t:1527030488655};\\\", \\\"{x:1322,y:678,t:1527030488672};\\\", \\\"{x:1322,y:681,t:1527030488690};\\\", \\\"{x:1322,y:685,t:1527030488706};\\\", \\\"{x:1322,y:689,t:1527030488723};\\\", \\\"{x:1323,y:695,t:1527030488740};\\\", \\\"{x:1323,y:698,t:1527030488756};\\\", \\\"{x:1323,y:704,t:1527030488773};\\\", \\\"{x:1323,y:711,t:1527030488790};\\\", \\\"{x:1323,y:718,t:1527030488805};\\\", \\\"{x:1323,y:725,t:1527030488823};\\\", \\\"{x:1323,y:736,t:1527030488840};\\\", \\\"{x:1321,y:744,t:1527030488855};\\\", \\\"{x:1321,y:749,t:1527030488873};\\\", \\\"{x:1321,y:754,t:1527030488890};\\\", \\\"{x:1321,y:761,t:1527030488906};\\\", \\\"{x:1321,y:769,t:1527030488922};\\\", \\\"{x:1322,y:776,t:1527030488939};\\\", \\\"{x:1322,y:781,t:1527030488955};\\\", \\\"{x:1322,y:785,t:1527030488972};\\\", \\\"{x:1322,y:791,t:1527030488990};\\\", \\\"{x:1322,y:795,t:1527030489006};\\\", \\\"{x:1322,y:799,t:1527030489022};\\\", \\\"{x:1324,y:805,t:1527030489039};\\\", \\\"{x:1324,y:806,t:1527030489056};\\\", \\\"{x:1325,y:808,t:1527030489072};\\\", \\\"{x:1325,y:807,t:1527030489192};\\\", \\\"{x:1325,y:805,t:1527030489206};\\\", \\\"{x:1325,y:800,t:1527030489223};\\\", \\\"{x:1325,y:790,t:1527030489239};\\\", \\\"{x:1325,y:783,t:1527030489256};\\\", \\\"{x:1325,y:773,t:1527030489273};\\\", \\\"{x:1325,y:764,t:1527030489290};\\\", \\\"{x:1325,y:756,t:1527030489306};\\\", \\\"{x:1325,y:749,t:1527030489322};\\\", \\\"{x:1325,y:741,t:1527030489340};\\\", \\\"{x:1325,y:734,t:1527030489357};\\\", \\\"{x:1325,y:725,t:1527030489373};\\\", \\\"{x:1325,y:714,t:1527030489390};\\\", \\\"{x:1325,y:704,t:1527030489406};\\\", \\\"{x:1325,y:693,t:1527030489422};\\\", \\\"{x:1322,y:684,t:1527030489439};\\\", \\\"{x:1322,y:676,t:1527030489456};\\\", \\\"{x:1320,y:668,t:1527030489473};\\\", \\\"{x:1319,y:662,t:1527030489490};\\\", \\\"{x:1319,y:655,t:1527030489507};\\\", \\\"{x:1318,y:649,t:1527030489524};\\\", \\\"{x:1317,y:643,t:1527030489539};\\\", \\\"{x:1317,y:638,t:1527030489556};\\\", \\\"{x:1317,y:632,t:1527030489574};\\\", \\\"{x:1317,y:628,t:1527030489589};\\\", \\\"{x:1317,y:624,t:1527030489608};\\\", \\\"{x:1317,y:618,t:1527030489624};\\\", \\\"{x:1317,y:613,t:1527030489640};\\\", \\\"{x:1317,y:608,t:1527030489657};\\\", \\\"{x:1317,y:602,t:1527030489674};\\\", \\\"{x:1317,y:596,t:1527030489690};\\\", \\\"{x:1317,y:587,t:1527030489707};\\\", \\\"{x:1317,y:579,t:1527030489723};\\\", \\\"{x:1317,y:571,t:1527030489739};\\\", \\\"{x:1317,y:565,t:1527030489757};\\\", \\\"{x:1317,y:559,t:1527030489773};\\\", \\\"{x:1316,y:552,t:1527030489790};\\\", \\\"{x:1316,y:546,t:1527030489807};\\\", \\\"{x:1316,y:538,t:1527030489824};\\\", \\\"{x:1316,y:531,t:1527030489840};\\\", \\\"{x:1316,y:524,t:1527030489857};\\\", \\\"{x:1316,y:518,t:1527030489873};\\\", \\\"{x:1316,y:508,t:1527030489889};\\\", \\\"{x:1316,y:502,t:1527030489908};\\\", \\\"{x:1317,y:495,t:1527030489923};\\\", \\\"{x:1318,y:491,t:1527030489941};\\\", \\\"{x:1318,y:488,t:1527030489957};\\\", \\\"{x:1320,y:492,t:1527030490048};\\\", \\\"{x:1321,y:497,t:1527030490056};\\\", \\\"{x:1325,y:519,t:1527030490074};\\\", \\\"{x:1328,y:548,t:1527030490091};\\\", \\\"{x:1335,y:591,t:1527030490107};\\\", \\\"{x:1340,y:630,t:1527030490124};\\\", \\\"{x:1342,y:676,t:1527030490141};\\\", \\\"{x:1342,y:703,t:1527030490157};\\\", \\\"{x:1346,y:729,t:1527030490173};\\\", \\\"{x:1347,y:744,t:1527030490190};\\\", \\\"{x:1347,y:753,t:1527030490207};\\\", \\\"{x:1347,y:757,t:1527030490224};\\\", \\\"{x:1347,y:759,t:1527030490240};\\\", \\\"{x:1346,y:760,t:1527030490256};\\\", \\\"{x:1342,y:761,t:1527030490272};\\\", \\\"{x:1332,y:761,t:1527030490290};\\\", \\\"{x:1319,y:761,t:1527030490306};\\\", \\\"{x:1282,y:761,t:1527030490323};\\\", \\\"{x:1227,y:761,t:1527030490340};\\\", \\\"{x:1166,y:756,t:1527030490356};\\\", \\\"{x:1102,y:747,t:1527030490373};\\\", \\\"{x:1042,y:736,t:1527030490390};\\\", \\\"{x:993,y:723,t:1527030490406};\\\", \\\"{x:946,y:717,t:1527030490424};\\\", \\\"{x:913,y:717,t:1527030490440};\\\", \\\"{x:874,y:717,t:1527030490457};\\\", \\\"{x:834,y:717,t:1527030490474};\\\", \\\"{x:804,y:717,t:1527030490490};\\\", \\\"{x:778,y:717,t:1527030490508};\\\", \\\"{x:756,y:717,t:1527030490524};\\\", \\\"{x:740,y:717,t:1527030490541};\\\", \\\"{x:725,y:717,t:1527030490557};\\\", \\\"{x:710,y:717,t:1527030490573};\\\", \\\"{x:699,y:717,t:1527030490590};\\\", \\\"{x:683,y:718,t:1527030490608};\\\", \\\"{x:671,y:720,t:1527030490623};\\\", \\\"{x:656,y:722,t:1527030490641};\\\", \\\"{x:641,y:724,t:1527030490658};\\\", \\\"{x:627,y:725,t:1527030490673};\\\", \\\"{x:615,y:728,t:1527030490691};\\\", \\\"{x:601,y:729,t:1527030490707};\\\", \\\"{x:586,y:729,t:1527030490724};\\\", \\\"{x:571,y:729,t:1527030490741};\\\", \\\"{x:554,y:729,t:1527030490759};\\\", \\\"{x:545,y:729,t:1527030490773};\\\", \\\"{x:542,y:729,t:1527030490790};\\\", \\\"{x:537,y:729,t:1527030490807};\\\", \\\"{x:533,y:729,t:1527030490824};\\\", \\\"{x:528,y:729,t:1527030490840};\\\", \\\"{x:521,y:729,t:1527030490857};\\\", \\\"{x:514,y:729,t:1527030490874};\\\", \\\"{x:504,y:729,t:1527030490891};\\\", \\\"{x:494,y:729,t:1527030490907};\\\", \\\"{x:482,y:729,t:1527030490924};\\\", \\\"{x:476,y:728,t:1527030490941};\\\", \\\"{x:478,y:728,t:1527030492847};\\\", \\\"{x:481,y:728,t:1527030492859};\\\", \\\"{x:487,y:728,t:1527030492876};\\\", \\\"{x:491,y:728,t:1527030492892};\\\", \\\"{x:492,y:728,t:1527030492909};\\\", \\\"{x:491,y:728,t:1527030492952};\\\", \\\"{x:490,y:729,t:1527030492967};\\\", \\\"{x:488,y:729,t:1527030492984};\\\", \\\"{x:486,y:730,t:1527030492992};\\\", \\\"{x:478,y:730,t:1527030493009};\\\", \\\"{x:471,y:724,t:1527030493026};\\\", \\\"{x:459,y:711,t:1527030493042};\\\", \\\"{x:447,y:687,t:1527030493059};\\\", \\\"{x:436,y:660,t:1527030493076};\\\", \\\"{x:431,y:640,t:1527030493092};\\\", \\\"{x:427,y:630,t:1527030493109};\\\", \\\"{x:425,y:622,t:1527030493126};\\\", \\\"{x:424,y:611,t:1527030493142};\\\", \\\"{x:421,y:595,t:1527030493159};\\\", \\\"{x:420,y:586,t:1527030493176};\\\", \\\"{x:417,y:580,t:1527030493192};\\\", \\\"{x:417,y:575,t:1527030493209};\\\", \\\"{x:417,y:572,t:1527030493226};\\\", \\\"{x:417,y:571,t:1527030493243};\\\" ] }, { \\\"rt\\\": 10097, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 420758, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-G -6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:417,y:569,t:1527030493959};\\\", \\\"{x:419,y:569,t:1527030493967};\\\", \\\"{x:421,y:569,t:1527030493977};\\\", \\\"{x:429,y:574,t:1527030493993};\\\", \\\"{x:434,y:578,t:1527030494010};\\\", \\\"{x:441,y:582,t:1527030494026};\\\", \\\"{x:452,y:585,t:1527030494043};\\\", \\\"{x:463,y:584,t:1527030494060};\\\", \\\"{x:472,y:580,t:1527030494077};\\\", \\\"{x:476,y:578,t:1527030494093};\\\", \\\"{x:478,y:575,t:1527030494111};\\\", \\\"{x:481,y:568,t:1527030494126};\\\", \\\"{x:490,y:543,t:1527030494144};\\\", \\\"{x:491,y:538,t:1527030494160};\\\", \\\"{x:493,y:533,t:1527030494177};\\\", \\\"{x:493,y:531,t:1527030494193};\\\", \\\"{x:493,y:523,t:1527030494210};\\\", \\\"{x:479,y:476,t:1527030494289};\\\", \\\"{x:476,y:473,t:1527030494295};\\\", \\\"{x:476,y:472,t:1527030494310};\\\", \\\"{x:476,y:471,t:1527030494327};\\\", \\\"{x:476,y:469,t:1527030494343};\\\", \\\"{x:476,y:465,t:1527030494360};\\\", \\\"{x:481,y:458,t:1527030494377};\\\", \\\"{x:488,y:451,t:1527030494393};\\\", \\\"{x:495,y:446,t:1527030494410};\\\", \\\"{x:498,y:444,t:1527030494427};\\\", \\\"{x:502,y:443,t:1527030494672};\\\", \\\"{x:510,y:443,t:1527030494679};\\\", \\\"{x:518,y:443,t:1527030494695};\\\", \\\"{x:536,y:443,t:1527030494710};\\\", \\\"{x:559,y:443,t:1527030494728};\\\", \\\"{x:565,y:443,t:1527030494744};\\\", \\\"{x:566,y:443,t:1527030494762};\\\", \\\"{x:568,y:443,t:1527030494784};\\\", \\\"{x:569,y:443,t:1527030494799};\\\", \\\"{x:571,y:444,t:1527030494812};\\\", \\\"{x:576,y:445,t:1527030494828};\\\", \\\"{x:580,y:447,t:1527030494844};\\\", \\\"{x:583,y:448,t:1527030494860};\\\", \\\"{x:586,y:448,t:1527030494877};\\\", \\\"{x:591,y:449,t:1527030494894};\\\", \\\"{x:597,y:450,t:1527030494912};\\\", \\\"{x:599,y:452,t:1527030494928};\\\", \\\"{x:604,y:453,t:1527030494945};\\\", \\\"{x:610,y:455,t:1527030494961};\\\", \\\"{x:626,y:457,t:1527030494977};\\\", \\\"{x:646,y:459,t:1527030494995};\\\", \\\"{x:672,y:462,t:1527030495011};\\\", \\\"{x:698,y:462,t:1527030495028};\\\", \\\"{x:725,y:465,t:1527030495045};\\\", \\\"{x:754,y:467,t:1527030495061};\\\", \\\"{x:796,y:473,t:1527030495078};\\\", \\\"{x:850,y:482,t:1527030495095};\\\", \\\"{x:941,y:504,t:1527030495113};\\\", \\\"{x:994,y:520,t:1527030495128};\\\", \\\"{x:1021,y:528,t:1527030495144};\\\", \\\"{x:1038,y:539,t:1527030495159};\\\", \\\"{x:1047,y:550,t:1527030495176};\\\", \\\"{x:1049,y:558,t:1527030495193};\\\", \\\"{x:1052,y:570,t:1527030495209};\\\", \\\"{x:1053,y:580,t:1527030495226};\\\", \\\"{x:1054,y:588,t:1527030495243};\\\", \\\"{x:1055,y:596,t:1527030495260};\\\", \\\"{x:1056,y:602,t:1527030495277};\\\", \\\"{x:1056,y:608,t:1527030495293};\\\", \\\"{x:1056,y:615,t:1527030495309};\\\", \\\"{x:1057,y:622,t:1527030495327};\\\", \\\"{x:1058,y:635,t:1527030495343};\\\", \\\"{x:1058,y:641,t:1527030495360};\\\", \\\"{x:1058,y:650,t:1527030495376};\\\", \\\"{x:1058,y:658,t:1527030495394};\\\", \\\"{x:1056,y:665,t:1527030495409};\\\", \\\"{x:1055,y:671,t:1527030495427};\\\", \\\"{x:1052,y:677,t:1527030495444};\\\", \\\"{x:1050,y:681,t:1527030495460};\\\", \\\"{x:1049,y:684,t:1527030495477};\\\", \\\"{x:1048,y:686,t:1527030495493};\\\", \\\"{x:1045,y:690,t:1527030495509};\\\", \\\"{x:1042,y:692,t:1527030495527};\\\", \\\"{x:1038,y:694,t:1527030495542};\\\", \\\"{x:1034,y:696,t:1527030495559};\\\", \\\"{x:1030,y:697,t:1527030495576};\\\", \\\"{x:1026,y:699,t:1527030495593};\\\", \\\"{x:1024,y:700,t:1527030495609};\\\", \\\"{x:1023,y:700,t:1527030495626};\\\", \\\"{x:1023,y:699,t:1527030495823};\\\", \\\"{x:1023,y:697,t:1527030495830};\\\", \\\"{x:1024,y:697,t:1527030495842};\\\", \\\"{x:1024,y:694,t:1527030495859};\\\", \\\"{x:1025,y:693,t:1527030495876};\\\", \\\"{x:1025,y:691,t:1527030495894};\\\", \\\"{x:1025,y:690,t:1527030495911};\\\", \\\"{x:1026,y:689,t:1527030495926};\\\", \\\"{x:1027,y:687,t:1527030495942};\\\", \\\"{x:1031,y:682,t:1527030495959};\\\", \\\"{x:1032,y:679,t:1527030495976};\\\", \\\"{x:1034,y:675,t:1527030495992};\\\", \\\"{x:1035,y:672,t:1527030496009};\\\", \\\"{x:1036,y:669,t:1527030496026};\\\", \\\"{x:1038,y:664,t:1527030496042};\\\", \\\"{x:1041,y:656,t:1527030496059};\\\", \\\"{x:1043,y:650,t:1527030496076};\\\", \\\"{x:1046,y:644,t:1527030496092};\\\", \\\"{x:1048,y:638,t:1527030496109};\\\", \\\"{x:1050,y:633,t:1527030496126};\\\", \\\"{x:1050,y:631,t:1527030496142};\\\", \\\"{x:1051,y:627,t:1527030496159};\\\", \\\"{x:1051,y:621,t:1527030496177};\\\", \\\"{x:1051,y:615,t:1527030496193};\\\", \\\"{x:1051,y:611,t:1527030496209};\\\", \\\"{x:1051,y:606,t:1527030496227};\\\", \\\"{x:1051,y:603,t:1527030496243};\\\", \\\"{x:1051,y:600,t:1527030496259};\\\", \\\"{x:1050,y:598,t:1527030496276};\\\", \\\"{x:1050,y:594,t:1527030496293};\\\", \\\"{x:1049,y:591,t:1527030496309};\\\", \\\"{x:1049,y:587,t:1527030496327};\\\", \\\"{x:1049,y:585,t:1527030496342};\\\", \\\"{x:1049,y:583,t:1527030496360};\\\", \\\"{x:1049,y:581,t:1527030496377};\\\", \\\"{x:1051,y:581,t:1527030496559};\\\", \\\"{x:1063,y:581,t:1527030496575};\\\", \\\"{x:1078,y:581,t:1527030496592};\\\", \\\"{x:1103,y:581,t:1527030496609};\\\", \\\"{x:1130,y:581,t:1527030496626};\\\", \\\"{x:1157,y:581,t:1527030496642};\\\", \\\"{x:1175,y:581,t:1527030496660};\\\", \\\"{x:1188,y:581,t:1527030496675};\\\", \\\"{x:1199,y:579,t:1527030496692};\\\", \\\"{x:1214,y:578,t:1527030496710};\\\", \\\"{x:1229,y:575,t:1527030496725};\\\", \\\"{x:1254,y:572,t:1527030496742};\\\", \\\"{x:1302,y:567,t:1527030496759};\\\", \\\"{x:1340,y:557,t:1527030496776};\\\", \\\"{x:1383,y:550,t:1527030496792};\\\", \\\"{x:1408,y:547,t:1527030496809};\\\", \\\"{x:1425,y:547,t:1527030496825};\\\", \\\"{x:1434,y:547,t:1527030496843};\\\", \\\"{x:1436,y:547,t:1527030496859};\\\", \\\"{x:1437,y:547,t:1527030496911};\\\", \\\"{x:1439,y:547,t:1527030496926};\\\", \\\"{x:1442,y:547,t:1527030496943};\\\", \\\"{x:1448,y:547,t:1527030496959};\\\", \\\"{x:1453,y:547,t:1527030496975};\\\", \\\"{x:1458,y:547,t:1527030496992};\\\", \\\"{x:1463,y:548,t:1527030497009};\\\", \\\"{x:1467,y:549,t:1527030497026};\\\", \\\"{x:1469,y:549,t:1527030497043};\\\", \\\"{x:1470,y:549,t:1527030497063};\\\", \\\"{x:1470,y:551,t:1527030497224};\\\", \\\"{x:1470,y:552,t:1527030497240};\\\", \\\"{x:1469,y:552,t:1527030497447};\\\", \\\"{x:1468,y:552,t:1527030497458};\\\", \\\"{x:1466,y:553,t:1527030497475};\\\", \\\"{x:1459,y:555,t:1527030497492};\\\", \\\"{x:1453,y:555,t:1527030497508};\\\", \\\"{x:1446,y:555,t:1527030497525};\\\", \\\"{x:1436,y:555,t:1527030497543};\\\", \\\"{x:1427,y:555,t:1527030497558};\\\", \\\"{x:1420,y:555,t:1527030497575};\\\", \\\"{x:1417,y:555,t:1527030497592};\\\", \\\"{x:1411,y:556,t:1527030497608};\\\", \\\"{x:1405,y:556,t:1527030497626};\\\", \\\"{x:1398,y:557,t:1527030497643};\\\", \\\"{x:1391,y:557,t:1527030497658};\\\", \\\"{x:1384,y:557,t:1527030497676};\\\", \\\"{x:1372,y:559,t:1527030497692};\\\", \\\"{x:1352,y:559,t:1527030497708};\\\", \\\"{x:1328,y:561,t:1527030497725};\\\", \\\"{x:1301,y:562,t:1527030497742};\\\", \\\"{x:1271,y:562,t:1527030497758};\\\", \\\"{x:1237,y:562,t:1527030497775};\\\", \\\"{x:1218,y:562,t:1527030497791};\\\", \\\"{x:1204,y:562,t:1527030497808};\\\", \\\"{x:1193,y:562,t:1527030497825};\\\", \\\"{x:1179,y:562,t:1527030497843};\\\", \\\"{x:1169,y:562,t:1527030497858};\\\", \\\"{x:1159,y:562,t:1527030497876};\\\", \\\"{x:1151,y:562,t:1527030497891};\\\", \\\"{x:1140,y:562,t:1527030497908};\\\", \\\"{x:1134,y:562,t:1527030497925};\\\", \\\"{x:1131,y:562,t:1527030497941};\\\", \\\"{x:1128,y:562,t:1527030497959};\\\", \\\"{x:1124,y:562,t:1527030497975};\\\", \\\"{x:1122,y:562,t:1527030497992};\\\", \\\"{x:1120,y:561,t:1527030498009};\\\", \\\"{x:1114,y:561,t:1527030498271};\\\", \\\"{x:1102,y:561,t:1527030498279};\\\", \\\"{x:1090,y:561,t:1527030498291};\\\", \\\"{x:1057,y:557,t:1527030498308};\\\", \\\"{x:1010,y:553,t:1527030498326};\\\", \\\"{x:968,y:553,t:1527030498342};\\\", \\\"{x:940,y:553,t:1527030498359};\\\", \\\"{x:922,y:553,t:1527030498375};\\\", \\\"{x:914,y:553,t:1527030498393};\\\", \\\"{x:908,y:553,t:1527030498410};\\\", \\\"{x:900,y:553,t:1527030498426};\\\", \\\"{x:889,y:553,t:1527030498444};\\\", \\\"{x:870,y:554,t:1527030498461};\\\", \\\"{x:853,y:556,t:1527030498477};\\\", \\\"{x:846,y:558,t:1527030498493};\\\", \\\"{x:842,y:558,t:1527030498513};\\\", \\\"{x:839,y:558,t:1527030498530};\\\", \\\"{x:831,y:558,t:1527030498547};\\\", \\\"{x:812,y:558,t:1527030498563};\\\", \\\"{x:789,y:558,t:1527030498580};\\\", \\\"{x:764,y:558,t:1527030498597};\\\", \\\"{x:744,y:558,t:1527030498613};\\\", \\\"{x:734,y:558,t:1527030498630};\\\", \\\"{x:726,y:558,t:1527030498646};\\\", \\\"{x:715,y:558,t:1527030498663};\\\", \\\"{x:698,y:558,t:1527030498680};\\\", \\\"{x:675,y:558,t:1527030498697};\\\", \\\"{x:653,y:558,t:1527030498714};\\\", \\\"{x:634,y:558,t:1527030498730};\\\", \\\"{x:620,y:558,t:1527030498747};\\\", \\\"{x:608,y:558,t:1527030498764};\\\", \\\"{x:592,y:558,t:1527030498780};\\\", \\\"{x:577,y:556,t:1527030498797};\\\", \\\"{x:562,y:556,t:1527030498814};\\\", \\\"{x:546,y:553,t:1527030498831};\\\", \\\"{x:544,y:553,t:1527030498847};\\\", \\\"{x:545,y:552,t:1527030498871};\\\", \\\"{x:549,y:549,t:1527030498880};\\\", \\\"{x:557,y:543,t:1527030498897};\\\", \\\"{x:563,y:539,t:1527030498914};\\\", \\\"{x:570,y:533,t:1527030498930};\\\", \\\"{x:573,y:530,t:1527030498947};\\\", \\\"{x:577,y:527,t:1527030498964};\\\", \\\"{x:582,y:523,t:1527030498981};\\\", \\\"{x:593,y:519,t:1527030498997};\\\", \\\"{x:609,y:515,t:1527030499015};\\\", \\\"{x:611,y:513,t:1527030499031};\\\", \\\"{x:613,y:513,t:1527030499047};\\\", \\\"{x:613,y:513,t:1527030499327};\\\", \\\"{x:613,y:512,t:1527030499902};\\\", \\\"{x:614,y:511,t:1527030499914};\\\", \\\"{x:618,y:511,t:1527030499930};\\\", \\\"{x:622,y:511,t:1527030499947};\\\", \\\"{x:623,y:511,t:1527030499964};\\\", \\\"{x:624,y:511,t:1527030499981};\\\", \\\"{x:627,y:511,t:1527030499997};\\\", \\\"{x:630,y:511,t:1527030500014};\\\", \\\"{x:633,y:511,t:1527030500030};\\\", \\\"{x:640,y:511,t:1527030500047};\\\", \\\"{x:646,y:511,t:1527030500065};\\\", \\\"{x:649,y:512,t:1527030500080};\\\", \\\"{x:651,y:512,t:1527030500098};\\\", \\\"{x:653,y:512,t:1527030500115};\\\", \\\"{x:656,y:513,t:1527030500131};\\\", \\\"{x:662,y:513,t:1527030500148};\\\", \\\"{x:668,y:515,t:1527030500165};\\\", \\\"{x:671,y:515,t:1527030500181};\\\", \\\"{x:674,y:516,t:1527030500198};\\\", \\\"{x:677,y:516,t:1527030500215};\\\", \\\"{x:678,y:516,t:1527030500231};\\\", \\\"{x:679,y:516,t:1527030500248};\\\", \\\"{x:680,y:516,t:1527030500265};\\\", \\\"{x:682,y:516,t:1527030500282};\\\", \\\"{x:686,y:517,t:1527030500298};\\\", \\\"{x:688,y:518,t:1527030500316};\\\", \\\"{x:691,y:520,t:1527030500331};\\\", \\\"{x:697,y:521,t:1527030500348};\\\", \\\"{x:703,y:523,t:1527030500365};\\\", \\\"{x:710,y:525,t:1527030500382};\\\", \\\"{x:719,y:526,t:1527030500398};\\\", \\\"{x:725,y:528,t:1527030500416};\\\", \\\"{x:730,y:528,t:1527030500431};\\\", \\\"{x:736,y:530,t:1527030500448};\\\", \\\"{x:742,y:531,t:1527030500465};\\\", \\\"{x:749,y:532,t:1527030500481};\\\", \\\"{x:755,y:533,t:1527030500498};\\\", \\\"{x:760,y:534,t:1527030500515};\\\", \\\"{x:761,y:534,t:1527030500532};\\\", \\\"{x:764,y:534,t:1527030500548};\\\", \\\"{x:765,y:535,t:1527030500565};\\\", \\\"{x:769,y:535,t:1527030500582};\\\", \\\"{x:772,y:536,t:1527030500598};\\\", \\\"{x:774,y:536,t:1527030500615};\\\", \\\"{x:775,y:536,t:1527030500632};\\\", \\\"{x:778,y:536,t:1527030500711};\\\", \\\"{x:781,y:536,t:1527030500719};\\\", \\\"{x:785,y:536,t:1527030500732};\\\", \\\"{x:790,y:536,t:1527030500748};\\\", \\\"{x:796,y:536,t:1527030500765};\\\", \\\"{x:799,y:536,t:1527030500783};\\\", \\\"{x:802,y:536,t:1527030500798};\\\", \\\"{x:806,y:537,t:1527030500816};\\\", \\\"{x:807,y:537,t:1527030500838};\\\", \\\"{x:808,y:537,t:1527030500848};\\\", \\\"{x:809,y:537,t:1527030500865};\\\", \\\"{x:811,y:537,t:1527030500882};\\\", \\\"{x:813,y:537,t:1527030500898};\\\", \\\"{x:818,y:538,t:1527030500915};\\\", \\\"{x:821,y:539,t:1527030500932};\\\", \\\"{x:825,y:539,t:1527030500950};\\\", \\\"{x:827,y:539,t:1527030500966};\\\", \\\"{x:832,y:539,t:1527030500983};\\\", \\\"{x:837,y:540,t:1527030500999};\\\", \\\"{x:842,y:542,t:1527030501015};\\\", \\\"{x:844,y:542,t:1527030501033};\\\", \\\"{x:843,y:542,t:1527030501831};\\\", \\\"{x:842,y:542,t:1527030501838};\\\", \\\"{x:833,y:542,t:1527030501849};\\\", \\\"{x:809,y:539,t:1527030501866};\\\", \\\"{x:770,y:532,t:1527030501883};\\\", \\\"{x:743,y:524,t:1527030501900};\\\", \\\"{x:710,y:517,t:1527030501916};\\\", \\\"{x:685,y:505,t:1527030501933};\\\", \\\"{x:674,y:499,t:1527030501950};\\\", \\\"{x:670,y:496,t:1527030501966};\\\", \\\"{x:670,y:505,t:1527030502086};\\\", \\\"{x:670,y:514,t:1527030502100};\\\", \\\"{x:670,y:531,t:1527030502117};\\\", \\\"{x:669,y:546,t:1527030502133};\\\", \\\"{x:662,y:563,t:1527030502149};\\\", \\\"{x:650,y:583,t:1527030502166};\\\", \\\"{x:644,y:595,t:1527030502184};\\\", \\\"{x:639,y:604,t:1527030502201};\\\", \\\"{x:636,y:611,t:1527030502216};\\\", \\\"{x:634,y:616,t:1527030502233};\\\", \\\"{x:629,y:627,t:1527030502250};\\\", \\\"{x:622,y:635,t:1527030502266};\\\", \\\"{x:615,y:644,t:1527030502283};\\\", \\\"{x:611,y:651,t:1527030502300};\\\", \\\"{x:609,y:656,t:1527030502316};\\\", \\\"{x:608,y:660,t:1527030502333};\\\", \\\"{x:605,y:665,t:1527030502351};\\\", \\\"{x:603,y:669,t:1527030502366};\\\", \\\"{x:598,y:673,t:1527030502383};\\\", \\\"{x:589,y:677,t:1527030502400};\\\", \\\"{x:574,y:682,t:1527030502417};\\\", \\\"{x:559,y:691,t:1527030502433};\\\", \\\"{x:547,y:697,t:1527030502451};\\\", \\\"{x:541,y:702,t:1527030502467};\\\", \\\"{x:534,y:706,t:1527030502484};\\\", \\\"{x:530,y:710,t:1527030502500};\\\", \\\"{x:526,y:714,t:1527030502517};\\\", \\\"{x:523,y:717,t:1527030502533};\\\", \\\"{x:521,y:720,t:1527030502551};\\\", \\\"{x:520,y:722,t:1527030502567};\\\", \\\"{x:519,y:723,t:1527030502582};\\\", \\\"{x:519,y:725,t:1527030502600};\\\", \\\"{x:519,y:727,t:1527030502616};\\\", \\\"{x:519,y:728,t:1527030502632};\\\", \\\"{x:519,y:729,t:1527030502673};\\\", \\\"{x:519,y:730,t:1527030502685};\\\", \\\"{x:519,y:731,t:1527030502701};\\\", \\\"{x:520,y:731,t:1527030504873};\\\", \\\"{x:521,y:731,t:1527030504888};\\\" ] }, { \\\"rt\\\": 30516, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 452479, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -O -X -X -H -11 AM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:728,t:1527030504999};\\\", \\\"{x:529,y:728,t:1527030505008};\\\", \\\"{x:529,y:727,t:1527030505057};\\\", \\\"{x:529,y:726,t:1527030505105};\\\", \\\"{x:530,y:726,t:1527030505121};\\\", \\\"{x:530,y:724,t:1527030505138};\\\", \\\"{x:531,y:722,t:1527030505155};\\\", \\\"{x:532,y:721,t:1527030505233};\\\", \\\"{x:532,y:720,t:1527030505249};\\\", \\\"{x:532,y:719,t:1527030505273};\\\", \\\"{x:532,y:717,t:1527030505288};\\\", \\\"{x:532,y:711,t:1527030505304};\\\", \\\"{x:531,y:700,t:1527030505321};\\\", \\\"{x:525,y:676,t:1527030505338};\\\", \\\"{x:514,y:641,t:1527030505355};\\\", \\\"{x:504,y:615,t:1527030505372};\\\", \\\"{x:474,y:532,t:1527030505447};\\\", \\\"{x:470,y:527,t:1527030505455};\\\", \\\"{x:463,y:516,t:1527030505473};\\\", \\\"{x:454,y:506,t:1527030505488};\\\", \\\"{x:444,y:498,t:1527030505505};\\\", \\\"{x:440,y:496,t:1527030505521};\\\", \\\"{x:436,y:492,t:1527030505538};\\\", \\\"{x:431,y:488,t:1527030505554};\\\", \\\"{x:426,y:485,t:1527030505572};\\\", \\\"{x:420,y:482,t:1527030505587};\\\", \\\"{x:412,y:481,t:1527030505605};\\\", \\\"{x:401,y:481,t:1527030505622};\\\", \\\"{x:391,y:481,t:1527030505638};\\\", \\\"{x:387,y:480,t:1527030505655};\\\", \\\"{x:382,y:479,t:1527030505672};\\\", \\\"{x:377,y:477,t:1527030505688};\\\", \\\"{x:366,y:475,t:1527030505704};\\\", \\\"{x:358,y:475,t:1527030505722};\\\", \\\"{x:351,y:475,t:1527030505739};\\\", \\\"{x:345,y:474,t:1527030505755};\\\", \\\"{x:342,y:473,t:1527030505772};\\\", \\\"{x:339,y:472,t:1527030505788};\\\", \\\"{x:337,y:471,t:1527030505804};\\\", \\\"{x:335,y:470,t:1527030505822};\\\", \\\"{x:334,y:470,t:1527030505839};\\\", \\\"{x:334,y:469,t:1527030506048};\\\", \\\"{x:336,y:468,t:1527030506056};\\\", \\\"{x:337,y:467,t:1527030506080};\\\", \\\"{x:338,y:467,t:1527030506145};\\\", \\\"{x:339,y:467,t:1527030506160};\\\", \\\"{x:340,y:466,t:1527030506184};\\\", \\\"{x:341,y:465,t:1527030506192};\\\", \\\"{x:342,y:465,t:1527030506232};\\\", \\\"{x:343,y:465,t:1527030506256};\\\", \\\"{x:343,y:464,t:1527030506271};\\\", \\\"{x:344,y:464,t:1527030506289};\\\", \\\"{x:345,y:464,t:1527030506321};\\\", \\\"{x:346,y:464,t:1527030506337};\\\", \\\"{x:348,y:462,t:1527030506353};\\\", \\\"{x:349,y:462,t:1527030506361};\\\", \\\"{x:353,y:462,t:1527030506372};\\\", \\\"{x:367,y:462,t:1527030506389};\\\", \\\"{x:378,y:462,t:1527030506405};\\\", \\\"{x:390,y:462,t:1527030506421};\\\", \\\"{x:398,y:462,t:1527030506439};\\\", \\\"{x:403,y:462,t:1527030506456};\\\", \\\"{x:410,y:462,t:1527030506472};\\\", \\\"{x:423,y:462,t:1527030506488};\\\", \\\"{x:431,y:462,t:1527030506505};\\\", \\\"{x:435,y:462,t:1527030506521};\\\", \\\"{x:437,y:462,t:1527030506538};\\\", \\\"{x:439,y:462,t:1527030506556};\\\", \\\"{x:441,y:462,t:1527030506572};\\\", \\\"{x:442,y:462,t:1527030506589};\\\", \\\"{x:444,y:462,t:1527030506605};\\\", \\\"{x:445,y:462,t:1527030506622};\\\", \\\"{x:447,y:462,t:1527030506639};\\\", \\\"{x:448,y:462,t:1527030506655};\\\", \\\"{x:450,y:462,t:1527030506672};\\\", \\\"{x:451,y:462,t:1527030506689};\\\", \\\"{x:453,y:462,t:1527030506706};\\\", \\\"{x:454,y:462,t:1527030506723};\\\", \\\"{x:457,y:462,t:1527030506738};\\\", \\\"{x:459,y:462,t:1527030506755};\\\", \\\"{x:461,y:463,t:1527030506773};\\\", \\\"{x:462,y:464,t:1527030506789};\\\", \\\"{x:463,y:464,t:1527030506806};\\\", \\\"{x:463,y:465,t:1527030506832};\\\", \\\"{x:464,y:465,t:1527030506864};\\\", \\\"{x:465,y:466,t:1527030506873};\\\", \\\"{x:466,y:466,t:1527030506889};\\\", \\\"{x:466,y:467,t:1527030506905};\\\", \\\"{x:466,y:469,t:1527030506928};\\\", \\\"{x:467,y:469,t:1527030507673};\\\", \\\"{x:469,y:469,t:1527030507690};\\\", \\\"{x:470,y:469,t:1527030507706};\\\", \\\"{x:474,y:469,t:1527030507723};\\\", \\\"{x:480,y:469,t:1527030507740};\\\", \\\"{x:485,y:469,t:1527030507756};\\\", \\\"{x:491,y:469,t:1527030507773};\\\", \\\"{x:495,y:469,t:1527030507790};\\\", \\\"{x:497,y:469,t:1527030507807};\\\", \\\"{x:501,y:469,t:1527030507823};\\\", \\\"{x:504,y:469,t:1527030507840};\\\", \\\"{x:514,y:469,t:1527030507856};\\\", \\\"{x:520,y:469,t:1527030507873};\\\", \\\"{x:528,y:469,t:1527030507890};\\\", \\\"{x:534,y:469,t:1527030507907};\\\", \\\"{x:540,y:469,t:1527030507923};\\\", \\\"{x:544,y:469,t:1527030507939};\\\", \\\"{x:547,y:469,t:1527030507957};\\\", \\\"{x:550,y:469,t:1527030507972};\\\", \\\"{x:555,y:469,t:1527030507990};\\\", \\\"{x:560,y:469,t:1527030508007};\\\", \\\"{x:565,y:469,t:1527030508024};\\\", \\\"{x:567,y:469,t:1527030508040};\\\", \\\"{x:568,y:469,t:1527030508136};\\\", \\\"{x:569,y:469,t:1527030508185};\\\", \\\"{x:573,y:469,t:1527030508192};\\\", \\\"{x:575,y:469,t:1527030508207};\\\", \\\"{x:577,y:469,t:1527030508224};\\\", \\\"{x:581,y:469,t:1527030508240};\\\", \\\"{x:583,y:469,t:1527030508256};\\\", \\\"{x:585,y:469,t:1527030508274};\\\", \\\"{x:586,y:469,t:1527030508290};\\\", \\\"{x:587,y:469,t:1527030508307};\\\", \\\"{x:588,y:469,t:1527030508324};\\\", \\\"{x:589,y:469,t:1527030508340};\\\", \\\"{x:590,y:469,t:1527030508357};\\\", \\\"{x:597,y:469,t:1527030511585};\\\", \\\"{x:609,y:469,t:1527030511592};\\\", \\\"{x:645,y:476,t:1527030511609};\\\", \\\"{x:683,y:482,t:1527030511626};\\\", \\\"{x:710,y:490,t:1527030511644};\\\", \\\"{x:730,y:497,t:1527030511659};\\\", \\\"{x:743,y:503,t:1527030511676};\\\", \\\"{x:759,y:509,t:1527030511693};\\\", \\\"{x:780,y:514,t:1527030511710};\\\", \\\"{x:810,y:519,t:1527030511727};\\\", \\\"{x:855,y:528,t:1527030511743};\\\", \\\"{x:908,y:541,t:1527030511760};\\\", \\\"{x:963,y:554,t:1527030511777};\\\", \\\"{x:989,y:560,t:1527030511794};\\\", \\\"{x:1002,y:562,t:1527030511810};\\\", \\\"{x:1005,y:562,t:1527030511828};\\\", \\\"{x:1006,y:563,t:1527030511921};\\\", \\\"{x:1006,y:565,t:1527030511928};\\\", \\\"{x:1010,y:569,t:1527030511943};\\\", \\\"{x:1017,y:576,t:1527030511960};\\\", \\\"{x:1019,y:581,t:1527030511976};\\\", \\\"{x:1020,y:583,t:1527030511993};\\\", \\\"{x:1020,y:587,t:1527030512010};\\\", \\\"{x:1020,y:592,t:1527030512027};\\\", \\\"{x:1026,y:598,t:1527030512044};\\\", \\\"{x:1035,y:603,t:1527030512060};\\\", \\\"{x:1043,y:606,t:1527030512077};\\\", \\\"{x:1047,y:606,t:1527030512093};\\\", \\\"{x:1048,y:606,t:1527030512168};\\\", \\\"{x:1050,y:606,t:1527030512177};\\\", \\\"{x:1058,y:607,t:1527030512194};\\\", \\\"{x:1070,y:610,t:1527030512210};\\\", \\\"{x:1084,y:612,t:1527030512227};\\\", \\\"{x:1092,y:616,t:1527030512244};\\\", \\\"{x:1098,y:617,t:1527030512261};\\\", \\\"{x:1100,y:618,t:1527030512277};\\\", \\\"{x:1101,y:618,t:1527030512369};\\\", \\\"{x:1105,y:618,t:1527030512377};\\\", \\\"{x:1116,y:619,t:1527030512394};\\\", \\\"{x:1136,y:621,t:1527030512411};\\\", \\\"{x:1172,y:628,t:1527030512427};\\\", \\\"{x:1214,y:633,t:1527030512444};\\\", \\\"{x:1267,y:640,t:1527030512461};\\\", \\\"{x:1316,y:643,t:1527030512477};\\\", \\\"{x:1352,y:643,t:1527030512494};\\\", \\\"{x:1392,y:643,t:1527030512511};\\\", \\\"{x:1417,y:643,t:1527030512528};\\\", \\\"{x:1437,y:643,t:1527030512544};\\\", \\\"{x:1459,y:639,t:1527030512561};\\\", \\\"{x:1471,y:638,t:1527030512578};\\\", \\\"{x:1490,y:634,t:1527030512594};\\\", \\\"{x:1513,y:633,t:1527030512611};\\\", \\\"{x:1536,y:633,t:1527030512628};\\\", \\\"{x:1557,y:632,t:1527030512644};\\\", \\\"{x:1568,y:630,t:1527030512661};\\\", \\\"{x:1577,y:630,t:1527030512678};\\\", \\\"{x:1583,y:630,t:1527030512695};\\\", \\\"{x:1586,y:630,t:1527030512711};\\\", \\\"{x:1589,y:630,t:1527030512728};\\\", \\\"{x:1594,y:630,t:1527030512744};\\\", \\\"{x:1600,y:630,t:1527030512761};\\\", \\\"{x:1601,y:630,t:1527030512778};\\\", \\\"{x:1602,y:629,t:1527030519753};\\\", \\\"{x:1604,y:628,t:1527030519760};\\\", \\\"{x:1606,y:627,t:1527030519770};\\\", \\\"{x:1616,y:627,t:1527030519788};\\\", \\\"{x:1622,y:627,t:1527030519805};\\\", \\\"{x:1627,y:627,t:1527030519820};\\\", \\\"{x:1631,y:627,t:1527030519838};\\\", \\\"{x:1632,y:627,t:1527030519855};\\\", \\\"{x:1634,y:627,t:1527030519873};\\\", \\\"{x:1635,y:627,t:1527030519887};\\\", \\\"{x:1640,y:627,t:1527030519905};\\\", \\\"{x:1645,y:627,t:1527030519920};\\\", \\\"{x:1653,y:630,t:1527030519937};\\\", \\\"{x:1659,y:632,t:1527030519954};\\\", \\\"{x:1665,y:634,t:1527030519971};\\\", \\\"{x:1669,y:635,t:1527030519987};\\\", \\\"{x:1671,y:635,t:1527030520004};\\\", \\\"{x:1672,y:635,t:1527030520021};\\\", \\\"{x:1673,y:635,t:1527030520040};\\\", \\\"{x:1674,y:635,t:1527030520054};\\\", \\\"{x:1676,y:635,t:1527030520071};\\\", \\\"{x:1679,y:635,t:1527030520087};\\\", \\\"{x:1683,y:634,t:1527030520104};\\\", \\\"{x:1684,y:634,t:1527030520368};\\\", \\\"{x:1684,y:635,t:1527030520457};\\\", \\\"{x:1684,y:636,t:1527030520480};\\\", \\\"{x:1684,y:637,t:1527030520528};\\\", \\\"{x:1683,y:638,t:1527030520544};\\\", \\\"{x:1682,y:639,t:1527030520560};\\\", \\\"{x:1682,y:640,t:1527030520571};\\\", \\\"{x:1681,y:641,t:1527030520588};\\\", \\\"{x:1679,y:643,t:1527030520606};\\\", \\\"{x:1677,y:644,t:1527030520621};\\\", \\\"{x:1674,y:647,t:1527030520639};\\\", \\\"{x:1672,y:650,t:1527030520655};\\\", \\\"{x:1670,y:652,t:1527030520672};\\\", \\\"{x:1662,y:657,t:1527030520688};\\\", \\\"{x:1658,y:660,t:1527030520705};\\\", \\\"{x:1649,y:666,t:1527030520721};\\\", \\\"{x:1638,y:673,t:1527030520738};\\\", \\\"{x:1627,y:679,t:1527030520755};\\\", \\\"{x:1618,y:684,t:1527030520772};\\\", \\\"{x:1609,y:690,t:1527030520788};\\\", \\\"{x:1605,y:693,t:1527030520805};\\\", \\\"{x:1595,y:699,t:1527030520823};\\\", \\\"{x:1591,y:703,t:1527030520838};\\\", \\\"{x:1590,y:704,t:1527030520856};\\\", \\\"{x:1588,y:705,t:1527030520873};\\\", \\\"{x:1585,y:709,t:1527030520888};\\\", \\\"{x:1581,y:714,t:1527030520905};\\\", \\\"{x:1576,y:719,t:1527030520922};\\\", \\\"{x:1572,y:724,t:1527030520938};\\\", \\\"{x:1569,y:728,t:1527030520955};\\\", \\\"{x:1566,y:731,t:1527030520973};\\\", \\\"{x:1564,y:733,t:1527030520988};\\\", \\\"{x:1559,y:737,t:1527030521005};\\\", \\\"{x:1550,y:744,t:1527030521022};\\\", \\\"{x:1542,y:750,t:1527030521040};\\\", \\\"{x:1536,y:756,t:1527030521056};\\\", \\\"{x:1532,y:762,t:1527030521073};\\\", \\\"{x:1530,y:766,t:1527030521089};\\\", \\\"{x:1526,y:771,t:1527030521106};\\\", \\\"{x:1522,y:776,t:1527030521122};\\\", \\\"{x:1520,y:779,t:1527030521140};\\\", \\\"{x:1518,y:783,t:1527030521156};\\\", \\\"{x:1515,y:788,t:1527030521172};\\\", \\\"{x:1511,y:793,t:1527030521190};\\\", \\\"{x:1508,y:796,t:1527030521206};\\\", \\\"{x:1507,y:799,t:1527030521222};\\\", \\\"{x:1506,y:800,t:1527030521239};\\\", \\\"{x:1504,y:804,t:1527030521256};\\\", \\\"{x:1501,y:806,t:1527030521272};\\\", \\\"{x:1496,y:811,t:1527030521289};\\\", \\\"{x:1493,y:815,t:1527030521306};\\\", \\\"{x:1490,y:818,t:1527030521322};\\\", \\\"{x:1489,y:819,t:1527030521339};\\\", \\\"{x:1489,y:820,t:1527030521356};\\\", \\\"{x:1488,y:821,t:1527030521392};\\\", \\\"{x:1488,y:822,t:1527030521406};\\\", \\\"{x:1487,y:823,t:1527030521422};\\\", \\\"{x:1486,y:823,t:1527030521439};\\\", \\\"{x:1485,y:823,t:1527030521617};\\\", \\\"{x:1485,y:822,t:1527030521632};\\\", \\\"{x:1485,y:820,t:1527030521640};\\\", \\\"{x:1485,y:817,t:1527030521656};\\\", \\\"{x:1485,y:816,t:1527030521673};\\\", \\\"{x:1485,y:814,t:1527030521689};\\\", \\\"{x:1485,y:811,t:1527030521707};\\\", \\\"{x:1485,y:810,t:1527030521724};\\\", \\\"{x:1486,y:807,t:1527030521739};\\\", \\\"{x:1488,y:803,t:1527030521757};\\\", \\\"{x:1491,y:798,t:1527030521773};\\\", \\\"{x:1493,y:793,t:1527030521790};\\\", \\\"{x:1496,y:788,t:1527030521807};\\\", \\\"{x:1498,y:786,t:1527030521824};\\\", \\\"{x:1500,y:781,t:1527030521840};\\\", \\\"{x:1501,y:780,t:1527030521856};\\\", \\\"{x:1502,y:778,t:1527030521873};\\\", \\\"{x:1503,y:776,t:1527030521891};\\\", \\\"{x:1505,y:773,t:1527030521907};\\\", \\\"{x:1507,y:770,t:1527030521924};\\\", \\\"{x:1509,y:768,t:1527030521940};\\\", \\\"{x:1510,y:767,t:1527030521956};\\\", \\\"{x:1510,y:766,t:1527030521973};\\\", \\\"{x:1511,y:763,t:1527030521990};\\\", \\\"{x:1512,y:762,t:1527030522025};\\\", \\\"{x:1513,y:761,t:1527030522073};\\\", \\\"{x:1512,y:762,t:1527030522760};\\\", \\\"{x:1511,y:762,t:1527030522775};\\\", \\\"{x:1509,y:764,t:1527030522791};\\\", \\\"{x:1508,y:764,t:1527030522809};\\\", \\\"{x:1507,y:765,t:1527030523048};\\\", \\\"{x:1506,y:766,t:1527030523059};\\\", \\\"{x:1504,y:767,t:1527030523075};\\\", \\\"{x:1503,y:768,t:1527030523152};\\\", \\\"{x:1501,y:769,t:1527030523176};\\\", \\\"{x:1501,y:770,t:1527030523192};\\\", \\\"{x:1501,y:772,t:1527030523208};\\\", \\\"{x:1500,y:773,t:1527030523225};\\\", \\\"{x:1499,y:775,t:1527030523241};\\\", \\\"{x:1499,y:779,t:1527030523258};\\\", \\\"{x:1497,y:782,t:1527030523275};\\\", \\\"{x:1496,y:784,t:1527030523292};\\\", \\\"{x:1496,y:785,t:1527030523309};\\\", \\\"{x:1495,y:789,t:1527030523326};\\\", \\\"{x:1493,y:791,t:1527030523342};\\\", \\\"{x:1490,y:795,t:1527030523358};\\\", \\\"{x:1488,y:800,t:1527030523375};\\\", \\\"{x:1483,y:806,t:1527030523392};\\\", \\\"{x:1480,y:809,t:1527030523408};\\\", \\\"{x:1480,y:811,t:1527030523425};\\\", \\\"{x:1478,y:813,t:1527030523442};\\\", \\\"{x:1474,y:817,t:1527030523459};\\\", \\\"{x:1469,y:822,t:1527030523475};\\\", \\\"{x:1465,y:825,t:1527030523493};\\\", \\\"{x:1463,y:827,t:1527030523508};\\\", \\\"{x:1462,y:827,t:1527030523526};\\\", \\\"{x:1461,y:829,t:1527030523542};\\\", \\\"{x:1460,y:830,t:1527030523558};\\\", \\\"{x:1457,y:831,t:1527030523575};\\\", \\\"{x:1448,y:837,t:1527030523592};\\\", \\\"{x:1446,y:838,t:1527030523610};\\\", \\\"{x:1445,y:838,t:1527030523625};\\\", \\\"{x:1443,y:838,t:1527030523656};\\\", \\\"{x:1441,y:838,t:1527030523665};\\\", \\\"{x:1438,y:839,t:1527030523675};\\\", \\\"{x:1432,y:841,t:1527030523693};\\\", \\\"{x:1425,y:841,t:1527030523709};\\\", \\\"{x:1418,y:842,t:1527030523725};\\\", \\\"{x:1414,y:843,t:1527030523742};\\\", \\\"{x:1410,y:844,t:1527030523759};\\\", \\\"{x:1405,y:847,t:1527030523775};\\\", \\\"{x:1392,y:851,t:1527030523792};\\\", \\\"{x:1383,y:855,t:1527030523809};\\\", \\\"{x:1373,y:859,t:1527030523826};\\\", \\\"{x:1364,y:863,t:1527030523842};\\\", \\\"{x:1356,y:867,t:1527030523860};\\\", \\\"{x:1345,y:872,t:1527030523876};\\\", \\\"{x:1338,y:874,t:1527030523892};\\\", \\\"{x:1333,y:877,t:1527030523910};\\\", \\\"{x:1329,y:878,t:1527030523927};\\\", \\\"{x:1326,y:878,t:1527030523943};\\\", \\\"{x:1324,y:878,t:1527030523959};\\\", \\\"{x:1319,y:878,t:1527030523976};\\\", \\\"{x:1313,y:878,t:1527030523992};\\\", \\\"{x:1307,y:878,t:1527030524009};\\\", \\\"{x:1295,y:875,t:1527030524026};\\\", \\\"{x:1287,y:871,t:1527030524042};\\\", \\\"{x:1278,y:866,t:1527030524059};\\\", \\\"{x:1272,y:863,t:1527030524077};\\\", \\\"{x:1270,y:862,t:1527030524093};\\\", \\\"{x:1268,y:860,t:1527030524110};\\\", \\\"{x:1267,y:858,t:1527030524127};\\\", \\\"{x:1266,y:857,t:1527030524144};\\\", \\\"{x:1266,y:854,t:1527030524159};\\\", \\\"{x:1266,y:847,t:1527030524176};\\\", \\\"{x:1275,y:840,t:1527030524194};\\\", \\\"{x:1285,y:835,t:1527030524209};\\\", \\\"{x:1297,y:833,t:1527030524226};\\\", \\\"{x:1307,y:831,t:1527030524243};\\\", \\\"{x:1315,y:831,t:1527030524259};\\\", \\\"{x:1327,y:829,t:1527030524277};\\\", \\\"{x:1342,y:829,t:1527030524293};\\\", \\\"{x:1361,y:828,t:1527030524309};\\\", \\\"{x:1374,y:828,t:1527030524326};\\\", \\\"{x:1385,y:828,t:1527030524343};\\\", \\\"{x:1390,y:828,t:1527030524360};\\\", \\\"{x:1394,y:828,t:1527030524376};\\\", \\\"{x:1397,y:828,t:1527030524393};\\\", \\\"{x:1403,y:828,t:1527030524410};\\\", \\\"{x:1408,y:828,t:1527030524427};\\\", \\\"{x:1415,y:828,t:1527030524443};\\\", \\\"{x:1421,y:828,t:1527030524460};\\\", \\\"{x:1428,y:828,t:1527030524477};\\\", \\\"{x:1432,y:828,t:1527030524493};\\\", \\\"{x:1439,y:828,t:1527030524511};\\\", \\\"{x:1447,y:828,t:1527030524527};\\\", \\\"{x:1450,y:828,t:1527030524544};\\\", \\\"{x:1451,y:828,t:1527030524560};\\\", \\\"{x:1453,y:828,t:1527030524600};\\\", \\\"{x:1455,y:828,t:1527030524610};\\\", \\\"{x:1462,y:831,t:1527030524627};\\\", \\\"{x:1465,y:832,t:1527030524643};\\\", \\\"{x:1467,y:834,t:1527030524661};\\\", \\\"{x:1468,y:835,t:1527030524677};\\\", \\\"{x:1468,y:837,t:1527030524694};\\\", \\\"{x:1468,y:838,t:1527030524710};\\\", \\\"{x:1468,y:839,t:1527030524728};\\\", \\\"{x:1469,y:840,t:1527030524760};\\\", \\\"{x:1472,y:839,t:1527030524840};\\\", \\\"{x:1474,y:837,t:1527030524848};\\\", \\\"{x:1476,y:835,t:1527030524861};\\\", \\\"{x:1482,y:828,t:1527030524878};\\\", \\\"{x:1485,y:823,t:1527030524895};\\\", \\\"{x:1491,y:815,t:1527030524910};\\\", \\\"{x:1494,y:811,t:1527030524927};\\\", \\\"{x:1500,y:801,t:1527030524944};\\\", \\\"{x:1507,y:793,t:1527030524960};\\\", \\\"{x:1515,y:787,t:1527030524977};\\\", \\\"{x:1530,y:781,t:1527030524994};\\\", \\\"{x:1546,y:772,t:1527030525011};\\\", \\\"{x:1568,y:766,t:1527030525028};\\\", \\\"{x:1586,y:757,t:1527030525045};\\\", \\\"{x:1592,y:754,t:1527030525060};\\\", \\\"{x:1594,y:752,t:1527030525077};\\\", \\\"{x:1595,y:751,t:1527030525095};\\\", \\\"{x:1595,y:749,t:1527030525111};\\\", \\\"{x:1593,y:745,t:1527030525127};\\\", \\\"{x:1571,y:736,t:1527030525144};\\\", \\\"{x:1527,y:727,t:1527030525161};\\\", \\\"{x:1446,y:714,t:1527030525177};\\\", \\\"{x:1352,y:703,t:1527030525195};\\\", \\\"{x:1250,y:691,t:1527030525212};\\\", \\\"{x:1158,y:676,t:1527030525227};\\\", \\\"{x:1058,y:664,t:1527030525245};\\\", \\\"{x:971,y:647,t:1527030525262};\\\", \\\"{x:888,y:626,t:1527030525278};\\\", \\\"{x:825,y:609,t:1527030525294};\\\", \\\"{x:787,y:597,t:1527030525305};\\\", \\\"{x:763,y:588,t:1527030525321};\\\", \\\"{x:750,y:579,t:1527030525338};\\\", \\\"{x:740,y:571,t:1527030525355};\\\", \\\"{x:732,y:560,t:1527030525371};\\\", \\\"{x:719,y:546,t:1527030525388};\\\", \\\"{x:701,y:535,t:1527030525404};\\\", \\\"{x:680,y:525,t:1527030525421};\\\", \\\"{x:666,y:521,t:1527030525437};\\\", \\\"{x:664,y:521,t:1527030525455};\\\", \\\"{x:666,y:521,t:1527030525568};\\\", \\\"{x:673,y:524,t:1527030525576};\\\", \\\"{x:678,y:526,t:1527030525588};\\\", \\\"{x:692,y:531,t:1527030525605};\\\", \\\"{x:710,y:537,t:1527030525621};\\\", \\\"{x:729,y:540,t:1527030525638};\\\", \\\"{x:744,y:542,t:1527030525654};\\\", \\\"{x:759,y:544,t:1527030525672};\\\", \\\"{x:773,y:544,t:1527030525687};\\\", \\\"{x:786,y:545,t:1527030525704};\\\", \\\"{x:790,y:546,t:1527030525721};\\\", \\\"{x:792,y:546,t:1527030525737};\\\", \\\"{x:793,y:546,t:1527030525754};\\\", \\\"{x:794,y:546,t:1527030525771};\\\", \\\"{x:795,y:546,t:1527030525788};\\\", \\\"{x:796,y:546,t:1527030525804};\\\", \\\"{x:800,y:546,t:1527030525822};\\\", \\\"{x:804,y:546,t:1527030525837};\\\", \\\"{x:808,y:546,t:1527030525855};\\\", \\\"{x:810,y:546,t:1527030525872};\\\", \\\"{x:811,y:545,t:1527030525887};\\\", \\\"{x:812,y:545,t:1527030525928};\\\", \\\"{x:813,y:545,t:1527030525938};\\\", \\\"{x:814,y:545,t:1527030525960};\\\", \\\"{x:815,y:545,t:1527030525972};\\\", \\\"{x:816,y:545,t:1527030525988};\\\", \\\"{x:817,y:545,t:1527030526004};\\\", \\\"{x:819,y:547,t:1527030526021};\\\", \\\"{x:820,y:548,t:1527030526048};\\\", \\\"{x:820,y:549,t:1527030526056};\\\", \\\"{x:820,y:550,t:1527030526072};\\\", \\\"{x:820,y:552,t:1527030526089};\\\", \\\"{x:820,y:555,t:1527030526104};\\\", \\\"{x:820,y:556,t:1527030526122};\\\", \\\"{x:821,y:558,t:1527030526139};\\\", \\\"{x:821,y:559,t:1527030526161};\\\", \\\"{x:822,y:560,t:1527030526176};\\\", \\\"{x:822,y:561,t:1527030526200};\\\", \\\"{x:822,y:562,t:1527030526208};\\\", \\\"{x:823,y:563,t:1527030526222};\\\", \\\"{x:824,y:564,t:1527030526239};\\\", \\\"{x:825,y:566,t:1527030526255};\\\", \\\"{x:826,y:567,t:1527030526272};\\\", \\\"{x:826,y:569,t:1527030526288};\\\", \\\"{x:827,y:570,t:1527030526305};\\\", \\\"{x:828,y:572,t:1527030526322};\\\", \\\"{x:829,y:572,t:1527030526339};\\\", \\\"{x:830,y:574,t:1527030526354};\\\", \\\"{x:830,y:575,t:1527030526372};\\\", \\\"{x:831,y:575,t:1527030526388};\\\", \\\"{x:831,y:576,t:1527030526404};\\\", \\\"{x:829,y:576,t:1527030526848};\\\", \\\"{x:825,y:578,t:1527030526856};\\\", \\\"{x:813,y:581,t:1527030526873};\\\", \\\"{x:795,y:584,t:1527030526889};\\\", \\\"{x:777,y:586,t:1527030526906};\\\", \\\"{x:760,y:586,t:1527030526922};\\\", \\\"{x:740,y:586,t:1527030526938};\\\", \\\"{x:720,y:589,t:1527030526956};\\\", \\\"{x:697,y:589,t:1527030526972};\\\", \\\"{x:685,y:590,t:1527030526989};\\\", \\\"{x:672,y:591,t:1527030527005};\\\", \\\"{x:664,y:593,t:1527030527023};\\\", \\\"{x:658,y:595,t:1527030527038};\\\", \\\"{x:650,y:598,t:1527030527055};\\\", \\\"{x:628,y:608,t:1527030527072};\\\", \\\"{x:613,y:615,t:1527030527089};\\\", \\\"{x:596,y:619,t:1527030527106};\\\", \\\"{x:582,y:623,t:1527030527122};\\\", \\\"{x:567,y:625,t:1527030527139};\\\", \\\"{x:539,y:625,t:1527030527155};\\\", \\\"{x:517,y:625,t:1527030527172};\\\", \\\"{x:501,y:625,t:1527030527189};\\\", \\\"{x:496,y:625,t:1527030527206};\\\", \\\"{x:495,y:625,t:1527030527224};\\\", \\\"{x:497,y:621,t:1527030527240};\\\", \\\"{x:502,y:619,t:1527030527256};\\\", \\\"{x:516,y:612,t:1527030527272};\\\", \\\"{x:529,y:607,t:1527030527289};\\\", \\\"{x:545,y:605,t:1527030527306};\\\", \\\"{x:564,y:600,t:1527030527323};\\\", \\\"{x:579,y:596,t:1527030527340};\\\", \\\"{x:589,y:593,t:1527030527356};\\\", \\\"{x:597,y:591,t:1527030527372};\\\", \\\"{x:604,y:588,t:1527030527390};\\\", \\\"{x:607,y:587,t:1527030527405};\\\", \\\"{x:608,y:586,t:1527030527423};\\\", \\\"{x:612,y:586,t:1527030527928};\\\", \\\"{x:621,y:586,t:1527030527939};\\\", \\\"{x:672,y:607,t:1527030527957};\\\", \\\"{x:754,y:638,t:1527030527973};\\\", \\\"{x:881,y:676,t:1527030527989};\\\", \\\"{x:1028,y:720,t:1527030528006};\\\", \\\"{x:1187,y:755,t:1527030528023};\\\", \\\"{x:1311,y:787,t:1527030528040};\\\", \\\"{x:1434,y:824,t:1527030528057};\\\", \\\"{x:1464,y:832,t:1527030528073};\\\", \\\"{x:1485,y:838,t:1527030528090};\\\", \\\"{x:1506,y:845,t:1527030528106};\\\", \\\"{x:1529,y:852,t:1527030528124};\\\", \\\"{x:1555,y:859,t:1527030528140};\\\", \\\"{x:1579,y:866,t:1527030528156};\\\", \\\"{x:1600,y:873,t:1527030528174};\\\", \\\"{x:1607,y:875,t:1527030528190};\\\", \\\"{x:1608,y:876,t:1527030528206};\\\", \\\"{x:1609,y:877,t:1527030528240};\\\", \\\"{x:1613,y:884,t:1527030528256};\\\", \\\"{x:1622,y:889,t:1527030528274};\\\", \\\"{x:1623,y:889,t:1527030528290};\\\", \\\"{x:1623,y:890,t:1527030528337};\\\", \\\"{x:1621,y:891,t:1527030528345};\\\", \\\"{x:1618,y:891,t:1527030528357};\\\", \\\"{x:1608,y:891,t:1527030528374};\\\", \\\"{x:1593,y:891,t:1527030528389};\\\", \\\"{x:1576,y:889,t:1527030528407};\\\", \\\"{x:1568,y:888,t:1527030528424};\\\", \\\"{x:1567,y:888,t:1527030528440};\\\", \\\"{x:1566,y:888,t:1527030528472};\\\", \\\"{x:1566,y:887,t:1527030528481};\\\", \\\"{x:1565,y:885,t:1527030528497};\\\", \\\"{x:1565,y:882,t:1527030528507};\\\", \\\"{x:1560,y:873,t:1527030528524};\\\", \\\"{x:1550,y:863,t:1527030528540};\\\", \\\"{x:1543,y:859,t:1527030528556};\\\", \\\"{x:1540,y:858,t:1527030528573};\\\", \\\"{x:1539,y:856,t:1527030528591};\\\", \\\"{x:1536,y:855,t:1527030528606};\\\", \\\"{x:1534,y:849,t:1527030528624};\\\", \\\"{x:1527,y:841,t:1527030528640};\\\", \\\"{x:1523,y:837,t:1527030528657};\\\", \\\"{x:1522,y:835,t:1527030528673};\\\", \\\"{x:1520,y:832,t:1527030528691};\\\", \\\"{x:1520,y:830,t:1527030528707};\\\", \\\"{x:1520,y:826,t:1527030528724};\\\", \\\"{x:1520,y:819,t:1527030528740};\\\", \\\"{x:1520,y:809,t:1527030528757};\\\", \\\"{x:1520,y:801,t:1527030528774};\\\", \\\"{x:1521,y:793,t:1527030528790};\\\", \\\"{x:1523,y:787,t:1527030528807};\\\", \\\"{x:1525,y:781,t:1527030528823};\\\", \\\"{x:1529,y:773,t:1527030528840};\\\", \\\"{x:1531,y:768,t:1527030528857};\\\", \\\"{x:1534,y:763,t:1527030528874};\\\", \\\"{x:1537,y:758,t:1527030528891};\\\", \\\"{x:1538,y:756,t:1527030528907};\\\", \\\"{x:1539,y:754,t:1527030528924};\\\", \\\"{x:1539,y:756,t:1527030529032};\\\", \\\"{x:1536,y:761,t:1527030529040};\\\", \\\"{x:1529,y:772,t:1527030529057};\\\", \\\"{x:1522,y:783,t:1527030529074};\\\", \\\"{x:1515,y:794,t:1527030529090};\\\", \\\"{x:1507,y:807,t:1527030529108};\\\", \\\"{x:1500,y:817,t:1527030529124};\\\", \\\"{x:1494,y:825,t:1527030529140};\\\", \\\"{x:1490,y:834,t:1527030529158};\\\", \\\"{x:1488,y:837,t:1527030529174};\\\", \\\"{x:1488,y:839,t:1527030529190};\\\", \\\"{x:1489,y:842,t:1527030529208};\\\", \\\"{x:1492,y:845,t:1527030529224};\\\", \\\"{x:1511,y:850,t:1527030529241};\\\", \\\"{x:1535,y:855,t:1527030529258};\\\", \\\"{x:1557,y:857,t:1527030529273};\\\", \\\"{x:1576,y:857,t:1527030529291};\\\", \\\"{x:1586,y:857,t:1527030529307};\\\", \\\"{x:1589,y:857,t:1527030529323};\\\", \\\"{x:1591,y:857,t:1527030529340};\\\", \\\"{x:1593,y:856,t:1527030529358};\\\", \\\"{x:1599,y:855,t:1527030529374};\\\", \\\"{x:1607,y:855,t:1527030529390};\\\", \\\"{x:1617,y:855,t:1527030529408};\\\", \\\"{x:1626,y:855,t:1527030529424};\\\", \\\"{x:1630,y:855,t:1527030529441};\\\", \\\"{x:1631,y:855,t:1527030529458};\\\", \\\"{x:1632,y:855,t:1527030529568};\\\", \\\"{x:1634,y:855,t:1527030529576};\\\", \\\"{x:1639,y:852,t:1527030529591};\\\", \\\"{x:1648,y:851,t:1527030529608};\\\", \\\"{x:1664,y:843,t:1527030529624};\\\", \\\"{x:1678,y:835,t:1527030529641};\\\", \\\"{x:1688,y:827,t:1527030529658};\\\", \\\"{x:1694,y:821,t:1527030529675};\\\", \\\"{x:1697,y:815,t:1527030529691};\\\", \\\"{x:1699,y:809,t:1527030529708};\\\", \\\"{x:1701,y:802,t:1527030529725};\\\", \\\"{x:1701,y:800,t:1527030529741};\\\", \\\"{x:1701,y:796,t:1527030529757};\\\", \\\"{x:1701,y:794,t:1527030529775};\\\", \\\"{x:1696,y:791,t:1527030529791};\\\", \\\"{x:1689,y:786,t:1527030529807};\\\", \\\"{x:1677,y:778,t:1527030529824};\\\", \\\"{x:1668,y:770,t:1527030529841};\\\", \\\"{x:1663,y:761,t:1527030529858};\\\", \\\"{x:1661,y:750,t:1527030529875};\\\", \\\"{x:1664,y:730,t:1527030529892};\\\", \\\"{x:1675,y:715,t:1527030529908};\\\", \\\"{x:1683,y:706,t:1527030529925};\\\", \\\"{x:1689,y:702,t:1527030529941};\\\", \\\"{x:1695,y:699,t:1527030529957};\\\", \\\"{x:1699,y:697,t:1527030529975};\\\", \\\"{x:1703,y:695,t:1527030529992};\\\", \\\"{x:1706,y:694,t:1527030530008};\\\", \\\"{x:1704,y:694,t:1527030530112};\\\", \\\"{x:1699,y:694,t:1527030530125};\\\", \\\"{x:1683,y:691,t:1527030530142};\\\", \\\"{x:1673,y:690,t:1527030530158};\\\", \\\"{x:1668,y:689,t:1527030530175};\\\", \\\"{x:1667,y:689,t:1527030530200};\\\", \\\"{x:1667,y:687,t:1527030530208};\\\", \\\"{x:1667,y:681,t:1527030530225};\\\", \\\"{x:1667,y:677,t:1527030530241};\\\", \\\"{x:1666,y:673,t:1527030530257};\\\", \\\"{x:1666,y:672,t:1527030530275};\\\", \\\"{x:1665,y:669,t:1527030530291};\\\", \\\"{x:1663,y:666,t:1527030530309};\\\", \\\"{x:1661,y:665,t:1527030530325};\\\", \\\"{x:1658,y:662,t:1527030530342};\\\", \\\"{x:1655,y:659,t:1527030530359};\\\", \\\"{x:1652,y:658,t:1527030530374};\\\", \\\"{x:1650,y:656,t:1527030530392};\\\", \\\"{x:1649,y:656,t:1527030530408};\\\", \\\"{x:1647,y:655,t:1527030530425};\\\", \\\"{x:1646,y:655,t:1527030530464};\\\", \\\"{x:1646,y:654,t:1527030530480};\\\", \\\"{x:1643,y:654,t:1527030530913};\\\", \\\"{x:1636,y:654,t:1527030530926};\\\", \\\"{x:1616,y:651,t:1527030530942};\\\", \\\"{x:1598,y:650,t:1527030530959};\\\", \\\"{x:1590,y:649,t:1527030530976};\\\", \\\"{x:1586,y:648,t:1527030530992};\\\", \\\"{x:1584,y:647,t:1527030531009};\\\", \\\"{x:1582,y:647,t:1527030531025};\\\", \\\"{x:1578,y:646,t:1527030531042};\\\", \\\"{x:1570,y:645,t:1527030531059};\\\", \\\"{x:1562,y:644,t:1527030531076};\\\", \\\"{x:1557,y:642,t:1527030531092};\\\", \\\"{x:1549,y:640,t:1527030531108};\\\", \\\"{x:1541,y:639,t:1527030531126};\\\", \\\"{x:1534,y:639,t:1527030531142};\\\", \\\"{x:1523,y:639,t:1527030531159};\\\", \\\"{x:1508,y:638,t:1527030531176};\\\", \\\"{x:1488,y:636,t:1527030531192};\\\", \\\"{x:1473,y:634,t:1527030531209};\\\", \\\"{x:1459,y:634,t:1527030531226};\\\", \\\"{x:1441,y:634,t:1527030531243};\\\", \\\"{x:1425,y:634,t:1527030531259};\\\", \\\"{x:1404,y:634,t:1527030531276};\\\", \\\"{x:1384,y:634,t:1527030531293};\\\", \\\"{x:1369,y:634,t:1527030531309};\\\", \\\"{x:1357,y:633,t:1527030531326};\\\", \\\"{x:1345,y:632,t:1527030531342};\\\", \\\"{x:1330,y:632,t:1527030531359};\\\", \\\"{x:1313,y:632,t:1527030531376};\\\", \\\"{x:1287,y:631,t:1527030531392};\\\", \\\"{x:1276,y:629,t:1527030531408};\\\", \\\"{x:1271,y:629,t:1527030531426};\\\", \\\"{x:1270,y:628,t:1527030531472};\\\", \\\"{x:1271,y:628,t:1527030531505};\\\", \\\"{x:1277,y:628,t:1527030531512};\\\", \\\"{x:1285,y:628,t:1527030531525};\\\", \\\"{x:1311,y:628,t:1527030531542};\\\", \\\"{x:1354,y:628,t:1527030531559};\\\", \\\"{x:1404,y:628,t:1527030531576};\\\", \\\"{x:1491,y:628,t:1527030531593};\\\", \\\"{x:1538,y:628,t:1527030531609};\\\", \\\"{x:1568,y:628,t:1527030531626};\\\", \\\"{x:1586,y:628,t:1527030531643};\\\", \\\"{x:1600,y:628,t:1527030531660};\\\", \\\"{x:1608,y:628,t:1527030531676};\\\", \\\"{x:1614,y:628,t:1527030531693};\\\", \\\"{x:1615,y:628,t:1527030531710};\\\", \\\"{x:1616,y:628,t:1527030531728};\\\", \\\"{x:1616,y:629,t:1527030531856};\\\", \\\"{x:1616,y:632,t:1527030531864};\\\", \\\"{x:1615,y:636,t:1527030531876};\\\", \\\"{x:1612,y:641,t:1527030531892};\\\", \\\"{x:1608,y:650,t:1527030531910};\\\", \\\"{x:1603,y:665,t:1527030531926};\\\", \\\"{x:1595,y:682,t:1527030531942};\\\", \\\"{x:1593,y:697,t:1527030531959};\\\", \\\"{x:1588,y:714,t:1527030531976};\\\", \\\"{x:1577,y:744,t:1527030531993};\\\", \\\"{x:1570,y:761,t:1527030532010};\\\", \\\"{x:1562,y:776,t:1527030532026};\\\", \\\"{x:1556,y:786,t:1527030532043};\\\", \\\"{x:1551,y:795,t:1527030532060};\\\", \\\"{x:1548,y:799,t:1527030532076};\\\", \\\"{x:1544,y:803,t:1527030532093};\\\", \\\"{x:1541,y:807,t:1527030532110};\\\", \\\"{x:1537,y:811,t:1527030532126};\\\", \\\"{x:1533,y:814,t:1527030532143};\\\", \\\"{x:1529,y:818,t:1527030532160};\\\", \\\"{x:1524,y:823,t:1527030532176};\\\", \\\"{x:1519,y:827,t:1527030532193};\\\", \\\"{x:1513,y:831,t:1527030532210};\\\", \\\"{x:1510,y:833,t:1527030532227};\\\", \\\"{x:1506,y:837,t:1527030532243};\\\", \\\"{x:1499,y:844,t:1527030532260};\\\", \\\"{x:1486,y:854,t:1527030532276};\\\", \\\"{x:1470,y:866,t:1527030532292};\\\", \\\"{x:1444,y:887,t:1527030532310};\\\", \\\"{x:1423,y:902,t:1527030532327};\\\", \\\"{x:1409,y:915,t:1527030532343};\\\", \\\"{x:1400,y:925,t:1527030532359};\\\", \\\"{x:1381,y:937,t:1527030532376};\\\", \\\"{x:1374,y:942,t:1527030532393};\\\", \\\"{x:1367,y:946,t:1527030532410};\\\", \\\"{x:1358,y:950,t:1527030532427};\\\", \\\"{x:1344,y:955,t:1527030532443};\\\", \\\"{x:1330,y:959,t:1527030532460};\\\", \\\"{x:1319,y:961,t:1527030532477};\\\", \\\"{x:1305,y:965,t:1527030532494};\\\", \\\"{x:1294,y:968,t:1527030532510};\\\", \\\"{x:1289,y:970,t:1527030532527};\\\", \\\"{x:1286,y:970,t:1527030532544};\\\", \\\"{x:1290,y:969,t:1527030532624};\\\", \\\"{x:1297,y:965,t:1527030532633};\\\", \\\"{x:1303,y:963,t:1527030532644};\\\", \\\"{x:1323,y:957,t:1527030532659};\\\", \\\"{x:1347,y:948,t:1527030532677};\\\", \\\"{x:1371,y:941,t:1527030532694};\\\", \\\"{x:1393,y:936,t:1527030532710};\\\", \\\"{x:1407,y:932,t:1527030532726};\\\", \\\"{x:1414,y:929,t:1527030532744};\\\", \\\"{x:1420,y:926,t:1527030532760};\\\", \\\"{x:1428,y:921,t:1527030532777};\\\", \\\"{x:1435,y:917,t:1527030532794};\\\", \\\"{x:1441,y:913,t:1527030532810};\\\", \\\"{x:1450,y:907,t:1527030532827};\\\", \\\"{x:1456,y:902,t:1527030532844};\\\", \\\"{x:1458,y:900,t:1527030532860};\\\", \\\"{x:1460,y:897,t:1527030532877};\\\", \\\"{x:1462,y:895,t:1527030532894};\\\", \\\"{x:1465,y:892,t:1527030532910};\\\", \\\"{x:1466,y:887,t:1527030532927};\\\", \\\"{x:1468,y:883,t:1527030532944};\\\", \\\"{x:1470,y:875,t:1527030532961};\\\", \\\"{x:1472,y:868,t:1527030532977};\\\", \\\"{x:1473,y:864,t:1527030532993};\\\", \\\"{x:1474,y:858,t:1527030533011};\\\", \\\"{x:1476,y:852,t:1527030533026};\\\", \\\"{x:1478,y:845,t:1527030533043};\\\", \\\"{x:1481,y:837,t:1527030533061};\\\", \\\"{x:1483,y:826,t:1527030533077};\\\", \\\"{x:1487,y:821,t:1527030533095};\\\", \\\"{x:1490,y:814,t:1527030533111};\\\", \\\"{x:1492,y:811,t:1527030533127};\\\", \\\"{x:1492,y:810,t:1527030533144};\\\", \\\"{x:1492,y:809,t:1527030533161};\\\", \\\"{x:1492,y:811,t:1527030533297};\\\", \\\"{x:1492,y:816,t:1527030533311};\\\", \\\"{x:1492,y:824,t:1527030533327};\\\", \\\"{x:1490,y:832,t:1527030533344};\\\", \\\"{x:1484,y:844,t:1527030533361};\\\", \\\"{x:1483,y:845,t:1527030533378};\\\", \\\"{x:1482,y:847,t:1527030533657};\\\", \\\"{x:1480,y:848,t:1527030533664};\\\", \\\"{x:1478,y:849,t:1527030533678};\\\", \\\"{x:1474,y:851,t:1527030533694};\\\", \\\"{x:1468,y:853,t:1527030533711};\\\", \\\"{x:1464,y:853,t:1527030533728};\\\", \\\"{x:1456,y:856,t:1527030533744};\\\", \\\"{x:1445,y:859,t:1527030533761};\\\", \\\"{x:1440,y:861,t:1527030533778};\\\", \\\"{x:1435,y:863,t:1527030533794};\\\", \\\"{x:1432,y:864,t:1527030533811};\\\", \\\"{x:1428,y:867,t:1527030533828};\\\", \\\"{x:1425,y:868,t:1527030533844};\\\", \\\"{x:1421,y:870,t:1527030533861};\\\", \\\"{x:1418,y:872,t:1527030533878};\\\", \\\"{x:1417,y:872,t:1527030533894};\\\", \\\"{x:1414,y:874,t:1527030533911};\\\", \\\"{x:1412,y:874,t:1527030533928};\\\", \\\"{x:1398,y:875,t:1527030533944};\\\", \\\"{x:1378,y:875,t:1527030533961};\\\", \\\"{x:1351,y:875,t:1527030533978};\\\", \\\"{x:1319,y:875,t:1527030533995};\\\", \\\"{x:1283,y:875,t:1527030534011};\\\", \\\"{x:1251,y:875,t:1527030534028};\\\", \\\"{x:1218,y:875,t:1527030534045};\\\", \\\"{x:1188,y:875,t:1527030534061};\\\", \\\"{x:1161,y:875,t:1527030534078};\\\", \\\"{x:1133,y:875,t:1527030534095};\\\", \\\"{x:1098,y:872,t:1527030534111};\\\", \\\"{x:1053,y:865,t:1527030534127};\\\", \\\"{x:985,y:856,t:1527030534145};\\\", \\\"{x:932,y:848,t:1527030534161};\\\", \\\"{x:873,y:840,t:1527030534178};\\\", \\\"{x:817,y:832,t:1527030534195};\\\", \\\"{x:755,y:820,t:1527030534211};\\\", \\\"{x:677,y:809,t:1527030534228};\\\", \\\"{x:602,y:800,t:1527030534245};\\\", \\\"{x:549,y:793,t:1527030534261};\\\", \\\"{x:515,y:783,t:1527030534278};\\\", \\\"{x:492,y:775,t:1527030534294};\\\", \\\"{x:479,y:772,t:1527030534312};\\\", \\\"{x:465,y:769,t:1527030534328};\\\", \\\"{x:442,y:765,t:1527030534345};\\\", \\\"{x:433,y:763,t:1527030534362};\\\", \\\"{x:428,y:760,t:1527030534378};\\\", \\\"{x:427,y:756,t:1527030534395};\\\", \\\"{x:427,y:751,t:1527030534412};\\\", \\\"{x:427,y:747,t:1527030534428};\\\", \\\"{x:427,y:742,t:1527030534445};\\\", \\\"{x:433,y:736,t:1527030534462};\\\", \\\"{x:442,y:732,t:1527030534478};\\\", \\\"{x:445,y:731,t:1527030534495};\\\", \\\"{x:451,y:729,t:1527030534512};\\\", \\\"{x:457,y:729,t:1527030534528};\\\", \\\"{x:462,y:729,t:1527030534536};\\\", \\\"{x:468,y:729,t:1527030534554};\\\", \\\"{x:477,y:730,t:1527030534570};\\\", \\\"{x:485,y:733,t:1527030534587};\\\", \\\"{x:489,y:734,t:1527030534604};\\\", \\\"{x:491,y:735,t:1527030534620};\\\", \\\"{x:493,y:735,t:1527030534637};\\\", \\\"{x:494,y:736,t:1527030534672};\\\" ] }, { \\\"rt\\\": 48146, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 501826, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -P \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:496,y:736,t:1527030537280};\\\", \\\"{x:502,y:732,t:1527030537297};\\\", \\\"{x:506,y:729,t:1527030537314};\\\", \\\"{x:510,y:723,t:1527030537330};\\\", \\\"{x:514,y:709,t:1527030537347};\\\", \\\"{x:514,y:691,t:1527030537364};\\\", \\\"{x:515,y:672,t:1527030537381};\\\", \\\"{x:515,y:654,t:1527030537397};\\\", \\\"{x:513,y:637,t:1527030537414};\\\", \\\"{x:511,y:620,t:1527030537431};\\\", \\\"{x:505,y:598,t:1527030537447};\\\", \\\"{x:489,y:555,t:1527030537465};\\\", \\\"{x:469,y:524,t:1527030537481};\\\", \\\"{x:442,y:502,t:1527030537498};\\\", \\\"{x:423,y:485,t:1527030537514};\\\", \\\"{x:404,y:476,t:1527030537532};\\\", \\\"{x:392,y:470,t:1527030537547};\\\", \\\"{x:388,y:470,t:1527030537564};\\\", \\\"{x:386,y:470,t:1527030537581};\\\", \\\"{x:379,y:467,t:1527030537598};\\\", \\\"{x:370,y:465,t:1527030537614};\\\", \\\"{x:361,y:463,t:1527030537631};\\\", \\\"{x:359,y:462,t:1527030537648};\\\", \\\"{x:358,y:461,t:1527030537728};\\\", \\\"{x:358,y:459,t:1527030537752};\\\", \\\"{x:362,y:459,t:1527030537764};\\\", \\\"{x:365,y:457,t:1527030537782};\\\", \\\"{x:367,y:456,t:1527030537798};\\\", \\\"{x:369,y:455,t:1527030537814};\\\", \\\"{x:371,y:455,t:1527030537831};\\\", \\\"{x:379,y:452,t:1527030537848};\\\", \\\"{x:385,y:452,t:1527030537864};\\\", \\\"{x:387,y:452,t:1527030537881};\\\", \\\"{x:388,y:452,t:1527030537898};\\\", \\\"{x:389,y:452,t:1527030537961};\\\", \\\"{x:390,y:452,t:1527030537967};\\\", \\\"{x:391,y:452,t:1527030537981};\\\", \\\"{x:393,y:451,t:1527030537998};\\\", \\\"{x:395,y:450,t:1527030538014};\\\", \\\"{x:397,y:449,t:1527030538031};\\\", \\\"{x:399,y:448,t:1527030538048};\\\", \\\"{x:400,y:448,t:1527030538065};\\\", \\\"{x:401,y:448,t:1527030538081};\\\", \\\"{x:403,y:447,t:1527030538097};\\\", \\\"{x:407,y:444,t:1527030538115};\\\", \\\"{x:415,y:440,t:1527030538131};\\\", \\\"{x:424,y:437,t:1527030538148};\\\", \\\"{x:433,y:432,t:1527030538165};\\\", \\\"{x:435,y:431,t:1527030538181};\\\", \\\"{x:436,y:431,t:1527030538198};\\\", \\\"{x:437,y:430,t:1527030538215};\\\", \\\"{x:439,y:430,t:1527030538231};\\\", \\\"{x:455,y:423,t:1527030538247};\\\", \\\"{x:464,y:421,t:1527030538265};\\\", \\\"{x:472,y:418,t:1527030538281};\\\", \\\"{x:477,y:417,t:1527030538298};\\\", \\\"{x:482,y:415,t:1527030538315};\\\", \\\"{x:485,y:414,t:1527030538331};\\\", \\\"{x:487,y:414,t:1527030538348};\\\", \\\"{x:493,y:412,t:1527030538365};\\\", \\\"{x:498,y:411,t:1527030538381};\\\", \\\"{x:507,y:410,t:1527030538398};\\\", \\\"{x:517,y:408,t:1527030538415};\\\", \\\"{x:522,y:406,t:1527030538431};\\\", \\\"{x:525,y:405,t:1527030538448};\\\", \\\"{x:527,y:405,t:1527030538465};\\\", \\\"{x:528,y:404,t:1527030538481};\\\", \\\"{x:529,y:404,t:1527030538498};\\\", \\\"{x:530,y:404,t:1527030538552};\\\", \\\"{x:532,y:404,t:1527030539824};\\\", \\\"{x:533,y:404,t:1527030539864};\\\", \\\"{x:534,y:404,t:1527030539920};\\\", \\\"{x:535,y:405,t:1527030539933};\\\", \\\"{x:538,y:406,t:1527030539949};\\\", \\\"{x:539,y:407,t:1527030539966};\\\", \\\"{x:541,y:408,t:1527030539992};\\\", \\\"{x:541,y:409,t:1527030540008};\\\", \\\"{x:542,y:410,t:1527030540048};\\\", \\\"{x:543,y:410,t:1527030540056};\\\", \\\"{x:544,y:410,t:1527030540080};\\\", \\\"{x:544,y:411,t:1527030540088};\\\", \\\"{x:545,y:412,t:1527030540104};\\\", \\\"{x:546,y:413,t:1527030540136};\\\", \\\"{x:547,y:413,t:1527030540159};\\\", \\\"{x:547,y:415,t:1527030540184};\\\", \\\"{x:548,y:415,t:1527030540864};\\\", \\\"{x:549,y:415,t:1527030540880};\\\", \\\"{x:553,y:415,t:1527030540888};\\\", \\\"{x:554,y:415,t:1527030540900};\\\", \\\"{x:555,y:415,t:1527030540916};\\\", \\\"{x:545,y:421,t:1527030540933};\\\", \\\"{x:526,y:425,t:1527030540950};\\\", \\\"{x:524,y:426,t:1527030540968};\\\", \\\"{x:525,y:426,t:1527030541808};\\\", \\\"{x:526,y:424,t:1527030541817};\\\", \\\"{x:533,y:421,t:1527030541834};\\\", \\\"{x:538,y:419,t:1527030541850};\\\", \\\"{x:550,y:416,t:1527030541867};\\\", \\\"{x:562,y:414,t:1527030541885};\\\", \\\"{x:572,y:412,t:1527030541901};\\\", \\\"{x:576,y:412,t:1527030541917};\\\", \\\"{x:578,y:412,t:1527030541934};\\\", \\\"{x:579,y:412,t:1527030541975};\\\", \\\"{x:581,y:411,t:1527030541983};\\\", \\\"{x:583,y:410,t:1527030542001};\\\", \\\"{x:586,y:409,t:1527030542017};\\\", \\\"{x:587,y:409,t:1527030542034};\\\", \\\"{x:588,y:408,t:1527030542052};\\\", \\\"{x:588,y:407,t:1527030542067};\\\", \\\"{x:590,y:407,t:1527030542085};\\\", \\\"{x:591,y:406,t:1527030542102};\\\", \\\"{x:592,y:405,t:1527030542176};\\\", \\\"{x:593,y:405,t:1527030542192};\\\", \\\"{x:594,y:404,t:1527030542224};\\\", \\\"{x:596,y:403,t:1527030542256};\\\", \\\"{x:597,y:403,t:1527030545080};\\\", \\\"{x:602,y:403,t:1527030545088};\\\", \\\"{x:610,y:403,t:1527030545103};\\\", \\\"{x:634,y:404,t:1527030545119};\\\", \\\"{x:664,y:410,t:1527030545136};\\\", \\\"{x:670,y:411,t:1527030545153};\\\", \\\"{x:674,y:412,t:1527030545170};\\\", \\\"{x:676,y:412,t:1527030545192};\\\", \\\"{x:677,y:412,t:1527030545203};\\\", \\\"{x:684,y:412,t:1527030545220};\\\", \\\"{x:692,y:412,t:1527030545237};\\\", \\\"{x:696,y:412,t:1527030545253};\\\", \\\"{x:697,y:412,t:1527030545270};\\\", \\\"{x:698,y:412,t:1527030545287};\\\", \\\"{x:699,y:412,t:1527030545360};\\\", \\\"{x:701,y:412,t:1527030545376};\\\", \\\"{x:702,y:412,t:1527030545386};\\\", \\\"{x:704,y:412,t:1527030545404};\\\", \\\"{x:706,y:412,t:1527030545420};\\\", \\\"{x:707,y:412,t:1527030545456};\\\", \\\"{x:708,y:412,t:1527030545480};\\\", \\\"{x:709,y:412,t:1527030545488};\\\", \\\"{x:710,y:412,t:1527030545503};\\\", \\\"{x:716,y:413,t:1527030545520};\\\", \\\"{x:719,y:413,t:1527030545536};\\\", \\\"{x:721,y:413,t:1527030545872};\\\", \\\"{x:722,y:413,t:1527030545912};\\\", \\\"{x:722,y:412,t:1527030545984};\\\", \\\"{x:722,y:411,t:1527030546016};\\\", \\\"{x:722,y:410,t:1527030546040};\\\", \\\"{x:728,y:413,t:1527030548305};\\\", \\\"{x:736,y:419,t:1527030548312};\\\", \\\"{x:744,y:425,t:1527030548323};\\\", \\\"{x:755,y:433,t:1527030548338};\\\", \\\"{x:766,y:443,t:1527030548356};\\\", \\\"{x:778,y:452,t:1527030548372};\\\", \\\"{x:789,y:460,t:1527030548388};\\\", \\\"{x:800,y:467,t:1527030548405};\\\", \\\"{x:807,y:472,t:1527030548423};\\\", \\\"{x:809,y:478,t:1527030548439};\\\", \\\"{x:811,y:482,t:1527030548455};\\\", \\\"{x:816,y:496,t:1527030548472};\\\", \\\"{x:822,y:513,t:1527030548489};\\\", \\\"{x:829,y:540,t:1527030548507};\\\", \\\"{x:837,y:568,t:1527030548525};\\\", \\\"{x:845,y:595,t:1527030548540};\\\", \\\"{x:855,y:618,t:1527030548557};\\\", \\\"{x:861,y:634,t:1527030548574};\\\", \\\"{x:865,y:644,t:1527030548589};\\\", \\\"{x:869,y:652,t:1527030548607};\\\", \\\"{x:874,y:659,t:1527030548624};\\\", \\\"{x:887,y:670,t:1527030548639};\\\", \\\"{x:912,y:687,t:1527030548657};\\\", \\\"{x:936,y:697,t:1527030548673};\\\", \\\"{x:961,y:704,t:1527030548690};\\\", \\\"{x:978,y:709,t:1527030548706};\\\", \\\"{x:989,y:713,t:1527030548724};\\\", \\\"{x:996,y:715,t:1527030548739};\\\", \\\"{x:1003,y:717,t:1527030548756};\\\", \\\"{x:1014,y:720,t:1527030548774};\\\", \\\"{x:1036,y:724,t:1527030548789};\\\", \\\"{x:1061,y:726,t:1527030548806};\\\", \\\"{x:1087,y:730,t:1527030548823};\\\", \\\"{x:1127,y:736,t:1527030548839};\\\", \\\"{x:1156,y:741,t:1527030548857};\\\", \\\"{x:1182,y:743,t:1527030548873};\\\", \\\"{x:1209,y:748,t:1527030548891};\\\", \\\"{x:1236,y:748,t:1527030548906};\\\", \\\"{x:1265,y:748,t:1527030548923};\\\", \\\"{x:1288,y:748,t:1527030548941};\\\", \\\"{x:1303,y:748,t:1527030548957};\\\", \\\"{x:1315,y:748,t:1527030548974};\\\", \\\"{x:1320,y:748,t:1527030548991};\\\", \\\"{x:1322,y:748,t:1527030549128};\\\", \\\"{x:1323,y:748,t:1527030549141};\\\", \\\"{x:1332,y:748,t:1527030549156};\\\", \\\"{x:1340,y:750,t:1527030549173};\\\", \\\"{x:1348,y:751,t:1527030549190};\\\", \\\"{x:1354,y:752,t:1527030549207};\\\", \\\"{x:1355,y:752,t:1527030549224};\\\", \\\"{x:1356,y:752,t:1527030549312};\\\", \\\"{x:1352,y:752,t:1527030549576};\\\", \\\"{x:1345,y:751,t:1527030549590};\\\", \\\"{x:1333,y:745,t:1527030549607};\\\", \\\"{x:1322,y:739,t:1527030549623};\\\", \\\"{x:1306,y:729,t:1527030549640};\\\", \\\"{x:1294,y:721,t:1527030549658};\\\", \\\"{x:1284,y:713,t:1527030549673};\\\", \\\"{x:1271,y:702,t:1527030549690};\\\", \\\"{x:1261,y:692,t:1527030549708};\\\", \\\"{x:1250,y:678,t:1527030549723};\\\", \\\"{x:1241,y:668,t:1527030549741};\\\", \\\"{x:1236,y:655,t:1527030549758};\\\", \\\"{x:1233,y:637,t:1527030549774};\\\", \\\"{x:1230,y:622,t:1527030549790};\\\", \\\"{x:1230,y:608,t:1527030549807};\\\", \\\"{x:1230,y:597,t:1527030549823};\\\", \\\"{x:1230,y:579,t:1527030549841};\\\", \\\"{x:1233,y:568,t:1527030549858};\\\", \\\"{x:1238,y:559,t:1527030549875};\\\", \\\"{x:1245,y:547,t:1527030549890};\\\", \\\"{x:1252,y:536,t:1527030549908};\\\", \\\"{x:1262,y:523,t:1527030549924};\\\", \\\"{x:1273,y:511,t:1527030549940};\\\", \\\"{x:1290,y:491,t:1527030549957};\\\", \\\"{x:1306,y:477,t:1527030549975};\\\", \\\"{x:1326,y:461,t:1527030549990};\\\", \\\"{x:1343,y:447,t:1527030550007};\\\", \\\"{x:1370,y:428,t:1527030550023};\\\", \\\"{x:1382,y:419,t:1527030550040};\\\", \\\"{x:1394,y:409,t:1527030550057};\\\", \\\"{x:1405,y:401,t:1527030550075};\\\", \\\"{x:1412,y:394,t:1527030550091};\\\", \\\"{x:1415,y:390,t:1527030550107};\\\", \\\"{x:1420,y:386,t:1527030550125};\\\", \\\"{x:1426,y:382,t:1527030550140};\\\", \\\"{x:1431,y:378,t:1527030550158};\\\", \\\"{x:1437,y:376,t:1527030550174};\\\", \\\"{x:1441,y:373,t:1527030550190};\\\", \\\"{x:1444,y:371,t:1527030550208};\\\", \\\"{x:1448,y:367,t:1527030550224};\\\", \\\"{x:1450,y:367,t:1527030550240};\\\", \\\"{x:1447,y:366,t:1527030550392};\\\", \\\"{x:1440,y:365,t:1527030550407};\\\", \\\"{x:1425,y:363,t:1527030550425};\\\", \\\"{x:1415,y:362,t:1527030550442};\\\", \\\"{x:1410,y:361,t:1527030550457};\\\", \\\"{x:1408,y:361,t:1527030550475};\\\", \\\"{x:1407,y:361,t:1527030550624};\\\", \\\"{x:1408,y:359,t:1527030550640};\\\", \\\"{x:1410,y:359,t:1527030550648};\\\", \\\"{x:1414,y:359,t:1527030550658};\\\", \\\"{x:1429,y:359,t:1527030550674};\\\", \\\"{x:1445,y:359,t:1527030550691};\\\", \\\"{x:1462,y:359,t:1527030550708};\\\", \\\"{x:1473,y:359,t:1527030550724};\\\", \\\"{x:1484,y:359,t:1527030550742};\\\", \\\"{x:1494,y:358,t:1527030550757};\\\", \\\"{x:1500,y:356,t:1527030550775};\\\", \\\"{x:1509,y:355,t:1527030550791};\\\", \\\"{x:1518,y:354,t:1527030550808};\\\", \\\"{x:1526,y:354,t:1527030550824};\\\", \\\"{x:1534,y:352,t:1527030550842};\\\", \\\"{x:1540,y:351,t:1527030550857};\\\", \\\"{x:1548,y:350,t:1527030550875};\\\", \\\"{x:1552,y:350,t:1527030550891};\\\", \\\"{x:1555,y:350,t:1527030550908};\\\", \\\"{x:1560,y:348,t:1527030550925};\\\", \\\"{x:1561,y:348,t:1527030550941};\\\", \\\"{x:1562,y:348,t:1527030550959};\\\", \\\"{x:1564,y:348,t:1527030550975};\\\", \\\"{x:1566,y:348,t:1527030550991};\\\", \\\"{x:1567,y:348,t:1527030551008};\\\", \\\"{x:1569,y:348,t:1527030551031};\\\", \\\"{x:1570,y:348,t:1527030551047};\\\", \\\"{x:1571,y:348,t:1527030551059};\\\", \\\"{x:1574,y:349,t:1527030551075};\\\", \\\"{x:1577,y:349,t:1527030551092};\\\", \\\"{x:1579,y:351,t:1527030551108};\\\", \\\"{x:1581,y:352,t:1527030551124};\\\", \\\"{x:1584,y:354,t:1527030551141};\\\", \\\"{x:1588,y:357,t:1527030551159};\\\", \\\"{x:1591,y:359,t:1527030551175};\\\", \\\"{x:1592,y:360,t:1527030551192};\\\", \\\"{x:1594,y:361,t:1527030551209};\\\", \\\"{x:1595,y:362,t:1527030551224};\\\", \\\"{x:1595,y:363,t:1527030551242};\\\", \\\"{x:1598,y:366,t:1527030551259};\\\", \\\"{x:1598,y:368,t:1527030551274};\\\", \\\"{x:1602,y:372,t:1527030551292};\\\", \\\"{x:1605,y:375,t:1527030551309};\\\", \\\"{x:1608,y:376,t:1527030551325};\\\", \\\"{x:1609,y:377,t:1527030551367};\\\", \\\"{x:1609,y:378,t:1527030552976};\\\", \\\"{x:1609,y:379,t:1527030553016};\\\", \\\"{x:1608,y:379,t:1527030553056};\\\", \\\"{x:1607,y:379,t:1527030553064};\\\", \\\"{x:1605,y:380,t:1527030553076};\\\", \\\"{x:1600,y:382,t:1527030553093};\\\", \\\"{x:1595,y:383,t:1527030553110};\\\", \\\"{x:1591,y:384,t:1527030553127};\\\", \\\"{x:1586,y:386,t:1527030553143};\\\", \\\"{x:1583,y:386,t:1527030553160};\\\", \\\"{x:1570,y:390,t:1527030553176};\\\", \\\"{x:1556,y:393,t:1527030553193};\\\", \\\"{x:1535,y:399,t:1527030553210};\\\", \\\"{x:1514,y:406,t:1527030553227};\\\", \\\"{x:1498,y:413,t:1527030553243};\\\", \\\"{x:1478,y:420,t:1527030553260};\\\", \\\"{x:1458,y:432,t:1527030553277};\\\", \\\"{x:1433,y:446,t:1527030553294};\\\", \\\"{x:1402,y:465,t:1527030553310};\\\", \\\"{x:1358,y:485,t:1527030553327};\\\", \\\"{x:1316,y:504,t:1527030553343};\\\", \\\"{x:1250,y:535,t:1527030553360};\\\", \\\"{x:1225,y:547,t:1527030553376};\\\", \\\"{x:1205,y:554,t:1527030553393};\\\", \\\"{x:1188,y:564,t:1527030553410};\\\", \\\"{x:1164,y:574,t:1527030553427};\\\", \\\"{x:1138,y:587,t:1527030553443};\\\", \\\"{x:1107,y:602,t:1527030553460};\\\", \\\"{x:1068,y:619,t:1527030553477};\\\", \\\"{x:1040,y:630,t:1527030553493};\\\", \\\"{x:1013,y:640,t:1527030553510};\\\", \\\"{x:990,y:649,t:1527030553527};\\\", \\\"{x:961,y:660,t:1527030553543};\\\", \\\"{x:919,y:673,t:1527030553560};\\\", \\\"{x:889,y:681,t:1527030553577};\\\", \\\"{x:859,y:688,t:1527030553594};\\\", \\\"{x:835,y:696,t:1527030553610};\\\", \\\"{x:814,y:701,t:1527030553627};\\\", \\\"{x:797,y:704,t:1527030553644};\\\", \\\"{x:784,y:707,t:1527030553660};\\\", \\\"{x:773,y:709,t:1527030553677};\\\", \\\"{x:762,y:712,t:1527030553694};\\\", \\\"{x:749,y:713,t:1527030553710};\\\", \\\"{x:729,y:714,t:1527030553727};\\\", \\\"{x:713,y:717,t:1527030553743};\\\", \\\"{x:712,y:717,t:1527030553760};\\\", \\\"{x:710,y:718,t:1527030553784};\\\", \\\"{x:709,y:718,t:1527030553808};\\\", \\\"{x:705,y:718,t:1527030553816};\\\", \\\"{x:700,y:719,t:1527030553827};\\\", \\\"{x:689,y:719,t:1527030553843};\\\", \\\"{x:685,y:719,t:1527030553860};\\\", \\\"{x:684,y:719,t:1527030553877};\\\", \\\"{x:683,y:719,t:1527030554064};\\\", \\\"{x:684,y:719,t:1527030554088};\\\", \\\"{x:685,y:718,t:1527030554104};\\\", \\\"{x:686,y:717,t:1527030554119};\\\", \\\"{x:687,y:717,t:1527030554144};\\\", \\\"{x:687,y:716,t:1527030554168};\\\", \\\"{x:688,y:716,t:1527030554176};\\\", \\\"{x:690,y:715,t:1527030554194};\\\", \\\"{x:691,y:714,t:1527030554211};\\\", \\\"{x:692,y:714,t:1527030554240};\\\", \\\"{x:694,y:713,t:1527030554265};\\\", \\\"{x:696,y:712,t:1527030554280};\\\", \\\"{x:698,y:710,t:1527030554294};\\\", \\\"{x:702,y:709,t:1527030554311};\\\", \\\"{x:708,y:709,t:1527030554326};\\\", \\\"{x:720,y:709,t:1527030554343};\\\", \\\"{x:729,y:709,t:1527030554360};\\\", \\\"{x:733,y:709,t:1527030554377};\\\", \\\"{x:737,y:709,t:1527030554394};\\\", \\\"{x:740,y:709,t:1527030554411};\\\", \\\"{x:745,y:711,t:1527030554427};\\\", \\\"{x:750,y:711,t:1527030554444};\\\", \\\"{x:755,y:711,t:1527030554461};\\\", \\\"{x:757,y:712,t:1527030554476};\\\", \\\"{x:758,y:712,t:1527030555488};\\\", \\\"{x:761,y:711,t:1527030555495};\\\", \\\"{x:764,y:711,t:1527030555511};\\\", \\\"{x:771,y:708,t:1527030555528};\\\", \\\"{x:774,y:706,t:1527030555545};\\\", \\\"{x:778,y:700,t:1527030555561};\\\", \\\"{x:796,y:669,t:1527030555578};\\\", \\\"{x:816,y:617,t:1527030555595};\\\", \\\"{x:849,y:548,t:1527030555611};\\\", \\\"{x:868,y:508,t:1527030555622};\\\", \\\"{x:903,y:438,t:1527030555639};\\\", \\\"{x:921,y:391,t:1527030555655};\\\", \\\"{x:939,y:344,t:1527030555679};\\\", \\\"{x:948,y:325,t:1527030555696};\\\", \\\"{x:950,y:321,t:1527030555712};\\\", \\\"{x:952,y:319,t:1527030555728};\\\", \\\"{x:954,y:319,t:1527030555752};\\\", \\\"{x:955,y:318,t:1527030555763};\\\", \\\"{x:968,y:316,t:1527030555779};\\\", \\\"{x:990,y:317,t:1527030555796};\\\", \\\"{x:1015,y:329,t:1527030555813};\\\", \\\"{x:1043,y:349,t:1527030555829};\\\", \\\"{x:1074,y:377,t:1527030555846};\\\", \\\"{x:1100,y:405,t:1527030555863};\\\", \\\"{x:1118,y:430,t:1527030555879};\\\", \\\"{x:1140,y:451,t:1527030555895};\\\", \\\"{x:1146,y:456,t:1527030555913};\\\", \\\"{x:1147,y:456,t:1527030555985};\\\", \\\"{x:1147,y:458,t:1527030555996};\\\", \\\"{x:1143,y:463,t:1527030556013};\\\", \\\"{x:1136,y:468,t:1527030556029};\\\", \\\"{x:1129,y:471,t:1527030556046};\\\", \\\"{x:1125,y:475,t:1527030556063};\\\", \\\"{x:1123,y:477,t:1527030556079};\\\", \\\"{x:1121,y:478,t:1527030556097};\\\", \\\"{x:1120,y:479,t:1527030556113};\\\", \\\"{x:1118,y:481,t:1527030556130};\\\", \\\"{x:1115,y:483,t:1527030556146};\\\", \\\"{x:1113,y:484,t:1527030556162};\\\", \\\"{x:1113,y:485,t:1527030556180};\\\", \\\"{x:1114,y:485,t:1527030556224};\\\", \\\"{x:1123,y:485,t:1527030556232};\\\", \\\"{x:1131,y:485,t:1527030556246};\\\", \\\"{x:1158,y:485,t:1527030556263};\\\", \\\"{x:1230,y:485,t:1527030556280};\\\", \\\"{x:1294,y:485,t:1527030556296};\\\", \\\"{x:1344,y:485,t:1527030556313};\\\", \\\"{x:1389,y:485,t:1527030556330};\\\", \\\"{x:1423,y:485,t:1527030556346};\\\", \\\"{x:1453,y:485,t:1527030556363};\\\", \\\"{x:1480,y:485,t:1527030556380};\\\", \\\"{x:1503,y:485,t:1527030556396};\\\", \\\"{x:1528,y:485,t:1527030556413};\\\", \\\"{x:1552,y:485,t:1527030556430};\\\", \\\"{x:1573,y:485,t:1527030556446};\\\", \\\"{x:1590,y:485,t:1527030556463};\\\", \\\"{x:1616,y:485,t:1527030556480};\\\", \\\"{x:1623,y:485,t:1527030556496};\\\", \\\"{x:1626,y:485,t:1527030556513};\\\", \\\"{x:1630,y:485,t:1527030556531};\\\", \\\"{x:1631,y:485,t:1527030556546};\\\", \\\"{x:1632,y:485,t:1527030556563};\\\", \\\"{x:1635,y:485,t:1527030556580};\\\", \\\"{x:1638,y:485,t:1527030556597};\\\", \\\"{x:1640,y:485,t:1527030556613};\\\", \\\"{x:1641,y:485,t:1527030556630};\\\", \\\"{x:1641,y:486,t:1527030556832};\\\", \\\"{x:1641,y:487,t:1527030556848};\\\", \\\"{x:1640,y:487,t:1527030556880};\\\", \\\"{x:1644,y:487,t:1527030577013};\\\", \\\"{x:1651,y:485,t:1527030577027};\\\", \\\"{x:1667,y:479,t:1527030577043};\\\", \\\"{x:1690,y:476,t:1527030577060};\\\", \\\"{x:1758,y:476,t:1527030577077};\\\", \\\"{x:1819,y:476,t:1527030577093};\\\", \\\"{x:1891,y:476,t:1527030577110};\\\", \\\"{x:1919,y:476,t:1527030577127};\\\", \\\"{x:1919,y:479,t:1527030577143};\\\", \\\"{x:1919,y:491,t:1527030577160};\\\", \\\"{x:1919,y:502,t:1527030577177};\\\", \\\"{x:1919,y:515,t:1527030577194};\\\", \\\"{x:1919,y:523,t:1527030577211};\\\", \\\"{x:1919,y:525,t:1527030577227};\\\", \\\"{x:1915,y:525,t:1527030577253};\\\", \\\"{x:1894,y:525,t:1527030577261};\\\", \\\"{x:1778,y:525,t:1527030577277};\\\", \\\"{x:1637,y:525,t:1527030577294};\\\", \\\"{x:1493,y:525,t:1527030577311};\\\", \\\"{x:1327,y:525,t:1527030577327};\\\", \\\"{x:1166,y:532,t:1527030577344};\\\", \\\"{x:1033,y:546,t:1527030577361};\\\", \\\"{x:943,y:554,t:1527030577377};\\\", \\\"{x:904,y:554,t:1527030577394};\\\", \\\"{x:888,y:554,t:1527030577411};\\\", \\\"{x:878,y:554,t:1527030577427};\\\", \\\"{x:871,y:554,t:1527030577444};\\\", \\\"{x:836,y:549,t:1527030577462};\\\", \\\"{x:765,y:546,t:1527030577477};\\\", \\\"{x:649,y:546,t:1527030577495};\\\", \\\"{x:502,y:546,t:1527030577511};\\\", \\\"{x:334,y:546,t:1527030577527};\\\", \\\"{x:168,y:546,t:1527030577545};\\\", \\\"{x:46,y:546,t:1527030577561};\\\", \\\"{x:0,y:546,t:1527030577577};\\\", \\\"{x:0,y:547,t:1527030577594};\\\", \\\"{x:0,y:551,t:1527030577611};\\\", \\\"{x:0,y:555,t:1527030577628};\\\", \\\"{x:0,y:556,t:1527030577644};\\\", \\\"{x:0,y:559,t:1527030577661};\\\", \\\"{x:0,y:560,t:1527030577678};\\\", \\\"{x:2,y:564,t:1527030577694};\\\", \\\"{x:24,y:569,t:1527030577711};\\\", \\\"{x:68,y:575,t:1527030577729};\\\", \\\"{x:122,y:577,t:1527030577744};\\\", \\\"{x:167,y:577,t:1527030577761};\\\", \\\"{x:191,y:577,t:1527030577778};\\\", \\\"{x:210,y:577,t:1527030577794};\\\", \\\"{x:227,y:577,t:1527030577811};\\\", \\\"{x:248,y:577,t:1527030577827};\\\", \\\"{x:280,y:577,t:1527030577844};\\\", \\\"{x:364,y:577,t:1527030577861};\\\", \\\"{x:428,y:577,t:1527030577877};\\\", \\\"{x:478,y:577,t:1527030577894};\\\", \\\"{x:523,y:577,t:1527030577912};\\\", \\\"{x:563,y:577,t:1527030577928};\\\", \\\"{x:593,y:577,t:1527030577944};\\\", \\\"{x:619,y:577,t:1527030577961};\\\", \\\"{x:639,y:577,t:1527030577978};\\\", \\\"{x:654,y:577,t:1527030577994};\\\", \\\"{x:668,y:577,t:1527030578011};\\\", \\\"{x:693,y:581,t:1527030578028};\\\", \\\"{x:716,y:582,t:1527030578044};\\\", \\\"{x:744,y:584,t:1527030578061};\\\", \\\"{x:755,y:584,t:1527030578078};\\\", \\\"{x:763,y:584,t:1527030578094};\\\", \\\"{x:772,y:584,t:1527030578111};\\\", \\\"{x:780,y:584,t:1527030578127};\\\", \\\"{x:785,y:584,t:1527030578145};\\\", \\\"{x:789,y:584,t:1527030578161};\\\", \\\"{x:796,y:584,t:1527030578178};\\\", \\\"{x:801,y:582,t:1527030578195};\\\", \\\"{x:809,y:581,t:1527030578211};\\\", \\\"{x:817,y:577,t:1527030578228};\\\", \\\"{x:823,y:575,t:1527030578244};\\\", \\\"{x:825,y:573,t:1527030578261};\\\", \\\"{x:825,y:571,t:1527030578301};\\\", \\\"{x:825,y:570,t:1527030578311};\\\", \\\"{x:826,y:567,t:1527030578328};\\\", \\\"{x:828,y:564,t:1527030578345};\\\", \\\"{x:831,y:561,t:1527030578362};\\\", \\\"{x:832,y:559,t:1527030578378};\\\", \\\"{x:832,y:557,t:1527030578395};\\\", \\\"{x:833,y:556,t:1527030578411};\\\", \\\"{x:834,y:553,t:1527030578428};\\\", \\\"{x:838,y:550,t:1527030578445};\\\", \\\"{x:838,y:549,t:1527030578461};\\\", \\\"{x:834,y:552,t:1527030578949};\\\", \\\"{x:830,y:556,t:1527030578962};\\\", \\\"{x:811,y:568,t:1527030578980};\\\", \\\"{x:785,y:580,t:1527030578995};\\\", \\\"{x:745,y:599,t:1527030579012};\\\", \\\"{x:709,y:614,t:1527030579029};\\\", \\\"{x:667,y:633,t:1527030579045};\\\", \\\"{x:651,y:639,t:1527030579062};\\\", \\\"{x:641,y:644,t:1527030579079};\\\", \\\"{x:637,y:647,t:1527030579095};\\\", \\\"{x:632,y:650,t:1527030579112};\\\", \\\"{x:629,y:652,t:1527030579130};\\\", \\\"{x:626,y:655,t:1527030579146};\\\", \\\"{x:620,y:659,t:1527030579162};\\\", \\\"{x:614,y:664,t:1527030579179};\\\", \\\"{x:604,y:668,t:1527030579195};\\\", \\\"{x:595,y:673,t:1527030579212};\\\", \\\"{x:585,y:677,t:1527030579228};\\\", \\\"{x:582,y:679,t:1527030579245};\\\", \\\"{x:579,y:680,t:1527030579262};\\\", \\\"{x:576,y:683,t:1527030579279};\\\", \\\"{x:569,y:687,t:1527030579295};\\\", \\\"{x:554,y:695,t:1527030579312};\\\", \\\"{x:541,y:703,t:1527030579330};\\\", \\\"{x:530,y:709,t:1527030579345};\\\", \\\"{x:522,y:714,t:1527030579362};\\\", \\\"{x:519,y:717,t:1527030579379};\\\", \\\"{x:518,y:718,t:1527030579396};\\\", \\\"{x:518,y:719,t:1527030579413};\\\", \\\"{x:518,y:720,t:1527030579454};\\\", \\\"{x:518,y:721,t:1527030579469};\\\", \\\"{x:518,y:722,t:1527030579557};\\\", \\\"{x:518,y:723,t:1527030579565};\\\", \\\"{x:518,y:724,t:1527030579581};\\\", \\\"{x:518,y:725,t:1527030579596};\\\", \\\"{x:518,y:728,t:1527030579612};\\\", \\\"{x:518,y:729,t:1527030579629};\\\", \\\"{x:518,y:731,t:1527030579646};\\\", \\\"{x:518,y:732,t:1527030579663};\\\" ] }, { \\\"rt\\\": 31933, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 535011, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:733,t:1527030586565};\\\", \\\"{x:523,y:732,t:1527030586573};\\\", \\\"{x:537,y:724,t:1527030586586};\\\", \\\"{x:585,y:698,t:1527030586601};\\\", \\\"{x:661,y:562,t:1527030586696};\\\", \\\"{x:661,y:549,t:1527030586705};\\\", \\\"{x:658,y:532,t:1527030586718};\\\", \\\"{x:648,y:517,t:1527030586735};\\\", \\\"{x:643,y:508,t:1527030586751};\\\", \\\"{x:633,y:500,t:1527030586768};\\\", \\\"{x:622,y:492,t:1527030586786};\\\", \\\"{x:614,y:486,t:1527030586802};\\\", \\\"{x:602,y:483,t:1527030586818};\\\", \\\"{x:589,y:482,t:1527030586836};\\\", \\\"{x:569,y:482,t:1527030586851};\\\", \\\"{x:547,y:481,t:1527030586868};\\\", \\\"{x:521,y:478,t:1527030586886};\\\", \\\"{x:505,y:476,t:1527030586902};\\\", \\\"{x:490,y:475,t:1527030586919};\\\", \\\"{x:473,y:473,t:1527030586936};\\\", \\\"{x:458,y:471,t:1527030586953};\\\", \\\"{x:442,y:468,t:1527030586969};\\\", \\\"{x:423,y:467,t:1527030586986};\\\", \\\"{x:405,y:467,t:1527030587003};\\\", \\\"{x:393,y:467,t:1527030587019};\\\", \\\"{x:388,y:467,t:1527030587036};\\\", \\\"{x:380,y:467,t:1527030587053};\\\", \\\"{x:370,y:467,t:1527030587069};\\\", \\\"{x:365,y:467,t:1527030587086};\\\", \\\"{x:362,y:466,t:1527030587103};\\\", \\\"{x:362,y:465,t:1527030587157};\\\", \\\"{x:365,y:464,t:1527030587170};\\\", \\\"{x:372,y:462,t:1527030587187};\\\", \\\"{x:379,y:462,t:1527030587203};\\\", \\\"{x:387,y:462,t:1527030587220};\\\", \\\"{x:399,y:462,t:1527030587236};\\\", \\\"{x:412,y:462,t:1527030587253};\\\", \\\"{x:417,y:462,t:1527030587270};\\\", \\\"{x:419,y:462,t:1527030587365};\\\", \\\"{x:423,y:465,t:1527030587373};\\\", \\\"{x:429,y:468,t:1527030587386};\\\", \\\"{x:438,y:472,t:1527030587404};\\\", \\\"{x:444,y:472,t:1527030587421};\\\", \\\"{x:449,y:473,t:1527030587436};\\\", \\\"{x:465,y:474,t:1527030587453};\\\", \\\"{x:486,y:474,t:1527030587471};\\\", \\\"{x:522,y:475,t:1527030587487};\\\", \\\"{x:565,y:475,t:1527030587503};\\\", \\\"{x:607,y:475,t:1527030587521};\\\", \\\"{x:635,y:475,t:1527030587538};\\\", \\\"{x:649,y:475,t:1527030587554};\\\", \\\"{x:652,y:475,t:1527030587571};\\\", \\\"{x:657,y:475,t:1527030587588};\\\", \\\"{x:667,y:472,t:1527030587604};\\\", \\\"{x:678,y:470,t:1527030587621};\\\", \\\"{x:697,y:466,t:1527030587637};\\\", \\\"{x:700,y:465,t:1527030587655};\\\", \\\"{x:701,y:465,t:1527030587671};\\\", \\\"{x:701,y:464,t:1527030587688};\\\", \\\"{x:705,y:464,t:1527030588165};\\\", \\\"{x:708,y:463,t:1527030588173};\\\", \\\"{x:709,y:463,t:1527030588189};\\\", \\\"{x:712,y:461,t:1527030588829};\\\", \\\"{x:719,y:458,t:1527030588840};\\\", \\\"{x:732,y:454,t:1527030588858};\\\", \\\"{x:753,y:454,t:1527030588875};\\\", \\\"{x:763,y:454,t:1527030588890};\\\", \\\"{x:769,y:454,t:1527030588908};\\\", \\\"{x:774,y:454,t:1527030588925};\\\", \\\"{x:783,y:454,t:1527030588940};\\\", \\\"{x:807,y:458,t:1527030588958};\\\", \\\"{x:825,y:464,t:1527030588974};\\\", \\\"{x:842,y:471,t:1527030588992};\\\", \\\"{x:854,y:476,t:1527030589008};\\\", \\\"{x:859,y:478,t:1527030589024};\\\", \\\"{x:864,y:480,t:1527030589041};\\\", \\\"{x:868,y:480,t:1527030589058};\\\", \\\"{x:874,y:482,t:1527030589074};\\\", \\\"{x:882,y:484,t:1527030589091};\\\", \\\"{x:894,y:491,t:1527030589109};\\\", \\\"{x:916,y:501,t:1527030589125};\\\", \\\"{x:924,y:506,t:1527030589142};\\\", \\\"{x:925,y:507,t:1527030589151};\\\", \\\"{x:926,y:508,t:1527030589168};\\\", \\\"{x:926,y:509,t:1527030589185};\\\", \\\"{x:926,y:511,t:1527030589202};\\\", \\\"{x:923,y:517,t:1527030589219};\\\", \\\"{x:904,y:524,t:1527030589236};\\\", \\\"{x:878,y:529,t:1527030589252};\\\", \\\"{x:813,y:533,t:1527030589271};\\\", \\\"{x:751,y:535,t:1527030589287};\\\", \\\"{x:704,y:535,t:1527030589304};\\\", \\\"{x:679,y:535,t:1527030589320};\\\", \\\"{x:664,y:535,t:1527030589338};\\\", \\\"{x:649,y:535,t:1527030589354};\\\", \\\"{x:637,y:535,t:1527030589371};\\\", \\\"{x:629,y:534,t:1527030589388};\\\", \\\"{x:621,y:531,t:1527030589403};\\\", \\\"{x:611,y:526,t:1527030589421};\\\", \\\"{x:606,y:523,t:1527030589437};\\\", \\\"{x:598,y:518,t:1527030589454};\\\", \\\"{x:592,y:514,t:1527030589471};\\\", \\\"{x:588,y:510,t:1527030589488};\\\", \\\"{x:583,y:505,t:1527030589504};\\\", \\\"{x:577,y:494,t:1527030589521};\\\", \\\"{x:569,y:486,t:1527030589538};\\\", \\\"{x:565,y:482,t:1527030589554};\\\", \\\"{x:565,y:481,t:1527030589571};\\\", \\\"{x:565,y:479,t:1527030589588};\\\", \\\"{x:572,y:474,t:1527030589604};\\\", \\\"{x:587,y:472,t:1527030589621};\\\", \\\"{x:601,y:472,t:1527030589638};\\\", \\\"{x:619,y:477,t:1527030589655};\\\", \\\"{x:646,y:486,t:1527030589671};\\\", \\\"{x:671,y:492,t:1527030589688};\\\", \\\"{x:692,y:497,t:1527030589705};\\\", \\\"{x:705,y:500,t:1527030589721};\\\", \\\"{x:717,y:502,t:1527030589738};\\\", \\\"{x:734,y:505,t:1527030589756};\\\", \\\"{x:751,y:510,t:1527030589770};\\\", \\\"{x:767,y:518,t:1527030589788};\\\", \\\"{x:787,y:529,t:1527030589805};\\\", \\\"{x:799,y:535,t:1527030589820};\\\", \\\"{x:811,y:543,t:1527030589838};\\\", \\\"{x:826,y:552,t:1527030589855};\\\", \\\"{x:846,y:562,t:1527030589871};\\\", \\\"{x:866,y:571,t:1527030589888};\\\", \\\"{x:882,y:579,t:1527030589905};\\\", \\\"{x:893,y:586,t:1527030589921};\\\", \\\"{x:897,y:590,t:1527030589938};\\\", \\\"{x:900,y:592,t:1527030589955};\\\", \\\"{x:908,y:598,t:1527030589971};\\\", \\\"{x:916,y:605,t:1527030589988};\\\", \\\"{x:929,y:617,t:1527030590004};\\\", \\\"{x:947,y:632,t:1527030590021};\\\", \\\"{x:969,y:663,t:1527030590038};\\\", \\\"{x:974,y:675,t:1527030590054};\\\", \\\"{x:979,y:685,t:1527030590070};\\\", \\\"{x:983,y:690,t:1527030590088};\\\", \\\"{x:987,y:694,t:1527030590105};\\\", \\\"{x:989,y:695,t:1527030590120};\\\", \\\"{x:993,y:698,t:1527030590138};\\\", \\\"{x:996,y:701,t:1527030590155};\\\", \\\"{x:1002,y:705,t:1527030590171};\\\", \\\"{x:1006,y:705,t:1527030590188};\\\", \\\"{x:1007,y:705,t:1527030590205};\\\", \\\"{x:1009,y:705,t:1527030590229};\\\", \\\"{x:1011,y:705,t:1527030590238};\\\", \\\"{x:1018,y:705,t:1527030590255};\\\", \\\"{x:1032,y:705,t:1527030590271};\\\", \\\"{x:1050,y:705,t:1527030590288};\\\", \\\"{x:1069,y:705,t:1527030590305};\\\", \\\"{x:1089,y:708,t:1527030590321};\\\", \\\"{x:1103,y:710,t:1527030590338};\\\", \\\"{x:1120,y:714,t:1527030590355};\\\", \\\"{x:1132,y:716,t:1527030590371};\\\", \\\"{x:1145,y:721,t:1527030590388};\\\", \\\"{x:1170,y:730,t:1527030590405};\\\", \\\"{x:1187,y:744,t:1527030590420};\\\", \\\"{x:1202,y:763,t:1527030590438};\\\", \\\"{x:1212,y:778,t:1527030590455};\\\", \\\"{x:1215,y:788,t:1527030590471};\\\", \\\"{x:1216,y:796,t:1527030590488};\\\", \\\"{x:1216,y:799,t:1527030590504};\\\", \\\"{x:1216,y:803,t:1527030590520};\\\", \\\"{x:1218,y:804,t:1527030590538};\\\", \\\"{x:1218,y:806,t:1527030590557};\\\", \\\"{x:1219,y:806,t:1527030590581};\\\", \\\"{x:1220,y:806,t:1527030590589};\\\", \\\"{x:1221,y:806,t:1527030590605};\\\", \\\"{x:1225,y:807,t:1527030590620};\\\", \\\"{x:1227,y:807,t:1527030590638};\\\", \\\"{x:1231,y:808,t:1527030590654};\\\", \\\"{x:1235,y:810,t:1527030590670};\\\", \\\"{x:1238,y:810,t:1527030590688};\\\", \\\"{x:1242,y:811,t:1527030590705};\\\", \\\"{x:1247,y:811,t:1527030590721};\\\", \\\"{x:1254,y:812,t:1527030590738};\\\", \\\"{x:1263,y:814,t:1527030590755};\\\", \\\"{x:1270,y:815,t:1527030590771};\\\", \\\"{x:1275,y:815,t:1527030590788};\\\", \\\"{x:1279,y:816,t:1527030590805};\\\", \\\"{x:1282,y:816,t:1527030590821};\\\", \\\"{x:1284,y:816,t:1527030590838};\\\", \\\"{x:1285,y:816,t:1527030590861};\\\", \\\"{x:1286,y:816,t:1527030590877};\\\", \\\"{x:1287,y:816,t:1527030590888};\\\", \\\"{x:1289,y:816,t:1527030590905};\\\", \\\"{x:1295,y:818,t:1527030590921};\\\", \\\"{x:1301,y:818,t:1527030590937};\\\", \\\"{x:1310,y:818,t:1527030590955};\\\", \\\"{x:1317,y:819,t:1527030590971};\\\", \\\"{x:1320,y:820,t:1527030590988};\\\", \\\"{x:1325,y:821,t:1527030591005};\\\", \\\"{x:1327,y:821,t:1527030591021};\\\", \\\"{x:1329,y:821,t:1527030591037};\\\", \\\"{x:1330,y:821,t:1527030591069};\\\", \\\"{x:1331,y:822,t:1527030591085};\\\", \\\"{x:1333,y:821,t:1527030591262};\\\", \\\"{x:1336,y:819,t:1527030591272};\\\", \\\"{x:1342,y:812,t:1527030591288};\\\", \\\"{x:1352,y:799,t:1527030591305};\\\", \\\"{x:1357,y:792,t:1527030591322};\\\", \\\"{x:1359,y:789,t:1527030591338};\\\", \\\"{x:1361,y:786,t:1527030591355};\\\", \\\"{x:1361,y:784,t:1527030591372};\\\", \\\"{x:1361,y:783,t:1527030591388};\\\", \\\"{x:1361,y:777,t:1527030591406};\\\", \\\"{x:1361,y:772,t:1527030591422};\\\", \\\"{x:1361,y:760,t:1527030591438};\\\", \\\"{x:1356,y:750,t:1527030591455};\\\", \\\"{x:1350,y:740,t:1527030591472};\\\", \\\"{x:1345,y:734,t:1527030591488};\\\", \\\"{x:1343,y:732,t:1527030591506};\\\", \\\"{x:1342,y:731,t:1527030591521};\\\", \\\"{x:1341,y:730,t:1527030591538};\\\", \\\"{x:1341,y:729,t:1527030591556};\\\", \\\"{x:1341,y:728,t:1527030591572};\\\", \\\"{x:1338,y:726,t:1527030591588};\\\", \\\"{x:1337,y:723,t:1527030591606};\\\", \\\"{x:1335,y:721,t:1527030591622};\\\", \\\"{x:1333,y:719,t:1527030591646};\\\", \\\"{x:1331,y:719,t:1527030591661};\\\", \\\"{x:1330,y:718,t:1527030591694};\\\", \\\"{x:1329,y:717,t:1527030591705};\\\", \\\"{x:1328,y:717,t:1527030591724};\\\", \\\"{x:1327,y:717,t:1527030591738};\\\", \\\"{x:1326,y:717,t:1527030591755};\\\", \\\"{x:1322,y:717,t:1527030591772};\\\", \\\"{x:1319,y:717,t:1527030591788};\\\", \\\"{x:1316,y:717,t:1527030591805};\\\", \\\"{x:1313,y:717,t:1527030591821};\\\", \\\"{x:1311,y:717,t:1527030591838};\\\", \\\"{x:1310,y:717,t:1527030591855};\\\", \\\"{x:1309,y:717,t:1527030591872};\\\", \\\"{x:1308,y:717,t:1527030591888};\\\", \\\"{x:1306,y:716,t:1527030591905};\\\", \\\"{x:1304,y:714,t:1527030591922};\\\", \\\"{x:1302,y:712,t:1527030591938};\\\", \\\"{x:1300,y:711,t:1527030591955};\\\", \\\"{x:1299,y:710,t:1527030591972};\\\", \\\"{x:1299,y:709,t:1527030592093};\\\", \\\"{x:1300,y:709,t:1527030592105};\\\", \\\"{x:1303,y:709,t:1527030592122};\\\", \\\"{x:1308,y:712,t:1527030592137};\\\", \\\"{x:1309,y:714,t:1527030592155};\\\", \\\"{x:1311,y:715,t:1527030592172};\\\", \\\"{x:1313,y:717,t:1527030592188};\\\", \\\"{x:1320,y:723,t:1527030592205};\\\", \\\"{x:1325,y:725,t:1527030592221};\\\", \\\"{x:1329,y:728,t:1527030592238};\\\", \\\"{x:1329,y:729,t:1527030592255};\\\", \\\"{x:1332,y:731,t:1527030592272};\\\", \\\"{x:1335,y:732,t:1527030592288};\\\", \\\"{x:1340,y:736,t:1527030592305};\\\", \\\"{x:1344,y:739,t:1527030592322};\\\", \\\"{x:1347,y:741,t:1527030592338};\\\", \\\"{x:1349,y:743,t:1527030592355};\\\", \\\"{x:1352,y:746,t:1527030592372};\\\", \\\"{x:1355,y:749,t:1527030592388};\\\", \\\"{x:1359,y:753,t:1527030592405};\\\", \\\"{x:1361,y:756,t:1527030592422};\\\", \\\"{x:1363,y:758,t:1527030592438};\\\", \\\"{x:1364,y:759,t:1527030592455};\\\", \\\"{x:1365,y:760,t:1527030592472};\\\", \\\"{x:1367,y:762,t:1527030592488};\\\", \\\"{x:1369,y:763,t:1527030592505};\\\", \\\"{x:1372,y:765,t:1527030592522};\\\", \\\"{x:1375,y:766,t:1527030592538};\\\", \\\"{x:1376,y:767,t:1527030592555};\\\", \\\"{x:1377,y:768,t:1527030592571};\\\", \\\"{x:1378,y:769,t:1527030592589};\\\", \\\"{x:1379,y:771,t:1527030592613};\\\", \\\"{x:1379,y:772,t:1527030592621};\\\", \\\"{x:1380,y:772,t:1527030592638};\\\", \\\"{x:1380,y:773,t:1527030592654};\\\", \\\"{x:1382,y:775,t:1527030592672};\\\", \\\"{x:1385,y:776,t:1527030592688};\\\", \\\"{x:1386,y:778,t:1527030592705};\\\", \\\"{x:1388,y:779,t:1527030592722};\\\", \\\"{x:1388,y:780,t:1527030592741};\\\", \\\"{x:1388,y:781,t:1527030592755};\\\", \\\"{x:1389,y:782,t:1527030592772};\\\", \\\"{x:1390,y:783,t:1527030592788};\\\", \\\"{x:1391,y:784,t:1527030592805};\\\", \\\"{x:1393,y:785,t:1527030592822};\\\", \\\"{x:1393,y:786,t:1527030592845};\\\", \\\"{x:1393,y:787,t:1527030592855};\\\", \\\"{x:1394,y:788,t:1527030592872};\\\", \\\"{x:1394,y:789,t:1527030592917};\\\", \\\"{x:1394,y:790,t:1527030592925};\\\", \\\"{x:1394,y:791,t:1527030592957};\\\", \\\"{x:1394,y:792,t:1527030592973};\\\", \\\"{x:1394,y:793,t:1527030592988};\\\", \\\"{x:1394,y:794,t:1527030593005};\\\", \\\"{x:1394,y:795,t:1527030593022};\\\", \\\"{x:1394,y:796,t:1527030593038};\\\", \\\"{x:1394,y:797,t:1527030593055};\\\", \\\"{x:1393,y:797,t:1527030593072};\\\", \\\"{x:1387,y:797,t:1527030593088};\\\", \\\"{x:1373,y:795,t:1527030593105};\\\", \\\"{x:1360,y:791,t:1527030593122};\\\", \\\"{x:1354,y:791,t:1527030593138};\\\", \\\"{x:1352,y:791,t:1527030593155};\\\", \\\"{x:1351,y:791,t:1527030593349};\\\", \\\"{x:1350,y:790,t:1527030593357};\\\", \\\"{x:1350,y:789,t:1527030593373};\\\", \\\"{x:1349,y:788,t:1527030593388};\\\", \\\"{x:1349,y:787,t:1527030593405};\\\", \\\"{x:1347,y:784,t:1527030593422};\\\", \\\"{x:1346,y:781,t:1527030593437};\\\", \\\"{x:1346,y:779,t:1527030593455};\\\", \\\"{x:1345,y:779,t:1527030593472};\\\", \\\"{x:1345,y:777,t:1527030593488};\\\", \\\"{x:1344,y:776,t:1527030593509};\\\", \\\"{x:1344,y:775,t:1527030593533};\\\", \\\"{x:1344,y:773,t:1527030593581};\\\", \\\"{x:1344,y:772,t:1527030593637};\\\", \\\"{x:1344,y:771,t:1527030593757};\\\", \\\"{x:1345,y:771,t:1527030593781};\\\", \\\"{x:1346,y:771,t:1527030593909};\\\", \\\"{x:1347,y:770,t:1527030593941};\\\", \\\"{x:1348,y:769,t:1527030593955};\\\", \\\"{x:1348,y:768,t:1527030595334};\\\", \\\"{x:1348,y:767,t:1527030595355};\\\", \\\"{x:1349,y:766,t:1527030595372};\\\", \\\"{x:1349,y:769,t:1527030597942};\\\", \\\"{x:1350,y:770,t:1527030597955};\\\", \\\"{x:1352,y:775,t:1527030597972};\\\", \\\"{x:1354,y:781,t:1527030597989};\\\", \\\"{x:1355,y:785,t:1527030598005};\\\", \\\"{x:1357,y:790,t:1527030598022};\\\", \\\"{x:1358,y:793,t:1527030598039};\\\", \\\"{x:1358,y:798,t:1527030598056};\\\", \\\"{x:1358,y:802,t:1527030598072};\\\", \\\"{x:1358,y:806,t:1527030598089};\\\", \\\"{x:1358,y:810,t:1527030598105};\\\", \\\"{x:1358,y:813,t:1527030598122};\\\", \\\"{x:1358,y:814,t:1527030598139};\\\", \\\"{x:1358,y:816,t:1527030598155};\\\", \\\"{x:1358,y:818,t:1527030598181};\\\", \\\"{x:1358,y:820,t:1527030598188};\\\", \\\"{x:1362,y:823,t:1527030598206};\\\", \\\"{x:1367,y:828,t:1527030598222};\\\", \\\"{x:1374,y:832,t:1527030598240};\\\", \\\"{x:1376,y:835,t:1527030598255};\\\", \\\"{x:1378,y:836,t:1527030598272};\\\", \\\"{x:1378,y:837,t:1527030598405};\\\", \\\"{x:1378,y:838,t:1527030598421};\\\", \\\"{x:1377,y:839,t:1527030598436};\\\", \\\"{x:1376,y:839,t:1527030598445};\\\", \\\"{x:1374,y:839,t:1527030598456};\\\", \\\"{x:1372,y:839,t:1527030598472};\\\", \\\"{x:1370,y:839,t:1527030598489};\\\", \\\"{x:1368,y:839,t:1527030598573};\\\", \\\"{x:1367,y:841,t:1527030598589};\\\", \\\"{x:1366,y:842,t:1527030598605};\\\", \\\"{x:1362,y:848,t:1527030598622};\\\", \\\"{x:1358,y:854,t:1527030598639};\\\", \\\"{x:1353,y:862,t:1527030598656};\\\", \\\"{x:1349,y:867,t:1527030598673};\\\", \\\"{x:1349,y:871,t:1527030598689};\\\", \\\"{x:1348,y:871,t:1527030598706};\\\", \\\"{x:1348,y:872,t:1527030598722};\\\", \\\"{x:1348,y:873,t:1527030598739};\\\", \\\"{x:1349,y:874,t:1527030598755};\\\", \\\"{x:1350,y:876,t:1527030598772};\\\", \\\"{x:1351,y:877,t:1527030598789};\\\", \\\"{x:1352,y:878,t:1527030598806};\\\", \\\"{x:1354,y:879,t:1527030598822};\\\", \\\"{x:1356,y:879,t:1527030598840};\\\", \\\"{x:1357,y:880,t:1527030598856};\\\", \\\"{x:1359,y:880,t:1527030598872};\\\", \\\"{x:1360,y:880,t:1527030598917};\\\", \\\"{x:1362,y:880,t:1527030599197};\\\", \\\"{x:1363,y:880,t:1527030599221};\\\", \\\"{x:1362,y:879,t:1527030599932};\\\", \\\"{x:1362,y:878,t:1527030600213};\\\", \\\"{x:1362,y:877,t:1527030600701};\\\", \\\"{x:1362,y:876,t:1527030600757};\\\", \\\"{x:1361,y:875,t:1527030600797};\\\", \\\"{x:1360,y:875,t:1527030600901};\\\", \\\"{x:1360,y:874,t:1527030601141};\\\", \\\"{x:1360,y:873,t:1527030601269};\\\", \\\"{x:1360,y:872,t:1527030601276};\\\", \\\"{x:1360,y:871,t:1527030601709};\\\", \\\"{x:1360,y:869,t:1527030601732};\\\", \\\"{x:1359,y:869,t:1527030601749};\\\", \\\"{x:1359,y:868,t:1527030601765};\\\", \\\"{x:1358,y:867,t:1527030601789};\\\", \\\"{x:1356,y:866,t:1527030601806};\\\", \\\"{x:1354,y:864,t:1527030601824};\\\", \\\"{x:1348,y:860,t:1527030601839};\\\", \\\"{x:1345,y:857,t:1527030601857};\\\", \\\"{x:1341,y:854,t:1527030601873};\\\", \\\"{x:1337,y:851,t:1527030601890};\\\", \\\"{x:1332,y:847,t:1527030601906};\\\", \\\"{x:1327,y:846,t:1527030601924};\\\", \\\"{x:1323,y:844,t:1527030601940};\\\", \\\"{x:1319,y:841,t:1527030601956};\\\", \\\"{x:1312,y:837,t:1527030601973};\\\", \\\"{x:1307,y:834,t:1527030601990};\\\", \\\"{x:1303,y:831,t:1527030602006};\\\", \\\"{x:1301,y:829,t:1527030602023};\\\", \\\"{x:1298,y:827,t:1527030602040};\\\", \\\"{x:1295,y:825,t:1527030602056};\\\", \\\"{x:1292,y:824,t:1527030602073};\\\", \\\"{x:1291,y:823,t:1527030602089};\\\", \\\"{x:1289,y:821,t:1527030602106};\\\", \\\"{x:1287,y:820,t:1527030602124};\\\", \\\"{x:1286,y:818,t:1527030602139};\\\", \\\"{x:1283,y:817,t:1527030602156};\\\", \\\"{x:1282,y:817,t:1527030602174};\\\", \\\"{x:1281,y:816,t:1527030602189};\\\", \\\"{x:1280,y:816,t:1527030602206};\\\", \\\"{x:1278,y:815,t:1527030602223};\\\", \\\"{x:1275,y:815,t:1527030602239};\\\", \\\"{x:1272,y:813,t:1527030602256};\\\", \\\"{x:1270,y:812,t:1527030602273};\\\", \\\"{x:1268,y:810,t:1527030602290};\\\", \\\"{x:1266,y:809,t:1527030602307};\\\", \\\"{x:1264,y:809,t:1527030602323};\\\", \\\"{x:1262,y:806,t:1527030602340};\\\", \\\"{x:1259,y:804,t:1527030602356};\\\", \\\"{x:1255,y:800,t:1527030602373};\\\", \\\"{x:1251,y:798,t:1527030602389};\\\", \\\"{x:1246,y:796,t:1527030602407};\\\", \\\"{x:1240,y:795,t:1527030602424};\\\", \\\"{x:1236,y:794,t:1527030602439};\\\", \\\"{x:1231,y:793,t:1527030602456};\\\", \\\"{x:1225,y:792,t:1527030602474};\\\", \\\"{x:1217,y:791,t:1527030602489};\\\", \\\"{x:1210,y:789,t:1527030602507};\\\", \\\"{x:1207,y:788,t:1527030602524};\\\", \\\"{x:1204,y:787,t:1527030602539};\\\", \\\"{x:1200,y:787,t:1527030602556};\\\", \\\"{x:1197,y:785,t:1527030602573};\\\", \\\"{x:1196,y:785,t:1527030602590};\\\", \\\"{x:1195,y:785,t:1527030602653};\\\", \\\"{x:1194,y:784,t:1527030602661};\\\", \\\"{x:1194,y:783,t:1527030602673};\\\", \\\"{x:1193,y:783,t:1527030602709};\\\", \\\"{x:1192,y:782,t:1527030602724};\\\", \\\"{x:1191,y:781,t:1527030602781};\\\", \\\"{x:1191,y:780,t:1527030602813};\\\", \\\"{x:1190,y:779,t:1527030602837};\\\", \\\"{x:1188,y:779,t:1527030602973};\\\", \\\"{x:1171,y:786,t:1527030602989};\\\", \\\"{x:1154,y:797,t:1527030603006};\\\", \\\"{x:1139,y:805,t:1527030603023};\\\", \\\"{x:1129,y:812,t:1527030603039};\\\", \\\"{x:1126,y:815,t:1527030603056};\\\", \\\"{x:1126,y:816,t:1527030603074};\\\", \\\"{x:1127,y:815,t:1527030603349};\\\", \\\"{x:1129,y:814,t:1527030603357};\\\", \\\"{x:1135,y:809,t:1527030603372};\\\", \\\"{x:1142,y:805,t:1527030603389};\\\", \\\"{x:1151,y:800,t:1527030603407};\\\", \\\"{x:1156,y:797,t:1527030603423};\\\", \\\"{x:1160,y:794,t:1527030603440};\\\", \\\"{x:1164,y:791,t:1527030603456};\\\", \\\"{x:1171,y:784,t:1527030603473};\\\", \\\"{x:1173,y:782,t:1527030603489};\\\", \\\"{x:1174,y:781,t:1527030603506};\\\", \\\"{x:1174,y:780,t:1527030603524};\\\", \\\"{x:1175,y:779,t:1527030603539};\\\", \\\"{x:1176,y:779,t:1527030604557};\\\", \\\"{x:1177,y:779,t:1527030604573};\\\", \\\"{x:1179,y:779,t:1527030604773};\\\", \\\"{x:1185,y:783,t:1527030604790};\\\", \\\"{x:1196,y:791,t:1527030604806};\\\", \\\"{x:1208,y:803,t:1527030604823};\\\", \\\"{x:1222,y:815,t:1527030604840};\\\", \\\"{x:1231,y:821,t:1527030604857};\\\", \\\"{x:1241,y:829,t:1527030604874};\\\", \\\"{x:1249,y:833,t:1527030604890};\\\", \\\"{x:1253,y:835,t:1527030604907};\\\", \\\"{x:1257,y:837,t:1527030604924};\\\", \\\"{x:1260,y:838,t:1527030604940};\\\", \\\"{x:1261,y:839,t:1527030604956};\\\", \\\"{x:1263,y:840,t:1527030604973};\\\", \\\"{x:1265,y:841,t:1527030604989};\\\", \\\"{x:1267,y:842,t:1527030605006};\\\", \\\"{x:1268,y:843,t:1527030605024};\\\", \\\"{x:1269,y:844,t:1527030605041};\\\", \\\"{x:1270,y:845,t:1527030605061};\\\", \\\"{x:1271,y:847,t:1527030605084};\\\", \\\"{x:1272,y:848,t:1527030605125};\\\", \\\"{x:1272,y:849,t:1527030605156};\\\", \\\"{x:1272,y:850,t:1527030605173};\\\", \\\"{x:1272,y:851,t:1527030605213};\\\", \\\"{x:1273,y:851,t:1527030605224};\\\", \\\"{x:1273,y:852,t:1527030605240};\\\", \\\"{x:1274,y:854,t:1527030605257};\\\", \\\"{x:1274,y:855,t:1527030605274};\\\", \\\"{x:1275,y:856,t:1527030605290};\\\", \\\"{x:1275,y:857,t:1527030605325};\\\", \\\"{x:1275,y:858,t:1527030605389};\\\", \\\"{x:1276,y:859,t:1527030605757};\\\", \\\"{x:1277,y:859,t:1527030605781};\\\", \\\"{x:1278,y:859,t:1527030605821};\\\", \\\"{x:1278,y:858,t:1527030605837};\\\", \\\"{x:1280,y:856,t:1527030605844};\\\", \\\"{x:1280,y:855,t:1527030605856};\\\", \\\"{x:1283,y:848,t:1527030605874};\\\", \\\"{x:1288,y:838,t:1527030605890};\\\", \\\"{x:1298,y:828,t:1527030605906};\\\", \\\"{x:1309,y:817,t:1527030605923};\\\", \\\"{x:1320,y:801,t:1527030605941};\\\", \\\"{x:1320,y:799,t:1527030605957};\\\", \\\"{x:1324,y:787,t:1527030605973};\\\", \\\"{x:1329,y:777,t:1527030605991};\\\", \\\"{x:1332,y:771,t:1527030606006};\\\", \\\"{x:1334,y:765,t:1527030606024};\\\", \\\"{x:1335,y:763,t:1527030606041};\\\", \\\"{x:1337,y:761,t:1527030606057};\\\", \\\"{x:1337,y:760,t:1527030606085};\\\", \\\"{x:1335,y:762,t:1527030606276};\\\", \\\"{x:1335,y:763,t:1527030606290};\\\", \\\"{x:1332,y:766,t:1527030606307};\\\", \\\"{x:1331,y:769,t:1527030606324};\\\", \\\"{x:1328,y:774,t:1527030606340};\\\", \\\"{x:1325,y:779,t:1527030606357};\\\", \\\"{x:1323,y:785,t:1527030606374};\\\", \\\"{x:1321,y:789,t:1527030606390};\\\", \\\"{x:1319,y:793,t:1527030606406};\\\", \\\"{x:1317,y:800,t:1527030606423};\\\", \\\"{x:1313,y:810,t:1527030606440};\\\", \\\"{x:1308,y:820,t:1527030606456};\\\", \\\"{x:1302,y:835,t:1527030606473};\\\", \\\"{x:1298,y:844,t:1527030606491};\\\", \\\"{x:1295,y:851,t:1527030606506};\\\", \\\"{x:1294,y:856,t:1527030606524};\\\", \\\"{x:1292,y:860,t:1527030606540};\\\", \\\"{x:1292,y:863,t:1527030606556};\\\", \\\"{x:1292,y:871,t:1527030606573};\\\", \\\"{x:1292,y:879,t:1527030606590};\\\", \\\"{x:1295,y:890,t:1527030606607};\\\", \\\"{x:1299,y:899,t:1527030606624};\\\", \\\"{x:1301,y:908,t:1527030606641};\\\", \\\"{x:1303,y:917,t:1527030606656};\\\", \\\"{x:1304,y:922,t:1527030606674};\\\", \\\"{x:1304,y:927,t:1527030606690};\\\", \\\"{x:1305,y:930,t:1527030606707};\\\", \\\"{x:1305,y:933,t:1527030606724};\\\", \\\"{x:1305,y:935,t:1527030606741};\\\", \\\"{x:1305,y:939,t:1527030606757};\\\", \\\"{x:1305,y:941,t:1527030606773};\\\", \\\"{x:1305,y:943,t:1527030606790};\\\", \\\"{x:1305,y:944,t:1527030606806};\\\", \\\"{x:1307,y:940,t:1527030606877};\\\", \\\"{x:1311,y:927,t:1527030606890};\\\", \\\"{x:1328,y:887,t:1527030606907};\\\", \\\"{x:1346,y:834,t:1527030606924};\\\", \\\"{x:1363,y:780,t:1527030606940};\\\", \\\"{x:1372,y:759,t:1527030606956};\\\", \\\"{x:1377,y:744,t:1527030606973};\\\", \\\"{x:1377,y:743,t:1527030606991};\\\", \\\"{x:1377,y:742,t:1527030607036};\\\", \\\"{x:1372,y:744,t:1527030607044};\\\", \\\"{x:1366,y:748,t:1527030607057};\\\", \\\"{x:1347,y:761,t:1527030607074};\\\", \\\"{x:1325,y:777,t:1527030607091};\\\", \\\"{x:1306,y:793,t:1527030607107};\\\", \\\"{x:1286,y:814,t:1527030607124};\\\", \\\"{x:1269,y:848,t:1527030607140};\\\", \\\"{x:1260,y:868,t:1527030607156};\\\", \\\"{x:1255,y:880,t:1527030607174};\\\", \\\"{x:1254,y:887,t:1527030607190};\\\", \\\"{x:1254,y:891,t:1527030607207};\\\", \\\"{x:1252,y:895,t:1527030607223};\\\", \\\"{x:1252,y:899,t:1527030607240};\\\", \\\"{x:1252,y:904,t:1527030607257};\\\", \\\"{x:1252,y:908,t:1527030607273};\\\", \\\"{x:1254,y:913,t:1527030607291};\\\", \\\"{x:1256,y:915,t:1527030607307};\\\", \\\"{x:1257,y:917,t:1527030607324};\\\", \\\"{x:1258,y:920,t:1527030607341};\\\", \\\"{x:1259,y:922,t:1527030607356};\\\", \\\"{x:1260,y:923,t:1527030607373};\\\", \\\"{x:1261,y:925,t:1527030607390};\\\", \\\"{x:1262,y:926,t:1527030607407};\\\", \\\"{x:1263,y:929,t:1527030607424};\\\", \\\"{x:1263,y:931,t:1527030607441};\\\", \\\"{x:1265,y:933,t:1527030607456};\\\", \\\"{x:1267,y:935,t:1527030607473};\\\", \\\"{x:1268,y:935,t:1527030607491};\\\", \\\"{x:1269,y:936,t:1527030607507};\\\", \\\"{x:1269,y:937,t:1527030607524};\\\", \\\"{x:1271,y:940,t:1527030607540};\\\", \\\"{x:1272,y:944,t:1527030607556};\\\", \\\"{x:1273,y:948,t:1527030607574};\\\", \\\"{x:1275,y:952,t:1527030607591};\\\", \\\"{x:1276,y:953,t:1527030607607};\\\", \\\"{x:1277,y:956,t:1527030607624};\\\", \\\"{x:1278,y:957,t:1527030607640};\\\", \\\"{x:1280,y:958,t:1527030607657};\\\", \\\"{x:1281,y:959,t:1527030607724};\\\", \\\"{x:1282,y:960,t:1527030607765};\\\", \\\"{x:1281,y:959,t:1527030608021};\\\", \\\"{x:1280,y:956,t:1527030608029};\\\", \\\"{x:1278,y:952,t:1527030608040};\\\", \\\"{x:1276,y:943,t:1527030608057};\\\", \\\"{x:1275,y:931,t:1527030608074};\\\", \\\"{x:1270,y:912,t:1527030608091};\\\", \\\"{x:1264,y:890,t:1527030608106};\\\", \\\"{x:1254,y:865,t:1527030608124};\\\", \\\"{x:1235,y:830,t:1527030608140};\\\", \\\"{x:1224,y:813,t:1527030608156};\\\", \\\"{x:1218,y:803,t:1527030608173};\\\", \\\"{x:1215,y:800,t:1527030608191};\\\", \\\"{x:1214,y:798,t:1527030608207};\\\", \\\"{x:1211,y:795,t:1527030608223};\\\", \\\"{x:1209,y:794,t:1527030608240};\\\", \\\"{x:1203,y:792,t:1527030608257};\\\", \\\"{x:1199,y:790,t:1527030608274};\\\", \\\"{x:1195,y:789,t:1527030608290};\\\", \\\"{x:1188,y:785,t:1527030608307};\\\", \\\"{x:1179,y:782,t:1527030608324};\\\", \\\"{x:1166,y:777,t:1527030608341};\\\", \\\"{x:1162,y:776,t:1527030608356};\\\", \\\"{x:1161,y:775,t:1527030608373};\\\", \\\"{x:1158,y:774,t:1527030608390};\\\", \\\"{x:1157,y:774,t:1527030608407};\\\", \\\"{x:1156,y:773,t:1527030608423};\\\", \\\"{x:1156,y:771,t:1527030608440};\\\", \\\"{x:1156,y:770,t:1527030608457};\\\", \\\"{x:1156,y:768,t:1527030608476};\\\", \\\"{x:1156,y:767,t:1527030608517};\\\", \\\"{x:1156,y:766,t:1527030608533};\\\", \\\"{x:1157,y:765,t:1527030608549};\\\", \\\"{x:1159,y:765,t:1527030608556};\\\", \\\"{x:1161,y:765,t:1527030608573};\\\", \\\"{x:1163,y:764,t:1527030608590};\\\", \\\"{x:1165,y:764,t:1527030608607};\\\", \\\"{x:1166,y:764,t:1527030608644};\\\", \\\"{x:1167,y:764,t:1527030608657};\\\", \\\"{x:1171,y:763,t:1527030608674};\\\", \\\"{x:1176,y:762,t:1527030608690};\\\", \\\"{x:1178,y:762,t:1527030608708};\\\", \\\"{x:1177,y:762,t:1527030609061};\\\", \\\"{x:1172,y:762,t:1527030609074};\\\", \\\"{x:1145,y:762,t:1527030609090};\\\", \\\"{x:1099,y:762,t:1527030609107};\\\", \\\"{x:1046,y:762,t:1527030609124};\\\", \\\"{x:986,y:758,t:1527030609140};\\\", \\\"{x:969,y:753,t:1527030609158};\\\", \\\"{x:957,y:749,t:1527030609174};\\\", \\\"{x:940,y:746,t:1527030609191};\\\", \\\"{x:916,y:737,t:1527030609208};\\\", \\\"{x:889,y:726,t:1527030609223};\\\", \\\"{x:864,y:715,t:1527030609240};\\\", \\\"{x:848,y:706,t:1527030609257};\\\", \\\"{x:841,y:700,t:1527030609274};\\\", \\\"{x:833,y:693,t:1527030609290};\\\", \\\"{x:824,y:683,t:1527030609307};\\\", \\\"{x:812,y:673,t:1527030609324};\\\", \\\"{x:785,y:652,t:1527030609340};\\\", \\\"{x:770,y:644,t:1527030609358};\\\", \\\"{x:759,y:637,t:1527030609373};\\\", \\\"{x:748,y:630,t:1527030609391};\\\", \\\"{x:737,y:624,t:1527030609408};\\\", \\\"{x:727,y:619,t:1527030609424};\\\", \\\"{x:719,y:612,t:1527030609436};\\\", \\\"{x:713,y:607,t:1527030609452};\\\", \\\"{x:711,y:605,t:1527030609471};\\\", \\\"{x:711,y:602,t:1527030609487};\\\", \\\"{x:709,y:599,t:1527030609504};\\\", \\\"{x:708,y:595,t:1527030609520};\\\", \\\"{x:702,y:589,t:1527030609537};\\\", \\\"{x:689,y:584,t:1527030609554};\\\", \\\"{x:668,y:580,t:1527030609571};\\\", \\\"{x:646,y:579,t:1527030609587};\\\", \\\"{x:620,y:576,t:1527030609604};\\\", \\\"{x:581,y:573,t:1527030609621};\\\", \\\"{x:555,y:571,t:1527030609637};\\\", \\\"{x:525,y:565,t:1527030609653};\\\", \\\"{x:502,y:561,t:1527030609671};\\\", \\\"{x:476,y:557,t:1527030609688};\\\", \\\"{x:456,y:555,t:1527030609703};\\\", \\\"{x:441,y:552,t:1527030609720};\\\", \\\"{x:426,y:547,t:1527030609737};\\\", \\\"{x:412,y:543,t:1527030609753};\\\", \\\"{x:397,y:536,t:1527030609770};\\\", \\\"{x:386,y:528,t:1527030609787};\\\", \\\"{x:376,y:519,t:1527030609803};\\\", \\\"{x:370,y:514,t:1527030609821};\\\", \\\"{x:369,y:513,t:1527030609838};\\\", \\\"{x:369,y:512,t:1527030609860};\\\", \\\"{x:369,y:510,t:1527030609876};\\\", \\\"{x:367,y:507,t:1527030609888};\\\", \\\"{x:364,y:504,t:1527030609904};\\\", \\\"{x:363,y:504,t:1527030609920};\\\", \\\"{x:362,y:503,t:1527030609937};\\\", \\\"{x:359,y:503,t:1527030609954};\\\", \\\"{x:352,y:503,t:1527030609971};\\\", \\\"{x:334,y:500,t:1527030609987};\\\", \\\"{x:287,y:500,t:1527030610004};\\\", \\\"{x:260,y:499,t:1527030610020};\\\", \\\"{x:249,y:499,t:1527030610037};\\\", \\\"{x:242,y:499,t:1527030610054};\\\", \\\"{x:235,y:499,t:1527030610071};\\\", \\\"{x:224,y:499,t:1527030610087};\\\", \\\"{x:213,y:499,t:1527030610105};\\\", \\\"{x:206,y:499,t:1527030610120};\\\", \\\"{x:204,y:499,t:1527030610137};\\\", \\\"{x:203,y:499,t:1527030610165};\\\", \\\"{x:200,y:498,t:1527030610180};\\\", \\\"{x:199,y:498,t:1527030610189};\\\", \\\"{x:195,y:497,t:1527030610204};\\\", \\\"{x:189,y:496,t:1527030610221};\\\", \\\"{x:182,y:496,t:1527030610238};\\\", \\\"{x:177,y:496,t:1527030610254};\\\", \\\"{x:171,y:496,t:1527030610270};\\\", \\\"{x:168,y:496,t:1527030610288};\\\", \\\"{x:167,y:496,t:1527030610304};\\\", \\\"{x:166,y:496,t:1527030610322};\\\", \\\"{x:163,y:496,t:1527030610337};\\\", \\\"{x:159,y:496,t:1527030610355};\\\", \\\"{x:156,y:496,t:1527030610370};\\\", \\\"{x:156,y:497,t:1527030610781};\\\", \\\"{x:156,y:499,t:1527030610789};\\\", \\\"{x:178,y:509,t:1527030610805};\\\", \\\"{x:220,y:525,t:1527030610823};\\\", \\\"{x:251,y:541,t:1527030610838};\\\", \\\"{x:279,y:562,t:1527030610855};\\\", \\\"{x:302,y:588,t:1527030610872};\\\", \\\"{x:312,y:606,t:1527030610889};\\\", \\\"{x:317,y:621,t:1527030610904};\\\", \\\"{x:320,y:631,t:1527030610921};\\\", \\\"{x:325,y:643,t:1527030610940};\\\", \\\"{x:327,y:648,t:1527030610955};\\\", \\\"{x:329,y:653,t:1527030610972};\\\", \\\"{x:331,y:662,t:1527030610989};\\\", \\\"{x:333,y:669,t:1527030611005};\\\", \\\"{x:333,y:674,t:1527030611022};\\\", \\\"{x:334,y:677,t:1527030611039};\\\", \\\"{x:335,y:680,t:1527030611055};\\\", \\\"{x:335,y:682,t:1527030611071};\\\", \\\"{x:337,y:683,t:1527030611089};\\\", \\\"{x:341,y:688,t:1527030611104};\\\", \\\"{x:346,y:693,t:1527030611122};\\\", \\\"{x:355,y:700,t:1527030611139};\\\", \\\"{x:374,y:710,t:1527030611155};\\\", \\\"{x:397,y:720,t:1527030611171};\\\", \\\"{x:433,y:731,t:1527030611188};\\\", \\\"{x:446,y:737,t:1527030611205};\\\", \\\"{x:452,y:739,t:1527030611222};\\\", \\\"{x:456,y:742,t:1527030611239};\\\", \\\"{x:459,y:746,t:1527030611256};\\\", \\\"{x:463,y:749,t:1527030611272};\\\", \\\"{x:471,y:754,t:1527030611289};\\\", \\\"{x:477,y:758,t:1527030611306};\\\", \\\"{x:485,y:762,t:1527030611322};\\\", \\\"{x:493,y:765,t:1527030611339};\\\", \\\"{x:501,y:769,t:1527030611355};\\\", \\\"{x:507,y:770,t:1527030611372};\\\", \\\"{x:517,y:774,t:1527030611389};\\\", \\\"{x:521,y:774,t:1527030611406};\\\", \\\"{x:527,y:775,t:1527030611421};\\\", \\\"{x:533,y:777,t:1527030611439};\\\", \\\"{x:539,y:777,t:1527030611456};\\\", \\\"{x:542,y:778,t:1527030611472};\\\", \\\"{x:545,y:778,t:1527030611488};\\\", \\\"{x:547,y:778,t:1527030611509};\\\", \\\"{x:548,y:778,t:1527030611521};\\\", \\\"{x:550,y:777,t:1527030611539};\\\", \\\"{x:551,y:776,t:1527030611556};\\\", \\\"{x:552,y:771,t:1527030611571};\\\", \\\"{x:552,y:769,t:1527030611588};\\\", \\\"{x:552,y:767,t:1527030611606};\\\", \\\"{x:554,y:765,t:1527030611622};\\\", \\\"{x:554,y:762,t:1527030611639};\\\", \\\"{x:554,y:761,t:1527030611660};\\\", \\\"{x:553,y:759,t:1527030611672};\\\", \\\"{x:551,y:757,t:1527030611688};\\\", \\\"{x:550,y:755,t:1527030611706};\\\", \\\"{x:547,y:753,t:1527030611723};\\\", \\\"{x:545,y:751,t:1527030611739};\\\", \\\"{x:541,y:749,t:1527030611756};\\\", \\\"{x:538,y:747,t:1527030611772};\\\", \\\"{x:537,y:746,t:1527030611788};\\\", \\\"{x:535,y:744,t:1527030611806};\\\", \\\"{x:531,y:743,t:1527030611822};\\\", \\\"{x:526,y:741,t:1527030611839};\\\", \\\"{x:522,y:740,t:1527030611856};\\\", \\\"{x:520,y:739,t:1527030611872};\\\", \\\"{x:519,y:739,t:1527030611890};\\\", \\\"{x:518,y:739,t:1527030611949};\\\", \\\"{x:517,y:738,t:1527030611957};\\\", \\\"{x:516,y:738,t:1527030611973};\\\", \\\"{x:515,y:737,t:1527030612061};\\\", \\\"{x:513,y:736,t:1527030612072};\\\", \\\"{x:512,y:736,t:1527030612133};\\\", \\\"{x:510,y:736,t:1527030619029};\\\", \\\"{x:503,y:736,t:1527030619044};\\\", \\\"{x:502,y:736,t:1527030619064};\\\", \\\"{x:501,y:736,t:1527030619084};\\\" ] }, { \\\"rt\\\": 9168, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 545408, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:736,t:1527030619997};\\\", \\\"{x:509,y:729,t:1527030620010};\\\", \\\"{x:531,y:710,t:1527030620027};\\\", \\\"{x:549,y:704,t:1527030620044};\\\", \\\"{x:550,y:698,t:1527030620062};\\\", \\\"{x:550,y:685,t:1527030620079};\\\", \\\"{x:550,y:663,t:1527030620096};\\\", \\\"{x:551,y:641,t:1527030620113};\\\", \\\"{x:553,y:622,t:1527030620129};\\\", \\\"{x:555,y:609,t:1527030620146};\\\", \\\"{x:557,y:592,t:1527030620162};\\\", \\\"{x:557,y:573,t:1527030620179};\\\", \\\"{x:554,y:555,t:1527030620196};\\\", \\\"{x:543,y:532,t:1527030620212};\\\", \\\"{x:525,y:509,t:1527030620230};\\\", \\\"{x:520,y:505,t:1527030620247};\\\", \\\"{x:518,y:504,t:1527030620262};\\\", \\\"{x:516,y:502,t:1527030620279};\\\", \\\"{x:510,y:501,t:1527030620296};\\\", \\\"{x:501,y:499,t:1527030620312};\\\", \\\"{x:490,y:498,t:1527030620329};\\\", \\\"{x:478,y:494,t:1527030620346};\\\", \\\"{x:468,y:491,t:1527030620363};\\\", \\\"{x:459,y:489,t:1527030620379};\\\", \\\"{x:452,y:488,t:1527030620396};\\\", \\\"{x:442,y:488,t:1527030620412};\\\", \\\"{x:436,y:488,t:1527030620429};\\\", \\\"{x:425,y:491,t:1527030620446};\\\", \\\"{x:406,y:500,t:1527030620464};\\\", \\\"{x:390,y:507,t:1527030620479};\\\", \\\"{x:383,y:513,t:1527030620496};\\\", \\\"{x:385,y:512,t:1527030620845};\\\", \\\"{x:393,y:506,t:1527030620852};\\\", \\\"{x:406,y:501,t:1527030620863};\\\", \\\"{x:427,y:494,t:1527030620880};\\\", \\\"{x:436,y:491,t:1527030620896};\\\", \\\"{x:444,y:488,t:1527030620913};\\\", \\\"{x:448,y:486,t:1527030620931};\\\", \\\"{x:449,y:485,t:1527030620946};\\\", \\\"{x:455,y:483,t:1527030620963};\\\", \\\"{x:468,y:480,t:1527030620980};\\\", \\\"{x:489,y:478,t:1527030620996};\\\", \\\"{x:531,y:478,t:1527030621013};\\\", \\\"{x:561,y:478,t:1527030621030};\\\", \\\"{x:587,y:478,t:1527030621046};\\\", \\\"{x:605,y:478,t:1527030621063};\\\", \\\"{x:613,y:478,t:1527030621080};\\\", \\\"{x:617,y:478,t:1527030621096};\\\", \\\"{x:619,y:476,t:1527030621113};\\\", \\\"{x:622,y:476,t:1527030621130};\\\", \\\"{x:632,y:476,t:1527030621146};\\\", \\\"{x:647,y:476,t:1527030621163};\\\", \\\"{x:662,y:476,t:1527030621180};\\\", \\\"{x:672,y:476,t:1527030621197};\\\", \\\"{x:681,y:476,t:1527030621213};\\\", \\\"{x:684,y:476,t:1527030621230};\\\", \\\"{x:689,y:476,t:1527030621247};\\\", \\\"{x:698,y:477,t:1527030621262};\\\", \\\"{x:710,y:483,t:1527030621280};\\\", \\\"{x:726,y:489,t:1527030621297};\\\", \\\"{x:741,y:495,t:1527030621313};\\\", \\\"{x:754,y:504,t:1527030621330};\\\", \\\"{x:775,y:521,t:1527030621347};\\\", \\\"{x:796,y:549,t:1527030621363};\\\", \\\"{x:821,y:586,t:1527030621381};\\\", \\\"{x:841,y:622,t:1527030621397};\\\", \\\"{x:851,y:639,t:1527030621414};\\\", \\\"{x:859,y:655,t:1527030621430};\\\", \\\"{x:870,y:672,t:1527030621447};\\\", \\\"{x:883,y:692,t:1527030621463};\\\", \\\"{x:906,y:719,t:1527030621480};\\\", \\\"{x:930,y:739,t:1527030621497};\\\", \\\"{x:958,y:763,t:1527030621514};\\\", \\\"{x:980,y:780,t:1527030621530};\\\", \\\"{x:998,y:798,t:1527030621547};\\\", \\\"{x:1027,y:822,t:1527030621564};\\\", \\\"{x:1066,y:856,t:1527030621581};\\\", \\\"{x:1141,y:895,t:1527030621597};\\\", \\\"{x:1193,y:908,t:1527030621614};\\\", \\\"{x:1237,y:914,t:1527030621631};\\\", \\\"{x:1265,y:915,t:1527030621647};\\\", \\\"{x:1284,y:915,t:1527030621665};\\\", \\\"{x:1300,y:915,t:1527030621681};\\\", \\\"{x:1314,y:915,t:1527030621697};\\\", \\\"{x:1331,y:915,t:1527030621714};\\\", \\\"{x:1347,y:915,t:1527030621731};\\\", \\\"{x:1373,y:915,t:1527030621749};\\\", \\\"{x:1386,y:913,t:1527030621764};\\\", \\\"{x:1393,y:912,t:1527030621781};\\\", \\\"{x:1396,y:911,t:1527030621799};\\\", \\\"{x:1397,y:911,t:1527030621822};\\\", \\\"{x:1399,y:911,t:1527030621838};\\\", \\\"{x:1403,y:911,t:1527030621849};\\\", \\\"{x:1418,y:911,t:1527030621865};\\\", \\\"{x:1442,y:915,t:1527030621882};\\\", \\\"{x:1467,y:922,t:1527030621899};\\\", \\\"{x:1488,y:930,t:1527030621915};\\\", \\\"{x:1504,y:933,t:1527030621932};\\\", \\\"{x:1517,y:936,t:1527030621949};\\\", \\\"{x:1535,y:938,t:1527030621965};\\\", \\\"{x:1546,y:940,t:1527030621981};\\\", \\\"{x:1556,y:941,t:1527030621998};\\\", \\\"{x:1568,y:942,t:1527030622015};\\\", \\\"{x:1579,y:945,t:1527030622032};\\\", \\\"{x:1588,y:946,t:1527030622048};\\\", \\\"{x:1598,y:946,t:1527030622065};\\\", \\\"{x:1612,y:946,t:1527030622082};\\\", \\\"{x:1622,y:946,t:1527030622098};\\\", \\\"{x:1631,y:943,t:1527030622115};\\\", \\\"{x:1641,y:939,t:1527030622133};\\\", \\\"{x:1643,y:938,t:1527030622148};\\\", \\\"{x:1648,y:932,t:1527030622165};\\\", \\\"{x:1652,y:929,t:1527030622182};\\\", \\\"{x:1659,y:923,t:1527030622199};\\\", \\\"{x:1664,y:916,t:1527030622215};\\\", \\\"{x:1666,y:913,t:1527030622233};\\\", \\\"{x:1667,y:911,t:1527030622249};\\\", \\\"{x:1668,y:909,t:1527030622266};\\\", \\\"{x:1668,y:908,t:1527030622283};\\\", \\\"{x:1669,y:905,t:1527030622299};\\\", \\\"{x:1671,y:902,t:1527030622316};\\\", \\\"{x:1672,y:900,t:1527030622333};\\\", \\\"{x:1673,y:899,t:1527030622349};\\\", \\\"{x:1675,y:898,t:1527030622366};\\\", \\\"{x:1676,y:896,t:1527030622382};\\\", \\\"{x:1678,y:895,t:1527030622399};\\\", \\\"{x:1680,y:894,t:1527030622416};\\\", \\\"{x:1681,y:893,t:1527030622433};\\\", \\\"{x:1681,y:892,t:1527030622449};\\\", \\\"{x:1683,y:891,t:1527030622466};\\\", \\\"{x:1686,y:887,t:1527030622483};\\\", \\\"{x:1690,y:881,t:1527030622499};\\\", \\\"{x:1695,y:868,t:1527030622516};\\\", \\\"{x:1702,y:845,t:1527030622533};\\\", \\\"{x:1705,y:831,t:1527030622550};\\\", \\\"{x:1708,y:814,t:1527030622566};\\\", \\\"{x:1708,y:799,t:1527030622583};\\\", \\\"{x:1708,y:777,t:1527030622600};\\\", \\\"{x:1708,y:754,t:1527030622616};\\\", \\\"{x:1708,y:740,t:1527030622632};\\\", \\\"{x:1705,y:727,t:1527030622650};\\\", \\\"{x:1698,y:716,t:1527030622667};\\\", \\\"{x:1690,y:708,t:1527030622683};\\\", \\\"{x:1676,y:696,t:1527030622700};\\\", \\\"{x:1652,y:681,t:1527030622717};\\\", \\\"{x:1643,y:675,t:1527030622731};\\\", \\\"{x:1629,y:668,t:1527030622748};\\\", \\\"{x:1616,y:658,t:1527030622765};\\\", \\\"{x:1595,y:645,t:1527030622781};\\\", \\\"{x:1576,y:631,t:1527030622798};\\\", \\\"{x:1555,y:618,t:1527030622815};\\\", \\\"{x:1543,y:608,t:1527030622832};\\\", \\\"{x:1538,y:605,t:1527030622848};\\\", \\\"{x:1537,y:604,t:1527030622865};\\\", \\\"{x:1536,y:603,t:1527030622882};\\\", \\\"{x:1535,y:602,t:1527030622897};\\\", \\\"{x:1535,y:599,t:1527030623010};\\\", \\\"{x:1537,y:597,t:1527030623026};\\\", \\\"{x:1538,y:596,t:1527030623034};\\\", \\\"{x:1541,y:593,t:1527030623048};\\\", \\\"{x:1544,y:591,t:1527030623066};\\\", \\\"{x:1546,y:588,t:1527030623082};\\\", \\\"{x:1547,y:585,t:1527030623098};\\\", \\\"{x:1547,y:584,t:1527030623115};\\\", \\\"{x:1547,y:582,t:1527030623132};\\\", \\\"{x:1547,y:581,t:1527030623149};\\\", \\\"{x:1547,y:580,t:1527030623165};\\\", \\\"{x:1547,y:578,t:1527030623182};\\\", \\\"{x:1541,y:578,t:1527030623198};\\\", \\\"{x:1535,y:580,t:1527030623216};\\\", \\\"{x:1522,y:585,t:1527030623233};\\\", \\\"{x:1503,y:595,t:1527030623248};\\\", \\\"{x:1481,y:606,t:1527030623265};\\\", \\\"{x:1454,y:623,t:1527030623283};\\\", \\\"{x:1436,y:633,t:1527030623298};\\\", \\\"{x:1420,y:643,t:1527030623316};\\\", \\\"{x:1405,y:651,t:1527030623333};\\\", \\\"{x:1389,y:660,t:1527030623349};\\\", \\\"{x:1372,y:667,t:1527030623365};\\\", \\\"{x:1357,y:671,t:1527030623382};\\\", \\\"{x:1347,y:673,t:1527030623400};\\\", \\\"{x:1344,y:673,t:1527030623415};\\\", \\\"{x:1338,y:675,t:1527030623433};\\\", \\\"{x:1334,y:677,t:1527030623450};\\\", \\\"{x:1324,y:683,t:1527030623465};\\\", \\\"{x:1322,y:684,t:1527030623483};\\\", \\\"{x:1320,y:685,t:1527030623499};\\\", \\\"{x:1320,y:683,t:1527030623746};\\\", \\\"{x:1321,y:678,t:1527030623753};\\\", \\\"{x:1322,y:674,t:1527030623766};\\\", \\\"{x:1324,y:664,t:1527030623783};\\\", \\\"{x:1326,y:655,t:1527030623801};\\\", \\\"{x:1326,y:644,t:1527030623816};\\\", \\\"{x:1326,y:633,t:1527030623834};\\\", \\\"{x:1318,y:624,t:1527030623851};\\\", \\\"{x:1312,y:619,t:1527030623867};\\\", \\\"{x:1304,y:614,t:1527030623884};\\\", \\\"{x:1298,y:608,t:1527030623901};\\\", \\\"{x:1291,y:601,t:1527030623917};\\\", \\\"{x:1285,y:594,t:1527030623933};\\\", \\\"{x:1280,y:589,t:1527030623951};\\\", \\\"{x:1275,y:581,t:1527030623967};\\\", \\\"{x:1272,y:578,t:1527030623984};\\\", \\\"{x:1270,y:575,t:1527030624001};\\\", \\\"{x:1267,y:569,t:1527030624018};\\\", \\\"{x:1266,y:565,t:1527030624034};\\\", \\\"{x:1266,y:560,t:1527030624051};\\\", \\\"{x:1266,y:556,t:1527030624068};\\\", \\\"{x:1266,y:554,t:1527030624085};\\\", \\\"{x:1266,y:553,t:1527030624100};\\\", \\\"{x:1266,y:551,t:1527030624118};\\\", \\\"{x:1266,y:550,t:1527030624134};\\\", \\\"{x:1266,y:549,t:1527030624266};\\\", \\\"{x:1270,y:552,t:1527030624282};\\\", \\\"{x:1273,y:556,t:1527030624290};\\\", \\\"{x:1275,y:559,t:1527030624302};\\\", \\\"{x:1280,y:566,t:1527030624319};\\\", \\\"{x:1286,y:576,t:1527030624335};\\\", \\\"{x:1291,y:582,t:1527030624352};\\\", \\\"{x:1293,y:587,t:1527030624368};\\\", \\\"{x:1295,y:589,t:1527030624384};\\\", \\\"{x:1296,y:593,t:1527030624402};\\\", \\\"{x:1298,y:598,t:1527030624419};\\\", \\\"{x:1299,y:601,t:1527030624436};\\\", \\\"{x:1300,y:605,t:1527030624452};\\\", \\\"{x:1301,y:610,t:1527030624468};\\\", \\\"{x:1303,y:615,t:1527030624486};\\\", \\\"{x:1303,y:622,t:1527030624502};\\\", \\\"{x:1306,y:631,t:1527030624518};\\\", \\\"{x:1309,y:641,t:1527030624536};\\\", \\\"{x:1312,y:652,t:1527030624553};\\\", \\\"{x:1316,y:662,t:1527030624568};\\\", \\\"{x:1320,y:674,t:1527030624586};\\\", \\\"{x:1321,y:679,t:1527030624603};\\\", \\\"{x:1325,y:686,t:1527030624618};\\\", \\\"{x:1327,y:690,t:1527030624635};\\\", \\\"{x:1332,y:698,t:1527030624652};\\\", \\\"{x:1337,y:704,t:1527030624669};\\\", \\\"{x:1342,y:712,t:1527030624685};\\\", \\\"{x:1348,y:721,t:1527030624703};\\\", \\\"{x:1354,y:732,t:1527030624719};\\\", \\\"{x:1362,y:744,t:1527030624735};\\\", \\\"{x:1371,y:759,t:1527030624753};\\\", \\\"{x:1382,y:773,t:1527030624769};\\\", \\\"{x:1394,y:787,t:1527030624786};\\\", \\\"{x:1404,y:799,t:1527030624802};\\\", \\\"{x:1417,y:809,t:1527030624819};\\\", \\\"{x:1425,y:818,t:1527030624837};\\\", \\\"{x:1433,y:826,t:1527030624852};\\\", \\\"{x:1436,y:833,t:1527030624869};\\\", \\\"{x:1440,y:839,t:1527030624887};\\\", \\\"{x:1445,y:845,t:1527030624903};\\\", \\\"{x:1451,y:856,t:1527030624920};\\\", \\\"{x:1459,y:870,t:1527030624937};\\\", \\\"{x:1473,y:894,t:1527030624953};\\\", \\\"{x:1479,y:906,t:1527030624970};\\\", \\\"{x:1487,y:920,t:1527030624986};\\\", \\\"{x:1492,y:927,t:1527030625003};\\\", \\\"{x:1493,y:931,t:1527030625019};\\\", \\\"{x:1496,y:936,t:1527030625036};\\\", \\\"{x:1496,y:937,t:1527030625053};\\\", \\\"{x:1496,y:938,t:1527030625071};\\\", \\\"{x:1493,y:934,t:1527030625130};\\\", \\\"{x:1487,y:922,t:1527030625137};\\\", \\\"{x:1463,y:887,t:1527030625153};\\\", \\\"{x:1433,y:847,t:1527030625170};\\\", \\\"{x:1412,y:816,t:1527030625187};\\\", \\\"{x:1398,y:798,t:1527030625204};\\\", \\\"{x:1392,y:785,t:1527030625221};\\\", \\\"{x:1387,y:773,t:1527030625237};\\\", \\\"{x:1384,y:764,t:1527030625253};\\\", \\\"{x:1377,y:753,t:1527030625270};\\\", \\\"{x:1365,y:738,t:1527030625288};\\\", \\\"{x:1351,y:722,t:1527030625304};\\\", \\\"{x:1334,y:707,t:1527030625321};\\\", \\\"{x:1309,y:689,t:1527030625337};\\\", \\\"{x:1297,y:680,t:1527030625354};\\\", \\\"{x:1291,y:674,t:1527030625371};\\\", \\\"{x:1281,y:665,t:1527030625388};\\\", \\\"{x:1269,y:652,t:1527030625405};\\\", \\\"{x:1251,y:633,t:1527030625420};\\\", \\\"{x:1234,y:616,t:1527030625438};\\\", \\\"{x:1225,y:601,t:1527030625455};\\\", \\\"{x:1220,y:591,t:1527030625471};\\\", \\\"{x:1218,y:582,t:1527030625488};\\\", \\\"{x:1218,y:578,t:1527030625505};\\\", \\\"{x:1218,y:571,t:1527030625522};\\\", \\\"{x:1216,y:569,t:1527030625537};\\\", \\\"{x:1204,y:562,t:1527030625555};\\\", \\\"{x:1183,y:556,t:1527030625571};\\\", \\\"{x:1156,y:555,t:1527030625588};\\\", \\\"{x:1118,y:555,t:1527030625605};\\\", \\\"{x:1065,y:555,t:1527030625621};\\\", \\\"{x:1012,y:555,t:1527030625639};\\\", \\\"{x:950,y:555,t:1527030625654};\\\", \\\"{x:900,y:555,t:1527030625672};\\\", \\\"{x:860,y:555,t:1527030625689};\\\", \\\"{x:831,y:555,t:1527030625708};\\\", \\\"{x:826,y:554,t:1527030625726};\\\", \\\"{x:824,y:554,t:1527030625742};\\\", \\\"{x:823,y:554,t:1527030625810};\\\", \\\"{x:819,y:554,t:1527030625826};\\\", \\\"{x:817,y:554,t:1527030625842};\\\", \\\"{x:816,y:551,t:1527030625986};\\\", \\\"{x:816,y:547,t:1527030625994};\\\", \\\"{x:823,y:532,t:1527030626009};\\\", \\\"{x:827,y:523,t:1527030626027};\\\", \\\"{x:830,y:518,t:1527030626042};\\\", \\\"{x:834,y:514,t:1527030626065};\\\", \\\"{x:836,y:510,t:1527030626082};\\\", \\\"{x:838,y:509,t:1527030626097};\\\", \\\"{x:838,y:508,t:1527030626114};\\\", \\\"{x:838,y:507,t:1527030626202};\\\", \\\"{x:837,y:507,t:1527030626215};\\\", \\\"{x:824,y:507,t:1527030626232};\\\", \\\"{x:801,y:507,t:1527030626248};\\\", \\\"{x:771,y:506,t:1527030626265};\\\", \\\"{x:725,y:506,t:1527030626282};\\\", \\\"{x:704,y:506,t:1527030626299};\\\", \\\"{x:692,y:506,t:1527030626314};\\\", \\\"{x:687,y:506,t:1527030626332};\\\", \\\"{x:687,y:507,t:1527030626353};\\\", \\\"{x:686,y:507,t:1527030626377};\\\", \\\"{x:685,y:507,t:1527030626386};\\\", \\\"{x:684,y:507,t:1527030626399};\\\", \\\"{x:683,y:507,t:1527030626441};\\\", \\\"{x:681,y:507,t:1527030626450};\\\", \\\"{x:678,y:507,t:1527030626465};\\\", \\\"{x:664,y:507,t:1527030626481};\\\", \\\"{x:657,y:507,t:1527030626498};\\\", \\\"{x:653,y:507,t:1527030626515};\\\", \\\"{x:652,y:507,t:1527030626531};\\\", \\\"{x:650,y:507,t:1527030626548};\\\", \\\"{x:646,y:507,t:1527030626565};\\\", \\\"{x:642,y:507,t:1527030626582};\\\", \\\"{x:638,y:507,t:1527030626599};\\\", \\\"{x:630,y:507,t:1527030626614};\\\", \\\"{x:627,y:507,t:1527030626632};\\\", \\\"{x:625,y:507,t:1527030626690};\\\", \\\"{x:624,y:507,t:1527030626698};\\\", \\\"{x:620,y:507,t:1527030626715};\\\", \\\"{x:616,y:507,t:1527030626731};\\\", \\\"{x:614,y:506,t:1527030626749};\\\", \\\"{x:612,y:505,t:1527030626842};\\\", \\\"{x:611,y:505,t:1527030626866};\\\", \\\"{x:609,y:505,t:1527030627210};\\\", \\\"{x:605,y:509,t:1527030627218};\\\", \\\"{x:603,y:522,t:1527030627232};\\\", \\\"{x:593,y:551,t:1527030627249};\\\", \\\"{x:574,y:618,t:1527030627266};\\\", \\\"{x:568,y:655,t:1527030627283};\\\", \\\"{x:566,y:677,t:1527030627299};\\\", \\\"{x:566,y:689,t:1527030627316};\\\", \\\"{x:565,y:696,t:1527030627332};\\\", \\\"{x:565,y:700,t:1527030627349};\\\", \\\"{x:561,y:705,t:1527030627365};\\\", \\\"{x:557,y:711,t:1527030627382};\\\", \\\"{x:555,y:714,t:1527030627399};\\\", \\\"{x:554,y:717,t:1527030627416};\\\", \\\"{x:553,y:718,t:1527030627433};\\\", \\\"{x:553,y:719,t:1527030627449};\\\", \\\"{x:552,y:721,t:1527030627466};\\\", \\\"{x:551,y:721,t:1527030627483};\\\", \\\"{x:550,y:722,t:1527030627499};\\\", \\\"{x:548,y:723,t:1527030627515};\\\", \\\"{x:545,y:724,t:1527030627533};\\\", \\\"{x:541,y:726,t:1527030627550};\\\", \\\"{x:536,y:728,t:1527030627565};\\\", \\\"{x:534,y:729,t:1527030627583};\\\", \\\"{x:533,y:730,t:1527030627618};\\\", \\\"{x:531,y:731,t:1527030627633};\\\", \\\"{x:528,y:734,t:1527030627650};\\\", \\\"{x:526,y:736,t:1527030627666};\\\", \\\"{x:525,y:737,t:1527030627683};\\\", \\\"{x:524,y:737,t:1527030627699};\\\", \\\"{x:523,y:738,t:1527030627715};\\\", \\\"{x:522,y:738,t:1527030627770};\\\", \\\"{x:521,y:739,t:1527030627786};\\\", \\\"{x:519,y:740,t:1527030627810};\\\", \\\"{x:517,y:741,t:1527030627818};\\\", \\\"{x:515,y:741,t:1527030627834};\\\", \\\"{x:513,y:742,t:1527030627850};\\\", \\\"{x:511,y:742,t:1527030627867};\\\", \\\"{x:508,y:742,t:1527030627883};\\\", \\\"{x:507,y:742,t:1527030627900};\\\", \\\"{x:506,y:742,t:1527030627917};\\\", \\\"{x:505,y:742,t:1527030628034};\\\", \\\"{x:504,y:742,t:1527030628050};\\\", \\\"{x:502,y:742,t:1527030628074};\\\", \\\"{x:501,y:742,t:1527030628097};\\\", \\\"{x:501,y:741,t:1527030628121};\\\", \\\"{x:500,y:740,t:1527030628133};\\\", \\\"{x:500,y:739,t:1527030628170};\\\", \\\"{x:499,y:739,t:1527030628184};\\\" ] }, { \\\"rt\\\": 24451, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 571064, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -M -M -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:738,t:1527030629826};\\\", \\\"{x:501,y:738,t:1527030629834};\\\", \\\"{x:503,y:736,t:1527030629852};\\\", \\\"{x:506,y:735,t:1527030629868};\\\", \\\"{x:508,y:732,t:1527030629930};\\\", \\\"{x:511,y:722,t:1527030629937};\\\", \\\"{x:512,y:713,t:1527030629952};\\\", \\\"{x:516,y:690,t:1527030629968};\\\", \\\"{x:517,y:673,t:1527030629985};\\\", \\\"{x:517,y:656,t:1527030630001};\\\", \\\"{x:517,y:622,t:1527030630018};\\\", \\\"{x:517,y:592,t:1527030630036};\\\", \\\"{x:514,y:537,t:1527030630102};\\\", \\\"{x:511,y:528,t:1527030630118};\\\", \\\"{x:500,y:515,t:1527030630136};\\\", \\\"{x:490,y:508,t:1527030630152};\\\", \\\"{x:480,y:504,t:1527030630168};\\\", \\\"{x:464,y:496,t:1527030630185};\\\", \\\"{x:446,y:488,t:1527030630201};\\\", \\\"{x:438,y:482,t:1527030630218};\\\", \\\"{x:432,y:476,t:1527030630235};\\\", \\\"{x:427,y:469,t:1527030630252};\\\", \\\"{x:426,y:468,t:1527030630268};\\\", \\\"{x:426,y:467,t:1527030630338};\\\", \\\"{x:426,y:466,t:1527030630351};\\\", \\\"{x:426,y:461,t:1527030630367};\\\", \\\"{x:426,y:460,t:1527030630385};\\\", \\\"{x:426,y:458,t:1527030630402};\\\", \\\"{x:427,y:458,t:1527030630417};\\\", \\\"{x:438,y:458,t:1527030630435};\\\", \\\"{x:457,y:458,t:1527030630452};\\\", \\\"{x:479,y:460,t:1527030630467};\\\", \\\"{x:498,y:464,t:1527030630485};\\\", \\\"{x:522,y:466,t:1527030630502};\\\", \\\"{x:542,y:466,t:1527030630517};\\\", \\\"{x:562,y:466,t:1527030630535};\\\", \\\"{x:578,y:466,t:1527030630552};\\\", \\\"{x:583,y:467,t:1527030630567};\\\", \\\"{x:585,y:467,t:1527030630584};\\\", \\\"{x:587,y:469,t:1527030630602};\\\", \\\"{x:589,y:469,t:1527030630618};\\\", \\\"{x:593,y:469,t:1527030630635};\\\", \\\"{x:597,y:468,t:1527030630652};\\\", \\\"{x:603,y:468,t:1527030630668};\\\", \\\"{x:604,y:468,t:1527030630697};\\\", \\\"{x:606,y:466,t:1527030631281};\\\", \\\"{x:607,y:465,t:1527030631290};\\\", \\\"{x:608,y:465,t:1527030631302};\\\", \\\"{x:622,y:465,t:1527030631318};\\\", \\\"{x:639,y:465,t:1527030631335};\\\", \\\"{x:663,y:471,t:1527030631352};\\\", \\\"{x:682,y:477,t:1527030631369};\\\", \\\"{x:697,y:479,t:1527030631385};\\\", \\\"{x:715,y:481,t:1527030631401};\\\", \\\"{x:726,y:482,t:1527030631419};\\\", \\\"{x:740,y:484,t:1527030631435};\\\", \\\"{x:759,y:487,t:1527030631453};\\\", \\\"{x:781,y:490,t:1527030631468};\\\", \\\"{x:807,y:495,t:1527030631486};\\\", \\\"{x:829,y:498,t:1527030631503};\\\", \\\"{x:845,y:500,t:1527030631519};\\\", \\\"{x:850,y:500,t:1527030631536};\\\", \\\"{x:852,y:501,t:1527030631553};\\\", \\\"{x:855,y:503,t:1527030631569};\\\", \\\"{x:866,y:507,t:1527030631586};\\\", \\\"{x:881,y:513,t:1527030631604};\\\", \\\"{x:894,y:518,t:1527030631620};\\\", \\\"{x:906,y:525,t:1527030631637};\\\", \\\"{x:918,y:531,t:1527030631653};\\\", \\\"{x:926,y:536,t:1527030631669};\\\", \\\"{x:935,y:542,t:1527030631686};\\\", \\\"{x:942,y:546,t:1527030631702};\\\", \\\"{x:949,y:550,t:1527030631719};\\\", \\\"{x:956,y:555,t:1527030631736};\\\", \\\"{x:964,y:560,t:1527030631752};\\\", \\\"{x:977,y:566,t:1527030631769};\\\", \\\"{x:1012,y:582,t:1527030631786};\\\", \\\"{x:1054,y:598,t:1527030631804};\\\", \\\"{x:1091,y:610,t:1527030631819};\\\", \\\"{x:1119,y:617,t:1527030631836};\\\", \\\"{x:1146,y:627,t:1527030631853};\\\", \\\"{x:1166,y:632,t:1527030631869};\\\", \\\"{x:1183,y:637,t:1527030631885};\\\", \\\"{x:1200,y:645,t:1527030631902};\\\", \\\"{x:1219,y:653,t:1527030631920};\\\", \\\"{x:1241,y:660,t:1527030631936};\\\", \\\"{x:1262,y:665,t:1527030631953};\\\", \\\"{x:1288,y:670,t:1527030631969};\\\", \\\"{x:1296,y:672,t:1527030631986};\\\", \\\"{x:1302,y:676,t:1527030632002};\\\", \\\"{x:1309,y:680,t:1527030632020};\\\", \\\"{x:1319,y:688,t:1527030632036};\\\", \\\"{x:1333,y:698,t:1527030632053};\\\", \\\"{x:1349,y:707,t:1527030632070};\\\", \\\"{x:1361,y:717,t:1527030632086};\\\", \\\"{x:1371,y:724,t:1527030632103};\\\", \\\"{x:1382,y:733,t:1527030632120};\\\", \\\"{x:1389,y:739,t:1527030632136};\\\", \\\"{x:1400,y:744,t:1527030632153};\\\", \\\"{x:1410,y:750,t:1527030632169};\\\", \\\"{x:1414,y:754,t:1527030632186};\\\", \\\"{x:1416,y:756,t:1527030632203};\\\", \\\"{x:1419,y:758,t:1527030632220};\\\", \\\"{x:1421,y:761,t:1527030632236};\\\", \\\"{x:1423,y:763,t:1527030632253};\\\", \\\"{x:1425,y:766,t:1527030632270};\\\", \\\"{x:1428,y:771,t:1527030632286};\\\", \\\"{x:1429,y:777,t:1527030632303};\\\", \\\"{x:1432,y:784,t:1527030632320};\\\", \\\"{x:1432,y:789,t:1527030632336};\\\", \\\"{x:1434,y:797,t:1527030632353};\\\", \\\"{x:1437,y:811,t:1527030632370};\\\", \\\"{x:1437,y:821,t:1527030632387};\\\", \\\"{x:1437,y:828,t:1527030632403};\\\", \\\"{x:1437,y:835,t:1527030632420};\\\", \\\"{x:1437,y:838,t:1527030632437};\\\", \\\"{x:1437,y:842,t:1527030632453};\\\", \\\"{x:1437,y:847,t:1527030632470};\\\", \\\"{x:1435,y:857,t:1527030632487};\\\", \\\"{x:1432,y:868,t:1527030632503};\\\", \\\"{x:1429,y:879,t:1527030632520};\\\", \\\"{x:1426,y:884,t:1527030632537};\\\", \\\"{x:1426,y:888,t:1527030632553};\\\", \\\"{x:1422,y:892,t:1527030632569};\\\", \\\"{x:1418,y:895,t:1527030632587};\\\", \\\"{x:1412,y:900,t:1527030632603};\\\", \\\"{x:1406,y:904,t:1527030632620};\\\", \\\"{x:1398,y:907,t:1527030632637};\\\", \\\"{x:1395,y:908,t:1527030632653};\\\", \\\"{x:1391,y:910,t:1527030632670};\\\", \\\"{x:1388,y:912,t:1527030632687};\\\", \\\"{x:1382,y:915,t:1527030632703};\\\", \\\"{x:1369,y:920,t:1527030632720};\\\", \\\"{x:1360,y:924,t:1527030632737};\\\", \\\"{x:1348,y:930,t:1527030632753};\\\", \\\"{x:1339,y:935,t:1527030632770};\\\", \\\"{x:1337,y:935,t:1527030632786};\\\", \\\"{x:1336,y:936,t:1527030632804};\\\", \\\"{x:1337,y:936,t:1527030632962};\\\", \\\"{x:1338,y:935,t:1527030632970};\\\", \\\"{x:1339,y:934,t:1527030632987};\\\", \\\"{x:1340,y:933,t:1527030633004};\\\", \\\"{x:1342,y:933,t:1527030633020};\\\", \\\"{x:1343,y:933,t:1527030633037};\\\", \\\"{x:1345,y:931,t:1527030633054};\\\", \\\"{x:1347,y:930,t:1527030633070};\\\", \\\"{x:1353,y:926,t:1527030633087};\\\", \\\"{x:1357,y:923,t:1527030633104};\\\", \\\"{x:1359,y:920,t:1527030633120};\\\", \\\"{x:1361,y:919,t:1527030633137};\\\", \\\"{x:1362,y:917,t:1527030633154};\\\", \\\"{x:1363,y:916,t:1527030633170};\\\", \\\"{x:1364,y:915,t:1527030633187};\\\", \\\"{x:1364,y:914,t:1527030633204};\\\", \\\"{x:1365,y:913,t:1527030633221};\\\", \\\"{x:1365,y:912,t:1527030633237};\\\", \\\"{x:1365,y:911,t:1527030633254};\\\", \\\"{x:1365,y:909,t:1527030633271};\\\", \\\"{x:1365,y:908,t:1527030633287};\\\", \\\"{x:1366,y:905,t:1527030633304};\\\", \\\"{x:1366,y:904,t:1527030633321};\\\", \\\"{x:1366,y:903,t:1527030633337};\\\", \\\"{x:1366,y:901,t:1527030633354};\\\", \\\"{x:1366,y:900,t:1527030633371};\\\", \\\"{x:1366,y:898,t:1527030633387};\\\", \\\"{x:1367,y:897,t:1527030633642};\\\", \\\"{x:1369,y:897,t:1527030634418};\\\", \\\"{x:1369,y:898,t:1527030634434};\\\", \\\"{x:1369,y:899,t:1527030634442};\\\", \\\"{x:1370,y:899,t:1527030634455};\\\", \\\"{x:1370,y:900,t:1527030634481};\\\", \\\"{x:1371,y:902,t:1527030634498};\\\", \\\"{x:1372,y:903,t:1527030634570};\\\", \\\"{x:1372,y:904,t:1527030634642};\\\", \\\"{x:1373,y:905,t:1527030634690};\\\", \\\"{x:1373,y:907,t:1527030634722};\\\", \\\"{x:1373,y:908,t:1527030634746};\\\", \\\"{x:1373,y:910,t:1527030634786};\\\", \\\"{x:1374,y:910,t:1527030635051};\\\", \\\"{x:1375,y:910,t:1527030635058};\\\", \\\"{x:1376,y:910,t:1527030635082};\\\", \\\"{x:1377,y:910,t:1527030635090};\\\", \\\"{x:1378,y:909,t:1527030635106};\\\", \\\"{x:1379,y:908,t:1527030635122};\\\", \\\"{x:1379,y:907,t:1527030635154};\\\", \\\"{x:1379,y:906,t:1527030635162};\\\", \\\"{x:1379,y:905,t:1527030635186};\\\", \\\"{x:1380,y:904,t:1527030635202};\\\", \\\"{x:1380,y:903,t:1527030635218};\\\", \\\"{x:1380,y:901,t:1527030635235};\\\", \\\"{x:1380,y:900,t:1527030635255};\\\", \\\"{x:1380,y:899,t:1527030635272};\\\", \\\"{x:1380,y:898,t:1527030635305};\\\", \\\"{x:1380,y:897,t:1527030635354};\\\", \\\"{x:1380,y:896,t:1527030636762};\\\", \\\"{x:1381,y:895,t:1527030636773};\\\", \\\"{x:1379,y:895,t:1527030637266};\\\", \\\"{x:1376,y:895,t:1527030637273};\\\", \\\"{x:1365,y:896,t:1527030637290};\\\", \\\"{x:1355,y:898,t:1527030637307};\\\", \\\"{x:1337,y:896,t:1527030637324};\\\", \\\"{x:1313,y:890,t:1527030637340};\\\", \\\"{x:1278,y:875,t:1527030637357};\\\", \\\"{x:1233,y:855,t:1527030637374};\\\", \\\"{x:1168,y:832,t:1527030637390};\\\", \\\"{x:1091,y:810,t:1527030637407};\\\", \\\"{x:1031,y:787,t:1527030637424};\\\", \\\"{x:973,y:764,t:1527030637440};\\\", \\\"{x:931,y:742,t:1527030637457};\\\", \\\"{x:884,y:713,t:1527030637474};\\\", \\\"{x:864,y:695,t:1527030637490};\\\", \\\"{x:850,y:682,t:1527030637507};\\\", \\\"{x:839,y:666,t:1527030637524};\\\", \\\"{x:831,y:650,t:1527030637540};\\\", \\\"{x:822,y:633,t:1527030637557};\\\", \\\"{x:818,y:616,t:1527030637575};\\\", \\\"{x:815,y:604,t:1527030637590};\\\", \\\"{x:813,y:597,t:1527030637608};\\\", \\\"{x:811,y:591,t:1527030637625};\\\", \\\"{x:810,y:586,t:1527030637641};\\\", \\\"{x:809,y:584,t:1527030637657};\\\", \\\"{x:809,y:581,t:1527030637674};\\\", \\\"{x:809,y:580,t:1527030637691};\\\", \\\"{x:809,y:579,t:1527030637713};\\\", \\\"{x:809,y:578,t:1527030637753};\\\", \\\"{x:809,y:577,t:1527030637762};\\\", \\\"{x:809,y:576,t:1527030637777};\\\", \\\"{x:808,y:574,t:1527030637791};\\\", \\\"{x:803,y:573,t:1527030637807};\\\", \\\"{x:795,y:567,t:1527030637824};\\\", \\\"{x:784,y:562,t:1527030637842};\\\", \\\"{x:775,y:559,t:1527030637858};\\\", \\\"{x:764,y:559,t:1527030637874};\\\", \\\"{x:757,y:559,t:1527030637892};\\\", \\\"{x:751,y:559,t:1527030637909};\\\", \\\"{x:750,y:559,t:1527030637924};\\\", \\\"{x:746,y:558,t:1527030637994};\\\", \\\"{x:745,y:556,t:1527030638008};\\\", \\\"{x:738,y:554,t:1527030638026};\\\", \\\"{x:718,y:544,t:1527030638042};\\\", \\\"{x:699,y:538,t:1527030638058};\\\", \\\"{x:677,y:532,t:1527030638074};\\\", \\\"{x:655,y:527,t:1527030638091};\\\", \\\"{x:639,y:525,t:1527030638108};\\\", \\\"{x:632,y:523,t:1527030638125};\\\", \\\"{x:627,y:521,t:1527030638141};\\\", \\\"{x:624,y:519,t:1527030638158};\\\", \\\"{x:620,y:518,t:1527030638175};\\\", \\\"{x:615,y:517,t:1527030638192};\\\", \\\"{x:610,y:516,t:1527030638208};\\\", \\\"{x:606,y:516,t:1527030638224};\\\", \\\"{x:601,y:516,t:1527030638241};\\\", \\\"{x:592,y:516,t:1527030638258};\\\", \\\"{x:583,y:516,t:1527030638274};\\\", \\\"{x:570,y:518,t:1527030638291};\\\", \\\"{x:552,y:522,t:1527030638308};\\\", \\\"{x:535,y:527,t:1527030638324};\\\", \\\"{x:523,y:529,t:1527030638341};\\\", \\\"{x:509,y:534,t:1527030638358};\\\", \\\"{x:493,y:538,t:1527030638375};\\\", \\\"{x:475,y:540,t:1527030638391};\\\", \\\"{x:457,y:543,t:1527030638408};\\\", \\\"{x:441,y:545,t:1527030638425};\\\", \\\"{x:439,y:545,t:1527030638441};\\\", \\\"{x:438,y:545,t:1527030638458};\\\", \\\"{x:437,y:545,t:1527030638489};\\\", \\\"{x:436,y:545,t:1527030638497};\\\", \\\"{x:435,y:545,t:1527030638508};\\\", \\\"{x:434,y:545,t:1527030638554};\\\", \\\"{x:433,y:545,t:1527030638561};\\\", \\\"{x:432,y:545,t:1527030638575};\\\", \\\"{x:429,y:543,t:1527030638592};\\\", \\\"{x:426,y:543,t:1527030638608};\\\", \\\"{x:424,y:542,t:1527030638625};\\\", \\\"{x:423,y:542,t:1527030638665};\\\", \\\"{x:422,y:542,t:1527030638675};\\\", \\\"{x:420,y:542,t:1527030638692};\\\", \\\"{x:418,y:542,t:1527030638709};\\\", \\\"{x:416,y:542,t:1527030638725};\\\", \\\"{x:410,y:543,t:1527030638741};\\\", \\\"{x:403,y:545,t:1527030638758};\\\", \\\"{x:399,y:548,t:1527030638775};\\\", \\\"{x:396,y:548,t:1527030638791};\\\", \\\"{x:393,y:549,t:1527030638809};\\\", \\\"{x:389,y:549,t:1527030638826};\\\", \\\"{x:386,y:549,t:1527030638841};\\\", \\\"{x:383,y:549,t:1527030638858};\\\", \\\"{x:382,y:549,t:1527030638875};\\\", \\\"{x:380,y:549,t:1527030638891};\\\", \\\"{x:377,y:549,t:1527030638908};\\\", \\\"{x:376,y:549,t:1527030638925};\\\", \\\"{x:374,y:549,t:1527030638946};\\\", \\\"{x:382,y:549,t:1527030639530};\\\", \\\"{x:400,y:553,t:1527030639543};\\\", \\\"{x:442,y:560,t:1527030639559};\\\", \\\"{x:498,y:567,t:1527030639576};\\\", \\\"{x:546,y:568,t:1527030639593};\\\", \\\"{x:570,y:570,t:1527030639609};\\\", \\\"{x:576,y:570,t:1527030639625};\\\", \\\"{x:577,y:570,t:1527030639673};\\\", \\\"{x:578,y:570,t:1527030639682};\\\", \\\"{x:580,y:570,t:1527030639692};\\\", \\\"{x:585,y:572,t:1527030639709};\\\", \\\"{x:589,y:573,t:1527030639727};\\\", \\\"{x:591,y:574,t:1527030639742};\\\", \\\"{x:593,y:574,t:1527030639759};\\\", \\\"{x:594,y:575,t:1527030639777};\\\", \\\"{x:595,y:576,t:1527030639792};\\\", \\\"{x:597,y:577,t:1527030639809};\\\", \\\"{x:600,y:579,t:1527030639826};\\\", \\\"{x:600,y:580,t:1527030639850};\\\", \\\"{x:600,y:582,t:1527030639859};\\\", \\\"{x:600,y:585,t:1527030639876};\\\", \\\"{x:602,y:589,t:1527030639892};\\\", \\\"{x:604,y:591,t:1527030639909};\\\", \\\"{x:607,y:591,t:1527030639926};\\\", \\\"{x:609,y:593,t:1527030639942};\\\", \\\"{x:610,y:594,t:1527030639960};\\\", \\\"{x:610,y:595,t:1527030639976};\\\", \\\"{x:611,y:596,t:1527030640001};\\\", \\\"{x:612,y:596,t:1527030640033};\\\", \\\"{x:612,y:597,t:1527030640042};\\\", \\\"{x:616,y:598,t:1527030640060};\\\", \\\"{x:624,y:598,t:1527030640076};\\\", \\\"{x:641,y:598,t:1527030640092};\\\", \\\"{x:662,y:598,t:1527030640109};\\\", \\\"{x:687,y:598,t:1527030640127};\\\", \\\"{x:709,y:598,t:1527030640142};\\\", \\\"{x:726,y:598,t:1527030640159};\\\", \\\"{x:742,y:594,t:1527030640176};\\\", \\\"{x:757,y:588,t:1527030640193};\\\", \\\"{x:768,y:582,t:1527030640210};\\\", \\\"{x:776,y:574,t:1527030640226};\\\", \\\"{x:779,y:573,t:1527030640243};\\\", \\\"{x:781,y:572,t:1527030640259};\\\", \\\"{x:784,y:571,t:1527030640276};\\\", \\\"{x:786,y:570,t:1527030640293};\\\", \\\"{x:787,y:568,t:1527030640309};\\\", \\\"{x:788,y:568,t:1527030640326};\\\", \\\"{x:787,y:567,t:1527030640370};\\\", \\\"{x:782,y:567,t:1527030640377};\\\", \\\"{x:772,y:565,t:1527030640393};\\\", \\\"{x:742,y:562,t:1527030640409};\\\", \\\"{x:670,y:562,t:1527030640426};\\\", \\\"{x:636,y:562,t:1527030640443};\\\", \\\"{x:620,y:562,t:1527030640460};\\\", \\\"{x:615,y:563,t:1527030640477};\\\", \\\"{x:613,y:563,t:1527030640521};\\\", \\\"{x:608,y:563,t:1527030640530};\\\", \\\"{x:601,y:563,t:1527030640544};\\\", \\\"{x:580,y:563,t:1527030640560};\\\", \\\"{x:564,y:563,t:1527030640576};\\\", \\\"{x:551,y:563,t:1527030640594};\\\", \\\"{x:536,y:563,t:1527030640610};\\\", \\\"{x:525,y:559,t:1527030640627};\\\", \\\"{x:512,y:551,t:1527030640644};\\\", \\\"{x:490,y:542,t:1527030640661};\\\", \\\"{x:465,y:535,t:1527030640677};\\\", \\\"{x:444,y:530,t:1527030640694};\\\", \\\"{x:434,y:527,t:1527030640711};\\\", \\\"{x:428,y:526,t:1527030640726};\\\", \\\"{x:426,y:526,t:1527030640754};\\\", \\\"{x:425,y:526,t:1527030640762};\\\", \\\"{x:423,y:525,t:1527030640776};\\\", \\\"{x:412,y:523,t:1527030640793};\\\", \\\"{x:388,y:522,t:1527030640809};\\\", \\\"{x:368,y:522,t:1527030640827};\\\", \\\"{x:348,y:521,t:1527030640843};\\\", \\\"{x:330,y:521,t:1527030640861};\\\", \\\"{x:312,y:521,t:1527030640876};\\\", \\\"{x:297,y:520,t:1527030640894};\\\", \\\"{x:289,y:518,t:1527030640910};\\\", \\\"{x:288,y:518,t:1527030640926};\\\", \\\"{x:285,y:517,t:1527030640970};\\\", \\\"{x:284,y:517,t:1527030640977};\\\", \\\"{x:272,y:517,t:1527030640994};\\\", \\\"{x:254,y:516,t:1527030641011};\\\", \\\"{x:244,y:516,t:1527030641028};\\\", \\\"{x:239,y:516,t:1527030641043};\\\", \\\"{x:237,y:516,t:1527030641060};\\\", \\\"{x:235,y:516,t:1527030641081};\\\", \\\"{x:234,y:516,t:1527030641093};\\\", \\\"{x:232,y:516,t:1527030641110};\\\", \\\"{x:230,y:517,t:1527030641128};\\\", \\\"{x:227,y:520,t:1527030641143};\\\", \\\"{x:224,y:528,t:1527030641161};\\\", \\\"{x:223,y:541,t:1527030641177};\\\", \\\"{x:223,y:545,t:1527030641193};\\\", \\\"{x:223,y:551,t:1527030641210};\\\", \\\"{x:223,y:554,t:1527030641228};\\\", \\\"{x:225,y:558,t:1527030641243};\\\", \\\"{x:227,y:561,t:1527030641260};\\\", \\\"{x:229,y:564,t:1527030641278};\\\", \\\"{x:234,y:569,t:1527030641294};\\\", \\\"{x:238,y:572,t:1527030641310};\\\", \\\"{x:243,y:576,t:1527030641327};\\\", \\\"{x:256,y:580,t:1527030641344};\\\", \\\"{x:272,y:581,t:1527030641360};\\\", \\\"{x:287,y:582,t:1527030641378};\\\", \\\"{x:295,y:583,t:1527030641393};\\\", \\\"{x:303,y:583,t:1527030641410};\\\", \\\"{x:314,y:583,t:1527030641427};\\\", \\\"{x:333,y:583,t:1527030641444};\\\", \\\"{x:350,y:583,t:1527030641461};\\\", \\\"{x:365,y:583,t:1527030641477};\\\", \\\"{x:372,y:583,t:1527030641494};\\\", \\\"{x:373,y:583,t:1527030641510};\\\", \\\"{x:375,y:583,t:1527030641527};\\\", \\\"{x:376,y:583,t:1527030641545};\\\", \\\"{x:381,y:583,t:1527030641560};\\\", \\\"{x:391,y:583,t:1527030641577};\\\", \\\"{x:400,y:583,t:1527030641594};\\\", \\\"{x:409,y:583,t:1527030641610};\\\", \\\"{x:421,y:583,t:1527030641628};\\\", \\\"{x:436,y:583,t:1527030641644};\\\", \\\"{x:444,y:583,t:1527030641660};\\\", \\\"{x:453,y:583,t:1527030641677};\\\", \\\"{x:459,y:583,t:1527030641694};\\\", \\\"{x:467,y:586,t:1527030641710};\\\", \\\"{x:474,y:587,t:1527030641727};\\\", \\\"{x:478,y:590,t:1527030641744};\\\", \\\"{x:484,y:592,t:1527030641761};\\\", \\\"{x:501,y:598,t:1527030641777};\\\", \\\"{x:509,y:599,t:1527030641794};\\\", \\\"{x:514,y:602,t:1527030641812};\\\", \\\"{x:517,y:603,t:1527030641828};\\\", \\\"{x:518,y:604,t:1527030641882};\\\", \\\"{x:519,y:605,t:1527030641894};\\\", \\\"{x:521,y:605,t:1527030641911};\\\", \\\"{x:521,y:606,t:1527030641928};\\\", \\\"{x:522,y:606,t:1527030641944};\\\", \\\"{x:523,y:606,t:1527030642034};\\\", \\\"{x:524,y:606,t:1527030642058};\\\", \\\"{x:526,y:607,t:1527030642082};\\\", \\\"{x:527,y:607,t:1527030642153};\\\", \\\"{x:529,y:608,t:1527030642169};\\\", \\\"{x:530,y:609,t:1527030642186};\\\", \\\"{x:532,y:609,t:1527030642194};\\\", \\\"{x:534,y:609,t:1527030642211};\\\", \\\"{x:535,y:609,t:1527030642228};\\\", \\\"{x:536,y:609,t:1527030642306};\\\", \\\"{x:537,y:609,t:1527030642314};\\\", \\\"{x:538,y:609,t:1527030642337};\\\", \\\"{x:538,y:610,t:1527030642809};\\\", \\\"{x:535,y:613,t:1527030642818};\\\", \\\"{x:532,y:613,t:1527030642829};\\\", \\\"{x:520,y:618,t:1527030642846};\\\", \\\"{x:505,y:622,t:1527030642863};\\\", \\\"{x:495,y:623,t:1527030642880};\\\", \\\"{x:493,y:624,t:1527030642895};\\\", \\\"{x:489,y:625,t:1527030645314};\\\", \\\"{x:487,y:625,t:1527030645326};\\\", \\\"{x:476,y:625,t:1527030645343};\\\", \\\"{x:453,y:625,t:1527030645359};\\\", \\\"{x:426,y:623,t:1527030645375};\\\", \\\"{x:416,y:620,t:1527030645392};\\\", \\\"{x:415,y:620,t:1527030645408};\\\", \\\"{x:413,y:620,t:1527030645425};\\\", \\\"{x:411,y:620,t:1527030645441};\\\", \\\"{x:410,y:620,t:1527030645561};\\\", \\\"{x:410,y:619,t:1527030645569};\\\", \\\"{x:410,y:618,t:1527030645581};\\\", \\\"{x:410,y:617,t:1527030645601};\\\", \\\"{x:410,y:616,t:1527030645625};\\\", \\\"{x:409,y:615,t:1527030645634};\\\", \\\"{x:408,y:614,t:1527030645649};\\\", \\\"{x:408,y:612,t:1527030645665};\\\", \\\"{x:406,y:611,t:1527030645681};\\\", \\\"{x:405,y:609,t:1527030645698};\\\", \\\"{x:404,y:609,t:1527030645745};\\\", \\\"{x:401,y:607,t:1527030645754};\\\", \\\"{x:400,y:607,t:1527030645764};\\\", \\\"{x:395,y:607,t:1527030645780};\\\", \\\"{x:393,y:607,t:1527030645797};\\\", \\\"{x:391,y:607,t:1527030645850};\\\", \\\"{x:390,y:607,t:1527030645865};\\\", \\\"{x:392,y:607,t:1527030646169};\\\", \\\"{x:406,y:607,t:1527030646181};\\\", \\\"{x:437,y:610,t:1527030646197};\\\", \\\"{x:467,y:615,t:1527030646214};\\\", \\\"{x:496,y:620,t:1527030646232};\\\", \\\"{x:518,y:622,t:1527030646248};\\\", \\\"{x:531,y:624,t:1527030646264};\\\", \\\"{x:532,y:625,t:1527030646281};\\\", \\\"{x:534,y:625,t:1527030646322};\\\", \\\"{x:536,y:628,t:1527030646331};\\\", \\\"{x:542,y:635,t:1527030646347};\\\", \\\"{x:553,y:643,t:1527030646365};\\\", \\\"{x:562,y:649,t:1527030646382};\\\", \\\"{x:569,y:657,t:1527030646398};\\\", \\\"{x:572,y:662,t:1527030646415};\\\", \\\"{x:575,y:670,t:1527030646432};\\\", \\\"{x:578,y:680,t:1527030646448};\\\", \\\"{x:585,y:694,t:1527030646465};\\\", \\\"{x:595,y:711,t:1527030646481};\\\", \\\"{x:601,y:719,t:1527030646498};\\\", \\\"{x:605,y:725,t:1527030646515};\\\", \\\"{x:609,y:730,t:1527030646531};\\\", \\\"{x:612,y:733,t:1527030646547};\\\", \\\"{x:613,y:735,t:1527030646564};\\\", \\\"{x:615,y:738,t:1527030646581};\\\", \\\"{x:616,y:740,t:1527030646597};\\\", \\\"{x:619,y:744,t:1527030646615};\\\", \\\"{x:623,y:750,t:1527030646631};\\\", \\\"{x:630,y:758,t:1527030646648};\\\", \\\"{x:636,y:764,t:1527030646664};\\\", \\\"{x:644,y:769,t:1527030646681};\\\", \\\"{x:647,y:772,t:1527030646698};\\\", \\\"{x:648,y:772,t:1527030646738};\\\", \\\"{x:649,y:772,t:1527030646747};\\\", \\\"{x:655,y:775,t:1527030646764};\\\", \\\"{x:657,y:775,t:1527030646781};\\\", \\\"{x:658,y:775,t:1527030646801};\\\", \\\"{x:659,y:776,t:1527030646817};\\\", \\\"{x:661,y:778,t:1527030646834};\\\", \\\"{x:663,y:779,t:1527030646850};\\\", \\\"{x:664,y:779,t:1527030646864};\\\", \\\"{x:668,y:783,t:1527030646882};\\\", \\\"{x:674,y:787,t:1527030646898};\\\", \\\"{x:677,y:788,t:1527030646915};\\\", \\\"{x:680,y:789,t:1527030646932};\\\", \\\"{x:681,y:789,t:1527030646948};\\\", \\\"{x:682,y:790,t:1527030646964};\\\", \\\"{x:682,y:791,t:1527030646981};\\\", \\\"{x:683,y:791,t:1527030646998};\\\", \\\"{x:684,y:791,t:1527030647015};\\\", \\\"{x:684,y:792,t:1527030647634};\\\", \\\"{x:683,y:792,t:1527030647674};\\\", \\\"{x:682,y:792,t:1527030647682};\\\", \\\"{x:679,y:791,t:1527030647699};\\\", \\\"{x:673,y:789,t:1527030647714};\\\", \\\"{x:668,y:789,t:1527030647731};\\\", \\\"{x:660,y:788,t:1527030647748};\\\", \\\"{x:652,y:787,t:1527030647765};\\\", \\\"{x:646,y:784,t:1527030647782};\\\", \\\"{x:639,y:783,t:1527030647798};\\\", \\\"{x:636,y:781,t:1527030647814};\\\", \\\"{x:632,y:779,t:1527030647832};\\\", \\\"{x:628,y:778,t:1527030647849};\\\", \\\"{x:624,y:777,t:1527030647865};\\\", \\\"{x:615,y:775,t:1527030647882};\\\", \\\"{x:614,y:775,t:1527030647899};\\\", \\\"{x:612,y:775,t:1527030647914};\\\", \\\"{x:610,y:774,t:1527030647932};\\\", \\\"{x:606,y:773,t:1527030647949};\\\", \\\"{x:601,y:772,t:1527030647965};\\\", \\\"{x:596,y:770,t:1527030647982};\\\", \\\"{x:592,y:769,t:1527030647999};\\\", \\\"{x:588,y:768,t:1527030648015};\\\", \\\"{x:584,y:767,t:1527030648031};\\\", \\\"{x:577,y:765,t:1527030648048};\\\", \\\"{x:573,y:765,t:1527030648065};\\\", \\\"{x:566,y:763,t:1527030648081};\\\", \\\"{x:562,y:762,t:1527030648098};\\\", \\\"{x:557,y:760,t:1527030648116};\\\", \\\"{x:551,y:758,t:1527030648132};\\\", \\\"{x:543,y:756,t:1527030648148};\\\", \\\"{x:538,y:753,t:1527030648165};\\\", \\\"{x:532,y:750,t:1527030648182};\\\", \\\"{x:527,y:749,t:1527030648199};\\\", \\\"{x:517,y:748,t:1527030648216};\\\", \\\"{x:509,y:746,t:1527030648233};\\\", \\\"{x:505,y:746,t:1527030648249};\\\", \\\"{x:505,y:745,t:1527030648267};\\\", \\\"{x:503,y:744,t:1527030648283};\\\", \\\"{x:498,y:742,t:1527030648300};\\\", \\\"{x:496,y:741,t:1527030648316};\\\", \\\"{x:495,y:741,t:1527030648332};\\\", \\\"{x:495,y:740,t:1527030648890};\\\", \\\"{x:495,y:739,t:1527030648914};\\\", \\\"{x:497,y:739,t:1527030648953};\\\", \\\"{x:497,y:738,t:1527030648967};\\\", \\\"{x:498,y:738,t:1527030648984};\\\", \\\"{x:500,y:738,t:1527030649018};\\\", \\\"{x:501,y:738,t:1527030649033};\\\", \\\"{x:503,y:738,t:1527030649050};\\\", \\\"{x:504,y:738,t:1527030649097};\\\", \\\"{x:511,y:736,t:1527030650105};\\\", \\\"{x:523,y:722,t:1527030650117};\\\", \\\"{x:535,y:682,t:1527030650136};\\\", \\\"{x:569,y:620,t:1527030650151};\\\", \\\"{x:584,y:567,t:1527030650168};\\\", \\\"{x:585,y:537,t:1527030650185};\\\", \\\"{x:585,y:510,t:1527030650202};\\\", \\\"{x:577,y:485,t:1527030650218};\\\", \\\"{x:572,y:475,t:1527030650234};\\\", \\\"{x:571,y:471,t:1527030650251};\\\", \\\"{x:571,y:470,t:1527030650268};\\\", \\\"{x:571,y:469,t:1527030650285};\\\", \\\"{x:571,y:468,t:1527030650302};\\\", \\\"{x:570,y:467,t:1527030650394};\\\", \\\"{x:569,y:467,t:1527030650409};\\\", \\\"{x:567,y:467,t:1527030650426};\\\", \\\"{x:573,y:469,t:1527030650521};\\\", \\\"{x:585,y:473,t:1527030650535};\\\", \\\"{x:619,y:483,t:1527030650552};\\\", \\\"{x:691,y:514,t:1527030650569};\\\", \\\"{x:767,y:538,t:1527030650585};\\\", \\\"{x:859,y:578,t:1527030650602};\\\", \\\"{x:892,y:593,t:1527030650619};\\\", \\\"{x:910,y:604,t:1527030650636};\\\", \\\"{x:928,y:619,t:1527030650652};\\\", \\\"{x:949,y:640,t:1527030650669};\\\", \\\"{x:979,y:685,t:1527030650685};\\\", \\\"{x:1028,y:736,t:1527030650702};\\\", \\\"{x:1076,y:771,t:1527030650718};\\\", \\\"{x:1117,y:795,t:1527030650735};\\\", \\\"{x:1133,y:804,t:1527030650752};\\\", \\\"{x:1138,y:810,t:1527030650769};\\\", \\\"{x:1142,y:815,t:1527030650785};\\\", \\\"{x:1159,y:829,t:1527030650802};\\\", \\\"{x:1176,y:839,t:1527030650819};\\\", \\\"{x:1193,y:845,t:1527030650835};\\\", \\\"{x:1214,y:849,t:1527030650852};\\\", \\\"{x:1241,y:850,t:1527030650868};\\\", \\\"{x:1271,y:850,t:1527030650885};\\\", \\\"{x:1296,y:850,t:1527030650902};\\\", \\\"{x:1315,y:849,t:1527030650919};\\\", \\\"{x:1325,y:848,t:1527030650935};\\\", \\\"{x:1333,y:847,t:1527030650952};\\\", \\\"{x:1339,y:847,t:1527030650969};\\\", \\\"{x:1346,y:847,t:1527030650985};\\\", \\\"{x:1373,y:853,t:1527030651002};\\\", \\\"{x:1386,y:856,t:1527030651019};\\\", \\\"{x:1387,y:859,t:1527030651081};\\\", \\\"{x:1387,y:862,t:1527030651089};\\\", \\\"{x:1387,y:865,t:1527030651102};\\\", \\\"{x:1387,y:872,t:1527030651119};\\\", \\\"{x:1388,y:883,t:1527030651135};\\\", \\\"{x:1393,y:890,t:1527030651152};\\\", \\\"{x:1395,y:894,t:1527030651169};\\\", \\\"{x:1396,y:896,t:1527030651185};\\\", \\\"{x:1396,y:900,t:1527030651201};\\\", \\\"{x:1396,y:905,t:1527030651219};\\\", \\\"{x:1394,y:910,t:1527030651236};\\\", \\\"{x:1393,y:915,t:1527030651252};\\\", \\\"{x:1387,y:921,t:1527030651269};\\\", \\\"{x:1384,y:923,t:1527030651286};\\\", \\\"{x:1379,y:927,t:1527030651302};\\\", \\\"{x:1377,y:929,t:1527030651319};\\\", \\\"{x:1375,y:931,t:1527030651336};\\\", \\\"{x:1374,y:932,t:1527030651352};\\\", \\\"{x:1372,y:933,t:1527030651369};\\\", \\\"{x:1370,y:935,t:1527030651385};\\\", \\\"{x:1368,y:937,t:1527030651402};\\\", \\\"{x:1365,y:940,t:1527030651419};\\\", \\\"{x:1364,y:943,t:1527030651436};\\\", \\\"{x:1363,y:944,t:1527030651452};\\\", \\\"{x:1361,y:945,t:1527030651469};\\\", \\\"{x:1361,y:946,t:1527030651486};\\\", \\\"{x:1361,y:944,t:1527030651570};\\\", \\\"{x:1362,y:938,t:1527030651585};\\\", \\\"{x:1364,y:934,t:1527030651603};\\\", \\\"{x:1367,y:926,t:1527030651619};\\\", \\\"{x:1369,y:919,t:1527030651636};\\\", \\\"{x:1374,y:907,t:1527030651653};\\\", \\\"{x:1377,y:899,t:1527030651669};\\\", \\\"{x:1380,y:892,t:1527030651686};\\\", \\\"{x:1381,y:887,t:1527030651704};\\\", \\\"{x:1384,y:880,t:1527030651719};\\\", \\\"{x:1385,y:873,t:1527030651736};\\\", \\\"{x:1386,y:866,t:1527030651753};\\\", \\\"{x:1388,y:858,t:1527030651769};\\\", \\\"{x:1392,y:843,t:1527030651786};\\\", \\\"{x:1394,y:834,t:1527030651803};\\\", \\\"{x:1398,y:825,t:1527030651819};\\\", \\\"{x:1403,y:815,t:1527030651835};\\\", \\\"{x:1407,y:807,t:1527030651853};\\\", \\\"{x:1411,y:801,t:1527030651869};\\\", \\\"{x:1412,y:796,t:1527030651885};\\\", \\\"{x:1416,y:791,t:1527030651903};\\\", \\\"{x:1420,y:783,t:1527030651919};\\\", \\\"{x:1425,y:775,t:1527030651936};\\\", \\\"{x:1431,y:764,t:1527030651953};\\\", \\\"{x:1439,y:752,t:1527030651969};\\\", \\\"{x:1449,y:734,t:1527030651986};\\\", \\\"{x:1455,y:720,t:1527030652003};\\\", \\\"{x:1461,y:706,t:1527030652020};\\\", \\\"{x:1467,y:690,t:1527030652036};\\\", \\\"{x:1475,y:672,t:1527030652053};\\\", \\\"{x:1482,y:655,t:1527030652070};\\\", \\\"{x:1492,y:637,t:1527030652086};\\\", \\\"{x:1498,y:622,t:1527030652103};\\\", \\\"{x:1507,y:606,t:1527030652120};\\\", \\\"{x:1514,y:588,t:1527030652136};\\\", \\\"{x:1522,y:572,t:1527030652153};\\\", \\\"{x:1533,y:552,t:1527030652170};\\\", \\\"{x:1538,y:538,t:1527030652186};\\\", \\\"{x:1542,y:528,t:1527030652203};\\\", \\\"{x:1545,y:523,t:1527030652220};\\\", \\\"{x:1549,y:516,t:1527030652236};\\\", \\\"{x:1553,y:511,t:1527030652252};\\\", \\\"{x:1557,y:502,t:1527030652269};\\\", \\\"{x:1562,y:494,t:1527030652286};\\\", \\\"{x:1566,y:486,t:1527030652303};\\\", \\\"{x:1572,y:480,t:1527030652320};\\\", \\\"{x:1575,y:476,t:1527030652335};\\\", \\\"{x:1576,y:475,t:1527030652353};\\\", \\\"{x:1579,y:470,t:1527030652370};\\\", \\\"{x:1580,y:468,t:1527030652387};\\\", \\\"{x:1581,y:468,t:1527030652403};\\\", \\\"{x:1581,y:467,t:1527030652420};\\\", \\\"{x:1580,y:467,t:1527030652505};\\\", \\\"{x:1576,y:470,t:1527030652520};\\\", \\\"{x:1565,y:475,t:1527030652537};\\\", \\\"{x:1547,y:483,t:1527030652553};\\\", \\\"{x:1513,y:493,t:1527030652570};\\\", \\\"{x:1493,y:499,t:1527030652587};\\\", \\\"{x:1473,y:509,t:1527030652603};\\\", \\\"{x:1455,y:519,t:1527030652620};\\\", \\\"{x:1435,y:527,t:1527030652637};\\\", \\\"{x:1417,y:536,t:1527030652653};\\\", \\\"{x:1400,y:541,t:1527030652670};\\\", \\\"{x:1386,y:543,t:1527030652687};\\\", \\\"{x:1370,y:548,t:1527030652703};\\\", \\\"{x:1353,y:553,t:1527030652720};\\\", \\\"{x:1325,y:559,t:1527030652737};\\\", \\\"{x:1281,y:565,t:1527030652753};\\\", \\\"{x:1195,y:578,t:1527030652770};\\\", \\\"{x:1149,y:587,t:1527030652787};\\\", \\\"{x:1115,y:592,t:1527030652804};\\\", \\\"{x:1084,y:595,t:1527030652820};\\\", \\\"{x:1061,y:599,t:1527030652837};\\\", \\\"{x:1042,y:600,t:1527030652854};\\\", \\\"{x:1020,y:600,t:1527030652870};\\\", \\\"{x:998,y:600,t:1527030652887};\\\", \\\"{x:973,y:600,t:1527030652904};\\\", \\\"{x:949,y:600,t:1527030652920};\\\", \\\"{x:926,y:600,t:1527030652937};\\\", \\\"{x:903,y:600,t:1527030652953};\\\", \\\"{x:893,y:601,t:1527030652970};\\\", \\\"{x:879,y:603,t:1527030652987};\\\", \\\"{x:869,y:604,t:1527030653004};\\\", \\\"{x:854,y:606,t:1527030653020};\\\", \\\"{x:837,y:609,t:1527030653037};\\\", \\\"{x:823,y:610,t:1527030653053};\\\", \\\"{x:807,y:615,t:1527030653070};\\\", \\\"{x:790,y:618,t:1527030653086};\\\", \\\"{x:781,y:620,t:1527030653104};\\\", \\\"{x:775,y:622,t:1527030653120};\\\", \\\"{x:766,y:625,t:1527030653137};\\\", \\\"{x:749,y:632,t:1527030653154};\\\", \\\"{x:738,y:637,t:1527030653170};\\\", \\\"{x:724,y:644,t:1527030653187};\\\", \\\"{x:707,y:651,t:1527030653204};\\\", \\\"{x:692,y:656,t:1527030653219};\\\", \\\"{x:679,y:661,t:1527030653237};\\\", \\\"{x:668,y:666,t:1527030653254};\\\", \\\"{x:659,y:671,t:1527030653270};\\\", \\\"{x:649,y:674,t:1527030653287};\\\", \\\"{x:635,y:681,t:1527030653304};\\\", \\\"{x:619,y:686,t:1527030653320};\\\", \\\"{x:603,y:691,t:1527030653337};\\\", \\\"{x:591,y:695,t:1527030653353};\\\", \\\"{x:590,y:695,t:1527030653370};\\\", \\\"{x:588,y:695,t:1527030653418};\\\", \\\"{x:586,y:696,t:1527030653426};\\\", \\\"{x:581,y:696,t:1527030653437};\\\", \\\"{x:559,y:699,t:1527030653454};\\\", \\\"{x:533,y:705,t:1527030653471};\\\", \\\"{x:511,y:710,t:1527030653487};\\\", \\\"{x:490,y:715,t:1527030653504};\\\", \\\"{x:480,y:720,t:1527030653521};\\\", \\\"{x:475,y:725,t:1527030653537};\\\", \\\"{x:467,y:734,t:1527030653554};\\\", \\\"{x:465,y:738,t:1527030653571};\\\", \\\"{x:465,y:739,t:1527030653587};\\\", \\\"{x:465,y:740,t:1527030653713};\\\", \\\"{x:465,y:741,t:1527030653794};\\\", \\\"{x:466,y:741,t:1527030653804};\\\", \\\"{x:469,y:741,t:1527030653821};\\\", \\\"{x:473,y:740,t:1527030653837};\\\", \\\"{x:474,y:740,t:1527030653855};\\\", \\\"{x:474,y:739,t:1527030653906};\\\" ] }, { \\\"rt\\\": 14559, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 586830, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:479,y:724,t:1527030655866};\\\", \\\"{x:480,y:703,t:1527030655874};\\\", \\\"{x:480,y:673,t:1527030655889};\\\", \\\"{x:470,y:578,t:1527030655906};\\\", \\\"{x:454,y:522,t:1527030655923};\\\", \\\"{x:443,y:487,t:1527030655940};\\\", \\\"{x:438,y:469,t:1527030655956};\\\", \\\"{x:435,y:457,t:1527030655971};\\\", \\\"{x:434,y:451,t:1527030655990};\\\", \\\"{x:434,y:449,t:1527030656006};\\\", \\\"{x:434,y:448,t:1527030656023};\\\", \\\"{x:433,y:448,t:1527030656121};\\\", \\\"{x:435,y:448,t:1527030656282};\\\", \\\"{x:448,y:448,t:1527030656290};\\\", \\\"{x:476,y:448,t:1527030656306};\\\", \\\"{x:508,y:448,t:1527030656323};\\\", \\\"{x:537,y:448,t:1527030656339};\\\", \\\"{x:556,y:448,t:1527030656356};\\\", \\\"{x:562,y:448,t:1527030656373};\\\", \\\"{x:564,y:447,t:1527030656388};\\\", \\\"{x:565,y:446,t:1527030656449};\\\", \\\"{x:566,y:446,t:1527030656457};\\\", \\\"{x:569,y:446,t:1527030656473};\\\", \\\"{x:581,y:446,t:1527030656489};\\\", \\\"{x:590,y:446,t:1527030656506};\\\", \\\"{x:602,y:446,t:1527030656523};\\\", \\\"{x:612,y:446,t:1527030656540};\\\", \\\"{x:622,y:446,t:1527030656556};\\\", \\\"{x:630,y:446,t:1527030656573};\\\", \\\"{x:637,y:446,t:1527030656590};\\\", \\\"{x:640,y:445,t:1527030656606};\\\", \\\"{x:641,y:445,t:1527030656623};\\\", \\\"{x:643,y:445,t:1527030656640};\\\", \\\"{x:644,y:444,t:1527030656656};\\\", \\\"{x:646,y:444,t:1527030656673};\\\", \\\"{x:647,y:444,t:1527030656690};\\\", \\\"{x:648,y:443,t:1527030657242};\\\", \\\"{x:650,y:442,t:1527030657273};\\\", \\\"{x:652,y:442,t:1527030657291};\\\", \\\"{x:658,y:441,t:1527030657307};\\\", \\\"{x:672,y:438,t:1527030657323};\\\", \\\"{x:697,y:436,t:1527030657340};\\\", \\\"{x:730,y:436,t:1527030657357};\\\", \\\"{x:772,y:436,t:1527030657373};\\\", \\\"{x:810,y:436,t:1527030657390};\\\", \\\"{x:849,y:441,t:1527030657407};\\\", \\\"{x:874,y:445,t:1527030657424};\\\", \\\"{x:889,y:448,t:1527030657440};\\\", \\\"{x:899,y:448,t:1527030657458};\\\", \\\"{x:914,y:448,t:1527030657473};\\\", \\\"{x:931,y:448,t:1527030657490};\\\", \\\"{x:953,y:448,t:1527030657508};\\\", \\\"{x:977,y:450,t:1527030657524};\\\", \\\"{x:1003,y:453,t:1527030657541};\\\", \\\"{x:1021,y:456,t:1527030657557};\\\", \\\"{x:1038,y:459,t:1527030657575};\\\", \\\"{x:1051,y:461,t:1527030657590};\\\", \\\"{x:1058,y:461,t:1527030657607};\\\", \\\"{x:1071,y:461,t:1527030657624};\\\", \\\"{x:1096,y:461,t:1527030657640};\\\", \\\"{x:1133,y:464,t:1527030657657};\\\", \\\"{x:1192,y:464,t:1527030657674};\\\", \\\"{x:1216,y:464,t:1527030657691};\\\", \\\"{x:1242,y:464,t:1527030657707};\\\", \\\"{x:1257,y:464,t:1527030657724};\\\", \\\"{x:1268,y:465,t:1527030657740};\\\", \\\"{x:1280,y:466,t:1527030657757};\\\", \\\"{x:1290,y:466,t:1527030657774};\\\", \\\"{x:1303,y:466,t:1527030657790};\\\", \\\"{x:1318,y:466,t:1527030657807};\\\", \\\"{x:1331,y:466,t:1527030657824};\\\", \\\"{x:1344,y:469,t:1527030657841};\\\", \\\"{x:1355,y:470,t:1527030657858};\\\", \\\"{x:1367,y:472,t:1527030657873};\\\", \\\"{x:1369,y:479,t:1527030657946};\\\", \\\"{x:1371,y:484,t:1527030657957};\\\", \\\"{x:1376,y:493,t:1527030657974};\\\", \\\"{x:1381,y:504,t:1527030657991};\\\", \\\"{x:1387,y:517,t:1527030658007};\\\", \\\"{x:1391,y:530,t:1527030658024};\\\", \\\"{x:1392,y:540,t:1527030658041};\\\", \\\"{x:1392,y:549,t:1527030658057};\\\", \\\"{x:1392,y:557,t:1527030658074};\\\", \\\"{x:1392,y:562,t:1527030658091};\\\", \\\"{x:1389,y:571,t:1527030658108};\\\", \\\"{x:1386,y:579,t:1527030658125};\\\", \\\"{x:1381,y:589,t:1527030658141};\\\", \\\"{x:1375,y:600,t:1527030658157};\\\", \\\"{x:1369,y:609,t:1527030658174};\\\", \\\"{x:1366,y:615,t:1527030658191};\\\", \\\"{x:1362,y:621,t:1527030658207};\\\", \\\"{x:1356,y:630,t:1527030658225};\\\", \\\"{x:1349,y:638,t:1527030658242};\\\", \\\"{x:1340,y:650,t:1527030658257};\\\", \\\"{x:1330,y:664,t:1527030658274};\\\", \\\"{x:1328,y:668,t:1527030658292};\\\", \\\"{x:1326,y:671,t:1527030658308};\\\", \\\"{x:1326,y:673,t:1527030658324};\\\", \\\"{x:1326,y:676,t:1527030658433};\\\", \\\"{x:1327,y:679,t:1527030658441};\\\", \\\"{x:1328,y:682,t:1527030658457};\\\", \\\"{x:1330,y:685,t:1527030658474};\\\", \\\"{x:1331,y:688,t:1527030658491};\\\", \\\"{x:1331,y:690,t:1527030658509};\\\", \\\"{x:1332,y:693,t:1527030658524};\\\", \\\"{x:1332,y:695,t:1527030658545};\\\", \\\"{x:1332,y:696,t:1527030658561};\\\", \\\"{x:1332,y:698,t:1527030658578};\\\", \\\"{x:1333,y:699,t:1527030658594};\\\", \\\"{x:1333,y:700,t:1527030658625};\\\", \\\"{x:1334,y:700,t:1527030658657};\\\", \\\"{x:1335,y:701,t:1527030658674};\\\", \\\"{x:1335,y:702,t:1527030658692};\\\", \\\"{x:1335,y:704,t:1527030658708};\\\", \\\"{x:1335,y:705,t:1527030658724};\\\", \\\"{x:1336,y:705,t:1527030658825};\\\", \\\"{x:1337,y:705,t:1527030658842};\\\", \\\"{x:1339,y:705,t:1527030658858};\\\", \\\"{x:1340,y:705,t:1527030658881};\\\", \\\"{x:1342,y:704,t:1527030658898};\\\", \\\"{x:1343,y:704,t:1527030659073};\\\", \\\"{x:1344,y:703,t:1527030659081};\\\", \\\"{x:1345,y:702,t:1527030659091};\\\", \\\"{x:1346,y:701,t:1527030659109};\\\", \\\"{x:1349,y:696,t:1527030659125};\\\", \\\"{x:1354,y:688,t:1527030659143};\\\", \\\"{x:1358,y:678,t:1527030659158};\\\", \\\"{x:1364,y:663,t:1527030659175};\\\", \\\"{x:1370,y:645,t:1527030659193};\\\", \\\"{x:1378,y:625,t:1527030659209};\\\", \\\"{x:1388,y:607,t:1527030659226};\\\", \\\"{x:1395,y:599,t:1527030659242};\\\", \\\"{x:1400,y:593,t:1527030659258};\\\", \\\"{x:1403,y:590,t:1527030659275};\\\", \\\"{x:1405,y:588,t:1527030659292};\\\", \\\"{x:1407,y:584,t:1527030659308};\\\", \\\"{x:1408,y:582,t:1527030659326};\\\", \\\"{x:1408,y:581,t:1527030659342};\\\", \\\"{x:1410,y:579,t:1527030659358};\\\", \\\"{x:1411,y:578,t:1527030659375};\\\", \\\"{x:1412,y:577,t:1527030659392};\\\", \\\"{x:1412,y:576,t:1527030659408};\\\", \\\"{x:1411,y:576,t:1527030659562};\\\", \\\"{x:1410,y:576,t:1527030659575};\\\", \\\"{x:1401,y:583,t:1527030659592};\\\", \\\"{x:1396,y:593,t:1527030659610};\\\", \\\"{x:1389,y:611,t:1527030659625};\\\", \\\"{x:1385,y:624,t:1527030659642};\\\", \\\"{x:1381,y:636,t:1527030659659};\\\", \\\"{x:1377,y:645,t:1527030659675};\\\", \\\"{x:1375,y:653,t:1527030659693};\\\", \\\"{x:1372,y:658,t:1527030659710};\\\", \\\"{x:1371,y:661,t:1527030659725};\\\", \\\"{x:1371,y:666,t:1527030659742};\\\", \\\"{x:1366,y:672,t:1527030659759};\\\", \\\"{x:1362,y:679,t:1527030659775};\\\", \\\"{x:1359,y:684,t:1527030659792};\\\", \\\"{x:1357,y:689,t:1527030659810};\\\", \\\"{x:1355,y:693,t:1527030659826};\\\", \\\"{x:1351,y:700,t:1527030659843};\\\", \\\"{x:1346,y:710,t:1527030659860};\\\", \\\"{x:1337,y:723,t:1527030659875};\\\", \\\"{x:1328,y:738,t:1527030659893};\\\", \\\"{x:1323,y:752,t:1527030659909};\\\", \\\"{x:1318,y:764,t:1527030659925};\\\", \\\"{x:1315,y:770,t:1527030659942};\\\", \\\"{x:1312,y:777,t:1527030659959};\\\", \\\"{x:1308,y:783,t:1527030659976};\\\", \\\"{x:1305,y:787,t:1527030659992};\\\", \\\"{x:1302,y:794,t:1527030660009};\\\", \\\"{x:1296,y:804,t:1527030660025};\\\", \\\"{x:1292,y:811,t:1527030660042};\\\", \\\"{x:1286,y:818,t:1527030660059};\\\", \\\"{x:1276,y:827,t:1527030660077};\\\", \\\"{x:1263,y:837,t:1527030660092};\\\", \\\"{x:1248,y:846,t:1527030660109};\\\", \\\"{x:1238,y:852,t:1527030660126};\\\", \\\"{x:1236,y:854,t:1527030660142};\\\", \\\"{x:1236,y:855,t:1527030660159};\\\", \\\"{x:1236,y:856,t:1527030660177};\\\", \\\"{x:1236,y:857,t:1527030660194};\\\", \\\"{x:1236,y:858,t:1527030660209};\\\", \\\"{x:1236,y:862,t:1527030660225};\\\", \\\"{x:1236,y:865,t:1527030660242};\\\", \\\"{x:1236,y:868,t:1527030660260};\\\", \\\"{x:1236,y:870,t:1527030660276};\\\", \\\"{x:1237,y:871,t:1527030660293};\\\", \\\"{x:1238,y:873,t:1527030660310};\\\", \\\"{x:1238,y:875,t:1527030660326};\\\", \\\"{x:1240,y:878,t:1527030660343};\\\", \\\"{x:1242,y:880,t:1527030660359};\\\", \\\"{x:1243,y:881,t:1527030660376};\\\", \\\"{x:1243,y:885,t:1527030660392};\\\", \\\"{x:1243,y:891,t:1527030660409};\\\", \\\"{x:1243,y:896,t:1527030660426};\\\", \\\"{x:1243,y:903,t:1527030660443};\\\", \\\"{x:1243,y:910,t:1527030660459};\\\", \\\"{x:1243,y:913,t:1527030660476};\\\", \\\"{x:1243,y:914,t:1527030660493};\\\", \\\"{x:1243,y:915,t:1527030660510};\\\", \\\"{x:1243,y:917,t:1527030660526};\\\", \\\"{x:1243,y:918,t:1527030660585};\\\", \\\"{x:1244,y:918,t:1527030660602};\\\", \\\"{x:1244,y:917,t:1527030660610};\\\", \\\"{x:1247,y:914,t:1527030660626};\\\", \\\"{x:1249,y:910,t:1527030660644};\\\", \\\"{x:1252,y:904,t:1527030660659};\\\", \\\"{x:1254,y:900,t:1527030660676};\\\", \\\"{x:1256,y:897,t:1527030660694};\\\", \\\"{x:1256,y:896,t:1527030660710};\\\", \\\"{x:1256,y:893,t:1527030660727};\\\", \\\"{x:1257,y:892,t:1527030660744};\\\", \\\"{x:1261,y:887,t:1527030660759};\\\", \\\"{x:1267,y:879,t:1527030660777};\\\", \\\"{x:1277,y:865,t:1527030660794};\\\", \\\"{x:1289,y:850,t:1527030660810};\\\", \\\"{x:1302,y:837,t:1527030660826};\\\", \\\"{x:1314,y:822,t:1527030660843};\\\", \\\"{x:1323,y:810,t:1527030660859};\\\", \\\"{x:1333,y:796,t:1527030660877};\\\", \\\"{x:1340,y:786,t:1527030660893};\\\", \\\"{x:1346,y:774,t:1527030660909};\\\", \\\"{x:1354,y:762,t:1527030660926};\\\", \\\"{x:1358,y:754,t:1527030660943};\\\", \\\"{x:1360,y:750,t:1527030660961};\\\", \\\"{x:1362,y:746,t:1527030660976};\\\", \\\"{x:1366,y:741,t:1527030660994};\\\", \\\"{x:1367,y:739,t:1527030661009};\\\", \\\"{x:1369,y:735,t:1527030661027};\\\", \\\"{x:1370,y:735,t:1527030661043};\\\", \\\"{x:1370,y:732,t:1527030661060};\\\", \\\"{x:1372,y:730,t:1527030661077};\\\", \\\"{x:1372,y:729,t:1527030661093};\\\", \\\"{x:1373,y:727,t:1527030661111};\\\", \\\"{x:1374,y:722,t:1527030661126};\\\", \\\"{x:1374,y:717,t:1527030661144};\\\", \\\"{x:1374,y:710,t:1527030661160};\\\", \\\"{x:1374,y:701,t:1527030661176};\\\", \\\"{x:1374,y:694,t:1527030661193};\\\", \\\"{x:1374,y:691,t:1527030661210};\\\", \\\"{x:1374,y:689,t:1527030661226};\\\", \\\"{x:1374,y:688,t:1527030661244};\\\", \\\"{x:1374,y:687,t:1527030661260};\\\", \\\"{x:1374,y:686,t:1527030661276};\\\", \\\"{x:1374,y:685,t:1527030661354};\\\", \\\"{x:1373,y:685,t:1527030661361};\\\", \\\"{x:1369,y:685,t:1527030661377};\\\", \\\"{x:1366,y:685,t:1527030661393};\\\", \\\"{x:1365,y:685,t:1527030661410};\\\", \\\"{x:1365,y:683,t:1527030661530};\\\", \\\"{x:1365,y:681,t:1527030661544};\\\", \\\"{x:1366,y:675,t:1527030661560};\\\", \\\"{x:1371,y:659,t:1527030661578};\\\", \\\"{x:1373,y:645,t:1527030661594};\\\", \\\"{x:1376,y:633,t:1527030661611};\\\", \\\"{x:1380,y:620,t:1527030661627};\\\", \\\"{x:1388,y:601,t:1527030661643};\\\", \\\"{x:1396,y:585,t:1527030661661};\\\", \\\"{x:1402,y:571,t:1527030661678};\\\", \\\"{x:1406,y:560,t:1527030661693};\\\", \\\"{x:1407,y:553,t:1527030661710};\\\", \\\"{x:1408,y:546,t:1527030661727};\\\", \\\"{x:1408,y:545,t:1527030661746};\\\", \\\"{x:1408,y:546,t:1527030662017};\\\", \\\"{x:1408,y:554,t:1527030662028};\\\", \\\"{x:1395,y:573,t:1527030662044};\\\", \\\"{x:1382,y:596,t:1527030662061};\\\", \\\"{x:1367,y:621,t:1527030662078};\\\", \\\"{x:1352,y:642,t:1527030662094};\\\", \\\"{x:1341,y:661,t:1527030662110};\\\", \\\"{x:1330,y:677,t:1527030662128};\\\", \\\"{x:1324,y:688,t:1527030662144};\\\", \\\"{x:1318,y:695,t:1527030662160};\\\", \\\"{x:1311,y:706,t:1527030662177};\\\", \\\"{x:1305,y:712,t:1527030662194};\\\", \\\"{x:1302,y:716,t:1527030662210};\\\", \\\"{x:1299,y:719,t:1527030662228};\\\", \\\"{x:1298,y:720,t:1527030662244};\\\", \\\"{x:1297,y:719,t:1527030662482};\\\", \\\"{x:1296,y:717,t:1527030662495};\\\", \\\"{x:1293,y:712,t:1527030662511};\\\", \\\"{x:1289,y:708,t:1527030662527};\\\", \\\"{x:1283,y:704,t:1527030662545};\\\", \\\"{x:1263,y:698,t:1527030662561};\\\", \\\"{x:1236,y:696,t:1527030662578};\\\", \\\"{x:1186,y:694,t:1527030662594};\\\", \\\"{x:1101,y:686,t:1527030662612};\\\", \\\"{x:1010,y:675,t:1527030662629};\\\", \\\"{x:918,y:662,t:1527030662645};\\\", \\\"{x:856,y:650,t:1527030662661};\\\", \\\"{x:815,y:642,t:1527030662677};\\\", \\\"{x:792,y:636,t:1527030662695};\\\", \\\"{x:774,y:627,t:1527030662712};\\\", \\\"{x:762,y:622,t:1527030662728};\\\", \\\"{x:748,y:617,t:1527030662744};\\\", \\\"{x:726,y:608,t:1527030662761};\\\", \\\"{x:711,y:601,t:1527030662779};\\\", \\\"{x:697,y:597,t:1527030662795};\\\", \\\"{x:681,y:594,t:1527030662812};\\\", \\\"{x:672,y:589,t:1527030662829};\\\", \\\"{x:666,y:586,t:1527030662845};\\\", \\\"{x:662,y:583,t:1527030662861};\\\", \\\"{x:660,y:581,t:1527030662878};\\\", \\\"{x:656,y:579,t:1527030662895};\\\", \\\"{x:648,y:578,t:1527030662911};\\\", \\\"{x:639,y:576,t:1527030662928};\\\", \\\"{x:628,y:574,t:1527030662945};\\\", \\\"{x:626,y:574,t:1527030662962};\\\", \\\"{x:625,y:574,t:1527030662978};\\\", \\\"{x:625,y:572,t:1527030663185};\\\", \\\"{x:624,y:571,t:1527030663196};\\\", \\\"{x:623,y:566,t:1527030663211};\\\", \\\"{x:622,y:564,t:1527030663228};\\\", \\\"{x:622,y:561,t:1527030663246};\\\", \\\"{x:621,y:558,t:1527030663262};\\\", \\\"{x:621,y:556,t:1527030663279};\\\", \\\"{x:621,y:554,t:1527030663296};\\\", \\\"{x:621,y:553,t:1527030663312};\\\", \\\"{x:621,y:551,t:1527030663328};\\\", \\\"{x:623,y:547,t:1527030663346};\\\", \\\"{x:626,y:544,t:1527030663362};\\\", \\\"{x:628,y:542,t:1527030663378};\\\", \\\"{x:632,y:538,t:1527030663396};\\\", \\\"{x:636,y:536,t:1527030663412};\\\", \\\"{x:638,y:533,t:1527030663429};\\\", \\\"{x:642,y:530,t:1527030663445};\\\", \\\"{x:644,y:529,t:1527030663463};\\\", \\\"{x:646,y:527,t:1527030663479};\\\", \\\"{x:647,y:526,t:1527030663496};\\\", \\\"{x:649,y:525,t:1527030663512};\\\", \\\"{x:650,y:524,t:1527030663529};\\\", \\\"{x:652,y:523,t:1527030663545};\\\", \\\"{x:655,y:521,t:1527030663562};\\\", \\\"{x:656,y:520,t:1527030663578};\\\", \\\"{x:658,y:520,t:1527030663595};\\\", \\\"{x:659,y:519,t:1527030663612};\\\", \\\"{x:662,y:518,t:1527030663629};\\\", \\\"{x:662,y:517,t:1527030663646};\\\", \\\"{x:663,y:517,t:1527030663666};\\\", \\\"{x:664,y:516,t:1527030663679};\\\", \\\"{x:665,y:515,t:1527030663696};\\\", \\\"{x:666,y:513,t:1527030663712};\\\", \\\"{x:668,y:512,t:1527030663729};\\\", \\\"{x:669,y:510,t:1527030663745};\\\", \\\"{x:670,y:508,t:1527030663762};\\\", \\\"{x:670,y:507,t:1527030663779};\\\", \\\"{x:671,y:507,t:1527030663817};\\\", \\\"{x:671,y:506,t:1527030663829};\\\", \\\"{x:672,y:506,t:1527030663845};\\\", \\\"{x:672,y:505,t:1527030663863};\\\", \\\"{x:674,y:503,t:1527030663878};\\\", \\\"{x:674,y:502,t:1527030663896};\\\", \\\"{x:675,y:501,t:1527030663940};\\\", \\\"{x:676,y:501,t:1527030663953};\\\", \\\"{x:677,y:501,t:1527030664034};\\\", \\\"{x:678,y:501,t:1527030664049};\\\", \\\"{x:678,y:502,t:1527030665481};\\\", \\\"{x:677,y:502,t:1527030665514};\\\", \\\"{x:676,y:503,t:1527030665529};\\\", \\\"{x:674,y:503,t:1527030665546};\\\", \\\"{x:671,y:504,t:1527030665563};\\\", \\\"{x:668,y:505,t:1527030665579};\\\", \\\"{x:663,y:506,t:1527030665596};\\\", \\\"{x:657,y:509,t:1527030665612};\\\", \\\"{x:650,y:511,t:1527030665630};\\\", \\\"{x:642,y:516,t:1527030665646};\\\", \\\"{x:634,y:518,t:1527030665663};\\\", \\\"{x:629,y:520,t:1527030665679};\\\", \\\"{x:624,y:521,t:1527030665698};\\\", \\\"{x:622,y:523,t:1527030665714};\\\", \\\"{x:620,y:523,t:1527030665731};\\\", \\\"{x:618,y:525,t:1527030665748};\\\", \\\"{x:616,y:528,t:1527030665763};\\\", \\\"{x:615,y:529,t:1527030665781};\\\", \\\"{x:612,y:531,t:1527030665798};\\\", \\\"{x:608,y:533,t:1527030665813};\\\", \\\"{x:605,y:536,t:1527030665830};\\\", \\\"{x:601,y:538,t:1527030665848};\\\", \\\"{x:594,y:540,t:1527030665864};\\\", \\\"{x:585,y:544,t:1527030665880};\\\", \\\"{x:570,y:549,t:1527030665898};\\\", \\\"{x:565,y:549,t:1527030665914};\\\", \\\"{x:558,y:552,t:1527030665930};\\\", \\\"{x:551,y:553,t:1527030665947};\\\", \\\"{x:541,y:554,t:1527030665964};\\\", \\\"{x:531,y:555,t:1527030665982};\\\", \\\"{x:519,y:559,t:1527030665998};\\\", \\\"{x:508,y:559,t:1527030666014};\\\", \\\"{x:493,y:562,t:1527030666030};\\\", \\\"{x:482,y:563,t:1527030666048};\\\", \\\"{x:475,y:563,t:1527030666065};\\\", \\\"{x:470,y:563,t:1527030666081};\\\", \\\"{x:468,y:563,t:1527030666097};\\\", \\\"{x:471,y:562,t:1527030666186};\\\", \\\"{x:475,y:560,t:1527030666197};\\\", \\\"{x:492,y:557,t:1527030666215};\\\", \\\"{x:514,y:556,t:1527030666231};\\\", \\\"{x:544,y:556,t:1527030666248};\\\", \\\"{x:572,y:555,t:1527030666265};\\\", \\\"{x:604,y:555,t:1527030666281};\\\", \\\"{x:647,y:555,t:1527030666297};\\\", \\\"{x:668,y:555,t:1527030666314};\\\", \\\"{x:675,y:553,t:1527030666330};\\\", \\\"{x:677,y:553,t:1527030666348};\\\", \\\"{x:680,y:553,t:1527030666410};\\\", \\\"{x:683,y:553,t:1527030666418};\\\", \\\"{x:689,y:553,t:1527030666430};\\\", \\\"{x:702,y:553,t:1527030666448};\\\", \\\"{x:712,y:553,t:1527030666464};\\\", \\\"{x:721,y:553,t:1527030666481};\\\", \\\"{x:722,y:553,t:1527030666498};\\\", \\\"{x:723,y:553,t:1527030666515};\\\", \\\"{x:725,y:552,t:1527030666532};\\\", \\\"{x:731,y:552,t:1527030666548};\\\", \\\"{x:745,y:552,t:1527030666564};\\\", \\\"{x:765,y:552,t:1527030666581};\\\", \\\"{x:782,y:550,t:1527030666598};\\\", \\\"{x:795,y:550,t:1527030666615};\\\", \\\"{x:799,y:550,t:1527030666631};\\\", \\\"{x:800,y:550,t:1527030666681};\\\", \\\"{x:803,y:549,t:1527030666698};\\\", \\\"{x:807,y:549,t:1527030666714};\\\", \\\"{x:810,y:548,t:1527030666732};\\\", \\\"{x:814,y:547,t:1527030666937};\\\", \\\"{x:816,y:545,t:1527030666947};\\\", \\\"{x:822,y:543,t:1527030666964};\\\", \\\"{x:828,y:543,t:1527030666982};\\\", \\\"{x:830,y:541,t:1527030666999};\\\", \\\"{x:831,y:541,t:1527030667014};\\\", \\\"{x:832,y:541,t:1527030667057};\\\", \\\"{x:833,y:541,t:1527030667065};\\\", \\\"{x:835,y:541,t:1527030667081};\\\", \\\"{x:836,y:541,t:1527030667098};\\\", \\\"{x:838,y:541,t:1527030667201};\\\", \\\"{x:838,y:541,t:1527030667285};\\\", \\\"{x:839,y:541,t:1527030667450};\\\", \\\"{x:852,y:541,t:1527030667465};\\\", \\\"{x:877,y:548,t:1527030667482};\\\", \\\"{x:948,y:573,t:1527030667499};\\\", \\\"{x:1047,y:597,t:1527030667516};\\\", \\\"{x:1153,y:629,t:1527030667531};\\\", \\\"{x:1263,y:660,t:1527030667549};\\\", \\\"{x:1362,y:686,t:1527030667566};\\\", \\\"{x:1434,y:694,t:1527030667583};\\\", \\\"{x:1500,y:702,t:1527030667598};\\\", \\\"{x:1551,y:702,t:1527030667616};\\\", \\\"{x:1579,y:701,t:1527030667633};\\\", \\\"{x:1592,y:695,t:1527030667649};\\\", \\\"{x:1599,y:689,t:1527030667665};\\\", \\\"{x:1600,y:688,t:1527030667682};\\\", \\\"{x:1601,y:686,t:1527030667699};\\\", \\\"{x:1602,y:681,t:1527030667715};\\\", \\\"{x:1603,y:675,t:1527030667733};\\\", \\\"{x:1603,y:670,t:1527030667749};\\\", \\\"{x:1603,y:663,t:1527030667766};\\\", \\\"{x:1600,y:658,t:1527030667782};\\\", \\\"{x:1588,y:649,t:1527030667799};\\\", \\\"{x:1568,y:640,t:1527030667816};\\\", \\\"{x:1545,y:630,t:1527030667833};\\\", \\\"{x:1522,y:619,t:1527030667849};\\\", \\\"{x:1501,y:608,t:1527030667865};\\\", \\\"{x:1495,y:603,t:1527030667882};\\\", \\\"{x:1492,y:599,t:1527030667900};\\\", \\\"{x:1489,y:594,t:1527030667916};\\\", \\\"{x:1483,y:590,t:1527030667932};\\\", \\\"{x:1479,y:587,t:1527030667950};\\\", \\\"{x:1474,y:584,t:1527030667965};\\\", \\\"{x:1470,y:579,t:1527030667983};\\\", \\\"{x:1467,y:576,t:1527030668000};\\\", \\\"{x:1465,y:572,t:1527030668015};\\\", \\\"{x:1463,y:569,t:1527030668032};\\\", \\\"{x:1462,y:566,t:1527030668049};\\\", \\\"{x:1460,y:564,t:1527030668066};\\\", \\\"{x:1456,y:561,t:1527030668082};\\\", \\\"{x:1446,y:557,t:1527030668099};\\\", \\\"{x:1437,y:553,t:1527030668116};\\\", \\\"{x:1432,y:552,t:1527030668133};\\\", \\\"{x:1431,y:552,t:1527030668150};\\\", \\\"{x:1430,y:552,t:1527030668217};\\\", \\\"{x:1429,y:552,t:1527030668233};\\\", \\\"{x:1426,y:555,t:1527030668250};\\\", \\\"{x:1425,y:562,t:1527030668266};\\\", \\\"{x:1425,y:569,t:1527030668283};\\\", \\\"{x:1425,y:576,t:1527030668300};\\\", \\\"{x:1425,y:582,t:1527030668316};\\\", \\\"{x:1425,y:588,t:1527030668333};\\\", \\\"{x:1422,y:597,t:1527030668350};\\\", \\\"{x:1416,y:609,t:1527030668367};\\\", \\\"{x:1406,y:621,t:1527030668383};\\\", \\\"{x:1396,y:635,t:1527030668400};\\\", \\\"{x:1380,y:651,t:1527030668416};\\\", \\\"{x:1358,y:668,t:1527030668433};\\\", \\\"{x:1330,y:691,t:1527030668450};\\\", \\\"{x:1309,y:708,t:1527030668467};\\\", \\\"{x:1291,y:725,t:1527030668483};\\\", \\\"{x:1281,y:739,t:1527030668500};\\\", \\\"{x:1270,y:756,t:1527030668517};\\\", \\\"{x:1259,y:774,t:1527030668532};\\\", \\\"{x:1250,y:791,t:1527030668550};\\\", \\\"{x:1245,y:804,t:1527030668567};\\\", \\\"{x:1239,y:816,t:1527030668583};\\\", \\\"{x:1238,y:823,t:1527030668599};\\\", \\\"{x:1237,y:828,t:1527030668617};\\\", \\\"{x:1232,y:839,t:1527030668633};\\\", \\\"{x:1227,y:851,t:1527030668650};\\\", \\\"{x:1223,y:861,t:1527030668667};\\\", \\\"{x:1220,y:868,t:1527030668684};\\\", \\\"{x:1218,y:873,t:1527030668700};\\\", \\\"{x:1217,y:877,t:1527030668716};\\\", \\\"{x:1214,y:881,t:1527030668734};\\\", \\\"{x:1208,y:886,t:1527030668749};\\\", \\\"{x:1200,y:891,t:1527030668766};\\\", \\\"{x:1186,y:897,t:1527030668783};\\\", \\\"{x:1163,y:898,t:1527030668799};\\\", \\\"{x:1111,y:898,t:1527030668817};\\\", \\\"{x:991,y:895,t:1527030668834};\\\", \\\"{x:900,y:886,t:1527030668849};\\\", \\\"{x:817,y:875,t:1527030668867};\\\", \\\"{x:761,y:867,t:1527030668884};\\\", \\\"{x:722,y:857,t:1527030668900};\\\", \\\"{x:698,y:850,t:1527030668917};\\\", \\\"{x:683,y:845,t:1527030668934};\\\", \\\"{x:671,y:839,t:1527030668950};\\\", \\\"{x:663,y:834,t:1527030668967};\\\", \\\"{x:659,y:829,t:1527030668984};\\\", \\\"{x:653,y:824,t:1527030669001};\\\", \\\"{x:643,y:818,t:1527030669017};\\\", \\\"{x:624,y:810,t:1527030669034};\\\", \\\"{x:613,y:802,t:1527030669051};\\\", \\\"{x:608,y:797,t:1527030669067};\\\", \\\"{x:605,y:790,t:1527030669084};\\\", \\\"{x:601,y:783,t:1527030669101};\\\", \\\"{x:595,y:776,t:1527030669116};\\\", \\\"{x:589,y:771,t:1527030669134};\\\", \\\"{x:577,y:766,t:1527030669151};\\\", \\\"{x:563,y:762,t:1527030669166};\\\", \\\"{x:554,y:759,t:1527030669183};\\\", \\\"{x:547,y:756,t:1527030669201};\\\", \\\"{x:544,y:756,t:1527030669216};\\\", \\\"{x:542,y:753,t:1527030669458};\\\", \\\"{x:540,y:750,t:1527030669473};\\\", \\\"{x:539,y:750,t:1527030669484};\\\", \\\"{x:538,y:748,t:1527030669500};\\\", \\\"{x:537,y:747,t:1527030669517};\\\", \\\"{x:535,y:745,t:1527030669537};\\\", \\\"{x:533,y:744,t:1527030669561};\\\", \\\"{x:531,y:742,t:1527030669578};\\\", \\\"{x:530,y:742,t:1527030669585};\\\", \\\"{x:528,y:740,t:1527030669601};\\\", \\\"{x:528,y:739,t:1527030669617};\\\", \\\"{x:526,y:738,t:1527030669633};\\\", \\\"{x:525,y:738,t:1527030669651};\\\", \\\"{x:524,y:737,t:1527030669668};\\\", \\\"{x:526,y:736,t:1527030670935};\\\", \\\"{x:530,y:736,t:1527030670951};\\\", \\\"{x:532,y:736,t:1527030670967};\\\", \\\"{x:533,y:735,t:1527030670985};\\\" ] }, { \\\"rt\\\": 26571, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 614652, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -Z -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:546,y:734,t:1527030671117};\\\", \\\"{x:547,y:734,t:1527030671177};\\\", \\\"{x:547,y:733,t:1527030671425};\\\", \\\"{x:547,y:731,t:1527030671434};\\\", \\\"{x:547,y:720,t:1527030671452};\\\", \\\"{x:547,y:697,t:1527030671469};\\\", \\\"{x:538,y:663,t:1527030671485};\\\", \\\"{x:526,y:635,t:1527030671501};\\\", \\\"{x:511,y:607,t:1527030671519};\\\", \\\"{x:495,y:578,t:1527030671536};\\\", \\\"{x:487,y:558,t:1527030671552};\\\", \\\"{x:481,y:545,t:1527030671569};\\\", \\\"{x:476,y:533,t:1527030671585};\\\", \\\"{x:462,y:517,t:1527030671602};\\\", \\\"{x:456,y:512,t:1527030671619};\\\", \\\"{x:449,y:505,t:1527030671636};\\\", \\\"{x:440,y:499,t:1527030671652};\\\", \\\"{x:431,y:493,t:1527030671669};\\\", \\\"{x:427,y:489,t:1527030671686};\\\", \\\"{x:385,y:467,t:1527030671803};\\\", \\\"{x:384,y:466,t:1527030671818};\\\", \\\"{x:386,y:465,t:1527030671962};\\\", \\\"{x:397,y:465,t:1527030671969};\\\", \\\"{x:431,y:465,t:1527030671985};\\\", \\\"{x:486,y:465,t:1527030672003};\\\", \\\"{x:537,y:465,t:1527030672018};\\\", \\\"{x:579,y:465,t:1527030672036};\\\", \\\"{x:605,y:464,t:1527030672052};\\\", \\\"{x:623,y:460,t:1527030672069};\\\", \\\"{x:637,y:458,t:1527030672086};\\\", \\\"{x:651,y:456,t:1527030672103};\\\", \\\"{x:672,y:453,t:1527030672120};\\\", \\\"{x:691,y:449,t:1527030672136};\\\", \\\"{x:708,y:446,t:1527030672153};\\\", \\\"{x:734,y:438,t:1527030672169};\\\", \\\"{x:740,y:437,t:1527030672186};\\\", \\\"{x:743,y:436,t:1527030672203};\\\", \\\"{x:743,y:435,t:1527030672225};\\\", \\\"{x:744,y:435,t:1527030672236};\\\", \\\"{x:745,y:435,t:1527030672257};\\\", \\\"{x:745,y:434,t:1527030672273};\\\", \\\"{x:747,y:434,t:1527030672297};\\\", \\\"{x:742,y:432,t:1527030673145};\\\", \\\"{x:737,y:433,t:1527030673154};\\\", \\\"{x:736,y:433,t:1527030674378};\\\", \\\"{x:733,y:434,t:1527030675417};\\\", \\\"{x:727,y:434,t:1527030675425};\\\", \\\"{x:716,y:437,t:1527030675440};\\\", \\\"{x:693,y:437,t:1527030675457};\\\", \\\"{x:665,y:437,t:1527030675474};\\\", \\\"{x:656,y:437,t:1527030675491};\\\", \\\"{x:649,y:437,t:1527030675507};\\\", \\\"{x:643,y:437,t:1527030675524};\\\", \\\"{x:637,y:437,t:1527030675541};\\\", \\\"{x:630,y:437,t:1527030675556};\\\", \\\"{x:622,y:437,t:1527030675574};\\\", \\\"{x:612,y:437,t:1527030675591};\\\", \\\"{x:597,y:437,t:1527030675607};\\\", \\\"{x:581,y:436,t:1527030675624};\\\", \\\"{x:566,y:435,t:1527030675641};\\\", \\\"{x:554,y:435,t:1527030675657};\\\", \\\"{x:540,y:435,t:1527030675674};\\\", \\\"{x:531,y:435,t:1527030675691};\\\", \\\"{x:527,y:435,t:1527030675707};\\\", \\\"{x:516,y:435,t:1527030675724};\\\", \\\"{x:505,y:435,t:1527030675741};\\\", \\\"{x:495,y:435,t:1527030675758};\\\", \\\"{x:484,y:435,t:1527030675774};\\\", \\\"{x:480,y:435,t:1527030675791};\\\", \\\"{x:479,y:435,t:1527030675818};\\\", \\\"{x:477,y:435,t:1527030675833};\\\", \\\"{x:475,y:435,t:1527030675841};\\\", \\\"{x:472,y:435,t:1527030675857};\\\", \\\"{x:466,y:435,t:1527030675874};\\\", \\\"{x:460,y:435,t:1527030675891};\\\", \\\"{x:453,y:435,t:1527030675907};\\\", \\\"{x:452,y:435,t:1527030675924};\\\", \\\"{x:451,y:435,t:1527030675941};\\\", \\\"{x:459,y:437,t:1527030676041};\\\", \\\"{x:481,y:439,t:1527030676058};\\\", \\\"{x:498,y:440,t:1527030676075};\\\", \\\"{x:518,y:442,t:1527030676091};\\\", \\\"{x:535,y:442,t:1527030676108};\\\", \\\"{x:543,y:442,t:1527030676125};\\\", \\\"{x:545,y:442,t:1527030676141};\\\", \\\"{x:546,y:442,t:1527030676162};\\\", \\\"{x:549,y:442,t:1527030676177};\\\", \\\"{x:552,y:442,t:1527030676191};\\\", \\\"{x:561,y:442,t:1527030676208};\\\", \\\"{x:574,y:442,t:1527030676225};\\\", \\\"{x:584,y:442,t:1527030676241};\\\", \\\"{x:602,y:442,t:1527030676258};\\\", \\\"{x:615,y:442,t:1527030676275};\\\", \\\"{x:620,y:442,t:1527030676292};\\\", \\\"{x:625,y:442,t:1527030676308};\\\", \\\"{x:633,y:442,t:1527030676324};\\\", \\\"{x:637,y:442,t:1527030676342};\\\", \\\"{x:640,y:442,t:1527030676358};\\\", \\\"{x:645,y:442,t:1527030676375};\\\", \\\"{x:651,y:443,t:1527030676392};\\\", \\\"{x:656,y:444,t:1527030676407};\\\", \\\"{x:666,y:444,t:1527030676425};\\\", \\\"{x:676,y:447,t:1527030676441};\\\", \\\"{x:681,y:447,t:1527030676458};\\\", \\\"{x:687,y:447,t:1527030676475};\\\", \\\"{x:692,y:447,t:1527030676492};\\\", \\\"{x:699,y:447,t:1527030677081};\\\", \\\"{x:717,y:447,t:1527030677093};\\\", \\\"{x:749,y:447,t:1527030677109};\\\", \\\"{x:786,y:447,t:1527030677126};\\\", \\\"{x:815,y:447,t:1527030677143};\\\", \\\"{x:831,y:447,t:1527030677159};\\\", \\\"{x:840,y:447,t:1527030677176};\\\", \\\"{x:849,y:447,t:1527030677193};\\\", \\\"{x:862,y:447,t:1527030677209};\\\", \\\"{x:883,y:447,t:1527030677226};\\\", \\\"{x:913,y:447,t:1527030677242};\\\", \\\"{x:947,y:451,t:1527030677259};\\\", \\\"{x:979,y:456,t:1527030677276};\\\", \\\"{x:1010,y:461,t:1527030677293};\\\", \\\"{x:1036,y:464,t:1527030677310};\\\", \\\"{x:1054,y:468,t:1527030677326};\\\", \\\"{x:1076,y:471,t:1527030677343};\\\", \\\"{x:1090,y:472,t:1527030677360};\\\", \\\"{x:1106,y:475,t:1527030677376};\\\", \\\"{x:1137,y:481,t:1527030677393};\\\", \\\"{x:1161,y:484,t:1527030677410};\\\", \\\"{x:1187,y:492,t:1527030677425};\\\", \\\"{x:1211,y:499,t:1527030677443};\\\", \\\"{x:1225,y:503,t:1527030677460};\\\", \\\"{x:1236,y:507,t:1527030677476};\\\", \\\"{x:1241,y:510,t:1527030677493};\\\", \\\"{x:1245,y:513,t:1527030677510};\\\", \\\"{x:1249,y:518,t:1527030677527};\\\", \\\"{x:1258,y:526,t:1527030677542};\\\", \\\"{x:1263,y:534,t:1527030677560};\\\", \\\"{x:1274,y:553,t:1527030677577};\\\", \\\"{x:1283,y:566,t:1527030677593};\\\", \\\"{x:1292,y:584,t:1527030677610};\\\", \\\"{x:1297,y:592,t:1527030677627};\\\", \\\"{x:1304,y:604,t:1527030677643};\\\", \\\"{x:1309,y:610,t:1527030677660};\\\", \\\"{x:1316,y:618,t:1527030677677};\\\", \\\"{x:1321,y:627,t:1527030677694};\\\", \\\"{x:1332,y:639,t:1527030677710};\\\", \\\"{x:1346,y:652,t:1527030677727};\\\", \\\"{x:1362,y:662,t:1527030677743};\\\", \\\"{x:1381,y:671,t:1527030677760};\\\", \\\"{x:1403,y:679,t:1527030677777};\\\", \\\"{x:1413,y:683,t:1527030677794};\\\", \\\"{x:1421,y:686,t:1527030677810};\\\", \\\"{x:1429,y:687,t:1527030677827};\\\", \\\"{x:1433,y:688,t:1527030677844};\\\", \\\"{x:1442,y:692,t:1527030677860};\\\", \\\"{x:1450,y:695,t:1527030677877};\\\", \\\"{x:1460,y:697,t:1527030677894};\\\", \\\"{x:1469,y:699,t:1527030677910};\\\", \\\"{x:1478,y:701,t:1527030677927};\\\", \\\"{x:1486,y:705,t:1527030677944};\\\", \\\"{x:1493,y:706,t:1527030677960};\\\", \\\"{x:1504,y:709,t:1527030677977};\\\", \\\"{x:1523,y:715,t:1527030677993};\\\", \\\"{x:1532,y:719,t:1527030678010};\\\", \\\"{x:1542,y:721,t:1527030678027};\\\", \\\"{x:1551,y:722,t:1527030678045};\\\", \\\"{x:1559,y:724,t:1527030678060};\\\", \\\"{x:1564,y:725,t:1527030678077};\\\", \\\"{x:1571,y:727,t:1527030678095};\\\", \\\"{x:1580,y:728,t:1527030678111};\\\", \\\"{x:1589,y:729,t:1527030678127};\\\", \\\"{x:1599,y:732,t:1527030678144};\\\", \\\"{x:1607,y:734,t:1527030678161};\\\", \\\"{x:1618,y:736,t:1527030678177};\\\", \\\"{x:1621,y:736,t:1527030678194};\\\", \\\"{x:1625,y:737,t:1527030678211};\\\", \\\"{x:1628,y:738,t:1527030678227};\\\", \\\"{x:1632,y:738,t:1527030678244};\\\", \\\"{x:1635,y:740,t:1527030678261};\\\", \\\"{x:1637,y:741,t:1527030678277};\\\", \\\"{x:1640,y:741,t:1527030678294};\\\", \\\"{x:1641,y:741,t:1527030678311};\\\", \\\"{x:1641,y:740,t:1527030678473};\\\", \\\"{x:1641,y:739,t:1527030678481};\\\", \\\"{x:1640,y:738,t:1527030678494};\\\", \\\"{x:1638,y:734,t:1527030678511};\\\", \\\"{x:1635,y:729,t:1527030678528};\\\", \\\"{x:1627,y:720,t:1527030678545};\\\", \\\"{x:1622,y:715,t:1527030678561};\\\", \\\"{x:1621,y:713,t:1527030678578};\\\", \\\"{x:1620,y:712,t:1527030678595};\\\", \\\"{x:1620,y:711,t:1527030678611};\\\", \\\"{x:1619,y:710,t:1527030678628};\\\", \\\"{x:1617,y:706,t:1527030678646};\\\", \\\"{x:1615,y:704,t:1527030678662};\\\", \\\"{x:1613,y:702,t:1527030678678};\\\", \\\"{x:1612,y:702,t:1527030684135};\\\", \\\"{x:1611,y:702,t:1527030684149};\\\", \\\"{x:1608,y:704,t:1527030684166};\\\", \\\"{x:1602,y:712,t:1527030684182};\\\", \\\"{x:1597,y:718,t:1527030684200};\\\", \\\"{x:1592,y:724,t:1527030684216};\\\", \\\"{x:1587,y:732,t:1527030684233};\\\", \\\"{x:1583,y:740,t:1527030684249};\\\", \\\"{x:1578,y:751,t:1527030684267};\\\", \\\"{x:1572,y:760,t:1527030684283};\\\", \\\"{x:1565,y:771,t:1527030684300};\\\", \\\"{x:1561,y:777,t:1527030684317};\\\", \\\"{x:1557,y:781,t:1527030684333};\\\", \\\"{x:1555,y:785,t:1527030684349};\\\", \\\"{x:1549,y:795,t:1527030684366};\\\", \\\"{x:1541,y:805,t:1527030684383};\\\", \\\"{x:1531,y:819,t:1527030684400};\\\", \\\"{x:1519,y:834,t:1527030684416};\\\", \\\"{x:1505,y:851,t:1527030684433};\\\", \\\"{x:1495,y:862,t:1527030684450};\\\", \\\"{x:1489,y:873,t:1527030684467};\\\", \\\"{x:1486,y:881,t:1527030684484};\\\", \\\"{x:1483,y:887,t:1527030684500};\\\", \\\"{x:1481,y:891,t:1527030684517};\\\", \\\"{x:1480,y:897,t:1527030684533};\\\", \\\"{x:1478,y:902,t:1527030684550};\\\", \\\"{x:1476,y:910,t:1527030684567};\\\", \\\"{x:1473,y:917,t:1527030684583};\\\", \\\"{x:1473,y:922,t:1527030684600};\\\", \\\"{x:1473,y:926,t:1527030684616};\\\", \\\"{x:1473,y:932,t:1527030684633};\\\", \\\"{x:1473,y:937,t:1527030684650};\\\", \\\"{x:1473,y:942,t:1527030684667};\\\", \\\"{x:1473,y:946,t:1527030684684};\\\", \\\"{x:1473,y:949,t:1527030684699};\\\", \\\"{x:1473,y:951,t:1527030684716};\\\", \\\"{x:1473,y:953,t:1527030684734};\\\", \\\"{x:1473,y:954,t:1527030684751};\\\", \\\"{x:1473,y:956,t:1527030684766};\\\", \\\"{x:1473,y:957,t:1527030684784};\\\", \\\"{x:1473,y:960,t:1527030684807};\\\", \\\"{x:1473,y:961,t:1527030684823};\\\", \\\"{x:1473,y:962,t:1527030684833};\\\", \\\"{x:1474,y:964,t:1527030684851};\\\", \\\"{x:1474,y:965,t:1527030684867};\\\", \\\"{x:1475,y:967,t:1527030684887};\\\", \\\"{x:1477,y:967,t:1527030684903};\\\", \\\"{x:1477,y:968,t:1527030684927};\\\", \\\"{x:1478,y:969,t:1527030684943};\\\", \\\"{x:1478,y:970,t:1527030684967};\\\", \\\"{x:1479,y:971,t:1527030684984};\\\", \\\"{x:1480,y:972,t:1527030685001};\\\", \\\"{x:1481,y:973,t:1527030685018};\\\", \\\"{x:1482,y:973,t:1527030685054};\\\", \\\"{x:1483,y:973,t:1527030685070};\\\", \\\"{x:1484,y:973,t:1527030685543};\\\", \\\"{x:1485,y:972,t:1527030687166};\\\", \\\"{x:1486,y:971,t:1527030687174};\\\", \\\"{x:1486,y:970,t:1527030687187};\\\", \\\"{x:1487,y:969,t:1527030687204};\\\", \\\"{x:1487,y:968,t:1527030687223};\\\", \\\"{x:1487,y:967,t:1527030688391};\\\", \\\"{x:1486,y:967,t:1527030688415};\\\", \\\"{x:1486,y:966,t:1527030688438};\\\", \\\"{x:1488,y:962,t:1527030688454};\\\", \\\"{x:1489,y:959,t:1527030688472};\\\", \\\"{x:1490,y:958,t:1527030688489};\\\", \\\"{x:1491,y:958,t:1527030688505};\\\", \\\"{x:1491,y:959,t:1527030688679};\\\", \\\"{x:1491,y:960,t:1527030688689};\\\", \\\"{x:1490,y:961,t:1527030688705};\\\", \\\"{x:1491,y:961,t:1527030689479};\\\", \\\"{x:1491,y:960,t:1527030689494};\\\", \\\"{x:1491,y:959,t:1527030689507};\\\", \\\"{x:1491,y:952,t:1527030689522};\\\", \\\"{x:1485,y:939,t:1527030689540};\\\", \\\"{x:1473,y:923,t:1527030689556};\\\", \\\"{x:1460,y:906,t:1527030689573};\\\", \\\"{x:1441,y:889,t:1527030689589};\\\", \\\"{x:1371,y:841,t:1527030689607};\\\", \\\"{x:1290,y:788,t:1527030689623};\\\", \\\"{x:1192,y:735,t:1527030689640};\\\", \\\"{x:1102,y:681,t:1527030689657};\\\", \\\"{x:1023,y:634,t:1527030689674};\\\", \\\"{x:976,y:605,t:1527030689691};\\\", \\\"{x:946,y:588,t:1527030689708};\\\", \\\"{x:924,y:574,t:1527030689724};\\\", \\\"{x:905,y:561,t:1527030689740};\\\", \\\"{x:872,y:544,t:1527030689761};\\\", \\\"{x:852,y:536,t:1527030689778};\\\", \\\"{x:834,y:526,t:1527030689799};\\\", \\\"{x:816,y:518,t:1527030689815};\\\", \\\"{x:784,y:504,t:1527030689831};\\\", \\\"{x:761,y:494,t:1527030689847};\\\", \\\"{x:740,y:485,t:1527030689864};\\\", \\\"{x:727,y:482,t:1527030689881};\\\", \\\"{x:719,y:479,t:1527030689898};\\\", \\\"{x:718,y:479,t:1527030689913};\\\", \\\"{x:716,y:479,t:1527030689967};\\\", \\\"{x:715,y:479,t:1527030689983};\\\", \\\"{x:713,y:480,t:1527030689999};\\\", \\\"{x:711,y:480,t:1527030690014};\\\", \\\"{x:703,y:485,t:1527030690031};\\\", \\\"{x:698,y:489,t:1527030690048};\\\", \\\"{x:691,y:493,t:1527030690064};\\\", \\\"{x:685,y:497,t:1527030690081};\\\", \\\"{x:682,y:498,t:1527030690098};\\\", \\\"{x:676,y:499,t:1527030690114};\\\", \\\"{x:669,y:501,t:1527030690130};\\\", \\\"{x:666,y:501,t:1527030690148};\\\", \\\"{x:665,y:503,t:1527030690165};\\\", \\\"{x:664,y:503,t:1527030690181};\\\", \\\"{x:661,y:504,t:1527030690198};\\\", \\\"{x:649,y:507,t:1527030690215};\\\", \\\"{x:636,y:508,t:1527030690231};\\\", \\\"{x:632,y:508,t:1527030690247};\\\", \\\"{x:629,y:508,t:1527030690265};\\\", \\\"{x:628,y:508,t:1527030690281};\\\", \\\"{x:626,y:508,t:1527030690302};\\\", \\\"{x:625,y:508,t:1527030690315};\\\", \\\"{x:621,y:509,t:1527030690331};\\\", \\\"{x:615,y:509,t:1527030690348};\\\", \\\"{x:609,y:509,t:1527030690365};\\\", \\\"{x:604,y:509,t:1527030690381};\\\", \\\"{x:600,y:509,t:1527030690398};\\\", \\\"{x:607,y:509,t:1527030690670};\\\", \\\"{x:615,y:509,t:1527030690682};\\\", \\\"{x:635,y:509,t:1527030690698};\\\", \\\"{x:656,y:509,t:1527030690715};\\\", \\\"{x:680,y:509,t:1527030690732};\\\", \\\"{x:701,y:509,t:1527030690748};\\\", \\\"{x:716,y:509,t:1527030690765};\\\", \\\"{x:726,y:509,t:1527030690782};\\\", \\\"{x:736,y:509,t:1527030690798};\\\", \\\"{x:739,y:509,t:1527030690815};\\\", \\\"{x:743,y:509,t:1527030690832};\\\", \\\"{x:748,y:509,t:1527030690848};\\\", \\\"{x:754,y:509,t:1527030690865};\\\", \\\"{x:758,y:509,t:1527030690881};\\\", \\\"{x:759,y:509,t:1527030690898};\\\", \\\"{x:762,y:509,t:1527030690915};\\\", \\\"{x:763,y:509,t:1527030690932};\\\", \\\"{x:765,y:509,t:1527030690948};\\\", \\\"{x:767,y:509,t:1527030690964};\\\", \\\"{x:768,y:509,t:1527030690982};\\\", \\\"{x:771,y:509,t:1527030690998};\\\", \\\"{x:776,y:509,t:1527030691015};\\\", \\\"{x:781,y:509,t:1527030691032};\\\", \\\"{x:789,y:509,t:1527030691048};\\\", \\\"{x:797,y:509,t:1527030691065};\\\", \\\"{x:805,y:509,t:1527030691081};\\\", \\\"{x:811,y:509,t:1527030691098};\\\", \\\"{x:814,y:509,t:1527030691115};\\\", \\\"{x:818,y:509,t:1527030691132};\\\", \\\"{x:820,y:509,t:1527030691149};\\\", \\\"{x:821,y:509,t:1527030691190};\\\", \\\"{x:822,y:508,t:1527030691238};\\\", \\\"{x:823,y:508,t:1527030691335};\\\", \\\"{x:824,y:508,t:1527030691349};\\\", \\\"{x:827,y:508,t:1527030691365};\\\", \\\"{x:829,y:507,t:1527030691382};\\\", \\\"{x:833,y:507,t:1527030691399};\\\", \\\"{x:834,y:507,t:1527030691415};\\\", \\\"{x:835,y:506,t:1527030691432};\\\", \\\"{x:836,y:506,t:1527030691449};\\\", \\\"{x:836,y:508,t:1527030691734};\\\", \\\"{x:835,y:509,t:1527030691749};\\\", \\\"{x:832,y:513,t:1527030691766};\\\", \\\"{x:827,y:520,t:1527030691783};\\\", \\\"{x:820,y:527,t:1527030691800};\\\", \\\"{x:809,y:535,t:1527030691816};\\\", \\\"{x:791,y:551,t:1527030691833};\\\", \\\"{x:767,y:566,t:1527030691850};\\\", \\\"{x:731,y:591,t:1527030691866};\\\", \\\"{x:700,y:613,t:1527030691883};\\\", \\\"{x:681,y:626,t:1527030691900};\\\", \\\"{x:672,y:630,t:1527030691916};\\\", \\\"{x:670,y:631,t:1527030691933};\\\", \\\"{x:666,y:631,t:1527030691949};\\\", \\\"{x:660,y:632,t:1527030691967};\\\", \\\"{x:642,y:636,t:1527030691982};\\\", \\\"{x:631,y:640,t:1527030691999};\\\", \\\"{x:627,y:642,t:1527030692016};\\\", \\\"{x:623,y:645,t:1527030692033};\\\", \\\"{x:622,y:646,t:1527030692049};\\\", \\\"{x:622,y:648,t:1527030692066};\\\", \\\"{x:622,y:649,t:1527030692082};\\\", \\\"{x:622,y:651,t:1527030692098};\\\", \\\"{x:621,y:655,t:1527030692116};\\\", \\\"{x:619,y:658,t:1527030692133};\\\", \\\"{x:618,y:663,t:1527030692149};\\\", \\\"{x:617,y:669,t:1527030692166};\\\", \\\"{x:617,y:672,t:1527030692183};\\\", \\\"{x:616,y:676,t:1527030692199};\\\", \\\"{x:614,y:680,t:1527030692216};\\\", \\\"{x:614,y:685,t:1527030692233};\\\", \\\"{x:612,y:690,t:1527030692250};\\\", \\\"{x:611,y:696,t:1527030692266};\\\", \\\"{x:611,y:700,t:1527030692283};\\\", \\\"{x:611,y:702,t:1527030692300};\\\", \\\"{x:610,y:704,t:1527030692316};\\\", \\\"{x:608,y:707,t:1527030692333};\\\", \\\"{x:606,y:710,t:1527030692350};\\\", \\\"{x:604,y:713,t:1527030692367};\\\", \\\"{x:601,y:716,t:1527030692383};\\\", \\\"{x:601,y:717,t:1527030692400};\\\", \\\"{x:600,y:717,t:1527030692422};\\\", \\\"{x:599,y:718,t:1527030692433};\\\", \\\"{x:598,y:718,t:1527030692450};\\\", \\\"{x:593,y:720,t:1527030692466};\\\", \\\"{x:588,y:722,t:1527030692483};\\\", \\\"{x:584,y:724,t:1527030692500};\\\", \\\"{x:582,y:724,t:1527030692516};\\\", \\\"{x:580,y:726,t:1527030692533};\\\", \\\"{x:579,y:726,t:1527030692550};\\\", \\\"{x:575,y:729,t:1527030692566};\\\", \\\"{x:572,y:731,t:1527030692583};\\\", \\\"{x:571,y:731,t:1527030692606};\\\", \\\"{x:570,y:731,t:1527030692647};\\\", \\\"{x:569,y:731,t:1527030692654};\\\", \\\"{x:568,y:730,t:1527030692666};\\\", \\\"{x:557,y:722,t:1527030692684};\\\", \\\"{x:532,y:706,t:1527030692700};\\\", \\\"{x:507,y:697,t:1527030692716};\\\", \\\"{x:481,y:685,t:1527030692733};\\\", \\\"{x:470,y:678,t:1527030692750};\\\", \\\"{x:465,y:673,t:1527030692765};\\\", \\\"{x:462,y:669,t:1527030692783};\\\", \\\"{x:460,y:666,t:1527030692800};\\\", \\\"{x:457,y:662,t:1527030692817};\\\", \\\"{x:453,y:658,t:1527030692834};\\\", \\\"{x:448,y:652,t:1527030692850};\\\", \\\"{x:444,y:646,t:1527030692867};\\\", \\\"{x:441,y:637,t:1527030692885};\\\", \\\"{x:438,y:625,t:1527030692901};\\\", \\\"{x:434,y:615,t:1527030692917};\\\", \\\"{x:431,y:607,t:1527030692933};\\\", \\\"{x:427,y:600,t:1527030692950};\\\", \\\"{x:423,y:594,t:1527030692966};\\\", \\\"{x:421,y:590,t:1527030692984};\\\", \\\"{x:418,y:586,t:1527030693000};\\\", \\\"{x:414,y:579,t:1527030693017};\\\", \\\"{x:413,y:574,t:1527030693034};\\\", \\\"{x:411,y:572,t:1527030693050};\\\", \\\"{x:411,y:571,t:1527030693066};\\\", \\\"{x:413,y:572,t:1527030693302};\\\", \\\"{x:418,y:576,t:1527030693316};\\\", \\\"{x:425,y:582,t:1527030693333};\\\", \\\"{x:438,y:591,t:1527030693349};\\\", \\\"{x:460,y:606,t:1527030693367};\\\", \\\"{x:478,y:616,t:1527030693383};\\\", \\\"{x:489,y:623,t:1527030693401};\\\", \\\"{x:494,y:629,t:1527030693416};\\\", \\\"{x:501,y:637,t:1527030693434};\\\", \\\"{x:511,y:647,t:1527030693451};\\\", \\\"{x:522,y:656,t:1527030693467};\\\", \\\"{x:537,y:663,t:1527030693484};\\\", \\\"{x:545,y:666,t:1527030693501};\\\", \\\"{x:551,y:671,t:1527030693518};\\\", \\\"{x:558,y:676,t:1527030693534};\\\", \\\"{x:572,y:687,t:1527030693550};\\\", \\\"{x:578,y:690,t:1527030693567};\\\", \\\"{x:589,y:693,t:1527030693584};\\\", \\\"{x:600,y:697,t:1527030693600};\\\", \\\"{x:608,y:699,t:1527030693616};\\\", \\\"{x:610,y:699,t:1527030693634};\\\", \\\"{x:612,y:701,t:1527030693651};\\\", \\\"{x:614,y:703,t:1527030693667};\\\", \\\"{x:615,y:706,t:1527030693684};\\\", \\\"{x:618,y:712,t:1527030693701};\\\", \\\"{x:619,y:717,t:1527030693717};\\\", \\\"{x:621,y:723,t:1527030693733};\\\", \\\"{x:620,y:728,t:1527030693751};\\\", \\\"{x:618,y:730,t:1527030693767};\\\", \\\"{x:614,y:734,t:1527030693784};\\\", \\\"{x:609,y:736,t:1527030693801};\\\", \\\"{x:598,y:739,t:1527030693817};\\\", \\\"{x:587,y:740,t:1527030693833};\\\", \\\"{x:574,y:742,t:1527030693851};\\\", \\\"{x:563,y:744,t:1527030693867};\\\", \\\"{x:555,y:744,t:1527030693884};\\\", \\\"{x:552,y:744,t:1527030693901};\\\", \\\"{x:549,y:744,t:1527030693917};\\\", \\\"{x:547,y:744,t:1527030693934};\\\", \\\"{x:538,y:744,t:1527030693950};\\\", \\\"{x:533,y:744,t:1527030693967};\\\", \\\"{x:529,y:744,t:1527030693984};\\\", \\\"{x:527,y:743,t:1527030694001};\\\", \\\"{x:526,y:743,t:1527030694017};\\\", \\\"{x:524,y:743,t:1527030694038};\\\", \\\"{x:523,y:743,t:1527030694102};\\\", \\\"{x:521,y:743,t:1527030694462};\\\", \\\"{x:518,y:741,t:1527030694470};\\\", \\\"{x:517,y:741,t:1527030694502};\\\" ] }, { \\\"rt\\\": 11997, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 627891, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:738,t:1527030699551};\\\", \\\"{x:533,y:732,t:1527030699558};\\\", \\\"{x:543,y:725,t:1527030699573};\\\", \\\"{x:556,y:713,t:1527030699589};\\\", \\\"{x:561,y:674,t:1527030699606};\\\", \\\"{x:560,y:633,t:1527030699622};\\\", \\\"{x:543,y:601,t:1527030699640};\\\", \\\"{x:526,y:579,t:1527030699655};\\\", \\\"{x:517,y:565,t:1527030699672};\\\", \\\"{x:513,y:560,t:1527030699690};\\\", \\\"{x:513,y:554,t:1527030699706};\\\", \\\"{x:513,y:548,t:1527030699722};\\\", \\\"{x:509,y:542,t:1527030699738};\\\", \\\"{x:505,y:535,t:1527030699755};\\\", \\\"{x:496,y:530,t:1527030699773};\\\", \\\"{x:490,y:528,t:1527030699788};\\\", \\\"{x:483,y:524,t:1527030699806};\\\", \\\"{x:481,y:523,t:1527030699823};\\\", \\\"{x:481,y:521,t:1527030699840};\\\", \\\"{x:481,y:519,t:1527030699856};\\\", \\\"{x:479,y:513,t:1527030699873};\\\", \\\"{x:478,y:507,t:1527030699889};\\\", \\\"{x:476,y:498,t:1527030699905};\\\", \\\"{x:474,y:493,t:1527030699922};\\\", \\\"{x:474,y:486,t:1527030699940};\\\", \\\"{x:474,y:483,t:1527030699955};\\\", \\\"{x:474,y:478,t:1527030699972};\\\", \\\"{x:473,y:473,t:1527030699989};\\\", \\\"{x:473,y:469,t:1527030700006};\\\", \\\"{x:473,y:465,t:1527030700022};\\\", \\\"{x:473,y:464,t:1527030700039};\\\", \\\"{x:471,y:461,t:1527030700057};\\\", \\\"{x:476,y:461,t:1527030700319};\\\", \\\"{x:488,y:461,t:1527030700326};\\\", \\\"{x:502,y:461,t:1527030700339};\\\", \\\"{x:531,y:463,t:1527030700357};\\\", \\\"{x:564,y:463,t:1527030700373};\\\", \\\"{x:589,y:463,t:1527030700389};\\\", \\\"{x:616,y:463,t:1527030700407};\\\", \\\"{x:633,y:463,t:1527030700422};\\\", \\\"{x:646,y:463,t:1527030700440};\\\", \\\"{x:655,y:463,t:1527030700456};\\\", \\\"{x:666,y:463,t:1527030700472};\\\", \\\"{x:681,y:463,t:1527030700490};\\\", \\\"{x:696,y:463,t:1527030700506};\\\", \\\"{x:711,y:463,t:1527030700522};\\\", \\\"{x:720,y:463,t:1527030700540};\\\", \\\"{x:722,y:463,t:1527030700557};\\\", \\\"{x:723,y:463,t:1527030700572};\\\", \\\"{x:726,y:465,t:1527030700598};\\\", \\\"{x:727,y:467,t:1527030700614};\\\", \\\"{x:730,y:472,t:1527030700622};\\\", \\\"{x:735,y:484,t:1527030700639};\\\", \\\"{x:738,y:492,t:1527030700656};\\\", \\\"{x:739,y:498,t:1527030700672};\\\", \\\"{x:740,y:503,t:1527030700689};\\\", \\\"{x:741,y:508,t:1527030700707};\\\", \\\"{x:741,y:513,t:1527030700723};\\\", \\\"{x:741,y:520,t:1527030700741};\\\", \\\"{x:741,y:526,t:1527030700757};\\\", \\\"{x:741,y:532,t:1527030700773};\\\", \\\"{x:741,y:540,t:1527030700789};\\\", \\\"{x:741,y:553,t:1527030700806};\\\", \\\"{x:741,y:560,t:1527030700824};\\\", \\\"{x:741,y:569,t:1527030700841};\\\", \\\"{x:739,y:584,t:1527030700856};\\\", \\\"{x:732,y:605,t:1527030700874};\\\", \\\"{x:728,y:627,t:1527030700891};\\\", \\\"{x:725,y:655,t:1527030700907};\\\", \\\"{x:725,y:684,t:1527030700923};\\\", \\\"{x:727,y:713,t:1527030700940};\\\", \\\"{x:733,y:741,t:1527030700956};\\\", \\\"{x:747,y:777,t:1527030700974};\\\", \\\"{x:768,y:822,t:1527030700990};\\\", \\\"{x:783,y:841,t:1527030701006};\\\", \\\"{x:792,y:851,t:1527030701023};\\\", \\\"{x:797,y:859,t:1527030701041};\\\", \\\"{x:803,y:866,t:1527030701058};\\\", \\\"{x:805,y:872,t:1527030701073};\\\", \\\"{x:808,y:878,t:1527030701090};\\\", \\\"{x:811,y:884,t:1527030701108};\\\", \\\"{x:815,y:889,t:1527030701124};\\\", \\\"{x:819,y:896,t:1527030701140};\\\", \\\"{x:824,y:901,t:1527030701157};\\\", \\\"{x:826,y:903,t:1527030701173};\\\", \\\"{x:826,y:904,t:1527030701190};\\\", \\\"{x:828,y:904,t:1527030701734};\\\", \\\"{x:833,y:905,t:1527030701751};\\\", \\\"{x:835,y:906,t:1527030701758};\\\", \\\"{x:842,y:906,t:1527030701774};\\\", \\\"{x:850,y:906,t:1527030701792};\\\", \\\"{x:859,y:906,t:1527030701808};\\\", \\\"{x:888,y:906,t:1527030701824};\\\", \\\"{x:960,y:906,t:1527030701842};\\\", \\\"{x:1046,y:906,t:1527030701858};\\\", \\\"{x:1146,y:906,t:1527030701875};\\\", \\\"{x:1257,y:906,t:1527030701891};\\\", \\\"{x:1343,y:906,t:1527030701909};\\\", \\\"{x:1388,y:906,t:1527030701926};\\\", \\\"{x:1407,y:904,t:1527030701942};\\\", \\\"{x:1414,y:903,t:1527030701959};\\\", \\\"{x:1416,y:903,t:1527030701976};\\\", \\\"{x:1423,y:903,t:1527030701992};\\\", \\\"{x:1437,y:903,t:1527030702009};\\\", \\\"{x:1452,y:903,t:1527030702025};\\\", \\\"{x:1468,y:907,t:1527030702041};\\\", \\\"{x:1477,y:910,t:1527030702058};\\\", \\\"{x:1485,y:913,t:1527030702076};\\\", \\\"{x:1489,y:916,t:1527030702092};\\\", \\\"{x:1491,y:917,t:1527030702109};\\\", \\\"{x:1492,y:918,t:1527030702125};\\\", \\\"{x:1493,y:919,t:1527030702142};\\\", \\\"{x:1495,y:922,t:1527030702159};\\\", \\\"{x:1500,y:926,t:1527030702175};\\\", \\\"{x:1509,y:930,t:1527030702193};\\\", \\\"{x:1519,y:934,t:1527030702208};\\\", \\\"{x:1522,y:936,t:1527030702226};\\\", \\\"{x:1523,y:936,t:1527030702263};\\\", \\\"{x:1524,y:938,t:1527030702278};\\\", \\\"{x:1525,y:941,t:1527030702293};\\\", \\\"{x:1530,y:948,t:1527030702309};\\\", \\\"{x:1536,y:955,t:1527030702325};\\\", \\\"{x:1544,y:962,t:1527030702342};\\\", \\\"{x:1546,y:963,t:1527030702359};\\\", \\\"{x:1547,y:963,t:1527030702376};\\\", \\\"{x:1548,y:964,t:1527030702470};\\\", \\\"{x:1548,y:963,t:1527030702846};\\\", \\\"{x:1547,y:962,t:1527030702859};\\\", \\\"{x:1545,y:960,t:1527030702877};\\\", \\\"{x:1545,y:958,t:1527030702894};\\\", \\\"{x:1542,y:955,t:1527030702910};\\\", \\\"{x:1539,y:951,t:1527030702926};\\\", \\\"{x:1537,y:948,t:1527030702944};\\\", \\\"{x:1535,y:943,t:1527030702960};\\\", \\\"{x:1531,y:938,t:1527030702977};\\\", \\\"{x:1528,y:932,t:1527030702993};\\\", \\\"{x:1524,y:926,t:1527030703011};\\\", \\\"{x:1523,y:921,t:1527030703026};\\\", \\\"{x:1521,y:917,t:1527030703043};\\\", \\\"{x:1519,y:912,t:1527030703061};\\\", \\\"{x:1516,y:906,t:1527030703077};\\\", \\\"{x:1515,y:902,t:1527030703094};\\\", \\\"{x:1509,y:896,t:1527030703110};\\\", \\\"{x:1507,y:891,t:1527030703126};\\\", \\\"{x:1501,y:881,t:1527030703143};\\\", \\\"{x:1499,y:875,t:1527030703160};\\\", \\\"{x:1494,y:868,t:1527030703177};\\\", \\\"{x:1490,y:861,t:1527030703193};\\\", \\\"{x:1487,y:855,t:1527030703211};\\\", \\\"{x:1483,y:848,t:1527030703227};\\\", \\\"{x:1481,y:844,t:1527030703244};\\\", \\\"{x:1480,y:842,t:1527030703261};\\\", \\\"{x:1479,y:841,t:1527030703277};\\\", \\\"{x:1481,y:845,t:1527030704302};\\\", \\\"{x:1485,y:851,t:1527030704312};\\\", \\\"{x:1496,y:865,t:1527030704329};\\\", \\\"{x:1504,y:878,t:1527030704345};\\\", \\\"{x:1514,y:891,t:1527030704363};\\\", \\\"{x:1520,y:899,t:1527030704379};\\\", \\\"{x:1524,y:905,t:1527030704395};\\\", \\\"{x:1526,y:908,t:1527030704413};\\\", \\\"{x:1527,y:911,t:1527030704430};\\\", \\\"{x:1530,y:915,t:1527030704446};\\\", \\\"{x:1538,y:928,t:1527030704462};\\\", \\\"{x:1546,y:938,t:1527030704479};\\\", \\\"{x:1550,y:943,t:1527030704495};\\\", \\\"{x:1556,y:952,t:1527030704513};\\\", \\\"{x:1557,y:954,t:1527030704530};\\\", \\\"{x:1559,y:959,t:1527030704546};\\\", \\\"{x:1560,y:959,t:1527030704563};\\\", \\\"{x:1561,y:961,t:1527030704580};\\\", \\\"{x:1561,y:962,t:1527030704596};\\\", \\\"{x:1562,y:963,t:1527030704614};\\\", \\\"{x:1563,y:964,t:1527030704663};\\\", \\\"{x:1562,y:965,t:1527030704790};\\\", \\\"{x:1559,y:964,t:1527030704798};\\\", \\\"{x:1557,y:963,t:1527030704813};\\\", \\\"{x:1550,y:952,t:1527030704830};\\\", \\\"{x:1536,y:932,t:1527030704846};\\\", \\\"{x:1525,y:919,t:1527030704863};\\\", \\\"{x:1516,y:906,t:1527030704880};\\\", \\\"{x:1504,y:891,t:1527030704897};\\\", \\\"{x:1496,y:879,t:1527030704914};\\\", \\\"{x:1490,y:870,t:1527030704930};\\\", \\\"{x:1486,y:861,t:1527030704947};\\\", \\\"{x:1480,y:850,t:1527030704964};\\\", \\\"{x:1477,y:845,t:1527030704979};\\\", \\\"{x:1476,y:843,t:1527030704997};\\\", \\\"{x:1474,y:841,t:1527030705013};\\\", \\\"{x:1471,y:834,t:1527030705031};\\\", \\\"{x:1470,y:831,t:1527030705047};\\\", \\\"{x:1469,y:829,t:1527030705064};\\\", \\\"{x:1468,y:828,t:1527030705080};\\\", \\\"{x:1469,y:832,t:1527030706206};\\\", \\\"{x:1477,y:839,t:1527030706216};\\\", \\\"{x:1492,y:850,t:1527030706232};\\\", \\\"{x:1500,y:857,t:1527030706249};\\\", \\\"{x:1507,y:862,t:1527030706266};\\\", \\\"{x:1510,y:864,t:1527030706282};\\\", \\\"{x:1514,y:869,t:1527030706299};\\\", \\\"{x:1517,y:871,t:1527030706316};\\\", \\\"{x:1519,y:876,t:1527030706333};\\\", \\\"{x:1521,y:881,t:1527030706348};\\\", \\\"{x:1522,y:883,t:1527030706366};\\\", \\\"{x:1522,y:886,t:1527030706382};\\\", \\\"{x:1522,y:890,t:1527030706399};\\\", \\\"{x:1522,y:892,t:1527030706416};\\\", \\\"{x:1523,y:895,t:1527030706433};\\\", \\\"{x:1524,y:899,t:1527030706449};\\\", \\\"{x:1525,y:902,t:1527030706466};\\\", \\\"{x:1527,y:905,t:1527030706483};\\\", \\\"{x:1529,y:909,t:1527030706500};\\\", \\\"{x:1529,y:911,t:1527030706515};\\\", \\\"{x:1529,y:913,t:1527030706532};\\\", \\\"{x:1529,y:915,t:1527030706550};\\\", \\\"{x:1529,y:916,t:1527030706566};\\\", \\\"{x:1528,y:916,t:1527030706662};\\\", \\\"{x:1527,y:912,t:1527030706670};\\\", \\\"{x:1523,y:906,t:1527030706683};\\\", \\\"{x:1513,y:894,t:1527030706699};\\\", \\\"{x:1506,y:883,t:1527030706716};\\\", \\\"{x:1500,y:873,t:1527030706733};\\\", \\\"{x:1495,y:866,t:1527030706749};\\\", \\\"{x:1490,y:859,t:1527030706765};\\\", \\\"{x:1489,y:858,t:1527030706782};\\\", \\\"{x:1489,y:856,t:1527030706799};\\\", \\\"{x:1489,y:855,t:1527030706816};\\\", \\\"{x:1488,y:853,t:1527030706838};\\\", \\\"{x:1488,y:852,t:1527030706854};\\\", \\\"{x:1488,y:850,t:1527030706878};\\\", \\\"{x:1488,y:849,t:1527030706886};\\\", \\\"{x:1488,y:848,t:1527030706902};\\\", \\\"{x:1487,y:848,t:1527030706918};\\\", \\\"{x:1487,y:847,t:1527030706933};\\\", \\\"{x:1487,y:845,t:1527030707078};\\\", \\\"{x:1483,y:841,t:1527030707086};\\\", \\\"{x:1475,y:837,t:1527030707101};\\\", \\\"{x:1455,y:829,t:1527030707116};\\\", \\\"{x:1424,y:816,t:1527030707134};\\\", \\\"{x:1367,y:792,t:1527030707150};\\\", \\\"{x:1313,y:772,t:1527030707167};\\\", \\\"{x:1258,y:749,t:1527030707183};\\\", \\\"{x:1202,y:732,t:1527030707200};\\\", \\\"{x:1149,y:718,t:1527030707216};\\\", \\\"{x:1083,y:700,t:1527030707234};\\\", \\\"{x:1022,y:683,t:1527030707251};\\\", \\\"{x:971,y:666,t:1527030707266};\\\", \\\"{x:920,y:650,t:1527030707284};\\\", \\\"{x:876,y:640,t:1527030707301};\\\", \\\"{x:831,y:626,t:1527030707317};\\\", \\\"{x:795,y:615,t:1527030707334};\\\", \\\"{x:757,y:605,t:1527030707350};\\\", \\\"{x:747,y:602,t:1527030707362};\\\", \\\"{x:725,y:596,t:1527030707379};\\\", \\\"{x:696,y:587,t:1527030707396};\\\", \\\"{x:664,y:578,t:1527030707412};\\\", \\\"{x:628,y:567,t:1527030707429};\\\", \\\"{x:595,y:561,t:1527030707446};\\\", \\\"{x:558,y:554,t:1527030707462};\\\", \\\"{x:512,y:549,t:1527030707479};\\\", \\\"{x:481,y:549,t:1527030707496};\\\", \\\"{x:449,y:549,t:1527030707511};\\\", \\\"{x:422,y:549,t:1527030707529};\\\", \\\"{x:398,y:549,t:1527030707546};\\\", \\\"{x:378,y:549,t:1527030707563};\\\", \\\"{x:364,y:549,t:1527030707579};\\\", \\\"{x:356,y:549,t:1527030707595};\\\", \\\"{x:350,y:551,t:1527030707612};\\\", \\\"{x:345,y:553,t:1527030707628};\\\", \\\"{x:332,y:557,t:1527030707646};\\\", \\\"{x:317,y:561,t:1527030707662};\\\", \\\"{x:294,y:565,t:1527030707679};\\\", \\\"{x:286,y:567,t:1527030707696};\\\", \\\"{x:283,y:568,t:1527030707712};\\\", \\\"{x:285,y:568,t:1527030707798};\\\", \\\"{x:295,y:568,t:1527030707811};\\\", \\\"{x:336,y:568,t:1527030707829};\\\", \\\"{x:394,y:568,t:1527030707846};\\\", \\\"{x:447,y:574,t:1527030707862};\\\", \\\"{x:497,y:579,t:1527030707879};\\\", \\\"{x:511,y:579,t:1527030707896};\\\", \\\"{x:516,y:579,t:1527030707913};\\\", \\\"{x:521,y:579,t:1527030707929};\\\", \\\"{x:531,y:579,t:1527030707946};\\\", \\\"{x:548,y:579,t:1527030707963};\\\", \\\"{x:569,y:579,t:1527030707979};\\\", \\\"{x:587,y:579,t:1527030707995};\\\", \\\"{x:598,y:579,t:1527030708012};\\\", \\\"{x:603,y:579,t:1527030708028};\\\", \\\"{x:605,y:579,t:1527030708046};\\\", \\\"{x:615,y:578,t:1527030708062};\\\", \\\"{x:627,y:578,t:1527030708080};\\\", \\\"{x:637,y:578,t:1527030708095};\\\", \\\"{x:646,y:576,t:1527030708113};\\\", \\\"{x:649,y:576,t:1527030708130};\\\", \\\"{x:649,y:578,t:1527030708238};\\\", \\\"{x:648,y:578,t:1527030708246};\\\", \\\"{x:641,y:578,t:1527030708263};\\\", \\\"{x:636,y:578,t:1527030708279};\\\", \\\"{x:630,y:578,t:1527030708296};\\\", \\\"{x:625,y:578,t:1527030708313};\\\", \\\"{x:623,y:578,t:1527030708330};\\\", \\\"{x:622,y:578,t:1527030708382};\\\", \\\"{x:620,y:578,t:1527030708397};\\\", \\\"{x:619,y:578,t:1527030708422};\\\", \\\"{x:618,y:578,t:1527030708470};\\\", \\\"{x:617,y:578,t:1527030708486};\\\", \\\"{x:615,y:581,t:1527030708622};\\\", \\\"{x:614,y:582,t:1527030708631};\\\", \\\"{x:613,y:583,t:1527030708638};\\\", \\\"{x:613,y:583,t:1527030708646};\\\", \\\"{x:610,y:586,t:1527030708663};\\\", \\\"{x:609,y:588,t:1527030708814};\\\", \\\"{x:609,y:590,t:1527030708830};\\\", \\\"{x:616,y:604,t:1527030708846};\\\", \\\"{x:630,y:613,t:1527030708863};\\\", \\\"{x:658,y:622,t:1527030708880};\\\", \\\"{x:713,y:637,t:1527030708897};\\\", \\\"{x:805,y:652,t:1527030708914};\\\", \\\"{x:902,y:664,t:1527030708930};\\\", \\\"{x:1014,y:684,t:1527030708947};\\\", \\\"{x:1121,y:706,t:1527030708963};\\\", \\\"{x:1226,y:737,t:1527030708979};\\\", \\\"{x:1321,y:773,t:1527030708996};\\\", \\\"{x:1406,y:801,t:1527030709014};\\\", \\\"{x:1463,y:825,t:1527030709030};\\\", \\\"{x:1510,y:846,t:1527030709047};\\\", \\\"{x:1530,y:854,t:1527030709064};\\\", \\\"{x:1544,y:862,t:1527030709079};\\\", \\\"{x:1552,y:868,t:1527030709097};\\\", \\\"{x:1559,y:873,t:1527030709114};\\\", \\\"{x:1569,y:882,t:1527030709130};\\\", \\\"{x:1575,y:887,t:1527030709147};\\\", \\\"{x:1579,y:893,t:1527030709164};\\\", \\\"{x:1582,y:901,t:1527030709180};\\\", \\\"{x:1588,y:916,t:1527030709197};\\\", \\\"{x:1594,y:934,t:1527030709214};\\\", \\\"{x:1601,y:951,t:1527030709230};\\\", \\\"{x:1605,y:962,t:1527030709247};\\\", \\\"{x:1605,y:964,t:1527030709264};\\\", \\\"{x:1605,y:967,t:1527030709280};\\\", \\\"{x:1603,y:970,t:1527030709297};\\\", \\\"{x:1600,y:973,t:1527030709314};\\\", \\\"{x:1595,y:978,t:1527030709330};\\\", \\\"{x:1589,y:982,t:1527030709347};\\\", \\\"{x:1584,y:983,t:1527030709363};\\\", \\\"{x:1581,y:984,t:1527030709380};\\\", \\\"{x:1578,y:986,t:1527030709397};\\\", \\\"{x:1576,y:986,t:1527030709414};\\\", \\\"{x:1571,y:986,t:1527030709430};\\\", \\\"{x:1563,y:986,t:1527030709447};\\\", \\\"{x:1554,y:984,t:1527030709463};\\\", \\\"{x:1548,y:982,t:1527030709481};\\\", \\\"{x:1545,y:979,t:1527030709497};\\\", \\\"{x:1540,y:973,t:1527030709514};\\\", \\\"{x:1537,y:967,t:1527030709531};\\\", \\\"{x:1533,y:960,t:1527030709547};\\\", \\\"{x:1530,y:956,t:1527030709564};\\\", \\\"{x:1528,y:954,t:1527030709580};\\\", \\\"{x:1528,y:953,t:1527030709597};\\\", \\\"{x:1528,y:951,t:1527030709614};\\\", \\\"{x:1526,y:946,t:1527030709630};\\\", \\\"{x:1522,y:937,t:1527030709646};\\\", \\\"{x:1518,y:929,t:1527030709663};\\\", \\\"{x:1512,y:918,t:1527030709681};\\\", \\\"{x:1501,y:898,t:1527030709696};\\\", \\\"{x:1492,y:883,t:1527030709713};\\\", \\\"{x:1479,y:870,t:1527030709731};\\\", \\\"{x:1464,y:861,t:1527030709747};\\\", \\\"{x:1456,y:857,t:1527030709764};\\\", \\\"{x:1447,y:854,t:1527030709781};\\\", \\\"{x:1431,y:850,t:1527030709797};\\\", \\\"{x:1408,y:848,t:1527030709814};\\\", \\\"{x:1362,y:843,t:1527030709830};\\\", \\\"{x:1326,y:838,t:1527030709847};\\\", \\\"{x:1292,y:838,t:1527030709864};\\\", \\\"{x:1264,y:838,t:1527030709881};\\\", \\\"{x:1242,y:838,t:1527030709897};\\\", \\\"{x:1217,y:838,t:1527030709914};\\\", \\\"{x:1189,y:838,t:1527030709931};\\\", \\\"{x:1151,y:838,t:1527030709948};\\\", \\\"{x:1114,y:838,t:1527030709964};\\\", \\\"{x:1081,y:835,t:1527030709981};\\\", \\\"{x:1028,y:835,t:1527030709999};\\\", \\\"{x:978,y:835,t:1527030710013};\\\", \\\"{x:916,y:828,t:1527030710031};\\\", \\\"{x:876,y:823,t:1527030710048};\\\", \\\"{x:834,y:815,t:1527030710064};\\\", \\\"{x:799,y:809,t:1527030710081};\\\", \\\"{x:764,y:801,t:1527030710098};\\\", \\\"{x:737,y:794,t:1527030710114};\\\", \\\"{x:711,y:784,t:1527030710131};\\\", \\\"{x:685,y:773,t:1527030710148};\\\", \\\"{x:653,y:764,t:1527030710163};\\\", \\\"{x:627,y:756,t:1527030710181};\\\", \\\"{x:603,y:750,t:1527030710198};\\\", \\\"{x:572,y:743,t:1527030710214};\\\", \\\"{x:559,y:739,t:1527030710231};\\\", \\\"{x:550,y:738,t:1527030710248};\\\", \\\"{x:541,y:737,t:1527030710264};\\\", \\\"{x:533,y:737,t:1527030710281};\\\", \\\"{x:519,y:737,t:1527030710298};\\\", \\\"{x:505,y:737,t:1527030710315};\\\", \\\"{x:500,y:737,t:1527030710331};\\\", \\\"{x:499,y:737,t:1527030710348};\\\", \\\"{x:497,y:737,t:1527030711798};\\\", \\\"{x:485,y:733,t:1527030711815};\\\", \\\"{x:481,y:733,t:1527030711832};\\\", \\\"{x:476,y:733,t:1527030711849};\\\", \\\"{x:473,y:733,t:1527030711866};\\\", \\\"{x:466,y:732,t:1527030711882};\\\", \\\"{x:463,y:732,t:1527030711899};\\\", \\\"{x:461,y:731,t:1527030711916};\\\", \\\"{x:460,y:730,t:1527030711950};\\\", \\\"{x:459,y:730,t:1527030711966};\\\", \\\"{x:458,y:730,t:1527030711982};\\\", \\\"{x:453,y:727,t:1527030711998};\\\", \\\"{x:449,y:726,t:1527030712016};\\\", \\\"{x:447,y:725,t:1527030712032};\\\" ] }, { \\\"rt\\\": 21573, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 650764, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-04 PM-05 PM-12 PM-12 PM-02 PM-02 PM-X -X -X -K -K -K \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:431,y:723,t:1527030712226};\\\", \\\"{x:431,y:712,t:1527030712607};\\\", \\\"{x:431,y:707,t:1527030712616};\\\", \\\"{x:432,y:699,t:1527030712633};\\\", \\\"{x:440,y:688,t:1527030712650};\\\", \\\"{x:448,y:678,t:1527030712667};\\\", \\\"{x:451,y:673,t:1527030712683};\\\", \\\"{x:452,y:667,t:1527030712700};\\\", \\\"{x:452,y:661,t:1527030712716};\\\", \\\"{x:455,y:656,t:1527030712733};\\\", \\\"{x:461,y:642,t:1527030712751};\\\", \\\"{x:464,y:637,t:1527030712766};\\\", \\\"{x:470,y:628,t:1527030712783};\\\", \\\"{x:475,y:616,t:1527030712800};\\\", \\\"{x:480,y:603,t:1527030712818};\\\", \\\"{x:484,y:589,t:1527030712833};\\\", \\\"{x:485,y:575,t:1527030712850};\\\", \\\"{x:485,y:568,t:1527030712866};\\\", \\\"{x:485,y:564,t:1527030712883};\\\", \\\"{x:483,y:560,t:1527030712900};\\\", \\\"{x:482,y:558,t:1527030712916};\\\", \\\"{x:480,y:556,t:1527030712932};\\\", \\\"{x:477,y:553,t:1527030712950};\\\", \\\"{x:462,y:551,t:1527030712966};\\\", \\\"{x:440,y:550,t:1527030712983};\\\", \\\"{x:425,y:548,t:1527030713000};\\\", \\\"{x:421,y:546,t:1527030713017};\\\", \\\"{x:418,y:544,t:1527030713033};\\\", \\\"{x:416,y:541,t:1527030713051};\\\", \\\"{x:412,y:537,t:1527030713068};\\\", \\\"{x:404,y:529,t:1527030713084};\\\", \\\"{x:399,y:523,t:1527030713101};\\\", \\\"{x:395,y:517,t:1527030713117};\\\", \\\"{x:392,y:512,t:1527030713133};\\\", \\\"{x:391,y:510,t:1527030713150};\\\", \\\"{x:391,y:504,t:1527030713167};\\\", \\\"{x:391,y:502,t:1527030713183};\\\", \\\"{x:391,y:497,t:1527030713201};\\\", \\\"{x:391,y:494,t:1527030713217};\\\", \\\"{x:390,y:490,t:1527030713234};\\\", \\\"{x:390,y:488,t:1527030713249};\\\", \\\"{x:389,y:486,t:1527030713267};\\\", \\\"{x:388,y:484,t:1527030713284};\\\", \\\"{x:388,y:483,t:1527030713301};\\\", \\\"{x:386,y:482,t:1527030713317};\\\", \\\"{x:384,y:480,t:1527030713334};\\\", \\\"{x:381,y:476,t:1527030713351};\\\", \\\"{x:379,y:474,t:1527030713368};\\\", \\\"{x:378,y:473,t:1527030713384};\\\", \\\"{x:378,y:472,t:1527030713447};\\\", \\\"{x:379,y:469,t:1527030713462};\\\", \\\"{x:382,y:469,t:1527030713471};\\\", \\\"{x:391,y:468,t:1527030713485};\\\", \\\"{x:415,y:464,t:1527030713501};\\\", \\\"{x:443,y:463,t:1527030713518};\\\", \\\"{x:482,y:456,t:1527030713535};\\\", \\\"{x:500,y:455,t:1527030713552};\\\", \\\"{x:509,y:453,t:1527030713568};\\\", \\\"{x:515,y:452,t:1527030713585};\\\", \\\"{x:517,y:452,t:1527030713602};\\\", \\\"{x:519,y:452,t:1527030713619};\\\", \\\"{x:523,y:451,t:1527030713635};\\\", \\\"{x:527,y:451,t:1527030713652};\\\", \\\"{x:530,y:451,t:1527030713669};\\\", \\\"{x:536,y:451,t:1527030713686};\\\", \\\"{x:539,y:451,t:1527030713702};\\\", \\\"{x:543,y:451,t:1527030713719};\\\", \\\"{x:549,y:451,t:1527030713736};\\\", \\\"{x:558,y:451,t:1527030713752};\\\", \\\"{x:564,y:451,t:1527030713769};\\\", \\\"{x:566,y:451,t:1527030713786};\\\", \\\"{x:569,y:450,t:1527030713803};\\\", \\\"{x:572,y:450,t:1527030713819};\\\", \\\"{x:574,y:450,t:1527030713836};\\\", \\\"{x:577,y:450,t:1527030713853};\\\", \\\"{x:582,y:450,t:1527030713870};\\\", \\\"{x:585,y:450,t:1527030713886};\\\", \\\"{x:588,y:450,t:1527030713903};\\\", \\\"{x:589,y:450,t:1527030713920};\\\", \\\"{x:591,y:449,t:1527030714119};\\\", \\\"{x:592,y:448,t:1527030714150};\\\", \\\"{x:593,y:448,t:1527030714174};\\\", \\\"{x:595,y:448,t:1527030714470};\\\", \\\"{x:603,y:448,t:1527030714477};\\\", \\\"{x:614,y:448,t:1527030714488};\\\", \\\"{x:633,y:451,t:1527030714506};\\\", \\\"{x:647,y:452,t:1527030714522};\\\", \\\"{x:655,y:452,t:1527030714539};\\\", \\\"{x:667,y:452,t:1527030714556};\\\", \\\"{x:668,y:452,t:1527030714573};\\\", \\\"{x:670,y:452,t:1527030714589};\\\", \\\"{x:671,y:452,t:1527030714614};\\\", \\\"{x:673,y:452,t:1527030714630};\\\", \\\"{x:674,y:452,t:1527030714646};\\\", \\\"{x:676,y:452,t:1527030714662};\\\", \\\"{x:678,y:452,t:1527030714678};\\\", \\\"{x:678,y:451,t:1527030714690};\\\", \\\"{x:679,y:451,t:1527030716710};\\\", \\\"{x:680,y:451,t:1527030716742};\\\", \\\"{x:680,y:450,t:1527030716750};\\\", \\\"{x:682,y:450,t:1527030716839};\\\", \\\"{x:683,y:450,t:1527030716855};\\\", \\\"{x:685,y:450,t:1527030716871};\\\", \\\"{x:687,y:448,t:1527030716887};\\\", \\\"{x:689,y:448,t:1527030716904};\\\", \\\"{x:692,y:447,t:1527030716917};\\\", \\\"{x:693,y:447,t:1527030716950};\\\", \\\"{x:697,y:447,t:1527030716966};\\\", \\\"{x:706,y:447,t:1527030716982};\\\", \\\"{x:726,y:447,t:1527030716999};\\\", \\\"{x:754,y:447,t:1527030717016};\\\", \\\"{x:781,y:447,t:1527030717033};\\\", \\\"{x:802,y:447,t:1527030717050};\\\", \\\"{x:812,y:447,t:1527030717066};\\\", \\\"{x:820,y:448,t:1527030717083};\\\", \\\"{x:825,y:448,t:1527030717100};\\\", \\\"{x:832,y:448,t:1527030717116};\\\", \\\"{x:840,y:448,t:1527030717133};\\\", \\\"{x:868,y:450,t:1527030717150};\\\", \\\"{x:891,y:453,t:1527030717167};\\\", \\\"{x:913,y:455,t:1527030717183};\\\", \\\"{x:935,y:457,t:1527030717200};\\\", \\\"{x:951,y:461,t:1527030717217};\\\", \\\"{x:963,y:465,t:1527030717234};\\\", \\\"{x:977,y:470,t:1527030717250};\\\", \\\"{x:997,y:475,t:1527030717267};\\\", \\\"{x:1020,y:481,t:1527030717284};\\\", \\\"{x:1062,y:497,t:1527030717301};\\\", \\\"{x:1128,y:525,t:1527030717318};\\\", \\\"{x:1240,y:574,t:1527030717334};\\\", \\\"{x:1307,y:606,t:1527030717351};\\\", \\\"{x:1363,y:633,t:1527030717368};\\\", \\\"{x:1408,y:655,t:1527030717384};\\\", \\\"{x:1428,y:664,t:1527030717401};\\\", \\\"{x:1432,y:665,t:1527030717418};\\\", \\\"{x:1436,y:669,t:1527030717434};\\\", \\\"{x:1453,y:685,t:1527030717452};\\\", \\\"{x:1477,y:705,t:1527030717468};\\\", \\\"{x:1513,y:735,t:1527030717485};\\\", \\\"{x:1537,y:759,t:1527030717501};\\\", \\\"{x:1556,y:778,t:1527030717518};\\\", \\\"{x:1559,y:788,t:1527030717535};\\\", \\\"{x:1560,y:795,t:1527030717552};\\\", \\\"{x:1561,y:803,t:1527030717568};\\\", \\\"{x:1566,y:815,t:1527030717585};\\\", \\\"{x:1575,y:837,t:1527030717602};\\\", \\\"{x:1581,y:854,t:1527030717619};\\\", \\\"{x:1583,y:869,t:1527030717635};\\\", \\\"{x:1583,y:883,t:1527030717652};\\\", \\\"{x:1583,y:891,t:1527030717669};\\\", \\\"{x:1583,y:900,t:1527030717685};\\\", \\\"{x:1577,y:914,t:1527030717702};\\\", \\\"{x:1574,y:924,t:1527030717719};\\\", \\\"{x:1570,y:935,t:1527030717736};\\\", \\\"{x:1569,y:942,t:1527030717752};\\\", \\\"{x:1569,y:943,t:1527030717770};\\\", \\\"{x:1569,y:944,t:1527030717790};\\\", \\\"{x:1569,y:945,t:1527030717803};\\\", \\\"{x:1569,y:946,t:1527030717822};\\\", \\\"{x:1568,y:946,t:1527030717846};\\\", \\\"{x:1568,y:947,t:1527030717854};\\\", \\\"{x:1568,y:949,t:1527030717870};\\\", \\\"{x:1572,y:951,t:1527030717886};\\\", \\\"{x:1574,y:952,t:1527030717903};\\\", \\\"{x:1576,y:952,t:1527030717920};\\\", \\\"{x:1577,y:952,t:1527030717990};\\\", \\\"{x:1581,y:952,t:1527030718004};\\\", \\\"{x:1588,y:953,t:1527030718020};\\\", \\\"{x:1593,y:955,t:1527030718038};\\\", \\\"{x:1597,y:955,t:1527030718054};\\\", \\\"{x:1598,y:955,t:1527030718086};\\\", \\\"{x:1600,y:956,t:1527030718094};\\\", \\\"{x:1602,y:957,t:1527030718104};\\\", \\\"{x:1608,y:960,t:1527030718121};\\\", \\\"{x:1614,y:962,t:1527030718137};\\\", \\\"{x:1619,y:964,t:1527030718154};\\\", \\\"{x:1622,y:967,t:1527030718171};\\\", \\\"{x:1623,y:968,t:1527030718190};\\\", \\\"{x:1623,y:969,t:1527030718205};\\\", \\\"{x:1625,y:970,t:1527030718221};\\\", \\\"{x:1626,y:972,t:1527030718238};\\\", \\\"{x:1628,y:973,t:1527030718255};\\\", \\\"{x:1628,y:975,t:1527030718278};\\\", \\\"{x:1629,y:975,t:1527030718288};\\\", \\\"{x:1630,y:976,t:1527030718305};\\\", \\\"{x:1631,y:978,t:1527030718322};\\\", \\\"{x:1632,y:979,t:1527030718338};\\\", \\\"{x:1633,y:982,t:1527030718355};\\\", \\\"{x:1634,y:984,t:1527030718398};\\\", \\\"{x:1635,y:985,t:1527030718414};\\\", \\\"{x:1636,y:985,t:1527030718422};\\\", \\\"{x:1638,y:987,t:1527030718439};\\\", \\\"{x:1638,y:988,t:1527030718455};\\\", \\\"{x:1638,y:989,t:1527030718478};\\\", \\\"{x:1639,y:989,t:1527030718489};\\\", \\\"{x:1639,y:990,t:1527030718507};\\\", \\\"{x:1639,y:991,t:1527030718523};\\\", \\\"{x:1640,y:991,t:1527030718542};\\\", \\\"{x:1640,y:992,t:1527030718556};\\\", \\\"{x:1642,y:994,t:1527030718573};\\\", \\\"{x:1644,y:994,t:1527030718590};\\\", \\\"{x:1647,y:994,t:1527030718606};\\\", \\\"{x:1649,y:994,t:1527030718623};\\\", \\\"{x:1651,y:994,t:1527030718639};\\\", \\\"{x:1654,y:994,t:1527030718656};\\\", \\\"{x:1658,y:994,t:1527030718673};\\\", \\\"{x:1661,y:994,t:1527030718690};\\\", \\\"{x:1666,y:994,t:1527030718706};\\\", \\\"{x:1670,y:994,t:1527030718723};\\\", \\\"{x:1673,y:994,t:1527030718740};\\\", \\\"{x:1675,y:994,t:1527030718757};\\\", \\\"{x:1676,y:994,t:1527030718774};\\\", \\\"{x:1678,y:993,t:1527030718799};\\\", \\\"{x:1680,y:991,t:1527030718807};\\\", \\\"{x:1682,y:991,t:1527030718824};\\\", \\\"{x:1685,y:991,t:1527030718840};\\\", \\\"{x:1687,y:990,t:1527030718857};\\\", \\\"{x:1688,y:988,t:1527030718874};\\\", \\\"{x:1689,y:988,t:1527030718951};\\\", \\\"{x:1690,y:987,t:1527030718967};\\\", \\\"{x:1690,y:986,t:1527030718990};\\\", \\\"{x:1691,y:985,t:1527030719006};\\\", \\\"{x:1691,y:984,t:1527030719023};\\\", \\\"{x:1691,y:983,t:1527030719030};\\\", \\\"{x:1691,y:981,t:1527030719041};\\\", \\\"{x:1691,y:980,t:1527030719062};\\\", \\\"{x:1691,y:979,t:1527030719075};\\\", \\\"{x:1691,y:977,t:1527030719091};\\\", \\\"{x:1691,y:975,t:1527030719108};\\\", \\\"{x:1691,y:972,t:1527030719126};\\\", \\\"{x:1691,y:969,t:1527030719142};\\\", \\\"{x:1691,y:967,t:1527030719159};\\\", \\\"{x:1691,y:966,t:1527030719175};\\\", \\\"{x:1691,y:965,t:1527030719193};\\\", \\\"{x:1691,y:964,t:1527030719208};\\\", \\\"{x:1691,y:963,t:1527030719225};\\\", \\\"{x:1690,y:961,t:1527030719246};\\\", \\\"{x:1689,y:960,t:1527030719294};\\\", \\\"{x:1688,y:959,t:1527030719358};\\\", \\\"{x:1687,y:959,t:1527030719454};\\\", \\\"{x:1686,y:959,t:1527030719462};\\\", \\\"{x:1685,y:958,t:1527030719476};\\\", \\\"{x:1684,y:958,t:1527030719511};\\\", \\\"{x:1683,y:958,t:1527030719526};\\\", \\\"{x:1681,y:958,t:1527030719544};\\\", \\\"{x:1679,y:956,t:1527030719560};\\\", \\\"{x:1678,y:956,t:1527030719578};\\\", \\\"{x:1676,y:956,t:1527030719593};\\\", \\\"{x:1671,y:956,t:1527030719610};\\\", \\\"{x:1668,y:955,t:1527030719627};\\\", \\\"{x:1660,y:953,t:1527030719645};\\\", \\\"{x:1653,y:952,t:1527030719660};\\\", \\\"{x:1649,y:952,t:1527030719677};\\\", \\\"{x:1646,y:951,t:1527030719694};\\\", \\\"{x:1644,y:950,t:1527030719711};\\\", \\\"{x:1642,y:949,t:1527030719727};\\\", \\\"{x:1641,y:949,t:1527030719744};\\\", \\\"{x:1639,y:948,t:1527030719762};\\\", \\\"{x:1637,y:948,t:1527030719782};\\\", \\\"{x:1635,y:948,t:1527030719798};\\\", \\\"{x:1634,y:948,t:1527030719814};\\\", \\\"{x:1633,y:948,t:1527030719828};\\\", \\\"{x:1630,y:948,t:1527030719845};\\\", \\\"{x:1626,y:948,t:1527030719861};\\\", \\\"{x:1623,y:948,t:1527030719878};\\\", \\\"{x:1619,y:948,t:1527030719895};\\\", \\\"{x:1617,y:949,t:1527030719911};\\\", \\\"{x:1613,y:949,t:1527030719928};\\\", \\\"{x:1609,y:951,t:1527030719945};\\\", \\\"{x:1604,y:952,t:1527030719962};\\\", \\\"{x:1596,y:953,t:1527030719978};\\\", \\\"{x:1590,y:953,t:1527030719995};\\\", \\\"{x:1581,y:954,t:1527030720012};\\\", \\\"{x:1570,y:957,t:1527030720030};\\\", \\\"{x:1562,y:958,t:1527030720045};\\\", \\\"{x:1550,y:958,t:1527030720062};\\\", \\\"{x:1543,y:958,t:1527030720080};\\\", \\\"{x:1537,y:958,t:1527030720097};\\\", \\\"{x:1530,y:958,t:1527030720112};\\\", \\\"{x:1523,y:958,t:1527030720129};\\\", \\\"{x:1516,y:958,t:1527030720146};\\\", \\\"{x:1509,y:958,t:1527030720163};\\\", \\\"{x:1501,y:958,t:1527030720179};\\\", \\\"{x:1495,y:958,t:1527030720196};\\\", \\\"{x:1487,y:958,t:1527030720213};\\\", \\\"{x:1480,y:959,t:1527030720229};\\\", \\\"{x:1474,y:959,t:1527030720246};\\\", \\\"{x:1470,y:961,t:1527030720263};\\\", \\\"{x:1465,y:961,t:1527030720280};\\\", \\\"{x:1457,y:962,t:1527030720297};\\\", \\\"{x:1446,y:962,t:1527030720313};\\\", \\\"{x:1436,y:962,t:1527030720330};\\\", \\\"{x:1425,y:963,t:1527030720348};\\\", \\\"{x:1413,y:966,t:1527030720364};\\\", \\\"{x:1403,y:967,t:1527030720380};\\\", \\\"{x:1395,y:968,t:1527030720398};\\\", \\\"{x:1381,y:970,t:1527030720414};\\\", \\\"{x:1374,y:971,t:1527030720431};\\\", \\\"{x:1369,y:972,t:1527030720448};\\\", \\\"{x:1364,y:972,t:1527030720464};\\\", \\\"{x:1359,y:973,t:1527030720481};\\\", \\\"{x:1355,y:974,t:1527030720497};\\\", \\\"{x:1351,y:974,t:1527030720515};\\\", \\\"{x:1346,y:975,t:1527030720532};\\\", \\\"{x:1339,y:976,t:1527030720548};\\\", \\\"{x:1334,y:976,t:1527030720565};\\\", \\\"{x:1328,y:978,t:1527030720581};\\\", \\\"{x:1321,y:979,t:1527030720598};\\\", \\\"{x:1319,y:979,t:1527030720614};\\\", \\\"{x:1318,y:979,t:1527030720632};\\\", \\\"{x:1317,y:979,t:1527030720648};\\\", \\\"{x:1318,y:979,t:1527030721231};\\\", \\\"{x:1319,y:979,t:1527030721247};\\\", \\\"{x:1320,y:979,t:1527030721262};\\\", \\\"{x:1321,y:979,t:1527030721270};\\\", \\\"{x:1323,y:980,t:1527030721286};\\\", \\\"{x:1325,y:980,t:1527030721326};\\\", \\\"{x:1327,y:980,t:1527030721334};\\\", \\\"{x:1329,y:980,t:1527030721352};\\\", \\\"{x:1332,y:980,t:1527030721368};\\\", \\\"{x:1335,y:980,t:1527030721384};\\\", \\\"{x:1340,y:980,t:1527030721401};\\\", \\\"{x:1344,y:980,t:1527030721418};\\\", \\\"{x:1348,y:980,t:1527030721434};\\\", \\\"{x:1351,y:980,t:1527030721451};\\\", \\\"{x:1355,y:982,t:1527030721468};\\\", \\\"{x:1359,y:982,t:1527030721485};\\\", \\\"{x:1364,y:982,t:1527030721501};\\\", \\\"{x:1371,y:983,t:1527030721519};\\\", \\\"{x:1375,y:984,t:1527030721535};\\\", \\\"{x:1379,y:984,t:1527030721552};\\\", \\\"{x:1386,y:986,t:1527030721569};\\\", \\\"{x:1391,y:988,t:1527030721585};\\\", \\\"{x:1396,y:988,t:1527030721602};\\\", \\\"{x:1401,y:989,t:1527030721619};\\\", \\\"{x:1407,y:989,t:1527030721636};\\\", \\\"{x:1411,y:990,t:1527030721652};\\\", \\\"{x:1418,y:990,t:1527030721670};\\\", \\\"{x:1432,y:990,t:1527030721686};\\\", \\\"{x:1443,y:990,t:1527030721702};\\\", \\\"{x:1452,y:990,t:1527030721720};\\\", \\\"{x:1462,y:990,t:1527030721737};\\\", \\\"{x:1476,y:989,t:1527030721752};\\\", \\\"{x:1489,y:985,t:1527030721769};\\\", \\\"{x:1497,y:984,t:1527030721786};\\\", \\\"{x:1503,y:982,t:1527030721803};\\\", \\\"{x:1505,y:981,t:1527030721819};\\\", \\\"{x:1505,y:980,t:1527030721950};\\\", \\\"{x:1505,y:978,t:1527030721982};\\\", \\\"{x:1504,y:977,t:1527030721990};\\\", \\\"{x:1503,y:977,t:1527030722003};\\\", \\\"{x:1499,y:975,t:1527030722020};\\\", \\\"{x:1495,y:973,t:1527030722037};\\\", \\\"{x:1492,y:972,t:1527030722054};\\\", \\\"{x:1490,y:972,t:1527030722070};\\\", \\\"{x:1488,y:971,t:1527030722087};\\\", \\\"{x:1487,y:971,t:1527030722105};\\\", \\\"{x:1486,y:970,t:1527030722543};\\\", \\\"{x:1486,y:967,t:1527030722557};\\\", \\\"{x:1485,y:960,t:1527030722572};\\\", \\\"{x:1483,y:955,t:1527030722590};\\\", \\\"{x:1481,y:948,t:1527030722606};\\\", \\\"{x:1480,y:945,t:1527030722623};\\\", \\\"{x:1479,y:944,t:1527030722639};\\\", \\\"{x:1479,y:943,t:1527030722657};\\\", \\\"{x:1479,y:941,t:1527030722674};\\\", \\\"{x:1479,y:936,t:1527030722690};\\\", \\\"{x:1479,y:933,t:1527030722706};\\\", \\\"{x:1479,y:930,t:1527030722724};\\\", \\\"{x:1479,y:928,t:1527030722740};\\\", \\\"{x:1479,y:927,t:1527030722758};\\\", \\\"{x:1479,y:924,t:1527030722790};\\\", \\\"{x:1479,y:923,t:1527030722822};\\\", \\\"{x:1479,y:922,t:1527030722830};\\\", \\\"{x:1479,y:921,t:1527030722841};\\\", \\\"{x:1480,y:920,t:1527030722857};\\\", \\\"{x:1480,y:918,t:1527030722874};\\\", \\\"{x:1480,y:917,t:1527030722891};\\\", \\\"{x:1480,y:916,t:1527030722907};\\\", \\\"{x:1480,y:915,t:1527030722924};\\\", \\\"{x:1480,y:914,t:1527030722942};\\\", \\\"{x:1480,y:913,t:1527030722957};\\\", \\\"{x:1480,y:912,t:1527030722974};\\\", \\\"{x:1480,y:910,t:1527030722991};\\\", \\\"{x:1481,y:908,t:1527030723008};\\\", \\\"{x:1481,y:907,t:1527030723025};\\\", \\\"{x:1481,y:905,t:1527030723042};\\\", \\\"{x:1481,y:904,t:1527030723062};\\\", \\\"{x:1481,y:902,t:1527030723075};\\\", \\\"{x:1481,y:900,t:1527030723094};\\\", \\\"{x:1481,y:899,t:1527030723108};\\\", \\\"{x:1481,y:897,t:1527030723125};\\\", \\\"{x:1482,y:893,t:1527030723142};\\\", \\\"{x:1482,y:890,t:1527030723158};\\\", \\\"{x:1482,y:889,t:1527030723175};\\\", \\\"{x:1482,y:887,t:1527030723192};\\\", \\\"{x:1482,y:884,t:1527030723208};\\\", \\\"{x:1482,y:883,t:1527030723230};\\\", \\\"{x:1482,y:882,t:1527030723242};\\\", \\\"{x:1482,y:881,t:1527030723259};\\\", \\\"{x:1482,y:879,t:1527030723275};\\\", \\\"{x:1482,y:877,t:1527030723292};\\\", \\\"{x:1482,y:873,t:1527030723310};\\\", \\\"{x:1482,y:869,t:1527030723326};\\\", \\\"{x:1482,y:866,t:1527030723342};\\\", \\\"{x:1482,y:864,t:1527030723366};\\\", \\\"{x:1482,y:863,t:1527030723382};\\\", \\\"{x:1482,y:861,t:1527030723397};\\\", \\\"{x:1482,y:860,t:1527030723414};\\\", \\\"{x:1482,y:858,t:1527030723430};\\\", \\\"{x:1482,y:857,t:1527030723446};\\\", \\\"{x:1482,y:855,t:1527030723462};\\\", \\\"{x:1482,y:854,t:1527030723477};\\\", \\\"{x:1482,y:852,t:1527030723493};\\\", \\\"{x:1482,y:845,t:1527030723509};\\\", \\\"{x:1482,y:840,t:1527030723526};\\\", \\\"{x:1482,y:836,t:1527030723543};\\\", \\\"{x:1482,y:834,t:1527030723560};\\\", \\\"{x:1482,y:833,t:1527030723577};\\\", \\\"{x:1481,y:830,t:1527030723593};\\\", \\\"{x:1480,y:829,t:1527030723613};\\\", \\\"{x:1480,y:828,t:1527030723628};\\\", \\\"{x:1479,y:827,t:1527030723644};\\\", \\\"{x:1478,y:825,t:1527030724030};\\\", \\\"{x:1477,y:825,t:1527030724046};\\\", \\\"{x:1476,y:825,t:1527030724062};\\\", \\\"{x:1475,y:825,t:1527030724079};\\\", \\\"{x:1474,y:825,t:1527030724095};\\\", \\\"{x:1473,y:825,t:1527030725326};\\\", \\\"{x:1472,y:825,t:1527030725334};\\\", \\\"{x:1471,y:826,t:1527030725352};\\\", \\\"{x:1470,y:828,t:1527030725367};\\\", \\\"{x:1468,y:831,t:1527030725384};\\\", \\\"{x:1468,y:832,t:1527030725401};\\\", \\\"{x:1468,y:834,t:1527030725418};\\\", \\\"{x:1468,y:838,t:1527030725435};\\\", \\\"{x:1468,y:841,t:1527030725451};\\\", \\\"{x:1468,y:845,t:1527030725468};\\\", \\\"{x:1468,y:847,t:1527030725486};\\\", \\\"{x:1468,y:851,t:1527030725502};\\\", \\\"{x:1468,y:855,t:1527030725518};\\\", \\\"{x:1468,y:857,t:1527030725536};\\\", \\\"{x:1468,y:860,t:1527030725552};\\\", \\\"{x:1470,y:863,t:1527030725569};\\\", \\\"{x:1471,y:865,t:1527030725586};\\\", \\\"{x:1471,y:867,t:1527030725602};\\\", \\\"{x:1474,y:870,t:1527030725619};\\\", \\\"{x:1474,y:871,t:1527030725635};\\\", \\\"{x:1475,y:874,t:1527030725653};\\\", \\\"{x:1477,y:876,t:1527030725669};\\\", \\\"{x:1479,y:878,t:1527030725685};\\\", \\\"{x:1481,y:881,t:1527030725702};\\\", \\\"{x:1483,y:885,t:1527030725719};\\\", \\\"{x:1484,y:888,t:1527030725736};\\\", \\\"{x:1485,y:889,t:1527030725753};\\\", \\\"{x:1486,y:892,t:1527030725769};\\\", \\\"{x:1487,y:894,t:1527030725786};\\\", \\\"{x:1488,y:897,t:1527030725803};\\\", \\\"{x:1488,y:899,t:1527030725819};\\\", \\\"{x:1490,y:901,t:1527030725836};\\\", \\\"{x:1490,y:903,t:1527030725853};\\\", \\\"{x:1490,y:904,t:1527030725870};\\\", \\\"{x:1490,y:905,t:1527030725959};\\\", \\\"{x:1489,y:905,t:1527030725990};\\\", \\\"{x:1488,y:905,t:1527030726006};\\\", \\\"{x:1488,y:904,t:1527030726045};\\\", \\\"{x:1488,y:903,t:1527030726062};\\\", \\\"{x:1488,y:902,t:1527030726070};\\\", \\\"{x:1488,y:900,t:1527030726088};\\\", \\\"{x:1488,y:898,t:1527030726105};\\\", \\\"{x:1488,y:896,t:1527030726121};\\\", \\\"{x:1488,y:894,t:1527030726138};\\\", \\\"{x:1488,y:890,t:1527030726155};\\\", \\\"{x:1488,y:886,t:1527030726172};\\\", \\\"{x:1488,y:883,t:1527030726188};\\\", \\\"{x:1488,y:880,t:1527030726205};\\\", \\\"{x:1488,y:877,t:1527030726221};\\\", \\\"{x:1488,y:873,t:1527030726238};\\\", \\\"{x:1488,y:871,t:1527030726255};\\\", \\\"{x:1488,y:868,t:1527030726272};\\\", \\\"{x:1487,y:863,t:1527030726288};\\\", \\\"{x:1487,y:861,t:1527030726305};\\\", \\\"{x:1486,y:858,t:1527030726321};\\\", \\\"{x:1486,y:857,t:1527030726339};\\\", \\\"{x:1486,y:856,t:1527030726356};\\\", \\\"{x:1486,y:855,t:1527030726372};\\\", \\\"{x:1486,y:853,t:1527030726388};\\\", \\\"{x:1484,y:851,t:1527030726406};\\\", \\\"{x:1483,y:847,t:1527030726422};\\\", \\\"{x:1483,y:845,t:1527030726439};\\\", \\\"{x:1482,y:844,t:1527030726456};\\\", \\\"{x:1482,y:842,t:1527030726472};\\\", \\\"{x:1481,y:839,t:1527030726490};\\\", \\\"{x:1480,y:838,t:1527030726506};\\\", \\\"{x:1480,y:834,t:1527030726523};\\\", \\\"{x:1480,y:832,t:1527030726557};\\\", \\\"{x:1479,y:831,t:1527030726862};\\\", \\\"{x:1479,y:829,t:1527030727335};\\\", \\\"{x:1479,y:828,t:1527030727351};\\\", \\\"{x:1479,y:825,t:1527030727360};\\\", \\\"{x:1479,y:823,t:1527030727377};\\\", \\\"{x:1479,y:822,t:1527030727393};\\\", \\\"{x:1479,y:819,t:1527030727409};\\\", \\\"{x:1479,y:817,t:1527030727430};\\\", \\\"{x:1479,y:816,t:1527030727444};\\\", \\\"{x:1479,y:815,t:1527030727459};\\\", \\\"{x:1479,y:813,t:1527030727477};\\\", \\\"{x:1479,y:812,t:1527030727493};\\\", \\\"{x:1479,y:809,t:1527030727511};\\\", \\\"{x:1479,y:807,t:1527030727526};\\\", \\\"{x:1479,y:806,t:1527030727544};\\\", \\\"{x:1479,y:804,t:1527030727560};\\\", \\\"{x:1479,y:803,t:1527030727578};\\\", \\\"{x:1479,y:800,t:1527030727594};\\\", \\\"{x:1478,y:797,t:1527030727610};\\\", \\\"{x:1477,y:796,t:1527030727627};\\\", \\\"{x:1477,y:794,t:1527030727645};\\\", \\\"{x:1476,y:790,t:1527030727660};\\\", \\\"{x:1476,y:787,t:1527030727678};\\\", \\\"{x:1476,y:780,t:1527030727694};\\\", \\\"{x:1476,y:775,t:1527030727712};\\\", \\\"{x:1476,y:769,t:1527030727727};\\\", \\\"{x:1476,y:765,t:1527030727745};\\\", \\\"{x:1476,y:761,t:1527030727762};\\\", \\\"{x:1476,y:757,t:1527030727778};\\\", \\\"{x:1476,y:753,t:1527030727794};\\\", \\\"{x:1476,y:750,t:1527030727812};\\\", \\\"{x:1474,y:744,t:1527030727828};\\\", \\\"{x:1474,y:741,t:1527030727844};\\\", \\\"{x:1474,y:737,t:1527030727861};\\\", \\\"{x:1474,y:734,t:1527030727878};\\\", \\\"{x:1474,y:732,t:1527030727896};\\\", \\\"{x:1474,y:730,t:1527030727911};\\\", \\\"{x:1473,y:726,t:1527030727928};\\\", \\\"{x:1472,y:722,t:1527030727945};\\\", \\\"{x:1472,y:720,t:1527030727962};\\\", \\\"{x:1472,y:717,t:1527030727979};\\\", \\\"{x:1472,y:716,t:1527030727996};\\\", \\\"{x:1472,y:714,t:1527030728012};\\\", \\\"{x:1472,y:712,t:1527030728030};\\\", \\\"{x:1472,y:710,t:1527030728046};\\\", \\\"{x:1473,y:706,t:1527030728062};\\\", \\\"{x:1474,y:703,t:1527030728079};\\\", \\\"{x:1474,y:700,t:1527030728095};\\\", \\\"{x:1476,y:698,t:1527030728112};\\\", \\\"{x:1476,y:697,t:1527030728129};\\\", \\\"{x:1478,y:695,t:1527030728146};\\\", \\\"{x:1478,y:694,t:1527030728162};\\\", \\\"{x:1478,y:693,t:1527030728180};\\\", \\\"{x:1478,y:692,t:1527030728197};\\\", \\\"{x:1478,y:690,t:1527030728710};\\\", \\\"{x:1480,y:686,t:1527030728717};\\\", \\\"{x:1480,y:684,t:1527030728732};\\\", \\\"{x:1481,y:675,t:1527030728748};\\\", \\\"{x:1482,y:663,t:1527030728766};\\\", \\\"{x:1482,y:641,t:1527030728781};\\\", \\\"{x:1483,y:632,t:1527030728798};\\\", \\\"{x:1483,y:624,t:1527030728816};\\\", \\\"{x:1485,y:616,t:1527030728832};\\\", \\\"{x:1485,y:610,t:1527030728850};\\\", \\\"{x:1486,y:601,t:1527030728865};\\\", \\\"{x:1487,y:591,t:1527030728883};\\\", \\\"{x:1489,y:584,t:1527030728900};\\\", \\\"{x:1489,y:580,t:1527030728917};\\\", \\\"{x:1489,y:578,t:1527030728933};\\\", \\\"{x:1489,y:577,t:1527030729007};\\\", \\\"{x:1489,y:575,t:1527030729022};\\\", \\\"{x:1489,y:574,t:1527030729034};\\\", \\\"{x:1489,y:569,t:1527030729049};\\\", \\\"{x:1489,y:567,t:1527030729067};\\\", \\\"{x:1488,y:565,t:1527030729084};\\\", \\\"{x:1487,y:563,t:1527030729102};\\\", \\\"{x:1486,y:563,t:1527030729126};\\\", \\\"{x:1485,y:562,t:1527030729134};\\\", \\\"{x:1484,y:559,t:1527030729151};\\\", \\\"{x:1483,y:557,t:1527030729167};\\\", \\\"{x:1481,y:556,t:1527030729183};\\\", \\\"{x:1480,y:555,t:1527030729200};\\\", \\\"{x:1480,y:554,t:1527030729222};\\\", \\\"{x:1480,y:553,t:1527030729262};\\\", \\\"{x:1479,y:553,t:1527030729270};\\\", \\\"{x:1478,y:552,t:1527030729285};\\\", \\\"{x:1478,y:551,t:1527030729300};\\\", \\\"{x:1478,y:548,t:1527030729390};\\\", \\\"{x:1478,y:547,t:1527030729402};\\\", \\\"{x:1478,y:541,t:1527030729419};\\\", \\\"{x:1477,y:532,t:1527030729435};\\\", \\\"{x:1476,y:524,t:1527030729451};\\\", \\\"{x:1475,y:514,t:1527030729469};\\\", \\\"{x:1474,y:505,t:1527030729485};\\\", \\\"{x:1472,y:501,t:1527030729502};\\\", \\\"{x:1472,y:498,t:1527030729519};\\\", \\\"{x:1472,y:497,t:1527030729535};\\\", \\\"{x:1472,y:496,t:1527030729552};\\\", \\\"{x:1472,y:495,t:1527030729569};\\\", \\\"{x:1471,y:491,t:1527030729585};\\\", \\\"{x:1470,y:488,t:1527030729603};\\\", \\\"{x:1470,y:484,t:1527030729619};\\\", \\\"{x:1470,y:482,t:1527030729636};\\\", \\\"{x:1470,y:478,t:1527030729652};\\\", \\\"{x:1470,y:474,t:1527030729669};\\\", \\\"{x:1470,y:469,t:1527030729686};\\\", \\\"{x:1474,y:458,t:1527030729702};\\\", \\\"{x:1476,y:451,t:1527030729720};\\\", \\\"{x:1478,y:445,t:1527030729737};\\\", \\\"{x:1479,y:441,t:1527030729753};\\\", \\\"{x:1479,y:439,t:1527030729769};\\\", \\\"{x:1480,y:437,t:1527030729786};\\\", \\\"{x:1480,y:436,t:1527030729814};\\\", \\\"{x:1480,y:435,t:1527030729829};\\\", \\\"{x:1480,y:434,t:1527030729838};\\\", \\\"{x:1480,y:432,t:1527030729854};\\\", \\\"{x:1480,y:430,t:1527030729870};\\\", \\\"{x:1480,y:429,t:1527030729887};\\\", \\\"{x:1480,y:428,t:1527030729904};\\\", \\\"{x:1480,y:427,t:1527030729921};\\\", \\\"{x:1480,y:426,t:1527030729936};\\\", \\\"{x:1480,y:423,t:1527030729954};\\\", \\\"{x:1481,y:418,t:1527030729971};\\\", \\\"{x:1481,y:411,t:1527030729988};\\\", \\\"{x:1482,y:402,t:1527030730003};\\\", \\\"{x:1482,y:397,t:1527030730021};\\\", \\\"{x:1482,y:390,t:1527030730038};\\\", \\\"{x:1482,y:382,t:1527030730054};\\\", \\\"{x:1482,y:378,t:1527030730071};\\\", \\\"{x:1482,y:375,t:1527030730088};\\\", \\\"{x:1481,y:369,t:1527030730104};\\\", \\\"{x:1480,y:363,t:1527030730122};\\\", \\\"{x:1479,y:356,t:1527030730138};\\\", \\\"{x:1477,y:351,t:1527030730155};\\\", \\\"{x:1476,y:345,t:1527030730171};\\\", \\\"{x:1476,y:342,t:1527030730188};\\\", \\\"{x:1476,y:338,t:1527030730205};\\\", \\\"{x:1476,y:335,t:1527030730221};\\\", \\\"{x:1476,y:327,t:1527030730238};\\\", \\\"{x:1476,y:323,t:1527030730255};\\\", \\\"{x:1476,y:318,t:1527030730271};\\\", \\\"{x:1476,y:314,t:1527030730288};\\\", \\\"{x:1476,y:311,t:1527030730305};\\\", \\\"{x:1476,y:309,t:1527030730322};\\\", \\\"{x:1476,y:306,t:1527030730339};\\\", \\\"{x:1476,y:304,t:1527030730355};\\\", \\\"{x:1476,y:299,t:1527030730372};\\\", \\\"{x:1476,y:296,t:1527030730388};\\\", \\\"{x:1476,y:293,t:1527030730406};\\\", \\\"{x:1476,y:292,t:1527030730422};\\\", \\\"{x:1476,y:291,t:1527030730439};\\\", \\\"{x:1477,y:291,t:1527030730455};\\\", \\\"{x:1477,y:295,t:1527030730598};\\\", \\\"{x:1476,y:300,t:1527030730607};\\\", \\\"{x:1470,y:316,t:1527030730623};\\\", \\\"{x:1459,y:331,t:1527030730640};\\\", \\\"{x:1434,y:350,t:1527030730656};\\\", \\\"{x:1403,y:371,t:1527030730674};\\\", \\\"{x:1324,y:401,t:1527030730691};\\\", \\\"{x:1229,y:431,t:1527030730707};\\\", \\\"{x:1091,y:452,t:1527030730723};\\\", \\\"{x:949,y:473,t:1527030730741};\\\", \\\"{x:817,y:492,t:1527030730757};\\\", \\\"{x:796,y:497,t:1527030730773};\\\", \\\"{x:754,y:504,t:1527030730791};\\\", \\\"{x:739,y:508,t:1527030730807};\\\", \\\"{x:725,y:509,t:1527030730824};\\\", \\\"{x:693,y:510,t:1527030730848};\\\", \\\"{x:668,y:510,t:1527030730864};\\\", \\\"{x:637,y:511,t:1527030730881};\\\", \\\"{x:614,y:511,t:1527030730898};\\\", \\\"{x:594,y:511,t:1527030730914};\\\", \\\"{x:582,y:511,t:1527030730932};\\\", \\\"{x:572,y:511,t:1527030730948};\\\", \\\"{x:566,y:511,t:1527030730965};\\\", \\\"{x:563,y:511,t:1527030730980};\\\", \\\"{x:559,y:512,t:1527030730997};\\\", \\\"{x:562,y:513,t:1527030731142};\\\", \\\"{x:566,y:514,t:1527030731150};\\\", \\\"{x:571,y:517,t:1527030731163};\\\", \\\"{x:577,y:519,t:1527030731181};\\\", \\\"{x:586,y:522,t:1527030731198};\\\", \\\"{x:589,y:523,t:1527030731214};\\\", \\\"{x:592,y:524,t:1527030731230};\\\", \\\"{x:596,y:527,t:1527030731248};\\\", \\\"{x:601,y:530,t:1527030731264};\\\", \\\"{x:609,y:536,t:1527030731281};\\\", \\\"{x:626,y:546,t:1527030731299};\\\", \\\"{x:640,y:555,t:1527030731314};\\\", \\\"{x:642,y:559,t:1527030731332};\\\", \\\"{x:644,y:563,t:1527030731348};\\\", \\\"{x:643,y:570,t:1527030731365};\\\", \\\"{x:642,y:576,t:1527030731382};\\\", \\\"{x:642,y:581,t:1527030731398};\\\", \\\"{x:642,y:583,t:1527030731470};\\\", \\\"{x:642,y:584,t:1527030731482};\\\", \\\"{x:639,y:587,t:1527030731497};\\\", \\\"{x:634,y:588,t:1527030731514};\\\", \\\"{x:632,y:589,t:1527030731530};\\\", \\\"{x:629,y:589,t:1527030731548};\\\", \\\"{x:627,y:589,t:1527030731564};\\\", \\\"{x:626,y:589,t:1527030731582};\\\", \\\"{x:624,y:589,t:1527030731621};\\\", \\\"{x:623,y:590,t:1527030731838};\\\", \\\"{x:623,y:590,t:1527030731914};\\\", \\\"{x:622,y:591,t:1527030731950};\\\", \\\"{x:609,y:591,t:1527030731966};\\\", \\\"{x:587,y:594,t:1527030731982};\\\", \\\"{x:567,y:596,t:1527030731999};\\\", \\\"{x:549,y:598,t:1527030732016};\\\", \\\"{x:530,y:602,t:1527030732032};\\\", \\\"{x:513,y:605,t:1527030732049};\\\", \\\"{x:499,y:607,t:1527030732066};\\\", \\\"{x:476,y:610,t:1527030732082};\\\", \\\"{x:461,y:613,t:1527030732099};\\\", \\\"{x:457,y:614,t:1527030732115};\\\", \\\"{x:454,y:614,t:1527030732132};\\\", \\\"{x:453,y:614,t:1527030732158};\\\", \\\"{x:451,y:613,t:1527030732183};\\\", \\\"{x:449,y:612,t:1527030732199};\\\", \\\"{x:443,y:610,t:1527030732215};\\\", \\\"{x:432,y:608,t:1527030732232};\\\", \\\"{x:424,y:604,t:1527030732249};\\\", \\\"{x:418,y:603,t:1527030732266};\\\", \\\"{x:416,y:602,t:1527030732282};\\\", \\\"{x:414,y:602,t:1527030732298};\\\", \\\"{x:409,y:601,t:1527030732316};\\\", \\\"{x:401,y:601,t:1527030732332};\\\", \\\"{x:397,y:601,t:1527030732349};\\\", \\\"{x:394,y:600,t:1527030732366};\\\", \\\"{x:393,y:600,t:1527030732383};\\\", \\\"{x:391,y:599,t:1527030732399};\\\", \\\"{x:389,y:599,t:1527030732454};\\\", \\\"{x:388,y:599,t:1527030732470};\\\", \\\"{x:387,y:598,t:1527030732483};\\\", \\\"{x:384,y:598,t:1527030732499};\\\", \\\"{x:381,y:597,t:1527030732516};\\\", \\\"{x:382,y:597,t:1527030732782};\\\", \\\"{x:389,y:592,t:1527030732799};\\\", \\\"{x:414,y:574,t:1527030732816};\\\", \\\"{x:460,y:538,t:1527030732833};\\\", \\\"{x:488,y:507,t:1527030732850};\\\", \\\"{x:497,y:487,t:1527030732866};\\\", \\\"{x:497,y:478,t:1527030732883};\\\", \\\"{x:497,y:473,t:1527030732899};\\\", \\\"{x:497,y:472,t:1527030732926};\\\", \\\"{x:495,y:472,t:1527030732933};\\\", \\\"{x:492,y:496,t:1527030732950};\\\", \\\"{x:492,y:526,t:1527030732967};\\\", \\\"{x:492,y:552,t:1527030732983};\\\", \\\"{x:498,y:571,t:1527030733000};\\\", \\\"{x:503,y:581,t:1527030733016};\\\", \\\"{x:505,y:589,t:1527030733033};\\\", \\\"{x:508,y:595,t:1527030733049};\\\", \\\"{x:513,y:606,t:1527030733065};\\\", \\\"{x:516,y:617,t:1527030733083};\\\", \\\"{x:519,y:628,t:1527030733100};\\\", \\\"{x:522,y:636,t:1527030733116};\\\", \\\"{x:526,y:646,t:1527030733133};\\\", \\\"{x:526,y:657,t:1527030733150};\\\", \\\"{x:526,y:663,t:1527030733167};\\\", \\\"{x:526,y:669,t:1527030733182};\\\", \\\"{x:526,y:674,t:1527030733200};\\\", \\\"{x:526,y:678,t:1527030733217};\\\", \\\"{x:526,y:684,t:1527030733233};\\\", \\\"{x:522,y:691,t:1527030733250};\\\", \\\"{x:522,y:696,t:1527030733267};\\\", \\\"{x:521,y:701,t:1527030733283};\\\", \\\"{x:521,y:705,t:1527030733299};\\\", \\\"{x:521,y:708,t:1527030733316};\\\", \\\"{x:521,y:714,t:1527030733333};\\\", \\\"{x:521,y:722,t:1527030733349};\\\", \\\"{x:521,y:724,t:1527030733366};\\\", \\\"{x:521,y:725,t:1527030733383};\\\", \\\"{x:522,y:726,t:1527030733399};\\\", \\\"{x:522,y:727,t:1527030733417};\\\", \\\"{x:522,y:728,t:1527030733432};\\\", \\\"{x:522,y:729,t:1527030733450};\\\", \\\"{x:522,y:730,t:1527030733467};\\\", \\\"{x:522,y:731,t:1527030733483};\\\", \\\"{x:522,y:734,t:1527030733500};\\\", \\\"{x:522,y:736,t:1527030733516};\\\", \\\"{x:521,y:740,t:1527030733533};\\\", \\\"{x:521,y:741,t:1527030733550};\\\", \\\"{x:521,y:742,t:1527030733567};\\\", \\\"{x:521,y:743,t:1527030733598};\\\", \\\"{x:521,y:744,t:1527030733629};\\\", \\\"{x:521,y:745,t:1527030733638};\\\", \\\"{x:521,y:746,t:1527030733654};\\\" ] }, { \\\"rt\\\": 155577, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 807553, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Go to the X-axis and find 12pm, take the forward(right) diagonal up to each point on that line. Each of those points denote an event that starts at 12pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 12441, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 821000, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 20319, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 842332, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 99127, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 942794, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"JVUC6\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"juliet\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"JVUC6\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 361, dom: 873, initialDom: 930",
  "javascriptErrors": []
}