var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060151771ef2e7f11a71decc3ea3d8b1bb0ce2fe"] = {
  "startTime": "2018-06-01T18:19:50.9073775Z",
  "websitePageUrl": "/16",
  "visitTime": 128896,
  "engagementTime": 93512,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "2f93c3115afbeb475816562f3ccb29e7",
    "created": "2018-06-01T18:19:50.904563+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=EPA4S",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "2a715b715f3d17da9ad1a5aef007f20d",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2f93c3115afbeb475816562f3ccb29e7/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 1092,
      "y": 588
    },
    {
      "t": 968,
      "e": 968,
      "ty": 6,
      "x": 588,
      "y": 541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 488,
      "y": 527
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 43941,
      "y": 3451,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1003,
      "e": 1003,
      "ty": 7,
      "x": 407,
      "y": 516,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 168,
      "y": 485
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 165,
      "y": 485
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 7183,
      "y": 4875,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1285,
      "e": 1285,
      "ty": 6,
      "x": 178,
      "y": 550,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1299,
      "e": 1299,
      "ty": 2,
      "x": 178,
      "y": 550
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 199,
      "y": 575
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 202,
      "y": 575
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 11792,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 211,
      "y": 566
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 12804,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1823,
      "e": 1823,
      "ty": 3,
      "x": 211,
      "y": 566,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1824,
      "e": 1824,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1927,
      "e": 1927,
      "ty": 4,
      "x": 12804,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1927,
      "e": 1927,
      "ty": 5,
      "x": 211,
      "y": 566,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2654,
      "e": 2654,
      "ty": 7,
      "x": 220,
      "y": 608,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2699,
      "e": 2699,
      "ty": 2,
      "x": 237,
      "y": 655
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 16288,
      "y": 36285,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 243,
      "y": 665
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 244,
      "y": 658
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 41,
      "x": 16513,
      "y": 36008,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 244,
      "y": 656
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 246,
      "y": 652
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 16850,
      "y": 35509,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 247,
      "y": 649
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 249,
      "y": 646
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 17075,
      "y": 35343,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 250,
      "y": 644
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 23370,
      "y": 62480,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 4256,
      "e": 4256,
      "ty": 6,
      "x": 378,
      "y": 587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 476,
      "y": 563
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 600,
      "y": 541
    },
    {
      "t": 4472,
      "e": 4472,
      "ty": 7,
      "x": 702,
      "y": 531,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 2,
      "x": 739,
      "y": 531
    },
    {
      "t": 4500,
      "e": 4500,
      "ty": 41,
      "x": 3381,
      "y": 27903,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 4600,
      "e": 4600,
      "ty": 2,
      "x": 955,
      "y": 581
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 1050,
      "y": 613
    },
    {
      "t": 4750,
      "e": 4750,
      "ty": 41,
      "x": 21000,
      "y": 36241,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 1146,
      "y": 702
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 1294,
      "y": 856
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 1354,
      "y": 956
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 40026,
      "y": 58587,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 1352,
      "y": 978
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1347,
      "y": 985
    },
    {
      "t": 5250,
      "e": 5250,
      "ty": 41,
      "x": 39533,
      "y": 60664,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 1354,
      "y": 981
    },
    {
      "t": 5400,
      "e": 5400,
      "ty": 2,
      "x": 1355,
      "y": 981
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1355,
      "y": 978
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 35750,
      "y": 37119,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[15] > text"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 1336,
      "y": 978
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 1331,
      "y": 977
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 38053,
      "y": 59948,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 2,
      "x": 1318,
      "y": 975
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 2,
      "x": 1298,
      "y": 975
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 1280,
      "y": 975
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 41,
      "x": 22250,
      "y": 24831,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[13] > text"
    },
    {
      "t": 6100,
      "e": 6100,
      "ty": 2,
      "x": 1239,
      "y": 974
    },
    {
      "t": 6200,
      "e": 6200,
      "ty": 2,
      "x": 1177,
      "y": 970
    },
    {
      "t": 6250,
      "e": 6250,
      "ty": 41,
      "x": 60050,
      "y": 255,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 1170,
      "y": 969
    },
    {
      "t": 6400,
      "e": 6400,
      "ty": 2,
      "x": 1166,
      "y": 969
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 2,
      "x": 1159,
      "y": 964
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 22324,
      "y": 5957,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 1154,
      "y": 964
    },
    {
      "t": 7200,
      "e": 7200,
      "ty": 2,
      "x": 1153,
      "y": 963
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 85,
      "y": 65534,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[6] > line:[9]"
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 2,
      "x": 1158,
      "y": 960
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 26215,
      "y": 58874,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7600,
      "e": 7600,
      "ty": 2,
      "x": 1164,
      "y": 954
    },
    {
      "t": 7700,
      "e": 7700,
      "ty": 2,
      "x": 1172,
      "y": 941
    },
    {
      "t": 7750,
      "e": 7750,
      "ty": 41,
      "x": 27624,
      "y": 56510,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7800,
      "e": 7800,
      "ty": 2,
      "x": 1184,
      "y": 921
    },
    {
      "t": 7900,
      "e": 7900,
      "ty": 2,
      "x": 1197,
      "y": 900
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 2,
      "x": 1199,
      "y": 894
    },
    {
      "t": 8000,
      "e": 8000,
      "ty": 41,
      "x": 29104,
      "y": 54146,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8100,
      "e": 8100,
      "ty": 2,
      "x": 1199,
      "y": 893
    },
    {
      "t": 8200,
      "e": 8200,
      "ty": 2,
      "x": 1069,
      "y": 864
    },
    {
      "t": 8250,
      "e": 8250,
      "ty": 41,
      "x": 4701,
      "y": 44234,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 8300,
      "e": 8300,
      "ty": 2,
      "x": 410,
      "y": 633
    },
    {
      "t": 8342,
      "e": 8342,
      "ty": 6,
      "x": 336,
      "y": 600,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 335,
      "y": 598
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 2,
      "x": 354,
      "y": 582
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 41,
      "x": 28878,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8584,
      "e": 8584,
      "ty": 3,
      "x": 358,
      "y": 575,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8600,
      "e": 8600,
      "ty": 2,
      "x": 358,
      "y": 575
    },
    {
      "t": 8687,
      "e": 8687,
      "ty": 4,
      "x": 29328,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8687,
      "e": 8687,
      "ty": 5,
      "x": 358,
      "y": 575,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8750,
      "e": 8750,
      "ty": 41,
      "x": 29328,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9211,
      "e": 9211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9491,
      "e": 9491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9492,
      "e": 9492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9578,
      "e": 9492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 9618,
      "e": 9532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 9915,
      "e": 9829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9916,
      "e": 9830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9970,
      "e": 9884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lO"
    },
    {
      "t": 10074,
      "e": 9988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10074,
      "e": 9988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10147,
      "e": 10061,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOO"
    },
    {
      "t": 10259,
      "e": 10173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 10260,
      "e": 10174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10354,
      "e": 10268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOOK"
    },
    {
      "t": 10636,
      "e": 10550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10674,
      "e": 10588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lOO"
    },
    {
      "t": 10778,
      "e": 10692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10827,
      "e": 10741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lO"
    },
    {
      "t": 10923,
      "e": 10837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10994,
      "e": 10908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 11082,
      "e": 10996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11139,
      "e": 11053,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 11243,
      "e": 11157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 11247,
      "e": 11161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11348,
      "e": 11262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 11420,
      "e": 11334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 11484,
      "e": 11398,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 11548,
      "e": 11462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11549,
      "e": 11463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11652,
      "e": 11566,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 11740,
      "e": 11654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11740,
      "e": 11654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11796,
      "e": 11710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Loo"
    },
    {
      "t": 12029,
      "e": 11943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 12029,
      "e": 11943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12115,
      "e": 12029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 12236,
      "e": 12150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12237,
      "e": 12151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12331,
      "e": 12245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12483,
      "e": 12397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12483,
      "e": 12397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12572,
      "e": 12486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 12636,
      "e": 12550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12636,
      "e": 12550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12716,
      "e": 12630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12860,
      "e": 12774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12861,
      "e": 12775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12947,
      "e": 12861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12964,
      "e": 12878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12964,
      "e": 12878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13044,
      "e": 12958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13092,
      "e": 13006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13093,
      "e": 13007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13188,
      "e": 13102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 13188,
      "e": 13102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13188,
      "e": 13102,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13284,
      "e": 13198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 13308,
      "e": 13222,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13309,
      "e": 13223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13356,
      "e": 13270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14276,
      "e": 14190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 14277,
      "e": 14191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14403,
      "e": 14317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 14452,
      "e": 14366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14452,
      "e": 14366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14533,
      "e": 14447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14812,
      "e": 14726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14813,
      "e": 14727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14884,
      "e": 14798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 15012,
      "e": 14926,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x a"
    },
    {
      "t": 15093,
      "e": 15007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 15093,
      "e": 15007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15157,
      "e": 15071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 15229,
      "e": 15143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15229,
      "e": 15143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15291,
      "e": 15205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 15339,
      "e": 15253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15339,
      "e": 15253,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15435,
      "e": 15349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 15493,
      "e": 15407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15493,
      "e": 15407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15572,
      "e": 15486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15733,
      "e": 15647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 15733,
      "e": 15647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15828,
      "e": 15742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 15876,
      "e": 15790,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15876,
      "e": 15790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15963,
      "e": 15877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 15979,
      "e": 15893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15980,
      "e": 15894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16051,
      "e": 15965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16052,
      "e": 15966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16083,
      "e": 15997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 16196,
      "e": 16110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16204,
      "e": 16118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16205,
      "e": 16119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16268,
      "e": 16182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16269,
      "e": 16183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16299,
      "e": 16213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 16355,
      "e": 16269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16484,
      "e": 16398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16484,
      "e": 16398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16556,
      "e": 16470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16837,
      "e": 16751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16838,
      "e": 16752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16931,
      "e": 16845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16995,
      "e": 16909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16996,
      "e": 16910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17077,
      "e": 16991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17204,
      "e": 17118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17205,
      "e": 17119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17228,
      "e": 17142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 17364,
      "e": 17278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17365,
      "e": 17279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17460,
      "e": 17374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17572,
      "e": 17486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 17573,
      "e": 17487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17651,
      "e": 17565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 17756,
      "e": 17670,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17756,
      "e": 17670,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17851,
      "e": 17765,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17852,
      "e": 17766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17859,
      "e": 17773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 17956,
      "e": 17870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17988,
      "e": 17902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17989,
      "e": 17903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18092,
      "e": 18006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 18125,
      "e": 18039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18126,
      "e": 18040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18212,
      "e": 18126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18243,
      "e": 18157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18244,
      "e": 18158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18332,
      "e": 18246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18333,
      "e": 18247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18349,
      "e": 18248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 18388,
      "e": 18287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18493,
      "e": 18392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18494,
      "e": 18393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18556,
      "e": 18455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18556,
      "e": 18455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18556,
      "e": 18455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18636,
      "e": 18535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19220,
      "e": 19119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 19572,
      "e": 19471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "55"
    },
    {
      "t": 19574,
      "e": 19473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19643,
      "e": 19542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||&"
    },
    {
      "t": 19668,
      "e": 19567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19716,
      "e": 19615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19716,
      "e": 19615,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19764,
      "e": 19663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19812,
      "e": 19711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19813,
      "e": 19712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19892,
      "e": 19791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19924,
      "e": 19823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19925,
      "e": 19824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19996,
      "e": 19895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20021,
      "e": 19920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20021,
      "e": 19920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20099,
      "e": 19998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 20115,
      "e": 20014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20116,
      "e": 20015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20180,
      "e": 20079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20229,
      "e": 20128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20229,
      "e": 20128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20299,
      "e": 20198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 20316,
      "e": 20215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20316,
      "e": 20215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20372,
      "e": 20271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20484,
      "e": 20383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 20485,
      "e": 20384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20548,
      "e": 20447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 20571,
      "e": 20470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20572,
      "e": 20471,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20684,
      "e": 20583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 20740,
      "e": 20639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 20741,
      "e": 20640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20827,
      "e": 20726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 20892,
      "e": 20791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20892,
      "e": 20791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20957,
      "e": 20856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21020,
      "e": 20919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21020,
      "e": 20919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21084,
      "e": 20983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21141,
      "e": 21040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21141,
      "e": 21040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21205,
      "e": 21104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 21220,
      "e": 21119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21221,
      "e": 21120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21332,
      "e": 21231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21371,
      "e": 21270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21372,
      "e": 21271,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21412,
      "e": 21311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 21675,
      "e": 21574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21675,
      "e": 21574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21740,
      "e": 21639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21837,
      "e": 21736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 21837,
      "e": 21736,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21923,
      "e": 21822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 22004,
      "e": 21903,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22005,
      "e": 21904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22100,
      "e": 21999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 22172,
      "e": 22071,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22172,
      "e": 22071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22268,
      "e": 22167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 22315,
      "e": 22214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22315,
      "e": 22214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22411,
      "e": 22310,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22484,
      "e": 22383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22484,
      "e": 22383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22557,
      "e": 22456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 22604,
      "e": 22503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22605,
      "e": 22504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22692,
      "e": 22591,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22732,
      "e": 22631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22732,
      "e": 22631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22837,
      "e": 22736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22843,
      "e": 22742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22844,
      "e": 22743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22891,
      "e": 22790,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 23003,
      "e": 22902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23004,
      "e": 22903,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23067,
      "e": 22966,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23123,
      "e": 23022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23123,
      "e": 23022,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23187,
      "e": 23086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23244,
      "e": 23143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23245,
      "e": 23144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23331,
      "e": 23230,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 23364,
      "e": 23263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 23364,
      "e": 23263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23404,
      "e": 23303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 23508,
      "e": 23407,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 23509,
      "e": 23408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23604,
      "e": 23503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 23851,
      "e": 23750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23851,
      "e": 23750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23939,
      "e": 23838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24492,
      "e": 24391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 24493,
      "e": 24392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24571,
      "e": 24470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 24780,
      "e": 24679,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24781,
      "e": 24680,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24820,
      "e": 24719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24931,
      "e": 24830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 24932,
      "e": 24831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24996,
      "e": 24895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25125,
      "e": 25024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 25125,
      "e": 25024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25212,
      "e": 25111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 25260,
      "e": 25159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25260,
      "e": 25159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25340,
      "e": 25239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25476,
      "e": 25375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25477,
      "e": 25376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25563,
      "e": 25462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 25748,
      "e": 25647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25749,
      "e": 25648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25804,
      "e": 25703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25923,
      "e": 25822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25924,
      "e": 25823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26013,
      "e": 25912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26269,
      "e": 26168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 26270,
      "e": 26169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26366,
      "e": 26171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 26507,
      "e": 26312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 26507,
      "e": 26312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26587,
      "e": 26392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 26684,
      "e": 26489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26685,
      "e": 26490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26747,
      "e": 26552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 26876,
      "e": 26681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26876,
      "e": 26681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26963,
      "e": 26768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 27323,
      "e": 27128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27324,
      "e": 27129,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27403,
      "e": 27208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27491,
      "e": 27296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27492,
      "e": 27297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27571,
      "e": 27376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27652,
      "e": 27457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27652,
      "e": 27457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27708,
      "e": 27513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 27764,
      "e": 27569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27765,
      "e": 27570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27860,
      "e": 27665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 27900,
      "e": 27705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27900,
      "e": 27705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27980,
      "e": 27785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28084,
      "e": 27889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 28084,
      "e": 27889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28155,
      "e": 27960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 28213,
      "e": 28018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28213,
      "e": 28018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28283,
      "e": 28088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28412,
      "e": 28217,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go"
    },
    {
      "t": 30677,
      "e": 30482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30678,
      "e": 30483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30779,
      "e": 30584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31108,
      "e": 30913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 31109,
      "e": 30914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31195,
      "e": 31000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 31372,
      "e": 31177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31372,
      "e": 31177,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31459,
      "e": 31264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 31604,
      "e": 31409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 31604,
      "e": 31409,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31692,
      "e": 31497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 32164,
      "e": 31969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32165,
      "e": 31970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32260,
      "e": 32065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32389,
      "e": 32194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32389,
      "e": 32194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32452,
      "e": 32257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 32540,
      "e": 32345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32541,
      "e": 32346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32603,
      "e": 32408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 32708,
      "e": 32513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32709,
      "e": 32514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32779,
      "e": 32584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 33085,
      "e": 32890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33172,
      "e": 32977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go dignal"
    },
    {
      "t": 33428,
      "e": 33233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33491,
      "e": 33296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go digna"
    },
    {
      "t": 33611,
      "e": 33416,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go digna"
    },
    {
      "t": 33611,
      "e": 33416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33675,
      "e": 33480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go dign"
    },
    {
      "t": 33811,
      "e": 33480,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go dign"
    },
    {
      "t": 34108,
      "e": 33777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34204,
      "e": 33873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go dig"
    },
    {
      "t": 34883,
      "e": 34552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34980,
      "e": 34649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go di"
    },
    {
      "t": 35540,
      "e": 35209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35580,
      "e": 35249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go d"
    },
    {
      "t": 35692,
      "e": 35361,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35755,
      "e": 35424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go "
    },
    {
      "t": 39325,
      "e": 38994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 39325,
      "e": 38994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39428,
      "e": 39097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 39612,
      "e": 39281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 39614,
      "e": 39283,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39699,
      "e": 39368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 39811,
      "e": 39480,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go up"
    },
    {
      "t": 40009,
      "e": 39678,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40644,
      "e": 40313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40723,
      "e": 40392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go u"
    },
    {
      "t": 40844,
      "e": 40513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40907,
      "e": 40576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go "
    },
    {
      "t": 41010,
      "e": 40679,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go "
    },
    {
      "t": 43868,
      "e": 43537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 43869,
      "e": 43538,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43971,
      "e": 43640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 44051,
      "e": 43720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44052,
      "e": 43721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44139,
      "e": 43808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 44300,
      "e": 43969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44300,
      "e": 43969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44372,
      "e": 44041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 44836,
      "e": 44505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 44836,
      "e": 44505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44915,
      "e": 44584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 45076,
      "e": 44745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 45077,
      "e": 44746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45171,
      "e": 44840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 45259,
      "e": 44928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45260,
      "e": 44929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45316,
      "e": 44985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 45484,
      "e": 45153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45484,
      "e": 45153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45540,
      "e": 45209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 45652,
      "e": 45321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45652,
      "e": 45321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45715,
      "e": 45384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 45755,
      "e": 45424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 45755,
      "e": 45424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45835,
      "e": 45504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 45852,
      "e": 45521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45852,
      "e": 45521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45947,
      "e": 45616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46299,
      "e": 45968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46301,
      "e": 45970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46379,
      "e": 46048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 46427,
      "e": 46096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 46428,
      "e": 46097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46524,
      "e": 46193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 46548,
      "e": 46217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 46549,
      "e": 46218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46597,
      "e": 46266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 46699,
      "e": 46368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 46701,
      "e": 46370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46747,
      "e": 46416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 46859,
      "e": 46528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46860,
      "e": 46529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46948,
      "e": 46617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47509,
      "e": 47178,
      "ty": 2,
      "x": 354,
      "y": 573
    },
    {
      "t": 47509,
      "e": 47178,
      "ty": 41,
      "x": 28878,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47610,
      "e": 47279,
      "ty": 2,
      "x": 388,
      "y": 573
    },
    {
      "t": 47709,
      "e": 47378,
      "ty": 2,
      "x": 412,
      "y": 583
    },
    {
      "t": 47760,
      "e": 47429,
      "ty": 41,
      "x": 33712,
      "y": 51995,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47809,
      "e": 47478,
      "ty": 2,
      "x": 353,
      "y": 595
    },
    {
      "t": 47910,
      "e": 47579,
      "ty": 2,
      "x": 273,
      "y": 580
    },
    {
      "t": 48009,
      "e": 47678,
      "ty": 2,
      "x": 214,
      "y": 573
    },
    {
      "t": 48009,
      "e": 47678,
      "ty": 41,
      "x": 13141,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48110,
      "e": 47779,
      "ty": 2,
      "x": 214,
      "y": 566
    },
    {
      "t": 48209,
      "e": 47878,
      "ty": 2,
      "x": 215,
      "y": 553
    },
    {
      "t": 48260,
      "e": 47929,
      "ty": 41,
      "x": 13478,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48303,
      "e": 47972,
      "ty": 3,
      "x": 217,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48310,
      "e": 47979,
      "ty": 2,
      "x": 217,
      "y": 551
    },
    {
      "t": 48431,
      "e": 48100,
      "ty": 4,
      "x": 13478,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49310,
      "e": 48979,
      "ty": 2,
      "x": 238,
      "y": 559
    },
    {
      "t": 49409,
      "e": 49078,
      "ty": 2,
      "x": 320,
      "y": 548
    },
    {
      "t": 49411,
      "e": 49080,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go diagonally right"
    },
    {
      "t": 49509,
      "e": 49178,
      "ty": 2,
      "x": 333,
      "y": 544
    },
    {
      "t": 49510,
      "e": 49179,
      "ty": 41,
      "x": 26518,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49610,
      "e": 49279,
      "ty": 2,
      "x": 335,
      "y": 544
    },
    {
      "t": 49624,
      "e": 49293,
      "ty": 3,
      "x": 335,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49727,
      "e": 49396,
      "ty": 4,
      "x": 26743,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49728,
      "e": 49397,
      "ty": 5,
      "x": 335,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49759,
      "e": 49428,
      "ty": 41,
      "x": 26743,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50009,
      "e": 49678,
      "ty": 2,
      "x": 336,
      "y": 544
    },
    {
      "t": 50010,
      "e": 49679,
      "ty": 41,
      "x": 26855,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50010,
      "e": 49679,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50760,
      "e": 50429,
      "ty": 41,
      "x": 29103,
      "y": 56041,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50769,
      "e": 50438,
      "ty": 7,
      "x": 410,
      "y": 693,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50810,
      "e": 50479,
      "ty": 2,
      "x": 524,
      "y": 867
    },
    {
      "t": 50910,
      "e": 50579,
      "ty": 2,
      "x": 1299,
      "y": 1186
    },
    {
      "t": 51009,
      "e": 50678,
      "ty": 2,
      "x": 1424,
      "y": 1177
    },
    {
      "t": 51009,
      "e": 50678,
      "ty": 41,
      "x": 48763,
      "y": 64759,
      "ta": "> div.stimulus"
    },
    {
      "t": 51109,
      "e": 50778,
      "ty": 2,
      "x": 1447,
      "y": 1102
    },
    {
      "t": 51210,
      "e": 50879,
      "ty": 2,
      "x": 1360,
      "y": 1031
    },
    {
      "t": 51260,
      "e": 50929,
      "ty": 41,
      "x": 39463,
      "y": 63457,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 51309,
      "e": 50978,
      "ty": 2,
      "x": 1273,
      "y": 1003
    },
    {
      "t": 51410,
      "e": 51079,
      "ty": 2,
      "x": 1149,
      "y": 966
    },
    {
      "t": 51510,
      "e": 51179,
      "ty": 2,
      "x": 1185,
      "y": 922
    },
    {
      "t": 51510,
      "e": 51179,
      "ty": 41,
      "x": 28117,
      "y": 56152,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 51610,
      "e": 51279,
      "ty": 2,
      "x": 1193,
      "y": 901
    },
    {
      "t": 51710,
      "e": 51379,
      "ty": 2,
      "x": 1202,
      "y": 874
    },
    {
      "t": 51760,
      "e": 51429,
      "ty": 41,
      "x": 29949,
      "y": 50995,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 51810,
      "e": 51479,
      "ty": 2,
      "x": 1218,
      "y": 826
    },
    {
      "t": 51909,
      "e": 51578,
      "ty": 2,
      "x": 1240,
      "y": 780
    },
    {
      "t": 52010,
      "e": 51679,
      "ty": 2,
      "x": 1267,
      "y": 736
    },
    {
      "t": 52010,
      "e": 51679,
      "ty": 41,
      "x": 33896,
      "y": 42830,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 52110,
      "e": 51779,
      "ty": 2,
      "x": 1292,
      "y": 696
    },
    {
      "t": 52209,
      "e": 51878,
      "ty": 2,
      "x": 1340,
      "y": 611
    },
    {
      "t": 52260,
      "e": 51929,
      "ty": 41,
      "x": 40449,
      "y": 30726,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 52310,
      "e": 51979,
      "ty": 2,
      "x": 1370,
      "y": 538
    },
    {
      "t": 52410,
      "e": 52079,
      "ty": 2,
      "x": 1382,
      "y": 513
    },
    {
      "t": 52510,
      "e": 52179,
      "ty": 2,
      "x": 1393,
      "y": 490
    },
    {
      "t": 52510,
      "e": 52179,
      "ty": 41,
      "x": 42775,
      "y": 25211,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 52610,
      "e": 52279,
      "ty": 2,
      "x": 1402,
      "y": 469
    },
    {
      "t": 52760,
      "e": 52429,
      "ty": 41,
      "x": 41224,
      "y": 26930,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 52810,
      "e": 52479,
      "ty": 2,
      "x": 1247,
      "y": 592
    },
    {
      "t": 52910,
      "e": 52579,
      "ty": 2,
      "x": 571,
      "y": 702
    },
    {
      "t": 52953,
      "e": 52622,
      "ty": 6,
      "x": 427,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 53010,
      "e": 52679,
      "ty": 2,
      "x": 425,
      "y": 687
    },
    {
      "t": 53010,
      "e": 52679,
      "ty": 41,
      "x": 47188,
      "y": 62191,
      "ta": "#strategyButton"
    },
    {
      "t": 54117,
      "e": 53786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54117,
      "e": 53786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54194,
      "e": 53863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go diagonally right "
    },
    {
      "t": 54348,
      "e": 54017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 54348,
      "e": 54017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54443,
      "e": 54112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 54468,
      "e": 54137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 54468,
      "e": 54137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54547,
      "e": 54216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 54619,
      "e": 54288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 54621,
      "e": 54290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54699,
      "e": 54368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 54731,
      "e": 54400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 54731,
      "e": 54400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54819,
      "e": 54488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 54820,
      "e": 54489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54827,
      "e": 54496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 54915,
      "e": 54584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54923,
      "e": 54592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54923,
      "e": 54592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55019,
      "e": 54688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56684,
      "e": 56353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 56684,
      "e": 56353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56747,
      "e": 56416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 56798,
      "e": 56467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 56798,
      "e": 56467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56875,
      "e": 56544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 57019,
      "e": 56688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 57020,
      "e": 56689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57035,
      "e": 56704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 57131,
      "e": 56800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 57132,
      "e": 56801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57227,
      "e": 56896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 57299,
      "e": 56968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57299,
      "e": 56968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57356,
      "e": 57025,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57492,
      "e": 57161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 57492,
      "e": 57161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57563,
      "e": 57232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 57683,
      "e": 57352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 57684,
      "e": 57353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57731,
      "e": 57400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 57771,
      "e": 57440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57771,
      "e": 57440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57851,
      "e": 57520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57875,
      "e": 57544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57876,
      "e": 57545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57963,
      "e": 57632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57988,
      "e": 57657,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57988,
      "e": 57657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58059,
      "e": 57728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 58099,
      "e": 57768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 58100,
      "e": 57769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58180,
      "e": 57849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 58228,
      "e": 57897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 58228,
      "e": 57897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58323,
      "e": 57992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 58387,
      "e": 58056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58387,
      "e": 58056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58508,
      "e": 58177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58556,
      "e": 58225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 58796,
      "e": 58465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 58796,
      "e": 58465,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58915,
      "e": 58584,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 58947,
      "e": 58616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 59092,
      "e": 58761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59092,
      "e": 58761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59187,
      "e": 58856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59292,
      "e": 58961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 59292,
      "e": 58961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59388,
      "e": 59057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 59419,
      "e": 59088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 59421,
      "e": 59090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59516,
      "e": 59185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 59532,
      "e": 59201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 59532,
      "e": 59201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59643,
      "e": 59312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 59667,
      "e": 59336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59668,
      "e": 59337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59747,
      "e": 59416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59979,
      "e": 59648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60009,
      "e": 59678,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60156,
      "e": 59825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 60156,
      "e": 59825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60267,
      "e": 59936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 60275,
      "e": 59944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61372,
      "e": 61041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 61372,
      "e": 61041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61434,
      "e": 61103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 61709,
      "e": 61378,
      "ty": 2,
      "x": 423,
      "y": 682
    },
    {
      "t": 61759,
      "e": 61428,
      "ty": 41,
      "x": 45550,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 61809,
      "e": 61478,
      "ty": 2,
      "x": 420,
      "y": 664
    },
    {
      "t": 61831,
      "e": 61500,
      "ty": 3,
      "x": 420,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 61832,
      "e": 61501,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis where it says start & end time, then for starting, look at 12pm and go diagonally right which will hit the M and L."
    },
    {
      "t": 61832,
      "e": 61501,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61833,
      "e": 61502,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 61927,
      "e": 61596,
      "ty": 4,
      "x": 44457,
      "y": 17859,
      "ta": "#strategyButton"
    },
    {
      "t": 61946,
      "e": 61615,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 61946,
      "e": 61615,
      "ty": 5,
      "x": 420,
      "y": 664,
      "ta": "#strategyButton"
    },
    {
      "t": 61952,
      "e": 61621,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 62009,
      "e": 61678,
      "ty": 41,
      "x": 14188,
      "y": 36340,
      "ta": "html > body"
    },
    {
      "t": 62209,
      "e": 61878,
      "ty": 2,
      "x": 425,
      "y": 663
    },
    {
      "t": 62259,
      "e": 61928,
      "ty": 41,
      "x": 15910,
      "y": 37947,
      "ta": "html > body"
    },
    {
      "t": 62310,
      "e": 61979,
      "ty": 2,
      "x": 470,
      "y": 694
    },
    {
      "t": 62510,
      "e": 62179,
      "ty": 41,
      "x": 15910,
      "y": 38002,
      "ta": "html > body"
    },
    {
      "t": 62954,
      "e": 62623,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 63409,
      "e": 63078,
      "ty": 2,
      "x": 506,
      "y": 681
    },
    {
      "t": 63509,
      "e": 63178,
      "ty": 2,
      "x": 655,
      "y": 633
    },
    {
      "t": 63510,
      "e": 63179,
      "ty": 41,
      "x": 22281,
      "y": 34623,
      "ta": "html > body"
    },
    {
      "t": 63609,
      "e": 63278,
      "ty": 2,
      "x": 740,
      "y": 585
    },
    {
      "t": 63709,
      "e": 63378,
      "ty": 2,
      "x": 827,
      "y": 547
    },
    {
      "t": 63759,
      "e": 63428,
      "ty": 41,
      "x": 5190,
      "y": 38757,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 63809,
      "e": 63478,
      "ty": 2,
      "x": 836,
      "y": 545
    },
    {
      "t": 63896,
      "e": 63565,
      "ty": 6,
      "x": 850,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 63909,
      "e": 63578,
      "ty": 2,
      "x": 850,
      "y": 555
    },
    {
      "t": 64010,
      "e": 63679,
      "ty": 41,
      "x": 9516,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64010,
      "e": 63679,
      "ty": 2,
      "x": 852,
      "y": 557
    },
    {
      "t": 64023,
      "e": 63692,
      "ty": 3,
      "x": 853,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64023,
      "e": 63692,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64109,
      "e": 63778,
      "ty": 2,
      "x": 854,
      "y": 557
    },
    {
      "t": 64127,
      "e": 63796,
      "ty": 4,
      "x": 9949,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64128,
      "e": 63797,
      "ty": 5,
      "x": 854,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64209,
      "e": 63878,
      "ty": 2,
      "x": 856,
      "y": 557
    },
    {
      "t": 64260,
      "e": 63929,
      "ty": 41,
      "x": 10381,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64669,
      "e": 64338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 64669,
      "e": 64338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64691,
      "e": 64360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 64732,
      "e": 64401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 64733,
      "e": 64402,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 64771,
      "e": 64440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 65109,
      "e": 64778,
      "ty": 2,
      "x": 856,
      "y": 566
    },
    {
      "t": 65113,
      "e": 64782,
      "ty": 7,
      "x": 856,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65210,
      "e": 64879,
      "ty": 2,
      "x": 851,
      "y": 620
    },
    {
      "t": 65259,
      "e": 64928,
      "ty": 41,
      "x": 9300,
      "y": 40871,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 65280,
      "e": 64949,
      "ty": 6,
      "x": 851,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65309,
      "e": 64978,
      "ty": 2,
      "x": 851,
      "y": 648
    },
    {
      "t": 65436,
      "e": 65105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 65437,
      "e": 65106,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 65437,
      "e": 65106,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 65438,
      "e": 65107,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65499,
      "e": 65168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 65510,
      "e": 65179,
      "ty": 41,
      "x": 9300,
      "y": 3120,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65609,
      "e": 65278,
      "ty": 2,
      "x": 851,
      "y": 649
    },
    {
      "t": 65709,
      "e": 65378,
      "ty": 2,
      "x": 851,
      "y": 651
    },
    {
      "t": 65760,
      "e": 65429,
      "ty": 41,
      "x": 9300,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 65909,
      "e": 65578,
      "ty": 2,
      "x": 851,
      "y": 653
    },
    {
      "t": 66009,
      "e": 65678,
      "ty": 41,
      "x": 9300,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66404,
      "e": 66073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 66674,
      "e": 66343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 66674,
      "e": 66343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66731,
      "e": 66400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 66932,
      "e": 66601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 66932,
      "e": 66601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67003,
      "e": 66672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 67179,
      "e": 66848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 67510,
      "e": 67179,
      "ty": 2,
      "x": 870,
      "y": 654
    },
    {
      "t": 67510,
      "e": 67179,
      "ty": 41,
      "x": 13409,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67566,
      "e": 67235,
      "ty": 7,
      "x": 908,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67609,
      "e": 67278,
      "ty": 2,
      "x": 909,
      "y": 669
    },
    {
      "t": 67682,
      "e": 67351,
      "ty": 6,
      "x": 916,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67710,
      "e": 67379,
      "ty": 2,
      "x": 920,
      "y": 681
    },
    {
      "t": 67759,
      "e": 67428,
      "ty": 41,
      "x": 14471,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67810,
      "e": 67479,
      "ty": 2,
      "x": 928,
      "y": 687
    },
    {
      "t": 67848,
      "e": 67517,
      "ty": 3,
      "x": 928,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67848,
      "e": 67517,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 67849,
      "e": 67518,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67850,
      "e": 67519,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67936,
      "e": 67605,
      "ty": 4,
      "x": 16532,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67937,
      "e": 67606,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67939,
      "e": 67608,
      "ty": 5,
      "x": 928,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67939,
      "e": 67608,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 68009,
      "e": 67678,
      "ty": 41,
      "x": 31682,
      "y": 37614,
      "ta": "html > body"
    },
    {
      "t": 68954,
      "e": 68623,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 69509,
      "e": 69178,
      "ty": 2,
      "x": 930,
      "y": 685
    },
    {
      "t": 69509,
      "e": 69178,
      "ty": 41,
      "x": 25768,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 69609,
      "e": 69278,
      "ty": 2,
      "x": 936,
      "y": 680
    },
    {
      "t": 69761,
      "e": 69279,
      "ty": 41,
      "x": 30764,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 69909,
      "e": 69427,
      "ty": 2,
      "x": 897,
      "y": 558
    },
    {
      "t": 70010,
      "e": 69528,
      "ty": 2,
      "x": 761,
      "y": 155
    },
    {
      "t": 70010,
      "e": 69528,
      "ty": 41,
      "x": 25931,
      "y": 8143,
      "ta": "html > body"
    },
    {
      "t": 70109,
      "e": 69627,
      "ty": 2,
      "x": 756,
      "y": 33
    },
    {
      "t": 70209,
      "e": 69727,
      "ty": 2,
      "x": 796,
      "y": 78
    },
    {
      "t": 70260,
      "e": 69778,
      "ty": 41,
      "x": 27412,
      "y": 6370,
      "ta": "html > body"
    },
    {
      "t": 70310,
      "e": 69828,
      "ty": 2,
      "x": 805,
      "y": 157
    },
    {
      "t": 70410,
      "e": 69928,
      "ty": 2,
      "x": 809,
      "y": 173
    },
    {
      "t": 70510,
      "e": 70028,
      "ty": 2,
      "x": 841,
      "y": 210
    },
    {
      "t": 70510,
      "e": 70028,
      "ty": 41,
      "x": 4646,
      "y": 12858,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 70609,
      "e": 70127,
      "ty": 2,
      "x": 845,
      "y": 224
    },
    {
      "t": 70710,
      "e": 70228,
      "ty": 2,
      "x": 845,
      "y": 229
    },
    {
      "t": 70760,
      "e": 70278,
      "ty": 41,
      "x": 18488,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70810,
      "e": 70328,
      "ty": 2,
      "x": 843,
      "y": 230
    },
    {
      "t": 71009,
      "e": 70527,
      "ty": 2,
      "x": 843,
      "y": 231
    },
    {
      "t": 71010,
      "e": 70528,
      "ty": 41,
      "x": 17669,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 71210,
      "e": 70728,
      "ty": 2,
      "x": 843,
      "y": 233
    },
    {
      "t": 71260,
      "e": 70778,
      "ty": 41,
      "x": 16031,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 71288,
      "e": 70806,
      "ty": 3,
      "x": 841,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 71310,
      "e": 70828,
      "ty": 2,
      "x": 841,
      "y": 235
    },
    {
      "t": 71424,
      "e": 70942,
      "ty": 4,
      "x": 16031,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 71424,
      "e": 70942,
      "ty": 5,
      "x": 841,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 71425,
      "e": 70943,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71426,
      "e": 70944,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 71713,
      "e": 71231,
      "ty": 6,
      "x": 838,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71719,
      "e": 71237,
      "ty": 2,
      "x": 838,
      "y": 242
    },
    {
      "t": 71728,
      "e": 71246,
      "ty": 7,
      "x": 836,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 71762,
      "e": 71280,
      "ty": 6,
      "x": 831,
      "y": 262,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 71769,
      "e": 71287,
      "ty": 41,
      "x": 23079,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 71778,
      "e": 71296,
      "ty": 7,
      "x": 829,
      "y": 276,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 71795,
      "e": 71313,
      "ty": 6,
      "x": 829,
      "y": 291,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 71811,
      "e": 71329,
      "ty": 7,
      "x": 831,
      "y": 310,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 71819,
      "e": 71337,
      "ty": 2,
      "x": 831,
      "y": 310
    },
    {
      "t": 71828,
      "e": 71346,
      "ty": 6,
      "x": 837,
      "y": 328,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 71844,
      "e": 71362,
      "ty": 7,
      "x": 839,
      "y": 339,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 71919,
      "e": 71437,
      "ty": 2,
      "x": 844,
      "y": 369
    },
    {
      "t": 72020,
      "e": 71538,
      "ty": 2,
      "x": 846,
      "y": 382
    },
    {
      "t": 72020,
      "e": 71538,
      "ty": 41,
      "x": 5832,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 72119,
      "e": 71637,
      "ty": 2,
      "x": 855,
      "y": 414
    },
    {
      "t": 72220,
      "e": 71738,
      "ty": 2,
      "x": 856,
      "y": 424
    },
    {
      "t": 72270,
      "e": 71788,
      "ty": 41,
      "x": 40476,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 72319,
      "e": 71837,
      "ty": 2,
      "x": 856,
      "y": 425
    },
    {
      "t": 72419,
      "e": 71937,
      "ty": 2,
      "x": 856,
      "y": 426
    },
    {
      "t": 72520,
      "e": 72038,
      "ty": 41,
      "x": 8206,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 72620,
      "e": 72138,
      "ty": 2,
      "x": 854,
      "y": 447
    },
    {
      "t": 72719,
      "e": 72138,
      "ty": 2,
      "x": 850,
      "y": 478
    },
    {
      "t": 72770,
      "e": 72189,
      "ty": 41,
      "x": 22060,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 72819,
      "e": 72238,
      "ty": 2,
      "x": 844,
      "y": 499
    },
    {
      "t": 72919,
      "e": 72338,
      "ty": 2,
      "x": 841,
      "y": 521
    },
    {
      "t": 73019,
      "e": 72438,
      "ty": 2,
      "x": 841,
      "y": 538
    },
    {
      "t": 73019,
      "e": 72438,
      "ty": 41,
      "x": 4646,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 73119,
      "e": 72538,
      "ty": 2,
      "x": 841,
      "y": 540
    },
    {
      "t": 73269,
      "e": 72688,
      "ty": 41,
      "x": 24081,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 73319,
      "e": 72738,
      "ty": 2,
      "x": 846,
      "y": 511
    },
    {
      "t": 73419,
      "e": 72838,
      "ty": 2,
      "x": 846,
      "y": 507
    },
    {
      "t": 73519,
      "e": 72938,
      "ty": 2,
      "x": 849,
      "y": 488
    },
    {
      "t": 73520,
      "e": 72939,
      "ty": 41,
      "x": 6544,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 73620,
      "e": 73039,
      "ty": 2,
      "x": 849,
      "y": 483
    },
    {
      "t": 73719,
      "e": 73138,
      "ty": 2,
      "x": 847,
      "y": 474
    },
    {
      "t": 73769,
      "e": 73188,
      "ty": 41,
      "x": 24922,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 73820,
      "e": 73239,
      "ty": 2,
      "x": 845,
      "y": 470
    },
    {
      "t": 74014,
      "e": 73433,
      "ty": 6,
      "x": 838,
      "y": 470,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 74019,
      "e": 73438,
      "ty": 2,
      "x": 838,
      "y": 470
    },
    {
      "t": 74019,
      "e": 73438,
      "ty": 41,
      "x": 58367,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 74122,
      "e": 73541,
      "ty": 3,
      "x": 838,
      "y": 470,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 74122,
      "e": 73541,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 74123,
      "e": 73542,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 74201,
      "e": 73620,
      "ty": 4,
      "x": 58367,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 74201,
      "e": 73620,
      "ty": 5,
      "x": 838,
      "y": 470,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 74201,
      "e": 73620,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 74497,
      "e": 73916,
      "ty": 7,
      "x": 837,
      "y": 479,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 74519,
      "e": 73938,
      "ty": 2,
      "x": 842,
      "y": 500
    },
    {
      "t": 74519,
      "e": 73938,
      "ty": 41,
      "x": 18469,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 74619,
      "e": 74038,
      "ty": 2,
      "x": 880,
      "y": 622
    },
    {
      "t": 74719,
      "e": 74138,
      "ty": 2,
      "x": 864,
      "y": 661
    },
    {
      "t": 74769,
      "e": 74188,
      "ty": 41,
      "x": 10104,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 75219,
      "e": 74638,
      "ty": 2,
      "x": 862,
      "y": 666
    },
    {
      "t": 75270,
      "e": 74689,
      "ty": 41,
      "x": 10895,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 75320,
      "e": 74739,
      "ty": 2,
      "x": 862,
      "y": 678
    },
    {
      "t": 75420,
      "e": 74839,
      "ty": 2,
      "x": 860,
      "y": 680
    },
    {
      "t": 75519,
      "e": 74938,
      "ty": 2,
      "x": 858,
      "y": 684
    },
    {
      "t": 75519,
      "e": 74938,
      "ty": 41,
      "x": 9821,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 75719,
      "e": 75138,
      "ty": 2,
      "x": 855,
      "y": 693
    },
    {
      "t": 75769,
      "e": 75188,
      "ty": 41,
      "x": 7957,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 75819,
      "e": 75238,
      "ty": 2,
      "x": 849,
      "y": 722
    },
    {
      "t": 75919,
      "e": 75338,
      "ty": 2,
      "x": 844,
      "y": 737
    },
    {
      "t": 76019,
      "e": 75438,
      "ty": 2,
      "x": 842,
      "y": 748
    },
    {
      "t": 76019,
      "e": 75438,
      "ty": 41,
      "x": 4883,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 76119,
      "e": 75538,
      "ty": 2,
      "x": 842,
      "y": 757
    },
    {
      "t": 76220,
      "e": 75639,
      "ty": 2,
      "x": 843,
      "y": 766
    },
    {
      "t": 76269,
      "e": 75688,
      "ty": 41,
      "x": 5358,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 76318,
      "e": 75737,
      "ty": 2,
      "x": 846,
      "y": 779
    },
    {
      "t": 76419,
      "e": 75838,
      "ty": 2,
      "x": 849,
      "y": 796
    },
    {
      "t": 76519,
      "e": 75938,
      "ty": 2,
      "x": 851,
      "y": 818
    },
    {
      "t": 76519,
      "e": 75938,
      "ty": 41,
      "x": 17458,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 76619,
      "e": 76038,
      "ty": 2,
      "x": 850,
      "y": 823
    },
    {
      "t": 76719,
      "e": 76138,
      "ty": 2,
      "x": 843,
      "y": 827
    },
    {
      "t": 76771,
      "e": 76139,
      "ty": 41,
      "x": 5121,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 76920,
      "e": 76288,
      "ty": 2,
      "x": 840,
      "y": 827
    },
    {
      "t": 77000,
      "e": 76368,
      "ty": 6,
      "x": 836,
      "y": 820,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 77019,
      "e": 76387,
      "ty": 2,
      "x": 836,
      "y": 818
    },
    {
      "t": 77019,
      "e": 76387,
      "ty": 41,
      "x": 48284,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 77119,
      "e": 76487,
      "ty": 2,
      "x": 835,
      "y": 816
    },
    {
      "t": 77270,
      "e": 76638,
      "ty": 41,
      "x": 43243,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78819,
      "e": 78187,
      "ty": 3,
      "x": 835,
      "y": 816,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78820,
      "e": 78188,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 78822,
      "e": 78190,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78920,
      "e": 78288,
      "ty": 4,
      "x": 43243,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78920,
      "e": 78288,
      "ty": 5,
      "x": 835,
      "y": 816,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78921,
      "e": 78289,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf",
      "v": "Humanities"
    },
    {
      "t": 79852,
      "e": 79220,
      "ty": 7,
      "x": 835,
      "y": 823,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 79885,
      "e": 79253,
      "ty": 6,
      "x": 836,
      "y": 839,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 79918,
      "e": 79286,
      "ty": 7,
      "x": 840,
      "y": 853,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 79919,
      "e": 79287,
      "ty": 2,
      "x": 840,
      "y": 853
    },
    {
      "t": 80020,
      "e": 79388,
      "ty": 2,
      "x": 848,
      "y": 887
    },
    {
      "t": 80020,
      "e": 79388,
      "ty": 41,
      "x": 6307,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 80120,
      "e": 79488,
      "ty": 2,
      "x": 848,
      "y": 898
    },
    {
      "t": 80219,
      "e": 79587,
      "ty": 2,
      "x": 848,
      "y": 905
    },
    {
      "t": 80268,
      "e": 79636,
      "ty": 41,
      "x": 5595,
      "y": 17644,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 80320,
      "e": 79688,
      "ty": 2,
      "x": 845,
      "y": 911
    },
    {
      "t": 80420,
      "e": 79788,
      "ty": 2,
      "x": 845,
      "y": 916
    },
    {
      "t": 80518,
      "e": 79886,
      "ty": 2,
      "x": 845,
      "y": 926
    },
    {
      "t": 80519,
      "e": 79887,
      "ty": 41,
      "x": 25753,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 80620,
      "e": 79988,
      "ty": 2,
      "x": 845,
      "y": 934
    },
    {
      "t": 80720,
      "e": 80088,
      "ty": 2,
      "x": 845,
      "y": 942
    },
    {
      "t": 80770,
      "e": 80138,
      "ty": 41,
      "x": 23568,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 80820,
      "e": 80188,
      "ty": 2,
      "x": 843,
      "y": 943
    },
    {
      "t": 80920,
      "e": 80288,
      "ty": 2,
      "x": 837,
      "y": 943
    },
    {
      "t": 80985,
      "e": 80353,
      "ty": 3,
      "x": 836,
      "y": 943,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 80985,
      "e": 80353,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 81020,
      "e": 80388,
      "ty": 2,
      "x": 836,
      "y": 943
    },
    {
      "t": 81020,
      "e": 80388,
      "ty": 41,
      "x": 15922,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 81080,
      "e": 80448,
      "ty": 4,
      "x": 15922,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 81080,
      "e": 80448,
      "ty": 5,
      "x": 836,
      "y": 943,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 81080,
      "e": 80448,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 81081,
      "e": 80449,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 81270,
      "e": 80638,
      "ty": 41,
      "x": 2985,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 81319,
      "e": 80687,
      "ty": 2,
      "x": 850,
      "y": 961
    },
    {
      "t": 81419,
      "e": 80787,
      "ty": 6,
      "x": 895,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81420,
      "e": 80788,
      "ty": 2,
      "x": 895,
      "y": 1007
    },
    {
      "t": 81520,
      "e": 80888,
      "ty": 2,
      "x": 897,
      "y": 1011
    },
    {
      "t": 81520,
      "e": 80888,
      "ty": 41,
      "x": 34829,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81993,
      "e": 81361,
      "ty": 3,
      "x": 897,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 81993,
      "e": 81361,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 81993,
      "e": 81361,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82113,
      "e": 81481,
      "ty": 4,
      "x": 34829,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82113,
      "e": 81481,
      "ty": 5,
      "x": 897,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82115,
      "e": 81483,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 82116,
      "e": 81484,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 82117,
      "e": 81485,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 83452,
      "e": 82820,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 84619,
      "e": 83987,
      "ty": 2,
      "x": 899,
      "y": 1011
    },
    {
      "t": 84719,
      "e": 84087,
      "ty": 2,
      "x": 899,
      "y": 1010
    },
    {
      "t": 84769,
      "e": 84137,
      "ty": 41,
      "x": 29840,
      "y": 60917,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 84819,
      "e": 84187,
      "ty": 2,
      "x": 904,
      "y": 1002
    },
    {
      "t": 84919,
      "e": 84287,
      "ty": 2,
      "x": 909,
      "y": 997
    },
    {
      "t": 85019,
      "e": 84387,
      "ty": 2,
      "x": 911,
      "y": 995
    },
    {
      "t": 85020,
      "e": 84387,
      "ty": 41,
      "x": 30381,
      "y": 60155,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 85118,
      "e": 84485,
      "ty": 2,
      "x": 911,
      "y": 991
    },
    {
      "t": 85270,
      "e": 84637,
      "ty": 41,
      "x": 30381,
      "y": 59878,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 100020,
      "e": 89637,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 125021,
      "e": 89637,
      "ty": 41,
      "x": 31955,
      "y": 61194,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 125021,
      "e": 89637,
      "ty": 2,
      "x": 943,
      "y": 1010
    },
    {
      "t": 125119,
      "e": 89735,
      "ty": 2,
      "x": 970,
      "y": 1031
    },
    {
      "t": 125220,
      "e": 89836,
      "ty": 2,
      "x": 990,
      "y": 1057
    },
    {
      "t": 125255,
      "e": 89871,
      "ty": 6,
      "x": 1008,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 125270,
      "e": 89886,
      "ty": 41,
      "x": 53793,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 125320,
      "e": 89936,
      "ty": 2,
      "x": 1017,
      "y": 1086
    },
    {
      "t": 125519,
      "e": 90135,
      "ty": 2,
      "x": 1018,
      "y": 1087
    },
    {
      "t": 125520,
      "e": 90136,
      "ty": 41,
      "x": 59254,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 125619,
      "e": 90235,
      "ty": 2,
      "x": 1015,
      "y": 1091
    },
    {
      "t": 125720,
      "e": 90336,
      "ty": 2,
      "x": 1012,
      "y": 1092
    },
    {
      "t": 125770,
      "e": 90386,
      "ty": 41,
      "x": 55977,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 125820,
      "e": 90436,
      "ty": 2,
      "x": 1008,
      "y": 1094
    },
    {
      "t": 125906,
      "e": 90522,
      "ty": 3,
      "x": 1008,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 125907,
      "e": 90523,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 126016,
      "e": 90632,
      "ty": 4,
      "x": 53793,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 126017,
      "e": 90633,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 126017,
      "e": 90633,
      "ty": 5,
      "x": 1008,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 126017,
      "e": 90633,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 126019,
      "e": 90635,
      "ty": 41,
      "x": 34437,
      "y": 60161,
      "ta": "html > body"
    },
    {
      "t": 127064,
      "e": 91680,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 128896,
      "e": 93512,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 19556, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 19559, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 16133, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 36818, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 28656, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"XRAY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 66477, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 5659, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 73238, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 11849, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 86089, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 37216, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 124619, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -A -C -Z -F -F -H -F -U -G -G -F -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1006,y:910,t:1527876691043};\\\", \\\"{x:1003,y:910,t:1527876691055};\\\", \\\"{x:1000,y:910,t:1527876691072};\\\", \\\"{x:994,y:908,t:1527876691088};\\\", \\\"{x:984,y:906,t:1527876691104};\\\", \\\"{x:973,y:902,t:1527876691122};\\\", \\\"{x:963,y:898,t:1527876691139};\\\", \\\"{x:949,y:892,t:1527876691155};\\\", \\\"{x:932,y:888,t:1527876691172};\\\", \\\"{x:917,y:884,t:1527876691189};\\\", \\\"{x:909,y:883,t:1527876691205};\\\", \\\"{x:904,y:881,t:1527876691221};\\\", \\\"{x:900,y:879,t:1527876691239};\\\", \\\"{x:893,y:876,t:1527876691255};\\\", \\\"{x:887,y:872,t:1527876691272};\\\", \\\"{x:880,y:870,t:1527876691289};\\\", \\\"{x:876,y:868,t:1527876691305};\\\", \\\"{x:870,y:867,t:1527876691321};\\\", \\\"{x:852,y:861,t:1527876691339};\\\", \\\"{x:846,y:857,t:1527876691355};\\\", \\\"{x:827,y:853,t:1527876691372};\\\", \\\"{x:813,y:848,t:1527876691388};\\\", \\\"{x:803,y:843,t:1527876691405};\\\", \\\"{x:797,y:835,t:1527876691422};\\\", \\\"{x:782,y:816,t:1527876691439};\\\", \\\"{x:769,y:796,t:1527876691455};\\\", \\\"{x:752,y:779,t:1527876691472};\\\", \\\"{x:737,y:765,t:1527876691488};\\\", \\\"{x:722,y:749,t:1527876691505};\\\", \\\"{x:707,y:733,t:1527876691522};\\\", \\\"{x:693,y:720,t:1527876691539};\\\", \\\"{x:684,y:711,t:1527876691555};\\\", \\\"{x:676,y:699,t:1527876691572};\\\", \\\"{x:673,y:694,t:1527876691589};\\\", \\\"{x:667,y:687,t:1527876691606};\\\", \\\"{x:662,y:682,t:1527876691622};\\\", \\\"{x:661,y:678,t:1527876691638};\\\", \\\"{x:659,y:676,t:1527876691656};\\\", \\\"{x:659,y:675,t:1527876692733};\\\", \\\"{x:659,y:674,t:1527876692747};\\\", \\\"{x:661,y:673,t:1527876692756};\\\", \\\"{x:662,y:672,t:1527876692773};\\\", \\\"{x:663,y:671,t:1527876692791};\\\", \\\"{x:664,y:670,t:1527876692806};\\\", \\\"{x:665,y:669,t:1527876692823};\\\", \\\"{x:667,y:668,t:1527876692840};\\\", \\\"{x:670,y:666,t:1527876692856};\\\", \\\"{x:671,y:665,t:1527876692873};\\\", \\\"{x:671,y:664,t:1527876692915};\\\", \\\"{x:672,y:664,t:1527876692931};\\\", \\\"{x:673,y:664,t:1527876692939};\\\", \\\"{x:675,y:662,t:1527876692956};\\\", \\\"{x:679,y:659,t:1527876692973};\\\", \\\"{x:679,y:658,t:1527876692990};\\\", \\\"{x:681,y:658,t:1527876693006};\\\", \\\"{x:682,y:657,t:1527876693023};\\\", \\\"{x:683,y:656,t:1527876693060};\\\", \\\"{x:684,y:655,t:1527876693074};\\\", \\\"{x:686,y:654,t:1527876693090};\\\", \\\"{x:687,y:652,t:1527876693107};\\\", \\\"{x:688,y:652,t:1527876693131};\\\", \\\"{x:689,y:651,t:1527876693180};\\\", \\\"{x:690,y:650,t:1527876693220};\\\", \\\"{x:691,y:650,t:1527876693236};\\\", \\\"{x:692,y:649,t:1527876693252};\\\", \\\"{x:693,y:649,t:1527876693268};\\\", \\\"{x:693,y:648,t:1527876693302};\\\", \\\"{x:694,y:647,t:1527876693315};\\\", \\\"{x:695,y:646,t:1527876693346};\\\", \\\"{x:696,y:646,t:1527876693371};\\\", \\\"{x:697,y:646,t:1527876693435};\\\", \\\"{x:701,y:643,t:1527876693458};\\\", \\\"{x:702,y:642,t:1527876693475};\\\", \\\"{x:703,y:642,t:1527876693490};\\\", \\\"{x:704,y:642,t:1527876693507};\\\", \\\"{x:704,y:641,t:1527876693587};\\\", \\\"{x:706,y:640,t:1527876693620};\\\", \\\"{x:706,y:639,t:1527876693772};\\\", \\\"{x:707,y:639,t:1527876694251};\\\", \\\"{x:716,y:641,t:1527876694259};\\\", \\\"{x:726,y:646,t:1527876694275};\\\", \\\"{x:769,y:658,t:1527876694292};\\\", \\\"{x:808,y:667,t:1527876694308};\\\", \\\"{x:844,y:678,t:1527876694324};\\\", \\\"{x:892,y:694,t:1527876694341};\\\", \\\"{x:924,y:705,t:1527876694358};\\\", \\\"{x:971,y:720,t:1527876694374};\\\", \\\"{x:1021,y:733,t:1527876694391};\\\", \\\"{x:1060,y:744,t:1527876694407};\\\", \\\"{x:1092,y:756,t:1527876694425};\\\", \\\"{x:1114,y:765,t:1527876694440};\\\", \\\"{x:1132,y:773,t:1527876694458};\\\", \\\"{x:1157,y:789,t:1527876694475};\\\", \\\"{x:1176,y:801,t:1527876694491};\\\", \\\"{x:1186,y:812,t:1527876694508};\\\", \\\"{x:1201,y:823,t:1527876694525};\\\", \\\"{x:1216,y:833,t:1527876694544};\\\", \\\"{x:1231,y:844,t:1527876694559};\\\", \\\"{x:1244,y:854,t:1527876694575};\\\", \\\"{x:1254,y:864,t:1527876694591};\\\", \\\"{x:1264,y:873,t:1527876694608};\\\", \\\"{x:1274,y:884,t:1527876694625};\\\", \\\"{x:1277,y:888,t:1527876694641};\\\", \\\"{x:1279,y:891,t:1527876694659};\\\", \\\"{x:1281,y:893,t:1527876694675};\\\", \\\"{x:1282,y:895,t:1527876694691};\\\", \\\"{x:1283,y:896,t:1527876694708};\\\", \\\"{x:1285,y:898,t:1527876694725};\\\", \\\"{x:1288,y:905,t:1527876694742};\\\", \\\"{x:1294,y:910,t:1527876694758};\\\", \\\"{x:1300,y:914,t:1527876694775};\\\", \\\"{x:1304,y:916,t:1527876694792};\\\", \\\"{x:1305,y:916,t:1527876694808};\\\", \\\"{x:1305,y:917,t:1527876694825};\\\", \\\"{x:1307,y:919,t:1527876694842};\\\", \\\"{x:1307,y:920,t:1527876694859};\\\", \\\"{x:1307,y:921,t:1527876694899};\\\", \\\"{x:1307,y:922,t:1527876694909};\\\", \\\"{x:1307,y:925,t:1527876694925};\\\", \\\"{x:1307,y:927,t:1527876694942};\\\", \\\"{x:1307,y:929,t:1527876694959};\\\", \\\"{x:1306,y:931,t:1527876694976};\\\", \\\"{x:1305,y:933,t:1527876694996};\\\", \\\"{x:1304,y:935,t:1527876695011};\\\", \\\"{x:1303,y:935,t:1527876695027};\\\", \\\"{x:1303,y:933,t:1527876695084};\\\", \\\"{x:1303,y:928,t:1527876695094};\\\", \\\"{x:1299,y:916,t:1527876695110};\\\", \\\"{x:1294,y:904,t:1527876695126};\\\", \\\"{x:1289,y:893,t:1527876695143};\\\", \\\"{x:1286,y:884,t:1527876695160};\\\", \\\"{x:1285,y:876,t:1527876695176};\\\", \\\"{x:1284,y:867,t:1527876695194};\\\", \\\"{x:1283,y:856,t:1527876695210};\\\", \\\"{x:1282,y:850,t:1527876695227};\\\", \\\"{x:1278,y:840,t:1527876695244};\\\", \\\"{x:1276,y:837,t:1527876695260};\\\", \\\"{x:1274,y:834,t:1527876695276};\\\", \\\"{x:1274,y:833,t:1527876695293};\\\", \\\"{x:1274,y:832,t:1527876695324};\\\", \\\"{x:1274,y:831,t:1527876695373};\\\", \\\"{x:1274,y:829,t:1527876695396};\\\", \\\"{x:1274,y:828,t:1527876695420};\\\", \\\"{x:1276,y:828,t:1527876695484};\\\", \\\"{x:1276,y:827,t:1527876695494};\\\", \\\"{x:1277,y:826,t:1527876695563};\\\", \\\"{x:1279,y:826,t:1527876695668};\\\", \\\"{x:1280,y:826,t:1527876699245};\\\", \\\"{x:1280,y:828,t:1527876699262};\\\", \\\"{x:1281,y:829,t:1527876699427};\\\", \\\"{x:1280,y:829,t:1527876701588};\\\", \\\"{x:1279,y:829,t:1527876701611};\\\", \\\"{x:1279,y:831,t:1527876701836};\\\", \\\"{x:1279,y:832,t:1527876701848};\\\", \\\"{x:1280,y:835,t:1527876701864};\\\", \\\"{x:1281,y:836,t:1527876701881};\\\", \\\"{x:1281,y:837,t:1527876701899};\\\", \\\"{x:1283,y:838,t:1527876701915};\\\", \\\"{x:1283,y:839,t:1527876701931};\\\", \\\"{x:1284,y:839,t:1527876701946};\\\", \\\"{x:1284,y:840,t:1527876701964};\\\", \\\"{x:1284,y:841,t:1527876701980};\\\", \\\"{x:1284,y:842,t:1527876702051};\\\", \\\"{x:1284,y:843,t:1527876702083};\\\", \\\"{x:1284,y:844,t:1527876702099};\\\", \\\"{x:1284,y:845,t:1527876702124};\\\", \\\"{x:1285,y:845,t:1527876702381};\\\", \\\"{x:1286,y:843,t:1527876702398};\\\", \\\"{x:1286,y:842,t:1527876702414};\\\", \\\"{x:1286,y:841,t:1527876702431};\\\", \\\"{x:1286,y:840,t:1527876702452};\\\", \\\"{x:1286,y:839,t:1527876702492};\\\", \\\"{x:1286,y:838,t:1527876702516};\\\", \\\"{x:1285,y:838,t:1527876702540};\\\", \\\"{x:1285,y:836,t:1527876702556};\\\", \\\"{x:1285,y:835,t:1527876702613};\\\", \\\"{x:1285,y:834,t:1527876702639};\\\", \\\"{x:1285,y:833,t:1527876702715};\\\", \\\"{x:1285,y:831,t:1527876702731};\\\", \\\"{x:1285,y:830,t:1527876702747};\\\", \\\"{x:1284,y:828,t:1527876702780};\\\", \\\"{x:1283,y:828,t:1527876704485};\\\", \\\"{x:1281,y:828,t:1527876705532};\\\", \\\"{x:1280,y:828,t:1527876705540};\\\", \\\"{x:1278,y:829,t:1527876705550};\\\", \\\"{x:1275,y:830,t:1527876705569};\\\", \\\"{x:1273,y:830,t:1527876705583};\\\", \\\"{x:1270,y:831,t:1527876705600};\\\", \\\"{x:1267,y:831,t:1527876705616};\\\", \\\"{x:1266,y:832,t:1527876705633};\\\", \\\"{x:1265,y:832,t:1527876705650};\\\", \\\"{x:1264,y:832,t:1527876705667};\\\", \\\"{x:1262,y:833,t:1527876705682};\\\", \\\"{x:1256,y:833,t:1527876705700};\\\", \\\"{x:1249,y:833,t:1527876705716};\\\", \\\"{x:1244,y:833,t:1527876705733};\\\", \\\"{x:1240,y:833,t:1527876705749};\\\", \\\"{x:1236,y:833,t:1527876705766};\\\", \\\"{x:1233,y:833,t:1527876705783};\\\", \\\"{x:1230,y:833,t:1527876705800};\\\", \\\"{x:1229,y:833,t:1527876705816};\\\", \\\"{x:1227,y:833,t:1527876705834};\\\", \\\"{x:1226,y:833,t:1527876705948};\\\", \\\"{x:1225,y:833,t:1527876705972};\\\", \\\"{x:1224,y:833,t:1527876705988};\\\", \\\"{x:1222,y:833,t:1527876706003};\\\", \\\"{x:1221,y:833,t:1527876706069};\\\", \\\"{x:1218,y:833,t:1527876706088};\\\", \\\"{x:1215,y:833,t:1527876706101};\\\", \\\"{x:1214,y:832,t:1527876708469};\\\", \\\"{x:1217,y:832,t:1527876708492};\\\", \\\"{x:1222,y:832,t:1527876708506};\\\", \\\"{x:1235,y:835,t:1527876708519};\\\", \\\"{x:1247,y:837,t:1527876708536};\\\", \\\"{x:1261,y:839,t:1527876708552};\\\", \\\"{x:1275,y:842,t:1527876708569};\\\", \\\"{x:1284,y:845,t:1527876708586};\\\", \\\"{x:1291,y:848,t:1527876708603};\\\", \\\"{x:1294,y:849,t:1527876708619};\\\", \\\"{x:1299,y:850,t:1527876708636};\\\", \\\"{x:1300,y:850,t:1527876708653};\\\", \\\"{x:1303,y:850,t:1527876708669};\\\", \\\"{x:1304,y:851,t:1527876708686};\\\", \\\"{x:1306,y:852,t:1527876708702};\\\", \\\"{x:1307,y:853,t:1527876708719};\\\", \\\"{x:1307,y:854,t:1527876708736};\\\", \\\"{x:1311,y:855,t:1527876708753};\\\", \\\"{x:1317,y:857,t:1527876708769};\\\", \\\"{x:1321,y:859,t:1527876708786};\\\", \\\"{x:1324,y:860,t:1527876708803};\\\", \\\"{x:1325,y:863,t:1527876708819};\\\", \\\"{x:1326,y:865,t:1527876708835};\\\", \\\"{x:1328,y:867,t:1527876708853};\\\", \\\"{x:1329,y:868,t:1527876708870};\\\", \\\"{x:1329,y:869,t:1527876708899};\\\", \\\"{x:1331,y:871,t:1527876708907};\\\", \\\"{x:1331,y:872,t:1527876708919};\\\", \\\"{x:1332,y:874,t:1527876708936};\\\", \\\"{x:1335,y:878,t:1527876708952};\\\", \\\"{x:1337,y:881,t:1527876708970};\\\", \\\"{x:1339,y:885,t:1527876708986};\\\", \\\"{x:1340,y:891,t:1527876709003};\\\", \\\"{x:1343,y:895,t:1527876709022};\\\", \\\"{x:1344,y:897,t:1527876709036};\\\", \\\"{x:1345,y:898,t:1527876709052};\\\", \\\"{x:1346,y:898,t:1527876709764};\\\", \\\"{x:1346,y:893,t:1527876709772};\\\", \\\"{x:1344,y:877,t:1527876709790};\\\", \\\"{x:1344,y:865,t:1527876709804};\\\", \\\"{x:1344,y:854,t:1527876709819};\\\", \\\"{x:1343,y:838,t:1527876709836};\\\", \\\"{x:1343,y:807,t:1527876709854};\\\", \\\"{x:1348,y:776,t:1527876709869};\\\", \\\"{x:1351,y:756,t:1527876709887};\\\", \\\"{x:1352,y:742,t:1527876709904};\\\", \\\"{x:1354,y:731,t:1527876709919};\\\", \\\"{x:1356,y:727,t:1527876709937};\\\", \\\"{x:1356,y:724,t:1527876709954};\\\", \\\"{x:1357,y:724,t:1527876709970};\\\", \\\"{x:1357,y:722,t:1527876709987};\\\", \\\"{x:1358,y:722,t:1527876710003};\\\", \\\"{x:1359,y:721,t:1527876710021};\\\", \\\"{x:1361,y:721,t:1527876710036};\\\", \\\"{x:1365,y:721,t:1527876710053};\\\", \\\"{x:1370,y:722,t:1527876710071};\\\", \\\"{x:1377,y:729,t:1527876710086};\\\", \\\"{x:1385,y:739,t:1527876710104};\\\", \\\"{x:1388,y:745,t:1527876710121};\\\", \\\"{x:1388,y:746,t:1527876710155};\\\", \\\"{x:1389,y:747,t:1527876710171};\\\", \\\"{x:1389,y:748,t:1527876710187};\\\", \\\"{x:1389,y:750,t:1527876710204};\\\", \\\"{x:1389,y:751,t:1527876710243};\\\", \\\"{x:1387,y:752,t:1527876710254};\\\", \\\"{x:1386,y:752,t:1527876710271};\\\", \\\"{x:1385,y:752,t:1527876710461};\\\", \\\"{x:1384,y:753,t:1527876710476};\\\", \\\"{x:1382,y:755,t:1527876710500};\\\", \\\"{x:1382,y:756,t:1527876710684};\\\", \\\"{x:1382,y:757,t:1527876710708};\\\", \\\"{x:1382,y:758,t:1527876710759};\\\", \\\"{x:1382,y:759,t:1527876710787};\\\", \\\"{x:1381,y:761,t:1527876710804};\\\", \\\"{x:1381,y:762,t:1527876710908};\\\", \\\"{x:1381,y:760,t:1527876712411};\\\", \\\"{x:1382,y:759,t:1527876712422};\\\", \\\"{x:1384,y:753,t:1527876712440};\\\", \\\"{x:1386,y:750,t:1527876712455};\\\", \\\"{x:1388,y:746,t:1527876712472};\\\", \\\"{x:1391,y:741,t:1527876712489};\\\", \\\"{x:1395,y:734,t:1527876712506};\\\", \\\"{x:1398,y:729,t:1527876712521};\\\", \\\"{x:1403,y:720,t:1527876712539};\\\", \\\"{x:1405,y:716,t:1527876712555};\\\", \\\"{x:1407,y:713,t:1527876712572};\\\", \\\"{x:1407,y:712,t:1527876712589};\\\", \\\"{x:1409,y:707,t:1527876712606};\\\", \\\"{x:1410,y:704,t:1527876712622};\\\", \\\"{x:1414,y:699,t:1527876712639};\\\", \\\"{x:1414,y:695,t:1527876712656};\\\", \\\"{x:1416,y:693,t:1527876712672};\\\", \\\"{x:1417,y:691,t:1527876712689};\\\", \\\"{x:1418,y:687,t:1527876712706};\\\", \\\"{x:1422,y:680,t:1527876712722};\\\", \\\"{x:1428,y:672,t:1527876712739};\\\", \\\"{x:1430,y:668,t:1527876712755};\\\", \\\"{x:1432,y:664,t:1527876712772};\\\", \\\"{x:1433,y:661,t:1527876712789};\\\", \\\"{x:1436,y:658,t:1527876712806};\\\", \\\"{x:1438,y:654,t:1527876712823};\\\", \\\"{x:1441,y:646,t:1527876712838};\\\", \\\"{x:1446,y:636,t:1527876712856};\\\", \\\"{x:1449,y:631,t:1527876712872};\\\", \\\"{x:1454,y:623,t:1527876712888};\\\", \\\"{x:1459,y:617,t:1527876712905};\\\", \\\"{x:1466,y:603,t:1527876712923};\\\", \\\"{x:1468,y:600,t:1527876712939};\\\", \\\"{x:1470,y:595,t:1527876712956};\\\", \\\"{x:1471,y:593,t:1527876712973};\\\", \\\"{x:1472,y:591,t:1527876712989};\\\", \\\"{x:1474,y:589,t:1527876713006};\\\", \\\"{x:1474,y:587,t:1527876713023};\\\", \\\"{x:1476,y:587,t:1527876713039};\\\", \\\"{x:1477,y:585,t:1527876713056};\\\", \\\"{x:1479,y:581,t:1527876713073};\\\", \\\"{x:1481,y:577,t:1527876713089};\\\", \\\"{x:1482,y:575,t:1527876713106};\\\", \\\"{x:1482,y:573,t:1527876713123};\\\", \\\"{x:1481,y:574,t:1527876713197};\\\", \\\"{x:1478,y:580,t:1527876713207};\\\", \\\"{x:1471,y:587,t:1527876713223};\\\", \\\"{x:1467,y:595,t:1527876713240};\\\", \\\"{x:1463,y:600,t:1527876713256};\\\", \\\"{x:1458,y:605,t:1527876713274};\\\", \\\"{x:1451,y:609,t:1527876713289};\\\", \\\"{x:1447,y:613,t:1527876713307};\\\", \\\"{x:1443,y:616,t:1527876713324};\\\", \\\"{x:1443,y:617,t:1527876713340};\\\", \\\"{x:1442,y:617,t:1527876713364};\\\", \\\"{x:1441,y:617,t:1527876713374};\\\", \\\"{x:1439,y:617,t:1527876713390};\\\", \\\"{x:1438,y:617,t:1527876713406};\\\", \\\"{x:1436,y:616,t:1527876713423};\\\", \\\"{x:1436,y:614,t:1527876713441};\\\", \\\"{x:1436,y:607,t:1527876713457};\\\", \\\"{x:1436,y:601,t:1527876713474};\\\", \\\"{x:1435,y:595,t:1527876713490};\\\", \\\"{x:1433,y:591,t:1527876713506};\\\", \\\"{x:1431,y:587,t:1527876713523};\\\", \\\"{x:1429,y:585,t:1527876713540};\\\", \\\"{x:1427,y:581,t:1527876713555};\\\", \\\"{x:1427,y:580,t:1527876713578};\\\", \\\"{x:1426,y:579,t:1527876713590};\\\", \\\"{x:1426,y:578,t:1527876713611};\\\", \\\"{x:1425,y:576,t:1527876713627};\\\", \\\"{x:1424,y:576,t:1527876713640};\\\", \\\"{x:1422,y:573,t:1527876713656};\\\", \\\"{x:1420,y:572,t:1527876713673};\\\", \\\"{x:1419,y:571,t:1527876713690};\\\", \\\"{x:1418,y:570,t:1527876713706};\\\", \\\"{x:1417,y:569,t:1527876713723};\\\", \\\"{x:1415,y:569,t:1527876713739};\\\", \\\"{x:1413,y:568,t:1527876713758};\\\", \\\"{x:1413,y:567,t:1527876714011};\\\", \\\"{x:1413,y:565,t:1527876714024};\\\", \\\"{x:1412,y:564,t:1527876714040};\\\", \\\"{x:1412,y:563,t:1527876714132};\\\", \\\"{x:1412,y:561,t:1527876714164};\\\", \\\"{x:1412,y:562,t:1527876714644};\\\", \\\"{x:1412,y:566,t:1527876714658};\\\", \\\"{x:1419,y:575,t:1527876714677};\\\", \\\"{x:1430,y:586,t:1527876714691};\\\", \\\"{x:1432,y:588,t:1527876714707};\\\", \\\"{x:1432,y:589,t:1527876714738};\\\", \\\"{x:1433,y:590,t:1527876714755};\\\", \\\"{x:1433,y:591,t:1527876714762};\\\", \\\"{x:1434,y:593,t:1527876714774};\\\", \\\"{x:1434,y:595,t:1527876714803};\\\", \\\"{x:1435,y:595,t:1527876714811};\\\", \\\"{x:1435,y:596,t:1527876714824};\\\", \\\"{x:1435,y:597,t:1527876714867};\\\", \\\"{x:1435,y:599,t:1527876714875};\\\", \\\"{x:1435,y:600,t:1527876714890};\\\", \\\"{x:1435,y:604,t:1527876714908};\\\", \\\"{x:1439,y:612,t:1527876714924};\\\", \\\"{x:1441,y:615,t:1527876714941};\\\", \\\"{x:1443,y:621,t:1527876714958};\\\", \\\"{x:1443,y:623,t:1527876714974};\\\", \\\"{x:1443,y:625,t:1527876714991};\\\", \\\"{x:1443,y:626,t:1527876715008};\\\", \\\"{x:1443,y:628,t:1527876715027};\\\", \\\"{x:1443,y:630,t:1527876715041};\\\", \\\"{x:1445,y:633,t:1527876715058};\\\", \\\"{x:1446,y:638,t:1527876715074};\\\", \\\"{x:1447,y:638,t:1527876715091};\\\", \\\"{x:1448,y:639,t:1527876715108};\\\", \\\"{x:1448,y:640,t:1527876715204};\\\", \\\"{x:1448,y:645,t:1527876715211};\\\", \\\"{x:1446,y:654,t:1527876715224};\\\", \\\"{x:1440,y:666,t:1527876715241};\\\", \\\"{x:1430,y:680,t:1527876715259};\\\", \\\"{x:1422,y:693,t:1527876715275};\\\", \\\"{x:1408,y:719,t:1527876715292};\\\", \\\"{x:1401,y:733,t:1527876715307};\\\", \\\"{x:1394,y:749,t:1527876715325};\\\", \\\"{x:1389,y:757,t:1527876715341};\\\", \\\"{x:1387,y:763,t:1527876715359};\\\", \\\"{x:1384,y:766,t:1527876715375};\\\", \\\"{x:1382,y:770,t:1527876715391};\\\", \\\"{x:1382,y:771,t:1527876715419};\\\", \\\"{x:1381,y:772,t:1527876715451};\\\", \\\"{x:1381,y:776,t:1527876715458};\\\", \\\"{x:1380,y:781,t:1527876715474};\\\", \\\"{x:1380,y:783,t:1527876715492};\\\", \\\"{x:1378,y:782,t:1527876715628};\\\", \\\"{x:1377,y:782,t:1527876715641};\\\", \\\"{x:1362,y:781,t:1527876715658};\\\", \\\"{x:1304,y:774,t:1527876715675};\\\", \\\"{x:1248,y:774,t:1527876715692};\\\", \\\"{x:1189,y:774,t:1527876715709};\\\", \\\"{x:1127,y:772,t:1527876715726};\\\", \\\"{x:1050,y:763,t:1527876715742};\\\", \\\"{x:1001,y:752,t:1527876715759};\\\", \\\"{x:963,y:742,t:1527876715776};\\\", \\\"{x:939,y:739,t:1527876715793};\\\", \\\"{x:916,y:737,t:1527876715809};\\\", \\\"{x:894,y:736,t:1527876715825};\\\", \\\"{x:869,y:731,t:1527876715843};\\\", \\\"{x:852,y:728,t:1527876715859};\\\", \\\"{x:809,y:722,t:1527876715875};\\\", \\\"{x:780,y:717,t:1527876715892};\\\", \\\"{x:754,y:713,t:1527876715909};\\\", \\\"{x:727,y:711,t:1527876715925};\\\", \\\"{x:706,y:705,t:1527876715942};\\\", \\\"{x:692,y:701,t:1527876715958};\\\", \\\"{x:672,y:698,t:1527876715975};\\\", \\\"{x:661,y:695,t:1527876715991};\\\", \\\"{x:635,y:687,t:1527876716007};\\\", \\\"{x:605,y:677,t:1527876716026};\\\", \\\"{x:574,y:666,t:1527876716042};\\\", \\\"{x:552,y:659,t:1527876716057};\\\", \\\"{x:525,y:651,t:1527876716075};\\\", \\\"{x:514,y:645,t:1527876716091};\\\", \\\"{x:510,y:644,t:1527876716108};\\\", \\\"{x:506,y:640,t:1527876716125};\\\", \\\"{x:499,y:637,t:1527876716142};\\\", \\\"{x:486,y:632,t:1527876716158};\\\", \\\"{x:471,y:630,t:1527876716175};\\\", \\\"{x:466,y:630,t:1527876716192};\\\", \\\"{x:453,y:630,t:1527876716209};\\\", \\\"{x:446,y:629,t:1527876716225};\\\", \\\"{x:442,y:629,t:1527876716242};\\\", \\\"{x:434,y:628,t:1527876716259};\\\", \\\"{x:426,y:628,t:1527876716275};\\\", \\\"{x:422,y:628,t:1527876716292};\\\", \\\"{x:418,y:628,t:1527876716309};\\\", \\\"{x:415,y:628,t:1527876716327};\\\", \\\"{x:414,y:628,t:1527876716342};\\\", \\\"{x:413,y:628,t:1527876716362};\\\", \\\"{x:412,y:628,t:1527876716375};\\\", \\\"{x:412,y:626,t:1527876716395};\\\", \\\"{x:412,y:624,t:1527876716409};\\\", \\\"{x:411,y:622,t:1527876716425};\\\", \\\"{x:408,y:619,t:1527876716442};\\\", \\\"{x:406,y:615,t:1527876716459};\\\", \\\"{x:405,y:615,t:1527876716507};\\\", \\\"{x:405,y:614,t:1527876716523};\\\", \\\"{x:405,y:613,t:1527876716531};\\\", \\\"{x:404,y:612,t:1527876716542};\\\", \\\"{x:402,y:611,t:1527876716620};\\\", \\\"{x:401,y:611,t:1527876716627};\\\", \\\"{x:399,y:610,t:1527876716644};\\\", \\\"{x:395,y:608,t:1527876716658};\\\", \\\"{x:394,y:607,t:1527876716691};\\\", \\\"{x:393,y:606,t:1527876716715};\\\", \\\"{x:392,y:606,t:1527876717003};\\\", \\\"{x:391,y:606,t:1527876717010};\\\", \\\"{x:392,y:606,t:1527876717075};\\\", \\\"{x:394,y:606,t:1527876717099};\\\", \\\"{x:395,y:606,t:1527876717115};\\\", \\\"{x:401,y:610,t:1527876717127};\\\", \\\"{x:453,y:652,t:1527876717144};\\\", \\\"{x:513,y:689,t:1527876717158};\\\", \\\"{x:544,y:695,t:1527876717176};\\\", \\\"{x:572,y:695,t:1527876717193};\\\", \\\"{x:616,y:692,t:1527876717209};\\\", \\\"{x:667,y:682,t:1527876717227};\\\", \\\"{x:760,y:681,t:1527876717243};\\\", \\\"{x:846,y:681,t:1527876717259};\\\", \\\"{x:954,y:683,t:1527876717276};\\\", \\\"{x:1084,y:683,t:1527876717293};\\\", \\\"{x:1209,y:665,t:1527876717309};\\\", \\\"{x:1321,y:645,t:1527876717325};\\\", \\\"{x:1419,y:625,t:1527876717343};\\\", \\\"{x:1504,y:606,t:1527876717359};\\\", \\\"{x:1547,y:601,t:1527876717376};\\\", \\\"{x:1560,y:601,t:1527876717393};\\\", \\\"{x:1562,y:601,t:1527876717409};\\\", \\\"{x:1560,y:601,t:1527876717938};\\\", \\\"{x:1556,y:604,t:1527876717947};\\\", \\\"{x:1553,y:606,t:1527876717960};\\\", \\\"{x:1542,y:615,t:1527876717977};\\\", \\\"{x:1525,y:627,t:1527876717993};\\\", \\\"{x:1513,y:636,t:1527876718009};\\\", \\\"{x:1503,y:642,t:1527876718027};\\\", \\\"{x:1501,y:642,t:1527876718075};\\\", \\\"{x:1499,y:643,t:1527876718091};\\\", \\\"{x:1499,y:644,t:1527876718099};\\\", \\\"{x:1498,y:645,t:1527876718110};\\\", \\\"{x:1495,y:648,t:1527876718127};\\\", \\\"{x:1492,y:654,t:1527876718143};\\\", \\\"{x:1488,y:657,t:1527876718160};\\\", \\\"{x:1488,y:659,t:1527876718177};\\\", \\\"{x:1486,y:662,t:1527876718193};\\\", \\\"{x:1484,y:666,t:1527876718210};\\\", \\\"{x:1480,y:678,t:1527876718227};\\\", \\\"{x:1469,y:698,t:1527876718243};\\\", \\\"{x:1453,y:740,t:1527876718261};\\\", \\\"{x:1429,y:795,t:1527876718277};\\\", \\\"{x:1410,y:830,t:1527876718293};\\\", \\\"{x:1400,y:853,t:1527876718310};\\\", \\\"{x:1401,y:862,t:1527876718327};\\\", \\\"{x:1410,y:870,t:1527876718343};\\\", \\\"{x:1413,y:876,t:1527876718361};\\\", \\\"{x:1414,y:884,t:1527876718377};\\\", \\\"{x:1414,y:895,t:1527876718393};\\\", \\\"{x:1414,y:904,t:1527876718410};\\\", \\\"{x:1415,y:907,t:1527876718427};\\\", \\\"{x:1416,y:908,t:1527876718443};\\\", \\\"{x:1419,y:908,t:1527876718461};\\\", \\\"{x:1425,y:908,t:1527876718477};\\\", \\\"{x:1431,y:903,t:1527876718494};\\\", \\\"{x:1439,y:892,t:1527876718510};\\\", \\\"{x:1444,y:883,t:1527876718527};\\\", \\\"{x:1449,y:874,t:1527876718545};\\\", \\\"{x:1452,y:872,t:1527876718560};\\\", \\\"{x:1452,y:870,t:1527876718578};\\\", \\\"{x:1452,y:868,t:1527876718594};\\\", \\\"{x:1453,y:865,t:1527876718610};\\\", \\\"{x:1456,y:862,t:1527876718627};\\\", \\\"{x:1456,y:859,t:1527876718644};\\\", \\\"{x:1457,y:855,t:1527876718660};\\\", \\\"{x:1457,y:853,t:1527876718677};\\\", \\\"{x:1458,y:851,t:1527876718694};\\\", \\\"{x:1458,y:850,t:1527876718710};\\\", \\\"{x:1458,y:849,t:1527876718728};\\\", \\\"{x:1458,y:847,t:1527876718744};\\\", \\\"{x:1458,y:845,t:1527876718760};\\\", \\\"{x:1461,y:841,t:1527876718777};\\\", \\\"{x:1463,y:839,t:1527876718794};\\\", \\\"{x:1463,y:836,t:1527876718843};\\\", \\\"{x:1465,y:835,t:1527876718868};\\\", \\\"{x:1467,y:834,t:1527876718877};\\\", \\\"{x:1468,y:834,t:1527876718894};\\\", \\\"{x:1469,y:834,t:1527876718911};\\\", \\\"{x:1470,y:833,t:1527876718956};\\\", \\\"{x:1471,y:833,t:1527876718972};\\\", \\\"{x:1471,y:832,t:1527876718996};\\\", \\\"{x:1472,y:831,t:1527876719012};\\\", \\\"{x:1473,y:831,t:1527876719027};\\\", \\\"{x:1476,y:830,t:1527876719045};\\\", \\\"{x:1477,y:829,t:1527876719980};\\\", \\\"{x:1478,y:828,t:1527876719997};\\\", \\\"{x:1479,y:828,t:1527876720014};\\\", \\\"{x:1486,y:825,t:1527876720934};\\\", \\\"{x:1503,y:823,t:1527876720949};\\\", \\\"{x:1511,y:820,t:1527876720962};\\\", \\\"{x:1556,y:806,t:1527876720978};\\\", \\\"{x:1602,y:799,t:1527876720995};\\\", \\\"{x:1643,y:795,t:1527876721012};\\\", \\\"{x:1694,y:785,t:1527876721029};\\\", \\\"{x:1729,y:779,t:1527876721046};\\\", \\\"{x:1754,y:773,t:1527876721062};\\\", \\\"{x:1774,y:772,t:1527876721079};\\\", \\\"{x:1786,y:768,t:1527876721097};\\\", \\\"{x:1792,y:767,t:1527876721112};\\\", \\\"{x:1792,y:766,t:1527876721147};\\\", \\\"{x:1791,y:765,t:1527876721163};\\\", \\\"{x:1787,y:763,t:1527876721179};\\\", \\\"{x:1780,y:760,t:1527876721196};\\\", \\\"{x:1765,y:757,t:1527876721212};\\\", \\\"{x:1751,y:756,t:1527876721229};\\\", \\\"{x:1742,y:756,t:1527876721247};\\\", \\\"{x:1738,y:756,t:1527876721262};\\\", \\\"{x:1733,y:756,t:1527876721279};\\\", \\\"{x:1730,y:756,t:1527876721296};\\\", \\\"{x:1723,y:756,t:1527876721312};\\\", \\\"{x:1718,y:756,t:1527876721329};\\\", \\\"{x:1710,y:756,t:1527876721346};\\\", \\\"{x:1702,y:756,t:1527876721363};\\\", \\\"{x:1685,y:763,t:1527876721379};\\\", \\\"{x:1676,y:767,t:1527876721396};\\\", \\\"{x:1671,y:768,t:1527876721412};\\\", \\\"{x:1669,y:768,t:1527876721429};\\\", \\\"{x:1663,y:768,t:1527876721446};\\\", \\\"{x:1655,y:768,t:1527876721462};\\\", \\\"{x:1651,y:768,t:1527876721479};\\\", \\\"{x:1650,y:769,t:1527876721497};\\\", \\\"{x:1649,y:769,t:1527876721523};\\\", \\\"{x:1648,y:769,t:1527876721588};\\\", \\\"{x:1647,y:769,t:1527876721596};\\\", \\\"{x:1644,y:769,t:1527876721614};\\\", \\\"{x:1643,y:769,t:1527876721820};\\\", \\\"{x:1643,y:768,t:1527876722079};\\\", \\\"{x:1643,y:767,t:1527876722102};\\\", \\\"{x:1643,y:766,t:1527876722289};\\\", \\\"{x:1643,y:765,t:1527876722316};\\\", \\\"{x:1645,y:763,t:1527876722334};\\\", \\\"{x:1645,y:761,t:1527876722349};\\\", \\\"{x:1646,y:758,t:1527876722366};\\\", \\\"{x:1647,y:757,t:1527876722399};\\\", \\\"{x:1647,y:753,t:1527876722607};\\\", \\\"{x:1643,y:747,t:1527876722616};\\\", \\\"{x:1641,y:743,t:1527876722634};\\\", \\\"{x:1639,y:735,t:1527876722651};\\\", \\\"{x:1638,y:732,t:1527876722667};\\\", \\\"{x:1637,y:731,t:1527876722684};\\\", \\\"{x:1635,y:730,t:1527876722701};\\\", \\\"{x:1630,y:729,t:1527876722717};\\\", \\\"{x:1626,y:728,t:1527876722734};\\\", \\\"{x:1615,y:728,t:1527876722750};\\\", \\\"{x:1597,y:747,t:1527876722767};\\\", \\\"{x:1540,y:779,t:1527876722784};\\\", \\\"{x:1455,y:831,t:1527876722801};\\\", \\\"{x:1422,y:859,t:1527876722818};\\\", \\\"{x:1410,y:874,t:1527876722834};\\\", \\\"{x:1396,y:880,t:1527876722851};\\\", \\\"{x:1388,y:892,t:1527876722868};\\\", \\\"{x:1388,y:895,t:1527876722884};\\\", \\\"{x:1387,y:895,t:1527876723086};\\\", \\\"{x:1386,y:895,t:1527876723102};\\\", \\\"{x:1385,y:895,t:1527876723118};\\\", \\\"{x:1381,y:895,t:1527876723133};\\\", \\\"{x:1378,y:883,t:1527876723151};\\\", \\\"{x:1374,y:872,t:1527876723167};\\\", \\\"{x:1374,y:867,t:1527876723183};\\\", \\\"{x:1374,y:859,t:1527876723200};\\\", \\\"{x:1374,y:854,t:1527876723217};\\\", \\\"{x:1374,y:849,t:1527876723234};\\\", \\\"{x:1373,y:844,t:1527876723250};\\\", \\\"{x:1371,y:844,t:1527876723267};\\\", \\\"{x:1370,y:843,t:1527876723334};\\\", \\\"{x:1370,y:841,t:1527876723351};\\\", \\\"{x:1370,y:837,t:1527876723367};\\\", \\\"{x:1370,y:834,t:1527876723385};\\\", \\\"{x:1369,y:828,t:1527876723401};\\\", \\\"{x:1369,y:822,t:1527876723418};\\\", \\\"{x:1373,y:811,t:1527876723434};\\\", \\\"{x:1378,y:798,t:1527876723451};\\\", \\\"{x:1381,y:789,t:1527876723468};\\\", \\\"{x:1381,y:781,t:1527876723484};\\\", \\\"{x:1382,y:777,t:1527876723500};\\\", \\\"{x:1383,y:772,t:1527876723517};\\\", \\\"{x:1383,y:770,t:1527876723535};\\\", \\\"{x:1383,y:769,t:1527876723575};\\\", \\\"{x:1383,y:768,t:1527876723653};\\\", \\\"{x:1383,y:766,t:1527876723667};\\\", \\\"{x:1383,y:765,t:1527876723685};\\\", \\\"{x:1383,y:764,t:1527876723702};\\\", \\\"{x:1383,y:763,t:1527876723718};\\\", \\\"{x:1382,y:762,t:1527876724087};\\\", \\\"{x:1378,y:762,t:1527876724102};\\\", \\\"{x:1342,y:781,t:1527876724122};\\\", \\\"{x:1288,y:808,t:1527876724135};\\\", \\\"{x:1215,y:835,t:1527876724153};\\\", \\\"{x:1134,y:848,t:1527876724169};\\\", \\\"{x:1063,y:853,t:1527876724184};\\\", \\\"{x:1015,y:853,t:1527876724201};\\\", \\\"{x:992,y:852,t:1527876724219};\\\", \\\"{x:981,y:848,t:1527876724234};\\\", \\\"{x:978,y:847,t:1527876724251};\\\", \\\"{x:978,y:846,t:1527876724268};\\\", \\\"{x:979,y:843,t:1527876724284};\\\", \\\"{x:982,y:841,t:1527876724302};\\\", \\\"{x:998,y:833,t:1527876724318};\\\", \\\"{x:1018,y:830,t:1527876724334};\\\", \\\"{x:1053,y:821,t:1527876724352};\\\", \\\"{x:1107,y:805,t:1527876724368};\\\", \\\"{x:1167,y:792,t:1527876724385};\\\", \\\"{x:1211,y:780,t:1527876724402};\\\", \\\"{x:1267,y:763,t:1527876724419};\\\", \\\"{x:1300,y:756,t:1527876724435};\\\", \\\"{x:1327,y:749,t:1527876724452};\\\", \\\"{x:1346,y:746,t:1527876724469};\\\", \\\"{x:1362,y:744,t:1527876724485};\\\", \\\"{x:1373,y:741,t:1527876724502};\\\", \\\"{x:1382,y:739,t:1527876724519};\\\", \\\"{x:1384,y:737,t:1527876724535};\\\", \\\"{x:1386,y:736,t:1527876724551};\\\", \\\"{x:1388,y:735,t:1527876724583};\\\", \\\"{x:1389,y:735,t:1527876724606};\\\", \\\"{x:1391,y:736,t:1527876724647};\\\", \\\"{x:1391,y:742,t:1527876724654};\\\", \\\"{x:1392,y:755,t:1527876724669};\\\", \\\"{x:1392,y:776,t:1527876724686};\\\", \\\"{x:1392,y:791,t:1527876724702};\\\", \\\"{x:1392,y:795,t:1527876724719};\\\", \\\"{x:1392,y:796,t:1527876724737};\\\", \\\"{x:1393,y:795,t:1527876724832};\\\", \\\"{x:1393,y:794,t:1527876724839};\\\", \\\"{x:1393,y:791,t:1527876724852};\\\", \\\"{x:1393,y:788,t:1527876724870};\\\", \\\"{x:1393,y:785,t:1527876724887};\\\", \\\"{x:1393,y:784,t:1527876724902};\\\", \\\"{x:1393,y:782,t:1527876724919};\\\", \\\"{x:1391,y:780,t:1527876724936};\\\", \\\"{x:1389,y:778,t:1527876724952};\\\", \\\"{x:1389,y:777,t:1527876724970};\\\", \\\"{x:1389,y:775,t:1527876724991};\\\", \\\"{x:1389,y:774,t:1527876725023};\\\", \\\"{x:1389,y:772,t:1527876725063};\\\", \\\"{x:1389,y:770,t:1527876725071};\\\", \\\"{x:1389,y:768,t:1527876725087};\\\", \\\"{x:1389,y:761,t:1527876725104};\\\", \\\"{x:1389,y:753,t:1527876725119};\\\", \\\"{x:1394,y:734,t:1527876725137};\\\", \\\"{x:1408,y:705,t:1527876725162};\\\", \\\"{x:1409,y:701,t:1527876725168};\\\", \\\"{x:1419,y:681,t:1527876725186};\\\", \\\"{x:1430,y:661,t:1527876725203};\\\", \\\"{x:1437,y:648,t:1527876725218};\\\", \\\"{x:1442,y:639,t:1527876725235};\\\", \\\"{x:1447,y:630,t:1527876725253};\\\", \\\"{x:1452,y:621,t:1527876725269};\\\", \\\"{x:1461,y:609,t:1527876725285};\\\", \\\"{x:1472,y:594,t:1527876725302};\\\", \\\"{x:1484,y:579,t:1527876725319};\\\", \\\"{x:1499,y:561,t:1527876725336};\\\", \\\"{x:1512,y:545,t:1527876725352};\\\", \\\"{x:1523,y:533,t:1527876725368};\\\", \\\"{x:1528,y:525,t:1527876725386};\\\", \\\"{x:1538,y:508,t:1527876725402};\\\", \\\"{x:1552,y:485,t:1527876725419};\\\", \\\"{x:1561,y:468,t:1527876725435};\\\", \\\"{x:1567,y:458,t:1527876725453};\\\", \\\"{x:1571,y:451,t:1527876725470};\\\", \\\"{x:1576,y:441,t:1527876725486};\\\", \\\"{x:1580,y:433,t:1527876725503};\\\", \\\"{x:1581,y:427,t:1527876725520};\\\", \\\"{x:1581,y:424,t:1527876725536};\\\", \\\"{x:1583,y:422,t:1527876725553};\\\", \\\"{x:1584,y:420,t:1527876725623};\\\", \\\"{x:1585,y:420,t:1527876725636};\\\", \\\"{x:1586,y:419,t:1527876725655};\\\", \\\"{x:1586,y:418,t:1527876725670};\\\", \\\"{x:1587,y:416,t:1527876725686};\\\", \\\"{x:1588,y:415,t:1527876725703};\\\", \\\"{x:1589,y:413,t:1527876725720};\\\", \\\"{x:1590,y:411,t:1527876725736};\\\", \\\"{x:1590,y:410,t:1527876725753};\\\", \\\"{x:1591,y:407,t:1527876725770};\\\", \\\"{x:1592,y:404,t:1527876725787};\\\", \\\"{x:1593,y:403,t:1527876725807};\\\", \\\"{x:1593,y:401,t:1527876725823};\\\", \\\"{x:1593,y:398,t:1527876725837};\\\", \\\"{x:1592,y:388,t:1527876725853};\\\", \\\"{x:1587,y:378,t:1527876725871};\\\", \\\"{x:1585,y:372,t:1527876725887};\\\", \\\"{x:1584,y:369,t:1527876725903};\\\", \\\"{x:1583,y:368,t:1527876725920};\\\", \\\"{x:1582,y:367,t:1527876725937};\\\", \\\"{x:1580,y:366,t:1527876725953};\\\", \\\"{x:1574,y:366,t:1527876725970};\\\", \\\"{x:1570,y:366,t:1527876725987};\\\", \\\"{x:1554,y:375,t:1527876726004};\\\", \\\"{x:1510,y:415,t:1527876726021};\\\", \\\"{x:1444,y:497,t:1527876726037};\\\", \\\"{x:1333,y:604,t:1527876726053};\\\", \\\"{x:1189,y:698,t:1527876726071};\\\", \\\"{x:969,y:832,t:1527876726087};\\\", \\\"{x:847,y:892,t:1527876726103};\\\", \\\"{x:768,y:935,t:1527876726120};\\\", \\\"{x:733,y:948,t:1527876726137};\\\", \\\"{x:691,y:962,t:1527876726153};\\\", \\\"{x:660,y:971,t:1527876726170};\\\", \\\"{x:639,y:978,t:1527876726188};\\\", \\\"{x:616,y:980,t:1527876726204};\\\", \\\"{x:584,y:984,t:1527876726221};\\\", \\\"{x:544,y:992,t:1527876726237};\\\", \\\"{x:466,y:1003,t:1527876726253};\\\", \\\"{x:392,y:1017,t:1527876726271};\\\", \\\"{x:345,y:1017,t:1527876726287};\\\", \\\"{x:331,y:1007,t:1527876726304};\\\", \\\"{x:324,y:987,t:1527876726320};\\\", \\\"{x:321,y:962,t:1527876726337};\\\", \\\"{x:328,y:938,t:1527876726354};\\\", \\\"{x:342,y:905,t:1527876726371};\\\", \\\"{x:362,y:871,t:1527876726387};\\\", \\\"{x:384,y:841,t:1527876726405};\\\", \\\"{x:395,y:821,t:1527876726420};\\\", \\\"{x:409,y:805,t:1527876726437};\\\", \\\"{x:415,y:796,t:1527876726454};\\\", \\\"{x:417,y:795,t:1527876726470};\\\", \\\"{x:418,y:794,t:1527876726487};\\\", \\\"{x:422,y:792,t:1527876726505};\\\", \\\"{x:425,y:790,t:1527876726520};\\\", \\\"{x:427,y:788,t:1527876726537};\\\", \\\"{x:428,y:787,t:1527876726554};\\\", \\\"{x:429,y:786,t:1527876726570};\\\", \\\"{x:431,y:785,t:1527876726588};\\\", \\\"{x:442,y:780,t:1527876726604};\\\", \\\"{x:456,y:772,t:1527876726620};\\\", \\\"{x:473,y:763,t:1527876726639};\\\", \\\"{x:478,y:760,t:1527876726653};\\\", \\\"{x:483,y:757,t:1527876726670};\\\", \\\"{x:488,y:756,t:1527876726687};\\\", \\\"{x:490,y:753,t:1527876726704};\\\", \\\"{x:491,y:752,t:1527876726721};\\\", \\\"{x:493,y:750,t:1527876726737};\\\", \\\"{x:498,y:747,t:1527876728223};\\\", \\\"{x:502,y:745,t:1527876728238};\\\", \\\"{x:507,y:743,t:1527876728255};\\\", \\\"{x:508,y:742,t:1527876728272};\\\", \\\"{x:510,y:741,t:1527876728288};\\\", \\\"{x:512,y:741,t:1527876728305};\\\", \\\"{x:514,y:740,t:1527876728323};\\\", \\\"{x:515,y:739,t:1527876728338};\\\", \\\"{x:516,y:738,t:1527876728375};\\\", \\\"{x:518,y:737,t:1527876728388};\\\", \\\"{x:520,y:734,t:1527876728405};\\\", \\\"{x:530,y:727,t:1527876728422};\\\", \\\"{x:540,y:721,t:1527876728439};\\\", \\\"{x:550,y:712,t:1527876728455};\\\", \\\"{x:565,y:701,t:1527876728473};\\\", \\\"{x:575,y:692,t:1527876728488};\\\", \\\"{x:584,y:690,t:1527876728505};\\\", \\\"{x:594,y:681,t:1527876728522};\\\", \\\"{x:604,y:671,t:1527876728538};\\\", \\\"{x:612,y:661,t:1527876728555};\\\", \\\"{x:615,y:653,t:1527876728572};\\\", \\\"{x:618,y:648,t:1527876728589};\\\", \\\"{x:619,y:646,t:1527876728605};\\\", \\\"{x:619,y:645,t:1527876728642};\\\" ] }, { \\\"rt\\\": 16224, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 142077, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -A -F -K -H -D -D -D -D -D -K -K -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:620,y:643,t:1527876728945};\\\", \\\"{x:621,y:643,t:1527876729428};\\\", \\\"{x:621,y:642,t:1527876729445};\\\", \\\"{x:621,y:641,t:1527876729582};\\\", \\\"{x:622,y:639,t:1527876729590};\\\", \\\"{x:632,y:635,t:1527876729606};\\\", \\\"{x:648,y:629,t:1527876729624};\\\", \\\"{x:670,y:627,t:1527876729640};\\\", \\\"{x:696,y:625,t:1527876729655};\\\", \\\"{x:728,y:625,t:1527876729674};\\\", \\\"{x:756,y:626,t:1527876729689};\\\", \\\"{x:785,y:629,t:1527876729706};\\\", \\\"{x:806,y:635,t:1527876729722};\\\", \\\"{x:818,y:638,t:1527876729738};\\\", \\\"{x:821,y:640,t:1527876729756};\\\", \\\"{x:822,y:641,t:1527876729773};\\\", \\\"{x:823,y:641,t:1527876729911};\\\", \\\"{x:823,y:642,t:1527876730479};\\\", \\\"{x:824,y:643,t:1527876730490};\\\", \\\"{x:845,y:654,t:1527876730509};\\\", \\\"{x:874,y:661,t:1527876730523};\\\", \\\"{x:924,y:673,t:1527876730540};\\\", \\\"{x:971,y:686,t:1527876730557};\\\", \\\"{x:1048,y:706,t:1527876730574};\\\", \\\"{x:1102,y:722,t:1527876730590};\\\", \\\"{x:1153,y:740,t:1527876730606};\\\", \\\"{x:1211,y:755,t:1527876730624};\\\", \\\"{x:1251,y:767,t:1527876730641};\\\", \\\"{x:1281,y:776,t:1527876730657};\\\", \\\"{x:1316,y:788,t:1527876730673};\\\", \\\"{x:1334,y:793,t:1527876730691};\\\", \\\"{x:1345,y:794,t:1527876730707};\\\", \\\"{x:1350,y:795,t:1527876730724};\\\", \\\"{x:1352,y:796,t:1527876730741};\\\", \\\"{x:1354,y:797,t:1527876730757};\\\", \\\"{x:1354,y:798,t:1527876730774};\\\", \\\"{x:1355,y:798,t:1527876730847};\\\", \\\"{x:1356,y:799,t:1527876730871};\\\", \\\"{x:1356,y:801,t:1527876730879};\\\", \\\"{x:1356,y:804,t:1527876730891};\\\", \\\"{x:1358,y:814,t:1527876730908};\\\", \\\"{x:1358,y:829,t:1527876730924};\\\", \\\"{x:1359,y:837,t:1527876730941};\\\", \\\"{x:1359,y:839,t:1527876730958};\\\", \\\"{x:1360,y:840,t:1527876730975};\\\", \\\"{x:1360,y:841,t:1527876730991};\\\", \\\"{x:1360,y:846,t:1527876731008};\\\", \\\"{x:1360,y:847,t:1527876731024};\\\", \\\"{x:1359,y:848,t:1527876731041};\\\", \\\"{x:1358,y:850,t:1527876731063};\\\", \\\"{x:1358,y:852,t:1527876731095};\\\", \\\"{x:1360,y:852,t:1527876731239};\\\", \\\"{x:1365,y:848,t:1527876731247};\\\", \\\"{x:1372,y:845,t:1527876731259};\\\", \\\"{x:1380,y:838,t:1527876731276};\\\", \\\"{x:1392,y:831,t:1527876731292};\\\", \\\"{x:1401,y:827,t:1527876731309};\\\", \\\"{x:1407,y:827,t:1527876731326};\\\", \\\"{x:1409,y:825,t:1527876731343};\\\", \\\"{x:1410,y:825,t:1527876731358};\\\", \\\"{x:1410,y:824,t:1527876731431};\\\", \\\"{x:1410,y:823,t:1527876731447};\\\", \\\"{x:1407,y:822,t:1527876731459};\\\", \\\"{x:1398,y:822,t:1527876731475};\\\", \\\"{x:1388,y:827,t:1527876731493};\\\", \\\"{x:1380,y:828,t:1527876731509};\\\", \\\"{x:1374,y:831,t:1527876731526};\\\", \\\"{x:1359,y:831,t:1527876731543};\\\", \\\"{x:1342,y:830,t:1527876731559};\\\", \\\"{x:1327,y:829,t:1527876731576};\\\", \\\"{x:1315,y:826,t:1527876731592};\\\", \\\"{x:1305,y:826,t:1527876731609};\\\", \\\"{x:1296,y:826,t:1527876731625};\\\", \\\"{x:1283,y:826,t:1527876731653};\\\", \\\"{x:1279,y:826,t:1527876731676};\\\", \\\"{x:1278,y:825,t:1527876731718};\\\", \\\"{x:1278,y:822,t:1527876731767};\\\", \\\"{x:1278,y:819,t:1527876731774};\\\", \\\"{x:1286,y:808,t:1527876731791};\\\", \\\"{x:1291,y:802,t:1527876731807};\\\", \\\"{x:1303,y:794,t:1527876731824};\\\", \\\"{x:1321,y:789,t:1527876731841};\\\", \\\"{x:1337,y:784,t:1527876731858};\\\", \\\"{x:1350,y:779,t:1527876731874};\\\", \\\"{x:1359,y:775,t:1527876731891};\\\", \\\"{x:1362,y:773,t:1527876731908};\\\", \\\"{x:1364,y:773,t:1527876731924};\\\", \\\"{x:1367,y:770,t:1527876731941};\\\", \\\"{x:1368,y:767,t:1527876731958};\\\", \\\"{x:1370,y:761,t:1527876731974};\\\", \\\"{x:1374,y:752,t:1527876731991};\\\", \\\"{x:1377,y:745,t:1527876732008};\\\", \\\"{x:1380,y:737,t:1527876732024};\\\", \\\"{x:1385,y:726,t:1527876732041};\\\", \\\"{x:1388,y:711,t:1527876732058};\\\", \\\"{x:1388,y:694,t:1527876732075};\\\", \\\"{x:1388,y:682,t:1527876732091};\\\", \\\"{x:1388,y:678,t:1527876732108};\\\", \\\"{x:1388,y:675,t:1527876732125};\\\", \\\"{x:1388,y:664,t:1527876732141};\\\", \\\"{x:1388,y:654,t:1527876732158};\\\", \\\"{x:1388,y:652,t:1527876732175};\\\", \\\"{x:1388,y:651,t:1527876732190};\\\", \\\"{x:1388,y:650,t:1527876732327};\\\", \\\"{x:1389,y:650,t:1527876732341};\\\", \\\"{x:1394,y:650,t:1527876732359};\\\", \\\"{x:1404,y:650,t:1527876732375};\\\", \\\"{x:1415,y:650,t:1527876732391};\\\", \\\"{x:1429,y:648,t:1527876732408};\\\", \\\"{x:1443,y:648,t:1527876732425};\\\", \\\"{x:1451,y:648,t:1527876732441};\\\", \\\"{x:1456,y:648,t:1527876732458};\\\", \\\"{x:1458,y:647,t:1527876732475};\\\", \\\"{x:1459,y:646,t:1527876732495};\\\", \\\"{x:1461,y:645,t:1527876732519};\\\", \\\"{x:1463,y:643,t:1527876732534};\\\", \\\"{x:1464,y:643,t:1527876732551};\\\", \\\"{x:1465,y:643,t:1527876732576};\\\", \\\"{x:1467,y:643,t:1527876732592};\\\", \\\"{x:1472,y:645,t:1527876732608};\\\", \\\"{x:1474,y:647,t:1527876732625};\\\", \\\"{x:1480,y:653,t:1527876732645};\\\", \\\"{x:1493,y:669,t:1527876732657};\\\", \\\"{x:1509,y:684,t:1527876732675};\\\", \\\"{x:1526,y:702,t:1527876732692};\\\", \\\"{x:1538,y:713,t:1527876732708};\\\", \\\"{x:1550,y:720,t:1527876732724};\\\", \\\"{x:1564,y:730,t:1527876732742};\\\", \\\"{x:1573,y:738,t:1527876732758};\\\", \\\"{x:1584,y:750,t:1527876732775};\\\", \\\"{x:1591,y:755,t:1527876732792};\\\", \\\"{x:1592,y:757,t:1527876732808};\\\", \\\"{x:1594,y:759,t:1527876732825};\\\", \\\"{x:1597,y:759,t:1527876732911};\\\", \\\"{x:1599,y:759,t:1527876732925};\\\", \\\"{x:1603,y:759,t:1527876732943};\\\", \\\"{x:1605,y:758,t:1527876732959};\\\", \\\"{x:1607,y:755,t:1527876732975};\\\", \\\"{x:1610,y:744,t:1527876732992};\\\", \\\"{x:1610,y:725,t:1527876733009};\\\", \\\"{x:1604,y:707,t:1527876733025};\\\", \\\"{x:1598,y:689,t:1527876733043};\\\", \\\"{x:1587,y:672,t:1527876733059};\\\", \\\"{x:1568,y:654,t:1527876733075};\\\", \\\"{x:1543,y:636,t:1527876733092};\\\", \\\"{x:1516,y:616,t:1527876733109};\\\", \\\"{x:1482,y:599,t:1527876733126};\\\", \\\"{x:1447,y:582,t:1527876733143};\\\", \\\"{x:1427,y:573,t:1527876733159};\\\", \\\"{x:1415,y:566,t:1527876733175};\\\", \\\"{x:1402,y:554,t:1527876733209};\\\", \\\"{x:1388,y:544,t:1527876733225};\\\", \\\"{x:1373,y:533,t:1527876733243};\\\", \\\"{x:1366,y:528,t:1527876733259};\\\", \\\"{x:1365,y:526,t:1527876733275};\\\", \\\"{x:1363,y:523,t:1527876733292};\\\", \\\"{x:1359,y:514,t:1527876733309};\\\", \\\"{x:1358,y:510,t:1527876733325};\\\", \\\"{x:1358,y:504,t:1527876733342};\\\", \\\"{x:1358,y:503,t:1527876733359};\\\", \\\"{x:1367,y:493,t:1527876733375};\\\", \\\"{x:1375,y:484,t:1527876733392};\\\", \\\"{x:1382,y:473,t:1527876733409};\\\", \\\"{x:1385,y:468,t:1527876733426};\\\", \\\"{x:1387,y:466,t:1527876733442};\\\", \\\"{x:1388,y:464,t:1527876733459};\\\", \\\"{x:1390,y:462,t:1527876733476};\\\", \\\"{x:1396,y:460,t:1527876733492};\\\", \\\"{x:1408,y:458,t:1527876733509};\\\", \\\"{x:1415,y:454,t:1527876733526};\\\", \\\"{x:1423,y:452,t:1527876733542};\\\", \\\"{x:1428,y:450,t:1527876733559};\\\", \\\"{x:1434,y:448,t:1527876733576};\\\", \\\"{x:1439,y:446,t:1527876733592};\\\", \\\"{x:1443,y:444,t:1527876733609};\\\", \\\"{x:1444,y:443,t:1527876733626};\\\", \\\"{x:1447,y:443,t:1527876733643};\\\", \\\"{x:1449,y:443,t:1527876733659};\\\", \\\"{x:1450,y:443,t:1527876733676};\\\", \\\"{x:1453,y:444,t:1527876733692};\\\", \\\"{x:1456,y:447,t:1527876733708};\\\", \\\"{x:1462,y:458,t:1527876733725};\\\", \\\"{x:1470,y:476,t:1527876733743};\\\", \\\"{x:1477,y:489,t:1527876733759};\\\", \\\"{x:1490,y:505,t:1527876733775};\\\", \\\"{x:1501,y:511,t:1527876733793};\\\", \\\"{x:1510,y:511,t:1527876733809};\\\", \\\"{x:1522,y:511,t:1527876733826};\\\", \\\"{x:1533,y:511,t:1527876733843};\\\", \\\"{x:1544,y:507,t:1527876733859};\\\", \\\"{x:1558,y:501,t:1527876733876};\\\", \\\"{x:1570,y:496,t:1527876733893};\\\", \\\"{x:1585,y:489,t:1527876733909};\\\", \\\"{x:1598,y:476,t:1527876733926};\\\", \\\"{x:1606,y:464,t:1527876733943};\\\", \\\"{x:1609,y:458,t:1527876733959};\\\", \\\"{x:1611,y:454,t:1527876733976};\\\", \\\"{x:1612,y:453,t:1527876733993};\\\", \\\"{x:1613,y:451,t:1527876734009};\\\", \\\"{x:1614,y:450,t:1527876734030};\\\", \\\"{x:1614,y:449,t:1527876734043};\\\", \\\"{x:1614,y:448,t:1527876734086};\\\", \\\"{x:1615,y:447,t:1527876734094};\\\", \\\"{x:1616,y:445,t:1527876734109};\\\", \\\"{x:1617,y:444,t:1527876734126};\\\", \\\"{x:1617,y:443,t:1527876734143};\\\", \\\"{x:1618,y:442,t:1527876734207};\\\", \\\"{x:1618,y:440,t:1527876734255};\\\", \\\"{x:1616,y:439,t:1527876734311};\\\", \\\"{x:1616,y:438,t:1527876734327};\\\", \\\"{x:1615,y:436,t:1527876734344};\\\", \\\"{x:1614,y:435,t:1527876734364};\\\", \\\"{x:1613,y:435,t:1527876734438};\\\", \\\"{x:1611,y:435,t:1527876734446};\\\", \\\"{x:1610,y:435,t:1527876734470};\\\", \\\"{x:1610,y:434,t:1527876734542};\\\", \\\"{x:1609,y:434,t:1527876734975};\\\", \\\"{x:1608,y:435,t:1527876734991};\\\", \\\"{x:1609,y:435,t:1527876735191};\\\", \\\"{x:1611,y:434,t:1527876735218};\\\", \\\"{x:1611,y:433,t:1527876735244};\\\", \\\"{x:1611,y:431,t:1527876735260};\\\", \\\"{x:1612,y:430,t:1527876735277};\\\", \\\"{x:1613,y:429,t:1527876735390};\\\", \\\"{x:1615,y:427,t:1527876735398};\\\", \\\"{x:1615,y:426,t:1527876735414};\\\", \\\"{x:1615,y:425,t:1527876735427};\\\", \\\"{x:1617,y:424,t:1527876735445};\\\", \\\"{x:1616,y:424,t:1527876735863};\\\", \\\"{x:1615,y:424,t:1527876735951};\\\", \\\"{x:1614,y:424,t:1527876736023};\\\", \\\"{x:1612,y:424,t:1527876736071};\\\", \\\"{x:1610,y:426,t:1527876736081};\\\", \\\"{x:1608,y:426,t:1527876736096};\\\", \\\"{x:1607,y:427,t:1527876736328};\\\", \\\"{x:1607,y:428,t:1527876736480};\\\", \\\"{x:1607,y:429,t:1527876736495};\\\", \\\"{x:1606,y:430,t:1527876736511};\\\", \\\"{x:1605,y:430,t:1527876736528};\\\", \\\"{x:1605,y:431,t:1527876736545};\\\", \\\"{x:1605,y:432,t:1527876736822};\\\", \\\"{x:1606,y:432,t:1527876737159};\\\", \\\"{x:1607,y:432,t:1527876737175};\\\", \\\"{x:1608,y:432,t:1527876737255};\\\", \\\"{x:1609,y:432,t:1527876737266};\\\", \\\"{x:1610,y:432,t:1527876737279};\\\", \\\"{x:1611,y:432,t:1527876737294};\\\", \\\"{x:1613,y:432,t:1527876737790};\\\", \\\"{x:1613,y:431,t:1527876738551};\\\", \\\"{x:1613,y:432,t:1527876739103};\\\", \\\"{x:1613,y:438,t:1527876739112};\\\", \\\"{x:1610,y:446,t:1527876739125};\\\", \\\"{x:1597,y:471,t:1527876739148};\\\", \\\"{x:1589,y:490,t:1527876739163};\\\", \\\"{x:1581,y:507,t:1527876739180};\\\", \\\"{x:1575,y:523,t:1527876739197};\\\", \\\"{x:1568,y:547,t:1527876739213};\\\", \\\"{x:1558,y:579,t:1527876739230};\\\", \\\"{x:1553,y:595,t:1527876739248};\\\", \\\"{x:1548,y:604,t:1527876739263};\\\", \\\"{x:1543,y:615,t:1527876739280};\\\", \\\"{x:1537,y:627,t:1527876739298};\\\", \\\"{x:1530,y:638,t:1527876739313};\\\", \\\"{x:1528,y:642,t:1527876739330};\\\", \\\"{x:1525,y:647,t:1527876739347};\\\", \\\"{x:1524,y:650,t:1527876739363};\\\", \\\"{x:1521,y:656,t:1527876739380};\\\", \\\"{x:1517,y:661,t:1527876739397};\\\", \\\"{x:1515,y:664,t:1527876739414};\\\", \\\"{x:1514,y:663,t:1527876739503};\\\", \\\"{x:1514,y:662,t:1527876739514};\\\", \\\"{x:1514,y:659,t:1527876739531};\\\", \\\"{x:1514,y:655,t:1527876739548};\\\", \\\"{x:1514,y:651,t:1527876739565};\\\", \\\"{x:1515,y:647,t:1527876739581};\\\", \\\"{x:1516,y:643,t:1527876739598};\\\", \\\"{x:1517,y:638,t:1527876739614};\\\", \\\"{x:1517,y:636,t:1527876739631};\\\", \\\"{x:1518,y:635,t:1527876739649};\\\", \\\"{x:1518,y:634,t:1527876739674};\\\", \\\"{x:1518,y:633,t:1527876739697};\\\", \\\"{x:1518,y:632,t:1527876739714};\\\", \\\"{x:1519,y:631,t:1527876739733};\\\", \\\"{x:1520,y:630,t:1527876739757};\\\", \\\"{x:1521,y:629,t:1527876739767};\\\", \\\"{x:1521,y:628,t:1527876739781};\\\", \\\"{x:1523,y:626,t:1527876739797};\\\", \\\"{x:1523,y:625,t:1527876739814};\\\", \\\"{x:1523,y:623,t:1527876739830};\\\", \\\"{x:1522,y:623,t:1527876740207};\\\", \\\"{x:1521,y:624,t:1527876740239};\\\", \\\"{x:1521,y:625,t:1527876740248};\\\", \\\"{x:1520,y:625,t:1527876740278};\\\", \\\"{x:1520,y:626,t:1527876740335};\\\", \\\"{x:1519,y:627,t:1527876740395};\\\", \\\"{x:1519,y:628,t:1527876741015};\\\", \\\"{x:1519,y:630,t:1527876741038};\\\", \\\"{x:1518,y:631,t:1527876741048};\\\", \\\"{x:1516,y:635,t:1527876741065};\\\", \\\"{x:1514,y:640,t:1527876741082};\\\", \\\"{x:1510,y:648,t:1527876741099};\\\", \\\"{x:1506,y:660,t:1527876741115};\\\", \\\"{x:1496,y:686,t:1527876741131};\\\", \\\"{x:1486,y:707,t:1527876741148};\\\", \\\"{x:1479,y:724,t:1527876741166};\\\", \\\"{x:1476,y:735,t:1527876741181};\\\", \\\"{x:1471,y:751,t:1527876741198};\\\", \\\"{x:1467,y:760,t:1527876741215};\\\", \\\"{x:1465,y:769,t:1527876741231};\\\", \\\"{x:1462,y:774,t:1527876741248};\\\", \\\"{x:1462,y:781,t:1527876741265};\\\", \\\"{x:1460,y:791,t:1527876741282};\\\", \\\"{x:1460,y:796,t:1527876741298};\\\", \\\"{x:1460,y:803,t:1527876741315};\\\", \\\"{x:1460,y:806,t:1527876741332};\\\", \\\"{x:1460,y:809,t:1527876741348};\\\", \\\"{x:1460,y:810,t:1527876741366};\\\", \\\"{x:1460,y:813,t:1527876741382};\\\", \\\"{x:1461,y:816,t:1527876741398};\\\", \\\"{x:1461,y:817,t:1527876741416};\\\", \\\"{x:1462,y:818,t:1527876741432};\\\", \\\"{x:1462,y:819,t:1527876741449};\\\", \\\"{x:1463,y:819,t:1527876741470};\\\", \\\"{x:1464,y:820,t:1527876741542};\\\", \\\"{x:1466,y:820,t:1527876741590};\\\", \\\"{x:1467,y:820,t:1527876741598};\\\", \\\"{x:1470,y:820,t:1527876741615};\\\", \\\"{x:1471,y:820,t:1527876741632};\\\", \\\"{x:1474,y:820,t:1527876741649};\\\", \\\"{x:1477,y:820,t:1527876741665};\\\", \\\"{x:1482,y:820,t:1527876741683};\\\", \\\"{x:1489,y:820,t:1527876741700};\\\", \\\"{x:1490,y:820,t:1527876741715};\\\", \\\"{x:1491,y:820,t:1527876741733};\\\", \\\"{x:1490,y:821,t:1527876741999};\\\", \\\"{x:1489,y:822,t:1527876742016};\\\", \\\"{x:1489,y:823,t:1527876742055};\\\", \\\"{x:1489,y:825,t:1527876742191};\\\", \\\"{x:1489,y:827,t:1527876742207};\\\", \\\"{x:1489,y:830,t:1527876742217};\\\", \\\"{x:1489,y:832,t:1527876742234};\\\", \\\"{x:1489,y:834,t:1527876742249};\\\", \\\"{x:1489,y:835,t:1527876742266};\\\", \\\"{x:1485,y:835,t:1527876742543};\\\", \\\"{x:1477,y:835,t:1527876742551};\\\", \\\"{x:1462,y:835,t:1527876742567};\\\", \\\"{x:1438,y:836,t:1527876742587};\\\", \\\"{x:1409,y:839,t:1527876742599};\\\", \\\"{x:1387,y:840,t:1527876742616};\\\", \\\"{x:1353,y:840,t:1527876742633};\\\", \\\"{x:1324,y:840,t:1527876742649};\\\", \\\"{x:1269,y:839,t:1527876742667};\\\", \\\"{x:1163,y:835,t:1527876742683};\\\", \\\"{x:1076,y:820,t:1527876742700};\\\", \\\"{x:998,y:809,t:1527876742716};\\\", \\\"{x:944,y:802,t:1527876742734};\\\", \\\"{x:900,y:790,t:1527876742749};\\\", \\\"{x:841,y:773,t:1527876742767};\\\", \\\"{x:804,y:759,t:1527876742783};\\\", \\\"{x:768,y:747,t:1527876742799};\\\", \\\"{x:743,y:737,t:1527876742816};\\\", \\\"{x:717,y:727,t:1527876742834};\\\", \\\"{x:691,y:715,t:1527876742849};\\\", \\\"{x:664,y:704,t:1527876742867};\\\", \\\"{x:639,y:691,t:1527876742884};\\\", \\\"{x:615,y:681,t:1527876742900};\\\", \\\"{x:599,y:672,t:1527876742917};\\\", \\\"{x:591,y:667,t:1527876742933};\\\", \\\"{x:589,y:665,t:1527876742949};\\\", \\\"{x:587,y:659,t:1527876742966};\\\", \\\"{x:586,y:655,t:1527876742984};\\\", \\\"{x:586,y:653,t:1527876743000};\\\", \\\"{x:585,y:651,t:1527876743016};\\\", \\\"{x:583,y:649,t:1527876743038};\\\", \\\"{x:580,y:648,t:1527876743062};\\\", \\\"{x:578,y:647,t:1527876743070};\\\", \\\"{x:572,y:646,t:1527876743083};\\\", \\\"{x:559,y:642,t:1527876743100};\\\", \\\"{x:541,y:642,t:1527876743116};\\\", \\\"{x:523,y:642,t:1527876743133};\\\", \\\"{x:501,y:642,t:1527876743150};\\\", \\\"{x:489,y:642,t:1527876743167};\\\", \\\"{x:482,y:642,t:1527876743183};\\\", \\\"{x:477,y:642,t:1527876743200};\\\", \\\"{x:465,y:641,t:1527876743216};\\\", \\\"{x:461,y:641,t:1527876743233};\\\", \\\"{x:460,y:641,t:1527876743250};\\\", \\\"{x:459,y:641,t:1527876743266};\\\", \\\"{x:458,y:641,t:1527876743302};\\\", \\\"{x:458,y:640,t:1527876743359};\\\", \\\"{x:455,y:640,t:1527876743366};\\\", \\\"{x:452,y:640,t:1527876743383};\\\", \\\"{x:450,y:638,t:1527876743401};\\\", \\\"{x:448,y:638,t:1527876743416};\\\", \\\"{x:446,y:638,t:1527876743434};\\\", \\\"{x:444,y:638,t:1527876743451};\\\", \\\"{x:440,y:637,t:1527876743467};\\\", \\\"{x:438,y:637,t:1527876743484};\\\", \\\"{x:437,y:637,t:1527876743534};\\\", \\\"{x:438,y:642,t:1527876743815};\\\", \\\"{x:441,y:647,t:1527876743823};\\\", \\\"{x:445,y:651,t:1527876743835};\\\", \\\"{x:457,y:663,t:1527876743852};\\\", \\\"{x:465,y:673,t:1527876743868};\\\", \\\"{x:476,y:685,t:1527876743884};\\\", \\\"{x:487,y:703,t:1527876743901};\\\", \\\"{x:499,y:723,t:1527876743917};\\\", \\\"{x:513,y:743,t:1527876743934};\\\", \\\"{x:520,y:749,t:1527876743950};\\\", \\\"{x:522,y:750,t:1527876743968};\\\", \\\"{x:521,y:749,t:1527876744014};\\\", \\\"{x:516,y:746,t:1527876744022};\\\", \\\"{x:506,y:741,t:1527876744034};\\\", \\\"{x:486,y:735,t:1527876744051};\\\", \\\"{x:471,y:733,t:1527876744067};\\\", \\\"{x:455,y:729,t:1527876744085};\\\", \\\"{x:435,y:722,t:1527876744101};\\\", \\\"{x:419,y:715,t:1527876744117};\\\", \\\"{x:400,y:703,t:1527876744134};\\\", \\\"{x:391,y:696,t:1527876744152};\\\", \\\"{x:376,y:685,t:1527876744168};\\\", \\\"{x:362,y:676,t:1527876744184};\\\", \\\"{x:347,y:667,t:1527876744200};\\\", \\\"{x:337,y:661,t:1527876744217};\\\", \\\"{x:333,y:658,t:1527876744234};\\\", \\\"{x:333,y:657,t:1527876744294};\\\", \\\"{x:335,y:655,t:1527876744303};\\\", \\\"{x:339,y:654,t:1527876744317};\\\", \\\"{x:357,y:649,t:1527876744334};\\\", \\\"{x:368,y:646,t:1527876744352};\\\", \\\"{x:375,y:644,t:1527876744368};\\\", \\\"{x:377,y:644,t:1527876744385};\\\", \\\"{x:379,y:643,t:1527876744463};\\\", \\\"{x:380,y:642,t:1527876744470};\\\", \\\"{x:381,y:641,t:1527876744487};\\\", \\\"{x:382,y:641,t:1527876744702};\\\", \\\"{x:390,y:643,t:1527876744718};\\\", \\\"{x:406,y:649,t:1527876744735};\\\", \\\"{x:422,y:661,t:1527876744751};\\\", \\\"{x:443,y:676,t:1527876744768};\\\", \\\"{x:462,y:693,t:1527876744784};\\\", \\\"{x:481,y:709,t:1527876744801};\\\", \\\"{x:504,y:721,t:1527876744819};\\\", \\\"{x:523,y:734,t:1527876744834};\\\", \\\"{x:541,y:746,t:1527876744851};\\\", \\\"{x:553,y:752,t:1527876744868};\\\", \\\"{x:558,y:754,t:1527876744884};\\\", \\\"{x:560,y:754,t:1527876744901};\\\", \\\"{x:566,y:754,t:1527876745375};\\\", \\\"{x:579,y:746,t:1527876745386};\\\", \\\"{x:623,y:729,t:1527876745401};\\\", \\\"{x:695,y:694,t:1527876745418};\\\", \\\"{x:800,y:647,t:1527876745436};\\\", \\\"{x:888,y:612,t:1527876745452};\\\", \\\"{x:948,y:578,t:1527876745469};\\\", \\\"{x:994,y:544,t:1527876745485};\\\", \\\"{x:1023,y:524,t:1527876745501};\\\", \\\"{x:1029,y:521,t:1527876745519};\\\", \\\"{x:1031,y:519,t:1527876745535};\\\" ] }, { \\\"rt\\\": 21592, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 164900, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -F -Z -O -O -H -F -A -C -C -K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1030,y:519,t:1527876746757};\\\", \\\"{x:1029,y:519,t:1527876746773};\\\", \\\"{x:1028,y:519,t:1527876746786};\\\", \\\"{x:1026,y:519,t:1527876746803};\\\", \\\"{x:1024,y:520,t:1527876746820};\\\", \\\"{x:1021,y:521,t:1527876746836};\\\", \\\"{x:1018,y:521,t:1527876746852};\\\", \\\"{x:1011,y:524,t:1527876746870};\\\", \\\"{x:1007,y:525,t:1527876746886};\\\", \\\"{x:997,y:530,t:1527876746903};\\\", \\\"{x:984,y:534,t:1527876746920};\\\", \\\"{x:975,y:538,t:1527876746937};\\\", \\\"{x:958,y:540,t:1527876746952};\\\", \\\"{x:943,y:541,t:1527876746969};\\\", \\\"{x:936,y:543,t:1527876746987};\\\", \\\"{x:934,y:543,t:1527876747004};\\\", \\\"{x:931,y:543,t:1527876747019};\\\", \\\"{x:928,y:544,t:1527876747037};\\\", \\\"{x:924,y:546,t:1527876747053};\\\", \\\"{x:920,y:549,t:1527876747069};\\\", \\\"{x:914,y:552,t:1527876747086};\\\", \\\"{x:905,y:556,t:1527876747103};\\\", \\\"{x:896,y:563,t:1527876747119};\\\", \\\"{x:890,y:565,t:1527876747136};\\\", \\\"{x:885,y:569,t:1527876747154};\\\", \\\"{x:878,y:572,t:1527876747170};\\\", \\\"{x:869,y:576,t:1527876747188};\\\", \\\"{x:855,y:579,t:1527876747204};\\\", \\\"{x:845,y:583,t:1527876747220};\\\", \\\"{x:834,y:589,t:1527876747237};\\\", \\\"{x:823,y:592,t:1527876747254};\\\", \\\"{x:819,y:593,t:1527876747270};\\\", \\\"{x:817,y:594,t:1527876747286};\\\", \\\"{x:817,y:595,t:1527876747309};\\\", \\\"{x:816,y:595,t:1527876747320};\\\", \\\"{x:814,y:598,t:1527876747336};\\\", \\\"{x:812,y:598,t:1527876747354};\\\", \\\"{x:811,y:599,t:1527876747369};\\\", \\\"{x:810,y:599,t:1527876747414};\\\", \\\"{x:809,y:599,t:1527876747430};\\\", \\\"{x:808,y:599,t:1527876747471};\\\", \\\"{x:806,y:602,t:1527876747487};\\\", \\\"{x:802,y:602,t:1527876747504};\\\", \\\"{x:799,y:604,t:1527876747521};\\\", \\\"{x:797,y:605,t:1527876747536};\\\", \\\"{x:796,y:605,t:1527876747566};\\\", \\\"{x:794,y:607,t:1527876747590};\\\", \\\"{x:792,y:608,t:1527876747606};\\\", \\\"{x:792,y:609,t:1527876747621};\\\", \\\"{x:790,y:609,t:1527876747637};\\\", \\\"{x:788,y:611,t:1527876747655};\\\", \\\"{x:787,y:613,t:1527876747670};\\\", \\\"{x:786,y:613,t:1527876747687};\\\", \\\"{x:785,y:613,t:1527876747703};\\\", \\\"{x:783,y:615,t:1527876747741};\\\", \\\"{x:782,y:615,t:1527876747870};\\\", \\\"{x:783,y:615,t:1527876748223};\\\", \\\"{x:794,y:615,t:1527876748239};\\\", \\\"{x:807,y:619,t:1527876748259};\\\", \\\"{x:826,y:625,t:1527876748271};\\\", \\\"{x:847,y:627,t:1527876748287};\\\", \\\"{x:867,y:632,t:1527876748305};\\\", \\\"{x:881,y:636,t:1527876748320};\\\", \\\"{x:891,y:638,t:1527876748337};\\\", \\\"{x:897,y:641,t:1527876748354};\\\", \\\"{x:898,y:641,t:1527876748370};\\\", \\\"{x:899,y:641,t:1527876748438};\\\", \\\"{x:901,y:643,t:1527876749015};\\\", \\\"{x:903,y:648,t:1527876749023};\\\", \\\"{x:904,y:651,t:1527876749039};\\\", \\\"{x:906,y:655,t:1527876749053};\\\", \\\"{x:910,y:665,t:1527876749072};\\\", \\\"{x:911,y:668,t:1527876749088};\\\", \\\"{x:913,y:671,t:1527876749105};\\\", \\\"{x:913,y:672,t:1527876749122};\\\", \\\"{x:914,y:674,t:1527876749138};\\\", \\\"{x:916,y:676,t:1527876749155};\\\", \\\"{x:916,y:677,t:1527876749172};\\\", \\\"{x:917,y:678,t:1527876749188};\\\", \\\"{x:917,y:679,t:1527876749205};\\\", \\\"{x:920,y:683,t:1527876749222};\\\", \\\"{x:923,y:686,t:1527876749238};\\\", \\\"{x:928,y:690,t:1527876749255};\\\", \\\"{x:936,y:696,t:1527876749272};\\\", \\\"{x:945,y:699,t:1527876749288};\\\", \\\"{x:957,y:707,t:1527876749305};\\\", \\\"{x:975,y:712,t:1527876749322};\\\", \\\"{x:995,y:719,t:1527876749338};\\\", \\\"{x:1018,y:725,t:1527876749355};\\\", \\\"{x:1046,y:732,t:1527876749372};\\\", \\\"{x:1070,y:740,t:1527876749388};\\\", \\\"{x:1097,y:746,t:1527876749405};\\\", \\\"{x:1149,y:763,t:1527876749423};\\\", \\\"{x:1172,y:769,t:1527876749439};\\\", \\\"{x:1195,y:777,t:1527876749455};\\\", \\\"{x:1218,y:780,t:1527876749472};\\\", \\\"{x:1244,y:786,t:1527876749488};\\\", \\\"{x:1265,y:790,t:1527876749506};\\\", \\\"{x:1285,y:792,t:1527876749522};\\\", \\\"{x:1302,y:796,t:1527876749538};\\\", \\\"{x:1309,y:799,t:1527876749555};\\\", \\\"{x:1324,y:801,t:1527876749571};\\\", \\\"{x:1339,y:805,t:1527876749588};\\\", \\\"{x:1355,y:809,t:1527876749605};\\\", \\\"{x:1370,y:813,t:1527876749623};\\\", \\\"{x:1375,y:814,t:1527876749639};\\\", \\\"{x:1379,y:816,t:1527876749656};\\\", \\\"{x:1384,y:818,t:1527876749672};\\\", \\\"{x:1387,y:819,t:1527876749688};\\\", \\\"{x:1391,y:821,t:1527876749705};\\\", \\\"{x:1393,y:822,t:1527876749721};\\\", \\\"{x:1393,y:823,t:1527876749739};\\\", \\\"{x:1397,y:828,t:1527876749755};\\\", \\\"{x:1400,y:834,t:1527876749772};\\\", \\\"{x:1402,y:840,t:1527876749789};\\\", \\\"{x:1403,y:843,t:1527876749805};\\\", \\\"{x:1404,y:844,t:1527876749823};\\\", \\\"{x:1404,y:845,t:1527876749879};\\\", \\\"{x:1405,y:845,t:1527876750039};\\\", \\\"{x:1406,y:845,t:1527876750159};\\\", \\\"{x:1407,y:846,t:1527876750295};\\\", \\\"{x:1407,y:848,t:1527876750305};\\\", \\\"{x:1406,y:851,t:1527876750323};\\\", \\\"{x:1405,y:852,t:1527876750339};\\\", \\\"{x:1402,y:854,t:1527876750356};\\\", \\\"{x:1399,y:857,t:1527876750373};\\\", \\\"{x:1396,y:858,t:1527876750389};\\\", \\\"{x:1395,y:858,t:1527876750406};\\\", \\\"{x:1394,y:859,t:1527876750422};\\\", \\\"{x:1392,y:860,t:1527876750447};\\\", \\\"{x:1392,y:861,t:1527876750463};\\\", \\\"{x:1390,y:861,t:1527876750473};\\\", \\\"{x:1384,y:861,t:1527876750489};\\\", \\\"{x:1378,y:861,t:1527876750506};\\\", \\\"{x:1376,y:861,t:1527876750522};\\\", \\\"{x:1373,y:861,t:1527876750540};\\\", \\\"{x:1370,y:862,t:1527876750556};\\\", \\\"{x:1367,y:862,t:1527876750573};\\\", \\\"{x:1362,y:864,t:1527876750589};\\\", \\\"{x:1356,y:864,t:1527876750607};\\\", \\\"{x:1350,y:865,t:1527876750622};\\\", \\\"{x:1346,y:865,t:1527876750639};\\\", \\\"{x:1341,y:866,t:1527876750656};\\\", \\\"{x:1339,y:866,t:1527876750673};\\\", \\\"{x:1338,y:866,t:1527876750689};\\\", \\\"{x:1334,y:866,t:1527876750707};\\\", \\\"{x:1332,y:866,t:1527876750722};\\\", \\\"{x:1330,y:867,t:1527876750740};\\\", \\\"{x:1329,y:867,t:1527876750756};\\\", \\\"{x:1328,y:867,t:1527876750772};\\\", \\\"{x:1325,y:867,t:1527876750790};\\\", \\\"{x:1301,y:862,t:1527876750807};\\\", \\\"{x:1276,y:855,t:1527876750822};\\\", \\\"{x:1255,y:852,t:1527876750839};\\\", \\\"{x:1240,y:850,t:1527876750856};\\\", \\\"{x:1224,y:845,t:1527876750873};\\\", \\\"{x:1213,y:841,t:1527876750890};\\\", \\\"{x:1207,y:841,t:1527876750906};\\\", \\\"{x:1206,y:840,t:1527876750921};\\\", \\\"{x:1204,y:839,t:1527876750939};\\\", \\\"{x:1203,y:839,t:1527876751046};\\\", \\\"{x:1202,y:837,t:1527876751056};\\\", \\\"{x:1202,y:835,t:1527876751078};\\\", \\\"{x:1202,y:834,t:1527876751126};\\\", \\\"{x:1203,y:833,t:1527876751158};\\\", \\\"{x:1203,y:832,t:1527876751173};\\\", \\\"{x:1203,y:831,t:1527876751223};\\\", \\\"{x:1203,y:830,t:1527876751287};\\\", \\\"{x:1204,y:829,t:1527876751303};\\\", \\\"{x:1205,y:828,t:1527876751326};\\\", \\\"{x:1206,y:828,t:1527876751462};\\\", \\\"{x:1207,y:828,t:1527876751559};\\\", \\\"{x:1208,y:828,t:1527876751583};\\\", \\\"{x:1209,y:828,t:1527876751619};\\\", \\\"{x:1210,y:828,t:1527876751655};\\\", \\\"{x:1211,y:828,t:1527876751774};\\\", \\\"{x:1212,y:828,t:1527876751797};\\\", \\\"{x:1214,y:828,t:1527876751806};\\\", \\\"{x:1216,y:828,t:1527876751824};\\\", \\\"{x:1218,y:830,t:1527876752430};\\\", \\\"{x:1218,y:831,t:1527876752454};\\\", \\\"{x:1219,y:831,t:1527876752462};\\\", \\\"{x:1220,y:833,t:1527876752477};\\\", \\\"{x:1223,y:837,t:1527876752491};\\\", \\\"{x:1230,y:840,t:1527876752508};\\\", \\\"{x:1238,y:844,t:1527876752524};\\\", \\\"{x:1247,y:847,t:1527876752541};\\\", \\\"{x:1252,y:849,t:1527876752558};\\\", \\\"{x:1255,y:850,t:1527876752574};\\\", \\\"{x:1255,y:851,t:1527876752591};\\\", \\\"{x:1256,y:852,t:1527876752608};\\\", \\\"{x:1257,y:854,t:1527876752631};\\\", \\\"{x:1258,y:856,t:1527876752641};\\\", \\\"{x:1259,y:858,t:1527876752658};\\\", \\\"{x:1262,y:859,t:1527876752674};\\\", \\\"{x:1265,y:863,t:1527876752691};\\\", \\\"{x:1272,y:867,t:1527876752708};\\\", \\\"{x:1280,y:874,t:1527876752725};\\\", \\\"{x:1291,y:879,t:1527876752741};\\\", \\\"{x:1302,y:890,t:1527876752758};\\\", \\\"{x:1311,y:896,t:1527876752774};\\\", \\\"{x:1315,y:903,t:1527876752792};\\\", \\\"{x:1316,y:908,t:1527876752808};\\\", \\\"{x:1316,y:915,t:1527876752825};\\\", \\\"{x:1316,y:917,t:1527876752841};\\\", \\\"{x:1316,y:920,t:1527876752858};\\\", \\\"{x:1315,y:924,t:1527876752875};\\\", \\\"{x:1311,y:929,t:1527876752891};\\\", \\\"{x:1308,y:933,t:1527876752909};\\\", \\\"{x:1306,y:937,t:1527876752925};\\\", \\\"{x:1304,y:938,t:1527876752941};\\\", \\\"{x:1302,y:940,t:1527876752958};\\\", \\\"{x:1301,y:940,t:1527876752999};\\\", \\\"{x:1300,y:940,t:1527876753014};\\\", \\\"{x:1298,y:940,t:1527876753025};\\\", \\\"{x:1297,y:940,t:1527876753119};\\\", \\\"{x:1297,y:939,t:1527876753127};\\\", \\\"{x:1297,y:937,t:1527876753141};\\\", \\\"{x:1300,y:929,t:1527876753158};\\\", \\\"{x:1303,y:922,t:1527876753175};\\\", \\\"{x:1307,y:917,t:1527876753192};\\\", \\\"{x:1311,y:912,t:1527876753207};\\\", \\\"{x:1314,y:907,t:1527876753225};\\\", \\\"{x:1316,y:902,t:1527876753242};\\\", \\\"{x:1319,y:899,t:1527876753257};\\\", \\\"{x:1320,y:893,t:1527876753275};\\\", \\\"{x:1322,y:889,t:1527876753292};\\\", \\\"{x:1324,y:887,t:1527876753308};\\\", \\\"{x:1326,y:884,t:1527876753324};\\\", \\\"{x:1328,y:880,t:1527876753342};\\\", \\\"{x:1332,y:872,t:1527876753358};\\\", \\\"{x:1334,y:868,t:1527876753375};\\\", \\\"{x:1336,y:864,t:1527876753392};\\\", \\\"{x:1339,y:859,t:1527876753408};\\\", \\\"{x:1342,y:857,t:1527876753425};\\\", \\\"{x:1344,y:854,t:1527876753441};\\\", \\\"{x:1347,y:849,t:1527876753458};\\\", \\\"{x:1349,y:846,t:1527876753475};\\\", \\\"{x:1349,y:843,t:1527876753492};\\\", \\\"{x:1352,y:840,t:1527876753508};\\\", \\\"{x:1352,y:837,t:1527876753525};\\\", \\\"{x:1354,y:833,t:1527876753542};\\\", \\\"{x:1355,y:829,t:1527876753558};\\\", \\\"{x:1358,y:825,t:1527876753575};\\\", \\\"{x:1358,y:823,t:1527876753592};\\\", \\\"{x:1360,y:822,t:1527876753609};\\\", \\\"{x:1360,y:820,t:1527876753625};\\\", \\\"{x:1361,y:817,t:1527876753642};\\\", \\\"{x:1361,y:814,t:1527876753660};\\\", \\\"{x:1363,y:811,t:1527876753675};\\\", \\\"{x:1364,y:807,t:1527876753693};\\\", \\\"{x:1365,y:804,t:1527876753709};\\\", \\\"{x:1366,y:802,t:1527876753725};\\\", \\\"{x:1367,y:798,t:1527876753742};\\\", \\\"{x:1367,y:796,t:1527876753759};\\\", \\\"{x:1367,y:795,t:1527876753775};\\\", \\\"{x:1368,y:794,t:1527876753792};\\\", \\\"{x:1368,y:792,t:1527876753810};\\\", \\\"{x:1369,y:791,t:1527876753826};\\\", \\\"{x:1370,y:790,t:1527876753843};\\\", \\\"{x:1370,y:789,t:1527876753863};\\\", \\\"{x:1370,y:788,t:1527876753903};\\\", \\\"{x:1370,y:786,t:1527876753927};\\\", \\\"{x:1370,y:785,t:1527876753942};\\\", \\\"{x:1371,y:784,t:1527876753959};\\\", \\\"{x:1371,y:783,t:1527876753976};\\\", \\\"{x:1371,y:780,t:1527876753993};\\\", \\\"{x:1371,y:779,t:1527876754010};\\\", \\\"{x:1372,y:779,t:1527876754025};\\\", \\\"{x:1372,y:777,t:1527876754042};\\\", \\\"{x:1372,y:776,t:1527876754062};\\\", \\\"{x:1373,y:773,t:1527876754076};\\\", \\\"{x:1373,y:772,t:1527876754095};\\\", \\\"{x:1373,y:771,t:1527876754110};\\\", \\\"{x:1373,y:770,t:1527876754126};\\\", \\\"{x:1373,y:769,t:1527876754255};\\\", \\\"{x:1373,y:768,t:1527876754263};\\\", \\\"{x:1373,y:767,t:1527876754295};\\\", \\\"{x:1373,y:766,t:1527876754367};\\\", \\\"{x:1374,y:765,t:1527876754406};\\\", \\\"{x:1376,y:764,t:1527876754442};\\\", \\\"{x:1377,y:763,t:1527876754518};\\\", \\\"{x:1378,y:763,t:1527876754557};\\\", \\\"{x:1380,y:763,t:1527876754614};\\\", \\\"{x:1381,y:763,t:1527876754630};\\\", \\\"{x:1382,y:763,t:1527876754654};\\\", \\\"{x:1383,y:762,t:1527876754670};\\\", \\\"{x:1383,y:763,t:1527876755695};\\\", \\\"{x:1383,y:766,t:1527876755711};\\\", \\\"{x:1383,y:775,t:1527876755745};\\\", \\\"{x:1383,y:788,t:1527876755760};\\\", \\\"{x:1381,y:808,t:1527876755777};\\\", \\\"{x:1376,y:827,t:1527876755794};\\\", \\\"{x:1374,y:852,t:1527876755810};\\\", \\\"{x:1374,y:870,t:1527876755827};\\\", \\\"{x:1374,y:884,t:1527876755844};\\\", \\\"{x:1374,y:893,t:1527876755860};\\\", \\\"{x:1372,y:904,t:1527876755877};\\\", \\\"{x:1367,y:914,t:1527876755893};\\\", \\\"{x:1366,y:915,t:1527876755910};\\\", \\\"{x:1364,y:915,t:1527876755927};\\\", \\\"{x:1362,y:915,t:1527876755998};\\\", \\\"{x:1360,y:916,t:1527876756014};\\\", \\\"{x:1359,y:916,t:1527876756047};\\\", \\\"{x:1358,y:916,t:1527876756061};\\\", \\\"{x:1356,y:916,t:1527876756077};\\\", \\\"{x:1352,y:916,t:1527876756095};\\\", \\\"{x:1351,y:914,t:1527876756110};\\\", \\\"{x:1351,y:913,t:1527876756127};\\\", \\\"{x:1349,y:911,t:1527876756144};\\\", \\\"{x:1347,y:908,t:1527876756160};\\\", \\\"{x:1347,y:906,t:1527876756230};\\\", \\\"{x:1347,y:905,t:1527876756279};\\\", \\\"{x:1347,y:903,t:1527876756319};\\\", \\\"{x:1347,y:902,t:1527876756331};\\\", \\\"{x:1347,y:901,t:1527876756344};\\\", \\\"{x:1348,y:899,t:1527876756361};\\\", \\\"{x:1349,y:897,t:1527876756414};\\\", \\\"{x:1350,y:897,t:1527876756427};\\\", \\\"{x:1350,y:896,t:1527876756751};\\\", \\\"{x:1350,y:893,t:1527876756761};\\\", \\\"{x:1350,y:885,t:1527876756782};\\\", \\\"{x:1351,y:876,t:1527876756794};\\\", \\\"{x:1353,y:860,t:1527876756811};\\\", \\\"{x:1355,y:845,t:1527876756828};\\\", \\\"{x:1357,y:835,t:1527876756844};\\\", \\\"{x:1359,y:824,t:1527876756861};\\\", \\\"{x:1359,y:819,t:1527876756877};\\\", \\\"{x:1359,y:816,t:1527876756894};\\\", \\\"{x:1359,y:813,t:1527876756911};\\\", \\\"{x:1359,y:808,t:1527876756928};\\\", \\\"{x:1358,y:801,t:1527876756944};\\\", \\\"{x:1356,y:795,t:1527876756961};\\\", \\\"{x:1356,y:786,t:1527876756978};\\\", \\\"{x:1354,y:782,t:1527876756994};\\\", \\\"{x:1352,y:778,t:1527876757011};\\\", \\\"{x:1351,y:775,t:1527876757028};\\\", \\\"{x:1348,y:768,t:1527876757044};\\\", \\\"{x:1348,y:765,t:1527876757061};\\\", \\\"{x:1348,y:753,t:1527876757078};\\\", \\\"{x:1348,y:744,t:1527876757094};\\\", \\\"{x:1348,y:729,t:1527876757111};\\\", \\\"{x:1348,y:709,t:1527876757127};\\\", \\\"{x:1348,y:684,t:1527876757145};\\\", \\\"{x:1343,y:668,t:1527876757161};\\\", \\\"{x:1343,y:664,t:1527876757178};\\\", \\\"{x:1341,y:659,t:1527876757195};\\\", \\\"{x:1340,y:657,t:1527876757210};\\\", \\\"{x:1338,y:654,t:1527876757228};\\\", \\\"{x:1337,y:654,t:1527876757245};\\\", \\\"{x:1335,y:653,t:1527876757278};\\\", \\\"{x:1331,y:650,t:1527876757295};\\\", \\\"{x:1324,y:649,t:1527876757311};\\\", \\\"{x:1320,y:646,t:1527876757329};\\\", \\\"{x:1319,y:646,t:1527876757345};\\\", \\\"{x:1315,y:645,t:1527876757361};\\\", \\\"{x:1312,y:643,t:1527876757378};\\\", \\\"{x:1310,y:643,t:1527876757395};\\\", \\\"{x:1309,y:642,t:1527876757415};\\\", \\\"{x:1307,y:641,t:1527876757454};\\\", \\\"{x:1307,y:640,t:1527876757462};\\\", \\\"{x:1305,y:640,t:1527876757479};\\\", \\\"{x:1305,y:637,t:1527876757527};\\\", \\\"{x:1305,y:634,t:1527876757534};\\\", \\\"{x:1305,y:632,t:1527876757546};\\\", \\\"{x:1311,y:626,t:1527876757565};\\\", \\\"{x:1318,y:620,t:1527876757579};\\\", \\\"{x:1325,y:618,t:1527876757596};\\\", \\\"{x:1330,y:614,t:1527876757612};\\\", \\\"{x:1339,y:607,t:1527876757628};\\\", \\\"{x:1349,y:599,t:1527876757645};\\\", \\\"{x:1367,y:583,t:1527876757661};\\\", \\\"{x:1381,y:574,t:1527876757678};\\\", \\\"{x:1386,y:569,t:1527876757695};\\\", \\\"{x:1390,y:564,t:1527876757712};\\\", \\\"{x:1391,y:563,t:1527876757728};\\\", \\\"{x:1392,y:563,t:1527876757745};\\\", \\\"{x:1393,y:562,t:1527876757774};\\\", \\\"{x:1394,y:562,t:1527876757790};\\\", \\\"{x:1395,y:560,t:1527876757798};\\\", \\\"{x:1397,y:560,t:1527876757813};\\\", \\\"{x:1399,y:559,t:1527876757828};\\\", \\\"{x:1402,y:558,t:1527876757846};\\\", \\\"{x:1403,y:558,t:1527876757862};\\\", \\\"{x:1404,y:558,t:1527876757909};\\\", \\\"{x:1405,y:558,t:1527876757934};\\\", \\\"{x:1406,y:558,t:1527876757945};\\\", \\\"{x:1408,y:558,t:1527876757962};\\\", \\\"{x:1411,y:561,t:1527876757980};\\\", \\\"{x:1413,y:563,t:1527876758012};\\\", \\\"{x:1413,y:564,t:1527876758094};\\\", \\\"{x:1414,y:566,t:1527876759134};\\\", \\\"{x:1414,y:570,t:1527876759152};\\\", \\\"{x:1418,y:595,t:1527876759166};\\\", \\\"{x:1418,y:606,t:1527876759179};\\\", \\\"{x:1418,y:622,t:1527876759196};\\\", \\\"{x:1419,y:644,t:1527876759213};\\\", \\\"{x:1422,y:665,t:1527876759229};\\\", \\\"{x:1424,y:687,t:1527876759246};\\\", \\\"{x:1424,y:696,t:1527876759263};\\\", \\\"{x:1424,y:704,t:1527876759280};\\\", \\\"{x:1424,y:711,t:1527876759296};\\\", \\\"{x:1424,y:715,t:1527876759313};\\\", \\\"{x:1423,y:718,t:1527876759330};\\\", \\\"{x:1419,y:723,t:1527876759346};\\\", \\\"{x:1414,y:732,t:1527876759364};\\\", \\\"{x:1408,y:744,t:1527876759380};\\\", \\\"{x:1403,y:756,t:1527876759396};\\\", \\\"{x:1400,y:765,t:1527876759413};\\\", \\\"{x:1398,y:774,t:1527876759430};\\\", \\\"{x:1392,y:786,t:1527876759446};\\\", \\\"{x:1385,y:796,t:1527876759463};\\\", \\\"{x:1383,y:802,t:1527876759479};\\\", \\\"{x:1381,y:803,t:1527876759496};\\\", \\\"{x:1381,y:802,t:1527876759582};\\\", \\\"{x:1381,y:800,t:1527876759597};\\\", \\\"{x:1381,y:795,t:1527876759614};\\\", \\\"{x:1381,y:788,t:1527876759630};\\\", \\\"{x:1381,y:776,t:1527876759646};\\\", \\\"{x:1382,y:771,t:1527876759664};\\\", \\\"{x:1383,y:768,t:1527876759683};\\\", \\\"{x:1383,y:767,t:1527876759713};\\\", \\\"{x:1383,y:765,t:1527876759730};\\\", \\\"{x:1381,y:764,t:1527876760366};\\\", \\\"{x:1377,y:764,t:1527876760381};\\\", \\\"{x:1344,y:767,t:1527876760413};\\\", \\\"{x:1332,y:772,t:1527876760430};\\\", \\\"{x:1323,y:776,t:1527876760448};\\\", \\\"{x:1317,y:780,t:1527876760464};\\\", \\\"{x:1310,y:785,t:1527876760480};\\\", \\\"{x:1299,y:793,t:1527876760498};\\\", \\\"{x:1289,y:803,t:1527876760514};\\\", \\\"{x:1281,y:812,t:1527876760530};\\\", \\\"{x:1278,y:817,t:1527876760547};\\\", \\\"{x:1276,y:820,t:1527876760564};\\\", \\\"{x:1275,y:824,t:1527876760580};\\\", \\\"{x:1275,y:826,t:1527876760597};\\\", \\\"{x:1275,y:827,t:1527876760653};\\\", \\\"{x:1275,y:828,t:1527876760664};\\\", \\\"{x:1272,y:830,t:1527876760680};\\\", \\\"{x:1266,y:834,t:1527876760698};\\\", \\\"{x:1264,y:836,t:1527876760714};\\\", \\\"{x:1260,y:838,t:1527876760731};\\\", \\\"{x:1256,y:839,t:1527876760747};\\\", \\\"{x:1253,y:839,t:1527876760764};\\\", \\\"{x:1251,y:839,t:1527876760781};\\\", \\\"{x:1248,y:839,t:1527876760798};\\\", \\\"{x:1246,y:842,t:1527876760814};\\\", \\\"{x:1244,y:842,t:1527876760832};\\\", \\\"{x:1243,y:842,t:1527876760847};\\\", \\\"{x:1241,y:842,t:1527876760864};\\\", \\\"{x:1236,y:842,t:1527876760881};\\\", \\\"{x:1231,y:842,t:1527876760897};\\\", \\\"{x:1228,y:842,t:1527876760914};\\\", \\\"{x:1227,y:842,t:1527876760931};\\\", \\\"{x:1226,y:840,t:1527876760958};\\\", \\\"{x:1224,y:839,t:1527876760982};\\\", \\\"{x:1221,y:837,t:1527876760998};\\\", \\\"{x:1217,y:836,t:1527876761015};\\\", \\\"{x:1216,y:836,t:1527876761032};\\\", \\\"{x:1215,y:836,t:1527876761287};\\\", \\\"{x:1214,y:836,t:1527876761311};\\\", \\\"{x:1212,y:836,t:1527876761318};\\\", \\\"{x:1211,y:835,t:1527876761415};\\\", \\\"{x:1211,y:834,t:1527876761652};\\\", \\\"{x:1211,y:832,t:1527876761681};\\\", \\\"{x:1211,y:831,t:1527876761830};\\\", \\\"{x:1211,y:829,t:1527876761846};\\\", \\\"{x:1211,y:828,t:1527876761870};\\\", \\\"{x:1212,y:827,t:1527876761935};\\\", \\\"{x:1212,y:826,t:1527876761959};\\\", \\\"{x:1213,y:825,t:1527876761983};\\\", \\\"{x:1216,y:822,t:1527876762001};\\\", \\\"{x:1221,y:818,t:1527876762016};\\\", \\\"{x:1231,y:813,t:1527876762032};\\\", \\\"{x:1243,y:807,t:1527876762048};\\\", \\\"{x:1259,y:797,t:1527876762065};\\\", \\\"{x:1276,y:793,t:1527876762082};\\\", \\\"{x:1296,y:790,t:1527876762098};\\\", \\\"{x:1319,y:784,t:1527876762115};\\\", \\\"{x:1349,y:778,t:1527876762133};\\\", \\\"{x:1371,y:775,t:1527876762149};\\\", \\\"{x:1393,y:768,t:1527876762165};\\\", \\\"{x:1427,y:755,t:1527876762182};\\\", \\\"{x:1446,y:740,t:1527876762199};\\\", \\\"{x:1461,y:726,t:1527876762215};\\\", \\\"{x:1471,y:713,t:1527876762233};\\\", \\\"{x:1477,y:701,t:1527876762249};\\\", \\\"{x:1483,y:691,t:1527876762266};\\\", \\\"{x:1485,y:680,t:1527876762283};\\\", \\\"{x:1485,y:665,t:1527876762299};\\\", \\\"{x:1488,y:646,t:1527876762315};\\\", \\\"{x:1506,y:612,t:1527876762333};\\\", \\\"{x:1512,y:597,t:1527876762348};\\\", \\\"{x:1515,y:592,t:1527876762365};\\\", \\\"{x:1516,y:589,t:1527876762382};\\\", \\\"{x:1516,y:588,t:1527876762398};\\\", \\\"{x:1517,y:587,t:1527876762439};\\\", \\\"{x:1518,y:586,t:1527876762450};\\\", \\\"{x:1519,y:586,t:1527876762518};\\\", \\\"{x:1520,y:586,t:1527876762541};\\\", \\\"{x:1520,y:587,t:1527876762549};\\\", \\\"{x:1517,y:598,t:1527876762565};\\\", \\\"{x:1513,y:608,t:1527876762582};\\\", \\\"{x:1511,y:616,t:1527876762599};\\\", \\\"{x:1509,y:622,t:1527876762615};\\\", \\\"{x:1509,y:624,t:1527876762632};\\\", \\\"{x:1508,y:625,t:1527876762654};\\\", \\\"{x:1508,y:626,t:1527876762678};\\\", \\\"{x:1508,y:627,t:1527876762693};\\\", \\\"{x:1508,y:628,t:1527876762709};\\\", \\\"{x:1508,y:629,t:1527876762959};\\\", \\\"{x:1508,y:630,t:1527876762967};\\\", \\\"{x:1508,y:631,t:1527876762991};\\\", \\\"{x:1509,y:631,t:1527876763107};\\\", \\\"{x:1510,y:631,t:1527876763132};\\\", \\\"{x:1510,y:632,t:1527876763453};\\\", \\\"{x:1509,y:634,t:1527876763467};\\\", \\\"{x:1498,y:642,t:1527876763483};\\\", \\\"{x:1480,y:655,t:1527876763499};\\\", \\\"{x:1456,y:667,t:1527876763517};\\\", \\\"{x:1426,y:677,t:1527876763533};\\\", \\\"{x:1367,y:694,t:1527876763549};\\\", \\\"{x:1319,y:703,t:1527876763567};\\\", \\\"{x:1233,y:714,t:1527876763583};\\\", \\\"{x:1136,y:724,t:1527876763599};\\\", \\\"{x:1065,y:731,t:1527876763616};\\\", \\\"{x:982,y:742,t:1527876763633};\\\", \\\"{x:906,y:742,t:1527876763650};\\\", \\\"{x:840,y:742,t:1527876763666};\\\", \\\"{x:789,y:742,t:1527876763684};\\\", \\\"{x:743,y:739,t:1527876763699};\\\", \\\"{x:696,y:734,t:1527876763716};\\\", \\\"{x:626,y:727,t:1527876763733};\\\", \\\"{x:597,y:722,t:1527876763749};\\\", \\\"{x:577,y:718,t:1527876763766};\\\", \\\"{x:570,y:717,t:1527876763784};\\\", \\\"{x:563,y:716,t:1527876763801};\\\", \\\"{x:561,y:714,t:1527876763816};\\\", \\\"{x:561,y:713,t:1527876763846};\\\", \\\"{x:561,y:712,t:1527876763870};\\\", \\\"{x:561,y:711,t:1527876763883};\\\", \\\"{x:561,y:709,t:1527876763900};\\\", \\\"{x:562,y:707,t:1527876763916};\\\", \\\"{x:563,y:706,t:1527876763942};\\\", \\\"{x:564,y:705,t:1527876764278};\\\", \\\"{x:565,y:704,t:1527876764287};\\\", \\\"{x:565,y:703,t:1527876764300};\\\", \\\"{x:566,y:701,t:1527876764319};\\\", \\\"{x:566,y:699,t:1527876764351};\\\", \\\"{x:565,y:697,t:1527876764367};\\\", \\\"{x:562,y:695,t:1527876764384};\\\", \\\"{x:558,y:694,t:1527876764401};\\\", \\\"{x:556,y:693,t:1527876764418};\\\", \\\"{x:554,y:692,t:1527876764434};\\\", \\\"{x:554,y:691,t:1527876764454};\\\", \\\"{x:552,y:690,t:1527876764470};\\\", \\\"{x:552,y:689,t:1527876765190};\\\", \\\"{x:550,y:686,t:1527876765206};\\\", \\\"{x:547,y:682,t:1527876765218};\\\", \\\"{x:542,y:675,t:1527876765234};\\\", \\\"{x:536,y:669,t:1527876765251};\\\", \\\"{x:530,y:664,t:1527876765268};\\\", \\\"{x:523,y:658,t:1527876765284};\\\", \\\"{x:520,y:655,t:1527876765302};\\\", \\\"{x:517,y:651,t:1527876765317};\\\", \\\"{x:514,y:648,t:1527876765334};\\\", \\\"{x:511,y:646,t:1527876765351};\\\", \\\"{x:506,y:643,t:1527876765368};\\\", \\\"{x:498,y:640,t:1527876765384};\\\", \\\"{x:491,y:639,t:1527876765401};\\\", \\\"{x:479,y:636,t:1527876765417};\\\", \\\"{x:468,y:634,t:1527876765434};\\\", \\\"{x:456,y:630,t:1527876765451};\\\", \\\"{x:444,y:628,t:1527876765469};\\\", \\\"{x:435,y:625,t:1527876765484};\\\", \\\"{x:420,y:622,t:1527876765502};\\\", \\\"{x:411,y:620,t:1527876765518};\\\", \\\"{x:404,y:619,t:1527876765534};\\\", \\\"{x:395,y:617,t:1527876765552};\\\", \\\"{x:387,y:616,t:1527876765569};\\\", \\\"{x:385,y:615,t:1527876765584};\\\", \\\"{x:383,y:614,t:1527876765602};\\\", \\\"{x:382,y:613,t:1527876765629};\\\", \\\"{x:381,y:611,t:1527876765694};\\\", \\\"{x:381,y:610,t:1527876765792};\\\", \\\"{x:381,y:609,t:1527876765802};\\\", \\\"{x:382,y:608,t:1527876765818};\\\", \\\"{x:384,y:607,t:1527876765835};\\\", \\\"{x:385,y:606,t:1527876766047};\\\", \\\"{x:389,y:607,t:1527876766053};\\\", \\\"{x:395,y:613,t:1527876766069};\\\", \\\"{x:419,y:629,t:1527876766086};\\\", \\\"{x:444,y:647,t:1527876766101};\\\", \\\"{x:471,y:665,t:1527876766119};\\\", \\\"{x:493,y:681,t:1527876766135};\\\", \\\"{x:516,y:700,t:1527876766151};\\\", \\\"{x:537,y:715,t:1527876766168};\\\", \\\"{x:551,y:735,t:1527876766185};\\\", \\\"{x:568,y:748,t:1527876766201};\\\", \\\"{x:576,y:755,t:1527876766218};\\\", \\\"{x:580,y:760,t:1527876766235};\\\", \\\"{x:582,y:764,t:1527876766251};\\\", \\\"{x:582,y:768,t:1527876766268};\\\", \\\"{x:582,y:770,t:1527876766285};\\\", \\\"{x:581,y:771,t:1527876766310};\\\", \\\"{x:580,y:771,t:1527876766342};\\\", \\\"{x:579,y:771,t:1527876766353};\\\", \\\"{x:567,y:771,t:1527876766369};\\\", \\\"{x:547,y:764,t:1527876766386};\\\", \\\"{x:522,y:747,t:1527876766402};\\\", \\\"{x:489,y:723,t:1527876766418};\\\", \\\"{x:463,y:704,t:1527876766435};\\\", \\\"{x:435,y:684,t:1527876766453};\\\", \\\"{x:411,y:669,t:1527876766469};\\\", \\\"{x:399,y:658,t:1527876766486};\\\", \\\"{x:399,y:653,t:1527876766503};\\\", \\\"{x:399,y:648,t:1527876766518};\\\", \\\"{x:399,y:644,t:1527876766536};\\\", \\\"{x:400,y:640,t:1527876766552};\\\", \\\"{x:401,y:638,t:1527876766570};\\\", \\\"{x:401,y:635,t:1527876766585};\\\", \\\"{x:403,y:633,t:1527876766603};\\\", \\\"{x:403,y:632,t:1527876766619};\\\", \\\"{x:404,y:631,t:1527876766635};\\\", \\\"{x:404,y:629,t:1527876766653};\\\", \\\"{x:404,y:627,t:1527876766668};\\\", \\\"{x:404,y:625,t:1527876766686};\\\", \\\"{x:404,y:624,t:1527876766702};\\\", \\\"{x:404,y:620,t:1527876766719};\\\", \\\"{x:402,y:612,t:1527876766736};\\\", \\\"{x:398,y:607,t:1527876766752};\\\", \\\"{x:398,y:605,t:1527876766770};\\\", \\\"{x:398,y:603,t:1527876766786};\\\", \\\"{x:398,y:602,t:1527876766802};\\\", \\\"{x:398,y:601,t:1527876766819};\\\", \\\"{x:398,y:600,t:1527876766835};\\\", \\\"{x:398,y:599,t:1527876766852};\\\", \\\"{x:397,y:598,t:1527876767223};\\\", \\\"{x:396,y:598,t:1527876767246};\\\", \\\"{x:396,y:599,t:1527876767254};\\\", \\\"{x:396,y:602,t:1527876767270};\\\", \\\"{x:398,y:612,t:1527876767287};\\\", \\\"{x:402,y:624,t:1527876767302};\\\", \\\"{x:411,y:637,t:1527876767319};\\\", \\\"{x:422,y:652,t:1527876767337};\\\", \\\"{x:436,y:670,t:1527876767353};\\\", \\\"{x:450,y:686,t:1527876767369};\\\", \\\"{x:464,y:701,t:1527876767387};\\\", \\\"{x:477,y:711,t:1527876767402};\\\", \\\"{x:486,y:718,t:1527876767419};\\\", \\\"{x:492,y:723,t:1527876767436};\\\", \\\"{x:493,y:724,t:1527876767453};\\\", \\\"{x:494,y:726,t:1527876767469};\\\", \\\"{x:495,y:727,t:1527876767486};\\\", \\\"{x:496,y:730,t:1527876767670};\\\", \\\"{x:499,y:740,t:1527876767687};\\\", \\\"{x:502,y:745,t:1527876767703};\\\", \\\"{x:503,y:745,t:1527876767719};\\\", \\\"{x:505,y:747,t:1527876767736};\\\", \\\"{x:505,y:748,t:1527876767754};\\\", \\\"{x:506,y:749,t:1527876767769};\\\", \\\"{x:506,y:750,t:1527876767782};\\\", \\\"{x:511,y:748,t:1527876768263};\\\", \\\"{x:520,y:745,t:1527876768270};\\\", \\\"{x:535,y:734,t:1527876768287};\\\", \\\"{x:561,y:723,t:1527876768303};\\\", \\\"{x:585,y:713,t:1527876768321};\\\", \\\"{x:602,y:708,t:1527876768336};\\\", \\\"{x:620,y:700,t:1527876768353};\\\", \\\"{x:638,y:689,t:1527876768370};\\\", \\\"{x:683,y:667,t:1527876768386};\\\", \\\"{x:737,y:637,t:1527876768404};\\\", \\\"{x:777,y:614,t:1527876768420};\\\", \\\"{x:803,y:601,t:1527876768436};\\\", \\\"{x:839,y:586,t:1527876768453};\\\", \\\"{x:864,y:567,t:1527876768470};\\\", \\\"{x:884,y:554,t:1527876768486};\\\", \\\"{x:896,y:545,t:1527876768503};\\\", \\\"{x:902,y:541,t:1527876768520};\\\", \\\"{x:905,y:538,t:1527876768537};\\\", \\\"{x:906,y:537,t:1527876768553};\\\", \\\"{x:907,y:536,t:1527876768571};\\\", \\\"{x:908,y:536,t:1527876768587};\\\", \\\"{x:909,y:536,t:1527876768606};\\\", \\\"{x:910,y:536,t:1527876768645};\\\" ] }, { \\\"rt\\\": 17285, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 183454, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-U -K -H -H -H -I -I -J -J -O -H -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:909,y:537,t:1527876769774};\\\", \\\"{x:907,y:538,t:1527876769788};\\\", \\\"{x:902,y:539,t:1527876769805};\\\", \\\"{x:892,y:543,t:1527876769821};\\\", \\\"{x:887,y:545,t:1527876769838};\\\", \\\"{x:878,y:549,t:1527876769854};\\\", \\\"{x:874,y:550,t:1527876769871};\\\", \\\"{x:868,y:554,t:1527876769888};\\\", \\\"{x:865,y:554,t:1527876769904};\\\", \\\"{x:862,y:554,t:1527876769921};\\\", \\\"{x:858,y:557,t:1527876769938};\\\", \\\"{x:857,y:557,t:1527876769954};\\\", \\\"{x:855,y:557,t:1527876769971};\\\", \\\"{x:854,y:557,t:1527876770054};\\\", \\\"{x:854,y:558,t:1527876770071};\\\", \\\"{x:853,y:559,t:1527876770174};\\\", \\\"{x:852,y:560,t:1527876770189};\\\", \\\"{x:851,y:560,t:1527876770205};\\\", \\\"{x:850,y:561,t:1527876770254};\\\", \\\"{x:849,y:562,t:1527876770272};\\\", \\\"{x:848,y:563,t:1527876770289};\\\", \\\"{x:844,y:564,t:1527876770305};\\\", \\\"{x:838,y:565,t:1527876770322};\\\", \\\"{x:833,y:567,t:1527876770338};\\\", \\\"{x:829,y:568,t:1527876770356};\\\", \\\"{x:825,y:568,t:1527876770372};\\\", \\\"{x:821,y:568,t:1527876770390};\\\", \\\"{x:814,y:568,t:1527876770405};\\\", \\\"{x:811,y:568,t:1527876770422};\\\", \\\"{x:810,y:568,t:1527876770439};\\\", \\\"{x:809,y:568,t:1527876770477};\\\", \\\"{x:808,y:569,t:1527876770501};\\\", \\\"{x:818,y:569,t:1527876770895};\\\", \\\"{x:840,y:569,t:1527876770906};\\\", \\\"{x:877,y:569,t:1527876770923};\\\", \\\"{x:912,y:573,t:1527876770940};\\\", \\\"{x:954,y:580,t:1527876770955};\\\", \\\"{x:986,y:590,t:1527876770972};\\\", \\\"{x:1010,y:603,t:1527876770989};\\\", \\\"{x:1052,y:614,t:1527876771006};\\\", \\\"{x:1081,y:624,t:1527876771023};\\\", \\\"{x:1104,y:629,t:1527876771039};\\\", \\\"{x:1125,y:635,t:1527876771056};\\\", \\\"{x:1143,y:642,t:1527876771073};\\\", \\\"{x:1162,y:648,t:1527876771088};\\\", \\\"{x:1175,y:654,t:1527876771106};\\\", \\\"{x:1192,y:661,t:1527876771122};\\\", \\\"{x:1206,y:671,t:1527876771138};\\\", \\\"{x:1220,y:686,t:1527876771156};\\\", \\\"{x:1240,y:703,t:1527876771173};\\\", \\\"{x:1256,y:716,t:1527876771189};\\\", \\\"{x:1285,y:731,t:1527876771205};\\\", \\\"{x:1308,y:741,t:1527876771223};\\\", \\\"{x:1331,y:750,t:1527876771240};\\\", \\\"{x:1363,y:764,t:1527876771255};\\\", \\\"{x:1387,y:776,t:1527876771273};\\\", \\\"{x:1413,y:787,t:1527876771290};\\\", \\\"{x:1430,y:793,t:1527876771305};\\\", \\\"{x:1445,y:797,t:1527876771323};\\\", \\\"{x:1456,y:801,t:1527876771339};\\\", \\\"{x:1464,y:805,t:1527876771355};\\\", \\\"{x:1473,y:807,t:1527876771373};\\\", \\\"{x:1481,y:810,t:1527876771389};\\\", \\\"{x:1485,y:811,t:1527876771405};\\\", \\\"{x:1489,y:813,t:1527876771423};\\\", \\\"{x:1495,y:816,t:1527876771440};\\\", \\\"{x:1500,y:818,t:1527876771456};\\\", \\\"{x:1513,y:826,t:1527876771472};\\\", \\\"{x:1519,y:832,t:1527876771490};\\\", \\\"{x:1529,y:845,t:1527876771506};\\\", \\\"{x:1541,y:862,t:1527876771522};\\\", \\\"{x:1553,y:877,t:1527876771540};\\\", \\\"{x:1561,y:889,t:1527876771556};\\\", \\\"{x:1576,y:899,t:1527876771573};\\\", \\\"{x:1599,y:917,t:1527876771590};\\\", \\\"{x:1605,y:922,t:1527876771606};\\\", \\\"{x:1608,y:925,t:1527876771622};\\\", \\\"{x:1608,y:926,t:1527876771640};\\\", \\\"{x:1611,y:928,t:1527876771656};\\\", \\\"{x:1611,y:929,t:1527876771673};\\\", \\\"{x:1612,y:929,t:1527876771718};\\\", \\\"{x:1613,y:929,t:1527876771725};\\\", \\\"{x:1614,y:929,t:1527876771815};\\\", \\\"{x:1617,y:932,t:1527876771846};\\\", \\\"{x:1617,y:935,t:1527876771863};\\\", \\\"{x:1617,y:938,t:1527876771873};\\\", \\\"{x:1617,y:942,t:1527876771890};\\\", \\\"{x:1617,y:947,t:1527876771907};\\\", \\\"{x:1616,y:949,t:1527876771923};\\\", \\\"{x:1616,y:952,t:1527876771940};\\\", \\\"{x:1613,y:960,t:1527876771957};\\\", \\\"{x:1611,y:964,t:1527876771973};\\\", \\\"{x:1610,y:967,t:1527876771990};\\\", \\\"{x:1610,y:964,t:1527876772103};\\\", \\\"{x:1610,y:963,t:1527876772110};\\\", \\\"{x:1610,y:962,t:1527876772123};\\\", \\\"{x:1611,y:958,t:1527876772139};\\\", \\\"{x:1611,y:952,t:1527876772157};\\\", \\\"{x:1614,y:943,t:1527876772173};\\\", \\\"{x:1619,y:927,t:1527876772190};\\\", \\\"{x:1622,y:918,t:1527876772207};\\\", \\\"{x:1623,y:913,t:1527876772224};\\\", \\\"{x:1623,y:908,t:1527876772240};\\\", \\\"{x:1623,y:901,t:1527876772257};\\\", \\\"{x:1620,y:897,t:1527876772274};\\\", \\\"{x:1616,y:893,t:1527876772291};\\\", \\\"{x:1613,y:890,t:1527876772307};\\\", \\\"{x:1611,y:889,t:1527876772324};\\\", \\\"{x:1611,y:888,t:1527876772358};\\\", \\\"{x:1609,y:887,t:1527876772374};\\\", \\\"{x:1606,y:885,t:1527876772391};\\\", \\\"{x:1605,y:885,t:1527876772407};\\\", \\\"{x:1603,y:885,t:1527876772424};\\\", \\\"{x:1603,y:888,t:1527876772607};\\\", \\\"{x:1606,y:894,t:1527876772624};\\\", \\\"{x:1608,y:902,t:1527876772640};\\\", \\\"{x:1611,y:912,t:1527876772657};\\\", \\\"{x:1613,y:920,t:1527876772674};\\\", \\\"{x:1614,y:924,t:1527876772691};\\\", \\\"{x:1615,y:928,t:1527876772707};\\\", \\\"{x:1615,y:930,t:1527876772723};\\\", \\\"{x:1616,y:935,t:1527876772741};\\\", \\\"{x:1616,y:945,t:1527876772756};\\\", \\\"{x:1616,y:951,t:1527876772773};\\\", \\\"{x:1616,y:953,t:1527876772791};\\\", \\\"{x:1618,y:951,t:1527876772966};\\\", \\\"{x:1618,y:950,t:1527876772973};\\\", \\\"{x:1623,y:941,t:1527876772991};\\\", \\\"{x:1626,y:933,t:1527876773007};\\\", \\\"{x:1629,y:925,t:1527876773024};\\\", \\\"{x:1636,y:914,t:1527876773040};\\\", \\\"{x:1637,y:911,t:1527876773058};\\\", \\\"{x:1640,y:908,t:1527876773074};\\\", \\\"{x:1641,y:906,t:1527876773091};\\\", \\\"{x:1643,y:903,t:1527876773107};\\\", \\\"{x:1644,y:899,t:1527876773124};\\\", \\\"{x:1646,y:894,t:1527876773141};\\\", \\\"{x:1649,y:888,t:1527876773157};\\\", \\\"{x:1651,y:884,t:1527876773174};\\\", \\\"{x:1652,y:881,t:1527876773190};\\\", \\\"{x:1654,y:878,t:1527876773208};\\\", \\\"{x:1655,y:876,t:1527876773224};\\\", \\\"{x:1655,y:873,t:1527876773241};\\\", \\\"{x:1656,y:870,t:1527876773258};\\\", \\\"{x:1656,y:868,t:1527876773274};\\\", \\\"{x:1658,y:864,t:1527876773291};\\\", \\\"{x:1659,y:861,t:1527876773308};\\\", \\\"{x:1659,y:860,t:1527876773324};\\\", \\\"{x:1661,y:856,t:1527876773341};\\\", \\\"{x:1662,y:854,t:1527876773358};\\\", \\\"{x:1663,y:850,t:1527876773374};\\\", \\\"{x:1663,y:846,t:1527876773391};\\\", \\\"{x:1664,y:843,t:1527876773408};\\\", \\\"{x:1664,y:841,t:1527876773424};\\\", \\\"{x:1665,y:838,t:1527876773441};\\\", \\\"{x:1665,y:837,t:1527876773458};\\\", \\\"{x:1665,y:836,t:1527876773474};\\\", \\\"{x:1667,y:833,t:1527876773491};\\\", \\\"{x:1668,y:832,t:1527876773508};\\\", \\\"{x:1669,y:831,t:1527876773607};\\\", \\\"{x:1669,y:829,t:1527876773614};\\\", \\\"{x:1669,y:827,t:1527876773625};\\\", \\\"{x:1665,y:825,t:1527876773641};\\\", \\\"{x:1660,y:822,t:1527876773658};\\\", \\\"{x:1659,y:821,t:1527876773675};\\\", \\\"{x:1658,y:820,t:1527876773691};\\\", \\\"{x:1658,y:819,t:1527876773709};\\\", \\\"{x:1658,y:817,t:1527876773726};\\\", \\\"{x:1657,y:815,t:1527876773741};\\\", \\\"{x:1654,y:812,t:1527876773759};\\\", \\\"{x:1650,y:810,t:1527876773775};\\\", \\\"{x:1647,y:809,t:1527876773791};\\\", \\\"{x:1646,y:808,t:1527876773808};\\\", \\\"{x:1643,y:808,t:1527876773825};\\\", \\\"{x:1629,y:808,t:1527876773841};\\\", \\\"{x:1606,y:808,t:1527876773858};\\\", \\\"{x:1583,y:818,t:1527876773875};\\\", \\\"{x:1556,y:828,t:1527876773891};\\\", \\\"{x:1531,y:836,t:1527876773909};\\\", \\\"{x:1506,y:844,t:1527876773925};\\\", \\\"{x:1477,y:848,t:1527876773942};\\\", \\\"{x:1467,y:848,t:1527876773958};\\\", \\\"{x:1460,y:848,t:1527876773976};\\\", \\\"{x:1456,y:848,t:1527876773992};\\\", \\\"{x:1455,y:848,t:1527876774008};\\\", \\\"{x:1456,y:848,t:1527876774175};\\\", \\\"{x:1461,y:846,t:1527876774193};\\\", \\\"{x:1463,y:844,t:1527876774209};\\\", \\\"{x:1465,y:843,t:1527876774225};\\\", \\\"{x:1466,y:842,t:1527876774242};\\\", \\\"{x:1469,y:841,t:1527876774259};\\\", \\\"{x:1471,y:840,t:1527876774275};\\\", \\\"{x:1473,y:839,t:1527876774292};\\\", \\\"{x:1473,y:838,t:1527876774308};\\\", \\\"{x:1474,y:838,t:1527876774325};\\\", \\\"{x:1474,y:837,t:1527876774343};\\\", \\\"{x:1474,y:836,t:1527876774390};\\\", \\\"{x:1475,y:836,t:1527876774431};\\\", \\\"{x:1476,y:836,t:1527876774462};\\\", \\\"{x:1477,y:836,t:1527876774475};\\\", \\\"{x:1479,y:834,t:1527876774496};\\\", \\\"{x:1481,y:833,t:1527876774508};\\\", \\\"{x:1481,y:832,t:1527876774525};\\\", \\\"{x:1482,y:832,t:1527876774726};\\\", \\\"{x:1483,y:832,t:1527876774742};\\\", \\\"{x:1484,y:830,t:1527876775013};\\\", \\\"{x:1486,y:827,t:1527876775025};\\\", \\\"{x:1487,y:823,t:1527876775043};\\\", \\\"{x:1496,y:805,t:1527876775059};\\\", \\\"{x:1507,y:781,t:1527876775075};\\\", \\\"{x:1510,y:770,t:1527876775092};\\\", \\\"{x:1515,y:758,t:1527876775109};\\\", \\\"{x:1523,y:737,t:1527876775125};\\\", \\\"{x:1529,y:728,t:1527876775142};\\\", \\\"{x:1532,y:719,t:1527876775159};\\\", \\\"{x:1534,y:711,t:1527876775175};\\\", \\\"{x:1536,y:702,t:1527876775193};\\\", \\\"{x:1537,y:699,t:1527876775209};\\\", \\\"{x:1538,y:694,t:1527876775225};\\\", \\\"{x:1540,y:690,t:1527876775243};\\\", \\\"{x:1541,y:682,t:1527876775259};\\\", \\\"{x:1542,y:676,t:1527876775276};\\\", \\\"{x:1542,y:670,t:1527876775292};\\\", \\\"{x:1540,y:665,t:1527876775309};\\\", \\\"{x:1536,y:662,t:1527876775325};\\\", \\\"{x:1533,y:661,t:1527876775343};\\\", \\\"{x:1531,y:660,t:1527876775359};\\\", \\\"{x:1531,y:659,t:1527876775376};\\\", \\\"{x:1529,y:658,t:1527876775398};\\\", \\\"{x:1527,y:655,t:1527876775408};\\\", \\\"{x:1524,y:652,t:1527876775426};\\\", \\\"{x:1519,y:648,t:1527876775443};\\\", \\\"{x:1516,y:646,t:1527876775459};\\\", \\\"{x:1515,y:645,t:1527876775476};\\\", \\\"{x:1513,y:645,t:1527876775493};\\\", \\\"{x:1513,y:644,t:1527876775533};\\\", \\\"{x:1513,y:643,t:1527876775549};\\\", \\\"{x:1513,y:642,t:1527876775560};\\\", \\\"{x:1513,y:641,t:1527876775624};\\\", \\\"{x:1513,y:639,t:1527876775629};\\\", \\\"{x:1513,y:638,t:1527876775643};\\\", \\\"{x:1513,y:636,t:1527876775660};\\\", \\\"{x:1514,y:634,t:1527876775676};\\\", \\\"{x:1514,y:633,t:1527876775710};\\\", \\\"{x:1514,y:632,t:1527876775725};\\\", \\\"{x:1514,y:631,t:1527876775765};\\\", \\\"{x:1514,y:630,t:1527876775781};\\\", \\\"{x:1514,y:629,t:1527876775805};\\\", \\\"{x:1512,y:629,t:1527876776487};\\\", \\\"{x:1508,y:627,t:1527876776496};\\\", \\\"{x:1491,y:623,t:1527876776510};\\\", \\\"{x:1470,y:614,t:1527876776526};\\\", \\\"{x:1449,y:607,t:1527876776542};\\\", \\\"{x:1431,y:606,t:1527876776560};\\\", \\\"{x:1418,y:601,t:1527876776577};\\\", \\\"{x:1411,y:598,t:1527876776593};\\\", \\\"{x:1405,y:596,t:1527876776610};\\\", \\\"{x:1400,y:594,t:1527876776627};\\\", \\\"{x:1398,y:593,t:1527876776643};\\\", \\\"{x:1397,y:593,t:1527876776660};\\\", \\\"{x:1397,y:592,t:1527876776733};\\\", \\\"{x:1397,y:591,t:1527876776744};\\\", \\\"{x:1397,y:590,t:1527876776760};\\\", \\\"{x:1397,y:588,t:1527876776777};\\\", \\\"{x:1397,y:587,t:1527876776794};\\\", \\\"{x:1397,y:585,t:1527876776810};\\\", \\\"{x:1397,y:584,t:1527876776827};\\\", \\\"{x:1399,y:581,t:1527876776844};\\\", \\\"{x:1400,y:580,t:1527876776860};\\\", \\\"{x:1401,y:580,t:1527876776877};\\\", \\\"{x:1402,y:578,t:1527876776893};\\\", \\\"{x:1402,y:576,t:1527876776910};\\\", \\\"{x:1402,y:575,t:1527876777046};\\\", \\\"{x:1402,y:572,t:1527876777078};\\\", \\\"{x:1405,y:572,t:1527876777095};\\\", \\\"{x:1407,y:569,t:1527876777111};\\\", \\\"{x:1409,y:566,t:1527876777128};\\\", \\\"{x:1409,y:565,t:1527876777147};\\\", \\\"{x:1410,y:564,t:1527876777161};\\\", \\\"{x:1411,y:562,t:1527876777177};\\\", \\\"{x:1411,y:561,t:1527876777197};\\\", \\\"{x:1412,y:559,t:1527876777210};\\\", \\\"{x:1414,y:557,t:1527876777228};\\\", \\\"{x:1415,y:556,t:1527876777244};\\\", \\\"{x:1415,y:555,t:1527876777285};\\\", \\\"{x:1415,y:556,t:1527876777983};\\\", \\\"{x:1415,y:557,t:1527876778102};\\\", \\\"{x:1415,y:558,t:1527876778121};\\\", \\\"{x:1415,y:559,t:1527876778253};\\\", \\\"{x:1416,y:560,t:1527876778269};\\\", \\\"{x:1414,y:560,t:1527876778935};\\\", \\\"{x:1411,y:560,t:1527876778945};\\\", \\\"{x:1403,y:555,t:1527876778965};\\\", \\\"{x:1395,y:552,t:1527876778979};\\\", \\\"{x:1375,y:548,t:1527876778995};\\\", \\\"{x:1370,y:547,t:1527876779012};\\\", \\\"{x:1363,y:543,t:1527876779029};\\\", \\\"{x:1360,y:540,t:1527876779045};\\\", \\\"{x:1359,y:539,t:1527876779061};\\\", \\\"{x:1355,y:537,t:1527876779079};\\\", \\\"{x:1354,y:537,t:1527876779095};\\\", \\\"{x:1353,y:537,t:1527876779125};\\\", \\\"{x:1353,y:536,t:1527876779134};\\\", \\\"{x:1352,y:536,t:1527876779146};\\\", \\\"{x:1346,y:534,t:1527876779162};\\\", \\\"{x:1342,y:533,t:1527876779179};\\\", \\\"{x:1337,y:530,t:1527876779196};\\\", \\\"{x:1335,y:529,t:1527876779212};\\\", \\\"{x:1334,y:529,t:1527876779229};\\\", \\\"{x:1330,y:527,t:1527876779246};\\\", \\\"{x:1329,y:526,t:1527876779262};\\\", \\\"{x:1326,y:525,t:1527876779279};\\\", \\\"{x:1324,y:523,t:1527876779296};\\\", \\\"{x:1322,y:523,t:1527876779312};\\\", \\\"{x:1321,y:523,t:1527876779382};\\\", \\\"{x:1321,y:522,t:1527876779396};\\\", \\\"{x:1321,y:519,t:1527876779412};\\\", \\\"{x:1320,y:517,t:1527876779429};\\\", \\\"{x:1320,y:516,t:1527876779446};\\\", \\\"{x:1320,y:514,t:1527876779485};\\\", \\\"{x:1320,y:512,t:1527876779496};\\\", \\\"{x:1317,y:508,t:1527876779512};\\\", \\\"{x:1313,y:495,t:1527876779530};\\\", \\\"{x:1308,y:476,t:1527876779547};\\\", \\\"{x:1308,y:475,t:1527876779563};\\\", \\\"{x:1307,y:472,t:1527876779579};\\\", \\\"{x:1307,y:471,t:1527876779596};\\\", \\\"{x:1307,y:470,t:1527876779710};\\\", \\\"{x:1308,y:471,t:1527876779767};\\\", \\\"{x:1308,y:472,t:1527876779780};\\\", \\\"{x:1308,y:476,t:1527876779797};\\\", \\\"{x:1308,y:479,t:1527876779814};\\\", \\\"{x:1308,y:480,t:1527876779829};\\\", \\\"{x:1308,y:481,t:1527876779846};\\\", \\\"{x:1308,y:483,t:1527876779864};\\\", \\\"{x:1308,y:484,t:1527876779880};\\\", \\\"{x:1308,y:485,t:1527876779897};\\\", \\\"{x:1308,y:487,t:1527876779914};\\\", \\\"{x:1308,y:488,t:1527876779930};\\\", \\\"{x:1308,y:490,t:1527876779946};\\\", \\\"{x:1308,y:491,t:1527876779991};\\\", \\\"{x:1308,y:493,t:1527876779998};\\\", \\\"{x:1308,y:494,t:1527876780013};\\\", \\\"{x:1308,y:496,t:1527876780030};\\\", \\\"{x:1308,y:497,t:1527876780046};\\\", \\\"{x:1309,y:498,t:1527876780135};\\\", \\\"{x:1311,y:498,t:1527876780222};\\\", \\\"{x:1313,y:498,t:1527876780230};\\\", \\\"{x:1314,y:498,t:1527876780822};\\\", \\\"{x:1318,y:498,t:1527876780832};\\\", \\\"{x:1327,y:492,t:1527876780853};\\\", \\\"{x:1336,y:485,t:1527876780866};\\\", \\\"{x:1349,y:477,t:1527876780880};\\\", \\\"{x:1362,y:471,t:1527876780897};\\\", \\\"{x:1381,y:460,t:1527876780914};\\\", \\\"{x:1393,y:455,t:1527876780930};\\\", \\\"{x:1404,y:448,t:1527876780947};\\\", \\\"{x:1411,y:442,t:1527876780964};\\\", \\\"{x:1415,y:439,t:1527876780979};\\\", \\\"{x:1420,y:433,t:1527876780997};\\\", \\\"{x:1425,y:430,t:1527876781013};\\\", \\\"{x:1429,y:425,t:1527876781030};\\\", \\\"{x:1431,y:424,t:1527876781047};\\\", \\\"{x:1433,y:420,t:1527876781064};\\\", \\\"{x:1435,y:418,t:1527876781080};\\\", \\\"{x:1436,y:417,t:1527876781097};\\\", \\\"{x:1437,y:416,t:1527876781114};\\\", \\\"{x:1436,y:415,t:1527876781182};\\\", \\\"{x:1432,y:415,t:1527876781197};\\\", \\\"{x:1427,y:415,t:1527876781214};\\\", \\\"{x:1427,y:416,t:1527876781231};\\\", \\\"{x:1425,y:417,t:1527876781247};\\\", \\\"{x:1424,y:417,t:1527876781265};\\\", \\\"{x:1422,y:418,t:1527876781281};\\\", \\\"{x:1420,y:420,t:1527876781298};\\\", \\\"{x:1420,y:421,t:1527876781314};\\\", \\\"{x:1419,y:421,t:1527876781332};\\\", \\\"{x:1417,y:422,t:1527876781358};\\\", \\\"{x:1417,y:423,t:1527876781390};\\\", \\\"{x:1416,y:423,t:1527876781406};\\\", \\\"{x:1414,y:425,t:1527876781459};\\\", \\\"{x:1411,y:429,t:1527876781481};\\\", \\\"{x:1408,y:430,t:1527876781498};\\\", \\\"{x:1408,y:431,t:1527876781514};\\\", \\\"{x:1407,y:432,t:1527876781549};\\\", \\\"{x:1408,y:432,t:1527876782170};\\\", \\\"{x:1411,y:431,t:1527876782186};\\\", \\\"{x:1416,y:431,t:1527876782201};\\\", \\\"{x:1418,y:431,t:1527876782218};\\\", \\\"{x:1417,y:431,t:1527876782442};\\\", \\\"{x:1415,y:431,t:1527876782769};\\\", \\\"{x:1413,y:432,t:1527876782785};\\\", \\\"{x:1410,y:438,t:1527876782804};\\\", \\\"{x:1409,y:441,t:1527876782819};\\\", \\\"{x:1407,y:445,t:1527876782835};\\\", \\\"{x:1406,y:448,t:1527876782851};\\\", \\\"{x:1406,y:449,t:1527876782869};\\\", \\\"{x:1406,y:450,t:1527876782969};\\\", \\\"{x:1405,y:452,t:1527876782985};\\\", \\\"{x:1404,y:455,t:1527876783002};\\\", \\\"{x:1402,y:459,t:1527876783018};\\\", \\\"{x:1395,y:471,t:1527876783036};\\\", \\\"{x:1387,y:490,t:1527876783052};\\\", \\\"{x:1375,y:513,t:1527876783068};\\\", \\\"{x:1363,y:535,t:1527876783085};\\\", \\\"{x:1351,y:563,t:1527876783102};\\\", \\\"{x:1343,y:594,t:1527876783119};\\\", \\\"{x:1335,y:624,t:1527876783135};\\\", \\\"{x:1329,y:644,t:1527876783151};\\\", \\\"{x:1327,y:651,t:1527876783169};\\\", \\\"{x:1327,y:649,t:1527876783353};\\\", \\\"{x:1327,y:648,t:1527876783378};\\\", \\\"{x:1327,y:647,t:1527876783393};\\\", \\\"{x:1327,y:646,t:1527876783426};\\\", \\\"{x:1327,y:645,t:1527876783481};\\\", \\\"{x:1327,y:644,t:1527876783530};\\\", \\\"{x:1326,y:643,t:1527876783537};\\\", \\\"{x:1325,y:641,t:1527876783577};\\\", \\\"{x:1325,y:640,t:1527876783585};\\\", \\\"{x:1319,y:635,t:1527876783603};\\\", \\\"{x:1315,y:632,t:1527876783623};\\\", \\\"{x:1315,y:631,t:1527876783635};\\\", \\\"{x:1315,y:630,t:1527876783653};\\\", \\\"{x:1315,y:626,t:1527876783669};\\\", \\\"{x:1319,y:618,t:1527876783686};\\\", \\\"{x:1326,y:611,t:1527876783703};\\\", \\\"{x:1340,y:602,t:1527876783719};\\\", \\\"{x:1356,y:596,t:1527876783735};\\\", \\\"{x:1378,y:585,t:1527876783752};\\\", \\\"{x:1393,y:577,t:1527876783769};\\\", \\\"{x:1402,y:575,t:1527876783785};\\\", \\\"{x:1410,y:571,t:1527876783803};\\\", \\\"{x:1413,y:569,t:1527876783819};\\\", \\\"{x:1416,y:567,t:1527876783838};\\\", \\\"{x:1418,y:565,t:1527876783852};\\\", \\\"{x:1419,y:564,t:1527876783870};\\\", \\\"{x:1421,y:561,t:1527876783887};\\\", \\\"{x:1421,y:560,t:1527876783902};\\\", \\\"{x:1421,y:559,t:1527876784008};\\\", \\\"{x:1419,y:559,t:1527876784186};\\\", \\\"{x:1418,y:559,t:1527876784301};\\\", \\\"{x:1415,y:559,t:1527876784602};\\\", \\\"{x:1410,y:562,t:1527876784609};\\\", \\\"{x:1388,y:575,t:1527876784636};\\\", \\\"{x:1361,y:590,t:1527876784653};\\\", \\\"{x:1325,y:607,t:1527876784670};\\\", \\\"{x:1284,y:621,t:1527876784687};\\\", \\\"{x:1258,y:630,t:1527876784703};\\\", \\\"{x:1234,y:637,t:1527876784720};\\\", \\\"{x:1198,y:642,t:1527876784736};\\\", \\\"{x:1181,y:644,t:1527876784753};\\\", \\\"{x:1160,y:647,t:1527876784770};\\\", \\\"{x:1142,y:650,t:1527876784786};\\\", \\\"{x:1085,y:670,t:1527876784803};\\\", \\\"{x:1028,y:683,t:1527876784819};\\\", \\\"{x:992,y:692,t:1527876784837};\\\", \\\"{x:972,y:698,t:1527876784853};\\\", \\\"{x:950,y:700,t:1527876784871};\\\", \\\"{x:930,y:700,t:1527876784886};\\\", \\\"{x:904,y:699,t:1527876784904};\\\", \\\"{x:869,y:695,t:1527876784921};\\\", \\\"{x:845,y:691,t:1527876784936};\\\", \\\"{x:824,y:687,t:1527876784953};\\\", \\\"{x:796,y:684,t:1527876784971};\\\", \\\"{x:769,y:678,t:1527876784986};\\\", \\\"{x:747,y:675,t:1527876785004};\\\", \\\"{x:733,y:667,t:1527876785020};\\\", \\\"{x:717,y:658,t:1527876785038};\\\", \\\"{x:702,y:649,t:1527876785053};\\\", \\\"{x:686,y:642,t:1527876785070};\\\", \\\"{x:671,y:637,t:1527876785086};\\\", \\\"{x:659,y:634,t:1527876785104};\\\", \\\"{x:641,y:631,t:1527876785121};\\\", \\\"{x:638,y:629,t:1527876785136};\\\", \\\"{x:636,y:628,t:1527876785153};\\\", \\\"{x:634,y:624,t:1527876785170};\\\", \\\"{x:629,y:618,t:1527876785187};\\\", \\\"{x:622,y:613,t:1527876785203};\\\", \\\"{x:617,y:611,t:1527876785220};\\\", \\\"{x:613,y:608,t:1527876785237};\\\", \\\"{x:612,y:607,t:1527876785313};\\\", \\\"{x:612,y:605,t:1527876785321};\\\", \\\"{x:612,y:603,t:1527876785441};\\\", \\\"{x:610,y:603,t:1527876785576};\\\", \\\"{x:608,y:603,t:1527876785587};\\\", \\\"{x:605,y:612,t:1527876785604};\\\", \\\"{x:599,y:625,t:1527876785621};\\\", \\\"{x:593,y:640,t:1527876785637};\\\", \\\"{x:589,y:652,t:1527876785654};\\\", \\\"{x:586,y:662,t:1527876785671};\\\", \\\"{x:583,y:676,t:1527876785688};\\\", \\\"{x:574,y:693,t:1527876785704};\\\", \\\"{x:553,y:739,t:1527876785721};\\\", \\\"{x:531,y:790,t:1527876785738};\\\", \\\"{x:518,y:820,t:1527876785754};\\\", \\\"{x:512,y:834,t:1527876785770};\\\", \\\"{x:511,y:838,t:1527876785788};\\\", \\\"{x:509,y:839,t:1527876785805};\\\", \\\"{x:509,y:838,t:1527876785897};\\\", \\\"{x:509,y:834,t:1527876785905};\\\", \\\"{x:515,y:825,t:1527876785921};\\\", \\\"{x:521,y:814,t:1527876785938};\\\", \\\"{x:523,y:810,t:1527876785955};\\\", \\\"{x:524,y:807,t:1527876785971};\\\", \\\"{x:526,y:803,t:1527876785989};\\\", \\\"{x:527,y:799,t:1527876786005};\\\", \\\"{x:528,y:797,t:1527876786022};\\\", \\\"{x:530,y:791,t:1527876786039};\\\", \\\"{x:530,y:790,t:1527876786055};\\\", \\\"{x:530,y:789,t:1527876786137};\\\", \\\"{x:530,y:787,t:1527876786155};\\\", \\\"{x:532,y:783,t:1527876786171};\\\", \\\"{x:532,y:778,t:1527876786189};\\\", \\\"{x:532,y:775,t:1527876786206};\\\", \\\"{x:532,y:771,t:1527876786222};\\\", \\\"{x:532,y:768,t:1527876786239};\\\", \\\"{x:534,y:764,t:1527876786255};\\\", \\\"{x:534,y:762,t:1527876786355};\\\", \\\"{x:534,y:762,t:1527876786460};\\\", \\\"{x:543,y:755,t:1527876786745};\\\", \\\"{x:565,y:740,t:1527876786755};\\\", \\\"{x:623,y:707,t:1527876786772};\\\", \\\"{x:687,y:677,t:1527876786789};\\\", \\\"{x:756,y:648,t:1527876786805};\\\", \\\"{x:825,y:629,t:1527876786822};\\\", \\\"{x:876,y:611,t:1527876786839};\\\", \\\"{x:914,y:595,t:1527876786855};\\\", \\\"{x:947,y:582,t:1527876786872};\\\", \\\"{x:971,y:572,t:1527876786889};\\\", \\\"{x:982,y:567,t:1527876786905};\\\", \\\"{x:984,y:566,t:1527876786922};\\\" ] }, { \\\"rt\\\": 75846, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 260527, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -A -Z -Z -C -C -F -F -F -O -I -J -X -X -X -D -K -K -K -F -F -F -Z -A -C -C -O -O -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:983,y:566,t:1527876789946};\\\", \\\"{x:982,y:567,t:1527876789969};\\\", \\\"{x:981,y:568,t:1527876789977};\\\", \\\"{x:981,y:570,t:1527876789992};\\\", \\\"{x:980,y:571,t:1527876790008};\\\", \\\"{x:979,y:573,t:1527876790024};\\\", \\\"{x:979,y:577,t:1527876790040};\\\", \\\"{x:978,y:577,t:1527876790058};\\\", \\\"{x:978,y:580,t:1527876790074};\\\", \\\"{x:977,y:583,t:1527876790091};\\\", \\\"{x:977,y:588,t:1527876790108};\\\", \\\"{x:974,y:593,t:1527876790123};\\\", \\\"{x:973,y:599,t:1527876790141};\\\", \\\"{x:973,y:603,t:1527876790158};\\\", \\\"{x:973,y:606,t:1527876790173};\\\", \\\"{x:972,y:609,t:1527876790190};\\\", \\\"{x:972,y:610,t:1527876790208};\\\", \\\"{x:971,y:611,t:1527876790223};\\\", \\\"{x:971,y:612,t:1527876790297};\\\", \\\"{x:970,y:612,t:1527876790308};\\\", \\\"{x:970,y:613,t:1527876790325};\\\", \\\"{x:970,y:615,t:1527876790341};\\\", \\\"{x:970,y:616,t:1527876790358};\\\", \\\"{x:969,y:618,t:1527876790375};\\\", \\\"{x:968,y:620,t:1527876790391};\\\", \\\"{x:968,y:621,t:1527876790409};\\\", \\\"{x:968,y:623,t:1527876790425};\\\", \\\"{x:968,y:624,t:1527876790441};\\\", \\\"{x:968,y:625,t:1527876790458};\\\", \\\"{x:967,y:626,t:1527876790476};\\\", \\\"{x:967,y:627,t:1527876790497};\\\", \\\"{x:967,y:628,t:1527876790513};\\\", \\\"{x:967,y:629,t:1527876790525};\\\", \\\"{x:967,y:630,t:1527876790541};\\\", \\\"{x:967,y:631,t:1527876790558};\\\", \\\"{x:966,y:634,t:1527876790575};\\\", \\\"{x:966,y:635,t:1527876790609};\\\", \\\"{x:965,y:637,t:1527876790625};\\\", \\\"{x:964,y:638,t:1527876790657};\\\", \\\"{x:964,y:639,t:1527876790681};\\\", \\\"{x:963,y:640,t:1527876790691};\\\", \\\"{x:962,y:642,t:1527876790708};\\\", \\\"{x:961,y:643,t:1527876790725};\\\", \\\"{x:960,y:644,t:1527876790741};\\\", \\\"{x:960,y:645,t:1527876790906};\\\", \\\"{x:960,y:646,t:1527876790913};\\\", \\\"{x:960,y:647,t:1527876790937};\\\", \\\"{x:959,y:648,t:1527876790969};\\\", \\\"{x:959,y:649,t:1527876791001};\\\", \\\"{x:958,y:649,t:1527876791081};\\\", \\\"{x:957,y:649,t:1527876791177};\\\", \\\"{x:956,y:649,t:1527876791201};\\\", \\\"{x:955,y:650,t:1527876791217};\\\", \\\"{x:954,y:652,t:1527876791233};\\\", \\\"{x:954,y:653,t:1527876791249};\\\", \\\"{x:953,y:654,t:1527876791259};\\\", \\\"{x:953,y:655,t:1527876791281};\\\", \\\"{x:953,y:656,t:1527876791473};\\\", \\\"{x:954,y:657,t:1527876791489};\\\", \\\"{x:955,y:659,t:1527876791497};\\\", \\\"{x:958,y:659,t:1527876791509};\\\", \\\"{x:969,y:664,t:1527876791525};\\\", \\\"{x:982,y:670,t:1527876791543};\\\", \\\"{x:999,y:676,t:1527876791559};\\\", \\\"{x:1016,y:683,t:1527876791576};\\\", \\\"{x:1034,y:691,t:1527876791592};\\\", \\\"{x:1054,y:699,t:1527876791609};\\\", \\\"{x:1070,y:707,t:1527876791626};\\\", \\\"{x:1084,y:713,t:1527876791642};\\\", \\\"{x:1098,y:719,t:1527876791660};\\\", \\\"{x:1111,y:723,t:1527876791676};\\\", \\\"{x:1125,y:725,t:1527876791692};\\\", \\\"{x:1138,y:729,t:1527876791709};\\\", \\\"{x:1150,y:733,t:1527876791726};\\\", \\\"{x:1159,y:737,t:1527876791743};\\\", \\\"{x:1170,y:738,t:1527876791759};\\\", \\\"{x:1179,y:742,t:1527876791776};\\\", \\\"{x:1184,y:743,t:1527876791792};\\\", \\\"{x:1187,y:744,t:1527876791809};\\\", \\\"{x:1188,y:745,t:1527876793378};\\\", \\\"{x:1190,y:746,t:1527876793394};\\\", \\\"{x:1195,y:749,t:1527876793410};\\\", \\\"{x:1205,y:753,t:1527876793427};\\\", \\\"{x:1214,y:755,t:1527876793443};\\\", \\\"{x:1221,y:759,t:1527876793460};\\\", \\\"{x:1225,y:759,t:1527876793477};\\\", \\\"{x:1231,y:760,t:1527876793492};\\\", \\\"{x:1238,y:762,t:1527876793510};\\\", \\\"{x:1244,y:764,t:1527876793526};\\\", \\\"{x:1249,y:766,t:1527876793542};\\\", \\\"{x:1252,y:767,t:1527876793560};\\\", \\\"{x:1253,y:769,t:1527876793577};\\\", \\\"{x:1254,y:769,t:1527876793593};\\\", \\\"{x:1256,y:770,t:1527876793610};\\\", \\\"{x:1257,y:770,t:1527876793627};\\\", \\\"{x:1257,y:771,t:1527876793644};\\\", \\\"{x:1259,y:772,t:1527876793660};\\\", \\\"{x:1261,y:774,t:1527876793677};\\\", \\\"{x:1262,y:774,t:1527876793693};\\\", \\\"{x:1264,y:776,t:1527876793710};\\\", \\\"{x:1266,y:777,t:1527876793727};\\\", \\\"{x:1268,y:777,t:1527876793744};\\\", \\\"{x:1271,y:779,t:1527876793760};\\\", \\\"{x:1274,y:781,t:1527876793776};\\\", \\\"{x:1278,y:781,t:1527876793808};\\\", \\\"{x:1280,y:781,t:1527876793816};\\\", \\\"{x:1281,y:781,t:1527876793826};\\\", \\\"{x:1283,y:781,t:1527876793848};\\\", \\\"{x:1286,y:781,t:1527876793860};\\\", \\\"{x:1309,y:776,t:1527876793877};\\\", \\\"{x:1329,y:765,t:1527876793894};\\\", \\\"{x:1347,y:752,t:1527876793910};\\\", \\\"{x:1359,y:739,t:1527876793926};\\\", \\\"{x:1367,y:726,t:1527876793944};\\\", \\\"{x:1374,y:715,t:1527876793960};\\\", \\\"{x:1384,y:686,t:1527876793977};\\\", \\\"{x:1388,y:668,t:1527876793994};\\\", \\\"{x:1390,y:649,t:1527876794010};\\\", \\\"{x:1390,y:628,t:1527876794026};\\\", \\\"{x:1388,y:605,t:1527876794044};\\\", \\\"{x:1380,y:575,t:1527876794059};\\\", \\\"{x:1373,y:555,t:1527876794077};\\\", \\\"{x:1366,y:540,t:1527876794094};\\\", \\\"{x:1361,y:533,t:1527876794111};\\\", \\\"{x:1358,y:528,t:1527876794127};\\\", \\\"{x:1354,y:521,t:1527876794143};\\\", \\\"{x:1343,y:508,t:1527876794160};\\\", \\\"{x:1337,y:500,t:1527876794176};\\\", \\\"{x:1331,y:497,t:1527876794194};\\\", \\\"{x:1327,y:495,t:1527876794211};\\\", \\\"{x:1320,y:491,t:1527876794227};\\\", \\\"{x:1315,y:490,t:1527876794243};\\\", \\\"{x:1314,y:489,t:1527876794261};\\\", \\\"{x:1313,y:489,t:1527876794305};\\\", \\\"{x:1312,y:489,t:1527876794313};\\\", \\\"{x:1310,y:489,t:1527876794328};\\\", \\\"{x:1308,y:490,t:1527876794346};\\\", \\\"{x:1307,y:492,t:1527876794377};\\\", \\\"{x:1307,y:493,t:1527876794786};\\\", \\\"{x:1307,y:494,t:1527876794826};\\\", \\\"{x:1308,y:495,t:1527876794874};\\\", \\\"{x:1309,y:496,t:1527876794947};\\\", \\\"{x:1310,y:496,t:1527876794961};\\\", \\\"{x:1312,y:497,t:1527876795016};\\\", \\\"{x:1313,y:498,t:1527876795032};\\\", \\\"{x:1314,y:498,t:1527876795048};\\\", \\\"{x:1315,y:498,t:1527876795061};\\\", \\\"{x:1316,y:499,t:1527876795078};\\\", \\\"{x:1316,y:500,t:1527876795095};\\\", \\\"{x:1317,y:508,t:1527876805804};\\\", \\\"{x:1317,y:524,t:1527876805823};\\\", \\\"{x:1317,y:537,t:1527876805840};\\\", \\\"{x:1317,y:546,t:1527876805853};\\\", \\\"{x:1317,y:555,t:1527876805870};\\\", \\\"{x:1317,y:563,t:1527876805886};\\\", \\\"{x:1319,y:578,t:1527876805904};\\\", \\\"{x:1325,y:611,t:1527876805920};\\\", \\\"{x:1327,y:629,t:1527876805936};\\\", \\\"{x:1327,y:651,t:1527876805954};\\\", \\\"{x:1327,y:674,t:1527876805970};\\\", \\\"{x:1330,y:695,t:1527876805986};\\\", \\\"{x:1331,y:714,t:1527876806004};\\\", \\\"{x:1331,y:734,t:1527876806020};\\\", \\\"{x:1331,y:749,t:1527876806036};\\\", \\\"{x:1331,y:767,t:1527876806054};\\\", \\\"{x:1331,y:789,t:1527876806070};\\\", \\\"{x:1325,y:819,t:1527876806087};\\\", \\\"{x:1315,y:853,t:1527876806103};\\\", \\\"{x:1299,y:890,t:1527876806121};\\\", \\\"{x:1297,y:907,t:1527876806136};\\\", \\\"{x:1295,y:921,t:1527876806154};\\\", \\\"{x:1296,y:931,t:1527876806170};\\\", \\\"{x:1296,y:938,t:1527876806187};\\\", \\\"{x:1296,y:943,t:1527876806203};\\\", \\\"{x:1296,y:944,t:1527876806220};\\\", \\\"{x:1296,y:945,t:1527876806237};\\\", \\\"{x:1296,y:946,t:1527876806254};\\\", \\\"{x:1298,y:945,t:1527876807753};\\\", \\\"{x:1298,y:944,t:1527876807776};\\\", \\\"{x:1299,y:944,t:1527876807817};\\\", \\\"{x:1299,y:943,t:1527876807865};\\\", \\\"{x:1300,y:940,t:1527876807873};\\\", \\\"{x:1300,y:938,t:1527876807897};\\\", \\\"{x:1302,y:937,t:1527876807905};\\\", \\\"{x:1302,y:936,t:1527876807922};\\\", \\\"{x:1302,y:934,t:1527876807939};\\\", \\\"{x:1303,y:933,t:1527876807955};\\\", \\\"{x:1305,y:931,t:1527876807973};\\\", \\\"{x:1305,y:929,t:1527876807988};\\\", \\\"{x:1305,y:928,t:1527876808017};\\\", \\\"{x:1306,y:926,t:1527876808033};\\\", \\\"{x:1306,y:924,t:1527876808201};\\\", \\\"{x:1306,y:922,t:1527876808209};\\\", \\\"{x:1306,y:919,t:1527876808222};\\\", \\\"{x:1306,y:916,t:1527876808239};\\\", \\\"{x:1306,y:911,t:1527876808256};\\\", \\\"{x:1306,y:905,t:1527876808272};\\\", \\\"{x:1303,y:896,t:1527876808290};\\\", \\\"{x:1303,y:893,t:1527876808305};\\\", \\\"{x:1303,y:890,t:1527876808322};\\\", \\\"{x:1301,y:882,t:1527876808339};\\\", \\\"{x:1299,y:877,t:1527876808356};\\\", \\\"{x:1297,y:871,t:1527876808372};\\\", \\\"{x:1295,y:866,t:1527876808389};\\\", \\\"{x:1290,y:859,t:1527876808406};\\\", \\\"{x:1285,y:853,t:1527876808422};\\\", \\\"{x:1280,y:849,t:1527876808439};\\\", \\\"{x:1278,y:847,t:1527876808456};\\\", \\\"{x:1276,y:845,t:1527876808472};\\\", \\\"{x:1275,y:843,t:1527876808489};\\\", \\\"{x:1275,y:842,t:1527876808506};\\\", \\\"{x:1275,y:840,t:1527876808553};\\\", \\\"{x:1274,y:838,t:1527876808577};\\\", \\\"{x:1274,y:837,t:1527876808634};\\\", \\\"{x:1274,y:836,t:1527876808738};\\\", \\\"{x:1274,y:835,t:1527876808745};\\\", \\\"{x:1275,y:835,t:1527876808817};\\\", \\\"{x:1276,y:834,t:1527876808825};\\\", \\\"{x:1276,y:833,t:1527876808857};\\\", \\\"{x:1277,y:833,t:1527876808878};\\\", \\\"{x:1277,y:832,t:1527876808912};\\\", \\\"{x:1279,y:830,t:1527876808936};\\\", \\\"{x:1279,y:829,t:1527876808960};\\\", \\\"{x:1280,y:828,t:1527876809000};\\\", \\\"{x:1281,y:827,t:1527876812937};\\\", \\\"{x:1285,y:827,t:1527876812945};\\\", \\\"{x:1292,y:827,t:1527876812962};\\\", \\\"{x:1305,y:827,t:1527876812976};\\\", \\\"{x:1325,y:830,t:1527876812992};\\\", \\\"{x:1333,y:833,t:1527876813008};\\\", \\\"{x:1339,y:835,t:1527876813025};\\\", \\\"{x:1342,y:837,t:1527876813042};\\\", \\\"{x:1344,y:840,t:1527876813059};\\\", \\\"{x:1347,y:842,t:1527876813075};\\\", \\\"{x:1348,y:846,t:1527876813092};\\\", \\\"{x:1350,y:850,t:1527876813110};\\\", \\\"{x:1351,y:853,t:1527876813125};\\\", \\\"{x:1353,y:857,t:1527876813143};\\\", \\\"{x:1353,y:860,t:1527876813168};\\\", \\\"{x:1353,y:865,t:1527876813176};\\\", \\\"{x:1353,y:873,t:1527876813192};\\\", \\\"{x:1353,y:881,t:1527876813210};\\\", \\\"{x:1353,y:884,t:1527876813226};\\\", \\\"{x:1354,y:886,t:1527876813243};\\\", \\\"{x:1354,y:887,t:1527876813361};\\\", \\\"{x:1354,y:888,t:1527876813377};\\\", \\\"{x:1354,y:889,t:1527876813425};\\\", \\\"{x:1354,y:890,t:1527876813457};\\\", \\\"{x:1353,y:891,t:1527876813481};\\\", \\\"{x:1353,y:892,t:1527876813505};\\\", \\\"{x:1352,y:892,t:1527876813529};\\\", \\\"{x:1351,y:892,t:1527876813589};\\\", \\\"{x:1350,y:892,t:1527876813632};\\\", \\\"{x:1349,y:893,t:1527876813643};\\\", \\\"{x:1348,y:893,t:1527876813659};\\\", \\\"{x:1348,y:894,t:1527876813677};\\\", \\\"{x:1347,y:894,t:1527876813704};\\\", \\\"{x:1346,y:895,t:1527876813744};\\\", \\\"{x:1345,y:896,t:1527876813784};\\\", \\\"{x:1345,y:895,t:1527876818769};\\\", \\\"{x:1345,y:894,t:1527876818784};\\\", \\\"{x:1345,y:893,t:1527876818841};\\\", \\\"{x:1345,y:892,t:1527876818857};\\\", \\\"{x:1345,y:891,t:1527876818875};\\\", \\\"{x:1345,y:890,t:1527876818912};\\\", \\\"{x:1345,y:888,t:1527876818920};\\\", \\\"{x:1345,y:887,t:1527876818936};\\\", \\\"{x:1345,y:885,t:1527876818948};\\\", \\\"{x:1344,y:883,t:1527876818964};\\\", \\\"{x:1341,y:880,t:1527876818981};\\\", \\\"{x:1338,y:878,t:1527876818997};\\\", \\\"{x:1334,y:874,t:1527876819014};\\\", \\\"{x:1330,y:872,t:1527876819031};\\\", \\\"{x:1327,y:870,t:1527876819048};\\\", \\\"{x:1325,y:868,t:1527876819064};\\\", \\\"{x:1323,y:866,t:1527876819080};\\\", \\\"{x:1320,y:861,t:1527876819098};\\\", \\\"{x:1313,y:857,t:1527876819114};\\\", \\\"{x:1307,y:854,t:1527876819131};\\\", \\\"{x:1298,y:849,t:1527876819148};\\\", \\\"{x:1285,y:844,t:1527876819164};\\\", \\\"{x:1272,y:841,t:1527876819181};\\\", \\\"{x:1257,y:838,t:1527876819198};\\\", \\\"{x:1242,y:834,t:1527876819214};\\\", \\\"{x:1231,y:830,t:1527876819232};\\\", \\\"{x:1221,y:828,t:1527876819248};\\\", \\\"{x:1213,y:826,t:1527876819266};\\\", \\\"{x:1212,y:825,t:1527876819281};\\\", \\\"{x:1211,y:825,t:1527876819298};\\\", \\\"{x:1210,y:825,t:1527876819369};\\\", \\\"{x:1209,y:825,t:1527876819381};\\\", \\\"{x:1209,y:826,t:1527876819465};\\\", \\\"{x:1210,y:827,t:1527876819629};\\\", \\\"{x:1211,y:828,t:1527876819665};\\\", \\\"{x:1213,y:829,t:1527876819681};\\\", \\\"{x:1214,y:830,t:1527876819704};\\\", \\\"{x:1215,y:830,t:1527876819720};\\\", \\\"{x:1216,y:830,t:1527876820393};\\\", \\\"{x:1220,y:828,t:1527876820401};\\\", \\\"{x:1224,y:824,t:1527876820417};\\\", \\\"{x:1231,y:814,t:1527876820432};\\\", \\\"{x:1239,y:805,t:1527876820448};\\\", \\\"{x:1257,y:792,t:1527876820465};\\\", \\\"{x:1283,y:774,t:1527876820482};\\\", \\\"{x:1297,y:763,t:1527876820498};\\\", \\\"{x:1306,y:757,t:1527876820515};\\\", \\\"{x:1315,y:750,t:1527876820532};\\\", \\\"{x:1326,y:739,t:1527876820549};\\\", \\\"{x:1340,y:728,t:1527876820565};\\\", \\\"{x:1346,y:724,t:1527876820582};\\\", \\\"{x:1347,y:723,t:1527876820599};\\\", \\\"{x:1348,y:723,t:1527876820614};\\\", \\\"{x:1348,y:722,t:1527876820632};\\\", \\\"{x:1349,y:722,t:1527876820721};\\\", \\\"{x:1353,y:722,t:1527876820737};\\\", \\\"{x:1353,y:725,t:1527876820750};\\\", \\\"{x:1354,y:726,t:1527876820765};\\\", \\\"{x:1356,y:728,t:1527876820783};\\\", \\\"{x:1358,y:732,t:1527876820800};\\\", \\\"{x:1360,y:737,t:1527876820816};\\\", \\\"{x:1366,y:742,t:1527876820832};\\\", \\\"{x:1371,y:744,t:1527876820849};\\\", \\\"{x:1372,y:744,t:1527876820865};\\\", \\\"{x:1374,y:744,t:1527876820882};\\\", \\\"{x:1375,y:745,t:1527876820920};\\\", \\\"{x:1375,y:746,t:1527876820932};\\\", \\\"{x:1375,y:747,t:1527876820952};\\\", \\\"{x:1375,y:749,t:1527876821025};\\\", \\\"{x:1375,y:750,t:1527876821032};\\\", \\\"{x:1375,y:751,t:1527876821049};\\\", \\\"{x:1375,y:752,t:1527876821130};\\\", \\\"{x:1375,y:753,t:1527876821138};\\\", \\\"{x:1375,y:754,t:1527876821474};\\\", \\\"{x:1375,y:755,t:1527876821489};\\\", \\\"{x:1376,y:756,t:1527876821505};\\\", \\\"{x:1377,y:756,t:1527876821521};\\\", \\\"{x:1377,y:757,t:1527876821857};\\\", \\\"{x:1377,y:758,t:1527876821881};\\\", \\\"{x:1377,y:759,t:1527876821893};\\\", \\\"{x:1376,y:754,t:1527876822428};\\\", \\\"{x:1368,y:741,t:1527876822450};\\\", \\\"{x:1359,y:731,t:1527876822467};\\\", \\\"{x:1355,y:725,t:1527876822483};\\\", \\\"{x:1348,y:719,t:1527876822500};\\\", \\\"{x:1344,y:713,t:1527876822517};\\\", \\\"{x:1342,y:708,t:1527876822533};\\\", \\\"{x:1340,y:702,t:1527876822550};\\\", \\\"{x:1336,y:694,t:1527876822567};\\\", \\\"{x:1334,y:690,t:1527876822583};\\\", \\\"{x:1328,y:680,t:1527876822600};\\\", \\\"{x:1323,y:673,t:1527876822617};\\\", \\\"{x:1318,y:667,t:1527876822634};\\\", \\\"{x:1314,y:659,t:1527876822650};\\\", \\\"{x:1311,y:655,t:1527876822667};\\\", \\\"{x:1311,y:653,t:1527876822683};\\\", \\\"{x:1311,y:652,t:1527876822700};\\\", \\\"{x:1311,y:649,t:1527876822717};\\\", \\\"{x:1311,y:646,t:1527876822734};\\\", \\\"{x:1311,y:643,t:1527876822750};\\\", \\\"{x:1311,y:640,t:1527876822767};\\\", \\\"{x:1311,y:639,t:1527876822784};\\\", \\\"{x:1311,y:637,t:1527876822800};\\\", \\\"{x:1311,y:635,t:1527876822818};\\\", \\\"{x:1312,y:633,t:1527876822837};\\\", \\\"{x:1312,y:631,t:1527876822872};\\\", \\\"{x:1315,y:628,t:1527876822884};\\\", \\\"{x:1315,y:627,t:1527876822900};\\\", \\\"{x:1314,y:626,t:1527876830049};\\\", \\\"{x:1309,y:626,t:1527876830059};\\\", \\\"{x:1297,y:631,t:1527876830073};\\\", \\\"{x:1281,y:637,t:1527876830090};\\\", \\\"{x:1262,y:638,t:1527876830106};\\\", \\\"{x:1244,y:640,t:1527876830122};\\\", \\\"{x:1225,y:642,t:1527876830140};\\\", \\\"{x:1204,y:642,t:1527876830156};\\\", \\\"{x:1189,y:642,t:1527876830173};\\\", \\\"{x:1181,y:642,t:1527876830189};\\\", \\\"{x:1172,y:642,t:1527876830206};\\\", \\\"{x:1171,y:642,t:1527876830223};\\\", \\\"{x:1169,y:642,t:1527876830239};\\\", \\\"{x:1163,y:641,t:1527876830256};\\\", \\\"{x:1157,y:641,t:1527876830275};\\\", \\\"{x:1147,y:641,t:1527876830290};\\\", \\\"{x:1133,y:641,t:1527876830306};\\\", \\\"{x:1111,y:641,t:1527876830323};\\\", \\\"{x:1078,y:641,t:1527876830339};\\\", \\\"{x:1038,y:640,t:1527876830356};\\\", \\\"{x:1004,y:635,t:1527876830373};\\\", \\\"{x:966,y:628,t:1527876830390};\\\", \\\"{x:929,y:617,t:1527876830407};\\\", \\\"{x:892,y:606,t:1527876830423};\\\", \\\"{x:861,y:596,t:1527876830440};\\\", \\\"{x:836,y:591,t:1527876830456};\\\", \\\"{x:830,y:589,t:1527876830474};\\\", \\\"{x:828,y:589,t:1527876830489};\\\", \\\"{x:828,y:587,t:1527876830600};\\\", \\\"{x:828,y:585,t:1527876830624};\\\", \\\"{x:828,y:584,t:1527876830648};\\\", \\\"{x:828,y:583,t:1527876830656};\\\", \\\"{x:829,y:582,t:1527876830676};\\\", \\\"{x:830,y:581,t:1527876830690};\\\", \\\"{x:830,y:580,t:1527876830711};\\\", \\\"{x:830,y:579,t:1527876830784};\\\", \\\"{x:830,y:578,t:1527876830808};\\\", \\\"{x:830,y:577,t:1527876830890};\\\", \\\"{x:830,y:577,t:1527876830964};\\\", \\\"{x:831,y:576,t:1527876831056};\\\", \\\"{x:834,y:575,t:1527876831064};\\\", \\\"{x:835,y:574,t:1527876831074};\\\", \\\"{x:839,y:573,t:1527876831090};\\\", \\\"{x:843,y:571,t:1527876831107};\\\", \\\"{x:855,y:571,t:1527876831123};\\\", \\\"{x:871,y:571,t:1527876831141};\\\", \\\"{x:893,y:571,t:1527876831158};\\\", \\\"{x:924,y:571,t:1527876831174};\\\", \\\"{x:977,y:571,t:1527876831190};\\\", \\\"{x:1027,y:571,t:1527876831208};\\\", \\\"{x:1064,y:571,t:1527876831224};\\\", \\\"{x:1112,y:570,t:1527876831240};\\\", \\\"{x:1141,y:565,t:1527876831257};\\\", \\\"{x:1161,y:562,t:1527876831274};\\\", \\\"{x:1173,y:558,t:1527876831291};\\\", \\\"{x:1178,y:555,t:1527876831307};\\\", \\\"{x:1190,y:551,t:1527876831324};\\\", \\\"{x:1201,y:549,t:1527876831341};\\\", \\\"{x:1209,y:543,t:1527876831358};\\\", \\\"{x:1212,y:540,t:1527876831374};\\\", \\\"{x:1215,y:537,t:1527876831391};\\\", \\\"{x:1217,y:535,t:1527876831408};\\\", \\\"{x:1220,y:532,t:1527876831424};\\\", \\\"{x:1224,y:530,t:1527876831441};\\\", \\\"{x:1226,y:529,t:1527876831480};\\\", \\\"{x:1227,y:528,t:1527876831491};\\\", \\\"{x:1231,y:527,t:1527876831508};\\\", \\\"{x:1237,y:524,t:1527876831524};\\\", \\\"{x:1244,y:522,t:1527876831541};\\\", \\\"{x:1249,y:519,t:1527876831558};\\\", \\\"{x:1250,y:518,t:1527876831574};\\\", \\\"{x:1251,y:518,t:1527876831591};\\\", \\\"{x:1251,y:517,t:1527876831608};\\\", \\\"{x:1255,y:515,t:1527876831624};\\\", \\\"{x:1274,y:509,t:1527876831640};\\\", \\\"{x:1285,y:506,t:1527876831658};\\\", \\\"{x:1296,y:502,t:1527876831675};\\\", \\\"{x:1299,y:502,t:1527876831691};\\\", \\\"{x:1301,y:501,t:1527876831708};\\\", \\\"{x:1302,y:501,t:1527876831724};\\\", \\\"{x:1303,y:499,t:1527876831741};\\\", \\\"{x:1304,y:499,t:1527876831758};\\\", \\\"{x:1306,y:498,t:1527876831785};\\\", \\\"{x:1307,y:497,t:1527876831929};\\\", \\\"{x:1308,y:497,t:1527876832001};\\\", \\\"{x:1310,y:496,t:1527876832350};\\\", \\\"{x:1311,y:496,t:1527876832357};\\\", \\\"{x:1311,y:501,t:1527876837929};\\\", \\\"{x:1305,y:506,t:1527876837939};\\\", \\\"{x:1271,y:527,t:1527876837964};\\\", \\\"{x:1244,y:540,t:1527876837980};\\\", \\\"{x:1216,y:549,t:1527876837995};\\\", \\\"{x:1175,y:563,t:1527876838013};\\\", \\\"{x:1131,y:575,t:1527876838028};\\\", \\\"{x:1093,y:583,t:1527876838046};\\\", \\\"{x:1064,y:589,t:1527876838062};\\\", \\\"{x:1014,y:595,t:1527876838080};\\\", \\\"{x:980,y:601,t:1527876838096};\\\", \\\"{x:948,y:608,t:1527876838113};\\\", \\\"{x:926,y:612,t:1527876838130};\\\", \\\"{x:916,y:617,t:1527876838145};\\\", \\\"{x:912,y:619,t:1527876838162};\\\", \\\"{x:909,y:621,t:1527876838180};\\\", \\\"{x:904,y:622,t:1527876838196};\\\", \\\"{x:892,y:625,t:1527876838213};\\\", \\\"{x:872,y:630,t:1527876838230};\\\", \\\"{x:848,y:633,t:1527876838247};\\\", \\\"{x:828,y:635,t:1527876838263};\\\", \\\"{x:788,y:635,t:1527876838280};\\\", \\\"{x:761,y:635,t:1527876838296};\\\", \\\"{x:739,y:634,t:1527876838313};\\\", \\\"{x:716,y:629,t:1527876838330};\\\", \\\"{x:687,y:622,t:1527876838346};\\\", \\\"{x:658,y:615,t:1527876838363};\\\", \\\"{x:640,y:609,t:1527876838380};\\\", \\\"{x:625,y:604,t:1527876838396};\\\", \\\"{x:618,y:602,t:1527876838413};\\\", \\\"{x:613,y:600,t:1527876838430};\\\", \\\"{x:611,y:600,t:1527876838445};\\\", \\\"{x:611,y:599,t:1527876838488};\\\", \\\"{x:611,y:598,t:1527876838504};\\\", \\\"{x:610,y:596,t:1527876838513};\\\", \\\"{x:609,y:593,t:1527876838530};\\\", \\\"{x:606,y:591,t:1527876838546};\\\", \\\"{x:606,y:589,t:1527876838562};\\\", \\\"{x:606,y:588,t:1527876838579};\\\", \\\"{x:606,y:586,t:1527876838597};\\\", \\\"{x:606,y:585,t:1527876838612};\\\", \\\"{x:606,y:583,t:1527876838639};\\\", \\\"{x:606,y:582,t:1527876838648};\\\", \\\"{x:606,y:581,t:1527876838662};\\\", \\\"{x:608,y:579,t:1527876838679};\\\", \\\"{x:608,y:578,t:1527876838696};\\\", \\\"{x:609,y:578,t:1527876838720};\\\", \\\"{x:615,y:578,t:1527876839201};\\\", \\\"{x:644,y:583,t:1527876839216};\\\", \\\"{x:740,y:586,t:1527876839230};\\\", \\\"{x:835,y:590,t:1527876839247};\\\", \\\"{x:987,y:590,t:1527876839264};\\\", \\\"{x:1087,y:590,t:1527876839280};\\\", \\\"{x:1209,y:589,t:1527876839296};\\\", \\\"{x:1331,y:575,t:1527876839314};\\\", \\\"{x:1437,y:557,t:1527876839330};\\\", \\\"{x:1487,y:545,t:1527876839347};\\\", \\\"{x:1517,y:533,t:1527876839364};\\\", \\\"{x:1539,y:521,t:1527876839380};\\\", \\\"{x:1550,y:514,t:1527876839397};\\\", \\\"{x:1556,y:510,t:1527876839414};\\\", \\\"{x:1559,y:502,t:1527876839430};\\\", \\\"{x:1562,y:498,t:1527876839447};\\\", \\\"{x:1562,y:493,t:1527876839464};\\\", \\\"{x:1563,y:487,t:1527876839480};\\\", \\\"{x:1564,y:476,t:1527876839497};\\\", \\\"{x:1564,y:467,t:1527876839514};\\\", \\\"{x:1564,y:465,t:1527876839530};\\\", \\\"{x:1561,y:463,t:1527876839547};\\\", \\\"{x:1558,y:460,t:1527876839564};\\\", \\\"{x:1543,y:460,t:1527876839580};\\\", \\\"{x:1524,y:460,t:1527876839597};\\\", \\\"{x:1509,y:458,t:1527876839614};\\\", \\\"{x:1499,y:455,t:1527876839630};\\\", \\\"{x:1494,y:453,t:1527876839647};\\\", \\\"{x:1486,y:452,t:1527876839664};\\\", \\\"{x:1483,y:452,t:1527876839680};\\\", \\\"{x:1479,y:452,t:1527876839697};\\\", \\\"{x:1477,y:452,t:1527876839714};\\\", \\\"{x:1469,y:449,t:1527876839730};\\\", \\\"{x:1455,y:449,t:1527876839747};\\\", \\\"{x:1452,y:448,t:1527876839764};\\\", \\\"{x:1450,y:448,t:1527876839780};\\\", \\\"{x:1444,y:446,t:1527876839797};\\\", \\\"{x:1437,y:444,t:1527876839814};\\\", \\\"{x:1430,y:444,t:1527876839831};\\\", \\\"{x:1428,y:444,t:1527876839848};\\\", \\\"{x:1427,y:444,t:1527876839880};\\\", \\\"{x:1425,y:443,t:1527876839897};\\\", \\\"{x:1424,y:443,t:1527876839928};\\\", \\\"{x:1423,y:443,t:1527876840001};\\\", \\\"{x:1423,y:442,t:1527876840233};\\\", \\\"{x:1423,y:441,t:1527876840249};\\\", \\\"{x:1422,y:440,t:1527876840264};\\\", \\\"{x:1422,y:439,t:1527876840297};\\\", \\\"{x:1421,y:438,t:1527876840377};\\\", \\\"{x:1420,y:437,t:1527876840384};\\\", \\\"{x:1420,y:436,t:1527876840398};\\\", \\\"{x:1420,y:435,t:1527876840414};\\\", \\\"{x:1419,y:434,t:1527876840449};\\\", \\\"{x:1418,y:433,t:1527876840468};\\\", \\\"{x:1417,y:432,t:1527876840481};\\\", \\\"{x:1417,y:425,t:1527876843612};\\\", \\\"{x:1417,y:420,t:1527876843623};\\\", \\\"{x:1417,y:418,t:1527876843637};\\\", \\\"{x:1420,y:412,t:1527876843654};\\\", \\\"{x:1422,y:406,t:1527876843670};\\\", \\\"{x:1424,y:397,t:1527876843687};\\\", \\\"{x:1427,y:388,t:1527876843703};\\\", \\\"{x:1431,y:381,t:1527876843720};\\\", \\\"{x:1438,y:365,t:1527876843737};\\\", \\\"{x:1442,y:349,t:1527876843754};\\\", \\\"{x:1448,y:328,t:1527876843770};\\\", \\\"{x:1457,y:300,t:1527876843787};\\\", \\\"{x:1465,y:283,t:1527876843804};\\\", \\\"{x:1471,y:264,t:1527876843820};\\\", \\\"{x:1481,y:247,t:1527876843837};\\\", \\\"{x:1490,y:228,t:1527876843854};\\\", \\\"{x:1496,y:218,t:1527876843871};\\\", \\\"{x:1501,y:206,t:1527876843887};\\\", \\\"{x:1505,y:198,t:1527876843903};\\\", \\\"{x:1506,y:193,t:1527876843920};\\\", \\\"{x:1508,y:188,t:1527876843937};\\\", \\\"{x:1509,y:180,t:1527876843954};\\\", \\\"{x:1510,y:172,t:1527876843970};\\\", \\\"{x:1510,y:156,t:1527876843988};\\\", \\\"{x:1510,y:150,t:1527876844004};\\\", \\\"{x:1510,y:146,t:1527876844021};\\\", \\\"{x:1508,y:144,t:1527876844037};\\\", \\\"{x:1507,y:144,t:1527876844054};\\\", \\\"{x:1505,y:144,t:1527876844071};\\\", \\\"{x:1503,y:144,t:1527876844087};\\\", \\\"{x:1498,y:146,t:1527876844104};\\\", \\\"{x:1494,y:149,t:1527876844121};\\\", \\\"{x:1489,y:153,t:1527876844137};\\\", \\\"{x:1486,y:154,t:1527876844154};\\\", \\\"{x:1484,y:155,t:1527876844171};\\\", \\\"{x:1482,y:157,t:1527876844187};\\\", \\\"{x:1480,y:159,t:1527876844206};\\\", \\\"{x:1478,y:161,t:1527876844220};\\\", \\\"{x:1476,y:163,t:1527876844237};\\\", \\\"{x:1473,y:166,t:1527876844272};\\\", \\\"{x:1473,y:167,t:1527876844517};\\\", \\\"{x:1473,y:168,t:1527876844573};\\\", \\\"{x:1474,y:168,t:1527876844668};\\\", \\\"{x:1476,y:168,t:1527876844725};\\\", \\\"{x:1477,y:168,t:1527876844740};\\\", \\\"{x:1478,y:168,t:1527876844775};\\\", \\\"{x:1479,y:169,t:1527876846637};\\\", \\\"{x:1483,y:184,t:1527876846655};\\\", \\\"{x:1487,y:201,t:1527876846673};\\\", \\\"{x:1495,y:218,t:1527876846690};\\\", \\\"{x:1501,y:236,t:1527876846707};\\\", \\\"{x:1509,y:256,t:1527876846722};\\\", \\\"{x:1514,y:283,t:1527876846739};\\\", \\\"{x:1520,y:303,t:1527876846757};\\\", \\\"{x:1524,y:320,t:1527876846772};\\\", \\\"{x:1529,y:346,t:1527876846789};\\\", \\\"{x:1533,y:369,t:1527876846807};\\\", \\\"{x:1536,y:389,t:1527876846822};\\\", \\\"{x:1540,y:397,t:1527876846839};\\\", \\\"{x:1542,y:400,t:1527876846856};\\\", \\\"{x:1544,y:402,t:1527876846873};\\\", \\\"{x:1547,y:407,t:1527876846890};\\\", \\\"{x:1552,y:415,t:1527876846906};\\\", \\\"{x:1560,y:421,t:1527876846923};\\\", \\\"{x:1567,y:423,t:1527876846939};\\\", \\\"{x:1568,y:423,t:1527876846957};\\\", \\\"{x:1570,y:424,t:1527876846974};\\\", \\\"{x:1572,y:425,t:1527876846990};\\\", \\\"{x:1574,y:426,t:1527876847006};\\\", \\\"{x:1577,y:427,t:1527876847024};\\\", \\\"{x:1579,y:427,t:1527876847039};\\\", \\\"{x:1582,y:427,t:1527876847057};\\\", \\\"{x:1588,y:427,t:1527876847074};\\\", \\\"{x:1594,y:427,t:1527876847089};\\\", \\\"{x:1598,y:427,t:1527876847107};\\\", \\\"{x:1601,y:427,t:1527876847123};\\\", \\\"{x:1602,y:427,t:1527876847139};\\\", \\\"{x:1603,y:427,t:1527876847156};\\\", \\\"{x:1605,y:427,t:1527876847309};\\\", \\\"{x:1607,y:427,t:1527876847324};\\\", \\\"{x:1609,y:428,t:1527876847345};\\\", \\\"{x:1614,y:431,t:1527876847373};\\\", \\\"{x:1616,y:432,t:1527876847390};\\\", \\\"{x:1617,y:432,t:1527876847406};\\\", \\\"{x:1618,y:433,t:1527876847423};\\\", \\\"{x:1618,y:434,t:1527876848484};\\\", \\\"{x:1618,y:436,t:1527876848494};\\\", \\\"{x:1617,y:439,t:1527876848507};\\\", \\\"{x:1616,y:444,t:1527876848525};\\\", \\\"{x:1616,y:448,t:1527876848541};\\\", \\\"{x:1616,y:451,t:1527876848558};\\\", \\\"{x:1614,y:460,t:1527876848574};\\\", \\\"{x:1613,y:470,t:1527876848591};\\\", \\\"{x:1607,y:484,t:1527876848608};\\\", \\\"{x:1603,y:498,t:1527876848625};\\\", \\\"{x:1596,y:514,t:1527876848641};\\\", \\\"{x:1587,y:531,t:1527876848657};\\\", \\\"{x:1577,y:543,t:1527876848674};\\\", \\\"{x:1569,y:555,t:1527876848691};\\\", \\\"{x:1567,y:560,t:1527876848708};\\\", \\\"{x:1563,y:564,t:1527876848725};\\\", \\\"{x:1552,y:580,t:1527876848742};\\\", \\\"{x:1538,y:590,t:1527876848758};\\\", \\\"{x:1527,y:597,t:1527876848775};\\\", \\\"{x:1517,y:605,t:1527876848792};\\\", \\\"{x:1515,y:607,t:1527876848808};\\\", \\\"{x:1514,y:608,t:1527876848825};\\\", \\\"{x:1514,y:610,t:1527876848876};\\\", \\\"{x:1514,y:613,t:1527876848892};\\\", \\\"{x:1511,y:616,t:1527876848908};\\\", \\\"{x:1509,y:618,t:1527876848926};\\\", \\\"{x:1510,y:619,t:1527876849029};\\\", \\\"{x:1511,y:621,t:1527876849044};\\\", \\\"{x:1511,y:622,t:1527876849058};\\\", \\\"{x:1511,y:624,t:1527876849075};\\\", \\\"{x:1511,y:625,t:1527876849127};\\\", \\\"{x:1510,y:628,t:1527876849796};\\\", \\\"{x:1510,y:629,t:1527876849828};\\\", \\\"{x:1509,y:630,t:1527876849842};\\\", \\\"{x:1506,y:632,t:1527876849862};\\\", \\\"{x:1499,y:633,t:1527876849876};\\\", \\\"{x:1491,y:637,t:1527876849892};\\\", \\\"{x:1487,y:640,t:1527876849909};\\\", \\\"{x:1483,y:645,t:1527876849925};\\\", \\\"{x:1478,y:650,t:1527876849941};\\\", \\\"{x:1472,y:657,t:1527876849959};\\\", \\\"{x:1469,y:660,t:1527876849976};\\\", \\\"{x:1465,y:666,t:1527876849992};\\\", \\\"{x:1459,y:674,t:1527876850008};\\\", \\\"{x:1450,y:682,t:1527876850026};\\\", \\\"{x:1446,y:684,t:1527876850042};\\\", \\\"{x:1441,y:688,t:1527876850059};\\\", \\\"{x:1438,y:689,t:1527876850076};\\\", \\\"{x:1438,y:690,t:1527876850140};\\\", \\\"{x:1438,y:691,t:1527876850147};\\\", \\\"{x:1438,y:696,t:1527876850197};\\\", \\\"{x:1438,y:697,t:1527876850285};\\\", \\\"{x:1435,y:701,t:1527876850294};\\\", \\\"{x:1435,y:706,t:1527876850309};\\\", \\\"{x:1432,y:709,t:1527876850326};\\\", \\\"{x:1429,y:714,t:1527876850344};\\\", \\\"{x:1426,y:715,t:1527876850359};\\\", \\\"{x:1423,y:718,t:1527876850376};\\\", \\\"{x:1419,y:721,t:1527876850393};\\\", \\\"{x:1415,y:725,t:1527876850410};\\\", \\\"{x:1409,y:732,t:1527876850426};\\\", \\\"{x:1395,y:744,t:1527876850444};\\\", \\\"{x:1388,y:749,t:1527876850460};\\\", \\\"{x:1380,y:754,t:1527876850477};\\\", \\\"{x:1376,y:756,t:1527876850493};\\\", \\\"{x:1374,y:757,t:1527876850510};\\\", \\\"{x:1369,y:761,t:1527876850527};\\\", \\\"{x:1365,y:765,t:1527876850543};\\\", \\\"{x:1364,y:770,t:1527876850560};\\\", \\\"{x:1362,y:771,t:1527876850577};\\\", \\\"{x:1362,y:772,t:1527876850593};\\\", \\\"{x:1362,y:771,t:1527876850652};\\\", \\\"{x:1363,y:770,t:1527876850660};\\\", \\\"{x:1364,y:768,t:1527876850677};\\\", \\\"{x:1365,y:767,t:1527876850694};\\\", \\\"{x:1366,y:765,t:1527876850860};\\\", \\\"{x:1367,y:764,t:1527876850877};\\\", \\\"{x:1368,y:764,t:1527876850894};\\\", \\\"{x:1369,y:764,t:1527876850940};\\\", \\\"{x:1371,y:764,t:1527876850948};\\\", \\\"{x:1373,y:764,t:1527876850960};\\\", \\\"{x:1374,y:763,t:1527876850977};\\\", \\\"{x:1375,y:763,t:1527876851024};\\\", \\\"{x:1375,y:762,t:1527876851116};\\\", \\\"{x:1376,y:762,t:1527876851128};\\\", \\\"{x:1376,y:761,t:1527876851143};\\\", \\\"{x:1377,y:761,t:1527876851160};\\\", \\\"{x:1378,y:761,t:1527876851179};\\\", \\\"{x:1379,y:761,t:1527876851195};\\\", \\\"{x:1381,y:761,t:1527876851211};\\\", \\\"{x:1381,y:766,t:1527876853524};\\\", \\\"{x:1381,y:771,t:1527876853534};\\\", \\\"{x:1382,y:778,t:1527876853545};\\\", \\\"{x:1382,y:789,t:1527876853562};\\\", \\\"{x:1382,y:799,t:1527876853578};\\\", \\\"{x:1382,y:809,t:1527876853594};\\\", \\\"{x:1382,y:812,t:1527876853611};\\\", \\\"{x:1382,y:814,t:1527876853627};\\\", \\\"{x:1382,y:821,t:1527876853644};\\\", \\\"{x:1377,y:837,t:1527876853660};\\\", \\\"{x:1376,y:843,t:1527876853678};\\\", \\\"{x:1372,y:851,t:1527876853695};\\\", \\\"{x:1371,y:853,t:1527876853711};\\\", \\\"{x:1370,y:856,t:1527876853727};\\\", \\\"{x:1369,y:860,t:1527876853747};\\\", \\\"{x:1369,y:862,t:1527876853762};\\\", \\\"{x:1366,y:868,t:1527876853778};\\\", \\\"{x:1364,y:871,t:1527876853795};\\\", \\\"{x:1361,y:874,t:1527876853811};\\\", \\\"{x:1360,y:875,t:1527876853828};\\\", \\\"{x:1359,y:878,t:1527876853845};\\\", \\\"{x:1358,y:878,t:1527876853862};\\\", \\\"{x:1358,y:879,t:1527876853907};\\\", \\\"{x:1356,y:880,t:1527876853923};\\\", \\\"{x:1355,y:881,t:1527876853931};\\\", \\\"{x:1355,y:882,t:1527876853945};\\\", \\\"{x:1354,y:883,t:1527876853962};\\\", \\\"{x:1354,y:884,t:1527876853978};\\\", \\\"{x:1351,y:890,t:1527876853995};\\\", \\\"{x:1349,y:895,t:1527876854012};\\\", \\\"{x:1347,y:898,t:1527876854028};\\\", \\\"{x:1346,y:899,t:1527876854046};\\\", \\\"{x:1346,y:900,t:1527876854062};\\\", \\\"{x:1345,y:900,t:1527876854452};\\\", \\\"{x:1343,y:899,t:1527876854484};\\\", \\\"{x:1343,y:897,t:1527876854500};\\\", \\\"{x:1336,y:882,t:1527876854529};\\\", \\\"{x:1331,y:875,t:1527876854546};\\\", \\\"{x:1325,y:869,t:1527876854563};\\\", \\\"{x:1325,y:868,t:1527876854579};\\\", \\\"{x:1324,y:868,t:1527876854596};\\\", \\\"{x:1323,y:867,t:1527876854612};\\\", \\\"{x:1322,y:865,t:1527876854629};\\\", \\\"{x:1319,y:863,t:1527876854646};\\\", \\\"{x:1315,y:860,t:1527876854662};\\\", \\\"{x:1311,y:858,t:1527876854679};\\\", \\\"{x:1305,y:856,t:1527876854696};\\\", \\\"{x:1301,y:854,t:1527876854713};\\\", \\\"{x:1293,y:853,t:1527876854729};\\\", \\\"{x:1289,y:850,t:1527876854746};\\\", \\\"{x:1287,y:850,t:1527876854763};\\\", \\\"{x:1286,y:849,t:1527876854779};\\\", \\\"{x:1284,y:849,t:1527876854796};\\\", \\\"{x:1283,y:849,t:1527876854813};\\\", \\\"{x:1282,y:847,t:1527876854829};\\\", \\\"{x:1281,y:846,t:1527876854868};\\\", \\\"{x:1281,y:844,t:1527876854899};\\\", \\\"{x:1281,y:842,t:1527876854916};\\\", \\\"{x:1281,y:841,t:1527876854930};\\\", \\\"{x:1281,y:838,t:1527876854946};\\\", \\\"{x:1281,y:834,t:1527876854966};\\\", \\\"{x:1281,y:832,t:1527876854980};\\\", \\\"{x:1281,y:831,t:1527876854996};\\\", \\\"{x:1281,y:830,t:1527876856460};\\\", \\\"{x:1280,y:830,t:1527876856468};\\\", \\\"{x:1278,y:830,t:1527876856483};\\\", \\\"{x:1277,y:830,t:1527876856499};\\\", \\\"{x:1274,y:830,t:1527876856517};\\\", \\\"{x:1272,y:830,t:1527876856531};\\\", \\\"{x:1271,y:830,t:1527876856548};\\\", \\\"{x:1268,y:830,t:1527876856563};\\\", \\\"{x:1264,y:830,t:1527876856581};\\\", \\\"{x:1256,y:830,t:1527876856598};\\\", \\\"{x:1247,y:830,t:1527876856614};\\\", \\\"{x:1239,y:830,t:1527876856631};\\\", \\\"{x:1230,y:830,t:1527876856647};\\\", \\\"{x:1224,y:830,t:1527876856664};\\\", \\\"{x:1222,y:830,t:1527876856680};\\\", \\\"{x:1220,y:830,t:1527876856700};\\\", \\\"{x:1217,y:830,t:1527876856714};\\\", \\\"{x:1216,y:830,t:1527876856731};\\\", \\\"{x:1215,y:830,t:1527876856787};\\\", \\\"{x:1214,y:831,t:1527876856884};\\\", \\\"{x:1211,y:831,t:1527876856898};\\\", \\\"{x:1209,y:831,t:1527876856915};\\\", \\\"{x:1203,y:831,t:1527876857228};\\\", \\\"{x:1204,y:831,t:1527876857309};\\\", \\\"{x:1205,y:830,t:1527876857324};\\\", \\\"{x:1206,y:829,t:1527876857333};\\\", \\\"{x:1207,y:829,t:1527876857348};\\\", \\\"{x:1208,y:828,t:1527876857366};\\\", \\\"{x:1209,y:828,t:1527876857839};\\\", \\\"{x:1210,y:828,t:1527876857899};\\\", \\\"{x:1211,y:828,t:1527876857915};\\\", \\\"{x:1212,y:828,t:1527876857932};\\\", \\\"{x:1213,y:829,t:1527876857955};\\\", \\\"{x:1214,y:829,t:1527876858821};\\\", \\\"{x:1217,y:828,t:1527876858832};\\\", \\\"{x:1224,y:822,t:1527876858852};\\\", \\\"{x:1234,y:816,t:1527876858866};\\\", \\\"{x:1252,y:799,t:1527876858883};\\\", \\\"{x:1266,y:788,t:1527876858899};\\\", \\\"{x:1282,y:776,t:1527876858916};\\\", \\\"{x:1295,y:766,t:1527876858933};\\\", \\\"{x:1303,y:752,t:1527876858949};\\\", \\\"{x:1312,y:739,t:1527876858966};\\\", \\\"{x:1315,y:731,t:1527876858983};\\\", \\\"{x:1322,y:719,t:1527876858999};\\\", \\\"{x:1327,y:708,t:1527876859016};\\\", \\\"{x:1336,y:691,t:1527876859033};\\\", \\\"{x:1343,y:675,t:1527876859049};\\\", \\\"{x:1350,y:660,t:1527876859066};\\\", \\\"{x:1355,y:636,t:1527876859083};\\\", \\\"{x:1356,y:627,t:1527876859101};\\\", \\\"{x:1356,y:624,t:1527876859116};\\\", \\\"{x:1357,y:622,t:1527876859133};\\\", \\\"{x:1357,y:621,t:1527876859163};\\\", \\\"{x:1355,y:620,t:1527876859172};\\\", \\\"{x:1354,y:619,t:1527876859195};\\\", \\\"{x:1352,y:619,t:1527876859236};\\\", \\\"{x:1350,y:619,t:1527876859250};\\\", \\\"{x:1343,y:619,t:1527876859266};\\\", \\\"{x:1338,y:620,t:1527876859283};\\\", \\\"{x:1335,y:623,t:1527876859307};\\\", \\\"{x:1333,y:624,t:1527876859316};\\\", \\\"{x:1326,y:628,t:1527876859333};\\\", \\\"{x:1322,y:631,t:1527876859351};\\\", \\\"{x:1321,y:632,t:1527876859366};\\\", \\\"{x:1320,y:633,t:1527876859383};\\\", \\\"{x:1320,y:634,t:1527876859508};\\\", \\\"{x:1319,y:634,t:1527876859725};\\\", \\\"{x:1318,y:634,t:1527876859912};\\\", \\\"{x:1317,y:634,t:1527876860372};\\\", \\\"{x:1317,y:631,t:1527876860385};\\\", \\\"{x:1318,y:624,t:1527876860403};\\\", \\\"{x:1322,y:615,t:1527876860417};\\\", \\\"{x:1325,y:604,t:1527876860434};\\\", \\\"{x:1330,y:593,t:1527876860450};\\\", \\\"{x:1337,y:569,t:1527876860467};\\\", \\\"{x:1342,y:555,t:1527876860484};\\\", \\\"{x:1345,y:547,t:1527876860500};\\\", \\\"{x:1348,y:542,t:1527876860517};\\\", \\\"{x:1351,y:535,t:1527876860534};\\\", \\\"{x:1351,y:532,t:1527876860551};\\\", \\\"{x:1351,y:531,t:1527876860567};\\\", \\\"{x:1351,y:529,t:1527876860584};\\\", \\\"{x:1350,y:528,t:1527876860619};\\\", \\\"{x:1347,y:527,t:1527876860634};\\\", \\\"{x:1339,y:525,t:1527876860651};\\\", \\\"{x:1336,y:523,t:1527876860667};\\\", \\\"{x:1328,y:523,t:1527876860684};\\\", \\\"{x:1320,y:518,t:1527876860701};\\\", \\\"{x:1315,y:516,t:1527876860717};\\\", \\\"{x:1314,y:515,t:1527876860734};\\\", \\\"{x:1313,y:514,t:1527876860752};\\\", \\\"{x:1313,y:513,t:1527876860844};\\\", \\\"{x:1313,y:512,t:1527876860860};\\\", \\\"{x:1313,y:511,t:1527876860900};\\\", \\\"{x:1312,y:511,t:1527876860915};\\\", \\\"{x:1312,y:510,t:1527876860931};\\\", \\\"{x:1312,y:507,t:1527876860940};\\\", \\\"{x:1312,y:506,t:1527876860951};\\\", \\\"{x:1312,y:503,t:1527876860968};\\\", \\\"{x:1313,y:501,t:1527876860986};\\\", \\\"{x:1313,y:499,t:1527876861001};\\\", \\\"{x:1312,y:499,t:1527876862100};\\\", \\\"{x:1308,y:501,t:1527876862110};\\\", \\\"{x:1302,y:505,t:1527876862119};\\\", \\\"{x:1281,y:518,t:1527876862135};\\\", \\\"{x:1249,y:537,t:1527876862152};\\\", \\\"{x:1198,y:561,t:1527876862168};\\\", \\\"{x:1127,y:602,t:1527876862185};\\\", \\\"{x:1035,y:651,t:1527876862202};\\\", \\\"{x:935,y:697,t:1527876862219};\\\", \\\"{x:806,y:756,t:1527876862235};\\\", \\\"{x:746,y:782,t:1527876862252};\\\", \\\"{x:664,y:810,t:1527876862268};\\\", \\\"{x:606,y:838,t:1527876862286};\\\", \\\"{x:577,y:851,t:1527876862302};\\\", \\\"{x:569,y:854,t:1527876862319};\\\", \\\"{x:565,y:856,t:1527876862335};\\\", \\\"{x:562,y:857,t:1527876862352};\\\", \\\"{x:560,y:860,t:1527876862369};\\\", \\\"{x:556,y:863,t:1527876862385};\\\", \\\"{x:550,y:866,t:1527876862402};\\\", \\\"{x:532,y:870,t:1527876862419};\\\", \\\"{x:524,y:870,t:1527876862435};\\\", \\\"{x:522,y:870,t:1527876862453};\\\", \\\"{x:520,y:868,t:1527876862469};\\\", \\\"{x:519,y:861,t:1527876862485};\\\", \\\"{x:519,y:843,t:1527876862502};\\\", \\\"{x:519,y:822,t:1527876862519};\\\", \\\"{x:517,y:802,t:1527876862536};\\\", \\\"{x:517,y:783,t:1527876862553};\\\", \\\"{x:518,y:769,t:1527876862569};\\\", \\\"{x:519,y:762,t:1527876862585};\\\", \\\"{x:519,y:759,t:1527876862602};\\\", \\\"{x:521,y:754,t:1527876862619};\\\", \\\"{x:521,y:753,t:1527876862642};\\\", \\\"{x:521,y:752,t:1527876862652};\\\", \\\"{x:521,y:753,t:1527876862940};\\\", \\\"{x:521,y:754,t:1527876862956};\\\", \\\"{x:521,y:756,t:1527876863204};\\\", \\\"{x:521,y:757,t:1527876863219};\\\", \\\"{x:521,y:759,t:1527876863236};\\\", \\\"{x:521,y:760,t:1527876863253};\\\", \\\"{x:521,y:762,t:1527876863269};\\\", \\\"{x:520,y:764,t:1527876863286};\\\", \\\"{x:520,y:766,t:1527876863303};\\\", \\\"{x:524,y:765,t:1527876863939};\\\", \\\"{x:531,y:761,t:1527876863954};\\\", \\\"{x:546,y:751,t:1527876863970};\\\", \\\"{x:562,y:745,t:1527876863986};\\\", \\\"{x:588,y:730,t:1527876864003};\\\", \\\"{x:611,y:718,t:1527876864020};\\\", \\\"{x:641,y:700,t:1527876864037};\\\", \\\"{x:682,y:674,t:1527876864053};\\\", \\\"{x:718,y:653,t:1527876864071};\\\", \\\"{x:739,y:639,t:1527876864087};\\\", \\\"{x:754,y:627,t:1527876864104};\\\", \\\"{x:770,y:617,t:1527876864121};\\\", \\\"{x:789,y:607,t:1527876864138};\\\", \\\"{x:806,y:596,t:1527876864154};\\\", \\\"{x:822,y:582,t:1527876864170};\\\", \\\"{x:838,y:567,t:1527876864187};\\\", \\\"{x:849,y:557,t:1527876864203};\\\", \\\"{x:853,y:553,t:1527876864221};\\\", \\\"{x:855,y:552,t:1527876864238};\\\", \\\"{x:856,y:550,t:1527876864254};\\\", \\\"{x:857,y:549,t:1527876864271};\\\" ] }, { \\\"rt\\\": 10163, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 272304, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -G -C -C -G -G -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:858,y:549,t:1527876866044};\\\", \\\"{x:860,y:549,t:1527876866055};\\\", \\\"{x:863,y:549,t:1527876866635};\\\", \\\"{x:864,y:549,t:1527876866644};\\\", \\\"{x:866,y:549,t:1527876866656};\\\", \\\"{x:876,y:550,t:1527876866674};\\\", \\\"{x:890,y:552,t:1527876866689};\\\", \\\"{x:907,y:555,t:1527876866705};\\\", \\\"{x:919,y:556,t:1527876866723};\\\", \\\"{x:939,y:557,t:1527876866739};\\\", \\\"{x:954,y:560,t:1527876866755};\\\", \\\"{x:965,y:562,t:1527876866773};\\\", \\\"{x:971,y:565,t:1527876866790};\\\", \\\"{x:976,y:565,t:1527876866806};\\\", \\\"{x:984,y:565,t:1527876866823};\\\", \\\"{x:989,y:566,t:1527876866840};\\\", \\\"{x:997,y:566,t:1527876866855};\\\", \\\"{x:1004,y:566,t:1527876866873};\\\", \\\"{x:1014,y:566,t:1527876866890};\\\", \\\"{x:1024,y:564,t:1527876866905};\\\", \\\"{x:1037,y:561,t:1527876866923};\\\", \\\"{x:1057,y:554,t:1527876866938};\\\", \\\"{x:1066,y:551,t:1527876866956};\\\", \\\"{x:1071,y:548,t:1527876866972};\\\", \\\"{x:1075,y:545,t:1527876866990};\\\", \\\"{x:1079,y:542,t:1527876867006};\\\", \\\"{x:1083,y:538,t:1527876867022};\\\", \\\"{x:1091,y:525,t:1527876867040};\\\", \\\"{x:1104,y:508,t:1527876867055};\\\", \\\"{x:1110,y:496,t:1527876867072};\\\", \\\"{x:1117,y:487,t:1527876867089};\\\", \\\"{x:1121,y:477,t:1527876867106};\\\", \\\"{x:1123,y:471,t:1527876867122};\\\", \\\"{x:1123,y:463,t:1527876867139};\\\", \\\"{x:1123,y:460,t:1527876867156};\\\", \\\"{x:1123,y:458,t:1527876867172};\\\", \\\"{x:1123,y:455,t:1527876867189};\\\", \\\"{x:1123,y:451,t:1527876867207};\\\", \\\"{x:1123,y:448,t:1527876867223};\\\", \\\"{x:1122,y:446,t:1527876867240};\\\", \\\"{x:1121,y:445,t:1527876867257};\\\", \\\"{x:1120,y:445,t:1527876867348};\\\", \\\"{x:1119,y:445,t:1527876867357};\\\", \\\"{x:1116,y:449,t:1527876867373};\\\", \\\"{x:1116,y:460,t:1527876867390};\\\", \\\"{x:1117,y:475,t:1527876867407};\\\", \\\"{x:1119,y:494,t:1527876867423};\\\", \\\"{x:1119,y:509,t:1527876867439};\\\", \\\"{x:1119,y:522,t:1527876867457};\\\", \\\"{x:1119,y:532,t:1527876867473};\\\", \\\"{x:1119,y:537,t:1527876867489};\\\", \\\"{x:1119,y:543,t:1527876867506};\\\", \\\"{x:1119,y:550,t:1527876867522};\\\", \\\"{x:1119,y:558,t:1527876867541};\\\", \\\"{x:1119,y:559,t:1527876867556};\\\", \\\"{x:1119,y:560,t:1527876867660};\\\", \\\"{x:1119,y:561,t:1527876867675};\\\", \\\"{x:1120,y:563,t:1527876867691};\\\", \\\"{x:1121,y:563,t:1527876867707};\\\", \\\"{x:1122,y:564,t:1527876867724};\\\", \\\"{x:1124,y:564,t:1527876867747};\\\", \\\"{x:1126,y:564,t:1527876867764};\\\", \\\"{x:1128,y:564,t:1527876867774};\\\", \\\"{x:1133,y:564,t:1527876867789};\\\", \\\"{x:1143,y:563,t:1527876867807};\\\", \\\"{x:1158,y:562,t:1527876867824};\\\", \\\"{x:1174,y:562,t:1527876867840};\\\", \\\"{x:1188,y:562,t:1527876867856};\\\", \\\"{x:1193,y:562,t:1527876867874};\\\", \\\"{x:1200,y:561,t:1527876867890};\\\", \\\"{x:1203,y:560,t:1527876867907};\\\", \\\"{x:1210,y:558,t:1527876867923};\\\", \\\"{x:1216,y:556,t:1527876867940};\\\", \\\"{x:1220,y:555,t:1527876867957};\\\", \\\"{x:1224,y:553,t:1527876867974};\\\", \\\"{x:1226,y:553,t:1527876867990};\\\", \\\"{x:1227,y:553,t:1527876868007};\\\", \\\"{x:1229,y:553,t:1527876868024};\\\", \\\"{x:1232,y:553,t:1527876868040};\\\", \\\"{x:1237,y:552,t:1527876868057};\\\", \\\"{x:1242,y:551,t:1527876868074};\\\", \\\"{x:1248,y:551,t:1527876868091};\\\", \\\"{x:1255,y:551,t:1527876868107};\\\", \\\"{x:1256,y:551,t:1527876868124};\\\", \\\"{x:1262,y:551,t:1527876868141};\\\", \\\"{x:1270,y:552,t:1527876868157};\\\", \\\"{x:1276,y:555,t:1527876868174};\\\", \\\"{x:1280,y:555,t:1527876868191};\\\", \\\"{x:1284,y:555,t:1527876868208};\\\", \\\"{x:1287,y:556,t:1527876868223};\\\", \\\"{x:1289,y:556,t:1527876868241};\\\", \\\"{x:1291,y:557,t:1527876868257};\\\", \\\"{x:1293,y:558,t:1527876868276};\\\", \\\"{x:1294,y:558,t:1527876868316};\\\", \\\"{x:1295,y:559,t:1527876868396};\\\", \\\"{x:1294,y:559,t:1527876868508};\\\", \\\"{x:1293,y:559,t:1527876868564};\\\", \\\"{x:1291,y:559,t:1527876868579};\\\", \\\"{x:1290,y:559,t:1527876868620};\\\", \\\"{x:1288,y:559,t:1527876868636};\\\", \\\"{x:1287,y:559,t:1527876868652};\\\", \\\"{x:1285,y:559,t:1527876868662};\\\", \\\"{x:1284,y:561,t:1527876868673};\\\", \\\"{x:1283,y:561,t:1527876868691};\\\", \\\"{x:1280,y:561,t:1527876868706};\\\", \\\"{x:1279,y:563,t:1527876868723};\\\", \\\"{x:1277,y:565,t:1527876868741};\\\", \\\"{x:1276,y:565,t:1527876868757};\\\", \\\"{x:1279,y:563,t:1527876869060};\\\", \\\"{x:1286,y:562,t:1527876869076};\\\", \\\"{x:1290,y:560,t:1527876869092};\\\", \\\"{x:1305,y:558,t:1527876869108};\\\", \\\"{x:1317,y:555,t:1527876869125};\\\", \\\"{x:1322,y:555,t:1527876869142};\\\", \\\"{x:1326,y:554,t:1527876869158};\\\", \\\"{x:1329,y:552,t:1527876869175};\\\", \\\"{x:1334,y:552,t:1527876869191};\\\", \\\"{x:1339,y:551,t:1527876869208};\\\", \\\"{x:1346,y:551,t:1527876869225};\\\", \\\"{x:1354,y:551,t:1527876869242};\\\", \\\"{x:1357,y:550,t:1527876869259};\\\", \\\"{x:1358,y:549,t:1527876869275};\\\", \\\"{x:1363,y:549,t:1527876869291};\\\", \\\"{x:1368,y:549,t:1527876869308};\\\", \\\"{x:1375,y:550,t:1527876869325};\\\", \\\"{x:1378,y:552,t:1527876869342};\\\", \\\"{x:1381,y:553,t:1527876869359};\\\", \\\"{x:1384,y:554,t:1527876869375};\\\", \\\"{x:1387,y:556,t:1527876869392};\\\", \\\"{x:1389,y:557,t:1527876869408};\\\", \\\"{x:1390,y:557,t:1527876869444};\\\", \\\"{x:1392,y:557,t:1527876869484};\\\", \\\"{x:1394,y:557,t:1527876869492};\\\", \\\"{x:1400,y:560,t:1527876869508};\\\", \\\"{x:1404,y:561,t:1527876869525};\\\", \\\"{x:1409,y:562,t:1527876869543};\\\", \\\"{x:1411,y:563,t:1527876869558};\\\", \\\"{x:1412,y:564,t:1527876869575};\\\", \\\"{x:1413,y:564,t:1527876869724};\\\", \\\"{x:1414,y:566,t:1527876869747};\\\", \\\"{x:1414,y:567,t:1527876869758};\\\", \\\"{x:1415,y:567,t:1527876869775};\\\", \\\"{x:1417,y:567,t:1527876869867};\\\", \\\"{x:1418,y:567,t:1527876869876};\\\", \\\"{x:1421,y:567,t:1527876869893};\\\", \\\"{x:1421,y:571,t:1527876869996};\\\", \\\"{x:1421,y:578,t:1527876870009};\\\", \\\"{x:1421,y:593,t:1527876870026};\\\", \\\"{x:1422,y:610,t:1527876870042};\\\", \\\"{x:1427,y:626,t:1527876870060};\\\", \\\"{x:1430,y:633,t:1527876870076};\\\", \\\"{x:1432,y:642,t:1527876870092};\\\", \\\"{x:1434,y:647,t:1527876870109};\\\", \\\"{x:1434,y:650,t:1527876870125};\\\", \\\"{x:1434,y:651,t:1527876870171};\\\", \\\"{x:1434,y:652,t:1527876870180};\\\", \\\"{x:1435,y:652,t:1527876870192};\\\", \\\"{x:1435,y:653,t:1527876870210};\\\", \\\"{x:1435,y:654,t:1527876870227};\\\", \\\"{x:1438,y:654,t:1527876870242};\\\", \\\"{x:1443,y:651,t:1527876870260};\\\", \\\"{x:1444,y:648,t:1527876870276};\\\", \\\"{x:1445,y:644,t:1527876870292};\\\", \\\"{x:1447,y:638,t:1527876870309};\\\", \\\"{x:1449,y:636,t:1527876870326};\\\", \\\"{x:1449,y:635,t:1527876870342};\\\", \\\"{x:1450,y:635,t:1527876870359};\\\", \\\"{x:1450,y:634,t:1527876870412};\\\", \\\"{x:1450,y:633,t:1527876870532};\\\", \\\"{x:1450,y:632,t:1527876870563};\\\", \\\"{x:1450,y:631,t:1527876870575};\\\", \\\"{x:1446,y:622,t:1527876870592};\\\", \\\"{x:1439,y:612,t:1527876870608};\\\", \\\"{x:1437,y:606,t:1527876870626};\\\", \\\"{x:1434,y:601,t:1527876870642};\\\", \\\"{x:1434,y:598,t:1527876870658};\\\", \\\"{x:1431,y:594,t:1527876870676};\\\", \\\"{x:1427,y:587,t:1527876870693};\\\", \\\"{x:1420,y:577,t:1527876870708};\\\", \\\"{x:1416,y:571,t:1527876870726};\\\", \\\"{x:1414,y:569,t:1527876870743};\\\", \\\"{x:1411,y:567,t:1527876870759};\\\", \\\"{x:1410,y:566,t:1527876870776};\\\", \\\"{x:1409,y:566,t:1527876870909};\\\", \\\"{x:1409,y:565,t:1527876870927};\\\", \\\"{x:1410,y:564,t:1527876870959};\\\", \\\"{x:1410,y:563,t:1527876870976};\\\", \\\"{x:1408,y:564,t:1527876871197};\\\", \\\"{x:1407,y:564,t:1527876871210};\\\", \\\"{x:1398,y:564,t:1527876871226};\\\", \\\"{x:1388,y:566,t:1527876871243};\\\", \\\"{x:1381,y:569,t:1527876871260};\\\", \\\"{x:1372,y:572,t:1527876871277};\\\", \\\"{x:1366,y:572,t:1527876871293};\\\", \\\"{x:1360,y:572,t:1527876871310};\\\", \\\"{x:1355,y:572,t:1527876871326};\\\", \\\"{x:1350,y:572,t:1527876871343};\\\", \\\"{x:1347,y:572,t:1527876871360};\\\", \\\"{x:1341,y:573,t:1527876871376};\\\", \\\"{x:1336,y:573,t:1527876871393};\\\", \\\"{x:1330,y:574,t:1527876871410};\\\", \\\"{x:1325,y:575,t:1527876871426};\\\", \\\"{x:1320,y:576,t:1527876871443};\\\", \\\"{x:1315,y:576,t:1527876871460};\\\", \\\"{x:1313,y:576,t:1527876871476};\\\", \\\"{x:1311,y:576,t:1527876871508};\\\", \\\"{x:1310,y:576,t:1527876871556};\\\", \\\"{x:1309,y:576,t:1527876871563};\\\", \\\"{x:1308,y:576,t:1527876871577};\\\", \\\"{x:1304,y:576,t:1527876871593};\\\", \\\"{x:1301,y:576,t:1527876871610};\\\", \\\"{x:1297,y:576,t:1527876871627};\\\", \\\"{x:1295,y:576,t:1527876871642};\\\", \\\"{x:1293,y:576,t:1527876871659};\\\", \\\"{x:1291,y:575,t:1527876871842};\\\", \\\"{x:1291,y:573,t:1527876871899};\\\", \\\"{x:1290,y:573,t:1527876871909};\\\", \\\"{x:1290,y:571,t:1527876871927};\\\", \\\"{x:1290,y:570,t:1527876871943};\\\", \\\"{x:1289,y:568,t:1527876871959};\\\", \\\"{x:1289,y:566,t:1527876871977};\\\", \\\"{x:1288,y:566,t:1527876872012};\\\", \\\"{x:1286,y:566,t:1527876872125};\\\", \\\"{x:1282,y:566,t:1527876872144};\\\", \\\"{x:1276,y:566,t:1527876872160};\\\", \\\"{x:1262,y:568,t:1527876872178};\\\", \\\"{x:1247,y:569,t:1527876872195};\\\", \\\"{x:1231,y:574,t:1527876872210};\\\", \\\"{x:1207,y:578,t:1527876872227};\\\", \\\"{x:1189,y:580,t:1527876872244};\\\", \\\"{x:1166,y:583,t:1527876872260};\\\", \\\"{x:1147,y:583,t:1527876872277};\\\", \\\"{x:1126,y:587,t:1527876872295};\\\", \\\"{x:1111,y:589,t:1527876872310};\\\", \\\"{x:1097,y:591,t:1527876872327};\\\", \\\"{x:1078,y:595,t:1527876872345};\\\", \\\"{x:1064,y:599,t:1527876872361};\\\", \\\"{x:1051,y:601,t:1527876872377};\\\", \\\"{x:1036,y:604,t:1527876872394};\\\", \\\"{x:1020,y:605,t:1527876872411};\\\", \\\"{x:1002,y:606,t:1527876872428};\\\", \\\"{x:975,y:606,t:1527876872443};\\\", \\\"{x:955,y:606,t:1527876872461};\\\", \\\"{x:923,y:606,t:1527876872478};\\\", \\\"{x:887,y:606,t:1527876872494};\\\", \\\"{x:849,y:605,t:1527876872511};\\\", \\\"{x:819,y:599,t:1527876872528};\\\", \\\"{x:797,y:591,t:1527876872544};\\\", \\\"{x:779,y:585,t:1527876872561};\\\", \\\"{x:762,y:579,t:1527876872577};\\\", \\\"{x:751,y:576,t:1527876872593};\\\", \\\"{x:749,y:576,t:1527876872610};\\\", \\\"{x:748,y:575,t:1527876872626};\\\", \\\"{x:748,y:571,t:1527876872643};\\\", \\\"{x:753,y:563,t:1527876872661};\\\", \\\"{x:757,y:554,t:1527876872677};\\\", \\\"{x:761,y:546,t:1527876872693};\\\", \\\"{x:767,y:536,t:1527876872711};\\\", \\\"{x:772,y:530,t:1527876872726};\\\", \\\"{x:775,y:526,t:1527876872743};\\\", \\\"{x:776,y:524,t:1527876872761};\\\", \\\"{x:776,y:523,t:1527876872777};\\\", \\\"{x:769,y:520,t:1527876872793};\\\", \\\"{x:753,y:518,t:1527876872811};\\\", \\\"{x:733,y:518,t:1527876872827};\\\", \\\"{x:714,y:518,t:1527876872844};\\\", \\\"{x:696,y:515,t:1527876872864};\\\", \\\"{x:677,y:513,t:1527876872877};\\\", \\\"{x:667,y:511,t:1527876872893};\\\", \\\"{x:660,y:510,t:1527876872911};\\\", \\\"{x:656,y:508,t:1527876872927};\\\", \\\"{x:655,y:508,t:1527876872944};\\\", \\\"{x:654,y:508,t:1527876872963};\\\", \\\"{x:653,y:507,t:1527876872978};\\\", \\\"{x:652,y:507,t:1527876873011};\\\", \\\"{x:651,y:507,t:1527876873027};\\\", \\\"{x:649,y:507,t:1527876873044};\\\", \\\"{x:645,y:507,t:1527876873061};\\\", \\\"{x:641,y:507,t:1527876873078};\\\", \\\"{x:637,y:507,t:1527876873094};\\\", \\\"{x:632,y:507,t:1527876873111};\\\", \\\"{x:627,y:506,t:1527876873127};\\\", \\\"{x:624,y:506,t:1527876873144};\\\", \\\"{x:623,y:505,t:1527876873160};\\\", \\\"{x:621,y:505,t:1527876873195};\\\", \\\"{x:620,y:505,t:1527876873219};\\\", \\\"{x:626,y:505,t:1527876873685};\\\", \\\"{x:632,y:508,t:1527876873695};\\\", \\\"{x:646,y:510,t:1527876873711};\\\", \\\"{x:664,y:514,t:1527876873727};\\\", \\\"{x:684,y:519,t:1527876873745};\\\", \\\"{x:705,y:525,t:1527876873762};\\\", \\\"{x:727,y:531,t:1527876873778};\\\", \\\"{x:763,y:540,t:1527876873794};\\\", \\\"{x:785,y:544,t:1527876873811};\\\", \\\"{x:806,y:548,t:1527876873828};\\\", \\\"{x:821,y:549,t:1527876873845};\\\", \\\"{x:833,y:551,t:1527876873862};\\\", \\\"{x:835,y:551,t:1527876873877};\\\", \\\"{x:837,y:551,t:1527876873895};\\\", \\\"{x:838,y:551,t:1527876874194};\\\", \\\"{x:838,y:551,t:1527876874288};\\\", \\\"{x:838,y:552,t:1527876874542};\\\", \\\"{x:818,y:570,t:1527876874563};\\\", \\\"{x:686,y:647,t:1527876874578};\\\", \\\"{x:587,y:714,t:1527876874595};\\\", \\\"{x:519,y:753,t:1527876874612};\\\", \\\"{x:489,y:775,t:1527876874629};\\\", \\\"{x:454,y:793,t:1527876874646};\\\", \\\"{x:441,y:803,t:1527876874662};\\\", \\\"{x:441,y:806,t:1527876874678};\\\", \\\"{x:435,y:810,t:1527876874696};\\\", \\\"{x:433,y:811,t:1527876874713};\\\", \\\"{x:432,y:813,t:1527876874729};\\\", \\\"{x:436,y:810,t:1527876874811};\\\", \\\"{x:445,y:804,t:1527876874819};\\\", \\\"{x:456,y:798,t:1527876874830};\\\", \\\"{x:474,y:785,t:1527876874846};\\\", \\\"{x:486,y:773,t:1527876874863};\\\", \\\"{x:491,y:764,t:1527876874880};\\\", \\\"{x:493,y:762,t:1527876874896};\\\", \\\"{x:494,y:762,t:1527876874912};\\\", \\\"{x:494,y:761,t:1527876874979};\\\", \\\"{x:496,y:758,t:1527876874997};\\\", \\\"{x:498,y:755,t:1527876875012};\\\", \\\"{x:500,y:753,t:1527876875030};\\\", \\\"{x:501,y:752,t:1527876875047};\\\", \\\"{x:501,y:750,t:1527876875066};\\\", \\\"{x:502,y:749,t:1527876875079};\\\", \\\"{x:505,y:746,t:1527876875096};\\\", \\\"{x:506,y:744,t:1527876875115};\\\", \\\"{x:507,y:743,t:1527876875129};\\\", \\\"{x:507,y:742,t:1527876875146};\\\", \\\"{x:508,y:741,t:1527876875211};\\\", \\\"{x:508,y:741,t:1527876875313};\\\", \\\"{x:511,y:741,t:1527876875676};\\\", \\\"{x:515,y:741,t:1527876875684};\\\", \\\"{x:527,y:738,t:1527876875696};\\\", \\\"{x:569,y:722,t:1527876875713};\\\", \\\"{x:625,y:704,t:1527876875730};\\\", \\\"{x:688,y:679,t:1527876875746};\\\", \\\"{x:782,y:653,t:1527876875763};\\\", \\\"{x:820,y:647,t:1527876875780};\\\", \\\"{x:845,y:642,t:1527876875796};\\\", \\\"{x:867,y:638,t:1527876875813};\\\", \\\"{x:881,y:635,t:1527876875830};\\\", \\\"{x:885,y:632,t:1527876875846};\\\", \\\"{x:893,y:632,t:1527876876260};\\\", \\\"{x:903,y:630,t:1527876876267};\\\", \\\"{x:906,y:629,t:1527876876280};\\\", \\\"{x:908,y:627,t:1527876876297};\\\", \\\"{x:919,y:613,t:1527876876358};\\\", \\\"{x:920,y:609,t:1527876876364};\\\", \\\"{x:923,y:604,t:1527876876380};\\\", \\\"{x:924,y:601,t:1527876876397};\\\", \\\"{x:925,y:600,t:1527876876414};\\\", \\\"{x:926,y:599,t:1527876876430};\\\" ] }, { \\\"rt\\\": 40399, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 313994, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -F -X -O -X -N -N -D -N -Z -Z -Z -O -M -M -B -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:919,y:603,t:1527876877021};\\\", \\\"{x:912,y:604,t:1527876877035};\\\", \\\"{x:906,y:606,t:1527876877046};\\\", \\\"{x:892,y:608,t:1527876877064};\\\", \\\"{x:875,y:611,t:1527876877080};\\\", \\\"{x:857,y:613,t:1527876877097};\\\", \\\"{x:836,y:613,t:1527876877114};\\\", \\\"{x:798,y:613,t:1527876877131};\\\", \\\"{x:771,y:613,t:1527876877146};\\\", \\\"{x:754,y:613,t:1527876877164};\\\", \\\"{x:740,y:613,t:1527876877180};\\\", \\\"{x:730,y:613,t:1527876877198};\\\", \\\"{x:729,y:613,t:1527876877428};\\\", \\\"{x:726,y:614,t:1527876877435};\\\", \\\"{x:726,y:615,t:1527876877448};\\\", \\\"{x:726,y:617,t:1527876877464};\\\", \\\"{x:724,y:620,t:1527876877481};\\\", \\\"{x:724,y:623,t:1527876877498};\\\", \\\"{x:723,y:626,t:1527876877516};\\\", \\\"{x:720,y:632,t:1527876877531};\\\", \\\"{x:720,y:633,t:1527876877548};\\\", \\\"{x:719,y:636,t:1527876877564};\\\", \\\"{x:719,y:642,t:1527876877580};\\\", \\\"{x:716,y:647,t:1527876877597};\\\", \\\"{x:713,y:653,t:1527876877614};\\\", \\\"{x:713,y:655,t:1527876877631};\\\", \\\"{x:712,y:656,t:1527876877648};\\\", \\\"{x:712,y:658,t:1527876877665};\\\", \\\"{x:712,y:659,t:1527876877680};\\\", \\\"{x:712,y:660,t:1527876877698};\\\", \\\"{x:712,y:661,t:1527876879378};\\\", \\\"{x:712,y:663,t:1527876879394};\\\", \\\"{x:712,y:664,t:1527876879418};\\\", \\\"{x:712,y:666,t:1527876879475};\\\", \\\"{x:712,y:667,t:1527876879819};\\\", \\\"{x:712,y:666,t:1527876880003};\\\", \\\"{x:712,y:665,t:1527876880016};\\\", \\\"{x:712,y:664,t:1527876880033};\\\", \\\"{x:712,y:663,t:1527876880124};\\\", \\\"{x:712,y:662,t:1527876880147};\\\", \\\"{x:712,y:661,t:1527876880267};\\\", \\\"{x:712,y:660,t:1527876880300};\\\", \\\"{x:713,y:659,t:1527876880364};\\\", \\\"{x:713,y:658,t:1527876880403};\\\", \\\"{x:714,y:657,t:1527876880435};\\\", \\\"{x:715,y:657,t:1527876880451};\\\", \\\"{x:719,y:654,t:1527876880467};\\\", \\\"{x:728,y:650,t:1527876880484};\\\", \\\"{x:743,y:648,t:1527876880501};\\\", \\\"{x:760,y:645,t:1527876880517};\\\", \\\"{x:782,y:643,t:1527876880535};\\\", \\\"{x:799,y:643,t:1527876880550};\\\", \\\"{x:803,y:642,t:1527876880568};\\\", \\\"{x:806,y:642,t:1527876881099};\\\", \\\"{x:807,y:642,t:1527876881108};\\\", \\\"{x:809,y:642,t:1527876881118};\\\", \\\"{x:819,y:642,t:1527876881134};\\\", \\\"{x:835,y:642,t:1527876881151};\\\", \\\"{x:855,y:642,t:1527876881167};\\\", \\\"{x:871,y:642,t:1527876881184};\\\", \\\"{x:891,y:645,t:1527876881201};\\\", \\\"{x:913,y:647,t:1527876881218};\\\", \\\"{x:937,y:650,t:1527876881235};\\\", \\\"{x:984,y:650,t:1527876881252};\\\", \\\"{x:1014,y:648,t:1527876881268};\\\", \\\"{x:1040,y:645,t:1527876881285};\\\", \\\"{x:1061,y:644,t:1527876881302};\\\", \\\"{x:1086,y:644,t:1527876881318};\\\", \\\"{x:1121,y:641,t:1527876881334};\\\", \\\"{x:1171,y:629,t:1527876881351};\\\", \\\"{x:1206,y:617,t:1527876881368};\\\", \\\"{x:1225,y:610,t:1527876881385};\\\", \\\"{x:1235,y:609,t:1527876881402};\\\", \\\"{x:1240,y:608,t:1527876881418};\\\", \\\"{x:1241,y:611,t:1527876881540};\\\", \\\"{x:1241,y:613,t:1527876881552};\\\", \\\"{x:1241,y:615,t:1527876881569};\\\", \\\"{x:1241,y:616,t:1527876881584};\\\", \\\"{x:1241,y:618,t:1527876881601};\\\", \\\"{x:1241,y:619,t:1527876881618};\\\", \\\"{x:1241,y:621,t:1527876881636};\\\", \\\"{x:1241,y:622,t:1527876881715};\\\", \\\"{x:1241,y:623,t:1527876881731};\\\", \\\"{x:1241,y:624,t:1527876881747};\\\", \\\"{x:1241,y:625,t:1527876881755};\\\", \\\"{x:1241,y:626,t:1527876881770};\\\", \\\"{x:1240,y:629,t:1527876881785};\\\", \\\"{x:1240,y:630,t:1527876882228};\\\", \\\"{x:1241,y:630,t:1527876883284};\\\", \\\"{x:1242,y:629,t:1527876883308};\\\", \\\"{x:1243,y:629,t:1527876883348};\\\", \\\"{x:1244,y:629,t:1527876883355};\\\", \\\"{x:1245,y:628,t:1527876883387};\\\", \\\"{x:1246,y:628,t:1527876883403};\\\", \\\"{x:1248,y:628,t:1527876883420};\\\", \\\"{x:1253,y:626,t:1527876883437};\\\", \\\"{x:1255,y:626,t:1527876883453};\\\", \\\"{x:1262,y:625,t:1527876883469};\\\", \\\"{x:1272,y:624,t:1527876883486};\\\", \\\"{x:1286,y:624,t:1527876883503};\\\", \\\"{x:1301,y:624,t:1527876883520};\\\", \\\"{x:1317,y:624,t:1527876883537};\\\", \\\"{x:1332,y:624,t:1527876883554};\\\", \\\"{x:1346,y:624,t:1527876883569};\\\", \\\"{x:1362,y:626,t:1527876883587};\\\", \\\"{x:1376,y:629,t:1527876883603};\\\", \\\"{x:1389,y:631,t:1527876883619};\\\", \\\"{x:1397,y:632,t:1527876883637};\\\", \\\"{x:1402,y:632,t:1527876883654};\\\", \\\"{x:1406,y:632,t:1527876883670};\\\", \\\"{x:1409,y:632,t:1527876883686};\\\", \\\"{x:1410,y:632,t:1527876883703};\\\", \\\"{x:1411,y:632,t:1527876883720};\\\", \\\"{x:1412,y:632,t:1527876883737};\\\", \\\"{x:1413,y:632,t:1527876883753};\\\", \\\"{x:1415,y:631,t:1527876883771};\\\", \\\"{x:1418,y:629,t:1527876883787};\\\", \\\"{x:1422,y:628,t:1527876883804};\\\", \\\"{x:1426,y:627,t:1527876883821};\\\", \\\"{x:1427,y:627,t:1527876883837};\\\", \\\"{x:1428,y:627,t:1527876883854};\\\", \\\"{x:1429,y:627,t:1527876883948};\\\", \\\"{x:1430,y:627,t:1527876883955};\\\", \\\"{x:1431,y:627,t:1527876883971};\\\", \\\"{x:1432,y:627,t:1527876883987};\\\", \\\"{x:1436,y:627,t:1527876884004};\\\", \\\"{x:1437,y:627,t:1527876884021};\\\", \\\"{x:1439,y:627,t:1527876884037};\\\", \\\"{x:1440,y:627,t:1527876884054};\\\", \\\"{x:1442,y:627,t:1527876884071};\\\", \\\"{x:1444,y:629,t:1527876884090};\\\", \\\"{x:1447,y:629,t:1527876884103};\\\", \\\"{x:1448,y:629,t:1527876884120};\\\", \\\"{x:1449,y:629,t:1527876884137};\\\", \\\"{x:1449,y:630,t:1527876884170};\\\", \\\"{x:1451,y:630,t:1527876884187};\\\", \\\"{x:1453,y:633,t:1527876884203};\\\", \\\"{x:1454,y:634,t:1527876884220};\\\", \\\"{x:1454,y:637,t:1527876884237};\\\", \\\"{x:1454,y:639,t:1527876884258};\\\", \\\"{x:1453,y:641,t:1527876884270};\\\", \\\"{x:1448,y:647,t:1527876884287};\\\", \\\"{x:1445,y:652,t:1527876884304};\\\", \\\"{x:1441,y:655,t:1527876884320};\\\", \\\"{x:1432,y:660,t:1527876884338};\\\", \\\"{x:1422,y:664,t:1527876884354};\\\", \\\"{x:1411,y:671,t:1527876884370};\\\", \\\"{x:1383,y:683,t:1527876884387};\\\", \\\"{x:1358,y:690,t:1527876884404};\\\", \\\"{x:1336,y:698,t:1527876884420};\\\", \\\"{x:1316,y:706,t:1527876884438};\\\", \\\"{x:1306,y:711,t:1527876884453};\\\", \\\"{x:1301,y:712,t:1527876884470};\\\", \\\"{x:1302,y:712,t:1527876884605};\\\", \\\"{x:1313,y:709,t:1527876884621};\\\", \\\"{x:1320,y:705,t:1527876884637};\\\", \\\"{x:1328,y:702,t:1527876884655};\\\", \\\"{x:1333,y:700,t:1527876884671};\\\", \\\"{x:1336,y:700,t:1527876884688};\\\", \\\"{x:1340,y:699,t:1527876884704};\\\", \\\"{x:1341,y:699,t:1527876884720};\\\", \\\"{x:1342,y:699,t:1527876884738};\\\", \\\"{x:1345,y:698,t:1527876884755};\\\", \\\"{x:1346,y:697,t:1527876884787};\\\", \\\"{x:1347,y:697,t:1527876884955};\\\", \\\"{x:1348,y:697,t:1527876885019};\\\", \\\"{x:1349,y:699,t:1527876896947};\\\", \\\"{x:1352,y:713,t:1527876896966};\\\", \\\"{x:1362,y:741,t:1527876896982};\\\", \\\"{x:1376,y:756,t:1527876896998};\\\", \\\"{x:1385,y:770,t:1527876897015};\\\", \\\"{x:1387,y:775,t:1527876897032};\\\", \\\"{x:1389,y:777,t:1527876897048};\\\", \\\"{x:1395,y:786,t:1527876897066};\\\", \\\"{x:1400,y:791,t:1527876897082};\\\", \\\"{x:1401,y:792,t:1527876897098};\\\", \\\"{x:1402,y:795,t:1527876897114};\\\", \\\"{x:1399,y:799,t:1527876897131};\\\", \\\"{x:1397,y:802,t:1527876897148};\\\", \\\"{x:1387,y:804,t:1527876897165};\\\", \\\"{x:1377,y:806,t:1527876897181};\\\", \\\"{x:1368,y:812,t:1527876897197};\\\", \\\"{x:1358,y:823,t:1527876897215};\\\", \\\"{x:1349,y:831,t:1527876897232};\\\", \\\"{x:1347,y:833,t:1527876897248};\\\", \\\"{x:1344,y:835,t:1527876897265};\\\", \\\"{x:1344,y:836,t:1527876897315};\\\", \\\"{x:1344,y:838,t:1527876897332};\\\", \\\"{x:1343,y:840,t:1527876897348};\\\", \\\"{x:1342,y:841,t:1527876897365};\\\", \\\"{x:1338,y:841,t:1527876897383};\\\", \\\"{x:1335,y:842,t:1527876897398};\\\", \\\"{x:1334,y:843,t:1527876897415};\\\", \\\"{x:1334,y:844,t:1527876897443};\\\", \\\"{x:1335,y:845,t:1527876897467};\\\", \\\"{x:1337,y:845,t:1527876897482};\\\", \\\"{x:1338,y:845,t:1527876897498};\\\", \\\"{x:1343,y:845,t:1527876897515};\\\", \\\"{x:1344,y:845,t:1527876897532};\\\", \\\"{x:1348,y:845,t:1527876897549};\\\", \\\"{x:1356,y:845,t:1527876897565};\\\", \\\"{x:1362,y:845,t:1527876897582};\\\", \\\"{x:1367,y:845,t:1527876897599};\\\", \\\"{x:1373,y:844,t:1527876897615};\\\", \\\"{x:1377,y:844,t:1527876897632};\\\", \\\"{x:1382,y:840,t:1527876897650};\\\", \\\"{x:1385,y:839,t:1527876897665};\\\", \\\"{x:1390,y:836,t:1527876897683};\\\", \\\"{x:1403,y:830,t:1527876897699};\\\", \\\"{x:1414,y:822,t:1527876897716};\\\", \\\"{x:1428,y:816,t:1527876897732};\\\", \\\"{x:1443,y:811,t:1527876897750};\\\", \\\"{x:1451,y:811,t:1527876897766};\\\", \\\"{x:1455,y:810,t:1527876897783};\\\", \\\"{x:1456,y:810,t:1527876897803};\\\", \\\"{x:1457,y:810,t:1527876897815};\\\", \\\"{x:1463,y:810,t:1527876897832};\\\", \\\"{x:1471,y:807,t:1527876897849};\\\", \\\"{x:1479,y:806,t:1527876897865};\\\", \\\"{x:1482,y:805,t:1527876897882};\\\", \\\"{x:1485,y:805,t:1527876897899};\\\", \\\"{x:1487,y:805,t:1527876897916};\\\", \\\"{x:1488,y:805,t:1527876897933};\\\", \\\"{x:1490,y:807,t:1527876897949};\\\", \\\"{x:1490,y:811,t:1527876897966};\\\", \\\"{x:1491,y:823,t:1527876897983};\\\", \\\"{x:1493,y:837,t:1527876897999};\\\", \\\"{x:1493,y:845,t:1527876898015};\\\", \\\"{x:1493,y:847,t:1527876898032};\\\", \\\"{x:1494,y:847,t:1527876898196};\\\", \\\"{x:1494,y:846,t:1527876898339};\\\", \\\"{x:1492,y:846,t:1527876898355};\\\", \\\"{x:1491,y:846,t:1527876898366};\\\", \\\"{x:1489,y:846,t:1527876898383};\\\", \\\"{x:1488,y:846,t:1527876898399};\\\", \\\"{x:1487,y:845,t:1527876898684};\\\", \\\"{x:1487,y:844,t:1527876898700};\\\", \\\"{x:1487,y:843,t:1527876898739};\\\", \\\"{x:1486,y:841,t:1527876898900};\\\", \\\"{x:1486,y:840,t:1527876898917};\\\", \\\"{x:1482,y:838,t:1527876898933};\\\", \\\"{x:1478,y:836,t:1527876898951};\\\", \\\"{x:1476,y:834,t:1527876898967};\\\", \\\"{x:1474,y:833,t:1527876898984};\\\", \\\"{x:1472,y:832,t:1527876899000};\\\", \\\"{x:1472,y:831,t:1527876899017};\\\", \\\"{x:1472,y:830,t:1527876899043};\\\", \\\"{x:1472,y:829,t:1527876899083};\\\", \\\"{x:1472,y:828,t:1527876899187};\\\", \\\"{x:1472,y:827,t:1527876899211};\\\", \\\"{x:1472,y:826,t:1527876899219};\\\", \\\"{x:1472,y:824,t:1527876899235};\\\", \\\"{x:1473,y:821,t:1527876899251};\\\", \\\"{x:1474,y:819,t:1527876899267};\\\", \\\"{x:1478,y:813,t:1527876899284};\\\", \\\"{x:1483,y:807,t:1527876899301};\\\", \\\"{x:1488,y:804,t:1527876899318};\\\", \\\"{x:1493,y:801,t:1527876899334};\\\", \\\"{x:1498,y:796,t:1527876899350};\\\", \\\"{x:1500,y:792,t:1527876899367};\\\", \\\"{x:1502,y:789,t:1527876899384};\\\", \\\"{x:1503,y:788,t:1527876899400};\\\", \\\"{x:1505,y:786,t:1527876899417};\\\", \\\"{x:1506,y:784,t:1527876899433};\\\", \\\"{x:1509,y:781,t:1527876899450};\\\", \\\"{x:1512,y:777,t:1527876899468};\\\", \\\"{x:1514,y:774,t:1527876899483};\\\", \\\"{x:1514,y:773,t:1527876899501};\\\", \\\"{x:1515,y:771,t:1527876899517};\\\", \\\"{x:1516,y:770,t:1527876899533};\\\", \\\"{x:1516,y:769,t:1527876899563};\\\", \\\"{x:1516,y:768,t:1527876899596};\\\", \\\"{x:1517,y:766,t:1527876899643};\\\", \\\"{x:1517,y:765,t:1527876899659};\\\", \\\"{x:1518,y:765,t:1527876899683};\\\", \\\"{x:1518,y:763,t:1527876899788};\\\", \\\"{x:1517,y:763,t:1527876900195};\\\", \\\"{x:1515,y:765,t:1527876900251};\\\", \\\"{x:1515,y:766,t:1527876900283};\\\", \\\"{x:1515,y:767,t:1527876901907};\\\", \\\"{x:1515,y:768,t:1527876902108};\\\", \\\"{x:1514,y:770,t:1527876902121};\\\", \\\"{x:1513,y:773,t:1527876902136};\\\", \\\"{x:1511,y:777,t:1527876902152};\\\", \\\"{x:1511,y:781,t:1527876902169};\\\", \\\"{x:1508,y:791,t:1527876902187};\\\", \\\"{x:1507,y:792,t:1527876902202};\\\", \\\"{x:1505,y:803,t:1527876902219};\\\", \\\"{x:1502,y:809,t:1527876902236};\\\", \\\"{x:1501,y:814,t:1527876902252};\\\", \\\"{x:1499,y:820,t:1527876902269};\\\", \\\"{x:1497,y:826,t:1527876902290};\\\", \\\"{x:1494,y:832,t:1527876902306};\\\", \\\"{x:1494,y:837,t:1527876902323};\\\", \\\"{x:1493,y:839,t:1527876902340};\\\", \\\"{x:1492,y:840,t:1527876902356};\\\", \\\"{x:1491,y:842,t:1527876902376};\\\", \\\"{x:1490,y:842,t:1527876902400};\\\", \\\"{x:1490,y:843,t:1527876902407};\\\", \\\"{x:1490,y:844,t:1527876902424};\\\", \\\"{x:1490,y:842,t:1527876902568};\\\", \\\"{x:1490,y:840,t:1527876902575};\\\", \\\"{x:1490,y:838,t:1527876902591};\\\", \\\"{x:1490,y:828,t:1527876902607};\\\", \\\"{x:1490,y:823,t:1527876902624};\\\", \\\"{x:1490,y:819,t:1527876902640};\\\", \\\"{x:1490,y:817,t:1527876902657};\\\", \\\"{x:1489,y:816,t:1527876902799};\\\", \\\"{x:1488,y:816,t:1527876902823};\\\", \\\"{x:1487,y:816,t:1527876902864};\\\", \\\"{x:1485,y:817,t:1527876902887};\\\", \\\"{x:1485,y:818,t:1527876902904};\\\", \\\"{x:1484,y:819,t:1527876902911};\\\", \\\"{x:1484,y:820,t:1527876902925};\\\", \\\"{x:1480,y:824,t:1527876902941};\\\", \\\"{x:1474,y:829,t:1527876902959};\\\", \\\"{x:1463,y:834,t:1527876902975};\\\", \\\"{x:1447,y:839,t:1527876902991};\\\", \\\"{x:1399,y:842,t:1527876903008};\\\", \\\"{x:1343,y:842,t:1527876903025};\\\", \\\"{x:1266,y:838,t:1527876903040};\\\", \\\"{x:1190,y:822,t:1527876903058};\\\", \\\"{x:1107,y:810,t:1527876903075};\\\", \\\"{x:1021,y:785,t:1527876903090};\\\", \\\"{x:938,y:765,t:1527876903108};\\\", \\\"{x:886,y:744,t:1527876903125};\\\", \\\"{x:853,y:729,t:1527876903141};\\\", \\\"{x:835,y:721,t:1527876903158};\\\", \\\"{x:828,y:716,t:1527876903175};\\\", \\\"{x:824,y:709,t:1527876903191};\\\", \\\"{x:815,y:690,t:1527876903207};\\\", \\\"{x:803,y:678,t:1527876903225};\\\", \\\"{x:783,y:667,t:1527876903241};\\\", \\\"{x:769,y:652,t:1527876903257};\\\", \\\"{x:755,y:641,t:1527876903275};\\\", \\\"{x:740,y:629,t:1527876903292};\\\", \\\"{x:733,y:618,t:1527876903308};\\\", \\\"{x:730,y:610,t:1527876903324};\\\", \\\"{x:730,y:602,t:1527876903341};\\\", \\\"{x:730,y:589,t:1527876903366};\\\", \\\"{x:736,y:583,t:1527876903382};\\\", \\\"{x:750,y:579,t:1527876903406};\\\", \\\"{x:754,y:577,t:1527876903422};\\\", \\\"{x:770,y:577,t:1527876903439};\\\", \\\"{x:779,y:577,t:1527876903455};\\\", \\\"{x:785,y:577,t:1527876903472};\\\", \\\"{x:787,y:577,t:1527876903489};\\\", \\\"{x:788,y:577,t:1527876903506};\\\", \\\"{x:790,y:577,t:1527876903522};\\\", \\\"{x:791,y:578,t:1527876903543};\\\", \\\"{x:792,y:578,t:1527876903556};\\\", \\\"{x:793,y:578,t:1527876903582};\\\", \\\"{x:795,y:578,t:1527876903591};\\\", \\\"{x:795,y:579,t:1527876903606};\\\", \\\"{x:804,y:579,t:1527876903623};\\\", \\\"{x:811,y:580,t:1527876903639};\\\", \\\"{x:818,y:580,t:1527876903657};\\\", \\\"{x:830,y:581,t:1527876903674};\\\", \\\"{x:836,y:581,t:1527876903689};\\\", \\\"{x:838,y:581,t:1527876903706};\\\", \\\"{x:836,y:581,t:1527876904047};\\\", \\\"{x:835,y:581,t:1527876904056};\\\", \\\"{x:832,y:583,t:1527876904073};\\\", \\\"{x:828,y:584,t:1527876904090};\\\", \\\"{x:821,y:587,t:1527876904107};\\\", \\\"{x:816,y:591,t:1527876904123};\\\", \\\"{x:808,y:595,t:1527876904141};\\\", \\\"{x:793,y:601,t:1527876904157};\\\", \\\"{x:781,y:606,t:1527876904173};\\\", \\\"{x:763,y:611,t:1527876904190};\\\", \\\"{x:746,y:616,t:1527876904207};\\\", \\\"{x:731,y:617,t:1527876904223};\\\", \\\"{x:725,y:617,t:1527876904240};\\\", \\\"{x:721,y:617,t:1527876904257};\\\", \\\"{x:717,y:617,t:1527876904273};\\\", \\\"{x:708,y:617,t:1527876904290};\\\", \\\"{x:697,y:615,t:1527876904306};\\\", \\\"{x:682,y:613,t:1527876904323};\\\", \\\"{x:667,y:610,t:1527876904340};\\\", \\\"{x:654,y:607,t:1527876904356};\\\", \\\"{x:645,y:602,t:1527876904373};\\\", \\\"{x:640,y:599,t:1527876904391};\\\", \\\"{x:636,y:597,t:1527876904406};\\\", \\\"{x:634,y:595,t:1527876904423};\\\", \\\"{x:633,y:595,t:1527876904512};\\\", \\\"{x:632,y:595,t:1527876904527};\\\", \\\"{x:632,y:594,t:1527876904543};\\\", \\\"{x:631,y:594,t:1527876904887};\\\", \\\"{x:630,y:594,t:1527876904903};\\\", \\\"{x:629,y:593,t:1527876904911};\\\", \\\"{x:628,y:591,t:1527876904923};\\\", \\\"{x:625,y:590,t:1527876904940};\\\", \\\"{x:623,y:589,t:1527876904957};\\\", \\\"{x:621,y:587,t:1527876904974};\\\", \\\"{x:620,y:587,t:1527876905046};\\\", \\\"{x:618,y:587,t:1527876905632};\\\", \\\"{x:619,y:587,t:1527876905680};\\\", \\\"{x:621,y:587,t:1527876905692};\\\", \\\"{x:628,y:588,t:1527876905709};\\\", \\\"{x:635,y:589,t:1527876905724};\\\", \\\"{x:649,y:591,t:1527876905741};\\\", \\\"{x:667,y:594,t:1527876905758};\\\", \\\"{x:701,y:595,t:1527876905774};\\\", \\\"{x:728,y:600,t:1527876905791};\\\", \\\"{x:748,y:602,t:1527876905807};\\\", \\\"{x:794,y:609,t:1527876905824};\\\", \\\"{x:851,y:622,t:1527876905841};\\\", \\\"{x:908,y:632,t:1527876905858};\\\", \\\"{x:973,y:645,t:1527876905874};\\\", \\\"{x:1038,y:666,t:1527876905892};\\\", \\\"{x:1100,y:689,t:1527876905908};\\\", \\\"{x:1155,y:702,t:1527876905924};\\\", \\\"{x:1214,y:722,t:1527876905941};\\\", \\\"{x:1300,y:752,t:1527876905958};\\\", \\\"{x:1315,y:764,t:1527876905975};\\\", \\\"{x:1366,y:785,t:1527876905991};\\\", \\\"{x:1372,y:788,t:1527876906009};\\\", \\\"{x:1378,y:791,t:1527876906439};\\\", \\\"{x:1398,y:796,t:1527876906447};\\\", \\\"{x:1416,y:797,t:1527876906459};\\\", \\\"{x:1468,y:808,t:1527876906476};\\\", \\\"{x:1514,y:817,t:1527876906492};\\\", \\\"{x:1540,y:819,t:1527876906509};\\\", \\\"{x:1564,y:823,t:1527876906526};\\\", \\\"{x:1590,y:828,t:1527876906542};\\\", \\\"{x:1636,y:836,t:1527876906559};\\\", \\\"{x:1700,y:846,t:1527876906575};\\\", \\\"{x:1728,y:854,t:1527876906591};\\\", \\\"{x:1752,y:861,t:1527876906608};\\\", \\\"{x:1771,y:867,t:1527876906625};\\\", \\\"{x:1778,y:868,t:1527876906641};\\\", \\\"{x:1781,y:870,t:1527876906659};\\\", \\\"{x:1782,y:870,t:1527876906703};\\\", \\\"{x:1782,y:869,t:1527876906711};\\\", \\\"{x:1779,y:867,t:1527876906726};\\\", \\\"{x:1778,y:867,t:1527876906767};\\\", \\\"{x:1775,y:865,t:1527876906790};\\\", \\\"{x:1771,y:864,t:1527876906799};\\\", \\\"{x:1768,y:862,t:1527876906808};\\\", \\\"{x:1755,y:857,t:1527876906826};\\\", \\\"{x:1743,y:852,t:1527876906842};\\\", \\\"{x:1725,y:846,t:1527876906859};\\\", \\\"{x:1701,y:840,t:1527876906876};\\\", \\\"{x:1679,y:835,t:1527876906893};\\\", \\\"{x:1667,y:834,t:1527876906909};\\\", \\\"{x:1662,y:833,t:1527876906925};\\\", \\\"{x:1658,y:833,t:1527876906942};\\\", \\\"{x:1659,y:833,t:1527876907152};\\\", \\\"{x:1660,y:833,t:1527876907159};\\\", \\\"{x:1662,y:833,t:1527876907175};\\\", \\\"{x:1664,y:833,t:1527876907193};\\\", \\\"{x:1665,y:833,t:1527876907209};\\\", \\\"{x:1667,y:833,t:1527876907239};\\\", \\\"{x:1668,y:833,t:1527876907255};\\\", \\\"{x:1670,y:833,t:1527876907263};\\\", \\\"{x:1672,y:833,t:1527876907286};\\\", \\\"{x:1673,y:833,t:1527876907311};\\\", \\\"{x:1674,y:833,t:1527876907375};\\\", \\\"{x:1675,y:832,t:1527876907728};\\\", \\\"{x:1676,y:832,t:1527876907752};\\\", \\\"{x:1677,y:831,t:1527876907777};\\\", \\\"{x:1679,y:831,t:1527876907912};\\\", \\\"{x:1681,y:831,t:1527876907927};\\\", \\\"{x:1682,y:831,t:1527876907976};\\\", \\\"{x:1683,y:830,t:1527876907983};\\\", \\\"{x:1684,y:829,t:1527876907999};\\\", \\\"{x:1685,y:829,t:1527876908039};\\\", \\\"{x:1688,y:829,t:1527876908232};\\\", \\\"{x:1691,y:829,t:1527876908244};\\\", \\\"{x:1704,y:829,t:1527876908260};\\\", \\\"{x:1720,y:829,t:1527876908277};\\\", \\\"{x:1735,y:829,t:1527876908294};\\\", \\\"{x:1756,y:829,t:1527876908309};\\\", \\\"{x:1782,y:829,t:1527876908327};\\\", \\\"{x:1792,y:829,t:1527876908343};\\\", \\\"{x:1794,y:829,t:1527876908360};\\\", \\\"{x:1795,y:829,t:1527876908377};\\\", \\\"{x:1795,y:828,t:1527876908408};\\\", \\\"{x:1794,y:827,t:1527876908440};\\\", \\\"{x:1792,y:826,t:1527876908447};\\\", \\\"{x:1791,y:826,t:1527876908460};\\\", \\\"{x:1784,y:826,t:1527876908477};\\\", \\\"{x:1775,y:826,t:1527876908494};\\\", \\\"{x:1764,y:826,t:1527876908511};\\\", \\\"{x:1761,y:826,t:1527876908527};\\\", \\\"{x:1759,y:825,t:1527876908567};\\\", \\\"{x:1757,y:825,t:1527876908584};\\\", \\\"{x:1754,y:825,t:1527876908599};\\\", \\\"{x:1753,y:825,t:1527876908611};\\\", \\\"{x:1747,y:825,t:1527876908627};\\\", \\\"{x:1739,y:828,t:1527876908645};\\\", \\\"{x:1732,y:829,t:1527876908661};\\\", \\\"{x:1724,y:829,t:1527876908677};\\\", \\\"{x:1716,y:830,t:1527876908694};\\\", \\\"{x:1707,y:832,t:1527876908712};\\\", \\\"{x:1704,y:832,t:1527876908727};\\\", \\\"{x:1699,y:832,t:1527876908744};\\\", \\\"{x:1696,y:831,t:1527876908761};\\\", \\\"{x:1684,y:829,t:1527876908778};\\\", \\\"{x:1674,y:827,t:1527876908795};\\\", \\\"{x:1669,y:825,t:1527876908811};\\\", \\\"{x:1664,y:822,t:1527876908827};\\\", \\\"{x:1658,y:813,t:1527876908844};\\\", \\\"{x:1651,y:802,t:1527876908861};\\\", \\\"{x:1646,y:791,t:1527876908877};\\\", \\\"{x:1641,y:780,t:1527876908894};\\\", \\\"{x:1635,y:742,t:1527876908912};\\\", \\\"{x:1628,y:718,t:1527876908927};\\\", \\\"{x:1626,y:703,t:1527876908944};\\\", \\\"{x:1625,y:693,t:1527876908961};\\\", \\\"{x:1621,y:682,t:1527876908979};\\\", \\\"{x:1620,y:680,t:1527876908995};\\\", \\\"{x:1620,y:679,t:1527876909080};\\\", \\\"{x:1618,y:679,t:1527876909159};\\\", \\\"{x:1615,y:680,t:1527876909179};\\\", \\\"{x:1609,y:689,t:1527876909195};\\\", \\\"{x:1600,y:701,t:1527876909211};\\\", \\\"{x:1594,y:708,t:1527876909228};\\\", \\\"{x:1589,y:713,t:1527876909244};\\\", \\\"{x:1586,y:716,t:1527876909261};\\\", \\\"{x:1583,y:719,t:1527876909278};\\\", \\\"{x:1580,y:724,t:1527876909294};\\\", \\\"{x:1576,y:728,t:1527876909311};\\\", \\\"{x:1573,y:731,t:1527876909328};\\\", \\\"{x:1568,y:736,t:1527876909344};\\\", \\\"{x:1566,y:739,t:1527876909361};\\\", \\\"{x:1563,y:741,t:1527876909378};\\\", \\\"{x:1561,y:743,t:1527876909394};\\\", \\\"{x:1562,y:742,t:1527876909519};\\\", \\\"{x:1565,y:740,t:1527876909527};\\\", \\\"{x:1572,y:734,t:1527876909544};\\\", \\\"{x:1576,y:728,t:1527876909561};\\\", \\\"{x:1580,y:721,t:1527876909577};\\\", \\\"{x:1582,y:719,t:1527876909594};\\\", \\\"{x:1582,y:718,t:1527876909610};\\\", \\\"{x:1582,y:717,t:1527876909655};\\\", \\\"{x:1583,y:717,t:1527876909663};\\\", \\\"{x:1583,y:715,t:1527876909678};\\\", \\\"{x:1585,y:713,t:1527876909694};\\\", \\\"{x:1585,y:712,t:1527876909711};\\\", \\\"{x:1586,y:711,t:1527876909727};\\\", \\\"{x:1587,y:708,t:1527876909745};\\\", \\\"{x:1587,y:707,t:1527876909768};\\\", \\\"{x:1587,y:706,t:1527876909778};\\\", \\\"{x:1588,y:705,t:1527876909795};\\\", \\\"{x:1589,y:704,t:1527876910008};\\\", \\\"{x:1589,y:703,t:1527876910031};\\\", \\\"{x:1590,y:702,t:1527876910104};\\\", \\\"{x:1591,y:701,t:1527876910128};\\\", \\\"{x:1592,y:700,t:1527876910145};\\\", \\\"{x:1592,y:698,t:1527876910162};\\\", \\\"{x:1593,y:698,t:1527876910178};\\\", \\\"{x:1593,y:697,t:1527876910195};\\\", \\\"{x:1595,y:696,t:1527876910212};\\\", \\\"{x:1596,y:695,t:1527876910240};\\\", \\\"{x:1597,y:695,t:1527876910320};\\\", \\\"{x:1598,y:694,t:1527876910329};\\\", \\\"{x:1598,y:693,t:1527876910399};\\\", \\\"{x:1601,y:692,t:1527876910412};\\\", \\\"{x:1605,y:689,t:1527876910429};\\\", \\\"{x:1607,y:689,t:1527876910560};\\\", \\\"{x:1608,y:689,t:1527876910576};\\\", \\\"{x:1609,y:689,t:1527876910608};\\\", \\\"{x:1610,y:690,t:1527876910704};\\\", \\\"{x:1611,y:691,t:1527876910736};\\\", \\\"{x:1611,y:692,t:1527876910809};\\\", \\\"{x:1612,y:694,t:1527876910829};\\\", \\\"{x:1612,y:696,t:1527876910846};\\\", \\\"{x:1613,y:698,t:1527876910920};\\\", \\\"{x:1614,y:698,t:1527876910935};\\\", \\\"{x:1615,y:699,t:1527876911288};\\\", \\\"{x:1614,y:702,t:1527876911303};\\\", \\\"{x:1614,y:705,t:1527876911320};\\\", \\\"{x:1613,y:706,t:1527876911329};\\\", \\\"{x:1609,y:714,t:1527876911346};\\\", \\\"{x:1606,y:719,t:1527876911363};\\\", \\\"{x:1600,y:728,t:1527876911379};\\\", \\\"{x:1599,y:731,t:1527876911396};\\\", \\\"{x:1595,y:740,t:1527876911413};\\\", \\\"{x:1588,y:752,t:1527876911430};\\\", \\\"{x:1580,y:762,t:1527876911446};\\\", \\\"{x:1568,y:770,t:1527876911464};\\\", \\\"{x:1562,y:775,t:1527876911479};\\\", \\\"{x:1556,y:779,t:1527876911496};\\\", \\\"{x:1553,y:779,t:1527876911513};\\\", \\\"{x:1551,y:781,t:1527876911529};\\\", \\\"{x:1548,y:782,t:1527876911547};\\\", \\\"{x:1546,y:782,t:1527876911565};\\\", \\\"{x:1545,y:782,t:1527876911583};\\\", \\\"{x:1544,y:782,t:1527876911596};\\\", \\\"{x:1542,y:782,t:1527876911614};\\\", \\\"{x:1541,y:782,t:1527876911630};\\\", \\\"{x:1540,y:782,t:1527876911646};\\\", \\\"{x:1536,y:782,t:1527876911664};\\\", \\\"{x:1529,y:781,t:1527876911679};\\\", \\\"{x:1524,y:780,t:1527876911695};\\\", \\\"{x:1523,y:779,t:1527876911712};\\\", \\\"{x:1522,y:779,t:1527876911729};\\\", \\\"{x:1522,y:778,t:1527876911745};\\\", \\\"{x:1522,y:777,t:1527876911763};\\\", \\\"{x:1521,y:774,t:1527876911779};\\\", \\\"{x:1521,y:772,t:1527876911796};\\\", \\\"{x:1521,y:771,t:1527876911813};\\\", \\\"{x:1520,y:770,t:1527876911839};\\\", \\\"{x:1520,y:769,t:1527876911911};\\\", \\\"{x:1520,y:768,t:1527876911936};\\\", \\\"{x:1520,y:767,t:1527876912016};\\\", \\\"{x:1519,y:767,t:1527876912030};\\\", \\\"{x:1513,y:767,t:1527876912048};\\\", \\\"{x:1504,y:767,t:1527876912064};\\\", \\\"{x:1493,y:767,t:1527876912080};\\\", \\\"{x:1487,y:767,t:1527876912097};\\\", \\\"{x:1484,y:767,t:1527876912113};\\\", \\\"{x:1482,y:767,t:1527876912130};\\\", \\\"{x:1479,y:767,t:1527876912148};\\\", \\\"{x:1477,y:767,t:1527876912165};\\\", \\\"{x:1474,y:767,t:1527876912180};\\\", \\\"{x:1473,y:768,t:1527876912197};\\\", \\\"{x:1475,y:768,t:1527876912336};\\\", \\\"{x:1476,y:768,t:1527876912348};\\\", \\\"{x:1480,y:768,t:1527876912365};\\\", \\\"{x:1481,y:769,t:1527876912380};\\\", \\\"{x:1481,y:773,t:1527876912397};\\\", \\\"{x:1482,y:777,t:1527876912413};\\\", \\\"{x:1483,y:782,t:1527876912430};\\\", \\\"{x:1483,y:787,t:1527876912447};\\\", \\\"{x:1482,y:792,t:1527876912464};\\\", \\\"{x:1482,y:796,t:1527876912480};\\\", \\\"{x:1478,y:800,t:1527876912498};\\\", \\\"{x:1476,y:804,t:1527876912515};\\\", \\\"{x:1472,y:805,t:1527876912530};\\\", \\\"{x:1466,y:808,t:1527876912547};\\\", \\\"{x:1455,y:811,t:1527876912565};\\\", \\\"{x:1441,y:819,t:1527876912580};\\\", \\\"{x:1439,y:824,t:1527876912598};\\\", \\\"{x:1434,y:826,t:1527876912614};\\\", \\\"{x:1431,y:827,t:1527876912630};\\\", \\\"{x:1428,y:827,t:1527876912646};\\\", \\\"{x:1427,y:827,t:1527876912663};\\\", \\\"{x:1426,y:827,t:1527876912702};\\\", \\\"{x:1425,y:827,t:1527876912714};\\\", \\\"{x:1420,y:830,t:1527876912729};\\\", \\\"{x:1417,y:831,t:1527876912746};\\\", \\\"{x:1415,y:833,t:1527876912764};\\\", \\\"{x:1413,y:836,t:1527876912780};\\\", \\\"{x:1408,y:839,t:1527876912797};\\\", \\\"{x:1405,y:843,t:1527876912814};\\\", \\\"{x:1404,y:844,t:1527876912830};\\\", \\\"{x:1401,y:849,t:1527876912846};\\\", \\\"{x:1400,y:849,t:1527876912870};\\\", \\\"{x:1400,y:851,t:1527876912887};\\\", \\\"{x:1399,y:852,t:1527876912927};\\\", \\\"{x:1399,y:853,t:1527876913023};\\\", \\\"{x:1399,y:855,t:1527876913039};\\\", \\\"{x:1399,y:856,t:1527876913055};\\\", \\\"{x:1399,y:857,t:1527876913064};\\\", \\\"{x:1399,y:860,t:1527876913081};\\\", \\\"{x:1399,y:865,t:1527876913098};\\\", \\\"{x:1397,y:871,t:1527876913115};\\\", \\\"{x:1393,y:877,t:1527876913132};\\\", \\\"{x:1390,y:882,t:1527876913147};\\\", \\\"{x:1387,y:889,t:1527876913164};\\\", \\\"{x:1385,y:892,t:1527876913181};\\\", \\\"{x:1384,y:895,t:1527876913197};\\\", \\\"{x:1382,y:898,t:1527876913214};\\\", \\\"{x:1381,y:899,t:1527876913271};\\\", \\\"{x:1379,y:899,t:1527876913287};\\\", \\\"{x:1379,y:898,t:1527876913439};\\\", \\\"{x:1379,y:896,t:1527876913447};\\\", \\\"{x:1379,y:891,t:1527876913465};\\\", \\\"{x:1382,y:879,t:1527876913481};\\\", \\\"{x:1386,y:865,t:1527876913498};\\\", \\\"{x:1390,y:852,t:1527876913514};\\\", \\\"{x:1393,y:840,t:1527876913530};\\\", \\\"{x:1395,y:829,t:1527876913548};\\\", \\\"{x:1395,y:823,t:1527876913564};\\\", \\\"{x:1394,y:819,t:1527876913581};\\\", \\\"{x:1391,y:814,t:1527876913597};\\\", \\\"{x:1389,y:811,t:1527876913614};\\\", \\\"{x:1387,y:809,t:1527876913631};\\\", \\\"{x:1384,y:804,t:1527876913648};\\\", \\\"{x:1380,y:801,t:1527876913664};\\\", \\\"{x:1377,y:799,t:1527876913681};\\\", \\\"{x:1375,y:797,t:1527876913698};\\\", \\\"{x:1374,y:797,t:1527876913719};\\\", \\\"{x:1374,y:796,t:1527876913731};\\\", \\\"{x:1370,y:792,t:1527876913748};\\\", \\\"{x:1365,y:786,t:1527876913766};\\\", \\\"{x:1355,y:782,t:1527876913781};\\\", \\\"{x:1352,y:779,t:1527876913798};\\\", \\\"{x:1348,y:776,t:1527876913815};\\\", \\\"{x:1348,y:775,t:1527876913831};\\\", \\\"{x:1348,y:771,t:1527876913848};\\\", \\\"{x:1347,y:769,t:1527876913865};\\\", \\\"{x:1346,y:767,t:1527876913882};\\\", \\\"{x:1346,y:766,t:1527876913943};\\\", \\\"{x:1346,y:765,t:1527876913951};\\\", \\\"{x:1346,y:764,t:1527876913967};\\\", \\\"{x:1346,y:763,t:1527876914080};\\\", \\\"{x:1347,y:763,t:1527876914118};\\\", \\\"{x:1347,y:761,t:1527876914343};\\\", \\\"{x:1347,y:758,t:1527876914351};\\\", \\\"{x:1347,y:756,t:1527876914365};\\\", \\\"{x:1349,y:750,t:1527876914382};\\\", \\\"{x:1350,y:744,t:1527876914398};\\\", \\\"{x:1351,y:734,t:1527876914415};\\\", \\\"{x:1353,y:724,t:1527876914432};\\\", \\\"{x:1353,y:722,t:1527876914448};\\\", \\\"{x:1353,y:721,t:1527876914465};\\\", \\\"{x:1353,y:720,t:1527876914482};\\\", \\\"{x:1354,y:718,t:1527876914498};\\\", \\\"{x:1354,y:715,t:1527876914515};\\\", \\\"{x:1355,y:709,t:1527876914532};\\\", \\\"{x:1357,y:703,t:1527876914548};\\\", \\\"{x:1357,y:699,t:1527876914565};\\\", \\\"{x:1358,y:696,t:1527876914582};\\\", \\\"{x:1359,y:694,t:1527876914599};\\\", \\\"{x:1359,y:693,t:1527876914615};\\\", \\\"{x:1359,y:692,t:1527876914792};\\\", \\\"{x:1358,y:692,t:1527876914799};\\\", \\\"{x:1356,y:693,t:1527876914815};\\\", \\\"{x:1355,y:694,t:1527876914832};\\\", \\\"{x:1354,y:694,t:1527876915270};\\\", \\\"{x:1353,y:695,t:1527876915282};\\\", \\\"{x:1351,y:696,t:1527876915298};\\\", \\\"{x:1351,y:698,t:1527876915319};\\\", \\\"{x:1350,y:698,t:1527876915342};\\\", \\\"{x:1349,y:699,t:1527876915350};\\\", \\\"{x:1347,y:700,t:1527876915366};\\\", \\\"{x:1345,y:701,t:1527876915382};\\\", \\\"{x:1343,y:703,t:1527876915399};\\\", \\\"{x:1343,y:704,t:1527876915416};\\\", \\\"{x:1342,y:704,t:1527876915432};\\\", \\\"{x:1340,y:705,t:1527876915449};\\\", \\\"{x:1339,y:708,t:1527876915466};\\\", \\\"{x:1336,y:712,t:1527876915482};\\\", \\\"{x:1333,y:715,t:1527876915498};\\\", \\\"{x:1331,y:716,t:1527876915516};\\\", \\\"{x:1329,y:719,t:1527876915532};\\\", \\\"{x:1326,y:722,t:1527876915549};\\\", \\\"{x:1324,y:724,t:1527876915566};\\\", \\\"{x:1319,y:729,t:1527876915583};\\\", \\\"{x:1315,y:734,t:1527876915599};\\\", \\\"{x:1311,y:739,t:1527876915616};\\\", \\\"{x:1300,y:750,t:1527876915633};\\\", \\\"{x:1287,y:764,t:1527876915649};\\\", \\\"{x:1282,y:774,t:1527876915666};\\\", \\\"{x:1271,y:785,t:1527876915683};\\\", \\\"{x:1260,y:797,t:1527876915698};\\\", \\\"{x:1246,y:810,t:1527876915716};\\\", \\\"{x:1233,y:820,t:1527876915733};\\\", \\\"{x:1221,y:830,t:1527876915749};\\\", \\\"{x:1214,y:837,t:1527876915766};\\\", \\\"{x:1211,y:839,t:1527876915783};\\\", \\\"{x:1210,y:840,t:1527876915799};\\\", \\\"{x:1208,y:842,t:1527876915817};\\\", \\\"{x:1206,y:842,t:1527876915833};\\\", \\\"{x:1205,y:843,t:1527876915849};\\\", \\\"{x:1204,y:843,t:1527876915866};\\\", \\\"{x:1202,y:843,t:1527876915887};\\\", \\\"{x:1201,y:843,t:1527876915899};\\\", \\\"{x:1198,y:843,t:1527876915916};\\\", \\\"{x:1191,y:843,t:1527876915933};\\\", \\\"{x:1177,y:836,t:1527876915950};\\\", \\\"{x:1160,y:829,t:1527876915967};\\\", \\\"{x:1125,y:814,t:1527876915983};\\\", \\\"{x:1100,y:806,t:1527876915999};\\\", \\\"{x:1073,y:794,t:1527876916017};\\\", \\\"{x:1047,y:786,t:1527876916033};\\\", \\\"{x:1019,y:776,t:1527876916050};\\\", \\\"{x:964,y:765,t:1527876916066};\\\", \\\"{x:920,y:753,t:1527876916083};\\\", \\\"{x:884,y:742,t:1527876916101};\\\", \\\"{x:856,y:736,t:1527876916116};\\\", \\\"{x:829,y:732,t:1527876916133};\\\", \\\"{x:803,y:731,t:1527876916150};\\\", \\\"{x:783,y:730,t:1527876916167};\\\", \\\"{x:745,y:733,t:1527876916183};\\\", \\\"{x:728,y:736,t:1527876916200};\\\", \\\"{x:713,y:741,t:1527876916216};\\\", \\\"{x:695,y:743,t:1527876916233};\\\", \\\"{x:673,y:745,t:1527876916250};\\\", \\\"{x:650,y:750,t:1527876916266};\\\", \\\"{x:626,y:753,t:1527876916283};\\\", \\\"{x:608,y:759,t:1527876916300};\\\", \\\"{x:594,y:761,t:1527876916316};\\\", \\\"{x:582,y:763,t:1527876916333};\\\", \\\"{x:569,y:764,t:1527876916350};\\\", \\\"{x:556,y:764,t:1527876916366};\\\", \\\"{x:544,y:764,t:1527876916383};\\\", \\\"{x:532,y:764,t:1527876916400};\\\", \\\"{x:523,y:764,t:1527876916416};\\\", \\\"{x:516,y:764,t:1527876916433};\\\", \\\"{x:515,y:764,t:1527876916450};\\\", \\\"{x:514,y:763,t:1527876916511};\\\", \\\"{x:513,y:761,t:1527876916535};\\\", \\\"{x:513,y:760,t:1527876916567};\\\", \\\"{x:513,y:757,t:1527876916584};\\\", \\\"{x:513,y:753,t:1527876916601};\\\", \\\"{x:513,y:750,t:1527876916616};\\\", \\\"{x:513,y:749,t:1527876916632};\\\", \\\"{x:513,y:748,t:1527876916831};\\\", \\\"{x:513,y:747,t:1527876916839};\\\", \\\"{x:513,y:746,t:1527876917495};\\\", \\\"{x:515,y:744,t:1527876917552};\\\", \\\"{x:516,y:744,t:1527876917591};\\\", \\\"{x:518,y:743,t:1527876917848};\\\", \\\"{x:519,y:742,t:1527876917879};\\\", \\\"{x:522,y:742,t:1527876917927};\\\", \\\"{x:523,y:741,t:1527876917935};\\\", \\\"{x:529,y:740,t:1527876917951};\\\", \\\"{x:535,y:738,t:1527876917968};\\\", \\\"{x:541,y:736,t:1527876917984};\\\", \\\"{x:549,y:735,t:1527876918014};\\\", \\\"{x:551,y:735,t:1527876918022};\\\", \\\"{x:553,y:734,t:1527876918038};\\\", \\\"{x:555,y:733,t:1527876918051};\\\", \\\"{x:558,y:733,t:1527876918068};\\\", \\\"{x:563,y:733,t:1527876918085};\\\", \\\"{x:571,y:732,t:1527876918100};\\\" ] }, { \\\"rt\\\": 71644, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 386889, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -X -X -B -X -J -J -G -G -B -B -G -C -C -G -10 AM-F -J -J -H \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:623,y:712,t:1527876918233};\\\", \\\"{x:632,y:705,t:1527876918257};\\\", \\\"{x:639,y:700,t:1527876918267};\\\", \\\"{x:648,y:694,t:1527876918285};\\\", \\\"{x:660,y:687,t:1527876918300};\\\", \\\"{x:670,y:680,t:1527876918318};\\\", \\\"{x:687,y:667,t:1527876918339};\\\", \\\"{x:690,y:665,t:1527876918351};\\\", \\\"{x:692,y:663,t:1527876918367};\\\", \\\"{x:692,y:662,t:1527876918385};\\\", \\\"{x:693,y:661,t:1527876918406};\\\", \\\"{x:694,y:660,t:1527876918422};\\\", \\\"{x:695,y:660,t:1527876918676};\\\", \\\"{x:696,y:660,t:1527876918685};\\\", \\\"{x:696,y:659,t:1527876918718};\\\", \\\"{x:703,y:657,t:1527876924152};\\\", \\\"{x:714,y:649,t:1527876924159};\\\", \\\"{x:729,y:643,t:1527876924172};\\\", \\\"{x:773,y:623,t:1527876924191};\\\", \\\"{x:852,y:619,t:1527876924206};\\\", \\\"{x:905,y:607,t:1527876924222};\\\", \\\"{x:924,y:586,t:1527876924254};\\\", \\\"{x:949,y:552,t:1527876924270};\\\", \\\"{x:994,y:492,t:1527876924290};\\\", \\\"{x:1018,y:451,t:1527876924306};\\\", \\\"{x:1031,y:430,t:1527876924322};\\\", \\\"{x:1034,y:425,t:1527876924339};\\\", \\\"{x:1035,y:424,t:1527876924356};\\\", \\\"{x:1036,y:422,t:1527876924373};\\\", \\\"{x:1046,y:416,t:1527876924390};\\\", \\\"{x:1049,y:414,t:1527876924406};\\\", \\\"{x:1051,y:414,t:1527876924423};\\\", \\\"{x:1052,y:413,t:1527876924440};\\\", \\\"{x:1057,y:413,t:1527876924457};\\\", \\\"{x:1074,y:415,t:1527876924473};\\\", \\\"{x:1123,y:431,t:1527876924490};\\\", \\\"{x:1173,y:446,t:1527876924507};\\\", \\\"{x:1189,y:453,t:1527876924523};\\\", \\\"{x:1196,y:457,t:1527876924540};\\\", \\\"{x:1202,y:462,t:1527876924557};\\\", \\\"{x:1206,y:466,t:1527876924575};\\\", \\\"{x:1206,y:467,t:1527876924631};\\\", \\\"{x:1207,y:467,t:1527876924663};\\\", \\\"{x:1208,y:467,t:1527876924679};\\\", \\\"{x:1208,y:468,t:1527876924703};\\\", \\\"{x:1208,y:471,t:1527876924711};\\\", \\\"{x:1208,y:475,t:1527876924725};\\\", \\\"{x:1208,y:481,t:1527876924742};\\\", \\\"{x:1208,y:486,t:1527876924759};\\\", \\\"{x:1208,y:493,t:1527876924776};\\\", \\\"{x:1209,y:496,t:1527876924792};\\\", \\\"{x:1210,y:497,t:1527876924809};\\\", \\\"{x:1211,y:497,t:1527876924936};\\\", \\\"{x:1212,y:500,t:1527876925079};\\\", \\\"{x:1212,y:504,t:1527876925093};\\\", \\\"{x:1210,y:515,t:1527876925109};\\\", \\\"{x:1201,y:533,t:1527876925127};\\\", \\\"{x:1198,y:538,t:1527876925143};\\\", \\\"{x:1193,y:546,t:1527876925160};\\\", \\\"{x:1188,y:551,t:1527876925177};\\\", \\\"{x:1182,y:562,t:1527876925194};\\\", \\\"{x:1178,y:570,t:1527876925210};\\\", \\\"{x:1178,y:571,t:1527876925227};\\\", \\\"{x:1179,y:574,t:1527876937248};\\\", \\\"{x:1200,y:582,t:1527876937261};\\\", \\\"{x:1234,y:595,t:1527876937278};\\\", \\\"{x:1252,y:601,t:1527876937294};\\\", \\\"{x:1266,y:605,t:1527876937311};\\\", \\\"{x:1274,y:610,t:1527876937327};\\\", \\\"{x:1275,y:611,t:1527876937344};\\\", \\\"{x:1276,y:611,t:1527876937361};\\\", \\\"{x:1278,y:613,t:1527876937383};\\\", \\\"{x:1281,y:616,t:1527876937394};\\\", \\\"{x:1288,y:625,t:1527876937412};\\\", \\\"{x:1300,y:632,t:1527876937428};\\\", \\\"{x:1318,y:639,t:1527876937445};\\\", \\\"{x:1345,y:651,t:1527876937462};\\\", \\\"{x:1373,y:665,t:1527876937478};\\\", \\\"{x:1397,y:676,t:1527876937495};\\\", \\\"{x:1414,y:687,t:1527876937511};\\\", \\\"{x:1419,y:696,t:1527876937529};\\\", \\\"{x:1420,y:707,t:1527876937545};\\\", \\\"{x:1418,y:719,t:1527876937562};\\\", \\\"{x:1412,y:734,t:1527876937579};\\\", \\\"{x:1410,y:739,t:1527876937596};\\\", \\\"{x:1409,y:742,t:1527876937611};\\\", \\\"{x:1408,y:744,t:1527876937628};\\\", \\\"{x:1404,y:749,t:1527876937644};\\\", \\\"{x:1400,y:756,t:1527876937661};\\\", \\\"{x:1394,y:761,t:1527876937678};\\\", \\\"{x:1384,y:766,t:1527876937694};\\\", \\\"{x:1377,y:770,t:1527876937711};\\\", \\\"{x:1373,y:771,t:1527876937729};\\\", \\\"{x:1369,y:772,t:1527876937745};\\\", \\\"{x:1368,y:772,t:1527876937762};\\\", \\\"{x:1367,y:772,t:1527876937798};\\\", \\\"{x:1366,y:772,t:1527876937839};\\\", \\\"{x:1365,y:772,t:1527876937847};\\\", \\\"{x:1362,y:772,t:1527876937861};\\\", \\\"{x:1358,y:772,t:1527876937879};\\\", \\\"{x:1356,y:772,t:1527876937896};\\\", \\\"{x:1355,y:772,t:1527876937959};\\\", \\\"{x:1352,y:770,t:1527876937975};\\\", \\\"{x:1351,y:769,t:1527876937991};\\\", \\\"{x:1351,y:768,t:1527876937999};\\\", \\\"{x:1351,y:767,t:1527876938083};\\\", \\\"{x:1350,y:767,t:1527876938117};\\\", \\\"{x:1349,y:767,t:1527876947775};\\\", \\\"{x:1348,y:767,t:1527876947786};\\\", \\\"{x:1345,y:767,t:1527876947803};\\\", \\\"{x:1344,y:768,t:1527876947822};\\\", \\\"{x:1343,y:768,t:1527876947837};\\\", \\\"{x:1342,y:769,t:1527876947854};\\\", \\\"{x:1341,y:770,t:1527876947878};\\\", \\\"{x:1340,y:771,t:1527876947887};\\\", \\\"{x:1339,y:772,t:1527876947904};\\\", \\\"{x:1338,y:773,t:1527876947920};\\\", \\\"{x:1338,y:774,t:1527876947942};\\\", \\\"{x:1337,y:775,t:1527876947954};\\\", \\\"{x:1336,y:777,t:1527876947971};\\\", \\\"{x:1334,y:778,t:1527876947987};\\\", \\\"{x:1333,y:779,t:1527876948004};\\\", \\\"{x:1333,y:780,t:1527876948022};\\\", \\\"{x:1332,y:780,t:1527876948038};\\\", \\\"{x:1332,y:781,t:1527876948054};\\\", \\\"{x:1331,y:782,t:1527876948086};\\\", \\\"{x:1335,y:781,t:1527876949648};\\\", \\\"{x:1338,y:778,t:1527876949662};\\\", \\\"{x:1343,y:774,t:1527876949679};\\\", \\\"{x:1345,y:772,t:1527876949695};\\\", \\\"{x:1346,y:771,t:1527876949711};\\\", \\\"{x:1347,y:771,t:1527876949728};\\\", \\\"{x:1348,y:771,t:1527876949767};\\\", \\\"{x:1348,y:770,t:1527876949783};\\\", \\\"{x:1349,y:770,t:1527876949796};\\\", \\\"{x:1351,y:768,t:1527876949812};\\\", \\\"{x:1353,y:768,t:1527876949828};\\\", \\\"{x:1353,y:769,t:1527876949951};\\\", \\\"{x:1351,y:771,t:1527876949963};\\\", \\\"{x:1343,y:780,t:1527876949980};\\\", \\\"{x:1339,y:788,t:1527876949996};\\\", \\\"{x:1335,y:799,t:1527876950013};\\\", \\\"{x:1331,y:809,t:1527876950030};\\\", \\\"{x:1329,y:812,t:1527876950046};\\\", \\\"{x:1328,y:813,t:1527876950063};\\\", \\\"{x:1328,y:814,t:1527876950079};\\\", \\\"{x:1328,y:815,t:1527876950110};\\\", \\\"{x:1327,y:816,t:1527876950206};\\\", \\\"{x:1327,y:817,t:1527876950247};\\\", \\\"{x:1327,y:818,t:1527876950264};\\\", \\\"{x:1327,y:819,t:1527876950287};\\\", \\\"{x:1326,y:823,t:1527876950318};\\\", \\\"{x:1326,y:824,t:1527876950335};\\\", \\\"{x:1326,y:825,t:1527876950348};\\\", \\\"{x:1326,y:826,t:1527876950365};\\\", \\\"{x:1326,y:827,t:1527876950381};\\\", \\\"{x:1325,y:829,t:1527876950397};\\\", \\\"{x:1325,y:830,t:1527876950415};\\\", \\\"{x:1323,y:833,t:1527876950431};\\\", \\\"{x:1322,y:836,t:1527876950448};\\\", \\\"{x:1322,y:838,t:1527876950465};\\\", \\\"{x:1321,y:839,t:1527876950482};\\\", \\\"{x:1320,y:841,t:1527876950499};\\\", \\\"{x:1319,y:842,t:1527876950515};\\\", \\\"{x:1319,y:843,t:1527876950534};\\\", \\\"{x:1318,y:844,t:1527876950549};\\\", \\\"{x:1318,y:845,t:1527876950566};\\\", \\\"{x:1317,y:846,t:1527876950581};\\\", \\\"{x:1316,y:847,t:1527876950599};\\\", \\\"{x:1315,y:848,t:1527876950618};\\\", \\\"{x:1315,y:850,t:1527876950639};\\\", \\\"{x:1314,y:850,t:1527876950649};\\\", \\\"{x:1312,y:853,t:1527876950666};\\\", \\\"{x:1310,y:856,t:1527876950683};\\\", \\\"{x:1310,y:857,t:1527876950727};\\\", \\\"{x:1309,y:859,t:1527876950743};\\\", \\\"{x:1308,y:859,t:1527876950751};\\\", \\\"{x:1307,y:861,t:1527876950766};\\\", \\\"{x:1306,y:863,t:1527876950783};\\\", \\\"{x:1305,y:865,t:1527876950800};\\\", \\\"{x:1304,y:866,t:1527876950839};\\\", \\\"{x:1304,y:867,t:1527876950863};\\\", \\\"{x:1303,y:867,t:1527876950871};\\\", \\\"{x:1302,y:868,t:1527876950883};\\\", \\\"{x:1300,y:872,t:1527876950900};\\\", \\\"{x:1299,y:874,t:1527876950917};\\\", \\\"{x:1298,y:875,t:1527876950934};\\\", \\\"{x:1297,y:877,t:1527876950950};\\\", \\\"{x:1296,y:878,t:1527876950967};\\\", \\\"{x:1295,y:879,t:1527876950999};\\\", \\\"{x:1294,y:879,t:1527876951023};\\\", \\\"{x:1294,y:880,t:1527876951039};\\\", \\\"{x:1294,y:881,t:1527876951071};\\\", \\\"{x:1293,y:881,t:1527876951084};\\\", \\\"{x:1292,y:882,t:1527876951111};\\\", \\\"{x:1291,y:884,t:1527876951119};\\\", \\\"{x:1289,y:886,t:1527876951135};\\\", \\\"{x:1287,y:888,t:1527876951150};\\\", \\\"{x:1286,y:890,t:1527876951168};\\\", \\\"{x:1285,y:894,t:1527876951185};\\\", \\\"{x:1284,y:895,t:1527876951201};\\\", \\\"{x:1281,y:898,t:1527876951218};\\\", \\\"{x:1279,y:901,t:1527876951234};\\\", \\\"{x:1277,y:903,t:1527876951252};\\\", \\\"{x:1274,y:905,t:1527876951268};\\\", \\\"{x:1273,y:905,t:1527876951295};\\\", \\\"{x:1272,y:905,t:1527876951303};\\\", \\\"{x:1271,y:905,t:1527876951319};\\\", \\\"{x:1267,y:908,t:1527876951335};\\\", \\\"{x:1266,y:908,t:1527876951352};\\\", \\\"{x:1265,y:908,t:1527876951391};\\\", \\\"{x:1264,y:909,t:1527876951431};\\\", \\\"{x:1263,y:911,t:1527876951471};\\\", \\\"{x:1262,y:912,t:1527876951487};\\\", \\\"{x:1261,y:913,t:1527876951503};\\\", \\\"{x:1261,y:916,t:1527876951519};\\\", \\\"{x:1260,y:918,t:1527876951536};\\\", \\\"{x:1260,y:921,t:1527876951553};\\\", \\\"{x:1260,y:924,t:1527876951570};\\\", \\\"{x:1260,y:925,t:1527876951586};\\\", \\\"{x:1260,y:927,t:1527876951602};\\\", \\\"{x:1260,y:928,t:1527876951620};\\\", \\\"{x:1259,y:929,t:1527876951637};\\\", \\\"{x:1259,y:931,t:1527876951653};\\\", \\\"{x:1259,y:932,t:1527876951670};\\\", \\\"{x:1258,y:933,t:1527876951687};\\\", \\\"{x:1258,y:936,t:1527876951703};\\\", \\\"{x:1257,y:941,t:1527876951719};\\\", \\\"{x:1256,y:942,t:1527876951737};\\\", \\\"{x:1256,y:945,t:1527876951754};\\\", \\\"{x:1256,y:947,t:1527876951771};\\\", \\\"{x:1256,y:948,t:1527876951786};\\\", \\\"{x:1256,y:949,t:1527876951804};\\\", \\\"{x:1255,y:949,t:1527876951821};\\\", \\\"{x:1255,y:950,t:1527876951837};\\\", \\\"{x:1255,y:951,t:1527876951854};\\\", \\\"{x:1254,y:953,t:1527876951871};\\\", \\\"{x:1254,y:954,t:1527876951894};\\\", \\\"{x:1254,y:955,t:1527876951943};\\\", \\\"{x:1253,y:956,t:1527876951959};\\\", \\\"{x:1253,y:957,t:1527876951975};\\\", \\\"{x:1253,y:958,t:1527876952023};\\\", \\\"{x:1251,y:959,t:1527876952039};\\\", \\\"{x:1251,y:961,t:1527876952055};\\\", \\\"{x:1251,y:963,t:1527876952200};\\\", \\\"{x:1250,y:963,t:1527876952207};\\\", \\\"{x:1250,y:964,t:1527876952278};\\\", \\\"{x:1250,y:966,t:1527876952366};\\\", \\\"{x:1250,y:967,t:1527876952390};\\\", \\\"{x:1251,y:966,t:1527876952638};\\\", \\\"{x:1251,y:965,t:1527876952645};\\\", \\\"{x:1252,y:964,t:1527876952657};\\\", \\\"{x:1253,y:963,t:1527876952673};\\\", \\\"{x:1255,y:961,t:1527876952691};\\\", \\\"{x:1257,y:958,t:1527876952707};\\\", \\\"{x:1257,y:957,t:1527876952723};\\\", \\\"{x:1260,y:954,t:1527876952740};\\\", \\\"{x:1268,y:949,t:1527876952757};\\\", \\\"{x:1285,y:939,t:1527876952774};\\\", \\\"{x:1292,y:934,t:1527876952790};\\\", \\\"{x:1296,y:927,t:1527876952807};\\\", \\\"{x:1299,y:916,t:1527876952824};\\\", \\\"{x:1301,y:902,t:1527876952841};\\\", \\\"{x:1304,y:892,t:1527876952858};\\\", \\\"{x:1305,y:884,t:1527876952874};\\\", \\\"{x:1309,y:876,t:1527876952892};\\\", \\\"{x:1313,y:865,t:1527876952907};\\\", \\\"{x:1326,y:842,t:1527876952925};\\\", \\\"{x:1334,y:821,t:1527876952942};\\\", \\\"{x:1340,y:793,t:1527876952958};\\\", \\\"{x:1342,y:772,t:1527876952974};\\\", \\\"{x:1345,y:757,t:1527876952992};\\\", \\\"{x:1350,y:747,t:1527876953008};\\\", \\\"{x:1354,y:738,t:1527876953027};\\\", \\\"{x:1359,y:728,t:1527876953041};\\\", \\\"{x:1367,y:716,t:1527876953058};\\\", \\\"{x:1370,y:706,t:1527876953076};\\\", \\\"{x:1374,y:696,t:1527876953092};\\\", \\\"{x:1375,y:694,t:1527876953108};\\\", \\\"{x:1375,y:693,t:1527876953126};\\\", \\\"{x:1376,y:693,t:1527876953207};\\\", \\\"{x:1376,y:698,t:1527876953215};\\\", \\\"{x:1373,y:704,t:1527876953226};\\\", \\\"{x:1368,y:720,t:1527876953243};\\\", \\\"{x:1362,y:734,t:1527876953260};\\\", \\\"{x:1357,y:743,t:1527876953277};\\\", \\\"{x:1355,y:747,t:1527876953293};\\\", \\\"{x:1354,y:748,t:1527876953310};\\\", \\\"{x:1353,y:750,t:1527876953327};\\\", \\\"{x:1352,y:753,t:1527876953344};\\\", \\\"{x:1350,y:755,t:1527876953360};\\\", \\\"{x:1348,y:757,t:1527876953377};\\\", \\\"{x:1346,y:758,t:1527876953394};\\\", \\\"{x:1346,y:759,t:1527876953410};\\\", \\\"{x:1345,y:760,t:1527876953519};\\\", \\\"{x:1345,y:761,t:1527876953542};\\\", \\\"{x:1347,y:761,t:1527876954951};\\\", \\\"{x:1349,y:761,t:1527876954967};\\\", \\\"{x:1356,y:760,t:1527876954985};\\\", \\\"{x:1368,y:758,t:1527876955000};\\\", \\\"{x:1380,y:757,t:1527876955017};\\\", \\\"{x:1392,y:755,t:1527876955034};\\\", \\\"{x:1402,y:755,t:1527876955051};\\\", \\\"{x:1408,y:754,t:1527876955067};\\\", \\\"{x:1411,y:754,t:1527876955084};\\\", \\\"{x:1413,y:753,t:1527876955101};\\\", \\\"{x:1414,y:753,t:1527876955118};\\\", \\\"{x:1415,y:753,t:1527876955134};\\\", \\\"{x:1416,y:753,t:1527876955151};\\\", \\\"{x:1419,y:753,t:1527876955168};\\\", \\\"{x:1421,y:753,t:1527876955185};\\\", \\\"{x:1424,y:753,t:1527876955201};\\\", \\\"{x:1426,y:753,t:1527876955218};\\\", \\\"{x:1427,y:753,t:1527876955247};\\\", \\\"{x:1429,y:756,t:1527876955255};\\\", \\\"{x:1431,y:762,t:1527876955268};\\\", \\\"{x:1440,y:773,t:1527876955285};\\\", \\\"{x:1448,y:782,t:1527876955302};\\\", \\\"{x:1455,y:787,t:1527876955318};\\\", \\\"{x:1460,y:791,t:1527876955334};\\\", \\\"{x:1463,y:796,t:1527876955352};\\\", \\\"{x:1466,y:800,t:1527876955369};\\\", \\\"{x:1467,y:803,t:1527876955385};\\\", \\\"{x:1468,y:806,t:1527876955402};\\\", \\\"{x:1470,y:807,t:1527876955420};\\\", \\\"{x:1472,y:810,t:1527876955435};\\\", \\\"{x:1472,y:811,t:1527876955452};\\\", \\\"{x:1473,y:813,t:1527876955469};\\\", \\\"{x:1474,y:814,t:1527876955486};\\\", \\\"{x:1474,y:815,t:1527876955502};\\\", \\\"{x:1474,y:816,t:1527876955519};\\\", \\\"{x:1474,y:818,t:1527876955536};\\\", \\\"{x:1474,y:819,t:1527876955791};\\\", \\\"{x:1476,y:820,t:1527876955804};\\\", \\\"{x:1476,y:821,t:1527876955820};\\\", \\\"{x:1476,y:822,t:1527876955837};\\\", \\\"{x:1476,y:824,t:1527876955853};\\\", \\\"{x:1477,y:825,t:1527876955880};\\\", \\\"{x:1477,y:826,t:1527876955912};\\\", \\\"{x:1477,y:828,t:1527876955943};\\\", \\\"{x:1477,y:830,t:1527876955958};\\\", \\\"{x:1477,y:831,t:1527876955971};\\\", \\\"{x:1478,y:833,t:1527876956007};\\\", \\\"{x:1478,y:834,t:1527876956055};\\\", \\\"{x:1478,y:836,t:1527876956088};\\\", \\\"{x:1481,y:845,t:1527876956105};\\\", \\\"{x:1490,y:860,t:1527876956122};\\\", \\\"{x:1495,y:868,t:1527876956138};\\\", \\\"{x:1502,y:878,t:1527876956155};\\\", \\\"{x:1511,y:889,t:1527876956172};\\\", \\\"{x:1517,y:899,t:1527876956190};\\\", \\\"{x:1522,y:909,t:1527876956205};\\\", \\\"{x:1528,y:920,t:1527876956222};\\\", \\\"{x:1534,y:931,t:1527876956239};\\\", \\\"{x:1534,y:934,t:1527876956257};\\\", \\\"{x:1534,y:935,t:1527876956272};\\\", \\\"{x:1535,y:937,t:1527876956289};\\\", \\\"{x:1535,y:938,t:1527876956306};\\\", \\\"{x:1536,y:940,t:1527876956326};\\\", \\\"{x:1536,y:941,t:1527876956340};\\\", \\\"{x:1536,y:942,t:1527876956359};\\\", \\\"{x:1532,y:942,t:1527876956512};\\\", \\\"{x:1526,y:942,t:1527876956523};\\\", \\\"{x:1499,y:931,t:1527876956540};\\\", \\\"{x:1451,y:907,t:1527876956557};\\\", \\\"{x:1399,y:875,t:1527876956574};\\\", \\\"{x:1353,y:850,t:1527876956590};\\\", \\\"{x:1324,y:832,t:1527876956607};\\\", \\\"{x:1318,y:827,t:1527876956624};\\\", \\\"{x:1317,y:826,t:1527876956641};\\\", \\\"{x:1317,y:825,t:1527876956657};\\\", \\\"{x:1317,y:822,t:1527876956674};\\\", \\\"{x:1318,y:818,t:1527876956692};\\\", \\\"{x:1319,y:818,t:1527876956708};\\\", \\\"{x:1320,y:816,t:1527876956724};\\\", \\\"{x:1323,y:811,t:1527876956742};\\\", \\\"{x:1324,y:802,t:1527876956759};\\\", \\\"{x:1328,y:794,t:1527876956774};\\\", \\\"{x:1332,y:785,t:1527876956791};\\\", \\\"{x:1341,y:771,t:1527876956808};\\\", \\\"{x:1349,y:759,t:1527876956825};\\\", \\\"{x:1352,y:751,t:1527876956842};\\\", \\\"{x:1353,y:748,t:1527876956858};\\\", \\\"{x:1355,y:746,t:1527876956875};\\\", \\\"{x:1356,y:744,t:1527876956918};\\\", \\\"{x:1356,y:743,t:1527876956943};\\\", \\\"{x:1356,y:741,t:1527876956959};\\\", \\\"{x:1358,y:739,t:1527876956975};\\\", \\\"{x:1358,y:738,t:1527876956993};\\\", \\\"{x:1358,y:735,t:1527876957010};\\\", \\\"{x:1358,y:732,t:1527876957025};\\\", \\\"{x:1359,y:728,t:1527876957042};\\\", \\\"{x:1359,y:725,t:1527876957059};\\\", \\\"{x:1359,y:722,t:1527876957076};\\\", \\\"{x:1359,y:721,t:1527876957092};\\\", \\\"{x:1359,y:720,t:1527876957110};\\\", \\\"{x:1359,y:719,t:1527876957167};\\\", \\\"{x:1359,y:717,t:1527876957184};\\\", \\\"{x:1359,y:715,t:1527876957193};\\\", \\\"{x:1359,y:714,t:1527876957215};\\\", \\\"{x:1358,y:712,t:1527876957239};\\\", \\\"{x:1358,y:711,t:1527876957271};\\\", \\\"{x:1357,y:709,t:1527876957279};\\\", \\\"{x:1357,y:707,t:1527876957333};\\\", \\\"{x:1356,y:707,t:1527876957398};\\\", \\\"{x:1354,y:706,t:1527876957511};\\\", \\\"{x:1353,y:706,t:1527876957535};\\\", \\\"{x:1352,y:705,t:1527876957607};\\\", \\\"{x:1351,y:705,t:1527876958191};\\\", \\\"{x:1349,y:705,t:1527876958206};\\\", \\\"{x:1348,y:705,t:1527876958407};\\\", \\\"{x:1344,y:707,t:1527876958415};\\\", \\\"{x:1336,y:717,t:1527876958431};\\\", \\\"{x:1325,y:733,t:1527876958447};\\\", \\\"{x:1313,y:753,t:1527876958465};\\\", \\\"{x:1303,y:771,t:1527876958480};\\\", \\\"{x:1293,y:783,t:1527876958498};\\\", \\\"{x:1285,y:795,t:1527876958515};\\\", \\\"{x:1277,y:804,t:1527876958531};\\\", \\\"{x:1270,y:817,t:1527876958547};\\\", \\\"{x:1264,y:829,t:1527876958564};\\\", \\\"{x:1257,y:849,t:1527876958582};\\\", \\\"{x:1254,y:860,t:1527876958598};\\\", \\\"{x:1250,y:866,t:1527876958614};\\\", \\\"{x:1247,y:873,t:1527876958632};\\\", \\\"{x:1245,y:882,t:1527876958649};\\\", \\\"{x:1241,y:896,t:1527876958665};\\\", \\\"{x:1237,y:912,t:1527876958682};\\\", \\\"{x:1235,y:922,t:1527876958699};\\\", \\\"{x:1233,y:929,t:1527876958715};\\\", \\\"{x:1233,y:931,t:1527876958732};\\\", \\\"{x:1233,y:932,t:1527876958749};\\\", \\\"{x:1233,y:933,t:1527876958766};\\\", \\\"{x:1233,y:934,t:1527876958783};\\\", \\\"{x:1232,y:935,t:1527876958815};\\\", \\\"{x:1232,y:927,t:1527876958919};\\\", \\\"{x:1235,y:919,t:1527876958934};\\\", \\\"{x:1242,y:903,t:1527876958950};\\\", \\\"{x:1263,y:871,t:1527876958967};\\\", \\\"{x:1277,y:850,t:1527876958984};\\\", \\\"{x:1287,y:828,t:1527876959000};\\\", \\\"{x:1301,y:807,t:1527876959018};\\\", \\\"{x:1315,y:788,t:1527876959033};\\\", \\\"{x:1326,y:767,t:1527876959050};\\\", \\\"{x:1332,y:752,t:1527876959067};\\\", \\\"{x:1336,y:745,t:1527876959084};\\\", \\\"{x:1339,y:740,t:1527876959101};\\\", \\\"{x:1340,y:738,t:1527876959117};\\\", \\\"{x:1340,y:736,t:1527876959134};\\\", \\\"{x:1341,y:735,t:1527876959151};\\\", \\\"{x:1342,y:734,t:1527876959167};\\\", \\\"{x:1342,y:732,t:1527876959184};\\\", \\\"{x:1342,y:731,t:1527876959201};\\\", \\\"{x:1343,y:728,t:1527876959218};\\\", \\\"{x:1343,y:727,t:1527876959234};\\\", \\\"{x:1343,y:726,t:1527876959251};\\\", \\\"{x:1343,y:723,t:1527876959268};\\\", \\\"{x:1344,y:721,t:1527876959285};\\\", \\\"{x:1345,y:716,t:1527876959300};\\\", \\\"{x:1346,y:713,t:1527876959318};\\\", \\\"{x:1346,y:712,t:1527876959335};\\\", \\\"{x:1346,y:710,t:1527876959352};\\\", \\\"{x:1346,y:709,t:1527876959368};\\\", \\\"{x:1346,y:708,t:1527876959385};\\\", \\\"{x:1346,y:707,t:1527876959402};\\\", \\\"{x:1347,y:706,t:1527876959420};\\\", \\\"{x:1349,y:709,t:1527876959591};\\\", \\\"{x:1350,y:712,t:1527876959603};\\\", \\\"{x:1352,y:715,t:1527876959619};\\\", \\\"{x:1354,y:721,t:1527876959636};\\\", \\\"{x:1354,y:724,t:1527876959653};\\\", \\\"{x:1357,y:732,t:1527876959670};\\\", \\\"{x:1358,y:735,t:1527876959687};\\\", \\\"{x:1362,y:743,t:1527876959702};\\\", \\\"{x:1366,y:747,t:1527876959720};\\\", \\\"{x:1369,y:752,t:1527876959737};\\\", \\\"{x:1371,y:756,t:1527876959753};\\\", \\\"{x:1374,y:760,t:1527876959770};\\\", \\\"{x:1378,y:766,t:1527876959786};\\\", \\\"{x:1384,y:774,t:1527876959803};\\\", \\\"{x:1390,y:779,t:1527876959820};\\\", \\\"{x:1398,y:785,t:1527876959837};\\\", \\\"{x:1401,y:789,t:1527876959854};\\\", \\\"{x:1402,y:790,t:1527876959869};\\\", \\\"{x:1406,y:793,t:1527876959887};\\\", \\\"{x:1413,y:797,t:1527876959904};\\\", \\\"{x:1418,y:801,t:1527876959921};\\\", \\\"{x:1430,y:807,t:1527876959937};\\\", \\\"{x:1439,y:812,t:1527876959954};\\\", \\\"{x:1445,y:814,t:1527876959971};\\\", \\\"{x:1448,y:815,t:1527876959988};\\\", \\\"{x:1449,y:815,t:1527876960004};\\\", \\\"{x:1450,y:815,t:1527876960020};\\\", \\\"{x:1452,y:815,t:1527876960079};\\\", \\\"{x:1454,y:815,t:1527876960094};\\\", \\\"{x:1456,y:814,t:1527876960105};\\\", \\\"{x:1458,y:813,t:1527876960121};\\\", \\\"{x:1461,y:813,t:1527876960138};\\\", \\\"{x:1463,y:813,t:1527876960159};\\\", \\\"{x:1464,y:813,t:1527876960172};\\\", \\\"{x:1465,y:814,t:1527876960188};\\\", \\\"{x:1466,y:814,t:1527876960206};\\\", \\\"{x:1468,y:817,t:1527876960223};\\\", \\\"{x:1469,y:819,t:1527876960238};\\\", \\\"{x:1470,y:822,t:1527876960256};\\\", \\\"{x:1471,y:823,t:1527876960272};\\\", \\\"{x:1471,y:824,t:1527876960295};\\\", \\\"{x:1472,y:825,t:1527876960335};\\\", \\\"{x:1473,y:825,t:1527876960343};\\\", \\\"{x:1474,y:826,t:1527876960359};\\\", \\\"{x:1475,y:826,t:1527876960431};\\\", \\\"{x:1476,y:826,t:1527876960439};\\\", \\\"{x:1478,y:826,t:1527876960457};\\\", \\\"{x:1479,y:826,t:1527876960490};\\\", \\\"{x:1480,y:826,t:1527876960543};\\\", \\\"{x:1481,y:826,t:1527876960558};\\\", \\\"{x:1481,y:827,t:1527876960958};\\\", \\\"{x:1481,y:828,t:1527876961039};\\\", \\\"{x:1480,y:829,t:1527876961054};\\\", \\\"{x:1478,y:830,t:1527876961071};\\\", \\\"{x:1475,y:830,t:1527876961080};\\\", \\\"{x:1470,y:830,t:1527876961092};\\\", \\\"{x:1462,y:830,t:1527876961109};\\\", \\\"{x:1455,y:830,t:1527876961125};\\\", \\\"{x:1444,y:830,t:1527876961142};\\\", \\\"{x:1428,y:826,t:1527876961159};\\\", \\\"{x:1406,y:818,t:1527876961176};\\\", \\\"{x:1378,y:809,t:1527876961192};\\\", \\\"{x:1354,y:797,t:1527876961209};\\\", \\\"{x:1333,y:792,t:1527876961225};\\\", \\\"{x:1317,y:788,t:1527876961243};\\\", \\\"{x:1303,y:783,t:1527876961259};\\\", \\\"{x:1297,y:783,t:1527876961276};\\\", \\\"{x:1295,y:783,t:1527876961293};\\\", \\\"{x:1292,y:783,t:1527876961310};\\\", \\\"{x:1286,y:784,t:1527876961326};\\\", \\\"{x:1281,y:787,t:1527876961343};\\\", \\\"{x:1274,y:790,t:1527876961360};\\\", \\\"{x:1265,y:794,t:1527876961377};\\\", \\\"{x:1252,y:799,t:1527876961393};\\\", \\\"{x:1241,y:804,t:1527876961410};\\\", \\\"{x:1232,y:807,t:1527876961427};\\\", \\\"{x:1224,y:812,t:1527876961443};\\\", \\\"{x:1220,y:813,t:1527876961460};\\\", \\\"{x:1215,y:818,t:1527876961477};\\\", \\\"{x:1208,y:826,t:1527876961495};\\\", \\\"{x:1203,y:828,t:1527876961510};\\\", \\\"{x:1202,y:828,t:1527876961527};\\\", \\\"{x:1202,y:829,t:1527876961544};\\\", \\\"{x:1202,y:828,t:1527876961671};\\\", \\\"{x:1202,y:826,t:1527876961679};\\\", \\\"{x:1206,y:817,t:1527876961695};\\\", \\\"{x:1210,y:811,t:1527876961711};\\\", \\\"{x:1213,y:805,t:1527876961729};\\\", \\\"{x:1214,y:800,t:1527876961745};\\\", \\\"{x:1216,y:794,t:1527876961761};\\\", \\\"{x:1218,y:789,t:1527876961778};\\\", \\\"{x:1218,y:782,t:1527876961795};\\\", \\\"{x:1221,y:778,t:1527876961812};\\\", \\\"{x:1222,y:773,t:1527876961828};\\\", \\\"{x:1227,y:764,t:1527876961845};\\\", \\\"{x:1236,y:746,t:1527876961862};\\\", \\\"{x:1246,y:733,t:1527876961878};\\\", \\\"{x:1258,y:718,t:1527876961895};\\\", \\\"{x:1270,y:692,t:1527876961912};\\\", \\\"{x:1290,y:665,t:1527876961930};\\\", \\\"{x:1293,y:660,t:1527876961946};\\\", \\\"{x:1296,y:654,t:1527876961962};\\\", \\\"{x:1298,y:651,t:1527876961979};\\\", \\\"{x:1300,y:645,t:1527876961996};\\\", \\\"{x:1300,y:643,t:1527876962012};\\\", \\\"{x:1300,y:641,t:1527876962030};\\\", \\\"{x:1300,y:638,t:1527876962046};\\\", \\\"{x:1301,y:636,t:1527876962062};\\\", \\\"{x:1301,y:631,t:1527876962079};\\\", \\\"{x:1304,y:624,t:1527876962096};\\\", \\\"{x:1304,y:620,t:1527876962114};\\\", \\\"{x:1304,y:617,t:1527876962130};\\\", \\\"{x:1303,y:615,t:1527876962146};\\\", \\\"{x:1301,y:614,t:1527876962163};\\\", \\\"{x:1300,y:613,t:1527876962181};\\\", \\\"{x:1300,y:612,t:1527876962198};\\\", \\\"{x:1299,y:609,t:1527876962214};\\\", \\\"{x:1298,y:605,t:1527876962231};\\\", \\\"{x:1297,y:603,t:1527876962246};\\\", \\\"{x:1296,y:601,t:1527876962263};\\\", \\\"{x:1296,y:600,t:1527876962293};\\\", \\\"{x:1295,y:600,t:1527876962301};\\\", \\\"{x:1295,y:599,t:1527876962325};\\\", \\\"{x:1295,y:598,t:1527876962341};\\\", \\\"{x:1294,y:593,t:1527876962694};\\\", \\\"{x:1294,y:591,t:1527876962709};\\\", \\\"{x:1294,y:590,t:1527876962717};\\\", \\\"{x:1293,y:590,t:1527876962732};\\\", \\\"{x:1293,y:587,t:1527876962748};\\\", \\\"{x:1293,y:584,t:1527876962765};\\\", \\\"{x:1293,y:583,t:1527876962861};\\\", \\\"{x:1293,y:582,t:1527876962869};\\\", \\\"{x:1293,y:581,t:1527876962881};\\\", \\\"{x:1293,y:580,t:1527876962909};\\\", \\\"{x:1293,y:579,t:1527876962925};\\\", \\\"{x:1293,y:578,t:1527876962933};\\\", \\\"{x:1293,y:577,t:1527876963005};\\\", \\\"{x:1293,y:576,t:1527876963016};\\\", \\\"{x:1291,y:575,t:1527876963032};\\\", \\\"{x:1290,y:574,t:1527876963048};\\\", \\\"{x:1289,y:574,t:1527876963124};\\\", \\\"{x:1288,y:574,t:1527876963189};\\\", \\\"{x:1287,y:574,t:1527876963213};\\\", \\\"{x:1286,y:574,t:1527876963261};\\\", \\\"{x:1285,y:574,t:1527876963269};\\\", \\\"{x:1282,y:574,t:1527876963282};\\\", \\\"{x:1281,y:574,t:1527876963300};\\\", \\\"{x:1279,y:574,t:1527876963316};\\\", \\\"{x:1280,y:573,t:1527876964108};\\\", \\\"{x:1282,y:572,t:1527876964123};\\\", \\\"{x:1283,y:572,t:1527876964188};\\\", \\\"{x:1286,y:571,t:1527876964213};\\\", \\\"{x:1287,y:571,t:1527876964228};\\\", \\\"{x:1289,y:571,t:1527876964253};\\\", \\\"{x:1291,y:570,t:1527876964260};\\\", \\\"{x:1292,y:570,t:1527876964271};\\\", \\\"{x:1296,y:570,t:1527876964287};\\\", \\\"{x:1313,y:567,t:1527876964303};\\\", \\\"{x:1329,y:565,t:1527876964321};\\\", \\\"{x:1340,y:563,t:1527876964338};\\\", \\\"{x:1349,y:562,t:1527876964354};\\\", \\\"{x:1356,y:562,t:1527876964370};\\\", \\\"{x:1363,y:562,t:1527876964387};\\\", \\\"{x:1368,y:562,t:1527876964404};\\\", \\\"{x:1371,y:562,t:1527876964420};\\\", \\\"{x:1373,y:562,t:1527876964438};\\\", \\\"{x:1376,y:561,t:1527876964454};\\\", \\\"{x:1381,y:561,t:1527876964471};\\\", \\\"{x:1386,y:559,t:1527876964488};\\\", \\\"{x:1390,y:558,t:1527876964504};\\\", \\\"{x:1396,y:557,t:1527876964522};\\\", \\\"{x:1402,y:557,t:1527876964538};\\\", \\\"{x:1404,y:557,t:1527876964555};\\\", \\\"{x:1406,y:556,t:1527876964572};\\\", \\\"{x:1408,y:555,t:1527876964589};\\\", \\\"{x:1410,y:555,t:1527876964605};\\\", \\\"{x:1414,y:555,t:1527876964622};\\\", \\\"{x:1417,y:555,t:1527876964638};\\\", \\\"{x:1418,y:555,t:1527876964655};\\\", \\\"{x:1419,y:555,t:1527876964672};\\\", \\\"{x:1420,y:556,t:1527876964688};\\\", \\\"{x:1421,y:556,t:1527876964706};\\\", \\\"{x:1421,y:557,t:1527876964722};\\\", \\\"{x:1421,y:559,t:1527876964796};\\\", \\\"{x:1421,y:561,t:1527876964806};\\\", \\\"{x:1421,y:562,t:1527876964828};\\\", \\\"{x:1421,y:564,t:1527876964839};\\\", \\\"{x:1421,y:565,t:1527876964918};\\\", \\\"{x:1420,y:565,t:1527876965078};\\\", \\\"{x:1419,y:565,t:1527876965150};\\\", \\\"{x:1417,y:565,t:1527876965174};\\\", \\\"{x:1415,y:565,t:1527876965804};\\\", \\\"{x:1414,y:565,t:1527876965836};\\\", \\\"{x:1413,y:565,t:1527876965845};\\\", \\\"{x:1412,y:566,t:1527876965861};\\\", \\\"{x:1410,y:567,t:1527876965877};\\\", \\\"{x:1409,y:569,t:1527876965895};\\\", \\\"{x:1408,y:570,t:1527876965911};\\\", \\\"{x:1407,y:571,t:1527876965928};\\\", \\\"{x:1407,y:572,t:1527876965944};\\\", \\\"{x:1405,y:574,t:1527876965961};\\\", \\\"{x:1404,y:576,t:1527876965978};\\\", \\\"{x:1403,y:576,t:1527876965994};\\\", \\\"{x:1402,y:578,t:1527876966011};\\\", \\\"{x:1401,y:579,t:1527876966028};\\\", \\\"{x:1401,y:582,t:1527876966045};\\\", \\\"{x:1400,y:583,t:1527876966061};\\\", \\\"{x:1399,y:587,t:1527876966078};\\\", \\\"{x:1398,y:589,t:1527876966095};\\\", \\\"{x:1396,y:597,t:1527876966112};\\\", \\\"{x:1394,y:604,t:1527876966128};\\\", \\\"{x:1393,y:609,t:1527876966145};\\\", \\\"{x:1390,y:614,t:1527876966162};\\\", \\\"{x:1389,y:619,t:1527876966179};\\\", \\\"{x:1388,y:624,t:1527876966195};\\\", \\\"{x:1386,y:629,t:1527876966212};\\\", \\\"{x:1385,y:634,t:1527876966229};\\\", \\\"{x:1383,y:638,t:1527876966245};\\\", \\\"{x:1382,y:642,t:1527876966262};\\\", \\\"{x:1380,y:649,t:1527876966279};\\\", \\\"{x:1377,y:654,t:1527876966296};\\\", \\\"{x:1374,y:661,t:1527876966312};\\\", \\\"{x:1373,y:667,t:1527876966329};\\\", \\\"{x:1372,y:673,t:1527876966346};\\\", \\\"{x:1369,y:679,t:1527876966363};\\\", \\\"{x:1366,y:684,t:1527876966379};\\\", \\\"{x:1363,y:691,t:1527876966396};\\\", \\\"{x:1360,y:698,t:1527876966413};\\\", \\\"{x:1357,y:704,t:1527876966430};\\\", \\\"{x:1354,y:711,t:1527876966446};\\\", \\\"{x:1348,y:721,t:1527876966463};\\\", \\\"{x:1342,y:731,t:1527876966480};\\\", \\\"{x:1339,y:737,t:1527876966497};\\\", \\\"{x:1337,y:742,t:1527876966514};\\\", \\\"{x:1336,y:746,t:1527876966530};\\\", \\\"{x:1335,y:749,t:1527876966547};\\\", \\\"{x:1335,y:750,t:1527876966563};\\\", \\\"{x:1334,y:752,t:1527876966580};\\\", \\\"{x:1332,y:754,t:1527876966598};\\\", \\\"{x:1331,y:756,t:1527876966614};\\\", \\\"{x:1331,y:759,t:1527876966629};\\\", \\\"{x:1328,y:763,t:1527876966647};\\\", \\\"{x:1326,y:771,t:1527876966664};\\\", \\\"{x:1323,y:776,t:1527876966680};\\\", \\\"{x:1319,y:780,t:1527876966696};\\\", \\\"{x:1316,y:787,t:1527876966714};\\\", \\\"{x:1312,y:794,t:1527876966731};\\\", \\\"{x:1308,y:801,t:1527876966748};\\\", \\\"{x:1305,y:805,t:1527876966763};\\\", \\\"{x:1302,y:809,t:1527876966780};\\\", \\\"{x:1300,y:814,t:1527876966797};\\\", \\\"{x:1298,y:818,t:1527876966814};\\\", \\\"{x:1296,y:824,t:1527876966831};\\\", \\\"{x:1291,y:835,t:1527876966848};\\\", \\\"{x:1285,y:846,t:1527876966864};\\\", \\\"{x:1277,y:857,t:1527876966880};\\\", \\\"{x:1273,y:864,t:1527876966897};\\\", \\\"{x:1270,y:872,t:1527876966914};\\\", \\\"{x:1267,y:879,t:1527876966932};\\\", \\\"{x:1267,y:884,t:1527876966947};\\\", \\\"{x:1262,y:893,t:1527876966964};\\\", \\\"{x:1259,y:898,t:1527876966981};\\\", \\\"{x:1255,y:902,t:1527876966998};\\\", \\\"{x:1250,y:908,t:1527876967014};\\\", \\\"{x:1246,y:913,t:1527876967032};\\\", \\\"{x:1244,y:918,t:1527876967048};\\\", \\\"{x:1243,y:923,t:1527876967065};\\\", \\\"{x:1242,y:927,t:1527876967081};\\\", \\\"{x:1240,y:930,t:1527876967098};\\\", \\\"{x:1240,y:932,t:1527876967156};\\\", \\\"{x:1240,y:933,t:1527876967181};\\\", \\\"{x:1240,y:934,t:1527876967230};\\\", \\\"{x:1240,y:936,t:1527876967237};\\\", \\\"{x:1239,y:936,t:1527876967249};\\\", \\\"{x:1238,y:936,t:1527876967277};\\\", \\\"{x:1237,y:936,t:1527876967285};\\\", \\\"{x:1238,y:930,t:1527876967526};\\\", \\\"{x:1241,y:926,t:1527876967534};\\\", \\\"{x:1246,y:918,t:1527876967551};\\\", \\\"{x:1251,y:903,t:1527876967568};\\\", \\\"{x:1263,y:889,t:1527876967584};\\\", \\\"{x:1271,y:873,t:1527876967601};\\\", \\\"{x:1283,y:858,t:1527876967618};\\\", \\\"{x:1294,y:844,t:1527876967635};\\\", \\\"{x:1303,y:832,t:1527876967652};\\\", \\\"{x:1313,y:819,t:1527876967668};\\\", \\\"{x:1326,y:798,t:1527876967685};\\\", \\\"{x:1334,y:785,t:1527876967701};\\\", \\\"{x:1343,y:768,t:1527876967718};\\\", \\\"{x:1348,y:759,t:1527876967736};\\\", \\\"{x:1350,y:756,t:1527876967753};\\\", \\\"{x:1351,y:755,t:1527876967769};\\\", \\\"{x:1351,y:754,t:1527876967785};\\\", \\\"{x:1351,y:753,t:1527876967861};\\\", \\\"{x:1351,y:752,t:1527876967869};\\\", \\\"{x:1351,y:746,t:1527876967885};\\\", \\\"{x:1351,y:741,t:1527876967902};\\\", \\\"{x:1354,y:734,t:1527876967919};\\\", \\\"{x:1356,y:725,t:1527876967936};\\\", \\\"{x:1363,y:709,t:1527876967954};\\\", \\\"{x:1370,y:689,t:1527876967969};\\\", \\\"{x:1374,y:673,t:1527876967986};\\\", \\\"{x:1380,y:660,t:1527876968004};\\\", \\\"{x:1384,y:648,t:1527876968018};\\\", \\\"{x:1388,y:634,t:1527876968035};\\\", \\\"{x:1394,y:617,t:1527876968052};\\\", \\\"{x:1399,y:607,t:1527876968069};\\\", \\\"{x:1401,y:598,t:1527876968085};\\\", \\\"{x:1405,y:592,t:1527876968103};\\\", \\\"{x:1407,y:587,t:1527876968119};\\\", \\\"{x:1408,y:585,t:1527876968137};\\\", \\\"{x:1408,y:583,t:1527876968152};\\\", \\\"{x:1409,y:581,t:1527876968169};\\\", \\\"{x:1410,y:580,t:1527876968188};\\\", \\\"{x:1410,y:579,t:1527876968212};\\\", \\\"{x:1411,y:578,t:1527876968220};\\\", \\\"{x:1411,y:577,t:1527876968236};\\\", \\\"{x:1414,y:573,t:1527876968253};\\\", \\\"{x:1414,y:572,t:1527876968270};\\\", \\\"{x:1415,y:571,t:1527876968286};\\\", \\\"{x:1416,y:568,t:1527876968303};\\\", \\\"{x:1417,y:566,t:1527876968337};\\\", \\\"{x:1417,y:565,t:1527876968353};\\\", \\\"{x:1418,y:564,t:1527876968371};\\\", \\\"{x:1419,y:565,t:1527876968709};\\\", \\\"{x:1419,y:568,t:1527876968722};\\\", \\\"{x:1420,y:575,t:1527876968738};\\\", \\\"{x:1421,y:586,t:1527876968756};\\\", \\\"{x:1427,y:607,t:1527876968772};\\\", \\\"{x:1430,y:618,t:1527876968789};\\\", \\\"{x:1433,y:628,t:1527876968805};\\\", \\\"{x:1436,y:636,t:1527876968822};\\\", \\\"{x:1437,y:641,t:1527876968838};\\\", \\\"{x:1440,y:646,t:1527876968855};\\\", \\\"{x:1440,y:650,t:1527876968873};\\\", \\\"{x:1442,y:654,t:1527876968889};\\\", \\\"{x:1444,y:661,t:1527876968906};\\\", \\\"{x:1447,y:673,t:1527876968922};\\\", \\\"{x:1450,y:685,t:1527876968940};\\\", \\\"{x:1459,y:700,t:1527876968956};\\\", \\\"{x:1462,y:704,t:1527876968973};\\\", \\\"{x:1462,y:706,t:1527876968990};\\\", \\\"{x:1463,y:708,t:1527876969013};\\\", \\\"{x:1464,y:710,t:1527876969024};\\\", \\\"{x:1466,y:717,t:1527876969039};\\\", \\\"{x:1467,y:724,t:1527876969056};\\\", \\\"{x:1471,y:733,t:1527876969074};\\\", \\\"{x:1476,y:743,t:1527876969091};\\\", \\\"{x:1481,y:752,t:1527876969106};\\\", \\\"{x:1488,y:766,t:1527876969124};\\\", \\\"{x:1499,y:784,t:1527876969140};\\\", \\\"{x:1506,y:799,t:1527876969156};\\\", \\\"{x:1514,y:811,t:1527876969174};\\\", \\\"{x:1521,y:818,t:1527876969191};\\\", \\\"{x:1525,y:825,t:1527876969208};\\\", \\\"{x:1529,y:831,t:1527876969223};\\\", \\\"{x:1532,y:837,t:1527876969240};\\\", \\\"{x:1536,y:845,t:1527876969257};\\\", \\\"{x:1539,y:850,t:1527876969274};\\\", \\\"{x:1546,y:857,t:1527876969291};\\\", \\\"{x:1551,y:862,t:1527876969307};\\\", \\\"{x:1559,y:872,t:1527876969325};\\\", \\\"{x:1567,y:883,t:1527876969342};\\\", \\\"{x:1579,y:895,t:1527876969358};\\\", \\\"{x:1590,y:908,t:1527876969374};\\\", \\\"{x:1602,y:916,t:1527876969392};\\\", \\\"{x:1610,y:921,t:1527876969408};\\\", \\\"{x:1615,y:924,t:1527876969424};\\\", \\\"{x:1621,y:931,t:1527876969442};\\\", \\\"{x:1626,y:938,t:1527876969458};\\\", \\\"{x:1629,y:942,t:1527876969474};\\\", \\\"{x:1631,y:944,t:1527876969491};\\\", \\\"{x:1633,y:948,t:1527876969509};\\\", \\\"{x:1634,y:953,t:1527876969525};\\\", \\\"{x:1634,y:956,t:1527876969542};\\\", \\\"{x:1634,y:957,t:1527876969606};\\\", \\\"{x:1633,y:957,t:1527876969646};\\\", \\\"{x:1631,y:957,t:1527876969659};\\\", \\\"{x:1626,y:957,t:1527876969677};\\\", \\\"{x:1622,y:955,t:1527876969693};\\\", \\\"{x:1622,y:950,t:1527876969710};\\\", \\\"{x:1616,y:935,t:1527876969726};\\\", \\\"{x:1605,y:911,t:1527876969743};\\\", \\\"{x:1579,y:869,t:1527876969761};\\\", \\\"{x:1551,y:830,t:1527876969777};\\\", \\\"{x:1530,y:797,t:1527876969794};\\\", \\\"{x:1517,y:774,t:1527876969810};\\\", \\\"{x:1506,y:754,t:1527876969826};\\\", \\\"{x:1494,y:732,t:1527876969844};\\\", \\\"{x:1487,y:714,t:1527876969859};\\\", \\\"{x:1483,y:703,t:1527876969877};\\\", \\\"{x:1482,y:698,t:1527876969894};\\\", \\\"{x:1481,y:693,t:1527876969911};\\\", \\\"{x:1479,y:684,t:1527876969927};\\\", \\\"{x:1476,y:671,t:1527876969944};\\\", \\\"{x:1474,y:664,t:1527876969961};\\\", \\\"{x:1473,y:659,t:1527876969976};\\\", \\\"{x:1472,y:654,t:1527876969994};\\\", \\\"{x:1468,y:641,t:1527876970011};\\\", \\\"{x:1463,y:629,t:1527876970028};\\\", \\\"{x:1456,y:621,t:1527876970043};\\\", \\\"{x:1452,y:609,t:1527876970060};\\\", \\\"{x:1448,y:602,t:1527876970077};\\\", \\\"{x:1440,y:589,t:1527876970095};\\\", \\\"{x:1426,y:578,t:1527876970110};\\\", \\\"{x:1415,y:573,t:1527876970128};\\\", \\\"{x:1405,y:568,t:1527876970144};\\\", \\\"{x:1395,y:563,t:1527876970161};\\\", \\\"{x:1382,y:559,t:1527876970178};\\\", \\\"{x:1359,y:558,t:1527876970194};\\\", \\\"{x:1319,y:558,t:1527876970212};\\\", \\\"{x:1230,y:558,t:1527876970228};\\\", \\\"{x:1161,y:558,t:1527876970245};\\\", \\\"{x:1095,y:555,t:1527876970262};\\\", \\\"{x:1036,y:551,t:1527876970279};\\\", \\\"{x:986,y:547,t:1527876970295};\\\", \\\"{x:930,y:539,t:1527876970312};\\\", \\\"{x:873,y:526,t:1527876970328};\\\", \\\"{x:832,y:516,t:1527876970346};\\\", \\\"{x:796,y:507,t:1527876970358};\\\", \\\"{x:757,y:503,t:1527876970375};\\\", \\\"{x:727,y:498,t:1527876970392};\\\", \\\"{x:715,y:498,t:1527876970409};\\\", \\\"{x:708,y:498,t:1527876970426};\\\", \\\"{x:705,y:498,t:1527876970442};\\\", \\\"{x:698,y:499,t:1527876970457};\\\", \\\"{x:693,y:502,t:1527876970474};\\\", \\\"{x:688,y:507,t:1527876970492};\\\", \\\"{x:686,y:509,t:1527876970508};\\\", \\\"{x:685,y:510,t:1527876970525};\\\", \\\"{x:681,y:513,t:1527876970542};\\\", \\\"{x:671,y:518,t:1527876970558};\\\", \\\"{x:658,y:526,t:1527876970575};\\\", \\\"{x:647,y:532,t:1527876970592};\\\", \\\"{x:640,y:535,t:1527876970609};\\\", \\\"{x:632,y:536,t:1527876970624};\\\", \\\"{x:617,y:539,t:1527876970641};\\\", \\\"{x:597,y:546,t:1527876970659};\\\", \\\"{x:577,y:552,t:1527876970675};\\\", \\\"{x:560,y:557,t:1527876970692};\\\", \\\"{x:547,y:560,t:1527876970708};\\\", \\\"{x:539,y:562,t:1527876970724};\\\", \\\"{x:532,y:566,t:1527876970743};\\\", \\\"{x:528,y:568,t:1527876970759};\\\", \\\"{x:524,y:569,t:1527876970774};\\\", \\\"{x:520,y:571,t:1527876970792};\\\", \\\"{x:515,y:572,t:1527876970808};\\\", \\\"{x:508,y:573,t:1527876970825};\\\", \\\"{x:496,y:574,t:1527876970843};\\\", \\\"{x:484,y:576,t:1527876970858};\\\", \\\"{x:475,y:576,t:1527876970874};\\\", \\\"{x:472,y:576,t:1527876970892};\\\", \\\"{x:463,y:575,t:1527876970908};\\\", \\\"{x:453,y:572,t:1527876970925};\\\", \\\"{x:442,y:571,t:1527876970942};\\\", \\\"{x:435,y:571,t:1527876970959};\\\", \\\"{x:426,y:570,t:1527876970975};\\\", \\\"{x:421,y:570,t:1527876970991};\\\", \\\"{x:419,y:570,t:1527876971009};\\\", \\\"{x:416,y:570,t:1527876971026};\\\", \\\"{x:410,y:571,t:1527876971043};\\\", \\\"{x:402,y:574,t:1527876971058};\\\", \\\"{x:390,y:578,t:1527876971076};\\\", \\\"{x:380,y:580,t:1527876971091};\\\", \\\"{x:363,y:583,t:1527876971108};\\\", \\\"{x:349,y:586,t:1527876971126};\\\", \\\"{x:337,y:587,t:1527876971141};\\\", \\\"{x:323,y:590,t:1527876971158};\\\", \\\"{x:308,y:590,t:1527876971175};\\\", \\\"{x:290,y:590,t:1527876971192};\\\", \\\"{x:275,y:590,t:1527876971209};\\\", \\\"{x:261,y:588,t:1527876971226};\\\", \\\"{x:253,y:586,t:1527876971241};\\\", \\\"{x:248,y:585,t:1527876971258};\\\", \\\"{x:242,y:584,t:1527876971276};\\\", \\\"{x:237,y:581,t:1527876971291};\\\", \\\"{x:227,y:577,t:1527876971309};\\\", \\\"{x:224,y:577,t:1527876971326};\\\", \\\"{x:224,y:576,t:1527876971342};\\\", \\\"{x:224,y:574,t:1527876971381};\\\", \\\"{x:229,y:574,t:1527876971392};\\\", \\\"{x:244,y:574,t:1527876971408};\\\", \\\"{x:273,y:574,t:1527876971427};\\\", \\\"{x:318,y:574,t:1527876971442};\\\", \\\"{x:368,y:580,t:1527876971458};\\\", \\\"{x:408,y:588,t:1527876971476};\\\", \\\"{x:446,y:596,t:1527876971493};\\\", \\\"{x:464,y:602,t:1527876971509};\\\", \\\"{x:486,y:604,t:1527876971525};\\\", \\\"{x:522,y:604,t:1527876971544};\\\", \\\"{x:554,y:599,t:1527876971559};\\\", \\\"{x:594,y:586,t:1527876971577};\\\", \\\"{x:656,y:565,t:1527876971592};\\\", \\\"{x:729,y:540,t:1527876971609};\\\", \\\"{x:794,y:521,t:1527876971627};\\\", \\\"{x:843,y:508,t:1527876971643};\\\", \\\"{x:885,y:503,t:1527876971659};\\\", \\\"{x:908,y:500,t:1527876971676};\\\", \\\"{x:927,y:496,t:1527876971692};\\\", \\\"{x:929,y:495,t:1527876971708};\\\", \\\"{x:930,y:495,t:1527876971732};\\\", \\\"{x:930,y:496,t:1527876971813};\\\", \\\"{x:929,y:497,t:1527876971826};\\\", \\\"{x:920,y:515,t:1527876971843};\\\", \\\"{x:913,y:524,t:1527876971860};\\\", \\\"{x:909,y:530,t:1527876971877};\\\", \\\"{x:903,y:534,t:1527876971893};\\\", \\\"{x:900,y:535,t:1527876971910};\\\", \\\"{x:895,y:536,t:1527876971926};\\\", \\\"{x:886,y:537,t:1527876971943};\\\", \\\"{x:877,y:537,t:1527876971960};\\\", \\\"{x:870,y:539,t:1527876971976};\\\", \\\"{x:866,y:539,t:1527876971994};\\\", \\\"{x:865,y:539,t:1527876972009};\\\", \\\"{x:863,y:539,t:1527876972026};\\\", \\\"{x:860,y:539,t:1527876972043};\\\", \\\"{x:858,y:539,t:1527876972060};\\\", \\\"{x:857,y:539,t:1527876972076};\\\", \\\"{x:855,y:541,t:1527876972093};\\\", \\\"{x:854,y:542,t:1527876972109};\\\", \\\"{x:853,y:542,t:1527876972126};\\\", \\\"{x:855,y:542,t:1527876972428};\\\", \\\"{x:860,y:542,t:1527876972443};\\\", \\\"{x:879,y:542,t:1527876972460};\\\", \\\"{x:926,y:542,t:1527876972477};\\\", \\\"{x:959,y:542,t:1527876972493};\\\", \\\"{x:1004,y:547,t:1527876972510};\\\", \\\"{x:1079,y:558,t:1527876972526};\\\", \\\"{x:1170,y:568,t:1527876972543};\\\", \\\"{x:1247,y:575,t:1527876972560};\\\", \\\"{x:1308,y:575,t:1527876972577};\\\", \\\"{x:1354,y:576,t:1527876972593};\\\", \\\"{x:1386,y:577,t:1527876972610};\\\", \\\"{x:1409,y:577,t:1527876972626};\\\", \\\"{x:1427,y:577,t:1527876972643};\\\", \\\"{x:1438,y:577,t:1527876972660};\\\", \\\"{x:1444,y:576,t:1527876972676};\\\", \\\"{x:1446,y:575,t:1527876972693};\\\", \\\"{x:1449,y:575,t:1527876972710};\\\", \\\"{x:1450,y:574,t:1527876972727};\\\", \\\"{x:1454,y:574,t:1527876972743};\\\", \\\"{x:1460,y:574,t:1527876972760};\\\", \\\"{x:1467,y:574,t:1527876972777};\\\", \\\"{x:1478,y:577,t:1527876972794};\\\", \\\"{x:1486,y:581,t:1527876972810};\\\", \\\"{x:1491,y:582,t:1527876972827};\\\", \\\"{x:1497,y:582,t:1527876972844};\\\", \\\"{x:1504,y:585,t:1527876972860};\\\", \\\"{x:1521,y:587,t:1527876972877};\\\", \\\"{x:1526,y:589,t:1527876972895};\\\", \\\"{x:1534,y:590,t:1527876972910};\\\", \\\"{x:1543,y:591,t:1527876972927};\\\", \\\"{x:1551,y:596,t:1527876972944};\\\", \\\"{x:1555,y:596,t:1527876972960};\\\", \\\"{x:1557,y:597,t:1527876972977};\\\", \\\"{x:1558,y:597,t:1527876973133};\\\", \\\"{x:1559,y:597,t:1527876973144};\\\", \\\"{x:1559,y:595,t:1527876973160};\\\", \\\"{x:1561,y:593,t:1527876973177};\\\", \\\"{x:1561,y:592,t:1527876973194};\\\", \\\"{x:1561,y:590,t:1527876973211};\\\", \\\"{x:1561,y:588,t:1527876973227};\\\", \\\"{x:1561,y:584,t:1527876973244};\\\", \\\"{x:1561,y:578,t:1527876973260};\\\", \\\"{x:1560,y:573,t:1527876973277};\\\", \\\"{x:1558,y:572,t:1527876973294};\\\", \\\"{x:1557,y:572,t:1527876973350};\\\", \\\"{x:1556,y:571,t:1527876973361};\\\", \\\"{x:1550,y:571,t:1527876973378};\\\", \\\"{x:1537,y:571,t:1527876973394};\\\", \\\"{x:1522,y:572,t:1527876973411};\\\", \\\"{x:1505,y:575,t:1527876973428};\\\", \\\"{x:1499,y:576,t:1527876973444};\\\", \\\"{x:1496,y:577,t:1527876973461};\\\", \\\"{x:1495,y:577,t:1527876973478};\\\", \\\"{x:1492,y:581,t:1527876973495};\\\", \\\"{x:1488,y:587,t:1527876973510};\\\", \\\"{x:1481,y:594,t:1527876973526};\\\", \\\"{x:1475,y:600,t:1527876973543};\\\", \\\"{x:1473,y:605,t:1527876973560};\\\", \\\"{x:1472,y:607,t:1527876973577};\\\", \\\"{x:1470,y:609,t:1527876973594};\\\", \\\"{x:1469,y:612,t:1527876973610};\\\", \\\"{x:1465,y:619,t:1527876973627};\\\", \\\"{x:1460,y:626,t:1527876973644};\\\", \\\"{x:1454,y:633,t:1527876973660};\\\", \\\"{x:1453,y:634,t:1527876973678};\\\", \\\"{x:1451,y:634,t:1527876973757};\\\", \\\"{x:1447,y:638,t:1527876973779};\\\", \\\"{x:1445,y:639,t:1527876973794};\\\", \\\"{x:1444,y:639,t:1527876973812};\\\", \\\"{x:1445,y:639,t:1527876974283};\\\", \\\"{x:1446,y:639,t:1527876974294};\\\", \\\"{x:1447,y:639,t:1527876974388};\\\", \\\"{x:1448,y:639,t:1527876974412};\\\", \\\"{x:1449,y:639,t:1527876974516};\\\", \\\"{x:1450,y:639,t:1527876974532};\\\", \\\"{x:1451,y:639,t:1527876974590};\\\", \\\"{x:1452,y:639,t:1527876974605};\\\", \\\"{x:1453,y:638,t:1527876974662};\\\", \\\"{x:1453,y:634,t:1527876979782};\\\", \\\"{x:1453,y:630,t:1527876979799};\\\", \\\"{x:1453,y:624,t:1527876979817};\\\", \\\"{x:1453,y:621,t:1527876979833};\\\", \\\"{x:1453,y:617,t:1527876979849};\\\", \\\"{x:1453,y:613,t:1527876979866};\\\", \\\"{x:1453,y:610,t:1527876979882};\\\", \\\"{x:1451,y:601,t:1527876979900};\\\", \\\"{x:1450,y:594,t:1527876979915};\\\", \\\"{x:1446,y:587,t:1527876979933};\\\", \\\"{x:1444,y:585,t:1527876979949};\\\", \\\"{x:1443,y:583,t:1527876979965};\\\", \\\"{x:1443,y:582,t:1527876979983};\\\", \\\"{x:1440,y:579,t:1527876980000};\\\", \\\"{x:1438,y:578,t:1527876980016};\\\", \\\"{x:1438,y:577,t:1527876980033};\\\", \\\"{x:1437,y:577,t:1527876980049};\\\", \\\"{x:1437,y:576,t:1527876980066};\\\", \\\"{x:1434,y:575,t:1527876980083};\\\", \\\"{x:1431,y:572,t:1527876980100};\\\", \\\"{x:1429,y:571,t:1527876980117};\\\", \\\"{x:1428,y:571,t:1527876980133};\\\", \\\"{x:1425,y:569,t:1527876980149};\\\", \\\"{x:1421,y:568,t:1527876980166};\\\", \\\"{x:1417,y:566,t:1527876980183};\\\", \\\"{x:1415,y:566,t:1527876980199};\\\", \\\"{x:1414,y:566,t:1527876980216};\\\", \\\"{x:1413,y:565,t:1527876980244};\\\", \\\"{x:1414,y:565,t:1527876981461};\\\", \\\"{x:1415,y:565,t:1527876981469};\\\", \\\"{x:1416,y:566,t:1527876981493};\\\", \\\"{x:1417,y:567,t:1527876981517};\\\", \\\"{x:1417,y:568,t:1527876981598};\\\", \\\"{x:1418,y:568,t:1527876981606};\\\", \\\"{x:1419,y:570,t:1527876981616};\\\", \\\"{x:1420,y:570,t:1527876981634};\\\", \\\"{x:1420,y:571,t:1527876981651};\\\", \\\"{x:1421,y:571,t:1527876981667};\\\", \\\"{x:1422,y:573,t:1527876981685};\\\", \\\"{x:1423,y:573,t:1527876981701};\\\", \\\"{x:1423,y:574,t:1527876981717};\\\", \\\"{x:1423,y:575,t:1527876982021};\\\", \\\"{x:1422,y:575,t:1527876982037};\\\", \\\"{x:1421,y:575,t:1527876982053};\\\", \\\"{x:1421,y:574,t:1527876982269};\\\", \\\"{x:1420,y:574,t:1527876982285};\\\", \\\"{x:1419,y:572,t:1527876982301};\\\", \\\"{x:1418,y:571,t:1527876982333};\\\", \\\"{x:1416,y:571,t:1527876982412};\\\", \\\"{x:1414,y:574,t:1527876982420};\\\", \\\"{x:1412,y:583,t:1527876982434};\\\", \\\"{x:1410,y:595,t:1527876982450};\\\", \\\"{x:1406,y:607,t:1527876982467};\\\", \\\"{x:1396,y:630,t:1527876982484};\\\", \\\"{x:1388,y:649,t:1527876982500};\\\", \\\"{x:1380,y:670,t:1527876982518};\\\", \\\"{x:1374,y:687,t:1527876982534};\\\", \\\"{x:1367,y:717,t:1527876982551};\\\", \\\"{x:1357,y:758,t:1527876982568};\\\", \\\"{x:1345,y:778,t:1527876982584};\\\", \\\"{x:1338,y:788,t:1527876982600};\\\", \\\"{x:1335,y:804,t:1527876982618};\\\", \\\"{x:1327,y:834,t:1527876982634};\\\", \\\"{x:1315,y:866,t:1527876982650};\\\", \\\"{x:1306,y:890,t:1527876982667};\\\", \\\"{x:1297,y:909,t:1527876982685};\\\", \\\"{x:1291,y:921,t:1527876982700};\\\", \\\"{x:1283,y:937,t:1527876982717};\\\", \\\"{x:1270,y:955,t:1527876982735};\\\", \\\"{x:1259,y:969,t:1527876982751};\\\", \\\"{x:1248,y:979,t:1527876982768};\\\", \\\"{x:1241,y:984,t:1527876982785};\\\", \\\"{x:1233,y:987,t:1527876982801};\\\", \\\"{x:1222,y:991,t:1527876982817};\\\", \\\"{x:1209,y:993,t:1527876982834};\\\", \\\"{x:1203,y:995,t:1527876982851};\\\", \\\"{x:1197,y:995,t:1527876982867};\\\", \\\"{x:1192,y:995,t:1527876982885};\\\", \\\"{x:1190,y:994,t:1527876982901};\\\", \\\"{x:1189,y:994,t:1527876982940};\\\", \\\"{x:1189,y:991,t:1527876982951};\\\", \\\"{x:1192,y:984,t:1527876982968};\\\", \\\"{x:1196,y:976,t:1527876982985};\\\", \\\"{x:1200,y:971,t:1527876983001};\\\", \\\"{x:1203,y:966,t:1527876983018};\\\", \\\"{x:1206,y:960,t:1527876983034};\\\", \\\"{x:1209,y:954,t:1527876983051};\\\", \\\"{x:1213,y:947,t:1527876983067};\\\", \\\"{x:1215,y:944,t:1527876983084};\\\", \\\"{x:1216,y:943,t:1527876983101};\\\", \\\"{x:1216,y:942,t:1527876983157};\\\", \\\"{x:1216,y:941,t:1527876983168};\\\", \\\"{x:1216,y:940,t:1527876983189};\\\", \\\"{x:1218,y:938,t:1527876983213};\\\", \\\"{x:1219,y:936,t:1527876983229};\\\", \\\"{x:1222,y:934,t:1527876983237};\\\", \\\"{x:1226,y:930,t:1527876983251};\\\", \\\"{x:1235,y:921,t:1527876983269};\\\", \\\"{x:1238,y:918,t:1527876983285};\\\", \\\"{x:1242,y:915,t:1527876983302};\\\", \\\"{x:1244,y:912,t:1527876983318};\\\", \\\"{x:1246,y:910,t:1527876983335};\\\", \\\"{x:1247,y:907,t:1527876983352};\\\", \\\"{x:1249,y:903,t:1527876983369};\\\", \\\"{x:1250,y:903,t:1527876983385};\\\", \\\"{x:1251,y:901,t:1527876983402};\\\", \\\"{x:1251,y:899,t:1527876983437};\\\", \\\"{x:1254,y:897,t:1527876983451};\\\", \\\"{x:1258,y:890,t:1527876983469};\\\", \\\"{x:1261,y:886,t:1527876983485};\\\", \\\"{x:1262,y:882,t:1527876983502};\\\", \\\"{x:1264,y:878,t:1527876983519};\\\", \\\"{x:1265,y:876,t:1527876983534};\\\", \\\"{x:1265,y:875,t:1527876983552};\\\", \\\"{x:1270,y:870,t:1527876983569};\\\", \\\"{x:1272,y:862,t:1527876983585};\\\", \\\"{x:1275,y:852,t:1527876983602};\\\", \\\"{x:1283,y:836,t:1527876983619};\\\", \\\"{x:1284,y:831,t:1527876983635};\\\", \\\"{x:1286,y:828,t:1527876983652};\\\", \\\"{x:1288,y:824,t:1527876983669};\\\", \\\"{x:1288,y:823,t:1527876983685};\\\", \\\"{x:1290,y:820,t:1527876983702};\\\", \\\"{x:1290,y:818,t:1527876983719};\\\", \\\"{x:1291,y:816,t:1527876983736};\\\", \\\"{x:1292,y:814,t:1527876983752};\\\", \\\"{x:1293,y:812,t:1527876983769};\\\", \\\"{x:1294,y:810,t:1527876983786};\\\", \\\"{x:1296,y:807,t:1527876983802};\\\", \\\"{x:1297,y:803,t:1527876983819};\\\", \\\"{x:1300,y:797,t:1527876983836};\\\", \\\"{x:1303,y:792,t:1527876983852};\\\", \\\"{x:1307,y:785,t:1527876983869};\\\", \\\"{x:1309,y:782,t:1527876983885};\\\", \\\"{x:1310,y:778,t:1527876983902};\\\", \\\"{x:1313,y:776,t:1527876983919};\\\", \\\"{x:1313,y:774,t:1527876983936};\\\", \\\"{x:1314,y:773,t:1527876983952};\\\", \\\"{x:1315,y:772,t:1527876983969};\\\", \\\"{x:1316,y:770,t:1527876983986};\\\", \\\"{x:1316,y:768,t:1527876984002};\\\", \\\"{x:1319,y:765,t:1527876984019};\\\", \\\"{x:1321,y:762,t:1527876984036};\\\", \\\"{x:1323,y:757,t:1527876984051};\\\", \\\"{x:1324,y:755,t:1527876984069};\\\", \\\"{x:1325,y:752,t:1527876984086};\\\", \\\"{x:1326,y:752,t:1527876984101};\\\", \\\"{x:1327,y:748,t:1527876984118};\\\", \\\"{x:1328,y:746,t:1527876984135};\\\", \\\"{x:1330,y:744,t:1527876984151};\\\", \\\"{x:1331,y:743,t:1527876984169};\\\", \\\"{x:1332,y:742,t:1527876984185};\\\", \\\"{x:1333,y:740,t:1527876984203};\\\", \\\"{x:1334,y:739,t:1527876984218};\\\", \\\"{x:1334,y:737,t:1527876984235};\\\", \\\"{x:1336,y:733,t:1527876984253};\\\", \\\"{x:1337,y:730,t:1527876984268};\\\", \\\"{x:1338,y:730,t:1527876984285};\\\", \\\"{x:1338,y:729,t:1527876984302};\\\", \\\"{x:1338,y:728,t:1527876984318};\\\", \\\"{x:1339,y:727,t:1527876984335};\\\", \\\"{x:1339,y:725,t:1527876984353};\\\", \\\"{x:1339,y:724,t:1527876984368};\\\", \\\"{x:1340,y:723,t:1527876984386};\\\", \\\"{x:1340,y:721,t:1527876984402};\\\", \\\"{x:1340,y:720,t:1527876984419};\\\", \\\"{x:1341,y:719,t:1527876984436};\\\", \\\"{x:1343,y:713,t:1527876984453};\\\", \\\"{x:1344,y:710,t:1527876984470};\\\", \\\"{x:1344,y:708,t:1527876984486};\\\", \\\"{x:1344,y:707,t:1527876984503};\\\", \\\"{x:1345,y:706,t:1527876984518};\\\", \\\"{x:1346,y:705,t:1527876984549};\\\", \\\"{x:1346,y:704,t:1527876984557};\\\", \\\"{x:1346,y:703,t:1527876984569};\\\", \\\"{x:1346,y:701,t:1527876984586};\\\", \\\"{x:1347,y:700,t:1527876984603};\\\", \\\"{x:1347,y:699,t:1527876984618};\\\", \\\"{x:1350,y:694,t:1527876985125};\\\", \\\"{x:1354,y:689,t:1527876985137};\\\", \\\"{x:1361,y:682,t:1527876985153};\\\", \\\"{x:1370,y:669,t:1527876985170};\\\", \\\"{x:1379,y:655,t:1527876985187};\\\", \\\"{x:1384,y:647,t:1527876985203};\\\", \\\"{x:1386,y:642,t:1527876985221};\\\", \\\"{x:1388,y:638,t:1527876985237};\\\", \\\"{x:1390,y:634,t:1527876985252};\\\", \\\"{x:1392,y:629,t:1527876985270};\\\", \\\"{x:1393,y:625,t:1527876985287};\\\", \\\"{x:1396,y:620,t:1527876985303};\\\", \\\"{x:1396,y:618,t:1527876985320};\\\", \\\"{x:1397,y:616,t:1527876985341};\\\", \\\"{x:1398,y:615,t:1527876985353};\\\", \\\"{x:1400,y:610,t:1527876985369};\\\", \\\"{x:1403,y:602,t:1527876985387};\\\", \\\"{x:1403,y:600,t:1527876985403};\\\", \\\"{x:1404,y:599,t:1527876985420};\\\", \\\"{x:1404,y:598,t:1527876985437};\\\", \\\"{x:1405,y:596,t:1527876985453};\\\", \\\"{x:1405,y:595,t:1527876985470};\\\", \\\"{x:1407,y:590,t:1527876985487};\\\", \\\"{x:1407,y:589,t:1527876985503};\\\", \\\"{x:1407,y:588,t:1527876985520};\\\", \\\"{x:1407,y:587,t:1527876985541};\\\", \\\"{x:1407,y:586,t:1527876985553};\\\", \\\"{x:1407,y:583,t:1527876985570};\\\", \\\"{x:1404,y:579,t:1527876985587};\\\", \\\"{x:1399,y:573,t:1527876985603};\\\", \\\"{x:1392,y:570,t:1527876985621};\\\", \\\"{x:1383,y:568,t:1527876985637};\\\", \\\"{x:1374,y:566,t:1527876985653};\\\", \\\"{x:1364,y:565,t:1527876985670};\\\", \\\"{x:1351,y:564,t:1527876985687};\\\", \\\"{x:1341,y:562,t:1527876985704};\\\", \\\"{x:1334,y:562,t:1527876985720};\\\", \\\"{x:1329,y:562,t:1527876985737};\\\", \\\"{x:1327,y:562,t:1527876985754};\\\", \\\"{x:1326,y:562,t:1527876985770};\\\", \\\"{x:1324,y:562,t:1527876985787};\\\", \\\"{x:1321,y:562,t:1527876985804};\\\", \\\"{x:1318,y:562,t:1527876985820};\\\", \\\"{x:1308,y:565,t:1527876985836};\\\", \\\"{x:1301,y:565,t:1527876985854};\\\", \\\"{x:1297,y:565,t:1527876985869};\\\", \\\"{x:1295,y:566,t:1527876985887};\\\", \\\"{x:1294,y:567,t:1527876985908};\\\", \\\"{x:1292,y:567,t:1527876985920};\\\", \\\"{x:1289,y:568,t:1527876985936};\\\", \\\"{x:1286,y:569,t:1527876985953};\\\", \\\"{x:1283,y:571,t:1527876985970};\\\", \\\"{x:1282,y:571,t:1527876985986};\\\", \\\"{x:1282,y:572,t:1527876986027};\\\", \\\"{x:1282,y:574,t:1527876986060};\\\", \\\"{x:1281,y:575,t:1527876986084};\\\", \\\"{x:1281,y:576,t:1527876986108};\\\", \\\"{x:1280,y:576,t:1527876986132};\\\", \\\"{x:1280,y:577,t:1527876986141};\\\", \\\"{x:1279,y:578,t:1527876986164};\\\", \\\"{x:1279,y:579,t:1527876986173};\\\", \\\"{x:1279,y:580,t:1527876986186};\\\", \\\"{x:1279,y:581,t:1527876986204};\\\", \\\"{x:1278,y:582,t:1527876986221};\\\", \\\"{x:1278,y:583,t:1527876986236};\\\", \\\"{x:1278,y:588,t:1527876986869};\\\", \\\"{x:1278,y:598,t:1527876986876};\\\", \\\"{x:1279,y:603,t:1527876986888};\\\", \\\"{x:1284,y:619,t:1527876986904};\\\", \\\"{x:1291,y:631,t:1527876986921};\\\", \\\"{x:1298,y:644,t:1527876986938};\\\", \\\"{x:1304,y:660,t:1527876986954};\\\", \\\"{x:1310,y:679,t:1527876986971};\\\", \\\"{x:1314,y:700,t:1527876986989};\\\", \\\"{x:1316,y:717,t:1527876987004};\\\", \\\"{x:1316,y:733,t:1527876987021};\\\", \\\"{x:1316,y:741,t:1527876987038};\\\", \\\"{x:1315,y:748,t:1527876987054};\\\", \\\"{x:1309,y:760,t:1527876987071};\\\", \\\"{x:1303,y:768,t:1527876987088};\\\", \\\"{x:1301,y:771,t:1527876987105};\\\", \\\"{x:1301,y:773,t:1527876987121};\\\", \\\"{x:1300,y:775,t:1527876987138};\\\", \\\"{x:1299,y:776,t:1527876987155};\\\", \\\"{x:1299,y:778,t:1527876987173};\\\", \\\"{x:1298,y:779,t:1527876987188};\\\", \\\"{x:1295,y:783,t:1527876987205};\\\", \\\"{x:1292,y:786,t:1527876987220};\\\", \\\"{x:1289,y:790,t:1527876987237};\\\", \\\"{x:1283,y:794,t:1527876987255};\\\", \\\"{x:1277,y:797,t:1527876987270};\\\", \\\"{x:1273,y:799,t:1527876987288};\\\", \\\"{x:1268,y:803,t:1527876987305};\\\", \\\"{x:1257,y:811,t:1527876987320};\\\", \\\"{x:1245,y:820,t:1527876987337};\\\", \\\"{x:1235,y:831,t:1527876987354};\\\", \\\"{x:1231,y:835,t:1527876987370};\\\", \\\"{x:1228,y:839,t:1527876987388};\\\", \\\"{x:1228,y:840,t:1527876987404};\\\", \\\"{x:1227,y:842,t:1527876987485};\\\", \\\"{x:1225,y:843,t:1527876987492};\\\", \\\"{x:1225,y:844,t:1527876987504};\\\", \\\"{x:1221,y:846,t:1527876987521};\\\", \\\"{x:1220,y:846,t:1527876987538};\\\", \\\"{x:1218,y:846,t:1527876987597};\\\", \\\"{x:1217,y:846,t:1527876987613};\\\", \\\"{x:1215,y:846,t:1527876987684};\\\", \\\"{x:1214,y:846,t:1527876987804};\\\", \\\"{x:1213,y:846,t:1527876987958};\\\", \\\"{x:1213,y:844,t:1527876987972};\\\", \\\"{x:1213,y:842,t:1527876987988};\\\", \\\"{x:1213,y:835,t:1527876988005};\\\", \\\"{x:1213,y:831,t:1527876988022};\\\", \\\"{x:1213,y:827,t:1527876988038};\\\", \\\"{x:1213,y:825,t:1527876988054};\\\", \\\"{x:1213,y:824,t:1527876988072};\\\", \\\"{x:1212,y:821,t:1527876988091};\\\", \\\"{x:1211,y:821,t:1527876988108};\\\", \\\"{x:1211,y:820,t:1527876988124};\\\", \\\"{x:1211,y:818,t:1527876988138};\\\", \\\"{x:1209,y:814,t:1527876988155};\\\", \\\"{x:1205,y:810,t:1527876988171};\\\", \\\"{x:1198,y:801,t:1527876988188};\\\", \\\"{x:1192,y:796,t:1527876988204};\\\", \\\"{x:1187,y:792,t:1527876988222};\\\", \\\"{x:1184,y:789,t:1527876988239};\\\", \\\"{x:1184,y:787,t:1527876988255};\\\", \\\"{x:1183,y:785,t:1527876988272};\\\", \\\"{x:1183,y:784,t:1527876988300};\\\", \\\"{x:1183,y:783,t:1527876988308};\\\", \\\"{x:1184,y:781,t:1527876988333};\\\", \\\"{x:1185,y:780,t:1527876988340};\\\", \\\"{x:1188,y:777,t:1527876988355};\\\", \\\"{x:1204,y:772,t:1527876988372};\\\", \\\"{x:1255,y:759,t:1527876988388};\\\", \\\"{x:1296,y:748,t:1527876988405};\\\", \\\"{x:1337,y:745,t:1527876988422};\\\", \\\"{x:1364,y:745,t:1527876988439};\\\", \\\"{x:1396,y:745,t:1527876988455};\\\", \\\"{x:1421,y:745,t:1527876988472};\\\", \\\"{x:1443,y:744,t:1527876988489};\\\", \\\"{x:1459,y:741,t:1527876988504};\\\", \\\"{x:1471,y:736,t:1527876988522};\\\", \\\"{x:1478,y:735,t:1527876988539};\\\", \\\"{x:1487,y:731,t:1527876988556};\\\", \\\"{x:1496,y:727,t:1527876988572};\\\", \\\"{x:1505,y:718,t:1527876988588};\\\", \\\"{x:1515,y:714,t:1527876988605};\\\", \\\"{x:1523,y:707,t:1527876988621};\\\", \\\"{x:1533,y:696,t:1527876988639};\\\", \\\"{x:1539,y:685,t:1527876988656};\\\", \\\"{x:1549,y:676,t:1527876988672};\\\", \\\"{x:1554,y:671,t:1527876988689};\\\", \\\"{x:1563,y:662,t:1527876988705};\\\", \\\"{x:1569,y:654,t:1527876988721};\\\", \\\"{x:1575,y:642,t:1527876988738};\\\", \\\"{x:1578,y:636,t:1527876988756};\\\", \\\"{x:1578,y:635,t:1527876988788};\\\", \\\"{x:1578,y:634,t:1527876988902};\\\", \\\"{x:1553,y:641,t:1527876988923};\\\", \\\"{x:1486,y:653,t:1527876988939};\\\", \\\"{x:1429,y:662,t:1527876988957};\\\", \\\"{x:1360,y:669,t:1527876988972};\\\", \\\"{x:1245,y:676,t:1527876988989};\\\", \\\"{x:1139,y:676,t:1527876989006};\\\", \\\"{x:1012,y:676,t:1527876989024};\\\", \\\"{x:894,y:685,t:1527876989040};\\\", \\\"{x:792,y:685,t:1527876989056};\\\", \\\"{x:705,y:684,t:1527876989073};\\\", \\\"{x:658,y:670,t:1527876989089};\\\", \\\"{x:629,y:662,t:1527876989106};\\\", \\\"{x:611,y:656,t:1527876989123};\\\", \\\"{x:598,y:652,t:1527876989139};\\\", \\\"{x:587,y:650,t:1527876989156};\\\", \\\"{x:574,y:647,t:1527876989173};\\\", \\\"{x:562,y:644,t:1527876989189};\\\", \\\"{x:551,y:643,t:1527876989206};\\\", \\\"{x:529,y:641,t:1527876989223};\\\", \\\"{x:510,y:641,t:1527876989238};\\\", \\\"{x:495,y:646,t:1527876989257};\\\", \\\"{x:486,y:651,t:1527876989273};\\\", \\\"{x:478,y:659,t:1527876989289};\\\", \\\"{x:467,y:676,t:1527876989305};\\\", \\\"{x:454,y:697,t:1527876989323};\\\", \\\"{x:449,y:712,t:1527876989339};\\\", \\\"{x:448,y:718,t:1527876989356};\\\", \\\"{x:448,y:721,t:1527876989374};\\\", \\\"{x:448,y:725,t:1527876989389};\\\", \\\"{x:448,y:729,t:1527876989407};\\\", \\\"{x:450,y:731,t:1527876989423};\\\", \\\"{x:451,y:732,t:1527876989441};\\\", \\\"{x:453,y:735,t:1527876989456};\\\", \\\"{x:456,y:741,t:1527876989473};\\\", \\\"{x:460,y:745,t:1527876989490};\\\", \\\"{x:461,y:746,t:1527876989507};\\\", \\\"{x:462,y:746,t:1527876989524};\\\", \\\"{x:463,y:746,t:1527876989572};\\\", \\\"{x:464,y:746,t:1527876989580};\\\", \\\"{x:466,y:745,t:1527876989596};\\\", \\\"{x:468,y:744,t:1527876989608};\\\", \\\"{x:472,y:739,t:1527876989624};\\\", \\\"{x:473,y:737,t:1527876989640};\\\", \\\"{x:474,y:737,t:1527876989657};\\\", \\\"{x:474,y:736,t:1527876989675};\\\", \\\"{x:475,y:735,t:1527876989700};\\\", \\\"{x:476,y:734,t:1527876989774};\\\", \\\"{x:477,y:734,t:1527876989812};\\\", \\\"{x:477,y:734,t:1527876989895};\\\", \\\"{x:478,y:734,t:1527876991084};\\\", \\\"{x:481,y:734,t:1527876991092};\\\", \\\"{x:486,y:732,t:1527876991108};\\\", \\\"{x:503,y:726,t:1527876991125};\\\", \\\"{x:520,y:724,t:1527876991142};\\\", \\\"{x:532,y:723,t:1527876991157};\\\", \\\"{x:546,y:723,t:1527876991174};\\\", \\\"{x:559,y:723,t:1527876991192};\\\", \\\"{x:567,y:721,t:1527876991207};\\\", \\\"{x:577,y:720,t:1527876991224};\\\", \\\"{x:582,y:719,t:1527876991241};\\\" ] }, { \\\"rt\\\": 77495, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 465933, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -B -B -B -J -J -I -B -B -B -B -I -E -I -F -A -F -J -J -J -J -J -J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:600,y:712,t:1527876991427};\\\", \\\"{x:605,y:710,t:1527876991796};\\\", \\\"{x:614,y:706,t:1527876991808};\\\", \\\"{x:626,y:703,t:1527876991825};\\\", \\\"{x:639,y:696,t:1527876991842};\\\", \\\"{x:656,y:688,t:1527876991858};\\\", \\\"{x:679,y:667,t:1527876991876};\\\", \\\"{x:706,y:640,t:1527876991892};\\\", \\\"{x:735,y:613,t:1527876991909};\\\", \\\"{x:737,y:609,t:1527876991925};\\\", \\\"{x:739,y:602,t:1527876991941};\\\", \\\"{x:739,y:598,t:1527876991959};\\\", \\\"{x:739,y:595,t:1527876991976};\\\", \\\"{x:739,y:594,t:1527876991992};\\\", \\\"{x:737,y:591,t:1527876992009};\\\", \\\"{x:735,y:591,t:1527876992026};\\\", \\\"{x:731,y:590,t:1527876992043};\\\", \\\"{x:720,y:588,t:1527876992059};\\\", \\\"{x:707,y:588,t:1527876992075};\\\", \\\"{x:689,y:588,t:1527876992092};\\\", \\\"{x:680,y:591,t:1527876992108};\\\", \\\"{x:677,y:591,t:1527876992126};\\\", \\\"{x:672,y:593,t:1527876992141};\\\", \\\"{x:668,y:597,t:1527876992159};\\\", \\\"{x:666,y:602,t:1527876992176};\\\", \\\"{x:661,y:611,t:1527876992192};\\\", \\\"{x:658,y:617,t:1527876992209};\\\", \\\"{x:657,y:621,t:1527876992225};\\\", \\\"{x:656,y:623,t:1527876992242};\\\", \\\"{x:655,y:624,t:1527876992260};\\\", \\\"{x:655,y:625,t:1527876992276};\\\", \\\"{x:654,y:626,t:1527876992293};\\\", \\\"{x:654,y:627,t:1527876992317};\\\", \\\"{x:654,y:628,t:1527876992373};\\\", \\\"{x:654,y:629,t:1527876992388};\\\", \\\"{x:654,y:630,t:1527876992397};\\\", \\\"{x:654,y:631,t:1527876992493};\\\", \\\"{x:655,y:631,t:1527877000813};\\\", \\\"{x:658,y:628,t:1527877000828};\\\", \\\"{x:664,y:625,t:1527877000846};\\\", \\\"{x:666,y:622,t:1527877000863};\\\", \\\"{x:669,y:621,t:1527877000878};\\\", \\\"{x:670,y:621,t:1527877000895};\\\", \\\"{x:676,y:621,t:1527877000913};\\\", \\\"{x:683,y:621,t:1527877000929};\\\", \\\"{x:698,y:621,t:1527877000945};\\\", \\\"{x:723,y:621,t:1527877000962};\\\", \\\"{x:747,y:621,t:1527877000979};\\\", \\\"{x:776,y:623,t:1527877000994};\\\", \\\"{x:818,y:631,t:1527877001011};\\\", \\\"{x:855,y:642,t:1527877001029};\\\", \\\"{x:900,y:657,t:1527877001046};\\\", \\\"{x:946,y:672,t:1527877001062};\\\", \\\"{x:994,y:682,t:1527877001079};\\\", \\\"{x:1034,y:694,t:1527877001096};\\\", \\\"{x:1064,y:700,t:1527877001113};\\\", \\\"{x:1096,y:707,t:1527877001129};\\\", \\\"{x:1130,y:713,t:1527877001146};\\\", \\\"{x:1152,y:715,t:1527877001162};\\\", \\\"{x:1172,y:719,t:1527877001179};\\\", \\\"{x:1221,y:726,t:1527877001196};\\\", \\\"{x:1245,y:735,t:1527877001213};\\\", \\\"{x:1270,y:741,t:1527877001229};\\\", \\\"{x:1298,y:747,t:1527877001246};\\\", \\\"{x:1323,y:750,t:1527877001263};\\\", \\\"{x:1341,y:754,t:1527877001281};\\\", \\\"{x:1366,y:758,t:1527877001296};\\\", \\\"{x:1392,y:761,t:1527877001313};\\\", \\\"{x:1405,y:770,t:1527877001330};\\\", \\\"{x:1413,y:771,t:1527877001346};\\\", \\\"{x:1414,y:771,t:1527877002188};\\\", \\\"{x:1414,y:773,t:1527877002198};\\\", \\\"{x:1415,y:775,t:1527877002404};\\\", \\\"{x:1418,y:776,t:1527877002415};\\\", \\\"{x:1423,y:778,t:1527877002432};\\\", \\\"{x:1433,y:779,t:1527877002449};\\\", \\\"{x:1441,y:781,t:1527877002466};\\\", \\\"{x:1454,y:782,t:1527877002482};\\\", \\\"{x:1461,y:783,t:1527877002499};\\\", \\\"{x:1471,y:783,t:1527877002516};\\\", \\\"{x:1475,y:783,t:1527877002532};\\\", \\\"{x:1479,y:783,t:1527877002549};\\\", \\\"{x:1482,y:783,t:1527877002567};\\\", \\\"{x:1483,y:783,t:1527877002582};\\\", \\\"{x:1484,y:783,t:1527877002599};\\\", \\\"{x:1483,y:783,t:1527877002765};\\\", \\\"{x:1483,y:785,t:1527877002773};\\\", \\\"{x:1482,y:789,t:1527877002783};\\\", \\\"{x:1478,y:793,t:1527877002800};\\\", \\\"{x:1474,y:800,t:1527877002817};\\\", \\\"{x:1469,y:805,t:1527877002834};\\\", \\\"{x:1466,y:807,t:1527877002852};\\\", \\\"{x:1463,y:809,t:1527877002867};\\\", \\\"{x:1462,y:810,t:1527877002884};\\\", \\\"{x:1459,y:810,t:1527877002901};\\\", \\\"{x:1452,y:810,t:1527877002916};\\\", \\\"{x:1441,y:810,t:1527877002933};\\\", \\\"{x:1430,y:810,t:1527877002950};\\\", \\\"{x:1416,y:810,t:1527877002967};\\\", \\\"{x:1401,y:807,t:1527877002984};\\\", \\\"{x:1389,y:802,t:1527877003000};\\\", \\\"{x:1372,y:795,t:1527877003017};\\\", \\\"{x:1356,y:790,t:1527877003033};\\\", \\\"{x:1342,y:788,t:1527877003050};\\\", \\\"{x:1337,y:788,t:1527877003067};\\\", \\\"{x:1332,y:787,t:1527877003084};\\\", \\\"{x:1331,y:787,t:1527877003261};\\\", \\\"{x:1329,y:787,t:1527877003268};\\\", \\\"{x:1321,y:795,t:1527877003284};\\\", \\\"{x:1309,y:806,t:1527877003301};\\\", \\\"{x:1298,y:815,t:1527877003317};\\\", \\\"{x:1293,y:818,t:1527877003334};\\\", \\\"{x:1279,y:824,t:1527877003352};\\\", \\\"{x:1273,y:827,t:1527877003368};\\\", \\\"{x:1268,y:829,t:1527877003384};\\\", \\\"{x:1255,y:834,t:1527877003402};\\\", \\\"{x:1244,y:834,t:1527877003418};\\\", \\\"{x:1236,y:836,t:1527877003434};\\\", \\\"{x:1232,y:836,t:1527877003451};\\\", \\\"{x:1227,y:836,t:1527877003468};\\\", \\\"{x:1226,y:836,t:1527877003484};\\\", \\\"{x:1225,y:836,t:1527877003541};\\\", \\\"{x:1223,y:836,t:1527877003652};\\\", \\\"{x:1221,y:836,t:1527877003667};\\\", \\\"{x:1220,y:837,t:1527877003685};\\\", \\\"{x:1218,y:837,t:1527877003772};\\\", \\\"{x:1217,y:837,t:1527877004022};\\\", \\\"{x:1216,y:837,t:1527877004037};\\\", \\\"{x:1214,y:836,t:1527877004053};\\\", \\\"{x:1214,y:834,t:1527877004079};\\\", \\\"{x:1214,y:833,t:1527877004107};\\\", \\\"{x:1214,y:832,t:1527877006868};\\\", \\\"{x:1216,y:830,t:1527877006876};\\\", \\\"{x:1219,y:828,t:1527877006891};\\\", \\\"{x:1230,y:822,t:1527877006909};\\\", \\\"{x:1242,y:814,t:1527877006926};\\\", \\\"{x:1254,y:809,t:1527877006942};\\\", \\\"{x:1265,y:804,t:1527877006959};\\\", \\\"{x:1277,y:796,t:1527877006975};\\\", \\\"{x:1284,y:791,t:1527877006992};\\\", \\\"{x:1303,y:780,t:1527877007009};\\\", \\\"{x:1316,y:774,t:1527877007026};\\\", \\\"{x:1327,y:769,t:1527877007042};\\\", \\\"{x:1335,y:766,t:1527877007059};\\\", \\\"{x:1340,y:764,t:1527877007076};\\\", \\\"{x:1342,y:761,t:1527877007092};\\\", \\\"{x:1343,y:761,t:1527877007109};\\\", \\\"{x:1344,y:761,t:1527877007147};\\\", \\\"{x:1345,y:761,t:1527877007188};\\\", \\\"{x:1345,y:760,t:1527877007212};\\\", \\\"{x:1346,y:760,t:1527877007268};\\\", \\\"{x:1347,y:760,t:1527877007668};\\\", \\\"{x:1347,y:761,t:1527877007677};\\\", \\\"{x:1348,y:765,t:1527877007694};\\\", \\\"{x:1349,y:766,t:1527877007710};\\\", \\\"{x:1351,y:769,t:1527877007728};\\\", \\\"{x:1353,y:773,t:1527877007745};\\\", \\\"{x:1355,y:778,t:1527877007760};\\\", \\\"{x:1358,y:781,t:1527877007778};\\\", \\\"{x:1361,y:785,t:1527877007794};\\\", \\\"{x:1364,y:788,t:1527877007811};\\\", \\\"{x:1365,y:789,t:1527877007827};\\\", \\\"{x:1366,y:791,t:1527877007845};\\\", \\\"{x:1367,y:792,t:1527877007861};\\\", \\\"{x:1368,y:793,t:1527877007925};\\\", \\\"{x:1368,y:794,t:1527877008165};\\\", \\\"{x:1367,y:794,t:1527877008188};\\\", \\\"{x:1366,y:792,t:1527877008205};\\\", \\\"{x:1364,y:788,t:1527877008213};\\\", \\\"{x:1359,y:782,t:1527877008229};\\\", \\\"{x:1355,y:776,t:1527877008246};\\\", \\\"{x:1353,y:775,t:1527877008263};\\\", \\\"{x:1351,y:772,t:1527877008278};\\\", \\\"{x:1350,y:771,t:1527877008296};\\\", \\\"{x:1350,y:770,t:1527877008313};\\\", \\\"{x:1349,y:768,t:1527877008373};\\\", \\\"{x:1349,y:767,t:1527877008420};\\\", \\\"{x:1349,y:766,t:1527877008453};\\\", \\\"{x:1349,y:765,t:1527877008468};\\\", \\\"{x:1349,y:764,t:1527877008493};\\\", \\\"{x:1349,y:763,t:1527877008500};\\\", \\\"{x:1349,y:762,t:1527877008532};\\\", \\\"{x:1349,y:761,t:1527877008829};\\\", \\\"{x:1351,y:762,t:1527877008847};\\\", \\\"{x:1351,y:763,t:1527877008864};\\\", \\\"{x:1353,y:766,t:1527877008882};\\\", \\\"{x:1353,y:768,t:1527877008897};\\\", \\\"{x:1355,y:770,t:1527877008914};\\\", \\\"{x:1355,y:773,t:1527877008931};\\\", \\\"{x:1357,y:774,t:1527877008947};\\\", \\\"{x:1358,y:778,t:1527877008964};\\\", \\\"{x:1361,y:782,t:1527877008980};\\\", \\\"{x:1362,y:784,t:1527877008997};\\\", \\\"{x:1362,y:785,t:1527877009014};\\\", \\\"{x:1364,y:787,t:1527877009031};\\\", \\\"{x:1364,y:789,t:1527877009048};\\\", \\\"{x:1365,y:793,t:1527877009064};\\\", \\\"{x:1366,y:798,t:1527877009081};\\\", \\\"{x:1369,y:802,t:1527877009097};\\\", \\\"{x:1372,y:806,t:1527877009114};\\\", \\\"{x:1373,y:808,t:1527877009131};\\\", \\\"{x:1374,y:812,t:1527877009148};\\\", \\\"{x:1375,y:815,t:1527877009164};\\\", \\\"{x:1378,y:822,t:1527877009181};\\\", \\\"{x:1381,y:826,t:1527877009198};\\\", \\\"{x:1384,y:832,t:1527877009215};\\\", \\\"{x:1384,y:834,t:1527877009231};\\\", \\\"{x:1386,y:837,t:1527877009248};\\\", \\\"{x:1387,y:838,t:1527877009265};\\\", \\\"{x:1387,y:842,t:1527877009281};\\\", \\\"{x:1388,y:848,t:1527877009298};\\\", \\\"{x:1390,y:853,t:1527877009315};\\\", \\\"{x:1391,y:860,t:1527877009331};\\\", \\\"{x:1394,y:867,t:1527877009348};\\\", \\\"{x:1396,y:876,t:1527877009364};\\\", \\\"{x:1399,y:881,t:1527877009382};\\\", \\\"{x:1402,y:887,t:1527877009398};\\\", \\\"{x:1404,y:892,t:1527877009415};\\\", \\\"{x:1406,y:897,t:1527877009432};\\\", \\\"{x:1409,y:902,t:1527877009448};\\\", \\\"{x:1410,y:905,t:1527877009465};\\\", \\\"{x:1412,y:909,t:1527877009482};\\\", \\\"{x:1414,y:914,t:1527877009499};\\\", \\\"{x:1415,y:919,t:1527877009515};\\\", \\\"{x:1417,y:923,t:1527877009532};\\\", \\\"{x:1419,y:927,t:1527877009549};\\\", \\\"{x:1419,y:928,t:1527877009565};\\\", \\\"{x:1421,y:930,t:1527877009582};\\\", \\\"{x:1421,y:931,t:1527877009613};\\\", \\\"{x:1421,y:932,t:1527877009645};\\\", \\\"{x:1422,y:933,t:1527877009652};\\\", \\\"{x:1424,y:934,t:1527877009677};\\\", \\\"{x:1425,y:936,t:1527877009692};\\\", \\\"{x:1425,y:937,t:1527877009709};\\\", \\\"{x:1427,y:939,t:1527877009717};\\\", \\\"{x:1429,y:941,t:1527877009733};\\\", \\\"{x:1431,y:944,t:1527877009748};\\\", \\\"{x:1432,y:947,t:1527877009766};\\\", \\\"{x:1434,y:950,t:1527877009783};\\\", \\\"{x:1435,y:951,t:1527877009804};\\\", \\\"{x:1435,y:952,t:1527877009820};\\\", \\\"{x:1436,y:953,t:1527877009833};\\\", \\\"{x:1436,y:955,t:1527877009853};\\\", \\\"{x:1438,y:957,t:1527877009866};\\\", \\\"{x:1439,y:961,t:1527877009883};\\\", \\\"{x:1440,y:964,t:1527877009901};\\\", \\\"{x:1441,y:967,t:1527877009915};\\\", \\\"{x:1442,y:971,t:1527877009932};\\\", \\\"{x:1442,y:972,t:1527877009964};\\\", \\\"{x:1443,y:972,t:1527877009972};\\\", \\\"{x:1443,y:973,t:1527877010068};\\\", \\\"{x:1444,y:973,t:1527877010092};\\\", \\\"{x:1445,y:973,t:1527877010100};\\\", \\\"{x:1446,y:973,t:1527877010116};\\\", \\\"{x:1447,y:973,t:1527877010164};\\\", \\\"{x:1448,y:973,t:1527877010196};\\\", \\\"{x:1449,y:973,t:1527877010269};\\\", \\\"{x:1449,y:972,t:1527877010621};\\\", \\\"{x:1449,y:971,t:1527877010742};\\\", \\\"{x:1449,y:970,t:1527877010757};\\\", \\\"{x:1449,y:969,t:1527877010781};\\\", \\\"{x:1449,y:968,t:1527877010829};\\\", \\\"{x:1449,y:967,t:1527877010852};\\\", \\\"{x:1449,y:966,t:1527877010868};\\\", \\\"{x:1449,y:965,t:1527877011181};\\\", \\\"{x:1450,y:964,t:1527877011196};\\\", \\\"{x:1451,y:962,t:1527877012181};\\\", \\\"{x:1451,y:957,t:1527877012188};\\\", \\\"{x:1446,y:949,t:1527877012204};\\\", \\\"{x:1439,y:939,t:1527877012221};\\\", \\\"{x:1431,y:932,t:1527877012238};\\\", \\\"{x:1425,y:925,t:1527877012255};\\\", \\\"{x:1422,y:918,t:1527877012271};\\\", \\\"{x:1419,y:910,t:1527877012288};\\\", \\\"{x:1417,y:901,t:1527877012305};\\\", \\\"{x:1415,y:894,t:1527877012321};\\\", \\\"{x:1414,y:891,t:1527877012337};\\\", \\\"{x:1413,y:887,t:1527877012354};\\\", \\\"{x:1412,y:881,t:1527877012372};\\\", \\\"{x:1411,y:879,t:1527877012388};\\\", \\\"{x:1410,y:873,t:1527877012404};\\\", \\\"{x:1410,y:869,t:1527877012421};\\\", \\\"{x:1408,y:860,t:1527877012437};\\\", \\\"{x:1404,y:852,t:1527877012454};\\\", \\\"{x:1397,y:844,t:1527877012471};\\\", \\\"{x:1391,y:837,t:1527877012488};\\\", \\\"{x:1384,y:829,t:1527877012504};\\\", \\\"{x:1380,y:825,t:1527877012521};\\\", \\\"{x:1377,y:822,t:1527877012539};\\\", \\\"{x:1374,y:819,t:1527877012554};\\\", \\\"{x:1373,y:817,t:1527877012571};\\\", \\\"{x:1369,y:814,t:1527877012588};\\\", \\\"{x:1365,y:812,t:1527877012604};\\\", \\\"{x:1365,y:809,t:1527877012621};\\\", \\\"{x:1364,y:807,t:1527877012639};\\\", \\\"{x:1360,y:803,t:1527877012654};\\\", \\\"{x:1357,y:798,t:1527877012672};\\\", \\\"{x:1354,y:794,t:1527877012689};\\\", \\\"{x:1353,y:792,t:1527877012706};\\\", \\\"{x:1352,y:790,t:1527877012721};\\\", \\\"{x:1352,y:789,t:1527877012738};\\\", \\\"{x:1352,y:786,t:1527877012756};\\\", \\\"{x:1350,y:784,t:1527877012772};\\\", \\\"{x:1350,y:783,t:1527877012828};\\\", \\\"{x:1350,y:782,t:1527877012869};\\\", \\\"{x:1350,y:781,t:1527877012877};\\\", \\\"{x:1350,y:779,t:1527877012889};\\\", \\\"{x:1350,y:777,t:1527877012906};\\\", \\\"{x:1350,y:774,t:1527877012922};\\\", \\\"{x:1350,y:773,t:1527877012964};\\\", \\\"{x:1350,y:772,t:1527877012980};\\\", \\\"{x:1350,y:771,t:1527877012990};\\\", \\\"{x:1350,y:769,t:1527877013006};\\\", \\\"{x:1350,y:767,t:1527877013023};\\\", \\\"{x:1350,y:766,t:1527877013040};\\\", \\\"{x:1350,y:765,t:1527877013101};\\\", \\\"{x:1350,y:764,t:1527877013109};\\\", \\\"{x:1349,y:763,t:1527877013141};\\\", \\\"{x:1348,y:762,t:1527877013429};\\\", \\\"{x:1347,y:761,t:1527877013445};\\\", \\\"{x:1347,y:760,t:1527877013525};\\\", \\\"{x:1345,y:759,t:1527877016725};\\\", \\\"{x:1342,y:760,t:1527877016733};\\\", \\\"{x:1331,y:768,t:1527877016749};\\\", \\\"{x:1325,y:773,t:1527877016765};\\\", \\\"{x:1317,y:781,t:1527877016781};\\\", \\\"{x:1309,y:787,t:1527877016797};\\\", \\\"{x:1298,y:795,t:1527877016814};\\\", \\\"{x:1286,y:806,t:1527877016831};\\\", \\\"{x:1270,y:819,t:1527877016848};\\\", \\\"{x:1254,y:830,t:1527877016865};\\\", \\\"{x:1240,y:841,t:1527877016881};\\\", \\\"{x:1224,y:853,t:1527877016897};\\\", \\\"{x:1197,y:869,t:1527877016915};\\\", \\\"{x:1172,y:887,t:1527877016932};\\\", \\\"{x:1157,y:896,t:1527877016948};\\\", \\\"{x:1148,y:901,t:1527877016965};\\\", \\\"{x:1145,y:901,t:1527877016982};\\\", \\\"{x:1145,y:902,t:1527877017076};\\\", \\\"{x:1145,y:904,t:1527877017100};\\\", \\\"{x:1147,y:904,t:1527877017116};\\\", \\\"{x:1150,y:904,t:1527877017132};\\\", \\\"{x:1156,y:904,t:1527877017149};\\\", \\\"{x:1159,y:902,t:1527877017165};\\\", \\\"{x:1164,y:899,t:1527877017182};\\\", \\\"{x:1169,y:895,t:1527877017199};\\\", \\\"{x:1176,y:890,t:1527877017215};\\\", \\\"{x:1183,y:883,t:1527877017233};\\\", \\\"{x:1188,y:875,t:1527877017249};\\\", \\\"{x:1194,y:868,t:1527877017266};\\\", \\\"{x:1196,y:862,t:1527877017283};\\\", \\\"{x:1199,y:858,t:1527877017299};\\\", \\\"{x:1202,y:852,t:1527877017316};\\\", \\\"{x:1204,y:849,t:1527877017332};\\\", \\\"{x:1205,y:845,t:1527877017349};\\\", \\\"{x:1205,y:843,t:1527877017367};\\\", \\\"{x:1206,y:838,t:1527877017382};\\\", \\\"{x:1208,y:833,t:1527877017399};\\\", \\\"{x:1208,y:829,t:1527877017416};\\\", \\\"{x:1208,y:828,t:1527877017433};\\\", \\\"{x:1208,y:827,t:1527877017449};\\\", \\\"{x:1208,y:826,t:1527877017466};\\\", \\\"{x:1209,y:825,t:1527877017483};\\\", \\\"{x:1210,y:824,t:1527877017500};\\\", \\\"{x:1211,y:824,t:1527877017516};\\\", \\\"{x:1212,y:824,t:1527877017613};\\\", \\\"{x:1213,y:824,t:1527877017724};\\\", \\\"{x:1216,y:825,t:1527877017756};\\\", \\\"{x:1216,y:826,t:1527877017820};\\\", \\\"{x:1216,y:827,t:1527877017860};\\\", \\\"{x:1216,y:828,t:1527877017940};\\\", \\\"{x:1216,y:830,t:1527877017950};\\\", \\\"{x:1216,y:831,t:1527877017967};\\\", \\\"{x:1216,y:834,t:1527877017985};\\\", \\\"{x:1215,y:837,t:1527877018002};\\\", \\\"{x:1214,y:840,t:1527877018018};\\\", \\\"{x:1211,y:844,t:1527877018034};\\\", \\\"{x:1210,y:850,t:1527877018051};\\\", \\\"{x:1206,y:855,t:1527877018067};\\\", \\\"{x:1202,y:861,t:1527877018085};\\\", \\\"{x:1201,y:865,t:1527877018100};\\\", \\\"{x:1198,y:869,t:1527877018117};\\\", \\\"{x:1196,y:872,t:1527877018133};\\\", \\\"{x:1195,y:875,t:1527877018150};\\\", \\\"{x:1193,y:877,t:1527877018168};\\\", \\\"{x:1192,y:882,t:1527877018183};\\\", \\\"{x:1191,y:883,t:1527877018201};\\\", \\\"{x:1189,y:886,t:1527877018217};\\\", \\\"{x:1188,y:889,t:1527877018236};\\\", \\\"{x:1187,y:890,t:1527877018300};\\\", \\\"{x:1187,y:893,t:1527877018318};\\\", \\\"{x:1186,y:894,t:1527877018334};\\\", \\\"{x:1185,y:896,t:1527877018351};\\\", \\\"{x:1183,y:899,t:1527877018368};\\\", \\\"{x:1182,y:900,t:1527877018385};\\\", \\\"{x:1182,y:901,t:1527877018401};\\\", \\\"{x:1181,y:904,t:1527877018418};\\\", \\\"{x:1180,y:905,t:1527877018435};\\\", \\\"{x:1178,y:907,t:1527877018452};\\\", \\\"{x:1178,y:908,t:1527877018468};\\\", \\\"{x:1176,y:910,t:1527877018485};\\\", \\\"{x:1175,y:912,t:1527877018502};\\\", \\\"{x:1174,y:913,t:1527877018519};\\\", \\\"{x:1173,y:915,t:1527877018536};\\\", \\\"{x:1172,y:915,t:1527877018556};\\\", \\\"{x:1171,y:915,t:1527877018573};\\\", \\\"{x:1170,y:915,t:1527877018585};\\\", \\\"{x:1168,y:915,t:1527877018603};\\\", \\\"{x:1164,y:915,t:1527877018619};\\\", \\\"{x:1159,y:915,t:1527877018635};\\\", \\\"{x:1152,y:915,t:1527877018652};\\\", \\\"{x:1151,y:914,t:1527877018669};\\\", \\\"{x:1151,y:908,t:1527877018685};\\\", \\\"{x:1149,y:899,t:1527877018702};\\\", \\\"{x:1149,y:888,t:1527877018719};\\\", \\\"{x:1153,y:875,t:1527877018735};\\\", \\\"{x:1160,y:859,t:1527877018752};\\\", \\\"{x:1171,y:840,t:1527877018769};\\\", \\\"{x:1182,y:824,t:1527877018786};\\\", \\\"{x:1188,y:812,t:1527877018802};\\\", \\\"{x:1198,y:793,t:1527877018820};\\\", \\\"{x:1208,y:775,t:1527877018837};\\\", \\\"{x:1211,y:771,t:1527877018853};\\\", \\\"{x:1211,y:769,t:1527877018869};\\\", \\\"{x:1213,y:766,t:1527877018886};\\\", \\\"{x:1215,y:764,t:1527877018903};\\\", \\\"{x:1215,y:761,t:1527877018919};\\\", \\\"{x:1216,y:760,t:1527877018936};\\\", \\\"{x:1216,y:759,t:1527877018953};\\\", \\\"{x:1217,y:758,t:1527877018969};\\\", \\\"{x:1217,y:757,t:1527877019013};\\\", \\\"{x:1215,y:757,t:1527877019020};\\\", \\\"{x:1210,y:757,t:1527877019036};\\\", \\\"{x:1208,y:757,t:1527877019052};\\\", \\\"{x:1207,y:757,t:1527877019070};\\\", \\\"{x:1205,y:757,t:1527877019099};\\\", \\\"{x:1203,y:758,t:1527877019107};\\\", \\\"{x:1202,y:758,t:1527877019119};\\\", \\\"{x:1197,y:761,t:1527877019136};\\\", \\\"{x:1194,y:762,t:1527877019153};\\\", \\\"{x:1192,y:763,t:1527877019170};\\\", \\\"{x:1190,y:764,t:1527877019186};\\\", \\\"{x:1189,y:765,t:1527877019204};\\\", \\\"{x:1187,y:765,t:1527877019219};\\\", \\\"{x:1186,y:766,t:1527877019237};\\\", \\\"{x:1184,y:768,t:1527877019253};\\\", \\\"{x:1187,y:768,t:1527877027043};\\\", \\\"{x:1202,y:768,t:1527877027051};\\\", \\\"{x:1239,y:771,t:1527877027067};\\\", \\\"{x:1300,y:771,t:1527877027085};\\\", \\\"{x:1351,y:772,t:1527877027101};\\\", \\\"{x:1379,y:775,t:1527877027119};\\\", \\\"{x:1395,y:775,t:1527877027135};\\\", \\\"{x:1403,y:777,t:1527877027152};\\\", \\\"{x:1405,y:777,t:1527877027168};\\\", \\\"{x:1405,y:776,t:1527877027306};\\\", \\\"{x:1403,y:774,t:1527877027319};\\\", \\\"{x:1395,y:773,t:1527877027336};\\\", \\\"{x:1391,y:772,t:1527877027352};\\\", \\\"{x:1382,y:772,t:1527877027369};\\\", \\\"{x:1367,y:772,t:1527877027386};\\\", \\\"{x:1360,y:774,t:1527877027402};\\\", \\\"{x:1356,y:775,t:1527877027419};\\\", \\\"{x:1355,y:775,t:1527877027436};\\\", \\\"{x:1354,y:775,t:1527877027452};\\\", \\\"{x:1353,y:775,t:1527877027746};\\\", \\\"{x:1352,y:773,t:1527877027785};\\\", \\\"{x:1352,y:772,t:1527877027826};\\\", \\\"{x:1350,y:771,t:1527877027849};\\\", \\\"{x:1350,y:770,t:1527877027857};\\\", \\\"{x:1350,y:769,t:1527877027870};\\\", \\\"{x:1350,y:768,t:1527877027887};\\\", \\\"{x:1349,y:765,t:1527877027920};\\\", \\\"{x:1349,y:762,t:1527877027937};\\\", \\\"{x:1349,y:757,t:1527877027954};\\\", \\\"{x:1349,y:756,t:1527877028018};\\\", \\\"{x:1348,y:756,t:1527877028112};\\\", \\\"{x:1347,y:756,t:1527877028120};\\\", \\\"{x:1347,y:757,t:1527877028136};\\\", \\\"{x:1342,y:762,t:1527877028153};\\\", \\\"{x:1339,y:765,t:1527877028171};\\\", \\\"{x:1337,y:768,t:1527877028187};\\\", \\\"{x:1336,y:770,t:1527877028203};\\\", \\\"{x:1335,y:772,t:1527877028241};\\\", \\\"{x:1334,y:774,t:1527877028265};\\\", \\\"{x:1332,y:776,t:1527877028272};\\\", \\\"{x:1330,y:777,t:1527877028288};\\\", \\\"{x:1330,y:779,t:1527877028303};\\\", \\\"{x:1328,y:782,t:1527877028320};\\\", \\\"{x:1325,y:786,t:1527877028336};\\\", \\\"{x:1323,y:789,t:1527877028354};\\\", \\\"{x:1322,y:791,t:1527877028370};\\\", \\\"{x:1322,y:792,t:1527877028388};\\\", \\\"{x:1321,y:793,t:1527877028405};\\\", \\\"{x:1320,y:795,t:1527877028420};\\\", \\\"{x:1319,y:797,t:1527877028437};\\\", \\\"{x:1318,y:799,t:1527877028456};\\\", \\\"{x:1316,y:801,t:1527877028470};\\\", \\\"{x:1316,y:802,t:1527877028487};\\\", \\\"{x:1315,y:804,t:1527877028505};\\\", \\\"{x:1315,y:809,t:1527877028520};\\\", \\\"{x:1314,y:813,t:1527877028537};\\\", \\\"{x:1312,y:817,t:1527877028554};\\\", \\\"{x:1311,y:822,t:1527877028571};\\\", \\\"{x:1310,y:824,t:1527877028593};\\\", \\\"{x:1310,y:825,t:1527877028604};\\\", \\\"{x:1310,y:828,t:1527877028625};\\\", \\\"{x:1306,y:832,t:1527877028639};\\\", \\\"{x:1306,y:833,t:1527877028654};\\\", \\\"{x:1305,y:836,t:1527877028671};\\\", \\\"{x:1304,y:839,t:1527877028689};\\\", \\\"{x:1303,y:840,t:1527877028704};\\\", \\\"{x:1300,y:846,t:1527877028721};\\\", \\\"{x:1299,y:850,t:1527877028738};\\\", \\\"{x:1297,y:853,t:1527877028754};\\\", \\\"{x:1296,y:857,t:1527877028772};\\\", \\\"{x:1295,y:860,t:1527877028788};\\\", \\\"{x:1293,y:861,t:1527877028806};\\\", \\\"{x:1292,y:862,t:1527877028821};\\\", \\\"{x:1291,y:864,t:1527877028839};\\\", \\\"{x:1289,y:867,t:1527877028856};\\\", \\\"{x:1289,y:869,t:1527877028871};\\\", \\\"{x:1288,y:873,t:1527877028889};\\\", \\\"{x:1286,y:877,t:1527877028905};\\\", \\\"{x:1284,y:880,t:1527877028922};\\\", \\\"{x:1283,y:885,t:1527877028939};\\\", \\\"{x:1282,y:889,t:1527877028956};\\\", \\\"{x:1279,y:897,t:1527877028972};\\\", \\\"{x:1278,y:902,t:1527877028988};\\\", \\\"{x:1275,y:908,t:1527877029005};\\\", \\\"{x:1274,y:912,t:1527877029023};\\\", \\\"{x:1272,y:918,t:1527877029039};\\\", \\\"{x:1268,y:926,t:1527877029056};\\\", \\\"{x:1265,y:933,t:1527877029073};\\\", \\\"{x:1264,y:937,t:1527877029089};\\\", \\\"{x:1261,y:943,t:1527877029105};\\\", \\\"{x:1259,y:947,t:1527877029123};\\\", \\\"{x:1258,y:950,t:1527877029140};\\\", \\\"{x:1255,y:953,t:1527877029156};\\\", \\\"{x:1255,y:954,t:1527877029173};\\\", \\\"{x:1255,y:955,t:1527877029190};\\\", \\\"{x:1255,y:957,t:1527877029205};\\\", \\\"{x:1254,y:958,t:1527877029223};\\\", \\\"{x:1254,y:957,t:1527877029330};\\\", \\\"{x:1256,y:951,t:1527877029340};\\\", \\\"{x:1264,y:938,t:1527877029357};\\\", \\\"{x:1273,y:923,t:1527877029373};\\\", \\\"{x:1280,y:907,t:1527877029390};\\\", \\\"{x:1290,y:894,t:1527877029407};\\\", \\\"{x:1296,y:880,t:1527877029424};\\\", \\\"{x:1302,y:868,t:1527877029440};\\\", \\\"{x:1308,y:854,t:1527877029457};\\\", \\\"{x:1314,y:840,t:1527877029473};\\\", \\\"{x:1319,y:827,t:1527877029490};\\\", \\\"{x:1324,y:818,t:1527877029508};\\\", \\\"{x:1327,y:808,t:1527877029523};\\\", \\\"{x:1328,y:804,t:1527877029540};\\\", \\\"{x:1328,y:799,t:1527877029556};\\\", \\\"{x:1328,y:795,t:1527877029574};\\\", \\\"{x:1329,y:792,t:1527877029591};\\\", \\\"{x:1330,y:788,t:1527877029606};\\\", \\\"{x:1331,y:784,t:1527877029623};\\\", \\\"{x:1332,y:778,t:1527877029641};\\\", \\\"{x:1333,y:773,t:1527877029657};\\\", \\\"{x:1336,y:771,t:1527877029674};\\\", \\\"{x:1337,y:767,t:1527877029691};\\\", \\\"{x:1340,y:765,t:1527877029708};\\\", \\\"{x:1343,y:762,t:1527877029724};\\\", \\\"{x:1343,y:761,t:1527877029741};\\\", \\\"{x:1344,y:760,t:1527877029757};\\\", \\\"{x:1347,y:760,t:1527877029774};\\\", \\\"{x:1350,y:759,t:1527877029791};\\\", \\\"{x:1353,y:758,t:1527877029809};\\\", \\\"{x:1355,y:757,t:1527877029824};\\\", \\\"{x:1355,y:758,t:1527877029961};\\\", \\\"{x:1356,y:761,t:1527877029975};\\\", \\\"{x:1356,y:766,t:1527877029990};\\\", \\\"{x:1356,y:775,t:1527877030008};\\\", \\\"{x:1357,y:784,t:1527877030025};\\\", \\\"{x:1358,y:793,t:1527877030042};\\\", \\\"{x:1360,y:800,t:1527877030057};\\\", \\\"{x:1363,y:804,t:1527877030075};\\\", \\\"{x:1365,y:807,t:1527877030092};\\\", \\\"{x:1366,y:809,t:1527877030108};\\\", \\\"{x:1366,y:812,t:1527877030125};\\\", \\\"{x:1366,y:814,t:1527877030141};\\\", \\\"{x:1366,y:815,t:1527877030159};\\\", \\\"{x:1366,y:817,t:1527877030175};\\\", \\\"{x:1367,y:818,t:1527877030192};\\\", \\\"{x:1367,y:817,t:1527877030330};\\\", \\\"{x:1367,y:815,t:1527877030342};\\\", \\\"{x:1368,y:810,t:1527877030359};\\\", \\\"{x:1368,y:807,t:1527877030376};\\\", \\\"{x:1368,y:802,t:1527877030392};\\\", \\\"{x:1368,y:794,t:1527877030409};\\\", \\\"{x:1368,y:788,t:1527877030425};\\\", \\\"{x:1368,y:784,t:1527877030442};\\\", \\\"{x:1368,y:781,t:1527877030459};\\\", \\\"{x:1368,y:779,t:1527877030476};\\\", \\\"{x:1368,y:781,t:1527877030585};\\\", \\\"{x:1370,y:786,t:1527877030594};\\\", \\\"{x:1373,y:795,t:1527877030609};\\\", \\\"{x:1376,y:801,t:1527877030626};\\\", \\\"{x:1378,y:808,t:1527877030643};\\\", \\\"{x:1382,y:816,t:1527877030660};\\\", \\\"{x:1386,y:827,t:1527877030676};\\\", \\\"{x:1392,y:835,t:1527877030692};\\\", \\\"{x:1398,y:844,t:1527877030710};\\\", \\\"{x:1403,y:852,t:1527877030726};\\\", \\\"{x:1408,y:859,t:1527877030742};\\\", \\\"{x:1412,y:864,t:1527877030759};\\\", \\\"{x:1415,y:870,t:1527877030776};\\\", \\\"{x:1417,y:875,t:1527877030793};\\\", \\\"{x:1418,y:880,t:1527877030809};\\\", \\\"{x:1421,y:882,t:1527877030826};\\\", \\\"{x:1423,y:886,t:1527877030842};\\\", \\\"{x:1426,y:889,t:1527877030860};\\\", \\\"{x:1428,y:892,t:1527877030877};\\\", \\\"{x:1428,y:893,t:1527877030905};\\\", \\\"{x:1428,y:894,t:1527877030913};\\\", \\\"{x:1429,y:895,t:1527877030926};\\\", \\\"{x:1429,y:898,t:1527877030943};\\\", \\\"{x:1431,y:900,t:1527877030959};\\\", \\\"{x:1432,y:903,t:1527877030976};\\\", \\\"{x:1434,y:906,t:1527877030993};\\\", \\\"{x:1434,y:907,t:1527877031010};\\\", \\\"{x:1436,y:911,t:1527877031027};\\\", \\\"{x:1436,y:914,t:1527877031044};\\\", \\\"{x:1438,y:917,t:1527877031060};\\\", \\\"{x:1439,y:918,t:1527877031076};\\\", \\\"{x:1442,y:921,t:1527877031093};\\\", \\\"{x:1442,y:924,t:1527877031111};\\\", \\\"{x:1443,y:926,t:1527877031127};\\\", \\\"{x:1445,y:928,t:1527877031144};\\\", \\\"{x:1446,y:930,t:1527877031160};\\\", \\\"{x:1447,y:932,t:1527877031176};\\\", \\\"{x:1447,y:933,t:1527877031193};\\\", \\\"{x:1448,y:937,t:1527877031211};\\\", \\\"{x:1448,y:939,t:1527877031227};\\\", \\\"{x:1449,y:941,t:1527877031244};\\\", \\\"{x:1449,y:943,t:1527877031260};\\\", \\\"{x:1451,y:944,t:1527877031281};\\\", \\\"{x:1451,y:945,t:1527877031305};\\\", \\\"{x:1451,y:946,t:1527877031321};\\\", \\\"{x:1451,y:947,t:1527877031345};\\\", \\\"{x:1451,y:948,t:1527877031361};\\\", \\\"{x:1450,y:946,t:1527877031578};\\\", \\\"{x:1450,y:945,t:1527877031594};\\\", \\\"{x:1449,y:943,t:1527877031612};\\\", \\\"{x:1448,y:942,t:1527877031628};\\\", \\\"{x:1448,y:940,t:1527877031645};\\\", \\\"{x:1446,y:939,t:1527877031662};\\\", \\\"{x:1445,y:937,t:1527877031698};\\\", \\\"{x:1445,y:936,t:1527877031722};\\\", \\\"{x:1444,y:936,t:1527877031729};\\\", \\\"{x:1443,y:934,t:1527877031753};\\\", \\\"{x:1443,y:933,t:1527877031785};\\\", \\\"{x:1442,y:932,t:1527877031794};\\\", \\\"{x:1441,y:932,t:1527877031812};\\\", \\\"{x:1441,y:930,t:1527877031829};\\\", \\\"{x:1441,y:926,t:1527877031846};\\\", \\\"{x:1439,y:924,t:1527877031862};\\\", \\\"{x:1439,y:923,t:1527877031882};\\\", \\\"{x:1438,y:923,t:1527877031897};\\\", \\\"{x:1438,y:922,t:1527877031913};\\\", \\\"{x:1438,y:921,t:1527877031937};\\\", \\\"{x:1438,y:920,t:1527877031994};\\\", \\\"{x:1436,y:918,t:1527877032009};\\\", \\\"{x:1436,y:917,t:1527877032018};\\\", \\\"{x:1435,y:914,t:1527877032033};\\\", \\\"{x:1433,y:911,t:1527877032046};\\\", \\\"{x:1431,y:905,t:1527877032063};\\\", \\\"{x:1425,y:892,t:1527877032079};\\\", \\\"{x:1415,y:878,t:1527877032096};\\\", \\\"{x:1394,y:854,t:1527877032113};\\\", \\\"{x:1380,y:840,t:1527877032130};\\\", \\\"{x:1372,y:827,t:1527877032146};\\\", \\\"{x:1366,y:809,t:1527877032163};\\\", \\\"{x:1361,y:796,t:1527877032179};\\\", \\\"{x:1355,y:782,t:1527877032196};\\\", \\\"{x:1346,y:770,t:1527877032213};\\\", \\\"{x:1335,y:758,t:1527877032230};\\\", \\\"{x:1326,y:752,t:1527877032246};\\\", \\\"{x:1322,y:749,t:1527877032263};\\\", \\\"{x:1322,y:748,t:1527877032280};\\\", \\\"{x:1322,y:747,t:1527877032296};\\\", \\\"{x:1321,y:745,t:1527877032312};\\\", \\\"{x:1320,y:744,t:1527877032329};\\\", \\\"{x:1320,y:741,t:1527877032346};\\\", \\\"{x:1320,y:740,t:1527877032363};\\\", \\\"{x:1319,y:739,t:1527877032385};\\\", \\\"{x:1318,y:739,t:1527877032433};\\\", \\\"{x:1313,y:739,t:1527877032447};\\\", \\\"{x:1302,y:744,t:1527877032463};\\\", \\\"{x:1283,y:751,t:1527877032480};\\\", \\\"{x:1251,y:760,t:1527877032496};\\\", \\\"{x:1236,y:763,t:1527877032514};\\\", \\\"{x:1220,y:765,t:1527877032530};\\\", \\\"{x:1209,y:767,t:1527877032546};\\\", \\\"{x:1199,y:767,t:1527877032564};\\\", \\\"{x:1192,y:768,t:1527877032579};\\\", \\\"{x:1190,y:769,t:1527877032596};\\\", \\\"{x:1188,y:769,t:1527877032613};\\\", \\\"{x:1187,y:769,t:1527877032777};\\\", \\\"{x:1185,y:769,t:1527877032801};\\\", \\\"{x:1184,y:769,t:1527877032858};\\\", \\\"{x:1183,y:769,t:1527877032907};\\\", \\\"{x:1183,y:766,t:1527877032915};\\\", \\\"{x:1183,y:755,t:1527877032930};\\\", \\\"{x:1186,y:744,t:1527877032947};\\\", \\\"{x:1190,y:726,t:1527877032965};\\\", \\\"{x:1196,y:710,t:1527877032980};\\\", \\\"{x:1204,y:692,t:1527877032997};\\\", \\\"{x:1215,y:668,t:1527877033014};\\\", \\\"{x:1233,y:638,t:1527877033030};\\\", \\\"{x:1235,y:628,t:1527877033047};\\\", \\\"{x:1238,y:623,t:1527877033064};\\\", \\\"{x:1241,y:618,t:1527877033081};\\\", \\\"{x:1242,y:615,t:1527877033098};\\\", \\\"{x:1243,y:612,t:1527877033114};\\\", \\\"{x:1245,y:609,t:1527877033131};\\\", \\\"{x:1246,y:606,t:1527877033147};\\\", \\\"{x:1248,y:604,t:1527877033164};\\\", \\\"{x:1249,y:603,t:1527877033181};\\\", \\\"{x:1251,y:599,t:1527877033199};\\\", \\\"{x:1252,y:597,t:1527877033215};\\\", \\\"{x:1253,y:596,t:1527877033232};\\\", \\\"{x:1256,y:592,t:1527877033249};\\\", \\\"{x:1259,y:588,t:1527877033265};\\\", \\\"{x:1262,y:584,t:1527877033281};\\\", \\\"{x:1263,y:582,t:1527877033299};\\\", \\\"{x:1265,y:580,t:1527877033314};\\\", \\\"{x:1265,y:578,t:1527877033332};\\\", \\\"{x:1266,y:577,t:1527877033348};\\\", \\\"{x:1267,y:576,t:1527877033366};\\\", \\\"{x:1268,y:575,t:1527877033382};\\\", \\\"{x:1269,y:574,t:1527877033398};\\\", \\\"{x:1271,y:572,t:1527877033416};\\\", \\\"{x:1272,y:571,t:1527877033433};\\\", \\\"{x:1274,y:571,t:1527877033473};\\\", \\\"{x:1275,y:569,t:1527877033497};\\\", \\\"{x:1276,y:569,t:1527877033506};\\\", \\\"{x:1278,y:568,t:1527877033546};\\\", \\\"{x:1279,y:567,t:1527877033570};\\\", \\\"{x:1280,y:566,t:1527877033593};\\\", \\\"{x:1281,y:566,t:1527877033609};\\\", \\\"{x:1282,y:566,t:1527877035858};\\\", \\\"{x:1281,y:571,t:1527877035872};\\\", \\\"{x:1278,y:580,t:1527877035888};\\\", \\\"{x:1271,y:599,t:1527877035904};\\\", \\\"{x:1264,y:622,t:1527877035921};\\\", \\\"{x:1258,y:638,t:1527877035938};\\\", \\\"{x:1254,y:655,t:1527877035955};\\\", \\\"{x:1250,y:669,t:1527877035971};\\\", \\\"{x:1246,y:685,t:1527877035988};\\\", \\\"{x:1242,y:700,t:1527877036005};\\\", \\\"{x:1239,y:711,t:1527877036021};\\\", \\\"{x:1238,y:722,t:1527877036038};\\\", \\\"{x:1238,y:726,t:1527877036055};\\\", \\\"{x:1237,y:730,t:1527877036071};\\\", \\\"{x:1234,y:732,t:1527877036088};\\\", \\\"{x:1233,y:735,t:1527877036105};\\\", \\\"{x:1230,y:738,t:1527877036122};\\\", \\\"{x:1228,y:742,t:1527877036138};\\\", \\\"{x:1224,y:747,t:1527877036154};\\\", \\\"{x:1219,y:752,t:1527877036171};\\\", \\\"{x:1208,y:764,t:1527877036188};\\\", \\\"{x:1192,y:777,t:1527877036204};\\\", \\\"{x:1174,y:787,t:1527877036221};\\\", \\\"{x:1167,y:791,t:1527877036237};\\\", \\\"{x:1163,y:793,t:1527877036255};\\\", \\\"{x:1161,y:794,t:1527877036272};\\\", \\\"{x:1161,y:792,t:1527877036394};\\\", \\\"{x:1163,y:788,t:1527877036407};\\\", \\\"{x:1168,y:782,t:1527877036423};\\\", \\\"{x:1173,y:776,t:1527877036439};\\\", \\\"{x:1179,y:769,t:1527877036456};\\\", \\\"{x:1183,y:765,t:1527877036473};\\\", \\\"{x:1185,y:762,t:1527877036489};\\\", \\\"{x:1186,y:762,t:1527877036505};\\\", \\\"{x:1186,y:764,t:1527877037114};\\\", \\\"{x:1186,y:766,t:1527877037123};\\\", \\\"{x:1186,y:767,t:1527877037142};\\\", \\\"{x:1186,y:768,t:1527877037157};\\\", \\\"{x:1186,y:769,t:1527877037174};\\\", \\\"{x:1185,y:770,t:1527877037482};\\\", \\\"{x:1184,y:770,t:1527877037530};\\\", \\\"{x:1184,y:771,t:1527877037818};\\\", \\\"{x:1188,y:771,t:1527877037825};\\\", \\\"{x:1192,y:768,t:1527877037842};\\\", \\\"{x:1204,y:763,t:1527877037860};\\\", \\\"{x:1217,y:756,t:1527877037876};\\\", \\\"{x:1225,y:753,t:1527877037892};\\\", \\\"{x:1231,y:749,t:1527877037909};\\\", \\\"{x:1236,y:746,t:1527877037925};\\\", \\\"{x:1238,y:744,t:1527877037942};\\\", \\\"{x:1242,y:740,t:1527877037959};\\\", \\\"{x:1247,y:733,t:1527877037975};\\\", \\\"{x:1251,y:726,t:1527877037992};\\\", \\\"{x:1256,y:720,t:1527877038008};\\\", \\\"{x:1258,y:714,t:1527877038025};\\\", \\\"{x:1260,y:712,t:1527877038042};\\\", \\\"{x:1260,y:711,t:1527877038058};\\\", \\\"{x:1260,y:710,t:1527877038075};\\\", \\\"{x:1262,y:709,t:1527877038093};\\\", \\\"{x:1267,y:706,t:1527877038109};\\\", \\\"{x:1271,y:704,t:1527877038126};\\\", \\\"{x:1276,y:703,t:1527877038143};\\\", \\\"{x:1280,y:702,t:1527877038159};\\\", \\\"{x:1283,y:702,t:1527877038176};\\\", \\\"{x:1293,y:702,t:1527877038192};\\\", \\\"{x:1299,y:702,t:1527877038210};\\\", \\\"{x:1301,y:702,t:1527877038225};\\\", \\\"{x:1303,y:702,t:1527877038243};\\\", \\\"{x:1304,y:702,t:1527877038260};\\\", \\\"{x:1306,y:702,t:1527877038276};\\\", \\\"{x:1309,y:701,t:1527877038293};\\\", \\\"{x:1310,y:701,t:1527877038310};\\\", \\\"{x:1313,y:701,t:1527877038326};\\\", \\\"{x:1315,y:699,t:1527877038343};\\\", \\\"{x:1318,y:699,t:1527877038360};\\\", \\\"{x:1323,y:696,t:1527877038377};\\\", \\\"{x:1326,y:696,t:1527877038393};\\\", \\\"{x:1327,y:694,t:1527877038411};\\\", \\\"{x:1330,y:694,t:1527877038427};\\\", \\\"{x:1331,y:694,t:1527877038490};\\\", \\\"{x:1332,y:692,t:1527877038504};\\\", \\\"{x:1333,y:692,t:1527877038560};\\\", \\\"{x:1334,y:692,t:1527877038584};\\\", \\\"{x:1335,y:693,t:1527877038594};\\\", \\\"{x:1336,y:693,t:1527877038609};\\\", \\\"{x:1338,y:693,t:1527877038632};\\\", \\\"{x:1339,y:693,t:1527877038664};\\\", \\\"{x:1340,y:693,t:1527877041217};\\\", \\\"{x:1342,y:692,t:1527877041233};\\\", \\\"{x:1345,y:692,t:1527877041250};\\\", \\\"{x:1343,y:692,t:1527877041459};\\\", \\\"{x:1341,y:692,t:1527877041468};\\\", \\\"{x:1338,y:692,t:1527877041483};\\\", \\\"{x:1335,y:692,t:1527877041499};\\\", \\\"{x:1333,y:692,t:1527877041516};\\\", \\\"{x:1332,y:692,t:1527877041533};\\\", \\\"{x:1329,y:692,t:1527877041549};\\\", \\\"{x:1328,y:692,t:1527877041567};\\\", \\\"{x:1328,y:689,t:1527877041649};\\\", \\\"{x:1328,y:686,t:1527877041656};\\\", \\\"{x:1328,y:683,t:1527877041667};\\\", \\\"{x:1328,y:676,t:1527877041684};\\\", \\\"{x:1329,y:657,t:1527877041700};\\\", \\\"{x:1332,y:647,t:1527877041717};\\\", \\\"{x:1335,y:639,t:1527877041734};\\\", \\\"{x:1336,y:630,t:1527877041751};\\\", \\\"{x:1336,y:624,t:1527877041767};\\\", \\\"{x:1338,y:617,t:1527877041784};\\\", \\\"{x:1338,y:615,t:1527877041801};\\\", \\\"{x:1338,y:614,t:1527877041817};\\\", \\\"{x:1338,y:613,t:1527877041954};\\\", \\\"{x:1338,y:610,t:1527877041969};\\\", \\\"{x:1339,y:604,t:1527877041985};\\\", \\\"{x:1341,y:595,t:1527877042001};\\\", \\\"{x:1343,y:592,t:1527877042018};\\\", \\\"{x:1345,y:587,t:1527877042035};\\\", \\\"{x:1349,y:581,t:1527877042052};\\\", \\\"{x:1354,y:574,t:1527877042068};\\\", \\\"{x:1362,y:568,t:1527877042085};\\\", \\\"{x:1372,y:560,t:1527877042102};\\\", \\\"{x:1378,y:554,t:1527877042119};\\\", \\\"{x:1385,y:546,t:1527877042136};\\\", \\\"{x:1387,y:543,t:1527877042151};\\\", \\\"{x:1388,y:536,t:1527877042168};\\\", \\\"{x:1391,y:530,t:1527877042185};\\\", \\\"{x:1392,y:525,t:1527877042202};\\\", \\\"{x:1396,y:518,t:1527877042219};\\\", \\\"{x:1401,y:508,t:1527877042235};\\\", \\\"{x:1404,y:500,t:1527877042252};\\\", \\\"{x:1404,y:486,t:1527877042268};\\\", \\\"{x:1404,y:472,t:1527877042285};\\\", \\\"{x:1405,y:460,t:1527877042302};\\\", \\\"{x:1406,y:447,t:1527877042318};\\\", \\\"{x:1406,y:443,t:1527877042335};\\\", \\\"{x:1406,y:442,t:1527877042352};\\\", \\\"{x:1406,y:440,t:1527877042369};\\\", \\\"{x:1406,y:438,t:1527877042386};\\\", \\\"{x:1406,y:437,t:1527877042409};\\\", \\\"{x:1406,y:435,t:1527877042506};\\\", \\\"{x:1407,y:434,t:1527877042522};\\\", \\\"{x:1407,y:433,t:1527877042537};\\\", \\\"{x:1408,y:433,t:1527877042553};\\\", \\\"{x:1408,y:432,t:1527877042569};\\\", \\\"{x:1410,y:430,t:1527877042587};\\\", \\\"{x:1411,y:430,t:1527877042603};\\\", \\\"{x:1412,y:428,t:1527877042657};\\\", \\\"{x:1413,y:428,t:1527877042669};\\\", \\\"{x:1414,y:427,t:1527877042762};\\\", \\\"{x:1412,y:433,t:1527877045914};\\\", \\\"{x:1405,y:437,t:1527877045928};\\\", \\\"{x:1392,y:445,t:1527877045943};\\\", \\\"{x:1366,y:462,t:1527877045961};\\\", \\\"{x:1357,y:466,t:1527877045977};\\\", \\\"{x:1343,y:478,t:1527877045994};\\\", \\\"{x:1339,y:484,t:1527877046011};\\\", \\\"{x:1332,y:494,t:1527877046028};\\\", \\\"{x:1324,y:511,t:1527877046043};\\\", \\\"{x:1313,y:527,t:1527877046060};\\\", \\\"{x:1305,y:539,t:1527877046077};\\\", \\\"{x:1303,y:544,t:1527877046094};\\\", \\\"{x:1299,y:551,t:1527877046111};\\\", \\\"{x:1297,y:556,t:1527877046128};\\\", \\\"{x:1296,y:561,t:1527877046145};\\\", \\\"{x:1295,y:563,t:1527877046161};\\\", \\\"{x:1294,y:566,t:1527877046178};\\\", \\\"{x:1292,y:568,t:1527877046195};\\\", \\\"{x:1291,y:574,t:1527877046210};\\\", \\\"{x:1290,y:576,t:1527877046228};\\\", \\\"{x:1290,y:577,t:1527877046346};\\\", \\\"{x:1289,y:578,t:1527877046362};\\\", \\\"{x:1288,y:578,t:1527877046378};\\\", \\\"{x:1287,y:578,t:1527877046402};\\\", \\\"{x:1287,y:580,t:1527877047650};\\\", \\\"{x:1288,y:589,t:1527877047664};\\\", \\\"{x:1294,y:604,t:1527877047681};\\\", \\\"{x:1309,y:631,t:1527877047698};\\\", \\\"{x:1319,y:649,t:1527877047715};\\\", \\\"{x:1327,y:661,t:1527877047730};\\\", \\\"{x:1334,y:670,t:1527877047747};\\\", \\\"{x:1335,y:675,t:1527877047765};\\\", \\\"{x:1336,y:679,t:1527877047781};\\\", \\\"{x:1336,y:683,t:1527877047797};\\\", \\\"{x:1339,y:690,t:1527877047814};\\\", \\\"{x:1343,y:698,t:1527877047832};\\\", \\\"{x:1344,y:704,t:1527877047849};\\\", \\\"{x:1346,y:710,t:1527877047865};\\\", \\\"{x:1350,y:717,t:1527877047881};\\\", \\\"{x:1352,y:721,t:1527877047898};\\\", \\\"{x:1358,y:731,t:1527877047914};\\\", \\\"{x:1365,y:743,t:1527877047931};\\\", \\\"{x:1368,y:753,t:1527877047948};\\\", \\\"{x:1373,y:761,t:1527877047964};\\\", \\\"{x:1376,y:766,t:1527877047981};\\\", \\\"{x:1378,y:770,t:1527877047999};\\\", \\\"{x:1380,y:774,t:1527877048015};\\\", \\\"{x:1382,y:777,t:1527877048032};\\\", \\\"{x:1384,y:782,t:1527877048049};\\\", \\\"{x:1386,y:785,t:1527877048065};\\\", \\\"{x:1386,y:789,t:1527877048081};\\\", \\\"{x:1390,y:795,t:1527877048099};\\\", \\\"{x:1392,y:799,t:1527877048115};\\\", \\\"{x:1394,y:803,t:1527877048131};\\\", \\\"{x:1395,y:808,t:1527877048148};\\\", \\\"{x:1397,y:812,t:1527877048166};\\\", \\\"{x:1399,y:814,t:1527877048182};\\\", \\\"{x:1401,y:818,t:1527877048198};\\\", \\\"{x:1404,y:822,t:1527877048215};\\\", \\\"{x:1406,y:825,t:1527877048231};\\\", \\\"{x:1409,y:831,t:1527877048249};\\\", \\\"{x:1413,y:837,t:1527877048266};\\\", \\\"{x:1414,y:841,t:1527877048283};\\\", \\\"{x:1417,y:845,t:1527877048298};\\\", \\\"{x:1422,y:851,t:1527877048316};\\\", \\\"{x:1427,y:858,t:1527877048332};\\\", \\\"{x:1431,y:864,t:1527877048349};\\\", \\\"{x:1431,y:869,t:1527877048366};\\\", \\\"{x:1434,y:873,t:1527877048382};\\\", \\\"{x:1437,y:878,t:1527877048398};\\\", \\\"{x:1439,y:881,t:1527877048416};\\\", \\\"{x:1441,y:885,t:1527877048433};\\\", \\\"{x:1442,y:891,t:1527877048449};\\\", \\\"{x:1444,y:892,t:1527877048466};\\\", \\\"{x:1446,y:896,t:1527877048482};\\\", \\\"{x:1448,y:898,t:1527877048500};\\\", \\\"{x:1450,y:901,t:1527877048516};\\\", \\\"{x:1450,y:905,t:1527877048533};\\\", \\\"{x:1451,y:909,t:1527877048550};\\\", \\\"{x:1452,y:910,t:1527877048566};\\\", \\\"{x:1453,y:910,t:1527877048585};\\\", \\\"{x:1454,y:910,t:1527877048609};\\\", \\\"{x:1455,y:910,t:1527877048673};\\\", \\\"{x:1456,y:912,t:1527877048698};\\\", \\\"{x:1457,y:912,t:1527877050418};\\\", \\\"{x:1457,y:911,t:1527877050425};\\\", \\\"{x:1457,y:908,t:1527877050437};\\\", \\\"{x:1451,y:902,t:1527877050454};\\\", \\\"{x:1444,y:893,t:1527877050471};\\\", \\\"{x:1437,y:885,t:1527877050487};\\\", \\\"{x:1433,y:880,t:1527877050504};\\\", \\\"{x:1428,y:874,t:1527877050520};\\\", \\\"{x:1426,y:869,t:1527877050536};\\\", \\\"{x:1420,y:861,t:1527877050554};\\\", \\\"{x:1414,y:851,t:1527877050571};\\\", \\\"{x:1408,y:841,t:1527877050587};\\\", \\\"{x:1400,y:834,t:1527877050603};\\\", \\\"{x:1395,y:828,t:1527877050620};\\\", \\\"{x:1384,y:820,t:1527877050637};\\\", \\\"{x:1368,y:807,t:1527877050653};\\\", \\\"{x:1351,y:794,t:1527877050670};\\\", \\\"{x:1338,y:782,t:1527877050687};\\\", \\\"{x:1327,y:765,t:1527877050705};\\\", \\\"{x:1323,y:756,t:1527877050720};\\\", \\\"{x:1323,y:750,t:1527877050737};\\\", \\\"{x:1321,y:743,t:1527877050754};\\\", \\\"{x:1320,y:737,t:1527877050770};\\\", \\\"{x:1320,y:731,t:1527877050787};\\\", \\\"{x:1320,y:723,t:1527877050805};\\\", \\\"{x:1319,y:713,t:1527877050821};\\\", \\\"{x:1319,y:708,t:1527877050838};\\\", \\\"{x:1319,y:705,t:1527877050854};\\\", \\\"{x:1321,y:700,t:1527877050871};\\\", \\\"{x:1322,y:695,t:1527877050887};\\\", \\\"{x:1325,y:688,t:1527877050904};\\\", \\\"{x:1328,y:685,t:1527877050921};\\\", \\\"{x:1329,y:683,t:1527877050937};\\\", \\\"{x:1329,y:682,t:1527877050954};\\\", \\\"{x:1331,y:681,t:1527877050972};\\\", \\\"{x:1332,y:679,t:1527877050988};\\\", \\\"{x:1332,y:677,t:1527877051004};\\\", \\\"{x:1334,y:675,t:1527877051022};\\\", \\\"{x:1334,y:670,t:1527877051039};\\\", \\\"{x:1334,y:667,t:1527877051055};\\\", \\\"{x:1334,y:665,t:1527877051071};\\\", \\\"{x:1334,y:661,t:1527877051088};\\\", \\\"{x:1333,y:660,t:1527877051104};\\\", \\\"{x:1331,y:658,t:1527877051122};\\\", \\\"{x:1325,y:653,t:1527877051138};\\\", \\\"{x:1318,y:646,t:1527877051155};\\\", \\\"{x:1316,y:643,t:1527877051171};\\\", \\\"{x:1315,y:640,t:1527877051188};\\\", \\\"{x:1314,y:634,t:1527877051205};\\\", \\\"{x:1314,y:620,t:1527877051221};\\\", \\\"{x:1312,y:609,t:1527877051239};\\\", \\\"{x:1309,y:596,t:1527877051255};\\\", \\\"{x:1308,y:589,t:1527877051271};\\\", \\\"{x:1308,y:586,t:1527877051288};\\\", \\\"{x:1308,y:584,t:1527877051328};\\\", \\\"{x:1306,y:582,t:1527877051353};\\\", \\\"{x:1306,y:581,t:1527877051361};\\\", \\\"{x:1304,y:580,t:1527877051372};\\\", \\\"{x:1301,y:577,t:1527877051388};\\\", \\\"{x:1300,y:577,t:1527877051425};\\\", \\\"{x:1299,y:577,t:1527877051449};\\\", \\\"{x:1298,y:577,t:1527877051465};\\\", \\\"{x:1295,y:577,t:1527877051473};\\\", \\\"{x:1290,y:578,t:1527877051488};\\\", \\\"{x:1285,y:581,t:1527877051505};\\\", \\\"{x:1283,y:582,t:1527877051522};\\\", \\\"{x:1279,y:586,t:1527877051539};\\\", \\\"{x:1277,y:590,t:1527877051556};\\\", \\\"{x:1273,y:598,t:1527877051572};\\\", \\\"{x:1267,y:606,t:1527877051590};\\\", \\\"{x:1262,y:613,t:1527877051606};\\\", \\\"{x:1257,y:623,t:1527877051623};\\\", \\\"{x:1252,y:633,t:1527877051639};\\\", \\\"{x:1247,y:655,t:1527877051656};\\\", \\\"{x:1246,y:673,t:1527877051672};\\\", \\\"{x:1246,y:684,t:1527877051690};\\\", \\\"{x:1246,y:692,t:1527877051707};\\\", \\\"{x:1244,y:705,t:1527877051722};\\\", \\\"{x:1242,y:723,t:1527877051739};\\\", \\\"{x:1236,y:747,t:1527877051757};\\\", \\\"{x:1232,y:769,t:1527877051773};\\\", \\\"{x:1224,y:790,t:1527877051789};\\\", \\\"{x:1215,y:807,t:1527877051806};\\\", \\\"{x:1204,y:830,t:1527877051824};\\\", \\\"{x:1191,y:856,t:1527877051840};\\\", \\\"{x:1164,y:902,t:1527877051856};\\\", \\\"{x:1146,y:926,t:1527877051873};\\\", \\\"{x:1125,y:955,t:1527877051889};\\\", \\\"{x:1110,y:973,t:1527877051907};\\\", \\\"{x:1102,y:985,t:1527877051924};\\\", \\\"{x:1100,y:992,t:1527877051940};\\\", \\\"{x:1099,y:997,t:1527877051957};\\\", \\\"{x:1098,y:1003,t:1527877051973};\\\", \\\"{x:1096,y:1006,t:1527877051990};\\\", \\\"{x:1093,y:1011,t:1527877052007};\\\", \\\"{x:1092,y:1013,t:1527877052023};\\\", \\\"{x:1094,y:1008,t:1527877052089};\\\", \\\"{x:1103,y:991,t:1527877052109};\\\", \\\"{x:1116,y:969,t:1527877052124};\\\", \\\"{x:1133,y:948,t:1527877052141};\\\", \\\"{x:1151,y:929,t:1527877052158};\\\", \\\"{x:1163,y:917,t:1527877052173};\\\", \\\"{x:1172,y:911,t:1527877052191};\\\", \\\"{x:1181,y:902,t:1527877052208};\\\", \\\"{x:1191,y:890,t:1527877052225};\\\", \\\"{x:1196,y:883,t:1527877052241};\\\", \\\"{x:1204,y:874,t:1527877052258};\\\", \\\"{x:1214,y:866,t:1527877052275};\\\", \\\"{x:1225,y:858,t:1527877052291};\\\", \\\"{x:1237,y:851,t:1527877052308};\\\", \\\"{x:1250,y:839,t:1527877052325};\\\", \\\"{x:1265,y:824,t:1527877052341};\\\", \\\"{x:1280,y:807,t:1527877052358};\\\", \\\"{x:1292,y:797,t:1527877052375};\\\", \\\"{x:1302,y:788,t:1527877052392};\\\", \\\"{x:1306,y:785,t:1527877052408};\\\", \\\"{x:1310,y:781,t:1527877052425};\\\", \\\"{x:1314,y:778,t:1527877052441};\\\", \\\"{x:1317,y:775,t:1527877052458};\\\", \\\"{x:1319,y:771,t:1527877052475};\\\", \\\"{x:1323,y:766,t:1527877052492};\\\", \\\"{x:1327,y:763,t:1527877052509};\\\", \\\"{x:1328,y:762,t:1527877052525};\\\", \\\"{x:1329,y:759,t:1527877052542};\\\", \\\"{x:1333,y:755,t:1527877052559};\\\", \\\"{x:1334,y:751,t:1527877052575};\\\", \\\"{x:1337,y:747,t:1527877052592};\\\", \\\"{x:1342,y:742,t:1527877052610};\\\", \\\"{x:1344,y:740,t:1527877052625};\\\", \\\"{x:1347,y:737,t:1527877052642};\\\", \\\"{x:1348,y:734,t:1527877052659};\\\", \\\"{x:1348,y:731,t:1527877052676};\\\", \\\"{x:1349,y:731,t:1527877052692};\\\", \\\"{x:1349,y:730,t:1527877052709};\\\", \\\"{x:1350,y:728,t:1527877052726};\\\", \\\"{x:1351,y:726,t:1527877052741};\\\", \\\"{x:1351,y:725,t:1527877052758};\\\", \\\"{x:1351,y:723,t:1527877052776};\\\", \\\"{x:1351,y:721,t:1527877052792};\\\", \\\"{x:1351,y:719,t:1527877052810};\\\", \\\"{x:1351,y:718,t:1527877052826};\\\", \\\"{x:1351,y:716,t:1527877052858};\\\", \\\"{x:1351,y:715,t:1527877052881};\\\", \\\"{x:1351,y:714,t:1527877052897};\\\", \\\"{x:1351,y:713,t:1527877052909};\\\", \\\"{x:1351,y:712,t:1527877052926};\\\", \\\"{x:1351,y:709,t:1527877052943};\\\", \\\"{x:1350,y:708,t:1527877052959};\\\", \\\"{x:1350,y:707,t:1527877052977};\\\", \\\"{x:1350,y:706,t:1527877053001};\\\", \\\"{x:1350,y:705,t:1527877053057};\\\", \\\"{x:1346,y:705,t:1527877053065};\\\", \\\"{x:1339,y:705,t:1527877053076};\\\", \\\"{x:1330,y:712,t:1527877053093};\\\", \\\"{x:1319,y:718,t:1527877053110};\\\", \\\"{x:1310,y:723,t:1527877053126};\\\", \\\"{x:1302,y:728,t:1527877053143};\\\", \\\"{x:1298,y:730,t:1527877053160};\\\", \\\"{x:1295,y:733,t:1527877053177};\\\", \\\"{x:1292,y:738,t:1527877053298};\\\", \\\"{x:1292,y:740,t:1527877053310};\\\", \\\"{x:1282,y:753,t:1527877053327};\\\", \\\"{x:1271,y:771,t:1527877053344};\\\", \\\"{x:1255,y:790,t:1527877053360};\\\", \\\"{x:1231,y:817,t:1527877053377};\\\", \\\"{x:1226,y:825,t:1527877053394};\\\", \\\"{x:1223,y:829,t:1527877053410};\\\", \\\"{x:1222,y:830,t:1527877053427};\\\", \\\"{x:1221,y:831,t:1527877053444};\\\", \\\"{x:1221,y:832,t:1527877053461};\\\", \\\"{x:1220,y:834,t:1527877053477};\\\", \\\"{x:1220,y:835,t:1527877053505};\\\", \\\"{x:1218,y:835,t:1527877053657};\\\", \\\"{x:1217,y:835,t:1527877053666};\\\", \\\"{x:1215,y:835,t:1527877053678};\\\", \\\"{x:1214,y:836,t:1527877053723};\\\", \\\"{x:1214,y:835,t:1527877053778};\\\", \\\"{x:1214,y:832,t:1527877053794};\\\", \\\"{x:1215,y:829,t:1527877053811};\\\", \\\"{x:1215,y:832,t:1527877053881};\\\", \\\"{x:1215,y:835,t:1527877053895};\\\", \\\"{x:1213,y:841,t:1527877053913};\\\", \\\"{x:1209,y:850,t:1527877053927};\\\", \\\"{x:1199,y:867,t:1527877053945};\\\", \\\"{x:1195,y:878,t:1527877053962};\\\", \\\"{x:1189,y:888,t:1527877053977};\\\", \\\"{x:1185,y:897,t:1527877053995};\\\", \\\"{x:1179,y:908,t:1527877054011};\\\", \\\"{x:1175,y:921,t:1527877054028};\\\", \\\"{x:1170,y:927,t:1527877054045};\\\", \\\"{x:1167,y:932,t:1527877054062};\\\", \\\"{x:1164,y:935,t:1527877054079};\\\", \\\"{x:1163,y:938,t:1527877054095};\\\", \\\"{x:1162,y:939,t:1527877054111};\\\", \\\"{x:1161,y:940,t:1527877054129};\\\", \\\"{x:1161,y:941,t:1527877054169};\\\", \\\"{x:1164,y:938,t:1527877054218};\\\", \\\"{x:1168,y:933,t:1527877054229};\\\", \\\"{x:1175,y:922,t:1527877054246};\\\", \\\"{x:1183,y:908,t:1527877054262};\\\", \\\"{x:1190,y:897,t:1527877054279};\\\", \\\"{x:1200,y:885,t:1527877054296};\\\", \\\"{x:1205,y:878,t:1527877054313};\\\", \\\"{x:1214,y:866,t:1527877054329};\\\", \\\"{x:1217,y:861,t:1527877054346};\\\", \\\"{x:1219,y:857,t:1527877054363};\\\", \\\"{x:1219,y:856,t:1527877054379};\\\", \\\"{x:1220,y:855,t:1527877054401};\\\", \\\"{x:1220,y:854,t:1527877054417};\\\", \\\"{x:1221,y:853,t:1527877054429};\\\", \\\"{x:1221,y:852,t:1527877054569};\\\", \\\"{x:1221,y:850,t:1527877054580};\\\", \\\"{x:1221,y:848,t:1527877054596};\\\", \\\"{x:1221,y:847,t:1527877054613};\\\", \\\"{x:1221,y:846,t:1527877054633};\\\", \\\"{x:1221,y:845,t:1527877054778};\\\", \\\"{x:1222,y:843,t:1527877054809};\\\", \\\"{x:1222,y:842,t:1527877054825};\\\", \\\"{x:1222,y:841,t:1527877054833};\\\", \\\"{x:1222,y:840,t:1527877054847};\\\", \\\"{x:1223,y:837,t:1527877054864};\\\", \\\"{x:1223,y:835,t:1527877054881};\\\", \\\"{x:1223,y:831,t:1527877054897};\\\", \\\"{x:1223,y:830,t:1527877054930};\\\", \\\"{x:1223,y:828,t:1527877054961};\\\", \\\"{x:1223,y:827,t:1527877055138};\\\", \\\"{x:1222,y:827,t:1527877055161};\\\", \\\"{x:1221,y:827,t:1527877055177};\\\", \\\"{x:1220,y:827,t:1527877055185};\\\", \\\"{x:1219,y:827,t:1527877055538};\\\", \\\"{x:1218,y:827,t:1527877055548};\\\", \\\"{x:1216,y:827,t:1527877055565};\\\", \\\"{x:1215,y:828,t:1527877055582};\\\", \\\"{x:1216,y:828,t:1527877057401};\\\", \\\"{x:1217,y:828,t:1527877057458};\\\", \\\"{x:1216,y:829,t:1527877057793};\\\", \\\"{x:1216,y:830,t:1527877057803};\\\", \\\"{x:1215,y:832,t:1527877057820};\\\", \\\"{x:1214,y:834,t:1527877057837};\\\", \\\"{x:1212,y:838,t:1527877057855};\\\", \\\"{x:1209,y:842,t:1527877057870};\\\", \\\"{x:1207,y:849,t:1527877057888};\\\", \\\"{x:1205,y:854,t:1527877057905};\\\", \\\"{x:1201,y:862,t:1527877057919};\\\", \\\"{x:1196,y:875,t:1527877057936};\\\", \\\"{x:1190,y:886,t:1527877057954};\\\", \\\"{x:1186,y:892,t:1527877057970};\\\", \\\"{x:1182,y:896,t:1527877057986};\\\", \\\"{x:1180,y:899,t:1527877058003};\\\", \\\"{x:1180,y:901,t:1527877058021};\\\", \\\"{x:1179,y:901,t:1527877058037};\\\", \\\"{x:1179,y:900,t:1527877058097};\\\", \\\"{x:1181,y:894,t:1527877058104};\\\", \\\"{x:1186,y:885,t:1527877058121};\\\", \\\"{x:1192,y:871,t:1527877058137};\\\", \\\"{x:1200,y:855,t:1527877058154};\\\", \\\"{x:1205,y:842,t:1527877058171};\\\", \\\"{x:1211,y:829,t:1527877058188};\\\", \\\"{x:1213,y:819,t:1527877058204};\\\", \\\"{x:1213,y:813,t:1527877058221};\\\", \\\"{x:1213,y:807,t:1527877058238};\\\", \\\"{x:1213,y:805,t:1527877058253};\\\", \\\"{x:1211,y:803,t:1527877058270};\\\", \\\"{x:1209,y:802,t:1527877058288};\\\", \\\"{x:1208,y:801,t:1527877058305};\\\", \\\"{x:1207,y:800,t:1527877058321};\\\", \\\"{x:1205,y:798,t:1527877058338};\\\", \\\"{x:1204,y:797,t:1527877058355};\\\", \\\"{x:1204,y:796,t:1527877058371};\\\", \\\"{x:1202,y:795,t:1527877058388};\\\", \\\"{x:1201,y:793,t:1527877058405};\\\", \\\"{x:1198,y:792,t:1527877058421};\\\", \\\"{x:1195,y:790,t:1527877058438};\\\", \\\"{x:1194,y:789,t:1527877058455};\\\", \\\"{x:1193,y:789,t:1527877058473};\\\", \\\"{x:1192,y:788,t:1527877058489};\\\", \\\"{x:1191,y:787,t:1527877058505};\\\", \\\"{x:1190,y:786,t:1527877058522};\\\", \\\"{x:1189,y:786,t:1527877058538};\\\", \\\"{x:1189,y:785,t:1527877058608};\\\", \\\"{x:1188,y:785,t:1527877058625};\\\", \\\"{x:1188,y:784,t:1527877058639};\\\", \\\"{x:1188,y:783,t:1527877058655};\\\", \\\"{x:1188,y:782,t:1527877058671};\\\", \\\"{x:1187,y:779,t:1527877058688};\\\", \\\"{x:1185,y:777,t:1527877058705};\\\", \\\"{x:1183,y:775,t:1527877058722};\\\", \\\"{x:1183,y:774,t:1527877058739};\\\", \\\"{x:1180,y:776,t:1527877058849};\\\", \\\"{x:1174,y:782,t:1527877058857};\\\", \\\"{x:1171,y:786,t:1527877058872};\\\", \\\"{x:1158,y:804,t:1527877058889};\\\", \\\"{x:1148,y:817,t:1527877058907};\\\", \\\"{x:1141,y:825,t:1527877058923};\\\", \\\"{x:1136,y:835,t:1527877058939};\\\", \\\"{x:1132,y:844,t:1527877058956};\\\", \\\"{x:1125,y:858,t:1527877058973};\\\", \\\"{x:1118,y:872,t:1527877058989};\\\", \\\"{x:1111,y:886,t:1527877059006};\\\", \\\"{x:1106,y:894,t:1527877059022};\\\", \\\"{x:1103,y:903,t:1527877059038};\\\", \\\"{x:1102,y:909,t:1527877059056};\\\", \\\"{x:1100,y:914,t:1527877059072};\\\", \\\"{x:1100,y:919,t:1527877059089};\\\", \\\"{x:1100,y:921,t:1527877059106};\\\", \\\"{x:1100,y:918,t:1527877059193};\\\", \\\"{x:1103,y:910,t:1527877059206};\\\", \\\"{x:1114,y:895,t:1527877059223};\\\", \\\"{x:1127,y:877,t:1527877059240};\\\", \\\"{x:1144,y:851,t:1527877059257};\\\", \\\"{x:1157,y:833,t:1527877059272};\\\", \\\"{x:1166,y:818,t:1527877059290};\\\", \\\"{x:1177,y:803,t:1527877059306};\\\", \\\"{x:1184,y:791,t:1527877059323};\\\", \\\"{x:1188,y:784,t:1527877059340};\\\", \\\"{x:1191,y:778,t:1527877059357};\\\", \\\"{x:1192,y:777,t:1527877059374};\\\", \\\"{x:1192,y:774,t:1527877059390};\\\", \\\"{x:1193,y:773,t:1527877059407};\\\", \\\"{x:1193,y:772,t:1527877059424};\\\", \\\"{x:1194,y:770,t:1527877059439};\\\", \\\"{x:1195,y:768,t:1527877059481};\\\", \\\"{x:1195,y:767,t:1527877059634};\\\", \\\"{x:1194,y:767,t:1527877059681};\\\", \\\"{x:1193,y:767,t:1527877059730};\\\", \\\"{x:1192,y:767,t:1527877059858};\\\", \\\"{x:1191,y:767,t:1527877059875};\\\", \\\"{x:1190,y:767,t:1527877059954};\\\", \\\"{x:1190,y:769,t:1527877060202};\\\", \\\"{x:1191,y:772,t:1527877060209};\\\", \\\"{x:1192,y:777,t:1527877060225};\\\", \\\"{x:1196,y:784,t:1527877060242};\\\", \\\"{x:1199,y:791,t:1527877060259};\\\", \\\"{x:1202,y:799,t:1527877060276};\\\", \\\"{x:1205,y:805,t:1527877060292};\\\", \\\"{x:1207,y:813,t:1527877060309};\\\", \\\"{x:1209,y:818,t:1527877060327};\\\", \\\"{x:1214,y:826,t:1527877060343};\\\", \\\"{x:1218,y:834,t:1527877060359};\\\", \\\"{x:1223,y:840,t:1527877060377};\\\", \\\"{x:1225,y:844,t:1527877060392};\\\", \\\"{x:1230,y:849,t:1527877060409};\\\", \\\"{x:1231,y:853,t:1527877060427};\\\", \\\"{x:1233,y:856,t:1527877060443};\\\", \\\"{x:1234,y:858,t:1527877060459};\\\", \\\"{x:1237,y:862,t:1527877060476};\\\", \\\"{x:1238,y:864,t:1527877060493};\\\", \\\"{x:1241,y:868,t:1527877060510};\\\", \\\"{x:1243,y:873,t:1527877060526};\\\", \\\"{x:1245,y:876,t:1527877060544};\\\", \\\"{x:1249,y:880,t:1527877060560};\\\", \\\"{x:1250,y:884,t:1527877060576};\\\", \\\"{x:1252,y:890,t:1527877060593};\\\", \\\"{x:1253,y:895,t:1527877060610};\\\", \\\"{x:1256,y:899,t:1527877060626};\\\", \\\"{x:1256,y:901,t:1527877060643};\\\", \\\"{x:1256,y:906,t:1527877060660};\\\", \\\"{x:1257,y:909,t:1527877060676};\\\", \\\"{x:1259,y:913,t:1527877060693};\\\", \\\"{x:1259,y:915,t:1527877060710};\\\", \\\"{x:1260,y:916,t:1527877060726};\\\", \\\"{x:1261,y:918,t:1527877060744};\\\", \\\"{x:1261,y:919,t:1527877060760};\\\", \\\"{x:1262,y:921,t:1527877060777};\\\", \\\"{x:1262,y:923,t:1527877060793};\\\", \\\"{x:1263,y:923,t:1527877060857};\\\", \\\"{x:1263,y:924,t:1527877060865};\\\", \\\"{x:1263,y:925,t:1527877060881};\\\", \\\"{x:1263,y:926,t:1527877060897};\\\", \\\"{x:1264,y:928,t:1527877060911};\\\", \\\"{x:1264,y:929,t:1527877060968};\\\", \\\"{x:1265,y:929,t:1527877062209};\\\", \\\"{x:1265,y:928,t:1527877062290};\\\", \\\"{x:1265,y:926,t:1527877062305};\\\", \\\"{x:1265,y:925,t:1527877062321};\\\", \\\"{x:1266,y:926,t:1527877062546};\\\", \\\"{x:1266,y:927,t:1527877062561};\\\", \\\"{x:1267,y:930,t:1527877062577};\\\", \\\"{x:1267,y:931,t:1527877062609};\\\", \\\"{x:1267,y:932,t:1527877062625};\\\", \\\"{x:1267,y:933,t:1527877062649};\\\", \\\"{x:1267,y:934,t:1527877062665};\\\", \\\"{x:1269,y:937,t:1527877062681};\\\", \\\"{x:1269,y:938,t:1527877062697};\\\", \\\"{x:1269,y:940,t:1527877062729};\\\", \\\"{x:1270,y:941,t:1527877062744};\\\", \\\"{x:1270,y:942,t:1527877062761};\\\", \\\"{x:1270,y:943,t:1527877062770};\\\", \\\"{x:1271,y:944,t:1527877062782};\\\", \\\"{x:1272,y:946,t:1527877062798};\\\", \\\"{x:1273,y:948,t:1527877062814};\\\", \\\"{x:1274,y:948,t:1527877062832};\\\", \\\"{x:1274,y:950,t:1527877062849};\\\", \\\"{x:1274,y:951,t:1527877062866};\\\", \\\"{x:1275,y:952,t:1527877062881};\\\", \\\"{x:1276,y:953,t:1527877062899};\\\", \\\"{x:1276,y:954,t:1527877062921};\\\", \\\"{x:1276,y:955,t:1527877062937};\\\", \\\"{x:1276,y:956,t:1527877062962};\\\", \\\"{x:1277,y:956,t:1527877062985};\\\", \\\"{x:1278,y:956,t:1527877062998};\\\", \\\"{x:1280,y:956,t:1527877063016};\\\", \\\"{x:1283,y:947,t:1527877063032};\\\", \\\"{x:1287,y:938,t:1527877063049};\\\", \\\"{x:1292,y:918,t:1527877063065};\\\", \\\"{x:1299,y:902,t:1527877063083};\\\", \\\"{x:1307,y:883,t:1527877063098};\\\", \\\"{x:1317,y:871,t:1527877063115};\\\", \\\"{x:1325,y:855,t:1527877063132};\\\", \\\"{x:1331,y:844,t:1527877063149};\\\", \\\"{x:1335,y:835,t:1527877063166};\\\", \\\"{x:1337,y:827,t:1527877063183};\\\", \\\"{x:1339,y:820,t:1527877063200};\\\", \\\"{x:1340,y:816,t:1527877063215};\\\", \\\"{x:1340,y:808,t:1527877063233};\\\", \\\"{x:1340,y:803,t:1527877063249};\\\", \\\"{x:1340,y:802,t:1527877063266};\\\", \\\"{x:1340,y:801,t:1527877063283};\\\", \\\"{x:1340,y:800,t:1527877063299};\\\", \\\"{x:1342,y:797,t:1527877063315};\\\", \\\"{x:1342,y:794,t:1527877063332};\\\", \\\"{x:1342,y:790,t:1527877063349};\\\", \\\"{x:1342,y:787,t:1527877063367};\\\", \\\"{x:1345,y:784,t:1527877063383};\\\", \\\"{x:1345,y:782,t:1527877063399};\\\", \\\"{x:1346,y:780,t:1527877063416};\\\", \\\"{x:1347,y:777,t:1527877063432};\\\", \\\"{x:1347,y:776,t:1527877063449};\\\", \\\"{x:1347,y:775,t:1527877063473};\\\", \\\"{x:1347,y:774,t:1527877063489};\\\", \\\"{x:1345,y:776,t:1527877063578};\\\", \\\"{x:1341,y:782,t:1527877063585};\\\", \\\"{x:1339,y:787,t:1527877063599};\\\", \\\"{x:1331,y:798,t:1527877063616};\\\", \\\"{x:1323,y:812,t:1527877063633};\\\", \\\"{x:1320,y:820,t:1527877063650};\\\", \\\"{x:1317,y:828,t:1527877063667};\\\", \\\"{x:1315,y:836,t:1527877063683};\\\", \\\"{x:1313,y:842,t:1527877063700};\\\", \\\"{x:1311,y:850,t:1527877063716};\\\", \\\"{x:1310,y:855,t:1527877063733};\\\", \\\"{x:1308,y:859,t:1527877063751};\\\", \\\"{x:1307,y:863,t:1527877063766};\\\", \\\"{x:1302,y:871,t:1527877063784};\\\", \\\"{x:1299,y:880,t:1527877063800};\\\", \\\"{x:1290,y:898,t:1527877063817};\\\", \\\"{x:1283,y:905,t:1527877063833};\\\", \\\"{x:1276,y:914,t:1527877063850};\\\", \\\"{x:1270,y:921,t:1527877063868};\\\", \\\"{x:1266,y:929,t:1527877063884};\\\", \\\"{x:1262,y:934,t:1527877063901};\\\", \\\"{x:1257,y:941,t:1527877063918};\\\", \\\"{x:1254,y:946,t:1527877063933};\\\", \\\"{x:1251,y:950,t:1527877063951};\\\", \\\"{x:1251,y:951,t:1527877063968};\\\", \\\"{x:1251,y:952,t:1527877063984};\\\", \\\"{x:1250,y:952,t:1527877064001};\\\", \\\"{x:1249,y:952,t:1527877064041};\\\", \\\"{x:1248,y:952,t:1527877064065};\\\", \\\"{x:1249,y:947,t:1527877064081};\\\", \\\"{x:1250,y:943,t:1527877064089};\\\", \\\"{x:1251,y:940,t:1527877064101};\\\", \\\"{x:1253,y:933,t:1527877064117};\\\", \\\"{x:1255,y:926,t:1527877064135};\\\", \\\"{x:1256,y:917,t:1527877064151};\\\", \\\"{x:1257,y:904,t:1527877064167};\\\", \\\"{x:1257,y:886,t:1527877064184};\\\", \\\"{x:1253,y:865,t:1527877064201};\\\", \\\"{x:1248,y:853,t:1527877064217};\\\", \\\"{x:1244,y:840,t:1527877064234};\\\", \\\"{x:1240,y:826,t:1527877064251};\\\", \\\"{x:1238,y:811,t:1527877064268};\\\", \\\"{x:1230,y:798,t:1527877064284};\\\", \\\"{x:1225,y:790,t:1527877064302};\\\", \\\"{x:1217,y:780,t:1527877064319};\\\", \\\"{x:1214,y:777,t:1527877064335};\\\", \\\"{x:1212,y:773,t:1527877064351};\\\", \\\"{x:1209,y:770,t:1527877064368};\\\", \\\"{x:1206,y:766,t:1527877064385};\\\", \\\"{x:1200,y:763,t:1527877064402};\\\", \\\"{x:1190,y:759,t:1527877064419};\\\", \\\"{x:1179,y:757,t:1527877064436};\\\", \\\"{x:1164,y:751,t:1527877064451};\\\", \\\"{x:1144,y:741,t:1527877064468};\\\", \\\"{x:1118,y:733,t:1527877064485};\\\", \\\"{x:1089,y:723,t:1527877064501};\\\", \\\"{x:1046,y:715,t:1527877064518};\\\", \\\"{x:1008,y:702,t:1527877064535};\\\", \\\"{x:925,y:686,t:1527877064552};\\\", \\\"{x:880,y:672,t:1527877064568};\\\", \\\"{x:851,y:663,t:1527877064584};\\\", \\\"{x:829,y:652,t:1527877064602};\\\", \\\"{x:821,y:649,t:1527877064618};\\\", \\\"{x:812,y:647,t:1527877064635};\\\", \\\"{x:808,y:644,t:1527877064651};\\\", \\\"{x:806,y:643,t:1527877064668};\\\", \\\"{x:806,y:641,t:1527877064704};\\\", \\\"{x:806,y:638,t:1527877064719};\\\", \\\"{x:809,y:629,t:1527877064735};\\\", \\\"{x:815,y:614,t:1527877064752};\\\", \\\"{x:815,y:612,t:1527877064769};\\\", \\\"{x:815,y:610,t:1527877064781};\\\", \\\"{x:815,y:608,t:1527877064797};\\\", \\\"{x:815,y:607,t:1527877064815};\\\", \\\"{x:815,y:606,t:1527877064831};\\\", \\\"{x:813,y:603,t:1527877064848};\\\", \\\"{x:790,y:603,t:1527877064864};\\\", \\\"{x:766,y:603,t:1527877064880};\\\", \\\"{x:733,y:600,t:1527877064899};\\\", \\\"{x:706,y:597,t:1527877064914};\\\", \\\"{x:671,y:597,t:1527877064931};\\\", \\\"{x:641,y:596,t:1527877064948};\\\", \\\"{x:599,y:591,t:1527877064964};\\\", \\\"{x:570,y:587,t:1527877064981};\\\", \\\"{x:548,y:587,t:1527877064997};\\\", \\\"{x:535,y:587,t:1527877065014};\\\", \\\"{x:526,y:587,t:1527877065031};\\\", \\\"{x:521,y:587,t:1527877065048};\\\", \\\"{x:520,y:587,t:1527877065063};\\\", \\\"{x:518,y:587,t:1527877065096};\\\", \\\"{x:514,y:587,t:1527877065104};\\\", \\\"{x:509,y:587,t:1527877065114};\\\", \\\"{x:494,y:587,t:1527877065132};\\\", \\\"{x:482,y:587,t:1527877065148};\\\", \\\"{x:468,y:588,t:1527877065164};\\\", \\\"{x:458,y:588,t:1527877065180};\\\", \\\"{x:452,y:589,t:1527877065198};\\\", \\\"{x:448,y:589,t:1527877065215};\\\", \\\"{x:444,y:590,t:1527877065231};\\\", \\\"{x:438,y:591,t:1527877065248};\\\", \\\"{x:421,y:598,t:1527877065266};\\\", \\\"{x:416,y:601,t:1527877065282};\\\", \\\"{x:415,y:601,t:1527877065298};\\\", \\\"{x:414,y:601,t:1527877065329};\\\", \\\"{x:413,y:601,t:1527877065336};\\\", \\\"{x:411,y:601,t:1527877065348};\\\", \\\"{x:406,y:602,t:1527877065365};\\\", \\\"{x:402,y:602,t:1527877065381};\\\", \\\"{x:396,y:602,t:1527877065398};\\\", \\\"{x:387,y:602,t:1527877065415};\\\", \\\"{x:365,y:602,t:1527877065431};\\\", \\\"{x:323,y:594,t:1527877065450};\\\", \\\"{x:295,y:587,t:1527877065465};\\\", \\\"{x:279,y:583,t:1527877065482};\\\", \\\"{x:272,y:581,t:1527877065498};\\\", \\\"{x:270,y:580,t:1527877065514};\\\", \\\"{x:269,y:580,t:1527877065608};\\\", \\\"{x:269,y:578,t:1527877065616};\\\", \\\"{x:269,y:575,t:1527877065632};\\\", \\\"{x:269,y:569,t:1527877065647};\\\", \\\"{x:271,y:564,t:1527877065664};\\\", \\\"{x:274,y:558,t:1527877065681};\\\", \\\"{x:278,y:554,t:1527877065698};\\\", \\\"{x:281,y:549,t:1527877065715};\\\", \\\"{x:282,y:548,t:1527877065731};\\\", \\\"{x:283,y:547,t:1527877065748};\\\", \\\"{x:282,y:544,t:1527877065765};\\\", \\\"{x:272,y:540,t:1527877065786};\\\", \\\"{x:257,y:535,t:1527877065797};\\\", \\\"{x:242,y:533,t:1527877065815};\\\", \\\"{x:220,y:530,t:1527877065831};\\\", \\\"{x:189,y:527,t:1527877065848};\\\", \\\"{x:177,y:522,t:1527877065865};\\\", \\\"{x:168,y:517,t:1527877065881};\\\", \\\"{x:158,y:512,t:1527877065898};\\\", \\\"{x:151,y:509,t:1527877065915};\\\", \\\"{x:149,y:507,t:1527877065932};\\\", \\\"{x:149,y:506,t:1527877066016};\\\", \\\"{x:150,y:505,t:1527877066048};\\\", \\\"{x:150,y:504,t:1527877066073};\\\", \\\"{x:151,y:504,t:1527877066082};\\\", \\\"{x:154,y:504,t:1527877066402};\\\", \\\"{x:157,y:504,t:1527877066415};\\\", \\\"{x:180,y:516,t:1527877066432};\\\", \\\"{x:201,y:528,t:1527877066448};\\\", \\\"{x:237,y:542,t:1527877066466};\\\", \\\"{x:287,y:563,t:1527877066482};\\\", \\\"{x:325,y:578,t:1527877066498};\\\", \\\"{x:357,y:588,t:1527877066516};\\\", \\\"{x:385,y:596,t:1527877066533};\\\", \\\"{x:413,y:610,t:1527877066549};\\\", \\\"{x:442,y:622,t:1527877066566};\\\", \\\"{x:468,y:631,t:1527877066581};\\\", \\\"{x:485,y:638,t:1527877066599};\\\", \\\"{x:502,y:651,t:1527877066616};\\\", \\\"{x:507,y:656,t:1527877066632};\\\", \\\"{x:515,y:666,t:1527877066648};\\\", \\\"{x:519,y:671,t:1527877066666};\\\", \\\"{x:524,y:678,t:1527877066682};\\\", \\\"{x:529,y:690,t:1527877066699};\\\", \\\"{x:532,y:695,t:1527877066716};\\\", \\\"{x:533,y:700,t:1527877066732};\\\", \\\"{x:537,y:708,t:1527877066749};\\\", \\\"{x:540,y:713,t:1527877066766};\\\", \\\"{x:543,y:714,t:1527877066782};\\\", \\\"{x:544,y:716,t:1527877066799};\\\", \\\"{x:544,y:717,t:1527877066816};\\\", \\\"{x:544,y:718,t:1527877066832};\\\", \\\"{x:543,y:718,t:1527877066864};\\\", \\\"{x:539,y:718,t:1527877066872};\\\", \\\"{x:533,y:718,t:1527877066883};\\\", \\\"{x:513,y:712,t:1527877066899};\\\", \\\"{x:492,y:702,t:1527877066916};\\\", \\\"{x:469,y:688,t:1527877066932};\\\", \\\"{x:437,y:671,t:1527877066949};\\\", \\\"{x:393,y:641,t:1527877066967};\\\", \\\"{x:344,y:614,t:1527877066983};\\\", \\\"{x:308,y:592,t:1527877066999};\\\", \\\"{x:277,y:570,t:1527877067015};\\\", \\\"{x:248,y:549,t:1527877067033};\\\", \\\"{x:232,y:540,t:1527877067049};\\\", \\\"{x:226,y:535,t:1527877067066};\\\", \\\"{x:223,y:532,t:1527877067083};\\\", \\\"{x:219,y:529,t:1527877067099};\\\", \\\"{x:213,y:524,t:1527877067116};\\\", \\\"{x:209,y:522,t:1527877067133};\\\", \\\"{x:206,y:521,t:1527877067216};\\\", \\\"{x:201,y:520,t:1527877067233};\\\", \\\"{x:199,y:518,t:1527877067250};\\\", \\\"{x:197,y:518,t:1527877067267};\\\", \\\"{x:193,y:517,t:1527877067284};\\\", \\\"{x:187,y:515,t:1527877067300};\\\", \\\"{x:186,y:515,t:1527877067317};\\\", \\\"{x:183,y:513,t:1527877067697};\\\", \\\"{x:180,y:513,t:1527877067705};\\\", \\\"{x:176,y:511,t:1527877067718};\\\", \\\"{x:171,y:509,t:1527877067733};\\\", \\\"{x:166,y:507,t:1527877067750};\\\", \\\"{x:159,y:504,t:1527877067767};\\\", \\\"{x:158,y:503,t:1527877067782};\\\", \\\"{x:158,y:502,t:1527877067984};\\\", \\\"{x:171,y:505,t:1527877067999};\\\", \\\"{x:196,y:516,t:1527877068017};\\\", \\\"{x:218,y:529,t:1527877068034};\\\", \\\"{x:240,y:538,t:1527877068050};\\\", \\\"{x:258,y:549,t:1527877068067};\\\", \\\"{x:283,y:565,t:1527877068083};\\\", \\\"{x:317,y:587,t:1527877068100};\\\", \\\"{x:359,y:615,t:1527877068118};\\\", \\\"{x:419,y:650,t:1527877068133};\\\", \\\"{x:466,y:678,t:1527877068150};\\\", \\\"{x:521,y:711,t:1527877068167};\\\", \\\"{x:574,y:745,t:1527877068184};\\\", \\\"{x:595,y:757,t:1527877068200};\\\", \\\"{x:608,y:771,t:1527877068217};\\\", \\\"{x:623,y:789,t:1527877068234};\\\", \\\"{x:636,y:798,t:1527877068250};\\\", \\\"{x:647,y:803,t:1527877068267};\\\", \\\"{x:653,y:804,t:1527877068283};\\\", \\\"{x:654,y:805,t:1527877068300};\\\", \\\"{x:655,y:805,t:1527877068317};\\\", \\\"{x:656,y:807,t:1527877068345};\\\", \\\"{x:651,y:805,t:1527877068409};\\\", \\\"{x:645,y:802,t:1527877068417};\\\", \\\"{x:627,y:795,t:1527877068434};\\\", \\\"{x:608,y:790,t:1527877068450};\\\", \\\"{x:594,y:786,t:1527877068468};\\\", \\\"{x:577,y:782,t:1527877068485};\\\", \\\"{x:568,y:779,t:1527877068500};\\\", \\\"{x:566,y:779,t:1527877068517};\\\", \\\"{x:565,y:777,t:1527877068537};\\\", \\\"{x:563,y:776,t:1527877068593};\\\", \\\"{x:559,y:775,t:1527877068601};\\\", \\\"{x:551,y:771,t:1527877068617};\\\", \\\"{x:536,y:764,t:1527877068634};\\\", \\\"{x:528,y:758,t:1527877068651};\\\", \\\"{x:523,y:754,t:1527877068667};\\\", \\\"{x:521,y:753,t:1527877068684};\\\", \\\"{x:521,y:752,t:1527877068699};\\\", \\\"{x:520,y:750,t:1527877068720};\\\", \\\"{x:519,y:750,t:1527877068736};\\\", \\\"{x:519,y:748,t:1527877068749};\\\", \\\"{x:518,y:748,t:1527877068768};\\\" ] }, { \\\"rt\\\": 13069, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 480638, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:748,t:1527877070808};\\\", \\\"{x:516,y:748,t:1527877070824};\\\", \\\"{x:515,y:748,t:1527877070840};\\\", \\\"{x:514,y:748,t:1527877070864};\\\", \\\"{x:513,y:748,t:1527877071072};\\\", \\\"{x:513,y:747,t:1527877071337};\\\", \\\"{x:513,y:745,t:1527877071360};\\\", \\\"{x:514,y:743,t:1527877071377};\\\", \\\"{x:516,y:741,t:1527877071386};\\\", \\\"{x:517,y:738,t:1527877071404};\\\", \\\"{x:518,y:737,t:1527877071419};\\\", \\\"{x:519,y:736,t:1527877071437};\\\", \\\"{x:519,y:735,t:1527877071454};\\\", \\\"{x:521,y:731,t:1527877071469};\\\", \\\"{x:523,y:728,t:1527877071486};\\\", \\\"{x:532,y:723,t:1527877071504};\\\", \\\"{x:539,y:721,t:1527877071519};\\\", \\\"{x:553,y:716,t:1527877071538};\\\", \\\"{x:573,y:709,t:1527877071554};\\\", \\\"{x:590,y:702,t:1527877071570};\\\", \\\"{x:595,y:699,t:1527877071586};\\\", \\\"{x:599,y:697,t:1527877071603};\\\", \\\"{x:601,y:696,t:1527877071619};\\\", \\\"{x:604,y:694,t:1527877071636};\\\", \\\"{x:608,y:691,t:1527877071653};\\\", \\\"{x:610,y:689,t:1527877071669};\\\", \\\"{x:612,y:688,t:1527877071686};\\\", \\\"{x:614,y:686,t:1527877071703};\\\", \\\"{x:615,y:686,t:1527877071720};\\\", \\\"{x:615,y:685,t:1527877071793};\\\", \\\"{x:616,y:684,t:1527877071803};\\\", \\\"{x:617,y:681,t:1527877071820};\\\", \\\"{x:618,y:680,t:1527877072386};\\\", \\\"{x:619,y:680,t:1527877072408};\\\", \\\"{x:620,y:680,t:1527877073529};\\\", \\\"{x:622,y:681,t:1527877073540};\\\", \\\"{x:623,y:681,t:1527877073555};\\\", \\\"{x:631,y:682,t:1527877073572};\\\", \\\"{x:647,y:683,t:1527877073589};\\\", \\\"{x:666,y:686,t:1527877073605};\\\", \\\"{x:686,y:691,t:1527877073623};\\\", \\\"{x:698,y:692,t:1527877073640};\\\", \\\"{x:728,y:698,t:1527877073656};\\\", \\\"{x:762,y:709,t:1527877073672};\\\", \\\"{x:789,y:714,t:1527877073690};\\\", \\\"{x:838,y:721,t:1527877073706};\\\", \\\"{x:891,y:731,t:1527877073723};\\\", \\\"{x:950,y:739,t:1527877073740};\\\", \\\"{x:1008,y:746,t:1527877073757};\\\", \\\"{x:1076,y:758,t:1527877073773};\\\", \\\"{x:1137,y:766,t:1527877073789};\\\", \\\"{x:1199,y:776,t:1527877073807};\\\", \\\"{x:1249,y:782,t:1527877073823};\\\", \\\"{x:1296,y:787,t:1527877073840};\\\", \\\"{x:1366,y:788,t:1527877073856};\\\", \\\"{x:1396,y:788,t:1527877073873};\\\", \\\"{x:1417,y:788,t:1527877073890};\\\", \\\"{x:1439,y:788,t:1527877073907};\\\", \\\"{x:1463,y:787,t:1527877073924};\\\", \\\"{x:1479,y:779,t:1527877073940};\\\", \\\"{x:1502,y:769,t:1527877073957};\\\", \\\"{x:1520,y:760,t:1527877073974};\\\", \\\"{x:1527,y:756,t:1527877073989};\\\", \\\"{x:1522,y:756,t:1527877074144};\\\", \\\"{x:1517,y:756,t:1527877074156};\\\", \\\"{x:1501,y:757,t:1527877074174};\\\", \\\"{x:1484,y:758,t:1527877074191};\\\", \\\"{x:1466,y:758,t:1527877074207};\\\", \\\"{x:1450,y:755,t:1527877074224};\\\", \\\"{x:1429,y:744,t:1527877074240};\\\", \\\"{x:1424,y:741,t:1527877074256};\\\", \\\"{x:1421,y:739,t:1527877074274};\\\", \\\"{x:1413,y:734,t:1527877074290};\\\", \\\"{x:1403,y:729,t:1527877074307};\\\", \\\"{x:1399,y:727,t:1527877074324};\\\", \\\"{x:1391,y:723,t:1527877074340};\\\", \\\"{x:1386,y:721,t:1527877074356};\\\", \\\"{x:1380,y:719,t:1527877074374};\\\", \\\"{x:1374,y:717,t:1527877074391};\\\", \\\"{x:1372,y:715,t:1527877074406};\\\", \\\"{x:1369,y:714,t:1527877074423};\\\", \\\"{x:1365,y:711,t:1527877074440};\\\", \\\"{x:1361,y:709,t:1527877074457};\\\", \\\"{x:1356,y:708,t:1527877074473};\\\", \\\"{x:1353,y:707,t:1527877074491};\\\", \\\"{x:1351,y:707,t:1527877074508};\\\", \\\"{x:1351,y:708,t:1527877074593};\\\", \\\"{x:1355,y:713,t:1527877074608};\\\", \\\"{x:1358,y:724,t:1527877074624};\\\", \\\"{x:1369,y:746,t:1527877074641};\\\", \\\"{x:1376,y:759,t:1527877074657};\\\", \\\"{x:1382,y:769,t:1527877074674};\\\", \\\"{x:1389,y:780,t:1527877074691};\\\", \\\"{x:1396,y:789,t:1527877074708};\\\", \\\"{x:1404,y:803,t:1527877074724};\\\", \\\"{x:1412,y:815,t:1527877074741};\\\", \\\"{x:1422,y:832,t:1527877074758};\\\", \\\"{x:1432,y:846,t:1527877074774};\\\", \\\"{x:1438,y:857,t:1527877074791};\\\", \\\"{x:1443,y:868,t:1527877074808};\\\", \\\"{x:1451,y:881,t:1527877074823};\\\", \\\"{x:1454,y:889,t:1527877074840};\\\", \\\"{x:1457,y:894,t:1527877074857};\\\", \\\"{x:1458,y:898,t:1527877074874};\\\", \\\"{x:1459,y:899,t:1527877074891};\\\", \\\"{x:1459,y:900,t:1527877074907};\\\", \\\"{x:1459,y:903,t:1527877074924};\\\", \\\"{x:1459,y:907,t:1527877074941};\\\", \\\"{x:1459,y:909,t:1527877074957};\\\", \\\"{x:1460,y:911,t:1527877074975};\\\", \\\"{x:1460,y:912,t:1527877074992};\\\", \\\"{x:1460,y:914,t:1527877075007};\\\", \\\"{x:1462,y:923,t:1527877075024};\\\", \\\"{x:1463,y:929,t:1527877075041};\\\", \\\"{x:1463,y:932,t:1527877075057};\\\", \\\"{x:1464,y:936,t:1527877075074};\\\", \\\"{x:1466,y:940,t:1527877075091};\\\", \\\"{x:1467,y:944,t:1527877075108};\\\", \\\"{x:1468,y:947,t:1527877075125};\\\", \\\"{x:1468,y:951,t:1527877075141};\\\", \\\"{x:1470,y:954,t:1527877075157};\\\", \\\"{x:1470,y:957,t:1527877075175};\\\", \\\"{x:1471,y:958,t:1527877075191};\\\", \\\"{x:1471,y:960,t:1527877075207};\\\", \\\"{x:1471,y:958,t:1527877075473};\\\", \\\"{x:1471,y:956,t:1527877075481};\\\", \\\"{x:1470,y:952,t:1527877075492};\\\", \\\"{x:1469,y:949,t:1527877075509};\\\", \\\"{x:1468,y:947,t:1527877075525};\\\", \\\"{x:1468,y:946,t:1527877075542};\\\", \\\"{x:1468,y:945,t:1527877075559};\\\", \\\"{x:1468,y:944,t:1527877075577};\\\", \\\"{x:1467,y:942,t:1527877075593};\\\", \\\"{x:1466,y:942,t:1527877075609};\\\", \\\"{x:1466,y:941,t:1527877075625};\\\", \\\"{x:1466,y:940,t:1527877075642};\\\", \\\"{x:1465,y:938,t:1527877075659};\\\", \\\"{x:1465,y:936,t:1527877075676};\\\", \\\"{x:1462,y:932,t:1527877075692};\\\", \\\"{x:1458,y:926,t:1527877075709};\\\", \\\"{x:1456,y:922,t:1527877075726};\\\", \\\"{x:1455,y:918,t:1527877075742};\\\", \\\"{x:1454,y:914,t:1527877075759};\\\", \\\"{x:1452,y:909,t:1527877075776};\\\", \\\"{x:1447,y:896,t:1527877075793};\\\", \\\"{x:1446,y:891,t:1527877075809};\\\", \\\"{x:1443,y:886,t:1527877075826};\\\", \\\"{x:1440,y:880,t:1527877075843};\\\", \\\"{x:1438,y:875,t:1527877075860};\\\", \\\"{x:1437,y:871,t:1527877075876};\\\", \\\"{x:1435,y:866,t:1527877075893};\\\", \\\"{x:1432,y:861,t:1527877075909};\\\", \\\"{x:1430,y:857,t:1527877075926};\\\", \\\"{x:1429,y:852,t:1527877075943};\\\", \\\"{x:1427,y:849,t:1527877075959};\\\", \\\"{x:1424,y:845,t:1527877075976};\\\", \\\"{x:1420,y:839,t:1527877075993};\\\", \\\"{x:1418,y:834,t:1527877076009};\\\", \\\"{x:1416,y:829,t:1527877076026};\\\", \\\"{x:1413,y:824,t:1527877076043};\\\", \\\"{x:1412,y:821,t:1527877076059};\\\", \\\"{x:1409,y:814,t:1527877076076};\\\", \\\"{x:1407,y:809,t:1527877076093};\\\", \\\"{x:1405,y:802,t:1527877076110};\\\", \\\"{x:1402,y:797,t:1527877076126};\\\", \\\"{x:1398,y:789,t:1527877076143};\\\", \\\"{x:1395,y:784,t:1527877076160};\\\", \\\"{x:1393,y:780,t:1527877076176};\\\", \\\"{x:1391,y:775,t:1527877076193};\\\", \\\"{x:1388,y:769,t:1527877076210};\\\", \\\"{x:1382,y:758,t:1527877076226};\\\", \\\"{x:1377,y:749,t:1527877076243};\\\", \\\"{x:1372,y:741,t:1527877076259};\\\", \\\"{x:1364,y:730,t:1527877076275};\\\", \\\"{x:1354,y:719,t:1527877076293};\\\", \\\"{x:1342,y:710,t:1527877076310};\\\", \\\"{x:1335,y:703,t:1527877076326};\\\", \\\"{x:1328,y:698,t:1527877076343};\\\", \\\"{x:1324,y:694,t:1527877076360};\\\", \\\"{x:1321,y:692,t:1527877076376};\\\", \\\"{x:1318,y:689,t:1527877076393};\\\", \\\"{x:1316,y:685,t:1527877076410};\\\", \\\"{x:1313,y:680,t:1527877076427};\\\", \\\"{x:1310,y:678,t:1527877076443};\\\", \\\"{x:1303,y:667,t:1527877076459};\\\", \\\"{x:1295,y:654,t:1527877076476};\\\", \\\"{x:1287,y:645,t:1527877076493};\\\", \\\"{x:1284,y:639,t:1527877076510};\\\", \\\"{x:1282,y:636,t:1527877076526};\\\", \\\"{x:1281,y:629,t:1527877076543};\\\", \\\"{x:1280,y:624,t:1527877076559};\\\", \\\"{x:1279,y:613,t:1527877076577};\\\", \\\"{x:1279,y:608,t:1527877076593};\\\", \\\"{x:1277,y:602,t:1527877076610};\\\", \\\"{x:1275,y:595,t:1527877076627};\\\", \\\"{x:1275,y:593,t:1527877076644};\\\", \\\"{x:1274,y:591,t:1527877076660};\\\", \\\"{x:1274,y:589,t:1527877076677};\\\", \\\"{x:1274,y:586,t:1527877076694};\\\", \\\"{x:1274,y:583,t:1527877076710};\\\", \\\"{x:1274,y:581,t:1527877076727};\\\", \\\"{x:1272,y:579,t:1527877076744};\\\", \\\"{x:1272,y:578,t:1527877076759};\\\", \\\"{x:1272,y:577,t:1527877076793};\\\", \\\"{x:1272,y:575,t:1527877076810};\\\", \\\"{x:1272,y:574,t:1527877076827};\\\", \\\"{x:1272,y:571,t:1527877076844};\\\", \\\"{x:1272,y:570,t:1527877076929};\\\", \\\"{x:1267,y:570,t:1527877076944};\\\", \\\"{x:1241,y:571,t:1527877076961};\\\", \\\"{x:1190,y:579,t:1527877076976};\\\", \\\"{x:1107,y:588,t:1527877076994};\\\", \\\"{x:1018,y:588,t:1527877077012};\\\", \\\"{x:902,y:588,t:1527877077028};\\\", \\\"{x:805,y:588,t:1527877077043};\\\", \\\"{x:723,y:586,t:1527877077061};\\\", \\\"{x:665,y:577,t:1527877077074};\\\", \\\"{x:616,y:568,t:1527877077090};\\\", \\\"{x:593,y:563,t:1527877077108};\\\", \\\"{x:576,y:558,t:1527877077124};\\\", \\\"{x:560,y:556,t:1527877077140};\\\", \\\"{x:557,y:555,t:1527877077158};\\\", \\\"{x:554,y:555,t:1527877077174};\\\", \\\"{x:551,y:555,t:1527877077191};\\\", \\\"{x:550,y:555,t:1527877077208};\\\", \\\"{x:550,y:553,t:1527877077288};\\\", \\\"{x:551,y:552,t:1527877077295};\\\", \\\"{x:554,y:551,t:1527877077307};\\\", \\\"{x:557,y:547,t:1527877077325};\\\", \\\"{x:564,y:542,t:1527877077340};\\\", \\\"{x:571,y:538,t:1527877077358};\\\", \\\"{x:576,y:535,t:1527877077375};\\\", \\\"{x:581,y:532,t:1527877077390};\\\", \\\"{x:583,y:530,t:1527877077407};\\\", \\\"{x:586,y:527,t:1527877077424};\\\", \\\"{x:589,y:524,t:1527877077441};\\\", \\\"{x:591,y:521,t:1527877077457};\\\", \\\"{x:592,y:520,t:1527877077474};\\\", \\\"{x:593,y:518,t:1527877077491};\\\", \\\"{x:593,y:517,t:1527877077529};\\\", \\\"{x:593,y:514,t:1527877077542};\\\", \\\"{x:594,y:514,t:1527877077557};\\\", \\\"{x:596,y:512,t:1527877077574};\\\", \\\"{x:596,y:511,t:1527877077591};\\\", \\\"{x:597,y:509,t:1527877077624};\\\", \\\"{x:600,y:507,t:1527877077642};\\\", \\\"{x:604,y:504,t:1527877077658};\\\", \\\"{x:607,y:502,t:1527877077674};\\\", \\\"{x:607,y:501,t:1527877077691};\\\", \\\"{x:611,y:501,t:1527877078105};\\\", \\\"{x:637,y:508,t:1527877078113};\\\", \\\"{x:666,y:513,t:1527877078125};\\\", \\\"{x:747,y:525,t:1527877078143};\\\", \\\"{x:826,y:538,t:1527877078159};\\\", \\\"{x:918,y:554,t:1527877078175};\\\", \\\"{x:1021,y:570,t:1527877078193};\\\", \\\"{x:1118,y:587,t:1527877078209};\\\", \\\"{x:1168,y:593,t:1527877078225};\\\", \\\"{x:1214,y:602,t:1527877078241};\\\", \\\"{x:1246,y:607,t:1527877078259};\\\", \\\"{x:1274,y:611,t:1527877078275};\\\", \\\"{x:1296,y:611,t:1527877078291};\\\", \\\"{x:1313,y:612,t:1527877078309};\\\", \\\"{x:1324,y:612,t:1527877078324};\\\", \\\"{x:1331,y:612,t:1527877078341};\\\", \\\"{x:1336,y:611,t:1527877078358};\\\", \\\"{x:1341,y:610,t:1527877078375};\\\", \\\"{x:1344,y:608,t:1527877078391};\\\", \\\"{x:1345,y:608,t:1527877078408};\\\", \\\"{x:1347,y:606,t:1527877078424};\\\", \\\"{x:1348,y:606,t:1527877078514};\\\", \\\"{x:1349,y:606,t:1527877078525};\\\", \\\"{x:1350,y:606,t:1527877078541};\\\", \\\"{x:1352,y:605,t:1527877078558};\\\", \\\"{x:1354,y:604,t:1527877078576};\\\", \\\"{x:1359,y:600,t:1527877078593};\\\", \\\"{x:1360,y:600,t:1527877078608};\\\", \\\"{x:1364,y:597,t:1527877078624};\\\", \\\"{x:1365,y:596,t:1527877078641};\\\", \\\"{x:1368,y:595,t:1527877078658};\\\", \\\"{x:1370,y:594,t:1527877078673};\\\", \\\"{x:1371,y:593,t:1527877078696};\\\", \\\"{x:1373,y:593,t:1527877079176};\\\", \\\"{x:1376,y:590,t:1527877079189};\\\", \\\"{x:1377,y:590,t:1527877079206};\\\", \\\"{x:1380,y:590,t:1527877079222};\\\", \\\"{x:1380,y:589,t:1527877079239};\\\", \\\"{x:1381,y:589,t:1527877079818};\\\", \\\"{x:1382,y:588,t:1527877079825};\\\", \\\"{x:1383,y:588,t:1527877079839};\\\", \\\"{x:1384,y:587,t:1527877079855};\\\", \\\"{x:1386,y:587,t:1527877079872};\\\", \\\"{x:1387,y:587,t:1527877079889};\\\", \\\"{x:1388,y:586,t:1527877079961};\\\", \\\"{x:1387,y:585,t:1527877080801};\\\", \\\"{x:1386,y:585,t:1527877080809};\\\", \\\"{x:1386,y:584,t:1527877080821};\\\", \\\"{x:1385,y:584,t:1527877080838};\\\", \\\"{x:1383,y:584,t:1527877080854};\\\", \\\"{x:1381,y:584,t:1527877080870};\\\", \\\"{x:1371,y:586,t:1527877080887};\\\", \\\"{x:1362,y:591,t:1527877080903};\\\", \\\"{x:1353,y:596,t:1527877080920};\\\", \\\"{x:1346,y:602,t:1527877080936};\\\", \\\"{x:1343,y:607,t:1527877080953};\\\", \\\"{x:1343,y:610,t:1527877080969};\\\", \\\"{x:1341,y:614,t:1527877080986};\\\", \\\"{x:1341,y:624,t:1527877081003};\\\", \\\"{x:1345,y:638,t:1527877081020};\\\", \\\"{x:1351,y:651,t:1527877081036};\\\", \\\"{x:1358,y:664,t:1527877081053};\\\", \\\"{x:1363,y:674,t:1527877081070};\\\", \\\"{x:1367,y:683,t:1527877081086};\\\", \\\"{x:1370,y:693,t:1527877081103};\\\", \\\"{x:1372,y:702,t:1527877081120};\\\", \\\"{x:1372,y:708,t:1527877081136};\\\", \\\"{x:1372,y:712,t:1527877081152};\\\", \\\"{x:1372,y:714,t:1527877081216};\\\", \\\"{x:1370,y:714,t:1527877081224};\\\", \\\"{x:1368,y:716,t:1527877081235};\\\", \\\"{x:1365,y:716,t:1527877081252};\\\", \\\"{x:1364,y:716,t:1527877081313};\\\", \\\"{x:1362,y:716,t:1527877081328};\\\", \\\"{x:1361,y:716,t:1527877081336};\\\", \\\"{x:1360,y:716,t:1527877081352};\\\", \\\"{x:1358,y:715,t:1527877081369};\\\", \\\"{x:1357,y:713,t:1527877081386};\\\", \\\"{x:1356,y:713,t:1527877081403};\\\", \\\"{x:1355,y:712,t:1527877081419};\\\", \\\"{x:1355,y:710,t:1527877081498};\\\", \\\"{x:1355,y:707,t:1527877081505};\\\", \\\"{x:1355,y:705,t:1527877081520};\\\", \\\"{x:1357,y:699,t:1527877081535};\\\", \\\"{x:1359,y:691,t:1527877081552};\\\", \\\"{x:1364,y:679,t:1527877081569};\\\", \\\"{x:1372,y:657,t:1527877081585};\\\", \\\"{x:1378,y:643,t:1527877081602};\\\", \\\"{x:1384,y:629,t:1527877081619};\\\", \\\"{x:1390,y:607,t:1527877081635};\\\", \\\"{x:1392,y:581,t:1527877081652};\\\", \\\"{x:1396,y:567,t:1527877081668};\\\", \\\"{x:1398,y:555,t:1527877081685};\\\", \\\"{x:1398,y:551,t:1527877081702};\\\", \\\"{x:1400,y:545,t:1527877081718};\\\", \\\"{x:1401,y:536,t:1527877081736};\\\", \\\"{x:1401,y:529,t:1527877081752};\\\", \\\"{x:1401,y:521,t:1527877081769};\\\", \\\"{x:1401,y:511,t:1527877081784};\\\", \\\"{x:1399,y:504,t:1527877081803};\\\", \\\"{x:1393,y:500,t:1527877081818};\\\", \\\"{x:1388,y:499,t:1527877081835};\\\", \\\"{x:1386,y:499,t:1527877081851};\\\", \\\"{x:1385,y:498,t:1527877081880};\\\", \\\"{x:1384,y:496,t:1527877081889};\\\", \\\"{x:1383,y:495,t:1527877081901};\\\", \\\"{x:1381,y:492,t:1527877081918};\\\", \\\"{x:1380,y:489,t:1527877081935};\\\", \\\"{x:1380,y:481,t:1527877081952};\\\", \\\"{x:1379,y:462,t:1527877081969};\\\", \\\"{x:1379,y:458,t:1527877081984};\\\", \\\"{x:1379,y:448,t:1527877082001};\\\", \\\"{x:1381,y:441,t:1527877082019};\\\", \\\"{x:1383,y:433,t:1527877082034};\\\", \\\"{x:1386,y:426,t:1527877082051};\\\", \\\"{x:1386,y:421,t:1527877082068};\\\", \\\"{x:1386,y:419,t:1527877082084};\\\", \\\"{x:1386,y:418,t:1527877082101};\\\", \\\"{x:1386,y:420,t:1527877082154};\\\", \\\"{x:1388,y:429,t:1527877082167};\\\", \\\"{x:1399,y:458,t:1527877082184};\\\", \\\"{x:1409,y:478,t:1527877082200};\\\", \\\"{x:1417,y:500,t:1527877082218};\\\", \\\"{x:1426,y:518,t:1527877082234};\\\", \\\"{x:1435,y:547,t:1527877082251};\\\", \\\"{x:1443,y:573,t:1527877082268};\\\", \\\"{x:1449,y:595,t:1527877082284};\\\", \\\"{x:1457,y:613,t:1527877082301};\\\", \\\"{x:1465,y:631,t:1527877082322};\\\", \\\"{x:1475,y:650,t:1527877082339};\\\", \\\"{x:1485,y:668,t:1527877082355};\\\", \\\"{x:1493,y:688,t:1527877082372};\\\", \\\"{x:1499,y:716,t:1527877082389};\\\", \\\"{x:1505,y:731,t:1527877082406};\\\", \\\"{x:1509,y:747,t:1527877082422};\\\", \\\"{x:1515,y:763,t:1527877082440};\\\", \\\"{x:1523,y:774,t:1527877082456};\\\", \\\"{x:1529,y:778,t:1527877082472};\\\", \\\"{x:1536,y:781,t:1527877082488};\\\", \\\"{x:1547,y:787,t:1527877082505};\\\", \\\"{x:1557,y:800,t:1527877082523};\\\", \\\"{x:1573,y:817,t:1527877082539};\\\", \\\"{x:1585,y:833,t:1527877082556};\\\", \\\"{x:1599,y:852,t:1527877082572};\\\", \\\"{x:1608,y:870,t:1527877082588};\\\", \\\"{x:1620,y:888,t:1527877082606};\\\", \\\"{x:1625,y:895,t:1527877082622};\\\", \\\"{x:1628,y:900,t:1527877082638};\\\", \\\"{x:1629,y:901,t:1527877082702};\\\", \\\"{x:1629,y:902,t:1527877082710};\\\", \\\"{x:1629,y:903,t:1527877082721};\\\", \\\"{x:1629,y:907,t:1527877082739};\\\", \\\"{x:1627,y:912,t:1527877082756};\\\", \\\"{x:1623,y:915,t:1527877082772};\\\", \\\"{x:1615,y:919,t:1527877082789};\\\", \\\"{x:1608,y:924,t:1527877082805};\\\", \\\"{x:1597,y:930,t:1527877082822};\\\", \\\"{x:1548,y:938,t:1527877082839};\\\", \\\"{x:1486,y:941,t:1527877082855};\\\", \\\"{x:1418,y:943,t:1527877082872};\\\", \\\"{x:1358,y:948,t:1527877082889};\\\", \\\"{x:1304,y:949,t:1527877082905};\\\", \\\"{x:1249,y:949,t:1527877082922};\\\", \\\"{x:1185,y:949,t:1527877082939};\\\", \\\"{x:1126,y:949,t:1527877082955};\\\", \\\"{x:1076,y:944,t:1527877082972};\\\", \\\"{x:1017,y:936,t:1527877082988};\\\", \\\"{x:951,y:916,t:1527877083005};\\\", \\\"{x:891,y:896,t:1527877083021};\\\", \\\"{x:850,y:880,t:1527877083037};\\\", \\\"{x:812,y:867,t:1527877083055};\\\", \\\"{x:805,y:862,t:1527877083071};\\\", \\\"{x:804,y:860,t:1527877083088};\\\", \\\"{x:804,y:848,t:1527877083105};\\\", \\\"{x:804,y:832,t:1527877083121};\\\", \\\"{x:804,y:826,t:1527877083137};\\\", \\\"{x:804,y:825,t:1527877083155};\\\", \\\"{x:800,y:823,t:1527877083170};\\\", \\\"{x:795,y:821,t:1527877083187};\\\", \\\"{x:787,y:818,t:1527877083205};\\\", \\\"{x:775,y:814,t:1527877083220};\\\", \\\"{x:744,y:804,t:1527877083239};\\\", \\\"{x:712,y:798,t:1527877083254};\\\", \\\"{x:664,y:789,t:1527877083271};\\\", \\\"{x:619,y:783,t:1527877083288};\\\", \\\"{x:581,y:774,t:1527877083304};\\\", \\\"{x:557,y:768,t:1527877083321};\\\", \\\"{x:532,y:757,t:1527877083338};\\\", \\\"{x:514,y:750,t:1527877083357};\\\", \\\"{x:505,y:745,t:1527877083370};\\\", \\\"{x:500,y:741,t:1527877083388};\\\", \\\"{x:499,y:741,t:1527877083401};\\\", \\\"{x:499,y:740,t:1527877083418};\\\", \\\"{x:498,y:739,t:1527877083470};\\\" ] }, { \\\"rt\\\": 11769, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 493647, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-01 PM-11 AM-M -M -L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:740,t:1527877084878};\\\", \\\"{x:500,y:741,t:1527877084893};\\\", \\\"{x:501,y:742,t:1527877084925};\\\", \\\"{x:502,y:742,t:1527877084935};\\\", \\\"{x:503,y:742,t:1527877085382};\\\", \\\"{x:506,y:742,t:1527877085404};\\\", \\\"{x:508,y:742,t:1527877085420};\\\", \\\"{x:516,y:737,t:1527877085437};\\\", \\\"{x:526,y:736,t:1527877085455};\\\", \\\"{x:542,y:731,t:1527877085471};\\\", \\\"{x:564,y:726,t:1527877085487};\\\", \\\"{x:585,y:723,t:1527877085505};\\\", \\\"{x:602,y:716,t:1527877085521};\\\", \\\"{x:619,y:714,t:1527877085536};\\\", \\\"{x:634,y:711,t:1527877085553};\\\", \\\"{x:648,y:710,t:1527877085569};\\\", \\\"{x:659,y:707,t:1527877085586};\\\", \\\"{x:674,y:705,t:1527877085603};\\\", \\\"{x:683,y:704,t:1527877085620};\\\", \\\"{x:695,y:701,t:1527877085636};\\\", \\\"{x:709,y:697,t:1527877085654};\\\", \\\"{x:720,y:693,t:1527877085670};\\\", \\\"{x:727,y:691,t:1527877085686};\\\", \\\"{x:734,y:689,t:1527877085703};\\\", \\\"{x:744,y:688,t:1527877085720};\\\", \\\"{x:756,y:687,t:1527877085737};\\\", \\\"{x:778,y:687,t:1527877085754};\\\", \\\"{x:787,y:682,t:1527877085769};\\\", \\\"{x:788,y:681,t:1527877085786};\\\", \\\"{x:788,y:679,t:1527877086095};\\\", \\\"{x:791,y:679,t:1527877086104};\\\", \\\"{x:815,y:686,t:1527877086121};\\\", \\\"{x:872,y:704,t:1527877086138};\\\", \\\"{x:962,y:725,t:1527877086154};\\\", \\\"{x:1054,y:752,t:1527877086172};\\\", \\\"{x:1112,y:778,t:1527877086187};\\\", \\\"{x:1162,y:801,t:1527877086204};\\\", \\\"{x:1217,y:824,t:1527877086221};\\\", \\\"{x:1269,y:856,t:1527877086237};\\\", \\\"{x:1321,y:895,t:1527877086254};\\\", \\\"{x:1342,y:913,t:1527877086270};\\\", \\\"{x:1365,y:927,t:1527877086289};\\\", \\\"{x:1381,y:937,t:1527877086305};\\\", \\\"{x:1400,y:945,t:1527877086321};\\\", \\\"{x:1413,y:951,t:1527877086338};\\\", \\\"{x:1423,y:956,t:1527877086354};\\\", \\\"{x:1429,y:960,t:1527877086371};\\\", \\\"{x:1434,y:962,t:1527877086388};\\\", \\\"{x:1437,y:963,t:1527877086405};\\\", \\\"{x:1440,y:964,t:1527877086421};\\\", \\\"{x:1442,y:965,t:1527877086438};\\\", \\\"{x:1451,y:968,t:1527877086454};\\\", \\\"{x:1456,y:970,t:1527877086470};\\\", \\\"{x:1460,y:971,t:1527877086487};\\\", \\\"{x:1463,y:971,t:1527877086504};\\\", \\\"{x:1467,y:973,t:1527877086520};\\\", \\\"{x:1469,y:973,t:1527877086538};\\\", \\\"{x:1471,y:975,t:1527877086554};\\\", \\\"{x:1472,y:975,t:1527877087063};\\\", \\\"{x:1472,y:976,t:1527877087086};\\\", \\\"{x:1469,y:977,t:1527877087094};\\\", \\\"{x:1464,y:977,t:1527877087104};\\\", \\\"{x:1450,y:979,t:1527877087122};\\\", \\\"{x:1436,y:980,t:1527877087138};\\\", \\\"{x:1421,y:982,t:1527877087155};\\\", \\\"{x:1410,y:984,t:1527877087171};\\\", \\\"{x:1398,y:984,t:1527877087188};\\\", \\\"{x:1382,y:984,t:1527877087205};\\\", \\\"{x:1370,y:984,t:1527877087221};\\\", \\\"{x:1357,y:985,t:1527877087238};\\\", \\\"{x:1353,y:985,t:1527877087254};\\\", \\\"{x:1346,y:985,t:1527877087271};\\\", \\\"{x:1339,y:985,t:1527877087288};\\\", \\\"{x:1333,y:985,t:1527877087305};\\\", \\\"{x:1328,y:985,t:1527877087322};\\\", \\\"{x:1322,y:985,t:1527877087338};\\\", \\\"{x:1315,y:982,t:1527877087355};\\\", \\\"{x:1310,y:981,t:1527877087372};\\\", \\\"{x:1304,y:981,t:1527877087387};\\\", \\\"{x:1300,y:981,t:1527877087405};\\\", \\\"{x:1296,y:980,t:1527877087422};\\\", \\\"{x:1292,y:979,t:1527877087438};\\\", \\\"{x:1289,y:979,t:1527877087455};\\\", \\\"{x:1282,y:979,t:1527877087472};\\\", \\\"{x:1278,y:979,t:1527877087488};\\\", \\\"{x:1274,y:979,t:1527877087505};\\\", \\\"{x:1271,y:979,t:1527877087522};\\\", \\\"{x:1268,y:979,t:1527877087538};\\\", \\\"{x:1265,y:979,t:1527877087555};\\\", \\\"{x:1264,y:979,t:1527877087571};\\\", \\\"{x:1262,y:979,t:1527877087588};\\\", \\\"{x:1263,y:977,t:1527877087679};\\\", \\\"{x:1264,y:977,t:1527877087688};\\\", \\\"{x:1268,y:975,t:1527877087705};\\\", \\\"{x:1272,y:974,t:1527877087722};\\\", \\\"{x:1277,y:973,t:1527877087738};\\\", \\\"{x:1279,y:973,t:1527877087755};\\\", \\\"{x:1280,y:972,t:1527877087772};\\\", \\\"{x:1281,y:972,t:1527877087863};\\\", \\\"{x:1282,y:972,t:1527877087872};\\\", \\\"{x:1284,y:972,t:1527877087888};\\\", \\\"{x:1287,y:970,t:1527877087904};\\\", \\\"{x:1293,y:968,t:1527877087922};\\\", \\\"{x:1297,y:965,t:1527877087939};\\\", \\\"{x:1304,y:964,t:1527877087955};\\\", \\\"{x:1315,y:960,t:1527877087972};\\\", \\\"{x:1322,y:960,t:1527877087989};\\\", \\\"{x:1325,y:960,t:1527877088005};\\\", \\\"{x:1329,y:960,t:1527877088021};\\\", \\\"{x:1330,y:960,t:1527877088077};\\\", \\\"{x:1331,y:960,t:1527877088089};\\\", \\\"{x:1332,y:960,t:1527877088105};\\\", \\\"{x:1333,y:961,t:1527877088142};\\\", \\\"{x:1334,y:962,t:1527877088183};\\\", \\\"{x:1335,y:962,t:1527877088391};\\\", \\\"{x:1337,y:963,t:1527877088407};\\\", \\\"{x:1338,y:963,t:1527877088423};\\\", \\\"{x:1339,y:963,t:1527877088439};\\\", \\\"{x:1340,y:964,t:1527877088456};\\\", \\\"{x:1341,y:964,t:1527877088473};\\\", \\\"{x:1342,y:964,t:1527877088495};\\\", \\\"{x:1344,y:964,t:1527877088518};\\\", \\\"{x:1345,y:964,t:1527877088607};\\\", \\\"{x:1346,y:964,t:1527877088622};\\\", \\\"{x:1347,y:964,t:1527877088639};\\\", \\\"{x:1348,y:962,t:1527877088656};\\\", \\\"{x:1349,y:961,t:1527877088673};\\\", \\\"{x:1349,y:960,t:1527877088689};\\\", \\\"{x:1350,y:960,t:1527877088706};\\\", \\\"{x:1352,y:958,t:1527877088723};\\\", \\\"{x:1353,y:957,t:1527877088742};\\\", \\\"{x:1353,y:956,t:1527877088767};\\\", \\\"{x:1354,y:955,t:1527877088774};\\\", \\\"{x:1355,y:954,t:1527877088798};\\\", \\\"{x:1356,y:954,t:1527877088806};\\\", \\\"{x:1356,y:952,t:1527877088831};\\\", \\\"{x:1357,y:952,t:1527877088847};\\\", \\\"{x:1357,y:951,t:1527877088856};\\\", \\\"{x:1357,y:949,t:1527877088873};\\\", \\\"{x:1360,y:945,t:1527877088889};\\\", \\\"{x:1361,y:943,t:1527877088906};\\\", \\\"{x:1363,y:940,t:1527877088922};\\\", \\\"{x:1364,y:938,t:1527877088939};\\\", \\\"{x:1365,y:934,t:1527877088956};\\\", \\\"{x:1367,y:931,t:1527877088973};\\\", \\\"{x:1368,y:927,t:1527877088988};\\\", \\\"{x:1369,y:925,t:1527877089006};\\\", \\\"{x:1369,y:924,t:1527877089022};\\\", \\\"{x:1370,y:923,t:1527877089046};\\\", \\\"{x:1370,y:922,t:1527877089070};\\\", \\\"{x:1370,y:921,t:1527877089094};\\\", \\\"{x:1371,y:919,t:1527877089106};\\\", \\\"{x:1371,y:918,t:1527877089122};\\\", \\\"{x:1372,y:915,t:1527877089140};\\\", \\\"{x:1373,y:914,t:1527877089156};\\\", \\\"{x:1373,y:913,t:1527877089173};\\\", \\\"{x:1373,y:912,t:1527877089190};\\\", \\\"{x:1374,y:909,t:1527877089207};\\\", \\\"{x:1375,y:909,t:1527877089223};\\\", \\\"{x:1375,y:906,t:1527877089241};\\\", \\\"{x:1376,y:905,t:1527877089256};\\\", \\\"{x:1377,y:903,t:1527877089302};\\\", \\\"{x:1378,y:902,t:1527877089310};\\\", \\\"{x:1379,y:901,t:1527877089326};\\\", \\\"{x:1379,y:900,t:1527877089340};\\\", \\\"{x:1379,y:899,t:1527877089365};\\\", \\\"{x:1379,y:898,t:1527877089414};\\\", \\\"{x:1379,y:895,t:1527877089423};\\\", \\\"{x:1383,y:886,t:1527877089441};\\\", \\\"{x:1392,y:871,t:1527877089457};\\\", \\\"{x:1395,y:861,t:1527877089473};\\\", \\\"{x:1398,y:855,t:1527877089489};\\\", \\\"{x:1398,y:852,t:1527877089505};\\\", \\\"{x:1399,y:850,t:1527877089523};\\\", \\\"{x:1400,y:847,t:1527877089539};\\\", \\\"{x:1402,y:844,t:1527877089556};\\\", \\\"{x:1403,y:840,t:1527877089573};\\\", \\\"{x:1405,y:837,t:1527877089589};\\\", \\\"{x:1406,y:836,t:1527877089606};\\\", \\\"{x:1408,y:833,t:1527877089623};\\\", \\\"{x:1409,y:830,t:1527877089640};\\\", \\\"{x:1413,y:822,t:1527877089657};\\\", \\\"{x:1418,y:812,t:1527877089673};\\\", \\\"{x:1422,y:805,t:1527877089690};\\\", \\\"{x:1422,y:804,t:1527877089707};\\\", \\\"{x:1423,y:802,t:1527877089723};\\\", \\\"{x:1427,y:796,t:1527877089739};\\\", \\\"{x:1432,y:787,t:1527877089756};\\\", \\\"{x:1440,y:776,t:1527877089773};\\\", \\\"{x:1448,y:764,t:1527877089790};\\\", \\\"{x:1450,y:762,t:1527877089807};\\\", \\\"{x:1450,y:761,t:1527877089823};\\\", \\\"{x:1452,y:758,t:1527877089840};\\\", \\\"{x:1453,y:756,t:1527877089857};\\\", \\\"{x:1457,y:751,t:1527877089873};\\\", \\\"{x:1460,y:746,t:1527877089890};\\\", \\\"{x:1463,y:742,t:1527877089906};\\\", \\\"{x:1464,y:741,t:1527877089923};\\\", \\\"{x:1465,y:738,t:1527877089939};\\\", \\\"{x:1469,y:732,t:1527877089957};\\\", \\\"{x:1473,y:727,t:1527877089973};\\\", \\\"{x:1483,y:711,t:1527877089990};\\\", \\\"{x:1486,y:705,t:1527877090006};\\\", \\\"{x:1489,y:700,t:1527877090023};\\\", \\\"{x:1490,y:699,t:1527877090046};\\\", \\\"{x:1491,y:696,t:1527877090062};\\\", \\\"{x:1492,y:695,t:1527877090074};\\\", \\\"{x:1497,y:687,t:1527877090090};\\\", \\\"{x:1499,y:679,t:1527877090107};\\\", \\\"{x:1506,y:669,t:1527877090124};\\\", \\\"{x:1508,y:665,t:1527877090140};\\\", \\\"{x:1510,y:662,t:1527877090157};\\\", \\\"{x:1512,y:656,t:1527877090174};\\\", \\\"{x:1517,y:644,t:1527877090189};\\\", \\\"{x:1521,y:636,t:1527877090207};\\\", \\\"{x:1525,y:627,t:1527877090224};\\\", \\\"{x:1527,y:622,t:1527877090240};\\\", \\\"{x:1528,y:618,t:1527877090256};\\\", \\\"{x:1529,y:614,t:1527877090274};\\\", \\\"{x:1532,y:609,t:1527877090289};\\\", \\\"{x:1533,y:605,t:1527877090306};\\\", \\\"{x:1535,y:603,t:1527877090323};\\\", \\\"{x:1535,y:600,t:1527877090339};\\\", \\\"{x:1537,y:598,t:1527877090357};\\\", \\\"{x:1539,y:593,t:1527877090374};\\\", \\\"{x:1541,y:588,t:1527877090390};\\\", \\\"{x:1544,y:584,t:1527877090407};\\\", \\\"{x:1546,y:582,t:1527877090424};\\\", \\\"{x:1548,y:577,t:1527877090439};\\\", \\\"{x:1550,y:574,t:1527877090457};\\\", \\\"{x:1551,y:571,t:1527877090474};\\\", \\\"{x:1554,y:566,t:1527877090490};\\\", \\\"{x:1557,y:560,t:1527877090506};\\\", \\\"{x:1560,y:553,t:1527877090524};\\\", \\\"{x:1564,y:548,t:1527877090540};\\\", \\\"{x:1568,y:540,t:1527877090557};\\\", \\\"{x:1572,y:532,t:1527877090574};\\\", \\\"{x:1574,y:526,t:1527877090590};\\\", \\\"{x:1576,y:521,t:1527877090606};\\\", \\\"{x:1578,y:517,t:1527877090624};\\\", \\\"{x:1582,y:511,t:1527877090641};\\\", \\\"{x:1584,y:508,t:1527877090657};\\\", \\\"{x:1588,y:502,t:1527877090674};\\\", \\\"{x:1590,y:495,t:1527877090690};\\\", \\\"{x:1592,y:492,t:1527877090707};\\\", \\\"{x:1594,y:488,t:1527877090724};\\\", \\\"{x:1595,y:485,t:1527877090741};\\\", \\\"{x:1593,y:484,t:1527877090959};\\\", \\\"{x:1580,y:486,t:1527877090975};\\\", \\\"{x:1549,y:500,t:1527877090992};\\\", \\\"{x:1497,y:523,t:1527877091007};\\\", \\\"{x:1450,y:543,t:1527877091024};\\\", \\\"{x:1385,y:564,t:1527877091041};\\\", \\\"{x:1285,y:594,t:1527877091058};\\\", \\\"{x:1173,y:636,t:1527877091073};\\\", \\\"{x:1073,y:666,t:1527877091091};\\\", \\\"{x:1016,y:679,t:1527877091108};\\\", \\\"{x:942,y:695,t:1527877091123};\\\", \\\"{x:888,y:704,t:1527877091140};\\\", \\\"{x:838,y:708,t:1527877091157};\\\", \\\"{x:811,y:708,t:1527877091174};\\\", \\\"{x:785,y:708,t:1527877091190};\\\", \\\"{x:773,y:708,t:1527877091207};\\\", \\\"{x:759,y:708,t:1527877091224};\\\", \\\"{x:750,y:707,t:1527877091240};\\\", \\\"{x:746,y:707,t:1527877091258};\\\", \\\"{x:743,y:704,t:1527877091273};\\\", \\\"{x:738,y:700,t:1527877091290};\\\", \\\"{x:728,y:691,t:1527877091308};\\\", \\\"{x:710,y:680,t:1527877091324};\\\", \\\"{x:699,y:672,t:1527877091340};\\\", \\\"{x:687,y:659,t:1527877091357};\\\", \\\"{x:682,y:653,t:1527877091373};\\\", \\\"{x:680,y:643,t:1527877091391};\\\", \\\"{x:679,y:630,t:1527877091408};\\\", \\\"{x:677,y:620,t:1527877091424};\\\", \\\"{x:673,y:614,t:1527877091440};\\\", \\\"{x:670,y:611,t:1527877091458};\\\", \\\"{x:668,y:609,t:1527877091474};\\\", \\\"{x:664,y:606,t:1527877091491};\\\", \\\"{x:658,y:602,t:1527877091507};\\\", \\\"{x:653,y:598,t:1527877091525};\\\", \\\"{x:637,y:592,t:1527877091542};\\\", \\\"{x:628,y:590,t:1527877091557};\\\", \\\"{x:620,y:590,t:1527877091574};\\\", \\\"{x:615,y:591,t:1527877091591};\\\", \\\"{x:613,y:592,t:1527877091608};\\\", \\\"{x:612,y:592,t:1527877091654};\\\", \\\"{x:611,y:593,t:1527877091662};\\\", \\\"{x:610,y:594,t:1527877091676};\\\", \\\"{x:609,y:595,t:1527877091692};\\\", \\\"{x:607,y:597,t:1527877091708};\\\", \\\"{x:604,y:600,t:1527877091724};\\\", \\\"{x:595,y:603,t:1527877091742};\\\", \\\"{x:590,y:605,t:1527877091759};\\\", \\\"{x:581,y:609,t:1527877091774};\\\", \\\"{x:570,y:613,t:1527877091792};\\\", \\\"{x:549,y:618,t:1527877091808};\\\", \\\"{x:535,y:619,t:1527877091825};\\\", \\\"{x:524,y:619,t:1527877091842};\\\", \\\"{x:515,y:619,t:1527877091857};\\\", \\\"{x:503,y:619,t:1527877091875};\\\", \\\"{x:495,y:619,t:1527877091893};\\\", \\\"{x:487,y:618,t:1527877091908};\\\", \\\"{x:481,y:615,t:1527877091925};\\\", \\\"{x:477,y:614,t:1527877091942};\\\", \\\"{x:474,y:612,t:1527877091957};\\\", \\\"{x:471,y:610,t:1527877091975};\\\", \\\"{x:470,y:604,t:1527877091992};\\\", \\\"{x:462,y:594,t:1527877092009};\\\", \\\"{x:452,y:587,t:1527877092026};\\\", \\\"{x:440,y:579,t:1527877092041};\\\", \\\"{x:429,y:574,t:1527877092059};\\\", \\\"{x:420,y:569,t:1527877092074};\\\", \\\"{x:413,y:566,t:1527877092093};\\\", \\\"{x:409,y:564,t:1527877092110};\\\", \\\"{x:409,y:563,t:1527877092125};\\\", \\\"{x:408,y:562,t:1527877092168};\\\", \\\"{x:407,y:561,t:1527877092175};\\\", \\\"{x:406,y:560,t:1527877092191};\\\", \\\"{x:406,y:559,t:1527877092229};\\\", \\\"{x:404,y:557,t:1527877092241};\\\", \\\"{x:397,y:552,t:1527877092259};\\\", \\\"{x:391,y:549,t:1527877092275};\\\", \\\"{x:389,y:548,t:1527877092291};\\\", \\\"{x:388,y:546,t:1527877092308};\\\", \\\"{x:387,y:546,t:1527877092374};\\\", \\\"{x:387,y:549,t:1527877092727};\\\", \\\"{x:386,y:554,t:1527877092743};\\\", \\\"{x:386,y:560,t:1527877092759};\\\", \\\"{x:386,y:566,t:1527877092776};\\\", \\\"{x:386,y:572,t:1527877092793};\\\", \\\"{x:386,y:574,t:1527877092808};\\\", \\\"{x:386,y:575,t:1527877092826};\\\", \\\"{x:385,y:577,t:1527877092846};\\\", \\\"{x:385,y:578,t:1527877092858};\\\", \\\"{x:385,y:581,t:1527877092876};\\\", \\\"{x:384,y:583,t:1527877092893};\\\", \\\"{x:384,y:586,t:1527877092909};\\\", \\\"{x:384,y:587,t:1527877092926};\\\", \\\"{x:384,y:589,t:1527877092990};\\\", \\\"{x:384,y:591,t:1527877092999};\\\", \\\"{x:384,y:593,t:1527877093009};\\\", \\\"{x:384,y:595,t:1527877093026};\\\", \\\"{x:384,y:596,t:1527877093043};\\\", \\\"{x:384,y:597,t:1527877093109};\\\", \\\"{x:384,y:598,t:1527877093125};\\\", \\\"{x:384,y:599,t:1527877093293};\\\", \\\"{x:384,y:601,t:1527877093310};\\\", \\\"{x:384,y:604,t:1527877093326};\\\", \\\"{x:385,y:605,t:1527877093342};\\\", \\\"{x:385,y:606,t:1527877093359};\\\", \\\"{x:386,y:607,t:1527877093430};\\\", \\\"{x:386,y:609,t:1527877093614};\\\", \\\"{x:387,y:612,t:1527877093625};\\\", \\\"{x:388,y:616,t:1527877093643};\\\", \\\"{x:392,y:620,t:1527877093660};\\\", \\\"{x:401,y:631,t:1527877093676};\\\", \\\"{x:415,y:640,t:1527877093693};\\\", \\\"{x:440,y:653,t:1527877093709};\\\", \\\"{x:461,y:662,t:1527877093726};\\\", \\\"{x:490,y:673,t:1527877093743};\\\", \\\"{x:521,y:683,t:1527877093760};\\\", \\\"{x:563,y:694,t:1527877093776};\\\", \\\"{x:587,y:706,t:1527877093793};\\\", \\\"{x:608,y:714,t:1527877093810};\\\", \\\"{x:615,y:718,t:1527877093826};\\\", \\\"{x:617,y:721,t:1527877093842};\\\", \\\"{x:618,y:722,t:1527877093860};\\\", \\\"{x:620,y:725,t:1527877093966};\\\", \\\"{x:638,y:742,t:1527877093976};\\\", \\\"{x:695,y:773,t:1527877093993};\\\", \\\"{x:724,y:785,t:1527877094010};\\\", \\\"{x:735,y:786,t:1527877094026};\\\", \\\"{x:754,y:786,t:1527877094043};\\\", \\\"{x:801,y:786,t:1527877094059};\\\", \\\"{x:873,y:795,t:1527877094076};\\\", \\\"{x:958,y:812,t:1527877094092};\\\", \\\"{x:1104,y:837,t:1527877094111};\\\", \\\"{x:1206,y:863,t:1527877094126};\\\", \\\"{x:1303,y:891,t:1527877094143};\\\", \\\"{x:1358,y:912,t:1527877094160};\\\", \\\"{x:1387,y:920,t:1527877094176};\\\", \\\"{x:1398,y:925,t:1527877094193};\\\", \\\"{x:1409,y:929,t:1527877094210};\\\", \\\"{x:1428,y:935,t:1527877094227};\\\", \\\"{x:1446,y:942,t:1527877094244};\\\", \\\"{x:1447,y:942,t:1527877094260};\\\", \\\"{x:1450,y:943,t:1527877094275};\\\", \\\"{x:1450,y:942,t:1527877094383};\\\", \\\"{x:1448,y:941,t:1527877094394};\\\", \\\"{x:1446,y:939,t:1527877094410};\\\", \\\"{x:1445,y:937,t:1527877094430};\\\", \\\"{x:1444,y:936,t:1527877094444};\\\", \\\"{x:1441,y:932,t:1527877094461};\\\", \\\"{x:1438,y:930,t:1527877094476};\\\", \\\"{x:1435,y:929,t:1527877094494};\\\", \\\"{x:1434,y:927,t:1527877094510};\\\", \\\"{x:1433,y:927,t:1527877094526};\\\", \\\"{x:1431,y:926,t:1527877094543};\\\", \\\"{x:1428,y:925,t:1527877094560};\\\", \\\"{x:1426,y:925,t:1527877094576};\\\", \\\"{x:1424,y:924,t:1527877094592};\\\", \\\"{x:1422,y:923,t:1527877094609};\\\", \\\"{x:1415,y:920,t:1527877094627};\\\", \\\"{x:1410,y:917,t:1527877094642};\\\", \\\"{x:1405,y:914,t:1527877094660};\\\", \\\"{x:1401,y:910,t:1527877094675};\\\", \\\"{x:1394,y:898,t:1527877094692};\\\", \\\"{x:1375,y:875,t:1527877094710};\\\", \\\"{x:1366,y:862,t:1527877094726};\\\", \\\"{x:1358,y:847,t:1527877094742};\\\", \\\"{x:1353,y:836,t:1527877094759};\\\", \\\"{x:1350,y:825,t:1527877094775};\\\", \\\"{x:1349,y:816,t:1527877094793};\\\", \\\"{x:1349,y:805,t:1527877094810};\\\", \\\"{x:1351,y:793,t:1527877094826};\\\", \\\"{x:1351,y:787,t:1527877094843};\\\", \\\"{x:1352,y:783,t:1527877094859};\\\", \\\"{x:1352,y:782,t:1527877094876};\\\", \\\"{x:1352,y:781,t:1527877094967};\\\", \\\"{x:1352,y:778,t:1527877094977};\\\", \\\"{x:1352,y:777,t:1527877094993};\\\", \\\"{x:1352,y:775,t:1527877095010};\\\", \\\"{x:1353,y:770,t:1527877095027};\\\", \\\"{x:1353,y:760,t:1527877095044};\\\", \\\"{x:1353,y:751,t:1527877095061};\\\", \\\"{x:1353,y:744,t:1527877095076};\\\", \\\"{x:1353,y:737,t:1527877095093};\\\", \\\"{x:1353,y:722,t:1527877095110};\\\", \\\"{x:1356,y:709,t:1527877095126};\\\", \\\"{x:1360,y:701,t:1527877095144};\\\", \\\"{x:1360,y:698,t:1527877095160};\\\", \\\"{x:1360,y:697,t:1527877095177};\\\", \\\"{x:1360,y:696,t:1527877095194};\\\", \\\"{x:1361,y:696,t:1527877095439};\\\", \\\"{x:1361,y:699,t:1527877095455};\\\", \\\"{x:1361,y:701,t:1527877095462};\\\", \\\"{x:1361,y:704,t:1527877095477};\\\", \\\"{x:1363,y:709,t:1527877095494};\\\", \\\"{x:1364,y:714,t:1527877095510};\\\", \\\"{x:1365,y:716,t:1527877095527};\\\", \\\"{x:1363,y:717,t:1527877095647};\\\", \\\"{x:1359,y:717,t:1527877095660};\\\", \\\"{x:1349,y:717,t:1527877095676};\\\", \\\"{x:1334,y:717,t:1527877095692};\\\", \\\"{x:1296,y:708,t:1527877095710};\\\", \\\"{x:1255,y:701,t:1527877095725};\\\", \\\"{x:1201,y:685,t:1527877095743};\\\", \\\"{x:1126,y:663,t:1527877095760};\\\", \\\"{x:1045,y:634,t:1527877095776};\\\", \\\"{x:956,y:595,t:1527877095793};\\\", \\\"{x:862,y:569,t:1527877095811};\\\", \\\"{x:798,y:550,t:1527877095827};\\\", \\\"{x:741,y:537,t:1527877095842};\\\", \\\"{x:673,y:522,t:1527877095862};\\\", \\\"{x:641,y:520,t:1527877095878};\\\", \\\"{x:620,y:520,t:1527877095895};\\\", \\\"{x:596,y:520,t:1527877095911};\\\", \\\"{x:573,y:520,t:1527877095927};\\\", \\\"{x:551,y:527,t:1527877095945};\\\", \\\"{x:523,y:540,t:1527877095962};\\\", \\\"{x:504,y:551,t:1527877095978};\\\", \\\"{x:490,y:560,t:1527877095995};\\\", \\\"{x:482,y:567,t:1527877096012};\\\", \\\"{x:475,y:577,t:1527877096027};\\\", \\\"{x:469,y:589,t:1527877096045};\\\", \\\"{x:462,y:604,t:1527877096061};\\\", \\\"{x:459,y:616,t:1527877096077};\\\", \\\"{x:459,y:630,t:1527877096094};\\\", \\\"{x:459,y:642,t:1527877096112};\\\", \\\"{x:460,y:651,t:1527877096129};\\\", \\\"{x:462,y:656,t:1527877096145};\\\", \\\"{x:463,y:663,t:1527877096162};\\\", \\\"{x:465,y:675,t:1527877096179};\\\", \\\"{x:468,y:690,t:1527877096195};\\\", \\\"{x:472,y:700,t:1527877096211};\\\", \\\"{x:476,y:706,t:1527877096228};\\\", \\\"{x:479,y:709,t:1527877096245};\\\", \\\"{x:481,y:717,t:1527877096262};\\\", \\\"{x:482,y:719,t:1527877096278};\\\", \\\"{x:483,y:721,t:1527877096295};\\\", \\\"{x:484,y:722,t:1527877096318};\\\", \\\"{x:485,y:722,t:1527877096365};\\\", \\\"{x:486,y:723,t:1527877096406};\\\", \\\"{x:486,y:724,t:1527877096414};\\\", \\\"{x:488,y:728,t:1527877096429};\\\", \\\"{x:491,y:738,t:1527877096445};\\\", \\\"{x:493,y:745,t:1527877096462};\\\", \\\"{x:495,y:747,t:1527877096479};\\\", \\\"{x:500,y:747,t:1527877097038};\\\", \\\"{x:507,y:746,t:1527877097045};\\\", \\\"{x:544,y:739,t:1527877097062};\\\", \\\"{x:611,y:731,t:1527877097079};\\\", \\\"{x:682,y:727,t:1527877097096};\\\", \\\"{x:746,y:726,t:1527877097112};\\\", \\\"{x:805,y:726,t:1527877097129};\\\", \\\"{x:861,y:726,t:1527877097146};\\\", \\\"{x:868,y:724,t:1527877097162};\\\" ] }, { \\\"rt\\\": 16105, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 511049, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -X -F -F -G -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:867,y:724,t:1527877098358};\\\", \\\"{x:867,y:723,t:1527877098365};\\\", \\\"{x:866,y:722,t:1527877098380};\\\", \\\"{x:861,y:718,t:1527877098397};\\\", \\\"{x:855,y:712,t:1527877098413};\\\", \\\"{x:845,y:704,t:1527877098430};\\\", \\\"{x:829,y:697,t:1527877098447};\\\", \\\"{x:811,y:690,t:1527877098463};\\\", \\\"{x:791,y:686,t:1527877098480};\\\", \\\"{x:772,y:682,t:1527877098496};\\\", \\\"{x:759,y:680,t:1527877098512};\\\", \\\"{x:747,y:678,t:1527877098530};\\\", \\\"{x:737,y:677,t:1527877098547};\\\", \\\"{x:732,y:677,t:1527877098563};\\\", \\\"{x:724,y:676,t:1527877098580};\\\", \\\"{x:718,y:676,t:1527877098597};\\\", \\\"{x:709,y:676,t:1527877098613};\\\", \\\"{x:698,y:676,t:1527877098630};\\\", \\\"{x:690,y:676,t:1527877098647};\\\", \\\"{x:680,y:676,t:1527877098664};\\\", \\\"{x:672,y:675,t:1527877098680};\\\", \\\"{x:666,y:675,t:1527877098697};\\\", \\\"{x:657,y:675,t:1527877098714};\\\", \\\"{x:646,y:675,t:1527877098730};\\\", \\\"{x:637,y:675,t:1527877098747};\\\", \\\"{x:632,y:675,t:1527877098764};\\\", \\\"{x:629,y:675,t:1527877098780};\\\", \\\"{x:626,y:675,t:1527877098797};\\\", \\\"{x:624,y:675,t:1527877098814};\\\", \\\"{x:623,y:675,t:1527877098837};\\\", \\\"{x:621,y:677,t:1527877098853};\\\", \\\"{x:619,y:678,t:1527877098878};\\\", \\\"{x:618,y:679,t:1527877098885};\\\", \\\"{x:617,y:679,t:1527877098897};\\\", \\\"{x:615,y:680,t:1527877098914};\\\", \\\"{x:614,y:681,t:1527877098958};\\\", \\\"{x:614,y:682,t:1527877098998};\\\", \\\"{x:614,y:683,t:1527877099094};\\\", \\\"{x:614,y:685,t:1527877099110};\\\", \\\"{x:614,y:687,t:1527877099126};\\\", \\\"{x:614,y:688,t:1527877099143};\\\", \\\"{x:614,y:689,t:1527877099150};\\\", \\\"{x:614,y:690,t:1527877099164};\\\", \\\"{x:614,y:692,t:1527877099182};\\\", \\\"{x:614,y:695,t:1527877099198};\\\", \\\"{x:614,y:696,t:1527877099230};\\\", \\\"{x:615,y:697,t:1527877099238};\\\", \\\"{x:616,y:697,t:1527877099813};\\\", \\\"{x:617,y:696,t:1527877099830};\\\", \\\"{x:618,y:695,t:1527877099861};\\\", \\\"{x:620,y:695,t:1527877099894};\\\", \\\"{x:622,y:693,t:1527877099909};\\\", \\\"{x:623,y:693,t:1527877099926};\\\", \\\"{x:625,y:692,t:1527877099933};\\\", \\\"{x:628,y:692,t:1527877099948};\\\", \\\"{x:635,y:692,t:1527877099965};\\\", \\\"{x:658,y:692,t:1527877099981};\\\", \\\"{x:680,y:692,t:1527877099998};\\\", \\\"{x:707,y:692,t:1527877100015};\\\", \\\"{x:739,y:692,t:1527877100031};\\\", \\\"{x:775,y:696,t:1527877100048};\\\", \\\"{x:805,y:700,t:1527877100065};\\\", \\\"{x:838,y:707,t:1527877100081};\\\", \\\"{x:869,y:715,t:1527877100098};\\\", \\\"{x:906,y:726,t:1527877100115};\\\", \\\"{x:953,y:740,t:1527877100131};\\\", \\\"{x:995,y:744,t:1527877100148};\\\", \\\"{x:1051,y:755,t:1527877100166};\\\", \\\"{x:1067,y:757,t:1527877100181};\\\", \\\"{x:1117,y:766,t:1527877100199};\\\", \\\"{x:1143,y:772,t:1527877100216};\\\", \\\"{x:1163,y:775,t:1527877100231};\\\", \\\"{x:1182,y:781,t:1527877100248};\\\", \\\"{x:1201,y:785,t:1527877100265};\\\", \\\"{x:1218,y:788,t:1527877100282};\\\", \\\"{x:1230,y:788,t:1527877100298};\\\", \\\"{x:1236,y:788,t:1527877100315};\\\", \\\"{x:1239,y:788,t:1527877100331};\\\", \\\"{x:1242,y:788,t:1527877100348};\\\", \\\"{x:1244,y:788,t:1527877100366};\\\", \\\"{x:1245,y:788,t:1527877100381};\\\", \\\"{x:1246,y:789,t:1527877100527};\\\", \\\"{x:1245,y:789,t:1527877100550};\\\", \\\"{x:1247,y:783,t:1527877100606};\\\", \\\"{x:1251,y:773,t:1527877100616};\\\", \\\"{x:1263,y:749,t:1527877100633};\\\", \\\"{x:1274,y:728,t:1527877100648};\\\", \\\"{x:1286,y:704,t:1527877100665};\\\", \\\"{x:1296,y:671,t:1527877100683};\\\", \\\"{x:1301,y:644,t:1527877100699};\\\", \\\"{x:1302,y:634,t:1527877100715};\\\", \\\"{x:1303,y:629,t:1527877100733};\\\", \\\"{x:1303,y:628,t:1527877100749};\\\", \\\"{x:1304,y:627,t:1527877100766};\\\", \\\"{x:1304,y:625,t:1527877100782};\\\", \\\"{x:1305,y:622,t:1527877100799};\\\", \\\"{x:1305,y:617,t:1527877100815};\\\", \\\"{x:1305,y:610,t:1527877100833};\\\", \\\"{x:1305,y:608,t:1527877100849};\\\", \\\"{x:1305,y:606,t:1527877100865};\\\", \\\"{x:1305,y:603,t:1527877100919};\\\", \\\"{x:1305,y:601,t:1527877100933};\\\", \\\"{x:1308,y:595,t:1527877100949};\\\", \\\"{x:1315,y:586,t:1527877100966};\\\", \\\"{x:1321,y:585,t:1527877100982};\\\", \\\"{x:1330,y:582,t:1527877100999};\\\", \\\"{x:1340,y:582,t:1527877101016};\\\", \\\"{x:1353,y:582,t:1527877101032};\\\", \\\"{x:1365,y:582,t:1527877101050};\\\", \\\"{x:1373,y:582,t:1527877101066};\\\", \\\"{x:1380,y:582,t:1527877101082};\\\", \\\"{x:1384,y:581,t:1527877101099};\\\", \\\"{x:1385,y:581,t:1527877101116};\\\", \\\"{x:1391,y:580,t:1527877101132};\\\", \\\"{x:1399,y:576,t:1527877101149};\\\", \\\"{x:1411,y:569,t:1527877101166};\\\", \\\"{x:1431,y:555,t:1527877101183};\\\", \\\"{x:1440,y:550,t:1527877101200};\\\", \\\"{x:1445,y:546,t:1527877101216};\\\", \\\"{x:1449,y:543,t:1527877101233};\\\", \\\"{x:1457,y:539,t:1527877101250};\\\", \\\"{x:1464,y:534,t:1527877101265};\\\", \\\"{x:1475,y:524,t:1527877101283};\\\", \\\"{x:1481,y:521,t:1527877101300};\\\", \\\"{x:1485,y:517,t:1527877101316};\\\", \\\"{x:1489,y:516,t:1527877101333};\\\", \\\"{x:1494,y:516,t:1527877101350};\\\", \\\"{x:1497,y:515,t:1527877101366};\\\", \\\"{x:1502,y:513,t:1527877101383};\\\", \\\"{x:1508,y:513,t:1527877101399};\\\", \\\"{x:1510,y:513,t:1527877101416};\\\", \\\"{x:1512,y:513,t:1527877101433};\\\", \\\"{x:1513,y:513,t:1527877101450};\\\", \\\"{x:1516,y:513,t:1527877101466};\\\", \\\"{x:1517,y:513,t:1527877101482};\\\", \\\"{x:1518,y:513,t:1527877101500};\\\", \\\"{x:1521,y:520,t:1527877101535};\\\", \\\"{x:1521,y:529,t:1527877101550};\\\", \\\"{x:1527,y:564,t:1527877101566};\\\", \\\"{x:1531,y:587,t:1527877101583};\\\", \\\"{x:1537,y:611,t:1527877101600};\\\", \\\"{x:1539,y:631,t:1527877101617};\\\", \\\"{x:1539,y:654,t:1527877101633};\\\", \\\"{x:1537,y:677,t:1527877101649};\\\", \\\"{x:1531,y:688,t:1527877101667};\\\", \\\"{x:1531,y:694,t:1527877101682};\\\", \\\"{x:1527,y:699,t:1527877101700};\\\", \\\"{x:1524,y:702,t:1527877101717};\\\", \\\"{x:1523,y:708,t:1527877101733};\\\", \\\"{x:1518,y:716,t:1527877101750};\\\", \\\"{x:1518,y:717,t:1527877101767};\\\", \\\"{x:1516,y:718,t:1527877101798};\\\", \\\"{x:1516,y:719,t:1527877101806};\\\", \\\"{x:1515,y:720,t:1527877101817};\\\", \\\"{x:1514,y:722,t:1527877101833};\\\", \\\"{x:1513,y:724,t:1527877101877};\\\", \\\"{x:1513,y:725,t:1527877101886};\\\", \\\"{x:1513,y:726,t:1527877101899};\\\", \\\"{x:1513,y:729,t:1527877101916};\\\", \\\"{x:1513,y:738,t:1527877101933};\\\", \\\"{x:1512,y:744,t:1527877101949};\\\", \\\"{x:1512,y:746,t:1527877101966};\\\", \\\"{x:1510,y:753,t:1527877101983};\\\", \\\"{x:1509,y:760,t:1527877102000};\\\", \\\"{x:1505,y:767,t:1527877102016};\\\", \\\"{x:1499,y:779,t:1527877102033};\\\", \\\"{x:1494,y:785,t:1527877102049};\\\", \\\"{x:1493,y:788,t:1527877102066};\\\", \\\"{x:1493,y:790,t:1527877102084};\\\", \\\"{x:1492,y:791,t:1527877102099};\\\", \\\"{x:1491,y:794,t:1527877102116};\\\", \\\"{x:1491,y:797,t:1527877102133};\\\", \\\"{x:1490,y:798,t:1527877102149};\\\", \\\"{x:1489,y:800,t:1527877102167};\\\", \\\"{x:1488,y:801,t:1527877102183};\\\", \\\"{x:1486,y:801,t:1527877102200};\\\", \\\"{x:1484,y:802,t:1527877102217};\\\", \\\"{x:1481,y:802,t:1527877102233};\\\", \\\"{x:1479,y:804,t:1527877102250};\\\", \\\"{x:1477,y:806,t:1527877102266};\\\", \\\"{x:1474,y:808,t:1527877102284};\\\", \\\"{x:1472,y:811,t:1527877102300};\\\", \\\"{x:1471,y:812,t:1527877102316};\\\", \\\"{x:1470,y:813,t:1527877102358};\\\", \\\"{x:1470,y:814,t:1527877102382};\\\", \\\"{x:1470,y:816,t:1527877102494};\\\", \\\"{x:1470,y:817,t:1527877102511};\\\", \\\"{x:1469,y:819,t:1527877102526};\\\", \\\"{x:1468,y:819,t:1527877102535};\\\", \\\"{x:1468,y:820,t:1527877102607};\\\", \\\"{x:1467,y:820,t:1527877102622};\\\", \\\"{x:1466,y:820,t:1527877102634};\\\", \\\"{x:1465,y:820,t:1527877102662};\\\", \\\"{x:1465,y:818,t:1527877103127};\\\", \\\"{x:1466,y:818,t:1527877103134};\\\", \\\"{x:1475,y:816,t:1527877103150};\\\", \\\"{x:1482,y:816,t:1527877103167};\\\", \\\"{x:1496,y:815,t:1527877103183};\\\", \\\"{x:1507,y:815,t:1527877103200};\\\", \\\"{x:1523,y:815,t:1527877103217};\\\", \\\"{x:1544,y:816,t:1527877103233};\\\", \\\"{x:1567,y:819,t:1527877103250};\\\", \\\"{x:1587,y:822,t:1527877103267};\\\", \\\"{x:1602,y:822,t:1527877103283};\\\", \\\"{x:1611,y:822,t:1527877103301};\\\", \\\"{x:1617,y:822,t:1527877103318};\\\", \\\"{x:1620,y:822,t:1527877103334};\\\", \\\"{x:1624,y:820,t:1527877103350};\\\", \\\"{x:1631,y:813,t:1527877103368};\\\", \\\"{x:1636,y:807,t:1527877103384};\\\", \\\"{x:1640,y:804,t:1527877103400};\\\", \\\"{x:1642,y:802,t:1527877103417};\\\", \\\"{x:1644,y:799,t:1527877103434};\\\", \\\"{x:1646,y:797,t:1527877103451};\\\", \\\"{x:1647,y:792,t:1527877103468};\\\", \\\"{x:1647,y:787,t:1527877103485};\\\", \\\"{x:1647,y:783,t:1527877103501};\\\", \\\"{x:1647,y:781,t:1527877103518};\\\", \\\"{x:1647,y:780,t:1527877103534};\\\", \\\"{x:1646,y:777,t:1527877103550};\\\", \\\"{x:1639,y:767,t:1527877103567};\\\", \\\"{x:1632,y:757,t:1527877103585};\\\", \\\"{x:1626,y:746,t:1527877103601};\\\", \\\"{x:1621,y:739,t:1527877103618};\\\", \\\"{x:1618,y:736,t:1527877103635};\\\", \\\"{x:1615,y:730,t:1527877103651};\\\", \\\"{x:1613,y:727,t:1527877103668};\\\", \\\"{x:1609,y:724,t:1527877103685};\\\", \\\"{x:1607,y:720,t:1527877103701};\\\", \\\"{x:1606,y:717,t:1527877103718};\\\", \\\"{x:1604,y:715,t:1527877103734};\\\", \\\"{x:1603,y:714,t:1527877103751};\\\", \\\"{x:1603,y:713,t:1527877103768};\\\", \\\"{x:1603,y:710,t:1527877103785};\\\", \\\"{x:1603,y:708,t:1527877103801};\\\", \\\"{x:1603,y:705,t:1527877103818};\\\", \\\"{x:1603,y:702,t:1527877103834};\\\", \\\"{x:1604,y:698,t:1527877103851};\\\", \\\"{x:1606,y:694,t:1527877103868};\\\", \\\"{x:1606,y:692,t:1527877103885};\\\", \\\"{x:1607,y:691,t:1527877103902};\\\", \\\"{x:1607,y:690,t:1527877103926};\\\", \\\"{x:1606,y:689,t:1527877104007};\\\", \\\"{x:1604,y:688,t:1527877104018};\\\", \\\"{x:1601,y:688,t:1527877104038};\\\", \\\"{x:1600,y:687,t:1527877104054};\\\", \\\"{x:1599,y:686,t:1527877104068};\\\", \\\"{x:1598,y:686,t:1527877104085};\\\", \\\"{x:1596,y:686,t:1527877104102};\\\", \\\"{x:1591,y:683,t:1527877104119};\\\", \\\"{x:1586,y:681,t:1527877104135};\\\", \\\"{x:1576,y:676,t:1527877104152};\\\", \\\"{x:1573,y:675,t:1527877104168};\\\", \\\"{x:1570,y:674,t:1527877104185};\\\", \\\"{x:1564,y:673,t:1527877104202};\\\", \\\"{x:1560,y:671,t:1527877104218};\\\", \\\"{x:1558,y:671,t:1527877104235};\\\", \\\"{x:1557,y:671,t:1527877104278};\\\", \\\"{x:1557,y:670,t:1527877104294};\\\", \\\"{x:1557,y:669,t:1527877104583};\\\", \\\"{x:1556,y:667,t:1527877104590};\\\", \\\"{x:1555,y:663,t:1527877104602};\\\", \\\"{x:1553,y:660,t:1527877104619};\\\", \\\"{x:1551,y:658,t:1527877104635};\\\", \\\"{x:1548,y:656,t:1527877104652};\\\", \\\"{x:1545,y:655,t:1527877104668};\\\", \\\"{x:1543,y:654,t:1527877104685};\\\", \\\"{x:1524,y:654,t:1527877104702};\\\", \\\"{x:1502,y:656,t:1527877104719};\\\", \\\"{x:1480,y:666,t:1527877104735};\\\", \\\"{x:1462,y:672,t:1527877104752};\\\", \\\"{x:1442,y:675,t:1527877104769};\\\", \\\"{x:1430,y:675,t:1527877104785};\\\", \\\"{x:1425,y:675,t:1527877104802};\\\", \\\"{x:1423,y:675,t:1527877104819};\\\", \\\"{x:1419,y:675,t:1527877104836};\\\", \\\"{x:1418,y:676,t:1527877104852};\\\", \\\"{x:1414,y:677,t:1527877104869};\\\", \\\"{x:1404,y:679,t:1527877104886};\\\", \\\"{x:1399,y:680,t:1527877104902};\\\", \\\"{x:1390,y:683,t:1527877104919};\\\", \\\"{x:1377,y:690,t:1527877104936};\\\", \\\"{x:1358,y:700,t:1527877104952};\\\", \\\"{x:1352,y:704,t:1527877104969};\\\", \\\"{x:1351,y:705,t:1527877104986};\\\", \\\"{x:1351,y:704,t:1527877105175};\\\", \\\"{x:1351,y:702,t:1527877105190};\\\", \\\"{x:1351,y:701,t:1527877106729};\\\", \\\"{x:1349,y:703,t:1527877106773};\\\", \\\"{x:1349,y:704,t:1527877106797};\\\", \\\"{x:1348,y:704,t:1527877106805};\\\", \\\"{x:1347,y:707,t:1527877106845};\\\", \\\"{x:1346,y:708,t:1527877106870};\\\", \\\"{x:1345,y:709,t:1527877106886};\\\", \\\"{x:1343,y:711,t:1527877106904};\\\", \\\"{x:1341,y:714,t:1527877106920};\\\", \\\"{x:1339,y:717,t:1527877106936};\\\", \\\"{x:1335,y:722,t:1527877106954};\\\", \\\"{x:1331,y:728,t:1527877106970};\\\", \\\"{x:1327,y:734,t:1527877106986};\\\", \\\"{x:1320,y:743,t:1527877107003};\\\", \\\"{x:1314,y:752,t:1527877107020};\\\", \\\"{x:1312,y:756,t:1527877107036};\\\", \\\"{x:1310,y:761,t:1527877107053};\\\", \\\"{x:1309,y:765,t:1527877107069};\\\", \\\"{x:1307,y:773,t:1527877107087};\\\", \\\"{x:1305,y:785,t:1527877107104};\\\", \\\"{x:1303,y:793,t:1527877107119};\\\", \\\"{x:1299,y:800,t:1527877107137};\\\", \\\"{x:1299,y:803,t:1527877107153};\\\", \\\"{x:1296,y:808,t:1527877107170};\\\", \\\"{x:1296,y:814,t:1527877107187};\\\", \\\"{x:1292,y:822,t:1527877107203};\\\", \\\"{x:1289,y:829,t:1527877107221};\\\", \\\"{x:1286,y:835,t:1527877107237};\\\", \\\"{x:1281,y:844,t:1527877107253};\\\", \\\"{x:1276,y:852,t:1527877107270};\\\", \\\"{x:1274,y:856,t:1527877107286};\\\", \\\"{x:1270,y:862,t:1527877107303};\\\", \\\"{x:1267,y:868,t:1527877107321};\\\", \\\"{x:1261,y:873,t:1527877107337};\\\", \\\"{x:1255,y:880,t:1527877107354};\\\", \\\"{x:1254,y:882,t:1527877107370};\\\", \\\"{x:1249,y:890,t:1527877107386};\\\", \\\"{x:1246,y:896,t:1527877107403};\\\", \\\"{x:1243,y:901,t:1527877107421};\\\", \\\"{x:1241,y:906,t:1527877107436};\\\", \\\"{x:1238,y:913,t:1527877107454};\\\", \\\"{x:1238,y:915,t:1527877107471};\\\", \\\"{x:1238,y:916,t:1527877107486};\\\", \\\"{x:1239,y:916,t:1527877107542};\\\", \\\"{x:1244,y:908,t:1527877107554};\\\", \\\"{x:1256,y:895,t:1527877107571};\\\", \\\"{x:1272,y:878,t:1527877107587};\\\", \\\"{x:1283,y:864,t:1527877107604};\\\", \\\"{x:1296,y:848,t:1527877107622};\\\", \\\"{x:1307,y:836,t:1527877107638};\\\", \\\"{x:1318,y:815,t:1527877107654};\\\", \\\"{x:1326,y:800,t:1527877107670};\\\", \\\"{x:1334,y:785,t:1527877107688};\\\", \\\"{x:1340,y:773,t:1527877107703};\\\", \\\"{x:1351,y:754,t:1527877107720};\\\", \\\"{x:1361,y:736,t:1527877107737};\\\", \\\"{x:1365,y:721,t:1527877107754};\\\", \\\"{x:1366,y:719,t:1527877107770};\\\", \\\"{x:1367,y:716,t:1527877107787};\\\", \\\"{x:1368,y:715,t:1527877107805};\\\", \\\"{x:1368,y:713,t:1527877107820};\\\", \\\"{x:1368,y:711,t:1527877107837};\\\", \\\"{x:1368,y:710,t:1527877107853};\\\", \\\"{x:1367,y:710,t:1527877107902};\\\", \\\"{x:1366,y:710,t:1527877107917};\\\", \\\"{x:1364,y:710,t:1527877107934};\\\", \\\"{x:1359,y:710,t:1527877107941};\\\", \\\"{x:1358,y:710,t:1527877107953};\\\", \\\"{x:1354,y:711,t:1527877107970};\\\", \\\"{x:1352,y:711,t:1527877107988};\\\", \\\"{x:1352,y:710,t:1527877108087};\\\", \\\"{x:1352,y:707,t:1527877108094};\\\", \\\"{x:1352,y:704,t:1527877108110};\\\", \\\"{x:1352,y:702,t:1527877108122};\\\", \\\"{x:1352,y:696,t:1527877108138};\\\", \\\"{x:1352,y:693,t:1527877108154};\\\", \\\"{x:1353,y:689,t:1527877108172};\\\", \\\"{x:1353,y:687,t:1527877108188};\\\", \\\"{x:1353,y:686,t:1527877108206};\\\", \\\"{x:1353,y:685,t:1527877108686};\\\", \\\"{x:1355,y:681,t:1527877108694};\\\", \\\"{x:1356,y:679,t:1527877108705};\\\", \\\"{x:1357,y:674,t:1527877108722};\\\", \\\"{x:1366,y:661,t:1527877108738};\\\", \\\"{x:1373,y:649,t:1527877108755};\\\", \\\"{x:1383,y:629,t:1527877108771};\\\", \\\"{x:1394,y:605,t:1527877108788};\\\", \\\"{x:1400,y:594,t:1527877108805};\\\", \\\"{x:1404,y:590,t:1527877108822};\\\", \\\"{x:1405,y:585,t:1527877108838};\\\", \\\"{x:1407,y:583,t:1527877108855};\\\", \\\"{x:1407,y:581,t:1527877108872};\\\", \\\"{x:1408,y:580,t:1527877108888};\\\", \\\"{x:1409,y:579,t:1527877108911};\\\", \\\"{x:1411,y:577,t:1527877108950};\\\", \\\"{x:1411,y:574,t:1527877108966};\\\", \\\"{x:1412,y:574,t:1527877108990};\\\", \\\"{x:1413,y:570,t:1527877109439};\\\", \\\"{x:1416,y:556,t:1527877109455};\\\", \\\"{x:1419,y:547,t:1527877109473};\\\", \\\"{x:1424,y:539,t:1527877109489};\\\", \\\"{x:1425,y:535,t:1527877109505};\\\", \\\"{x:1426,y:534,t:1527877109522};\\\", \\\"{x:1426,y:533,t:1527877109540};\\\", \\\"{x:1426,y:532,t:1527877109556};\\\", \\\"{x:1426,y:530,t:1527877109572};\\\", \\\"{x:1429,y:526,t:1527877109590};\\\", \\\"{x:1429,y:524,t:1527877109605};\\\", \\\"{x:1431,y:519,t:1527877109622};\\\", \\\"{x:1434,y:514,t:1527877109639};\\\", \\\"{x:1441,y:506,t:1527877109656};\\\", \\\"{x:1447,y:494,t:1527877109672};\\\", \\\"{x:1454,y:481,t:1527877109689};\\\", \\\"{x:1464,y:465,t:1527877109706};\\\", \\\"{x:1472,y:449,t:1527877109723};\\\", \\\"{x:1478,y:440,t:1527877109739};\\\", \\\"{x:1482,y:433,t:1527877109756};\\\", \\\"{x:1483,y:427,t:1527877109772};\\\", \\\"{x:1486,y:421,t:1527877109789};\\\", \\\"{x:1492,y:409,t:1527877109806};\\\", \\\"{x:1495,y:402,t:1527877109823};\\\", \\\"{x:1499,y:392,t:1527877109839};\\\", \\\"{x:1501,y:385,t:1527877109857};\\\", \\\"{x:1505,y:375,t:1527877109872};\\\", \\\"{x:1510,y:366,t:1527877109889};\\\", \\\"{x:1515,y:357,t:1527877109906};\\\", \\\"{x:1520,y:345,t:1527877109922};\\\", \\\"{x:1522,y:340,t:1527877109939};\\\", \\\"{x:1523,y:339,t:1527877109956};\\\", \\\"{x:1523,y:338,t:1527877109972};\\\", \\\"{x:1522,y:338,t:1527877110030};\\\", \\\"{x:1517,y:344,t:1527877110039};\\\", \\\"{x:1502,y:359,t:1527877110056};\\\", \\\"{x:1485,y:379,t:1527877110073};\\\", \\\"{x:1466,y:398,t:1527877110089};\\\", \\\"{x:1444,y:418,t:1527877110106};\\\", \\\"{x:1428,y:433,t:1527877110123};\\\", \\\"{x:1416,y:452,t:1527877110139};\\\", \\\"{x:1408,y:468,t:1527877110156};\\\", \\\"{x:1401,y:485,t:1527877110173};\\\", \\\"{x:1393,y:503,t:1527877110189};\\\", \\\"{x:1381,y:541,t:1527877110205};\\\", \\\"{x:1375,y:567,t:1527877110222};\\\", \\\"{x:1371,y:584,t:1527877110239};\\\", \\\"{x:1371,y:595,t:1527877110255};\\\", \\\"{x:1371,y:598,t:1527877110272};\\\", \\\"{x:1371,y:600,t:1527877110358};\\\", \\\"{x:1371,y:602,t:1527877110519};\\\", \\\"{x:1373,y:606,t:1527877110526};\\\", \\\"{x:1374,y:614,t:1527877110539};\\\", \\\"{x:1377,y:626,t:1527877110557};\\\", \\\"{x:1377,y:640,t:1527877110574};\\\", \\\"{x:1369,y:682,t:1527877110591};\\\", \\\"{x:1355,y:727,t:1527877110606};\\\", \\\"{x:1336,y:772,t:1527877110624};\\\", \\\"{x:1327,y:796,t:1527877110640};\\\", \\\"{x:1326,y:798,t:1527877110656};\\\", \\\"{x:1326,y:797,t:1527877110751};\\\", \\\"{x:1326,y:790,t:1527877110758};\\\", \\\"{x:1329,y:780,t:1527877110773};\\\", \\\"{x:1336,y:760,t:1527877110790};\\\", \\\"{x:1341,y:743,t:1527877110806};\\\", \\\"{x:1349,y:723,t:1527877110823};\\\", \\\"{x:1354,y:707,t:1527877110841};\\\", \\\"{x:1356,y:697,t:1527877110856};\\\", \\\"{x:1357,y:691,t:1527877110874};\\\", \\\"{x:1357,y:690,t:1527877110890};\\\", \\\"{x:1352,y:690,t:1527877111062};\\\", \\\"{x:1347,y:695,t:1527877111074};\\\", \\\"{x:1327,y:707,t:1527877111091};\\\", \\\"{x:1290,y:726,t:1527877111107};\\\", \\\"{x:1257,y:739,t:1527877111123};\\\", \\\"{x:1234,y:753,t:1527877111140};\\\", \\\"{x:1213,y:761,t:1527877111157};\\\", \\\"{x:1189,y:768,t:1527877111173};\\\", \\\"{x:1148,y:779,t:1527877111190};\\\", \\\"{x:1130,y:779,t:1527877111207};\\\", \\\"{x:1118,y:779,t:1527877111223};\\\", \\\"{x:1110,y:779,t:1527877111240};\\\", \\\"{x:1082,y:779,t:1527877111257};\\\", \\\"{x:1052,y:779,t:1527877111273};\\\", \\\"{x:1022,y:779,t:1527877111290};\\\", \\\"{x:980,y:779,t:1527877111307};\\\", \\\"{x:919,y:779,t:1527877111322};\\\", \\\"{x:884,y:779,t:1527877111340};\\\", \\\"{x:839,y:777,t:1527877111357};\\\", \\\"{x:799,y:777,t:1527877111373};\\\", \\\"{x:755,y:776,t:1527877111390};\\\", \\\"{x:731,y:770,t:1527877111407};\\\", \\\"{x:714,y:760,t:1527877111423};\\\", \\\"{x:695,y:749,t:1527877111440};\\\", \\\"{x:676,y:736,t:1527877111457};\\\", \\\"{x:667,y:728,t:1527877111473};\\\", \\\"{x:665,y:724,t:1527877111490};\\\", \\\"{x:665,y:713,t:1527877111507};\\\", \\\"{x:666,y:693,t:1527877111524};\\\", \\\"{x:667,y:674,t:1527877111541};\\\", \\\"{x:669,y:663,t:1527877111556};\\\", \\\"{x:669,y:656,t:1527877111574};\\\", \\\"{x:669,y:649,t:1527877111590};\\\", \\\"{x:668,y:639,t:1527877111607};\\\", \\\"{x:661,y:628,t:1527877111625};\\\", \\\"{x:658,y:624,t:1527877111640};\\\", \\\"{x:651,y:620,t:1527877111656};\\\", \\\"{x:642,y:614,t:1527877111674};\\\", \\\"{x:633,y:607,t:1527877111690};\\\", \\\"{x:617,y:600,t:1527877111707};\\\", \\\"{x:602,y:592,t:1527877111725};\\\", \\\"{x:594,y:586,t:1527877111741};\\\", \\\"{x:580,y:577,t:1527877111757};\\\", \\\"{x:569,y:572,t:1527877111774};\\\", \\\"{x:551,y:565,t:1527877111790};\\\", \\\"{x:534,y:561,t:1527877111808};\\\", \\\"{x:521,y:557,t:1527877111824};\\\", \\\"{x:512,y:556,t:1527877111841};\\\", \\\"{x:509,y:555,t:1527877111858};\\\", \\\"{x:506,y:554,t:1527877111874};\\\", \\\"{x:502,y:554,t:1527877111891};\\\", \\\"{x:493,y:554,t:1527877111908};\\\", \\\"{x:478,y:554,t:1527877111924};\\\", \\\"{x:467,y:554,t:1527877111940};\\\", \\\"{x:456,y:554,t:1527877111957};\\\", \\\"{x:453,y:555,t:1527877111974};\\\", \\\"{x:451,y:557,t:1527877111992};\\\", \\\"{x:445,y:560,t:1527877112008};\\\", \\\"{x:431,y:568,t:1527877112026};\\\", \\\"{x:413,y:576,t:1527877112040};\\\", \\\"{x:403,y:580,t:1527877112058};\\\", \\\"{x:401,y:582,t:1527877112074};\\\", \\\"{x:398,y:582,t:1527877112126};\\\", \\\"{x:394,y:582,t:1527877112141};\\\", \\\"{x:368,y:582,t:1527877112158};\\\", \\\"{x:356,y:582,t:1527877112175};\\\", \\\"{x:350,y:582,t:1527877112191};\\\", \\\"{x:347,y:582,t:1527877112208};\\\", \\\"{x:344,y:582,t:1527877112224};\\\", \\\"{x:341,y:581,t:1527877112241};\\\", \\\"{x:337,y:580,t:1527877112259};\\\", \\\"{x:324,y:578,t:1527877112275};\\\", \\\"{x:314,y:577,t:1527877112291};\\\", \\\"{x:310,y:576,t:1527877112309};\\\", \\\"{x:309,y:576,t:1527877112325};\\\", \\\"{x:308,y:576,t:1527877112341};\\\", \\\"{x:303,y:576,t:1527877112359};\\\", \\\"{x:292,y:576,t:1527877112375};\\\", \\\"{x:284,y:576,t:1527877112391};\\\", \\\"{x:266,y:576,t:1527877112410};\\\", \\\"{x:255,y:576,t:1527877112425};\\\", \\\"{x:250,y:576,t:1527877112441};\\\", \\\"{x:250,y:574,t:1527877112518};\\\", \\\"{x:252,y:572,t:1527877112525};\\\", \\\"{x:256,y:569,t:1527877112541};\\\", \\\"{x:271,y:563,t:1527877112557};\\\", \\\"{x:311,y:553,t:1527877112575};\\\", \\\"{x:397,y:544,t:1527877112592};\\\", \\\"{x:505,y:544,t:1527877112608};\\\", \\\"{x:635,y:544,t:1527877112625};\\\", \\\"{x:765,y:544,t:1527877112643};\\\", \\\"{x:887,y:544,t:1527877112657};\\\", \\\"{x:967,y:544,t:1527877112675};\\\", \\\"{x:1009,y:544,t:1527877112692};\\\", \\\"{x:1027,y:542,t:1527877112709};\\\", \\\"{x:1032,y:541,t:1527877112725};\\\", \\\"{x:1030,y:541,t:1527877112854};\\\", \\\"{x:1022,y:541,t:1527877112862};\\\", \\\"{x:1010,y:541,t:1527877112876};\\\", \\\"{x:983,y:543,t:1527877112893};\\\", \\\"{x:921,y:543,t:1527877112911};\\\", \\\"{x:898,y:539,t:1527877112926};\\\", \\\"{x:887,y:537,t:1527877112942};\\\", \\\"{x:885,y:537,t:1527877112958};\\\", \\\"{x:884,y:537,t:1527877113053};\\\", \\\"{x:881,y:537,t:1527877113061};\\\", \\\"{x:878,y:537,t:1527877113075};\\\", \\\"{x:876,y:537,t:1527877113091};\\\", \\\"{x:873,y:537,t:1527877113150};\\\", \\\"{x:867,y:538,t:1527877113159};\\\", \\\"{x:858,y:539,t:1527877113175};\\\", \\\"{x:856,y:539,t:1527877113192};\\\", \\\"{x:854,y:539,t:1527877113209};\\\", \\\"{x:853,y:539,t:1527877113364};\\\", \\\"{x:852,y:540,t:1527877113375};\\\", \\\"{x:849,y:542,t:1527877113391};\\\", \\\"{x:834,y:554,t:1527877113408};\\\", \\\"{x:792,y:581,t:1527877113426};\\\", \\\"{x:754,y:601,t:1527877113443};\\\", \\\"{x:736,y:610,t:1527877113458};\\\", \\\"{x:728,y:613,t:1527877113475};\\\", \\\"{x:726,y:613,t:1527877113492};\\\", \\\"{x:722,y:615,t:1527877113509};\\\", \\\"{x:713,y:621,t:1527877113526};\\\", \\\"{x:699,y:638,t:1527877113543};\\\", \\\"{x:679,y:654,t:1527877113559};\\\", \\\"{x:665,y:665,t:1527877113576};\\\", \\\"{x:658,y:669,t:1527877113593};\\\", \\\"{x:653,y:671,t:1527877113608};\\\", \\\"{x:650,y:674,t:1527877113626};\\\", \\\"{x:642,y:679,t:1527877113643};\\\", \\\"{x:632,y:686,t:1527877113659};\\\", \\\"{x:625,y:691,t:1527877113676};\\\", \\\"{x:623,y:692,t:1527877113692};\\\", \\\"{x:621,y:692,t:1527877113709};\\\", \\\"{x:610,y:697,t:1527877113725};\\\", \\\"{x:599,y:704,t:1527877113742};\\\", \\\"{x:594,y:707,t:1527877113758};\\\", \\\"{x:586,y:713,t:1527877113776};\\\", \\\"{x:574,y:723,t:1527877113791};\\\", \\\"{x:563,y:729,t:1527877113810};\\\", \\\"{x:559,y:732,t:1527877113826};\\\", \\\"{x:558,y:732,t:1527877113843};\\\", \\\"{x:558,y:733,t:1527877113927};\\\", \\\"{x:559,y:734,t:1527877114286};\\\", \\\"{x:572,y:732,t:1527877114294};\\\", \\\"{x:602,y:716,t:1527877114310};\\\", \\\"{x:645,y:699,t:1527877114326};\\\", \\\"{x:716,y:674,t:1527877114343};\\\", \\\"{x:765,y:657,t:1527877114360};\\\", \\\"{x:798,y:648,t:1527877114376};\\\", \\\"{x:839,y:637,t:1527877114392};\\\", \\\"{x:864,y:628,t:1527877114409};\\\", \\\"{x:879,y:623,t:1527877114426};\\\", \\\"{x:881,y:621,t:1527877114442};\\\", \\\"{x:882,y:621,t:1527877114774};\\\" ] }, { \\\"rt\\\": 15150, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 527489, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -O -Z -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:857,y:626,t:1527877115329};\\\", \\\"{x:849,y:628,t:1527877115343};\\\", \\\"{x:845,y:631,t:1527877115360};\\\", \\\"{x:838,y:634,t:1527877115377};\\\", \\\"{x:829,y:635,t:1527877115394};\\\", \\\"{x:820,y:636,t:1527877115411};\\\", \\\"{x:813,y:636,t:1527877115427};\\\", \\\"{x:807,y:638,t:1527877115444};\\\", \\\"{x:800,y:638,t:1527877115461};\\\", \\\"{x:790,y:638,t:1527877115477};\\\", \\\"{x:787,y:638,t:1527877115507};\\\", \\\"{x:786,y:639,t:1527877115517};\\\", \\\"{x:784,y:639,t:1527877115528};\\\", \\\"{x:783,y:639,t:1527877115543};\\\", \\\"{x:782,y:639,t:1527877115727};\\\", \\\"{x:783,y:640,t:1527877116175};\\\", \\\"{x:787,y:642,t:1527877116182};\\\", \\\"{x:792,y:644,t:1527877116194};\\\", \\\"{x:795,y:646,t:1527877116211};\\\", \\\"{x:796,y:646,t:1527877116791};\\\", \\\"{x:796,y:647,t:1527877116925};\\\", \\\"{x:796,y:648,t:1527877116933};\\\", \\\"{x:796,y:649,t:1527877116944};\\\", \\\"{x:796,y:650,t:1527877116989};\\\", \\\"{x:796,y:651,t:1527877117013};\\\", \\\"{x:796,y:652,t:1527877117029};\\\", \\\"{x:796,y:654,t:1527877117061};\\\", \\\"{x:797,y:656,t:1527877117078};\\\", \\\"{x:797,y:658,t:1527877117094};\\\", \\\"{x:797,y:661,t:1527877117111};\\\", \\\"{x:799,y:663,t:1527877117127};\\\", \\\"{x:801,y:666,t:1527877117144};\\\", \\\"{x:803,y:667,t:1527877117162};\\\", \\\"{x:805,y:669,t:1527877117177};\\\", \\\"{x:807,y:672,t:1527877117194};\\\", \\\"{x:809,y:674,t:1527877117211};\\\", \\\"{x:815,y:680,t:1527877117228};\\\", \\\"{x:818,y:683,t:1527877117245};\\\", \\\"{x:824,y:688,t:1527877117261};\\\", \\\"{x:831,y:691,t:1527877117277};\\\", \\\"{x:844,y:698,t:1527877117294};\\\", \\\"{x:854,y:703,t:1527877117311};\\\", \\\"{x:865,y:708,t:1527877117327};\\\", \\\"{x:881,y:712,t:1527877117344};\\\", \\\"{x:900,y:714,t:1527877117361};\\\", \\\"{x:921,y:715,t:1527877117377};\\\", \\\"{x:937,y:715,t:1527877117394};\\\", \\\"{x:954,y:717,t:1527877117411};\\\", \\\"{x:965,y:718,t:1527877117427};\\\", \\\"{x:974,y:718,t:1527877117444};\\\", \\\"{x:977,y:718,t:1527877117461};\\\", \\\"{x:979,y:718,t:1527877117477};\\\", \\\"{x:982,y:718,t:1527877117495};\\\", \\\"{x:984,y:718,t:1527877117511};\\\", \\\"{x:987,y:718,t:1527877117527};\\\", \\\"{x:990,y:718,t:1527877117544};\\\", \\\"{x:994,y:717,t:1527877117561};\\\", \\\"{x:1000,y:717,t:1527877117577};\\\", \\\"{x:1006,y:717,t:1527877117594};\\\", \\\"{x:1013,y:717,t:1527877117611};\\\", \\\"{x:1019,y:718,t:1527877117627};\\\", \\\"{x:1028,y:720,t:1527877117645};\\\", \\\"{x:1041,y:722,t:1527877117661};\\\", \\\"{x:1050,y:724,t:1527877117677};\\\", \\\"{x:1064,y:727,t:1527877117694};\\\", \\\"{x:1073,y:729,t:1527877117711};\\\", \\\"{x:1089,y:733,t:1527877117727};\\\", \\\"{x:1110,y:740,t:1527877117745};\\\", \\\"{x:1127,y:745,t:1527877117761};\\\", \\\"{x:1137,y:746,t:1527877117777};\\\", \\\"{x:1138,y:748,t:1527877117794};\\\", \\\"{x:1143,y:750,t:1527877118350};\\\", \\\"{x:1150,y:754,t:1527877118362};\\\", \\\"{x:1161,y:763,t:1527877118378};\\\", \\\"{x:1173,y:769,t:1527877118394};\\\", \\\"{x:1186,y:776,t:1527877118411};\\\", \\\"{x:1201,y:784,t:1527877118427};\\\", \\\"{x:1213,y:791,t:1527877118444};\\\", \\\"{x:1227,y:798,t:1527877118461};\\\", \\\"{x:1243,y:805,t:1527877118477};\\\", \\\"{x:1259,y:810,t:1527877118494};\\\", \\\"{x:1265,y:811,t:1527877118512};\\\", \\\"{x:1266,y:811,t:1527877118527};\\\", \\\"{x:1268,y:811,t:1527877118622};\\\", \\\"{x:1269,y:811,t:1527877118630};\\\", \\\"{x:1272,y:811,t:1527877118644};\\\", \\\"{x:1276,y:811,t:1527877118662};\\\", \\\"{x:1296,y:809,t:1527877118678};\\\", \\\"{x:1310,y:808,t:1527877118694};\\\", \\\"{x:1337,y:808,t:1527877118712};\\\", \\\"{x:1360,y:808,t:1527877118727};\\\", \\\"{x:1385,y:808,t:1527877118745};\\\", \\\"{x:1414,y:808,t:1527877118762};\\\", \\\"{x:1447,y:808,t:1527877118777};\\\", \\\"{x:1485,y:807,t:1527877118795};\\\", \\\"{x:1508,y:807,t:1527877118811};\\\", \\\"{x:1525,y:807,t:1527877118828};\\\", \\\"{x:1546,y:805,t:1527877118844};\\\", \\\"{x:1572,y:803,t:1527877118862};\\\", \\\"{x:1586,y:802,t:1527877118878};\\\", \\\"{x:1595,y:799,t:1527877118895};\\\", \\\"{x:1604,y:797,t:1527877118912};\\\", \\\"{x:1617,y:793,t:1527877118927};\\\", \\\"{x:1632,y:789,t:1527877118945};\\\", \\\"{x:1646,y:782,t:1527877118962};\\\", \\\"{x:1661,y:776,t:1527877118978};\\\", \\\"{x:1667,y:774,t:1527877118994};\\\", \\\"{x:1669,y:772,t:1527877119012};\\\", \\\"{x:1671,y:770,t:1527877119027};\\\", \\\"{x:1672,y:766,t:1527877119045};\\\", \\\"{x:1677,y:751,t:1527877119062};\\\", \\\"{x:1683,y:720,t:1527877119078};\\\", \\\"{x:1704,y:653,t:1527877119095};\\\", \\\"{x:1710,y:630,t:1527877119112};\\\", \\\"{x:1711,y:611,t:1527877119127};\\\", \\\"{x:1711,y:588,t:1527877119145};\\\", \\\"{x:1710,y:560,t:1527877119162};\\\", \\\"{x:1703,y:542,t:1527877119178};\\\", \\\"{x:1699,y:532,t:1527877119194};\\\", \\\"{x:1696,y:521,t:1527877119211};\\\", \\\"{x:1692,y:512,t:1527877119228};\\\", \\\"{x:1686,y:501,t:1527877119244};\\\", \\\"{x:1679,y:493,t:1527877119262};\\\", \\\"{x:1664,y:479,t:1527877119278};\\\", \\\"{x:1650,y:472,t:1527877119294};\\\", \\\"{x:1632,y:465,t:1527877119311};\\\", \\\"{x:1612,y:457,t:1527877119327};\\\", \\\"{x:1588,y:448,t:1527877119344};\\\", \\\"{x:1571,y:440,t:1527877119361};\\\", \\\"{x:1551,y:431,t:1527877119377};\\\", \\\"{x:1534,y:424,t:1527877119394};\\\", \\\"{x:1518,y:414,t:1527877119411};\\\", \\\"{x:1509,y:409,t:1527877119427};\\\", \\\"{x:1505,y:405,t:1527877119445};\\\", \\\"{x:1504,y:401,t:1527877119462};\\\", \\\"{x:1502,y:399,t:1527877119478};\\\", \\\"{x:1502,y:396,t:1527877119494};\\\", \\\"{x:1501,y:395,t:1527877119511};\\\", \\\"{x:1501,y:394,t:1527877119527};\\\", \\\"{x:1501,y:399,t:1527877119647};\\\", \\\"{x:1503,y:417,t:1527877119662};\\\", \\\"{x:1505,y:437,t:1527877119678};\\\", \\\"{x:1508,y:454,t:1527877119695};\\\", \\\"{x:1509,y:469,t:1527877119711};\\\", \\\"{x:1512,y:484,t:1527877119727};\\\", \\\"{x:1514,y:493,t:1527877119745};\\\", \\\"{x:1515,y:498,t:1527877119761};\\\", \\\"{x:1516,y:503,t:1527877119778};\\\", \\\"{x:1516,y:505,t:1527877119795};\\\", \\\"{x:1516,y:508,t:1527877119811};\\\", \\\"{x:1516,y:511,t:1527877119828};\\\", \\\"{x:1515,y:518,t:1527877119845};\\\", \\\"{x:1509,y:530,t:1527877119861};\\\", \\\"{x:1506,y:541,t:1527877119878};\\\", \\\"{x:1503,y:551,t:1527877119895};\\\", \\\"{x:1499,y:563,t:1527877119911};\\\", \\\"{x:1496,y:576,t:1527877119928};\\\", \\\"{x:1494,y:589,t:1527877119944};\\\", \\\"{x:1494,y:600,t:1527877119962};\\\", \\\"{x:1496,y:615,t:1527877119977};\\\", \\\"{x:1500,y:626,t:1527877119994};\\\", \\\"{x:1505,y:636,t:1527877120012};\\\", \\\"{x:1511,y:647,t:1527877120028};\\\", \\\"{x:1514,y:658,t:1527877120044};\\\", \\\"{x:1519,y:667,t:1527877120062};\\\", \\\"{x:1522,y:681,t:1527877120078};\\\", \\\"{x:1527,y:693,t:1527877120095};\\\", \\\"{x:1532,y:702,t:1527877120111};\\\", \\\"{x:1533,y:707,t:1527877120127};\\\", \\\"{x:1534,y:709,t:1527877120144};\\\", \\\"{x:1535,y:709,t:1527877120162};\\\", \\\"{x:1535,y:711,t:1527877120178};\\\", \\\"{x:1535,y:712,t:1527877120198};\\\", \\\"{x:1534,y:712,t:1527877120212};\\\", \\\"{x:1534,y:713,t:1527877120227};\\\", \\\"{x:1532,y:716,t:1527877120245};\\\", \\\"{x:1531,y:720,t:1527877120262};\\\", \\\"{x:1528,y:724,t:1527877120278};\\\", \\\"{x:1527,y:727,t:1527877120295};\\\", \\\"{x:1525,y:729,t:1527877120311};\\\", \\\"{x:1524,y:730,t:1527877120328};\\\", \\\"{x:1523,y:732,t:1527877120350};\\\", \\\"{x:1523,y:733,t:1527877120362};\\\", \\\"{x:1522,y:735,t:1527877120378};\\\", \\\"{x:1522,y:736,t:1527877120394};\\\", \\\"{x:1522,y:739,t:1527877120411};\\\", \\\"{x:1522,y:742,t:1527877120428};\\\", \\\"{x:1522,y:744,t:1527877120444};\\\", \\\"{x:1522,y:750,t:1527877120462};\\\", \\\"{x:1522,y:753,t:1527877120478};\\\", \\\"{x:1522,y:756,t:1527877120494};\\\", \\\"{x:1523,y:763,t:1527877120512};\\\", \\\"{x:1523,y:768,t:1527877120528};\\\", \\\"{x:1523,y:774,t:1527877120544};\\\", \\\"{x:1523,y:779,t:1527877120562};\\\", \\\"{x:1523,y:781,t:1527877120577};\\\", \\\"{x:1523,y:782,t:1527877120595};\\\", \\\"{x:1522,y:786,t:1527877120611};\\\", \\\"{x:1520,y:789,t:1527877120627};\\\", \\\"{x:1517,y:793,t:1527877120644};\\\", \\\"{x:1514,y:797,t:1527877120661};\\\", \\\"{x:1513,y:800,t:1527877120678};\\\", \\\"{x:1508,y:806,t:1527877120694};\\\", \\\"{x:1503,y:810,t:1527877120712};\\\", \\\"{x:1495,y:814,t:1527877120727};\\\", \\\"{x:1485,y:819,t:1527877120745};\\\", \\\"{x:1478,y:823,t:1527877120762};\\\", \\\"{x:1474,y:826,t:1527877120779};\\\", \\\"{x:1471,y:829,t:1527877120795};\\\", \\\"{x:1469,y:831,t:1527877120812};\\\", \\\"{x:1468,y:833,t:1527877120827};\\\", \\\"{x:1466,y:836,t:1527877120845};\\\", \\\"{x:1463,y:837,t:1527877120861};\\\", \\\"{x:1462,y:839,t:1527877120878};\\\", \\\"{x:1461,y:839,t:1527877120902};\\\", \\\"{x:1461,y:840,t:1527877120926};\\\", \\\"{x:1459,y:842,t:1527877120934};\\\", \\\"{x:1458,y:843,t:1527877120950};\\\", \\\"{x:1457,y:845,t:1527877120966};\\\", \\\"{x:1455,y:847,t:1527877120978};\\\", \\\"{x:1452,y:850,t:1527877120995};\\\", \\\"{x:1451,y:854,t:1527877121012};\\\", \\\"{x:1451,y:856,t:1527877121028};\\\", \\\"{x:1450,y:856,t:1527877121044};\\\", \\\"{x:1450,y:857,t:1527877121133};\\\", \\\"{x:1449,y:857,t:1527877121144};\\\", \\\"{x:1447,y:857,t:1527877121189};\\\", \\\"{x:1445,y:859,t:1527877121205};\\\", \\\"{x:1444,y:862,t:1527877121213};\\\", \\\"{x:1442,y:866,t:1527877121227};\\\", \\\"{x:1441,y:867,t:1527877121244};\\\", \\\"{x:1441,y:872,t:1527877121261};\\\", \\\"{x:1441,y:873,t:1527877121301};\\\", \\\"{x:1441,y:874,t:1527877121375};\\\", \\\"{x:1441,y:876,t:1527877121406};\\\", \\\"{x:1441,y:877,t:1527877121414};\\\", \\\"{x:1442,y:877,t:1527877121430};\\\", \\\"{x:1443,y:877,t:1527877121446};\\\", \\\"{x:1444,y:877,t:1527877121462};\\\", \\\"{x:1447,y:877,t:1527877121478};\\\", \\\"{x:1450,y:877,t:1527877121495};\\\", \\\"{x:1454,y:877,t:1527877121512};\\\", \\\"{x:1456,y:876,t:1527877121528};\\\", \\\"{x:1459,y:876,t:1527877121545};\\\", \\\"{x:1462,y:874,t:1527877121561};\\\", \\\"{x:1464,y:873,t:1527877121577};\\\", \\\"{x:1465,y:873,t:1527877121598};\\\", \\\"{x:1468,y:871,t:1527877121614};\\\", \\\"{x:1471,y:869,t:1527877121628};\\\", \\\"{x:1475,y:864,t:1527877121645};\\\", \\\"{x:1483,y:857,t:1527877121662};\\\", \\\"{x:1492,y:849,t:1527877121678};\\\", \\\"{x:1501,y:842,t:1527877121694};\\\", \\\"{x:1514,y:828,t:1527877121712};\\\", \\\"{x:1524,y:810,t:1527877121728};\\\", \\\"{x:1529,y:798,t:1527877121745};\\\", \\\"{x:1531,y:792,t:1527877121761};\\\", \\\"{x:1532,y:789,t:1527877121779};\\\", \\\"{x:1532,y:786,t:1527877121795};\\\", \\\"{x:1532,y:783,t:1527877121811};\\\", \\\"{x:1532,y:780,t:1527877121829};\\\", \\\"{x:1532,y:779,t:1527877121845};\\\", \\\"{x:1532,y:777,t:1527877121862};\\\", \\\"{x:1532,y:776,t:1527877121879};\\\", \\\"{x:1532,y:774,t:1527877121895};\\\", \\\"{x:1531,y:771,t:1527877121912};\\\", \\\"{x:1528,y:768,t:1527877121929};\\\", \\\"{x:1522,y:763,t:1527877121944};\\\", \\\"{x:1515,y:760,t:1527877121964};\\\", \\\"{x:1501,y:754,t:1527877121980};\\\", \\\"{x:1487,y:747,t:1527877121994};\\\", \\\"{x:1474,y:743,t:1527877122012};\\\", \\\"{x:1467,y:738,t:1527877122028};\\\", \\\"{x:1464,y:736,t:1527877122045};\\\", \\\"{x:1459,y:733,t:1527877122062};\\\", \\\"{x:1458,y:732,t:1527877122079};\\\", \\\"{x:1457,y:731,t:1527877122094};\\\", \\\"{x:1457,y:730,t:1527877122126};\\\", \\\"{x:1459,y:729,t:1527877122134};\\\", \\\"{x:1464,y:725,t:1527877122145};\\\", \\\"{x:1480,y:720,t:1527877122162};\\\", \\\"{x:1501,y:715,t:1527877122178};\\\", \\\"{x:1511,y:712,t:1527877122195};\\\", \\\"{x:1516,y:710,t:1527877122211};\\\", \\\"{x:1522,y:709,t:1527877122228};\\\", \\\"{x:1526,y:706,t:1527877122245};\\\", \\\"{x:1531,y:703,t:1527877122261};\\\", \\\"{x:1534,y:702,t:1527877122278};\\\", \\\"{x:1536,y:702,t:1527877122294};\\\", \\\"{x:1538,y:700,t:1527877122312};\\\", \\\"{x:1539,y:700,t:1527877122329};\\\", \\\"{x:1541,y:700,t:1527877122345};\\\", \\\"{x:1543,y:700,t:1527877122362};\\\", \\\"{x:1545,y:700,t:1527877122379};\\\", \\\"{x:1550,y:700,t:1527877122394};\\\", \\\"{x:1557,y:700,t:1527877122412};\\\", \\\"{x:1565,y:700,t:1527877122429};\\\", \\\"{x:1567,y:700,t:1527877122444};\\\", \\\"{x:1575,y:700,t:1527877122462};\\\", \\\"{x:1578,y:700,t:1527877122478};\\\", \\\"{x:1581,y:700,t:1527877122494};\\\", \\\"{x:1583,y:700,t:1527877122511};\\\", \\\"{x:1584,y:700,t:1527877122527};\\\", \\\"{x:1585,y:700,t:1527877122614};\\\", \\\"{x:1587,y:700,t:1527877122629};\\\", \\\"{x:1588,y:710,t:1527877122644};\\\", \\\"{x:1588,y:733,t:1527877122662};\\\", \\\"{x:1588,y:754,t:1527877122678};\\\", \\\"{x:1587,y:772,t:1527877122695};\\\", \\\"{x:1586,y:788,t:1527877122712};\\\", \\\"{x:1582,y:808,t:1527877122729};\\\", \\\"{x:1579,y:829,t:1527877122745};\\\", \\\"{x:1578,y:855,t:1527877122762};\\\", \\\"{x:1573,y:877,t:1527877122779};\\\", \\\"{x:1570,y:890,t:1527877122795};\\\", \\\"{x:1569,y:905,t:1527877122811};\\\", \\\"{x:1565,y:922,t:1527877122829};\\\", \\\"{x:1563,y:935,t:1527877122845};\\\", \\\"{x:1563,y:940,t:1527877122862};\\\", \\\"{x:1561,y:942,t:1527877122878};\\\", \\\"{x:1561,y:943,t:1527877122894};\\\", \\\"{x:1561,y:946,t:1527877122911};\\\", \\\"{x:1560,y:946,t:1527877122928};\\\", \\\"{x:1560,y:948,t:1527877122945};\\\", \\\"{x:1560,y:950,t:1527877122998};\\\", \\\"{x:1560,y:951,t:1527877123012};\\\", \\\"{x:1560,y:952,t:1527877123118};\\\", \\\"{x:1561,y:952,t:1527877123129};\\\", \\\"{x:1565,y:950,t:1527877123145};\\\", \\\"{x:1569,y:945,t:1527877123161};\\\", \\\"{x:1574,y:935,t:1527877123178};\\\", \\\"{x:1581,y:919,t:1527877123195};\\\", \\\"{x:1587,y:898,t:1527877123212};\\\", \\\"{x:1599,y:868,t:1527877123228};\\\", \\\"{x:1615,y:839,t:1527877123245};\\\", \\\"{x:1647,y:786,t:1527877123262};\\\", \\\"{x:1665,y:754,t:1527877123278};\\\", \\\"{x:1672,y:735,t:1527877123295};\\\", \\\"{x:1676,y:725,t:1527877123311};\\\", \\\"{x:1677,y:721,t:1527877123329};\\\", \\\"{x:1677,y:720,t:1527877123366};\\\", \\\"{x:1677,y:718,t:1527877123377};\\\", \\\"{x:1677,y:713,t:1527877123394};\\\", \\\"{x:1675,y:706,t:1527877123411};\\\", \\\"{x:1669,y:698,t:1527877123428};\\\", \\\"{x:1662,y:692,t:1527877123444};\\\", \\\"{x:1659,y:691,t:1527877123461};\\\", \\\"{x:1655,y:690,t:1527877123478};\\\", \\\"{x:1646,y:690,t:1527877123494};\\\", \\\"{x:1630,y:692,t:1527877123512};\\\", \\\"{x:1624,y:693,t:1527877123529};\\\", \\\"{x:1612,y:697,t:1527877123546};\\\", \\\"{x:1607,y:698,t:1527877123563};\\\", \\\"{x:1606,y:698,t:1527877123579};\\\", \\\"{x:1606,y:699,t:1527877123694};\\\", \\\"{x:1606,y:701,t:1527877123711};\\\", \\\"{x:1606,y:705,t:1527877123729};\\\", \\\"{x:1606,y:706,t:1527877123744};\\\", \\\"{x:1606,y:708,t:1527877123762};\\\", \\\"{x:1606,y:711,t:1527877123779};\\\", \\\"{x:1606,y:714,t:1527877123795};\\\", \\\"{x:1606,y:717,t:1527877123812};\\\", \\\"{x:1603,y:721,t:1527877123828};\\\", \\\"{x:1597,y:735,t:1527877123855};\\\", \\\"{x:1596,y:738,t:1527877123861};\\\", \\\"{x:1594,y:742,t:1527877123905};\\\", \\\"{x:1593,y:742,t:1527877123924};\\\", \\\"{x:1593,y:743,t:1527877123933};\\\", \\\"{x:1592,y:744,t:1527877123943};\\\", \\\"{x:1590,y:746,t:1527877123961};\\\", \\\"{x:1587,y:751,t:1527877123978};\\\", \\\"{x:1585,y:755,t:1527877123994};\\\", \\\"{x:1582,y:759,t:1527877124012};\\\", \\\"{x:1580,y:764,t:1527877124028};\\\", \\\"{x:1577,y:768,t:1527877124044};\\\", \\\"{x:1573,y:775,t:1527877124061};\\\", \\\"{x:1570,y:779,t:1527877124078};\\\", \\\"{x:1565,y:784,t:1527877124094};\\\", \\\"{x:1559,y:793,t:1527877124111};\\\", \\\"{x:1552,y:801,t:1527877124128};\\\", \\\"{x:1548,y:807,t:1527877124144};\\\", \\\"{x:1547,y:809,t:1527877124161};\\\", \\\"{x:1546,y:810,t:1527877124178};\\\", \\\"{x:1545,y:812,t:1527877124194};\\\", \\\"{x:1544,y:817,t:1527877124211};\\\", \\\"{x:1541,y:824,t:1527877124228};\\\", \\\"{x:1538,y:830,t:1527877124245};\\\", \\\"{x:1537,y:834,t:1527877124261};\\\", \\\"{x:1537,y:836,t:1527877124293};\\\", \\\"{x:1537,y:837,t:1527877124311};\\\", \\\"{x:1536,y:838,t:1527877124328};\\\", \\\"{x:1536,y:839,t:1527877124344};\\\", \\\"{x:1536,y:840,t:1527877124361};\\\", \\\"{x:1536,y:842,t:1527877124382};\\\", \\\"{x:1536,y:843,t:1527877124406};\\\", \\\"{x:1536,y:844,t:1527877124499};\\\", \\\"{x:1536,y:853,t:1527877124552};\\\", \\\"{x:1536,y:854,t:1527877124561};\\\", \\\"{x:1535,y:856,t:1527877124580};\\\", \\\"{x:1534,y:858,t:1527877124597};\\\", \\\"{x:1534,y:859,t:1527877124611};\\\", \\\"{x:1533,y:863,t:1527877124628};\\\", \\\"{x:1531,y:867,t:1527877124644};\\\", \\\"{x:1531,y:870,t:1527877124661};\\\", \\\"{x:1530,y:871,t:1527877124678};\\\", \\\"{x:1530,y:872,t:1527877124709};\\\", \\\"{x:1529,y:874,t:1527877124717};\\\", \\\"{x:1529,y:875,t:1527877124757};\\\", \\\"{x:1529,y:876,t:1527877124765};\\\", \\\"{x:1529,y:878,t:1527877124778};\\\", \\\"{x:1528,y:879,t:1527877124794};\\\", \\\"{x:1528,y:880,t:1527877124811};\\\", \\\"{x:1528,y:881,t:1527877124878};\\\", \\\"{x:1527,y:881,t:1527877124895};\\\", \\\"{x:1527,y:883,t:1527877124918};\\\", \\\"{x:1527,y:884,t:1527877125173};\\\", \\\"{x:1527,y:886,t:1527877125181};\\\", \\\"{x:1526,y:886,t:1527877125194};\\\", \\\"{x:1524,y:890,t:1527877125211};\\\", \\\"{x:1523,y:891,t:1527877125228};\\\", \\\"{x:1521,y:895,t:1527877125244};\\\", \\\"{x:1518,y:900,t:1527877125261};\\\", \\\"{x:1515,y:906,t:1527877125278};\\\", \\\"{x:1513,y:909,t:1527877125294};\\\", \\\"{x:1509,y:916,t:1527877125312};\\\", \\\"{x:1508,y:920,t:1527877125328};\\\", \\\"{x:1506,y:924,t:1527877125344};\\\", \\\"{x:1504,y:928,t:1527877125361};\\\", \\\"{x:1502,y:932,t:1527877125379};\\\", \\\"{x:1500,y:936,t:1527877125394};\\\", \\\"{x:1498,y:943,t:1527877125412};\\\", \\\"{x:1496,y:947,t:1527877125428};\\\", \\\"{x:1494,y:951,t:1527877125445};\\\", \\\"{x:1493,y:955,t:1527877125461};\\\", \\\"{x:1491,y:958,t:1527877125478};\\\", \\\"{x:1490,y:961,t:1527877125495};\\\", \\\"{x:1488,y:964,t:1527877125512};\\\", \\\"{x:1487,y:965,t:1527877125529};\\\", \\\"{x:1486,y:967,t:1527877125545};\\\", \\\"{x:1486,y:968,t:1527877125574};\\\", \\\"{x:1485,y:968,t:1527877125598};\\\", \\\"{x:1484,y:968,t:1527877125614};\\\", \\\"{x:1484,y:969,t:1527877125630};\\\", \\\"{x:1483,y:970,t:1527877125645};\\\", \\\"{x:1482,y:970,t:1527877125662};\\\", \\\"{x:1481,y:970,t:1527877125758};\\\", \\\"{x:1480,y:970,t:1527877125814};\\\", \\\"{x:1479,y:969,t:1527877125828};\\\", \\\"{x:1479,y:967,t:1527877125845};\\\", \\\"{x:1479,y:964,t:1527877125861};\\\", \\\"{x:1479,y:962,t:1527877125879};\\\", \\\"{x:1479,y:960,t:1527877125895};\\\", \\\"{x:1479,y:959,t:1527877125912};\\\", \\\"{x:1478,y:956,t:1527877125928};\\\", \\\"{x:1477,y:954,t:1527877125945};\\\", \\\"{x:1476,y:953,t:1527877125962};\\\", \\\"{x:1474,y:950,t:1527877125979};\\\", \\\"{x:1473,y:949,t:1527877125995};\\\", \\\"{x:1472,y:947,t:1527877126012};\\\", \\\"{x:1472,y:945,t:1527877126029};\\\", \\\"{x:1469,y:942,t:1527877126045};\\\", \\\"{x:1467,y:938,t:1527877126062};\\\", \\\"{x:1466,y:937,t:1527877126078};\\\", \\\"{x:1465,y:936,t:1527877126095};\\\", \\\"{x:1464,y:932,t:1527877126112};\\\", \\\"{x:1464,y:931,t:1527877126128};\\\", \\\"{x:1462,y:927,t:1527877126144};\\\", \\\"{x:1460,y:924,t:1527877126161};\\\", \\\"{x:1456,y:919,t:1527877126178};\\\", \\\"{x:1448,y:912,t:1527877126195};\\\", \\\"{x:1443,y:907,t:1527877126212};\\\", \\\"{x:1437,y:902,t:1527877126229};\\\", \\\"{x:1435,y:899,t:1527877126245};\\\", \\\"{x:1432,y:892,t:1527877126262};\\\", \\\"{x:1429,y:887,t:1527877126278};\\\", \\\"{x:1425,y:884,t:1527877126294};\\\", \\\"{x:1424,y:880,t:1527877126312};\\\", \\\"{x:1421,y:876,t:1527877126328};\\\", \\\"{x:1420,y:872,t:1527877126345};\\\", \\\"{x:1419,y:869,t:1527877126362};\\\", \\\"{x:1418,y:865,t:1527877126379};\\\", \\\"{x:1417,y:862,t:1527877126395};\\\", \\\"{x:1413,y:856,t:1527877126411};\\\", \\\"{x:1413,y:852,t:1527877126428};\\\", \\\"{x:1410,y:845,t:1527877126444};\\\", \\\"{x:1408,y:837,t:1527877126462};\\\", \\\"{x:1405,y:831,t:1527877126478};\\\", \\\"{x:1404,y:824,t:1527877126495};\\\", \\\"{x:1402,y:821,t:1527877126511};\\\", \\\"{x:1401,y:817,t:1527877126528};\\\", \\\"{x:1401,y:812,t:1527877126545};\\\", \\\"{x:1398,y:804,t:1527877126561};\\\", \\\"{x:1393,y:793,t:1527877126578};\\\", \\\"{x:1382,y:780,t:1527877126595};\\\", \\\"{x:1377,y:774,t:1527877126611};\\\", \\\"{x:1372,y:766,t:1527877126628};\\\", \\\"{x:1366,y:761,t:1527877126645};\\\", \\\"{x:1361,y:754,t:1527877126661};\\\", \\\"{x:1354,y:746,t:1527877126679};\\\", \\\"{x:1347,y:735,t:1527877126694};\\\", \\\"{x:1340,y:728,t:1527877126712};\\\", \\\"{x:1337,y:724,t:1527877126729};\\\", \\\"{x:1335,y:720,t:1527877126745};\\\", \\\"{x:1335,y:718,t:1527877126762};\\\", \\\"{x:1335,y:716,t:1527877126779};\\\", \\\"{x:1335,y:713,t:1527877126795};\\\", \\\"{x:1335,y:711,t:1527877126811};\\\", \\\"{x:1335,y:708,t:1527877126829};\\\", \\\"{x:1335,y:704,t:1527877126845};\\\", \\\"{x:1335,y:701,t:1527877126862};\\\", \\\"{x:1335,y:697,t:1527877126878};\\\", \\\"{x:1335,y:694,t:1527877126895};\\\", \\\"{x:1336,y:687,t:1527877126912};\\\", \\\"{x:1336,y:680,t:1527877126929};\\\", \\\"{x:1333,y:667,t:1527877126944};\\\", \\\"{x:1327,y:658,t:1527877126962};\\\", \\\"{x:1324,y:654,t:1527877126979};\\\", \\\"{x:1321,y:650,t:1527877126995};\\\", \\\"{x:1317,y:646,t:1527877127012};\\\", \\\"{x:1314,y:643,t:1527877127028};\\\", \\\"{x:1311,y:640,t:1527877127044};\\\", \\\"{x:1301,y:634,t:1527877127061};\\\", \\\"{x:1289,y:629,t:1527877127079};\\\", \\\"{x:1273,y:624,t:1527877127094};\\\", \\\"{x:1254,y:618,t:1527877127111};\\\", \\\"{x:1231,y:612,t:1527877127129};\\\", \\\"{x:1207,y:603,t:1527877127145};\\\", \\\"{x:1177,y:592,t:1527877127162};\\\", \\\"{x:1144,y:582,t:1527877127178};\\\", \\\"{x:1102,y:571,t:1527877127195};\\\", \\\"{x:1054,y:563,t:1527877127212};\\\", \\\"{x:1009,y:557,t:1527877127229};\\\", \\\"{x:964,y:550,t:1527877127245};\\\", \\\"{x:912,y:544,t:1527877127263};\\\", \\\"{x:880,y:540,t:1527877127278};\\\", \\\"{x:863,y:538,t:1527877127294};\\\", \\\"{x:852,y:538,t:1527877127303};\\\", \\\"{x:831,y:538,t:1527877127320};\\\", \\\"{x:809,y:538,t:1527877127337};\\\", \\\"{x:785,y:540,t:1527877127353};\\\", \\\"{x:767,y:543,t:1527877127370};\\\", \\\"{x:753,y:548,t:1527877127386};\\\", \\\"{x:743,y:549,t:1527877127403};\\\", \\\"{x:734,y:550,t:1527877127420};\\\", \\\"{x:720,y:552,t:1527877127437};\\\", \\\"{x:696,y:558,t:1527877127454};\\\", \\\"{x:676,y:564,t:1527877127471};\\\", \\\"{x:669,y:566,t:1527877127486};\\\", \\\"{x:665,y:568,t:1527877127503};\\\", \\\"{x:662,y:568,t:1527877127520};\\\", \\\"{x:660,y:568,t:1527877127537};\\\", \\\"{x:658,y:568,t:1527877127554};\\\", \\\"{x:653,y:568,t:1527877127570};\\\", \\\"{x:649,y:568,t:1527877127586};\\\", \\\"{x:643,y:568,t:1527877127603};\\\", \\\"{x:637,y:568,t:1527877127620};\\\", \\\"{x:632,y:567,t:1527877127638};\\\", \\\"{x:630,y:565,t:1527877127654};\\\", \\\"{x:630,y:564,t:1527877127670};\\\", \\\"{x:630,y:562,t:1527877127688};\\\", \\\"{x:629,y:559,t:1527877127703};\\\", \\\"{x:629,y:554,t:1527877127721};\\\", \\\"{x:627,y:545,t:1527877127737};\\\", \\\"{x:625,y:539,t:1527877127753};\\\", \\\"{x:624,y:534,t:1527877127770};\\\", \\\"{x:623,y:531,t:1527877127787};\\\", \\\"{x:622,y:529,t:1527877127803};\\\", \\\"{x:621,y:528,t:1527877127820};\\\", \\\"{x:620,y:524,t:1527877127838};\\\", \\\"{x:620,y:520,t:1527877127854};\\\", \\\"{x:617,y:516,t:1527877127871};\\\", \\\"{x:615,y:514,t:1527877127887};\\\", \\\"{x:614,y:513,t:1527877127903};\\\", \\\"{x:615,y:513,t:1527877128261};\\\", \\\"{x:617,y:513,t:1527877128270};\\\", \\\"{x:621,y:513,t:1527877128288};\\\", \\\"{x:629,y:513,t:1527877128304};\\\", \\\"{x:641,y:513,t:1527877128320};\\\", \\\"{x:657,y:513,t:1527877128337};\\\", \\\"{x:666,y:513,t:1527877128354};\\\", \\\"{x:675,y:513,t:1527877128370};\\\", \\\"{x:683,y:513,t:1527877128387};\\\", \\\"{x:693,y:513,t:1527877128405};\\\", \\\"{x:701,y:513,t:1527877128420};\\\", \\\"{x:713,y:513,t:1527877128437};\\\", \\\"{x:717,y:513,t:1527877128455};\\\", \\\"{x:725,y:511,t:1527877128473};\\\", \\\"{x:729,y:509,t:1527877128488};\\\", \\\"{x:734,y:509,t:1527877128504};\\\", \\\"{x:738,y:509,t:1527877128521};\\\", \\\"{x:740,y:508,t:1527877128537};\\\", \\\"{x:743,y:508,t:1527877128554};\\\", \\\"{x:744,y:508,t:1527877128571};\\\", \\\"{x:749,y:507,t:1527877128587};\\\", \\\"{x:757,y:507,t:1527877128604};\\\", \\\"{x:771,y:507,t:1527877128621};\\\", \\\"{x:789,y:505,t:1527877128637};\\\", \\\"{x:807,y:505,t:1527877128655};\\\", \\\"{x:820,y:505,t:1527877128671};\\\", \\\"{x:829,y:505,t:1527877128688};\\\", \\\"{x:836,y:505,t:1527877128705};\\\", \\\"{x:841,y:505,t:1527877128722};\\\", \\\"{x:843,y:505,t:1527877128737};\\\", \\\"{x:846,y:504,t:1527877128754};\\\", \\\"{x:844,y:504,t:1527877128997};\\\", \\\"{x:843,y:505,t:1527877129005};\\\", \\\"{x:841,y:505,t:1527877129021};\\\", \\\"{x:836,y:508,t:1527877129038};\\\", \\\"{x:831,y:512,t:1527877129054};\\\", \\\"{x:827,y:519,t:1527877129072};\\\", \\\"{x:825,y:526,t:1527877129089};\\\", \\\"{x:822,y:530,t:1527877129104};\\\", \\\"{x:818,y:536,t:1527877129121};\\\", \\\"{x:812,y:542,t:1527877129138};\\\", \\\"{x:801,y:550,t:1527877129154};\\\", \\\"{x:790,y:558,t:1527877129172};\\\", \\\"{x:775,y:569,t:1527877129189};\\\", \\\"{x:759,y:580,t:1527877129205};\\\", \\\"{x:741,y:599,t:1527877129221};\\\", \\\"{x:729,y:612,t:1527877129239};\\\", \\\"{x:715,y:622,t:1527877129255};\\\", \\\"{x:702,y:630,t:1527877129271};\\\", \\\"{x:688,y:639,t:1527877129289};\\\", \\\"{x:662,y:654,t:1527877129306};\\\", \\\"{x:631,y:674,t:1527877129321};\\\", \\\"{x:606,y:692,t:1527877129339};\\\", \\\"{x:596,y:702,t:1527877129355};\\\", \\\"{x:584,y:713,t:1527877129371};\\\", \\\"{x:574,y:725,t:1527877129388};\\\", \\\"{x:564,y:738,t:1527877129405};\\\", \\\"{x:562,y:742,t:1527877129421};\\\", \\\"{x:561,y:744,t:1527877129439};\\\", \\\"{x:559,y:747,t:1527877129455};\\\", \\\"{x:558,y:749,t:1527877129471};\\\", \\\"{x:557,y:750,t:1527877129488};\\\", \\\"{x:556,y:750,t:1527877129505};\\\", \\\"{x:555,y:752,t:1527877129526};\\\", \\\"{x:554,y:752,t:1527877129539};\\\", \\\"{x:548,y:753,t:1527877129556};\\\", \\\"{x:540,y:754,t:1527877129571};\\\", \\\"{x:536,y:755,t:1527877129589};\\\", \\\"{x:534,y:755,t:1527877129606};\\\", \\\"{x:533,y:755,t:1527877129630};\\\", \\\"{x:532,y:755,t:1527877129661};\\\", \\\"{x:531,y:754,t:1527877129673};\\\", \\\"{x:530,y:753,t:1527877129688};\\\", \\\"{x:530,y:750,t:1527877129705};\\\", \\\"{x:530,y:749,t:1527877129721};\\\", \\\"{x:530,y:746,t:1527877129738};\\\", \\\"{x:529,y:744,t:1527877129755};\\\", \\\"{x:529,y:743,t:1527877129772};\\\", \\\"{x:528,y:742,t:1527877129788};\\\", \\\"{x:528,y:741,t:1527877129813};\\\", \\\"{x:528,y:740,t:1527877129845};\\\" ] }, { \\\"rt\\\": 7551, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 536367, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:739,t:1527877131973};\\\", \\\"{x:529,y:738,t:1527877131990};\\\", \\\"{x:530,y:738,t:1527877132013};\\\", \\\"{x:531,y:737,t:1527877132023};\\\", \\\"{x:534,y:737,t:1527877132040};\\\", \\\"{x:539,y:737,t:1527877132057};\\\", \\\"{x:555,y:737,t:1527877132074};\\\", \\\"{x:575,y:737,t:1527877132091};\\\", \\\"{x:601,y:739,t:1527877132108};\\\", \\\"{x:760,y:740,t:1527877132228};\\\", \\\"{x:775,y:734,t:1527877132242};\\\", \\\"{x:788,y:726,t:1527877132257};\\\", \\\"{x:793,y:720,t:1527877132273};\\\", \\\"{x:797,y:718,t:1527877132290};\\\", \\\"{x:798,y:717,t:1527877132308};\\\", \\\"{x:804,y:709,t:1527877132324};\\\", \\\"{x:812,y:694,t:1527877132340};\\\", \\\"{x:819,y:674,t:1527877132357};\\\", \\\"{x:820,y:665,t:1527877132374};\\\", \\\"{x:820,y:656,t:1527877132391};\\\", \\\"{x:820,y:648,t:1527877132407};\\\", \\\"{x:816,y:639,t:1527877132424};\\\", \\\"{x:808,y:627,t:1527877132441};\\\", \\\"{x:799,y:613,t:1527877132458};\\\", \\\"{x:794,y:602,t:1527877132474};\\\", \\\"{x:791,y:593,t:1527877132491};\\\", \\\"{x:790,y:587,t:1527877132507};\\\", \\\"{x:790,y:585,t:1527877132523};\\\", \\\"{x:793,y:584,t:1527877132814};\\\", \\\"{x:801,y:584,t:1527877132825};\\\", \\\"{x:804,y:586,t:1527877132841};\\\", \\\"{x:804,y:587,t:1527877132858};\\\", \\\"{x:810,y:587,t:1527877133278};\\\", \\\"{x:833,y:591,t:1527877133292};\\\", \\\"{x:891,y:604,t:1527877133309};\\\", \\\"{x:951,y:627,t:1527877133325};\\\", \\\"{x:1023,y:657,t:1527877133342};\\\", \\\"{x:1087,y:685,t:1527877133358};\\\", \\\"{x:1167,y:717,t:1527877133374};\\\", \\\"{x:1237,y:741,t:1527877133391};\\\", \\\"{x:1320,y:761,t:1527877133408};\\\", \\\"{x:1390,y:787,t:1527877133424};\\\", \\\"{x:1431,y:802,t:1527877133442};\\\", \\\"{x:1473,y:822,t:1527877133459};\\\", \\\"{x:1505,y:839,t:1527877133475};\\\", \\\"{x:1532,y:861,t:1527877133492};\\\", \\\"{x:1555,y:876,t:1527877133509};\\\", \\\"{x:1584,y:895,t:1527877133524};\\\", \\\"{x:1598,y:901,t:1527877133542};\\\", \\\"{x:1601,y:905,t:1527877133559};\\\", \\\"{x:1604,y:908,t:1527877133575};\\\", \\\"{x:1604,y:913,t:1527877133591};\\\", \\\"{x:1604,y:915,t:1527877133608};\\\", \\\"{x:1603,y:921,t:1527877133626};\\\", \\\"{x:1601,y:923,t:1527877133642};\\\", \\\"{x:1601,y:925,t:1527877133659};\\\", \\\"{x:1601,y:926,t:1527877133676};\\\", \\\"{x:1599,y:928,t:1527877133694};\\\", \\\"{x:1598,y:929,t:1527877133709};\\\", \\\"{x:1594,y:934,t:1527877133725};\\\", \\\"{x:1588,y:938,t:1527877133741};\\\", \\\"{x:1578,y:946,t:1527877133759};\\\", \\\"{x:1574,y:950,t:1527877133776};\\\", \\\"{x:1571,y:951,t:1527877133792};\\\", \\\"{x:1569,y:952,t:1527877133809};\\\", \\\"{x:1566,y:953,t:1527877133826};\\\", \\\"{x:1565,y:953,t:1527877133902};\\\", \\\"{x:1564,y:953,t:1527877133934};\\\", \\\"{x:1563,y:953,t:1527877133958};\\\", \\\"{x:1559,y:953,t:1527877133976};\\\", \\\"{x:1553,y:953,t:1527877133994};\\\", \\\"{x:1545,y:953,t:1527877134010};\\\", \\\"{x:1542,y:953,t:1527877134026};\\\", \\\"{x:1540,y:953,t:1527877134044};\\\", \\\"{x:1539,y:953,t:1527877134059};\\\", \\\"{x:1537,y:951,t:1527877134076};\\\", \\\"{x:1533,y:943,t:1527877134094};\\\", \\\"{x:1525,y:930,t:1527877134110};\\\", \\\"{x:1521,y:920,t:1527877134126};\\\", \\\"{x:1517,y:912,t:1527877134144};\\\", \\\"{x:1516,y:908,t:1527877134160};\\\", \\\"{x:1515,y:906,t:1527877134176};\\\", \\\"{x:1515,y:904,t:1527877134193};\\\", \\\"{x:1514,y:901,t:1527877134210};\\\", \\\"{x:1512,y:895,t:1527877134226};\\\", \\\"{x:1510,y:892,t:1527877134242};\\\", \\\"{x:1510,y:885,t:1527877134260};\\\", \\\"{x:1507,y:881,t:1527877134276};\\\", \\\"{x:1506,y:877,t:1527877134294};\\\", \\\"{x:1504,y:873,t:1527877134309};\\\", \\\"{x:1502,y:869,t:1527877134326};\\\", \\\"{x:1499,y:865,t:1527877134344};\\\", \\\"{x:1496,y:862,t:1527877134360};\\\", \\\"{x:1495,y:860,t:1527877134377};\\\", \\\"{x:1493,y:859,t:1527877134393};\\\", \\\"{x:1492,y:853,t:1527877134410};\\\", \\\"{x:1488,y:849,t:1527877134426};\\\", \\\"{x:1485,y:844,t:1527877134443};\\\", \\\"{x:1481,y:839,t:1527877134460};\\\", \\\"{x:1478,y:835,t:1527877134476};\\\", \\\"{x:1476,y:834,t:1527877134494};\\\", \\\"{x:1474,y:833,t:1527877134511};\\\", \\\"{x:1474,y:832,t:1527877134574};\\\", \\\"{x:1474,y:831,t:1527877134590};\\\", \\\"{x:1474,y:830,t:1527877134598};\\\", \\\"{x:1474,y:829,t:1527877134703};\\\", \\\"{x:1474,y:828,t:1527877134710};\\\", \\\"{x:1474,y:827,t:1527877134727};\\\", \\\"{x:1473,y:826,t:1527877134744};\\\", \\\"{x:1473,y:825,t:1527877134760};\\\", \\\"{x:1473,y:824,t:1527877134777};\\\", \\\"{x:1472,y:821,t:1527877134794};\\\", \\\"{x:1470,y:818,t:1527877134810};\\\", \\\"{x:1470,y:815,t:1527877134827};\\\", \\\"{x:1469,y:814,t:1527877134844};\\\", \\\"{x:1469,y:813,t:1527877134861};\\\", \\\"{x:1469,y:811,t:1527877134877};\\\", \\\"{x:1469,y:810,t:1527877134894};\\\", \\\"{x:1469,y:809,t:1527877134910};\\\", \\\"{x:1469,y:808,t:1527877134934};\\\", \\\"{x:1468,y:807,t:1527877134944};\\\", \\\"{x:1467,y:806,t:1527877135014};\\\", \\\"{x:1467,y:804,t:1527877135027};\\\", \\\"{x:1466,y:801,t:1527877135043};\\\", \\\"{x:1464,y:797,t:1527877135059};\\\", \\\"{x:1459,y:787,t:1527877135077};\\\", \\\"{x:1453,y:777,t:1527877135094};\\\", \\\"{x:1447,y:768,t:1527877135110};\\\", \\\"{x:1440,y:761,t:1527877135127};\\\", \\\"{x:1439,y:759,t:1527877135143};\\\", \\\"{x:1436,y:755,t:1527877135160};\\\", \\\"{x:1434,y:750,t:1527877135176};\\\", \\\"{x:1429,y:740,t:1527877135194};\\\", \\\"{x:1427,y:734,t:1527877135211};\\\", \\\"{x:1424,y:728,t:1527877135227};\\\", \\\"{x:1422,y:725,t:1527877135244};\\\", \\\"{x:1421,y:722,t:1527877135261};\\\", \\\"{x:1417,y:712,t:1527877135277};\\\", \\\"{x:1414,y:701,t:1527877135294};\\\", \\\"{x:1409,y:686,t:1527877135311};\\\", \\\"{x:1402,y:668,t:1527877135327};\\\", \\\"{x:1396,y:648,t:1527877135344};\\\", \\\"{x:1393,y:637,t:1527877135361};\\\", \\\"{x:1392,y:633,t:1527877135376};\\\", \\\"{x:1392,y:631,t:1527877135393};\\\", \\\"{x:1392,y:628,t:1527877135411};\\\", \\\"{x:1391,y:625,t:1527877135428};\\\", \\\"{x:1391,y:623,t:1527877135443};\\\", \\\"{x:1387,y:616,t:1527877135461};\\\", \\\"{x:1387,y:613,t:1527877135477};\\\", \\\"{x:1386,y:612,t:1527877135493};\\\", \\\"{x:1386,y:611,t:1527877135517};\\\", \\\"{x:1385,y:610,t:1527877135528};\\\", \\\"{x:1384,y:609,t:1527877135544};\\\", \\\"{x:1384,y:608,t:1527877135565};\\\", \\\"{x:1385,y:609,t:1527877135671};\\\", \\\"{x:1388,y:617,t:1527877135677};\\\", \\\"{x:1394,y:630,t:1527877135695};\\\", \\\"{x:1401,y:652,t:1527877135712};\\\", \\\"{x:1418,y:687,t:1527877135728};\\\", \\\"{x:1434,y:717,t:1527877135745};\\\", \\\"{x:1453,y:743,t:1527877135760};\\\", \\\"{x:1467,y:762,t:1527877135778};\\\", \\\"{x:1481,y:781,t:1527877135795};\\\", \\\"{x:1496,y:804,t:1527877135811};\\\", \\\"{x:1512,y:836,t:1527877135828};\\\", \\\"{x:1529,y:872,t:1527877135846};\\\", \\\"{x:1539,y:889,t:1527877135862};\\\", \\\"{x:1545,y:901,t:1527877135878};\\\", \\\"{x:1550,y:912,t:1527877135895};\\\", \\\"{x:1552,y:925,t:1527877135911};\\\", \\\"{x:1554,y:938,t:1527877135928};\\\", \\\"{x:1555,y:942,t:1527877135945};\\\", \\\"{x:1555,y:946,t:1527877135961};\\\", \\\"{x:1553,y:946,t:1527877136038};\\\", \\\"{x:1553,y:945,t:1527877136046};\\\", \\\"{x:1548,y:936,t:1527877136062};\\\", \\\"{x:1543,y:916,t:1527877136078};\\\", \\\"{x:1531,y:894,t:1527877136095};\\\", \\\"{x:1518,y:873,t:1527877136112};\\\", \\\"{x:1505,y:863,t:1527877136128};\\\", \\\"{x:1494,y:851,t:1527877136145};\\\", \\\"{x:1486,y:846,t:1527877136162};\\\", \\\"{x:1478,y:841,t:1527877136177};\\\", \\\"{x:1476,y:839,t:1527877136194};\\\", \\\"{x:1475,y:838,t:1527877136212};\\\", \\\"{x:1472,y:838,t:1527877136462};\\\", \\\"{x:1469,y:839,t:1527877136480};\\\", \\\"{x:1462,y:841,t:1527877136495};\\\", \\\"{x:1447,y:844,t:1527877136512};\\\", \\\"{x:1428,y:849,t:1527877136529};\\\", \\\"{x:1412,y:855,t:1527877136545};\\\", \\\"{x:1404,y:857,t:1527877136562};\\\", \\\"{x:1401,y:857,t:1527877136579};\\\", \\\"{x:1399,y:855,t:1527877136647};\\\", \\\"{x:1398,y:843,t:1527877136662};\\\", \\\"{x:1394,y:829,t:1527877136679};\\\", \\\"{x:1387,y:809,t:1527877136696};\\\", \\\"{x:1380,y:794,t:1527877136712};\\\", \\\"{x:1367,y:781,t:1527877136729};\\\", \\\"{x:1357,y:774,t:1527877136746};\\\", \\\"{x:1345,y:767,t:1527877136763};\\\", \\\"{x:1340,y:763,t:1527877136779};\\\", \\\"{x:1336,y:756,t:1527877136796};\\\", \\\"{x:1328,y:743,t:1527877136811};\\\", \\\"{x:1317,y:727,t:1527877136828};\\\", \\\"{x:1315,y:724,t:1527877136845};\\\", \\\"{x:1314,y:724,t:1527877136862};\\\", \\\"{x:1314,y:722,t:1527877136885};\\\", \\\"{x:1314,y:721,t:1527877136896};\\\", \\\"{x:1314,y:720,t:1527877136911};\\\", \\\"{x:1315,y:717,t:1527877136928};\\\", \\\"{x:1316,y:714,t:1527877136946};\\\", \\\"{x:1316,y:712,t:1527877136961};\\\", \\\"{x:1318,y:709,t:1527877136979};\\\", \\\"{x:1322,y:707,t:1527877136995};\\\", \\\"{x:1324,y:705,t:1527877137013};\\\", \\\"{x:1324,y:704,t:1527877137029};\\\", \\\"{x:1325,y:704,t:1527877137061};\\\", \\\"{x:1326,y:703,t:1527877137126};\\\", \\\"{x:1327,y:703,t:1527877137134};\\\", \\\"{x:1328,y:703,t:1527877137150};\\\", \\\"{x:1329,y:703,t:1527877137163};\\\", \\\"{x:1332,y:703,t:1527877137179};\\\", \\\"{x:1335,y:703,t:1527877137196};\\\", \\\"{x:1337,y:706,t:1527877137213};\\\", \\\"{x:1339,y:709,t:1527877137229};\\\", \\\"{x:1342,y:716,t:1527877137247};\\\", \\\"{x:1345,y:720,t:1527877137263};\\\", \\\"{x:1354,y:729,t:1527877137279};\\\", \\\"{x:1359,y:735,t:1527877137296};\\\", \\\"{x:1371,y:748,t:1527877137314};\\\", \\\"{x:1378,y:760,t:1527877137329};\\\", \\\"{x:1387,y:775,t:1527877137346};\\\", \\\"{x:1394,y:787,t:1527877137364};\\\", \\\"{x:1402,y:797,t:1527877137380};\\\", \\\"{x:1404,y:802,t:1527877137396};\\\", \\\"{x:1409,y:809,t:1527877137413};\\\", \\\"{x:1413,y:814,t:1527877137429};\\\", \\\"{x:1414,y:818,t:1527877137446};\\\", \\\"{x:1415,y:822,t:1527877137464};\\\", \\\"{x:1417,y:823,t:1527877137481};\\\", \\\"{x:1417,y:825,t:1527877137497};\\\", \\\"{x:1418,y:825,t:1527877137599};\\\", \\\"{x:1426,y:828,t:1527877137614};\\\", \\\"{x:1437,y:831,t:1527877137630};\\\", \\\"{x:1447,y:832,t:1527877137647};\\\", \\\"{x:1456,y:832,t:1527877137663};\\\", \\\"{x:1463,y:834,t:1527877137680};\\\", \\\"{x:1465,y:835,t:1527877137697};\\\", \\\"{x:1466,y:835,t:1527877137713};\\\", \\\"{x:1467,y:835,t:1527877137823};\\\", \\\"{x:1466,y:835,t:1527877137894};\\\", \\\"{x:1460,y:835,t:1527877137902};\\\", \\\"{x:1453,y:835,t:1527877137913};\\\", \\\"{x:1422,y:831,t:1527877137930};\\\", \\\"{x:1369,y:817,t:1527877137948};\\\", \\\"{x:1295,y:801,t:1527877137964};\\\", \\\"{x:1207,y:778,t:1527877137980};\\\", \\\"{x:1058,y:742,t:1527877137998};\\\", \\\"{x:949,y:722,t:1527877138014};\\\", \\\"{x:850,y:694,t:1527877138030};\\\", \\\"{x:759,y:673,t:1527877138048};\\\", \\\"{x:705,y:655,t:1527877138064};\\\", \\\"{x:675,y:641,t:1527877138080};\\\", \\\"{x:662,y:634,t:1527877138097};\\\", \\\"{x:661,y:633,t:1527877138114};\\\", \\\"{x:659,y:632,t:1527877138130};\\\", \\\"{x:659,y:628,t:1527877138148};\\\", \\\"{x:651,y:619,t:1527877138163};\\\", \\\"{x:644,y:609,t:1527877138179};\\\", \\\"{x:630,y:595,t:1527877138197};\\\", \\\"{x:624,y:591,t:1527877138207};\\\", \\\"{x:614,y:584,t:1527877138223};\\\", \\\"{x:609,y:582,t:1527877138240};\\\", \\\"{x:609,y:580,t:1527877138269};\\\", \\\"{x:609,y:579,t:1527877138278};\\\", \\\"{x:609,y:577,t:1527877138296};\\\", \\\"{x:609,y:576,t:1527877138332};\\\", \\\"{x:609,y:575,t:1527877138345};\\\", \\\"{x:609,y:573,t:1527877138365};\\\", \\\"{x:609,y:572,t:1527877138380};\\\", \\\"{x:609,y:573,t:1527877138501};\\\", \\\"{x:609,y:575,t:1527877138709};\\\", \\\"{x:609,y:578,t:1527877138717};\\\", \\\"{x:609,y:582,t:1527877138729};\\\", \\\"{x:604,y:600,t:1527877138746};\\\", \\\"{x:595,y:622,t:1527877138763};\\\", \\\"{x:588,y:639,t:1527877138779};\\\", \\\"{x:578,y:654,t:1527877138795};\\\", \\\"{x:565,y:673,t:1527877138813};\\\", \\\"{x:557,y:685,t:1527877138829};\\\", \\\"{x:552,y:694,t:1527877138846};\\\", \\\"{x:543,y:705,t:1527877138863};\\\", \\\"{x:539,y:713,t:1527877138879};\\\", \\\"{x:536,y:720,t:1527877138896};\\\", \\\"{x:534,y:726,t:1527877138913};\\\", \\\"{x:531,y:736,t:1527877138929};\\\", \\\"{x:527,y:747,t:1527877138946};\\\", \\\"{x:525,y:755,t:1527877138963};\\\", \\\"{x:523,y:758,t:1527877138979};\\\", \\\"{x:522,y:759,t:1527877138995};\\\", \\\"{x:523,y:759,t:1527877139102};\\\", \\\"{x:526,y:758,t:1527877139118};\\\", \\\"{x:528,y:756,t:1527877139130};\\\", \\\"{x:532,y:751,t:1527877139147};\\\", \\\"{x:534,y:746,t:1527877139162};\\\", \\\"{x:538,y:742,t:1527877139179};\\\", \\\"{x:539,y:739,t:1527877139195};\\\", \\\"{x:540,y:738,t:1527877139213};\\\", \\\"{x:541,y:738,t:1527877139758};\\\", \\\"{x:542,y:737,t:1527877139765};\\\", \\\"{x:545,y:735,t:1527877139780};\\\", \\\"{x:559,y:730,t:1527877139797};\\\", \\\"{x:577,y:726,t:1527877139813};\\\", \\\"{x:597,y:724,t:1527877139830};\\\", \\\"{x:616,y:720,t:1527877139847};\\\", \\\"{x:637,y:715,t:1527877139863};\\\", \\\"{x:653,y:707,t:1527877139880};\\\", \\\"{x:673,y:698,t:1527877139897};\\\", \\\"{x:685,y:691,t:1527877139913};\\\", \\\"{x:698,y:685,t:1527877139930};\\\", \\\"{x:705,y:679,t:1527877139947};\\\", \\\"{x:711,y:675,t:1527877139963};\\\", \\\"{x:712,y:674,t:1527877139980};\\\", \\\"{x:715,y:671,t:1527877139997};\\\", \\\"{x:717,y:668,t:1527877140013};\\\", \\\"{x:719,y:667,t:1527877140029};\\\", \\\"{x:722,y:665,t:1527877140047};\\\", \\\"{x:723,y:664,t:1527877140064};\\\", \\\"{x:725,y:662,t:1527877140080};\\\", \\\"{x:727,y:660,t:1527877140097};\\\", \\\"{x:728,y:659,t:1527877140114};\\\", \\\"{x:729,y:657,t:1527877140130};\\\", \\\"{x:730,y:656,t:1527877140147};\\\", \\\"{x:731,y:655,t:1527877140164};\\\", \\\"{x:732,y:655,t:1527877140182};\\\" ] }, { \\\"rt\\\": 49410, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 587058, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X -X -X -O -O -O -O -O -X -X -K -G -D -07 PM-K -K -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:736,y:645,t:1527877140637};\\\", \\\"{x:737,y:644,t:1527877140676};\\\", \\\"{x:737,y:643,t:1527877140737};\\\", \\\"{x:737,y:642,t:1527877140764};\\\", \\\"{x:737,y:641,t:1527877141031};\\\", \\\"{x:737,y:640,t:1527877141822};\\\", \\\"{x:739,y:640,t:1527877144335};\\\", \\\"{x:747,y:642,t:1527877144343};\\\", \\\"{x:768,y:649,t:1527877144361};\\\", \\\"{x:793,y:660,t:1527877144375};\\\", \\\"{x:827,y:667,t:1527877144392};\\\", \\\"{x:854,y:678,t:1527877144409};\\\", \\\"{x:890,y:687,t:1527877144426};\\\", \\\"{x:946,y:697,t:1527877144443};\\\", \\\"{x:985,y:701,t:1527877144460};\\\", \\\"{x:1031,y:710,t:1527877144476};\\\", \\\"{x:1075,y:715,t:1527877144493};\\\", \\\"{x:1104,y:721,t:1527877144509};\\\", \\\"{x:1140,y:730,t:1527877144526};\\\", \\\"{x:1161,y:737,t:1527877144544};\\\", \\\"{x:1181,y:743,t:1527877144560};\\\", \\\"{x:1202,y:749,t:1527877144576};\\\", \\\"{x:1223,y:759,t:1527877144593};\\\", \\\"{x:1241,y:772,t:1527877144610};\\\", \\\"{x:1265,y:789,t:1527877144626};\\\", \\\"{x:1280,y:799,t:1527877144643};\\\", \\\"{x:1293,y:807,t:1527877144661};\\\", \\\"{x:1308,y:817,t:1527877144677};\\\", \\\"{x:1319,y:826,t:1527877144693};\\\", \\\"{x:1338,y:841,t:1527877144710};\\\", \\\"{x:1353,y:853,t:1527877144726};\\\", \\\"{x:1366,y:864,t:1527877144743};\\\", \\\"{x:1380,y:873,t:1527877144761};\\\", \\\"{x:1395,y:880,t:1527877144777};\\\", \\\"{x:1410,y:888,t:1527877144794};\\\", \\\"{x:1426,y:891,t:1527877144811};\\\", \\\"{x:1436,y:895,t:1527877144827};\\\", \\\"{x:1442,y:897,t:1527877144843};\\\", \\\"{x:1447,y:901,t:1527877144861};\\\", \\\"{x:1449,y:903,t:1527877144878};\\\", \\\"{x:1452,y:906,t:1527877144893};\\\", \\\"{x:1453,y:907,t:1527877144910};\\\", \\\"{x:1453,y:908,t:1527877144935};\\\", \\\"{x:1453,y:909,t:1527877144966};\\\", \\\"{x:1454,y:911,t:1527877144977};\\\", \\\"{x:1455,y:912,t:1527877144998};\\\", \\\"{x:1456,y:914,t:1527877145014};\\\", \\\"{x:1456,y:915,t:1527877145028};\\\", \\\"{x:1459,y:918,t:1527877145044};\\\", \\\"{x:1461,y:926,t:1527877145061};\\\", \\\"{x:1464,y:929,t:1527877145078};\\\", \\\"{x:1468,y:936,t:1527877145094};\\\", \\\"{x:1472,y:940,t:1527877145110};\\\", \\\"{x:1473,y:940,t:1527877145127};\\\", \\\"{x:1473,y:942,t:1527877145145};\\\", \\\"{x:1474,y:944,t:1527877145263};\\\", \\\"{x:1474,y:945,t:1527877145278};\\\", \\\"{x:1476,y:945,t:1527877145295};\\\", \\\"{x:1477,y:946,t:1527877145400};\\\", \\\"{x:1478,y:946,t:1527877145415};\\\", \\\"{x:1479,y:947,t:1527877145431};\\\", \\\"{x:1480,y:948,t:1527877145447};\\\", \\\"{x:1481,y:949,t:1527877145495};\\\", \\\"{x:1481,y:952,t:1527877145511};\\\", \\\"{x:1482,y:953,t:1527877145528};\\\", \\\"{x:1483,y:954,t:1527877145592};\\\", \\\"{x:1483,y:955,t:1527877145599};\\\", \\\"{x:1484,y:956,t:1527877145615};\\\", \\\"{x:1484,y:957,t:1527877145628};\\\", \\\"{x:1484,y:958,t:1527877145654};\\\", \\\"{x:1484,y:960,t:1527877145671};\\\", \\\"{x:1484,y:961,t:1527877145800};\\\", \\\"{x:1484,y:962,t:1527877145812};\\\", \\\"{x:1484,y:965,t:1527877146287};\\\", \\\"{x:1484,y:967,t:1527877146375};\\\", \\\"{x:1484,y:968,t:1527877146399};\\\", \\\"{x:1484,y:967,t:1527877146567};\\\", \\\"{x:1484,y:964,t:1527877146580};\\\", \\\"{x:1484,y:957,t:1527877146596};\\\", \\\"{x:1484,y:952,t:1527877146613};\\\", \\\"{x:1484,y:944,t:1527877146630};\\\", \\\"{x:1484,y:939,t:1527877146646};\\\", \\\"{x:1484,y:932,t:1527877146662};\\\", \\\"{x:1484,y:929,t:1527877146680};\\\", \\\"{x:1484,y:926,t:1527877146696};\\\", \\\"{x:1484,y:922,t:1527877146713};\\\", \\\"{x:1484,y:919,t:1527877146730};\\\", \\\"{x:1485,y:914,t:1527877146747};\\\", \\\"{x:1486,y:907,t:1527877146763};\\\", \\\"{x:1486,y:902,t:1527877146780};\\\", \\\"{x:1486,y:895,t:1527877146797};\\\", \\\"{x:1486,y:893,t:1527877146813};\\\", \\\"{x:1486,y:892,t:1527877146839};\\\", \\\"{x:1486,y:890,t:1527877146863};\\\", \\\"{x:1486,y:887,t:1527877146880};\\\", \\\"{x:1486,y:886,t:1527877146897};\\\", \\\"{x:1486,y:884,t:1527877146912};\\\", \\\"{x:1486,y:883,t:1527877146929};\\\", \\\"{x:1486,y:881,t:1527877146946};\\\", \\\"{x:1486,y:879,t:1527877146962};\\\", \\\"{x:1486,y:877,t:1527877146979};\\\", \\\"{x:1487,y:874,t:1527877146996};\\\", \\\"{x:1487,y:870,t:1527877147012};\\\", \\\"{x:1487,y:868,t:1527877147030};\\\", \\\"{x:1487,y:863,t:1527877147046};\\\", \\\"{x:1487,y:862,t:1527877147063};\\\", \\\"{x:1488,y:859,t:1527877147080};\\\", \\\"{x:1488,y:856,t:1527877147096};\\\", \\\"{x:1489,y:854,t:1527877147114};\\\", \\\"{x:1489,y:852,t:1527877147129};\\\", \\\"{x:1489,y:850,t:1527877147146};\\\", \\\"{x:1489,y:848,t:1527877147163};\\\", \\\"{x:1490,y:847,t:1527877147180};\\\", \\\"{x:1490,y:846,t:1527877147197};\\\", \\\"{x:1490,y:843,t:1527877147214};\\\", \\\"{x:1490,y:842,t:1527877147271};\\\", \\\"{x:1490,y:841,t:1527877147280};\\\", \\\"{x:1490,y:840,t:1527877147296};\\\", \\\"{x:1490,y:838,t:1527877147351};\\\", \\\"{x:1490,y:837,t:1527877147383};\\\", \\\"{x:1489,y:837,t:1527877147414};\\\", \\\"{x:1488,y:836,t:1527877147431};\\\", \\\"{x:1487,y:836,t:1527877147446};\\\", \\\"{x:1486,y:835,t:1527877147487};\\\", \\\"{x:1485,y:834,t:1527877147505};\\\", \\\"{x:1484,y:834,t:1527877147574};\\\", \\\"{x:1483,y:834,t:1527877147589};\\\", \\\"{x:1482,y:834,t:1527877147598};\\\", \\\"{x:1482,y:833,t:1527877147614};\\\", \\\"{x:1481,y:833,t:1527877147719};\\\", \\\"{x:1480,y:833,t:1527877147831};\\\", \\\"{x:1477,y:834,t:1527877147848};\\\", \\\"{x:1474,y:838,t:1527877147867};\\\", \\\"{x:1470,y:843,t:1527877147881};\\\", \\\"{x:1468,y:846,t:1527877147897};\\\", \\\"{x:1466,y:850,t:1527877147915};\\\", \\\"{x:1464,y:855,t:1527877147931};\\\", \\\"{x:1460,y:864,t:1527877147948};\\\", \\\"{x:1458,y:871,t:1527877147965};\\\", \\\"{x:1456,y:878,t:1527877147981};\\\", \\\"{x:1453,y:888,t:1527877147998};\\\", \\\"{x:1446,y:903,t:1527877148014};\\\", \\\"{x:1445,y:908,t:1527877148030};\\\", \\\"{x:1443,y:912,t:1527877148048};\\\", \\\"{x:1443,y:914,t:1527877148065};\\\", \\\"{x:1441,y:920,t:1527877148082};\\\", \\\"{x:1440,y:922,t:1527877148098};\\\", \\\"{x:1439,y:927,t:1527877148114};\\\", \\\"{x:1438,y:929,t:1527877148132};\\\", \\\"{x:1438,y:932,t:1527877148148};\\\", \\\"{x:1438,y:933,t:1527877148167};\\\", \\\"{x:1438,y:931,t:1527877148280};\\\", \\\"{x:1439,y:927,t:1527877148287};\\\", \\\"{x:1440,y:924,t:1527877148298};\\\", \\\"{x:1444,y:915,t:1527877148315};\\\", \\\"{x:1447,y:905,t:1527877148332};\\\", \\\"{x:1452,y:897,t:1527877148348};\\\", \\\"{x:1454,y:890,t:1527877148365};\\\", \\\"{x:1457,y:885,t:1527877148382};\\\", \\\"{x:1460,y:877,t:1527877148400};\\\", \\\"{x:1464,y:870,t:1527877148415};\\\", \\\"{x:1466,y:865,t:1527877148432};\\\", \\\"{x:1468,y:860,t:1527877148449};\\\", \\\"{x:1469,y:857,t:1527877148465};\\\", \\\"{x:1471,y:855,t:1527877148482};\\\", \\\"{x:1473,y:851,t:1527877148499};\\\", \\\"{x:1473,y:850,t:1527877148515};\\\", \\\"{x:1475,y:848,t:1527877148532};\\\", \\\"{x:1476,y:844,t:1527877148549};\\\", \\\"{x:1477,y:843,t:1527877148565};\\\", \\\"{x:1478,y:841,t:1527877148582};\\\", \\\"{x:1478,y:840,t:1527877148599};\\\", \\\"{x:1479,y:839,t:1527877148759};\\\", \\\"{x:1480,y:839,t:1527877148775};\\\", \\\"{x:1481,y:840,t:1527877148790};\\\", \\\"{x:1482,y:845,t:1527877148798};\\\", \\\"{x:1484,y:850,t:1527877148816};\\\", \\\"{x:1486,y:856,t:1527877148832};\\\", \\\"{x:1488,y:861,t:1527877148848};\\\", \\\"{x:1490,y:865,t:1527877148866};\\\", \\\"{x:1493,y:869,t:1527877148881};\\\", \\\"{x:1496,y:877,t:1527877148899};\\\", \\\"{x:1498,y:881,t:1527877148915};\\\", \\\"{x:1502,y:887,t:1527877148932};\\\", \\\"{x:1506,y:893,t:1527877148948};\\\", \\\"{x:1509,y:900,t:1527877148965};\\\", \\\"{x:1513,y:905,t:1527877148982};\\\", \\\"{x:1514,y:907,t:1527877148999};\\\", \\\"{x:1517,y:911,t:1527877149016};\\\", \\\"{x:1518,y:915,t:1527877149032};\\\", \\\"{x:1520,y:919,t:1527877149049};\\\", \\\"{x:1521,y:921,t:1527877149066};\\\", \\\"{x:1522,y:922,t:1527877149082};\\\", \\\"{x:1523,y:925,t:1527877149099};\\\", \\\"{x:1525,y:929,t:1527877149116};\\\", \\\"{x:1528,y:935,t:1527877149132};\\\", \\\"{x:1531,y:940,t:1527877149149};\\\", \\\"{x:1532,y:943,t:1527877149166};\\\", \\\"{x:1533,y:943,t:1527877149183};\\\", \\\"{x:1533,y:945,t:1527877149200};\\\", \\\"{x:1533,y:946,t:1527877149216};\\\", \\\"{x:1533,y:947,t:1527877149233};\\\", \\\"{x:1534,y:948,t:1527877149250};\\\", \\\"{x:1534,y:947,t:1527877149303};\\\", \\\"{x:1534,y:944,t:1527877149316};\\\", \\\"{x:1533,y:939,t:1527877149333};\\\", \\\"{x:1532,y:933,t:1527877149351};\\\", \\\"{x:1530,y:927,t:1527877149366};\\\", \\\"{x:1526,y:910,t:1527877149384};\\\", \\\"{x:1521,y:900,t:1527877149400};\\\", \\\"{x:1519,y:894,t:1527877149416};\\\", \\\"{x:1515,y:886,t:1527877149432};\\\", \\\"{x:1512,y:877,t:1527877149450};\\\", \\\"{x:1510,y:873,t:1527877149466};\\\", \\\"{x:1507,y:867,t:1527877149483};\\\", \\\"{x:1504,y:864,t:1527877149499};\\\", \\\"{x:1503,y:862,t:1527877149516};\\\", \\\"{x:1501,y:861,t:1527877149533};\\\", \\\"{x:1501,y:859,t:1527877149549};\\\", \\\"{x:1500,y:855,t:1527877149566};\\\", \\\"{x:1500,y:854,t:1527877149590};\\\", \\\"{x:1500,y:853,t:1527877149599};\\\", \\\"{x:1496,y:849,t:1527877149616};\\\", \\\"{x:1492,y:844,t:1527877149632};\\\", \\\"{x:1490,y:842,t:1527877149650};\\\", \\\"{x:1489,y:841,t:1527877149667};\\\", \\\"{x:1489,y:840,t:1527877149682};\\\", \\\"{x:1489,y:839,t:1527877149710};\\\", \\\"{x:1487,y:838,t:1527877149718};\\\", \\\"{x:1487,y:837,t:1527877149743};\\\", \\\"{x:1486,y:836,t:1527877149759};\\\", \\\"{x:1486,y:835,t:1527877149775};\\\", \\\"{x:1485,y:835,t:1527877149784};\\\", \\\"{x:1484,y:835,t:1527877149848};\\\", \\\"{x:1481,y:835,t:1527877149879};\\\", \\\"{x:1478,y:836,t:1527877149901};\\\", \\\"{x:1476,y:837,t:1527877149917};\\\", \\\"{x:1476,y:839,t:1527877149934};\\\", \\\"{x:1476,y:840,t:1527877149950};\\\", \\\"{x:1476,y:845,t:1527877149967};\\\", \\\"{x:1476,y:855,t:1527877149984};\\\", \\\"{x:1476,y:865,t:1527877150001};\\\", \\\"{x:1476,y:873,t:1527877150017};\\\", \\\"{x:1476,y:880,t:1527877150034};\\\", \\\"{x:1476,y:889,t:1527877150052};\\\", \\\"{x:1476,y:895,t:1527877150067};\\\", \\\"{x:1477,y:905,t:1527877150084};\\\", \\\"{x:1478,y:910,t:1527877150101};\\\", \\\"{x:1479,y:916,t:1527877150117};\\\", \\\"{x:1479,y:918,t:1527877150134};\\\", \\\"{x:1479,y:923,t:1527877150150};\\\", \\\"{x:1479,y:925,t:1527877150167};\\\", \\\"{x:1478,y:930,t:1527877150184};\\\", \\\"{x:1478,y:931,t:1527877150201};\\\", \\\"{x:1478,y:934,t:1527877150216};\\\", \\\"{x:1478,y:936,t:1527877150239};\\\", \\\"{x:1478,y:937,t:1527877150251};\\\", \\\"{x:1478,y:940,t:1527877150268};\\\", \\\"{x:1478,y:944,t:1527877150284};\\\", \\\"{x:1478,y:945,t:1527877150302};\\\", \\\"{x:1478,y:947,t:1527877150318};\\\", \\\"{x:1479,y:947,t:1527877150446};\\\", \\\"{x:1481,y:947,t:1527877150453};\\\", \\\"{x:1481,y:944,t:1527877150468};\\\", \\\"{x:1482,y:933,t:1527877150483};\\\", \\\"{x:1482,y:919,t:1527877150500};\\\", \\\"{x:1482,y:905,t:1527877150517};\\\", \\\"{x:1485,y:896,t:1527877150534};\\\", \\\"{x:1486,y:889,t:1527877150551};\\\", \\\"{x:1487,y:884,t:1527877150568};\\\", \\\"{x:1487,y:879,t:1527877150585};\\\", \\\"{x:1487,y:875,t:1527877150601};\\\", \\\"{x:1488,y:870,t:1527877150617};\\\", \\\"{x:1488,y:866,t:1527877150635};\\\", \\\"{x:1488,y:860,t:1527877150651};\\\", \\\"{x:1488,y:855,t:1527877150668};\\\", \\\"{x:1488,y:851,t:1527877150685};\\\", \\\"{x:1486,y:847,t:1527877150701};\\\", \\\"{x:1485,y:843,t:1527877150718};\\\", \\\"{x:1484,y:836,t:1527877150734};\\\", \\\"{x:1484,y:833,t:1527877150751};\\\", \\\"{x:1484,y:831,t:1527877150768};\\\", \\\"{x:1483,y:830,t:1527877150784};\\\", \\\"{x:1483,y:828,t:1527877150815};\\\", \\\"{x:1480,y:828,t:1527877152839};\\\", \\\"{x:1478,y:828,t:1527877152854};\\\", \\\"{x:1466,y:827,t:1527877152872};\\\", \\\"{x:1439,y:822,t:1527877152887};\\\", \\\"{x:1407,y:816,t:1527877152905};\\\", \\\"{x:1363,y:811,t:1527877152921};\\\", \\\"{x:1306,y:798,t:1527877152937};\\\", \\\"{x:1223,y:777,t:1527877152954};\\\", \\\"{x:1143,y:757,t:1527877152971};\\\", \\\"{x:1047,y:733,t:1527877152989};\\\", \\\"{x:963,y:718,t:1527877153004};\\\", \\\"{x:877,y:696,t:1527877153021};\\\", \\\"{x:792,y:675,t:1527877153038};\\\", \\\"{x:708,y:658,t:1527877153054};\\\", \\\"{x:599,y:638,t:1527877153072};\\\", \\\"{x:564,y:630,t:1527877153088};\\\", \\\"{x:547,y:626,t:1527877153103};\\\", \\\"{x:541,y:626,t:1527877153116};\\\", \\\"{x:534,y:623,t:1527877153133};\\\", \\\"{x:530,y:621,t:1527877153149};\\\", \\\"{x:534,y:621,t:1527877153230};\\\", \\\"{x:537,y:621,t:1527877153237};\\\", \\\"{x:539,y:619,t:1527877153249};\\\", \\\"{x:552,y:616,t:1527877153266};\\\", \\\"{x:563,y:613,t:1527877153284};\\\", \\\"{x:571,y:610,t:1527877153300};\\\", \\\"{x:579,y:607,t:1527877153317};\\\", \\\"{x:583,y:605,t:1527877153334};\\\", \\\"{x:587,y:604,t:1527877153350};\\\", \\\"{x:589,y:603,t:1527877153367};\\\", \\\"{x:591,y:603,t:1527877153414};\\\", \\\"{x:592,y:601,t:1527877153429};\\\", \\\"{x:594,y:601,t:1527877153445};\\\", \\\"{x:596,y:601,t:1527877153454};\\\", \\\"{x:597,y:601,t:1527877153470};\\\", \\\"{x:599,y:599,t:1527877153486};\\\", \\\"{x:600,y:599,t:1527877153502};\\\", \\\"{x:601,y:599,t:1527877153518};\\\", \\\"{x:601,y:598,t:1527877153533};\\\", \\\"{x:602,y:598,t:1527877153549};\\\", \\\"{x:603,y:598,t:1527877153781};\\\", \\\"{x:606,y:598,t:1527877153789};\\\", \\\"{x:610,y:598,t:1527877153801};\\\", \\\"{x:626,y:605,t:1527877153817};\\\", \\\"{x:642,y:612,t:1527877153834};\\\", \\\"{x:671,y:621,t:1527877153851};\\\", \\\"{x:698,y:626,t:1527877153867};\\\", \\\"{x:729,y:636,t:1527877153884};\\\", \\\"{x:756,y:647,t:1527877153901};\\\", \\\"{x:790,y:657,t:1527877153917};\\\", \\\"{x:875,y:677,t:1527877153934};\\\", \\\"{x:945,y:698,t:1527877153950};\\\", \\\"{x:1021,y:713,t:1527877153967};\\\", \\\"{x:1078,y:722,t:1527877153983};\\\", \\\"{x:1128,y:736,t:1527877154001};\\\", \\\"{x:1155,y:742,t:1527877154017};\\\", \\\"{x:1173,y:747,t:1527877154033};\\\", \\\"{x:1192,y:753,t:1527877154051};\\\", \\\"{x:1216,y:763,t:1527877154068};\\\", \\\"{x:1231,y:768,t:1527877154084};\\\", \\\"{x:1242,y:772,t:1527877154101};\\\", \\\"{x:1252,y:776,t:1527877154118};\\\", \\\"{x:1256,y:778,t:1527877154134};\\\", \\\"{x:1260,y:780,t:1527877154151};\\\", \\\"{x:1262,y:782,t:1527877154167};\\\", \\\"{x:1267,y:786,t:1527877154184};\\\", \\\"{x:1277,y:794,t:1527877154201};\\\", \\\"{x:1291,y:807,t:1527877154218};\\\", \\\"{x:1304,y:816,t:1527877154234};\\\", \\\"{x:1323,y:823,t:1527877154251};\\\", \\\"{x:1339,y:830,t:1527877154268};\\\", \\\"{x:1359,y:834,t:1527877154284};\\\", \\\"{x:1375,y:837,t:1527877154301};\\\", \\\"{x:1395,y:839,t:1527877154318};\\\", \\\"{x:1402,y:839,t:1527877154334};\\\", \\\"{x:1407,y:839,t:1527877154351};\\\", \\\"{x:1409,y:839,t:1527877154368};\\\", \\\"{x:1412,y:839,t:1527877154384};\\\", \\\"{x:1413,y:838,t:1527877154401};\\\", \\\"{x:1415,y:834,t:1527877154418};\\\", \\\"{x:1417,y:832,t:1527877154434};\\\", \\\"{x:1419,y:830,t:1527877154451};\\\", \\\"{x:1423,y:827,t:1527877154469};\\\", \\\"{x:1424,y:827,t:1527877154485};\\\", \\\"{x:1427,y:827,t:1527877154501};\\\", \\\"{x:1429,y:827,t:1527877154518};\\\", \\\"{x:1431,y:827,t:1527877154543};\\\", \\\"{x:1433,y:827,t:1527877154551};\\\", \\\"{x:1441,y:826,t:1527877154568};\\\", \\\"{x:1442,y:825,t:1527877154584};\\\", \\\"{x:1445,y:823,t:1527877154601};\\\", \\\"{x:1449,y:823,t:1527877154618};\\\", \\\"{x:1451,y:823,t:1527877154635};\\\", \\\"{x:1452,y:822,t:1527877154694};\\\", \\\"{x:1453,y:822,t:1527877154813};\\\", \\\"{x:1454,y:822,t:1527877154829};\\\", \\\"{x:1455,y:822,t:1527877154837};\\\", \\\"{x:1456,y:822,t:1527877154851};\\\", \\\"{x:1458,y:822,t:1527877154867};\\\", \\\"{x:1459,y:822,t:1527877154974};\\\", \\\"{x:1460,y:822,t:1527877154985};\\\", \\\"{x:1461,y:822,t:1527877155002};\\\", \\\"{x:1463,y:822,t:1527877155063};\\\", \\\"{x:1464,y:822,t:1527877155087};\\\", \\\"{x:1466,y:822,t:1527877155103};\\\", \\\"{x:1467,y:822,t:1527877155135};\\\", \\\"{x:1469,y:822,t:1527877155152};\\\", \\\"{x:1472,y:822,t:1527877155168};\\\", \\\"{x:1476,y:820,t:1527877155186};\\\", \\\"{x:1478,y:819,t:1527877155202};\\\", \\\"{x:1479,y:819,t:1527877155218};\\\", \\\"{x:1481,y:819,t:1527877155235};\\\", \\\"{x:1484,y:819,t:1527877155252};\\\", \\\"{x:1488,y:819,t:1527877155269};\\\", \\\"{x:1490,y:819,t:1527877155285};\\\", \\\"{x:1493,y:819,t:1527877155302};\\\", \\\"{x:1493,y:818,t:1527877155487};\\\", \\\"{x:1495,y:816,t:1527877155502};\\\", \\\"{x:1497,y:813,t:1527877155519};\\\", \\\"{x:1497,y:810,t:1527877155535};\\\", \\\"{x:1501,y:803,t:1527877155553};\\\", \\\"{x:1502,y:799,t:1527877155569};\\\", \\\"{x:1504,y:795,t:1527877155586};\\\", \\\"{x:1506,y:793,t:1527877155602};\\\", \\\"{x:1507,y:791,t:1527877155619};\\\", \\\"{x:1508,y:790,t:1527877155636};\\\", \\\"{x:1508,y:789,t:1527877155652};\\\", \\\"{x:1508,y:787,t:1527877155669};\\\", \\\"{x:1508,y:786,t:1527877155694};\\\", \\\"{x:1508,y:785,t:1527877155702};\\\", \\\"{x:1510,y:783,t:1527877155719};\\\", \\\"{x:1510,y:782,t:1527877155736};\\\", \\\"{x:1511,y:779,t:1527877155752};\\\", \\\"{x:1511,y:777,t:1527877155769};\\\", \\\"{x:1511,y:775,t:1527877155786};\\\", \\\"{x:1511,y:772,t:1527877155802};\\\", \\\"{x:1511,y:770,t:1527877155823};\\\", \\\"{x:1511,y:768,t:1527877155847};\\\", \\\"{x:1512,y:768,t:1527877155855};\\\", \\\"{x:1513,y:767,t:1527877155869};\\\", \\\"{x:1514,y:765,t:1527877155887};\\\", \\\"{x:1515,y:764,t:1527877155943};\\\", \\\"{x:1516,y:764,t:1527877156031};\\\", \\\"{x:1515,y:764,t:1527877156230};\\\", \\\"{x:1511,y:764,t:1527877156238};\\\", \\\"{x:1506,y:767,t:1527877156255};\\\", \\\"{x:1498,y:773,t:1527877156269};\\\", \\\"{x:1480,y:787,t:1527877156287};\\\", \\\"{x:1469,y:794,t:1527877156303};\\\", \\\"{x:1462,y:800,t:1527877156319};\\\", \\\"{x:1454,y:809,t:1527877156337};\\\", \\\"{x:1446,y:821,t:1527877156353};\\\", \\\"{x:1441,y:829,t:1527877156369};\\\", \\\"{x:1437,y:836,t:1527877156386};\\\", \\\"{x:1433,y:842,t:1527877156403};\\\", \\\"{x:1432,y:845,t:1527877156420};\\\", \\\"{x:1431,y:850,t:1527877156437};\\\", \\\"{x:1427,y:855,t:1527877156453};\\\", \\\"{x:1424,y:862,t:1527877156469};\\\", \\\"{x:1421,y:868,t:1527877156487};\\\", \\\"{x:1420,y:868,t:1527877156503};\\\", \\\"{x:1418,y:870,t:1527877156519};\\\", \\\"{x:1418,y:869,t:1527877156575};\\\", \\\"{x:1418,y:865,t:1527877156586};\\\", \\\"{x:1419,y:860,t:1527877156603};\\\", \\\"{x:1424,y:845,t:1527877156620};\\\", \\\"{x:1429,y:830,t:1527877156636};\\\", \\\"{x:1436,y:812,t:1527877156654};\\\", \\\"{x:1440,y:798,t:1527877156669};\\\", \\\"{x:1444,y:785,t:1527877156686};\\\", \\\"{x:1446,y:774,t:1527877156703};\\\", \\\"{x:1446,y:769,t:1527877156720};\\\", \\\"{x:1449,y:758,t:1527877156736};\\\", \\\"{x:1450,y:749,t:1527877156753};\\\", \\\"{x:1459,y:730,t:1527877156770};\\\", \\\"{x:1460,y:723,t:1527877156786};\\\", \\\"{x:1461,y:714,t:1527877156803};\\\", \\\"{x:1463,y:702,t:1527877156820};\\\", \\\"{x:1463,y:685,t:1527877156837};\\\", \\\"{x:1463,y:683,t:1527877156854};\\\", \\\"{x:1463,y:682,t:1527877156871};\\\", \\\"{x:1463,y:681,t:1527877156887};\\\", \\\"{x:1463,y:680,t:1527877156903};\\\", \\\"{x:1464,y:678,t:1527877156920};\\\", \\\"{x:1464,y:677,t:1527877156943};\\\", \\\"{x:1464,y:676,t:1527877156953};\\\", \\\"{x:1464,y:673,t:1527877156970};\\\", \\\"{x:1463,y:672,t:1527877156987};\\\", \\\"{x:1463,y:669,t:1527877157004};\\\", \\\"{x:1463,y:667,t:1527877157023};\\\", \\\"{x:1463,y:666,t:1527877157047};\\\", \\\"{x:1462,y:665,t:1527877157054};\\\", \\\"{x:1460,y:662,t:1527877157070};\\\", \\\"{x:1459,y:659,t:1527877157086};\\\", \\\"{x:1457,y:656,t:1527877157103};\\\", \\\"{x:1456,y:652,t:1527877157120};\\\", \\\"{x:1455,y:649,t:1527877157136};\\\", \\\"{x:1453,y:646,t:1527877157153};\\\", \\\"{x:1453,y:645,t:1527877157170};\\\", \\\"{x:1452,y:644,t:1527877157232};\\\", \\\"{x:1452,y:643,t:1527877157247};\\\", \\\"{x:1452,y:642,t:1527877157343};\\\", \\\"{x:1451,y:642,t:1527877157359};\\\", \\\"{x:1451,y:641,t:1527877158392};\\\", \\\"{x:1451,y:640,t:1527877158406};\\\", \\\"{x:1451,y:639,t:1527877158422};\\\", \\\"{x:1451,y:637,t:1527877158438};\\\", \\\"{x:1451,y:636,t:1527877158455};\\\", \\\"{x:1450,y:636,t:1527877158471};\\\", \\\"{x:1448,y:640,t:1527877160422};\\\", \\\"{x:1442,y:646,t:1527877160439};\\\", \\\"{x:1438,y:656,t:1527877160456};\\\", \\\"{x:1435,y:661,t:1527877160472};\\\", \\\"{x:1432,y:667,t:1527877160488};\\\", \\\"{x:1428,y:676,t:1527877160506};\\\", \\\"{x:1424,y:684,t:1527877160522};\\\", \\\"{x:1419,y:699,t:1527877160539};\\\", \\\"{x:1410,y:714,t:1527877160556};\\\", \\\"{x:1402,y:729,t:1527877160572};\\\", \\\"{x:1392,y:745,t:1527877160589};\\\", \\\"{x:1386,y:764,t:1527877160606};\\\", \\\"{x:1385,y:771,t:1527877160622};\\\", \\\"{x:1384,y:777,t:1527877160639};\\\", \\\"{x:1383,y:779,t:1527877160656};\\\", \\\"{x:1382,y:782,t:1527877160673};\\\", \\\"{x:1380,y:787,t:1527877160689};\\\", \\\"{x:1379,y:788,t:1527877160706};\\\", \\\"{x:1379,y:792,t:1527877160723};\\\", \\\"{x:1378,y:796,t:1527877160739};\\\", \\\"{x:1376,y:799,t:1527877160756};\\\", \\\"{x:1376,y:803,t:1527877160773};\\\", \\\"{x:1372,y:809,t:1527877160789};\\\", \\\"{x:1368,y:816,t:1527877160806};\\\", \\\"{x:1364,y:826,t:1527877160824};\\\", \\\"{x:1360,y:831,t:1527877160839};\\\", \\\"{x:1357,y:838,t:1527877160856};\\\", \\\"{x:1353,y:845,t:1527877160874};\\\", \\\"{x:1349,y:851,t:1527877160889};\\\", \\\"{x:1348,y:856,t:1527877160906};\\\", \\\"{x:1347,y:859,t:1527877160924};\\\", \\\"{x:1346,y:864,t:1527877160940};\\\", \\\"{x:1345,y:865,t:1527877160957};\\\", \\\"{x:1343,y:867,t:1527877160973};\\\", \\\"{x:1340,y:873,t:1527877160990};\\\", \\\"{x:1334,y:882,t:1527877161006};\\\", \\\"{x:1331,y:889,t:1527877161023};\\\", \\\"{x:1329,y:893,t:1527877161040};\\\", \\\"{x:1328,y:895,t:1527877161056};\\\", \\\"{x:1326,y:898,t:1527877161074};\\\", \\\"{x:1326,y:900,t:1527877161090};\\\", \\\"{x:1323,y:904,t:1527877161107};\\\", \\\"{x:1322,y:908,t:1527877161123};\\\", \\\"{x:1319,y:913,t:1527877161141};\\\", \\\"{x:1316,y:920,t:1527877161156};\\\", \\\"{x:1314,y:927,t:1527877161173};\\\", \\\"{x:1312,y:933,t:1527877161190};\\\", \\\"{x:1309,y:938,t:1527877161207};\\\", \\\"{x:1307,y:942,t:1527877161223};\\\", \\\"{x:1304,y:947,t:1527877161240};\\\", \\\"{x:1303,y:951,t:1527877161256};\\\", \\\"{x:1298,y:954,t:1527877161273};\\\", \\\"{x:1297,y:956,t:1527877161291};\\\", \\\"{x:1294,y:959,t:1527877161306};\\\", \\\"{x:1292,y:959,t:1527877161323};\\\", \\\"{x:1291,y:959,t:1527877161339};\\\", \\\"{x:1292,y:956,t:1527877161661};\\\", \\\"{x:1294,y:952,t:1527877161673};\\\", \\\"{x:1299,y:939,t:1527877161690};\\\", \\\"{x:1309,y:921,t:1527877161707};\\\", \\\"{x:1323,y:895,t:1527877161723};\\\", \\\"{x:1338,y:875,t:1527877161740};\\\", \\\"{x:1351,y:857,t:1527877161756};\\\", \\\"{x:1366,y:840,t:1527877161772};\\\", \\\"{x:1378,y:823,t:1527877161789};\\\", \\\"{x:1386,y:808,t:1527877161806};\\\", \\\"{x:1393,y:795,t:1527877161823};\\\", \\\"{x:1398,y:782,t:1527877161839};\\\", \\\"{x:1402,y:767,t:1527877161856};\\\", \\\"{x:1403,y:759,t:1527877161873};\\\", \\\"{x:1408,y:748,t:1527877161890};\\\", \\\"{x:1414,y:735,t:1527877161907};\\\", \\\"{x:1419,y:725,t:1527877161923};\\\", \\\"{x:1427,y:709,t:1527877161939};\\\", \\\"{x:1432,y:699,t:1527877161957};\\\", \\\"{x:1438,y:684,t:1527877161973};\\\", \\\"{x:1441,y:674,t:1527877161990};\\\", \\\"{x:1447,y:659,t:1527877162007};\\\", \\\"{x:1452,y:645,t:1527877162024};\\\", \\\"{x:1457,y:635,t:1527877162040};\\\", \\\"{x:1461,y:625,t:1527877162057};\\\", \\\"{x:1464,y:622,t:1527877162073};\\\", \\\"{x:1464,y:621,t:1527877162090};\\\", \\\"{x:1464,y:620,t:1527877162106};\\\", \\\"{x:1464,y:619,t:1527877162182};\\\", \\\"{x:1462,y:619,t:1527877162205};\\\", \\\"{x:1461,y:619,t:1527877162213};\\\", \\\"{x:1457,y:619,t:1527877162224};\\\", \\\"{x:1457,y:620,t:1527877162277};\\\", \\\"{x:1456,y:623,t:1527877162289};\\\", \\\"{x:1456,y:631,t:1527877162306};\\\", \\\"{x:1456,y:640,t:1527877162324};\\\", \\\"{x:1456,y:647,t:1527877162340};\\\", \\\"{x:1459,y:652,t:1527877162357};\\\", \\\"{x:1464,y:662,t:1527877162373};\\\", \\\"{x:1466,y:668,t:1527877162391};\\\", \\\"{x:1467,y:671,t:1527877162407};\\\", \\\"{x:1467,y:672,t:1527877162430};\\\", \\\"{x:1467,y:673,t:1527877162441};\\\", \\\"{x:1468,y:675,t:1527877162457};\\\", \\\"{x:1468,y:676,t:1527877162477};\\\", \\\"{x:1468,y:677,t:1527877162518};\\\", \\\"{x:1469,y:678,t:1527877162550};\\\", \\\"{x:1470,y:678,t:1527877162566};\\\", \\\"{x:1470,y:680,t:1527877162574};\\\", \\\"{x:1472,y:682,t:1527877162591};\\\", \\\"{x:1474,y:684,t:1527877162607};\\\", \\\"{x:1476,y:690,t:1527877162624};\\\", \\\"{x:1488,y:703,t:1527877162641};\\\", \\\"{x:1499,y:712,t:1527877162657};\\\", \\\"{x:1509,y:720,t:1527877162674};\\\", \\\"{x:1512,y:722,t:1527877162691};\\\", \\\"{x:1512,y:723,t:1527877162805};\\\", \\\"{x:1512,y:724,t:1527877162813};\\\", \\\"{x:1512,y:725,t:1527877162830};\\\", \\\"{x:1513,y:726,t:1527877162845};\\\", \\\"{x:1513,y:727,t:1527877162857};\\\", \\\"{x:1513,y:731,t:1527877162874};\\\", \\\"{x:1514,y:733,t:1527877162891};\\\", \\\"{x:1515,y:735,t:1527877162908};\\\", \\\"{x:1516,y:738,t:1527877162924};\\\", \\\"{x:1516,y:742,t:1527877162941};\\\", \\\"{x:1516,y:746,t:1527877162957};\\\", \\\"{x:1518,y:750,t:1527877162974};\\\", \\\"{x:1518,y:754,t:1527877162991};\\\", \\\"{x:1518,y:760,t:1527877163008};\\\", \\\"{x:1518,y:764,t:1527877163023};\\\", \\\"{x:1519,y:767,t:1527877163041};\\\", \\\"{x:1520,y:768,t:1527877163057};\\\", \\\"{x:1520,y:770,t:1527877163085};\\\", \\\"{x:1521,y:771,t:1527877163133};\\\", \\\"{x:1522,y:773,t:1527877163157};\\\", \\\"{x:1523,y:777,t:1527877163174};\\\", \\\"{x:1524,y:781,t:1527877163191};\\\", \\\"{x:1525,y:784,t:1527877163208};\\\", \\\"{x:1526,y:786,t:1527877163224};\\\", \\\"{x:1526,y:787,t:1527877163241};\\\", \\\"{x:1526,y:788,t:1527877163258};\\\", \\\"{x:1528,y:788,t:1527877163326};\\\", \\\"{x:1529,y:784,t:1527877163341};\\\", \\\"{x:1528,y:764,t:1527877163357};\\\", \\\"{x:1521,y:748,t:1527877163375};\\\", \\\"{x:1511,y:731,t:1527877163391};\\\", \\\"{x:1507,y:721,t:1527877163408};\\\", \\\"{x:1506,y:707,t:1527877163425};\\\", \\\"{x:1506,y:693,t:1527877163441};\\\", \\\"{x:1505,y:682,t:1527877163458};\\\", \\\"{x:1500,y:664,t:1527877163475};\\\", \\\"{x:1489,y:646,t:1527877163491};\\\", \\\"{x:1483,y:639,t:1527877163508};\\\", \\\"{x:1480,y:636,t:1527877163525};\\\", \\\"{x:1480,y:635,t:1527877163541};\\\", \\\"{x:1478,y:634,t:1527877163558};\\\", \\\"{x:1475,y:633,t:1527877163575};\\\", \\\"{x:1471,y:632,t:1527877163591};\\\", \\\"{x:1467,y:632,t:1527877163608};\\\", \\\"{x:1466,y:631,t:1527877163625};\\\", \\\"{x:1465,y:632,t:1527877163709};\\\", \\\"{x:1465,y:634,t:1527877163725};\\\", \\\"{x:1465,y:641,t:1527877163741};\\\", \\\"{x:1465,y:647,t:1527877163758};\\\", \\\"{x:1469,y:657,t:1527877163775};\\\", \\\"{x:1472,y:662,t:1527877163792};\\\", \\\"{x:1477,y:672,t:1527877163808};\\\", \\\"{x:1480,y:680,t:1527877163825};\\\", \\\"{x:1487,y:694,t:1527877163842};\\\", \\\"{x:1492,y:707,t:1527877163858};\\\", \\\"{x:1498,y:719,t:1527877163875};\\\", \\\"{x:1504,y:728,t:1527877163892};\\\", \\\"{x:1508,y:734,t:1527877163908};\\\", \\\"{x:1511,y:743,t:1527877163925};\\\", \\\"{x:1513,y:752,t:1527877163942};\\\", \\\"{x:1514,y:758,t:1527877163958};\\\", \\\"{x:1516,y:763,t:1527877163974};\\\", \\\"{x:1516,y:767,t:1527877163992};\\\", \\\"{x:1516,y:770,t:1527877164008};\\\", \\\"{x:1517,y:773,t:1527877164025};\\\", \\\"{x:1518,y:776,t:1527877164042};\\\", \\\"{x:1518,y:780,t:1527877164058};\\\", \\\"{x:1520,y:783,t:1527877164075};\\\", \\\"{x:1522,y:792,t:1527877164092};\\\", \\\"{x:1526,y:797,t:1527877164108};\\\", \\\"{x:1529,y:802,t:1527877164125};\\\", \\\"{x:1534,y:810,t:1527877164142};\\\", \\\"{x:1536,y:814,t:1527877164159};\\\", \\\"{x:1540,y:821,t:1527877164175};\\\", \\\"{x:1541,y:825,t:1527877164192};\\\", \\\"{x:1545,y:832,t:1527877164209};\\\", \\\"{x:1548,y:836,t:1527877164225};\\\", \\\"{x:1550,y:840,t:1527877164242};\\\", \\\"{x:1551,y:841,t:1527877164259};\\\", \\\"{x:1552,y:844,t:1527877164275};\\\", \\\"{x:1555,y:848,t:1527877164292};\\\", \\\"{x:1557,y:857,t:1527877164309};\\\", \\\"{x:1563,y:865,t:1527877164325};\\\", \\\"{x:1567,y:872,t:1527877164341};\\\", \\\"{x:1568,y:873,t:1527877164359};\\\", \\\"{x:1570,y:875,t:1527877164375};\\\", \\\"{x:1571,y:876,t:1527877164392};\\\", \\\"{x:1573,y:880,t:1527877164409};\\\", \\\"{x:1576,y:886,t:1527877164425};\\\", \\\"{x:1578,y:888,t:1527877164442};\\\", \\\"{x:1579,y:890,t:1527877164459};\\\", \\\"{x:1579,y:892,t:1527877164494};\\\", \\\"{x:1579,y:893,t:1527877164509};\\\", \\\"{x:1580,y:893,t:1527877164679};\\\", \\\"{x:1582,y:893,t:1527877164692};\\\", \\\"{x:1582,y:895,t:1527877164709};\\\", \\\"{x:1582,y:896,t:1527877164727};\\\", \\\"{x:1582,y:899,t:1527877164743};\\\", \\\"{x:1582,y:900,t:1527877164791};\\\", \\\"{x:1583,y:901,t:1527877164879};\\\", \\\"{x:1583,y:902,t:1527877164892};\\\", \\\"{x:1583,y:904,t:1527877164909};\\\", \\\"{x:1584,y:905,t:1527877164926};\\\", \\\"{x:1585,y:906,t:1527877164942};\\\", \\\"{x:1586,y:906,t:1527877164959};\\\", \\\"{x:1589,y:908,t:1527877164976};\\\", \\\"{x:1589,y:911,t:1527877164992};\\\", \\\"{x:1591,y:912,t:1527877165009};\\\", \\\"{x:1592,y:913,t:1527877165026};\\\", \\\"{x:1594,y:916,t:1527877165043};\\\", \\\"{x:1594,y:917,t:1527877165062};\\\", \\\"{x:1595,y:917,t:1527877165076};\\\", \\\"{x:1595,y:916,t:1527877165911};\\\", \\\"{x:1595,y:909,t:1527877165927};\\\", \\\"{x:1593,y:898,t:1527877165944};\\\", \\\"{x:1586,y:880,t:1527877165961};\\\", \\\"{x:1575,y:858,t:1527877165977};\\\", \\\"{x:1566,y:834,t:1527877165994};\\\", \\\"{x:1555,y:810,t:1527877166011};\\\", \\\"{x:1544,y:788,t:1527877166027};\\\", \\\"{x:1538,y:771,t:1527877166044};\\\", \\\"{x:1533,y:758,t:1527877166061};\\\", \\\"{x:1531,y:745,t:1527877166078};\\\", \\\"{x:1522,y:725,t:1527877166094};\\\", \\\"{x:1508,y:699,t:1527877166110};\\\", \\\"{x:1498,y:684,t:1527877166128};\\\", \\\"{x:1491,y:675,t:1527877166144};\\\", \\\"{x:1486,y:669,t:1527877166161};\\\", \\\"{x:1480,y:662,t:1527877166178};\\\", \\\"{x:1478,y:659,t:1527877166193};\\\", \\\"{x:1475,y:656,t:1527877166210};\\\", \\\"{x:1474,y:652,t:1527877166228};\\\", \\\"{x:1470,y:649,t:1527877166244};\\\", \\\"{x:1465,y:644,t:1527877166260};\\\", \\\"{x:1463,y:643,t:1527877166277};\\\", \\\"{x:1462,y:643,t:1527877166294};\\\", \\\"{x:1460,y:639,t:1527877166310};\\\", \\\"{x:1459,y:639,t:1527877166328};\\\", \\\"{x:1459,y:638,t:1527877166344};\\\", \\\"{x:1458,y:638,t:1527877166766};\\\", \\\"{x:1457,y:638,t:1527877168247};\\\", \\\"{x:1456,y:638,t:1527877168263};\\\", \\\"{x:1455,y:638,t:1527877168287};\\\", \\\"{x:1454,y:638,t:1527877168303};\\\", \\\"{x:1453,y:639,t:1527877168326};\\\", \\\"{x:1453,y:640,t:1527877168703};\\\", \\\"{x:1453,y:643,t:1527877168713};\\\", \\\"{x:1454,y:653,t:1527877168730};\\\", \\\"{x:1457,y:670,t:1527877168746};\\\", \\\"{x:1462,y:687,t:1527877168763};\\\", \\\"{x:1468,y:704,t:1527877168780};\\\", \\\"{x:1474,y:727,t:1527877168796};\\\", \\\"{x:1479,y:745,t:1527877168813};\\\", \\\"{x:1483,y:755,t:1527877168830};\\\", \\\"{x:1485,y:763,t:1527877168846};\\\", \\\"{x:1485,y:770,t:1527877168863};\\\", \\\"{x:1485,y:773,t:1527877168880};\\\", \\\"{x:1485,y:780,t:1527877168896};\\\", \\\"{x:1482,y:786,t:1527877168913};\\\", \\\"{x:1480,y:794,t:1527877168930};\\\", \\\"{x:1479,y:798,t:1527877168946};\\\", \\\"{x:1479,y:799,t:1527877169048};\\\", \\\"{x:1479,y:800,t:1527877169063};\\\", \\\"{x:1478,y:801,t:1527877169087};\\\", \\\"{x:1478,y:802,t:1527877169167};\\\", \\\"{x:1479,y:804,t:1527877169975};\\\", \\\"{x:1480,y:804,t:1527877169991};\\\", \\\"{x:1481,y:804,t:1527877169998};\\\", \\\"{x:1482,y:805,t:1527877170014};\\\", \\\"{x:1483,y:807,t:1527877170031};\\\", \\\"{x:1483,y:808,t:1527877170087};\\\", \\\"{x:1483,y:809,t:1527877170102};\\\", \\\"{x:1483,y:810,t:1527877170134};\\\", \\\"{x:1482,y:810,t:1527877170148};\\\", \\\"{x:1481,y:813,t:1527877170164};\\\", \\\"{x:1480,y:816,t:1527877170181};\\\", \\\"{x:1479,y:821,t:1527877170197};\\\", \\\"{x:1479,y:832,t:1527877170215};\\\", \\\"{x:1479,y:840,t:1527877170232};\\\", \\\"{x:1479,y:846,t:1527877170247};\\\", \\\"{x:1482,y:850,t:1527877170264};\\\", \\\"{x:1482,y:851,t:1527877170281};\\\", \\\"{x:1482,y:852,t:1527877170327};\\\", \\\"{x:1482,y:854,t:1527877170335};\\\", \\\"{x:1483,y:855,t:1527877170348};\\\", \\\"{x:1483,y:856,t:1527877170364};\\\", \\\"{x:1484,y:859,t:1527877170381};\\\", \\\"{x:1485,y:859,t:1527877170407};\\\", \\\"{x:1487,y:859,t:1527877170485};\\\", \\\"{x:1489,y:858,t:1527877170502};\\\", \\\"{x:1489,y:857,t:1527877170514};\\\", \\\"{x:1489,y:854,t:1527877170530};\\\", \\\"{x:1489,y:849,t:1527877170547};\\\", \\\"{x:1490,y:844,t:1527877170564};\\\", \\\"{x:1492,y:840,t:1527877170580};\\\", \\\"{x:1492,y:833,t:1527877170598};\\\", \\\"{x:1492,y:832,t:1527877170614};\\\", \\\"{x:1493,y:825,t:1527877170631};\\\", \\\"{x:1493,y:823,t:1527877170647};\\\", \\\"{x:1493,y:819,t:1527877170664};\\\", \\\"{x:1494,y:816,t:1527877170681};\\\", \\\"{x:1494,y:813,t:1527877170698};\\\", \\\"{x:1494,y:811,t:1527877170713};\\\", \\\"{x:1494,y:806,t:1527877170731};\\\", \\\"{x:1494,y:805,t:1527877170747};\\\", \\\"{x:1494,y:804,t:1527877170783};\\\", \\\"{x:1494,y:803,t:1527877170798};\\\", \\\"{x:1494,y:801,t:1527877170814};\\\", \\\"{x:1494,y:799,t:1527877170831};\\\", \\\"{x:1494,y:797,t:1527877170848};\\\", \\\"{x:1494,y:796,t:1527877170865};\\\", \\\"{x:1494,y:794,t:1527877170919};\\\", \\\"{x:1494,y:792,t:1527877170935};\\\", \\\"{x:1494,y:789,t:1527877170948};\\\", \\\"{x:1494,y:788,t:1527877170982};\\\", \\\"{x:1495,y:786,t:1527877170999};\\\", \\\"{x:1495,y:783,t:1527877171015};\\\", \\\"{x:1496,y:780,t:1527877171031};\\\", \\\"{x:1496,y:775,t:1527877171048};\\\", \\\"{x:1497,y:771,t:1527877171065};\\\", \\\"{x:1497,y:765,t:1527877171081};\\\", \\\"{x:1497,y:763,t:1527877171098};\\\", \\\"{x:1497,y:759,t:1527877171115};\\\", \\\"{x:1497,y:754,t:1527877171131};\\\", \\\"{x:1495,y:744,t:1527877171148};\\\", \\\"{x:1489,y:733,t:1527877171164};\\\", \\\"{x:1488,y:727,t:1527877171181};\\\", \\\"{x:1479,y:711,t:1527877171198};\\\", \\\"{x:1471,y:695,t:1527877171214};\\\", \\\"{x:1464,y:675,t:1527877171232};\\\", \\\"{x:1461,y:668,t:1527877171248};\\\", \\\"{x:1460,y:663,t:1527877171265};\\\", \\\"{x:1458,y:654,t:1527877171281};\\\", \\\"{x:1456,y:648,t:1527877171298};\\\", \\\"{x:1456,y:644,t:1527877171314};\\\", \\\"{x:1455,y:642,t:1527877171332};\\\", \\\"{x:1454,y:638,t:1527877171348};\\\", \\\"{x:1454,y:637,t:1527877171365};\\\", \\\"{x:1457,y:632,t:1527877171382};\\\", \\\"{x:1457,y:631,t:1527877171399};\\\", \\\"{x:1457,y:630,t:1527877171430};\\\", \\\"{x:1457,y:629,t:1527877171471};\\\", \\\"{x:1458,y:629,t:1527877171575};\\\", \\\"{x:1459,y:629,t:1527877171678};\\\", \\\"{x:1460,y:627,t:1527877171687};\\\", \\\"{x:1462,y:627,t:1527877171699};\\\", \\\"{x:1464,y:624,t:1527877171715};\\\", \\\"{x:1467,y:621,t:1527877171732};\\\", \\\"{x:1471,y:616,t:1527877171749};\\\", \\\"{x:1474,y:611,t:1527877171765};\\\", \\\"{x:1474,y:610,t:1527877171782};\\\", \\\"{x:1475,y:608,t:1527877171799};\\\", \\\"{x:1477,y:602,t:1527877171815};\\\", \\\"{x:1480,y:596,t:1527877171832};\\\", \\\"{x:1480,y:592,t:1527877171849};\\\", \\\"{x:1481,y:589,t:1527877171865};\\\", \\\"{x:1481,y:587,t:1527877171882};\\\", \\\"{x:1481,y:586,t:1527877171899};\\\", \\\"{x:1481,y:585,t:1527877171918};\\\", \\\"{x:1481,y:583,t:1527877171942};\\\", \\\"{x:1481,y:581,t:1527877171950};\\\", \\\"{x:1481,y:579,t:1527877171965};\\\", \\\"{x:1478,y:571,t:1527877171983};\\\", \\\"{x:1477,y:568,t:1527877171999};\\\", \\\"{x:1476,y:566,t:1527877172015};\\\", \\\"{x:1476,y:565,t:1527877172032};\\\", \\\"{x:1476,y:563,t:1527877172055};\\\", \\\"{x:1475,y:561,t:1527877172071};\\\", \\\"{x:1475,y:560,t:1527877172082};\\\", \\\"{x:1475,y:556,t:1527877172099};\\\", \\\"{x:1473,y:553,t:1527877172115};\\\", \\\"{x:1472,y:546,t:1527877172131};\\\", \\\"{x:1472,y:540,t:1527877172148};\\\", \\\"{x:1471,y:530,t:1527877172165};\\\", \\\"{x:1471,y:522,t:1527877172181};\\\", \\\"{x:1471,y:512,t:1527877172198};\\\", \\\"{x:1471,y:502,t:1527877172215};\\\", \\\"{x:1476,y:485,t:1527877172231};\\\", \\\"{x:1482,y:467,t:1527877172248};\\\", \\\"{x:1484,y:453,t:1527877172266};\\\", \\\"{x:1484,y:439,t:1527877172282};\\\", \\\"{x:1486,y:426,t:1527877172298};\\\", \\\"{x:1487,y:416,t:1527877172315};\\\", \\\"{x:1491,y:406,t:1527877172331};\\\", \\\"{x:1494,y:400,t:1527877172349};\\\", \\\"{x:1498,y:382,t:1527877172365};\\\", \\\"{x:1501,y:374,t:1527877172381};\\\", \\\"{x:1502,y:366,t:1527877172399};\\\", \\\"{x:1502,y:360,t:1527877172416};\\\", \\\"{x:1502,y:357,t:1527877172431};\\\", \\\"{x:1502,y:355,t:1527877172448};\\\", \\\"{x:1502,y:354,t:1527877172465};\\\", \\\"{x:1502,y:351,t:1527877172486};\\\", \\\"{x:1502,y:350,t:1527877172498};\\\", \\\"{x:1502,y:348,t:1527877172515};\\\", \\\"{x:1499,y:343,t:1527877172532};\\\", \\\"{x:1499,y:340,t:1527877172550};\\\", \\\"{x:1498,y:336,t:1527877172566};\\\", \\\"{x:1496,y:334,t:1527877172582};\\\", \\\"{x:1494,y:330,t:1527877172599};\\\", \\\"{x:1492,y:328,t:1527877172615};\\\", \\\"{x:1490,y:324,t:1527877172633};\\\", \\\"{x:1489,y:320,t:1527877172648};\\\", \\\"{x:1489,y:318,t:1527877172665};\\\", \\\"{x:1488,y:316,t:1527877172682};\\\", \\\"{x:1486,y:313,t:1527877172699};\\\", \\\"{x:1486,y:312,t:1527877172715};\\\", \\\"{x:1486,y:311,t:1527877172732};\\\", \\\"{x:1485,y:308,t:1527877172748};\\\", \\\"{x:1485,y:307,t:1527877172863};\\\", \\\"{x:1485,y:306,t:1527877172886};\\\", \\\"{x:1485,y:305,t:1527877172911};\\\", \\\"{x:1485,y:304,t:1527877172933};\\\", \\\"{x:1485,y:303,t:1527877172973};\\\", \\\"{x:1485,y:302,t:1527877173030};\\\", \\\"{x:1485,y:301,t:1527877173046};\\\", \\\"{x:1484,y:301,t:1527877175830};\\\", \\\"{x:1479,y:303,t:1527877175852};\\\", \\\"{x:1476,y:307,t:1527877175867};\\\", \\\"{x:1474,y:309,t:1527877175884};\\\", \\\"{x:1470,y:311,t:1527877175901};\\\", \\\"{x:1468,y:315,t:1527877175918};\\\", \\\"{x:1466,y:318,t:1527877175935};\\\", \\\"{x:1465,y:322,t:1527877175952};\\\", \\\"{x:1463,y:326,t:1527877175968};\\\", \\\"{x:1462,y:330,t:1527877175985};\\\", \\\"{x:1461,y:336,t:1527877176002};\\\", \\\"{x:1460,y:341,t:1527877176019};\\\", \\\"{x:1456,y:354,t:1527877176034};\\\", \\\"{x:1450,y:371,t:1527877176051};\\\", \\\"{x:1443,y:394,t:1527877176068};\\\", \\\"{x:1437,y:422,t:1527877176084};\\\", \\\"{x:1430,y:454,t:1527877176101};\\\", \\\"{x:1424,y:471,t:1527877176118};\\\", \\\"{x:1421,y:487,t:1527877176134};\\\", \\\"{x:1413,y:508,t:1527877176151};\\\", \\\"{x:1406,y:531,t:1527877176168};\\\", \\\"{x:1396,y:546,t:1527877176185};\\\", \\\"{x:1391,y:553,t:1527877176201};\\\", \\\"{x:1390,y:554,t:1527877176229};\\\", \\\"{x:1390,y:555,t:1527877176237};\\\", \\\"{x:1389,y:557,t:1527877176251};\\\", \\\"{x:1384,y:561,t:1527877176268};\\\", \\\"{x:1380,y:565,t:1527877176285};\\\", \\\"{x:1364,y:578,t:1527877176301};\\\", \\\"{x:1359,y:583,t:1527877176319};\\\", \\\"{x:1352,y:590,t:1527877176334};\\\", \\\"{x:1346,y:601,t:1527877176351};\\\", \\\"{x:1336,y:612,t:1527877176368};\\\", \\\"{x:1322,y:628,t:1527877176385};\\\", \\\"{x:1305,y:650,t:1527877176401};\\\", \\\"{x:1291,y:675,t:1527877176419};\\\", \\\"{x:1270,y:715,t:1527877176435};\\\", \\\"{x:1258,y:739,t:1527877176451};\\\", \\\"{x:1245,y:766,t:1527877176468};\\\", \\\"{x:1235,y:802,t:1527877176485};\\\", \\\"{x:1235,y:819,t:1527877176501};\\\", \\\"{x:1235,y:832,t:1527877176518};\\\", \\\"{x:1235,y:836,t:1527877176535};\\\", \\\"{x:1235,y:838,t:1527877176551};\\\", \\\"{x:1235,y:840,t:1527877176568};\\\", \\\"{x:1235,y:843,t:1527877176585};\\\", \\\"{x:1235,y:847,t:1527877176602};\\\", \\\"{x:1234,y:853,t:1527877176618};\\\", \\\"{x:1234,y:858,t:1527877176636};\\\", \\\"{x:1232,y:863,t:1527877176651};\\\", \\\"{x:1229,y:870,t:1527877176669};\\\", \\\"{x:1223,y:877,t:1527877176685};\\\", \\\"{x:1218,y:884,t:1527877176701};\\\", \\\"{x:1212,y:892,t:1527877176719};\\\", \\\"{x:1205,y:902,t:1527877176735};\\\", \\\"{x:1198,y:911,t:1527877176751};\\\", \\\"{x:1193,y:918,t:1527877176768};\\\", \\\"{x:1184,y:928,t:1527877176785};\\\", \\\"{x:1176,y:937,t:1527877176801};\\\", \\\"{x:1165,y:948,t:1527877176819};\\\", \\\"{x:1159,y:956,t:1527877176835};\\\", \\\"{x:1154,y:960,t:1527877176852};\\\", \\\"{x:1152,y:962,t:1527877176869};\\\", \\\"{x:1151,y:964,t:1527877176885};\\\", \\\"{x:1151,y:965,t:1527877176903};\\\", \\\"{x:1151,y:966,t:1527877176926};\\\", \\\"{x:1150,y:966,t:1527877176973};\\\", \\\"{x:1150,y:961,t:1527877177182};\\\", \\\"{x:1156,y:948,t:1527877177190};\\\", \\\"{x:1170,y:928,t:1527877177202};\\\", \\\"{x:1208,y:872,t:1527877177218};\\\", \\\"{x:1257,y:792,t:1527877177236};\\\", \\\"{x:1308,y:710,t:1527877177253};\\\", \\\"{x:1355,y:638,t:1527877177269};\\\", \\\"{x:1413,y:554,t:1527877177285};\\\", \\\"{x:1439,y:510,t:1527877177303};\\\", \\\"{x:1458,y:473,t:1527877177320};\\\", \\\"{x:1481,y:444,t:1527877177336};\\\", \\\"{x:1491,y:429,t:1527877177353};\\\", \\\"{x:1496,y:416,t:1527877177369};\\\", \\\"{x:1500,y:403,t:1527877177385};\\\", \\\"{x:1500,y:389,t:1527877177402};\\\", \\\"{x:1504,y:375,t:1527877177420};\\\", \\\"{x:1508,y:360,t:1527877177435};\\\", \\\"{x:1514,y:347,t:1527877177452};\\\", \\\"{x:1516,y:334,t:1527877177469};\\\", \\\"{x:1519,y:324,t:1527877177485};\\\", \\\"{x:1520,y:316,t:1527877177503};\\\", \\\"{x:1521,y:310,t:1527877177519};\\\", \\\"{x:1521,y:303,t:1527877177536};\\\", \\\"{x:1521,y:298,t:1527877177552};\\\", \\\"{x:1520,y:296,t:1527877177570};\\\", \\\"{x:1518,y:295,t:1527877177586};\\\", \\\"{x:1517,y:295,t:1527877177602};\\\", \\\"{x:1515,y:295,t:1527877177620};\\\", \\\"{x:1508,y:295,t:1527877177636};\\\", \\\"{x:1505,y:295,t:1527877177653};\\\", \\\"{x:1503,y:295,t:1527877177669};\\\", \\\"{x:1502,y:295,t:1527877177773};\\\", \\\"{x:1499,y:298,t:1527877177785};\\\", \\\"{x:1496,y:307,t:1527877177802};\\\", \\\"{x:1494,y:317,t:1527877177820};\\\", \\\"{x:1489,y:335,t:1527877177836};\\\", \\\"{x:1489,y:365,t:1527877177852};\\\", \\\"{x:1512,y:437,t:1527877177869};\\\", \\\"{x:1536,y:479,t:1527877177887};\\\", \\\"{x:1560,y:508,t:1527877177903};\\\", \\\"{x:1578,y:529,t:1527877177919};\\\", \\\"{x:1589,y:541,t:1527877177936};\\\", \\\"{x:1597,y:551,t:1527877177953};\\\", \\\"{x:1599,y:558,t:1527877177970};\\\", \\\"{x:1601,y:562,t:1527877177986};\\\", \\\"{x:1602,y:565,t:1527877178003};\\\", \\\"{x:1602,y:566,t:1527877178020};\\\", \\\"{x:1602,y:567,t:1527877178045};\\\", \\\"{x:1602,y:562,t:1527877178141};\\\", \\\"{x:1602,y:554,t:1527877178153};\\\", \\\"{x:1602,y:531,t:1527877178169};\\\", \\\"{x:1597,y:502,t:1527877178187};\\\", \\\"{x:1578,y:465,t:1527877178204};\\\", \\\"{x:1567,y:447,t:1527877178220};\\\", \\\"{x:1560,y:435,t:1527877178236};\\\", \\\"{x:1554,y:424,t:1527877178253};\\\", \\\"{x:1551,y:419,t:1527877178270};\\\", \\\"{x:1551,y:413,t:1527877178286};\\\", \\\"{x:1550,y:407,t:1527877178304};\\\", \\\"{x:1543,y:396,t:1527877178320};\\\", \\\"{x:1534,y:386,t:1527877178337};\\\", \\\"{x:1529,y:379,t:1527877178353};\\\", \\\"{x:1525,y:374,t:1527877178370};\\\", \\\"{x:1523,y:371,t:1527877178387};\\\", \\\"{x:1523,y:366,t:1527877178403};\\\", \\\"{x:1521,y:360,t:1527877178419};\\\", \\\"{x:1518,y:355,t:1527877178437};\\\", \\\"{x:1518,y:356,t:1527877178493};\\\", \\\"{x:1518,y:364,t:1527877178504};\\\", \\\"{x:1520,y:381,t:1527877178520};\\\", \\\"{x:1521,y:391,t:1527877178536};\\\", \\\"{x:1522,y:400,t:1527877178554};\\\", \\\"{x:1524,y:414,t:1527877178569};\\\", \\\"{x:1527,y:428,t:1527877178586};\\\", \\\"{x:1532,y:448,t:1527877178604};\\\", \\\"{x:1540,y:470,t:1527877178619};\\\", \\\"{x:1548,y:489,t:1527877178636};\\\", \\\"{x:1558,y:508,t:1527877178654};\\\", \\\"{x:1561,y:513,t:1527877178671};\\\", \\\"{x:1563,y:518,t:1527877178687};\\\", \\\"{x:1566,y:523,t:1527877178703};\\\", \\\"{x:1567,y:526,t:1527877178719};\\\", \\\"{x:1570,y:532,t:1527877178737};\\\", \\\"{x:1572,y:538,t:1527877178754};\\\", \\\"{x:1577,y:547,t:1527877178771};\\\", \\\"{x:1583,y:556,t:1527877178786};\\\", \\\"{x:1588,y:566,t:1527877178804};\\\", \\\"{x:1593,y:571,t:1527877178821};\\\", \\\"{x:1598,y:580,t:1527877178836};\\\", \\\"{x:1611,y:597,t:1527877178854};\\\", \\\"{x:1619,y:608,t:1527877178871};\\\", \\\"{x:1628,y:618,t:1527877178886};\\\", \\\"{x:1643,y:630,t:1527877178903};\\\", \\\"{x:1656,y:640,t:1527877178921};\\\", \\\"{x:1667,y:651,t:1527877178937};\\\", \\\"{x:1675,y:662,t:1527877178953};\\\", \\\"{x:1685,y:678,t:1527877178970};\\\", \\\"{x:1690,y:691,t:1527877178986};\\\", \\\"{x:1695,y:701,t:1527877179003};\\\", \\\"{x:1700,y:709,t:1527877179021};\\\", \\\"{x:1705,y:719,t:1527877179037};\\\", \\\"{x:1718,y:745,t:1527877179054};\\\", \\\"{x:1724,y:760,t:1527877179071};\\\", \\\"{x:1725,y:766,t:1527877179087};\\\", \\\"{x:1728,y:776,t:1527877179104};\\\", \\\"{x:1735,y:787,t:1527877179121};\\\", \\\"{x:1741,y:796,t:1527877179137};\\\", \\\"{x:1745,y:803,t:1527877179154};\\\", \\\"{x:1747,y:807,t:1527877179171};\\\", \\\"{x:1748,y:810,t:1527877179187};\\\", \\\"{x:1749,y:814,t:1527877179203};\\\", \\\"{x:1751,y:819,t:1527877179221};\\\", \\\"{x:1757,y:829,t:1527877179238};\\\", \\\"{x:1762,y:835,t:1527877179254};\\\", \\\"{x:1764,y:839,t:1527877179271};\\\", \\\"{x:1767,y:843,t:1527877179288};\\\", \\\"{x:1773,y:851,t:1527877179303};\\\", \\\"{x:1781,y:863,t:1527877179320};\\\", \\\"{x:1788,y:873,t:1527877179337};\\\", \\\"{x:1796,y:884,t:1527877179354};\\\", \\\"{x:1804,y:892,t:1527877179371};\\\", \\\"{x:1809,y:901,t:1527877179388};\\\", \\\"{x:1813,y:906,t:1527877179404};\\\", \\\"{x:1815,y:912,t:1527877179420};\\\", \\\"{x:1817,y:919,t:1527877179438};\\\", \\\"{x:1818,y:923,t:1527877179453};\\\", \\\"{x:1819,y:924,t:1527877179471};\\\", \\\"{x:1819,y:926,t:1527877179487};\\\", \\\"{x:1819,y:929,t:1527877179504};\\\", \\\"{x:1819,y:936,t:1527877179521};\\\", \\\"{x:1820,y:944,t:1527877179538};\\\", \\\"{x:1822,y:950,t:1527877179555};\\\", \\\"{x:1823,y:955,t:1527877179571};\\\", \\\"{x:1823,y:957,t:1527877179588};\\\", \\\"{x:1823,y:958,t:1527877179605};\\\", \\\"{x:1823,y:959,t:1527877179620};\\\", \\\"{x:1823,y:960,t:1527877179750};\\\", \\\"{x:1823,y:961,t:1527877179757};\\\", \\\"{x:1823,y:963,t:1527877179773};\\\", \\\"{x:1823,y:964,t:1527877179788};\\\", \\\"{x:1822,y:967,t:1527877179805};\\\", \\\"{x:1822,y:968,t:1527877179821};\\\", \\\"{x:1822,y:969,t:1527877179838};\\\", \\\"{x:1822,y:971,t:1527877179854};\\\", \\\"{x:1821,y:972,t:1527877179870};\\\", \\\"{x:1820,y:972,t:1527877180294};\\\", \\\"{x:1819,y:972,t:1527877180326};\\\", \\\"{x:1819,y:971,t:1527877180614};\\\", \\\"{x:1819,y:970,t:1527877180638};\\\", \\\"{x:1819,y:969,t:1527877180654};\\\", \\\"{x:1819,y:968,t:1527877180669};\\\", \\\"{x:1819,y:967,t:1527877180750};\\\", \\\"{x:1819,y:966,t:1527877180845};\\\", \\\"{x:1819,y:965,t:1527877180877};\\\", \\\"{x:1818,y:963,t:1527877180926};\\\", \\\"{x:1818,y:962,t:1527877180957};\\\", \\\"{x:1818,y:960,t:1527877180990};\\\", \\\"{x:1818,y:959,t:1527877181005};\\\", \\\"{x:1817,y:958,t:1527877181022};\\\", \\\"{x:1817,y:956,t:1527877181669};\\\", \\\"{x:1815,y:949,t:1527877181677};\\\", \\\"{x:1814,y:943,t:1527877181690};\\\", \\\"{x:1805,y:925,t:1527877181706};\\\", \\\"{x:1793,y:897,t:1527877181723};\\\", \\\"{x:1758,y:855,t:1527877181739};\\\", \\\"{x:1723,y:814,t:1527877181756};\\\", \\\"{x:1685,y:767,t:1527877181772};\\\", \\\"{x:1618,y:684,t:1527877181789};\\\", \\\"{x:1590,y:623,t:1527877181805};\\\", \\\"{x:1562,y:559,t:1527877181823};\\\", \\\"{x:1543,y:474,t:1527877181840};\\\", \\\"{x:1529,y:427,t:1527877181856};\\\", \\\"{x:1517,y:387,t:1527877181873};\\\", \\\"{x:1502,y:342,t:1527877181890};\\\", \\\"{x:1496,y:321,t:1527877181906};\\\", \\\"{x:1496,y:312,t:1527877181922};\\\", \\\"{x:1494,y:301,t:1527877181940};\\\", \\\"{x:1491,y:284,t:1527877181956};\\\", \\\"{x:1490,y:273,t:1527877181973};\\\", \\\"{x:1489,y:258,t:1527877181989};\\\", \\\"{x:1489,y:253,t:1527877182006};\\\", \\\"{x:1489,y:251,t:1527877182023};\\\", \\\"{x:1487,y:249,t:1527877182040};\\\", \\\"{x:1484,y:247,t:1527877182056};\\\", \\\"{x:1481,y:245,t:1527877182073};\\\", \\\"{x:1480,y:245,t:1527877182089};\\\", \\\"{x:1478,y:245,t:1527877182106};\\\", \\\"{x:1476,y:245,t:1527877182142};\\\", \\\"{x:1476,y:246,t:1527877182155};\\\", \\\"{x:1475,y:248,t:1527877182173};\\\", \\\"{x:1474,y:255,t:1527877182189};\\\", \\\"{x:1474,y:258,t:1527877182207};\\\", \\\"{x:1474,y:261,t:1527877182223};\\\", \\\"{x:1474,y:265,t:1527877182240};\\\", \\\"{x:1474,y:269,t:1527877182257};\\\", \\\"{x:1474,y:271,t:1527877182273};\\\", \\\"{x:1474,y:275,t:1527877182290};\\\", \\\"{x:1475,y:279,t:1527877182307};\\\", \\\"{x:1476,y:284,t:1527877182323};\\\", \\\"{x:1478,y:287,t:1527877182340};\\\", \\\"{x:1478,y:288,t:1527877182357};\\\", \\\"{x:1478,y:289,t:1527877182374};\\\", \\\"{x:1479,y:290,t:1527877182390};\\\", \\\"{x:1480,y:291,t:1527877182422};\\\", \\\"{x:1482,y:291,t:1527877182440};\\\", \\\"{x:1483,y:291,t:1527877182457};\\\", \\\"{x:1486,y:291,t:1527877182474};\\\", \\\"{x:1487,y:291,t:1527877182495};\\\", \\\"{x:1488,y:292,t:1527877182574};\\\", \\\"{x:1488,y:293,t:1527877182591};\\\", \\\"{x:1488,y:297,t:1527877182607};\\\", \\\"{x:1488,y:298,t:1527877182678};\\\", \\\"{x:1487,y:300,t:1527877182725};\\\", \\\"{x:1486,y:300,t:1527877182774};\\\", \\\"{x:1485,y:300,t:1527877182806};\\\", \\\"{x:1484,y:300,t:1527877182840};\\\", \\\"{x:1481,y:301,t:1527877183446};\\\", \\\"{x:1477,y:305,t:1527877183458};\\\", \\\"{x:1471,y:310,t:1527877183474};\\\", \\\"{x:1460,y:322,t:1527877183491};\\\", \\\"{x:1449,y:338,t:1527877183508};\\\", \\\"{x:1429,y:368,t:1527877183525};\\\", \\\"{x:1412,y:402,t:1527877183541};\\\", \\\"{x:1393,y:434,t:1527877183558};\\\", \\\"{x:1388,y:443,t:1527877183574};\\\", \\\"{x:1384,y:448,t:1527877183591};\\\", \\\"{x:1383,y:451,t:1527877183609};\\\", \\\"{x:1383,y:452,t:1527877183625};\\\", \\\"{x:1382,y:453,t:1527877183642};\\\", \\\"{x:1381,y:454,t:1527877183670};\\\", \\\"{x:1381,y:450,t:1527877183711};\\\", \\\"{x:1382,y:447,t:1527877183724};\\\", \\\"{x:1387,y:432,t:1527877183741};\\\", \\\"{x:1395,y:414,t:1527877183759};\\\", \\\"{x:1403,y:400,t:1527877183775};\\\", \\\"{x:1415,y:384,t:1527877183791};\\\", \\\"{x:1424,y:369,t:1527877183809};\\\", \\\"{x:1427,y:361,t:1527877183825};\\\", \\\"{x:1429,y:357,t:1527877183842};\\\", \\\"{x:1430,y:355,t:1527877183859};\\\", \\\"{x:1431,y:352,t:1527877183875};\\\", \\\"{x:1432,y:350,t:1527877183892};\\\", \\\"{x:1432,y:349,t:1527877183909};\\\", \\\"{x:1432,y:347,t:1527877183925};\\\", \\\"{x:1433,y:346,t:1527877183941};\\\", \\\"{x:1434,y:344,t:1527877183958};\\\", \\\"{x:1431,y:347,t:1527877184039};\\\", \\\"{x:1429,y:351,t:1527877184046};\\\", \\\"{x:1423,y:360,t:1527877184058};\\\", \\\"{x:1413,y:380,t:1527877184075};\\\", \\\"{x:1404,y:398,t:1527877184092};\\\", \\\"{x:1396,y:418,t:1527877184109};\\\", \\\"{x:1386,y:442,t:1527877184125};\\\", \\\"{x:1371,y:490,t:1527877184142};\\\", \\\"{x:1359,y:543,t:1527877184158};\\\", \\\"{x:1357,y:565,t:1527877184175};\\\", \\\"{x:1355,y:585,t:1527877184191};\\\", \\\"{x:1351,y:605,t:1527877184208};\\\", \\\"{x:1348,y:620,t:1527877184226};\\\", \\\"{x:1346,y:625,t:1527877184241};\\\", \\\"{x:1346,y:631,t:1527877184258};\\\", \\\"{x:1344,y:638,t:1527877184275};\\\", \\\"{x:1342,y:653,t:1527877184291};\\\", \\\"{x:1338,y:670,t:1527877184309};\\\", \\\"{x:1336,y:683,t:1527877184326};\\\", \\\"{x:1334,y:687,t:1527877184342};\\\", \\\"{x:1333,y:691,t:1527877184358};\\\", \\\"{x:1331,y:694,t:1527877184376};\\\", \\\"{x:1329,y:697,t:1527877184391};\\\", \\\"{x:1326,y:701,t:1527877184408};\\\", \\\"{x:1323,y:703,t:1527877184425};\\\", \\\"{x:1318,y:707,t:1527877184443};\\\", \\\"{x:1313,y:710,t:1527877184459};\\\", \\\"{x:1307,y:715,t:1527877184476};\\\", \\\"{x:1303,y:719,t:1527877184492};\\\", \\\"{x:1296,y:725,t:1527877184509};\\\", \\\"{x:1289,y:731,t:1527877184526};\\\", \\\"{x:1276,y:745,t:1527877184543};\\\", \\\"{x:1266,y:756,t:1527877184559};\\\", \\\"{x:1255,y:768,t:1527877184576};\\\", \\\"{x:1245,y:780,t:1527877184593};\\\", \\\"{x:1233,y:795,t:1527877184608};\\\", \\\"{x:1222,y:809,t:1527877184625};\\\", \\\"{x:1218,y:816,t:1527877184642};\\\", \\\"{x:1217,y:820,t:1527877184658};\\\", \\\"{x:1215,y:822,t:1527877184675};\\\", \\\"{x:1214,y:825,t:1527877184692};\\\", \\\"{x:1210,y:832,t:1527877184708};\\\", \\\"{x:1201,y:844,t:1527877184726};\\\", \\\"{x:1194,y:860,t:1527877184742};\\\", \\\"{x:1189,y:869,t:1527877184758};\\\", \\\"{x:1185,y:878,t:1527877184775};\\\", \\\"{x:1180,y:887,t:1527877184792};\\\", \\\"{x:1180,y:888,t:1527877184808};\\\", \\\"{x:1176,y:893,t:1527877184825};\\\", \\\"{x:1176,y:895,t:1527877184842};\\\", \\\"{x:1174,y:897,t:1527877184858};\\\", \\\"{x:1172,y:901,t:1527877184875};\\\", \\\"{x:1171,y:906,t:1527877184892};\\\", \\\"{x:1171,y:907,t:1527877184909};\\\", \\\"{x:1170,y:907,t:1527877185335};\\\", \\\"{x:1169,y:908,t:1527877185366};\\\", \\\"{x:1167,y:908,t:1527877185382};\\\", \\\"{x:1166,y:908,t:1527877185393};\\\", \\\"{x:1165,y:908,t:1527877185414};\\\", \\\"{x:1163,y:908,t:1527877185427};\\\", \\\"{x:1160,y:908,t:1527877185442};\\\", \\\"{x:1159,y:908,t:1527877185459};\\\", \\\"{x:1158,y:908,t:1527877185476};\\\", \\\"{x:1156,y:908,t:1527877185493};\\\", \\\"{x:1156,y:907,t:1527877185550};\\\", \\\"{x:1155,y:907,t:1527877185639};\\\", \\\"{x:1154,y:907,t:1527877185662};\\\", \\\"{x:1154,y:908,t:1527877185734};\\\", \\\"{x:1154,y:909,t:1527877185742};\\\", \\\"{x:1154,y:910,t:1527877185774};\\\", \\\"{x:1154,y:911,t:1527877185783};\\\", \\\"{x:1155,y:912,t:1527877185793};\\\", \\\"{x:1157,y:914,t:1527877185809};\\\", \\\"{x:1158,y:917,t:1527877185825};\\\", \\\"{x:1161,y:919,t:1527877185842};\\\", \\\"{x:1165,y:921,t:1527877185859};\\\", \\\"{x:1171,y:921,t:1527877185876};\\\", \\\"{x:1181,y:923,t:1527877185893};\\\", \\\"{x:1189,y:923,t:1527877185909};\\\", \\\"{x:1194,y:923,t:1527877185926};\\\", \\\"{x:1197,y:923,t:1527877186071};\\\", \\\"{x:1200,y:921,t:1527877186078};\\\", \\\"{x:1206,y:913,t:1527877186094};\\\", \\\"{x:1216,y:901,t:1527877186110};\\\", \\\"{x:1236,y:877,t:1527877186127};\\\", \\\"{x:1257,y:858,t:1527877186144};\\\", \\\"{x:1275,y:842,t:1527877186160};\\\", \\\"{x:1296,y:825,t:1527877186177};\\\", \\\"{x:1316,y:808,t:1527877186193};\\\", \\\"{x:1344,y:776,t:1527877186210};\\\", \\\"{x:1365,y:743,t:1527877186227};\\\", \\\"{x:1389,y:706,t:1527877186243};\\\", \\\"{x:1405,y:677,t:1527877186261};\\\", \\\"{x:1417,y:654,t:1527877186277};\\\", \\\"{x:1431,y:631,t:1527877186293};\\\", \\\"{x:1449,y:600,t:1527877186310};\\\", \\\"{x:1456,y:583,t:1527877186326};\\\", \\\"{x:1461,y:566,t:1527877186344};\\\", \\\"{x:1465,y:549,t:1527877186360};\\\", \\\"{x:1472,y:532,t:1527877186376};\\\", \\\"{x:1478,y:514,t:1527877186394};\\\", \\\"{x:1480,y:506,t:1527877186410};\\\", \\\"{x:1480,y:500,t:1527877186426};\\\", \\\"{x:1482,y:491,t:1527877186443};\\\", \\\"{x:1483,y:482,t:1527877186460};\\\", \\\"{x:1484,y:474,t:1527877186476};\\\", \\\"{x:1485,y:458,t:1527877186493};\\\", \\\"{x:1485,y:432,t:1527877186509};\\\", \\\"{x:1486,y:418,t:1527877186526};\\\", \\\"{x:1487,y:406,t:1527877186543};\\\", \\\"{x:1488,y:390,t:1527877186560};\\\", \\\"{x:1490,y:381,t:1527877186576};\\\", \\\"{x:1491,y:374,t:1527877186593};\\\", \\\"{x:1491,y:372,t:1527877186610};\\\", \\\"{x:1492,y:367,t:1527877186626};\\\", \\\"{x:1494,y:359,t:1527877186643};\\\", \\\"{x:1496,y:353,t:1527877186660};\\\", \\\"{x:1498,y:346,t:1527877186677};\\\", \\\"{x:1500,y:341,t:1527877186693};\\\", \\\"{x:1504,y:328,t:1527877186709};\\\", \\\"{x:1506,y:322,t:1527877186727};\\\", \\\"{x:1506,y:320,t:1527877186744};\\\", \\\"{x:1506,y:319,t:1527877186761};\\\", \\\"{x:1507,y:318,t:1527877186831};\\\", \\\"{x:1507,y:317,t:1527877186854};\\\", \\\"{x:1507,y:318,t:1527877186926};\\\", \\\"{x:1504,y:363,t:1527877186943};\\\", \\\"{x:1497,y:406,t:1527877186960};\\\", \\\"{x:1490,y:449,t:1527877186977};\\\", \\\"{x:1483,y:494,t:1527877186993};\\\", \\\"{x:1481,y:537,t:1527877187010};\\\", \\\"{x:1481,y:571,t:1527877187027};\\\", \\\"{x:1481,y:601,t:1527877187044};\\\", \\\"{x:1481,y:648,t:1527877187060};\\\", \\\"{x:1481,y:695,t:1527877187077};\\\", \\\"{x:1476,y:746,t:1527877187094};\\\", \\\"{x:1476,y:764,t:1527877187110};\\\", \\\"{x:1476,y:771,t:1527877187127};\\\", \\\"{x:1476,y:776,t:1527877187144};\\\", \\\"{x:1476,y:778,t:1527877187160};\\\", \\\"{x:1478,y:783,t:1527877187177};\\\", \\\"{x:1480,y:787,t:1527877187195};\\\", \\\"{x:1481,y:791,t:1527877187210};\\\", \\\"{x:1482,y:794,t:1527877187228};\\\", \\\"{x:1483,y:795,t:1527877187244};\\\", \\\"{x:1481,y:795,t:1527877187350};\\\", \\\"{x:1475,y:793,t:1527877187361};\\\", \\\"{x:1453,y:787,t:1527877187378};\\\", \\\"{x:1408,y:775,t:1527877187395};\\\", \\\"{x:1325,y:753,t:1527877187411};\\\", \\\"{x:1230,y:721,t:1527877187427};\\\", \\\"{x:1172,y:706,t:1527877187444};\\\", \\\"{x:1170,y:706,t:1527877187460};\\\", \\\"{x:1169,y:705,t:1527877187478};\\\", \\\"{x:1168,y:703,t:1527877187503};\\\", \\\"{x:1164,y:703,t:1527877187511};\\\", \\\"{x:1148,y:696,t:1527877187528};\\\", \\\"{x:1123,y:683,t:1527877187545};\\\", \\\"{x:1108,y:677,t:1527877187562};\\\", \\\"{x:1103,y:673,t:1527877187577};\\\", \\\"{x:1102,y:673,t:1527877187595};\\\", \\\"{x:1099,y:672,t:1527877187679};\\\", \\\"{x:1090,y:668,t:1527877187694};\\\", \\\"{x:1074,y:668,t:1527877187712};\\\", \\\"{x:1059,y:668,t:1527877187728};\\\", \\\"{x:1035,y:679,t:1527877187744};\\\", \\\"{x:1004,y:690,t:1527877187761};\\\", \\\"{x:975,y:698,t:1527877187778};\\\", \\\"{x:951,y:703,t:1527877187795};\\\", \\\"{x:929,y:709,t:1527877187812};\\\", \\\"{x:908,y:714,t:1527877187828};\\\", \\\"{x:890,y:722,t:1527877187845};\\\", \\\"{x:874,y:723,t:1527877187862};\\\", \\\"{x:860,y:724,t:1527877187878};\\\", \\\"{x:835,y:724,t:1527877187894};\\\", \\\"{x:825,y:723,t:1527877187912};\\\", \\\"{x:817,y:721,t:1527877187928};\\\", \\\"{x:815,y:721,t:1527877187944};\\\", \\\"{x:811,y:719,t:1527877187962};\\\", \\\"{x:807,y:716,t:1527877187978};\\\", \\\"{x:805,y:714,t:1527877187994};\\\", \\\"{x:803,y:712,t:1527877188011};\\\", \\\"{x:799,y:704,t:1527877188028};\\\", \\\"{x:798,y:699,t:1527877188045};\\\", \\\"{x:798,y:692,t:1527877188061};\\\", \\\"{x:798,y:670,t:1527877188077};\\\", \\\"{x:796,y:657,t:1527877188094};\\\", \\\"{x:795,y:649,t:1527877188111};\\\", \\\"{x:794,y:638,t:1527877188129};\\\", \\\"{x:793,y:627,t:1527877188143};\\\", \\\"{x:789,y:621,t:1527877188161};\\\", \\\"{x:783,y:615,t:1527877188178};\\\", \\\"{x:771,y:608,t:1527877188195};\\\", \\\"{x:760,y:603,t:1527877188212};\\\", \\\"{x:747,y:597,t:1527877188228};\\\", \\\"{x:730,y:589,t:1527877188244};\\\", \\\"{x:695,y:578,t:1527877188261};\\\", \\\"{x:646,y:563,t:1527877188278};\\\", \\\"{x:594,y:550,t:1527877188294};\\\", \\\"{x:572,y:543,t:1527877188311};\\\", \\\"{x:562,y:540,t:1527877188328};\\\", \\\"{x:560,y:539,t:1527877188345};\\\", \\\"{x:558,y:538,t:1527877188390};\\\", \\\"{x:557,y:538,t:1527877188397};\\\", \\\"{x:555,y:538,t:1527877188413};\\\", \\\"{x:553,y:538,t:1527877188428};\\\", \\\"{x:544,y:538,t:1527877188445};\\\", \\\"{x:530,y:538,t:1527877188461};\\\", \\\"{x:512,y:536,t:1527877188478};\\\", \\\"{x:488,y:536,t:1527877188495};\\\", \\\"{x:465,y:536,t:1527877188512};\\\", \\\"{x:442,y:536,t:1527877188528};\\\", \\\"{x:429,y:536,t:1527877188545};\\\", \\\"{x:422,y:537,t:1527877188562};\\\", \\\"{x:415,y:538,t:1527877188578};\\\", \\\"{x:408,y:539,t:1527877188596};\\\", \\\"{x:401,y:544,t:1527877188612};\\\", \\\"{x:395,y:548,t:1527877188628};\\\", \\\"{x:385,y:554,t:1527877188646};\\\", \\\"{x:374,y:560,t:1527877188661};\\\", \\\"{x:352,y:572,t:1527877188679};\\\", \\\"{x:340,y:580,t:1527877188697};\\\", \\\"{x:335,y:581,t:1527877188712};\\\", \\\"{x:332,y:583,t:1527877188728};\\\", \\\"{x:331,y:583,t:1527877188745};\\\", \\\"{x:324,y:583,t:1527877188762};\\\", \\\"{x:319,y:583,t:1527877188778};\\\", \\\"{x:316,y:586,t:1527877188795};\\\", \\\"{x:316,y:587,t:1527877188837};\\\", \\\"{x:323,y:587,t:1527877188845};\\\", \\\"{x:340,y:587,t:1527877188862};\\\", \\\"{x:366,y:588,t:1527877188879};\\\", \\\"{x:387,y:589,t:1527877188895};\\\", \\\"{x:397,y:589,t:1527877188912};\\\", \\\"{x:402,y:591,t:1527877188928};\\\", \\\"{x:404,y:592,t:1527877188945};\\\", \\\"{x:399,y:591,t:1527877189062};\\\", \\\"{x:397,y:590,t:1527877189079};\\\", \\\"{x:396,y:590,t:1527877189149};\\\", \\\"{x:395,y:590,t:1527877189162};\\\", \\\"{x:395,y:590,t:1527877189217};\\\", \\\"{x:396,y:592,t:1527877189269};\\\", \\\"{x:402,y:593,t:1527877189279};\\\", \\\"{x:418,y:601,t:1527877189296};\\\", \\\"{x:438,y:609,t:1527877189312};\\\", \\\"{x:472,y:626,t:1527877189330};\\\", \\\"{x:502,y:640,t:1527877189346};\\\", \\\"{x:524,y:652,t:1527877189363};\\\", \\\"{x:547,y:670,t:1527877189379};\\\", \\\"{x:562,y:685,t:1527877189395};\\\", \\\"{x:575,y:697,t:1527877189412};\\\", \\\"{x:594,y:714,t:1527877189430};\\\", \\\"{x:595,y:717,t:1527877189445};\\\", \\\"{x:597,y:720,t:1527877189463};\\\", \\\"{x:597,y:721,t:1527877189480};\\\", \\\"{x:597,y:727,t:1527877189496};\\\", \\\"{x:597,y:734,t:1527877189512};\\\", \\\"{x:595,y:738,t:1527877189529};\\\", \\\"{x:592,y:741,t:1527877189547};\\\", \\\"{x:591,y:744,t:1527877189562};\\\", \\\"{x:588,y:749,t:1527877189580};\\\", \\\"{x:588,y:750,t:1527877189597};\\\", \\\"{x:587,y:751,t:1527877189622};\\\", \\\"{x:587,y:753,t:1527877189630};\\\", \\\"{x:585,y:757,t:1527877189646};\\\", \\\"{x:583,y:759,t:1527877189662};\\\", \\\"{x:581,y:759,t:1527877189679};\\\", \\\"{x:580,y:759,t:1527877189766};\\\", \\\"{x:578,y:759,t:1527877189779};\\\", \\\"{x:577,y:759,t:1527877189796};\\\", \\\"{x:575,y:759,t:1527877189870};\\\", \\\"{x:573,y:759,t:1527877189879};\\\", \\\"{x:568,y:759,t:1527877189897};\\\", \\\"{x:564,y:759,t:1527877189914};\\\", \\\"{x:563,y:759,t:1527877190045};\\\", \\\"{x:560,y:759,t:1527877190066};\\\", \\\"{x:557,y:759,t:1527877190079};\\\", \\\"{x:556,y:759,t:1527877190189};\\\", \\\"{x:555,y:758,t:1527877190318};\\\", \\\"{x:555,y:755,t:1527877190329};\\\", \\\"{x:563,y:747,t:1527877190346};\\\", \\\"{x:580,y:732,t:1527877190363};\\\", \\\"{x:620,y:715,t:1527877190379};\\\", \\\"{x:686,y:685,t:1527877190397};\\\", \\\"{x:825,y:644,t:1527877190414};\\\", \\\"{x:930,y:620,t:1527877190430};\\\", \\\"{x:1022,y:602,t:1527877190446};\\\", \\\"{x:1096,y:588,t:1527877190463};\\\", \\\"{x:1119,y:582,t:1527877190480};\\\", \\\"{x:1136,y:580,t:1527877190496};\\\", \\\"{x:1141,y:579,t:1527877190514};\\\", \\\"{x:1142,y:579,t:1527877190542};\\\", \\\"{x:1143,y:579,t:1527877190566};\\\", \\\"{x:1144,y:579,t:1527877190579};\\\", \\\"{x:1145,y:581,t:1527877190750};\\\", \\\"{x:1148,y:587,t:1527877190763};\\\", \\\"{x:1151,y:595,t:1527877190781};\\\" ] }, { \\\"rt\\\": 61719, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 650025, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look at the x axis where it says start & end time, then for starting, look at 12pm and go diagonally right which will hit the M and L.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 4984, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"US\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 656017, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 13164, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Humanities\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 670194, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 42570, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 714096, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"EPA4S\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"EPA4S\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 209, dom: 706, initialDom: 793",
  "javascriptErrors": []
}