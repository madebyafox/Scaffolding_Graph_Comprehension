var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d87e13307801fa4e6577443933f53416",
  "created": "2018-05-18T11:15:49.7383956-07:00",
  "lastActivity": "2018-05-18T11:15:57.5814445-07:00",
  "pageViews": [
    {
      "id": "05185091709cb8ee6b14190cebb3092390b74b78",
      "startTime": "2018-05-18T11:15:50.2934445-07:00",
      "endTime": "2018-05-18T11:15:57.5814445-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 7288,
      "engagementTime": 7288,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 7288,
  "engagementTime": 7288,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=08WET",
    "CONDITION=113",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "44ffc7351d639f2c1e83fb069810d8c7",
  "gdpr": false
}