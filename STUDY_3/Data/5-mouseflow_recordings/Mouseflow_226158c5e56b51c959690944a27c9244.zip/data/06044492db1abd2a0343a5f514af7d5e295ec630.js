var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06044492db1abd2a0343a5f514af7d5e295ec630"] = {
  "startTime": "2018-06-04T20:27:44.567321Z",
  "websitePageUrl": "/16",
  "visitTime": 142695,
  "engagementTime": 124729,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "226158c5e56b51c959690944a27c9244",
    "created": "2018-06-04T20:27:44.5470011+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=Z5GWP",
      "CONDITION=211"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "2e64ce96d624260f10c429a36fdbbb94",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/226158c5e56b51c959690944a27c9244/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 100,
      "e": 100,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 720,
      "e": 720,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 516,
      "y": 709
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 505,
      "y": 657
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 45627,
      "y": 34623,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 503,
      "y": 614
    },
    {
      "t": 4823,
      "e": 4823,
      "ty": 6,
      "x": 503,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 510,
      "y": 581
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 532,
      "y": 550
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 48887,
      "y": 22059,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 2,
      "x": 543,
      "y": 537
    },
    {
      "t": 5159,
      "e": 5159,
      "ty": 3,
      "x": 543,
      "y": 537,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5160,
      "e": 5160,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 50124,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5326,
      "e": 5326,
      "ty": 4,
      "x": 50124,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5326,
      "e": 5326,
      "ty": 5,
      "x": 543,
      "y": 537,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9898,
      "e": 9898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 9898,
      "e": 9898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "w"
    },
    {
      "t": 10066,
      "e": 10066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "w"
    },
    {
      "t": 10074,
      "e": 10074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10074,
      "e": 10074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10203,
      "e": 10203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "we"
    },
    {
      "t": 10210,
      "e": 10210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "we"
    },
    {
      "t": 10242,
      "e": 10242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10243,
      "e": 10243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10378,
      "e": 10378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "we "
    },
    {
      "t": 11203,
      "e": 11203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11306,
      "e": 11306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "we"
    },
    {
      "t": 11459,
      "e": 11459,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11506,
      "e": 11506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "w"
    },
    {
      "t": 11666,
      "e": 11666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11729,
      "e": 11729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 12939,
      "e": 12939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12939,
      "e": 12939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13002,
      "e": 13002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "l"
    },
    {
      "t": 13211,
      "e": 13211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13212,
      "e": 13212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13266,
      "e": 13266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "lo"
    },
    {
      "t": 13378,
      "e": 13378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13378,
      "e": 13378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13442,
      "e": 13442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "loo"
    },
    {
      "t": 13571,
      "e": 13571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13571,
      "e": 13571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13673,
      "e": 13673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look"
    },
    {
      "t": 13779,
      "e": 13779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13779,
      "e": 13779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13851,
      "e": 13851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13852,
      "e": 13852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13906,
      "e": 13906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 13979,
      "e": 13979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14099,
      "e": 14099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14099,
      "e": 14099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14202,
      "e": 14202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at"
    },
    {
      "t": 14202,
      "e": 14202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14210,
      "e": 14210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14210,
      "e": 14210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14346,
      "e": 14346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14362,
      "e": 14362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14363,
      "e": 14363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14435,
      "e": 14435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14522,
      "e": 14522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14523,
      "e": 14523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14610,
      "e": 14610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14930,
      "e": 14930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14931,
      "e": 14931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15075,
      "e": 15075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15138,
      "e": 15138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15139,
      "e": 15139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15289,
      "e": 15289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15875,
      "e": 15875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 15875,
      "e": 15875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16003,
      "e": 16003,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x"
    },
    {
      "t": 16026,
      "e": 16026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 16290,
      "e": 16290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 16290,
      "e": 16290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16402,
      "e": 16402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-"
    },
    {
      "t": 16475,
      "e": 16475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 16483,
      "e": 16483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16483,
      "e": 16483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16601,
      "e": 16601,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-a"
    },
    {
      "t": 16602,
      "e": 16602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16810,
      "e": 16810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 16811,
      "e": 16811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16962,
      "e": 16962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 16994,
      "e": 16994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16994,
      "e": 16994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17138,
      "e": 17138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 17146,
      "e": 17146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17146,
      "e": 17146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17274,
      "e": 17274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17274,
      "e": 17274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17281,
      "e": 17281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 17386,
      "e": 17386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17386,
      "e": 17386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17409,
      "e": 17409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 17474,
      "e": 17474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 17475,
      "e": 17475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17529,
      "e": 17529,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 17569,
      "e": 17569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17626,
      "e": 17626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17626,
      "e": 17626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17754,
      "e": 17754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17755,
      "e": 17755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17770,
      "e": 17770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 17889,
      "e": 17889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17938,
      "e": 17938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17938,
      "e": 17938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18034,
      "e": 18034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18036,
      "e": 18036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18051,
      "e": 18051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 18130,
      "e": 18130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18163,
      "e": 18163,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18163,
      "e": 18163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18298,
      "e": 18298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 18298,
      "e": 18298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18306,
      "e": 18306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| g"
    },
    {
      "t": 18387,
      "e": 18387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18531,
      "e": 18531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18532,
      "e": 18532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18626,
      "e": 18626,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 18714,
      "e": 18714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18714,
      "e": 18714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18835,
      "e": 18835,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18867,
      "e": 18867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 18867,
      "e": 18867,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18978,
      "e": 18978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 19137,
      "e": 19137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19137,
      "e": 19137,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19265,
      "e": 19265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 19378,
      "e": 19378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19378,
      "e": 19378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19498,
      "e": 19498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19523,
      "e": 19523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19523,
      "e": 19523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19658,
      "e": 19658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19698,
      "e": 19698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19698,
      "e": 19698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19803,
      "e": 19803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph an"
    },
    {
      "t": 19827,
      "e": 19827,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 19842,
      "e": 19842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 19845,
      "e": 19844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19970,
      "e": 19969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 19994,
      "e": 19993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19994,
      "e": 19993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20115,
      "e": 20114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20258,
      "e": 20257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20259,
      "e": 20258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20386,
      "e": 20385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20491,
      "e": 20490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20491,
      "e": 20490,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20602,
      "e": 20601,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and no"
    },
    {
      "t": 20658,
      "e": 20657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20673,
      "e": 20672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20674,
      "e": 20673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20803,
      "e": 20802,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and not"
    },
    {
      "t": 20810,
      "e": 20809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21498,
      "e": 21497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21571,
      "e": 21570,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and no"
    },
    {
      "t": 21731,
      "e": 21730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21786,
      "e": 21785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and n"
    },
    {
      "t": 21930,
      "e": 21929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21986,
      "e": 21985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and "
    },
    {
      "t": 22212,
      "e": 22211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 22212,
      "e": 22211,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22346,
      "e": 22345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 22394,
      "e": 22393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22394,
      "e": 22393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22515,
      "e": 22514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22604,
      "e": 22603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22604,
      "e": 22603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22722,
      "e": 22721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22835,
      "e": 22834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 22836,
      "e": 22835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22938,
      "e": 22937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 23019,
      "e": 23018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23019,
      "e": 23018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23146,
      "e": 23145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 23186,
      "e": 23185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23186,
      "e": 23185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23338,
      "e": 23337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23949,
      "e": 23948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23950,
      "e": 23949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24101,
      "e": 24100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 24117,
      "e": 24116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24118,
      "e": 24117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24246,
      "e": 24245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24389,
      "e": 24388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24390,
      "e": 24389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24525,
      "e": 24524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25749,
      "e": 25748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 25750,
      "e": 25749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25860,
      "e": 25859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 26007,
      "e": 26006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26008,
      "e": 26007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26140,
      "e": 26139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26229,
      "e": 26228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26230,
      "e": 26229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26334,
      "e": 26333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26422,
      "e": 26421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26422,
      "e": 26421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26533,
      "e": 26532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26653,
      "e": 26652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26655,
      "e": 26654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26757,
      "e": 26756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26870,
      "e": 26869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26871,
      "e": 26870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27006,
      "e": 27005,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and where it states"
    },
    {
      "t": 27037,
      "e": 27036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27053,
      "e": 27052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27054,
      "e": 27053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27206,
      "e": 27205,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and where it states "
    },
    {
      "t": 27208,
      "e": 27207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27677,
      "e": 27676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 27677,
      "e": 27676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27789,
      "e": 27788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 27917,
      "e": 27916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 27918,
      "e": 27917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28061,
      "e": 28060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 28077,
      "e": 28076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28078,
      "e": 28077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28208,
      "e": 28207,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and where it states 12 "
    },
    {
      "t": 28214,
      "e": 28213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28478,
      "e": 28477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 28934,
      "e": 28933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28934,
      "e": 28933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29052,
      "e": 29051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 29182,
      "e": 29051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 29184,
      "e": 29053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29277,
      "e": 29146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 29325,
      "e": 29194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31382,
      "e": 31251,
      "ty": 7,
      "x": 487,
      "y": 509,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31404,
      "e": 31273,
      "ty": 2,
      "x": 464,
      "y": 495
    },
    {
      "t": 31504,
      "e": 31373,
      "ty": 2,
      "x": 433,
      "y": 492
    },
    {
      "t": 31504,
      "e": 31373,
      "ty": 41,
      "x": 37759,
      "y": 6690,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 31604,
      "e": 31473,
      "ty": 2,
      "x": 428,
      "y": 500
    },
    {
      "t": 31682,
      "e": 31551,
      "ty": 6,
      "x": 404,
      "y": 524,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31704,
      "e": 31573,
      "ty": 2,
      "x": 402,
      "y": 527
    },
    {
      "t": 31753,
      "e": 31622,
      "ty": 41,
      "x": 32925,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31804,
      "e": 31673,
      "ty": 2,
      "x": 384,
      "y": 539
    },
    {
      "t": 31904,
      "e": 31773,
      "ty": 2,
      "x": 377,
      "y": 551
    },
    {
      "t": 32004,
      "e": 31873,
      "ty": 2,
      "x": 372,
      "y": 552
    },
    {
      "t": 32004,
      "e": 31873,
      "ty": 41,
      "x": 30902,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32103,
      "e": 31972,
      "ty": 2,
      "x": 370,
      "y": 549
    },
    {
      "t": 32204,
      "e": 32073,
      "ty": 2,
      "x": 370,
      "y": 547
    },
    {
      "t": 32254,
      "e": 32123,
      "ty": 41,
      "x": 30677,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32304,
      "e": 32173,
      "ty": 2,
      "x": 370,
      "y": 540
    },
    {
      "t": 32404,
      "e": 32273,
      "ty": 2,
      "x": 370,
      "y": 537
    },
    {
      "t": 32504,
      "e": 32373,
      "ty": 2,
      "x": 370,
      "y": 533
    },
    {
      "t": 32504,
      "e": 32373,
      "ty": 41,
      "x": 30677,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32754,
      "e": 32623,
      "ty": 41,
      "x": 30452,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32804,
      "e": 32673,
      "ty": 2,
      "x": 368,
      "y": 532
    },
    {
      "t": 32904,
      "e": 32773,
      "ty": 2,
      "x": 367,
      "y": 532
    },
    {
      "t": 33004,
      "e": 32873,
      "ty": 2,
      "x": 365,
      "y": 532
    },
    {
      "t": 33004,
      "e": 32873,
      "ty": 41,
      "x": 30115,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33171,
      "e": 33040,
      "ty": 3,
      "x": 365,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33254,
      "e": 33123,
      "ty": 41,
      "x": 30002,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33304,
      "e": 33173,
      "ty": 2,
      "x": 364,
      "y": 532
    },
    {
      "t": 33353,
      "e": 33222,
      "ty": 4,
      "x": 30002,
      "y": 7496,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33353,
      "e": 33222,
      "ty": 5,
      "x": 364,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33604,
      "e": 33473,
      "ty": 2,
      "x": 376,
      "y": 529
    },
    {
      "t": 33754,
      "e": 33623,
      "ty": 41,
      "x": 31351,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33989,
      "e": 33858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33990,
      "e": 33859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34084,
      "e": 33953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and twhere it states 12 PM"
    },
    {
      "t": 34230,
      "e": 34099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34230,
      "e": 34099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34357,
      "e": 34226,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34357,
      "e": 34226,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34364,
      "e": 34233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and thewhere it states 12 PM"
    },
    {
      "t": 34477,
      "e": 34346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34509,
      "e": 34378,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34510,
      "e": 34379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34613,
      "e": 34482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 34614,
      "e": 34483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34637,
      "e": 34506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dwhere it states 12 PM"
    },
    {
      "t": 34750,
      "e": 34619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34772,
      "e": 34641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34773,
      "e": 34642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34916,
      "e": 34785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dawhere it states 12 PM"
    },
    {
      "t": 35021,
      "e": 34890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 35021,
      "e": 34890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35125,
      "e": 34994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the daswhere it states 12 PM"
    },
    {
      "t": 35189,
      "e": 35058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35189,
      "e": 35058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35318,
      "e": 35187,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dashwhere it states 12 PM"
    },
    {
      "t": 35453,
      "e": 35322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35455,
      "e": 35324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35590,
      "e": 35459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash where it states 12 PM"
    },
    {
      "t": 35661,
      "e": 35530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35662,
      "e": 35531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35741,
      "e": 35610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash dwhere it states 12 PM"
    },
    {
      "t": 35877,
      "e": 35746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35877,
      "e": 35746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35966,
      "e": 35747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash dewhere it states 12 PM"
    },
    {
      "t": 35973,
      "e": 35754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35973,
      "e": 35754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36125,
      "e": 35906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denwhere it states 12 PM"
    },
    {
      "t": 36126,
      "e": 35907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 36127,
      "e": 35908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36253,
      "e": 36034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36254,
      "e": 36035,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36261,
      "e": 36042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denotwhere it states 12 PM"
    },
    {
      "t": 36364,
      "e": 36145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36405,
      "e": 36186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36405,
      "e": 36186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36581,
      "e": 36362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denotiwhere it states 12 PM"
    },
    {
      "t": 36589,
      "e": 36370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36590,
      "e": 36371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36725,
      "e": 36506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denotinwhere it states 12 PM"
    },
    {
      "t": 36830,
      "e": 36611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 36830,
      "e": 36611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36941,
      "e": 36722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denotingwhere it states 12 PM"
    },
    {
      "t": 37126,
      "e": 36907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37126,
      "e": 36907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37261,
      "e": 37042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denoting where it states 12 PM"
    },
    {
      "t": 39430,
      "e": 39211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39477,
      "e": 39258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denotingwhere it states 12 PM"
    },
    {
      "t": 39606,
      "e": 39387,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denotingwhere it states 12 PM"
    },
    {
      "t": 39622,
      "e": 39403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39661,
      "e": 39442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denotinwhere it states 12 PM"
    },
    {
      "t": 39789,
      "e": 39570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39837,
      "e": 39618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denotiwhere it states 12 PM"
    },
    {
      "t": 39965,
      "e": 39746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40037,
      "e": 39746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denotwhere it states 12 PM"
    },
    {
      "t": 40132,
      "e": 39841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40220,
      "e": 39929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denowhere it states 12 PM"
    },
    {
      "t": 40333,
      "e": 40042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40406,
      "e": 40115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash denwhere it states 12 PM"
    },
    {
      "t": 40526,
      "e": 40235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40596,
      "e": 40305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash dewhere it states 12 PM"
    },
    {
      "t": 40709,
      "e": 40418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40797,
      "e": 40506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash dwhere it states 12 PM"
    },
    {
      "t": 41373,
      "e": 41082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41485,
      "e": 41194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash where it states 12 PM"
    },
    {
      "t": 41607,
      "e": 41316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 41607,
      "e": 41316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41716,
      "e": 41425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash cwhere it states 12 PM"
    },
    {
      "t": 41821,
      "e": 41530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 41821,
      "e": 41530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41973,
      "e": 41682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash cowhere it states 12 PM"
    },
    {
      "t": 41981,
      "e": 41690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 41981,
      "e": 41690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42085,
      "e": 41794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corwhere it states 12 PM"
    },
    {
      "t": 42229,
      "e": 41938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 42230,
      "e": 41939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42300,
      "e": 42009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corrwhere it states 12 PM"
    },
    {
      "t": 42406,
      "e": 42115,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corrwhere it states 12 PM"
    },
    {
      "t": 42614,
      "e": 42323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 42614,
      "e": 42323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42701,
      "e": 42324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash correwhere it states 12 PM"
    },
    {
      "t": 42805,
      "e": 42428,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash correwhere it states 12 PM"
    },
    {
      "t": 42813,
      "e": 42436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 42814,
      "e": 42437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42926,
      "e": 42549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash correswhere it states 12 PM"
    },
    {
      "t": 42949,
      "e": 42572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 42950,
      "e": 42573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43061,
      "e": 42684,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash correspwhere it states 12 PM"
    },
    {
      "t": 43166,
      "e": 42789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43167,
      "e": 42790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43317,
      "e": 42940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash correspowhere it states 12 PM"
    },
    {
      "t": 43317,
      "e": 42940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43317,
      "e": 42940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43453,
      "e": 43076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corresponwhere it states 12 PM"
    },
    {
      "t": 43486,
      "e": 43109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 43486,
      "e": 43109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43605,
      "e": 43228,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash correspondwhere it states 12 PM"
    },
    {
      "t": 43612,
      "e": 43235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43613,
      "e": 43236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43628,
      "e": 43251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash correspondiwhere it states 12 PM"
    },
    {
      "t": 43757,
      "e": 43380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43758,
      "e": 43381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43796,
      "e": 43419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash correspondinwhere it states 12 PM"
    },
    {
      "t": 43885,
      "e": 43508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43965,
      "e": 43588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 43967,
      "e": 43590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44100,
      "e": 43723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash correspondingwhere it states 12 PM"
    },
    {
      "t": 44133,
      "e": 43756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44134,
      "e": 43757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44246,
      "e": 43758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corresponding where it states 12 PM"
    },
    {
      "t": 44269,
      "e": 43781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44270,
      "e": 43782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44364,
      "e": 43876,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corresponding twhere it states 12 PM"
    },
    {
      "t": 44388,
      "e": 43900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44389,
      "e": 43901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44461,
      "e": 43973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44462,
      "e": 43974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44485,
      "e": 43997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corresponding to where it states 12 PM"
    },
    {
      "t": 44581,
      "e": 44093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44630,
      "e": 44142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44631,
      "e": 44143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44692,
      "e": 44204,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corresponding to twhere it states 12 PM"
    },
    {
      "t": 44796,
      "e": 44308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44797,
      "e": 44309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44909,
      "e": 44421,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corresponding to thwhere it states 12 PM"
    },
    {
      "t": 44942,
      "e": 44454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44943,
      "e": 44455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45028,
      "e": 44540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corresponding to thewhere it states 12 PM"
    },
    {
      "t": 45077,
      "e": 44589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45077,
      "e": 44589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45181,
      "e": 44693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corresponding to the where it states 12 PM"
    },
    {
      "t": 46749,
      "e": 46261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 47249,
      "e": 46761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 47261,
      "e": 46773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "40"
    },
    {
      "t": 47525,
      "e": 47037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47662,
      "e": 47174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48261,
      "e": 47773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 48357,
      "e": 47869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look at the x-axis of the graph and the dash corresponding to the "
    },
    {
      "t": 49261,
      "e": 48773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "97"
    },
    {
      "t": 49263,
      "e": 48775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49389,
      "e": 48901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 49494,
      "e": 49006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "98"
    },
    {
      "t": 49494,
      "e": 49006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49605,
      "e": 49117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 49997,
      "e": 49509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49999,
      "e": 49511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50004,
      "e": 49516,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50093,
      "e": 49605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50445,
      "e": 49957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 50654,
      "e": 50166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 50654,
      "e": 50166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50789,
      "e": 50301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 50965,
      "e": 50477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 50966,
      "e": 50478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51092,
      "e": 50604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 51109,
      "e": 50621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51381,
      "e": 50893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51382,
      "e": 50894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51564,
      "e": 51076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57403,
      "e": 56076,
      "ty": 2,
      "x": 352,
      "y": 540
    },
    {
      "t": 57504,
      "e": 56177,
      "ty": 2,
      "x": 284,
      "y": 557
    },
    {
      "t": 57504,
      "e": 56177,
      "ty": 41,
      "x": 21010,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57603,
      "e": 56276,
      "ty": 2,
      "x": 283,
      "y": 557
    },
    {
      "t": 57755,
      "e": 56428,
      "ty": 41,
      "x": 14377,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57803,
      "e": 56476,
      "ty": 2,
      "x": 172,
      "y": 556
    },
    {
      "t": 57903,
      "e": 56576,
      "ty": 2,
      "x": 152,
      "y": 542
    },
    {
      "t": 58003,
      "e": 56676,
      "ty": 2,
      "x": 149,
      "y": 531
    },
    {
      "t": 58003,
      "e": 56676,
      "ty": 41,
      "x": 5834,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58103,
      "e": 56776,
      "ty": 2,
      "x": 156,
      "y": 525
    },
    {
      "t": 58204,
      "e": 56877,
      "ty": 2,
      "x": 159,
      "y": 525
    },
    {
      "t": 58253,
      "e": 56926,
      "ty": 41,
      "x": 7071,
      "y": 1833,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58303,
      "e": 56976,
      "ty": 2,
      "x": 166,
      "y": 525
    },
    {
      "t": 58404,
      "e": 57077,
      "ty": 2,
      "x": 195,
      "y": 524
    },
    {
      "t": 58453,
      "e": 57126,
      "ty": 7,
      "x": 200,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58504,
      "e": 57177,
      "ty": 2,
      "x": 211,
      "y": 517
    },
    {
      "t": 58504,
      "e": 57177,
      "ty": 41,
      "x": 12804,
      "y": 52113,
      "ta": "#.strategy > p"
    },
    {
      "t": 58604,
      "e": 57277,
      "ty": 2,
      "x": 221,
      "y": 517
    },
    {
      "t": 58703,
      "e": 57376,
      "ty": 2,
      "x": 233,
      "y": 518
    },
    {
      "t": 58753,
      "e": 57426,
      "ty": 41,
      "x": 15502,
      "y": 54454,
      "ta": "#.strategy > p"
    },
    {
      "t": 58804,
      "e": 57477,
      "ty": 2,
      "x": 239,
      "y": 519
    },
    {
      "t": 58821,
      "e": 57494,
      "ty": 6,
      "x": 241,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58903,
      "e": 57576,
      "ty": 2,
      "x": 257,
      "y": 527
    },
    {
      "t": 59003,
      "e": 57676,
      "ty": 2,
      "x": 282,
      "y": 535
    },
    {
      "t": 59004,
      "e": 57677,
      "ty": 41,
      "x": 20785,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59303,
      "e": 57976,
      "ty": 2,
      "x": 277,
      "y": 538
    },
    {
      "t": 59403,
      "e": 58076,
      "ty": 2,
      "x": 228,
      "y": 542
    },
    {
      "t": 59503,
      "e": 58176,
      "ty": 2,
      "x": 171,
      "y": 541
    },
    {
      "t": 59503,
      "e": 58176,
      "ty": 41,
      "x": 8307,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59603,
      "e": 58276,
      "ty": 2,
      "x": 139,
      "y": 535
    },
    {
      "t": 59754,
      "e": 58427,
      "ty": 41,
      "x": 4710,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59903,
      "e": 58576,
      "ty": 2,
      "x": 139,
      "y": 533
    },
    {
      "t": 60003,
      "e": 58676,
      "ty": 41,
      "x": 4710,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60004,
      "e": 58677,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60253,
      "e": 58926,
      "ty": 41,
      "x": 4823,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60303,
      "e": 58976,
      "ty": 2,
      "x": 138,
      "y": 534
    },
    {
      "t": 60403,
      "e": 59076,
      "ty": 2,
      "x": 134,
      "y": 536
    },
    {
      "t": 60504,
      "e": 59177,
      "ty": 41,
      "x": 4148,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60553,
      "e": 59226,
      "ty": 3,
      "x": 134,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60721,
      "e": 59394,
      "ty": 4,
      "x": 4148,
      "y": 10732,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60721,
      "e": 59394,
      "ty": 5,
      "x": 134,
      "y": 536,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60904,
      "e": 59577,
      "ty": 2,
      "x": 177,
      "y": 529
    },
    {
      "t": 61003,
      "e": 59676,
      "ty": 2,
      "x": 187,
      "y": 526
    },
    {
      "t": 61004,
      "e": 59677,
      "ty": 41,
      "x": 10106,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61806,
      "e": 60479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 61806,
      "e": 60479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61916,
      "e": 60589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look fat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 62741,
      "e": 61414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 62742,
      "e": 61415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62876,
      "e": 61549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look foat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 62916,
      "e": 61589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 62917,
      "e": 61590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63013,
      "e": 61686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look forat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 63030,
      "e": 61703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63030,
      "e": 61703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63157,
      "e": 61830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for at the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 63237,
      "e": 61910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 63238,
      "e": 61911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63357,
      "e": 62030,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 63373,
      "e": 62046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 63373,
      "e": 62046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63517,
      "e": 62190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for doat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 63533,
      "e": 62206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 63534,
      "e": 62207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63629,
      "e": 62302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dotat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 63782,
      "e": 62455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 63782,
      "e": 62455,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63901,
      "e": 62574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63901,
      "e": 62574,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63908,
      "e": 62581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots at the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 64021,
      "e": 62694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64045,
      "e": 62718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 64046,
      "e": 62719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64125,
      "e": 62798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 64172,
      "e": 62845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 64173,
      "e": 62846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64246,
      "e": 62847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots alat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 64397,
      "e": 62998,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 64398,
      "e": 62999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64524,
      "e": 63125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aliat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 64540,
      "e": 63141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 64541,
      "e": 63142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64637,
      "e": 63238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 65814,
      "e": 64415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 65814,
      "e": 64415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65941,
      "e": 64542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 65943,
      "e": 64544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65949,
      "e": 64550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligneat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 66036,
      "e": 64637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66173,
      "e": 64774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 66174,
      "e": 64775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66254,
      "e": 64855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots alignedat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 66269,
      "e": 64870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66270,
      "e": 64871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66405,
      "e": 65006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned at the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 66413,
      "e": 65014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned at the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 66468,
      "e": 65069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 66470,
      "e": 65071,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66589,
      "e": 65190,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 66590,
      "e": 65191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66596,
      "e": 65197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned wiat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 66700,
      "e": 65301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66772,
      "e": 65373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66773,
      "e": 65374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66885,
      "e": 65486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned witat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 66933,
      "e": 65534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 66934,
      "e": 65535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67022,
      "e": 65537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned withat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 67124,
      "e": 65639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67124,
      "e": 65639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67245,
      "e": 65760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with at the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 67414,
      "e": 65929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 67414,
      "e": 65929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67493,
      "e": 66008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with tat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 67606,
      "e": 66121,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with tat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 67645,
      "e": 66160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 67646,
      "e": 66161,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67740,
      "e": 66255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with that the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 67828,
      "e": 66343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 67829,
      "e": 66344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67925,
      "e": 66440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with theat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 68012,
      "e": 66527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68013,
      "e": 66528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68133,
      "e": 66648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the at the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 70525,
      "e": 69040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 70525,
      "e": 69040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70669,
      "e": 69184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 70774,
      "e": 69289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 70775,
      "e": 69290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70901,
      "e": 69290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the daat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 71028,
      "e": 69417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 71028,
      "e": 69417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71157,
      "e": 69546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dasat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 71208,
      "e": 69597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 71208,
      "e": 69597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71324,
      "e": 69713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dashat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 71445,
      "e": 69834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71446,
      "e": 69835,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71580,
      "e": 69969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash at the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 71581,
      "e": 69970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 71581,
      "e": 69970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71733,
      "e": 70122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash oat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 71749,
      "e": 70138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 71750,
      "e": 70139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71828,
      "e": 70217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash onat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 71941,
      "e": 70330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71941,
      "e": 70330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72044,
      "e": 70433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on at the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 72060,
      "e": 70449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 72061,
      "e": 70450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72173,
      "e": 70562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on tat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 72198,
      "e": 70587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 72199,
      "e": 70588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72293,
      "e": 70589,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on that the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 72317,
      "e": 70613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 72317,
      "e": 70613,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72420,
      "e": 70716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on theat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 72437,
      "e": 70733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72437,
      "e": 70733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72557,
      "e": 70853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the at the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 73037,
      "e": 71333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 73038,
      "e": 71334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73205,
      "e": 71501,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the xat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 73261,
      "e": 71557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the xat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 73453,
      "e": 71749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 73454,
      "e": 71750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73605,
      "e": 71901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the x-at the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 73606,
      "e": 71902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73606,
      "e": 71902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73748,
      "e": 72044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the x-aat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 73989,
      "e": 72285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 73990,
      "e": 72286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74101,
      "e": 72287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the x-axat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 74157,
      "e": 72343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 74157,
      "e": 72343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74293,
      "e": 72479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the x-axiat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 74309,
      "e": 72495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 74309,
      "e": 72495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74452,
      "e": 72638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the x-axisat the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 76429,
      "e": 74615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76430,
      "e": 74616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76556,
      "e": 74742,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the x-axis at the x-axis of the graph and the dash corresponding to the 12 PM "
    },
    {
      "t": 76604,
      "e": 74790,
      "ty": 2,
      "x": 173,
      "y": 539
    },
    {
      "t": 76704,
      "e": 74890,
      "ty": 2,
      "x": 150,
      "y": 550
    },
    {
      "t": 76754,
      "e": 74940,
      "ty": 41,
      "x": 5160,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76804,
      "e": 74990,
      "ty": 2,
      "x": 140,
      "y": 557
    },
    {
      "t": 76886,
      "e": 75072,
      "ty": 7,
      "x": 237,
      "y": 515,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76903,
      "e": 75089,
      "ty": 2,
      "x": 259,
      "y": 504
    },
    {
      "t": 77004,
      "e": 75190,
      "ty": 2,
      "x": 334,
      "y": 481
    },
    {
      "t": 77005,
      "e": 75191,
      "ty": 41,
      "x": 26630,
      "y": 1700,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 77104,
      "e": 75290,
      "ty": 2,
      "x": 400,
      "y": 498
    },
    {
      "t": 77204,
      "e": 75390,
      "ty": 2,
      "x": 412,
      "y": 509
    },
    {
      "t": 77251,
      "e": 75437,
      "ty": 6,
      "x": 423,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77254,
      "e": 75440,
      "ty": 41,
      "x": 36635,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77303,
      "e": 75489,
      "ty": 2,
      "x": 431,
      "y": 526
    },
    {
      "t": 77403,
      "e": 75589,
      "ty": 2,
      "x": 434,
      "y": 526
    },
    {
      "t": 77503,
      "e": 75689,
      "ty": 2,
      "x": 439,
      "y": 526
    },
    {
      "t": 77503,
      "e": 75689,
      "ty": 41,
      "x": 38433,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77603,
      "e": 75789,
      "ty": 2,
      "x": 443,
      "y": 528
    },
    {
      "t": 77703,
      "e": 75889,
      "ty": 2,
      "x": 445,
      "y": 528
    },
    {
      "t": 77754,
      "e": 75940,
      "ty": 41,
      "x": 39220,
      "y": 4260,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77803,
      "e": 75989,
      "ty": 2,
      "x": 447,
      "y": 529
    },
    {
      "t": 77903,
      "e": 76089,
      "ty": 2,
      "x": 454,
      "y": 531
    },
    {
      "t": 78004,
      "e": 76190,
      "ty": 2,
      "x": 455,
      "y": 533
    },
    {
      "t": 78004,
      "e": 76190,
      "ty": 41,
      "x": 40232,
      "y": 8305,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78103,
      "e": 76289,
      "ty": 2,
      "x": 456,
      "y": 534
    },
    {
      "t": 78204,
      "e": 76390,
      "ty": 2,
      "x": 461,
      "y": 537
    },
    {
      "t": 78254,
      "e": 76440,
      "ty": 41,
      "x": 41019,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78303,
      "e": 76489,
      "ty": 2,
      "x": 465,
      "y": 537
    },
    {
      "t": 78403,
      "e": 76589,
      "ty": 2,
      "x": 468,
      "y": 537
    },
    {
      "t": 78466,
      "e": 76652,
      "ty": 3,
      "x": 471,
      "y": 537,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78503,
      "e": 76689,
      "ty": 2,
      "x": 471,
      "y": 537
    },
    {
      "t": 78503,
      "e": 76689,
      "ty": 41,
      "x": 42030,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78703,
      "e": 76889,
      "ty": 2,
      "x": 411,
      "y": 561
    },
    {
      "t": 78753,
      "e": 76939,
      "ty": 41,
      "x": 30452,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78803,
      "e": 76989,
      "ty": 2,
      "x": 338,
      "y": 580
    },
    {
      "t": 78903,
      "e": 77089,
      "ty": 2,
      "x": 269,
      "y": 573
    },
    {
      "t": 79003,
      "e": 77189,
      "ty": 2,
      "x": 244,
      "y": 567
    },
    {
      "t": 79003,
      "e": 77189,
      "ty": 41,
      "x": 16513,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79103,
      "e": 77289,
      "ty": 2,
      "x": 236,
      "y": 564
    },
    {
      "t": 79203,
      "e": 77389,
      "ty": 2,
      "x": 218,
      "y": 561
    },
    {
      "t": 79253,
      "e": 77439,
      "ty": 41,
      "x": 12242,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79303,
      "e": 77489,
      "ty": 2,
      "x": 192,
      "y": 559
    },
    {
      "t": 79404,
      "e": 77590,
      "ty": 2,
      "x": 177,
      "y": 559
    },
    {
      "t": 79503,
      "e": 77689,
      "ty": 2,
      "x": 163,
      "y": 559
    },
    {
      "t": 79503,
      "e": 77689,
      "ty": 41,
      "x": 7408,
      "y": 29341,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79704,
      "e": 77890,
      "ty": 2,
      "x": 165,
      "y": 554
    },
    {
      "t": 79754,
      "e": 77940,
      "ty": 41,
      "x": 7970,
      "y": 24487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79803,
      "e": 77989,
      "ty": 2,
      "x": 170,
      "y": 553
    },
    {
      "t": 79903,
      "e": 78089,
      "ty": 2,
      "x": 174,
      "y": 551
    },
    {
      "t": 80004,
      "e": 78190,
      "ty": 41,
      "x": 8645,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80004,
      "e": 78190,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80204,
      "e": 78390,
      "ty": 2,
      "x": 177,
      "y": 550
    },
    {
      "t": 80253,
      "e": 78439,
      "ty": 41,
      "x": 9431,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80303,
      "e": 78489,
      "ty": 2,
      "x": 183,
      "y": 548
    },
    {
      "t": 80403,
      "e": 78589,
      "ty": 2,
      "x": 190,
      "y": 545
    },
    {
      "t": 80504,
      "e": 78690,
      "ty": 2,
      "x": 192,
      "y": 544
    },
    {
      "t": 80504,
      "e": 78690,
      "ty": 41,
      "x": 10668,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80778,
      "e": 78964,
      "ty": 4,
      "x": 10668,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80778,
      "e": 78964,
      "ty": 5,
      "x": 192,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81366,
      "e": 79552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 81453,
      "e": 79639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the x-axis acorresponding to the 12 PM "
    },
    {
      "t": 83013,
      "e": 81199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 83076,
      "e": 81262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the x-axis corresponding to the 12 PM "
    },
    {
      "t": 83205,
      "e": 81391,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the x-axis corresponding to the 12 PM "
    },
    {
      "t": 84007,
      "e": 82193,
      "ty": 2,
      "x": 204,
      "y": 598
    },
    {
      "t": 84007,
      "e": 82193,
      "ty": 41,
      "x": 12017,
      "y": 60895,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84107,
      "e": 82293,
      "ty": 2,
      "x": 212,
      "y": 603
    },
    {
      "t": 84118,
      "e": 82304,
      "ty": 7,
      "x": 212,
      "y": 606,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84207,
      "e": 82393,
      "ty": 2,
      "x": 206,
      "y": 632
    },
    {
      "t": 84258,
      "e": 82444,
      "ty": 41,
      "x": 19661,
      "y": 36506,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 84307,
      "e": 82493,
      "ty": 2,
      "x": 331,
      "y": 675
    },
    {
      "t": 84312,
      "e": 82498,
      "ty": 6,
      "x": 338,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 84408,
      "e": 82594,
      "ty": 2,
      "x": 341,
      "y": 674
    },
    {
      "t": 84507,
      "e": 82693,
      "ty": 2,
      "x": 361,
      "y": 665
    },
    {
      "t": 84508,
      "e": 82694,
      "ty": 41,
      "x": 12236,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 84607,
      "e": 82793,
      "ty": 2,
      "x": 368,
      "y": 662
    },
    {
      "t": 84757,
      "e": 82943,
      "ty": 41,
      "x": 16059,
      "y": 14004,
      "ta": "#strategyButton"
    },
    {
      "t": 85005,
      "e": 83191,
      "ty": 3,
      "x": 368,
      "y": 662,
      "ta": "#strategyButton"
    },
    {
      "t": 85007,
      "e": 83193,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "look for dots aligned with the dash on the x-axis corresponding to the 12 PM "
    },
    {
      "t": 85008,
      "e": 83194,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85008,
      "e": 83194,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 85229,
      "e": 83415,
      "ty": 4,
      "x": 16059,
      "y": 14004,
      "ta": "#strategyButton"
    },
    {
      "t": 85247,
      "e": 83433,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 85249,
      "e": 83435,
      "ty": 5,
      "x": 368,
      "y": 662,
      "ta": "#strategyButton"
    },
    {
      "t": 85254,
      "e": 83440,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 86256,
      "e": 84442,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 86307,
      "e": 84493,
      "ty": 2,
      "x": 368,
      "y": 659
    },
    {
      "t": 86407,
      "e": 84593,
      "ty": 2,
      "x": 366,
      "y": 646
    },
    {
      "t": 86507,
      "e": 84693,
      "ty": 2,
      "x": 365,
      "y": 637
    },
    {
      "t": 86508,
      "e": 84694,
      "ty": 41,
      "x": 12294,
      "y": 34844,
      "ta": "html > body"
    },
    {
      "t": 86608,
      "e": 84794,
      "ty": 2,
      "x": 386,
      "y": 616
    },
    {
      "t": 86707,
      "e": 84893,
      "ty": 2,
      "x": 530,
      "y": 547
    },
    {
      "t": 86762,
      "e": 84948,
      "ty": 41,
      "x": 21144,
      "y": 29249,
      "ta": "html > body"
    },
    {
      "t": 86807,
      "e": 84993,
      "ty": 2,
      "x": 675,
      "y": 539
    },
    {
      "t": 86907,
      "e": 85093,
      "ty": 2,
      "x": 720,
      "y": 545
    },
    {
      "t": 87007,
      "e": 85193,
      "ty": 2,
      "x": 804,
      "y": 586
    },
    {
      "t": 87007,
      "e": 85193,
      "ty": 41,
      "x": 27412,
      "y": 32019,
      "ta": "html > body"
    },
    {
      "t": 87107,
      "e": 85293,
      "ty": 2,
      "x": 874,
      "y": 618
    },
    {
      "t": 87207,
      "e": 85393,
      "ty": 2,
      "x": 876,
      "y": 606
    },
    {
      "t": 87258,
      "e": 85444,
      "ty": 41,
      "x": 14707,
      "y": 10570,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 87308,
      "e": 85494,
      "ty": 2,
      "x": 877,
      "y": 596
    },
    {
      "t": 87408,
      "e": 85594,
      "ty": 2,
      "x": 878,
      "y": 594
    },
    {
      "t": 87482,
      "e": 85668,
      "ty": 6,
      "x": 873,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87507,
      "e": 85693,
      "ty": 2,
      "x": 872,
      "y": 569
    },
    {
      "t": 87508,
      "e": 85694,
      "ty": 41,
      "x": 13842,
      "y": 46810,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87607,
      "e": 85793,
      "ty": 2,
      "x": 868,
      "y": 561
    },
    {
      "t": 87734,
      "e": 85920,
      "ty": 3,
      "x": 868,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87735,
      "e": 85921,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87758,
      "e": 85944,
      "ty": 41,
      "x": 12977,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87877,
      "e": 86063,
      "ty": 4,
      "x": 12977,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87877,
      "e": 86063,
      "ty": 5,
      "x": 868,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88007,
      "e": 86193,
      "ty": 2,
      "x": 864,
      "y": 561
    },
    {
      "t": 88008,
      "e": 86194,
      "ty": 41,
      "x": 12112,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88873,
      "e": 87059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 88874,
      "e": 87060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88945,
      "e": 87131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 89112,
      "e": 87298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 89113,
      "e": 87299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89193,
      "e": 87379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 89608,
      "e": 87794,
      "ty": 2,
      "x": 940,
      "y": 558
    },
    {
      "t": 89708,
      "e": 87894,
      "ty": 2,
      "x": 935,
      "y": 559
    },
    {
      "t": 89757,
      "e": 87943,
      "ty": 41,
      "x": 27468,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89808,
      "e": 87994,
      "ty": 2,
      "x": 930,
      "y": 570
    },
    {
      "t": 89816,
      "e": 88002,
      "ty": 7,
      "x": 925,
      "y": 581,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 89907,
      "e": 88093,
      "ty": 2,
      "x": 910,
      "y": 642
    },
    {
      "t": 89916,
      "e": 88102,
      "ty": 6,
      "x": 910,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90007,
      "e": 88193,
      "ty": 2,
      "x": 907,
      "y": 658
    },
    {
      "t": 90007,
      "e": 88193,
      "ty": 41,
      "x": 21412,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90007,
      "e": 88193,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90107,
      "e": 88293,
      "ty": 2,
      "x": 906,
      "y": 665
    },
    {
      "t": 90204,
      "e": 88390,
      "ty": 3,
      "x": 906,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90205,
      "e": 88391,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 90205,
      "e": 88391,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 90205,
      "e": 88391,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90257,
      "e": 88443,
      "ty": 41,
      "x": 21196,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90364,
      "e": 88550,
      "ty": 4,
      "x": 21196,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90364,
      "e": 88550,
      "ty": 5,
      "x": 906,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91385,
      "e": 89571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 91473,
      "e": 89659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 91473,
      "e": 89659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91560,
      "e": 89746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 91584,
      "e": 89770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 91656,
      "e": 89842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 91657,
      "e": 89843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91776,
      "e": 89962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 91777,
      "e": 89963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91808,
      "e": 89994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 91928,
      "e": 90114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 91936,
      "e": 90122,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 91937,
      "e": 90123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92065,
      "e": 90251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 92208,
      "e": 90394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 92208,
      "e": 90394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92312,
      "e": 90498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 92441,
      "e": 90627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 92442,
      "e": 90628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92545,
      "e": 90731,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 92560,
      "e": 90746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 92561,
      "e": 90747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92680,
      "e": 90866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 93184,
      "e": 91370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 93367,
      "e": 91553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 93368,
      "e": 91554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93408,
      "e": 91594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 93465,
      "e": 91651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 93696,
      "e": 91882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 93696,
      "e": 91882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93808,
      "e": 91994,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United St"
    },
    {
      "t": 93808,
      "e": 91994,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 93856,
      "e": 92042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 93856,
      "e": 92042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 93976,
      "e": 92162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 93992,
      "e": 92178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 93993,
      "e": 92179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94072,
      "e": 92258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 94184,
      "e": 92370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 94185,
      "e": 92371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94264,
      "e": 92450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 94337,
      "e": 92523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 94337,
      "e": 92523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94448,
      "e": 92634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 94457,
      "e": 92643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 94458,
      "e": 92644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94552,
      "e": 92738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 94553,
      "e": 92739,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94576,
      "e": 92762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| o"
    },
    {
      "t": 94648,
      "e": 92834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "70"
    },
    {
      "t": 94648,
      "e": 92834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94697,
      "e": 92883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||f"
    },
    {
      "t": 94761,
      "e": 92947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 94777,
      "e": 92963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 94777,
      "e": 92963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 94897,
      "e": 93083,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 94920,
      "e": 93106,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 95015,
      "e": 93201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 95015,
      "e": 93201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95185,
      "e": 93371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||A"
    },
    {
      "t": 95208,
      "e": 93394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 95217,
      "e": 93403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 95217,
      "e": 93403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95321,
      "e": 93507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||m"
    },
    {
      "t": 95352,
      "e": 93538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 95353,
      "e": 93539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95433,
      "e": 93619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 95504,
      "e": 93690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 95505,
      "e": 93691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95608,
      "e": 93794,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of Amer"
    },
    {
      "t": 95632,
      "e": 93818,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||r"
    },
    {
      "t": 95656,
      "e": 93842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 95656,
      "e": 93842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95785,
      "e": 93971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 95803,
      "e": 93989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 95803,
      "e": 93989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 95921,
      "e": 94107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||c"
    },
    {
      "t": 95953,
      "e": 94139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 95954,
      "e": 94140,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 96113,
      "e": 94299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 96607,
      "e": 94793,
      "ty": 2,
      "x": 907,
      "y": 665
    },
    {
      "t": 96655,
      "e": 94841,
      "ty": 7,
      "x": 920,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 96707,
      "e": 94893,
      "ty": 2,
      "x": 924,
      "y": 675
    },
    {
      "t": 96717,
      "e": 94903,
      "ty": 6,
      "x": 925,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 96757,
      "e": 94943,
      "ty": 41,
      "x": 15501,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 96808,
      "e": 94994,
      "ty": 2,
      "x": 928,
      "y": 688
    },
    {
      "t": 96908,
      "e": 95094,
      "ty": 2,
      "x": 928,
      "y": 689
    },
    {
      "t": 96950,
      "e": 95136,
      "ty": 3,
      "x": 929,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 96950,
      "e": 95136,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States of America"
    },
    {
      "t": 96951,
      "e": 95137,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 96951,
      "e": 95137,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 97008,
      "e": 95194,
      "ty": 2,
      "x": 929,
      "y": 689
    },
    {
      "t": 97008,
      "e": 95194,
      "ty": 41,
      "x": 17048,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 97117,
      "e": 95303,
      "ty": 4,
      "x": 17048,
      "y": 25816,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 97117,
      "e": 95303,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 97118,
      "e": 95304,
      "ty": 5,
      "x": 929,
      "y": 689,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 97118,
      "e": 95304,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 98137,
      "e": 96323,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 99107,
      "e": 97293,
      "ty": 2,
      "x": 842,
      "y": 22
    },
    {
      "t": 99207,
      "e": 97393,
      "ty": 2,
      "x": 738,
      "y": 16
    },
    {
      "t": 99257,
      "e": 97443,
      "ty": 41,
      "x": 25139,
      "y": 443,
      "ta": "html > body"
    },
    {
      "t": 99307,
      "e": 97493,
      "ty": 2,
      "x": 736,
      "y": 32
    },
    {
      "t": 99407,
      "e": 97593,
      "ty": 2,
      "x": 741,
      "y": 171
    },
    {
      "t": 99507,
      "e": 97693,
      "ty": 2,
      "x": 759,
      "y": 185
    },
    {
      "t": 99507,
      "e": 97693,
      "ty": 41,
      "x": 25862,
      "y": 9805,
      "ta": "html > body"
    },
    {
      "t": 99607,
      "e": 97793,
      "ty": 2,
      "x": 856,
      "y": 217
    },
    {
      "t": 99707,
      "e": 97893,
      "ty": 2,
      "x": 864,
      "y": 224
    },
    {
      "t": 99757,
      "e": 97943,
      "ty": 41,
      "x": 24220,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 99758,
      "e": 97943,
      "ty": 6,
      "x": 836,
      "y": 243,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 99774,
      "e": 97959,
      "ty": 7,
      "x": 818,
      "y": 247,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 99807,
      "e": 97992,
      "ty": 2,
      "x": 800,
      "y": 249
    },
    {
      "t": 99907,
      "e": 98092,
      "ty": 2,
      "x": 768,
      "y": 266
    },
    {
      "t": 100007,
      "e": 98192,
      "ty": 2,
      "x": 777,
      "y": 264
    },
    {
      "t": 100007,
      "e": 98192,
      "ty": 41,
      "x": 26482,
      "y": 14181,
      "ta": "html > body"
    },
    {
      "t": 100107,
      "e": 98292,
      "ty": 2,
      "x": 815,
      "y": 257
    },
    {
      "t": 100207,
      "e": 98392,
      "ty": 2,
      "x": 819,
      "y": 255
    },
    {
      "t": 100257,
      "e": 98442,
      "ty": 41,
      "x": 27928,
      "y": 13683,
      "ta": "html > body"
    },
    {
      "t": 100307,
      "e": 98492,
      "ty": 2,
      "x": 821,
      "y": 252
    },
    {
      "t": 100405,
      "e": 98590,
      "ty": 6,
      "x": 826,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 100407,
      "e": 98592,
      "ty": 2,
      "x": 826,
      "y": 242
    },
    {
      "t": 100508,
      "e": 98693,
      "ty": 2,
      "x": 828,
      "y": 237
    },
    {
      "t": 100508,
      "e": 98693,
      "ty": 41,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 100607,
      "e": 98792,
      "ty": 2,
      "x": 829,
      "y": 236
    },
    {
      "t": 100708,
      "e": 98893,
      "ty": 3,
      "x": 829,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 100709,
      "e": 98894,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 100758,
      "e": 98943,
      "ty": 41,
      "x": 12996,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 100931,
      "e": 99116,
      "ty": 4,
      "x": 12996,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 100932,
      "e": 99117,
      "ty": 5,
      "x": 829,
      "y": 236,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 100932,
      "e": 99117,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 101960,
      "e": 100145,
      "ty": 7,
      "x": 832,
      "y": 247,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 101977,
      "e": 100162,
      "ty": 6,
      "x": 837,
      "y": 263,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 101993,
      "e": 100178,
      "ty": 7,
      "x": 840,
      "y": 272,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 102007,
      "e": 100192,
      "ty": 2,
      "x": 840,
      "y": 272
    },
    {
      "t": 102007,
      "e": 100192,
      "ty": 41,
      "x": 14149,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 102107,
      "e": 100292,
      "ty": 2,
      "x": 863,
      "y": 340
    },
    {
      "t": 102207,
      "e": 100392,
      "ty": 2,
      "x": 864,
      "y": 343
    },
    {
      "t": 102257,
      "e": 100442,
      "ty": 41,
      "x": 11054,
      "y": 13600,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 102307,
      "e": 100492,
      "ty": 2,
      "x": 869,
      "y": 343
    },
    {
      "t": 102507,
      "e": 100692,
      "ty": 41,
      "x": 11291,
      "y": 13600,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 102907,
      "e": 101092,
      "ty": 2,
      "x": 864,
      "y": 376
    },
    {
      "t": 103007,
      "e": 101192,
      "ty": 2,
      "x": 848,
      "y": 430
    },
    {
      "t": 103007,
      "e": 101192,
      "ty": 41,
      "x": 6307,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 103107,
      "e": 101292,
      "ty": 2,
      "x": 838,
      "y": 461
    },
    {
      "t": 103207,
      "e": 101392,
      "ty": 2,
      "x": 837,
      "y": 463
    },
    {
      "t": 103221,
      "e": 101406,
      "ty": 6,
      "x": 837,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 103257,
      "e": 101442,
      "ty": 41,
      "x": 53325,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 103307,
      "e": 101492,
      "ty": 2,
      "x": 837,
      "y": 464
    },
    {
      "t": 103494,
      "e": 101679,
      "ty": 3,
      "x": 837,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 103495,
      "e": 101680,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 103496,
      "e": 101681,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 103668,
      "e": 101853,
      "ty": 4,
      "x": 53325,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 103669,
      "e": 101854,
      "ty": 5,
      "x": 837,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 103669,
      "e": 101854,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 105149,
      "e": 103334,
      "ty": 7,
      "x": 846,
      "y": 479,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 105207,
      "e": 103392,
      "ty": 2,
      "x": 881,
      "y": 517
    },
    {
      "t": 105258,
      "e": 103443,
      "ty": 41,
      "x": 63168,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 105308,
      "e": 103493,
      "ty": 2,
      "x": 917,
      "y": 581
    },
    {
      "t": 105408,
      "e": 103593,
      "ty": 2,
      "x": 888,
      "y": 640
    },
    {
      "t": 105507,
      "e": 103692,
      "ty": 2,
      "x": 853,
      "y": 692
    },
    {
      "t": 105507,
      "e": 103692,
      "ty": 41,
      "x": 7494,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 105607,
      "e": 103792,
      "ty": 2,
      "x": 850,
      "y": 695
    },
    {
      "t": 105757,
      "e": 103942,
      "ty": 41,
      "x": 7201,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 105807,
      "e": 103992,
      "ty": 2,
      "x": 849,
      "y": 701
    },
    {
      "t": 105908,
      "e": 104093,
      "ty": 2,
      "x": 844,
      "y": 712
    },
    {
      "t": 106007,
      "e": 104192,
      "ty": 2,
      "x": 842,
      "y": 713
    },
    {
      "t": 106008,
      "e": 104193,
      "ty": 41,
      "x": 4883,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 106208,
      "e": 104393,
      "ty": 2,
      "x": 840,
      "y": 719
    },
    {
      "t": 106258,
      "e": 104394,
      "ty": 41,
      "x": 4662,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 106307,
      "e": 104443,
      "ty": 2,
      "x": 840,
      "y": 724
    },
    {
      "t": 106308,
      "e": 104444,
      "ty": 6,
      "x": 839,
      "y": 725,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 106408,
      "e": 104544,
      "ty": 2,
      "x": 839,
      "y": 727
    },
    {
      "t": 106507,
      "e": 104643,
      "ty": 2,
      "x": 838,
      "y": 730
    },
    {
      "t": 106508,
      "e": 104644,
      "ty": 41,
      "x": 58367,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 106813,
      "e": 104949,
      "ty": 3,
      "x": 838,
      "y": 730,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 106814,
      "e": 104950,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 106815,
      "e": 104951,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 106980,
      "e": 105116,
      "ty": 4,
      "x": 58367,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 106980,
      "e": 105116,
      "ty": 5,
      "x": 838,
      "y": 730,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 106981,
      "e": 105117,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 107481,
      "e": 105617,
      "ty": 7,
      "x": 840,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 107507,
      "e": 105643,
      "ty": 2,
      "x": 845,
      "y": 764
    },
    {
      "t": 107508,
      "e": 105644,
      "ty": 41,
      "x": 9838,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 107607,
      "e": 105743,
      "ty": 2,
      "x": 872,
      "y": 821
    },
    {
      "t": 107707,
      "e": 105843,
      "ty": 2,
      "x": 875,
      "y": 848
    },
    {
      "t": 107758,
      "e": 105894,
      "ty": 41,
      "x": 12952,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 107807,
      "e": 105943,
      "ty": 2,
      "x": 876,
      "y": 937
    },
    {
      "t": 107908,
      "e": 106044,
      "ty": 2,
      "x": 877,
      "y": 955
    },
    {
      "t": 108007,
      "e": 106143,
      "ty": 2,
      "x": 876,
      "y": 957
    },
    {
      "t": 108008,
      "e": 106144,
      "ty": 41,
      "x": 44149,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 108108,
      "e": 106244,
      "ty": 2,
      "x": 871,
      "y": 959
    },
    {
      "t": 108207,
      "e": 106343,
      "ty": 2,
      "x": 863,
      "y": 963
    },
    {
      "t": 108258,
      "e": 106394,
      "ty": 41,
      "x": 30397,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 108307,
      "e": 106443,
      "ty": 2,
      "x": 859,
      "y": 965
    },
    {
      "t": 108414,
      "e": 106550,
      "ty": 3,
      "x": 859,
      "y": 965,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 108414,
      "e": 106550,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 108572,
      "e": 106708,
      "ty": 4,
      "x": 30397,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 108572,
      "e": 106708,
      "ty": 5,
      "x": 859,
      "y": 965,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 108573,
      "e": 106709,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 108573,
      "e": 106709,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 108807,
      "e": 106943,
      "ty": 2,
      "x": 855,
      "y": 967
    },
    {
      "t": 108907,
      "e": 107043,
      "ty": 2,
      "x": 850,
      "y": 967
    },
    {
      "t": 109007,
      "e": 107143,
      "ty": 2,
      "x": 842,
      "y": 979
    },
    {
      "t": 109008,
      "e": 107144,
      "ty": 41,
      "x": 4883,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 109108,
      "e": 107244,
      "ty": 2,
      "x": 845,
      "y": 1001
    },
    {
      "t": 109116,
      "e": 107252,
      "ty": 6,
      "x": 847,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 109208,
      "e": 107344,
      "ty": 2,
      "x": 858,
      "y": 1027
    },
    {
      "t": 109258,
      "e": 107394,
      "ty": 41,
      "x": 15244,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 109307,
      "e": 107443,
      "ty": 2,
      "x": 859,
      "y": 1028
    },
    {
      "t": 109350,
      "e": 107486,
      "ty": 3,
      "x": 859,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 109350,
      "e": 107486,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 109351,
      "e": 107487,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 109501,
      "e": 107637,
      "ty": 4,
      "x": 15244,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 109501,
      "e": 107637,
      "ty": 5,
      "x": 859,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 109504,
      "e": 107640,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 109505,
      "e": 107641,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 109506,
      "e": 107642,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 110849,
      "e": 108985,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 119407,
      "e": 112641,
      "ty": 2,
      "x": 839,
      "y": 1015
    },
    {
      "t": 119507,
      "e": 112741,
      "ty": 2,
      "x": 833,
      "y": 1014
    },
    {
      "t": 119508,
      "e": 112742,
      "ty": 41,
      "x": 26544,
      "y": 61471,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 120007,
      "e": 113241,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 135708,
      "e": 117742,
      "ty": 2,
      "x": 834,
      "y": 1014
    },
    {
      "t": 135759,
      "e": 117793,
      "ty": 41,
      "x": 27528,
      "y": 60847,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 135808,
      "e": 117842,
      "ty": 2,
      "x": 867,
      "y": 1002
    },
    {
      "t": 135908,
      "e": 117942,
      "ty": 2,
      "x": 900,
      "y": 1017
    },
    {
      "t": 136008,
      "e": 118042,
      "ty": 2,
      "x": 928,
      "y": 1034
    },
    {
      "t": 136008,
      "e": 118042,
      "ty": 41,
      "x": 31217,
      "y": 62855,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 136108,
      "e": 118142,
      "ty": 2,
      "x": 935,
      "y": 1048
    },
    {
      "t": 136208,
      "e": 118242,
      "ty": 2,
      "x": 932,
      "y": 1065
    },
    {
      "t": 136258,
      "e": 118292,
      "ty": 41,
      "x": 31414,
      "y": 65071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 136308,
      "e": 118342,
      "ty": 2,
      "x": 933,
      "y": 1067
    },
    {
      "t": 136408,
      "e": 118442,
      "ty": 2,
      "x": 937,
      "y": 1070
    },
    {
      "t": 136421,
      "e": 118455,
      "ty": 6,
      "x": 941,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 136508,
      "e": 118542,
      "ty": 2,
      "x": 953,
      "y": 1075
    },
    {
      "t": 136508,
      "e": 118542,
      "ty": 41,
      "x": 23756,
      "y": 4457,
      "ta": "#start"
    },
    {
      "t": 139507,
      "e": 121541,
      "ty": 2,
      "x": 961,
      "y": 1095
    },
    {
      "t": 139507,
      "e": 121541,
      "ty": 41,
      "x": 28125,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 139607,
      "e": 121641,
      "ty": 2,
      "x": 963,
      "y": 1100
    },
    {
      "t": 139706,
      "e": 121740,
      "ty": 2,
      "x": 964,
      "y": 1101
    },
    {
      "t": 139757,
      "e": 121791,
      "ty": 41,
      "x": 29763,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 139885,
      "e": 121919,
      "ty": 3,
      "x": 964,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 139886,
      "e": 121920,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 140052,
      "e": 122086,
      "ty": 4,
      "x": 29763,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 140052,
      "e": 122086,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 140053,
      "e": 122087,
      "ty": 5,
      "x": 964,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 140055,
      "e": 122089,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 141092,
      "e": 123126,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 141993,
      "e": 124027,
      "ty": 2,
      "x": 897,
      "y": 1063
    },
    {
      "t": 141993,
      "e": 124027,
      "ty": 41,
      "x": 29104,
      "y": 32861,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 142695,
      "e": 124729,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2311,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"previousSibling\":{\"id\":2302},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"previousSibling\":{\"id\":2311},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2312},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"previousSibling\":{\"id\":2313},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"previousSibling\":{\"id\":2314},\"parentNode\":{\"id\":2300}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"previousSibling\":{\"id\":2316},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"previousSibling\":{\"id\":2317},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"previousSibling\":{\"id\":2318},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"previousSibling\":{\"id\":2319},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"previousSibling\":{\"id\":2320},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"previousSibling\":{\"id\":2321},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"previousSibling\":{\"id\":2322},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"previousSibling\":{\"id\":2323},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"previousSibling\":{\"id\":2324},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"previousSibling\":{\"id\":2325},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"previousSibling\":{\"id\":2326},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"previousSibling\":{\"id\":2327},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"previousSibling\":{\"id\":2328},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"previousSibling\":{\"id\":2329},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"previousSibling\":{\"id\":2330},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"previousSibling\":{\"id\":2331},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"previousSibling\":{\"id\":2332},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"previousSibling\":{\"id\":2333},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"previousSibling\":{\"id\":2334},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"previousSibling\":{\"id\":2335},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"previousSibling\":{\"id\":2336},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"previousSibling\":{\"id\":2337},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"previousSibling\":{\"id\":2338},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"previousSibling\":{\"id\":2339},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"previousSibling\":{\"id\":2340},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2341},\"parentNode\":{\"id\":2311}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2343},\"parentNode\":{\"id\":2317}},{\"nodeType\":1,\"id\":2345,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2346,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2345},\"parentNode\":{\"id\":2318}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2347},\"parentNode\":{\"id\":2319}},{\"nodeType\":1,\"id\":2349,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2350,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2349},\"parentNode\":{\"id\":2320}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2351},\"parentNode\":{\"id\":2321}},{\"nodeType\":1,\"id\":2353,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2354,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2353},\"parentNode\":{\"id\":2322}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2355},\"parentNode\":{\"id\":2323}},{\"nodeType\":1,\"id\":2357,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2358,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2357},\"parentNode\":{\"id\":2324}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2359},\"parentNode\":{\"id\":2325}},{\"nodeType\":1,\"id\":2361,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2362,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2361},\"parentNode\":{\"id\":2326}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2363},\"parentNode\":{\"id\":2327}},{\"nodeType\":1,\"id\":2365,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2366,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2365},\"parentNode\":{\"id\":2328}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2367},\"parentNode\":{\"id\":2329}},{\"nodeType\":1,\"id\":2369,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2370,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2369},\"parentNode\":{\"id\":2330}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2371},\"parentNode\":{\"id\":2331}},{\"nodeType\":1,\"id\":2373,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2374,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2373},\"parentNode\":{\"id\":2332}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2375},\"parentNode\":{\"id\":2333}},{\"nodeType\":1,\"id\":2377,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2378,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2377},\"parentNode\":{\"id\":2334}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2379},\"parentNode\":{\"id\":2335}},{\"nodeType\":1,\"id\":2381,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2382,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2381},\"parentNode\":{\"id\":2336}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2383},\"parentNode\":{\"id\":2337}},{\"nodeType\":1,\"id\":2385,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2386,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2385},\"parentNode\":{\"id\":2338}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2387},\"parentNode\":{\"id\":2339}},{\"nodeType\":1,\"id\":2389,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2390,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"previousSibling\":{\"id\":2389},\"parentNode\":{\"id\":2340}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"},\"parentNode\":{\"id\":2341}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"previousSibling\":{\"id\":2391},\"parentNode\":{\"id\":2341}},{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 AM\",\"parentNode\":{\"id\":2344}},{\"nodeType\":3,\"id\":2394,\"textContent\":\"08:30\",\"parentNode\":{\"id\":2346}},{\"nodeType\":3,\"id\":2395,\"textContent\":\"09 AM\",\"parentNode\":{\"id\":2348}},{\"nodeType\":3,\"id\":2396,\"textContent\":\"09:30\",\"parentNode\":{\"id\":2350}},{\"nodeType\":3,\"id\":2397,\"textContent\":\"10 AM\",\"parentNode\":{\"id\":2352}},{\"nodeType\":3,\"id\":2398,\"textContent\":\"10:30\",\"parentNode\":{\"id\":2354}},{\"nodeType\":3,\"id\":2399,\"textContent\":\"11 AM\",\"parentNode\":{\"id\":2356}},{\"nodeType\":3,\"id\":2400,\"textContent\":\"11:30\",\"parentNode\":{\"id\":2358}},{\"nodeType\":3,\"id\":2401,\"textContent\":\"12 PM\",\"parentNode\":{\"id\":2360}},{\"nodeType\":3,\"id\":2402,\"textContent\":\"12:30\",\"parentNode\":{\"id\":2362}},{\"nodeType\":3,\"id\":2403,\"textContent\":\"01 PM\",\"parentNode\":{\"id\":2364}},{\"nodeType\":3,\"id\":2404,\"textContent\":\"01:30\",\"parentNode\":{\"id\":2366}},{\"nodeType\":3,\"id\":2405,\"textContent\":\"02 PM\",\"parentNode\":{\"id\":2368}},{\"nodeType\":3,\"id\":2406,\"textContent\":\"02:30\",\"parentNode\":{\"id\":2370}},{\"nodeType\":3,\"id\":2407,\"textContent\":\"03 PM\",\"parentNode\":{\"id\":2372}},{\"nodeType\":3,\"id\":2408,\"textContent\":\"03:30\",\"parentNode\":{\"id\":2374}},{\"nodeType\":3,\"id\":2409,\"textContent\":\"04 PM\",\"parentNode\":{\"id\":2376}},{\"nodeType\":3,\"id\":2410,\"textContent\":\"04:30\",\"parentNode\":{\"id\":2378}},{\"nodeType\":3,\"id\":2411,\"textContent\":\"05 PM\",\"parentNode\":{\"id\":2380}},{\"nodeType\":3,\"id\":2412,\"textContent\":\"05:30\",\"parentNode\":{\"id\":2382}},{\"nodeType\":3,\"id\":2413,\"textContent\":\"06 PM\",\"parentNode\":{\"id\":2384}},{\"nodeType\":3,\"id\":2414,\"textContent\":\"06:30\",\"parentNode\":{\"id\":2386}},{\"nodeType\":3,\"id\":2415,\"textContent\":\"07 PM\",\"parentNode\":{\"id\":2388}},{\"nodeType\":3,\"id\":2416,\"textContent\":\"07:30\",\"parentNode\":{\"id\":2390}},{\"nodeType\":3,\"id\":2417,\"textContent\":\"08 PM\",\"parentNode\":{\"id\":2392}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2342}},{\"nodeType\":3,\"id\":2419,\"textContent\":\"START & END TIME (time of day)\",\"parentNode\":{\"id\":2418}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"previousSibling\":{\"id\":2420},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"previousSibling\":{\"id\":2421},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"previousSibling\":{\"id\":2422},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"previousSibling\":{\"id\":2423},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2425,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"previousSibling\":{\"id\":2424},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"previousSibling\":{\"id\":2425},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"previousSibling\":{\"id\":2426},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"previousSibling\":{\"id\":2427},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2429,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"previousSibling\":{\"id\":2428},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"previousSibling\":{\"id\":2429},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"previousSibling\":{\"id\":2430},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"previousSibling\":{\"id\":2431},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"previousSibling\":{\"id\":2432},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"previousSibling\":{\"id\":2433},\"parentNode\":{\"id\":2312}},{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2435},\"parentNode\":{\"id\":2421}},{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2437},\"parentNode\":{\"id\":2422}},{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2439},\"parentNode\":{\"id\":2423}},{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2442,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2441},\"parentNode\":{\"id\":2424}},{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2443},\"parentNode\":{\"id\":2425}},{\"nodeType\":1,\"id\":2445,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2446,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2445},\"parentNode\":{\"id\":2426}},{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2447},\"parentNode\":{\"id\":2427}},{\"nodeType\":1,\"id\":2449,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2450,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2449},\"parentNode\":{\"id\":2428}},{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2451},\"parentNode\":{\"id\":2429}},{\"nodeType\":1,\"id\":2453,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2453},\"parentNode\":{\"id\":2430}},{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2455},\"parentNode\":{\"id\":2431}},{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2457},\"parentNode\":{\"id\":2432}},{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"},\"parentNode\":{\"id\":2433}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"previousSibling\":{\"id\":2459},\"parentNode\":{\"id\":2433}},{\"nodeType\":3,\"id\":2461,\"textContent\":\"0\",\"parentNode\":{\"id\":2436}},{\"nodeType\":3,\"id\":2462,\"textContent\":\"1\",\"parentNode\":{\"id\":2438}},{\"nodeType\":3,\"id\":2463,\"textContent\":\"2\",\"parentNode\":{\"id\":2440}},{\"nodeType\":3,\"id\":2464,\"textContent\":\"3\",\"parentNode\":{\"id\":2442}},{\"nodeType\":3,\"id\":2465,\"textContent\":\"4\",\"parentNode\":{\"id\":2444}},{\"nodeType\":3,\"id\":2466,\"textContent\":\"5\",\"parentNode\":{\"id\":2446}},{\"nodeType\":3,\"id\":2467,\"textContent\":\"6\",\"parentNode\":{\"id\":2448}},{\"nodeType\":3,\"id\":2468,\"textContent\":\"7\",\"parentNode\":{\"id\":2450}},{\"nodeType\":3,\"id\":2469,\"textContent\":\"8\",\"parentNode\":{\"id\":2452}},{\"nodeType\":3,\"id\":2470,\"textContent\":\"9\",\"parentNode\":{\"id\":2454}},{\"nodeType\":3,\"id\":2471,\"textContent\":\"10\",\"parentNode\":{\"id\":2456}},{\"nodeType\":3,\"id\":2472,\"textContent\":\"11\",\"parentNode\":{\"id\":2458}},{\"nodeType\":3,\"id\":2473,\"textContent\":\"12\",\"parentNode\":{\"id\":2460}},{\"nodeType\":1,\"id\":2474,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"parentNode\":{\"id\":2434}},{\"nodeType\":3,\"id\":2475,\"textContent\":\"DURATION (in hours)\",\"parentNode\":{\"id\":2474}},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2476},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2477},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2479,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2478},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2479},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2481,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2480},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2481},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2483,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2482},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2483},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2484},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2485},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"previousSibling\":{\"id\":2486},\"parentNode\":{\"id\":2313}},{\"nodeType\":1,\"id\":2488,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"},\"parentNode\":{\"id\":2476}},{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"},\"parentNode\":{\"id\":2477}},{\"nodeType\":1,\"id\":2490,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"},\"parentNode\":{\"id\":2478}},{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"},\"parentNode\":{\"id\":2479}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"},\"parentNode\":{\"id\":2480}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"},\"parentNode\":{\"id\":2481}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"},\"parentNode\":{\"id\":2482}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"},\"parentNode\":{\"id\":2483}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"},\"parentNode\":{\"id\":2484}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"},\"parentNode\":{\"id\":2485}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"},\"parentNode\":{\"id\":2486}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"},\"parentNode\":{\"id\":2487}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"},\"previousSibling\":{\"id\":2500},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2501},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"},\"previousSibling\":{\"id\":2502},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2503},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"},\"previousSibling\":{\"id\":2504},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2505},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"},\"previousSibling\":{\"id\":2506},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2507},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"},\"previousSibling\":{\"id\":2508},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2509},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"},\"previousSibling\":{\"id\":2510},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2511},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"},\"previousSibling\":{\"id\":2512},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2513},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"},\"previousSibling\":{\"id\":2514},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2515},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"},\"previousSibling\":{\"id\":2516},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2517},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"},\"previousSibling\":{\"id\":2518},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2519},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"},\"previousSibling\":{\"id\":2520},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2521},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"},\"previousSibling\":{\"id\":2522},\"parentNode\":{\"id\":2314}},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2524},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2525},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2526},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2527},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2528},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2529},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2530},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2531},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2532},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2533},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2534},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2535},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2536},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2537},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2538},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2539},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"previousSibling\":{\"id\":2540},\"parentNode\":{\"id\":2315}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"previousSibling\":{\"id\":2542},\"parentNode\":{\"id\":2524}},{\"nodeType\":1,\"id\":2544,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2545,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"previousSibling\":{\"id\":2544},\"parentNode\":{\"id\":2525}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2546},\"parentNode\":{\"id\":2526}},{\"nodeType\":1,\"id\":2548,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2549,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2548},\"parentNode\":{\"id\":2527}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"previousSibling\":{\"id\":2550},\"parentNode\":{\"id\":2528}},{\"nodeType\":1,\"id\":2552,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2553,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2552},\"parentNode\":{\"id\":2529}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"previousSibling\":{\"id\":2554},\"parentNode\":{\"id\":2530}},{\"nodeType\":1,\"id\":2556,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2557,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"previousSibling\":{\"id\":2556},\"parentNode\":{\"id\":2531}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"previousSibling\":{\"id\":2558},\"parentNode\":{\"id\":2532}},{\"nodeType\":1,\"id\":2560,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2561,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2560},\"parentNode\":{\"id\":2533}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"previousSibling\":{\"id\":2562},\"parentNode\":{\"id\":2534}},{\"nodeType\":1,\"id\":2564,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2565,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"previousSibling\":{\"id\":2564},\"parentNode\":{\"id\":2535}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"previousSibling\":{\"id\":2566},\"parentNode\":{\"id\":2536}},{\"nodeType\":1,\"id\":2568,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2569,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2568},\"parentNode\":{\"id\":2537}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"previousSibling\":{\"id\":2570},\"parentNode\":{\"id\":2538}},{\"nodeType\":1,\"id\":2572,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2573,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"previousSibling\":{\"id\":2572},\"parentNode\":{\"id\":2539}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"previousSibling\":{\"id\":2574},\"parentNode\":{\"id\":2540}},{\"nodeType\":1,\"id\":2576,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"},\"parentNode\":{\"id\":2541}},{\"nodeType\":1,\"id\":2577,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"previousSibling\":{\"id\":2576},\"parentNode\":{\"id\":2541}},{\"nodeType\":3,\"id\":2578,\"textContent\":\"A \",\"parentNode\":{\"id\":2543}},{\"nodeType\":3,\"id\":2579,\"textContent\":\"B \",\"parentNode\":{\"id\":2545}},{\"nodeType\":3,\"id\":2580,\"textContent\":\"C \",\"parentNode\":{\"id\":2547}},{\"nodeType\":3,\"id\":2581,\"textContent\":\"D \",\"parentNode\":{\"id\":2549}},{\"nodeType\":3,\"id\":2582,\"textContent\":\"E \",\"parentNode\":{\"id\":2551}},{\"nodeType\":3,\"id\":2583,\"textContent\":\"F \",\"parentNode\":{\"id\":2553}},{\"nodeType\":3,\"id\":2584,\"textContent\":\"G \",\"parentNode\":{\"id\":2555}},{\"nodeType\":3,\"id\":2585,\"textContent\":\"H \",\"parentNode\":{\"id\":2557}},{\"nodeType\":3,\"id\":2586,\"textContent\":\"I \",\"parentNode\":{\"id\":2559}},{\"nodeType\":3,\"id\":2587,\"textContent\":\"J \",\"parentNode\":{\"id\":2561}},{\"nodeType\":3,\"id\":2588,\"textContent\":\"K \",\"parentNode\":{\"id\":2563}},{\"nodeType\":3,\"id\":2589,\"textContent\":\"L \",\"parentNode\":{\"id\":2565}},{\"nodeType\":3,\"id\":2590,\"textContent\":\"M \",\"parentNode\":{\"id\":2567}},{\"nodeType\":3,\"id\":2591,\"textContent\":\"N \",\"parentNode\":{\"id\":2569}},{\"nodeType\":3,\"id\":2592,\"textContent\":\"O \",\"parentNode\":{\"id\":2571}},{\"nodeType\":3,\"id\":2593,\"textContent\":\"P \",\"parentNode\":{\"id\":2573}},{\"nodeType\":3,\"id\":2594,\"textContent\":\"Z \",\"parentNode\":{\"id\":2575}},{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \",\"parentNode\":{\"id\":2577}}],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2311},{\"id\":2316},{\"id\":2317},{\"id\":2343},{\"id\":2344},{\"id\":2393},{\"id\":2318},{\"id\":2345},{\"id\":2346},{\"id\":2394},{\"id\":2319},{\"id\":2347},{\"id\":2348},{\"id\":2395},{\"id\":2320},{\"id\":2349},{\"id\":2350},{\"id\":2396},{\"id\":2321},{\"id\":2351},{\"id\":2352},{\"id\":2397},{\"id\":2322},{\"id\":2353},{\"id\":2354},{\"id\":2398},{\"id\":2323},{\"id\":2355},{\"id\":2356},{\"id\":2399},{\"id\":2324},{\"id\":2357},{\"id\":2358},{\"id\":2400},{\"id\":2325},{\"id\":2359},{\"id\":2360},{\"id\":2401},{\"id\":2326},{\"id\":2361},{\"id\":2362},{\"id\":2402},{\"id\":2327},{\"id\":2363},{\"id\":2364},{\"id\":2403},{\"id\":2328},{\"id\":2365},{\"id\":2366},{\"id\":2404},{\"id\":2329},{\"id\":2367},{\"id\":2368},{\"id\":2405},{\"id\":2330},{\"id\":2369},{\"id\":2370},{\"id\":2406},{\"id\":2331},{\"id\":2371},{\"id\":2372},{\"id\":2407},{\"id\":2332},{\"id\":2373},{\"id\":2374},{\"id\":2408},{\"id\":2333},{\"id\":2375},{\"id\":2376},{\"id\":2409},{\"id\":2334},{\"id\":2377},{\"id\":2378},{\"id\":2410},{\"id\":2335},{\"id\":2379},{\"id\":2380},{\"id\":2411},{\"id\":2336},{\"id\":2381},{\"id\":2382},{\"id\":2412},{\"id\":2337},{\"id\":2383},{\"id\":2384},{\"id\":2413},{\"id\":2338},{\"id\":2385},{\"id\":2386},{\"id\":2414},{\"id\":2339},{\"id\":2387},{\"id\":2388},{\"id\":2415},{\"id\":2340},{\"id\":2389},{\"id\":2390},{\"id\":2416},{\"id\":2341},{\"id\":2391},{\"id\":2392},{\"id\":2417},{\"id\":2342},{\"id\":2418},{\"id\":2419},{\"id\":2312},{\"id\":2420},{\"id\":2421},{\"id\":2435},{\"id\":2436},{\"id\":2461},{\"id\":2422},{\"id\":2437},{\"id\":2438},{\"id\":2462},{\"id\":2423},{\"id\":2439},{\"id\":2440},{\"id\":2463},{\"id\":2424},{\"id\":2441},{\"id\":2442},{\"id\":2464},{\"id\":2425},{\"id\":2443},{\"id\":2444},{\"id\":2465},{\"id\":2426},{\"id\":2445},{\"id\":2446},{\"id\":2466},{\"id\":2427},{\"id\":2447},{\"id\":2448},{\"id\":2467},{\"id\":2428},{\"id\":2449},{\"id\":2450},{\"id\":2468},{\"id\":2429},{\"id\":2451},{\"id\":2452},{\"id\":2469},{\"id\":2430},{\"id\":2453},{\"id\":2454},{\"id\":2470},{\"id\":2431},{\"id\":2455},{\"id\":2456},{\"id\":2471},{\"id\":2432},{\"id\":2457},{\"id\":2458},{\"id\":2472},{\"id\":2433},{\"id\":2459},{\"id\":2460},{\"id\":2473},{\"id\":2434},{\"id\":2474},{\"id\":2475},{\"id\":2313},{\"id\":2476},{\"id\":2488},{\"id\":2477},{\"id\":2489},{\"id\":2478},{\"id\":2490},{\"id\":2479},{\"id\":2491},{\"id\":2480},{\"id\":2492},{\"id\":2481},{\"id\":2493},{\"id\":2482},{\"id\":2494},{\"id\":2483},{\"id\":2495},{\"id\":2484},{\"id\":2496},{\"id\":2485},{\"id\":2497},{\"id\":2486},{\"id\":2498},{\"id\":2487},{\"id\":2499},{\"id\":2314},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2315},{\"id\":2524},{\"id\":2542},{\"id\":2543},{\"id\":2578},{\"id\":2525},{\"id\":2544},{\"id\":2545},{\"id\":2579},{\"id\":2526},{\"id\":2546},{\"id\":2547},{\"id\":2580},{\"id\":2527},{\"id\":2548},{\"id\":2549},{\"id\":2581},{\"id\":2528},{\"id\":2550},{\"id\":2551},{\"id\":2582},{\"id\":2529},{\"id\":2552},{\"id\":2553},{\"id\":2583},{\"id\":2530},{\"id\":2554},{\"id\":2555},{\"id\":2584},{\"id\":2531},{\"id\":2556},{\"id\":2557},{\"id\":2585},{\"id\":2532},{\"id\":2558},{\"id\":2559},{\"id\":2586},{\"id\":2533},{\"id\":2560},{\"id\":2561},{\"id\":2587},{\"id\":2534},{\"id\":2562},{\"id\":2563},{\"id\":2588},{\"id\":2535},{\"id\":2564},{\"id\":2565},{\"id\":2589},{\"id\":2536},{\"id\":2566},{\"id\":2567},{\"id\":2590},{\"id\":2537},{\"id\":2568},{\"id\":2569},{\"id\":2591},{\"id\":2538},{\"id\":2570},{\"id\":2571},{\"id\":2592},{\"id\":2539},{\"id\":2572},{\"id\":2573},{\"id\":2593},{\"id\":2540},{\"id\":2574},{\"id\":2575},{\"id\":2594},{\"id\":2541},{\"id\":2576},{\"id\":2577},{\"id\":2595},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2308},{\"id\":2309},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2310}],[],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 375321, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 375326, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 5025, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 381697, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 11311, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"zulu\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"211\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 394014, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 26508, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 421626, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 14010, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 436637, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 23923, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 461937, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-12 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1805,y:922,t:1528143450740};\\\", \\\"{x:1799,y:930,t:1528143450747};\\\", \\\"{x:1786,y:948,t:1528143450760};\\\", \\\"{x:1767,y:976,t:1528143450777};\\\", \\\"{x:1756,y:1009,t:1528143450795};\\\", \\\"{x:1750,y:1054,t:1528143450811};\\\", \\\"{x:1745,y:1101,t:1528143450826};\\\", \\\"{x:1739,y:1154,t:1528143450844};\\\", \\\"{x:1734,y:1182,t:1528143450860};\\\", \\\"{x:1730,y:1201,t:1528143450877};\\\", \\\"{x:1727,y:1210,t:1528143450893};\\\", \\\"{x:1727,y:1211,t:1528143450910};\\\", \\\"{x:1725,y:1209,t:1528143451075};\\\", \\\"{x:1723,y:1199,t:1528143451082};\\\", \\\"{x:1722,y:1195,t:1528143451094};\\\", \\\"{x:1709,y:1185,t:1528143451112};\\\", \\\"{x:1699,y:1184,t:1528143451127};\\\", \\\"{x:1682,y:1184,t:1528143451144};\\\", \\\"{x:1670,y:1184,t:1528143451161};\\\", \\\"{x:1654,y:1184,t:1528143451177};\\\", \\\"{x:1648,y:1184,t:1528143451194};\\\", \\\"{x:1623,y:1180,t:1528143451210};\\\", \\\"{x:1605,y:1174,t:1528143451227};\\\", \\\"{x:1600,y:1163,t:1528143451244};\\\", \\\"{x:1574,y:1143,t:1528143451261};\\\", \\\"{x:1536,y:1119,t:1528143451278};\\\", \\\"{x:1498,y:1093,t:1528143451294};\\\", \\\"{x:1487,y:1076,t:1528143451311};\\\", \\\"{x:1476,y:1066,t:1528143451328};\\\", \\\"{x:1466,y:1056,t:1528143451344};\\\", \\\"{x:1450,y:1041,t:1528143451361};\\\", \\\"{x:1429,y:1024,t:1528143451378};\\\", \\\"{x:1414,y:1013,t:1528143451394};\\\", \\\"{x:1403,y:1006,t:1528143451411};\\\", \\\"{x:1394,y:999,t:1528143451428};\\\", \\\"{x:1388,y:993,t:1528143451444};\\\", \\\"{x:1381,y:988,t:1528143451461};\\\", \\\"{x:1370,y:983,t:1528143451479};\\\", \\\"{x:1361,y:979,t:1528143451495};\\\", \\\"{x:1355,y:975,t:1528143451511};\\\", \\\"{x:1347,y:972,t:1528143451528};\\\", \\\"{x:1341,y:970,t:1528143451544};\\\", \\\"{x:1332,y:967,t:1528143451562};\\\", \\\"{x:1320,y:966,t:1528143451578};\\\", \\\"{x:1318,y:966,t:1528143451594};\\\", \\\"{x:1315,y:964,t:1528143451611};\\\", \\\"{x:1311,y:964,t:1528143451629};\\\", \\\"{x:1309,y:964,t:1528143451644};\\\", \\\"{x:1304,y:965,t:1528143451662};\\\", \\\"{x:1302,y:966,t:1528143451678};\\\", \\\"{x:1299,y:967,t:1528143451695};\\\", \\\"{x:1297,y:967,t:1528143451711};\\\", \\\"{x:1295,y:968,t:1528143451728};\\\", \\\"{x:1293,y:968,t:1528143451745};\\\", \\\"{x:1291,y:969,t:1528143452148};\\\", \\\"{x:1289,y:970,t:1528143452162};\\\", \\\"{x:1287,y:970,t:1528143452179};\\\", \\\"{x:1287,y:971,t:1528143452195};\\\", \\\"{x:1286,y:971,t:1528143452219};\\\", \\\"{x:1286,y:972,t:1528143452243};\\\", \\\"{x:1284,y:972,t:1528143452250};\\\", \\\"{x:1283,y:972,t:1528143452315};\\\", \\\"{x:1282,y:973,t:1528143452331};\\\", \\\"{x:1281,y:973,t:1528143452379};\\\", \\\"{x:1280,y:974,t:1528143452595};\\\", \\\"{x:1280,y:975,t:1528143453459};\\\", \\\"{x:1279,y:972,t:1528143459146};\\\", \\\"{x:1277,y:966,t:1528143459154};\\\", \\\"{x:1276,y:960,t:1528143459167};\\\", \\\"{x:1271,y:948,t:1528143459184};\\\", \\\"{x:1268,y:935,t:1528143459201};\\\", \\\"{x:1265,y:925,t:1528143459218};\\\", \\\"{x:1261,y:915,t:1528143459234};\\\", \\\"{x:1260,y:906,t:1528143459250};\\\", \\\"{x:1258,y:900,t:1528143459267};\\\", \\\"{x:1257,y:895,t:1528143459283};\\\", \\\"{x:1256,y:892,t:1528143459300};\\\", \\\"{x:1256,y:888,t:1528143459317};\\\", \\\"{x:1255,y:885,t:1528143459334};\\\", \\\"{x:1255,y:881,t:1528143459350};\\\", \\\"{x:1254,y:878,t:1528143459368};\\\", \\\"{x:1254,y:875,t:1528143459384};\\\", \\\"{x:1254,y:870,t:1528143459400};\\\", \\\"{x:1255,y:864,t:1528143459417};\\\", \\\"{x:1257,y:854,t:1528143459434};\\\", \\\"{x:1258,y:848,t:1528143459450};\\\", \\\"{x:1258,y:841,t:1528143459467};\\\", \\\"{x:1260,y:835,t:1528143459483};\\\", \\\"{x:1261,y:830,t:1528143459500};\\\", \\\"{x:1263,y:825,t:1528143459517};\\\", \\\"{x:1264,y:822,t:1528143459534};\\\", \\\"{x:1266,y:819,t:1528143459550};\\\", \\\"{x:1266,y:816,t:1528143459567};\\\", \\\"{x:1267,y:812,t:1528143459584};\\\", \\\"{x:1269,y:809,t:1528143459600};\\\", \\\"{x:1270,y:807,t:1528143459617};\\\", \\\"{x:1270,y:805,t:1528143459634};\\\", \\\"{x:1270,y:804,t:1528143459651};\\\", \\\"{x:1271,y:803,t:1528143459667};\\\", \\\"{x:1272,y:802,t:1528143459685};\\\", \\\"{x:1273,y:802,t:1528143460851};\\\", \\\"{x:1260,y:805,t:1528143460868};\\\", \\\"{x:1236,y:809,t:1528143460886};\\\", \\\"{x:1202,y:815,t:1528143460902};\\\", \\\"{x:1144,y:815,t:1528143460918};\\\", \\\"{x:1079,y:817,t:1528143460936};\\\", \\\"{x:991,y:812,t:1528143460952};\\\", \\\"{x:859,y:799,t:1528143460969};\\\", \\\"{x:737,y:778,t:1528143460985};\\\", \\\"{x:605,y:751,t:1528143461002};\\\", \\\"{x:429,y:710,t:1528143461019};\\\", \\\"{x:328,y:688,t:1528143461036};\\\", \\\"{x:256,y:666,t:1528143461053};\\\", \\\"{x:175,y:642,t:1528143461070};\\\", \\\"{x:134,y:620,t:1528143461086};\\\", \\\"{x:120,y:609,t:1528143461102};\\\", \\\"{x:91,y:589,t:1528143461135};\\\", \\\"{x:86,y:583,t:1528143461151};\\\", \\\"{x:84,y:579,t:1528143461170};\\\", \\\"{x:79,y:573,t:1528143461186};\\\", \\\"{x:78,y:565,t:1528143461201};\\\", \\\"{x:77,y:560,t:1528143461218};\\\", \\\"{x:77,y:556,t:1528143461235};\\\", \\\"{x:78,y:549,t:1528143461252};\\\", \\\"{x:78,y:545,t:1528143461268};\\\", \\\"{x:82,y:539,t:1528143461286};\\\", \\\"{x:85,y:533,t:1528143461303};\\\", \\\"{x:89,y:528,t:1528143461319};\\\", \\\"{x:92,y:524,t:1528143461335};\\\", \\\"{x:97,y:520,t:1528143461352};\\\", \\\"{x:100,y:517,t:1528143461369};\\\", \\\"{x:101,y:516,t:1528143461385};\\\", \\\"{x:105,y:514,t:1528143461402};\\\", \\\"{x:110,y:511,t:1528143461419};\\\", \\\"{x:120,y:507,t:1528143461436};\\\", \\\"{x:130,y:504,t:1528143461453};\\\", \\\"{x:134,y:500,t:1528143461469};\\\", \\\"{x:145,y:499,t:1528143461485};\\\", \\\"{x:152,y:497,t:1528143461502};\\\", \\\"{x:159,y:496,t:1528143461518};\\\", \\\"{x:165,y:496,t:1528143461536};\\\", \\\"{x:174,y:495,t:1528143461552};\\\", \\\"{x:181,y:495,t:1528143461569};\\\", \\\"{x:194,y:495,t:1528143461585};\\\", \\\"{x:207,y:495,t:1528143461604};\\\", \\\"{x:219,y:495,t:1528143461619};\\\", \\\"{x:232,y:495,t:1528143461636};\\\", \\\"{x:240,y:495,t:1528143461653};\\\", \\\"{x:250,y:497,t:1528143461670};\\\", \\\"{x:263,y:500,t:1528143461686};\\\", \\\"{x:268,y:500,t:1528143461704};\\\", \\\"{x:276,y:503,t:1528143461719};\\\", \\\"{x:284,y:504,t:1528143461737};\\\", \\\"{x:290,y:506,t:1528143461756};\\\", \\\"{x:302,y:508,t:1528143461770};\\\", \\\"{x:311,y:512,t:1528143461786};\\\", \\\"{x:325,y:515,t:1528143461802};\\\", \\\"{x:335,y:518,t:1528143461819};\\\", \\\"{x:336,y:518,t:1528143461836};\\\", \\\"{x:342,y:519,t:1528143461853};\\\", \\\"{x:349,y:520,t:1528143461869};\\\", \\\"{x:350,y:521,t:1528143461886};\\\", \\\"{x:353,y:521,t:1528143461902};\\\", \\\"{x:354,y:521,t:1528143461931};\\\", \\\"{x:355,y:521,t:1528143462123};\\\", \\\"{x:356,y:521,t:1528143462146};\\\", \\\"{x:357,y:521,t:1528143462227};\\\", \\\"{x:359,y:521,t:1528143462243};\\\", \\\"{x:360,y:521,t:1528143462254};\\\", \\\"{x:361,y:521,t:1528143462331};\\\", \\\"{x:363,y:521,t:1528143462626};\\\", \\\"{x:365,y:521,t:1528143462637};\\\", \\\"{x:366,y:521,t:1528143462654};\\\", \\\"{x:368,y:521,t:1528143462671};\\\", \\\"{x:369,y:521,t:1528143462686};\\\", \\\"{x:370,y:521,t:1528143462922};\\\", \\\"{x:371,y:521,t:1528143462936};\\\", \\\"{x:372,y:521,t:1528143462954};\\\", \\\"{x:373,y:521,t:1528143462970};\\\", \\\"{x:373,y:520,t:1528143462987};\\\", \\\"{x:374,y:520,t:1528143463004};\\\", \\\"{x:375,y:520,t:1528143463020};\\\", \\\"{x:376,y:520,t:1528143463459};\\\", \\\"{x:376,y:519,t:1528143463470};\\\", \\\"{x:378,y:519,t:1528143463487};\\\", \\\"{x:379,y:520,t:1528143464347};\\\", \\\"{x:383,y:526,t:1528143464355};\\\", \\\"{x:388,y:547,t:1528143464377};\\\", \\\"{x:395,y:566,t:1528143464388};\\\", \\\"{x:402,y:594,t:1528143464405};\\\", \\\"{x:408,y:620,t:1528143464422};\\\", \\\"{x:413,y:636,t:1528143464438};\\\", \\\"{x:417,y:647,t:1528143464454};\\\", \\\"{x:421,y:655,t:1528143464471};\\\", \\\"{x:422,y:659,t:1528143464488};\\\", \\\"{x:426,y:664,t:1528143464504};\\\", \\\"{x:428,y:666,t:1528143464521};\\\", \\\"{x:429,y:667,t:1528143464634};\\\", \\\"{x:430,y:668,t:1528143464642};\\\", \\\"{x:430,y:670,t:1528143464654};\\\", \\\"{x:431,y:671,t:1528143464672};\\\", \\\"{x:434,y:675,t:1528143464689};\\\", \\\"{x:437,y:679,t:1528143464704};\\\", \\\"{x:439,y:681,t:1528143464721};\\\", \\\"{x:443,y:687,t:1528143464738};\\\", \\\"{x:447,y:690,t:1528143464756};\\\", \\\"{x:450,y:693,t:1528143464772};\\\", \\\"{x:451,y:695,t:1528143464789};\\\", \\\"{x:456,y:702,t:1528143464805};\\\", \\\"{x:462,y:708,t:1528143464821};\\\", \\\"{x:465,y:710,t:1528143464838};\\\", \\\"{x:467,y:712,t:1528143464855};\\\", \\\"{x:468,y:713,t:1528143464871};\\\", \\\"{x:470,y:715,t:1528143464888};\\\", \\\"{x:473,y:716,t:1528143464905};\\\", \\\"{x:475,y:717,t:1528143464930};\\\", \\\"{x:476,y:717,t:1528143464946};\\\", \\\"{x:477,y:717,t:1528143464961};\\\", \\\"{x:478,y:718,t:1528143464978};\\\", \\\"{x:480,y:719,t:1528143465002};\\\", \\\"{x:481,y:720,t:1528143465042};\\\" ] }, { \\\"rt\\\": 19761, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 482999, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:481,y:722,t:1528143474698};\\\", \\\"{x:478,y:738,t:1528143474717};\\\", \\\"{x:474,y:752,t:1528143474732};\\\", \\\"{x:472,y:764,t:1528143474748};\\\", \\\"{x:471,y:770,t:1528143474762};\\\", \\\"{x:471,y:774,t:1528143474780};\\\", \\\"{x:470,y:775,t:1528143474797};\\\", \\\"{x:468,y:776,t:1528143474841};\\\", \\\"{x:466,y:778,t:1528143474865};\\\", \\\"{x:465,y:779,t:1528143474881};\\\", \\\"{x:465,y:780,t:1528143474897};\\\", \\\"{x:465,y:781,t:1528143474914};\\\", \\\"{x:465,y:783,t:1528143474987};\\\", \\\"{x:463,y:785,t:1528143474997};\\\", \\\"{x:462,y:786,t:1528143475014};\\\", \\\"{x:461,y:788,t:1528143475030};\\\", \\\"{x:461,y:790,t:1528143475047};\\\", \\\"{x:460,y:791,t:1528143475074};\\\", \\\"{x:460,y:792,t:1528143475090};\\\", \\\"{x:460,y:793,t:1528143475098};\\\", \\\"{x:460,y:791,t:1528143475322};\\\", \\\"{x:460,y:787,t:1528143475330};\\\", \\\"{x:459,y:783,t:1528143475347};\\\", \\\"{x:458,y:778,t:1528143475364};\\\", \\\"{x:458,y:770,t:1528143475381};\\\", \\\"{x:458,y:764,t:1528143475397};\\\", \\\"{x:456,y:757,t:1528143475414};\\\", \\\"{x:455,y:754,t:1528143475431};\\\", \\\"{x:453,y:748,t:1528143475448};\\\", \\\"{x:453,y:746,t:1528143475464};\\\", \\\"{x:453,y:744,t:1528143475481};\\\", \\\"{x:451,y:740,t:1528143475498};\\\", \\\"{x:451,y:739,t:1528143475514};\\\", \\\"{x:449,y:737,t:1528143475611};\\\", \\\"{x:447,y:737,t:1528143475626};\\\", \\\"{x:444,y:737,t:1528143475634};\\\", \\\"{x:442,y:737,t:1528143475648};\\\", \\\"{x:438,y:739,t:1528143475664};\\\", \\\"{x:434,y:742,t:1528143475681};\\\", \\\"{x:427,y:748,t:1528143475697};\\\", \\\"{x:425,y:750,t:1528143475714};\\\", \\\"{x:424,y:751,t:1528143475731};\\\", \\\"{x:423,y:751,t:1528143475749};\\\", \\\"{x:422,y:750,t:1528143475931};\\\", \\\"{x:422,y:749,t:1528143475948};\\\", \\\"{x:419,y:751,t:1528143476089};\\\", \\\"{x:418,y:755,t:1528143476097};\\\", \\\"{x:409,y:772,t:1528143476115};\\\", \\\"{x:398,y:789,t:1528143476132};\\\", \\\"{x:389,y:807,t:1528143476148};\\\", \\\"{x:374,y:831,t:1528143476165};\\\", \\\"{x:355,y:856,t:1528143476182};\\\", \\\"{x:344,y:875,t:1528143476198};\\\", \\\"{x:331,y:901,t:1528143476214};\\\", \\\"{x:320,y:921,t:1528143476232};\\\", \\\"{x:314,y:934,t:1528143476248};\\\", \\\"{x:306,y:944,t:1528143476265};\\\", \\\"{x:305,y:948,t:1528143476282};\\\", \\\"{x:303,y:947,t:1528143477162};\\\", \\\"{x:302,y:939,t:1528143477178};\\\", \\\"{x:301,y:926,t:1528143477186};\\\", \\\"{x:301,y:921,t:1528143477199};\\\", \\\"{x:296,y:902,t:1528143477216};\\\", \\\"{x:293,y:886,t:1528143477234};\\\", \\\"{x:292,y:869,t:1528143477249};\\\", \\\"{x:292,y:846,t:1528143477266};\\\", \\\"{x:292,y:832,t:1528143477283};\\\", \\\"{x:291,y:827,t:1528143477300};\\\", \\\"{x:291,y:823,t:1528143477316};\\\", \\\"{x:291,y:822,t:1528143477333};\\\", \\\"{x:292,y:821,t:1528143479410};\\\", \\\"{x:300,y:817,t:1528143479418};\\\", \\\"{x:320,y:817,t:1528143479435};\\\", \\\"{x:345,y:817,t:1528143479452};\\\", \\\"{x:369,y:816,t:1528143479470};\\\", \\\"{x:402,y:816,t:1528143479485};\\\", \\\"{x:440,y:812,t:1528143479503};\\\", \\\"{x:516,y:816,t:1528143479519};\\\", \\\"{x:611,y:816,t:1528143479535};\\\", \\\"{x:716,y:816,t:1528143479552};\\\", \\\"{x:806,y:818,t:1528143479569};\\\", \\\"{x:872,y:818,t:1528143479585};\\\", \\\"{x:951,y:820,t:1528143479602};\\\", \\\"{x:1013,y:820,t:1528143479619};\\\", \\\"{x:1063,y:820,t:1528143479635};\\\", \\\"{x:1133,y:830,t:1528143479653};\\\", \\\"{x:1155,y:832,t:1528143479670};\\\", \\\"{x:1184,y:834,t:1528143479685};\\\", \\\"{x:1223,y:836,t:1528143479703};\\\", \\\"{x:1254,y:840,t:1528143479719};\\\", \\\"{x:1306,y:846,t:1528143479737};\\\", \\\"{x:1359,y:852,t:1528143479753};\\\", \\\"{x:1435,y:855,t:1528143479770};\\\", \\\"{x:1477,y:867,t:1528143479787};\\\", \\\"{x:1500,y:872,t:1528143479803};\\\", \\\"{x:1521,y:871,t:1528143479819};\\\", \\\"{x:1557,y:871,t:1528143479836};\\\", \\\"{x:1570,y:871,t:1528143479852};\\\", \\\"{x:1589,y:871,t:1528143479870};\\\", \\\"{x:1605,y:871,t:1528143479887};\\\", \\\"{x:1618,y:871,t:1528143479903};\\\", \\\"{x:1632,y:871,t:1528143479920};\\\", \\\"{x:1638,y:873,t:1528143479937};\\\", \\\"{x:1641,y:875,t:1528143479953};\\\", \\\"{x:1643,y:875,t:1528143479970};\\\", \\\"{x:1644,y:877,t:1528143479986};\\\", \\\"{x:1646,y:878,t:1528143480018};\\\", \\\"{x:1647,y:879,t:1528143480042};\\\", \\\"{x:1648,y:879,t:1528143480113};\\\", \\\"{x:1648,y:880,t:1528143480371};\\\", \\\"{x:1648,y:881,t:1528143480779};\\\", \\\"{x:1647,y:882,t:1528143480810};\\\", \\\"{x:1646,y:882,t:1528143480821};\\\", \\\"{x:1645,y:882,t:1528143480838};\\\", \\\"{x:1644,y:882,t:1528143480853};\\\", \\\"{x:1643,y:882,t:1528143480890};\\\", \\\"{x:1642,y:883,t:1528143480907};\\\", \\\"{x:1641,y:884,t:1528143480947};\\\", \\\"{x:1641,y:885,t:1528143480955};\\\", \\\"{x:1639,y:885,t:1528143480994};\\\", \\\"{x:1638,y:885,t:1528143481010};\\\", \\\"{x:1637,y:886,t:1528143481021};\\\", \\\"{x:1635,y:887,t:1528143481038};\\\", \\\"{x:1631,y:888,t:1528143481055};\\\", \\\"{x:1627,y:888,t:1528143481071};\\\", \\\"{x:1623,y:889,t:1528143481088};\\\", \\\"{x:1621,y:889,t:1528143481105};\\\", \\\"{x:1616,y:890,t:1528143481120};\\\", \\\"{x:1615,y:890,t:1528143481136};\\\", \\\"{x:1607,y:890,t:1528143481153};\\\", \\\"{x:1606,y:891,t:1528143481170};\\\", \\\"{x:1603,y:892,t:1528143481187};\\\", \\\"{x:1595,y:892,t:1528143481204};\\\", \\\"{x:1589,y:892,t:1528143481221};\\\", \\\"{x:1581,y:892,t:1528143481237};\\\", \\\"{x:1573,y:892,t:1528143481254};\\\", \\\"{x:1566,y:892,t:1528143481271};\\\", \\\"{x:1564,y:892,t:1528143481289};\\\", \\\"{x:1561,y:892,t:1528143481304};\\\", \\\"{x:1552,y:892,t:1528143481321};\\\", \\\"{x:1548,y:892,t:1528143481337};\\\", \\\"{x:1542,y:892,t:1528143481354};\\\", \\\"{x:1537,y:892,t:1528143481372};\\\", \\\"{x:1531,y:892,t:1528143481387};\\\", \\\"{x:1526,y:892,t:1528143481404};\\\", \\\"{x:1519,y:893,t:1528143481422};\\\", \\\"{x:1514,y:893,t:1528143481438};\\\", \\\"{x:1507,y:893,t:1528143481454};\\\", \\\"{x:1503,y:893,t:1528143481472};\\\", \\\"{x:1500,y:893,t:1528143481488};\\\", \\\"{x:1493,y:893,t:1528143481505};\\\", \\\"{x:1487,y:893,t:1528143481522};\\\", \\\"{x:1483,y:893,t:1528143481539};\\\", \\\"{x:1477,y:893,t:1528143481554};\\\", \\\"{x:1474,y:893,t:1528143481572};\\\", \\\"{x:1470,y:893,t:1528143481588};\\\", \\\"{x:1467,y:893,t:1528143481605};\\\", \\\"{x:1464,y:893,t:1528143481621};\\\", \\\"{x:1459,y:893,t:1528143481638};\\\", \\\"{x:1453,y:893,t:1528143481654};\\\", \\\"{x:1448,y:893,t:1528143481672};\\\", \\\"{x:1440,y:893,t:1528143481688};\\\", \\\"{x:1433,y:893,t:1528143481705};\\\", \\\"{x:1428,y:893,t:1528143481721};\\\", \\\"{x:1421,y:893,t:1528143481738};\\\", \\\"{x:1419,y:893,t:1528143481755};\\\", \\\"{x:1418,y:893,t:1528143481772};\\\", \\\"{x:1417,y:892,t:1528143483659};\\\", \\\"{x:1422,y:877,t:1528143483674};\\\", \\\"{x:1436,y:854,t:1528143483690};\\\", \\\"{x:1451,y:824,t:1528143483708};\\\", \\\"{x:1484,y:776,t:1528143483724};\\\", \\\"{x:1528,y:722,t:1528143483741};\\\", \\\"{x:1566,y:662,t:1528143483758};\\\", \\\"{x:1601,y:602,t:1528143483773};\\\", \\\"{x:1633,y:552,t:1528143483790};\\\", \\\"{x:1662,y:505,t:1528143483807};\\\", \\\"{x:1675,y:482,t:1528143483823};\\\", \\\"{x:1687,y:463,t:1528143483841};\\\", \\\"{x:1693,y:448,t:1528143483858};\\\", \\\"{x:1696,y:442,t:1528143483874};\\\", \\\"{x:1698,y:437,t:1528143483890};\\\", \\\"{x:1699,y:431,t:1528143483908};\\\", \\\"{x:1701,y:422,t:1528143483924};\\\", \\\"{x:1702,y:413,t:1528143483940};\\\", \\\"{x:1703,y:406,t:1528143483958};\\\", \\\"{x:1704,y:397,t:1528143483974};\\\", \\\"{x:1704,y:396,t:1528143483990};\\\", \\\"{x:1704,y:393,t:1528143484007};\\\", \\\"{x:1704,y:390,t:1528143484024};\\\", \\\"{x:1704,y:389,t:1528143484040};\\\", \\\"{x:1704,y:388,t:1528143484058};\\\", \\\"{x:1704,y:387,t:1528143484082};\\\", \\\"{x:1704,y:386,t:1528143484090};\\\", \\\"{x:1699,y:383,t:1528143484107};\\\", \\\"{x:1695,y:383,t:1528143484124};\\\", \\\"{x:1682,y:383,t:1528143484140};\\\", \\\"{x:1663,y:384,t:1528143484157};\\\", \\\"{x:1645,y:389,t:1528143484174};\\\", \\\"{x:1634,y:392,t:1528143484190};\\\", \\\"{x:1625,y:394,t:1528143484207};\\\", \\\"{x:1609,y:397,t:1528143484224};\\\", \\\"{x:1600,y:399,t:1528143484241};\\\", \\\"{x:1596,y:401,t:1528143484258};\\\", \\\"{x:1593,y:403,t:1528143484274};\\\", \\\"{x:1592,y:403,t:1528143484292};\\\", \\\"{x:1590,y:405,t:1528143484307};\\\", \\\"{x:1588,y:406,t:1528143484325};\\\", \\\"{x:1587,y:408,t:1528143484342};\\\", \\\"{x:1586,y:410,t:1528143484358};\\\", \\\"{x:1584,y:413,t:1528143484375};\\\", \\\"{x:1583,y:414,t:1528143484392};\\\", \\\"{x:1581,y:416,t:1528143484407};\\\", \\\"{x:1580,y:419,t:1528143484425};\\\", \\\"{x:1579,y:421,t:1528143484441};\\\", \\\"{x:1579,y:423,t:1528143484458};\\\", \\\"{x:1577,y:423,t:1528143484474};\\\", \\\"{x:1577,y:424,t:1528143484492};\\\", \\\"{x:1577,y:426,t:1528143484508};\\\", \\\"{x:1577,y:428,t:1528143484525};\\\", \\\"{x:1577,y:429,t:1528143484546};\\\", \\\"{x:1576,y:430,t:1528143484558};\\\", \\\"{x:1576,y:431,t:1528143484594};\\\", \\\"{x:1576,y:432,t:1528143484610};\\\", \\\"{x:1576,y:433,t:1528143484625};\\\", \\\"{x:1578,y:436,t:1528143484642};\\\", \\\"{x:1578,y:437,t:1528143484674};\\\", \\\"{x:1579,y:437,t:1528143484706};\\\", \\\"{x:1580,y:439,t:1528143484722};\\\", \\\"{x:1580,y:440,t:1528143484738};\\\", \\\"{x:1581,y:440,t:1528143484746};\\\", \\\"{x:1581,y:442,t:1528143484762};\\\", \\\"{x:1581,y:443,t:1528143484775};\\\", \\\"{x:1582,y:444,t:1528143484791};\\\", \\\"{x:1582,y:446,t:1528143484809};\\\", \\\"{x:1582,y:449,t:1528143484826};\\\", \\\"{x:1583,y:450,t:1528143484842};\\\", \\\"{x:1583,y:452,t:1528143484859};\\\", \\\"{x:1583,y:455,t:1528143484876};\\\", \\\"{x:1583,y:458,t:1528143484892};\\\", \\\"{x:1583,y:460,t:1528143484909};\\\", \\\"{x:1584,y:462,t:1528143484926};\\\", \\\"{x:1584,y:464,t:1528143484941};\\\", \\\"{x:1584,y:466,t:1528143484959};\\\", \\\"{x:1585,y:468,t:1528143484975};\\\", \\\"{x:1585,y:469,t:1528143484992};\\\", \\\"{x:1585,y:472,t:1528143485009};\\\", \\\"{x:1585,y:474,t:1528143485026};\\\", \\\"{x:1585,y:477,t:1528143485042};\\\", \\\"{x:1585,y:479,t:1528143485058};\\\", \\\"{x:1585,y:481,t:1528143485076};\\\", \\\"{x:1585,y:484,t:1528143485092};\\\", \\\"{x:1585,y:487,t:1528143485109};\\\", \\\"{x:1585,y:488,t:1528143485125};\\\", \\\"{x:1586,y:490,t:1528143485143};\\\", \\\"{x:1587,y:494,t:1528143485159};\\\", \\\"{x:1587,y:496,t:1528143485176};\\\", \\\"{x:1588,y:501,t:1528143485193};\\\", \\\"{x:1589,y:506,t:1528143485209};\\\", \\\"{x:1589,y:508,t:1528143485226};\\\", \\\"{x:1590,y:510,t:1528143485242};\\\", \\\"{x:1591,y:516,t:1528143485258};\\\", \\\"{x:1592,y:518,t:1528143485275};\\\", \\\"{x:1594,y:523,t:1528143485291};\\\", \\\"{x:1594,y:525,t:1528143485308};\\\", \\\"{x:1594,y:528,t:1528143485325};\\\", \\\"{x:1594,y:530,t:1528143485342};\\\", \\\"{x:1593,y:531,t:1528143485358};\\\", \\\"{x:1592,y:533,t:1528143485375};\\\", \\\"{x:1590,y:535,t:1528143485401};\\\", \\\"{x:1590,y:536,t:1528143485409};\\\", \\\"{x:1590,y:537,t:1528143485425};\\\", \\\"{x:1590,y:540,t:1528143485443};\\\", \\\"{x:1590,y:543,t:1528143485460};\\\", \\\"{x:1590,y:546,t:1528143485475};\\\", \\\"{x:1592,y:551,t:1528143485492};\\\", \\\"{x:1592,y:552,t:1528143485510};\\\", \\\"{x:1592,y:555,t:1528143485525};\\\", \\\"{x:1592,y:557,t:1528143485542};\\\", \\\"{x:1592,y:559,t:1528143485560};\\\", \\\"{x:1592,y:560,t:1528143485576};\\\", \\\"{x:1592,y:563,t:1528143485593};\\\", \\\"{x:1592,y:565,t:1528143485610};\\\", \\\"{x:1592,y:568,t:1528143485626};\\\", \\\"{x:1592,y:569,t:1528143485658};\\\", \\\"{x:1592,y:570,t:1528143485666};\\\", \\\"{x:1592,y:571,t:1528143485676};\\\", \\\"{x:1592,y:572,t:1528143485692};\\\", \\\"{x:1592,y:574,t:1528143485722};\\\", \\\"{x:1592,y:575,t:1528143485779};\\\", \\\"{x:1591,y:577,t:1528143485818};\\\", \\\"{x:1591,y:578,t:1528143485842};\\\", \\\"{x:1591,y:579,t:1528143485874};\\\", \\\"{x:1590,y:580,t:1528143486227};\\\", \\\"{x:1590,y:579,t:1528143486244};\\\", \\\"{x:1590,y:575,t:1528143486260};\\\", \\\"{x:1590,y:573,t:1528143486277};\\\", \\\"{x:1590,y:571,t:1528143486294};\\\", \\\"{x:1590,y:569,t:1528143486310};\\\", \\\"{x:1590,y:568,t:1528143486327};\\\", \\\"{x:1590,y:566,t:1528143486344};\\\", \\\"{x:1590,y:565,t:1528143486361};\\\", \\\"{x:1590,y:567,t:1528143486523};\\\", \\\"{x:1591,y:569,t:1528143486530};\\\", \\\"{x:1591,y:575,t:1528143486543};\\\", \\\"{x:1592,y:586,t:1528143486561};\\\", \\\"{x:1592,y:599,t:1528143486577};\\\", \\\"{x:1593,y:615,t:1528143486595};\\\", \\\"{x:1593,y:624,t:1528143486610};\\\", \\\"{x:1593,y:632,t:1528143486627};\\\", \\\"{x:1593,y:635,t:1528143486643};\\\", \\\"{x:1593,y:639,t:1528143486660};\\\", \\\"{x:1593,y:644,t:1528143486678};\\\", \\\"{x:1593,y:651,t:1528143486694};\\\", \\\"{x:1593,y:656,t:1528143486711};\\\", \\\"{x:1593,y:660,t:1528143486728};\\\", \\\"{x:1593,y:666,t:1528143486744};\\\", \\\"{x:1593,y:671,t:1528143486760};\\\", \\\"{x:1593,y:678,t:1528143486778};\\\", \\\"{x:1593,y:685,t:1528143486794};\\\", \\\"{x:1593,y:692,t:1528143486811};\\\", \\\"{x:1592,y:698,t:1528143486828};\\\", \\\"{x:1591,y:704,t:1528143486844};\\\", \\\"{x:1590,y:710,t:1528143486861};\\\", \\\"{x:1587,y:719,t:1528143486878};\\\", \\\"{x:1586,y:725,t:1528143486894};\\\", \\\"{x:1586,y:727,t:1528143486911};\\\", \\\"{x:1585,y:733,t:1528143486928};\\\", \\\"{x:1585,y:740,t:1528143486944};\\\", \\\"{x:1585,y:745,t:1528143486961};\\\", \\\"{x:1585,y:754,t:1528143486978};\\\", \\\"{x:1587,y:762,t:1528143486995};\\\", \\\"{x:1587,y:767,t:1528143487011};\\\", \\\"{x:1588,y:774,t:1528143487028};\\\", \\\"{x:1588,y:783,t:1528143487044};\\\", \\\"{x:1588,y:791,t:1528143487060};\\\", \\\"{x:1588,y:797,t:1528143487077};\\\", \\\"{x:1589,y:803,t:1528143487095};\\\", \\\"{x:1591,y:811,t:1528143487110};\\\", \\\"{x:1591,y:814,t:1528143487127};\\\", \\\"{x:1593,y:816,t:1528143487144};\\\", \\\"{x:1593,y:821,t:1528143487160};\\\", \\\"{x:1594,y:825,t:1528143487177};\\\", \\\"{x:1595,y:828,t:1528143487194};\\\", \\\"{x:1595,y:830,t:1528143487212};\\\", \\\"{x:1595,y:831,t:1528143487228};\\\", \\\"{x:1596,y:835,t:1528143487245};\\\", \\\"{x:1596,y:836,t:1528143487262};\\\", \\\"{x:1596,y:837,t:1528143487282};\\\", \\\"{x:1596,y:838,t:1528143487295};\\\", \\\"{x:1596,y:839,t:1528143487312};\\\", \\\"{x:1596,y:840,t:1528143487330};\\\", \\\"{x:1598,y:843,t:1528143487346};\\\", \\\"{x:1598,y:847,t:1528143487362};\\\", \\\"{x:1598,y:848,t:1528143487378};\\\", \\\"{x:1599,y:852,t:1528143487396};\\\", \\\"{x:1599,y:855,t:1528143487412};\\\", \\\"{x:1600,y:859,t:1528143487428};\\\", \\\"{x:1602,y:865,t:1528143487445};\\\", \\\"{x:1602,y:869,t:1528143487462};\\\", \\\"{x:1602,y:874,t:1528143487478};\\\", \\\"{x:1605,y:880,t:1528143487495};\\\", \\\"{x:1605,y:884,t:1528143487512};\\\", \\\"{x:1607,y:887,t:1528143487529};\\\", \\\"{x:1609,y:890,t:1528143487545};\\\", \\\"{x:1610,y:893,t:1528143487562};\\\", \\\"{x:1610,y:898,t:1528143487578};\\\", \\\"{x:1611,y:903,t:1528143487595};\\\", \\\"{x:1611,y:907,t:1528143487612};\\\", \\\"{x:1611,y:911,t:1528143487629};\\\", \\\"{x:1611,y:916,t:1528143487645};\\\", \\\"{x:1611,y:920,t:1528143487662};\\\", \\\"{x:1611,y:924,t:1528143487680};\\\", \\\"{x:1611,y:928,t:1528143487695};\\\", \\\"{x:1611,y:934,t:1528143487712};\\\", \\\"{x:1611,y:937,t:1528143487728};\\\", \\\"{x:1611,y:941,t:1528143487745};\\\", \\\"{x:1614,y:947,t:1528143487762};\\\", \\\"{x:1614,y:951,t:1528143487778};\\\", \\\"{x:1615,y:953,t:1528143487795};\\\", \\\"{x:1615,y:954,t:1528143487812};\\\", \\\"{x:1615,y:956,t:1528143487915};\\\", \\\"{x:1615,y:957,t:1528143487930};\\\", \\\"{x:1615,y:959,t:1528143487946};\\\", \\\"{x:1615,y:960,t:1528143487962};\\\", \\\"{x:1615,y:961,t:1528143487979};\\\", \\\"{x:1610,y:964,t:1528143487996};\\\", \\\"{x:1603,y:967,t:1528143488012};\\\", \\\"{x:1591,y:967,t:1528143488028};\\\", \\\"{x:1575,y:967,t:1528143488046};\\\", \\\"{x:1557,y:964,t:1528143488062};\\\", \\\"{x:1528,y:957,t:1528143488079};\\\", \\\"{x:1482,y:942,t:1528143488096};\\\", \\\"{x:1450,y:931,t:1528143488112};\\\", \\\"{x:1360,y:896,t:1528143488129};\\\", \\\"{x:1284,y:856,t:1528143488146};\\\", \\\"{x:1186,y:822,t:1528143488162};\\\", \\\"{x:1072,y:785,t:1528143488179};\\\", \\\"{x:962,y:735,t:1528143488196};\\\", \\\"{x:846,y:686,t:1528143488213};\\\", \\\"{x:738,y:635,t:1528143488229};\\\", \\\"{x:639,y:579,t:1528143488245};\\\", \\\"{x:579,y:544,t:1528143488265};\\\", \\\"{x:520,y:514,t:1528143488279};\\\", \\\"{x:490,y:490,t:1528143488298};\\\", \\\"{x:462,y:463,t:1528143488327};\\\", \\\"{x:455,y:453,t:1528143488343};\\\", \\\"{x:452,y:447,t:1528143488360};\\\", \\\"{x:449,y:443,t:1528143488377};\\\", \\\"{x:448,y:441,t:1528143488393};\\\", \\\"{x:445,y:436,t:1528143488410};\\\", \\\"{x:442,y:433,t:1528143488427};\\\", \\\"{x:436,y:430,t:1528143488443};\\\", \\\"{x:434,y:429,t:1528143488460};\\\", \\\"{x:433,y:429,t:1528143488476};\\\", \\\"{x:432,y:429,t:1528143488493};\\\", \\\"{x:430,y:429,t:1528143488516};\\\", \\\"{x:427,y:433,t:1528143488528};\\\", \\\"{x:422,y:439,t:1528143488543};\\\", \\\"{x:412,y:448,t:1528143488561};\\\", \\\"{x:400,y:460,t:1528143488578};\\\", \\\"{x:392,y:475,t:1528143488594};\\\", \\\"{x:389,y:489,t:1528143488611};\\\", \\\"{x:386,y:495,t:1528143488627};\\\", \\\"{x:383,y:502,t:1528143488645};\\\", \\\"{x:381,y:505,t:1528143488661};\\\", \\\"{x:380,y:507,t:1528143488679};\\\", \\\"{x:378,y:510,t:1528143488694};\\\", \\\"{x:377,y:513,t:1528143488712};\\\", \\\"{x:375,y:514,t:1528143488726};\\\", \\\"{x:374,y:514,t:1528143488781};\\\", \\\"{x:374,y:515,t:1528143488837};\\\", \\\"{x:373,y:516,t:1528143488845};\\\", \\\"{x:372,y:516,t:1528143488860};\\\", \\\"{x:371,y:516,t:1528143488877};\\\", \\\"{x:366,y:519,t:1528143488893};\\\", \\\"{x:361,y:523,t:1528143488911};\\\", \\\"{x:355,y:533,t:1528143488927};\\\", \\\"{x:347,y:538,t:1528143488945};\\\", \\\"{x:341,y:543,t:1528143488961};\\\", \\\"{x:332,y:549,t:1528143488977};\\\", \\\"{x:325,y:552,t:1528143488994};\\\", \\\"{x:321,y:554,t:1528143489011};\\\", \\\"{x:313,y:556,t:1528143489027};\\\", \\\"{x:301,y:559,t:1528143489044};\\\", \\\"{x:296,y:561,t:1528143489061};\\\", \\\"{x:292,y:563,t:1528143489077};\\\", \\\"{x:288,y:564,t:1528143489094};\\\", \\\"{x:284,y:565,t:1528143489111};\\\", \\\"{x:277,y:567,t:1528143489127};\\\", \\\"{x:276,y:568,t:1528143489144};\\\", \\\"{x:273,y:569,t:1528143489161};\\\", \\\"{x:269,y:571,t:1528143489180};\\\", \\\"{x:266,y:572,t:1528143489194};\\\", \\\"{x:262,y:574,t:1528143489211};\\\", \\\"{x:253,y:579,t:1528143489228};\\\", \\\"{x:249,y:582,t:1528143489244};\\\", \\\"{x:243,y:584,t:1528143489261};\\\", \\\"{x:231,y:594,t:1528143489278};\\\", \\\"{x:214,y:605,t:1528143489294};\\\", \\\"{x:202,y:612,t:1528143489311};\\\", \\\"{x:193,y:617,t:1528143489329};\\\", \\\"{x:183,y:623,t:1528143489345};\\\", \\\"{x:173,y:628,t:1528143489361};\\\", \\\"{x:166,y:633,t:1528143489377};\\\", \\\"{x:161,y:635,t:1528143489394};\\\", \\\"{x:160,y:636,t:1528143489411};\\\", \\\"{x:157,y:636,t:1528143489427};\\\", \\\"{x:155,y:637,t:1528143489443};\\\", \\\"{x:154,y:637,t:1528143489531};\\\", \\\"{x:157,y:637,t:1528143489900};\\\", \\\"{x:160,y:637,t:1528143489911};\\\", \\\"{x:180,y:639,t:1528143489929};\\\", \\\"{x:202,y:639,t:1528143489945};\\\", \\\"{x:215,y:639,t:1528143489961};\\\", \\\"{x:230,y:639,t:1528143489978};\\\", \\\"{x:238,y:639,t:1528143489995};\\\", \\\"{x:243,y:639,t:1528143490011};\\\", \\\"{x:252,y:640,t:1528143490028};\\\", \\\"{x:260,y:644,t:1528143490045};\\\", \\\"{x:267,y:648,t:1528143490062};\\\", \\\"{x:279,y:651,t:1528143490079};\\\", \\\"{x:288,y:654,t:1528143490095};\\\", \\\"{x:298,y:661,t:1528143490112};\\\", \\\"{x:306,y:670,t:1528143490128};\\\", \\\"{x:321,y:685,t:1528143490145};\\\", \\\"{x:340,y:707,t:1528143490162};\\\", \\\"{x:364,y:728,t:1528143490178};\\\", \\\"{x:396,y:751,t:1528143490195};\\\", \\\"{x:464,y:779,t:1528143490213};\\\", \\\"{x:519,y:793,t:1528143490229};\\\", \\\"{x:550,y:798,t:1528143490246};\\\", \\\"{x:579,y:799,t:1528143490263};\\\", \\\"{x:587,y:797,t:1528143490279};\\\", \\\"{x:589,y:795,t:1528143490296};\\\", \\\"{x:591,y:793,t:1528143490312};\\\", \\\"{x:593,y:790,t:1528143490329};\\\", \\\"{x:593,y:786,t:1528143490346};\\\", \\\"{x:593,y:785,t:1528143490365};\\\", \\\"{x:593,y:784,t:1528143490397};\\\", \\\"{x:593,y:783,t:1528143490413};\\\", \\\"{x:593,y:780,t:1528143490429};\\\", \\\"{x:593,y:778,t:1528143490446};\\\", \\\"{x:593,y:777,t:1528143490462};\\\", \\\"{x:593,y:775,t:1528143490479};\\\", \\\"{x:592,y:772,t:1528143490495};\\\", \\\"{x:590,y:770,t:1528143490513};\\\", \\\"{x:586,y:766,t:1528143490529};\\\", \\\"{x:578,y:758,t:1528143490546};\\\", \\\"{x:569,y:747,t:1528143490563};\\\", \\\"{x:563,y:739,t:1528143490580};\\\", \\\"{x:559,y:734,t:1528143490595};\\\", \\\"{x:554,y:726,t:1528143490612};\\\", \\\"{x:547,y:720,t:1528143490628};\\\", \\\"{x:543,y:717,t:1528143490645};\\\", \\\"{x:536,y:715,t:1528143490661};\\\", \\\"{x:532,y:713,t:1528143490679};\\\", \\\"{x:531,y:711,t:1528143490694};\\\", \\\"{x:530,y:711,t:1528143490712};\\\", \\\"{x:528,y:710,t:1528143490729};\\\", \\\"{x:526,y:709,t:1528143490745};\\\", \\\"{x:524,y:709,t:1528143490762};\\\", \\\"{x:522,y:709,t:1528143490779};\\\", \\\"{x:521,y:709,t:1528143490795};\\\", \\\"{x:521,y:708,t:1528143490819};\\\" ] }, { \\\"rt\\\": 26064, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 510313, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:705,t:1528143495173};\\\", \\\"{x:543,y:693,t:1528143495186};\\\", \\\"{x:565,y:676,t:1528143495202};\\\", \\\"{x:570,y:671,t:1528143495217};\\\", \\\"{x:600,y:657,t:1528143495233};\\\", \\\"{x:671,y:638,t:1528143495250};\\\", \\\"{x:750,y:622,t:1528143495266};\\\", \\\"{x:873,y:601,t:1528143495282};\\\", \\\"{x:983,y:591,t:1528143495300};\\\", \\\"{x:1145,y:571,t:1528143495315};\\\", \\\"{x:1261,y:553,t:1528143495332};\\\", \\\"{x:1353,y:541,t:1528143495349};\\\", \\\"{x:1460,y:534,t:1528143495366};\\\", \\\"{x:1546,y:534,t:1528143495382};\\\", \\\"{x:1625,y:530,t:1528143495399};\\\", \\\"{x:1682,y:519,t:1528143495416};\\\", \\\"{x:1725,y:512,t:1528143495432};\\\", \\\"{x:1751,y:508,t:1528143495450};\\\", \\\"{x:1774,y:500,t:1528143495466};\\\", \\\"{x:1793,y:498,t:1528143495483};\\\", \\\"{x:1809,y:493,t:1528143495499};\\\", \\\"{x:1832,y:485,t:1528143495517};\\\", \\\"{x:1838,y:483,t:1528143495533};\\\", \\\"{x:1839,y:482,t:1528143495549};\\\", \\\"{x:1840,y:482,t:1528143495567};\\\", \\\"{x:1840,y:483,t:1528143495612};\\\", \\\"{x:1831,y:486,t:1528143495620};\\\", \\\"{x:1821,y:490,t:1528143495634};\\\", \\\"{x:1808,y:494,t:1528143495649};\\\", \\\"{x:1786,y:495,t:1528143495666};\\\", \\\"{x:1764,y:498,t:1528143495684};\\\", \\\"{x:1751,y:505,t:1528143495699};\\\", \\\"{x:1742,y:510,t:1528143495716};\\\", \\\"{x:1726,y:517,t:1528143495734};\\\", \\\"{x:1720,y:524,t:1528143495750};\\\", \\\"{x:1694,y:530,t:1528143495767};\\\", \\\"{x:1677,y:537,t:1528143495784};\\\", \\\"{x:1662,y:545,t:1528143495800};\\\", \\\"{x:1641,y:556,t:1528143495816};\\\", \\\"{x:1627,y:564,t:1528143495834};\\\", \\\"{x:1608,y:575,t:1528143495850};\\\", \\\"{x:1585,y:586,t:1528143495867};\\\", \\\"{x:1556,y:594,t:1528143495884};\\\", \\\"{x:1533,y:598,t:1528143495900};\\\", \\\"{x:1515,y:605,t:1528143495917};\\\", \\\"{x:1497,y:614,t:1528143495934};\\\", \\\"{x:1492,y:619,t:1528143495950};\\\", \\\"{x:1488,y:619,t:1528143495967};\\\", \\\"{x:1485,y:623,t:1528143495984};\\\", \\\"{x:1478,y:628,t:1528143496001};\\\", \\\"{x:1476,y:631,t:1528143496017};\\\", \\\"{x:1473,y:633,t:1528143496034};\\\", \\\"{x:1470,y:636,t:1528143496052};\\\", \\\"{x:1467,y:639,t:1528143496067};\\\", \\\"{x:1465,y:642,t:1528143496084};\\\", \\\"{x:1462,y:648,t:1528143496101};\\\", \\\"{x:1453,y:656,t:1528143496117};\\\", \\\"{x:1444,y:669,t:1528143496134};\\\", \\\"{x:1438,y:675,t:1528143496151};\\\", \\\"{x:1423,y:687,t:1528143496167};\\\", \\\"{x:1414,y:697,t:1528143496185};\\\", \\\"{x:1399,y:710,t:1528143496202};\\\", \\\"{x:1381,y:726,t:1528143496217};\\\", \\\"{x:1355,y:747,t:1528143496234};\\\", \\\"{x:1328,y:768,t:1528143496251};\\\", \\\"{x:1299,y:788,t:1528143496267};\\\", \\\"{x:1276,y:804,t:1528143496284};\\\", \\\"{x:1249,y:820,t:1528143496301};\\\", \\\"{x:1232,y:831,t:1528143496316};\\\", \\\"{x:1220,y:837,t:1528143496334};\\\", \\\"{x:1213,y:840,t:1528143496351};\\\", \\\"{x:1208,y:842,t:1528143496368};\\\", \\\"{x:1205,y:843,t:1528143496384};\\\", \\\"{x:1201,y:845,t:1528143496401};\\\", \\\"{x:1199,y:846,t:1528143496418};\\\", \\\"{x:1198,y:846,t:1528143496437};\\\", \\\"{x:1197,y:847,t:1528143496453};\\\", \\\"{x:1197,y:845,t:1528143496709};\\\", \\\"{x:1197,y:844,t:1528143496829};\\\", \\\"{x:1197,y:842,t:1528143496925};\\\", \\\"{x:1197,y:841,t:1528143496997};\\\", \\\"{x:1197,y:839,t:1528143497029};\\\", \\\"{x:1198,y:838,t:1528143497037};\\\", \\\"{x:1199,y:837,t:1528143497069};\\\", \\\"{x:1201,y:837,t:1528143497085};\\\", \\\"{x:1202,y:837,t:1528143497101};\\\", \\\"{x:1204,y:836,t:1528143497118};\\\", \\\"{x:1205,y:835,t:1528143497149};\\\", \\\"{x:1206,y:834,t:1528143497172};\\\", \\\"{x:1207,y:834,t:1528143497189};\\\", \\\"{x:1208,y:834,t:1528143497421};\\\", \\\"{x:1210,y:834,t:1528143503789};\\\", \\\"{x:1211,y:834,t:1528143503810};\\\", \\\"{x:1212,y:834,t:1528143503823};\\\", \\\"{x:1214,y:834,t:1528143503840};\\\", \\\"{x:1216,y:834,t:1528143505733};\\\", \\\"{x:1220,y:834,t:1528143505744};\\\", \\\"{x:1226,y:835,t:1528143505758};\\\", \\\"{x:1229,y:835,t:1528143505776};\\\", \\\"{x:1235,y:835,t:1528143505793};\\\", \\\"{x:1237,y:835,t:1528143505808};\\\", \\\"{x:1239,y:835,t:1528143505825};\\\", \\\"{x:1243,y:835,t:1528143505842};\\\", \\\"{x:1249,y:835,t:1528143505859};\\\", \\\"{x:1254,y:835,t:1528143505876};\\\", \\\"{x:1261,y:835,t:1528143505893};\\\", \\\"{x:1265,y:835,t:1528143505909};\\\", \\\"{x:1268,y:834,t:1528143505926};\\\", \\\"{x:1272,y:833,t:1528143505943};\\\", \\\"{x:1276,y:833,t:1528143505959};\\\", \\\"{x:1284,y:832,t:1528143505976};\\\", \\\"{x:1292,y:830,t:1528143505994};\\\", \\\"{x:1301,y:830,t:1528143506009};\\\", \\\"{x:1307,y:830,t:1528143506025};\\\", \\\"{x:1319,y:830,t:1528143506042};\\\", \\\"{x:1327,y:830,t:1528143506059};\\\", \\\"{x:1335,y:828,t:1528143506076};\\\", \\\"{x:1341,y:828,t:1528143506093};\\\", \\\"{x:1349,y:828,t:1528143506109};\\\", \\\"{x:1358,y:827,t:1528143506126};\\\", \\\"{x:1364,y:827,t:1528143506143};\\\", \\\"{x:1370,y:827,t:1528143506160};\\\", \\\"{x:1375,y:827,t:1528143506176};\\\", \\\"{x:1374,y:827,t:1528143506437};\\\", \\\"{x:1372,y:828,t:1528143506445};\\\", \\\"{x:1371,y:829,t:1528143506460};\\\", \\\"{x:1368,y:829,t:1528143506476};\\\", \\\"{x:1364,y:832,t:1528143506492};\\\", \\\"{x:1363,y:832,t:1528143506629};\\\", \\\"{x:1361,y:832,t:1528143506645};\\\", \\\"{x:1360,y:833,t:1528143506685};\\\", \\\"{x:1359,y:834,t:1528143506750};\\\", \\\"{x:1358,y:835,t:1528143506759};\\\", \\\"{x:1356,y:835,t:1528143506776};\\\", \\\"{x:1354,y:835,t:1528143506793};\\\", \\\"{x:1354,y:836,t:1528143506809};\\\", \\\"{x:1353,y:836,t:1528143506827};\\\", \\\"{x:1352,y:837,t:1528143506843};\\\", \\\"{x:1351,y:838,t:1528143506869};\\\", \\\"{x:1350,y:838,t:1528143506909};\\\", \\\"{x:1349,y:838,t:1528143507629};\\\", \\\"{x:1349,y:839,t:1528143507644};\\\", \\\"{x:1348,y:839,t:1528143507661};\\\", \\\"{x:1347,y:839,t:1528143507726};\\\", \\\"{x:1347,y:840,t:1528143508845};\\\", \\\"{x:1346,y:840,t:1528143511141};\\\", \\\"{x:1342,y:840,t:1528143511148};\\\", \\\"{x:1330,y:837,t:1528143511165};\\\", \\\"{x:1310,y:825,t:1528143511180};\\\", \\\"{x:1271,y:799,t:1528143511197};\\\", \\\"{x:1200,y:772,t:1528143511213};\\\", \\\"{x:1114,y:731,t:1528143511230};\\\", \\\"{x:1072,y:703,t:1528143511247};\\\", \\\"{x:987,y:666,t:1528143511264};\\\", \\\"{x:895,y:620,t:1528143511280};\\\", \\\"{x:813,y:591,t:1528143511297};\\\", \\\"{x:746,y:555,t:1528143511314};\\\", \\\"{x:685,y:530,t:1528143511330};\\\", \\\"{x:631,y:509,t:1528143511346};\\\", \\\"{x:588,y:494,t:1528143511362};\\\", \\\"{x:562,y:481,t:1528143511379};\\\", \\\"{x:524,y:468,t:1528143511395};\\\", \\\"{x:510,y:461,t:1528143511412};\\\", \\\"{x:505,y:461,t:1528143511429};\\\", \\\"{x:503,y:461,t:1528143511446};\\\", \\\"{x:497,y:462,t:1528143511463};\\\", \\\"{x:493,y:465,t:1528143511479};\\\", \\\"{x:488,y:469,t:1528143511496};\\\", \\\"{x:484,y:473,t:1528143511513};\\\", \\\"{x:467,y:487,t:1528143511529};\\\", \\\"{x:453,y:503,t:1528143511546};\\\", \\\"{x:441,y:515,t:1528143511564};\\\", \\\"{x:425,y:526,t:1528143511580};\\\", \\\"{x:422,y:530,t:1528143511595};\\\", \\\"{x:410,y:542,t:1528143511612};\\\", \\\"{x:401,y:554,t:1528143511630};\\\", \\\"{x:392,y:564,t:1528143511646};\\\", \\\"{x:380,y:580,t:1528143511663};\\\", \\\"{x:369,y:593,t:1528143511680};\\\", \\\"{x:359,y:603,t:1528143511696};\\\", \\\"{x:356,y:607,t:1528143511713};\\\", \\\"{x:355,y:610,t:1528143511729};\\\", \\\"{x:354,y:611,t:1528143511746};\\\", \\\"{x:362,y:610,t:1528143511861};\\\", \\\"{x:363,y:609,t:1528143511868};\\\", \\\"{x:369,y:608,t:1528143511880};\\\", \\\"{x:381,y:608,t:1528143511898};\\\", \\\"{x:396,y:606,t:1528143511913};\\\", \\\"{x:424,y:606,t:1528143511930};\\\", \\\"{x:456,y:605,t:1528143511946};\\\", \\\"{x:490,y:602,t:1528143511963};\\\", \\\"{x:531,y:602,t:1528143511980};\\\", \\\"{x:559,y:602,t:1528143511996};\\\", \\\"{x:586,y:602,t:1528143512013};\\\", \\\"{x:609,y:602,t:1528143512029};\\\", \\\"{x:629,y:602,t:1528143512047};\\\", \\\"{x:642,y:602,t:1528143512063};\\\", \\\"{x:655,y:600,t:1528143512080};\\\", \\\"{x:663,y:597,t:1528143512096};\\\", \\\"{x:671,y:592,t:1528143512113};\\\", \\\"{x:681,y:588,t:1528143512130};\\\", \\\"{x:684,y:585,t:1528143512146};\\\", \\\"{x:686,y:584,t:1528143512163};\\\", \\\"{x:687,y:583,t:1528143512180};\\\", \\\"{x:687,y:582,t:1528143512196};\\\", \\\"{x:687,y:581,t:1528143512300};\\\", \\\"{x:682,y:581,t:1528143512313};\\\", \\\"{x:676,y:581,t:1528143512330};\\\", \\\"{x:666,y:579,t:1528143512346};\\\", \\\"{x:654,y:576,t:1528143512363};\\\", \\\"{x:633,y:571,t:1528143512380};\\\", \\\"{x:613,y:566,t:1528143512396};\\\", \\\"{x:591,y:562,t:1528143512413};\\\", \\\"{x:585,y:559,t:1528143512430};\\\", \\\"{x:577,y:557,t:1528143512446};\\\", \\\"{x:569,y:555,t:1528143512463};\\\", \\\"{x:566,y:555,t:1528143512480};\\\", \\\"{x:565,y:555,t:1528143512541};\\\", \\\"{x:562,y:555,t:1528143512556};\\\", \\\"{x:560,y:555,t:1528143512564};\\\", \\\"{x:556,y:555,t:1528143512581};\\\", \\\"{x:550,y:555,t:1528143512597};\\\", \\\"{x:541,y:556,t:1528143512614};\\\", \\\"{x:523,y:556,t:1528143512630};\\\", \\\"{x:500,y:556,t:1528143512647};\\\", \\\"{x:477,y:556,t:1528143512666};\\\", \\\"{x:447,y:551,t:1528143512680};\\\", \\\"{x:425,y:545,t:1528143512697};\\\", \\\"{x:398,y:540,t:1528143512715};\\\", \\\"{x:386,y:534,t:1528143512730};\\\", \\\"{x:358,y:532,t:1528143512747};\\\", \\\"{x:335,y:527,t:1528143512763};\\\", \\\"{x:314,y:523,t:1528143512780};\\\", \\\"{x:298,y:521,t:1528143512797};\\\", \\\"{x:287,y:519,t:1528143512813};\\\", \\\"{x:277,y:518,t:1528143512831};\\\", \\\"{x:264,y:517,t:1528143512848};\\\", \\\"{x:250,y:514,t:1528143512863};\\\", \\\"{x:235,y:514,t:1528143512880};\\\", \\\"{x:218,y:514,t:1528143512897};\\\", \\\"{x:202,y:514,t:1528143512915};\\\", \\\"{x:179,y:514,t:1528143512932};\\\", \\\"{x:158,y:514,t:1528143512948};\\\", \\\"{x:146,y:514,t:1528143512963};\\\", \\\"{x:131,y:514,t:1528143512980};\\\", \\\"{x:129,y:515,t:1528143512997};\\\", \\\"{x:128,y:515,t:1528143513067};\\\", \\\"{x:127,y:517,t:1528143513080};\\\", \\\"{x:127,y:518,t:1528143513132};\\\", \\\"{x:127,y:519,t:1528143513156};\\\", \\\"{x:127,y:520,t:1528143513164};\\\", \\\"{x:127,y:521,t:1528143513188};\\\", \\\"{x:127,y:522,t:1528143513268};\\\", \\\"{x:127,y:523,t:1528143513280};\\\", \\\"{x:127,y:525,t:1528143513307};\\\", \\\"{x:127,y:527,t:1528143513316};\\\", \\\"{x:127,y:528,t:1528143513330};\\\", \\\"{x:131,y:532,t:1528143513347};\\\", \\\"{x:135,y:538,t:1528143513364};\\\", \\\"{x:143,y:544,t:1528143513381};\\\", \\\"{x:149,y:550,t:1528143513397};\\\", \\\"{x:153,y:553,t:1528143513414};\\\", \\\"{x:158,y:559,t:1528143513431};\\\", \\\"{x:162,y:561,t:1528143513447};\\\", \\\"{x:165,y:563,t:1528143513465};\\\", \\\"{x:166,y:563,t:1528143513481};\\\", \\\"{x:167,y:563,t:1528143514100};\\\", \\\"{x:170,y:567,t:1528143514115};\\\", \\\"{x:202,y:585,t:1528143514133};\\\", \\\"{x:225,y:596,t:1528143514148};\\\", \\\"{x:257,y:609,t:1528143514164};\\\", \\\"{x:279,y:626,t:1528143514182};\\\", \\\"{x:323,y:642,t:1528143514198};\\\", \\\"{x:349,y:653,t:1528143514215};\\\", \\\"{x:377,y:666,t:1528143514231};\\\", \\\"{x:397,y:672,t:1528143514249};\\\", \\\"{x:416,y:680,t:1528143514265};\\\", \\\"{x:430,y:685,t:1528143514281};\\\", \\\"{x:442,y:687,t:1528143514299};\\\", \\\"{x:448,y:687,t:1528143514314};\\\", \\\"{x:452,y:688,t:1528143514332};\\\", \\\"{x:455,y:689,t:1528143514349};\\\", \\\"{x:457,y:690,t:1528143514364};\\\", \\\"{x:466,y:691,t:1528143514382};\\\", \\\"{x:477,y:694,t:1528143514399};\\\", \\\"{x:486,y:695,t:1528143514415};\\\", \\\"{x:497,y:699,t:1528143514431};\\\", \\\"{x:499,y:700,t:1528143514449};\\\", \\\"{x:500,y:700,t:1528143514465};\\\", \\\"{x:501,y:701,t:1528143514766};\\\", \\\"{x:502,y:705,t:1528143514782};\\\", \\\"{x:503,y:707,t:1528143514798};\\\", \\\"{x:503,y:708,t:1528143514821};\\\", \\\"{x:503,y:709,t:1528143514837};\\\", \\\"{x:504,y:709,t:1528143514849};\\\", \\\"{x:504,y:710,t:1528143514924};\\\", \\\"{x:504,y:711,t:1528143514997};\\\" ] }, { \\\"rt\\\": 76250, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 587835, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 3, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -Z -Z -F -F -O -O -U -U -U -H -06 PM-05 PM-K -G -G -K -U -Z -2\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:711,t:1528143524485};\\\", \\\"{x:510,y:711,t:1528143524498};\\\", \\\"{x:527,y:717,t:1528143524514};\\\", \\\"{x:539,y:719,t:1528143524531};\\\", \\\"{x:572,y:730,t:1528143524550};\\\", \\\"{x:595,y:737,t:1528143524565};\\\", \\\"{x:612,y:745,t:1528143524580};\\\", \\\"{x:624,y:747,t:1528143524590};\\\", \\\"{x:651,y:756,t:1528143524606};\\\", \\\"{x:678,y:764,t:1528143524623};\\\", \\\"{x:703,y:770,t:1528143524640};\\\", \\\"{x:720,y:776,t:1528143524656};\\\", \\\"{x:736,y:784,t:1528143524672};\\\", \\\"{x:754,y:790,t:1528143524689};\\\", \\\"{x:770,y:792,t:1528143524706};\\\", \\\"{x:786,y:797,t:1528143524723};\\\", \\\"{x:807,y:801,t:1528143524740};\\\", \\\"{x:813,y:806,t:1528143524756};\\\", \\\"{x:821,y:810,t:1528143524774};\\\", \\\"{x:839,y:814,t:1528143524790};\\\", \\\"{x:849,y:815,t:1528143524807};\\\", \\\"{x:867,y:819,t:1528143524824};\\\", \\\"{x:890,y:823,t:1528143524840};\\\", \\\"{x:904,y:826,t:1528143524857};\\\", \\\"{x:922,y:830,t:1528143524874};\\\", \\\"{x:939,y:832,t:1528143524890};\\\", \\\"{x:957,y:836,t:1528143524907};\\\", \\\"{x:968,y:837,t:1528143524923};\\\", \\\"{x:969,y:840,t:1528143524940};\\\", \\\"{x:975,y:843,t:1528143524957};\\\", \\\"{x:987,y:844,t:1528143524973};\\\", \\\"{x:1000,y:845,t:1528143524990};\\\", \\\"{x:1015,y:848,t:1528143525008};\\\", \\\"{x:1028,y:850,t:1528143525025};\\\", \\\"{x:1029,y:850,t:1528143525041};\\\", \\\"{x:1042,y:853,t:1528143525057};\\\", \\\"{x:1054,y:854,t:1528143525075};\\\", \\\"{x:1069,y:857,t:1528143525090};\\\", \\\"{x:1071,y:857,t:1528143525107};\\\", \\\"{x:1091,y:862,t:1528143525124};\\\", \\\"{x:1099,y:863,t:1528143525140};\\\", \\\"{x:1106,y:864,t:1528143525157};\\\", \\\"{x:1116,y:867,t:1528143525174};\\\", \\\"{x:1124,y:869,t:1528143525191};\\\", \\\"{x:1130,y:871,t:1528143525207};\\\", \\\"{x:1138,y:872,t:1528143525225};\\\", \\\"{x:1145,y:875,t:1528143525240};\\\", \\\"{x:1149,y:875,t:1528143525258};\\\", \\\"{x:1156,y:876,t:1528143525274};\\\", \\\"{x:1164,y:880,t:1528143525291};\\\", \\\"{x:1173,y:881,t:1528143525307};\\\", \\\"{x:1184,y:882,t:1528143525325};\\\", \\\"{x:1194,y:884,t:1528143525340};\\\", \\\"{x:1202,y:884,t:1528143525358};\\\", \\\"{x:1208,y:886,t:1528143525374};\\\", \\\"{x:1218,y:888,t:1528143525390};\\\", \\\"{x:1222,y:888,t:1528143525408};\\\", \\\"{x:1229,y:888,t:1528143525424};\\\", \\\"{x:1233,y:888,t:1528143525441};\\\", \\\"{x:1246,y:892,t:1528143525458};\\\", \\\"{x:1257,y:894,t:1528143525475};\\\", \\\"{x:1267,y:896,t:1528143525492};\\\", \\\"{x:1277,y:900,t:1528143525508};\\\", \\\"{x:1295,y:903,t:1528143525525};\\\", \\\"{x:1304,y:907,t:1528143525540};\\\", \\\"{x:1311,y:907,t:1528143525558};\\\", \\\"{x:1318,y:909,t:1528143525574};\\\", \\\"{x:1330,y:912,t:1528143525592};\\\", \\\"{x:1346,y:913,t:1528143525608};\\\", \\\"{x:1354,y:915,t:1528143525625};\\\", \\\"{x:1360,y:915,t:1528143525642};\\\", \\\"{x:1361,y:915,t:1528143525658};\\\", \\\"{x:1363,y:917,t:1528143525674};\\\", \\\"{x:1364,y:917,t:1528143525692};\\\", \\\"{x:1367,y:917,t:1528143525708};\\\", \\\"{x:1367,y:918,t:1528143525725};\\\", \\\"{x:1369,y:918,t:1528143525742};\\\", \\\"{x:1370,y:918,t:1528143525765};\\\", \\\"{x:1372,y:918,t:1528143525781};\\\", \\\"{x:1374,y:918,t:1528143525805};\\\", \\\"{x:1375,y:918,t:1528143525828};\\\", \\\"{x:1376,y:918,t:1528143525842};\\\", \\\"{x:1378,y:918,t:1528143525982};\\\", \\\"{x:1378,y:917,t:1528143526189};\\\", \\\"{x:1378,y:916,t:1528143526197};\\\", \\\"{x:1377,y:916,t:1528143526209};\\\", \\\"{x:1376,y:915,t:1528143526224};\\\", \\\"{x:1373,y:915,t:1528143526241};\\\", \\\"{x:1370,y:915,t:1528143526258};\\\", \\\"{x:1367,y:913,t:1528143526275};\\\", \\\"{x:1363,y:913,t:1528143526292};\\\", \\\"{x:1360,y:911,t:1528143526309};\\\", \\\"{x:1357,y:911,t:1528143526324};\\\", \\\"{x:1354,y:910,t:1528143526341};\\\", \\\"{x:1351,y:909,t:1528143526359};\\\", \\\"{x:1349,y:909,t:1528143526375};\\\", \\\"{x:1349,y:908,t:1528143526392};\\\", \\\"{x:1347,y:907,t:1528143526409};\\\", \\\"{x:1346,y:907,t:1528143526425};\\\", \\\"{x:1345,y:906,t:1528143526453};\\\", \\\"{x:1343,y:906,t:1528143526677};\\\", \\\"{x:1342,y:906,t:1528143526700};\\\", \\\"{x:1341,y:906,t:1528143526732};\\\", \\\"{x:1340,y:906,t:1528143526742};\\\", \\\"{x:1339,y:906,t:1528143526797};\\\", \\\"{x:1337,y:906,t:1528143526837};\\\", \\\"{x:1336,y:906,t:1528143526917};\\\", \\\"{x:1334,y:906,t:1528143526940};\\\", \\\"{x:1333,y:906,t:1528143526997};\\\", \\\"{x:1330,y:906,t:1528143527021};\\\", \\\"{x:1329,y:906,t:1528143527053};\\\", \\\"{x:1328,y:906,t:1528143527077};\\\", \\\"{x:1327,y:906,t:1528143527092};\\\", \\\"{x:1324,y:906,t:1528143527108};\\\", \\\"{x:1323,y:905,t:1528143527133};\\\", \\\"{x:1321,y:905,t:1528143527142};\\\", \\\"{x:1320,y:905,t:1528143527159};\\\", \\\"{x:1317,y:905,t:1528143527176};\\\", \\\"{x:1316,y:905,t:1528143527193};\\\", \\\"{x:1311,y:905,t:1528143527209};\\\", \\\"{x:1309,y:904,t:1528143527225};\\\", \\\"{x:1307,y:904,t:1528143527242};\\\", \\\"{x:1305,y:903,t:1528143527259};\\\", \\\"{x:1304,y:902,t:1528143527277};\\\", \\\"{x:1303,y:902,t:1528143527293};\\\", \\\"{x:1300,y:902,t:1528143527308};\\\", \\\"{x:1297,y:902,t:1528143527326};\\\", \\\"{x:1294,y:902,t:1528143527342};\\\", \\\"{x:1293,y:901,t:1528143527359};\\\", \\\"{x:1290,y:901,t:1528143527375};\\\", \\\"{x:1287,y:901,t:1528143527393};\\\", \\\"{x:1286,y:901,t:1528143527409};\\\", \\\"{x:1284,y:901,t:1528143527426};\\\", \\\"{x:1283,y:901,t:1528143527443};\\\", \\\"{x:1281,y:901,t:1528143527459};\\\", \\\"{x:1280,y:901,t:1528143527485};\\\", \\\"{x:1279,y:901,t:1528143527565};\\\", \\\"{x:1277,y:901,t:1528143527629};\\\", \\\"{x:1274,y:901,t:1528143527661};\\\", \\\"{x:1273,y:901,t:1528143527733};\\\", \\\"{x:1271,y:901,t:1528143527749};\\\", \\\"{x:1270,y:901,t:1528143527845};\\\", \\\"{x:1269,y:901,t:1528143527885};\\\", \\\"{x:1268,y:901,t:1528143527900};\\\", \\\"{x:1267,y:901,t:1528143527941};\\\", \\\"{x:1266,y:902,t:1528143527949};\\\", \\\"{x:1266,y:901,t:1528143530469};\\\", \\\"{x:1263,y:895,t:1528143530478};\\\", \\\"{x:1253,y:885,t:1528143530495};\\\", \\\"{x:1243,y:875,t:1528143530512};\\\", \\\"{x:1235,y:869,t:1528143530528};\\\", \\\"{x:1230,y:862,t:1528143530545};\\\", \\\"{x:1227,y:857,t:1528143530562};\\\", \\\"{x:1223,y:853,t:1528143530578};\\\", \\\"{x:1222,y:853,t:1528143530595};\\\", \\\"{x:1221,y:853,t:1528143530965};\\\", \\\"{x:1221,y:856,t:1528143530979};\\\", \\\"{x:1221,y:859,t:1528143530995};\\\", \\\"{x:1221,y:866,t:1528143531012};\\\", \\\"{x:1222,y:871,t:1528143531028};\\\", \\\"{x:1222,y:873,t:1528143531045};\\\", \\\"{x:1224,y:876,t:1528143531062};\\\", \\\"{x:1224,y:878,t:1528143531078};\\\", \\\"{x:1224,y:880,t:1528143531095};\\\", \\\"{x:1224,y:881,t:1528143531112};\\\", \\\"{x:1223,y:881,t:1528143531203};\\\", \\\"{x:1221,y:879,t:1528143531211};\\\", \\\"{x:1221,y:878,t:1528143531228};\\\", \\\"{x:1220,y:876,t:1528143531267};\\\", \\\"{x:1220,y:874,t:1528143531278};\\\", \\\"{x:1218,y:867,t:1528143531294};\\\", \\\"{x:1218,y:862,t:1528143531311};\\\", \\\"{x:1218,y:861,t:1528143531328};\\\", \\\"{x:1218,y:858,t:1528143531345};\\\", \\\"{x:1218,y:855,t:1528143531362};\\\", \\\"{x:1218,y:852,t:1528143531379};\\\", \\\"{x:1218,y:850,t:1528143531395};\\\", \\\"{x:1218,y:848,t:1528143531411};\\\", \\\"{x:1218,y:846,t:1528143531429};\\\", \\\"{x:1218,y:845,t:1528143531893};\\\", \\\"{x:1218,y:843,t:1528143531909};\\\", \\\"{x:1218,y:841,t:1528143531933};\\\", \\\"{x:1218,y:839,t:1528143531949};\\\", \\\"{x:1218,y:838,t:1528143531972};\\\", \\\"{x:1218,y:837,t:1528143531980};\\\", \\\"{x:1218,y:836,t:1528143532013};\\\", \\\"{x:1219,y:836,t:1528143532933};\\\", \\\"{x:1220,y:836,t:1528143532947};\\\", \\\"{x:1221,y:835,t:1528143532963};\\\", \\\"{x:1223,y:835,t:1528143532980};\\\", \\\"{x:1225,y:834,t:1528143533045};\\\", \\\"{x:1225,y:833,t:1528143533061};\\\", \\\"{x:1226,y:833,t:1528143533076};\\\", \\\"{x:1227,y:833,t:1528143533092};\\\", \\\"{x:1228,y:833,t:1528143533117};\\\", \\\"{x:1229,y:832,t:1528143533133};\\\", \\\"{x:1230,y:832,t:1528143533146};\\\", \\\"{x:1231,y:832,t:1528143533162};\\\", \\\"{x:1234,y:830,t:1528143533180};\\\", \\\"{x:1237,y:829,t:1528143533197};\\\", \\\"{x:1238,y:829,t:1528143533220};\\\", \\\"{x:1239,y:829,t:1528143533230};\\\", \\\"{x:1241,y:829,t:1528143533247};\\\", \\\"{x:1248,y:829,t:1528143533263};\\\", \\\"{x:1251,y:829,t:1528143533279};\\\", \\\"{x:1257,y:829,t:1528143533297};\\\", \\\"{x:1260,y:829,t:1528143533314};\\\", \\\"{x:1264,y:829,t:1528143533329};\\\", \\\"{x:1267,y:829,t:1528143533348};\\\", \\\"{x:1269,y:829,t:1528143533396};\\\", \\\"{x:1271,y:829,t:1528143533436};\\\", \\\"{x:1272,y:829,t:1528143533460};\\\", \\\"{x:1273,y:829,t:1528143533485};\\\", \\\"{x:1275,y:829,t:1528143533556};\\\", \\\"{x:1276,y:829,t:1528143534408};\\\", \\\"{x:1277,y:829,t:1528143534604};\\\", \\\"{x:1278,y:829,t:1528143534661};\\\", \\\"{x:1279,y:829,t:1528143534708};\\\", \\\"{x:1280,y:829,t:1528143534892};\\\", \\\"{x:1282,y:829,t:1528143534948};\\\", \\\"{x:1285,y:829,t:1528143534988};\\\", \\\"{x:1286,y:829,t:1528143535004};\\\", \\\"{x:1288,y:829,t:1528143535016};\\\", \\\"{x:1289,y:829,t:1528143535031};\\\", \\\"{x:1293,y:829,t:1528143535048};\\\", \\\"{x:1294,y:829,t:1528143535064};\\\", \\\"{x:1298,y:829,t:1528143535081};\\\", \\\"{x:1304,y:829,t:1528143535098};\\\", \\\"{x:1308,y:829,t:1528143535114};\\\", \\\"{x:1310,y:829,t:1528143535131};\\\", \\\"{x:1312,y:828,t:1528143535148};\\\", \\\"{x:1313,y:828,t:1528143535251};\\\", \\\"{x:1314,y:828,t:1528143535265};\\\", \\\"{x:1316,y:828,t:1528143535284};\\\", \\\"{x:1317,y:828,t:1528143535300};\\\", \\\"{x:1318,y:828,t:1528143535314};\\\", \\\"{x:1320,y:828,t:1528143535332};\\\", \\\"{x:1322,y:828,t:1528143535365};\\\", \\\"{x:1323,y:828,t:1528143535389};\\\", \\\"{x:1324,y:828,t:1528143535413};\\\", \\\"{x:1325,y:828,t:1528143535428};\\\", \\\"{x:1326,y:829,t:1528143535453};\\\", \\\"{x:1327,y:829,t:1528143535468};\\\", \\\"{x:1328,y:829,t:1528143535485};\\\", \\\"{x:1328,y:830,t:1528143535500};\\\", \\\"{x:1330,y:831,t:1528143535515};\\\", \\\"{x:1330,y:832,t:1528143535531};\\\", \\\"{x:1331,y:836,t:1528143535548};\\\", \\\"{x:1331,y:840,t:1528143535564};\\\", \\\"{x:1331,y:847,t:1528143535581};\\\", \\\"{x:1331,y:855,t:1528143535598};\\\", \\\"{x:1330,y:861,t:1528143535615};\\\", \\\"{x:1329,y:866,t:1528143535632};\\\", \\\"{x:1328,y:874,t:1528143535649};\\\", \\\"{x:1328,y:876,t:1528143535665};\\\", \\\"{x:1328,y:878,t:1528143535681};\\\", \\\"{x:1327,y:881,t:1528143535699};\\\", \\\"{x:1327,y:882,t:1528143535724};\\\", \\\"{x:1327,y:883,t:1528143535748};\\\", \\\"{x:1327,y:884,t:1528143535765};\\\", \\\"{x:1327,y:885,t:1528143535885};\\\", \\\"{x:1327,y:886,t:1528143535924};\\\", \\\"{x:1327,y:887,t:1528143535933};\\\", \\\"{x:1331,y:889,t:1528143535948};\\\", \\\"{x:1334,y:889,t:1528143535964};\\\", \\\"{x:1337,y:889,t:1528143535982};\\\", \\\"{x:1340,y:889,t:1528143535999};\\\", \\\"{x:1343,y:890,t:1528143536109};\\\", \\\"{x:1344,y:891,t:1528143536116};\\\", \\\"{x:1346,y:892,t:1528143536150};\\\", \\\"{x:1348,y:893,t:1528143536182};\\\", \\\"{x:1350,y:895,t:1528143536199};\\\", \\\"{x:1351,y:895,t:1528143537877};\\\", \\\"{x:1354,y:895,t:1528143537886};\\\", \\\"{x:1356,y:894,t:1528143537901};\\\", \\\"{x:1357,y:894,t:1528143537948};\\\", \\\"{x:1359,y:892,t:1528143539548};\\\", \\\"{x:1363,y:892,t:1528143539556};\\\", \\\"{x:1369,y:892,t:1528143539568};\\\", \\\"{x:1372,y:892,t:1528143539584};\\\", \\\"{x:1376,y:892,t:1528143539601};\\\", \\\"{x:1383,y:892,t:1528143539618};\\\", \\\"{x:1387,y:892,t:1528143539635};\\\", \\\"{x:1389,y:893,t:1528143539651};\\\", \\\"{x:1390,y:893,t:1528143539667};\\\", \\\"{x:1391,y:893,t:1528143539684};\\\", \\\"{x:1391,y:892,t:1528143540165};\\\", \\\"{x:1391,y:889,t:1528143540172};\\\", \\\"{x:1391,y:887,t:1528143540185};\\\", \\\"{x:1391,y:880,t:1528143540203};\\\", \\\"{x:1391,y:866,t:1528143540218};\\\", \\\"{x:1391,y:853,t:1528143540236};\\\", \\\"{x:1389,y:831,t:1528143540253};\\\", \\\"{x:1388,y:814,t:1528143540268};\\\", \\\"{x:1388,y:796,t:1528143540285};\\\", \\\"{x:1384,y:777,t:1528143540303};\\\", \\\"{x:1383,y:763,t:1528143540319};\\\", \\\"{x:1380,y:750,t:1528143540336};\\\", \\\"{x:1379,y:745,t:1528143540352};\\\", \\\"{x:1378,y:740,t:1528143540369};\\\", \\\"{x:1376,y:740,t:1528143540589};\\\", \\\"{x:1375,y:741,t:1528143540602};\\\", \\\"{x:1373,y:746,t:1528143540620};\\\", \\\"{x:1371,y:750,t:1528143540636};\\\", \\\"{x:1369,y:753,t:1528143540653};\\\", \\\"{x:1368,y:755,t:1528143540669};\\\", \\\"{x:1368,y:748,t:1528143544652};\\\", \\\"{x:1368,y:742,t:1528143544660};\\\", \\\"{x:1365,y:735,t:1528143544671};\\\", \\\"{x:1363,y:723,t:1528143544688};\\\", \\\"{x:1353,y:703,t:1528143544706};\\\", \\\"{x:1344,y:687,t:1528143544721};\\\", \\\"{x:1342,y:681,t:1528143544739};\\\", \\\"{x:1337,y:671,t:1528143544755};\\\", \\\"{x:1334,y:667,t:1528143544771};\\\", \\\"{x:1330,y:662,t:1528143544789};\\\", \\\"{x:1328,y:659,t:1528143544806};\\\", \\\"{x:1327,y:658,t:1528143544821};\\\", \\\"{x:1326,y:657,t:1528143544838};\\\", \\\"{x:1325,y:656,t:1528143544855};\\\", \\\"{x:1324,y:656,t:1528143544873};\\\", \\\"{x:1322,y:654,t:1528143544888};\\\", \\\"{x:1321,y:653,t:1528143544905};\\\", \\\"{x:1320,y:651,t:1528143544923};\\\", \\\"{x:1319,y:650,t:1528143544939};\\\", \\\"{x:1318,y:649,t:1528143544955};\\\", \\\"{x:1318,y:647,t:1528143544972};\\\", \\\"{x:1316,y:645,t:1528143544988};\\\", \\\"{x:1315,y:644,t:1528143545005};\\\", \\\"{x:1312,y:640,t:1528143545023};\\\", \\\"{x:1312,y:639,t:1528143545039};\\\", \\\"{x:1310,y:636,t:1528143545055};\\\", \\\"{x:1310,y:635,t:1528143545072};\\\", \\\"{x:1310,y:633,t:1528143545089};\\\", \\\"{x:1310,y:632,t:1528143545172};\\\", \\\"{x:1310,y:631,t:1528143545188};\\\", \\\"{x:1309,y:631,t:1528143545204};\\\", \\\"{x:1309,y:630,t:1528143545228};\\\", \\\"{x:1309,y:629,t:1528143545251};\\\", \\\"{x:1309,y:627,t:1528143550440};\\\", \\\"{x:1310,y:627,t:1528143550448};\\\", \\\"{x:1312,y:626,t:1528143550462};\\\", \\\"{x:1313,y:625,t:1528143550478};\\\", \\\"{x:1317,y:623,t:1528143550496};\\\", \\\"{x:1320,y:621,t:1528143550513};\\\", \\\"{x:1321,y:620,t:1528143550528};\\\", \\\"{x:1322,y:620,t:1528143550545};\\\", \\\"{x:1323,y:619,t:1528143550562};\\\", \\\"{x:1323,y:618,t:1528143550616};\\\", \\\"{x:1323,y:617,t:1528143550628};\\\", \\\"{x:1325,y:617,t:1528143550645};\\\", \\\"{x:1327,y:616,t:1528143550663};\\\", \\\"{x:1328,y:616,t:1528143550679};\\\", \\\"{x:1330,y:615,t:1528143550695};\\\", \\\"{x:1331,y:614,t:1528143550712};\\\", \\\"{x:1334,y:613,t:1528143550730};\\\", \\\"{x:1337,y:612,t:1528143550746};\\\", \\\"{x:1340,y:610,t:1528143550762};\\\", \\\"{x:1343,y:609,t:1528143550780};\\\", \\\"{x:1346,y:607,t:1528143550795};\\\", \\\"{x:1348,y:604,t:1528143550812};\\\", \\\"{x:1349,y:604,t:1528143550831};\\\", \\\"{x:1350,y:603,t:1528143550848};\\\", \\\"{x:1352,y:603,t:1528143550879};\\\", \\\"{x:1353,y:603,t:1528143550896};\\\", \\\"{x:1356,y:603,t:1528143550920};\\\", \\\"{x:1359,y:604,t:1528143550929};\\\", \\\"{x:1365,y:612,t:1528143550945};\\\", \\\"{x:1372,y:624,t:1528143550962};\\\", \\\"{x:1381,y:638,t:1528143550979};\\\", \\\"{x:1388,y:650,t:1528143550995};\\\", \\\"{x:1395,y:665,t:1528143551012};\\\", \\\"{x:1408,y:680,t:1528143551029};\\\", \\\"{x:1420,y:699,t:1528143551045};\\\", \\\"{x:1431,y:715,t:1528143551063};\\\", \\\"{x:1449,y:746,t:1528143551079};\\\", \\\"{x:1456,y:758,t:1528143551097};\\\", \\\"{x:1466,y:774,t:1528143551113};\\\", \\\"{x:1474,y:790,t:1528143551130};\\\", \\\"{x:1477,y:796,t:1528143551146};\\\", \\\"{x:1481,y:805,t:1528143551163};\\\", \\\"{x:1486,y:813,t:1528143551180};\\\", \\\"{x:1487,y:817,t:1528143551197};\\\", \\\"{x:1488,y:820,t:1528143551213};\\\", \\\"{x:1489,y:822,t:1528143551229};\\\", \\\"{x:1489,y:823,t:1528143551255};\\\", \\\"{x:1489,y:824,t:1528143551263};\\\", \\\"{x:1489,y:825,t:1528143551279};\\\", \\\"{x:1490,y:825,t:1528143551297};\\\", \\\"{x:1490,y:827,t:1528143551313};\\\", \\\"{x:1490,y:828,t:1528143551329};\\\", \\\"{x:1490,y:829,t:1528143551347};\\\", \\\"{x:1490,y:830,t:1528143553248};\\\", \\\"{x:1488,y:833,t:1528143560063};\\\", \\\"{x:1480,y:833,t:1528143560071};\\\", \\\"{x:1469,y:833,t:1528143560086};\\\", \\\"{x:1447,y:822,t:1528143560102};\\\", \\\"{x:1414,y:807,t:1528143560119};\\\", \\\"{x:1337,y:787,t:1528143560136};\\\", \\\"{x:1226,y:750,t:1528143560153};\\\", \\\"{x:1112,y:715,t:1528143560169};\\\", \\\"{x:1008,y:676,t:1528143560186};\\\", \\\"{x:899,y:635,t:1528143560204};\\\", \\\"{x:790,y:600,t:1528143560220};\\\", \\\"{x:682,y:552,t:1528143560236};\\\", \\\"{x:581,y:512,t:1528143560253};\\\", \\\"{x:417,y:447,t:1528143560289};\\\", \\\"{x:388,y:437,t:1528143560306};\\\", \\\"{x:369,y:431,t:1528143560322};\\\", \\\"{x:359,y:429,t:1528143560339};\\\", \\\"{x:352,y:428,t:1528143560355};\\\", \\\"{x:344,y:428,t:1528143560372};\\\", \\\"{x:338,y:428,t:1528143560389};\\\", \\\"{x:336,y:428,t:1528143560406};\\\", \\\"{x:331,y:428,t:1528143560422};\\\", \\\"{x:327,y:428,t:1528143560439};\\\", \\\"{x:324,y:428,t:1528143560455};\\\", \\\"{x:321,y:428,t:1528143560472};\\\", \\\"{x:320,y:428,t:1528143560551};\\\", \\\"{x:319,y:428,t:1528143560559};\\\", \\\"{x:320,y:428,t:1528143560632};\\\", \\\"{x:322,y:428,t:1528143560639};\\\", \\\"{x:328,y:428,t:1528143560655};\\\", \\\"{x:340,y:431,t:1528143560673};\\\", \\\"{x:354,y:433,t:1528143560690};\\\", \\\"{x:366,y:438,t:1528143560706};\\\", \\\"{x:385,y:448,t:1528143560723};\\\", \\\"{x:408,y:454,t:1528143560739};\\\", \\\"{x:424,y:465,t:1528143560757};\\\", \\\"{x:447,y:474,t:1528143560773};\\\", \\\"{x:465,y:481,t:1528143560789};\\\", \\\"{x:481,y:491,t:1528143560807};\\\", \\\"{x:505,y:501,t:1528143560823};\\\", \\\"{x:528,y:509,t:1528143560841};\\\", \\\"{x:536,y:512,t:1528143560857};\\\", \\\"{x:551,y:518,t:1528143560872};\\\", \\\"{x:558,y:524,t:1528143560890};\\\", \\\"{x:570,y:530,t:1528143560906};\\\", \\\"{x:574,y:532,t:1528143560923};\\\", \\\"{x:579,y:535,t:1528143560940};\\\", \\\"{x:582,y:537,t:1528143560957};\\\", \\\"{x:583,y:538,t:1528143560973};\\\", \\\"{x:585,y:539,t:1528143560989};\\\", \\\"{x:587,y:542,t:1528143561007};\\\", \\\"{x:589,y:544,t:1528143561023};\\\", \\\"{x:589,y:546,t:1528143561039};\\\", \\\"{x:590,y:547,t:1528143561057};\\\", \\\"{x:592,y:550,t:1528143561073};\\\", \\\"{x:593,y:555,t:1528143561090};\\\", \\\"{x:598,y:559,t:1528143561106};\\\", \\\"{x:601,y:561,t:1528143561124};\\\", \\\"{x:609,y:565,t:1528143561140};\\\", \\\"{x:613,y:566,t:1528143561157};\\\", \\\"{x:618,y:569,t:1528143561174};\\\", \\\"{x:624,y:573,t:1528143561190};\\\", \\\"{x:642,y:576,t:1528143561207};\\\", \\\"{x:655,y:578,t:1528143561223};\\\", \\\"{x:662,y:578,t:1528143561240};\\\", \\\"{x:670,y:578,t:1528143561256};\\\", \\\"{x:674,y:578,t:1528143561273};\\\", \\\"{x:688,y:578,t:1528143561289};\\\", \\\"{x:699,y:578,t:1528143561307};\\\", \\\"{x:707,y:579,t:1528143561324};\\\", \\\"{x:711,y:579,t:1528143561340};\\\", \\\"{x:722,y:580,t:1528143561357};\\\", \\\"{x:730,y:582,t:1528143561374};\\\", \\\"{x:733,y:582,t:1528143561389};\\\", \\\"{x:742,y:582,t:1528143561406};\\\", \\\"{x:749,y:581,t:1528143561424};\\\", \\\"{x:757,y:578,t:1528143561441};\\\", \\\"{x:763,y:576,t:1528143561456};\\\", \\\"{x:764,y:575,t:1528143561474};\\\", \\\"{x:767,y:574,t:1528143561490};\\\", \\\"{x:769,y:573,t:1528143561506};\\\", \\\"{x:767,y:574,t:1528143561591};\\\", \\\"{x:760,y:575,t:1528143561608};\\\", \\\"{x:751,y:580,t:1528143561623};\\\", \\\"{x:749,y:581,t:1528143561641};\\\", \\\"{x:747,y:583,t:1528143561656};\\\", \\\"{x:742,y:586,t:1528143561674};\\\", \\\"{x:731,y:592,t:1528143561690};\\\", \\\"{x:717,y:598,t:1528143561707};\\\", \\\"{x:691,y:607,t:1528143561723};\\\", \\\"{x:680,y:615,t:1528143561740};\\\", \\\"{x:670,y:619,t:1528143561756};\\\", \\\"{x:661,y:619,t:1528143561773};\\\", \\\"{x:655,y:619,t:1528143561790};\\\", \\\"{x:654,y:619,t:1528143561839};\\\", \\\"{x:652,y:619,t:1528143561862};\\\", \\\"{x:651,y:619,t:1528143561873};\\\", \\\"{x:649,y:618,t:1528143561894};\\\", \\\"{x:647,y:616,t:1528143561906};\\\", \\\"{x:644,y:614,t:1528143561983};\\\", \\\"{x:643,y:613,t:1528143561991};\\\", \\\"{x:636,y:609,t:1528143562007};\\\", \\\"{x:632,y:606,t:1528143562025};\\\", \\\"{x:625,y:603,t:1528143562041};\\\", \\\"{x:623,y:602,t:1528143562057};\\\", \\\"{x:620,y:600,t:1528143562073};\\\", \\\"{x:618,y:600,t:1528143562091};\\\", \\\"{x:617,y:599,t:1528143562107};\\\", \\\"{x:615,y:599,t:1528143562134};\\\", \\\"{x:614,y:599,t:1528143562150};\\\", \\\"{x:613,y:599,t:1528143562158};\\\", \\\"{x:612,y:599,t:1528143562173};\\\", \\\"{x:611,y:598,t:1528143562191};\\\", \\\"{x:610,y:598,t:1528143562208};\\\", \\\"{x:609,y:598,t:1528143562239};\\\", \\\"{x:608,y:598,t:1528143562678};\\\", \\\"{x:606,y:598,t:1528143562695};\\\", \\\"{x:606,y:600,t:1528143562707};\\\", \\\"{x:605,y:604,t:1528143562725};\\\", \\\"{x:605,y:607,t:1528143562741};\\\", \\\"{x:604,y:608,t:1528143562767};\\\", \\\"{x:604,y:609,t:1528143562776};\\\", \\\"{x:604,y:610,t:1528143562806};\\\", \\\"{x:604,y:611,t:1528143562830};\\\", \\\"{x:604,y:613,t:1528143562846};\\\", \\\"{x:604,y:614,t:1528143562870};\\\", \\\"{x:604,y:616,t:1528143562878};\\\", \\\"{x:604,y:618,t:1528143562894};\\\", \\\"{x:604,y:619,t:1528143562907};\\\", \\\"{x:604,y:622,t:1528143562925};\\\", \\\"{x:605,y:624,t:1528143562942};\\\", \\\"{x:607,y:627,t:1528143562957};\\\", \\\"{x:609,y:630,t:1528143562974};\\\", \\\"{x:609,y:632,t:1528143562992};\\\", \\\"{x:611,y:634,t:1528143563007};\\\", \\\"{x:611,y:635,t:1528143563025};\\\", \\\"{x:612,y:636,t:1528143563041};\\\", \\\"{x:616,y:636,t:1528143564832};\\\", \\\"{x:623,y:636,t:1528143564843};\\\", \\\"{x:627,y:636,t:1528143564859};\\\", \\\"{x:637,y:638,t:1528143564875};\\\", \\\"{x:662,y:642,t:1528143564894};\\\", \\\"{x:695,y:648,t:1528143564910};\\\", \\\"{x:743,y:657,t:1528143564926};\\\", \\\"{x:849,y:676,t:1528143564943};\\\", \\\"{x:937,y:699,t:1528143564960};\\\", \\\"{x:1020,y:720,t:1528143564976};\\\", \\\"{x:1110,y:741,t:1528143564993};\\\", \\\"{x:1199,y:752,t:1528143565010};\\\", \\\"{x:1286,y:770,t:1528143565025};\\\", \\\"{x:1316,y:777,t:1528143565043};\\\", \\\"{x:1365,y:785,t:1528143565060};\\\", \\\"{x:1390,y:793,t:1528143565076};\\\", \\\"{x:1412,y:799,t:1528143565093};\\\", \\\"{x:1435,y:807,t:1528143565109};\\\", \\\"{x:1476,y:811,t:1528143565127};\\\", \\\"{x:1491,y:816,t:1528143565143};\\\", \\\"{x:1505,y:818,t:1528143565160};\\\", \\\"{x:1512,y:820,t:1528143565177};\\\", \\\"{x:1517,y:821,t:1528143565192};\\\", \\\"{x:1521,y:822,t:1528143565210};\\\", \\\"{x:1522,y:822,t:1528143565728};\\\", \\\"{x:1522,y:823,t:1528143566400};\\\", \\\"{x:1521,y:825,t:1528143566414};\\\", \\\"{x:1520,y:825,t:1528143566428};\\\", \\\"{x:1513,y:825,t:1528143566444};\\\", \\\"{x:1507,y:825,t:1528143566461};\\\", \\\"{x:1500,y:825,t:1528143566477};\\\", \\\"{x:1492,y:825,t:1528143566494};\\\", \\\"{x:1476,y:824,t:1528143566511};\\\", \\\"{x:1471,y:823,t:1528143566529};\\\", \\\"{x:1468,y:823,t:1528143566545};\\\", \\\"{x:1466,y:821,t:1528143566561};\\\", \\\"{x:1461,y:821,t:1528143566578};\\\", \\\"{x:1460,y:821,t:1528143566595};\\\", \\\"{x:1457,y:821,t:1528143566611};\\\", \\\"{x:1456,y:821,t:1528143566840};\\\", \\\"{x:1456,y:820,t:1528143566863};\\\", \\\"{x:1455,y:819,t:1528143566879};\\\", \\\"{x:1454,y:818,t:1528143566896};\\\", \\\"{x:1454,y:817,t:1528143566944};\\\", \\\"{x:1454,y:815,t:1528143567320};\\\", \\\"{x:1454,y:810,t:1528143567329};\\\", \\\"{x:1452,y:801,t:1528143567346};\\\", \\\"{x:1444,y:787,t:1528143567362};\\\", \\\"{x:1436,y:773,t:1528143567378};\\\", \\\"{x:1425,y:756,t:1528143567395};\\\", \\\"{x:1415,y:734,t:1528143567412};\\\", \\\"{x:1405,y:719,t:1528143567428};\\\", \\\"{x:1395,y:699,t:1528143567446};\\\", \\\"{x:1382,y:683,t:1528143567462};\\\", \\\"{x:1372,y:668,t:1528143567479};\\\", \\\"{x:1368,y:654,t:1528143567496};\\\", \\\"{x:1362,y:647,t:1528143567513};\\\", \\\"{x:1360,y:639,t:1528143567528};\\\", \\\"{x:1359,y:632,t:1528143567546};\\\", \\\"{x:1359,y:626,t:1528143567562};\\\", \\\"{x:1359,y:619,t:1528143567578};\\\", \\\"{x:1359,y:615,t:1528143567596};\\\", \\\"{x:1359,y:607,t:1528143567612};\\\", \\\"{x:1360,y:599,t:1528143567628};\\\", \\\"{x:1361,y:593,t:1528143567645};\\\", \\\"{x:1363,y:588,t:1528143567662};\\\", \\\"{x:1364,y:585,t:1528143567679};\\\", \\\"{x:1367,y:582,t:1528143567695};\\\", \\\"{x:1369,y:579,t:1528143567713};\\\", \\\"{x:1373,y:573,t:1528143567728};\\\", \\\"{x:1376,y:569,t:1528143567746};\\\", \\\"{x:1378,y:567,t:1528143567762};\\\", \\\"{x:1379,y:566,t:1528143567780};\\\", \\\"{x:1382,y:564,t:1528143567796};\\\", \\\"{x:1384,y:562,t:1528143567812};\\\", \\\"{x:1386,y:561,t:1528143567829};\\\", \\\"{x:1387,y:561,t:1528143567845};\\\", \\\"{x:1388,y:560,t:1528143567863};\\\", \\\"{x:1389,y:559,t:1528143568152};\\\", \\\"{x:1391,y:559,t:1528143568183};\\\", \\\"{x:1392,y:559,t:1528143568223};\\\", \\\"{x:1393,y:560,t:1528143568231};\\\", \\\"{x:1394,y:561,t:1528143568327};\\\", \\\"{x:1395,y:561,t:1528143568335};\\\", \\\"{x:1396,y:562,t:1528143568375};\\\", \\\"{x:1397,y:562,t:1528143568448};\\\", \\\"{x:1397,y:563,t:1528143568463};\\\", \\\"{x:1398,y:563,t:1528143568511};\\\", \\\"{x:1399,y:564,t:1528143568559};\\\", \\\"{x:1400,y:564,t:1528143568630};\\\", \\\"{x:1401,y:564,t:1528143568670};\\\", \\\"{x:1402,y:564,t:1528143568679};\\\", \\\"{x:1404,y:565,t:1528143568718};\\\", \\\"{x:1405,y:565,t:1528143568767};\\\", \\\"{x:1406,y:565,t:1528143568779};\\\", \\\"{x:1407,y:565,t:1528143568796};\\\", \\\"{x:1408,y:565,t:1528143568823};\\\", \\\"{x:1409,y:565,t:1528143568920};\\\", \\\"{x:1410,y:565,t:1528143568984};\\\", \\\"{x:1410,y:566,t:1528143569071};\\\", \\\"{x:1410,y:567,t:1528143569383};\\\", \\\"{x:1410,y:568,t:1528143569398};\\\", \\\"{x:1408,y:568,t:1528143569414};\\\", \\\"{x:1404,y:569,t:1528143569430};\\\", \\\"{x:1398,y:569,t:1528143569447};\\\", \\\"{x:1385,y:564,t:1528143569464};\\\", \\\"{x:1378,y:560,t:1528143569481};\\\", \\\"{x:1362,y:555,t:1528143569496};\\\", \\\"{x:1346,y:547,t:1528143569514};\\\", \\\"{x:1333,y:539,t:1528143569530};\\\", \\\"{x:1313,y:530,t:1528143569546};\\\", \\\"{x:1304,y:525,t:1528143569563};\\\", \\\"{x:1298,y:521,t:1528143569580};\\\", \\\"{x:1293,y:518,t:1528143569597};\\\", \\\"{x:1291,y:517,t:1528143569613};\\\", \\\"{x:1287,y:513,t:1528143569630};\\\", \\\"{x:1285,y:510,t:1528143569646};\\\", \\\"{x:1285,y:508,t:1528143569663};\\\", \\\"{x:1284,y:507,t:1528143569680};\\\", \\\"{x:1284,y:506,t:1528143569698};\\\", \\\"{x:1284,y:504,t:1528143569713};\\\", \\\"{x:1284,y:503,t:1528143569730};\\\", \\\"{x:1284,y:501,t:1528143569747};\\\", \\\"{x:1284,y:500,t:1528143569767};\\\", \\\"{x:1284,y:499,t:1528143569783};\\\", \\\"{x:1284,y:498,t:1528143569797};\\\", \\\"{x:1284,y:497,t:1528143569831};\\\", \\\"{x:1284,y:496,t:1528143569847};\\\", \\\"{x:1284,y:495,t:1528143569863};\\\", \\\"{x:1284,y:494,t:1528143570007};\\\", \\\"{x:1284,y:493,t:1528143570064};\\\", \\\"{x:1284,y:492,t:1528143570183};\\\", \\\"{x:1284,y:491,t:1528143570463};\\\", \\\"{x:1285,y:492,t:1528143570481};\\\", \\\"{x:1286,y:493,t:1528143570535};\\\", \\\"{x:1287,y:493,t:1528143570551};\\\", \\\"{x:1289,y:493,t:1528143570568};\\\", \\\"{x:1290,y:493,t:1528143570583};\\\", \\\"{x:1293,y:494,t:1528143570607};\\\", \\\"{x:1294,y:495,t:1528143570615};\\\", \\\"{x:1295,y:495,t:1528143570655};\\\", \\\"{x:1297,y:495,t:1528143570704};\\\", \\\"{x:1299,y:495,t:1528143570743};\\\", \\\"{x:1299,y:496,t:1528143570751};\\\", \\\"{x:1300,y:496,t:1528143570767};\\\", \\\"{x:1302,y:497,t:1528143570792};\\\", \\\"{x:1303,y:497,t:1528143570816};\\\", \\\"{x:1304,y:498,t:1528143570839};\\\", \\\"{x:1305,y:498,t:1528143570887};\\\", \\\"{x:1305,y:501,t:1528143575120};\\\", \\\"{x:1307,y:512,t:1528143575135};\\\", \\\"{x:1322,y:528,t:1528143575151};\\\", \\\"{x:1338,y:541,t:1528143575168};\\\", \\\"{x:1355,y:555,t:1528143575185};\\\", \\\"{x:1378,y:569,t:1528143575202};\\\", \\\"{x:1410,y:587,t:1528143575218};\\\", \\\"{x:1433,y:605,t:1528143575235};\\\", \\\"{x:1496,y:632,t:1528143575252};\\\", \\\"{x:1575,y:662,t:1528143575268};\\\", \\\"{x:1669,y:702,t:1528143575284};\\\", \\\"{x:1758,y:733,t:1528143575302};\\\", \\\"{x:1844,y:772,t:1528143575318};\\\", \\\"{x:1910,y:802,t:1528143575335};\\\", \\\"{x:1919,y:817,t:1528143575351};\\\", \\\"{x:1919,y:828,t:1528143575369};\\\", \\\"{x:1919,y:833,t:1528143575384};\\\", \\\"{x:1919,y:834,t:1528143575455};\\\", \\\"{x:1919,y:836,t:1528143575468};\\\", \\\"{x:1914,y:838,t:1528143575485};\\\", \\\"{x:1903,y:845,t:1528143575502};\\\", \\\"{x:1888,y:862,t:1528143575519};\\\", \\\"{x:1883,y:867,t:1528143575535};\\\", \\\"{x:1873,y:877,t:1528143575551};\\\", \\\"{x:1857,y:890,t:1528143575569};\\\", \\\"{x:1846,y:904,t:1528143575585};\\\", \\\"{x:1828,y:918,t:1528143575602};\\\", \\\"{x:1810,y:929,t:1528143575619};\\\", \\\"{x:1793,y:941,t:1528143575636};\\\", \\\"{x:1776,y:954,t:1528143575652};\\\", \\\"{x:1758,y:962,t:1528143575669};\\\", \\\"{x:1745,y:970,t:1528143575686};\\\", \\\"{x:1733,y:975,t:1528143575702};\\\", \\\"{x:1722,y:976,t:1528143575720};\\\", \\\"{x:1720,y:978,t:1528143575735};\\\", \\\"{x:1717,y:980,t:1528143575752};\\\", \\\"{x:1716,y:980,t:1528143575769};\\\", \\\"{x:1709,y:982,t:1528143575786};\\\", \\\"{x:1700,y:984,t:1528143575803};\\\", \\\"{x:1692,y:984,t:1528143575818};\\\", \\\"{x:1673,y:979,t:1528143575836};\\\", \\\"{x:1655,y:967,t:1528143575852};\\\", \\\"{x:1634,y:956,t:1528143575869};\\\", \\\"{x:1624,y:945,t:1528143575886};\\\", \\\"{x:1614,y:926,t:1528143575903};\\\", \\\"{x:1603,y:909,t:1528143575919};\\\", \\\"{x:1594,y:893,t:1528143575935};\\\", \\\"{x:1587,y:877,t:1528143575953};\\\", \\\"{x:1582,y:867,t:1528143575969};\\\", \\\"{x:1578,y:858,t:1528143575986};\\\", \\\"{x:1575,y:844,t:1528143576003};\\\", \\\"{x:1571,y:832,t:1528143576019};\\\", \\\"{x:1568,y:823,t:1528143576036};\\\", \\\"{x:1562,y:813,t:1528143576053};\\\", \\\"{x:1559,y:804,t:1528143576069};\\\", \\\"{x:1557,y:796,t:1528143576086};\\\", \\\"{x:1555,y:789,t:1528143576103};\\\", \\\"{x:1553,y:787,t:1528143576118};\\\", \\\"{x:1553,y:785,t:1528143576136};\\\", \\\"{x:1553,y:781,t:1528143576153};\\\", \\\"{x:1553,y:780,t:1528143576169};\\\", \\\"{x:1553,y:776,t:1528143576186};\\\", \\\"{x:1553,y:771,t:1528143576202};\\\", \\\"{x:1554,y:768,t:1528143576219};\\\", \\\"{x:1557,y:764,t:1528143576236};\\\", \\\"{x:1561,y:760,t:1528143576252};\\\", \\\"{x:1564,y:758,t:1528143576269};\\\", \\\"{x:1564,y:755,t:1528143576286};\\\", \\\"{x:1570,y:749,t:1528143576303};\\\", \\\"{x:1575,y:746,t:1528143576319};\\\", \\\"{x:1580,y:744,t:1528143576336};\\\", \\\"{x:1585,y:741,t:1528143576353};\\\", \\\"{x:1589,y:739,t:1528143576370};\\\", \\\"{x:1591,y:739,t:1528143576386};\\\", \\\"{x:1588,y:739,t:1528143576663};\\\", \\\"{x:1587,y:739,t:1528143576679};\\\", \\\"{x:1584,y:739,t:1528143576687};\\\", \\\"{x:1580,y:738,t:1528143576703};\\\", \\\"{x:1574,y:735,t:1528143576719};\\\", \\\"{x:1570,y:733,t:1528143576737};\\\", \\\"{x:1566,y:726,t:1528143576753};\\\", \\\"{x:1558,y:719,t:1528143576770};\\\", \\\"{x:1554,y:710,t:1528143576787};\\\", \\\"{x:1548,y:702,t:1528143576803};\\\", \\\"{x:1546,y:696,t:1528143576820};\\\", \\\"{x:1544,y:692,t:1528143576837};\\\", \\\"{x:1542,y:687,t:1528143576852};\\\", \\\"{x:1541,y:681,t:1528143576870};\\\", \\\"{x:1540,y:674,t:1528143576887};\\\", \\\"{x:1540,y:668,t:1528143576903};\\\", \\\"{x:1540,y:662,t:1528143576920};\\\", \\\"{x:1538,y:656,t:1528143576937};\\\", \\\"{x:1537,y:647,t:1528143576953};\\\", \\\"{x:1535,y:641,t:1528143576970};\\\", \\\"{x:1534,y:639,t:1528143576987};\\\", \\\"{x:1533,y:636,t:1528143577003};\\\", \\\"{x:1532,y:634,t:1528143577020};\\\", \\\"{x:1532,y:633,t:1528143577039};\\\", \\\"{x:1532,y:631,t:1528143577071};\\\", \\\"{x:1531,y:630,t:1528143577152};\\\", \\\"{x:1529,y:630,t:1528143577170};\\\", \\\"{x:1528,y:630,t:1528143577187};\\\", \\\"{x:1523,y:629,t:1528143577204};\\\", \\\"{x:1522,y:629,t:1528143577220};\\\", \\\"{x:1521,y:629,t:1528143577237};\\\", \\\"{x:1520,y:629,t:1528143577254};\\\", \\\"{x:1518,y:629,t:1528143577286};\\\", \\\"{x:1517,y:629,t:1528143577303};\\\", \\\"{x:1516,y:629,t:1528143577335};\\\", \\\"{x:1515,y:629,t:1528143577351};\\\", \\\"{x:1514,y:630,t:1528143577359};\\\", \\\"{x:1513,y:631,t:1528143578575};\\\", \\\"{x:1513,y:633,t:1528143578588};\\\", \\\"{x:1517,y:637,t:1528143578606};\\\", \\\"{x:1523,y:642,t:1528143578621};\\\", \\\"{x:1530,y:648,t:1528143578638};\\\", \\\"{x:1545,y:657,t:1528143578655};\\\", \\\"{x:1557,y:666,t:1528143578671};\\\", \\\"{x:1567,y:670,t:1528143578688};\\\", \\\"{x:1573,y:674,t:1528143578705};\\\", \\\"{x:1579,y:679,t:1528143578721};\\\", \\\"{x:1587,y:684,t:1528143578738};\\\", \\\"{x:1589,y:686,t:1528143578755};\\\", \\\"{x:1590,y:687,t:1528143578771};\\\", \\\"{x:1591,y:688,t:1528143578788};\\\", \\\"{x:1592,y:690,t:1528143578805};\\\", \\\"{x:1594,y:693,t:1528143578823};\\\", \\\"{x:1594,y:694,t:1528143578838};\\\", \\\"{x:1595,y:698,t:1528143578856};\\\", \\\"{x:1595,y:700,t:1528143578871};\\\", \\\"{x:1595,y:707,t:1528143578888};\\\", \\\"{x:1598,y:722,t:1528143578905};\\\", \\\"{x:1601,y:736,t:1528143578921};\\\", \\\"{x:1605,y:745,t:1528143578938};\\\", \\\"{x:1607,y:751,t:1528143578955};\\\", \\\"{x:1609,y:758,t:1528143578972};\\\", \\\"{x:1609,y:766,t:1528143578988};\\\", \\\"{x:1612,y:769,t:1528143579005};\\\", \\\"{x:1613,y:774,t:1528143579022};\\\", \\\"{x:1616,y:778,t:1528143579038};\\\", \\\"{x:1618,y:782,t:1528143579055};\\\", \\\"{x:1619,y:783,t:1528143579071};\\\", \\\"{x:1619,y:784,t:1528143579094};\\\", \\\"{x:1620,y:786,t:1528143579118};\\\", \\\"{x:1621,y:788,t:1528143579134};\\\", \\\"{x:1621,y:789,t:1528143579150};\\\", \\\"{x:1623,y:792,t:1528143579158};\\\", \\\"{x:1623,y:793,t:1528143579183};\\\", \\\"{x:1624,y:794,t:1528143579198};\\\", \\\"{x:1624,y:795,t:1528143579207};\\\", \\\"{x:1624,y:796,t:1528143579222};\\\", \\\"{x:1625,y:797,t:1528143579254};\\\", \\\"{x:1625,y:798,t:1528143579272};\\\", \\\"{x:1625,y:799,t:1528143579288};\\\", \\\"{x:1626,y:803,t:1528143579305};\\\", \\\"{x:1627,y:803,t:1528143579322};\\\", \\\"{x:1627,y:805,t:1528143579338};\\\", \\\"{x:1627,y:806,t:1528143579355};\\\", \\\"{x:1627,y:808,t:1528143579372};\\\", \\\"{x:1627,y:811,t:1528143579388};\\\", \\\"{x:1627,y:813,t:1528143579404};\\\", \\\"{x:1627,y:817,t:1528143579422};\\\", \\\"{x:1627,y:822,t:1528143579439};\\\", \\\"{x:1627,y:826,t:1528143579454};\\\", \\\"{x:1627,y:828,t:1528143579471};\\\", \\\"{x:1627,y:829,t:1528143579489};\\\", \\\"{x:1627,y:834,t:1528143579504};\\\", \\\"{x:1627,y:838,t:1528143579522};\\\", \\\"{x:1627,y:839,t:1528143579538};\\\", \\\"{x:1627,y:843,t:1528143579555};\\\", \\\"{x:1627,y:845,t:1528143579571};\\\", \\\"{x:1627,y:847,t:1528143579588};\\\", \\\"{x:1627,y:849,t:1528143579605};\\\", \\\"{x:1627,y:852,t:1528143579622};\\\", \\\"{x:1627,y:855,t:1528143579639};\\\", \\\"{x:1627,y:859,t:1528143579655};\\\", \\\"{x:1625,y:862,t:1528143579672};\\\", \\\"{x:1625,y:866,t:1528143579689};\\\", \\\"{x:1622,y:870,t:1528143579705};\\\", \\\"{x:1622,y:873,t:1528143579722};\\\", \\\"{x:1618,y:878,t:1528143579739};\\\", \\\"{x:1615,y:883,t:1528143579755};\\\", \\\"{x:1611,y:890,t:1528143579772};\\\", \\\"{x:1609,y:897,t:1528143579788};\\\", \\\"{x:1605,y:901,t:1528143579805};\\\", \\\"{x:1603,y:904,t:1528143579822};\\\", \\\"{x:1599,y:908,t:1528143579839};\\\", \\\"{x:1598,y:911,t:1528143579855};\\\", \\\"{x:1595,y:914,t:1528143579872};\\\", \\\"{x:1594,y:916,t:1528143579889};\\\", \\\"{x:1593,y:919,t:1528143579905};\\\", \\\"{x:1592,y:920,t:1528143579922};\\\", \\\"{x:1592,y:922,t:1528143579938};\\\", \\\"{x:1591,y:925,t:1528143579956};\\\", \\\"{x:1589,y:926,t:1528143579972};\\\", \\\"{x:1588,y:929,t:1528143579988};\\\", \\\"{x:1588,y:931,t:1528143580005};\\\", \\\"{x:1588,y:932,t:1528143580022};\\\", \\\"{x:1586,y:936,t:1528143580038};\\\", \\\"{x:1586,y:939,t:1528143580055};\\\", \\\"{x:1585,y:941,t:1528143580072};\\\", \\\"{x:1585,y:942,t:1528143580094};\\\", \\\"{x:1585,y:945,t:1528143580110};\\\", \\\"{x:1585,y:946,t:1528143580127};\\\", \\\"{x:1585,y:947,t:1528143580159};\\\", \\\"{x:1585,y:948,t:1528143580175};\\\", \\\"{x:1585,y:949,t:1528143580191};\\\", \\\"{x:1585,y:951,t:1528143580206};\\\", \\\"{x:1584,y:951,t:1528143580223};\\\", \\\"{x:1583,y:953,t:1528143580239};\\\", \\\"{x:1583,y:954,t:1528143580256};\\\", \\\"{x:1583,y:955,t:1528143580287};\\\", \\\"{x:1583,y:956,t:1528143580327};\\\", \\\"{x:1583,y:957,t:1528143580343};\\\", \\\"{x:1583,y:958,t:1528143580424};\\\", \\\"{x:1588,y:959,t:1528143580439};\\\", \\\"{x:1593,y:960,t:1528143580456};\\\", \\\"{x:1598,y:962,t:1528143580473};\\\", \\\"{x:1602,y:963,t:1528143580489};\\\", \\\"{x:1603,y:964,t:1528143580506};\\\", \\\"{x:1604,y:964,t:1528143580527};\\\", \\\"{x:1605,y:964,t:1528143580567};\\\", \\\"{x:1607,y:964,t:1528143580575};\\\", \\\"{x:1608,y:964,t:1528143580591};\\\", \\\"{x:1610,y:964,t:1528143580606};\\\", \\\"{x:1611,y:964,t:1528143580623};\\\", \\\"{x:1611,y:961,t:1528143580639};\\\", \\\"{x:1611,y:957,t:1528143580657};\\\", \\\"{x:1608,y:944,t:1528143580674};\\\", \\\"{x:1606,y:934,t:1528143580689};\\\", \\\"{x:1604,y:923,t:1528143580706};\\\", \\\"{x:1598,y:909,t:1528143580723};\\\", \\\"{x:1594,y:895,t:1528143580740};\\\", \\\"{x:1590,y:876,t:1528143580756};\\\", \\\"{x:1586,y:861,t:1528143580773};\\\", \\\"{x:1584,y:849,t:1528143580790};\\\", \\\"{x:1583,y:838,t:1528143580806};\\\", \\\"{x:1578,y:827,t:1528143580823};\\\", \\\"{x:1577,y:823,t:1528143580840};\\\", \\\"{x:1577,y:822,t:1528143580856};\\\", \\\"{x:1577,y:820,t:1528143580880};\\\", \\\"{x:1577,y:819,t:1528143580911};\\\", \\\"{x:1577,y:817,t:1528143580923};\\\", \\\"{x:1577,y:816,t:1528143580940};\\\", \\\"{x:1578,y:813,t:1528143580957};\\\", \\\"{x:1580,y:809,t:1528143580973};\\\", \\\"{x:1580,y:807,t:1528143580990};\\\", \\\"{x:1583,y:804,t:1528143581006};\\\", \\\"{x:1584,y:802,t:1528143581023};\\\", \\\"{x:1584,y:800,t:1528143581055};\\\", \\\"{x:1584,y:799,t:1528143581073};\\\", \\\"{x:1585,y:797,t:1528143581090};\\\", \\\"{x:1587,y:795,t:1528143581106};\\\", \\\"{x:1588,y:795,t:1528143581123};\\\", \\\"{x:1591,y:793,t:1528143581140};\\\", \\\"{x:1592,y:791,t:1528143581157};\\\", \\\"{x:1596,y:789,t:1528143581173};\\\", \\\"{x:1598,y:788,t:1528143581190};\\\", \\\"{x:1600,y:788,t:1528143581207};\\\", \\\"{x:1601,y:787,t:1528143581223};\\\", \\\"{x:1601,y:786,t:1528143581240};\\\", \\\"{x:1602,y:786,t:1528143581257};\\\", \\\"{x:1602,y:785,t:1528143581273};\\\", \\\"{x:1604,y:785,t:1528143581291};\\\", \\\"{x:1605,y:785,t:1528143581308};\\\", \\\"{x:1607,y:784,t:1528143581323};\\\", \\\"{x:1609,y:784,t:1528143581340};\\\", \\\"{x:1610,y:783,t:1528143581358};\\\", \\\"{x:1612,y:782,t:1528143581374};\\\", \\\"{x:1615,y:781,t:1528143581390};\\\", \\\"{x:1616,y:780,t:1528143581408};\\\", \\\"{x:1618,y:779,t:1528143581423};\\\", \\\"{x:1622,y:778,t:1528143581440};\\\", \\\"{x:1624,y:776,t:1528143581457};\\\", \\\"{x:1626,y:776,t:1528143581473};\\\", \\\"{x:1629,y:776,t:1528143581490};\\\", \\\"{x:1632,y:774,t:1528143581507};\\\", \\\"{x:1633,y:774,t:1528143581523};\\\", \\\"{x:1634,y:773,t:1528143581543};\\\", \\\"{x:1635,y:773,t:1528143581560};\\\", \\\"{x:1636,y:773,t:1528143581591};\\\", \\\"{x:1637,y:772,t:1528143581607};\\\", \\\"{x:1637,y:771,t:1528143581632};\\\", \\\"{x:1639,y:771,t:1528143581640};\\\", \\\"{x:1640,y:769,t:1528143581658};\\\", \\\"{x:1640,y:768,t:1528143581675};\\\", \\\"{x:1642,y:767,t:1528143581690};\\\", \\\"{x:1642,y:766,t:1528143581707};\\\", \\\"{x:1643,y:764,t:1528143581725};\\\", \\\"{x:1644,y:760,t:1528143581740};\\\", \\\"{x:1645,y:757,t:1528143581758};\\\", \\\"{x:1645,y:752,t:1528143581774};\\\", \\\"{x:1645,y:745,t:1528143581790};\\\", \\\"{x:1645,y:740,t:1528143581808};\\\", \\\"{x:1645,y:734,t:1528143581824};\\\", \\\"{x:1644,y:728,t:1528143581840};\\\", \\\"{x:1639,y:721,t:1528143581857};\\\", \\\"{x:1635,y:716,t:1528143581874};\\\", \\\"{x:1631,y:712,t:1528143581890};\\\", \\\"{x:1625,y:706,t:1528143581907};\\\", \\\"{x:1623,y:700,t:1528143581924};\\\", \\\"{x:1616,y:694,t:1528143581941};\\\", \\\"{x:1610,y:685,t:1528143581958};\\\", \\\"{x:1604,y:678,t:1528143581974};\\\", \\\"{x:1599,y:673,t:1528143581990};\\\", \\\"{x:1595,y:667,t:1528143582007};\\\", \\\"{x:1593,y:664,t:1528143582024};\\\", \\\"{x:1592,y:660,t:1528143582041};\\\", \\\"{x:1586,y:657,t:1528143582057};\\\", \\\"{x:1582,y:655,t:1528143582074};\\\", \\\"{x:1581,y:652,t:1528143582091};\\\", \\\"{x:1579,y:651,t:1528143582107};\\\", \\\"{x:1578,y:650,t:1528143582124};\\\", \\\"{x:1577,y:650,t:1528143582159};\\\", \\\"{x:1576,y:650,t:1528143582352};\\\", \\\"{x:1573,y:650,t:1528143582359};\\\", \\\"{x:1569,y:649,t:1528143582375};\\\", \\\"{x:1560,y:645,t:1528143582391};\\\", \\\"{x:1559,y:645,t:1528143582408};\\\", \\\"{x:1556,y:643,t:1528143582424};\\\", \\\"{x:1548,y:640,t:1528143582441};\\\", \\\"{x:1542,y:639,t:1528143582457};\\\", \\\"{x:1531,y:637,t:1528143582474};\\\", \\\"{x:1519,y:633,t:1528143582492};\\\", \\\"{x:1513,y:631,t:1528143582508};\\\", \\\"{x:1507,y:629,t:1528143582526};\\\", \\\"{x:1505,y:629,t:1528143582541};\\\", \\\"{x:1503,y:628,t:1528143582558};\\\", \\\"{x:1502,y:628,t:1528143582574};\\\", \\\"{x:1500,y:628,t:1528143582648};\\\", \\\"{x:1499,y:628,t:1528143582659};\\\", \\\"{x:1496,y:630,t:1528143582674};\\\", \\\"{x:1494,y:633,t:1528143582691};\\\", \\\"{x:1493,y:637,t:1528143582708};\\\", \\\"{x:1491,y:643,t:1528143582724};\\\", \\\"{x:1491,y:648,t:1528143582741};\\\", \\\"{x:1491,y:653,t:1528143582759};\\\", \\\"{x:1491,y:658,t:1528143582775};\\\", \\\"{x:1492,y:669,t:1528143582792};\\\", \\\"{x:1495,y:676,t:1528143582809};\\\", \\\"{x:1496,y:680,t:1528143582825};\\\", \\\"{x:1498,y:683,t:1528143582841};\\\", \\\"{x:1500,y:688,t:1528143582859};\\\", \\\"{x:1501,y:688,t:1528143582879};\\\", \\\"{x:1501,y:690,t:1528143582892};\\\", \\\"{x:1502,y:692,t:1528143582909};\\\", \\\"{x:1505,y:697,t:1528143582925};\\\", \\\"{x:1505,y:701,t:1528143582942};\\\", \\\"{x:1510,y:707,t:1528143582959};\\\", \\\"{x:1520,y:722,t:1528143582975};\\\", \\\"{x:1525,y:735,t:1528143582991};\\\", \\\"{x:1533,y:746,t:1528143583008};\\\", \\\"{x:1544,y:760,t:1528143583025};\\\", \\\"{x:1553,y:772,t:1528143583042};\\\", \\\"{x:1559,y:782,t:1528143583058};\\\", \\\"{x:1566,y:790,t:1528143583075};\\\", \\\"{x:1570,y:799,t:1528143583091};\\\", \\\"{x:1575,y:806,t:1528143583108};\\\", \\\"{x:1579,y:812,t:1528143583125};\\\", \\\"{x:1582,y:817,t:1528143583141};\\\", \\\"{x:1584,y:820,t:1528143583159};\\\", \\\"{x:1586,y:824,t:1528143583175};\\\", \\\"{x:1586,y:830,t:1528143583191};\\\", \\\"{x:1588,y:835,t:1528143583208};\\\", \\\"{x:1588,y:847,t:1528143583225};\\\", \\\"{x:1588,y:851,t:1528143583241};\\\", \\\"{x:1590,y:852,t:1528143583258};\\\", \\\"{x:1595,y:861,t:1528143583275};\\\", \\\"{x:1599,y:870,t:1528143583291};\\\", \\\"{x:1603,y:879,t:1528143583308};\\\", \\\"{x:1605,y:883,t:1528143583325};\\\", \\\"{x:1606,y:886,t:1528143583342};\\\", \\\"{x:1606,y:889,t:1528143583358};\\\", \\\"{x:1607,y:891,t:1528143583375};\\\", \\\"{x:1605,y:888,t:1528143584552};\\\", \\\"{x:1604,y:881,t:1528143584560};\\\", \\\"{x:1599,y:864,t:1528143584577};\\\", \\\"{x:1594,y:852,t:1528143584593};\\\", \\\"{x:1589,y:838,t:1528143584610};\\\", \\\"{x:1585,y:829,t:1528143584626};\\\", \\\"{x:1584,y:823,t:1528143584643};\\\", \\\"{x:1579,y:813,t:1528143584659};\\\", \\\"{x:1578,y:806,t:1528143584677};\\\", \\\"{x:1576,y:799,t:1528143584692};\\\", \\\"{x:1575,y:795,t:1528143584709};\\\", \\\"{x:1574,y:792,t:1528143584727};\\\", \\\"{x:1574,y:791,t:1528143584743};\\\", \\\"{x:1572,y:787,t:1528143584759};\\\", \\\"{x:1571,y:784,t:1528143584776};\\\", \\\"{x:1569,y:779,t:1528143584794};\\\", \\\"{x:1567,y:771,t:1528143584809};\\\", \\\"{x:1564,y:756,t:1528143584826};\\\", \\\"{x:1562,y:741,t:1528143584843};\\\", \\\"{x:1561,y:724,t:1528143584859};\\\", \\\"{x:1554,y:708,t:1528143584876};\\\", \\\"{x:1547,y:686,t:1528143584894};\\\", \\\"{x:1541,y:666,t:1528143584909};\\\", \\\"{x:1531,y:646,t:1528143584926};\\\", \\\"{x:1524,y:619,t:1528143584943};\\\", \\\"{x:1515,y:603,t:1528143584959};\\\", \\\"{x:1513,y:600,t:1528143584976};\\\", \\\"{x:1513,y:598,t:1528143584993};\\\", \\\"{x:1513,y:596,t:1528143585009};\\\", \\\"{x:1512,y:595,t:1528143585026};\\\", \\\"{x:1510,y:595,t:1528143585071};\\\", \\\"{x:1508,y:595,t:1528143585087};\\\", \\\"{x:1506,y:595,t:1528143585103};\\\", \\\"{x:1504,y:595,t:1528143585111};\\\", \\\"{x:1503,y:596,t:1528143585135};\\\", \\\"{x:1502,y:596,t:1528143585143};\\\", \\\"{x:1501,y:596,t:1528143585160};\\\", \\\"{x:1498,y:597,t:1528143585177};\\\", \\\"{x:1496,y:599,t:1528143585194};\\\", \\\"{x:1495,y:599,t:1528143585231};\\\", \\\"{x:1495,y:601,t:1528143585311};\\\", \\\"{x:1495,y:602,t:1528143585326};\\\", \\\"{x:1494,y:608,t:1528143585343};\\\", \\\"{x:1492,y:614,t:1528143585360};\\\", \\\"{x:1492,y:619,t:1528143585376};\\\", \\\"{x:1491,y:622,t:1528143585394};\\\", \\\"{x:1491,y:624,t:1528143585410};\\\", \\\"{x:1491,y:629,t:1528143585427};\\\", \\\"{x:1491,y:630,t:1528143585443};\\\", \\\"{x:1491,y:632,t:1528143585461};\\\", \\\"{x:1491,y:633,t:1528143585477};\\\", \\\"{x:1491,y:634,t:1528143585600};\\\", \\\"{x:1491,y:636,t:1528143585611};\\\", \\\"{x:1491,y:637,t:1528143585628};\\\", \\\"{x:1492,y:643,t:1528143585643};\\\", \\\"{x:1492,y:648,t:1528143585661};\\\", \\\"{x:1492,y:655,t:1528143585677};\\\", \\\"{x:1493,y:661,t:1528143585694};\\\", \\\"{x:1493,y:667,t:1528143585710};\\\", \\\"{x:1493,y:671,t:1528143585727};\\\", \\\"{x:1493,y:673,t:1528143585744};\\\", \\\"{x:1493,y:677,t:1528143585761};\\\", \\\"{x:1493,y:678,t:1528143585777};\\\", \\\"{x:1493,y:681,t:1528143585793};\\\", \\\"{x:1493,y:683,t:1528143585810};\\\", \\\"{x:1493,y:685,t:1528143585827};\\\", \\\"{x:1494,y:688,t:1528143585843};\\\", \\\"{x:1496,y:691,t:1528143585860};\\\", \\\"{x:1496,y:696,t:1528143585877};\\\", \\\"{x:1496,y:701,t:1528143585894};\\\", \\\"{x:1496,y:705,t:1528143585911};\\\", \\\"{x:1497,y:715,t:1528143585927};\\\", \\\"{x:1498,y:717,t:1528143585943};\\\", \\\"{x:1499,y:719,t:1528143585960};\\\", \\\"{x:1500,y:720,t:1528143585977};\\\", \\\"{x:1500,y:721,t:1528143585993};\\\", \\\"{x:1500,y:722,t:1528143586011};\\\", \\\"{x:1500,y:723,t:1528143586027};\\\", \\\"{x:1501,y:724,t:1528143586044};\\\", \\\"{x:1502,y:724,t:1528143586071};\\\", \\\"{x:1502,y:725,t:1528143586087};\\\", \\\"{x:1502,y:726,t:1528143586095};\\\", \\\"{x:1503,y:727,t:1528143586111};\\\", \\\"{x:1503,y:731,t:1528143586127};\\\", \\\"{x:1505,y:733,t:1528143586145};\\\", \\\"{x:1505,y:735,t:1528143586160};\\\", \\\"{x:1505,y:736,t:1528143586177};\\\", \\\"{x:1506,y:740,t:1528143586195};\\\", \\\"{x:1506,y:741,t:1528143586223};\\\", \\\"{x:1506,y:743,t:1528143586239};\\\", \\\"{x:1507,y:745,t:1528143586247};\\\", \\\"{x:1507,y:746,t:1528143586260};\\\", \\\"{x:1508,y:750,t:1528143586278};\\\", \\\"{x:1509,y:751,t:1528143586295};\\\", \\\"{x:1510,y:751,t:1528143586310};\\\", \\\"{x:1510,y:753,t:1528143586327};\\\", \\\"{x:1511,y:756,t:1528143586345};\\\", \\\"{x:1511,y:757,t:1528143586367};\\\", \\\"{x:1512,y:757,t:1528143586383};\\\", \\\"{x:1512,y:758,t:1528143586415};\\\", \\\"{x:1512,y:759,t:1528143586431};\\\", \\\"{x:1513,y:759,t:1528143586455};\\\", \\\"{x:1513,y:760,t:1528143586495};\\\", \\\"{x:1513,y:762,t:1528143586512};\\\", \\\"{x:1513,y:763,t:1528143586528};\\\", \\\"{x:1513,y:764,t:1528143586545};\\\", \\\"{x:1513,y:765,t:1528143586561};\\\", \\\"{x:1514,y:766,t:1528143586578};\\\", \\\"{x:1515,y:768,t:1528143586595};\\\", \\\"{x:1515,y:770,t:1528143586612};\\\", \\\"{x:1515,y:771,t:1528143586628};\\\", \\\"{x:1515,y:776,t:1528143586644};\\\", \\\"{x:1515,y:778,t:1528143586662};\\\", \\\"{x:1515,y:782,t:1528143586678};\\\", \\\"{x:1514,y:786,t:1528143586695};\\\", \\\"{x:1514,y:790,t:1528143586711};\\\", \\\"{x:1514,y:792,t:1528143586728};\\\", \\\"{x:1512,y:794,t:1528143586744};\\\", \\\"{x:1512,y:795,t:1528143586761};\\\", \\\"{x:1512,y:798,t:1528143586778};\\\", \\\"{x:1511,y:798,t:1528143586823};\\\", \\\"{x:1511,y:799,t:1528143587183};\\\", \\\"{x:1511,y:801,t:1528143587195};\\\", \\\"{x:1511,y:803,t:1528143587212};\\\", \\\"{x:1508,y:807,t:1528143587229};\\\", \\\"{x:1504,y:810,t:1528143587244};\\\", \\\"{x:1502,y:812,t:1528143587261};\\\", \\\"{x:1500,y:815,t:1528143587279};\\\", \\\"{x:1499,y:817,t:1528143587295};\\\", \\\"{x:1496,y:820,t:1528143587311};\\\", \\\"{x:1495,y:822,t:1528143587329};\\\", \\\"{x:1494,y:823,t:1528143587345};\\\", \\\"{x:1492,y:826,t:1528143587361};\\\", \\\"{x:1490,y:827,t:1528143587379};\\\", \\\"{x:1489,y:828,t:1528143587400};\\\", \\\"{x:1489,y:829,t:1528143587411};\\\", \\\"{x:1488,y:830,t:1528143587429};\\\", \\\"{x:1487,y:830,t:1528143587445};\\\", \\\"{x:1487,y:831,t:1528143587462};\\\", \\\"{x:1486,y:833,t:1528143587478};\\\", \\\"{x:1485,y:833,t:1528143587503};\\\", \\\"{x:1484,y:833,t:1528143587528};\\\", \\\"{x:1483,y:834,t:1528143587544};\\\", \\\"{x:1483,y:835,t:1528143588127};\\\", \\\"{x:1483,y:837,t:1528143588147};\\\", \\\"{x:1483,y:838,t:1528143588163};\\\", \\\"{x:1483,y:839,t:1528143588207};\\\", \\\"{x:1483,y:840,t:1528143588216};\\\", \\\"{x:1482,y:840,t:1528143588229};\\\", \\\"{x:1482,y:841,t:1528143588245};\\\", \\\"{x:1481,y:841,t:1528143588262};\\\", \\\"{x:1481,y:842,t:1528143588279};\\\", \\\"{x:1481,y:843,t:1528143588296};\\\", \\\"{x:1481,y:844,t:1528143588313};\\\", \\\"{x:1481,y:845,t:1528143588360};\\\", \\\"{x:1481,y:846,t:1528143588368};\\\", \\\"{x:1480,y:847,t:1528143588379};\\\", \\\"{x:1480,y:848,t:1528143588407};\\\", \\\"{x:1480,y:849,t:1528143588424};\\\", \\\"{x:1480,y:850,t:1528143588439};\\\", \\\"{x:1480,y:851,t:1528143588463};\\\", \\\"{x:1480,y:852,t:1528143588487};\\\", \\\"{x:1480,y:853,t:1528143588496};\\\", \\\"{x:1480,y:855,t:1528143588535};\\\", \\\"{x:1480,y:856,t:1528143588551};\\\", \\\"{x:1479,y:856,t:1528143588575};\\\", \\\"{x:1478,y:856,t:1528143588984};\\\", \\\"{x:1477,y:857,t:1528143589263};\\\", \\\"{x:1476,y:860,t:1528143589279};\\\", \\\"{x:1476,y:866,t:1528143589297};\\\", \\\"{x:1475,y:871,t:1528143589313};\\\", \\\"{x:1475,y:872,t:1528143589329};\\\", \\\"{x:1475,y:874,t:1528143589346};\\\", \\\"{x:1475,y:878,t:1528143589363};\\\", \\\"{x:1474,y:882,t:1528143589379};\\\", \\\"{x:1474,y:884,t:1528143589396};\\\", \\\"{x:1474,y:885,t:1528143589413};\\\", \\\"{x:1472,y:887,t:1528143589430};\\\", \\\"{x:1472,y:889,t:1528143589446};\\\", \\\"{x:1470,y:891,t:1528143589463};\\\", \\\"{x:1468,y:895,t:1528143589479};\\\", \\\"{x:1465,y:896,t:1528143589496};\\\", \\\"{x:1463,y:898,t:1528143589513};\\\", \\\"{x:1458,y:899,t:1528143589528};\\\", \\\"{x:1455,y:900,t:1528143589546};\\\", \\\"{x:1450,y:902,t:1528143589563};\\\", \\\"{x:1449,y:906,t:1528143589579};\\\", \\\"{x:1446,y:907,t:1528143589595};\\\", \\\"{x:1445,y:908,t:1528143589613};\\\", \\\"{x:1445,y:909,t:1528143589670};\\\", \\\"{x:1444,y:909,t:1528143589680};\\\", \\\"{x:1442,y:909,t:1528143589696};\\\", \\\"{x:1440,y:909,t:1528143589713};\\\", \\\"{x:1438,y:909,t:1528143589730};\\\", \\\"{x:1434,y:909,t:1528143589776};\\\", \\\"{x:1430,y:909,t:1528143589783};\\\", \\\"{x:1425,y:907,t:1528143589796};\\\", \\\"{x:1415,y:903,t:1528143589813};\\\", \\\"{x:1400,y:897,t:1528143589831};\\\", \\\"{x:1399,y:897,t:1528143589847};\\\", \\\"{x:1389,y:892,t:1528143589863};\\\", \\\"{x:1383,y:889,t:1528143589880};\\\", \\\"{x:1381,y:888,t:1528143589897};\\\", \\\"{x:1379,y:886,t:1528143589914};\\\", \\\"{x:1377,y:885,t:1528143589930};\\\", \\\"{x:1375,y:883,t:1528143589947};\\\", \\\"{x:1374,y:883,t:1528143590000};\\\", \\\"{x:1373,y:883,t:1528143590247};\\\", \\\"{x:1370,y:883,t:1528143590263};\\\", \\\"{x:1367,y:883,t:1528143590281};\\\", \\\"{x:1364,y:883,t:1528143590298};\\\", \\\"{x:1362,y:883,t:1528143590314};\\\", \\\"{x:1361,y:883,t:1528143590331};\\\", \\\"{x:1360,y:883,t:1528143590351};\\\", \\\"{x:1359,y:883,t:1528143590364};\\\", \\\"{x:1358,y:883,t:1528143590380};\\\", \\\"{x:1357,y:883,t:1528143590398};\\\", \\\"{x:1356,y:883,t:1528143590414};\\\", \\\"{x:1355,y:883,t:1528143590431};\\\", \\\"{x:1354,y:883,t:1528143590447};\\\", \\\"{x:1353,y:883,t:1528143590463};\\\", \\\"{x:1351,y:883,t:1528143590480};\\\", \\\"{x:1351,y:882,t:1528143590590};\\\", \\\"{x:1350,y:882,t:1528143590598};\\\", \\\"{x:1348,y:881,t:1528143590614};\\\", \\\"{x:1347,y:877,t:1528143590631};\\\", \\\"{x:1346,y:873,t:1528143590646};\\\", \\\"{x:1346,y:870,t:1528143590664};\\\", \\\"{x:1345,y:867,t:1528143590681};\\\", \\\"{x:1345,y:862,t:1528143590698};\\\", \\\"{x:1345,y:858,t:1528143590714};\\\", \\\"{x:1345,y:854,t:1528143590731};\\\", \\\"{x:1345,y:849,t:1528143590747};\\\", \\\"{x:1345,y:846,t:1528143590765};\\\", \\\"{x:1345,y:841,t:1528143590781};\\\", \\\"{x:1345,y:837,t:1528143590798};\\\", \\\"{x:1347,y:829,t:1528143590815};\\\", \\\"{x:1349,y:824,t:1528143590831};\\\", \\\"{x:1349,y:819,t:1528143590847};\\\", \\\"{x:1350,y:816,t:1528143590865};\\\", \\\"{x:1351,y:812,t:1528143590881};\\\", \\\"{x:1352,y:806,t:1528143590898};\\\", \\\"{x:1353,y:801,t:1528143590915};\\\", \\\"{x:1353,y:795,t:1528143590931};\\\", \\\"{x:1354,y:789,t:1528143590948};\\\", \\\"{x:1354,y:781,t:1528143590965};\\\", \\\"{x:1354,y:770,t:1528143590981};\\\", \\\"{x:1354,y:762,t:1528143590997};\\\", \\\"{x:1354,y:747,t:1528143591015};\\\", \\\"{x:1355,y:730,t:1528143591031};\\\", \\\"{x:1355,y:717,t:1528143591047};\\\", \\\"{x:1355,y:704,t:1528143591064};\\\", \\\"{x:1355,y:693,t:1528143591081};\\\", \\\"{x:1355,y:685,t:1528143591097};\\\", \\\"{x:1355,y:677,t:1528143591114};\\\", \\\"{x:1355,y:671,t:1528143591132};\\\", \\\"{x:1355,y:667,t:1528143591147};\\\", \\\"{x:1354,y:662,t:1528143591165};\\\", \\\"{x:1351,y:658,t:1528143591182};\\\", \\\"{x:1350,y:656,t:1528143591198};\\\", \\\"{x:1348,y:652,t:1528143591214};\\\", \\\"{x:1346,y:650,t:1528143591231};\\\", \\\"{x:1345,y:647,t:1528143591247};\\\", \\\"{x:1343,y:647,t:1528143591264};\\\", \\\"{x:1341,y:645,t:1528143591281};\\\", \\\"{x:1340,y:645,t:1528143591823};\\\", \\\"{x:1337,y:645,t:1528143591839};\\\", \\\"{x:1336,y:645,t:1528143592095};\\\", \\\"{x:1336,y:646,t:1528143592103};\\\", \\\"{x:1334,y:646,t:1528143592116};\\\", \\\"{x:1333,y:646,t:1528143592131};\\\", \\\"{x:1332,y:647,t:1528143592151};\\\", \\\"{x:1331,y:648,t:1528143592166};\\\", \\\"{x:1330,y:648,t:1528143592182};\\\", \\\"{x:1328,y:649,t:1528143592911};\\\", \\\"{x:1326,y:650,t:1528143592943};\\\", \\\"{x:1325,y:650,t:1528143592951};\\\", \\\"{x:1324,y:651,t:1528143593016};\\\", \\\"{x:1323,y:651,t:1528143593047};\\\", \\\"{x:1321,y:652,t:1528143593088};\\\", \\\"{x:1320,y:653,t:1528143593100};\\\", \\\"{x:1319,y:654,t:1528143593792};\\\", \\\"{x:1318,y:654,t:1528143593831};\\\", \\\"{x:1317,y:654,t:1528143593839};\\\", \\\"{x:1317,y:655,t:1528143593903};\\\", \\\"{x:1316,y:656,t:1528143593927};\\\", \\\"{x:1315,y:656,t:1528143593935};\\\", \\\"{x:1314,y:657,t:1528143593951};\\\", \\\"{x:1313,y:658,t:1528143593967};\\\", \\\"{x:1312,y:658,t:1528143593983};\\\", \\\"{x:1308,y:660,t:1528143593999};\\\", \\\"{x:1304,y:662,t:1528143594017};\\\", \\\"{x:1292,y:669,t:1528143594034};\\\", \\\"{x:1277,y:678,t:1528143594051};\\\", \\\"{x:1266,y:688,t:1528143594067};\\\", \\\"{x:1247,y:700,t:1528143594083};\\\", \\\"{x:1225,y:715,t:1528143594100};\\\", \\\"{x:1188,y:735,t:1528143594116};\\\", \\\"{x:1165,y:751,t:1528143594134};\\\", \\\"{x:1134,y:783,t:1528143594151};\\\", \\\"{x:1101,y:804,t:1528143594167};\\\", \\\"{x:1078,y:815,t:1528143594183};\\\", \\\"{x:1058,y:831,t:1528143594201};\\\", \\\"{x:1038,y:842,t:1528143594217};\\\", \\\"{x:1018,y:857,t:1528143594233};\\\", \\\"{x:1000,y:867,t:1528143594250};\\\", \\\"{x:977,y:878,t:1528143594267};\\\", \\\"{x:955,y:885,t:1528143594284};\\\", \\\"{x:928,y:890,t:1528143594301};\\\", \\\"{x:906,y:890,t:1528143594316};\\\", \\\"{x:876,y:887,t:1528143594333};\\\", \\\"{x:813,y:862,t:1528143594351};\\\", \\\"{x:795,y:851,t:1528143594367};\\\", \\\"{x:785,y:835,t:1528143594384};\\\", \\\"{x:772,y:824,t:1528143594401};\\\", \\\"{x:758,y:808,t:1528143594417};\\\", \\\"{x:745,y:796,t:1528143594433};\\\", \\\"{x:735,y:783,t:1528143594451};\\\", \\\"{x:728,y:774,t:1528143594466};\\\", \\\"{x:715,y:760,t:1528143594483};\\\", \\\"{x:701,y:748,t:1528143594500};\\\", \\\"{x:684,y:738,t:1528143594517};\\\", \\\"{x:669,y:727,t:1528143594533};\\\", \\\"{x:640,y:719,t:1528143594550};\\\", \\\"{x:623,y:718,t:1528143594567};\\\", \\\"{x:605,y:718,t:1528143594583};\\\", \\\"{x:595,y:718,t:1528143594600};\\\", \\\"{x:587,y:718,t:1528143594617};\\\", \\\"{x:574,y:719,t:1528143594633};\\\", \\\"{x:569,y:719,t:1528143594650};\\\", \\\"{x:566,y:719,t:1528143594667};\\\", \\\"{x:561,y:719,t:1528143594683};\\\", \\\"{x:553,y:719,t:1528143594700};\\\", \\\"{x:539,y:719,t:1528143594717};\\\", \\\"{x:526,y:718,t:1528143594734};\\\", \\\"{x:524,y:716,t:1528143594758};\\\", \\\"{x:522,y:715,t:1528143594767};\\\", \\\"{x:516,y:712,t:1528143594784};\\\", \\\"{x:509,y:705,t:1528143594801};\\\", \\\"{x:504,y:702,t:1528143594817};\\\", \\\"{x:498,y:701,t:1528143594834};\\\", \\\"{x:497,y:701,t:1528143594851};\\\", \\\"{x:495,y:700,t:1528143594868};\\\", \\\"{x:494,y:700,t:1528143594884};\\\", \\\"{x:491,y:700,t:1528143595287};\\\", \\\"{x:490,y:700,t:1528143595301};\\\", \\\"{x:489,y:700,t:1528143595317};\\\", \\\"{x:488,y:701,t:1528143595336};\\\", \\\"{x:487,y:701,t:1528143595366};\\\", \\\"{x:487,y:702,t:1528143595398};\\\" ] }, { \\\"rt\\\": 84187, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 673578, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -H -I -01 PM-06 PM-Z -12 PM-02 PM-04 PM-06 PM-06 PM-11 AM-A -3-F -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:487,y:699,t:1528143598294};\\\", \\\"{x:489,y:697,t:1528143598303};\\\", \\\"{x:489,y:693,t:1528143598321};\\\", \\\"{x:489,y:690,t:1528143598337};\\\", \\\"{x:491,y:682,t:1528143598353};\\\", \\\"{x:494,y:679,t:1528143598370};\\\", \\\"{x:495,y:678,t:1528143598387};\\\", \\\"{x:497,y:676,t:1528143598403};\\\", \\\"{x:498,y:674,t:1528143598421};\\\", \\\"{x:502,y:668,t:1528143598438};\\\", \\\"{x:503,y:667,t:1528143598454};\\\", \\\"{x:505,y:662,t:1528143598472};\\\", \\\"{x:507,y:661,t:1528143598487};\\\", \\\"{x:510,y:658,t:1528143598503};\\\", \\\"{x:511,y:656,t:1528143598520};\\\", \\\"{x:512,y:654,t:1528143598537};\\\", \\\"{x:513,y:654,t:1528143598553};\\\", \\\"{x:513,y:652,t:1528143598570};\\\", \\\"{x:514,y:651,t:1528143598587};\\\", \\\"{x:514,y:650,t:1528143598603};\\\", \\\"{x:516,y:649,t:1528143598620};\\\", \\\"{x:516,y:648,t:1528143598637};\\\", \\\"{x:518,y:648,t:1528143598653};\\\", \\\"{x:519,y:647,t:1528143598671};\\\", \\\"{x:519,y:646,t:1528143598687};\\\", \\\"{x:520,y:645,t:1528143598703};\\\", \\\"{x:521,y:644,t:1528143598720};\\\", \\\"{x:522,y:643,t:1528143598743};\\\", \\\"{x:523,y:643,t:1528143598758};\\\", \\\"{x:523,y:642,t:1528143598783};\\\", \\\"{x:524,y:640,t:1528143598823};\\\", \\\"{x:525,y:638,t:1528143598855};\\\", \\\"{x:526,y:638,t:1528143598878};\\\", \\\"{x:526,y:637,t:1528143598895};\\\", \\\"{x:526,y:636,t:1528143598927};\\\", \\\"{x:526,y:635,t:1528143598951};\\\", \\\"{x:526,y:634,t:1528143599031};\\\", \\\"{x:527,y:634,t:1528143599038};\\\", \\\"{x:527,y:633,t:1528143599064};\\\", \\\"{x:528,y:632,t:1528143599070};\\\", \\\"{x:529,y:631,t:1528143599088};\\\", \\\"{x:530,y:630,t:1528143599110};\\\", \\\"{x:531,y:629,t:1528143599174};\\\", \\\"{x:532,y:628,t:1528143599254};\\\", \\\"{x:532,y:627,t:1528143599343};\\\", \\\"{x:532,y:625,t:1528143599743};\\\", \\\"{x:534,y:624,t:1528143599774};\\\", \\\"{x:534,y:623,t:1528143599788};\\\", \\\"{x:535,y:622,t:1528143599805};\\\", \\\"{x:535,y:621,t:1528143599821};\\\", \\\"{x:536,y:620,t:1528143599838};\\\", \\\"{x:537,y:619,t:1528143599855};\\\", \\\"{x:537,y:618,t:1528143599903};\\\", \\\"{x:538,y:618,t:1528143599969};\\\", \\\"{x:538,y:617,t:1528143600007};\\\", \\\"{x:542,y:615,t:1528143601776};\\\", \\\"{x:545,y:614,t:1528143601790};\\\", \\\"{x:552,y:612,t:1528143601806};\\\", \\\"{x:571,y:609,t:1528143601824};\\\", \\\"{x:582,y:609,t:1528143601840};\\\", \\\"{x:606,y:605,t:1528143601858};\\\", \\\"{x:644,y:604,t:1528143601875};\\\", \\\"{x:673,y:611,t:1528143601889};\\\", \\\"{x:708,y:615,t:1528143601906};\\\", \\\"{x:787,y:627,t:1528143601924};\\\", \\\"{x:875,y:637,t:1528143601940};\\\", \\\"{x:982,y:649,t:1528143601956};\\\", \\\"{x:1087,y:657,t:1528143601974};\\\", \\\"{x:1186,y:670,t:1528143601990};\\\", \\\"{x:1336,y:696,t:1528143602007};\\\", \\\"{x:1422,y:707,t:1528143602024};\\\", \\\"{x:1513,y:719,t:1528143602040};\\\", \\\"{x:1596,y:730,t:1528143602057};\\\", \\\"{x:1678,y:746,t:1528143602074};\\\", \\\"{x:1723,y:754,t:1528143602090};\\\", \\\"{x:1782,y:764,t:1528143602106};\\\", \\\"{x:1824,y:774,t:1528143602124};\\\", \\\"{x:1845,y:783,t:1528143602140};\\\", \\\"{x:1876,y:794,t:1528143602157};\\\", \\\"{x:1905,y:801,t:1528143602174};\\\", \\\"{x:1919,y:811,t:1528143602190};\\\", \\\"{x:1919,y:813,t:1528143602230};\\\", \\\"{x:1919,y:814,t:1528143602246};\\\", \\\"{x:1919,y:815,t:1528143602287};\\\", \\\"{x:1919,y:816,t:1528143602335};\\\", \\\"{x:1919,y:817,t:1528143602359};\\\", \\\"{x:1918,y:821,t:1528143602374};\\\", \\\"{x:1911,y:825,t:1528143602391};\\\", \\\"{x:1905,y:826,t:1528143602407};\\\", \\\"{x:1898,y:827,t:1528143602425};\\\", \\\"{x:1887,y:829,t:1528143602441};\\\", \\\"{x:1876,y:830,t:1528143602457};\\\", \\\"{x:1864,y:831,t:1528143602474};\\\", \\\"{x:1859,y:831,t:1528143602491};\\\", \\\"{x:1853,y:831,t:1528143602508};\\\", \\\"{x:1836,y:831,t:1528143602524};\\\", \\\"{x:1831,y:831,t:1528143602542};\\\", \\\"{x:1811,y:831,t:1528143602557};\\\", \\\"{x:1798,y:831,t:1528143602574};\\\", \\\"{x:1762,y:831,t:1528143602591};\\\", \\\"{x:1738,y:831,t:1528143602608};\\\", \\\"{x:1722,y:831,t:1528143602624};\\\", \\\"{x:1712,y:829,t:1528143602642};\\\", \\\"{x:1702,y:828,t:1528143602658};\\\", \\\"{x:1695,y:827,t:1528143602674};\\\", \\\"{x:1684,y:827,t:1528143602693};\\\", \\\"{x:1666,y:827,t:1528143602708};\\\", \\\"{x:1655,y:827,t:1528143602723};\\\", \\\"{x:1643,y:827,t:1528143602740};\\\", \\\"{x:1634,y:827,t:1528143602758};\\\", \\\"{x:1625,y:827,t:1528143602774};\\\", \\\"{x:1602,y:826,t:1528143602790};\\\", \\\"{x:1595,y:824,t:1528143602807};\\\", \\\"{x:1591,y:823,t:1528143602823};\\\", \\\"{x:1585,y:822,t:1528143602841};\\\", \\\"{x:1580,y:820,t:1528143602858};\\\", \\\"{x:1574,y:819,t:1528143602874};\\\", \\\"{x:1573,y:819,t:1528143602891};\\\", \\\"{x:1573,y:818,t:1528143602909};\\\", \\\"{x:1573,y:816,t:1528143602960};\\\", \\\"{x:1573,y:810,t:1528143602975};\\\", \\\"{x:1575,y:803,t:1528143602991};\\\", \\\"{x:1581,y:794,t:1528143603008};\\\", \\\"{x:1588,y:781,t:1528143603026};\\\", \\\"{x:1594,y:769,t:1528143603041};\\\", \\\"{x:1597,y:756,t:1528143603058};\\\", \\\"{x:1601,y:749,t:1528143603076};\\\", \\\"{x:1607,y:740,t:1528143603092};\\\", \\\"{x:1617,y:725,t:1528143603108};\\\", \\\"{x:1625,y:710,t:1528143603125};\\\", \\\"{x:1633,y:699,t:1528143603141};\\\", \\\"{x:1639,y:689,t:1528143603158};\\\", \\\"{x:1643,y:676,t:1528143603175};\\\", \\\"{x:1647,y:668,t:1528143603191};\\\", \\\"{x:1652,y:655,t:1528143603208};\\\", \\\"{x:1656,y:640,t:1528143603225};\\\", \\\"{x:1664,y:626,t:1528143603241};\\\", \\\"{x:1668,y:615,t:1528143603259};\\\", \\\"{x:1673,y:601,t:1528143603275};\\\", \\\"{x:1677,y:590,t:1528143603291};\\\", \\\"{x:1678,y:583,t:1528143603308};\\\", \\\"{x:1678,y:579,t:1528143603325};\\\", \\\"{x:1678,y:577,t:1528143603342};\\\", \\\"{x:1677,y:575,t:1528143603358};\\\", \\\"{x:1675,y:575,t:1528143603400};\\\", \\\"{x:1673,y:575,t:1528143603409};\\\", \\\"{x:1671,y:575,t:1528143603425};\\\", \\\"{x:1668,y:575,t:1528143603442};\\\", \\\"{x:1661,y:575,t:1528143603458};\\\", \\\"{x:1644,y:575,t:1528143603475};\\\", \\\"{x:1622,y:575,t:1528143603492};\\\", \\\"{x:1599,y:575,t:1528143603508};\\\", \\\"{x:1590,y:575,t:1528143603525};\\\", \\\"{x:1581,y:575,t:1528143603542};\\\", \\\"{x:1573,y:575,t:1528143603559};\\\", \\\"{x:1550,y:572,t:1528143603574};\\\", \\\"{x:1525,y:572,t:1528143603593};\\\", \\\"{x:1505,y:572,t:1528143603608};\\\", \\\"{x:1487,y:572,t:1528143603625};\\\", \\\"{x:1480,y:572,t:1528143603642};\\\", \\\"{x:1467,y:572,t:1528143603658};\\\", \\\"{x:1455,y:570,t:1528143603675};\\\", \\\"{x:1440,y:567,t:1528143603693};\\\", \\\"{x:1432,y:565,t:1528143603709};\\\", \\\"{x:1428,y:561,t:1528143603725};\\\", \\\"{x:1415,y:557,t:1528143603743};\\\", \\\"{x:1401,y:553,t:1528143603759};\\\", \\\"{x:1396,y:550,t:1528143603775};\\\", \\\"{x:1396,y:549,t:1528143603792};\\\", \\\"{x:1396,y:547,t:1528143603809};\\\", \\\"{x:1396,y:545,t:1528143603825};\\\", \\\"{x:1396,y:543,t:1528143603842};\\\", \\\"{x:1396,y:541,t:1528143603859};\\\", \\\"{x:1393,y:538,t:1528143603875};\\\", \\\"{x:1391,y:536,t:1528143603892};\\\", \\\"{x:1388,y:533,t:1528143603909};\\\", \\\"{x:1382,y:530,t:1528143603925};\\\", \\\"{x:1378,y:528,t:1528143603942};\\\", \\\"{x:1371,y:523,t:1528143603959};\\\", \\\"{x:1367,y:521,t:1528143603975};\\\", \\\"{x:1362,y:520,t:1528143603992};\\\", \\\"{x:1360,y:519,t:1528143604008};\\\", \\\"{x:1357,y:519,t:1528143604025};\\\", \\\"{x:1351,y:518,t:1528143604042};\\\", \\\"{x:1349,y:517,t:1528143604059};\\\", \\\"{x:1345,y:517,t:1528143604075};\\\", \\\"{x:1340,y:517,t:1528143604092};\\\", \\\"{x:1338,y:517,t:1528143604109};\\\", \\\"{x:1332,y:517,t:1528143604125};\\\", \\\"{x:1330,y:517,t:1528143604142};\\\", \\\"{x:1328,y:517,t:1528143604159};\\\", \\\"{x:1324,y:517,t:1528143604176};\\\", \\\"{x:1323,y:517,t:1528143604192};\\\", \\\"{x:1321,y:517,t:1528143604209};\\\", \\\"{x:1320,y:517,t:1528143604239};\\\", \\\"{x:1320,y:516,t:1528143604360};\\\", \\\"{x:1319,y:515,t:1528143604376};\\\", \\\"{x:1317,y:514,t:1528143604392};\\\", \\\"{x:1316,y:512,t:1528143604415};\\\", \\\"{x:1315,y:511,t:1528143604426};\\\", \\\"{x:1314,y:510,t:1528143604442};\\\", \\\"{x:1314,y:509,t:1528143604459};\\\", \\\"{x:1314,y:506,t:1528143604476};\\\", \\\"{x:1313,y:505,t:1528143604493};\\\", \\\"{x:1312,y:504,t:1528143604509};\\\", \\\"{x:1311,y:503,t:1528143604559};\\\", \\\"{x:1311,y:502,t:1528143604615};\\\", \\\"{x:1311,y:501,t:1528143604696};\\\", \\\"{x:1310,y:501,t:1528143606640};\\\", \\\"{x:1309,y:502,t:1528143606646};\\\", \\\"{x:1309,y:503,t:1528143606661};\\\", \\\"{x:1308,y:507,t:1528143606678};\\\", \\\"{x:1307,y:510,t:1528143606695};\\\", \\\"{x:1307,y:512,t:1528143606711};\\\", \\\"{x:1307,y:513,t:1528143606728};\\\", \\\"{x:1307,y:514,t:1528143606745};\\\", \\\"{x:1307,y:515,t:1528143606855};\\\", \\\"{x:1307,y:516,t:1528143606863};\\\", \\\"{x:1307,y:517,t:1528143606887};\\\", \\\"{x:1307,y:518,t:1528143606936};\\\", \\\"{x:1307,y:521,t:1528143606951};\\\", \\\"{x:1307,y:522,t:1528143606998};\\\", \\\"{x:1307,y:523,t:1528143607013};\\\", \\\"{x:1307,y:524,t:1528143607030};\\\", \\\"{x:1307,y:526,t:1528143607044};\\\", \\\"{x:1307,y:531,t:1528143607061};\\\", \\\"{x:1305,y:538,t:1528143607077};\\\", \\\"{x:1304,y:542,t:1528143607094};\\\", \\\"{x:1304,y:548,t:1528143607110};\\\", \\\"{x:1304,y:553,t:1528143607128};\\\", \\\"{x:1304,y:559,t:1528143607145};\\\", \\\"{x:1303,y:565,t:1528143607161};\\\", \\\"{x:1303,y:572,t:1528143607178};\\\", \\\"{x:1301,y:579,t:1528143607195};\\\", \\\"{x:1301,y:582,t:1528143607211};\\\", \\\"{x:1301,y:587,t:1528143607228};\\\", \\\"{x:1300,y:591,t:1528143607246};\\\", \\\"{x:1300,y:595,t:1528143607261};\\\", \\\"{x:1300,y:599,t:1528143607278};\\\", \\\"{x:1300,y:608,t:1528143607294};\\\", \\\"{x:1300,y:611,t:1528143607311};\\\", \\\"{x:1300,y:615,t:1528143607328};\\\", \\\"{x:1300,y:617,t:1528143607345};\\\", \\\"{x:1300,y:622,t:1528143607362};\\\", \\\"{x:1300,y:625,t:1528143607378};\\\", \\\"{x:1300,y:629,t:1528143607396};\\\", \\\"{x:1301,y:632,t:1528143607412};\\\", \\\"{x:1302,y:637,t:1528143607428};\\\", \\\"{x:1304,y:641,t:1528143607445};\\\", \\\"{x:1305,y:645,t:1528143607462};\\\", \\\"{x:1305,y:648,t:1528143607479};\\\", \\\"{x:1308,y:652,t:1528143607496};\\\", \\\"{x:1308,y:656,t:1528143607512};\\\", \\\"{x:1308,y:660,t:1528143607528};\\\", \\\"{x:1309,y:663,t:1528143607546};\\\", \\\"{x:1309,y:666,t:1528143607562};\\\", \\\"{x:1310,y:669,t:1528143607578};\\\", \\\"{x:1310,y:672,t:1528143607595};\\\", \\\"{x:1311,y:673,t:1528143607613};\\\", \\\"{x:1311,y:674,t:1528143607631};\\\", \\\"{x:1311,y:675,t:1528143607646};\\\", \\\"{x:1311,y:677,t:1528143607671};\\\", \\\"{x:1311,y:680,t:1528143607687};\\\", \\\"{x:1311,y:682,t:1528143607703};\\\", \\\"{x:1311,y:683,t:1528143607712};\\\", \\\"{x:1312,y:685,t:1528143607729};\\\", \\\"{x:1312,y:686,t:1528143607746};\\\", \\\"{x:1312,y:688,t:1528143607768};\\\", \\\"{x:1313,y:689,t:1528143607791};\\\", \\\"{x:1313,y:690,t:1528143607807};\\\", \\\"{x:1314,y:691,t:1528143607815};\\\", \\\"{x:1314,y:692,t:1528143607829};\\\", \\\"{x:1315,y:694,t:1528143607845};\\\", \\\"{x:1315,y:695,t:1528143607862};\\\", \\\"{x:1317,y:699,t:1528143607879};\\\", \\\"{x:1318,y:702,t:1528143607919};\\\", \\\"{x:1318,y:703,t:1528143607929};\\\", \\\"{x:1318,y:706,t:1528143607945};\\\", \\\"{x:1319,y:709,t:1528143607963};\\\", \\\"{x:1321,y:713,t:1528143607980};\\\", \\\"{x:1321,y:719,t:1528143607995};\\\", \\\"{x:1321,y:724,t:1528143608012};\\\", \\\"{x:1323,y:729,t:1528143608029};\\\", \\\"{x:1323,y:734,t:1528143608045};\\\", \\\"{x:1323,y:743,t:1528143608062};\\\", \\\"{x:1323,y:748,t:1528143608078};\\\", \\\"{x:1323,y:753,t:1528143608095};\\\", \\\"{x:1323,y:758,t:1528143608112};\\\", \\\"{x:1324,y:763,t:1528143608129};\\\", \\\"{x:1326,y:765,t:1528143608146};\\\", \\\"{x:1326,y:771,t:1528143608162};\\\", \\\"{x:1326,y:773,t:1528143608179};\\\", \\\"{x:1326,y:777,t:1528143608195};\\\", \\\"{x:1326,y:780,t:1528143608213};\\\", \\\"{x:1326,y:783,t:1528143608229};\\\", \\\"{x:1326,y:789,t:1528143608246};\\\", \\\"{x:1326,y:794,t:1528143608263};\\\", \\\"{x:1326,y:797,t:1528143608279};\\\", \\\"{x:1326,y:799,t:1528143608296};\\\", \\\"{x:1326,y:802,t:1528143608312};\\\", \\\"{x:1326,y:806,t:1528143608329};\\\", \\\"{x:1326,y:808,t:1528143608347};\\\", \\\"{x:1326,y:810,t:1528143608363};\\\", \\\"{x:1325,y:814,t:1528143608380};\\\", \\\"{x:1324,y:817,t:1528143608396};\\\", \\\"{x:1324,y:820,t:1528143608412};\\\", \\\"{x:1323,y:822,t:1528143608429};\\\", \\\"{x:1322,y:823,t:1528143608446};\\\", \\\"{x:1321,y:826,t:1528143608466};\\\", \\\"{x:1319,y:831,t:1528143608483};\\\", \\\"{x:1318,y:833,t:1528143608507};\\\", \\\"{x:1318,y:834,t:1528143608516};\\\", \\\"{x:1317,y:837,t:1528143608533};\\\", \\\"{x:1317,y:838,t:1528143608550};\\\", \\\"{x:1315,y:841,t:1528143608566};\\\", \\\"{x:1314,y:842,t:1528143608583};\\\", \\\"{x:1313,y:844,t:1528143608600};\\\", \\\"{x:1312,y:846,t:1528143608618};\\\", \\\"{x:1311,y:847,t:1528143608633};\\\", \\\"{x:1311,y:850,t:1528143608651};\\\", \\\"{x:1311,y:851,t:1528143608667};\\\", \\\"{x:1311,y:854,t:1528143608683};\\\", \\\"{x:1311,y:857,t:1528143608700};\\\", \\\"{x:1311,y:860,t:1528143608717};\\\", \\\"{x:1311,y:863,t:1528143608734};\\\", \\\"{x:1311,y:866,t:1528143608751};\\\", \\\"{x:1311,y:868,t:1528143608767};\\\", \\\"{x:1311,y:870,t:1528143608784};\\\", \\\"{x:1311,y:874,t:1528143608800};\\\", \\\"{x:1311,y:875,t:1528143608834};\\\", \\\"{x:1312,y:879,t:1528143608851};\\\", \\\"{x:1312,y:884,t:1528143608867};\\\", \\\"{x:1312,y:888,t:1528143608883};\\\", \\\"{x:1312,y:891,t:1528143608900};\\\", \\\"{x:1313,y:895,t:1528143608918};\\\", \\\"{x:1313,y:896,t:1528143608934};\\\", \\\"{x:1313,y:899,t:1528143608950};\\\", \\\"{x:1313,y:902,t:1528143608968};\\\", \\\"{x:1313,y:905,t:1528143608983};\\\", \\\"{x:1313,y:906,t:1528143609000};\\\", \\\"{x:1313,y:909,t:1528143609017};\\\", \\\"{x:1313,y:912,t:1528143609033};\\\", \\\"{x:1313,y:914,t:1528143609050};\\\", \\\"{x:1313,y:915,t:1528143609067};\\\", \\\"{x:1313,y:916,t:1528143609083};\\\", \\\"{x:1313,y:917,t:1528143609100};\\\", \\\"{x:1313,y:919,t:1528143609117};\\\", \\\"{x:1313,y:921,t:1528143609134};\\\", \\\"{x:1313,y:924,t:1528143609151};\\\", \\\"{x:1312,y:929,t:1528143609167};\\\", \\\"{x:1312,y:931,t:1528143609184};\\\", \\\"{x:1311,y:935,t:1528143609200};\\\", \\\"{x:1310,y:936,t:1528143609217};\\\", \\\"{x:1310,y:937,t:1528143609234};\\\", \\\"{x:1310,y:938,t:1528143609250};\\\", \\\"{x:1309,y:938,t:1528143609306};\\\", \\\"{x:1309,y:939,t:1528143609354};\\\", \\\"{x:1309,y:941,t:1528143609379};\\\", \\\"{x:1309,y:942,t:1528143609419};\\\", \\\"{x:1309,y:944,t:1528143609467};\\\", \\\"{x:1309,y:945,t:1528143609506};\\\", \\\"{x:1309,y:947,t:1528143609555};\\\", \\\"{x:1310,y:948,t:1528143609574};\\\", \\\"{x:1311,y:948,t:1528143609585};\\\", \\\"{x:1311,y:950,t:1528143609626};\\\", \\\"{x:1311,y:951,t:1528143609682};\\\", \\\"{x:1311,y:952,t:1528143609713};\\\", \\\"{x:1311,y:953,t:1528143609722};\\\", \\\"{x:1311,y:954,t:1528143609754};\\\", \\\"{x:1312,y:954,t:1528143609771};\\\", \\\"{x:1312,y:956,t:1528143609819};\\\", \\\"{x:1312,y:957,t:1528143609923};\\\", \\\"{x:1312,y:959,t:1528143610043};\\\", \\\"{x:1313,y:960,t:1528143618387};\\\", \\\"{x:1318,y:960,t:1528143618395};\\\", \\\"{x:1328,y:960,t:1528143618409};\\\", \\\"{x:1340,y:960,t:1528143618424};\\\", \\\"{x:1358,y:964,t:1528143618442};\\\", \\\"{x:1379,y:967,t:1528143618459};\\\", \\\"{x:1394,y:970,t:1528143618475};\\\", \\\"{x:1412,y:970,t:1528143618492};\\\", \\\"{x:1429,y:970,t:1528143618508};\\\", \\\"{x:1453,y:968,t:1528143618525};\\\", \\\"{x:1477,y:968,t:1528143618542};\\\", \\\"{x:1480,y:968,t:1528143618558};\\\", \\\"{x:1495,y:968,t:1528143618574};\\\", \\\"{x:1513,y:964,t:1528143618591};\\\", \\\"{x:1534,y:963,t:1528143618608};\\\", \\\"{x:1546,y:963,t:1528143618625};\\\", \\\"{x:1557,y:962,t:1528143618641};\\\", \\\"{x:1574,y:957,t:1528143618658};\\\", \\\"{x:1582,y:957,t:1528143618675};\\\", \\\"{x:1602,y:949,t:1528143618691};\\\", \\\"{x:1628,y:944,t:1528143618708};\\\", \\\"{x:1649,y:943,t:1528143618725};\\\", \\\"{x:1653,y:942,t:1528143618741};\\\", \\\"{x:1656,y:940,t:1528143618758};\\\", \\\"{x:1662,y:940,t:1528143618775};\\\", \\\"{x:1667,y:940,t:1528143618792};\\\", \\\"{x:1669,y:940,t:1528143618809};\\\", \\\"{x:1670,y:939,t:1528143618826};\\\", \\\"{x:1671,y:939,t:1528143618841};\\\", \\\"{x:1673,y:939,t:1528143618858};\\\", \\\"{x:1675,y:938,t:1528143618875};\\\", \\\"{x:1677,y:938,t:1528143618891};\\\", \\\"{x:1681,y:937,t:1528143618908};\\\", \\\"{x:1687,y:936,t:1528143618926};\\\", \\\"{x:1688,y:936,t:1528143618941};\\\", \\\"{x:1691,y:936,t:1528143618958};\\\", \\\"{x:1696,y:936,t:1528143618976};\\\", \\\"{x:1701,y:937,t:1528143618992};\\\", \\\"{x:1704,y:938,t:1528143619009};\\\", \\\"{x:1705,y:939,t:1528143619025};\\\", \\\"{x:1705,y:941,t:1528143619042};\\\", \\\"{x:1708,y:943,t:1528143619226};\\\", \\\"{x:1709,y:944,t:1528143619242};\\\", \\\"{x:1712,y:945,t:1528143619258};\\\", \\\"{x:1713,y:947,t:1528143619275};\\\", \\\"{x:1715,y:948,t:1528143619292};\\\", \\\"{x:1719,y:950,t:1528143619308};\\\", \\\"{x:1721,y:951,t:1528143619325};\\\", \\\"{x:1722,y:952,t:1528143619343};\\\", \\\"{x:1723,y:953,t:1528143619358};\\\", \\\"{x:1724,y:953,t:1528143619376};\\\", \\\"{x:1726,y:955,t:1528143619392};\\\", \\\"{x:1732,y:957,t:1528143619409};\\\", \\\"{x:1737,y:958,t:1528143619425};\\\", \\\"{x:1741,y:961,t:1528143619442};\\\", \\\"{x:1742,y:962,t:1528143619459};\\\", \\\"{x:1744,y:962,t:1528143619476};\\\", \\\"{x:1746,y:962,t:1528143619492};\\\", \\\"{x:1747,y:963,t:1528143619510};\\\", \\\"{x:1748,y:963,t:1528143619531};\\\", \\\"{x:1749,y:963,t:1528143619543};\\\", \\\"{x:1750,y:964,t:1528143619560};\\\", \\\"{x:1750,y:965,t:1528143619576};\\\", \\\"{x:1752,y:965,t:1528143619593};\\\", \\\"{x:1754,y:965,t:1528143619610};\\\", \\\"{x:1755,y:965,t:1528143619635};\\\", \\\"{x:1757,y:966,t:1528143620235};\\\", \\\"{x:1758,y:967,t:1528143620267};\\\", \\\"{x:1760,y:968,t:1528143620323};\\\", \\\"{x:1761,y:968,t:1528143620338};\\\", \\\"{x:1762,y:968,t:1528143620347};\\\", \\\"{x:1763,y:968,t:1528143620387};\\\", \\\"{x:1766,y:969,t:1528143620394};\\\", \\\"{x:1768,y:969,t:1528143620409};\\\", \\\"{x:1773,y:970,t:1528143620427};\\\", \\\"{x:1775,y:970,t:1528143620443};\\\", \\\"{x:1779,y:971,t:1528143620460};\\\", \\\"{x:1781,y:972,t:1528143620477};\\\", \\\"{x:1783,y:972,t:1528143620494};\\\", \\\"{x:1784,y:973,t:1528143620510};\\\", \\\"{x:1785,y:973,t:1528143620883};\\\", \\\"{x:1786,y:973,t:1528143620923};\\\", \\\"{x:1786,y:972,t:1528143620947};\\\", \\\"{x:1786,y:971,t:1528143620974};\\\", \\\"{x:1786,y:970,t:1528143620985};\\\", \\\"{x:1786,y:969,t:1528143621002};\\\", \\\"{x:1786,y:968,t:1528143621122};\\\", \\\"{x:1786,y:966,t:1528143621138};\\\", \\\"{x:1786,y:965,t:1528143621603};\\\", \\\"{x:1786,y:964,t:1528143623595};\\\", \\\"{x:1786,y:965,t:1528143624531};\\\", \\\"{x:1785,y:966,t:1528143624546};\\\", \\\"{x:1784,y:966,t:1528143624564};\\\", \\\"{x:1783,y:967,t:1528143624580};\\\", \\\"{x:1783,y:968,t:1528143624597};\\\", \\\"{x:1782,y:968,t:1528143624667};\\\", \\\"{x:1780,y:968,t:1528143624680};\\\", \\\"{x:1780,y:967,t:1528143624939};\\\", \\\"{x:1780,y:965,t:1528143624947};\\\", \\\"{x:1780,y:963,t:1528143624987};\\\", \\\"{x:1780,y:962,t:1528143625026};\\\", \\\"{x:1778,y:961,t:1528143626803};\\\", \\\"{x:1773,y:961,t:1528143626815};\\\", \\\"{x:1764,y:961,t:1528143626832};\\\", \\\"{x:1753,y:961,t:1528143626849};\\\", \\\"{x:1745,y:961,t:1528143626866};\\\", \\\"{x:1737,y:961,t:1528143626883};\\\", \\\"{x:1717,y:961,t:1528143626899};\\\", \\\"{x:1709,y:962,t:1528143626916};\\\", \\\"{x:1699,y:964,t:1528143626932};\\\", \\\"{x:1687,y:964,t:1528143626949};\\\", \\\"{x:1672,y:964,t:1528143626966};\\\", \\\"{x:1654,y:964,t:1528143626982};\\\", \\\"{x:1635,y:962,t:1528143626999};\\\", \\\"{x:1615,y:959,t:1528143627015};\\\", \\\"{x:1587,y:954,t:1528143627032};\\\", \\\"{x:1561,y:947,t:1528143627048};\\\", \\\"{x:1497,y:929,t:1528143627065};\\\", \\\"{x:1476,y:918,t:1528143627082};\\\", \\\"{x:1453,y:911,t:1528143627099};\\\", \\\"{x:1431,y:903,t:1528143627115};\\\", \\\"{x:1417,y:895,t:1528143627132};\\\", \\\"{x:1405,y:890,t:1528143627149};\\\", \\\"{x:1396,y:888,t:1528143627166};\\\", \\\"{x:1391,y:886,t:1528143627182};\\\", \\\"{x:1388,y:886,t:1528143627199};\\\", \\\"{x:1385,y:886,t:1528143627216};\\\", \\\"{x:1381,y:886,t:1528143627232};\\\", \\\"{x:1376,y:887,t:1528143627249};\\\", \\\"{x:1369,y:889,t:1528143627266};\\\", \\\"{x:1366,y:891,t:1528143627283};\\\", \\\"{x:1361,y:892,t:1528143627300};\\\", \\\"{x:1356,y:895,t:1528143627316};\\\", \\\"{x:1348,y:899,t:1528143627332};\\\", \\\"{x:1339,y:904,t:1528143627350};\\\", \\\"{x:1333,y:907,t:1528143627366};\\\", \\\"{x:1328,y:909,t:1528143627383};\\\", \\\"{x:1324,y:912,t:1528143627399};\\\", \\\"{x:1323,y:912,t:1528143627416};\\\", \\\"{x:1319,y:914,t:1528143627433};\\\", \\\"{x:1317,y:915,t:1528143627449};\\\", \\\"{x:1315,y:916,t:1528143627466};\\\", \\\"{x:1314,y:918,t:1528143627483};\\\", \\\"{x:1313,y:918,t:1528143627555};\\\", \\\"{x:1312,y:919,t:1528143627626};\\\", \\\"{x:1310,y:919,t:1528143627643};\\\", \\\"{x:1309,y:919,t:1528143627675};\\\", \\\"{x:1308,y:919,t:1528143627715};\\\", \\\"{x:1308,y:920,t:1528143627723};\\\", \\\"{x:1307,y:921,t:1528143627755};\\\", \\\"{x:1306,y:921,t:1528143627766};\\\", \\\"{x:1305,y:925,t:1528143627783};\\\", \\\"{x:1302,y:928,t:1528143627800};\\\", \\\"{x:1301,y:932,t:1528143627816};\\\", \\\"{x:1300,y:933,t:1528143627833};\\\", \\\"{x:1300,y:934,t:1528143627850};\\\", \\\"{x:1300,y:935,t:1528143627866};\\\", \\\"{x:1300,y:937,t:1528143627891};\\\", \\\"{x:1300,y:938,t:1528143627907};\\\", \\\"{x:1300,y:940,t:1528143627923};\\\", \\\"{x:1300,y:942,t:1528143627933};\\\", \\\"{x:1300,y:943,t:1528143627962};\\\", \\\"{x:1300,y:944,t:1528143627972};\\\", \\\"{x:1301,y:946,t:1528143627983};\\\", \\\"{x:1302,y:949,t:1528143628000};\\\", \\\"{x:1305,y:952,t:1528143628016};\\\", \\\"{x:1307,y:954,t:1528143628033};\\\", \\\"{x:1311,y:959,t:1528143628050};\\\", \\\"{x:1312,y:960,t:1528143628067};\\\", \\\"{x:1314,y:962,t:1528143628091};\\\", \\\"{x:1315,y:962,t:1528143628100};\\\", \\\"{x:1318,y:964,t:1528143628118};\\\", \\\"{x:1319,y:966,t:1528143628133};\\\", \\\"{x:1322,y:968,t:1528143628150};\\\", \\\"{x:1325,y:969,t:1528143628167};\\\", \\\"{x:1327,y:970,t:1528143628184};\\\", \\\"{x:1330,y:971,t:1528143628200};\\\", \\\"{x:1334,y:972,t:1528143628217};\\\", \\\"{x:1336,y:973,t:1528143628233};\\\", \\\"{x:1338,y:973,t:1528143628250};\\\", \\\"{x:1339,y:973,t:1528143628267};\\\", \\\"{x:1340,y:973,t:1528143628283};\\\", \\\"{x:1341,y:973,t:1528143628339};\\\", \\\"{x:1344,y:973,t:1528143628354};\\\", \\\"{x:1346,y:973,t:1528143628372};\\\", \\\"{x:1347,y:972,t:1528143628383};\\\", \\\"{x:1348,y:972,t:1528143628401};\\\", \\\"{x:1349,y:972,t:1528143628417};\\\", \\\"{x:1350,y:972,t:1528143628433};\\\", \\\"{x:1351,y:970,t:1528143628449};\\\", \\\"{x:1354,y:968,t:1528143628907};\\\", \\\"{x:1355,y:967,t:1528143628922};\\\", \\\"{x:1356,y:967,t:1528143628934};\\\", \\\"{x:1357,y:967,t:1528143628951};\\\", \\\"{x:1359,y:967,t:1528143628973};\\\", \\\"{x:1360,y:967,t:1528143628985};\\\", \\\"{x:1363,y:967,t:1528143629002};\\\", \\\"{x:1364,y:967,t:1528143629019};\\\", \\\"{x:1367,y:967,t:1528143629035};\\\", \\\"{x:1370,y:967,t:1528143629051};\\\", \\\"{x:1371,y:967,t:1528143629068};\\\", \\\"{x:1372,y:967,t:1528143629084};\\\", \\\"{x:1373,y:967,t:1528143629373};\\\", \\\"{x:1374,y:967,t:1528143629435};\\\", \\\"{x:1375,y:967,t:1528143629467};\\\", \\\"{x:1377,y:967,t:1528143629474};\\\", \\\"{x:1378,y:967,t:1528143629531};\\\", \\\"{x:1379,y:967,t:1528143629555};\\\", \\\"{x:1381,y:967,t:1528143629569};\\\", \\\"{x:1382,y:967,t:1528143629586};\\\", \\\"{x:1383,y:967,t:1528143629602};\\\", \\\"{x:1386,y:965,t:1528143629691};\\\", \\\"{x:1387,y:965,t:1528143629755};\\\", \\\"{x:1389,y:965,t:1528143629795};\\\", \\\"{x:1390,y:965,t:1528143629802};\\\", \\\"{x:1392,y:965,t:1528143629819};\\\", \\\"{x:1395,y:965,t:1528143629834};\\\", \\\"{x:1397,y:965,t:1528143629851};\\\", \\\"{x:1398,y:965,t:1528143629868};\\\", \\\"{x:1399,y:964,t:1528143629886};\\\", \\\"{x:1400,y:963,t:1528143629902};\\\", \\\"{x:1401,y:963,t:1528143629939};\\\", \\\"{x:1402,y:963,t:1528143629972};\\\", \\\"{x:1402,y:962,t:1528143630003};\\\", \\\"{x:1403,y:962,t:1528143630043};\\\", \\\"{x:1404,y:962,t:1528143630074};\\\", \\\"{x:1405,y:962,t:1528143630195};\\\", \\\"{x:1407,y:962,t:1528143630210};\\\", \\\"{x:1408,y:962,t:1528143630411};\\\", \\\"{x:1409,y:962,t:1528143630419};\\\", \\\"{x:1411,y:962,t:1528143630435};\\\", \\\"{x:1411,y:961,t:1528143630452};\\\", \\\"{x:1413,y:960,t:1528143630491};\\\", \\\"{x:1413,y:959,t:1528143630547};\\\", \\\"{x:1415,y:957,t:1528143630643};\\\", \\\"{x:1417,y:957,t:1528143630667};\\\", \\\"{x:1418,y:957,t:1528143630674};\\\", \\\"{x:1421,y:957,t:1528143630691};\\\", \\\"{x:1423,y:957,t:1528143630702};\\\", \\\"{x:1427,y:957,t:1528143630720};\\\", \\\"{x:1429,y:958,t:1528143630735};\\\", \\\"{x:1440,y:961,t:1528143630753};\\\", \\\"{x:1452,y:965,t:1528143630769};\\\", \\\"{x:1458,y:967,t:1528143630785};\\\", \\\"{x:1466,y:970,t:1528143630803};\\\", \\\"{x:1469,y:971,t:1528143630819};\\\", \\\"{x:1470,y:972,t:1528143630835};\\\", \\\"{x:1471,y:973,t:1528143631355};\\\", \\\"{x:1472,y:973,t:1528143631451};\\\", \\\"{x:1473,y:973,t:1528143631459};\\\", \\\"{x:1474,y:972,t:1528143631482};\\\", \\\"{x:1475,y:972,t:1528143631522};\\\", \\\"{x:1476,y:972,t:1528143631547};\\\", \\\"{x:1478,y:972,t:1528143631763};\\\", \\\"{x:1480,y:972,t:1528143631771};\\\", \\\"{x:1482,y:972,t:1528143631787};\\\", \\\"{x:1487,y:969,t:1528143631803};\\\", \\\"{x:1491,y:968,t:1528143631821};\\\", \\\"{x:1493,y:968,t:1528143631836};\\\", \\\"{x:1494,y:967,t:1528143631853};\\\", \\\"{x:1496,y:965,t:1528143631875};\\\", \\\"{x:1497,y:965,t:1528143631886};\\\", \\\"{x:1499,y:965,t:1528143631903};\\\", \\\"{x:1500,y:965,t:1528143631920};\\\", \\\"{x:1503,y:964,t:1528143631937};\\\", \\\"{x:1505,y:964,t:1528143631954};\\\", \\\"{x:1508,y:963,t:1528143631971};\\\", \\\"{x:1509,y:962,t:1528143631987};\\\", \\\"{x:1510,y:962,t:1528143632003};\\\", \\\"{x:1511,y:962,t:1528143632035};\\\", \\\"{x:1513,y:960,t:1528143632083};\\\", \\\"{x:1514,y:960,t:1528143632091};\\\", \\\"{x:1515,y:960,t:1528143632103};\\\", \\\"{x:1517,y:959,t:1528143632120};\\\", \\\"{x:1519,y:959,t:1528143632587};\\\", \\\"{x:1522,y:959,t:1528143632610};\\\", \\\"{x:1523,y:959,t:1528143632634};\\\", \\\"{x:1526,y:960,t:1528143632642};\\\", \\\"{x:1527,y:960,t:1528143632667};\\\", \\\"{x:1528,y:960,t:1528143632683};\\\", \\\"{x:1529,y:960,t:1528143632715};\\\", \\\"{x:1530,y:961,t:1528143632731};\\\", \\\"{x:1531,y:962,t:1528143632772};\\\", \\\"{x:1532,y:962,t:1528143632787};\\\", \\\"{x:1536,y:963,t:1528143632805};\\\", \\\"{x:1538,y:964,t:1528143632827};\\\", \\\"{x:1539,y:965,t:1528143632838};\\\", \\\"{x:1541,y:965,t:1528143632930};\\\", \\\"{x:1543,y:965,t:1528143632946};\\\", \\\"{x:1544,y:965,t:1528143632963};\\\", \\\"{x:1545,y:965,t:1528143632972};\\\", \\\"{x:1546,y:965,t:1528143632986};\\\", \\\"{x:1548,y:965,t:1528143633003};\\\", \\\"{x:1549,y:965,t:1528143633019};\\\", \\\"{x:1552,y:965,t:1528143633339};\\\", \\\"{x:1558,y:965,t:1528143633354};\\\", \\\"{x:1560,y:965,t:1528143633371};\\\", \\\"{x:1562,y:965,t:1528143633388};\\\", \\\"{x:1569,y:963,t:1528143633404};\\\", \\\"{x:1573,y:963,t:1528143633421};\\\", \\\"{x:1574,y:963,t:1528143633437};\\\", \\\"{x:1576,y:963,t:1528143633499};\\\", \\\"{x:1577,y:963,t:1528143633530};\\\", \\\"{x:1577,y:962,t:1528143633538};\\\", \\\"{x:1579,y:962,t:1528143633574};\\\", \\\"{x:1580,y:963,t:1528143633755};\\\", \\\"{x:1583,y:964,t:1528143633915};\\\", \\\"{x:1584,y:964,t:1528143633946};\\\", \\\"{x:1585,y:964,t:1528143634451};\\\", \\\"{x:1586,y:965,t:1528143634459};\\\", \\\"{x:1588,y:965,t:1528143634473};\\\", \\\"{x:1590,y:966,t:1528143634489};\\\", \\\"{x:1592,y:967,t:1528143634505};\\\", \\\"{x:1593,y:967,t:1528143634611};\\\", \\\"{x:1594,y:968,t:1528143634623};\\\", \\\"{x:1594,y:969,t:1528143634659};\\\", \\\"{x:1595,y:969,t:1528143634690};\\\", \\\"{x:1596,y:969,t:1528143634707};\\\", \\\"{x:1600,y:967,t:1528143634787};\\\", \\\"{x:1601,y:967,t:1528143634810};\\\", \\\"{x:1602,y:967,t:1528143634827};\\\", \\\"{x:1603,y:967,t:1528143634859};\\\", \\\"{x:1604,y:966,t:1528143634875};\\\", \\\"{x:1605,y:965,t:1528143634899};\\\", \\\"{x:1606,y:965,t:1528143634907};\\\", \\\"{x:1608,y:964,t:1528143634922};\\\", \\\"{x:1612,y:963,t:1528143634939};\\\", \\\"{x:1613,y:962,t:1528143634956};\\\", \\\"{x:1614,y:961,t:1528143634995};\\\", \\\"{x:1615,y:960,t:1528143635099};\\\", \\\"{x:1616,y:959,t:1528143635267};\\\", \\\"{x:1617,y:959,t:1528143635299};\\\", \\\"{x:1619,y:959,t:1528143635305};\\\", \\\"{x:1623,y:959,t:1528143635321};\\\", \\\"{x:1624,y:959,t:1528143635339};\\\", \\\"{x:1628,y:959,t:1528143635356};\\\", \\\"{x:1630,y:959,t:1528143635372};\\\", \\\"{x:1632,y:959,t:1528143635389};\\\", \\\"{x:1633,y:959,t:1528143635406};\\\", \\\"{x:1635,y:959,t:1528143635422};\\\", \\\"{x:1637,y:959,t:1528143635439};\\\", \\\"{x:1638,y:959,t:1528143635474};\\\", \\\"{x:1639,y:959,t:1528143635490};\\\", \\\"{x:1641,y:958,t:1528143635563};\\\", \\\"{x:1642,y:958,t:1528143635795};\\\", \\\"{x:1643,y:958,t:1528143635806};\\\", \\\"{x:1644,y:958,t:1528143635824};\\\", \\\"{x:1645,y:958,t:1528143635839};\\\", \\\"{x:1647,y:958,t:1528143635857};\\\", \\\"{x:1648,y:958,t:1528143635873};\\\", \\\"{x:1650,y:958,t:1528143635891};\\\", \\\"{x:1653,y:958,t:1528143635906};\\\", \\\"{x:1654,y:958,t:1528143635930};\\\", \\\"{x:1655,y:958,t:1528143635941};\\\", \\\"{x:1658,y:958,t:1528143635957};\\\", \\\"{x:1659,y:958,t:1528143635973};\\\", \\\"{x:1661,y:959,t:1528143635991};\\\", \\\"{x:1664,y:959,t:1528143636007};\\\", \\\"{x:1665,y:959,t:1528143636115};\\\", \\\"{x:1666,y:959,t:1528143636154};\\\", \\\"{x:1667,y:959,t:1528143636178};\\\", \\\"{x:1669,y:959,t:1528143636307};\\\", \\\"{x:1670,y:959,t:1528143636355};\\\", \\\"{x:1672,y:959,t:1528143636426};\\\", \\\"{x:1673,y:959,t:1528143636467};\\\", \\\"{x:1676,y:959,t:1528143636475};\\\", \\\"{x:1680,y:959,t:1528143636490};\\\", \\\"{x:1684,y:959,t:1528143636507};\\\", \\\"{x:1686,y:959,t:1528143636523};\\\", \\\"{x:1687,y:960,t:1528143636540};\\\", \\\"{x:1690,y:963,t:1528143636557};\\\", \\\"{x:1693,y:964,t:1528143636573};\\\", \\\"{x:1696,y:966,t:1528143636590};\\\", \\\"{x:1697,y:966,t:1528143636607};\\\", \\\"{x:1698,y:966,t:1528143636707};\\\", \\\"{x:1699,y:966,t:1528143636739};\\\", \\\"{x:1701,y:966,t:1528143636755};\\\", \\\"{x:1703,y:966,t:1528143636763};\\\", \\\"{x:1705,y:967,t:1528143636774};\\\", \\\"{x:1706,y:967,t:1528143636790};\\\", \\\"{x:1709,y:967,t:1528143636808};\\\", \\\"{x:1710,y:967,t:1528143636875};\\\", \\\"{x:1712,y:967,t:1528143636890};\\\", \\\"{x:1714,y:967,t:1528143636947};\\\", \\\"{x:1717,y:965,t:1528143637258};\\\", \\\"{x:1718,y:964,t:1528143637275};\\\", \\\"{x:1720,y:963,t:1528143637291};\\\", \\\"{x:1721,y:962,t:1528143637314};\\\", \\\"{x:1722,y:962,t:1528143637325};\\\", \\\"{x:1724,y:962,t:1528143637341};\\\", \\\"{x:1724,y:961,t:1528143637372};\\\", \\\"{x:1725,y:960,t:1528143637402};\\\", \\\"{x:1727,y:960,t:1528143637418};\\\", \\\"{x:1727,y:959,t:1528143637426};\\\", \\\"{x:1729,y:959,t:1528143637578};\\\", \\\"{x:1730,y:959,t:1528143637626};\\\", \\\"{x:1732,y:959,t:1528143637642};\\\", \\\"{x:1736,y:959,t:1528143637658};\\\", \\\"{x:1737,y:959,t:1528143637674};\\\", \\\"{x:1739,y:959,t:1528143637692};\\\", \\\"{x:1741,y:959,t:1528143637772};\\\", \\\"{x:1742,y:959,t:1528143637843};\\\", \\\"{x:1744,y:960,t:1528143637874};\\\", \\\"{x:1746,y:961,t:1528143637891};\\\", \\\"{x:1748,y:962,t:1528143637909};\\\", \\\"{x:1750,y:964,t:1528143637925};\\\", \\\"{x:1755,y:966,t:1528143637942};\\\", \\\"{x:1760,y:968,t:1528143637958};\\\", \\\"{x:1766,y:970,t:1528143637976};\\\", \\\"{x:1771,y:972,t:1528143637992};\\\", \\\"{x:1773,y:974,t:1528143638009};\\\", \\\"{x:1773,y:975,t:1528143638026};\\\", \\\"{x:1775,y:975,t:1528143638059};\\\", \\\"{x:1776,y:975,t:1528143638131};\\\", \\\"{x:1778,y:975,t:1528143638154};\\\", \\\"{x:1779,y:975,t:1528143638203};\\\", \\\"{x:1781,y:975,t:1528143638258};\\\", \\\"{x:1782,y:975,t:1528143638299};\\\", \\\"{x:1772,y:975,t:1528143638875};\\\", \\\"{x:1757,y:975,t:1528143638892};\\\", \\\"{x:1706,y:971,t:1528143638911};\\\", \\\"{x:1647,y:961,t:1528143638926};\\\", \\\"{x:1563,y:935,t:1528143638943};\\\", \\\"{x:1465,y:903,t:1528143638959};\\\", \\\"{x:1378,y:868,t:1528143638976};\\\", \\\"{x:1319,y:851,t:1528143638992};\\\", \\\"{x:1305,y:845,t:1528143639009};\\\", \\\"{x:1294,y:842,t:1528143639026};\\\", \\\"{x:1285,y:840,t:1528143639043};\\\", \\\"{x:1284,y:840,t:1528143639060};\\\", \\\"{x:1282,y:840,t:1528143639076};\\\", \\\"{x:1280,y:841,t:1528143639093};\\\", \\\"{x:1278,y:846,t:1528143639109};\\\", \\\"{x:1272,y:854,t:1528143639125};\\\", \\\"{x:1268,y:859,t:1528143639143};\\\", \\\"{x:1264,y:866,t:1528143639160};\\\", \\\"{x:1256,y:880,t:1528143639176};\\\", \\\"{x:1253,y:889,t:1528143639193};\\\", \\\"{x:1249,y:901,t:1528143639209};\\\", \\\"{x:1248,y:908,t:1528143639226};\\\", \\\"{x:1248,y:916,t:1528143639242};\\\", \\\"{x:1247,y:921,t:1528143639259};\\\", \\\"{x:1246,y:923,t:1528143639276};\\\", \\\"{x:1245,y:926,t:1528143639292};\\\", \\\"{x:1245,y:931,t:1528143639309};\\\", \\\"{x:1245,y:937,t:1528143639326};\\\", \\\"{x:1245,y:941,t:1528143639342};\\\", \\\"{x:1246,y:944,t:1528143639359};\\\", \\\"{x:1247,y:946,t:1528143639376};\\\", \\\"{x:1247,y:948,t:1528143639392};\\\", \\\"{x:1247,y:950,t:1528143639409};\\\", \\\"{x:1247,y:953,t:1528143639426};\\\", \\\"{x:1247,y:956,t:1528143639442};\\\", \\\"{x:1247,y:959,t:1528143639459};\\\", \\\"{x:1248,y:962,t:1528143639476};\\\", \\\"{x:1250,y:966,t:1528143639492};\\\", \\\"{x:1251,y:969,t:1528143639509};\\\", \\\"{x:1254,y:970,t:1528143639526};\\\", \\\"{x:1254,y:972,t:1528143639543};\\\", \\\"{x:1256,y:972,t:1528143639562};\\\", \\\"{x:1256,y:973,t:1528143639577};\\\", \\\"{x:1257,y:973,t:1528143639593};\\\", \\\"{x:1259,y:973,t:1528143639609};\\\", \\\"{x:1263,y:973,t:1528143639627};\\\", \\\"{x:1266,y:971,t:1528143639643};\\\", \\\"{x:1274,y:967,t:1528143639660};\\\", \\\"{x:1283,y:956,t:1528143639677};\\\", \\\"{x:1292,y:941,t:1528143639694};\\\", \\\"{x:1297,y:931,t:1528143639709};\\\", \\\"{x:1309,y:908,t:1528143639726};\\\", \\\"{x:1319,y:884,t:1528143639744};\\\", \\\"{x:1332,y:844,t:1528143639760};\\\", \\\"{x:1345,y:781,t:1528143639777};\\\", \\\"{x:1358,y:724,t:1528143639793};\\\", \\\"{x:1366,y:676,t:1528143639809};\\\", \\\"{x:1372,y:631,t:1528143639827};\\\", \\\"{x:1371,y:608,t:1528143639844};\\\", \\\"{x:1371,y:589,t:1528143639860};\\\", \\\"{x:1366,y:568,t:1528143639877};\\\", \\\"{x:1361,y:550,t:1528143639894};\\\", \\\"{x:1359,y:543,t:1528143639910};\\\", \\\"{x:1357,y:541,t:1528143639927};\\\", \\\"{x:1356,y:540,t:1528143639972};\\\", \\\"{x:1355,y:540,t:1528143640034};\\\", \\\"{x:1354,y:540,t:1528143640075};\\\", \\\"{x:1352,y:539,t:1528143640090};\\\", \\\"{x:1351,y:539,t:1528143640099};\\\", \\\"{x:1350,y:538,t:1528143640109};\\\", \\\"{x:1344,y:537,t:1528143640127};\\\", \\\"{x:1343,y:535,t:1528143640144};\\\", \\\"{x:1342,y:534,t:1528143640161};\\\", \\\"{x:1340,y:531,t:1528143640177};\\\", \\\"{x:1339,y:530,t:1528143640193};\\\", \\\"{x:1338,y:528,t:1528143640211};\\\", \\\"{x:1337,y:526,t:1528143640226};\\\", \\\"{x:1336,y:524,t:1528143640244};\\\", \\\"{x:1335,y:523,t:1528143640266};\\\", \\\"{x:1334,y:522,t:1528143640283};\\\", \\\"{x:1333,y:525,t:1528143640387};\\\", \\\"{x:1327,y:535,t:1528143640395};\\\", \\\"{x:1315,y:560,t:1528143640410};\\\", \\\"{x:1306,y:584,t:1528143640428};\\\", \\\"{x:1301,y:604,t:1528143640444};\\\", \\\"{x:1294,y:625,t:1528143640461};\\\", \\\"{x:1290,y:642,t:1528143640477};\\\", \\\"{x:1288,y:652,t:1528143640493};\\\", \\\"{x:1287,y:657,t:1528143640511};\\\", \\\"{x:1283,y:668,t:1528143640527};\\\", \\\"{x:1283,y:676,t:1528143640544};\\\", \\\"{x:1283,y:684,t:1528143640561};\\\", \\\"{x:1283,y:691,t:1528143640578};\\\", \\\"{x:1283,y:700,t:1528143640593};\\\", \\\"{x:1284,y:710,t:1528143640611};\\\", \\\"{x:1284,y:715,t:1528143640628};\\\", \\\"{x:1285,y:718,t:1528143640644};\\\", \\\"{x:1285,y:722,t:1528143640660};\\\", \\\"{x:1286,y:726,t:1528143640678};\\\", \\\"{x:1286,y:731,t:1528143640693};\\\", \\\"{x:1286,y:734,t:1528143640710};\\\", \\\"{x:1288,y:741,t:1528143640728};\\\", \\\"{x:1288,y:744,t:1528143640744};\\\", \\\"{x:1288,y:749,t:1528143640760};\\\", \\\"{x:1288,y:755,t:1528143640778};\\\", \\\"{x:1289,y:761,t:1528143640794};\\\", \\\"{x:1289,y:767,t:1528143640811};\\\", \\\"{x:1289,y:771,t:1528143640828};\\\", \\\"{x:1290,y:774,t:1528143640844};\\\", \\\"{x:1290,y:777,t:1528143640861};\\\", \\\"{x:1290,y:781,t:1528143640878};\\\", \\\"{x:1291,y:784,t:1528143640895};\\\", \\\"{x:1291,y:787,t:1528143640910};\\\", \\\"{x:1291,y:790,t:1528143640927};\\\", \\\"{x:1291,y:796,t:1528143640945};\\\", \\\"{x:1290,y:800,t:1528143640961};\\\", \\\"{x:1288,y:800,t:1528143640978};\\\", \\\"{x:1288,y:802,t:1528143641010};\\\", \\\"{x:1288,y:805,t:1528143641027};\\\", \\\"{x:1288,y:809,t:1528143641045};\\\", \\\"{x:1287,y:814,t:1528143641060};\\\", \\\"{x:1287,y:818,t:1528143641078};\\\", \\\"{x:1285,y:823,t:1528143641095};\\\", \\\"{x:1285,y:825,t:1528143641111};\\\", \\\"{x:1284,y:828,t:1528143641128};\\\", \\\"{x:1284,y:830,t:1528143641144};\\\", \\\"{x:1282,y:832,t:1528143641160};\\\", \\\"{x:1282,y:834,t:1528143641177};\\\", \\\"{x:1282,y:838,t:1528143641195};\\\", \\\"{x:1282,y:841,t:1528143641211};\\\", \\\"{x:1285,y:845,t:1528143641228};\\\", \\\"{x:1285,y:846,t:1528143641245};\\\", \\\"{x:1285,y:848,t:1528143641261};\\\", \\\"{x:1285,y:849,t:1528143641278};\\\", \\\"{x:1286,y:851,t:1528143641294};\\\", \\\"{x:1288,y:852,t:1528143641312};\\\", \\\"{x:1288,y:854,t:1528143641328};\\\", \\\"{x:1289,y:856,t:1528143641345};\\\", \\\"{x:1292,y:861,t:1528143641362};\\\", \\\"{x:1292,y:863,t:1528143641378};\\\", \\\"{x:1293,y:866,t:1528143641402};\\\", \\\"{x:1294,y:867,t:1528143641411};\\\", \\\"{x:1294,y:869,t:1528143641428};\\\", \\\"{x:1294,y:871,t:1528143641445};\\\", \\\"{x:1295,y:873,t:1528143641462};\\\", \\\"{x:1295,y:876,t:1528143641477};\\\", \\\"{x:1295,y:879,t:1528143641495};\\\", \\\"{x:1295,y:883,t:1528143641512};\\\", \\\"{x:1295,y:884,t:1528143641528};\\\", \\\"{x:1295,y:888,t:1528143641545};\\\", \\\"{x:1295,y:892,t:1528143641562};\\\", \\\"{x:1295,y:897,t:1528143641578};\\\", \\\"{x:1295,y:905,t:1528143641594};\\\", \\\"{x:1294,y:912,t:1528143641612};\\\", \\\"{x:1291,y:917,t:1528143641627};\\\", \\\"{x:1290,y:923,t:1528143641645};\\\", \\\"{x:1290,y:926,t:1528143641661};\\\", \\\"{x:1290,y:932,t:1528143641679};\\\", \\\"{x:1290,y:933,t:1528143641695};\\\", \\\"{x:1290,y:935,t:1528143641730};\\\", \\\"{x:1291,y:936,t:1528143641772};\\\", \\\"{x:1292,y:938,t:1528143641819};\\\", \\\"{x:1292,y:940,t:1528143641843};\\\", \\\"{x:1294,y:941,t:1528143641851};\\\", \\\"{x:1294,y:943,t:1528143641862};\\\", \\\"{x:1295,y:945,t:1528143641879};\\\", \\\"{x:1295,y:946,t:1528143641895};\\\", \\\"{x:1296,y:949,t:1528143641912};\\\", \\\"{x:1296,y:950,t:1528143641928};\\\", \\\"{x:1298,y:951,t:1528143641945};\\\", \\\"{x:1298,y:952,t:1528143641962};\\\", \\\"{x:1299,y:953,t:1528143641987};\\\", \\\"{x:1299,y:954,t:1528143641995};\\\", \\\"{x:1300,y:955,t:1528143642011};\\\", \\\"{x:1301,y:956,t:1528143642029};\\\", \\\"{x:1302,y:958,t:1528143642044};\\\", \\\"{x:1304,y:960,t:1528143642066};\\\", \\\"{x:1304,y:961,t:1528143642106};\\\", \\\"{x:1305,y:962,t:1528143642154};\\\", \\\"{x:1306,y:962,t:1528143642362};\\\", \\\"{x:1307,y:962,t:1528143642379};\\\", \\\"{x:1309,y:963,t:1528143642435};\\\", \\\"{x:1311,y:964,t:1528143642451};\\\", \\\"{x:1311,y:965,t:1528143642467};\\\", \\\"{x:1312,y:965,t:1528143642498};\\\", \\\"{x:1314,y:966,t:1528143642763};\\\", \\\"{x:1317,y:966,t:1528143642786};\\\", \\\"{x:1318,y:966,t:1528143642796};\\\", \\\"{x:1320,y:966,t:1528143642813};\\\", \\\"{x:1322,y:966,t:1528143642829};\\\", \\\"{x:1324,y:966,t:1528143642846};\\\", \\\"{x:1325,y:966,t:1528143642863};\\\", \\\"{x:1327,y:966,t:1528143642880};\\\", \\\"{x:1328,y:966,t:1528143643003};\\\", \\\"{x:1331,y:966,t:1528143643013};\\\", \\\"{x:1338,y:966,t:1528143643030};\\\", \\\"{x:1340,y:966,t:1528143643046};\\\", \\\"{x:1341,y:966,t:1528143643064};\\\", \\\"{x:1342,y:966,t:1528143643131};\\\", \\\"{x:1344,y:966,t:1528143643179};\\\", \\\"{x:1345,y:965,t:1528143643196};\\\", \\\"{x:1346,y:964,t:1528143643213};\\\", \\\"{x:1347,y:963,t:1528143643243};\\\", \\\"{x:1348,y:963,t:1528143643347};\\\", \\\"{x:1349,y:962,t:1528143643363};\\\", \\\"{x:1352,y:962,t:1528143643380};\\\", \\\"{x:1353,y:962,t:1528143643397};\\\", \\\"{x:1355,y:962,t:1528143643413};\\\", \\\"{x:1356,y:962,t:1528143643430};\\\", \\\"{x:1358,y:962,t:1528143643447};\\\", \\\"{x:1360,y:962,t:1528143643464};\\\", \\\"{x:1367,y:962,t:1528143643481};\\\", \\\"{x:1372,y:962,t:1528143643496};\\\", \\\"{x:1376,y:962,t:1528143643513};\\\", \\\"{x:1382,y:963,t:1528143643530};\\\", \\\"{x:1384,y:963,t:1528143643547};\\\", \\\"{x:1386,y:965,t:1528143643563};\\\", \\\"{x:1388,y:965,t:1528143643610};\\\", \\\"{x:1389,y:965,t:1528143643666};\\\", \\\"{x:1391,y:965,t:1528143644051};\\\", \\\"{x:1392,y:965,t:1528143644064};\\\", \\\"{x:1393,y:965,t:1528143644090};\\\", \\\"{x:1394,y:965,t:1528143644098};\\\", \\\"{x:1396,y:966,t:1528143644114};\\\", \\\"{x:1398,y:966,t:1528143644130};\\\", \\\"{x:1401,y:967,t:1528143644147};\\\", \\\"{x:1403,y:968,t:1528143644164};\\\", \\\"{x:1405,y:968,t:1528143644180};\\\", \\\"{x:1408,y:968,t:1528143644196};\\\", \\\"{x:1409,y:968,t:1528143644306};\\\", \\\"{x:1411,y:968,t:1528143644386};\\\", \\\"{x:1412,y:968,t:1528143644498};\\\", \\\"{x:1416,y:968,t:1528143644795};\\\", \\\"{x:1419,y:968,t:1528143644803};\\\", \\\"{x:1422,y:968,t:1528143644813};\\\", \\\"{x:1426,y:968,t:1528143644831};\\\", \\\"{x:1428,y:968,t:1528143644848};\\\", \\\"{x:1429,y:968,t:1528143644899};\\\", \\\"{x:1430,y:968,t:1528143644914};\\\", \\\"{x:1431,y:968,t:1528143644931};\\\", \\\"{x:1432,y:968,t:1528143644948};\\\", \\\"{x:1433,y:968,t:1528143644964};\\\", \\\"{x:1434,y:968,t:1528143645083};\\\", \\\"{x:1436,y:968,t:1528143645098};\\\", \\\"{x:1437,y:968,t:1528143645146};\\\", \\\"{x:1439,y:967,t:1528143645155};\\\", \\\"{x:1439,y:966,t:1528143645172};\\\", \\\"{x:1440,y:966,t:1528143645181};\\\", \\\"{x:1442,y:965,t:1528143645198};\\\", \\\"{x:1443,y:964,t:1528143645214};\\\", \\\"{x:1447,y:964,t:1528143645230};\\\", \\\"{x:1448,y:963,t:1528143645247};\\\", \\\"{x:1450,y:962,t:1528143645265};\\\", \\\"{x:1451,y:962,t:1528143645281};\\\", \\\"{x:1452,y:962,t:1528143645298};\\\", \\\"{x:1453,y:961,t:1528143645315};\\\", \\\"{x:1455,y:961,t:1528143645578};\\\", \\\"{x:1457,y:960,t:1528143645594};\\\", \\\"{x:1459,y:960,t:1528143645602};\\\", \\\"{x:1460,y:960,t:1528143645651};\\\", \\\"{x:1463,y:960,t:1528143645665};\\\", \\\"{x:1467,y:961,t:1528143645682};\\\", \\\"{x:1467,y:962,t:1528143645698};\\\", \\\"{x:1468,y:963,t:1528143645715};\\\", \\\"{x:1469,y:963,t:1528143645801};\\\", \\\"{x:1471,y:963,t:1528143645826};\\\", \\\"{x:1472,y:963,t:1528143645834};\\\", \\\"{x:1475,y:963,t:1528143645848};\\\", \\\"{x:1480,y:963,t:1528143645864};\\\", \\\"{x:1487,y:963,t:1528143645881};\\\", \\\"{x:1490,y:963,t:1528143645898};\\\", \\\"{x:1493,y:963,t:1528143645915};\\\", \\\"{x:1494,y:963,t:1528143646043};\\\", \\\"{x:1497,y:963,t:1528143646083};\\\", \\\"{x:1499,y:963,t:1528143646099};\\\", \\\"{x:1500,y:963,t:1528143646115};\\\", \\\"{x:1501,y:963,t:1528143646179};\\\", \\\"{x:1502,y:963,t:1528143646194};\\\", \\\"{x:1503,y:963,t:1528143646234};\\\", \\\"{x:1504,y:963,t:1528143646251};\\\", \\\"{x:1505,y:963,t:1528143646283};\\\", \\\"{x:1506,y:963,t:1528143646323};\\\", \\\"{x:1507,y:963,t:1528143646355};\\\", \\\"{x:1509,y:963,t:1528143646372};\\\", \\\"{x:1510,y:963,t:1528143646382};\\\", \\\"{x:1511,y:963,t:1528143646399};\\\", \\\"{x:1512,y:963,t:1528143646416};\\\", \\\"{x:1513,y:963,t:1528143646432};\\\", \\\"{x:1512,y:963,t:1528143650387};\\\", \\\"{x:1489,y:958,t:1528143650403};\\\", \\\"{x:1444,y:939,t:1528143650419};\\\", \\\"{x:1386,y:913,t:1528143650437};\\\", \\\"{x:1288,y:862,t:1528143650452};\\\", \\\"{x:1197,y:820,t:1528143650470};\\\", \\\"{x:1111,y:785,t:1528143650486};\\\", \\\"{x:1060,y:757,t:1528143650503};\\\", \\\"{x:1019,y:733,t:1528143650520};\\\", \\\"{x:980,y:714,t:1528143650537};\\\", \\\"{x:953,y:697,t:1528143650552};\\\", \\\"{x:945,y:692,t:1528143650569};\\\", \\\"{x:944,y:692,t:1528143650618};\\\", \\\"{x:945,y:692,t:1528143651227};\\\", \\\"{x:946,y:692,t:1528143651236};\\\", \\\"{x:960,y:693,t:1528143651253};\\\", \\\"{x:981,y:699,t:1528143651270};\\\", \\\"{x:1007,y:711,t:1528143651285};\\\", \\\"{x:1027,y:718,t:1528143651303};\\\", \\\"{x:1043,y:726,t:1528143651320};\\\", \\\"{x:1065,y:732,t:1528143651336};\\\", \\\"{x:1089,y:739,t:1528143651353};\\\", \\\"{x:1145,y:745,t:1528143651369};\\\", \\\"{x:1182,y:758,t:1528143651385};\\\", \\\"{x:1220,y:765,t:1528143651403};\\\", \\\"{x:1243,y:770,t:1528143651420};\\\", \\\"{x:1262,y:772,t:1528143651436};\\\", \\\"{x:1285,y:772,t:1528143651453};\\\", \\\"{x:1298,y:772,t:1528143651470};\\\", \\\"{x:1310,y:772,t:1528143651486};\\\", \\\"{x:1327,y:772,t:1528143651504};\\\", \\\"{x:1334,y:772,t:1528143651520};\\\", \\\"{x:1347,y:772,t:1528143651536};\\\", \\\"{x:1358,y:772,t:1528143651554};\\\", \\\"{x:1372,y:769,t:1528143651571};\\\", \\\"{x:1380,y:767,t:1528143651587};\\\", \\\"{x:1386,y:765,t:1528143651603};\\\", \\\"{x:1390,y:762,t:1528143651621};\\\", \\\"{x:1395,y:760,t:1528143651637};\\\", \\\"{x:1403,y:756,t:1528143651653};\\\", \\\"{x:1413,y:753,t:1528143651670};\\\", \\\"{x:1423,y:748,t:1528143651687};\\\", \\\"{x:1437,y:743,t:1528143651703};\\\", \\\"{x:1448,y:738,t:1528143651720};\\\", \\\"{x:1457,y:734,t:1528143651737};\\\", \\\"{x:1462,y:732,t:1528143651754};\\\", \\\"{x:1471,y:726,t:1528143651772};\\\", \\\"{x:1478,y:720,t:1528143651788};\\\", \\\"{x:1486,y:715,t:1528143651804};\\\", \\\"{x:1491,y:711,t:1528143651821};\\\", \\\"{x:1496,y:707,t:1528143651838};\\\", \\\"{x:1499,y:702,t:1528143651853};\\\", \\\"{x:1508,y:693,t:1528143651871};\\\", \\\"{x:1514,y:685,t:1528143651887};\\\", \\\"{x:1522,y:679,t:1528143651903};\\\", \\\"{x:1526,y:673,t:1528143651920};\\\", \\\"{x:1533,y:669,t:1528143651938};\\\", \\\"{x:1535,y:667,t:1528143651954};\\\", \\\"{x:1536,y:665,t:1528143651995};\\\", \\\"{x:1537,y:663,t:1528143652019};\\\", \\\"{x:1538,y:662,t:1528143652026};\\\", \\\"{x:1539,y:661,t:1528143652037};\\\", \\\"{x:1540,y:659,t:1528143652058};\\\", \\\"{x:1540,y:658,t:1528143652075};\\\", \\\"{x:1541,y:656,t:1528143652090};\\\", \\\"{x:1541,y:655,t:1528143652105};\\\", \\\"{x:1541,y:653,t:1528143652122};\\\", \\\"{x:1541,y:652,t:1528143652137};\\\", \\\"{x:1541,y:648,t:1528143652154};\\\", \\\"{x:1541,y:646,t:1528143652172};\\\", \\\"{x:1541,y:645,t:1528143652187};\\\", \\\"{x:1541,y:643,t:1528143652205};\\\", \\\"{x:1541,y:642,t:1528143652229};\\\", \\\"{x:1541,y:641,t:1528143652241};\\\", \\\"{x:1541,y:639,t:1528143652273};\\\", \\\"{x:1540,y:639,t:1528143652298};\\\", \\\"{x:1539,y:637,t:1528143652337};\\\", \\\"{x:1538,y:636,t:1528143652353};\\\", \\\"{x:1536,y:635,t:1528143652402};\\\", \\\"{x:1535,y:635,t:1528143652442};\\\", \\\"{x:1535,y:634,t:1528143652454};\\\", \\\"{x:1532,y:634,t:1528143652471};\\\", \\\"{x:1531,y:634,t:1528143652488};\\\", \\\"{x:1527,y:632,t:1528143652503};\\\", \\\"{x:1526,y:631,t:1528143652520};\\\", \\\"{x:1524,y:631,t:1528143652537};\\\", \\\"{x:1523,y:631,t:1528143652553};\\\", \\\"{x:1522,y:631,t:1528143652731};\\\", \\\"{x:1522,y:630,t:1528143653907};\\\", \\\"{x:1521,y:629,t:1528143654067};\\\", \\\"{x:1520,y:629,t:1528143654290};\\\", \\\"{x:1519,y:629,t:1528143654338};\\\", \\\"{x:1518,y:629,t:1528143654972};\\\", \\\"{x:1517,y:629,t:1528143655507};\\\", \\\"{x:1516,y:629,t:1528143656939};\\\", \\\"{x:1515,y:629,t:1528143656954};\\\", \\\"{x:1513,y:629,t:1528143668394};\\\", \\\"{x:1510,y:633,t:1528143668402};\\\", \\\"{x:1503,y:643,t:1528143668419};\\\", \\\"{x:1499,y:651,t:1528143668434};\\\", \\\"{x:1497,y:661,t:1528143668451};\\\", \\\"{x:1491,y:671,t:1528143668471};\\\", \\\"{x:1487,y:680,t:1528143668488};\\\", \\\"{x:1484,y:686,t:1528143668504};\\\", \\\"{x:1480,y:693,t:1528143668521};\\\", \\\"{x:1477,y:699,t:1528143668538};\\\", \\\"{x:1472,y:708,t:1528143668553};\\\", \\\"{x:1469,y:712,t:1528143668571};\\\", \\\"{x:1466,y:720,t:1528143668588};\\\", \\\"{x:1461,y:729,t:1528143668604};\\\", \\\"{x:1454,y:742,t:1528143668621};\\\", \\\"{x:1447,y:750,t:1528143668637};\\\", \\\"{x:1440,y:758,t:1528143668654};\\\", \\\"{x:1433,y:768,t:1528143668671};\\\", \\\"{x:1424,y:775,t:1528143668688};\\\", \\\"{x:1421,y:778,t:1528143668704};\\\", \\\"{x:1419,y:782,t:1528143668720};\\\", \\\"{x:1416,y:783,t:1528143668738};\\\", \\\"{x:1411,y:786,t:1528143668754};\\\", \\\"{x:1406,y:789,t:1528143668770};\\\", \\\"{x:1401,y:791,t:1528143668788};\\\", \\\"{x:1399,y:792,t:1528143668804};\\\", \\\"{x:1398,y:792,t:1528143668933};\\\", \\\"{x:1396,y:792,t:1528143669061};\\\", \\\"{x:1394,y:792,t:1528143669077};\\\", \\\"{x:1393,y:790,t:1528143669087};\\\", \\\"{x:1392,y:790,t:1528143669105};\\\", \\\"{x:1389,y:788,t:1528143669121};\\\", \\\"{x:1387,y:787,t:1528143669138};\\\", \\\"{x:1385,y:786,t:1528143669154};\\\", \\\"{x:1383,y:785,t:1528143669171};\\\", \\\"{x:1381,y:785,t:1528143669188};\\\", \\\"{x:1379,y:784,t:1528143669205};\\\", \\\"{x:1376,y:783,t:1528143669221};\\\", \\\"{x:1374,y:782,t:1528143669268};\\\", \\\"{x:1374,y:781,t:1528143669284};\\\", \\\"{x:1374,y:779,t:1528143669292};\\\", \\\"{x:1374,y:776,t:1528143669304};\\\", \\\"{x:1383,y:770,t:1528143669322};\\\", \\\"{x:1390,y:768,t:1528143669337};\\\", \\\"{x:1396,y:764,t:1528143669354};\\\", \\\"{x:1403,y:762,t:1528143669372};\\\", \\\"{x:1417,y:759,t:1528143669387};\\\", \\\"{x:1441,y:759,t:1528143669405};\\\", \\\"{x:1451,y:758,t:1528143669422};\\\", \\\"{x:1461,y:758,t:1528143669438};\\\", \\\"{x:1467,y:758,t:1528143669455};\\\", \\\"{x:1472,y:758,t:1528143669472};\\\", \\\"{x:1474,y:758,t:1528143669541};\\\", \\\"{x:1478,y:758,t:1528143669556};\\\", \\\"{x:1479,y:758,t:1528143669575};\\\", \\\"{x:1480,y:758,t:1528143669589};\\\", \\\"{x:1483,y:758,t:1528143669605};\\\", \\\"{x:1488,y:760,t:1528143669622};\\\", \\\"{x:1493,y:762,t:1528143669637};\\\", \\\"{x:1498,y:764,t:1528143669655};\\\", \\\"{x:1504,y:766,t:1528143669672};\\\", \\\"{x:1508,y:768,t:1528143669688};\\\", \\\"{x:1513,y:768,t:1528143669705};\\\", \\\"{x:1515,y:769,t:1528143669722};\\\", \\\"{x:1518,y:769,t:1528143669738};\\\", \\\"{x:1519,y:769,t:1528143669781};\\\", \\\"{x:1520,y:769,t:1528143669788};\\\", \\\"{x:1522,y:770,t:1528143669805};\\\", \\\"{x:1523,y:770,t:1528143670029};\\\", \\\"{x:1523,y:769,t:1528143670142};\\\", \\\"{x:1522,y:767,t:1528143670157};\\\", \\\"{x:1519,y:767,t:1528143670172};\\\", \\\"{x:1518,y:767,t:1528143670189};\\\", \\\"{x:1514,y:765,t:1528143670205};\\\", \\\"{x:1512,y:764,t:1528143670222};\\\", \\\"{x:1511,y:764,t:1528143670239};\\\", \\\"{x:1511,y:763,t:1528143670256};\\\", \\\"{x:1510,y:763,t:1528143670285};\\\", \\\"{x:1510,y:761,t:1528143671021};\\\", \\\"{x:1510,y:760,t:1528143671053};\\\", \\\"{x:1510,y:759,t:1528143671069};\\\", \\\"{x:1510,y:758,t:1528143671077};\\\", \\\"{x:1507,y:756,t:1528143679213};\\\", \\\"{x:1481,y:746,t:1528143679231};\\\", \\\"{x:1451,y:737,t:1528143679246};\\\", \\\"{x:1397,y:722,t:1528143679263};\\\", \\\"{x:1312,y:697,t:1528143679280};\\\", \\\"{x:1173,y:653,t:1528143679296};\\\", \\\"{x:1015,y:607,t:1528143679313};\\\", \\\"{x:876,y:554,t:1528143679330};\\\", \\\"{x:742,y:511,t:1528143679345};\\\", \\\"{x:616,y:457,t:1528143679363};\\\", \\\"{x:503,y:403,t:1528143679380};\\\", \\\"{x:461,y:389,t:1528143679396};\\\", \\\"{x:398,y:372,t:1528143679412};\\\", \\\"{x:357,y:360,t:1528143679430};\\\", \\\"{x:336,y:355,t:1528143679445};\\\", \\\"{x:325,y:354,t:1528143679463};\\\", \\\"{x:317,y:354,t:1528143679480};\\\", \\\"{x:314,y:354,t:1528143679496};\\\", \\\"{x:310,y:354,t:1528143679513};\\\", \\\"{x:308,y:354,t:1528143679530};\\\", \\\"{x:306,y:356,t:1528143679589};\\\", \\\"{x:305,y:356,t:1528143679597};\\\", \\\"{x:300,y:362,t:1528143679613};\\\", \\\"{x:295,y:369,t:1528143679630};\\\", \\\"{x:284,y:378,t:1528143679647};\\\", \\\"{x:274,y:390,t:1528143679663};\\\", \\\"{x:269,y:398,t:1528143679680};\\\", \\\"{x:262,y:412,t:1528143679697};\\\", \\\"{x:254,y:427,t:1528143679714};\\\", \\\"{x:247,y:440,t:1528143679730};\\\", \\\"{x:243,y:454,t:1528143679747};\\\", \\\"{x:240,y:470,t:1528143679763};\\\", \\\"{x:237,y:479,t:1528143679781};\\\", \\\"{x:234,y:483,t:1528143679797};\\\", \\\"{x:232,y:488,t:1528143679813};\\\", \\\"{x:232,y:493,t:1528143679830};\\\", \\\"{x:232,y:498,t:1528143679847};\\\", \\\"{x:234,y:501,t:1528143679863};\\\", \\\"{x:237,y:505,t:1528143679880};\\\", \\\"{x:240,y:509,t:1528143679896};\\\", \\\"{x:253,y:517,t:1528143679914};\\\", \\\"{x:267,y:525,t:1528143679930};\\\", \\\"{x:291,y:534,t:1528143679947};\\\", \\\"{x:313,y:546,t:1528143679963};\\\", \\\"{x:322,y:550,t:1528143679976};\\\", \\\"{x:338,y:556,t:1528143679994};\\\", \\\"{x:350,y:563,t:1528143680011};\\\", \\\"{x:355,y:563,t:1528143680027};\\\", \\\"{x:358,y:565,t:1528143680044};\\\", \\\"{x:360,y:566,t:1528143680084};\\\", \\\"{x:361,y:566,t:1528143680099};\\\", \\\"{x:362,y:568,t:1528143680116};\\\", \\\"{x:362,y:569,t:1528143680139};\\\", \\\"{x:363,y:569,t:1528143680148};\\\", \\\"{x:364,y:570,t:1528143680161};\\\", \\\"{x:365,y:570,t:1528143680253};\\\", \\\"{x:365,y:571,t:1528143680261};\\\", \\\"{x:367,y:573,t:1528143680278};\\\", \\\"{x:368,y:575,t:1528143680294};\\\", \\\"{x:370,y:575,t:1528143680311};\\\", \\\"{x:375,y:579,t:1528143680329};\\\", \\\"{x:377,y:579,t:1528143680344};\\\", \\\"{x:383,y:581,t:1528143680361};\\\", \\\"{x:385,y:581,t:1528143680378};\\\", \\\"{x:386,y:581,t:1528143680393};\\\", \\\"{x:387,y:583,t:1528143680820};\\\", \\\"{x:387,y:588,t:1528143680829};\\\", \\\"{x:388,y:591,t:1528143680845};\\\", \\\"{x:390,y:597,t:1528143680861};\\\", \\\"{x:393,y:608,t:1528143680878};\\\", \\\"{x:397,y:620,t:1528143680895};\\\", \\\"{x:400,y:626,t:1528143680910};\\\", \\\"{x:405,y:633,t:1528143680928};\\\", \\\"{x:414,y:645,t:1528143680945};\\\", \\\"{x:418,y:652,t:1528143680962};\\\", \\\"{x:429,y:668,t:1528143680978};\\\", \\\"{x:437,y:681,t:1528143680994};\\\", \\\"{x:447,y:692,t:1528143681011};\\\", \\\"{x:460,y:706,t:1528143681028};\\\", \\\"{x:469,y:715,t:1528143681045};\\\", \\\"{x:478,y:722,t:1528143681061};\\\", \\\"{x:479,y:724,t:1528143681078};\\\", \\\"{x:486,y:729,t:1528143681094};\\\", \\\"{x:490,y:731,t:1528143681112};\\\", \\\"{x:493,y:733,t:1528143681128};\\\", \\\"{x:494,y:733,t:1528143681145};\\\", \\\"{x:496,y:733,t:1528143681162};\\\", \\\"{x:498,y:734,t:1528143681178};\\\", \\\"{x:499,y:734,t:1528143681195};\\\", \\\"{x:502,y:736,t:1528143681212};\\\", \\\"{x:503,y:736,t:1528143682212};\\\", \\\"{x:504,y:736,t:1528143682228};\\\", \\\"{x:504,y:734,t:1528143682252};\\\", \\\"{x:506,y:731,t:1528143682269};\\\", \\\"{x:507,y:730,t:1528143682292};\\\", \\\"{x:507,y:728,t:1528143682333};\\\", \\\"{x:508,y:728,t:1528143682397};\\\", \\\"{x:508,y:727,t:1528143682429};\\\", \\\"{x:508,y:726,t:1528143682460};\\\", \\\"{x:508,y:725,t:1528143683060};\\\", \\\"{x:508,y:724,t:1528143683069};\\\", \\\"{x:508,y:723,t:1528143683093};\\\", \\\"{x:508,y:722,t:1528143683100};\\\" ] }, { \\\"rt\\\": 11384, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 686661, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -02 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:720,t:1528143683368};\\\", \\\"{x:508,y:714,t:1528143683452};\\\", \\\"{x:508,y:711,t:1528143683484};\\\", \\\"{x:508,y:710,t:1528143683501};\\\", \\\"{x:508,y:708,t:1528143683523};\\\", \\\"{x:508,y:707,t:1528143683556};\\\", \\\"{x:508,y:705,t:1528143683588};\\\", \\\"{x:508,y:704,t:1528143683668};\\\", \\\"{x:508,y:702,t:1528143683739};\\\", \\\"{x:508,y:700,t:1528143683756};\\\", \\\"{x:508,y:699,t:1528143683763};\\\", \\\"{x:508,y:697,t:1528143683779};\\\", \\\"{x:509,y:694,t:1528143683796};\\\", \\\"{x:511,y:692,t:1528143683813};\\\", \\\"{x:513,y:690,t:1528143683830};\\\", \\\"{x:513,y:687,t:1528143683847};\\\", \\\"{x:514,y:684,t:1528143683864};\\\", \\\"{x:516,y:681,t:1528143683880};\\\", \\\"{x:518,y:677,t:1528143683897};\\\", \\\"{x:520,y:673,t:1528143683914};\\\", \\\"{x:522,y:666,t:1528143683930};\\\", \\\"{x:523,y:662,t:1528143683947};\\\", \\\"{x:524,y:656,t:1528143683964};\\\", \\\"{x:526,y:654,t:1528143683980};\\\", \\\"{x:527,y:648,t:1528143683997};\\\", \\\"{x:528,y:643,t:1528143684015};\\\", \\\"{x:532,y:632,t:1528143684030};\\\", \\\"{x:538,y:620,t:1528143684049};\\\", \\\"{x:544,y:608,t:1528143684064};\\\", \\\"{x:549,y:604,t:1528143684082};\\\", \\\"{x:549,y:601,t:1528143684100};\\\", \\\"{x:551,y:599,t:1528143684116};\\\", \\\"{x:556,y:586,t:1528143684132};\\\", \\\"{x:559,y:572,t:1528143684146};\\\", \\\"{x:567,y:555,t:1528143684164};\\\", \\\"{x:571,y:552,t:1528143684181};\\\", \\\"{x:576,y:543,t:1528143684196};\\\", \\\"{x:579,y:538,t:1528143684214};\\\", \\\"{x:580,y:537,t:1528143684235};\\\", \\\"{x:580,y:534,t:1528143684246};\\\", \\\"{x:581,y:527,t:1528143684263};\\\", \\\"{x:583,y:519,t:1528143684281};\\\", \\\"{x:584,y:511,t:1528143684297};\\\", \\\"{x:585,y:506,t:1528143684314};\\\", \\\"{x:588,y:499,t:1528143684331};\\\", \\\"{x:588,y:494,t:1528143684347};\\\", \\\"{x:588,y:487,t:1528143684364};\\\", \\\"{x:590,y:481,t:1528143684382};\\\", \\\"{x:590,y:478,t:1528143684398};\\\", \\\"{x:591,y:478,t:1528143684414};\\\", \\\"{x:591,y:475,t:1528143684431};\\\", \\\"{x:591,y:471,t:1528143684447};\\\", \\\"{x:591,y:468,t:1528143684464};\\\", \\\"{x:591,y:465,t:1528143684481};\\\", \\\"{x:591,y:462,t:1528143684498};\\\", \\\"{x:592,y:455,t:1528143684514};\\\", \\\"{x:593,y:454,t:1528143684531};\\\", \\\"{x:597,y:447,t:1528143684548};\\\", \\\"{x:599,y:442,t:1528143684565};\\\", \\\"{x:600,y:439,t:1528143684581};\\\", \\\"{x:600,y:436,t:1528143684598};\\\", \\\"{x:602,y:432,t:1528143684614};\\\", \\\"{x:602,y:429,t:1528143684631};\\\", \\\"{x:603,y:424,t:1528143684649};\\\", \\\"{x:604,y:417,t:1528143684665};\\\", \\\"{x:607,y:412,t:1528143684681};\\\", \\\"{x:609,y:403,t:1528143684699};\\\", \\\"{x:611,y:397,t:1528143684715};\\\", \\\"{x:614,y:388,t:1528143684732};\\\", \\\"{x:615,y:380,t:1528143684748};\\\", \\\"{x:616,y:374,t:1528143684764};\\\", \\\"{x:618,y:370,t:1528143684782};\\\", \\\"{x:619,y:367,t:1528143684798};\\\", \\\"{x:620,y:363,t:1528143684815};\\\", \\\"{x:621,y:362,t:1528143684831};\\\", \\\"{x:622,y:361,t:1528143684848};\\\", \\\"{x:623,y:360,t:1528143684885};\\\", \\\"{x:623,y:359,t:1528143684909};\\\", \\\"{x:624,y:357,t:1528143684924};\\\", \\\"{x:624,y:356,t:1528143684932};\\\", \\\"{x:628,y:344,t:1528143684971};\\\", \\\"{x:630,y:338,t:1528143684981};\\\", \\\"{x:631,y:333,t:1528143684998};\\\", \\\"{x:633,y:324,t:1528143685015};\\\", \\\"{x:634,y:316,t:1528143685031};\\\", \\\"{x:634,y:310,t:1528143685048};\\\", \\\"{x:635,y:304,t:1528143685065};\\\", \\\"{x:637,y:300,t:1528143685081};\\\", \\\"{x:637,y:298,t:1528143685098};\\\", \\\"{x:638,y:293,t:1528143685115};\\\", \\\"{x:639,y:291,t:1528143685131};\\\", \\\"{x:639,y:288,t:1528143685148};\\\", \\\"{x:639,y:285,t:1528143685165};\\\", \\\"{x:640,y:282,t:1528143685181};\\\", \\\"{x:641,y:278,t:1528143685198};\\\", \\\"{x:641,y:274,t:1528143685216};\\\", \\\"{x:642,y:270,t:1528143685231};\\\", \\\"{x:644,y:266,t:1528143685249};\\\", \\\"{x:644,y:263,t:1528143685265};\\\", \\\"{x:644,y:260,t:1528143685282};\\\", \\\"{x:644,y:257,t:1528143685298};\\\", \\\"{x:644,y:254,t:1528143685315};\\\", \\\"{x:644,y:251,t:1528143685332};\\\", \\\"{x:645,y:249,t:1528143685349};\\\", \\\"{x:646,y:248,t:1528143685365};\\\", \\\"{x:647,y:246,t:1528143685381};\\\", \\\"{x:650,y:243,t:1528143685399};\\\", \\\"{x:651,y:241,t:1528143685415};\\\", \\\"{x:651,y:240,t:1528143685485};\\\", \\\"{x:651,y:239,t:1528143685498};\\\", \\\"{x:651,y:234,t:1528143685516};\\\", \\\"{x:657,y:218,t:1528143685533};\\\", \\\"{x:673,y:197,t:1528143685549};\\\", \\\"{x:687,y:172,t:1528143685566};\\\", \\\"{x:699,y:147,t:1528143685583};\\\", \\\"{x:710,y:131,t:1528143685598};\\\", \\\"{x:718,y:119,t:1528143685615};\\\", \\\"{x:721,y:112,t:1528143685632};\\\", \\\"{x:728,y:106,t:1528143685649};\\\", \\\"{x:732,y:103,t:1528143685665};\\\", \\\"{x:737,y:96,t:1528143685682};\\\", \\\"{x:741,y:89,t:1528143685698};\\\", \\\"{x:745,y:85,t:1528143685716};\\\", \\\"{x:755,y:74,t:1528143685732};\\\", \\\"{x:771,y:64,t:1528143685748};\\\", \\\"{x:785,y:52,t:1528143685765};\\\", \\\"{x:794,y:45,t:1528143685783};\\\", \\\"{x:811,y:37,t:1528143685798};\\\", \\\"{x:829,y:30,t:1528143685816};\\\", \\\"{x:848,y:29,t:1528143685832};\\\", \\\"{x:874,y:29,t:1528143685849};\\\", \\\"{x:905,y:35,t:1528143685865};\\\", \\\"{x:975,y:56,t:1528143685883};\\\", \\\"{x:1062,y:85,t:1528143685899};\\\", \\\"{x:1156,y:127,t:1528143685915};\\\", \\\"{x:1238,y:185,t:1528143685933};\\\", \\\"{x:1297,y:251,t:1528143685949};\\\", \\\"{x:1355,y:335,t:1528143685966};\\\", \\\"{x:1415,y:421,t:1528143685983};\\\", \\\"{x:1452,y:515,t:1528143686001};\\\", \\\"{x:1476,y:619,t:1528143686016};\\\", \\\"{x:1495,y:730,t:1528143686033};\\\", \\\"{x:1510,y:828,t:1528143686050};\\\", \\\"{x:1512,y:909,t:1528143686066};\\\", \\\"{x:1509,y:942,t:1528143686082};\\\", \\\"{x:1498,y:973,t:1528143686100};\\\", \\\"{x:1493,y:989,t:1528143686117};\\\", \\\"{x:1488,y:999,t:1528143686132};\\\", \\\"{x:1486,y:1001,t:1528143686149};\\\", \\\"{x:1486,y:1002,t:1528143686165};\\\", \\\"{x:1485,y:1002,t:1528143686204};\\\", \\\"{x:1482,y:1001,t:1528143686216};\\\", \\\"{x:1481,y:998,t:1528143686232};\\\", \\\"{x:1472,y:986,t:1528143686250};\\\", \\\"{x:1466,y:972,t:1528143686266};\\\", \\\"{x:1456,y:958,t:1528143686283};\\\", \\\"{x:1447,y:941,t:1528143686300};\\\", \\\"{x:1439,y:929,t:1528143686315};\\\", \\\"{x:1426,y:908,t:1528143686332};\\\", \\\"{x:1413,y:889,t:1528143686350};\\\", \\\"{x:1401,y:871,t:1528143686365};\\\", \\\"{x:1387,y:858,t:1528143686382};\\\", \\\"{x:1369,y:827,t:1528143686399};\\\", \\\"{x:1351,y:810,t:1528143686415};\\\", \\\"{x:1340,y:786,t:1528143686432};\\\", \\\"{x:1329,y:771,t:1528143686450};\\\", \\\"{x:1323,y:757,t:1528143686467};\\\", \\\"{x:1314,y:739,t:1528143686482};\\\", \\\"{x:1309,y:730,t:1528143686500};\\\", \\\"{x:1305,y:718,t:1528143686516};\\\", \\\"{x:1304,y:711,t:1528143686533};\\\", \\\"{x:1302,y:698,t:1528143686549};\\\", \\\"{x:1297,y:680,t:1528143686567};\\\", \\\"{x:1293,y:667,t:1528143686583};\\\", \\\"{x:1289,y:657,t:1528143686600};\\\", \\\"{x:1288,y:655,t:1528143686617};\\\", \\\"{x:1287,y:653,t:1528143686633};\\\", \\\"{x:1285,y:647,t:1528143686649};\\\", \\\"{x:1285,y:640,t:1528143686667};\\\", \\\"{x:1283,y:630,t:1528143686683};\\\", \\\"{x:1283,y:627,t:1528143686700};\\\", \\\"{x:1281,y:617,t:1528143686716};\\\", \\\"{x:1281,y:611,t:1528143686733};\\\", \\\"{x:1281,y:608,t:1528143686750};\\\", \\\"{x:1281,y:604,t:1528143686767};\\\", \\\"{x:1282,y:599,t:1528143686783};\\\", \\\"{x:1284,y:593,t:1528143686800};\\\", \\\"{x:1286,y:589,t:1528143686817};\\\", \\\"{x:1288,y:585,t:1528143686833};\\\", \\\"{x:1290,y:579,t:1528143686850};\\\", \\\"{x:1292,y:573,t:1528143686867};\\\", \\\"{x:1293,y:570,t:1528143686883};\\\", \\\"{x:1294,y:568,t:1528143686900};\\\", \\\"{x:1296,y:565,t:1528143686916};\\\", \\\"{x:1297,y:563,t:1528143686933};\\\", \\\"{x:1299,y:560,t:1528143686950};\\\", \\\"{x:1300,y:558,t:1528143686966};\\\", \\\"{x:1301,y:556,t:1528143686984};\\\", \\\"{x:1303,y:554,t:1528143686999};\\\", \\\"{x:1305,y:554,t:1528143687020};\\\", \\\"{x:1306,y:551,t:1528143687036};\\\", \\\"{x:1307,y:551,t:1528143687076};\\\", \\\"{x:1307,y:550,t:1528143687107};\\\", \\\"{x:1308,y:550,t:1528143687116};\\\", \\\"{x:1309,y:550,t:1528143687133};\\\", \\\"{x:1309,y:549,t:1528143687149};\\\", \\\"{x:1310,y:548,t:1528143687166};\\\", \\\"{x:1312,y:548,t:1528143687183};\\\", \\\"{x:1314,y:547,t:1528143687199};\\\", \\\"{x:1317,y:546,t:1528143687217};\\\", \\\"{x:1322,y:544,t:1528143687234};\\\", \\\"{x:1324,y:542,t:1528143687249};\\\", \\\"{x:1326,y:542,t:1528143687266};\\\", \\\"{x:1327,y:540,t:1528143687284};\\\", \\\"{x:1330,y:539,t:1528143687299};\\\", \\\"{x:1333,y:537,t:1528143687316};\\\", \\\"{x:1335,y:537,t:1528143687334};\\\", \\\"{x:1336,y:537,t:1528143687350};\\\", \\\"{x:1337,y:537,t:1528143687367};\\\", \\\"{x:1340,y:535,t:1528143687384};\\\", \\\"{x:1346,y:535,t:1528143687400};\\\", \\\"{x:1351,y:535,t:1528143687417};\\\", \\\"{x:1356,y:536,t:1528143687434};\\\", \\\"{x:1362,y:536,t:1528143687451};\\\", \\\"{x:1363,y:536,t:1528143687469};\\\", \\\"{x:1364,y:536,t:1528143687483};\\\", \\\"{x:1365,y:536,t:1528143687501};\\\", \\\"{x:1359,y:536,t:1528143687605};\\\", \\\"{x:1348,y:536,t:1528143687617};\\\", \\\"{x:1311,y:536,t:1528143687633};\\\", \\\"{x:1222,y:536,t:1528143687651};\\\", \\\"{x:1175,y:528,t:1528143687667};\\\", \\\"{x:1053,y:521,t:1528143687683};\\\", \\\"{x:853,y:498,t:1528143687702};\\\", \\\"{x:734,y:484,t:1528143687717};\\\", \\\"{x:664,y:476,t:1528143687733};\\\", \\\"{x:540,y:459,t:1528143687751};\\\", \\\"{x:423,y:439,t:1528143687767};\\\", \\\"{x:375,y:431,t:1528143687784};\\\", \\\"{x:343,y:426,t:1528143687800};\\\", \\\"{x:331,y:425,t:1528143687817};\\\", \\\"{x:330,y:425,t:1528143687834};\\\", \\\"{x:329,y:425,t:1528143687850};\\\", \\\"{x:328,y:425,t:1528143687892};\\\", \\\"{x:329,y:425,t:1528143688012};\\\", \\\"{x:337,y:429,t:1528143688021};\\\", \\\"{x:342,y:433,t:1528143688034};\\\", \\\"{x:349,y:435,t:1528143688050};\\\", \\\"{x:360,y:437,t:1528143688068};\\\", \\\"{x:372,y:440,t:1528143688085};\\\", \\\"{x:392,y:443,t:1528143688100};\\\", \\\"{x:409,y:448,t:1528143688117};\\\", \\\"{x:431,y:450,t:1528143688135};\\\", \\\"{x:444,y:453,t:1528143688150};\\\", \\\"{x:462,y:456,t:1528143688168};\\\", \\\"{x:477,y:463,t:1528143688184};\\\", \\\"{x:491,y:470,t:1528143688201};\\\", \\\"{x:503,y:477,t:1528143688217};\\\", \\\"{x:508,y:480,t:1528143688234};\\\", \\\"{x:508,y:481,t:1528143688252};\\\", \\\"{x:508,y:482,t:1528143688301};\\\", \\\"{x:510,y:484,t:1528143688318};\\\", \\\"{x:512,y:487,t:1528143688336};\\\", \\\"{x:513,y:487,t:1528143688389};\\\", \\\"{x:515,y:487,t:1528143688412};\\\", \\\"{x:516,y:487,t:1528143688429};\\\", \\\"{x:520,y:487,t:1528143688436};\\\", \\\"{x:521,y:487,t:1528143688450};\\\", \\\"{x:530,y:487,t:1528143688467};\\\", \\\"{x:537,y:487,t:1528143688484};\\\", \\\"{x:546,y:487,t:1528143688500};\\\", \\\"{x:559,y:489,t:1528143688517};\\\", \\\"{x:576,y:491,t:1528143688533};\\\", \\\"{x:585,y:491,t:1528143688550};\\\", \\\"{x:590,y:492,t:1528143688566};\\\", \\\"{x:595,y:493,t:1528143688584};\\\", \\\"{x:599,y:494,t:1528143688600};\\\", \\\"{x:602,y:494,t:1528143688617};\\\", \\\"{x:603,y:495,t:1528143688635};\\\", \\\"{x:607,y:496,t:1528143689244};\\\", \\\"{x:607,y:500,t:1528143689252};\\\", \\\"{x:612,y:507,t:1528143689268};\\\", \\\"{x:616,y:507,t:1528143689285};\\\", \\\"{x:621,y:507,t:1528143689301};\\\", \\\"{x:626,y:508,t:1528143689319};\\\", \\\"{x:639,y:512,t:1528143689336};\\\", \\\"{x:649,y:513,t:1528143689352};\\\", \\\"{x:658,y:515,t:1528143689369};\\\", \\\"{x:663,y:515,t:1528143689385};\\\", \\\"{x:663,y:516,t:1528143689401};\\\", \\\"{x:665,y:516,t:1528143689418};\\\", \\\"{x:670,y:515,t:1528143689435};\\\", \\\"{x:681,y:511,t:1528143689451};\\\", \\\"{x:693,y:510,t:1528143689468};\\\", \\\"{x:703,y:510,t:1528143689485};\\\", \\\"{x:706,y:510,t:1528143689501};\\\", \\\"{x:709,y:510,t:1528143689519};\\\", \\\"{x:713,y:511,t:1528143689535};\\\", \\\"{x:717,y:514,t:1528143689551};\\\", \\\"{x:719,y:515,t:1528143689569};\\\", \\\"{x:723,y:518,t:1528143689587};\\\", \\\"{x:729,y:520,t:1528143689602};\\\", \\\"{x:736,y:525,t:1528143689619};\\\", \\\"{x:741,y:529,t:1528143689635};\\\", \\\"{x:746,y:531,t:1528143689651};\\\", \\\"{x:765,y:543,t:1528143689668};\\\", \\\"{x:780,y:550,t:1528143689685};\\\", \\\"{x:789,y:554,t:1528143689702};\\\", \\\"{x:800,y:559,t:1528143689719};\\\", \\\"{x:804,y:560,t:1528143689735};\\\", \\\"{x:808,y:562,t:1528143689753};\\\", \\\"{x:809,y:563,t:1528143689769};\\\", \\\"{x:810,y:563,t:1528143689785};\\\", \\\"{x:811,y:563,t:1528143689803};\\\", \\\"{x:812,y:563,t:1528143689818};\\\", \\\"{x:813,y:563,t:1528143689845};\\\", \\\"{x:814,y:562,t:1528143689854};\\\", \\\"{x:815,y:561,t:1528143689892};\\\", \\\"{x:816,y:560,t:1528143689903};\\\", \\\"{x:817,y:558,t:1528143689932};\\\", \\\"{x:817,y:557,t:1528143689941};\\\", \\\"{x:818,y:556,t:1528143689952};\\\", \\\"{x:819,y:555,t:1528143689969};\\\", \\\"{x:820,y:553,t:1528143689985};\\\", \\\"{x:820,y:551,t:1528143690002};\\\", \\\"{x:821,y:550,t:1528143690019};\\\", \\\"{x:821,y:548,t:1528143690036};\\\", \\\"{x:823,y:547,t:1528143690068};\\\", \\\"{x:823,y:546,t:1528143690124};\\\", \\\"{x:824,y:546,t:1528143690135};\\\", \\\"{x:825,y:545,t:1528143690153};\\\", \\\"{x:825,y:544,t:1528143690172};\\\", \\\"{x:826,y:543,t:1528143690213};\\\", \\\"{x:829,y:541,t:1528143690236};\\\", \\\"{x:829,y:540,t:1528143690253};\\\", \\\"{x:830,y:540,t:1528143690269};\\\", \\\"{x:831,y:539,t:1528143690286};\\\", \\\"{x:831,y:538,t:1528143690302};\\\", \\\"{x:832,y:538,t:1528143690325};\\\", \\\"{x:826,y:539,t:1528143691341};\\\", \\\"{x:822,y:543,t:1528143691355};\\\", \\\"{x:821,y:543,t:1528143691372};\\\", \\\"{x:818,y:546,t:1528143691386};\\\", \\\"{x:807,y:558,t:1528143691404};\\\", \\\"{x:791,y:577,t:1528143691420};\\\", \\\"{x:774,y:589,t:1528143691436};\\\", \\\"{x:755,y:600,t:1528143691453};\\\", \\\"{x:731,y:613,t:1528143691470};\\\", \\\"{x:708,y:622,t:1528143691487};\\\", \\\"{x:681,y:636,t:1528143691504};\\\", \\\"{x:654,y:645,t:1528143691520};\\\", \\\"{x:625,y:652,t:1528143691536};\\\", \\\"{x:611,y:658,t:1528143691553};\\\", \\\"{x:583,y:665,t:1528143691570};\\\", \\\"{x:572,y:669,t:1528143691586};\\\", \\\"{x:545,y:674,t:1528143691604};\\\", \\\"{x:512,y:674,t:1528143691620};\\\", \\\"{x:492,y:680,t:1528143691636};\\\", \\\"{x:465,y:686,t:1528143691654};\\\", \\\"{x:451,y:688,t:1528143691671};\\\", \\\"{x:424,y:692,t:1528143691687};\\\", \\\"{x:407,y:699,t:1528143691704};\\\", \\\"{x:391,y:705,t:1528143691721};\\\", \\\"{x:382,y:710,t:1528143691736};\\\", \\\"{x:372,y:714,t:1528143691753};\\\", \\\"{x:368,y:716,t:1528143691771};\\\", \\\"{x:366,y:717,t:1528143691787};\\\", \\\"{x:365,y:718,t:1528143691804};\\\", \\\"{x:365,y:719,t:1528143691860};\\\", \\\"{x:365,y:720,t:1528143691871};\\\", \\\"{x:364,y:723,t:1528143691888};\\\", \\\"{x:364,y:727,t:1528143691904};\\\", \\\"{x:364,y:733,t:1528143691921};\\\", \\\"{x:368,y:738,t:1528143691937};\\\", \\\"{x:385,y:747,t:1528143691954};\\\", \\\"{x:396,y:752,t:1528143691971};\\\", \\\"{x:411,y:756,t:1528143691987};\\\", \\\"{x:418,y:758,t:1528143692003};\\\", \\\"{x:433,y:760,t:1528143692020};\\\", \\\"{x:437,y:760,t:1528143692037};\\\", \\\"{x:443,y:759,t:1528143692054};\\\", \\\"{x:448,y:757,t:1528143692070};\\\", \\\"{x:452,y:754,t:1528143692088};\\\", \\\"{x:453,y:752,t:1528143692105};\\\", \\\"{x:460,y:747,t:1528143692120};\\\", \\\"{x:463,y:746,t:1528143692138};\\\", \\\"{x:467,y:743,t:1528143692154};\\\", \\\"{x:469,y:742,t:1528143692170};\\\", \\\"{x:470,y:742,t:1528143692187};\\\", \\\"{x:471,y:741,t:1528143692204};\\\", \\\"{x:472,y:741,t:1528143692251};\\\" ] }, { \\\"rt\\\": 37694, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 725648, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-C -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:472,y:740,t:1528143698293};\\\", \\\"{x:472,y:735,t:1528143698301};\\\", \\\"{x:472,y:734,t:1528143698313};\\\", \\\"{x:472,y:733,t:1528143698330};\\\", \\\"{x:471,y:731,t:1528143698346};\\\", \\\"{x:471,y:730,t:1528143698373};\\\", \\\"{x:470,y:728,t:1528143698388};\\\", \\\"{x:469,y:727,t:1528143698437};\\\", \\\"{x:469,y:726,t:1528143698509};\\\", \\\"{x:468,y:725,t:1528143698516};\\\", \\\"{x:467,y:724,t:1528143698533};\\\", \\\"{x:466,y:723,t:1528143698548};\\\", \\\"{x:464,y:720,t:1528143698565};\\\", \\\"{x:464,y:719,t:1528143698582};\\\", \\\"{x:464,y:718,t:1528143698597};\\\", \\\"{x:462,y:717,t:1528143698613};\\\", \\\"{x:461,y:716,t:1528143698659};\\\", \\\"{x:461,y:715,t:1528143698732};\\\", \\\"{x:461,y:714,t:1528143698742};\\\", \\\"{x:459,y:713,t:1528143698759};\\\", \\\"{x:458,y:713,t:1528143698788};\\\", \\\"{x:457,y:712,t:1528143698796};\\\", \\\"{x:457,y:711,t:1528143698893};\\\", \\\"{x:456,y:710,t:1528143698925};\\\", \\\"{x:455,y:710,t:1528143698940};\\\", \\\"{x:455,y:709,t:1528143698964};\\\", \\\"{x:454,y:709,t:1528143698981};\\\", \\\"{x:454,y:708,t:1528143699021};\\\", \\\"{x:453,y:707,t:1528143699052};\\\", \\\"{x:453,y:706,t:1528143699117};\\\", \\\"{x:453,y:705,t:1528143699148};\\\", \\\"{x:453,y:704,t:1528143699164};\\\", \\\"{x:453,y:703,t:1528143699428};\\\", \\\"{x:453,y:702,t:1528143699613};\\\", \\\"{x:452,y:701,t:1528143699627};\\\", \\\"{x:451,y:701,t:1528143699709};\\\", \\\"{x:451,y:700,t:1528143699773};\\\", \\\"{x:450,y:700,t:1528143699780};\\\", \\\"{x:450,y:699,t:1528143699812};\\\", \\\"{x:450,y:698,t:1528143699844};\\\", \\\"{x:450,y:697,t:1528143699949};\\\", \\\"{x:450,y:696,t:1528143699981};\\\", \\\"{x:449,y:694,t:1528143700012};\\\", \\\"{x:449,y:693,t:1528143700028};\\\", \\\"{x:449,y:692,t:1528143700052};\\\", \\\"{x:449,y:691,t:1528143700085};\\\", \\\"{x:448,y:690,t:1528143700101};\\\", \\\"{x:448,y:689,t:1528143700149};\\\", \\\"{x:448,y:688,t:1528143703333};\\\", \\\"{x:448,y:687,t:1528143703346};\\\", \\\"{x:449,y:686,t:1528143703364};\\\", \\\"{x:449,y:685,t:1528143703380};\\\", \\\"{x:450,y:684,t:1528143703397};\\\", \\\"{x:453,y:684,t:1528143703421};\\\", \\\"{x:459,y:684,t:1528143703430};\\\", \\\"{x:470,y:689,t:1528143703447};\\\", \\\"{x:490,y:698,t:1528143703463};\\\", \\\"{x:502,y:705,t:1528143703479};\\\", \\\"{x:510,y:709,t:1528143703496};\\\", \\\"{x:530,y:719,t:1528143703513};\\\", \\\"{x:561,y:729,t:1528143703530};\\\", \\\"{x:592,y:744,t:1528143703547};\\\", \\\"{x:633,y:754,t:1528143703563};\\\", \\\"{x:675,y:766,t:1528143703580};\\\", \\\"{x:698,y:774,t:1528143703597};\\\", \\\"{x:716,y:783,t:1528143703613};\\\", \\\"{x:733,y:792,t:1528143703629};\\\", \\\"{x:750,y:798,t:1528143703646};\\\", \\\"{x:778,y:808,t:1528143703662};\\\", \\\"{x:798,y:813,t:1528143703680};\\\", \\\"{x:823,y:819,t:1528143703697};\\\", \\\"{x:851,y:829,t:1528143703713};\\\", \\\"{x:878,y:841,t:1528143703730};\\\", \\\"{x:908,y:853,t:1528143703747};\\\", \\\"{x:934,y:866,t:1528143703763};\\\", \\\"{x:961,y:881,t:1528143703780};\\\", \\\"{x:979,y:888,t:1528143703797};\\\", \\\"{x:1018,y:904,t:1528143703813};\\\", \\\"{x:1066,y:920,t:1528143703830};\\\", \\\"{x:1103,y:935,t:1528143703847};\\\", \\\"{x:1134,y:945,t:1528143703863};\\\", \\\"{x:1152,y:953,t:1528143703880};\\\", \\\"{x:1167,y:958,t:1528143703898};\\\", \\\"{x:1177,y:963,t:1528143703914};\\\", \\\"{x:1188,y:966,t:1528143703931};\\\", \\\"{x:1190,y:966,t:1528143703948};\\\", \\\"{x:1196,y:966,t:1528143703964};\\\", \\\"{x:1201,y:968,t:1528143703980};\\\", \\\"{x:1208,y:971,t:1528143703998};\\\", \\\"{x:1216,y:971,t:1528143704014};\\\", \\\"{x:1221,y:969,t:1528143704030};\\\", \\\"{x:1226,y:967,t:1528143704048};\\\", \\\"{x:1229,y:967,t:1528143704064};\\\", \\\"{x:1234,y:965,t:1528143704081};\\\", \\\"{x:1236,y:962,t:1528143704098};\\\", \\\"{x:1238,y:961,t:1528143704115};\\\", \\\"{x:1241,y:958,t:1528143704131};\\\", \\\"{x:1244,y:952,t:1528143704147};\\\", \\\"{x:1245,y:935,t:1528143704165};\\\", \\\"{x:1239,y:908,t:1528143704181};\\\", \\\"{x:1219,y:868,t:1528143704197};\\\", \\\"{x:1182,y:812,t:1528143704215};\\\", \\\"{x:1149,y:772,t:1528143704231};\\\", \\\"{x:1123,y:744,t:1528143704248};\\\", \\\"{x:1109,y:735,t:1528143704264};\\\", \\\"{x:1097,y:730,t:1528143704281};\\\", \\\"{x:1089,y:727,t:1528143704297};\\\", \\\"{x:1081,y:725,t:1528143704315};\\\", \\\"{x:1076,y:724,t:1528143704331};\\\", \\\"{x:1075,y:723,t:1528143704461};\\\", \\\"{x:1075,y:721,t:1528143704509};\\\", \\\"{x:1075,y:720,t:1528143704533};\\\", \\\"{x:1075,y:719,t:1528143704549};\\\", \\\"{x:1075,y:716,t:1528143704565};\\\", \\\"{x:1078,y:708,t:1528143704581};\\\", \\\"{x:1082,y:698,t:1528143704598};\\\", \\\"{x:1087,y:686,t:1528143704615};\\\", \\\"{x:1089,y:678,t:1528143704632};\\\", \\\"{x:1092,y:670,t:1528143704647};\\\", \\\"{x:1093,y:669,t:1528143704664};\\\", \\\"{x:1095,y:669,t:1528143704682};\\\", \\\"{x:1096,y:666,t:1528143704698};\\\", \\\"{x:1096,y:662,t:1528143704714};\\\", \\\"{x:1099,y:658,t:1528143704732};\\\", \\\"{x:1099,y:656,t:1528143704747};\\\", \\\"{x:1101,y:653,t:1528143704765};\\\", \\\"{x:1101,y:652,t:1528143704789};\\\", \\\"{x:1102,y:652,t:1528143704797};\\\", \\\"{x:1103,y:650,t:1528143704814};\\\", \\\"{x:1106,y:647,t:1528143704831};\\\", \\\"{x:1106,y:644,t:1528143704848};\\\", \\\"{x:1110,y:639,t:1528143704865};\\\", \\\"{x:1112,y:635,t:1528143704882};\\\", \\\"{x:1116,y:629,t:1528143704898};\\\", \\\"{x:1118,y:627,t:1528143704915};\\\", \\\"{x:1120,y:625,t:1528143704932};\\\", \\\"{x:1127,y:621,t:1528143704949};\\\", \\\"{x:1132,y:621,t:1528143704964};\\\", \\\"{x:1137,y:619,t:1528143704981};\\\", \\\"{x:1140,y:618,t:1528143704999};\\\", \\\"{x:1141,y:618,t:1528143705015};\\\", \\\"{x:1143,y:618,t:1528143705032};\\\", \\\"{x:1146,y:618,t:1528143705048};\\\", \\\"{x:1157,y:618,t:1528143705065};\\\", \\\"{x:1174,y:618,t:1528143705082};\\\", \\\"{x:1193,y:620,t:1528143705099};\\\", \\\"{x:1209,y:624,t:1528143705114};\\\", \\\"{x:1228,y:625,t:1528143705132};\\\", \\\"{x:1249,y:631,t:1528143705149};\\\", \\\"{x:1260,y:634,t:1528143705164};\\\", \\\"{x:1273,y:636,t:1528143705182};\\\", \\\"{x:1281,y:636,t:1528143705198};\\\", \\\"{x:1290,y:638,t:1528143705214};\\\", \\\"{x:1291,y:639,t:1528143705231};\\\", \\\"{x:1294,y:639,t:1528143705249};\\\", \\\"{x:1296,y:639,t:1528143705265};\\\", \\\"{x:1298,y:639,t:1528143705282};\\\", \\\"{x:1301,y:639,t:1528143705299};\\\", \\\"{x:1303,y:639,t:1528143705325};\\\", \\\"{x:1304,y:639,t:1528143705332};\\\", \\\"{x:1307,y:639,t:1528143705348};\\\", \\\"{x:1308,y:639,t:1528143705413};\\\", \\\"{x:1308,y:638,t:1528143705420};\\\", \\\"{x:1309,y:638,t:1528143705437};\\\", \\\"{x:1310,y:637,t:1528143705453};\\\", \\\"{x:1311,y:637,t:1528143705477};\\\", \\\"{x:1312,y:636,t:1528143705501};\\\", \\\"{x:1314,y:635,t:1528143705533};\\\", \\\"{x:1314,y:633,t:1528143705581};\\\", \\\"{x:1316,y:633,t:1528143705599};\\\", \\\"{x:1318,y:632,t:1528143705670};\\\", \\\"{x:1318,y:631,t:1528143705741};\\\", \\\"{x:1319,y:630,t:1528143705748};\\\", \\\"{x:1320,y:629,t:1528143707445};\\\", \\\"{x:1323,y:629,t:1528143709339};\\\", \\\"{x:1330,y:629,t:1528143709351};\\\", \\\"{x:1351,y:629,t:1528143709369};\\\", \\\"{x:1362,y:629,t:1528143709384};\\\", \\\"{x:1377,y:629,t:1528143709401};\\\", \\\"{x:1394,y:629,t:1528143709419};\\\", \\\"{x:1405,y:630,t:1528143709435};\\\", \\\"{x:1410,y:631,t:1528143709451};\\\", \\\"{x:1420,y:632,t:1528143709468};\\\", \\\"{x:1422,y:632,t:1528143709492};\\\", \\\"{x:1423,y:632,t:1528143709502};\\\", \\\"{x:1425,y:632,t:1528143709519};\\\", \\\"{x:1429,y:632,t:1528143709535};\\\", \\\"{x:1432,y:632,t:1528143709552};\\\", \\\"{x:1438,y:632,t:1528143709568};\\\", \\\"{x:1444,y:632,t:1528143709587};\\\", \\\"{x:1451,y:632,t:1528143709601};\\\", \\\"{x:1454,y:630,t:1528143709619};\\\", \\\"{x:1458,y:630,t:1528143709635};\\\", \\\"{x:1462,y:630,t:1528143709651};\\\", \\\"{x:1467,y:630,t:1528143709667};\\\", \\\"{x:1473,y:630,t:1528143709685};\\\", \\\"{x:1479,y:630,t:1528143709702};\\\", \\\"{x:1482,y:630,t:1528143709719};\\\", \\\"{x:1485,y:630,t:1528143709735};\\\", \\\"{x:1490,y:630,t:1528143709751};\\\", \\\"{x:1492,y:630,t:1528143709769};\\\", \\\"{x:1493,y:630,t:1528143709796};\\\", \\\"{x:1498,y:630,t:1528143709804};\\\", \\\"{x:1500,y:630,t:1528143709819};\\\", \\\"{x:1502,y:630,t:1528143709836};\\\", \\\"{x:1515,y:630,t:1528143709852};\\\", \\\"{x:1521,y:630,t:1528143709869};\\\", \\\"{x:1524,y:630,t:1528143709886};\\\", \\\"{x:1525,y:630,t:1528143709941};\\\", \\\"{x:1527,y:630,t:1528143710149};\\\", \\\"{x:1528,y:630,t:1528143710157};\\\", \\\"{x:1529,y:630,t:1528143710172};\\\", \\\"{x:1531,y:630,t:1528143710221};\\\", \\\"{x:1534,y:630,t:1528143710236};\\\", \\\"{x:1539,y:630,t:1528143710253};\\\", \\\"{x:1541,y:630,t:1528143710269};\\\", \\\"{x:1545,y:630,t:1528143710286};\\\", \\\"{x:1546,y:631,t:1528143710304};\\\", \\\"{x:1547,y:631,t:1528143710319};\\\", \\\"{x:1549,y:631,t:1528143710336};\\\", \\\"{x:1550,y:631,t:1528143710353};\\\", \\\"{x:1551,y:631,t:1528143710369};\\\", \\\"{x:1554,y:632,t:1528143710385};\\\", \\\"{x:1556,y:632,t:1528143710421};\\\", \\\"{x:1557,y:632,t:1528143710436};\\\", \\\"{x:1559,y:632,t:1528143710461};\\\", \\\"{x:1561,y:632,t:1528143710477};\\\", \\\"{x:1562,y:632,t:1528143710492};\\\", \\\"{x:1563,y:632,t:1528143710503};\\\", \\\"{x:1567,y:632,t:1528143710519};\\\", \\\"{x:1569,y:632,t:1528143710536};\\\", \\\"{x:1571,y:632,t:1528143710556};\\\", \\\"{x:1571,y:633,t:1528143711292};\\\", \\\"{x:1571,y:635,t:1528143711303};\\\", \\\"{x:1573,y:637,t:1528143711319};\\\", \\\"{x:1573,y:638,t:1528143711336};\\\", \\\"{x:1573,y:639,t:1528143711352};\\\", \\\"{x:1574,y:641,t:1528143711370};\\\", \\\"{x:1574,y:643,t:1528143711387};\\\", \\\"{x:1575,y:645,t:1528143711402};\\\", \\\"{x:1577,y:646,t:1528143711428};\\\", \\\"{x:1577,y:648,t:1528143711444};\\\", \\\"{x:1577,y:649,t:1528143711453};\\\", \\\"{x:1580,y:656,t:1528143711470};\\\", \\\"{x:1582,y:659,t:1528143711486};\\\", \\\"{x:1587,y:664,t:1528143711502};\\\", \\\"{x:1588,y:667,t:1528143711520};\\\", \\\"{x:1589,y:669,t:1528143711537};\\\", \\\"{x:1591,y:674,t:1528143711553};\\\", \\\"{x:1593,y:677,t:1528143711570};\\\", \\\"{x:1595,y:682,t:1528143711587};\\\", \\\"{x:1598,y:685,t:1528143711604};\\\", \\\"{x:1601,y:689,t:1528143711620};\\\", \\\"{x:1604,y:691,t:1528143711636};\\\", \\\"{x:1605,y:693,t:1528143711654};\\\", \\\"{x:1606,y:693,t:1528143711670};\\\", \\\"{x:1605,y:695,t:1528143720317};\\\", \\\"{x:1600,y:697,t:1528143720328};\\\", \\\"{x:1599,y:698,t:1528143720343};\\\", \\\"{x:1596,y:700,t:1528143720361};\\\", \\\"{x:1589,y:703,t:1528143720378};\\\", \\\"{x:1576,y:709,t:1528143720394};\\\", \\\"{x:1566,y:712,t:1528143720410};\\\", \\\"{x:1558,y:716,t:1528143720427};\\\", \\\"{x:1544,y:722,t:1528143720443};\\\", \\\"{x:1521,y:732,t:1528143720460};\\\", \\\"{x:1516,y:736,t:1528143720477};\\\", \\\"{x:1504,y:741,t:1528143720494};\\\", \\\"{x:1490,y:746,t:1528143720510};\\\", \\\"{x:1481,y:747,t:1528143720527};\\\", \\\"{x:1476,y:750,t:1528143720544};\\\", \\\"{x:1468,y:754,t:1528143720561};\\\", \\\"{x:1459,y:754,t:1528143720578};\\\", \\\"{x:1454,y:754,t:1528143720594};\\\", \\\"{x:1444,y:753,t:1528143720610};\\\", \\\"{x:1437,y:753,t:1528143720627};\\\", \\\"{x:1426,y:752,t:1528143720644};\\\", \\\"{x:1420,y:750,t:1528143720661};\\\", \\\"{x:1419,y:749,t:1528143720677};\\\", \\\"{x:1411,y:744,t:1528143720694};\\\", \\\"{x:1405,y:740,t:1528143720710};\\\", \\\"{x:1397,y:736,t:1528143720728};\\\", \\\"{x:1390,y:730,t:1528143720744};\\\", \\\"{x:1384,y:724,t:1528143720760};\\\", \\\"{x:1369,y:714,t:1528143720778};\\\", \\\"{x:1365,y:709,t:1528143720795};\\\", \\\"{x:1359,y:705,t:1528143720810};\\\", \\\"{x:1354,y:702,t:1528143720828};\\\", \\\"{x:1350,y:698,t:1528143720845};\\\", \\\"{x:1348,y:697,t:1528143720860};\\\", \\\"{x:1346,y:695,t:1528143720877};\\\", \\\"{x:1345,y:694,t:1528143720894};\\\", \\\"{x:1344,y:693,t:1528143720911};\\\", \\\"{x:1344,y:692,t:1528143720949};\\\", \\\"{x:1343,y:691,t:1528143720973};\\\", \\\"{x:1342,y:690,t:1528143721021};\\\", \\\"{x:1341,y:690,t:1528143721036};\\\", \\\"{x:1339,y:690,t:1528143721237};\\\", \\\"{x:1338,y:690,t:1528143721268};\\\", \\\"{x:1336,y:691,t:1528143721285};\\\", \\\"{x:1336,y:692,t:1528143721295};\\\", \\\"{x:1335,y:693,t:1528143721311};\\\", \\\"{x:1335,y:694,t:1528143721327};\\\", \\\"{x:1334,y:695,t:1528143721356};\\\", \\\"{x:1333,y:697,t:1528143721365};\\\", \\\"{x:1333,y:698,t:1528143721380};\\\", \\\"{x:1333,y:700,t:1528143721395};\\\", \\\"{x:1333,y:703,t:1528143721411};\\\", \\\"{x:1333,y:707,t:1528143721429};\\\", \\\"{x:1332,y:708,t:1528143721444};\\\", \\\"{x:1332,y:710,t:1528143721485};\\\", \\\"{x:1332,y:712,t:1528143721495};\\\", \\\"{x:1332,y:714,t:1528143721511};\\\", \\\"{x:1332,y:716,t:1528143721529};\\\", \\\"{x:1332,y:718,t:1528143721545};\\\", \\\"{x:1334,y:721,t:1528143721561};\\\", \\\"{x:1334,y:722,t:1528143721578};\\\", \\\"{x:1336,y:724,t:1528143721594};\\\", \\\"{x:1336,y:725,t:1528143721611};\\\", \\\"{x:1337,y:727,t:1528143721628};\\\", \\\"{x:1337,y:728,t:1528143721644};\\\", \\\"{x:1339,y:728,t:1528143721662};\\\", \\\"{x:1339,y:729,t:1528143721685};\\\", \\\"{x:1339,y:730,t:1528143721708};\\\", \\\"{x:1340,y:732,t:1528143721773};\\\", \\\"{x:1341,y:733,t:1528143721789};\\\", \\\"{x:1343,y:734,t:1528143721805};\\\", \\\"{x:1343,y:735,t:1528143721819};\\\", \\\"{x:1344,y:736,t:1528143721836};\\\", \\\"{x:1344,y:737,t:1528143721845};\\\", \\\"{x:1346,y:738,t:1528143721861};\\\", \\\"{x:1346,y:739,t:1528143721899};\\\", \\\"{x:1347,y:740,t:1528143721911};\\\", \\\"{x:1348,y:741,t:1528143721948};\\\", \\\"{x:1349,y:741,t:1528143722013};\\\", \\\"{x:1349,y:742,t:1528143722037};\\\", \\\"{x:1350,y:743,t:1528143722052};\\\", \\\"{x:1351,y:745,t:1528143722085};\\\", \\\"{x:1352,y:747,t:1528143722096};\\\", \\\"{x:1352,y:748,t:1528143722117};\\\", \\\"{x:1352,y:749,t:1528143722133};\\\", \\\"{x:1353,y:750,t:1528143722156};\\\", \\\"{x:1353,y:752,t:1528143722181};\\\", \\\"{x:1353,y:753,t:1528143722204};\\\", \\\"{x:1354,y:754,t:1528143722213};\\\", \\\"{x:1355,y:756,t:1528143722237};\\\", \\\"{x:1356,y:756,t:1528143722276};\\\", \\\"{x:1357,y:757,t:1528143722349};\\\", \\\"{x:1357,y:759,t:1528143722453};\\\", \\\"{x:1359,y:760,t:1528143723653};\\\", \\\"{x:1362,y:759,t:1528143723669};\\\", \\\"{x:1364,y:758,t:1528143723684};\\\", \\\"{x:1367,y:757,t:1528143723697};\\\", \\\"{x:1370,y:754,t:1528143723713};\\\", \\\"{x:1374,y:751,t:1528143723730};\\\", \\\"{x:1375,y:750,t:1528143723746};\\\", \\\"{x:1377,y:748,t:1528143723764};\\\", \\\"{x:1377,y:746,t:1528143723789};\\\", \\\"{x:1378,y:745,t:1528143723796};\\\", \\\"{x:1379,y:742,t:1528143723814};\\\", \\\"{x:1381,y:740,t:1528143723830};\\\", \\\"{x:1384,y:736,t:1528143723846};\\\", \\\"{x:1388,y:733,t:1528143723864};\\\", \\\"{x:1389,y:726,t:1528143723880};\\\", \\\"{x:1393,y:723,t:1528143723897};\\\", \\\"{x:1398,y:716,t:1528143723913};\\\", \\\"{x:1403,y:713,t:1528143723930};\\\", \\\"{x:1407,y:710,t:1528143723947};\\\", \\\"{x:1411,y:707,t:1528143723964};\\\", \\\"{x:1415,y:705,t:1528143723980};\\\", \\\"{x:1424,y:699,t:1528143723996};\\\", \\\"{x:1427,y:697,t:1528143724014};\\\", \\\"{x:1432,y:695,t:1528143724030};\\\", \\\"{x:1436,y:694,t:1528143724047};\\\", \\\"{x:1438,y:693,t:1528143724064};\\\", \\\"{x:1439,y:693,t:1528143724080};\\\", \\\"{x:1441,y:692,t:1528143724097};\\\", \\\"{x:1444,y:690,t:1528143724113};\\\", \\\"{x:1450,y:689,t:1528143724130};\\\", \\\"{x:1455,y:686,t:1528143724146};\\\", \\\"{x:1460,y:685,t:1528143724164};\\\", \\\"{x:1461,y:685,t:1528143724181};\\\", \\\"{x:1461,y:684,t:1528143724197};\\\", \\\"{x:1461,y:683,t:1528143724214};\\\", \\\"{x:1462,y:682,t:1528143724230};\\\", \\\"{x:1463,y:681,t:1528143724246};\\\", \\\"{x:1466,y:680,t:1528143724264};\\\", \\\"{x:1469,y:679,t:1528143724281};\\\", \\\"{x:1472,y:679,t:1528143724296};\\\", \\\"{x:1473,y:679,t:1528143724315};\\\", \\\"{x:1473,y:677,t:1528143724332};\\\", \\\"{x:1474,y:676,t:1528143724363};\\\", \\\"{x:1474,y:675,t:1528143724387};\\\", \\\"{x:1475,y:675,t:1528143724396};\\\", \\\"{x:1477,y:673,t:1528143724413};\\\", \\\"{x:1478,y:673,t:1528143724444};\\\", \\\"{x:1480,y:672,t:1528143724452};\\\", \\\"{x:1480,y:671,t:1528143724463};\\\", \\\"{x:1481,y:671,t:1528143724533};\\\", \\\"{x:1481,y:674,t:1528143724669};\\\", \\\"{x:1481,y:676,t:1528143724680};\\\", \\\"{x:1482,y:683,t:1528143724698};\\\", \\\"{x:1483,y:690,t:1528143724713};\\\", \\\"{x:1483,y:693,t:1528143724730};\\\", \\\"{x:1483,y:697,t:1528143724747};\\\", \\\"{x:1485,y:702,t:1528143724763};\\\", \\\"{x:1487,y:706,t:1528143724780};\\\", \\\"{x:1488,y:708,t:1528143724797};\\\", \\\"{x:1488,y:710,t:1528143724820};\\\", \\\"{x:1488,y:711,t:1528143724836};\\\", \\\"{x:1488,y:713,t:1528143724847};\\\", \\\"{x:1488,y:714,t:1528143724864};\\\", \\\"{x:1488,y:715,t:1528143724957};\\\", \\\"{x:1489,y:715,t:1528143724965};\\\", \\\"{x:1490,y:715,t:1528143724980};\\\", \\\"{x:1492,y:715,t:1528143724997};\\\", \\\"{x:1496,y:713,t:1528143725014};\\\", \\\"{x:1502,y:711,t:1528143725030};\\\", \\\"{x:1507,y:708,t:1528143725047};\\\", \\\"{x:1511,y:706,t:1528143725064};\\\", \\\"{x:1515,y:705,t:1528143725080};\\\", \\\"{x:1517,y:703,t:1528143725098};\\\", \\\"{x:1519,y:702,t:1528143725114};\\\", \\\"{x:1520,y:701,t:1528143725132};\\\", \\\"{x:1521,y:701,t:1528143725236};\\\", \\\"{x:1523,y:703,t:1528143725252};\\\", \\\"{x:1523,y:706,t:1528143725264};\\\", \\\"{x:1523,y:707,t:1528143725281};\\\", \\\"{x:1524,y:712,t:1528143725298};\\\", \\\"{x:1527,y:719,t:1528143725315};\\\", \\\"{x:1530,y:723,t:1528143725330};\\\", \\\"{x:1532,y:729,t:1528143725347};\\\", \\\"{x:1532,y:731,t:1528143725364};\\\", \\\"{x:1533,y:733,t:1528143725381};\\\", \\\"{x:1534,y:733,t:1528143725420};\\\", \\\"{x:1536,y:733,t:1528143725533};\\\", \\\"{x:1539,y:733,t:1528143725548};\\\", \\\"{x:1545,y:732,t:1528143725565};\\\", \\\"{x:1553,y:730,t:1528143725581};\\\", \\\"{x:1558,y:726,t:1528143725598};\\\", \\\"{x:1565,y:722,t:1528143725614};\\\", \\\"{x:1567,y:719,t:1528143725631};\\\", \\\"{x:1569,y:717,t:1528143725648};\\\", \\\"{x:1572,y:716,t:1528143725665};\\\", \\\"{x:1572,y:715,t:1528143725682};\\\", \\\"{x:1573,y:715,t:1528143725698};\\\", \\\"{x:1574,y:715,t:1528143725714};\\\", \\\"{x:1575,y:714,t:1528143725732};\\\", \\\"{x:1576,y:713,t:1528143725796};\\\", \\\"{x:1577,y:713,t:1528143725811};\\\", \\\"{x:1578,y:713,t:1528143725940};\\\", \\\"{x:1578,y:714,t:1528143725948};\\\", \\\"{x:1579,y:716,t:1528143725965};\\\", \\\"{x:1579,y:721,t:1528143725981};\\\", \\\"{x:1580,y:723,t:1528143725998};\\\", \\\"{x:1581,y:725,t:1528143726014};\\\", \\\"{x:1582,y:726,t:1528143726037};\\\", \\\"{x:1582,y:727,t:1528143726060};\\\", \\\"{x:1584,y:728,t:1528143726068};\\\", \\\"{x:1585,y:729,t:1528143726093};\\\", \\\"{x:1585,y:730,t:1528143726108};\\\", \\\"{x:1586,y:731,t:1528143726116};\\\", \\\"{x:1587,y:733,t:1528143726132};\\\", \\\"{x:1588,y:735,t:1528143726157};\\\", \\\"{x:1588,y:736,t:1528143726164};\\\", \\\"{x:1589,y:738,t:1528143726181};\\\", \\\"{x:1589,y:740,t:1528143726199};\\\", \\\"{x:1589,y:741,t:1528143726215};\\\", \\\"{x:1591,y:743,t:1528143726232};\\\", \\\"{x:1591,y:744,t:1528143726249};\\\", \\\"{x:1592,y:744,t:1528143726294};\\\", \\\"{x:1592,y:745,t:1528143726629};\\\", \\\"{x:1591,y:745,t:1528143726636};\\\", \\\"{x:1585,y:745,t:1528143726649};\\\", \\\"{x:1574,y:745,t:1528143726666};\\\", \\\"{x:1558,y:744,t:1528143726683};\\\", \\\"{x:1542,y:743,t:1528143726699};\\\", \\\"{x:1496,y:736,t:1528143726716};\\\", \\\"{x:1402,y:711,t:1528143726732};\\\", \\\"{x:1212,y:660,t:1528143726748};\\\", \\\"{x:1104,y:627,t:1528143726766};\\\", \\\"{x:1018,y:605,t:1528143726783};\\\", \\\"{x:871,y:563,t:1528143726800};\\\", \\\"{x:730,y:520,t:1528143726816};\\\", \\\"{x:614,y:489,t:1528143726833};\\\", \\\"{x:565,y:481,t:1528143726845};\\\", \\\"{x:532,y:470,t:1528143726861};\\\", \\\"{x:508,y:465,t:1528143726882};\\\", \\\"{x:493,y:463,t:1528143726899};\\\", \\\"{x:483,y:460,t:1528143726915};\\\", \\\"{x:482,y:460,t:1528143727117};\\\", \\\"{x:478,y:466,t:1528143727132};\\\", \\\"{x:476,y:471,t:1528143727149};\\\", \\\"{x:473,y:474,t:1528143727167};\\\", \\\"{x:472,y:475,t:1528143727182};\\\", \\\"{x:471,y:478,t:1528143727200};\\\", \\\"{x:469,y:482,t:1528143727216};\\\", \\\"{x:467,y:485,t:1528143727232};\\\", \\\"{x:465,y:487,t:1528143727251};\\\", \\\"{x:465,y:489,t:1528143727266};\\\", \\\"{x:465,y:490,t:1528143727282};\\\", \\\"{x:465,y:492,t:1528143727299};\\\", \\\"{x:465,y:495,t:1528143727316};\\\", \\\"{x:465,y:498,t:1528143727333};\\\", \\\"{x:465,y:501,t:1528143727349};\\\", \\\"{x:463,y:507,t:1528143727366};\\\", \\\"{x:460,y:512,t:1528143727383};\\\", \\\"{x:455,y:519,t:1528143727399};\\\", \\\"{x:449,y:527,t:1528143727417};\\\", \\\"{x:445,y:531,t:1528143727433};\\\", \\\"{x:441,y:535,t:1528143727449};\\\", \\\"{x:438,y:540,t:1528143727466};\\\", \\\"{x:436,y:544,t:1528143727483};\\\", \\\"{x:428,y:548,t:1528143727500};\\\", \\\"{x:415,y:559,t:1528143727517};\\\", \\\"{x:402,y:566,t:1528143727534};\\\", \\\"{x:395,y:568,t:1528143727550};\\\", \\\"{x:380,y:576,t:1528143727566};\\\", \\\"{x:374,y:578,t:1528143727583};\\\", \\\"{x:364,y:582,t:1528143727601};\\\", \\\"{x:351,y:585,t:1528143727616};\\\", \\\"{x:336,y:587,t:1528143727633};\\\", \\\"{x:317,y:588,t:1528143727650};\\\", \\\"{x:301,y:590,t:1528143727666};\\\", \\\"{x:291,y:592,t:1528143727683};\\\", \\\"{x:284,y:593,t:1528143727699};\\\", \\\"{x:275,y:595,t:1528143727718};\\\", \\\"{x:278,y:595,t:1528143727795};\\\", \\\"{x:282,y:595,t:1528143727804};\\\", \\\"{x:288,y:592,t:1528143727816};\\\", \\\"{x:299,y:587,t:1528143727833};\\\", \\\"{x:315,y:581,t:1528143727850};\\\", \\\"{x:323,y:576,t:1528143727866};\\\", \\\"{x:329,y:571,t:1528143727883};\\\", \\\"{x:347,y:565,t:1528143727900};\\\", \\\"{x:356,y:563,t:1528143727916};\\\", \\\"{x:367,y:557,t:1528143727934};\\\", \\\"{x:381,y:554,t:1528143727951};\\\", \\\"{x:390,y:550,t:1528143727968};\\\", \\\"{x:394,y:549,t:1528143727983};\\\", \\\"{x:402,y:546,t:1528143728000};\\\", \\\"{x:412,y:544,t:1528143728017};\\\", \\\"{x:425,y:544,t:1528143728034};\\\", \\\"{x:435,y:543,t:1528143728051};\\\", \\\"{x:440,y:542,t:1528143728068};\\\", \\\"{x:442,y:541,t:1528143728084};\\\", \\\"{x:440,y:541,t:1528143728204};\\\", \\\"{x:435,y:541,t:1528143728217};\\\", \\\"{x:429,y:544,t:1528143728233};\\\", \\\"{x:418,y:549,t:1528143728251};\\\", \\\"{x:407,y:552,t:1528143728267};\\\", \\\"{x:399,y:554,t:1528143728283};\\\", \\\"{x:372,y:564,t:1528143728300};\\\", \\\"{x:361,y:568,t:1528143728317};\\\", \\\"{x:352,y:570,t:1528143728332};\\\", \\\"{x:344,y:572,t:1528143728350};\\\", \\\"{x:335,y:573,t:1528143728367};\\\", \\\"{x:337,y:571,t:1528143728460};\\\", \\\"{x:340,y:565,t:1528143728467};\\\", \\\"{x:341,y:562,t:1528143728487};\\\", \\\"{x:361,y:551,t:1528143728504};\\\", \\\"{x:379,y:541,t:1528143728520};\\\", \\\"{x:398,y:530,t:1528143728537};\\\", \\\"{x:426,y:523,t:1528143728553};\\\", \\\"{x:455,y:515,t:1528143728570};\\\", \\\"{x:495,y:512,t:1528143728587};\\\", \\\"{x:533,y:507,t:1528143728603};\\\", \\\"{x:595,y:516,t:1528143728620};\\\", \\\"{x:664,y:525,t:1528143728637};\\\", \\\"{x:710,y:534,t:1528143728653};\\\", \\\"{x:742,y:544,t:1528143728671};\\\", \\\"{x:789,y:548,t:1528143728686};\\\", \\\"{x:800,y:548,t:1528143728703};\\\", \\\"{x:806,y:548,t:1528143728720};\\\", \\\"{x:811,y:547,t:1528143728736};\\\", \\\"{x:811,y:546,t:1528143728753};\\\", \\\"{x:814,y:546,t:1528143728770};\\\", \\\"{x:817,y:544,t:1528143728787};\\\", \\\"{x:818,y:544,t:1528143728803};\\\", \\\"{x:824,y:540,t:1528143728821};\\\", \\\"{x:828,y:537,t:1528143728836};\\\", \\\"{x:830,y:532,t:1528143728854};\\\", \\\"{x:831,y:531,t:1528143728870};\\\", \\\"{x:832,y:531,t:1528143728958};\\\", \\\"{x:832,y:530,t:1528143728983};\\\", \\\"{x:832,y:529,t:1528143728990};\\\", \\\"{x:832,y:528,t:1528143729007};\\\", \\\"{x:832,y:527,t:1528143729020};\\\", \\\"{x:832,y:525,t:1528143729037};\\\", \\\"{x:832,y:522,t:1528143729055};\\\", \\\"{x:832,y:518,t:1528143729070};\\\", \\\"{x:833,y:510,t:1528143729088};\\\", \\\"{x:836,y:505,t:1528143729103};\\\", \\\"{x:838,y:502,t:1528143729120};\\\", \\\"{x:839,y:502,t:1528143729137};\\\", \\\"{x:839,y:501,t:1528143729154};\\\", \\\"{x:840,y:500,t:1528143729170};\\\", \\\"{x:840,y:499,t:1528143729206};\\\", \\\"{x:835,y:499,t:1528143729542};\\\", \\\"{x:823,y:499,t:1528143729554};\\\", \\\"{x:783,y:488,t:1528143729571};\\\", \\\"{x:696,y:459,t:1528143729587};\\\", \\\"{x:598,y:439,t:1528143729604};\\\", \\\"{x:486,y:433,t:1528143729621};\\\", \\\"{x:381,y:433,t:1528143729637};\\\", \\\"{x:269,y:430,t:1528143729653};\\\", \\\"{x:124,y:429,t:1528143729670};\\\", \\\"{x:78,y:436,t:1528143729686};\\\", \\\"{x:57,y:445,t:1528143729704};\\\", \\\"{x:51,y:450,t:1528143729721};\\\", \\\"{x:49,y:452,t:1528143729737};\\\", \\\"{x:47,y:456,t:1528143729754};\\\", \\\"{x:45,y:459,t:1528143729771};\\\", \\\"{x:44,y:465,t:1528143729787};\\\", \\\"{x:43,y:467,t:1528143729804};\\\", \\\"{x:39,y:471,t:1528143729822};\\\", \\\"{x:37,y:477,t:1528143729837};\\\", \\\"{x:34,y:481,t:1528143729854};\\\", \\\"{x:33,y:489,t:1528143729871};\\\", \\\"{x:33,y:493,t:1528143729887};\\\", \\\"{x:33,y:496,t:1528143729904};\\\", \\\"{x:33,y:497,t:1528143729921};\\\", \\\"{x:33,y:498,t:1528143729959};\\\", \\\"{x:33,y:499,t:1528143729991};\\\", \\\"{x:36,y:503,t:1528143730005};\\\", \\\"{x:44,y:505,t:1528143730022};\\\", \\\"{x:64,y:513,t:1528143730040};\\\", \\\"{x:69,y:519,t:1528143730054};\\\", \\\"{x:90,y:528,t:1528143730071};\\\", \\\"{x:98,y:532,t:1528143730088};\\\", \\\"{x:101,y:533,t:1528143730103};\\\", \\\"{x:105,y:537,t:1528143730121};\\\", \\\"{x:109,y:541,t:1528143730138};\\\", \\\"{x:111,y:542,t:1528143730155};\\\", \\\"{x:112,y:542,t:1528143730171};\\\", \\\"{x:113,y:543,t:1528143730187};\\\", \\\"{x:115,y:544,t:1528143730206};\\\", \\\"{x:117,y:544,t:1528143730238};\\\", \\\"{x:122,y:544,t:1528143730254};\\\", \\\"{x:125,y:544,t:1528143730271};\\\", \\\"{x:126,y:544,t:1528143730335};\\\", \\\"{x:127,y:544,t:1528143730342};\\\", \\\"{x:130,y:544,t:1528143730358};\\\", \\\"{x:132,y:544,t:1528143730371};\\\", \\\"{x:133,y:544,t:1528143730388};\\\", \\\"{x:135,y:544,t:1528143730582};\\\", \\\"{x:136,y:545,t:1528143730598};\\\", \\\"{x:137,y:546,t:1528143730671};\\\", \\\"{x:138,y:546,t:1528143730719};\\\", \\\"{x:139,y:546,t:1528143730776};\\\", \\\"{x:140,y:546,t:1528143730791};\\\", \\\"{x:140,y:545,t:1528143730815};\\\", \\\"{x:141,y:545,t:1528143730830};\\\", \\\"{x:142,y:545,t:1528143730847};\\\", \\\"{x:143,y:544,t:1528143730871};\\\", \\\"{x:144,y:544,t:1528143730935};\\\", \\\"{x:144,y:543,t:1528143730943};\\\", \\\"{x:146,y:543,t:1528143731239};\\\", \\\"{x:153,y:544,t:1528143731257};\\\", \\\"{x:164,y:554,t:1528143731274};\\\", \\\"{x:174,y:563,t:1528143731291};\\\", \\\"{x:186,y:573,t:1528143731305};\\\", \\\"{x:195,y:581,t:1528143731322};\\\", \\\"{x:204,y:586,t:1528143731339};\\\", \\\"{x:213,y:595,t:1528143731355};\\\", \\\"{x:225,y:595,t:1528143731372};\\\", \\\"{x:238,y:598,t:1528143731388};\\\", \\\"{x:243,y:602,t:1528143731405};\\\", \\\"{x:255,y:607,t:1528143731421};\\\", \\\"{x:267,y:611,t:1528143731439};\\\", \\\"{x:277,y:616,t:1528143731455};\\\", \\\"{x:284,y:617,t:1528143731472};\\\", \\\"{x:287,y:618,t:1528143731489};\\\", \\\"{x:287,y:611,t:1528143731575};\\\", \\\"{x:286,y:598,t:1528143731590};\\\", \\\"{x:273,y:574,t:1528143731605};\\\", \\\"{x:262,y:550,t:1528143731623};\\\", \\\"{x:259,y:543,t:1528143731639};\\\", \\\"{x:254,y:537,t:1528143731655};\\\", \\\"{x:247,y:527,t:1528143731672};\\\", \\\"{x:243,y:523,t:1528143731689};\\\", \\\"{x:240,y:519,t:1528143731706};\\\", \\\"{x:237,y:516,t:1528143731722};\\\", \\\"{x:236,y:516,t:1528143731742};\\\", \\\"{x:235,y:516,t:1528143731774};\\\", \\\"{x:234,y:516,t:1528143731789};\\\", \\\"{x:229,y:517,t:1528143731806};\\\", \\\"{x:224,y:518,t:1528143731823};\\\", \\\"{x:218,y:525,t:1528143731839};\\\", \\\"{x:208,y:531,t:1528143731856};\\\", \\\"{x:198,y:538,t:1528143731872};\\\", \\\"{x:185,y:540,t:1528143731890};\\\", \\\"{x:182,y:543,t:1528143731906};\\\", \\\"{x:182,y:544,t:1528143731923};\\\", \\\"{x:180,y:545,t:1528143731939};\\\", \\\"{x:177,y:547,t:1528143731956};\\\", \\\"{x:179,y:552,t:1528143732905};\\\", \\\"{x:191,y:566,t:1528143732923};\\\", \\\"{x:204,y:578,t:1528143732940};\\\", \\\"{x:212,y:590,t:1528143732957};\\\", \\\"{x:228,y:601,t:1528143732973};\\\", \\\"{x:271,y:631,t:1528143732990};\\\", \\\"{x:288,y:646,t:1528143733007};\\\", \\\"{x:322,y:667,t:1528143733022};\\\", \\\"{x:347,y:685,t:1528143733040};\\\", \\\"{x:356,y:693,t:1528143733057};\\\", \\\"{x:361,y:699,t:1528143733073};\\\", \\\"{x:365,y:701,t:1528143733090};\\\", \\\"{x:367,y:704,t:1528143733106};\\\", \\\"{x:367,y:705,t:1528143733124};\\\", \\\"{x:373,y:710,t:1528143733140};\\\", \\\"{x:380,y:715,t:1528143733157};\\\", \\\"{x:391,y:724,t:1528143733174};\\\", \\\"{x:403,y:733,t:1528143733190};\\\", \\\"{x:415,y:739,t:1528143733206};\\\", \\\"{x:425,y:742,t:1528143733224};\\\", \\\"{x:437,y:747,t:1528143733241};\\\", \\\"{x:439,y:748,t:1528143733257};\\\", \\\"{x:444,y:751,t:1528143733278};\\\", \\\"{x:445,y:751,t:1528143733291};\\\", \\\"{x:446,y:751,t:1528143733308};\\\", \\\"{x:449,y:751,t:1528143733325};\\\", \\\"{x:450,y:750,t:1528143733341};\\\", \\\"{x:452,y:749,t:1528143733357};\\\", \\\"{x:453,y:747,t:1528143733374};\\\", \\\"{x:453,y:746,t:1528143733391};\\\", \\\"{x:453,y:744,t:1528143733415};\\\", \\\"{x:454,y:742,t:1528143733479};\\\", \\\"{x:455,y:742,t:1528143733503};\\\", \\\"{x:455,y:740,t:1528143734008};\\\", \\\"{x:438,y:719,t:1528143734024};\\\", \\\"{x:428,y:710,t:1528143734042};\\\", \\\"{x:424,y:707,t:1528143734057};\\\", \\\"{x:408,y:689,t:1528143734075};\\\", \\\"{x:331,y:648,t:1528143734091};\\\", \\\"{x:221,y:602,t:1528143734107};\\\", \\\"{x:134,y:575,t:1528143734124};\\\", \\\"{x:135,y:574,t:1528143734535};\\\", \\\"{x:136,y:572,t:1528143734543};\\\", \\\"{x:143,y:563,t:1528143734559};\\\", \\\"{x:145,y:554,t:1528143734574};\\\", \\\"{x:150,y:541,t:1528143734591};\\\", \\\"{x:155,y:527,t:1528143734609};\\\", \\\"{x:163,y:514,t:1528143734625};\\\", \\\"{x:172,y:499,t:1528143734641};\\\", \\\"{x:182,y:487,t:1528143734658};\\\", \\\"{x:192,y:471,t:1528143734674};\\\", \\\"{x:204,y:457,t:1528143734691};\\\", \\\"{x:218,y:444,t:1528143734708};\\\", \\\"{x:243,y:424,t:1528143734726};\\\", \\\"{x:268,y:406,t:1528143734741};\\\", \\\"{x:339,y:364,t:1528143734779};\\\", \\\"{x:375,y:349,t:1528143734791};\\\", \\\"{x:432,y:330,t:1528143734808};\\\", \\\"{x:528,y:320,t:1528143734825};\\\", \\\"{x:568,y:313,t:1528143734841};\\\", \\\"{x:614,y:306,t:1528143734858};\\\" ] }, { \\\"rt\\\": 44005, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 770931, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:901,y:383,t:1528143735021};\\\", \\\"{x:902,y:383,t:1528143735039};\\\", \\\"{x:901,y:384,t:1528143735518};\\\", \\\"{x:900,y:386,t:1528143735526};\\\", \\\"{x:896,y:389,t:1528143735542};\\\", \\\"{x:893,y:392,t:1528143735559};\\\", \\\"{x:892,y:393,t:1528143735575};\\\", \\\"{x:889,y:395,t:1528143735592};\\\", \\\"{x:886,y:397,t:1528143735611};\\\", \\\"{x:885,y:398,t:1528143735638};\\\", \\\"{x:884,y:398,t:1528143735654};\\\", \\\"{x:883,y:399,t:1528143735678};\\\", \\\"{x:883,y:402,t:1528143741600};\\\", \\\"{x:890,y:407,t:1528143741614};\\\", \\\"{x:990,y:457,t:1528143741631};\\\", \\\"{x:1079,y:488,t:1528143741647};\\\", \\\"{x:1178,y:524,t:1528143741664};\\\", \\\"{x:1263,y:559,t:1528143741681};\\\", \\\"{x:1338,y:593,t:1528143741698};\\\", \\\"{x:1365,y:606,t:1528143741714};\\\", \\\"{x:1384,y:613,t:1528143741731};\\\", \\\"{x:1394,y:617,t:1528143741748};\\\", \\\"{x:1400,y:619,t:1528143741764};\\\", \\\"{x:1403,y:619,t:1528143741782};\\\", \\\"{x:1409,y:620,t:1528143741799};\\\", \\\"{x:1413,y:620,t:1528143741814};\\\", \\\"{x:1417,y:620,t:1528143741831};\\\", \\\"{x:1419,y:620,t:1528143741848};\\\", \\\"{x:1420,y:620,t:1528143741934};\\\", \\\"{x:1421,y:620,t:1528143741948};\\\", \\\"{x:1423,y:619,t:1528143741974};\\\", \\\"{x:1423,y:617,t:1528143741982};\\\", \\\"{x:1418,y:611,t:1528143741997};\\\", \\\"{x:1403,y:597,t:1528143742014};\\\", \\\"{x:1384,y:580,t:1528143742030};\\\", \\\"{x:1376,y:575,t:1528143742048};\\\", \\\"{x:1366,y:571,t:1528143742065};\\\", \\\"{x:1357,y:570,t:1528143742081};\\\", \\\"{x:1340,y:568,t:1528143742098};\\\", \\\"{x:1329,y:565,t:1528143742114};\\\", \\\"{x:1318,y:563,t:1528143742130};\\\", \\\"{x:1300,y:561,t:1528143742147};\\\", \\\"{x:1280,y:554,t:1528143742164};\\\", \\\"{x:1252,y:546,t:1528143742181};\\\", \\\"{x:1248,y:543,t:1528143742197};\\\", \\\"{x:1237,y:541,t:1528143742214};\\\", \\\"{x:1236,y:541,t:1528143742230};\\\", \\\"{x:1235,y:540,t:1528143742247};\\\", \\\"{x:1235,y:538,t:1528143742375};\\\", \\\"{x:1237,y:537,t:1528143742382};\\\", \\\"{x:1240,y:536,t:1528143742397};\\\", \\\"{x:1249,y:529,t:1528143742415};\\\", \\\"{x:1257,y:527,t:1528143742431};\\\", \\\"{x:1263,y:524,t:1528143742448};\\\", \\\"{x:1265,y:520,t:1528143742465};\\\", \\\"{x:1270,y:519,t:1528143742481};\\\", \\\"{x:1275,y:517,t:1528143742498};\\\", \\\"{x:1280,y:513,t:1528143742525};\\\", \\\"{x:1282,y:512,t:1528143742554};\\\", \\\"{x:1283,y:512,t:1528143742565};\\\", \\\"{x:1284,y:510,t:1528143742581};\\\", \\\"{x:1287,y:510,t:1528143742598};\\\", \\\"{x:1292,y:508,t:1528143742614};\\\", \\\"{x:1295,y:507,t:1528143742631};\\\", \\\"{x:1296,y:506,t:1528143742647};\\\", \\\"{x:1297,y:505,t:1528143742671};\\\", \\\"{x:1298,y:505,t:1528143742681};\\\", \\\"{x:1301,y:504,t:1528143742697};\\\", \\\"{x:1305,y:503,t:1528143742715};\\\", \\\"{x:1306,y:503,t:1528143742732};\\\", \\\"{x:1307,y:503,t:1528143742748};\\\", \\\"{x:1307,y:502,t:1528143742775};\\\", \\\"{x:1312,y:502,t:1528143742832};\\\", \\\"{x:1313,y:502,t:1528143742856};\\\", \\\"{x:1314,y:502,t:1528143742865};\\\", \\\"{x:1316,y:502,t:1528143742882};\\\", \\\"{x:1317,y:502,t:1528143742968};\\\", \\\"{x:1318,y:502,t:1528143746368};\\\", \\\"{x:1318,y:514,t:1528143746384};\\\", \\\"{x:1315,y:539,t:1528143746401};\\\", \\\"{x:1311,y:561,t:1528143746419};\\\", \\\"{x:1306,y:585,t:1528143746434};\\\", \\\"{x:1306,y:603,t:1528143746451};\\\", \\\"{x:1302,y:618,t:1528143746468};\\\", \\\"{x:1298,y:637,t:1528143746484};\\\", \\\"{x:1295,y:655,t:1528143746501};\\\", \\\"{x:1295,y:672,t:1528143746518};\\\", \\\"{x:1293,y:686,t:1528143746534};\\\", \\\"{x:1293,y:708,t:1528143746551};\\\", \\\"{x:1295,y:719,t:1528143746568};\\\", \\\"{x:1298,y:727,t:1528143746585};\\\", \\\"{x:1298,y:729,t:1528143746602};\\\", \\\"{x:1298,y:730,t:1528143746618};\\\", \\\"{x:1299,y:731,t:1528143746635};\\\", \\\"{x:1299,y:732,t:1528143746651};\\\", \\\"{x:1300,y:736,t:1528143746669};\\\", \\\"{x:1301,y:741,t:1528143746685};\\\", \\\"{x:1303,y:750,t:1528143746702};\\\", \\\"{x:1305,y:756,t:1528143746718};\\\", \\\"{x:1306,y:762,t:1528143746734};\\\", \\\"{x:1306,y:764,t:1528143746751};\\\", \\\"{x:1307,y:766,t:1528143746768};\\\", \\\"{x:1307,y:767,t:1528143746785};\\\", \\\"{x:1308,y:769,t:1528143746801};\\\", \\\"{x:1310,y:772,t:1528143746818};\\\", \\\"{x:1312,y:775,t:1528143746835};\\\", \\\"{x:1312,y:776,t:1528143746943};\\\", \\\"{x:1312,y:778,t:1528143747503};\\\", \\\"{x:1311,y:778,t:1528143747519};\\\", \\\"{x:1310,y:778,t:1528143747535};\\\", \\\"{x:1309,y:778,t:1528143747552};\\\", \\\"{x:1308,y:778,t:1528143747735};\\\", \\\"{x:1307,y:778,t:1528143747792};\\\", \\\"{x:1306,y:778,t:1528143747808};\\\", \\\"{x:1304,y:778,t:1528143747823};\\\", \\\"{x:1301,y:778,t:1528143747880};\\\", \\\"{x:1299,y:778,t:1528143747887};\\\", \\\"{x:1297,y:778,t:1528143747903};\\\", \\\"{x:1287,y:774,t:1528143747919};\\\", \\\"{x:1282,y:772,t:1528143747936};\\\", \\\"{x:1276,y:771,t:1528143747953};\\\", \\\"{x:1273,y:769,t:1528143747970};\\\", \\\"{x:1268,y:768,t:1528143747986};\\\", \\\"{x:1266,y:766,t:1528143748002};\\\", \\\"{x:1264,y:765,t:1528143748020};\\\", \\\"{x:1260,y:765,t:1528143748036};\\\", \\\"{x:1258,y:763,t:1528143748052};\\\", \\\"{x:1257,y:762,t:1528143748080};\\\", \\\"{x:1256,y:762,t:1528143748087};\\\", \\\"{x:1255,y:762,t:1528143748102};\\\", \\\"{x:1255,y:761,t:1528143748119};\\\", \\\"{x:1254,y:761,t:1528143748160};\\\", \\\"{x:1254,y:760,t:1528143748799};\\\", \\\"{x:1256,y:760,t:1528143748807};\\\", \\\"{x:1264,y:757,t:1528143748820};\\\", \\\"{x:1269,y:757,t:1528143748837};\\\", \\\"{x:1275,y:757,t:1528143748854};\\\", \\\"{x:1280,y:757,t:1528143748871};\\\", \\\"{x:1288,y:757,t:1528143748886};\\\", \\\"{x:1293,y:757,t:1528143748903};\\\", \\\"{x:1296,y:757,t:1528143748921};\\\", \\\"{x:1297,y:757,t:1528143748967};\\\", \\\"{x:1298,y:758,t:1528143749055};\\\", \\\"{x:1298,y:759,t:1528143749087};\\\", \\\"{x:1299,y:761,t:1528143749143};\\\", \\\"{x:1302,y:763,t:1528143749159};\\\", \\\"{x:1304,y:764,t:1528143749175};\\\", \\\"{x:1306,y:764,t:1528143749187};\\\", \\\"{x:1307,y:764,t:1528143749204};\\\", \\\"{x:1308,y:766,t:1528143749231};\\\", \\\"{x:1309,y:766,t:1528143749247};\\\", \\\"{x:1311,y:767,t:1528143749263};\\\", \\\"{x:1312,y:767,t:1528143749280};\\\", \\\"{x:1313,y:768,t:1528143749296};\\\", \\\"{x:1314,y:768,t:1528143749304};\\\", \\\"{x:1316,y:768,t:1528143749321};\\\", \\\"{x:1316,y:769,t:1528143749338};\\\", \\\"{x:1318,y:769,t:1528143749353};\\\", \\\"{x:1321,y:769,t:1528143749370};\\\", \\\"{x:1322,y:769,t:1528143749399};\\\", \\\"{x:1323,y:769,t:1528143749471};\\\", \\\"{x:1324,y:769,t:1528143749503};\\\", \\\"{x:1325,y:769,t:1528143749648};\\\", \\\"{x:1326,y:769,t:1528143749695};\\\", \\\"{x:1326,y:767,t:1528143770679};\\\", \\\"{x:1326,y:766,t:1528143770687};\\\", \\\"{x:1324,y:760,t:1528143770705};\\\", \\\"{x:1322,y:757,t:1528143770720};\\\", \\\"{x:1319,y:754,t:1528143770738};\\\", \\\"{x:1317,y:751,t:1528143770755};\\\", \\\"{x:1315,y:749,t:1528143770771};\\\", \\\"{x:1313,y:746,t:1528143770788};\\\", \\\"{x:1313,y:745,t:1528143770951};\\\", \\\"{x:1310,y:741,t:1528143770959};\\\", \\\"{x:1309,y:737,t:1528143770970};\\\", \\\"{x:1308,y:729,t:1528143770987};\\\", \\\"{x:1304,y:722,t:1528143771005};\\\", \\\"{x:1299,y:705,t:1528143771022};\\\", \\\"{x:1295,y:691,t:1528143771038};\\\", \\\"{x:1286,y:658,t:1528143771055};\\\", \\\"{x:1279,y:638,t:1528143771071};\\\", \\\"{x:1274,y:621,t:1528143771088};\\\", \\\"{x:1269,y:606,t:1528143771104};\\\", \\\"{x:1262,y:594,t:1528143771120};\\\", \\\"{x:1260,y:585,t:1528143771137};\\\", \\\"{x:1257,y:580,t:1528143771154};\\\", \\\"{x:1256,y:576,t:1528143771171};\\\", \\\"{x:1254,y:573,t:1528143771187};\\\", \\\"{x:1254,y:571,t:1528143771204};\\\", \\\"{x:1253,y:568,t:1528143771221};\\\", \\\"{x:1252,y:567,t:1528143771237};\\\", \\\"{x:1250,y:564,t:1528143771254};\\\", \\\"{x:1250,y:563,t:1528143771286};\\\", \\\"{x:1250,y:562,t:1528143771294};\\\", \\\"{x:1250,y:561,t:1528143771309};\\\", \\\"{x:1250,y:560,t:1528143771326};\\\", \\\"{x:1250,y:559,t:1528143771337};\\\", \\\"{x:1250,y:558,t:1528143771354};\\\", \\\"{x:1250,y:556,t:1528143771374};\\\", \\\"{x:1249,y:553,t:1528143771398};\\\", \\\"{x:1248,y:552,t:1528143771414};\\\", \\\"{x:1248,y:551,t:1528143771422};\\\", \\\"{x:1248,y:550,t:1528143771470};\\\", \\\"{x:1249,y:548,t:1528143771488};\\\", \\\"{x:1251,y:547,t:1528143771504};\\\", \\\"{x:1254,y:547,t:1528143771522};\\\", \\\"{x:1255,y:547,t:1528143771568};\\\", \\\"{x:1255,y:548,t:1528143771888};\\\", \\\"{x:1254,y:548,t:1528143771911};\\\", \\\"{x:1254,y:550,t:1528143771935};\\\", \\\"{x:1254,y:551,t:1528143772119};\\\", \\\"{x:1254,y:552,t:1528143772150};\\\", \\\"{x:1255,y:553,t:1528143772239};\\\", \\\"{x:1256,y:553,t:1528143772256};\\\", \\\"{x:1257,y:553,t:1528143774247};\\\", \\\"{x:1258,y:553,t:1528143774257};\\\", \\\"{x:1262,y:555,t:1528143774273};\\\", \\\"{x:1264,y:556,t:1528143774291};\\\", \\\"{x:1265,y:557,t:1528143774306};\\\", \\\"{x:1266,y:557,t:1528143774350};\\\", \\\"{x:1266,y:560,t:1528143774470};\\\", \\\"{x:1266,y:561,t:1528143774478};\\\", \\\"{x:1262,y:565,t:1528143774491};\\\", \\\"{x:1247,y:571,t:1528143774507};\\\", \\\"{x:1229,y:578,t:1528143774523};\\\", \\\"{x:1215,y:585,t:1528143774541};\\\", \\\"{x:1194,y:590,t:1528143774557};\\\", \\\"{x:1158,y:599,t:1528143774574};\\\", \\\"{x:1001,y:605,t:1528143774591};\\\", \\\"{x:882,y:605,t:1528143774607};\\\", \\\"{x:813,y:605,t:1528143774623};\\\", \\\"{x:769,y:595,t:1528143774640};\\\", \\\"{x:696,y:587,t:1528143774656};\\\", \\\"{x:598,y:572,t:1528143774672};\\\", \\\"{x:544,y:561,t:1528143774692};\\\", \\\"{x:507,y:550,t:1528143774708};\\\", \\\"{x:494,y:543,t:1528143774725};\\\", \\\"{x:478,y:537,t:1528143774741};\\\", \\\"{x:464,y:532,t:1528143774757};\\\", \\\"{x:460,y:530,t:1528143774773};\\\", \\\"{x:459,y:530,t:1528143774806};\\\", \\\"{x:458,y:530,t:1528143774822};\\\", \\\"{x:458,y:529,t:1528143774830};\\\", \\\"{x:458,y:528,t:1528143774841};\\\", \\\"{x:458,y:523,t:1528143774858};\\\", \\\"{x:458,y:518,t:1528143774874};\\\", \\\"{x:461,y:516,t:1528143774892};\\\", \\\"{x:471,y:509,t:1528143774907};\\\", \\\"{x:479,y:504,t:1528143774924};\\\", \\\"{x:485,y:500,t:1528143774941};\\\", \\\"{x:496,y:497,t:1528143774958};\\\", \\\"{x:499,y:495,t:1528143774976};\\\", \\\"{x:505,y:494,t:1528143774991};\\\", \\\"{x:517,y:494,t:1528143775008};\\\", \\\"{x:528,y:495,t:1528143775024};\\\", \\\"{x:533,y:497,t:1528143775041};\\\", \\\"{x:536,y:500,t:1528143775058};\\\", \\\"{x:546,y:504,t:1528143775075};\\\", \\\"{x:548,y:506,t:1528143775092};\\\", \\\"{x:552,y:507,t:1528143775109};\\\", \\\"{x:556,y:509,t:1528143775126};\\\", \\\"{x:562,y:511,t:1528143775141};\\\", \\\"{x:565,y:512,t:1528143775159};\\\", \\\"{x:566,y:512,t:1528143775175};\\\", \\\"{x:568,y:512,t:1528143775192};\\\", \\\"{x:569,y:512,t:1528143775209};\\\", \\\"{x:572,y:512,t:1528143775225};\\\", \\\"{x:573,y:512,t:1528143775241};\\\", \\\"{x:577,y:512,t:1528143775259};\\\", \\\"{x:579,y:512,t:1528143775276};\\\", \\\"{x:585,y:512,t:1528143775291};\\\", \\\"{x:591,y:509,t:1528143775309};\\\", \\\"{x:593,y:509,t:1528143775325};\\\", \\\"{x:597,y:508,t:1528143775341};\\\", \\\"{x:602,y:505,t:1528143775360};\\\", \\\"{x:605,y:504,t:1528143775375};\\\", \\\"{x:603,y:509,t:1528143776031};\\\", \\\"{x:600,y:514,t:1528143776043};\\\", \\\"{x:596,y:520,t:1528143776059};\\\", \\\"{x:592,y:527,t:1528143776075};\\\", \\\"{x:583,y:538,t:1528143776092};\\\", \\\"{x:574,y:547,t:1528143776109};\\\", \\\"{x:564,y:559,t:1528143776126};\\\", \\\"{x:545,y:580,t:1528143776142};\\\", \\\"{x:530,y:591,t:1528143776160};\\\", \\\"{x:523,y:597,t:1528143776176};\\\", \\\"{x:512,y:610,t:1528143776193};\\\", \\\"{x:505,y:622,t:1528143776209};\\\", \\\"{x:498,y:636,t:1528143776227};\\\", \\\"{x:493,y:644,t:1528143776242};\\\", \\\"{x:489,y:652,t:1528143776259};\\\", \\\"{x:486,y:655,t:1528143776276};\\\", \\\"{x:485,y:659,t:1528143776293};\\\", \\\"{x:483,y:661,t:1528143776309};\\\", \\\"{x:483,y:666,t:1528143776327};\\\", \\\"{x:483,y:669,t:1528143776343};\\\", \\\"{x:483,y:672,t:1528143776360};\\\", \\\"{x:483,y:674,t:1528143776377};\\\", \\\"{x:483,y:675,t:1528143776392};\\\", \\\"{x:483,y:676,t:1528143776414};\\\", \\\"{x:483,y:677,t:1528143776429};\\\", \\\"{x:483,y:678,t:1528143776445};\\\", \\\"{x:483,y:680,t:1528143776559};\\\", \\\"{x:483,y:681,t:1528143776631};\\\", \\\"{x:483,y:683,t:1528143778255};\\\", \\\"{x:483,y:687,t:1528143778263};\\\", \\\"{x:483,y:699,t:1528143778280};\\\", \\\"{x:485,y:713,t:1528143778295};\\\", \\\"{x:488,y:724,t:1528143778315};\\\", \\\"{x:489,y:733,t:1528143778328};\\\", \\\"{x:491,y:738,t:1528143778345};\\\", \\\"{x:493,y:741,t:1528143778361};\\\", \\\"{x:493,y:743,t:1528143778377};\\\", \\\"{x:494,y:744,t:1528143778393};\\\" ] }, { \\\"rt\\\": 21168, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 793413, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:744,t:1528143781559};\\\", \\\"{x:491,y:731,t:1528143781590};\\\", \\\"{x:490,y:726,t:1528143781598};\\\", \\\"{x:484,y:713,t:1528143781616};\\\", \\\"{x:480,y:702,t:1528143781632};\\\", \\\"{x:476,y:696,t:1528143781646};\\\", \\\"{x:471,y:689,t:1528143781664};\\\", \\\"{x:471,y:684,t:1528143781681};\\\", \\\"{x:466,y:679,t:1528143781696};\\\", \\\"{x:464,y:676,t:1528143781713};\\\", \\\"{x:463,y:675,t:1528143781750};\\\", \\\"{x:463,y:674,t:1528143782087};\\\", \\\"{x:462,y:673,t:1528143782098};\\\", \\\"{x:461,y:672,t:1528143782118};\\\", \\\"{x:460,y:672,t:1528143782134};\\\", \\\"{x:458,y:670,t:1528143782151};\\\", \\\"{x:457,y:669,t:1528143782200};\\\", \\\"{x:456,y:669,t:1528143782214};\\\", \\\"{x:455,y:668,t:1528143782463};\\\", \\\"{x:454,y:668,t:1528143782470};\\\", \\\"{x:453,y:667,t:1528143782481};\\\", \\\"{x:452,y:667,t:1528143782497};\\\", \\\"{x:451,y:667,t:1528143782515};\\\", \\\"{x:449,y:666,t:1528143782530};\\\", \\\"{x:447,y:665,t:1528143782548};\\\", \\\"{x:447,y:664,t:1528143782565};\\\", \\\"{x:446,y:664,t:1528143782598};\\\", \\\"{x:446,y:663,t:1528143782695};\\\", \\\"{x:444,y:662,t:1528143782855};\\\", \\\"{x:443,y:661,t:1528143782865};\\\", \\\"{x:442,y:661,t:1528143782882};\\\", \\\"{x:441,y:660,t:1528143782898};\\\", \\\"{x:438,y:660,t:1528143782915};\\\", \\\"{x:436,y:658,t:1528143782932};\\\", \\\"{x:433,y:658,t:1528143782948};\\\", \\\"{x:431,y:655,t:1528143782965};\\\", \\\"{x:430,y:654,t:1528143782982};\\\", \\\"{x:429,y:654,t:1528143783023};\\\", \\\"{x:428,y:654,t:1528143783046};\\\", \\\"{x:427,y:654,t:1528143783055};\\\", \\\"{x:425,y:653,t:1528143783065};\\\", \\\"{x:424,y:651,t:1528143783094};\\\", \\\"{x:422,y:651,t:1528143783102};\\\", \\\"{x:421,y:651,t:1528143783127};\\\", \\\"{x:420,y:651,t:1528143783143};\\\", \\\"{x:419,y:651,t:1528143783151};\\\", \\\"{x:418,y:651,t:1528143783174};\\\", \\\"{x:417,y:651,t:1528143783207};\\\", \\\"{x:415,y:651,t:1528143783246};\\\", \\\"{x:413,y:651,t:1528143783269};\\\", \\\"{x:411,y:650,t:1528143783293};\\\", \\\"{x:410,y:649,t:1528143783301};\\\", \\\"{x:409,y:647,t:1528143783314};\\\", \\\"{x:405,y:641,t:1528143783331};\\\", \\\"{x:400,y:632,t:1528143783349};\\\", \\\"{x:396,y:621,t:1528143783366};\\\", \\\"{x:393,y:610,t:1528143783382};\\\", \\\"{x:391,y:608,t:1528143783398};\\\", \\\"{x:389,y:602,t:1528143783415};\\\", \\\"{x:385,y:589,t:1528143783432};\\\", \\\"{x:381,y:577,t:1528143783448};\\\", \\\"{x:377,y:564,t:1528143783465};\\\", \\\"{x:373,y:555,t:1528143783483};\\\", \\\"{x:371,y:546,t:1528143783498};\\\", \\\"{x:368,y:539,t:1528143783516};\\\", \\\"{x:366,y:532,t:1528143783531};\\\", \\\"{x:365,y:530,t:1528143783548};\\\", \\\"{x:365,y:528,t:1528143783566};\\\", \\\"{x:365,y:524,t:1528143783582};\\\", \\\"{x:365,y:520,t:1528143783598};\\\", \\\"{x:365,y:514,t:1528143783615};\\\", \\\"{x:365,y:512,t:1528143783631};\\\", \\\"{x:365,y:508,t:1528143783648};\\\", \\\"{x:365,y:505,t:1528143783666};\\\", \\\"{x:365,y:501,t:1528143783682};\\\", \\\"{x:365,y:497,t:1528143783699};\\\", \\\"{x:365,y:496,t:1528143783718};\\\", \\\"{x:365,y:495,t:1528143783731};\\\", \\\"{x:365,y:494,t:1528143783749};\\\", \\\"{x:365,y:493,t:1528143783766};\\\", \\\"{x:365,y:492,t:1528143783782};\\\", \\\"{x:366,y:489,t:1528143783798};\\\", \\\"{x:369,y:495,t:1528143785863};\\\", \\\"{x:375,y:506,t:1528143785871};\\\", \\\"{x:381,y:515,t:1528143785884};\\\", \\\"{x:397,y:531,t:1528143785903};\\\", \\\"{x:439,y:579,t:1528143785918};\\\", \\\"{x:493,y:623,t:1528143785950};\\\", \\\"{x:506,y:629,t:1528143785967};\\\", \\\"{x:522,y:643,t:1528143785984};\\\", \\\"{x:550,y:658,t:1528143786001};\\\", \\\"{x:633,y:685,t:1528143786017};\\\", \\\"{x:697,y:701,t:1528143786034};\\\", \\\"{x:733,y:713,t:1528143786051};\\\", \\\"{x:749,y:722,t:1528143786066};\\\", \\\"{x:761,y:727,t:1528143786083};\\\", \\\"{x:766,y:730,t:1528143786101};\\\", \\\"{x:774,y:734,t:1528143786117};\\\", \\\"{x:775,y:734,t:1528143786134};\\\", \\\"{x:780,y:734,t:1528143786150};\\\", \\\"{x:783,y:735,t:1528143786167};\\\", \\\"{x:788,y:738,t:1528143786184};\\\", \\\"{x:796,y:743,t:1528143786201};\\\", \\\"{x:804,y:747,t:1528143786217};\\\", \\\"{x:820,y:752,t:1528143786234};\\\", \\\"{x:838,y:758,t:1528143786251};\\\", \\\"{x:852,y:761,t:1528143786267};\\\", \\\"{x:875,y:765,t:1528143786284};\\\", \\\"{x:898,y:769,t:1528143786301};\\\", \\\"{x:936,y:776,t:1528143786318};\\\", \\\"{x:952,y:781,t:1528143786334};\\\", \\\"{x:1017,y:794,t:1528143786351};\\\", \\\"{x:1040,y:804,t:1528143786368};\\\", \\\"{x:1075,y:815,t:1528143786384};\\\", \\\"{x:1121,y:822,t:1528143786402};\\\", \\\"{x:1170,y:835,t:1528143786419};\\\", \\\"{x:1201,y:841,t:1528143786434};\\\", \\\"{x:1218,y:849,t:1528143786451};\\\", \\\"{x:1233,y:852,t:1528143786469};\\\", \\\"{x:1244,y:852,t:1528143786485};\\\", \\\"{x:1250,y:853,t:1528143786501};\\\", \\\"{x:1254,y:853,t:1528143786518};\\\", \\\"{x:1255,y:853,t:1528143786551};\\\", \\\"{x:1257,y:851,t:1528143786569};\\\", \\\"{x:1257,y:848,t:1528143786584};\\\", \\\"{x:1259,y:841,t:1528143786601};\\\", \\\"{x:1259,y:833,t:1528143786618};\\\", \\\"{x:1259,y:825,t:1528143786634};\\\", \\\"{x:1261,y:821,t:1528143786651};\\\", \\\"{x:1261,y:820,t:1528143786668};\\\", \\\"{x:1261,y:818,t:1528143786684};\\\", \\\"{x:1261,y:817,t:1528143786703};\\\", \\\"{x:1261,y:816,t:1528143786879};\\\", \\\"{x:1258,y:816,t:1528143786887};\\\", \\\"{x:1257,y:816,t:1528143786901};\\\", \\\"{x:1251,y:818,t:1528143786918};\\\", \\\"{x:1243,y:821,t:1528143786935};\\\", \\\"{x:1232,y:826,t:1528143786951};\\\", \\\"{x:1227,y:827,t:1528143786968};\\\", \\\"{x:1221,y:831,t:1528143786985};\\\", \\\"{x:1217,y:831,t:1528143787004};\\\", \\\"{x:1215,y:832,t:1528143787017};\\\", \\\"{x:1214,y:832,t:1528143787034};\\\", \\\"{x:1213,y:832,t:1528143787078};\\\", \\\"{x:1211,y:832,t:1528143791578};\\\", \\\"{x:1208,y:832,t:1528143791592};\\\", \\\"{x:1206,y:830,t:1528143791609};\\\", \\\"{x:1201,y:828,t:1528143791625};\\\", \\\"{x:1197,y:825,t:1528143791642};\\\", \\\"{x:1196,y:824,t:1528143791658};\\\", \\\"{x:1194,y:823,t:1528143791675};\\\", \\\"{x:1193,y:823,t:1528143792434};\\\", \\\"{x:1193,y:822,t:1528143792442};\\\", \\\"{x:1194,y:820,t:1528143792459};\\\", \\\"{x:1196,y:819,t:1528143792554};\\\", \\\"{x:1197,y:818,t:1528143792578};\\\", \\\"{x:1197,y:817,t:1528143792650};\\\", \\\"{x:1199,y:816,t:1528143792666};\\\", \\\"{x:1199,y:815,t:1528143792676};\\\", \\\"{x:1200,y:814,t:1528143792746};\\\", \\\"{x:1200,y:813,t:1528143793586};\\\", \\\"{x:1199,y:813,t:1528143793593};\\\", \\\"{x:1190,y:808,t:1528143793609};\\\", \\\"{x:1175,y:803,t:1528143793627};\\\", \\\"{x:1155,y:795,t:1528143793644};\\\", \\\"{x:1146,y:789,t:1528143793659};\\\", \\\"{x:1105,y:774,t:1528143793676};\\\", \\\"{x:1037,y:749,t:1528143793694};\\\", \\\"{x:937,y:717,t:1528143793710};\\\", \\\"{x:855,y:684,t:1528143793728};\\\", \\\"{x:782,y:661,t:1528143793743};\\\", \\\"{x:690,y:634,t:1528143793759};\\\", \\\"{x:631,y:618,t:1528143793777};\\\", \\\"{x:551,y:585,t:1528143793794};\\\", \\\"{x:498,y:562,t:1528143793810};\\\", \\\"{x:458,y:548,t:1528143793843};\\\", \\\"{x:443,y:543,t:1528143793860};\\\", \\\"{x:432,y:540,t:1528143793876};\\\", \\\"{x:422,y:536,t:1528143793893};\\\", \\\"{x:417,y:535,t:1528143793910};\\\", \\\"{x:413,y:535,t:1528143793926};\\\", \\\"{x:410,y:534,t:1528143793942};\\\", \\\"{x:407,y:534,t:1528143793960};\\\", \\\"{x:406,y:534,t:1528143794017};\\\", \\\"{x:404,y:534,t:1528143794027};\\\", \\\"{x:401,y:532,t:1528143794043};\\\", \\\"{x:399,y:532,t:1528143794065};\\\", \\\"{x:397,y:532,t:1528143794081};\\\", \\\"{x:396,y:532,t:1528143794121};\\\", \\\"{x:395,y:532,t:1528143794170};\\\", \\\"{x:394,y:531,t:1528143794177};\\\", \\\"{x:393,y:530,t:1528143794193};\\\", \\\"{x:392,y:530,t:1528143794218};\\\", \\\"{x:391,y:530,t:1528143794227};\\\", \\\"{x:390,y:529,t:1528143794244};\\\", \\\"{x:389,y:528,t:1528143794260};\\\", \\\"{x:388,y:528,t:1528143794278};\\\", \\\"{x:387,y:528,t:1528143794297};\\\", \\\"{x:386,y:528,t:1528143794310};\\\", \\\"{x:385,y:528,t:1528143794327};\\\", \\\"{x:383,y:528,t:1528143794343};\\\", \\\"{x:381,y:528,t:1528143794361};\\\", \\\"{x:371,y:528,t:1528143794378};\\\", \\\"{x:367,y:529,t:1528143794394};\\\", \\\"{x:362,y:529,t:1528143794410};\\\", \\\"{x:362,y:530,t:1528143794427};\\\", \\\"{x:359,y:531,t:1528143794444};\\\", \\\"{x:353,y:532,t:1528143794461};\\\", \\\"{x:351,y:532,t:1528143794477};\\\", \\\"{x:349,y:532,t:1528143794494};\\\", \\\"{x:344,y:532,t:1528143794511};\\\", \\\"{x:339,y:532,t:1528143794527};\\\", \\\"{x:333,y:532,t:1528143794545};\\\", \\\"{x:326,y:532,t:1528143794560};\\\", \\\"{x:320,y:532,t:1528143794577};\\\", \\\"{x:309,y:524,t:1528143794595};\\\", \\\"{x:295,y:520,t:1528143794609};\\\", \\\"{x:282,y:510,t:1528143794627};\\\", \\\"{x:265,y:503,t:1528143794644};\\\", \\\"{x:256,y:496,t:1528143794660};\\\", \\\"{x:245,y:492,t:1528143794677};\\\", \\\"{x:236,y:489,t:1528143794694};\\\", \\\"{x:232,y:488,t:1528143794710};\\\", \\\"{x:227,y:486,t:1528143794727};\\\", \\\"{x:224,y:486,t:1528143794744};\\\", \\\"{x:220,y:486,t:1528143794760};\\\", \\\"{x:214,y:486,t:1528143794777};\\\", \\\"{x:208,y:486,t:1528143794794};\\\", \\\"{x:201,y:486,t:1528143794810};\\\", \\\"{x:197,y:486,t:1528143794828};\\\", \\\"{x:194,y:486,t:1528143794844};\\\", \\\"{x:190,y:486,t:1528143794860};\\\", \\\"{x:184,y:486,t:1528143794877};\\\", \\\"{x:183,y:487,t:1528143794895};\\\", \\\"{x:181,y:487,t:1528143794911};\\\", \\\"{x:180,y:488,t:1528143794927};\\\", \\\"{x:179,y:488,t:1528143794976};\\\", \\\"{x:178,y:488,t:1528143794994};\\\", \\\"{x:175,y:489,t:1528143795049};\\\", \\\"{x:174,y:490,t:1528143795062};\\\", \\\"{x:172,y:490,t:1528143795077};\\\", \\\"{x:170,y:490,t:1528143795094};\\\", \\\"{x:169,y:492,t:1528143795111};\\\", \\\"{x:168,y:492,t:1528143795145};\\\", \\\"{x:167,y:492,t:1528143795209};\\\", \\\"{x:166,y:492,t:1528143795306};\\\", \\\"{x:165,y:493,t:1528143795314};\\\", \\\"{x:164,y:500,t:1528143799969};\\\", \\\"{x:171,y:513,t:1528143799981};\\\", \\\"{x:193,y:542,t:1528143799999};\\\", \\\"{x:205,y:556,t:1528143800015};\\\", \\\"{x:225,y:572,t:1528143800031};\\\", \\\"{x:264,y:603,t:1528143800048};\\\", \\\"{x:284,y:626,t:1528143800065};\\\", \\\"{x:364,y:668,t:1528143800082};\\\", \\\"{x:429,y:687,t:1528143800098};\\\", \\\"{x:451,y:696,t:1528143800115};\\\", \\\"{x:460,y:701,t:1528143800131};\\\", \\\"{x:483,y:711,t:1528143800148};\\\", \\\"{x:500,y:718,t:1528143800164};\\\", \\\"{x:513,y:724,t:1528143800182};\\\", \\\"{x:536,y:732,t:1528143800198};\\\", \\\"{x:546,y:735,t:1528143800215};\\\", \\\"{x:554,y:739,t:1528143800232};\\\", \\\"{x:555,y:739,t:1528143800248};\\\", \\\"{x:556,y:739,t:1528143800265};\\\", \\\"{x:558,y:741,t:1528143800370};\\\", \\\"{x:559,y:742,t:1528143800383};\\\", \\\"{x:559,y:743,t:1528143800401};\\\", \\\"{x:559,y:744,t:1528143800415};\\\", \\\"{x:560,y:745,t:1528143800433};\\\", \\\"{x:560,y:746,t:1528143800449};\\\", \\\"{x:561,y:747,t:1528143800498};\\\", \\\"{x:560,y:747,t:1528143800945};\\\", \\\"{x:559,y:746,t:1528143800970};\\\", \\\"{x:558,y:746,t:1528143800993};\\\", \\\"{x:556,y:746,t:1528143801041};\\\", \\\"{x:555,y:745,t:1528143801081};\\\", \\\"{x:554,y:744,t:1528143801097};\\\", \\\"{x:553,y:744,t:1528143801105};\\\", \\\"{x:552,y:744,t:1528143801119};\\\", \\\"{x:551,y:744,t:1528143801137};\\\", \\\"{x:550,y:744,t:1528143801152};\\\", \\\"{x:547,y:744,t:1528143801168};\\\", \\\"{x:542,y:743,t:1528143801185};\\\", \\\"{x:540,y:742,t:1528143801202};\\\", \\\"{x:539,y:741,t:1528143801219};\\\", \\\"{x:537,y:740,t:1528143801241};\\\", \\\"{x:536,y:740,t:1528143801401};\\\", \\\"{x:536,y:740,t:1528143801527};\\\" ] }, { \\\"rt\\\": 39601, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 834279, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -04 PM-Z -Z -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:740,t:1528143804978};\\\", \\\"{x:533,y:740,t:1528143804986};\\\", \\\"{x:531,y:740,t:1528143805003};\\\", \\\"{x:530,y:740,t:1528143805091};\\\", \\\"{x:529,y:740,t:1528143805112};\\\", \\\"{x:528,y:740,t:1528143805120};\\\", \\\"{x:534,y:739,t:1528143806433};\\\", \\\"{x:542,y:739,t:1528143806441};\\\", \\\"{x:557,y:737,t:1528143806454};\\\", \\\"{x:585,y:737,t:1528143806470};\\\", \\\"{x:615,y:738,t:1528143806487};\\\", \\\"{x:676,y:733,t:1528143806504};\\\", \\\"{x:721,y:729,t:1528143806520};\\\", \\\"{x:813,y:726,t:1528143806536};\\\", \\\"{x:869,y:724,t:1528143806554};\\\", \\\"{x:940,y:719,t:1528143806570};\\\", \\\"{x:981,y:711,t:1528143806587};\\\", \\\"{x:994,y:710,t:1528143806603};\\\", \\\"{x:1018,y:702,t:1528143806620};\\\", \\\"{x:1025,y:700,t:1528143806637};\\\", \\\"{x:1027,y:698,t:1528143806653};\\\", \\\"{x:1032,y:693,t:1528143806671};\\\", \\\"{x:1037,y:690,t:1528143806687};\\\", \\\"{x:1041,y:686,t:1528143806704};\\\", \\\"{x:1043,y:685,t:1528143806721};\\\", \\\"{x:1043,y:684,t:1528143806738};\\\", \\\"{x:1045,y:684,t:1528143806754};\\\", \\\"{x:1045,y:683,t:1528143806771};\\\", \\\"{x:1046,y:682,t:1528143806787};\\\", \\\"{x:1049,y:678,t:1528143806804};\\\", \\\"{x:1052,y:676,t:1528143806821};\\\", \\\"{x:1053,y:674,t:1528143806837};\\\", \\\"{x:1065,y:668,t:1528143806854};\\\", \\\"{x:1075,y:664,t:1528143806871};\\\", \\\"{x:1087,y:661,t:1528143806888};\\\", \\\"{x:1106,y:659,t:1528143806905};\\\", \\\"{x:1129,y:657,t:1528143806922};\\\", \\\"{x:1156,y:659,t:1528143806937};\\\", \\\"{x:1184,y:665,t:1528143806954};\\\", \\\"{x:1218,y:675,t:1528143806971};\\\", \\\"{x:1234,y:682,t:1528143806988};\\\", \\\"{x:1251,y:690,t:1528143807004};\\\", \\\"{x:1261,y:697,t:1528143807021};\\\", \\\"{x:1289,y:708,t:1528143807038};\\\", \\\"{x:1313,y:714,t:1528143807054};\\\", \\\"{x:1334,y:721,t:1528143807071};\\\", \\\"{x:1346,y:728,t:1528143807088};\\\", \\\"{x:1358,y:730,t:1528143807104};\\\", \\\"{x:1369,y:734,t:1528143807121};\\\", \\\"{x:1372,y:735,t:1528143807138};\\\", \\\"{x:1373,y:735,t:1528143807210};\\\", \\\"{x:1376,y:735,t:1528143807241};\\\", \\\"{x:1379,y:735,t:1528143807254};\\\", \\\"{x:1383,y:734,t:1528143807271};\\\", \\\"{x:1388,y:730,t:1528143807289};\\\", \\\"{x:1395,y:725,t:1528143807305};\\\", \\\"{x:1400,y:717,t:1528143807322};\\\", \\\"{x:1406,y:709,t:1528143807338};\\\", \\\"{x:1407,y:705,t:1528143807354};\\\", \\\"{x:1408,y:702,t:1528143807371};\\\", \\\"{x:1408,y:701,t:1528143807474};\\\", \\\"{x:1407,y:701,t:1528143807488};\\\", \\\"{x:1400,y:701,t:1528143807505};\\\", \\\"{x:1397,y:701,t:1528143807521};\\\", \\\"{x:1391,y:701,t:1528143807537};\\\", \\\"{x:1379,y:701,t:1528143807555};\\\", \\\"{x:1370,y:703,t:1528143807571};\\\", \\\"{x:1366,y:703,t:1528143807588};\\\", \\\"{x:1357,y:703,t:1528143807605};\\\", \\\"{x:1349,y:704,t:1528143807620};\\\", \\\"{x:1345,y:704,t:1528143807638};\\\", \\\"{x:1342,y:704,t:1528143807655};\\\", \\\"{x:1342,y:703,t:1528143808090};\\\", \\\"{x:1342,y:702,t:1528143808122};\\\", \\\"{x:1342,y:700,t:1528143808138};\\\", \\\"{x:1343,y:698,t:1528143808158};\\\", \\\"{x:1343,y:697,t:1528143808200};\\\", \\\"{x:1344,y:696,t:1528143808208};\\\", \\\"{x:1345,y:695,t:1528143808426};\\\", \\\"{x:1345,y:694,t:1528143808449};\\\", \\\"{x:1345,y:693,t:1528143808458};\\\", \\\"{x:1347,y:692,t:1528143809682};\\\", \\\"{x:1349,y:692,t:1528143809697};\\\", \\\"{x:1350,y:692,t:1528143809707};\\\", \\\"{x:1351,y:692,t:1528143809729};\\\", \\\"{x:1352,y:692,t:1528143809742};\\\", \\\"{x:1353,y:692,t:1528143809757};\\\", \\\"{x:1354,y:692,t:1528143809773};\\\", \\\"{x:1356,y:692,t:1528143809882};\\\", \\\"{x:1358,y:693,t:1528143809890};\\\", \\\"{x:1360,y:694,t:1528143809906};\\\", \\\"{x:1363,y:695,t:1528143809923};\\\", \\\"{x:1366,y:697,t:1528143809941};\\\", \\\"{x:1368,y:698,t:1528143809957};\\\", \\\"{x:1374,y:699,t:1528143809974};\\\", \\\"{x:1381,y:700,t:1528143809990};\\\", \\\"{x:1387,y:702,t:1528143810007};\\\", \\\"{x:1393,y:703,t:1528143810024};\\\", \\\"{x:1403,y:705,t:1528143810041};\\\", \\\"{x:1409,y:705,t:1528143810057};\\\", \\\"{x:1422,y:706,t:1528143810073};\\\", \\\"{x:1433,y:709,t:1528143810091};\\\", \\\"{x:1444,y:709,t:1528143810107};\\\", \\\"{x:1457,y:709,t:1528143810124};\\\", \\\"{x:1467,y:709,t:1528143810140};\\\", \\\"{x:1479,y:710,t:1528143810157};\\\", \\\"{x:1490,y:710,t:1528143810173};\\\", \\\"{x:1498,y:711,t:1528143810191};\\\", \\\"{x:1508,y:711,t:1528143810208};\\\", \\\"{x:1518,y:711,t:1528143810224};\\\", \\\"{x:1521,y:711,t:1528143810240};\\\", \\\"{x:1536,y:711,t:1528143810257};\\\", \\\"{x:1542,y:711,t:1528143810273};\\\", \\\"{x:1545,y:711,t:1528143810291};\\\", \\\"{x:1549,y:711,t:1528143810308};\\\", \\\"{x:1552,y:711,t:1528143810324};\\\", \\\"{x:1555,y:711,t:1528143810340};\\\", \\\"{x:1559,y:711,t:1528143810358};\\\", \\\"{x:1565,y:713,t:1528143810374};\\\", \\\"{x:1571,y:714,t:1528143810390};\\\", \\\"{x:1587,y:714,t:1528143810407};\\\", \\\"{x:1594,y:716,t:1528143810423};\\\", \\\"{x:1603,y:718,t:1528143810441};\\\", \\\"{x:1607,y:719,t:1528143810458};\\\", \\\"{x:1609,y:719,t:1528143810474};\\\", \\\"{x:1612,y:719,t:1528143810491};\\\", \\\"{x:1615,y:721,t:1528143810508};\\\", \\\"{x:1618,y:723,t:1528143810524};\\\", \\\"{x:1621,y:728,t:1528143810540};\\\", \\\"{x:1625,y:737,t:1528143810558};\\\", \\\"{x:1630,y:744,t:1528143810574};\\\", \\\"{x:1639,y:758,t:1528143810590};\\\", \\\"{x:1642,y:773,t:1528143810608};\\\", \\\"{x:1647,y:785,t:1528143810624};\\\", \\\"{x:1651,y:800,t:1528143810640};\\\", \\\"{x:1656,y:831,t:1528143810658};\\\", \\\"{x:1656,y:853,t:1528143810673};\\\", \\\"{x:1658,y:869,t:1528143810690};\\\", \\\"{x:1660,y:884,t:1528143810707};\\\", \\\"{x:1660,y:889,t:1528143810724};\\\", \\\"{x:1662,y:893,t:1528143810740};\\\", \\\"{x:1664,y:897,t:1528143810758};\\\", \\\"{x:1664,y:900,t:1528143810774};\\\", \\\"{x:1664,y:903,t:1528143810791};\\\", \\\"{x:1664,y:906,t:1528143810808};\\\", \\\"{x:1664,y:909,t:1528143810824};\\\", \\\"{x:1664,y:910,t:1528143810840};\\\", \\\"{x:1664,y:915,t:1528143810858};\\\", \\\"{x:1664,y:917,t:1528143810874};\\\", \\\"{x:1664,y:921,t:1528143810891};\\\", \\\"{x:1664,y:923,t:1528143810907};\\\", \\\"{x:1664,y:927,t:1528143810924};\\\", \\\"{x:1664,y:929,t:1528143810945};\\\", \\\"{x:1664,y:931,t:1528143810958};\\\", \\\"{x:1664,y:935,t:1528143810974};\\\", \\\"{x:1664,y:938,t:1528143810991};\\\", \\\"{x:1664,y:941,t:1528143811007};\\\", \\\"{x:1664,y:944,t:1528143811024};\\\", \\\"{x:1660,y:953,t:1528143811041};\\\", \\\"{x:1656,y:960,t:1528143811057};\\\", \\\"{x:1655,y:961,t:1528143811075};\\\", \\\"{x:1651,y:966,t:1528143811092};\\\", \\\"{x:1648,y:970,t:1528143811106};\\\", \\\"{x:1647,y:973,t:1528143811124};\\\", \\\"{x:1645,y:976,t:1528143811141};\\\", \\\"{x:1643,y:976,t:1528143811157};\\\", \\\"{x:1641,y:979,t:1528143811174};\\\", \\\"{x:1640,y:980,t:1528143811193};\\\", \\\"{x:1639,y:980,t:1528143811207};\\\", \\\"{x:1636,y:983,t:1528143811223};\\\", \\\"{x:1634,y:984,t:1528143811240};\\\", \\\"{x:1633,y:984,t:1528143811425};\\\", \\\"{x:1632,y:984,t:1528143811442};\\\", \\\"{x:1629,y:984,t:1528143811458};\\\", \\\"{x:1626,y:982,t:1528143811474};\\\", \\\"{x:1623,y:979,t:1528143811491};\\\", \\\"{x:1620,y:976,t:1528143811508};\\\", \\\"{x:1617,y:972,t:1528143811524};\\\", \\\"{x:1613,y:967,t:1528143811543};\\\", \\\"{x:1612,y:967,t:1528143811561};\\\", \\\"{x:1610,y:965,t:1528143811574};\\\", \\\"{x:1608,y:961,t:1528143811591};\\\", \\\"{x:1605,y:958,t:1528143811609};\\\", \\\"{x:1604,y:957,t:1528143811624};\\\", \\\"{x:1602,y:955,t:1528143811642};\\\", \\\"{x:1601,y:950,t:1528143811658};\\\", \\\"{x:1601,y:945,t:1528143811674};\\\", \\\"{x:1599,y:938,t:1528143811692};\\\", \\\"{x:1598,y:934,t:1528143811708};\\\", \\\"{x:1598,y:929,t:1528143811724};\\\", \\\"{x:1598,y:922,t:1528143811741};\\\", \\\"{x:1598,y:914,t:1528143811759};\\\", \\\"{x:1599,y:905,t:1528143811775};\\\", \\\"{x:1599,y:897,t:1528143811792};\\\", \\\"{x:1599,y:885,t:1528143811809};\\\", \\\"{x:1600,y:876,t:1528143811825};\\\", \\\"{x:1602,y:860,t:1528143811842};\\\", \\\"{x:1604,y:856,t:1528143811859};\\\", \\\"{x:1607,y:847,t:1528143811875};\\\", \\\"{x:1610,y:838,t:1528143811891};\\\", \\\"{x:1612,y:828,t:1528143811909};\\\", \\\"{x:1614,y:821,t:1528143811926};\\\", \\\"{x:1615,y:814,t:1528143811942};\\\", \\\"{x:1616,y:808,t:1528143811959};\\\", \\\"{x:1618,y:802,t:1528143811975};\\\", \\\"{x:1618,y:801,t:1528143811992};\\\", \\\"{x:1618,y:789,t:1528143812008};\\\", \\\"{x:1621,y:776,t:1528143812026};\\\", \\\"{x:1621,y:769,t:1528143812041};\\\", \\\"{x:1621,y:764,t:1528143812059};\\\", \\\"{x:1621,y:759,t:1528143812075};\\\", \\\"{x:1621,y:754,t:1528143812092};\\\", \\\"{x:1621,y:748,t:1528143812108};\\\", \\\"{x:1621,y:741,t:1528143812126};\\\", \\\"{x:1621,y:733,t:1528143812142};\\\", \\\"{x:1621,y:728,t:1528143812158};\\\", \\\"{x:1621,y:725,t:1528143812176};\\\", \\\"{x:1621,y:719,t:1528143812192};\\\", \\\"{x:1621,y:713,t:1528143812208};\\\", \\\"{x:1620,y:708,t:1528143812226};\\\", \\\"{x:1620,y:704,t:1528143812242};\\\", \\\"{x:1620,y:700,t:1528143812259};\\\", \\\"{x:1620,y:697,t:1528143812276};\\\", \\\"{x:1618,y:694,t:1528143812292};\\\", \\\"{x:1618,y:692,t:1528143812309};\\\", \\\"{x:1618,y:691,t:1528143812327};\\\", \\\"{x:1617,y:689,t:1528143812343};\\\", \\\"{x:1617,y:688,t:1528143812358};\\\", \\\"{x:1617,y:687,t:1528143812378};\\\", \\\"{x:1616,y:686,t:1528143813058};\\\", \\\"{x:1612,y:686,t:1528143830842};\\\", \\\"{x:1590,y:693,t:1528143830858};\\\", \\\"{x:1549,y:701,t:1528143830874};\\\", \\\"{x:1457,y:698,t:1528143830890};\\\", \\\"{x:1344,y:685,t:1528143830907};\\\", \\\"{x:1219,y:664,t:1528143830924};\\\", \\\"{x:1048,y:617,t:1528143830940};\\\", \\\"{x:879,y:563,t:1528143830957};\\\", \\\"{x:696,y:508,t:1528143830973};\\\", \\\"{x:508,y:446,t:1528143830990};\\\", \\\"{x:393,y:423,t:1528143831007};\\\", \\\"{x:292,y:399,t:1528143831023};\\\", \\\"{x:249,y:393,t:1528143831040};\\\", \\\"{x:221,y:394,t:1528143831056};\\\", \\\"{x:200,y:400,t:1528143831073};\\\", \\\"{x:193,y:406,t:1528143831089};\\\", \\\"{x:189,y:410,t:1528143831106};\\\", \\\"{x:186,y:418,t:1528143831123};\\\", \\\"{x:181,y:427,t:1528143831140};\\\", \\\"{x:177,y:432,t:1528143831157};\\\", \\\"{x:176,y:436,t:1528143831174};\\\", \\\"{x:174,y:439,t:1528143831190};\\\", \\\"{x:174,y:441,t:1528143831207};\\\", \\\"{x:174,y:444,t:1528143831224};\\\", \\\"{x:174,y:446,t:1528143831240};\\\", \\\"{x:174,y:453,t:1528143831257};\\\", \\\"{x:174,y:454,t:1528143831274};\\\", \\\"{x:174,y:455,t:1528143831290};\\\", \\\"{x:174,y:456,t:1528143831361};\\\", \\\"{x:174,y:458,t:1528143831374};\\\", \\\"{x:174,y:466,t:1528143831390};\\\", \\\"{x:173,y:477,t:1528143831407};\\\", \\\"{x:170,y:499,t:1528143831425};\\\", \\\"{x:167,y:518,t:1528143831442};\\\", \\\"{x:158,y:546,t:1528143831459};\\\", \\\"{x:156,y:563,t:1528143831475};\\\", \\\"{x:156,y:576,t:1528143831491};\\\", \\\"{x:156,y:591,t:1528143831508};\\\", \\\"{x:156,y:599,t:1528143831525};\\\", \\\"{x:156,y:602,t:1528143831541};\\\", \\\"{x:154,y:604,t:1528143831558};\\\", \\\"{x:154,y:606,t:1528143831873};\\\", \\\"{x:155,y:608,t:1528143831891};\\\", \\\"{x:155,y:609,t:1528143831908};\\\", \\\"{x:157,y:610,t:1528143831937};\\\", \\\"{x:161,y:610,t:1528143831945};\\\", \\\"{x:165,y:611,t:1528143831961};\\\", \\\"{x:167,y:612,t:1528143831975};\\\", \\\"{x:172,y:614,t:1528143831992};\\\", \\\"{x:178,y:615,t:1528143832008};\\\", \\\"{x:181,y:617,t:1528143832025};\\\", \\\"{x:182,y:618,t:1528143832065};\\\", \\\"{x:182,y:619,t:1528143832122};\\\", \\\"{x:183,y:619,t:1528143832202};\\\", \\\"{x:184,y:619,t:1528143832209};\\\", \\\"{x:188,y:618,t:1528143832225};\\\", \\\"{x:201,y:609,t:1528143832243};\\\", \\\"{x:208,y:604,t:1528143832257};\\\", \\\"{x:216,y:598,t:1528143832276};\\\", \\\"{x:230,y:594,t:1528143832292};\\\", \\\"{x:244,y:587,t:1528143832308};\\\", \\\"{x:256,y:581,t:1528143832325};\\\", \\\"{x:270,y:575,t:1528143832342};\\\", \\\"{x:281,y:571,t:1528143832359};\\\", \\\"{x:290,y:566,t:1528143832374};\\\", \\\"{x:295,y:564,t:1528143832392};\\\", \\\"{x:298,y:559,t:1528143832409};\\\", \\\"{x:300,y:557,t:1528143832424};\\\", \\\"{x:302,y:557,t:1528143832442};\\\", \\\"{x:304,y:555,t:1528143832461};\\\", \\\"{x:305,y:555,t:1528143832584};\\\", \\\"{x:309,y:555,t:1528143832592};\\\", \\\"{x:319,y:557,t:1528143832609};\\\", \\\"{x:338,y:563,t:1528143832625};\\\", \\\"{x:347,y:565,t:1528143832642};\\\", \\\"{x:361,y:568,t:1528143832658};\\\", \\\"{x:372,y:571,t:1528143832674};\\\", \\\"{x:376,y:572,t:1528143832692};\\\", \\\"{x:389,y:573,t:1528143832708};\\\", \\\"{x:406,y:576,t:1528143832725};\\\", \\\"{x:422,y:576,t:1528143832742};\\\", \\\"{x:433,y:576,t:1528143832759};\\\", \\\"{x:440,y:576,t:1528143832775};\\\", \\\"{x:451,y:575,t:1528143832792};\\\", \\\"{x:454,y:572,t:1528143832808};\\\", \\\"{x:465,y:571,t:1528143832824};\\\", \\\"{x:468,y:570,t:1528143832842};\\\", \\\"{x:478,y:569,t:1528143832858};\\\", \\\"{x:491,y:569,t:1528143832875};\\\", \\\"{x:504,y:567,t:1528143832894};\\\", \\\"{x:516,y:565,t:1528143832908};\\\", \\\"{x:531,y:565,t:1528143832925};\\\", \\\"{x:553,y:565,t:1528143832941};\\\", \\\"{x:568,y:562,t:1528143832959};\\\", \\\"{x:585,y:558,t:1528143832974};\\\", \\\"{x:599,y:555,t:1528143832993};\\\", \\\"{x:605,y:553,t:1528143833009};\\\", \\\"{x:611,y:551,t:1528143833025};\\\", \\\"{x:619,y:549,t:1528143833042};\\\", \\\"{x:627,y:546,t:1528143833059};\\\", \\\"{x:634,y:543,t:1528143833074};\\\", \\\"{x:645,y:538,t:1528143833092};\\\", \\\"{x:657,y:537,t:1528143833109};\\\", \\\"{x:671,y:533,t:1528143833125};\\\", \\\"{x:686,y:533,t:1528143833142};\\\", \\\"{x:703,y:533,t:1528143833159};\\\", \\\"{x:716,y:533,t:1528143833175};\\\", \\\"{x:719,y:533,t:1528143833192};\\\", \\\"{x:720,y:534,t:1528143833209};\\\", \\\"{x:722,y:535,t:1528143833226};\\\", \\\"{x:730,y:539,t:1528143833244};\\\", \\\"{x:739,y:544,t:1528143833258};\\\", \\\"{x:750,y:552,t:1528143833276};\\\", \\\"{x:757,y:558,t:1528143833292};\\\", \\\"{x:760,y:562,t:1528143833309};\\\", \\\"{x:765,y:567,t:1528143833326};\\\", \\\"{x:767,y:577,t:1528143833341};\\\", \\\"{x:768,y:587,t:1528143833358};\\\", \\\"{x:771,y:598,t:1528143833377};\\\", \\\"{x:772,y:604,t:1528143833392};\\\", \\\"{x:772,y:609,t:1528143833409};\\\", \\\"{x:771,y:613,t:1528143833426};\\\", \\\"{x:770,y:618,t:1528143833442};\\\", \\\"{x:765,y:624,t:1528143833459};\\\", \\\"{x:759,y:628,t:1528143833476};\\\", \\\"{x:755,y:630,t:1528143833493};\\\", \\\"{x:753,y:632,t:1528143833510};\\\", \\\"{x:751,y:632,t:1528143833527};\\\", \\\"{x:739,y:633,t:1528143833543};\\\", \\\"{x:733,y:634,t:1528143833559};\\\", \\\"{x:711,y:630,t:1528143833578};\\\", \\\"{x:686,y:628,t:1528143833592};\\\", \\\"{x:672,y:625,t:1528143833608};\\\", \\\"{x:661,y:622,t:1528143833625};\\\", \\\"{x:646,y:619,t:1528143833643};\\\", \\\"{x:636,y:617,t:1528143833659};\\\", \\\"{x:624,y:613,t:1528143833676};\\\", \\\"{x:617,y:611,t:1528143833692};\\\", \\\"{x:611,y:608,t:1528143833709};\\\", \\\"{x:606,y:605,t:1528143833726};\\\", \\\"{x:603,y:604,t:1528143833742};\\\", \\\"{x:602,y:604,t:1528143833759};\\\", \\\"{x:597,y:601,t:1528143833777};\\\", \\\"{x:594,y:599,t:1528143833792};\\\", \\\"{x:591,y:598,t:1528143833809};\\\", \\\"{x:589,y:598,t:1528143833826};\\\", \\\"{x:588,y:597,t:1528143833913};\\\", \\\"{x:588,y:596,t:1528143833926};\\\", \\\"{x:588,y:591,t:1528143833944};\\\", \\\"{x:588,y:589,t:1528143833959};\\\", \\\"{x:587,y:585,t:1528143833976};\\\", \\\"{x:587,y:581,t:1528143833992};\\\", \\\"{x:588,y:574,t:1528143834010};\\\", \\\"{x:588,y:573,t:1528143834026};\\\", \\\"{x:589,y:571,t:1528143834043};\\\", \\\"{x:589,y:570,t:1528143834060};\\\", \\\"{x:591,y:570,t:1528143834265};\\\", \\\"{x:592,y:570,t:1528143834288};\\\", \\\"{x:595,y:570,t:1528143834304};\\\", \\\"{x:596,y:570,t:1528143834313};\\\", \\\"{x:597,y:570,t:1528143834329};\\\", \\\"{x:598,y:570,t:1528143834345};\\\", \\\"{x:599,y:570,t:1528143834377};\\\", \\\"{x:600,y:570,t:1528143834482};\\\", \\\"{x:601,y:570,t:1528143834584};\\\", \\\"{x:601,y:572,t:1528143836433};\\\", \\\"{x:601,y:573,t:1528143836445};\\\", \\\"{x:599,y:576,t:1528143836462};\\\", \\\"{x:594,y:576,t:1528143836477};\\\", \\\"{x:593,y:577,t:1528143836496};\\\", \\\"{x:593,y:579,t:1528143838882};\\\", \\\"{x:593,y:597,t:1528143838899};\\\", \\\"{x:601,y:620,t:1528143838915};\\\", \\\"{x:608,y:633,t:1528143838931};\\\", \\\"{x:619,y:650,t:1528143838947};\\\", \\\"{x:631,y:662,t:1528143838963};\\\", \\\"{x:644,y:672,t:1528143838980};\\\", \\\"{x:650,y:677,t:1528143838998};\\\", \\\"{x:656,y:677,t:1528143839014};\\\", \\\"{x:657,y:678,t:1528143839030};\\\", \\\"{x:663,y:677,t:1528143839047};\\\", \\\"{x:667,y:674,t:1528143839063};\\\", \\\"{x:679,y:668,t:1528143839080};\\\", \\\"{x:685,y:664,t:1528143839096};\\\", \\\"{x:703,y:657,t:1528143839113};\\\", \\\"{x:724,y:648,t:1528143839131};\\\", \\\"{x:745,y:639,t:1528143839147};\\\", \\\"{x:761,y:631,t:1528143839164};\\\", \\\"{x:788,y:625,t:1528143839180};\\\", \\\"{x:828,y:616,t:1528143839198};\\\", \\\"{x:876,y:616,t:1528143839215};\\\", \\\"{x:921,y:616,t:1528143839230};\\\", \\\"{x:962,y:613,t:1528143839248};\\\", \\\"{x:1036,y:617,t:1528143839264};\\\", \\\"{x:1083,y:620,t:1528143839280};\\\", \\\"{x:1141,y:633,t:1528143839297};\\\", \\\"{x:1201,y:644,t:1528143839315};\\\", \\\"{x:1254,y:671,t:1528143839331};\\\", \\\"{x:1303,y:697,t:1528143839347};\\\", \\\"{x:1355,y:714,t:1528143839364};\\\", \\\"{x:1401,y:733,t:1528143839381};\\\", \\\"{x:1426,y:747,t:1528143839398};\\\", \\\"{x:1441,y:760,t:1528143839415};\\\", \\\"{x:1453,y:771,t:1528143839431};\\\", \\\"{x:1462,y:778,t:1528143839447};\\\", \\\"{x:1467,y:782,t:1528143839465};\\\", \\\"{x:1467,y:783,t:1528143839481};\\\", \\\"{x:1467,y:789,t:1528143839498};\\\", \\\"{x:1466,y:796,t:1528143839515};\\\", \\\"{x:1464,y:808,t:1528143839531};\\\", \\\"{x:1463,y:811,t:1528143839548};\\\", \\\"{x:1457,y:820,t:1528143839565};\\\", \\\"{x:1450,y:835,t:1528143839582};\\\", \\\"{x:1445,y:852,t:1528143839598};\\\", \\\"{x:1433,y:871,t:1528143839615};\\\", \\\"{x:1425,y:890,t:1528143839632};\\\", \\\"{x:1412,y:909,t:1528143839649};\\\", \\\"{x:1398,y:941,t:1528143839665};\\\", \\\"{x:1392,y:955,t:1528143839682};\\\", \\\"{x:1384,y:969,t:1528143839698};\\\", \\\"{x:1382,y:980,t:1528143839715};\\\", \\\"{x:1380,y:986,t:1528143839732};\\\", \\\"{x:1378,y:990,t:1528143839748};\\\", \\\"{x:1377,y:993,t:1528143839764};\\\", \\\"{x:1377,y:995,t:1528143839781};\\\", \\\"{x:1376,y:996,t:1528143839798};\\\", \\\"{x:1376,y:997,t:1528143839815};\\\", \\\"{x:1376,y:999,t:1528143839842};\\\", \\\"{x:1375,y:999,t:1528143839849};\\\", \\\"{x:1375,y:1000,t:1528143839882};\\\", \\\"{x:1375,y:1001,t:1528143839899};\\\", \\\"{x:1374,y:1002,t:1528143839914};\\\", \\\"{x:1374,y:1003,t:1528143839932};\\\", \\\"{x:1373,y:1005,t:1528143839948};\\\", \\\"{x:1373,y:1006,t:1528143839965};\\\", \\\"{x:1373,y:1009,t:1528143839982};\\\", \\\"{x:1373,y:1010,t:1528143839999};\\\", \\\"{x:1372,y:1012,t:1528143840015};\\\", \\\"{x:1372,y:1014,t:1528143840031};\\\", \\\"{x:1372,y:1015,t:1528143840049};\\\", \\\"{x:1371,y:1016,t:1528143840130};\\\", \\\"{x:1371,y:1017,t:1528143840137};\\\", \\\"{x:1364,y:1017,t:1528143840538};\\\", \\\"{x:1354,y:1013,t:1528143840549};\\\", \\\"{x:1324,y:1006,t:1528143840566};\\\", \\\"{x:1255,y:975,t:1528143840583};\\\", \\\"{x:1220,y:958,t:1528143840599};\\\", \\\"{x:1129,y:916,t:1528143840616};\\\", \\\"{x:954,y:848,t:1528143840634};\\\", \\\"{x:795,y:785,t:1528143840649};\\\", \\\"{x:625,y:719,t:1528143840665};\\\", \\\"{x:471,y:652,t:1528143840684};\\\", \\\"{x:329,y:609,t:1528143840700};\\\", \\\"{x:278,y:584,t:1528143840714};\\\", \\\"{x:250,y:571,t:1528143840732};\\\", \\\"{x:233,y:566,t:1528143840748};\\\", \\\"{x:225,y:562,t:1528143840765};\\\", \\\"{x:222,y:562,t:1528143840782};\\\", \\\"{x:221,y:562,t:1528143840889};\\\", \\\"{x:221,y:563,t:1528143840899};\\\", \\\"{x:221,y:570,t:1528143840916};\\\", \\\"{x:222,y:579,t:1528143840931};\\\", \\\"{x:227,y:592,t:1528143840949};\\\", \\\"{x:234,y:603,t:1528143840967};\\\", \\\"{x:239,y:614,t:1528143840981};\\\", \\\"{x:243,y:623,t:1528143840998};\\\", \\\"{x:251,y:631,t:1528143841015};\\\", \\\"{x:269,y:643,t:1528143841033};\\\", \\\"{x:288,y:654,t:1528143841048};\\\", \\\"{x:300,y:667,t:1528143841065};\\\", \\\"{x:319,y:681,t:1528143841083};\\\", \\\"{x:326,y:689,t:1528143841098};\\\", \\\"{x:338,y:696,t:1528143841115};\\\", \\\"{x:353,y:702,t:1528143841131};\\\", \\\"{x:363,y:707,t:1528143841148};\\\", \\\"{x:372,y:708,t:1528143841165};\\\", \\\"{x:379,y:708,t:1528143841181};\\\", \\\"{x:381,y:710,t:1528143841199};\\\", \\\"{x:382,y:710,t:1528143841215};\\\", \\\"{x:383,y:710,t:1528143841231};\\\", \\\"{x:386,y:710,t:1528143841248};\\\", \\\"{x:386,y:709,t:1528143841266};\\\", \\\"{x:391,y:709,t:1528143841282};\\\", \\\"{x:398,y:710,t:1528143841298};\\\", \\\"{x:400,y:711,t:1528143841316};\\\", \\\"{x:404,y:712,t:1528143841332};\\\", \\\"{x:406,y:712,t:1528143841348};\\\", \\\"{x:407,y:712,t:1528143841369};\\\", \\\"{x:409,y:714,t:1528143841382};\\\", \\\"{x:412,y:714,t:1528143841399};\\\", \\\"{x:413,y:714,t:1528143841416};\\\", \\\"{x:415,y:715,t:1528143841432};\\\", \\\"{x:420,y:716,t:1528143841449};\\\", \\\"{x:424,y:719,t:1528143841465};\\\", \\\"{x:427,y:721,t:1528143841481};\\\", \\\"{x:434,y:725,t:1528143841499};\\\", \\\"{x:436,y:725,t:1528143841516};\\\", \\\"{x:442,y:729,t:1528143841532};\\\", \\\"{x:448,y:731,t:1528143841550};\\\", \\\"{x:453,y:731,t:1528143841566};\\\", \\\"{x:459,y:733,t:1528143841582};\\\", \\\"{x:462,y:733,t:1528143841599};\\\", \\\"{x:464,y:733,t:1528143841616};\\\", \\\"{x:465,y:733,t:1528143841633};\\\", \\\"{x:466,y:733,t:1528143841656};\\\", \\\"{x:467,y:733,t:1528143841713};\\\", \\\"{x:460,y:732,t:1528143843009};\\\", \\\"{x:446,y:726,t:1528143843017};\\\", \\\"{x:414,y:713,t:1528143843033};\\\", \\\"{x:360,y:690,t:1528143843051};\\\", \\\"{x:257,y:651,t:1528143843067};\\\", \\\"{x:133,y:600,t:1528143843084};\\\", \\\"{x:0,y:543,t:1528143843101};\\\", \\\"{x:0,y:472,t:1528143843117};\\\", \\\"{x:0,y:390,t:1528143843134};\\\", \\\"{x:0,y:307,t:1528143843150};\\\", \\\"{x:0,y:221,t:1528143843167};\\\", \\\"{x:0,y:143,t:1528143843184};\\\", \\\"{x:0,y:18,t:1528143843201};\\\", \\\"{x:0,y:16,t:1528143843218};\\\", \\\"{x:1,y:16,t:1528143843448};\\\", \\\"{x:3,y:16,t:1528143843456};\\\", \\\"{x:4,y:16,t:1528143843472};\\\", \\\"{x:6,y:16,t:1528143843483};\\\", \\\"{x:7,y:16,t:1528143843500};\\\", \\\"{x:10,y:16,t:1528143843518};\\\", \\\"{x:14,y:16,t:1528143843533};\\\" ] }, { \\\"rt\\\": 11784, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 847333, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:46,y:16,t:1528143843645};\\\", \\\"{x:49,y:16,t:1528143843652};\\\", \\\"{x:50,y:16,t:1528143843671};\\\", \\\"{x:52,y:16,t:1528143843684};\\\", \\\"{x:53,y:16,t:1528143843700};\\\", \\\"{x:54,y:16,t:1528143843720};\\\", \\\"{x:56,y:16,t:1528143843734};\\\", \\\"{x:77,y:80,t:1528143844062};\\\", \\\"{x:80,y:91,t:1528143844070};\\\", \\\"{x:88,y:111,t:1528143844084};\\\", \\\"{x:105,y:131,t:1528143844101};\\\", \\\"{x:123,y:148,t:1528143844117};\\\", \\\"{x:143,y:162,t:1528143844134};\\\", \\\"{x:157,y:172,t:1528143844152};\\\", \\\"{x:169,y:178,t:1528143844168};\\\", \\\"{x:182,y:189,t:1528143844184};\\\", \\\"{x:198,y:199,t:1528143844201};\\\", \\\"{x:209,y:204,t:1528143844218};\\\", \\\"{x:218,y:211,t:1528143844234};\\\", \\\"{x:230,y:218,t:1528143844251};\\\", \\\"{x:232,y:218,t:1528143844267};\\\", \\\"{x:233,y:223,t:1528143844285};\\\", \\\"{x:236,y:224,t:1528143844301};\\\", \\\"{x:239,y:226,t:1528143844317};\\\", \\\"{x:246,y:230,t:1528143844334};\\\", \\\"{x:253,y:232,t:1528143844352};\\\", \\\"{x:257,y:235,t:1528143844367};\\\", \\\"{x:265,y:242,t:1528143844385};\\\", \\\"{x:274,y:247,t:1528143844402};\\\", \\\"{x:284,y:252,t:1528143844418};\\\", \\\"{x:299,y:261,t:1528143844435};\\\", \\\"{x:314,y:270,t:1528143844452};\\\", \\\"{x:331,y:278,t:1528143844468};\\\", \\\"{x:344,y:284,t:1528143844485};\\\", \\\"{x:353,y:288,t:1528143844502};\\\", \\\"{x:370,y:292,t:1528143844519};\\\", \\\"{x:384,y:297,t:1528143844535};\\\", \\\"{x:395,y:301,t:1528143844552};\\\", \\\"{x:413,y:308,t:1528143844569};\\\", \\\"{x:417,y:312,t:1528143844585};\\\", \\\"{x:429,y:317,t:1528143844602};\\\", \\\"{x:439,y:322,t:1528143844618};\\\", \\\"{x:445,y:325,t:1528143844635};\\\", \\\"{x:454,y:328,t:1528143844652};\\\", \\\"{x:463,y:332,t:1528143844669};\\\", \\\"{x:469,y:335,t:1528143844685};\\\", \\\"{x:478,y:339,t:1528143844702};\\\", \\\"{x:486,y:344,t:1528143844719};\\\", \\\"{x:494,y:350,t:1528143844735};\\\", \\\"{x:502,y:353,t:1528143844752};\\\", \\\"{x:526,y:363,t:1528143844769};\\\", \\\"{x:540,y:369,t:1528143844785};\\\", \\\"{x:551,y:374,t:1528143844802};\\\", \\\"{x:566,y:382,t:1528143844819};\\\", \\\"{x:582,y:392,t:1528143844835};\\\", \\\"{x:597,y:400,t:1528143844852};\\\", \\\"{x:613,y:409,t:1528143844869};\\\", \\\"{x:634,y:416,t:1528143844886};\\\", \\\"{x:636,y:420,t:1528143844902};\\\", \\\"{x:650,y:429,t:1528143844919};\\\", \\\"{x:662,y:433,t:1528143844936};\\\", \\\"{x:672,y:437,t:1528143844951};\\\", \\\"{x:677,y:441,t:1528143844969};\\\", \\\"{x:682,y:443,t:1528143844985};\\\", \\\"{x:685,y:447,t:1528143845002};\\\", \\\"{x:689,y:450,t:1528143845019};\\\", \\\"{x:693,y:452,t:1528143845036};\\\", \\\"{x:693,y:453,t:1528143845052};\\\", \\\"{x:698,y:458,t:1528143845069};\\\", \\\"{x:703,y:461,t:1528143845086};\\\", \\\"{x:710,y:467,t:1528143845102};\\\", \\\"{x:715,y:471,t:1528143845119};\\\", \\\"{x:715,y:472,t:1528143845137};\\\", \\\"{x:716,y:473,t:1528143845152};\\\", \\\"{x:716,y:474,t:1528143845530};\\\", \\\"{x:717,y:474,t:1528143845545};\\\", \\\"{x:718,y:475,t:1528143845778};\\\", \\\"{x:730,y:483,t:1528143846593};\\\", \\\"{x:739,y:492,t:1528143846605};\\\", \\\"{x:780,y:517,t:1528143846620};\\\", \\\"{x:875,y:563,t:1528143846637};\\\", \\\"{x:929,y:581,t:1528143846654};\\\", \\\"{x:1057,y:628,t:1528143846670};\\\", \\\"{x:1207,y:676,t:1528143846687};\\\", \\\"{x:1365,y:751,t:1528143846703};\\\", \\\"{x:1517,y:797,t:1528143846720};\\\", \\\"{x:1717,y:862,t:1528143846736};\\\", \\\"{x:1811,y:889,t:1528143846754};\\\", \\\"{x:1857,y:904,t:1528143846771};\\\", \\\"{x:1875,y:915,t:1528143846787};\\\", \\\"{x:1878,y:920,t:1528143846803};\\\", \\\"{x:1884,y:925,t:1528143846821};\\\", \\\"{x:1884,y:927,t:1528143846857};\\\", \\\"{x:1883,y:929,t:1528143846871};\\\", \\\"{x:1882,y:929,t:1528143846897};\\\", \\\"{x:1880,y:931,t:1528143846906};\\\", \\\"{x:1879,y:931,t:1528143846921};\\\", \\\"{x:1876,y:932,t:1528143846938};\\\", \\\"{x:1868,y:936,t:1528143846954};\\\", \\\"{x:1860,y:937,t:1528143846972};\\\", \\\"{x:1842,y:937,t:1528143846988};\\\", \\\"{x:1821,y:937,t:1528143847004};\\\", \\\"{x:1802,y:937,t:1528143847021};\\\", \\\"{x:1787,y:937,t:1528143847038};\\\", \\\"{x:1763,y:937,t:1528143847055};\\\", \\\"{x:1752,y:937,t:1528143847071};\\\", \\\"{x:1741,y:934,t:1528143847089};\\\", \\\"{x:1716,y:930,t:1528143847106};\\\", \\\"{x:1707,y:931,t:1528143847121};\\\", \\\"{x:1703,y:932,t:1528143847139};\\\", \\\"{x:1699,y:934,t:1528143847155};\\\", \\\"{x:1697,y:934,t:1528143847172};\\\", \\\"{x:1695,y:934,t:1528143847189};\\\", \\\"{x:1693,y:935,t:1528143847207};\\\", \\\"{x:1691,y:935,t:1528143847225};\\\", \\\"{x:1690,y:936,t:1528143847241};\\\", \\\"{x:1687,y:938,t:1528143847256};\\\", \\\"{x:1681,y:939,t:1528143847272};\\\", \\\"{x:1677,y:940,t:1528143847289};\\\", \\\"{x:1668,y:942,t:1528143847305};\\\", \\\"{x:1652,y:945,t:1528143847322};\\\", \\\"{x:1633,y:948,t:1528143847340};\\\", \\\"{x:1615,y:949,t:1528143847356};\\\", \\\"{x:1590,y:949,t:1528143847373};\\\", \\\"{x:1577,y:949,t:1528143847390};\\\", \\\"{x:1554,y:949,t:1528143847406};\\\", \\\"{x:1546,y:949,t:1528143847422};\\\", \\\"{x:1544,y:949,t:1528143847440};\\\", \\\"{x:1543,y:949,t:1528143847457};\\\", \\\"{x:1540,y:949,t:1528143847481};\\\", \\\"{x:1538,y:949,t:1528143847489};\\\", \\\"{x:1529,y:949,t:1528143847507};\\\", \\\"{x:1522,y:949,t:1528143847522};\\\", \\\"{x:1517,y:949,t:1528143847539};\\\", \\\"{x:1513,y:949,t:1528143847556};\\\", \\\"{x:1503,y:949,t:1528143847574};\\\", \\\"{x:1493,y:949,t:1528143847589};\\\", \\\"{x:1481,y:948,t:1528143847606};\\\", \\\"{x:1467,y:948,t:1528143847623};\\\", \\\"{x:1453,y:948,t:1528143847640};\\\", \\\"{x:1444,y:948,t:1528143847656};\\\", \\\"{x:1435,y:948,t:1528143847674};\\\", \\\"{x:1430,y:948,t:1528143847690};\\\", \\\"{x:1417,y:947,t:1528143847706};\\\", \\\"{x:1405,y:947,t:1528143847723};\\\", \\\"{x:1404,y:947,t:1528143847740};\\\", \\\"{x:1399,y:947,t:1528143847757};\\\", \\\"{x:1395,y:947,t:1528143847773};\\\", \\\"{x:1393,y:947,t:1528143847790};\\\", \\\"{x:1391,y:947,t:1528143847807};\\\", \\\"{x:1385,y:947,t:1528143847823};\\\", \\\"{x:1380,y:947,t:1528143847841};\\\", \\\"{x:1379,y:947,t:1528143847857};\\\", \\\"{x:1377,y:947,t:1528143847889};\\\", \\\"{x:1376,y:947,t:1528143847962};\\\", \\\"{x:1374,y:947,t:1528143848049};\\\", \\\"{x:1373,y:947,t:1528143848082};\\\", \\\"{x:1372,y:947,t:1528143848091};\\\", \\\"{x:1371,y:947,t:1528143848107};\\\", \\\"{x:1370,y:947,t:1528143848162};\\\", \\\"{x:1369,y:947,t:1528143848178};\\\", \\\"{x:1367,y:947,t:1528143848191};\\\", \\\"{x:1366,y:947,t:1528143848209};\\\", \\\"{x:1364,y:947,t:1528143848225};\\\", \\\"{x:1363,y:947,t:1528143848241};\\\", \\\"{x:1362,y:947,t:1528143848258};\\\", \\\"{x:1361,y:947,t:1528143848275};\\\", \\\"{x:1360,y:947,t:1528143848305};\\\", \\\"{x:1359,y:947,t:1528143848393};\\\", \\\"{x:1358,y:947,t:1528143848474};\\\", \\\"{x:1356,y:947,t:1528143848557};\\\", \\\"{x:1355,y:947,t:1528143848581};\\\", \\\"{x:1354,y:947,t:1528143848597};\\\", \\\"{x:1353,y:944,t:1528143848613};\\\", \\\"{x:1351,y:942,t:1528143848629};\\\", \\\"{x:1351,y:939,t:1528143848646};\\\", \\\"{x:1350,y:934,t:1528143848663};\\\", \\\"{x:1350,y:933,t:1528143848685};\\\", \\\"{x:1350,y:932,t:1528143848696};\\\", \\\"{x:1349,y:930,t:1528143848713};\\\", \\\"{x:1349,y:929,t:1528143848730};\\\", \\\"{x:1349,y:927,t:1528143848746};\\\", \\\"{x:1349,y:924,t:1528143848763};\\\", \\\"{x:1349,y:921,t:1528143848780};\\\", \\\"{x:1351,y:917,t:1528143848797};\\\", \\\"{x:1351,y:915,t:1528143848813};\\\", \\\"{x:1351,y:914,t:1528143848870};\\\", \\\"{x:1352,y:912,t:1528143848982};\\\", \\\"{x:1352,y:911,t:1528143848997};\\\", \\\"{x:1353,y:908,t:1528143849013};\\\", \\\"{x:1353,y:904,t:1528143849029};\\\", \\\"{x:1353,y:902,t:1528143849046};\\\", \\\"{x:1353,y:897,t:1528143849064};\\\", \\\"{x:1353,y:884,t:1528143849081};\\\", \\\"{x:1355,y:871,t:1528143849096};\\\", \\\"{x:1355,y:859,t:1528143849113};\\\", \\\"{x:1356,y:845,t:1528143849130};\\\", \\\"{x:1356,y:833,t:1528143849147};\\\", \\\"{x:1356,y:817,t:1528143849164};\\\", \\\"{x:1356,y:802,t:1528143849180};\\\", \\\"{x:1357,y:794,t:1528143849198};\\\", \\\"{x:1357,y:785,t:1528143849214};\\\", \\\"{x:1357,y:780,t:1528143849231};\\\", \\\"{x:1357,y:774,t:1528143849247};\\\", \\\"{x:1357,y:770,t:1528143849263};\\\", \\\"{x:1357,y:767,t:1528143849280};\\\", \\\"{x:1357,y:762,t:1528143849298};\\\", \\\"{x:1358,y:758,t:1528143849315};\\\", \\\"{x:1358,y:754,t:1528143849331};\\\", \\\"{x:1358,y:748,t:1528143849349};\\\", \\\"{x:1358,y:743,t:1528143849365};\\\", \\\"{x:1358,y:741,t:1528143849397};\\\", \\\"{x:1358,y:736,t:1528143849415};\\\", \\\"{x:1360,y:730,t:1528143849431};\\\", \\\"{x:1360,y:725,t:1528143849448};\\\", \\\"{x:1361,y:721,t:1528143849464};\\\", \\\"{x:1361,y:717,t:1528143849481};\\\", \\\"{x:1363,y:712,t:1528143849498};\\\", \\\"{x:1364,y:700,t:1528143849514};\\\", \\\"{x:1365,y:695,t:1528143849531};\\\", \\\"{x:1365,y:686,t:1528143849548};\\\", \\\"{x:1366,y:681,t:1528143849565};\\\", \\\"{x:1366,y:675,t:1528143849582};\\\", \\\"{x:1366,y:673,t:1528143849598};\\\", \\\"{x:1366,y:670,t:1528143849615};\\\", \\\"{x:1366,y:668,t:1528143849631};\\\", \\\"{x:1366,y:665,t:1528143849649};\\\", \\\"{x:1364,y:660,t:1528143849666};\\\", \\\"{x:1359,y:654,t:1528143849682};\\\", \\\"{x:1354,y:647,t:1528143849699};\\\", \\\"{x:1345,y:638,t:1528143849716};\\\", \\\"{x:1332,y:626,t:1528143849732};\\\", \\\"{x:1312,y:604,t:1528143849749};\\\", \\\"{x:1286,y:585,t:1528143849765};\\\", \\\"{x:1258,y:566,t:1528143849782};\\\", \\\"{x:1216,y:548,t:1528143849798};\\\", \\\"{x:1153,y:526,t:1528143849816};\\\", \\\"{x:1100,y:510,t:1528143849833};\\\", \\\"{x:1057,y:508,t:1528143849848};\\\", \\\"{x:1046,y:508,t:1528143849866};\\\", \\\"{x:1024,y:510,t:1528143849883};\\\", \\\"{x:1012,y:512,t:1528143849899};\\\", \\\"{x:1003,y:516,t:1528143849916};\\\", \\\"{x:982,y:525,t:1528143849933};\\\", \\\"{x:973,y:527,t:1528143849950};\\\", \\\"{x:964,y:532,t:1528143849966};\\\", \\\"{x:956,y:534,t:1528143849983};\\\", \\\"{x:954,y:535,t:1528143850000};\\\", \\\"{x:948,y:537,t:1528143850017};\\\", \\\"{x:943,y:539,t:1528143850033};\\\", \\\"{x:940,y:539,t:1528143850042};\\\", \\\"{x:932,y:539,t:1528143850059};\\\", \\\"{x:928,y:540,t:1528143850076};\\\", \\\"{x:924,y:541,t:1528143850092};\\\", \\\"{x:921,y:542,t:1528143850109};\\\", \\\"{x:919,y:542,t:1528143850126};\\\", \\\"{x:914,y:543,t:1528143850141};\\\", \\\"{x:903,y:543,t:1528143850159};\\\", \\\"{x:890,y:545,t:1528143850176};\\\", \\\"{x:870,y:545,t:1528143850191};\\\", \\\"{x:853,y:546,t:1528143850210};\\\", \\\"{x:841,y:546,t:1528143850225};\\\", \\\"{x:825,y:546,t:1528143850241};\\\", \\\"{x:805,y:546,t:1528143850260};\\\", \\\"{x:791,y:545,t:1528143850277};\\\", \\\"{x:781,y:545,t:1528143850293};\\\", \\\"{x:773,y:545,t:1528143850310};\\\", \\\"{x:765,y:546,t:1528143850327};\\\", \\\"{x:760,y:547,t:1528143850343};\\\", \\\"{x:757,y:548,t:1528143850360};\\\", \\\"{x:756,y:548,t:1528143850377};\\\", \\\"{x:755,y:549,t:1528143850394};\\\", \\\"{x:753,y:549,t:1528143850411};\\\", \\\"{x:750,y:550,t:1528143850426};\\\", \\\"{x:749,y:551,t:1528143850445};\\\", \\\"{x:744,y:552,t:1528143850460};\\\", \\\"{x:730,y:554,t:1528143850477};\\\", \\\"{x:722,y:555,t:1528143850496};\\\", \\\"{x:719,y:557,t:1528143850511};\\\", \\\"{x:717,y:557,t:1528143850526};\\\", \\\"{x:703,y:557,t:1528143850543};\\\", \\\"{x:692,y:557,t:1528143850560};\\\", \\\"{x:670,y:554,t:1528143850577};\\\", \\\"{x:654,y:551,t:1528143850593};\\\", \\\"{x:644,y:542,t:1528143850610};\\\", \\\"{x:637,y:539,t:1528143850627};\\\", \\\"{x:614,y:533,t:1528143850644};\\\", \\\"{x:590,y:524,t:1528143850660};\\\", \\\"{x:572,y:520,t:1528143850676};\\\", \\\"{x:561,y:515,t:1528143850694};\\\", \\\"{x:558,y:514,t:1528143850710};\\\", \\\"{x:557,y:514,t:1528143850726};\\\", \\\"{x:556,y:514,t:1528143850901};\\\", \\\"{x:555,y:514,t:1528143850924};\\\", \\\"{x:550,y:519,t:1528143850934};\\\", \\\"{x:547,y:520,t:1528143850944};\\\", \\\"{x:535,y:526,t:1528143850961};\\\", \\\"{x:515,y:536,t:1528143850978};\\\", \\\"{x:506,y:541,t:1528143850993};\\\", \\\"{x:496,y:547,t:1528143851011};\\\", \\\"{x:480,y:551,t:1528143851027};\\\", \\\"{x:475,y:552,t:1528143851043};\\\", \\\"{x:455,y:557,t:1528143851060};\\\", \\\"{x:448,y:560,t:1528143851078};\\\", \\\"{x:441,y:561,t:1528143851093};\\\", \\\"{x:433,y:561,t:1528143851111};\\\", \\\"{x:428,y:561,t:1528143851127};\\\", \\\"{x:422,y:561,t:1528143851144};\\\", \\\"{x:415,y:561,t:1528143851161};\\\", \\\"{x:406,y:561,t:1528143851178};\\\", \\\"{x:403,y:561,t:1528143851194};\\\", \\\"{x:396,y:561,t:1528143851211};\\\", \\\"{x:380,y:559,t:1528143851228};\\\", \\\"{x:369,y:555,t:1528143851248};\\\", \\\"{x:361,y:554,t:1528143851260};\\\", \\\"{x:357,y:552,t:1528143851277};\\\", \\\"{x:349,y:551,t:1528143851295};\\\", \\\"{x:339,y:550,t:1528143851311};\\\", \\\"{x:328,y:549,t:1528143851327};\\\", \\\"{x:318,y:546,t:1528143851344};\\\", \\\"{x:308,y:545,t:1528143851361};\\\", \\\"{x:303,y:545,t:1528143851377};\\\", \\\"{x:296,y:543,t:1528143851394};\\\", \\\"{x:287,y:542,t:1528143851410};\\\", \\\"{x:280,y:541,t:1528143851427};\\\", \\\"{x:274,y:541,t:1528143851444};\\\", \\\"{x:267,y:539,t:1528143851462};\\\", \\\"{x:261,y:539,t:1528143851477};\\\", \\\"{x:254,y:538,t:1528143851494};\\\", \\\"{x:252,y:538,t:1528143851510};\\\", \\\"{x:245,y:537,t:1528143851527};\\\", \\\"{x:243,y:537,t:1528143851547};\\\", \\\"{x:241,y:537,t:1528143851560};\\\", \\\"{x:237,y:537,t:1528143851577};\\\", \\\"{x:233,y:537,t:1528143851594};\\\", \\\"{x:231,y:537,t:1528143851610};\\\", \\\"{x:228,y:537,t:1528143851627};\\\", \\\"{x:220,y:538,t:1528143851644};\\\", \\\"{x:217,y:538,t:1528143851661};\\\", \\\"{x:213,y:538,t:1528143851677};\\\", \\\"{x:210,y:538,t:1528143851695};\\\", \\\"{x:208,y:538,t:1528143851711};\\\", \\\"{x:205,y:538,t:1528143851727};\\\", \\\"{x:201,y:538,t:1528143851745};\\\", \\\"{x:195,y:538,t:1528143851761};\\\", \\\"{x:192,y:538,t:1528143851778};\\\", \\\"{x:187,y:538,t:1528143851796};\\\", \\\"{x:181,y:538,t:1528143851811};\\\", \\\"{x:173,y:538,t:1528143851827};\\\", \\\"{x:164,y:538,t:1528143851844};\\\", \\\"{x:162,y:537,t:1528143851861};\\\", \\\"{x:160,y:537,t:1528143851878};\\\", \\\"{x:158,y:537,t:1528143851895};\\\", \\\"{x:157,y:536,t:1528143851965};\\\", \\\"{x:157,y:535,t:1528143852101};\\\", \\\"{x:157,y:532,t:1528143852549};\\\", \\\"{x:168,y:526,t:1528143852563};\\\", \\\"{x:195,y:510,t:1528143852579};\\\", \\\"{x:229,y:498,t:1528143852594};\\\", \\\"{x:263,y:494,t:1528143852612};\\\", \\\"{x:327,y:484,t:1528143852628};\\\", \\\"{x:383,y:478,t:1528143852646};\\\", \\\"{x:465,y:472,t:1528143852661};\\\", \\\"{x:524,y:469,t:1528143852679};\\\", \\\"{x:560,y:468,t:1528143852694};\\\", \\\"{x:635,y:468,t:1528143852711};\\\", \\\"{x:657,y:470,t:1528143852729};\\\", \\\"{x:675,y:470,t:1528143852745};\\\", \\\"{x:697,y:469,t:1528143852762};\\\", \\\"{x:711,y:469,t:1528143852778};\\\", \\\"{x:721,y:469,t:1528143852795};\\\", \\\"{x:735,y:469,t:1528143852812};\\\", \\\"{x:747,y:469,t:1528143852828};\\\", \\\"{x:748,y:469,t:1528143852853};\\\", \\\"{x:750,y:469,t:1528143852862};\\\", \\\"{x:752,y:469,t:1528143852879};\\\", \\\"{x:764,y:466,t:1528143852895};\\\", \\\"{x:771,y:465,t:1528143852912};\\\", \\\"{x:780,y:464,t:1528143852929};\\\", \\\"{x:791,y:464,t:1528143852945};\\\", \\\"{x:803,y:463,t:1528143852962};\\\", \\\"{x:817,y:463,t:1528143852979};\\\", \\\"{x:827,y:462,t:1528143852995};\\\", \\\"{x:830,y:462,t:1528143853012};\\\", \\\"{x:852,y:463,t:1528143853028};\\\", \\\"{x:866,y:463,t:1528143853045};\\\", \\\"{x:867,y:464,t:1528143853062};\\\", \\\"{x:872,y:465,t:1528143853079};\\\", \\\"{x:875,y:469,t:1528143853095};\\\", \\\"{x:880,y:470,t:1528143853112};\\\", \\\"{x:882,y:472,t:1528143853129};\\\", \\\"{x:885,y:474,t:1528143853145};\\\", \\\"{x:887,y:477,t:1528143853162};\\\", \\\"{x:887,y:482,t:1528143853179};\\\", \\\"{x:887,y:487,t:1528143853196};\\\", \\\"{x:887,y:491,t:1528143853212};\\\", \\\"{x:887,y:497,t:1528143853229};\\\", \\\"{x:887,y:500,t:1528143853246};\\\", \\\"{x:888,y:500,t:1528143853268};\\\", \\\"{x:888,y:501,t:1528143853284};\\\", \\\"{x:888,y:503,t:1528143853317};\\\", \\\"{x:888,y:504,t:1528143853332};\\\", \\\"{x:887,y:505,t:1528143853349};\\\", \\\"{x:886,y:505,t:1528143853363};\\\", \\\"{x:885,y:506,t:1528143853388};\\\", \\\"{x:884,y:506,t:1528143853453};\\\", \\\"{x:882,y:506,t:1528143853463};\\\", \\\"{x:877,y:505,t:1528143853480};\\\", \\\"{x:872,y:503,t:1528143853496};\\\", \\\"{x:872,y:502,t:1528143853513};\\\", \\\"{x:869,y:501,t:1528143853530};\\\", \\\"{x:867,y:500,t:1528143853547};\\\", \\\"{x:863,y:500,t:1528143853563};\\\", \\\"{x:859,y:500,t:1528143853579};\\\", \\\"{x:858,y:500,t:1528143853596};\\\", \\\"{x:853,y:500,t:1528143853613};\\\", \\\"{x:852,y:500,t:1528143853636};\\\", \\\"{x:850,y:500,t:1528143853645};\\\", \\\"{x:849,y:500,t:1528143854173};\\\", \\\"{x:842,y:500,t:1528143854190};\\\", \\\"{x:840,y:500,t:1528143854196};\\\", \\\"{x:834,y:505,t:1528143854212};\\\", \\\"{x:825,y:511,t:1528143854230};\\\", \\\"{x:818,y:515,t:1528143854247};\\\", \\\"{x:807,y:523,t:1528143854265};\\\", \\\"{x:805,y:525,t:1528143854281};\\\", \\\"{x:799,y:531,t:1528143854297};\\\", \\\"{x:783,y:537,t:1528143854314};\\\", \\\"{x:766,y:546,t:1528143854329};\\\", \\\"{x:754,y:553,t:1528143854347};\\\", \\\"{x:745,y:558,t:1528143854364};\\\", \\\"{x:740,y:561,t:1528143854380};\\\", \\\"{x:731,y:567,t:1528143854397};\\\", \\\"{x:724,y:571,t:1528143854414};\\\", \\\"{x:721,y:573,t:1528143854431};\\\", \\\"{x:714,y:577,t:1528143854446};\\\", \\\"{x:709,y:583,t:1528143854463};\\\", \\\"{x:701,y:596,t:1528143854481};\\\", \\\"{x:693,y:603,t:1528143854498};\\\", \\\"{x:685,y:610,t:1528143854514};\\\", \\\"{x:677,y:617,t:1528143854529};\\\", \\\"{x:666,y:626,t:1528143854546};\\\", \\\"{x:655,y:633,t:1528143854564};\\\", \\\"{x:644,y:641,t:1528143854580};\\\", \\\"{x:628,y:656,t:1528143854596};\\\", \\\"{x:612,y:664,t:1528143854613};\\\", \\\"{x:592,y:679,t:1528143854631};\\\", \\\"{x:571,y:687,t:1528143854647};\\\", \\\"{x:554,y:692,t:1528143854663};\\\", \\\"{x:543,y:692,t:1528143854681};\\\", \\\"{x:528,y:695,t:1528143854697};\\\", \\\"{x:509,y:703,t:1528143854714};\\\", \\\"{x:492,y:707,t:1528143854731};\\\", \\\"{x:486,y:710,t:1528143854748};\\\", \\\"{x:482,y:711,t:1528143854764};\\\", \\\"{x:477,y:712,t:1528143854781};\\\", \\\"{x:477,y:713,t:1528143854926};\\\", \\\"{x:476,y:714,t:1528143854948};\\\", \\\"{x:475,y:719,t:1528143854965};\\\", \\\"{x:474,y:724,t:1528143854984};\\\", \\\"{x:474,y:728,t:1528143854999};\\\", \\\"{x:474,y:731,t:1528143855020};\\\", \\\"{x:474,y:732,t:1528143855030};\\\", \\\"{x:473,y:735,t:1528143855047};\\\", \\\"{x:473,y:736,t:1528143855064};\\\", \\\"{x:473,y:738,t:1528143855079};\\\", \\\"{x:472,y:736,t:1528143855725};\\\", \\\"{x:472,y:734,t:1528143855732};\\\", \\\"{x:472,y:730,t:1528143855748};\\\", \\\"{x:472,y:713,t:1528143855764};\\\", \\\"{x:472,y:704,t:1528143855781};\\\", \\\"{x:472,y:697,t:1528143855798};\\\", \\\"{x:472,y:693,t:1528143855815};\\\", \\\"{x:472,y:690,t:1528143855831};\\\", \\\"{x:472,y:689,t:1528143855941};\\\", \\\"{x:472,y:688,t:1528143855957};\\\", \\\"{x:473,y:687,t:1528143855965};\\\", \\\"{x:475,y:685,t:1528143855981};\\\", \\\"{x:476,y:682,t:1528143855998};\\\", \\\"{x:478,y:680,t:1528143856020};\\\", \\\"{x:479,y:679,t:1528143856036};\\\", \\\"{x:480,y:677,t:1528143856052};\\\", \\\"{x:481,y:676,t:1528143856065};\\\", \\\"{x:481,y:673,t:1528143856081};\\\", \\\"{x:482,y:669,t:1528143856097};\\\", \\\"{x:485,y:662,t:1528143856115};\\\", \\\"{x:486,y:656,t:1528143856132};\\\", \\\"{x:487,y:649,t:1528143856148};\\\", \\\"{x:493,y:635,t:1528143856165};\\\", \\\"{x:496,y:627,t:1528143856182};\\\", \\\"{x:500,y:617,t:1528143856198};\\\", \\\"{x:501,y:613,t:1528143856215};\\\", \\\"{x:503,y:608,t:1528143856232};\\\", \\\"{x:504,y:599,t:1528143856248};\\\", \\\"{x:507,y:591,t:1528143856265};\\\", \\\"{x:508,y:587,t:1528143856282};\\\", \\\"{x:508,y:581,t:1528143856298};\\\", \\\"{x:512,y:575,t:1528143856315};\\\", \\\"{x:514,y:571,t:1528143856332};\\\", \\\"{x:516,y:569,t:1528143856348};\\\", \\\"{x:518,y:568,t:1528143856365};\\\", \\\"{x:518,y:567,t:1528143856413};\\\", \\\"{x:519,y:566,t:1528143856420};\\\", \\\"{x:520,y:565,t:1528143856437};\\\", \\\"{x:522,y:564,t:1528143856458};\\\", \\\"{x:522,y:562,t:1528143856465};\\\", \\\"{x:526,y:557,t:1528143856482};\\\", \\\"{x:526,y:556,t:1528143856497};\\\", \\\"{x:529,y:554,t:1528143856514};\\\", \\\"{x:531,y:551,t:1528143856531};\\\", \\\"{x:533,y:550,t:1528143856548};\\\" ] }, { \\\"rt\\\": 15048, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 863622, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:536,y:548,t:1528143856663};\\\", \\\"{x:537,y:548,t:1528143856688};\\\", \\\"{x:538,y:547,t:1528143856699};\\\", \\\"{x:539,y:546,t:1528143856716};\\\", \\\"{x:540,y:545,t:1528143856796};\\\", \\\"{x:541,y:544,t:1528143856876};\\\", \\\"{x:542,y:543,t:1528143856884};\\\", \\\"{x:544,y:542,t:1528143856908};\\\", \\\"{x:545,y:541,t:1528143856933};\\\", \\\"{x:547,y:538,t:1528143856949};\\\", \\\"{x:548,y:538,t:1528143856989};\\\", \\\"{x:552,y:536,t:1528143857012};\\\", \\\"{x:554,y:535,t:1528143857021};\\\", \\\"{x:555,y:534,t:1528143857032};\\\", \\\"{x:561,y:529,t:1528143857132};\\\", \\\"{x:561,y:528,t:1528143857613};\\\", \\\"{x:561,y:527,t:1528143857645};\\\", \\\"{x:561,y:526,t:1528143857653};\\\", \\\"{x:562,y:526,t:1528143857668};\\\", \\\"{x:562,y:525,t:1528143857683};\\\", \\\"{x:563,y:525,t:1528143857699};\\\", \\\"{x:564,y:525,t:1528143857853};\\\", \\\"{x:564,y:523,t:1528143857868};\\\", \\\"{x:564,y:521,t:1528143857883};\\\", \\\"{x:564,y:519,t:1528143857899};\\\", \\\"{x:567,y:516,t:1528143857916};\\\", \\\"{x:571,y:514,t:1528143858261};\\\", \\\"{x:572,y:513,t:1528143858293};\\\", \\\"{x:572,y:512,t:1528143858373};\\\", \\\"{x:574,y:512,t:1528143858540};\\\", \\\"{x:575,y:512,t:1528143858603};\\\", \\\"{x:576,y:512,t:1528143858620};\\\", \\\"{x:577,y:512,t:1528143858636};\\\", \\\"{x:578,y:512,t:1528143858652};\\\", \\\"{x:579,y:512,t:1528143858667};\\\", \\\"{x:580,y:512,t:1528143858683};\\\", \\\"{x:581,y:512,t:1528143858699};\\\", \\\"{x:581,y:511,t:1528143858836};\\\", \\\"{x:582,y:510,t:1528143859005};\\\", \\\"{x:583,y:509,t:1528143860485};\\\", \\\"{x:583,y:508,t:1528143860557};\\\", \\\"{x:583,y:507,t:1528143861085};\\\", \\\"{x:582,y:506,t:1528143861109};\\\", \\\"{x:582,y:505,t:1528143862989};\\\", \\\"{x:584,y:505,t:1528143863004};\\\", \\\"{x:597,y:505,t:1528143863020};\\\", \\\"{x:606,y:505,t:1528143863038};\\\", \\\"{x:626,y:509,t:1528143863054};\\\", \\\"{x:649,y:512,t:1528143863071};\\\", \\\"{x:673,y:517,t:1528143863087};\\\", \\\"{x:703,y:522,t:1528143863104};\\\", \\\"{x:727,y:528,t:1528143863120};\\\", \\\"{x:759,y:535,t:1528143863137};\\\", \\\"{x:797,y:545,t:1528143863154};\\\", \\\"{x:820,y:548,t:1528143863171};\\\", \\\"{x:835,y:555,t:1528143863187};\\\", \\\"{x:851,y:565,t:1528143863204};\\\", \\\"{x:862,y:566,t:1528143863221};\\\", \\\"{x:889,y:576,t:1528143863238};\\\", \\\"{x:917,y:581,t:1528143863254};\\\", \\\"{x:943,y:587,t:1528143863269};\\\", \\\"{x:960,y:588,t:1528143863288};\\\", \\\"{x:986,y:589,t:1528143863304};\\\", \\\"{x:1008,y:592,t:1528143863321};\\\", \\\"{x:1027,y:598,t:1528143863337};\\\", \\\"{x:1040,y:600,t:1528143863355};\\\", \\\"{x:1054,y:606,t:1528143863370};\\\", \\\"{x:1062,y:609,t:1528143863387};\\\", \\\"{x:1089,y:618,t:1528143863404};\\\", \\\"{x:1105,y:620,t:1528143863421};\\\", \\\"{x:1119,y:626,t:1528143863438};\\\", \\\"{x:1141,y:636,t:1528143863455};\\\", \\\"{x:1165,y:647,t:1528143863472};\\\", \\\"{x:1181,y:657,t:1528143863487};\\\", \\\"{x:1210,y:666,t:1528143863505};\\\", \\\"{x:1235,y:676,t:1528143863522};\\\", \\\"{x:1253,y:686,t:1528143863538};\\\", \\\"{x:1270,y:694,t:1528143863555};\\\", \\\"{x:1294,y:704,t:1528143863571};\\\", \\\"{x:1314,y:711,t:1528143863588};\\\", \\\"{x:1334,y:723,t:1528143863605};\\\", \\\"{x:1350,y:732,t:1528143863622};\\\", \\\"{x:1360,y:741,t:1528143863638};\\\", \\\"{x:1372,y:748,t:1528143863655};\\\", \\\"{x:1379,y:752,t:1528143863672};\\\", \\\"{x:1384,y:754,t:1528143863688};\\\", \\\"{x:1384,y:755,t:1528143863705};\\\", \\\"{x:1384,y:754,t:1528143863828};\\\", \\\"{x:1382,y:749,t:1528143863839};\\\", \\\"{x:1379,y:744,t:1528143863854};\\\", \\\"{x:1378,y:741,t:1528143863872};\\\", \\\"{x:1377,y:739,t:1528143863889};\\\", \\\"{x:1377,y:738,t:1528143863905};\\\", \\\"{x:1376,y:738,t:1528143863922};\\\", \\\"{x:1375,y:737,t:1528143863941};\\\", \\\"{x:1375,y:735,t:1528143864046};\\\", \\\"{x:1375,y:733,t:1528143864061};\\\", \\\"{x:1374,y:731,t:1528143864072};\\\", \\\"{x:1372,y:728,t:1528143864089};\\\", \\\"{x:1372,y:722,t:1528143864105};\\\", \\\"{x:1372,y:719,t:1528143864122};\\\", \\\"{x:1372,y:718,t:1528143864139};\\\", \\\"{x:1371,y:716,t:1528143864155};\\\", \\\"{x:1371,y:715,t:1528143864181};\\\", \\\"{x:1370,y:714,t:1528143864189};\\\", \\\"{x:1369,y:713,t:1528143864205};\\\", \\\"{x:1368,y:711,t:1528143864222};\\\", \\\"{x:1368,y:710,t:1528143864239};\\\", \\\"{x:1368,y:709,t:1528143864255};\\\", \\\"{x:1368,y:708,t:1528143864272};\\\", \\\"{x:1367,y:707,t:1528143864289};\\\", \\\"{x:1366,y:705,t:1528143864306};\\\", \\\"{x:1366,y:703,t:1528143864322};\\\", \\\"{x:1364,y:701,t:1528143864338};\\\", \\\"{x:1364,y:699,t:1528143864355};\\\", \\\"{x:1362,y:698,t:1528143864371};\\\", \\\"{x:1361,y:694,t:1528143864388};\\\", \\\"{x:1360,y:691,t:1528143864406};\\\", \\\"{x:1358,y:688,t:1528143864422};\\\", \\\"{x:1357,y:685,t:1528143864439};\\\", \\\"{x:1353,y:681,t:1528143864456};\\\", \\\"{x:1352,y:680,t:1528143864501};\\\", \\\"{x:1352,y:681,t:1528143864677};\\\", \\\"{x:1352,y:683,t:1528143864708};\\\", \\\"{x:1352,y:685,t:1528143864733};\\\", \\\"{x:1352,y:686,t:1528143864814};\\\", \\\"{x:1352,y:687,t:1528143864845};\\\", \\\"{x:1352,y:688,t:1528143864909};\\\", \\\"{x:1352,y:689,t:1528143864923};\\\", \\\"{x:1353,y:690,t:1528143864939};\\\", \\\"{x:1353,y:691,t:1528143864956};\\\", \\\"{x:1354,y:694,t:1528143864973};\\\", \\\"{x:1354,y:696,t:1528143864989};\\\", \\\"{x:1354,y:698,t:1528143865007};\\\", \\\"{x:1354,y:700,t:1528143865023};\\\", \\\"{x:1354,y:701,t:1528143865040};\\\", \\\"{x:1354,y:702,t:1528143865056};\\\", \\\"{x:1355,y:703,t:1528143865073};\\\", \\\"{x:1355,y:705,t:1528143865089};\\\", \\\"{x:1355,y:707,t:1528143865106};\\\", \\\"{x:1355,y:710,t:1528143865123};\\\", \\\"{x:1355,y:712,t:1528143865165};\\\", \\\"{x:1355,y:713,t:1528143865189};\\\", \\\"{x:1355,y:715,t:1528143865212};\\\", \\\"{x:1355,y:716,t:1528143865237};\\\", \\\"{x:1355,y:718,t:1528143865261};\\\", \\\"{x:1355,y:720,t:1528143865285};\\\", \\\"{x:1355,y:721,t:1528143865301};\\\", \\\"{x:1355,y:723,t:1528143865333};\\\", \\\"{x:1355,y:724,t:1528143865349};\\\", \\\"{x:1355,y:725,t:1528143865381};\\\", \\\"{x:1355,y:726,t:1528143865397};\\\", \\\"{x:1355,y:727,t:1528143865429};\\\", \\\"{x:1355,y:728,t:1528143865440};\\\", \\\"{x:1355,y:729,t:1528143865517};\\\", \\\"{x:1355,y:731,t:1528143865525};\\\", \\\"{x:1355,y:733,t:1528143865597};\\\", \\\"{x:1355,y:734,t:1528143865613};\\\", \\\"{x:1355,y:735,t:1528143865726};\\\", \\\"{x:1355,y:736,t:1528143865765};\\\", \\\"{x:1355,y:737,t:1528143865837};\\\", \\\"{x:1355,y:738,t:1528143865981};\\\", \\\"{x:1355,y:739,t:1528143866038};\\\", \\\"{x:1355,y:740,t:1528143866085};\\\", \\\"{x:1355,y:741,t:1528143866166};\\\", \\\"{x:1356,y:743,t:1528143866181};\\\", \\\"{x:1355,y:744,t:1528143866717};\\\", \\\"{x:1352,y:744,t:1528143866725};\\\", \\\"{x:1339,y:742,t:1528143866741};\\\", \\\"{x:1324,y:737,t:1528143866758};\\\", \\\"{x:1268,y:714,t:1528143866774};\\\", \\\"{x:1176,y:671,t:1528143866791};\\\", \\\"{x:1074,y:628,t:1528143866808};\\\", \\\"{x:956,y:581,t:1528143866824};\\\", \\\"{x:828,y:534,t:1528143866841};\\\", \\\"{x:718,y:491,t:1528143866858};\\\", \\\"{x:645,y:468,t:1528143866873};\\\", \\\"{x:611,y:460,t:1528143866890};\\\", \\\"{x:584,y:454,t:1528143866907};\\\", \\\"{x:569,y:451,t:1528143866923};\\\", \\\"{x:557,y:449,t:1528143866940};\\\", \\\"{x:556,y:449,t:1528143866958};\\\", \\\"{x:556,y:450,t:1528143867100};\\\", \\\"{x:556,y:451,t:1528143867132};\\\", \\\"{x:556,y:452,t:1528143867197};\\\", \\\"{x:556,y:453,t:1528143867236};\\\", \\\"{x:555,y:454,t:1528143867253};\\\", \\\"{x:553,y:455,t:1528143867261};\\\", \\\"{x:551,y:456,t:1528143867274};\\\", \\\"{x:545,y:459,t:1528143867291};\\\", \\\"{x:537,y:462,t:1528143867307};\\\", \\\"{x:527,y:466,t:1528143867325};\\\", \\\"{x:522,y:469,t:1528143867340};\\\", \\\"{x:514,y:476,t:1528143867358};\\\", \\\"{x:507,y:480,t:1528143867375};\\\", \\\"{x:496,y:486,t:1528143867391};\\\", \\\"{x:493,y:489,t:1528143867409};\\\", \\\"{x:489,y:492,t:1528143867424};\\\", \\\"{x:486,y:494,t:1528143867441};\\\", \\\"{x:485,y:495,t:1528143867457};\\\", \\\"{x:484,y:497,t:1528143867474};\\\", \\\"{x:481,y:500,t:1528143867492};\\\", \\\"{x:481,y:502,t:1528143867508};\\\", \\\"{x:476,y:506,t:1528143867524};\\\", \\\"{x:471,y:511,t:1528143867541};\\\", \\\"{x:467,y:513,t:1528143867557};\\\", \\\"{x:462,y:516,t:1528143867574};\\\", \\\"{x:458,y:518,t:1528143867592};\\\", \\\"{x:454,y:520,t:1528143867609};\\\", \\\"{x:445,y:523,t:1528143867625};\\\", \\\"{x:436,y:527,t:1528143867642};\\\", \\\"{x:422,y:532,t:1528143867657};\\\", \\\"{x:410,y:536,t:1528143867675};\\\", \\\"{x:394,y:541,t:1528143867692};\\\", \\\"{x:381,y:548,t:1528143867708};\\\", \\\"{x:372,y:551,t:1528143867723};\\\", \\\"{x:357,y:556,t:1528143867741};\\\", \\\"{x:342,y:561,t:1528143867757};\\\", \\\"{x:325,y:562,t:1528143867774};\\\", \\\"{x:315,y:567,t:1528143867791};\\\", \\\"{x:295,y:570,t:1528143867807};\\\", \\\"{x:291,y:570,t:1528143867824};\\\", \\\"{x:283,y:571,t:1528143867842};\\\", \\\"{x:278,y:571,t:1528143867858};\\\", \\\"{x:270,y:574,t:1528143867875};\\\", \\\"{x:261,y:575,t:1528143867891};\\\", \\\"{x:255,y:576,t:1528143867907};\\\", \\\"{x:245,y:579,t:1528143867923};\\\", \\\"{x:233,y:580,t:1528143867942};\\\", \\\"{x:224,y:581,t:1528143867957};\\\", \\\"{x:221,y:581,t:1528143867975};\\\", \\\"{x:214,y:581,t:1528143867991};\\\", \\\"{x:205,y:581,t:1528143868007};\\\", \\\"{x:197,y:581,t:1528143868024};\\\", \\\"{x:188,y:579,t:1528143868043};\\\", \\\"{x:183,y:572,t:1528143868057};\\\", \\\"{x:167,y:563,t:1528143868074};\\\", \\\"{x:152,y:552,t:1528143868092};\\\", \\\"{x:143,y:543,t:1528143868107};\\\", \\\"{x:140,y:540,t:1528143868124};\\\", \\\"{x:138,y:537,t:1528143868141};\\\", \\\"{x:135,y:533,t:1528143868158};\\\", \\\"{x:134,y:531,t:1528143868174};\\\", \\\"{x:134,y:530,t:1528143868191};\\\", \\\"{x:133,y:530,t:1528143868209};\\\", \\\"{x:133,y:529,t:1528143868365};\\\", \\\"{x:133,y:528,t:1528143868375};\\\", \\\"{x:135,y:528,t:1528143868391};\\\", \\\"{x:137,y:528,t:1528143868420};\\\", \\\"{x:138,y:528,t:1528143868461};\\\", \\\"{x:140,y:528,t:1528143868474};\\\", \\\"{x:141,y:528,t:1528143868509};\\\", \\\"{x:142,y:528,t:1528143868525};\\\", \\\"{x:144,y:528,t:1528143868548};\\\", \\\"{x:144,y:529,t:1528143868669};\\\", \\\"{x:151,y:529,t:1528143869214};\\\", \\\"{x:159,y:533,t:1528143869225};\\\", \\\"{x:170,y:551,t:1528143869240};\\\", \\\"{x:179,y:562,t:1528143869257};\\\", \\\"{x:195,y:580,t:1528143869276};\\\", \\\"{x:232,y:612,t:1528143869292};\\\", \\\"{x:264,y:631,t:1528143869309};\\\", \\\"{x:291,y:642,t:1528143869326};\\\", \\\"{x:304,y:649,t:1528143869343};\\\", \\\"{x:319,y:656,t:1528143869358};\\\", \\\"{x:332,y:661,t:1528143869375};\\\", \\\"{x:338,y:664,t:1528143869393};\\\", \\\"{x:340,y:666,t:1528143869409};\\\", \\\"{x:336,y:663,t:1528143869597};\\\", \\\"{x:334,y:662,t:1528143869610};\\\", \\\"{x:326,y:657,t:1528143869626};\\\", \\\"{x:319,y:650,t:1528143869643};\\\", \\\"{x:305,y:633,t:1528143869661};\\\", \\\"{x:304,y:631,t:1528143869676};\\\", \\\"{x:289,y:620,t:1528143869693};\\\", \\\"{x:278,y:613,t:1528143869709};\\\", \\\"{x:272,y:608,t:1528143869726};\\\", \\\"{x:263,y:603,t:1528143869742};\\\", \\\"{x:257,y:597,t:1528143869759};\\\", \\\"{x:253,y:596,t:1528143869777};\\\", \\\"{x:249,y:593,t:1528143869793};\\\", \\\"{x:243,y:587,t:1528143869809};\\\", \\\"{x:238,y:584,t:1528143869826};\\\", \\\"{x:234,y:580,t:1528143869842};\\\", \\\"{x:227,y:572,t:1528143869860};\\\", \\\"{x:224,y:569,t:1528143869875};\\\", \\\"{x:221,y:566,t:1528143869892};\\\", \\\"{x:219,y:564,t:1528143869909};\\\", \\\"{x:213,y:561,t:1528143869927};\\\", \\\"{x:209,y:559,t:1528143869942};\\\", \\\"{x:206,y:556,t:1528143869959};\\\", \\\"{x:196,y:552,t:1528143869976};\\\", \\\"{x:196,y:551,t:1528143870004};\\\", \\\"{x:194,y:551,t:1528143870027};\\\", \\\"{x:192,y:551,t:1528143870042};\\\", \\\"{x:188,y:548,t:1528143870060};\\\", \\\"{x:183,y:547,t:1528143870077};\\\", \\\"{x:178,y:547,t:1528143870093};\\\", \\\"{x:175,y:547,t:1528143870110};\\\", \\\"{x:173,y:547,t:1528143870126};\\\", \\\"{x:171,y:545,t:1528143870143};\\\", \\\"{x:170,y:545,t:1528143870164};\\\", \\\"{x:169,y:545,t:1528143870181};\\\", \\\"{x:168,y:544,t:1528143870580};\\\", \\\"{x:168,y:543,t:1528143870594};\\\", \\\"{x:174,y:541,t:1528143870609};\\\", \\\"{x:183,y:544,t:1528143870627};\\\", \\\"{x:199,y:555,t:1528143870644};\\\", \\\"{x:211,y:565,t:1528143870660};\\\", \\\"{x:233,y:583,t:1528143870677};\\\", \\\"{x:246,y:594,t:1528143870694};\\\", \\\"{x:252,y:600,t:1528143870710};\\\", \\\"{x:271,y:618,t:1528143870727};\\\", \\\"{x:287,y:632,t:1528143870745};\\\", \\\"{x:311,y:650,t:1528143870761};\\\", \\\"{x:330,y:667,t:1528143870777};\\\", \\\"{x:341,y:676,t:1528143870794};\\\", \\\"{x:352,y:686,t:1528143870811};\\\", \\\"{x:366,y:696,t:1528143870827};\\\", \\\"{x:388,y:706,t:1528143870843};\\\", \\\"{x:407,y:712,t:1528143870860};\\\", \\\"{x:427,y:722,t:1528143870877};\\\", \\\"{x:440,y:728,t:1528143870894};\\\", \\\"{x:449,y:736,t:1528143870913};\\\", \\\"{x:462,y:741,t:1528143870927};\\\", \\\"{x:477,y:746,t:1528143870944};\\\", \\\"{x:500,y:750,t:1528143870960};\\\", \\\"{x:516,y:752,t:1528143870977};\\\", \\\"{x:536,y:756,t:1528143870995};\\\", \\\"{x:542,y:756,t:1528143871011};\\\", \\\"{x:548,y:756,t:1528143871026};\\\", \\\"{x:553,y:755,t:1528143871044};\\\", \\\"{x:556,y:754,t:1528143871061};\\\", \\\"{x:556,y:753,t:1528143871078};\\\", \\\"{x:556,y:750,t:1528143871173};\\\", \\\"{x:556,y:749,t:1528143871189};\\\", \\\"{x:555,y:746,t:1528143871196};\\\", \\\"{x:555,y:745,t:1528143871210};\\\", \\\"{x:554,y:742,t:1528143871237};\\\", \\\"{x:552,y:740,t:1528143871244};\\\", \\\"{x:551,y:738,t:1528143871261};\\\", \\\"{x:549,y:737,t:1528143871278};\\\", \\\"{x:547,y:736,t:1528143871294};\\\", \\\"{x:545,y:734,t:1528143871311};\\\", \\\"{x:542,y:732,t:1528143871328};\\\", \\\"{x:538,y:731,t:1528143871344};\\\", \\\"{x:535,y:731,t:1528143871361};\\\", \\\"{x:534,y:731,t:1528143871377};\\\", \\\"{x:531,y:729,t:1528143871394};\\\", \\\"{x:528,y:728,t:1528143871411};\\\", \\\"{x:527,y:728,t:1528143871428};\\\", \\\"{x:525,y:728,t:1528143871445};\\\" ] }, { \\\"rt\\\": 33029, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 897969, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -F -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:727,t:1528143873058};\\\", \\\"{x:524,y:726,t:1528143873845};\\\", \\\"{x:522,y:724,t:1528143873853};\\\", \\\"{x:522,y:723,t:1528143873868};\\\", \\\"{x:522,y:722,t:1528143873881};\\\", \\\"{x:521,y:721,t:1528143873897};\\\", \\\"{x:519,y:719,t:1528143873915};\\\", \\\"{x:518,y:719,t:1528143873931};\\\", \\\"{x:517,y:718,t:1528143873948};\\\", \\\"{x:516,y:715,t:1528143873962};\\\", \\\"{x:514,y:713,t:1528143873985};\\\", \\\"{x:512,y:710,t:1528143873996};\\\", \\\"{x:507,y:704,t:1528143874013};\\\", \\\"{x:495,y:692,t:1528143874030};\\\", \\\"{x:480,y:680,t:1528143874047};\\\", \\\"{x:463,y:667,t:1528143874063};\\\", \\\"{x:440,y:650,t:1528143874080};\\\", \\\"{x:417,y:630,t:1528143874097};\\\", \\\"{x:399,y:605,t:1528143874113};\\\", \\\"{x:375,y:585,t:1528143874130};\\\", \\\"{x:352,y:562,t:1528143874147};\\\", \\\"{x:333,y:544,t:1528143874163};\\\", \\\"{x:311,y:522,t:1528143874180};\\\", \\\"{x:293,y:502,t:1528143874197};\\\", \\\"{x:277,y:484,t:1528143874213};\\\", \\\"{x:266,y:469,t:1528143874230};\\\", \\\"{x:259,y:460,t:1528143874245};\\\", \\\"{x:256,y:454,t:1528143874262};\\\", \\\"{x:253,y:450,t:1528143874280};\\\", \\\"{x:253,y:447,t:1528143874297};\\\", \\\"{x:252,y:446,t:1528143874314};\\\", \\\"{x:252,y:444,t:1528143874329};\\\", \\\"{x:251,y:443,t:1528143874347};\\\", \\\"{x:253,y:433,t:1528143874364};\\\", \\\"{x:254,y:432,t:1528143874380};\\\", \\\"{x:257,y:428,t:1528143874397};\\\", \\\"{x:259,y:424,t:1528143874414};\\\", \\\"{x:262,y:420,t:1528143874430};\\\", \\\"{x:265,y:415,t:1528143874447};\\\", \\\"{x:275,y:408,t:1528143874464};\\\", \\\"{x:280,y:404,t:1528143874481};\\\", \\\"{x:293,y:398,t:1528143874497};\\\", \\\"{x:309,y:391,t:1528143874514};\\\", \\\"{x:328,y:382,t:1528143874531};\\\", \\\"{x:350,y:371,t:1528143874548};\\\", \\\"{x:363,y:365,t:1528143874565};\\\", \\\"{x:380,y:361,t:1528143874581};\\\", \\\"{x:410,y:360,t:1528143874598};\\\", \\\"{x:432,y:359,t:1528143874614};\\\", \\\"{x:452,y:359,t:1528143874631};\\\", \\\"{x:477,y:359,t:1528143874648};\\\", \\\"{x:496,y:359,t:1528143874665};\\\", \\\"{x:519,y:357,t:1528143874681};\\\", \\\"{x:539,y:357,t:1528143874698};\\\", \\\"{x:551,y:357,t:1528143874715};\\\", \\\"{x:569,y:357,t:1528143874731};\\\", \\\"{x:577,y:356,t:1528143874749};\\\", \\\"{x:593,y:357,t:1528143874765};\\\", \\\"{x:620,y:362,t:1528143874783};\\\", \\\"{x:636,y:365,t:1528143874798};\\\", \\\"{x:655,y:369,t:1528143874815};\\\", \\\"{x:675,y:373,t:1528143874832};\\\", \\\"{x:700,y:376,t:1528143874848};\\\", \\\"{x:716,y:379,t:1528143874865};\\\", \\\"{x:732,y:381,t:1528143874882};\\\", \\\"{x:759,y:386,t:1528143874899};\\\", \\\"{x:788,y:392,t:1528143874915};\\\", \\\"{x:817,y:401,t:1528143874933};\\\", \\\"{x:836,y:407,t:1528143874948};\\\", \\\"{x:852,y:411,t:1528143874965};\\\", \\\"{x:867,y:414,t:1528143874982};\\\", \\\"{x:887,y:417,t:1528143874999};\\\", \\\"{x:898,y:419,t:1528143875016};\\\", \\\"{x:907,y:421,t:1528143875033};\\\", \\\"{x:914,y:422,t:1528143875050};\\\", \\\"{x:916,y:423,t:1528143875066};\\\", \\\"{x:920,y:423,t:1528143875082};\\\", \\\"{x:921,y:423,t:1528143875100};\\\", \\\"{x:922,y:423,t:1528143875150};\\\", \\\"{x:923,y:423,t:1528143875173};\\\", \\\"{x:925,y:425,t:1528143877725};\\\", \\\"{x:927,y:430,t:1528143877741};\\\", \\\"{x:940,y:446,t:1528143877758};\\\", \\\"{x:951,y:461,t:1528143877774};\\\", \\\"{x:969,y:475,t:1528143877791};\\\", \\\"{x:980,y:488,t:1528143877807};\\\", \\\"{x:999,y:500,t:1528143877825};\\\", \\\"{x:1016,y:512,t:1528143877841};\\\", \\\"{x:1039,y:525,t:1528143877857};\\\", \\\"{x:1066,y:542,t:1528143877875};\\\", \\\"{x:1092,y:552,t:1528143877891};\\\", \\\"{x:1115,y:565,t:1528143877908};\\\", \\\"{x:1148,y:582,t:1528143877925};\\\", \\\"{x:1172,y:596,t:1528143877941};\\\", \\\"{x:1192,y:609,t:1528143877958};\\\", \\\"{x:1210,y:621,t:1528143877974};\\\", \\\"{x:1229,y:631,t:1528143877991};\\\", \\\"{x:1244,y:639,t:1528143878008};\\\", \\\"{x:1247,y:641,t:1528143878025};\\\", \\\"{x:1257,y:646,t:1528143878042};\\\", \\\"{x:1267,y:652,t:1528143878059};\\\", \\\"{x:1283,y:659,t:1528143878075};\\\", \\\"{x:1293,y:667,t:1528143878091};\\\", \\\"{x:1304,y:672,t:1528143878108};\\\", \\\"{x:1310,y:678,t:1528143878125};\\\", \\\"{x:1321,y:685,t:1528143878142};\\\", \\\"{x:1333,y:693,t:1528143878159};\\\", \\\"{x:1340,y:697,t:1528143878175};\\\", \\\"{x:1348,y:704,t:1528143878192};\\\", \\\"{x:1363,y:711,t:1528143878208};\\\", \\\"{x:1374,y:716,t:1528143878226};\\\", \\\"{x:1384,y:720,t:1528143878242};\\\", \\\"{x:1392,y:720,t:1528143878258};\\\", \\\"{x:1397,y:721,t:1528143878275};\\\", \\\"{x:1408,y:721,t:1528143878293};\\\", \\\"{x:1413,y:723,t:1528143878309};\\\", \\\"{x:1415,y:723,t:1528143878350};\\\", \\\"{x:1420,y:723,t:1528143878360};\\\", \\\"{x:1432,y:725,t:1528143878377};\\\", \\\"{x:1439,y:727,t:1528143878393};\\\", \\\"{x:1445,y:728,t:1528143878410};\\\", \\\"{x:1455,y:729,t:1528143878427};\\\", \\\"{x:1468,y:732,t:1528143878443};\\\", \\\"{x:1479,y:733,t:1528143878459};\\\", \\\"{x:1491,y:734,t:1528143878477};\\\", \\\"{x:1505,y:737,t:1528143878492};\\\", \\\"{x:1515,y:739,t:1528143878509};\\\", \\\"{x:1526,y:743,t:1528143878526};\\\", \\\"{x:1536,y:745,t:1528143878544};\\\", \\\"{x:1544,y:747,t:1528143878559};\\\", \\\"{x:1546,y:748,t:1528143878575};\\\", \\\"{x:1551,y:749,t:1528143878593};\\\", \\\"{x:1555,y:749,t:1528143878610};\\\", \\\"{x:1557,y:749,t:1528143878626};\\\", \\\"{x:1559,y:750,t:1528143878643};\\\", \\\"{x:1561,y:752,t:1528143878660};\\\", \\\"{x:1563,y:754,t:1528143878675};\\\", \\\"{x:1565,y:755,t:1528143878693};\\\", \\\"{x:1566,y:756,t:1528143878716};\\\", \\\"{x:1567,y:756,t:1528143878749};\\\", \\\"{x:1567,y:757,t:1528143878829};\\\", \\\"{x:1567,y:758,t:1528143878845};\\\", \\\"{x:1567,y:760,t:1528143878877};\\\", \\\"{x:1567,y:761,t:1528143878917};\\\", \\\"{x:1567,y:762,t:1528143878957};\\\", \\\"{x:1567,y:761,t:1528143880156};\\\", \\\"{x:1567,y:759,t:1528143880173};\\\", \\\"{x:1567,y:757,t:1528143880189};\\\", \\\"{x:1567,y:756,t:1528143880198};\\\", \\\"{x:1567,y:755,t:1528143880229};\\\", \\\"{x:1567,y:754,t:1528143880333};\\\", \\\"{x:1566,y:753,t:1528143881005};\\\", \\\"{x:1565,y:753,t:1528143881133};\\\", \\\"{x:1564,y:753,t:1528143881141};\\\", \\\"{x:1563,y:753,t:1528143881181};\\\", \\\"{x:1562,y:753,t:1528143881189};\\\", \\\"{x:1561,y:754,t:1528143881202};\\\", \\\"{x:1560,y:754,t:1528143881218};\\\", \\\"{x:1557,y:755,t:1528143881235};\\\", \\\"{x:1554,y:757,t:1528143881253};\\\", \\\"{x:1553,y:757,t:1528143881277};\\\", \\\"{x:1553,y:758,t:1528143881293};\\\", \\\"{x:1552,y:758,t:1528143881301};\\\", \\\"{x:1552,y:759,t:1528143881319};\\\", \\\"{x:1551,y:759,t:1528143881350};\\\", \\\"{x:1550,y:760,t:1528143881437};\\\", \\\"{x:1549,y:760,t:1528143881452};\\\", \\\"{x:1542,y:761,t:1528143881468};\\\", \\\"{x:1537,y:764,t:1528143881485};\\\", \\\"{x:1534,y:767,t:1528143881502};\\\", \\\"{x:1528,y:770,t:1528143881519};\\\", \\\"{x:1520,y:776,t:1528143881536};\\\", \\\"{x:1514,y:781,t:1528143881553};\\\", \\\"{x:1510,y:784,t:1528143881569};\\\", \\\"{x:1507,y:786,t:1528143881586};\\\", \\\"{x:1507,y:787,t:1528143881604};\\\", \\\"{x:1506,y:788,t:1528143881621};\\\", \\\"{x:1506,y:789,t:1528143881636};\\\", \\\"{x:1504,y:793,t:1528143881653};\\\", \\\"{x:1504,y:795,t:1528143881669};\\\", \\\"{x:1504,y:796,t:1528143881685};\\\", \\\"{x:1504,y:798,t:1528143881703};\\\", \\\"{x:1504,y:801,t:1528143881719};\\\", \\\"{x:1505,y:804,t:1528143881736};\\\", \\\"{x:1507,y:807,t:1528143881752};\\\", \\\"{x:1512,y:811,t:1528143881770};\\\", \\\"{x:1515,y:814,t:1528143881787};\\\", \\\"{x:1520,y:817,t:1528143881803};\\\", \\\"{x:1528,y:820,t:1528143881819};\\\", \\\"{x:1538,y:823,t:1528143881837};\\\", \\\"{x:1547,y:827,t:1528143881853};\\\", \\\"{x:1559,y:831,t:1528143881870};\\\", \\\"{x:1564,y:832,t:1528143881887};\\\", \\\"{x:1565,y:832,t:1528143881904};\\\", \\\"{x:1565,y:833,t:1528143881919};\\\", \\\"{x:1566,y:833,t:1528143881940};\\\", \\\"{x:1568,y:833,t:1528143881954};\\\", \\\"{x:1575,y:835,t:1528143881971};\\\", \\\"{x:1579,y:835,t:1528143881987};\\\", \\\"{x:1583,y:835,t:1528143882003};\\\", \\\"{x:1585,y:835,t:1528143882061};\\\", \\\"{x:1586,y:835,t:1528143882071};\\\", \\\"{x:1589,y:832,t:1528143882086};\\\", \\\"{x:1595,y:823,t:1528143882103};\\\", \\\"{x:1600,y:815,t:1528143882120};\\\", \\\"{x:1606,y:806,t:1528143882137};\\\", \\\"{x:1609,y:791,t:1528143882154};\\\", \\\"{x:1613,y:780,t:1528143882171};\\\", \\\"{x:1614,y:767,t:1528143882187};\\\", \\\"{x:1614,y:746,t:1528143882205};\\\", \\\"{x:1614,y:732,t:1528143882221};\\\", \\\"{x:1612,y:720,t:1528143882238};\\\", \\\"{x:1611,y:713,t:1528143882255};\\\", \\\"{x:1607,y:700,t:1528143882271};\\\", \\\"{x:1605,y:692,t:1528143882288};\\\", \\\"{x:1604,y:686,t:1528143882305};\\\", \\\"{x:1603,y:683,t:1528143882322};\\\", \\\"{x:1603,y:681,t:1528143882338};\\\", \\\"{x:1603,y:680,t:1528143882354};\\\", \\\"{x:1603,y:678,t:1528143882373};\\\", \\\"{x:1602,y:678,t:1528143882421};\\\", \\\"{x:1603,y:678,t:1528143882645};\\\", \\\"{x:1604,y:678,t:1528143882656};\\\", \\\"{x:1605,y:678,t:1528143882673};\\\", \\\"{x:1606,y:678,t:1528143882689};\\\", \\\"{x:1608,y:678,t:1528143882706};\\\", \\\"{x:1610,y:678,t:1528143882722};\\\", \\\"{x:1611,y:678,t:1528143882740};\\\", \\\"{x:1612,y:678,t:1528143883077};\\\", \\\"{x:1613,y:678,t:1528143883090};\\\", \\\"{x:1613,y:679,t:1528143883109};\\\", \\\"{x:1613,y:680,t:1528143883124};\\\", \\\"{x:1613,y:681,t:1528143883141};\\\", \\\"{x:1613,y:683,t:1528143883156};\\\", \\\"{x:1613,y:684,t:1528143883188};\\\", \\\"{x:1613,y:685,t:1528143883196};\\\", \\\"{x:1613,y:686,t:1528143883213};\\\", \\\"{x:1613,y:687,t:1528143883224};\\\", \\\"{x:1613,y:689,t:1528143883241};\\\", \\\"{x:1613,y:690,t:1528143883257};\\\", \\\"{x:1613,y:691,t:1528143883273};\\\", \\\"{x:1613,y:693,t:1528143883294};\\\", \\\"{x:1613,y:696,t:1528143883323};\\\", \\\"{x:1613,y:698,t:1528143883436};\\\", \\\"{x:1613,y:699,t:1528143883460};\\\", \\\"{x:1613,y:701,t:1528143883517};\\\", \\\"{x:1609,y:702,t:1528143888726};\\\", \\\"{x:1539,y:666,t:1528143888741};\\\", \\\"{x:1462,y:618,t:1528143888757};\\\", \\\"{x:1349,y:575,t:1528143888774};\\\", \\\"{x:1187,y:505,t:1528143888791};\\\", \\\"{x:997,y:428,t:1528143888807};\\\", \\\"{x:799,y:335,t:1528143888824};\\\", \\\"{x:644,y:288,t:1528143888840};\\\", \\\"{x:508,y:250,t:1528143888858};\\\", \\\"{x:419,y:236,t:1528143888874};\\\", \\\"{x:370,y:232,t:1528143888891};\\\", \\\"{x:330,y:231,t:1528143888908};\\\", \\\"{x:313,y:232,t:1528143888923};\\\", \\\"{x:293,y:243,t:1528143888941};\\\", \\\"{x:288,y:248,t:1528143888957};\\\", \\\"{x:285,y:255,t:1528143888975};\\\", \\\"{x:280,y:267,t:1528143888991};\\\", \\\"{x:276,y:286,t:1528143889008};\\\", \\\"{x:271,y:301,t:1528143889025};\\\", \\\"{x:269,y:309,t:1528143889040};\\\", \\\"{x:266,y:325,t:1528143889058};\\\", \\\"{x:266,y:333,t:1528143889075};\\\", \\\"{x:268,y:346,t:1528143889092};\\\", \\\"{x:278,y:360,t:1528143889108};\\\", \\\"{x:297,y:376,t:1528143889124};\\\", \\\"{x:316,y:393,t:1528143889142};\\\", \\\"{x:370,y:424,t:1528143889159};\\\", \\\"{x:438,y:451,t:1528143889176};\\\", \\\"{x:497,y:470,t:1528143889192};\\\", \\\"{x:566,y:485,t:1528143889209};\\\", \\\"{x:620,y:500,t:1528143889226};\\\", \\\"{x:666,y:502,t:1528143889243};\\\", \\\"{x:717,y:508,t:1528143889274};\\\", \\\"{x:722,y:508,t:1528143889291};\\\", \\\"{x:723,y:508,t:1528143889308};\\\", \\\"{x:723,y:507,t:1528143889380};\\\", \\\"{x:725,y:506,t:1528143889393};\\\", \\\"{x:725,y:505,t:1528143889408};\\\", \\\"{x:726,y:504,t:1528143889425};\\\", \\\"{x:727,y:503,t:1528143889442};\\\", \\\"{x:728,y:502,t:1528143889459};\\\", \\\"{x:729,y:500,t:1528143889475};\\\", \\\"{x:731,y:497,t:1528143889492};\\\", \\\"{x:733,y:496,t:1528143889510};\\\", \\\"{x:735,y:495,t:1528143889525};\\\", \\\"{x:736,y:494,t:1528143889543};\\\", \\\"{x:739,y:493,t:1528143889560};\\\", \\\"{x:741,y:493,t:1528143889605};\\\", \\\"{x:742,y:493,t:1528143889613};\\\", \\\"{x:746,y:493,t:1528143889625};\\\", \\\"{x:752,y:493,t:1528143889643};\\\", \\\"{x:757,y:492,t:1528143889659};\\\", \\\"{x:768,y:492,t:1528143889675};\\\", \\\"{x:782,y:492,t:1528143889692};\\\", \\\"{x:789,y:492,t:1528143889710};\\\", \\\"{x:798,y:493,t:1528143889727};\\\", \\\"{x:800,y:494,t:1528143889742};\\\", \\\"{x:802,y:494,t:1528143889759};\\\", \\\"{x:802,y:495,t:1528143889776};\\\", \\\"{x:802,y:496,t:1528143889793};\\\", \\\"{x:802,y:497,t:1528143889820};\\\", \\\"{x:803,y:499,t:1528143889997};\\\", \\\"{x:804,y:499,t:1528143890013};\\\", \\\"{x:807,y:500,t:1528143890028};\\\", \\\"{x:808,y:500,t:1528143890044};\\\", \\\"{x:813,y:500,t:1528143890061};\\\", \\\"{x:816,y:500,t:1528143890076};\\\", \\\"{x:818,y:499,t:1528143890094};\\\", \\\"{x:822,y:497,t:1528143890111};\\\", \\\"{x:824,y:497,t:1528143890128};\\\", \\\"{x:827,y:495,t:1528143890144};\\\", \\\"{x:828,y:494,t:1528143890161};\\\", \\\"{x:830,y:493,t:1528143890180};\\\", \\\"{x:831,y:493,t:1528143890196};\\\", \\\"{x:833,y:493,t:1528143890237};\\\", \\\"{x:834,y:493,t:1528143890869};\\\", \\\"{x:839,y:493,t:1528143890876};\\\", \\\"{x:842,y:493,t:1528143890894};\\\", \\\"{x:851,y:494,t:1528143890911};\\\", \\\"{x:860,y:495,t:1528143890927};\\\", \\\"{x:867,y:501,t:1528143890944};\\\", \\\"{x:879,y:509,t:1528143890962};\\\", \\\"{x:895,y:518,t:1528143890977};\\\", \\\"{x:911,y:525,t:1528143890994};\\\", \\\"{x:921,y:531,t:1528143891011};\\\", \\\"{x:933,y:538,t:1528143891027};\\\", \\\"{x:954,y:552,t:1528143891044};\\\", \\\"{x:970,y:562,t:1528143891059};\\\", \\\"{x:996,y:572,t:1528143891076};\\\", \\\"{x:1015,y:582,t:1528143891094};\\\", \\\"{x:1041,y:591,t:1528143891110};\\\", \\\"{x:1080,y:604,t:1528143891127};\\\", \\\"{x:1125,y:624,t:1528143891144};\\\", \\\"{x:1160,y:638,t:1528143891161};\\\", \\\"{x:1195,y:650,t:1528143891176};\\\", \\\"{x:1223,y:664,t:1528143891194};\\\", \\\"{x:1239,y:671,t:1528143891211};\\\", \\\"{x:1264,y:677,t:1528143891227};\\\", \\\"{x:1301,y:691,t:1528143891244};\\\", \\\"{x:1329,y:693,t:1528143891260};\\\", \\\"{x:1345,y:695,t:1528143891276};\\\", \\\"{x:1362,y:696,t:1528143891294};\\\", \\\"{x:1381,y:696,t:1528143891310};\\\", \\\"{x:1392,y:705,t:1528143891327};\\\", \\\"{x:1402,y:706,t:1528143891343};\\\", \\\"{x:1409,y:706,t:1528143891361};\\\", \\\"{x:1417,y:706,t:1528143891377};\\\", \\\"{x:1422,y:704,t:1528143891394};\\\", \\\"{x:1429,y:702,t:1528143891411};\\\", \\\"{x:1445,y:695,t:1528143891428};\\\", \\\"{x:1456,y:690,t:1528143891444};\\\", \\\"{x:1468,y:684,t:1528143891461};\\\", \\\"{x:1478,y:679,t:1528143891478};\\\", \\\"{x:1490,y:674,t:1528143891493};\\\", \\\"{x:1509,y:668,t:1528143891511};\\\", \\\"{x:1525,y:664,t:1528143891527};\\\", \\\"{x:1543,y:660,t:1528143891543};\\\", \\\"{x:1558,y:654,t:1528143891560};\\\", \\\"{x:1567,y:652,t:1528143891578};\\\", \\\"{x:1568,y:652,t:1528143891596};\\\", \\\"{x:1569,y:652,t:1528143891611};\\\", \\\"{x:1570,y:652,t:1528143891628};\\\", \\\"{x:1571,y:652,t:1528143891644};\\\", \\\"{x:1573,y:652,t:1528143891661};\\\", \\\"{x:1573,y:653,t:1528143891750};\\\", \\\"{x:1573,y:655,t:1528143891761};\\\", \\\"{x:1576,y:659,t:1528143891778};\\\", \\\"{x:1578,y:663,t:1528143891794};\\\", \\\"{x:1581,y:667,t:1528143891812};\\\", \\\"{x:1582,y:669,t:1528143891828};\\\", \\\"{x:1583,y:669,t:1528143891844};\\\", \\\"{x:1585,y:669,t:1528143891868};\\\", \\\"{x:1586,y:669,t:1528143891885};\\\", \\\"{x:1587,y:669,t:1528143891894};\\\", \\\"{x:1589,y:671,t:1528143891911};\\\", \\\"{x:1595,y:674,t:1528143891928};\\\", \\\"{x:1598,y:677,t:1528143891945};\\\", \\\"{x:1601,y:678,t:1528143891961};\\\", \\\"{x:1605,y:679,t:1528143891978};\\\", \\\"{x:1606,y:679,t:1528143892013};\\\", \\\"{x:1607,y:679,t:1528143892029};\\\", \\\"{x:1608,y:679,t:1528143892045};\\\", \\\"{x:1610,y:681,t:1528143892061};\\\", \\\"{x:1611,y:681,t:1528143892077};\\\", \\\"{x:1613,y:682,t:1528143892095};\\\", \\\"{x:1616,y:683,t:1528143892111};\\\", \\\"{x:1617,y:683,t:1528143892129};\\\", \\\"{x:1618,y:683,t:1528143892181};\\\", \\\"{x:1619,y:684,t:1528143893661};\\\", \\\"{x:1619,y:685,t:1528143893853};\\\", \\\"{x:1619,y:686,t:1528143893950};\\\", \\\"{x:1619,y:687,t:1528143894013};\\\", \\\"{x:1619,y:688,t:1528143894069};\\\", \\\"{x:1619,y:689,t:1528143894253};\\\", \\\"{x:1619,y:691,t:1528143902429};\\\", \\\"{x:1618,y:692,t:1528143902437};\\\", \\\"{x:1604,y:690,t:1528143902453};\\\", \\\"{x:1566,y:671,t:1528143902469};\\\", \\\"{x:1471,y:625,t:1528143902486};\\\", \\\"{x:1378,y:587,t:1528143902503};\\\", \\\"{x:1275,y:557,t:1528143902519};\\\", \\\"{x:1157,y:528,t:1528143902537};\\\", \\\"{x:1035,y:492,t:1528143902553};\\\", \\\"{x:906,y:462,t:1528143902570};\\\", \\\"{x:817,y:437,t:1528143902587};\\\", \\\"{x:748,y:429,t:1528143902603};\\\", \\\"{x:730,y:425,t:1528143902619};\\\", \\\"{x:708,y:425,t:1528143902636};\\\", \\\"{x:700,y:424,t:1528143902653};\\\", \\\"{x:693,y:427,t:1528143902669};\\\", \\\"{x:686,y:431,t:1528143902686};\\\", \\\"{x:670,y:436,t:1528143902704};\\\", \\\"{x:659,y:438,t:1528143902719};\\\", \\\"{x:651,y:441,t:1528143902737};\\\", \\\"{x:634,y:444,t:1528143902754};\\\", \\\"{x:617,y:449,t:1528143902769};\\\", \\\"{x:602,y:454,t:1528143902786};\\\", \\\"{x:596,y:456,t:1528143902803};\\\", \\\"{x:590,y:458,t:1528143902819};\\\", \\\"{x:586,y:461,t:1528143902836};\\\", \\\"{x:584,y:462,t:1528143902853};\\\", \\\"{x:583,y:462,t:1528143902869};\\\", \\\"{x:581,y:465,t:1528143902886};\\\", \\\"{x:579,y:467,t:1528143902903};\\\", \\\"{x:573,y:472,t:1528143902919};\\\", \\\"{x:568,y:476,t:1528143902936};\\\", \\\"{x:563,y:481,t:1528143902953};\\\", \\\"{x:558,y:488,t:1528143902970};\\\", \\\"{x:549,y:495,t:1528143902986};\\\", \\\"{x:545,y:499,t:1528143903003};\\\", \\\"{x:536,y:508,t:1528143903019};\\\", \\\"{x:524,y:516,t:1528143903037};\\\", \\\"{x:509,y:525,t:1528143903053};\\\", \\\"{x:489,y:537,t:1528143903070};\\\", \\\"{x:466,y:545,t:1528143903085};\\\", \\\"{x:448,y:555,t:1528143903103};\\\", \\\"{x:432,y:562,t:1528143903120};\\\", \\\"{x:413,y:566,t:1528143903137};\\\", \\\"{x:398,y:571,t:1528143903153};\\\", \\\"{x:386,y:575,t:1528143903170};\\\", \\\"{x:378,y:577,t:1528143903188};\\\", \\\"{x:367,y:579,t:1528143903204};\\\", \\\"{x:349,y:579,t:1528143903220};\\\", \\\"{x:339,y:579,t:1528143903237};\\\", \\\"{x:333,y:579,t:1528143903253};\\\", \\\"{x:325,y:578,t:1528143903271};\\\", \\\"{x:317,y:577,t:1528143903287};\\\", \\\"{x:309,y:573,t:1528143903303};\\\", \\\"{x:304,y:570,t:1528143903321};\\\", \\\"{x:302,y:570,t:1528143903338};\\\", \\\"{x:298,y:570,t:1528143903354};\\\", \\\"{x:294,y:570,t:1528143903370};\\\", \\\"{x:292,y:570,t:1528143903387};\\\", \\\"{x:287,y:572,t:1528143903404};\\\", \\\"{x:278,y:574,t:1528143903421};\\\", \\\"{x:267,y:577,t:1528143903440};\\\", \\\"{x:260,y:581,t:1528143903454};\\\", \\\"{x:251,y:586,t:1528143903470};\\\", \\\"{x:242,y:589,t:1528143903487};\\\", \\\"{x:232,y:593,t:1528143903503};\\\", \\\"{x:218,y:595,t:1528143903520};\\\", \\\"{x:201,y:598,t:1528143903537};\\\", \\\"{x:178,y:598,t:1528143903553};\\\", \\\"{x:177,y:599,t:1528143903570};\\\", \\\"{x:166,y:599,t:1528143903588};\\\", \\\"{x:154,y:599,t:1528143903603};\\\", \\\"{x:136,y:593,t:1528143903621};\\\", \\\"{x:133,y:592,t:1528143903637};\\\", \\\"{x:128,y:592,t:1528143903654};\\\", \\\"{x:128,y:591,t:1528143903671};\\\", \\\"{x:128,y:590,t:1528143903741};\\\", \\\"{x:129,y:589,t:1528143903753};\\\", \\\"{x:131,y:588,t:1528143903770};\\\", \\\"{x:137,y:585,t:1528143903787};\\\", \\\"{x:145,y:583,t:1528143903804};\\\", \\\"{x:156,y:580,t:1528143903820};\\\", \\\"{x:177,y:579,t:1528143903838};\\\", \\\"{x:214,y:579,t:1528143903854};\\\", \\\"{x:273,y:579,t:1528143903871};\\\", \\\"{x:313,y:583,t:1528143903887};\\\", \\\"{x:347,y:588,t:1528143903904};\\\", \\\"{x:375,y:592,t:1528143903921};\\\", \\\"{x:413,y:596,t:1528143903938};\\\", \\\"{x:446,y:601,t:1528143903955};\\\", \\\"{x:468,y:606,t:1528143903971};\\\", \\\"{x:486,y:607,t:1528143903987};\\\", \\\"{x:499,y:608,t:1528143904004};\\\", \\\"{x:501,y:608,t:1528143904021};\\\", \\\"{x:503,y:608,t:1528143904037};\\\", \\\"{x:506,y:608,t:1528143904054};\\\", \\\"{x:508,y:607,t:1528143904071};\\\", \\\"{x:509,y:607,t:1528143904088};\\\", \\\"{x:510,y:607,t:1528143904108};\\\", \\\"{x:511,y:606,t:1528143904121};\\\", \\\"{x:512,y:606,t:1528143904138};\\\", \\\"{x:516,y:603,t:1528143904154};\\\", \\\"{x:518,y:601,t:1528143904171};\\\", \\\"{x:524,y:600,t:1528143904190};\\\", \\\"{x:528,y:597,t:1528143904205};\\\", \\\"{x:537,y:596,t:1528143904221};\\\", \\\"{x:540,y:595,t:1528143904237};\\\", \\\"{x:546,y:593,t:1528143904254};\\\", \\\"{x:549,y:592,t:1528143904271};\\\", \\\"{x:552,y:591,t:1528143904287};\\\", \\\"{x:554,y:589,t:1528143904304};\\\", \\\"{x:558,y:587,t:1528143904321};\\\", \\\"{x:562,y:584,t:1528143904337};\\\", \\\"{x:567,y:583,t:1528143904354};\\\", \\\"{x:568,y:581,t:1528143904371};\\\", \\\"{x:570,y:580,t:1528143904388};\\\", \\\"{x:572,y:578,t:1528143904405};\\\", \\\"{x:575,y:577,t:1528143904421};\\\", \\\"{x:581,y:577,t:1528143904439};\\\", \\\"{x:582,y:575,t:1528143904454};\\\", \\\"{x:584,y:575,t:1528143904471};\\\", \\\"{x:586,y:574,t:1528143904488};\\\", \\\"{x:589,y:574,t:1528143904504};\\\", \\\"{x:590,y:574,t:1528143904564};\\\", \\\"{x:592,y:572,t:1528143904571};\\\", \\\"{x:594,y:571,t:1528143904588};\\\", \\\"{x:596,y:571,t:1528143904620};\\\", \\\"{x:596,y:570,t:1528143904628};\\\", \\\"{x:597,y:569,t:1528143904638};\\\", \\\"{x:598,y:568,t:1528143904654};\\\", \\\"{x:601,y:568,t:1528143904672};\\\", \\\"{x:603,y:566,t:1528143904688};\\\", \\\"{x:604,y:566,t:1528143904704};\\\", \\\"{x:603,y:568,t:1528143905252};\\\", \\\"{x:595,y:579,t:1528143905260};\\\", \\\"{x:588,y:589,t:1528143905271};\\\", \\\"{x:576,y:603,t:1528143905289};\\\", \\\"{x:567,y:614,t:1528143905305};\\\", \\\"{x:562,y:626,t:1528143905322};\\\", \\\"{x:553,y:636,t:1528143905339};\\\", \\\"{x:550,y:643,t:1528143905355};\\\", \\\"{x:545,y:649,t:1528143905372};\\\", \\\"{x:543,y:650,t:1528143905388};\\\", \\\"{x:543,y:651,t:1528143905405};\\\", \\\"{x:543,y:653,t:1528143905422};\\\", \\\"{x:541,y:656,t:1528143905438};\\\", \\\"{x:541,y:661,t:1528143905455};\\\", \\\"{x:539,y:663,t:1528143905472};\\\", \\\"{x:537,y:667,t:1528143905488};\\\", \\\"{x:537,y:671,t:1528143905506};\\\", \\\"{x:536,y:677,t:1528143905523};\\\", \\\"{x:533,y:681,t:1528143905539};\\\", \\\"{x:531,y:687,t:1528143905556};\\\", \\\"{x:527,y:695,t:1528143905572};\\\", \\\"{x:524,y:698,t:1528143905588};\\\", \\\"{x:521,y:704,t:1528143905605};\\\", \\\"{x:517,y:712,t:1528143905623};\\\", \\\"{x:517,y:718,t:1528143905639};\\\", \\\"{x:513,y:724,t:1528143905657};\\\", \\\"{x:511,y:731,t:1528143905673};\\\", \\\"{x:508,y:733,t:1528143905688};\\\", \\\"{x:508,y:735,t:1528143905706};\\\", \\\"{x:508,y:738,t:1528143905723};\\\", \\\"{x:508,y:740,t:1528143905738};\\\", \\\"{x:508,y:741,t:1528143905755};\\\", \\\"{x:508,y:737,t:1528143906501};\\\", \\\"{x:507,y:733,t:1528143906508};\\\", \\\"{x:505,y:728,t:1528143906524};\\\", \\\"{x:503,y:714,t:1528143906540};\\\", \\\"{x:499,y:701,t:1528143906556};\\\", \\\"{x:494,y:691,t:1528143906573};\\\", \\\"{x:494,y:689,t:1528143906590};\\\", \\\"{x:492,y:684,t:1528143906606};\\\", \\\"{x:487,y:679,t:1528143906624};\\\", \\\"{x:487,y:672,t:1528143906640};\\\", \\\"{x:485,y:667,t:1528143906657};\\\", \\\"{x:483,y:659,t:1528143906674};\\\", \\\"{x:481,y:646,t:1528143906689};\\\", \\\"{x:478,y:637,t:1528143906706};\\\", \\\"{x:476,y:629,t:1528143906723};\\\", \\\"{x:471,y:619,t:1528143906740};\\\", \\\"{x:466,y:603,t:1528143906756};\\\", \\\"{x:463,y:594,t:1528143906774};\\\", \\\"{x:458,y:580,t:1528143906790};\\\", \\\"{x:453,y:563,t:1528143906806};\\\", \\\"{x:447,y:543,t:1528143906823};\\\", \\\"{x:445,y:528,t:1528143906840};\\\", \\\"{x:442,y:512,t:1528143906856};\\\", \\\"{x:440,y:503,t:1528143906874};\\\", \\\"{x:439,y:497,t:1528143906890};\\\", \\\"{x:439,y:491,t:1528143906906};\\\", \\\"{x:439,y:486,t:1528143906923};\\\", \\\"{x:437,y:478,t:1528143906940};\\\", \\\"{x:436,y:472,t:1528143906956};\\\", \\\"{x:436,y:469,t:1528143906974};\\\", \\\"{x:435,y:459,t:1528143906990};\\\", \\\"{x:435,y:454,t:1528143907007};\\\", \\\"{x:435,y:452,t:1528143907024};\\\", \\\"{x:435,y:450,t:1528143907041};\\\", \\\"{x:435,y:447,t:1528143907057};\\\", \\\"{x:436,y:444,t:1528143907073};\\\", \\\"{x:437,y:441,t:1528143907097};\\\", \\\"{x:437,y:438,t:1528143907106};\\\", \\\"{x:437,y:436,t:1528143907123};\\\", \\\"{x:438,y:431,t:1528143907140};\\\", \\\"{x:438,y:429,t:1528143907156};\\\", \\\"{x:438,y:427,t:1528143907173};\\\", \\\"{x:438,y:426,t:1528143907190};\\\" ] }, { \\\"rt\\\": 23635, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 922937, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -02 PM-03 PM-04 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:438,y:419,t:1528143907398};\\\", \\\"{x:438,y:418,t:1528143907427};\\\", \\\"{x:437,y:418,t:1528143907440};\\\", \\\"{x:437,y:416,t:1528143907476};\\\", \\\"{x:437,y:415,t:1528143907523};\\\", \\\"{x:437,y:413,t:1528143907555};\\\", \\\"{x:437,y:412,t:1528143907579};\\\", \\\"{x:437,y:410,t:1528143907596};\\\", \\\"{x:436,y:410,t:1528143907607};\\\", \\\"{x:436,y:409,t:1528143907628};\\\", \\\"{x:436,y:407,t:1528143907667};\\\", \\\"{x:436,y:406,t:1528143907765};\\\", \\\"{x:435,y:405,t:1528143907779};\\\", \\\"{x:435,y:404,t:1528143907790};\\\", \\\"{x:435,y:403,t:1528143908116};\\\", \\\"{x:434,y:403,t:1528143908124};\\\", \\\"{x:432,y:402,t:1528143908141};\\\", \\\"{x:428,y:400,t:1528143908157};\\\", \\\"{x:414,y:398,t:1528143908175};\\\", \\\"{x:405,y:395,t:1528143908191};\\\", \\\"{x:397,y:394,t:1528143908208};\\\", \\\"{x:383,y:390,t:1528143908224};\\\", \\\"{x:369,y:387,t:1528143908241};\\\", \\\"{x:357,y:384,t:1528143908257};\\\", \\\"{x:332,y:379,t:1528143908275};\\\", \\\"{x:311,y:372,t:1528143908291};\\\", \\\"{x:293,y:364,t:1528143908307};\\\", \\\"{x:252,y:340,t:1528143908324};\\\", \\\"{x:225,y:320,t:1528143908341};\\\", \\\"{x:199,y:301,t:1528143908358};\\\", \\\"{x:150,y:276,t:1528143908375};\\\", \\\"{x:101,y:244,t:1528143908391};\\\", \\\"{x:24,y:198,t:1528143908407};\\\", \\\"{x:0,y:132,t:1528143908425};\\\", \\\"{x:0,y:87,t:1528143908441};\\\", \\\"{x:0,y:37,t:1528143908457};\\\", \\\"{x:0,y:16,t:1528143908474};\\\", \\\"{x:1,y:16,t:1528143908600};\\\", \\\"{x:2,y:16,t:1528143908611};\\\", \\\"{x:11,y:16,t:1528143908627};\\\", \\\"{x:17,y:16,t:1528143908645};\\\", \\\"{x:25,y:16,t:1528143908660};\\\", \\\"{x:36,y:16,t:1528143908678};\\\", \\\"{x:52,y:16,t:1528143908694};\\\", \\\"{x:59,y:16,t:1528143908711};\\\", \\\"{x:71,y:16,t:1528143908727};\\\", \\\"{x:79,y:16,t:1528143908744};\\\", \\\"{x:91,y:16,t:1528143908760};\\\", \\\"{x:116,y:16,t:1528143908778};\\\", \\\"{x:132,y:24,t:1528143908794};\\\", \\\"{x:192,y:36,t:1528143908811};\\\", \\\"{x:237,y:45,t:1528143908828};\\\", \\\"{x:302,y:68,t:1528143908845};\\\", \\\"{x:367,y:87,t:1528143908861};\\\", \\\"{x:430,y:104,t:1528143908877};\\\", \\\"{x:492,y:125,t:1528143908894};\\\", \\\"{x:564,y:153,t:1528143908911};\\\", \\\"{x:617,y:176,t:1528143908928};\\\", \\\"{x:652,y:195,t:1528143908945};\\\", \\\"{x:683,y:218,t:1528143908962};\\\", \\\"{x:717,y:234,t:1528143908978};\\\", \\\"{x:741,y:247,t:1528143908995};\\\", \\\"{x:772,y:265,t:1528143909012};\\\", \\\"{x:808,y:289,t:1528143909028};\\\", \\\"{x:836,y:305,t:1528143909045};\\\", \\\"{x:857,y:320,t:1528143909061};\\\", \\\"{x:876,y:332,t:1528143909078};\\\", \\\"{x:894,y:343,t:1528143909095};\\\", \\\"{x:928,y:369,t:1528143909111};\\\", \\\"{x:955,y:386,t:1528143909128};\\\", \\\"{x:973,y:399,t:1528143909145};\\\", \\\"{x:992,y:413,t:1528143909162};\\\", \\\"{x:1004,y:423,t:1528143909178};\\\", \\\"{x:1026,y:436,t:1528143909195};\\\", \\\"{x:1048,y:443,t:1528143909212};\\\", \\\"{x:1066,y:457,t:1528143909228};\\\", \\\"{x:1089,y:468,t:1528143909245};\\\", \\\"{x:1108,y:477,t:1528143909262};\\\", \\\"{x:1119,y:486,t:1528143909278};\\\", \\\"{x:1143,y:500,t:1528143909295};\\\", \\\"{x:1155,y:504,t:1528143909312};\\\", \\\"{x:1171,y:513,t:1528143909328};\\\", \\\"{x:1185,y:519,t:1528143909345};\\\", \\\"{x:1195,y:523,t:1528143909362};\\\", \\\"{x:1198,y:524,t:1528143909378};\\\", \\\"{x:1199,y:525,t:1528143909395};\\\", \\\"{x:1204,y:525,t:1528143909412};\\\", \\\"{x:1206,y:525,t:1528143909429};\\\", \\\"{x:1206,y:524,t:1528143909445};\\\", \\\"{x:1202,y:524,t:1528143909462};\\\", \\\"{x:1191,y:524,t:1528143909479};\\\", \\\"{x:1187,y:524,t:1528143909495};\\\", \\\"{x:1186,y:524,t:1528143909527};\\\", \\\"{x:1184,y:524,t:1528143909560};\\\", \\\"{x:1180,y:524,t:1528143909567};\\\", \\\"{x:1172,y:526,t:1528143909579};\\\", \\\"{x:1131,y:527,t:1528143909595};\\\", \\\"{x:1117,y:514,t:1528143909612};\\\", \\\"{x:1120,y:511,t:1528143909928};\\\", \\\"{x:1133,y:506,t:1528143909946};\\\", \\\"{x:1145,y:500,t:1528143909962};\\\", \\\"{x:1161,y:496,t:1528143909979};\\\", \\\"{x:1177,y:494,t:1528143909996};\\\", \\\"{x:1198,y:494,t:1528143910012};\\\", \\\"{x:1220,y:494,t:1528143910029};\\\", \\\"{x:1248,y:494,t:1528143910046};\\\", \\\"{x:1271,y:494,t:1528143910062};\\\", \\\"{x:1286,y:494,t:1528143910079};\\\", \\\"{x:1306,y:494,t:1528143910095};\\\", \\\"{x:1324,y:506,t:1528143910113};\\\", \\\"{x:1354,y:521,t:1528143910129};\\\", \\\"{x:1369,y:538,t:1528143910146};\\\", \\\"{x:1389,y:559,t:1528143910162};\\\", \\\"{x:1413,y:585,t:1528143910179};\\\", \\\"{x:1444,y:618,t:1528143910196};\\\", \\\"{x:1470,y:667,t:1528143910213};\\\", \\\"{x:1510,y:717,t:1528143910229};\\\", \\\"{x:1544,y:760,t:1528143910246};\\\", \\\"{x:1562,y:794,t:1528143910263};\\\", \\\"{x:1572,y:814,t:1528143910279};\\\", \\\"{x:1587,y:845,t:1528143910296};\\\", \\\"{x:1595,y:868,t:1528143910313};\\\", \\\"{x:1596,y:884,t:1528143910329};\\\", \\\"{x:1597,y:894,t:1528143910346};\\\", \\\"{x:1597,y:905,t:1528143910362};\\\", \\\"{x:1597,y:916,t:1528143910379};\\\", \\\"{x:1597,y:917,t:1528143910396};\\\", \\\"{x:1597,y:918,t:1528143910415};\\\", \\\"{x:1597,y:919,t:1528143910432};\\\", \\\"{x:1597,y:920,t:1528143910456};\\\", \\\"{x:1597,y:921,t:1528143910471};\\\", \\\"{x:1593,y:921,t:1528143910480};\\\", \\\"{x:1582,y:926,t:1528143910496};\\\", \\\"{x:1572,y:932,t:1528143910513};\\\", \\\"{x:1555,y:941,t:1528143910530};\\\", \\\"{x:1542,y:946,t:1528143910546};\\\", \\\"{x:1531,y:950,t:1528143910563};\\\", \\\"{x:1515,y:954,t:1528143910579};\\\", \\\"{x:1499,y:956,t:1528143910596};\\\", \\\"{x:1486,y:959,t:1528143910614};\\\", \\\"{x:1480,y:961,t:1528143910630};\\\", \\\"{x:1475,y:964,t:1528143910647};\\\", \\\"{x:1471,y:965,t:1528143910664};\\\", \\\"{x:1468,y:967,t:1528143910680};\\\", \\\"{x:1468,y:968,t:1528143910704};\\\", \\\"{x:1469,y:968,t:1528143910904};\\\", \\\"{x:1471,y:970,t:1528143910913};\\\", \\\"{x:1479,y:971,t:1528143910929};\\\", \\\"{x:1488,y:972,t:1528143910946};\\\", \\\"{x:1497,y:974,t:1528143910963};\\\", \\\"{x:1510,y:974,t:1528143910981};\\\", \\\"{x:1519,y:976,t:1528143910996};\\\", \\\"{x:1524,y:978,t:1528143911013};\\\", \\\"{x:1540,y:982,t:1528143911031};\\\", \\\"{x:1552,y:986,t:1528143911047};\\\", \\\"{x:1559,y:989,t:1528143911063};\\\", \\\"{x:1582,y:996,t:1528143911080};\\\", \\\"{x:1592,y:998,t:1528143911097};\\\", \\\"{x:1598,y:999,t:1528143911113};\\\", \\\"{x:1600,y:999,t:1528143911152};\\\", \\\"{x:1601,y:999,t:1528143911208};\\\", \\\"{x:1604,y:995,t:1528143911231};\\\", \\\"{x:1604,y:993,t:1528143911246};\\\", \\\"{x:1604,y:989,t:1528143911264};\\\", \\\"{x:1604,y:988,t:1528143911296};\\\", \\\"{x:1605,y:986,t:1528143911311};\\\", \\\"{x:1605,y:984,t:1528143911336};\\\", \\\"{x:1605,y:983,t:1528143911346};\\\", \\\"{x:1605,y:982,t:1528143911363};\\\", \\\"{x:1605,y:981,t:1528143911384};\\\", \\\"{x:1605,y:980,t:1528143911397};\\\", \\\"{x:1604,y:979,t:1528143911413};\\\", \\\"{x:1603,y:978,t:1528143911432};\\\", \\\"{x:1601,y:977,t:1528143911448};\\\", \\\"{x:1600,y:976,t:1528143911463};\\\", \\\"{x:1598,y:975,t:1528143911480};\\\", \\\"{x:1597,y:975,t:1528143911497};\\\", \\\"{x:1595,y:974,t:1528143911513};\\\", \\\"{x:1593,y:973,t:1528143911530};\\\", \\\"{x:1593,y:972,t:1528143911547};\\\", \\\"{x:1591,y:972,t:1528143911563};\\\", \\\"{x:1588,y:972,t:1528143911580};\\\", \\\"{x:1585,y:972,t:1528143911598};\\\", \\\"{x:1581,y:972,t:1528143911614};\\\", \\\"{x:1579,y:972,t:1528143911630};\\\", \\\"{x:1578,y:972,t:1528143911647};\\\", \\\"{x:1577,y:972,t:1528143911663};\\\", \\\"{x:1575,y:972,t:1528143911727};\\\", \\\"{x:1574,y:972,t:1528143911735};\\\", \\\"{x:1572,y:972,t:1528143911775};\\\", \\\"{x:1571,y:972,t:1528143911807};\\\", \\\"{x:1569,y:972,t:1528143911832};\\\", \\\"{x:1568,y:972,t:1528143911847};\\\", \\\"{x:1566,y:972,t:1528143911863};\\\", \\\"{x:1565,y:971,t:1528143911880};\\\", \\\"{x:1565,y:970,t:1528143911928};\\\", \\\"{x:1564,y:969,t:1528143911936};\\\", \\\"{x:1564,y:968,t:1528143911968};\\\", \\\"{x:1563,y:968,t:1528143911984};\\\", \\\"{x:1562,y:967,t:1528143911997};\\\", \\\"{x:1560,y:967,t:1528143912023};\\\", \\\"{x:1559,y:967,t:1528143912160};\\\", \\\"{x:1559,y:966,t:1528143912352};\\\", \\\"{x:1558,y:965,t:1528143912364};\\\", \\\"{x:1557,y:965,t:1528143912384};\\\", \\\"{x:1556,y:965,t:1528143912432};\\\", \\\"{x:1555,y:964,t:1528143912488};\\\", \\\"{x:1554,y:964,t:1528143913023};\\\", \\\"{x:1553,y:964,t:1528143913039};\\\", \\\"{x:1553,y:963,t:1528143913047};\\\", \\\"{x:1552,y:963,t:1528143913071};\\\", \\\"{x:1550,y:962,t:1528143913081};\\\", \\\"{x:1549,y:962,t:1528143913119};\\\", \\\"{x:1548,y:962,t:1528143913144};\\\", \\\"{x:1547,y:962,t:1528143913159};\\\", \\\"{x:1544,y:960,t:1528143927488};\\\", \\\"{x:1532,y:952,t:1528143927495};\\\", \\\"{x:1516,y:937,t:1528143927509};\\\", \\\"{x:1465,y:910,t:1528143927525};\\\", \\\"{x:1407,y:875,t:1528143927542};\\\", \\\"{x:1263,y:793,t:1528143927560};\\\", \\\"{x:1183,y:750,t:1528143927575};\\\", \\\"{x:917,y:588,t:1528143927593};\\\", \\\"{x:758,y:495,t:1528143927609};\\\", \\\"{x:584,y:415,t:1528143927625};\\\", \\\"{x:427,y:322,t:1528143927641};\\\", \\\"{x:295,y:263,t:1528143927659};\\\", \\\"{x:221,y:224,t:1528143927675};\\\", \\\"{x:193,y:206,t:1528143927692};\\\", \\\"{x:181,y:200,t:1528143927708};\\\", \\\"{x:179,y:200,t:1528143927725};\\\", \\\"{x:178,y:200,t:1528143927815};\\\", \\\"{x:175,y:203,t:1528143927825};\\\", \\\"{x:171,y:209,t:1528143927842};\\\", \\\"{x:165,y:220,t:1528143927858};\\\", \\\"{x:163,y:233,t:1528143927875};\\\", \\\"{x:154,y:258,t:1528143927892};\\\", \\\"{x:149,y:279,t:1528143927909};\\\", \\\"{x:149,y:307,t:1528143927925};\\\", \\\"{x:152,y:349,t:1528143927942};\\\", \\\"{x:158,y:370,t:1528143927959};\\\", \\\"{x:161,y:383,t:1528143927976};\\\", \\\"{x:161,y:392,t:1528143927992};\\\", \\\"{x:161,y:401,t:1528143928010};\\\", \\\"{x:162,y:404,t:1528143928026};\\\", \\\"{x:164,y:412,t:1528143928043};\\\", \\\"{x:169,y:422,t:1528143928060};\\\", \\\"{x:176,y:428,t:1528143928076};\\\", \\\"{x:183,y:434,t:1528143928093};\\\", \\\"{x:190,y:439,t:1528143928110};\\\", \\\"{x:202,y:443,t:1528143928127};\\\", \\\"{x:238,y:458,t:1528143928143};\\\", \\\"{x:260,y:465,t:1528143928159};\\\", \\\"{x:282,y:469,t:1528143928177};\\\", \\\"{x:312,y:479,t:1528143928193};\\\", \\\"{x:336,y:490,t:1528143928211};\\\", \\\"{x:357,y:496,t:1528143928226};\\\", \\\"{x:371,y:501,t:1528143928243};\\\", \\\"{x:381,y:504,t:1528143928260};\\\", \\\"{x:387,y:507,t:1528143928277};\\\", \\\"{x:390,y:509,t:1528143928294};\\\", \\\"{x:394,y:511,t:1528143928310};\\\", \\\"{x:397,y:513,t:1528143928328};\\\", \\\"{x:400,y:514,t:1528143928343};\\\", \\\"{x:403,y:515,t:1528143928360};\\\", \\\"{x:407,y:517,t:1528143928378};\\\", \\\"{x:414,y:518,t:1528143928394};\\\", \\\"{x:422,y:519,t:1528143928410};\\\", \\\"{x:438,y:519,t:1528143928427};\\\", \\\"{x:454,y:519,t:1528143928444};\\\", \\\"{x:477,y:519,t:1528143928460};\\\", \\\"{x:496,y:519,t:1528143928477};\\\", \\\"{x:520,y:516,t:1528143928495};\\\", \\\"{x:534,y:514,t:1528143928510};\\\", \\\"{x:538,y:511,t:1528143928528};\\\", \\\"{x:547,y:508,t:1528143928544};\\\", \\\"{x:552,y:507,t:1528143928561};\\\", \\\"{x:560,y:504,t:1528143928577};\\\", \\\"{x:566,y:502,t:1528143928594};\\\", \\\"{x:576,y:501,t:1528143928611};\\\", \\\"{x:586,y:499,t:1528143928628};\\\", \\\"{x:601,y:499,t:1528143928645};\\\", \\\"{x:613,y:498,t:1528143928660};\\\", \\\"{x:617,y:497,t:1528143928677};\\\", \\\"{x:618,y:496,t:1528143928694};\\\", \\\"{x:614,y:496,t:1528143928888};\\\", \\\"{x:611,y:497,t:1528143928895};\\\", \\\"{x:606,y:501,t:1528143928912};\\\", \\\"{x:602,y:504,t:1528143928927};\\\", \\\"{x:596,y:507,t:1528143928946};\\\", \\\"{x:588,y:512,t:1528143928961};\\\", \\\"{x:574,y:516,t:1528143928977};\\\", \\\"{x:559,y:521,t:1528143928995};\\\", \\\"{x:542,y:524,t:1528143929011};\\\", \\\"{x:529,y:533,t:1528143929027};\\\", \\\"{x:516,y:535,t:1528143929044};\\\", \\\"{x:502,y:536,t:1528143929062};\\\", \\\"{x:493,y:537,t:1528143929078};\\\", \\\"{x:467,y:538,t:1528143929094};\\\", \\\"{x:445,y:537,t:1528143929110};\\\", \\\"{x:426,y:537,t:1528143929127};\\\", \\\"{x:415,y:535,t:1528143929145};\\\", \\\"{x:408,y:535,t:1528143929161};\\\", \\\"{x:395,y:534,t:1528143929178};\\\", \\\"{x:385,y:534,t:1528143929195};\\\", \\\"{x:376,y:532,t:1528143929212};\\\", \\\"{x:366,y:531,t:1528143929228};\\\", \\\"{x:358,y:531,t:1528143929245};\\\", \\\"{x:346,y:531,t:1528143929261};\\\", \\\"{x:336,y:531,t:1528143929279};\\\", \\\"{x:328,y:531,t:1528143929294};\\\", \\\"{x:319,y:531,t:1528143929312};\\\", \\\"{x:315,y:531,t:1528143929329};\\\", \\\"{x:305,y:531,t:1528143929344};\\\", \\\"{x:290,y:533,t:1528143929362};\\\", \\\"{x:280,y:534,t:1528143929379};\\\", \\\"{x:265,y:536,t:1528143929397};\\\", \\\"{x:256,y:538,t:1528143929411};\\\", \\\"{x:235,y:538,t:1528143929429};\\\", \\\"{x:222,y:538,t:1528143929444};\\\", \\\"{x:217,y:540,t:1528143929461};\\\", \\\"{x:212,y:540,t:1528143929478};\\\", \\\"{x:206,y:540,t:1528143929494};\\\", \\\"{x:196,y:540,t:1528143929511};\\\", \\\"{x:190,y:540,t:1528143929529};\\\", \\\"{x:187,y:540,t:1528143929544};\\\", \\\"{x:186,y:540,t:1528143929562};\\\", \\\"{x:186,y:541,t:1528143929579};\\\", \\\"{x:185,y:541,t:1528143929607};\\\", \\\"{x:184,y:541,t:1528143929615};\\\", \\\"{x:183,y:541,t:1528143929629};\\\", \\\"{x:180,y:542,t:1528143929645};\\\", \\\"{x:179,y:542,t:1528143929661};\\\", \\\"{x:176,y:544,t:1528143929680};\\\", \\\"{x:175,y:544,t:1528143929743};\\\", \\\"{x:174,y:544,t:1528143929759};\\\", \\\"{x:173,y:544,t:1528143929784};\\\", \\\"{x:171,y:544,t:1528143929896};\\\", \\\"{x:172,y:544,t:1528143930231};\\\", \\\"{x:173,y:543,t:1528143930247};\\\", \\\"{x:174,y:543,t:1528143930279};\\\", \\\"{x:177,y:542,t:1528143930295};\\\", \\\"{x:181,y:541,t:1528143930313};\\\", \\\"{x:186,y:540,t:1528143930328};\\\", \\\"{x:188,y:540,t:1528143930346};\\\", \\\"{x:189,y:540,t:1528143930363};\\\", \\\"{x:196,y:541,t:1528143930380};\\\", \\\"{x:199,y:544,t:1528143930396};\\\", \\\"{x:206,y:550,t:1528143930412};\\\", \\\"{x:214,y:558,t:1528143930429};\\\", \\\"{x:225,y:573,t:1528143930446};\\\", \\\"{x:259,y:600,t:1528143930463};\\\", \\\"{x:281,y:615,t:1528143930478};\\\", \\\"{x:310,y:630,t:1528143930496};\\\", \\\"{x:326,y:641,t:1528143930513};\\\", \\\"{x:359,y:665,t:1528143930528};\\\", \\\"{x:407,y:688,t:1528143930546};\\\", \\\"{x:434,y:702,t:1528143930563};\\\", \\\"{x:450,y:710,t:1528143930579};\\\", \\\"{x:460,y:717,t:1528143930596};\\\", \\\"{x:469,y:726,t:1528143930613};\\\", \\\"{x:476,y:731,t:1528143930629};\\\", \\\"{x:485,y:735,t:1528143930646};\\\", \\\"{x:489,y:740,t:1528143930663};\\\", \\\"{x:492,y:740,t:1528143930680};\\\", \\\"{x:494,y:740,t:1528143930696};\\\", \\\"{x:496,y:740,t:1528143930712};\\\", \\\"{x:500,y:740,t:1528143930730};\\\", \\\"{x:501,y:740,t:1528143930746};\\\", \\\"{x:502,y:740,t:1528143930763};\\\", \\\"{x:503,y:740,t:1528143930791};\\\", \\\"{x:506,y:740,t:1528143931174};\\\", \\\"{x:507,y:735,t:1528143931183};\\\", \\\"{x:507,y:732,t:1528143931197};\\\", \\\"{x:510,y:728,t:1528143931213};\\\", \\\"{x:511,y:723,t:1528143931230};\\\", \\\"{x:513,y:719,t:1528143931247};\\\", \\\"{x:513,y:718,t:1528143931271};\\\", \\\"{x:513,y:717,t:1528143931280};\\\", \\\"{x:513,y:714,t:1528143931296};\\\", \\\"{x:513,y:711,t:1528143931312};\\\", \\\"{x:514,y:708,t:1528143931330};\\\", \\\"{x:515,y:703,t:1528143931347};\\\", \\\"{x:515,y:702,t:1528143931362};\\\", \\\"{x:517,y:699,t:1528143931380};\\\", \\\"{x:518,y:685,t:1528143931396};\\\", \\\"{x:518,y:665,t:1528143931413};\\\", \\\"{x:518,y:646,t:1528143931430};\\\", \\\"{x:507,y:593,t:1528143931446};\\\", \\\"{x:495,y:538,t:1528143931463};\\\", \\\"{x:474,y:461,t:1528143931480};\\\", \\\"{x:459,y:392,t:1528143931497};\\\", \\\"{x:455,y:351,t:1528143931513};\\\", \\\"{x:444,y:296,t:1528143931530};\\\", \\\"{x:437,y:256,t:1528143931546};\\\", \\\"{x:434,y:225,t:1528143931562};\\\", \\\"{x:421,y:173,t:1528143931580};\\\", \\\"{x:413,y:133,t:1528143931596};\\\", \\\"{x:400,y:92,t:1528143931614};\\\", \\\"{x:385,y:58,t:1528143931630};\\\", \\\"{x:367,y:19,t:1528143931647};\\\", \\\"{x:352,y:16,t:1528143931663};\\\", \\\"{x:331,y:16,t:1528143931680};\\\", \\\"{x:318,y:16,t:1528143931697};\\\", \\\"{x:307,y:16,t:1528143931714};\\\", \\\"{x:298,y:16,t:1528143931729};\\\", \\\"{x:293,y:16,t:1528143931747};\\\", \\\"{x:292,y:16,t:1528143931763};\\\", \\\"{x:288,y:16,t:1528143931783};\\\", \\\"{x:287,y:16,t:1528143931797};\\\", \\\"{x:285,y:16,t:1528143931813};\\\", \\\"{x:282,y:16,t:1528143931830};\\\", \\\"{x:279,y:16,t:1528143931847};\\\", \\\"{x:278,y:16,t:1528143931871};\\\" ] }, { \\\"rt\\\": 131482, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 1055731, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -X -X -06 PM-N -9-01 PM-02 PM-X -03 PM-X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:376,y:16,t:1528143932340};\\\", \\\"{x:415,y:20,t:1528143932348};\\\", \\\"{x:457,y:33,t:1528143932367};\\\", \\\"{x:485,y:41,t:1528143932381};\\\", \\\"{x:512,y:46,t:1528143932397};\\\", \\\"{x:579,y:61,t:1528143932413};\\\", \\\"{x:786,y:87,t:1528143932446};\\\", \\\"{x:981,y:91,t:1528143932463};\\\", \\\"{x:1127,y:91,t:1528143932480};\\\", \\\"{x:1264,y:91,t:1528143932498};\\\", \\\"{x:1384,y:95,t:1528143932514};\\\", \\\"{x:1490,y:111,t:1528143932530};\\\", \\\"{x:1608,y:126,t:1528143932547};\\\", \\\"{x:1697,y:135,t:1528143932563};\\\", \\\"{x:1763,y:142,t:1528143932581};\\\", \\\"{x:1785,y:142,t:1528143932598};\\\", \\\"{x:1795,y:141,t:1528143932614};\\\", \\\"{x:1800,y:138,t:1528143932631};\\\", \\\"{x:1794,y:132,t:1528143932722};\\\", \\\"{x:1792,y:131,t:1528143932730};\\\", \\\"{x:1785,y:129,t:1528143932747};\\\", \\\"{x:1781,y:129,t:1528143932765};\\\", \\\"{x:1774,y:130,t:1528143932780};\\\", \\\"{x:1769,y:130,t:1528143932797};\\\", \\\"{x:1756,y:130,t:1528143932814};\\\", \\\"{x:1750,y:129,t:1528143932830};\\\", \\\"{x:1735,y:123,t:1528143932848};\\\", \\\"{x:1705,y:117,t:1528143932864};\\\", \\\"{x:1668,y:104,t:1528143932880};\\\", \\\"{x:1603,y:93,t:1528143932898};\\\", \\\"{x:1569,y:79,t:1528143932914};\\\", \\\"{x:1522,y:71,t:1528143932930};\\\", \\\"{x:1498,y:66,t:1528143932947};\\\", \\\"{x:1477,y:61,t:1528143932964};\\\", \\\"{x:1460,y:58,t:1528143932981};\\\", \\\"{x:1445,y:54,t:1528143932997};\\\", \\\"{x:1426,y:49,t:1528143933015};\\\", \\\"{x:1420,y:48,t:1528143933031};\\\", \\\"{x:1415,y:48,t:1528143933048};\\\", \\\"{x:1406,y:48,t:1528143933065};\\\", \\\"{x:1398,y:48,t:1528143933081};\\\", \\\"{x:1393,y:48,t:1528143933098};\\\", \\\"{x:1385,y:49,t:1528143933115};\\\", \\\"{x:1377,y:53,t:1528143933131};\\\", \\\"{x:1368,y:58,t:1528143933148};\\\", \\\"{x:1352,y:61,t:1528143933165};\\\", \\\"{x:1337,y:69,t:1528143933180};\\\", \\\"{x:1316,y:75,t:1528143933198};\\\", \\\"{x:1293,y:79,t:1528143933215};\\\", \\\"{x:1277,y:82,t:1528143933231};\\\", \\\"{x:1260,y:85,t:1528143933248};\\\", \\\"{x:1249,y:86,t:1528143933265};\\\", \\\"{x:1242,y:87,t:1528143933281};\\\", \\\"{x:1239,y:87,t:1528143933298};\\\", \\\"{x:1237,y:88,t:1528143933315};\\\", \\\"{x:1236,y:88,t:1528143933332};\\\", \\\"{x:1234,y:88,t:1528143933391};\\\", \\\"{x:1233,y:89,t:1528143934160};\\\", \\\"{x:1231,y:89,t:1528143934247};\\\", \\\"{x:1230,y:89,t:1528143934271};\\\", \\\"{x:1229,y:90,t:1528143934282};\\\", \\\"{x:1228,y:91,t:1528143934319};\\\", \\\"{x:1227,y:91,t:1528143934496};\\\", \\\"{x:1227,y:92,t:1528143935832};\\\", \\\"{x:1223,y:96,t:1528143935839};\\\", \\\"{x:1222,y:97,t:1528143935851};\\\", \\\"{x:1219,y:105,t:1528143935867};\\\", \\\"{x:1218,y:109,t:1528143935883};\\\", \\\"{x:1217,y:118,t:1528143935900};\\\", \\\"{x:1217,y:131,t:1528143935917};\\\", \\\"{x:1217,y:139,t:1528143935933};\\\", \\\"{x:1225,y:151,t:1528143935950};\\\", \\\"{x:1236,y:165,t:1528143935967};\\\", \\\"{x:1252,y:181,t:1528143935983};\\\", \\\"{x:1265,y:193,t:1528143936000};\\\", \\\"{x:1284,y:206,t:1528143936017};\\\", \\\"{x:1298,y:216,t:1528143936034};\\\", \\\"{x:1308,y:221,t:1528143936050};\\\", \\\"{x:1323,y:230,t:1528143936067};\\\", \\\"{x:1334,y:236,t:1528143936085};\\\", \\\"{x:1338,y:239,t:1528143936100};\\\", \\\"{x:1342,y:241,t:1528143936118};\\\", \\\"{x:1342,y:245,t:1528143936135};\\\", \\\"{x:1347,y:247,t:1528143936150};\\\", \\\"{x:1350,y:249,t:1528143936167};\\\", \\\"{x:1352,y:250,t:1528143936184};\\\", \\\"{x:1353,y:251,t:1528143936200};\\\", \\\"{x:1353,y:250,t:1528143936719};\\\", \\\"{x:1350,y:250,t:1528143936743};\\\", \\\"{x:1349,y:249,t:1528143936751};\\\", \\\"{x:1348,y:248,t:1528143936768};\\\", \\\"{x:1346,y:248,t:1528143936785};\\\", \\\"{x:1344,y:248,t:1528143936802};\\\", \\\"{x:1343,y:248,t:1528143936817};\\\", \\\"{x:1342,y:247,t:1528143936880};\\\", \\\"{x:1341,y:246,t:1528143936976};\\\", \\\"{x:1340,y:246,t:1528143937264};\\\", \\\"{x:1340,y:245,t:1528143937271};\\\", \\\"{x:1345,y:248,t:1528143937952};\\\", \\\"{x:1383,y:273,t:1528143937968};\\\", \\\"{x:1439,y:311,t:1528143937986};\\\", \\\"{x:1524,y:363,t:1528143938003};\\\", \\\"{x:1607,y:416,t:1528143938019};\\\", \\\"{x:1646,y:454,t:1528143938036};\\\", \\\"{x:1710,y:517,t:1528143938053};\\\", \\\"{x:1764,y:583,t:1528143938068};\\\", \\\"{x:1784,y:612,t:1528143938086};\\\", \\\"{x:1799,y:637,t:1528143938103};\\\", \\\"{x:1809,y:660,t:1528143938119};\\\", \\\"{x:1815,y:684,t:1528143938135};\\\", \\\"{x:1816,y:695,t:1528143938152};\\\", \\\"{x:1816,y:701,t:1528143938169};\\\", \\\"{x:1816,y:704,t:1528143938186};\\\", \\\"{x:1814,y:709,t:1528143938202};\\\", \\\"{x:1806,y:712,t:1528143938219};\\\", \\\"{x:1786,y:720,t:1528143938235};\\\", \\\"{x:1766,y:730,t:1528143938253};\\\", \\\"{x:1758,y:734,t:1528143938270};\\\", \\\"{x:1739,y:746,t:1528143938285};\\\", \\\"{x:1722,y:764,t:1528143938303};\\\", \\\"{x:1703,y:790,t:1528143938320};\\\", \\\"{x:1694,y:803,t:1528143938336};\\\", \\\"{x:1687,y:817,t:1528143938352};\\\", \\\"{x:1676,y:831,t:1528143938372};\\\", \\\"{x:1673,y:842,t:1528143938387};\\\", \\\"{x:1668,y:853,t:1528143938402};\\\", \\\"{x:1664,y:860,t:1528143938420};\\\", \\\"{x:1660,y:869,t:1528143938435};\\\", \\\"{x:1657,y:874,t:1528143938453};\\\", \\\"{x:1654,y:883,t:1528143938470};\\\", \\\"{x:1650,y:896,t:1528143938486};\\\", \\\"{x:1644,y:908,t:1528143938503};\\\", \\\"{x:1627,y:924,t:1528143938519};\\\", \\\"{x:1615,y:931,t:1528143938535};\\\", \\\"{x:1597,y:946,t:1528143938552};\\\", \\\"{x:1586,y:951,t:1528143938569};\\\", \\\"{x:1572,y:957,t:1528143938586};\\\", \\\"{x:1555,y:958,t:1528143938603};\\\", \\\"{x:1547,y:958,t:1528143938620};\\\", \\\"{x:1534,y:960,t:1528143938637};\\\", \\\"{x:1520,y:963,t:1528143938653};\\\", \\\"{x:1507,y:965,t:1528143938670};\\\", \\\"{x:1498,y:965,t:1528143938687};\\\", \\\"{x:1496,y:965,t:1528143938703};\\\", \\\"{x:1493,y:966,t:1528143938720};\\\", \\\"{x:1493,y:963,t:1528143938808};\\\", \\\"{x:1493,y:961,t:1528143938820};\\\", \\\"{x:1493,y:956,t:1528143938836};\\\", \\\"{x:1493,y:954,t:1528143938852};\\\", \\\"{x:1493,y:951,t:1528143938869};\\\", \\\"{x:1493,y:946,t:1528143938886};\\\", \\\"{x:1494,y:941,t:1528143938902};\\\", \\\"{x:1494,y:938,t:1528143938919};\\\", \\\"{x:1494,y:935,t:1528143938937};\\\", \\\"{x:1494,y:931,t:1528143938952};\\\", \\\"{x:1494,y:928,t:1528143938969};\\\", \\\"{x:1494,y:927,t:1528143938986};\\\", \\\"{x:1494,y:924,t:1528143939002};\\\", \\\"{x:1494,y:923,t:1528143939022};\\\", \\\"{x:1493,y:923,t:1528143939288};\\\", \\\"{x:1491,y:924,t:1528143939304};\\\", \\\"{x:1489,y:926,t:1528143939327};\\\", \\\"{x:1488,y:926,t:1528143939336};\\\", \\\"{x:1487,y:928,t:1528143939353};\\\", \\\"{x:1485,y:930,t:1528143939370};\\\", \\\"{x:1484,y:931,t:1528143939387};\\\", \\\"{x:1483,y:933,t:1528143939404};\\\", \\\"{x:1482,y:936,t:1528143939420};\\\", \\\"{x:1481,y:937,t:1528143939437};\\\", \\\"{x:1480,y:939,t:1528143939454};\\\", \\\"{x:1480,y:941,t:1528143939469};\\\", \\\"{x:1479,y:943,t:1528143939487};\\\", \\\"{x:1478,y:945,t:1528143939503};\\\", \\\"{x:1478,y:947,t:1528143939616};\\\", \\\"{x:1478,y:948,t:1528143939623};\\\", \\\"{x:1478,y:950,t:1528143939647};\\\", \\\"{x:1478,y:951,t:1528143939664};\\\", \\\"{x:1478,y:953,t:1528143939680};\\\", \\\"{x:1478,y:954,t:1528143939688};\\\", \\\"{x:1478,y:956,t:1528143939704};\\\", \\\"{x:1479,y:957,t:1528143939721};\\\", \\\"{x:1480,y:961,t:1528143939737};\\\", \\\"{x:1481,y:962,t:1528143939753};\\\", \\\"{x:1482,y:963,t:1528143939771};\\\", \\\"{x:1483,y:964,t:1528143939787};\\\", \\\"{x:1484,y:966,t:1528143939804};\\\", \\\"{x:1485,y:966,t:1528143939820};\\\", \\\"{x:1485,y:967,t:1528143939839};\\\", \\\"{x:1485,y:964,t:1528143941305};\\\", \\\"{x:1484,y:963,t:1528143941322};\\\", \\\"{x:1483,y:961,t:1528143941384};\\\", \\\"{x:1482,y:961,t:1528143941614};\\\", \\\"{x:1481,y:961,t:1528143941630};\\\", \\\"{x:1480,y:961,t:1528143941638};\\\", \\\"{x:1478,y:962,t:1528143941654};\\\", \\\"{x:1474,y:964,t:1528143941671};\\\", \\\"{x:1474,y:965,t:1528143941718};\\\", \\\"{x:1472,y:965,t:1528143941784};\\\", \\\"{x:1471,y:965,t:1528143942143};\\\", \\\"{x:1472,y:964,t:1528143942155};\\\", \\\"{x:1475,y:963,t:1528143942171};\\\", \\\"{x:1480,y:960,t:1528143942188};\\\", \\\"{x:1483,y:959,t:1528143942205};\\\", \\\"{x:1484,y:958,t:1528143942221};\\\", \\\"{x:1485,y:957,t:1528143943888};\\\", \\\"{x:1485,y:955,t:1528143944768};\\\", \\\"{x:1485,y:954,t:1528143944776};\\\", \\\"{x:1485,y:951,t:1528143944791};\\\", \\\"{x:1485,y:939,t:1528143944807};\\\", \\\"{x:1485,y:931,t:1528143944823};\\\", \\\"{x:1485,y:924,t:1528143944841};\\\", \\\"{x:1485,y:918,t:1528143944857};\\\", \\\"{x:1485,y:914,t:1528143944874};\\\", \\\"{x:1486,y:908,t:1528143944890};\\\", \\\"{x:1486,y:903,t:1528143944907};\\\", \\\"{x:1486,y:900,t:1528143944924};\\\", \\\"{x:1486,y:895,t:1528143944941};\\\", \\\"{x:1487,y:889,t:1528143944958};\\\", \\\"{x:1487,y:881,t:1528143944975};\\\", \\\"{x:1488,y:879,t:1528143944991};\\\", \\\"{x:1489,y:877,t:1528143945008};\\\", \\\"{x:1489,y:873,t:1528143945025};\\\", \\\"{x:1489,y:869,t:1528143945041};\\\", \\\"{x:1489,y:866,t:1528143945058};\\\", \\\"{x:1489,y:863,t:1528143945075};\\\", \\\"{x:1489,y:857,t:1528143945091};\\\", \\\"{x:1488,y:850,t:1528143945107};\\\", \\\"{x:1487,y:842,t:1528143945126};\\\", \\\"{x:1485,y:835,t:1528143945141};\\\", \\\"{x:1484,y:825,t:1528143945159};\\\", \\\"{x:1481,y:815,t:1528143945176};\\\", \\\"{x:1480,y:806,t:1528143945191};\\\", \\\"{x:1476,y:796,t:1528143945207};\\\", \\\"{x:1475,y:790,t:1528143945225};\\\", \\\"{x:1474,y:782,t:1528143945241};\\\", \\\"{x:1474,y:776,t:1528143945258};\\\", \\\"{x:1471,y:771,t:1528143945275};\\\", \\\"{x:1468,y:766,t:1528143945291};\\\", \\\"{x:1468,y:762,t:1528143945308};\\\", \\\"{x:1468,y:756,t:1528143945325};\\\", \\\"{x:1464,y:745,t:1528143945342};\\\", \\\"{x:1464,y:742,t:1528143945358};\\\", \\\"{x:1462,y:737,t:1528143945375};\\\", \\\"{x:1459,y:726,t:1528143945391};\\\", \\\"{x:1459,y:719,t:1528143945408};\\\", \\\"{x:1459,y:716,t:1528143945425};\\\", \\\"{x:1459,y:712,t:1528143945442};\\\", \\\"{x:1459,y:709,t:1528143945458};\\\", \\\"{x:1460,y:704,t:1528143945474};\\\", \\\"{x:1460,y:701,t:1528143945492};\\\", \\\"{x:1461,y:700,t:1528143945508};\\\", \\\"{x:1461,y:697,t:1528143945525};\\\", \\\"{x:1461,y:695,t:1528143945542};\\\", \\\"{x:1462,y:693,t:1528143945558};\\\", \\\"{x:1462,y:691,t:1528143945575};\\\", \\\"{x:1463,y:690,t:1528143945592};\\\", \\\"{x:1463,y:689,t:1528143945608};\\\", \\\"{x:1464,y:688,t:1528143945625};\\\", \\\"{x:1465,y:686,t:1528143945736};\\\", \\\"{x:1466,y:686,t:1528143945767};\\\", \\\"{x:1467,y:686,t:1528143945782};\\\", \\\"{x:1468,y:686,t:1528143945814};\\\", \\\"{x:1469,y:684,t:1528143945838};\\\", \\\"{x:1470,y:684,t:1528143945879};\\\", \\\"{x:1469,y:684,t:1528143946048};\\\", \\\"{x:1468,y:684,t:1528143946059};\\\", \\\"{x:1467,y:684,t:1528143946088};\\\", \\\"{x:1466,y:685,t:1528143946119};\\\", \\\"{x:1464,y:685,t:1528143946184};\\\", \\\"{x:1463,y:685,t:1528143946200};\\\", \\\"{x:1463,y:686,t:1528143946231};\\\", \\\"{x:1463,y:687,t:1528143946280};\\\", \\\"{x:1463,y:688,t:1528143946624};\\\", \\\"{x:1464,y:688,t:1528143946663};\\\", \\\"{x:1465,y:688,t:1528143946676};\\\", \\\"{x:1466,y:689,t:1528143946693};\\\", \\\"{x:1468,y:690,t:1528143946709};\\\", \\\"{x:1469,y:690,t:1528143946726};\\\", \\\"{x:1472,y:691,t:1528143946743};\\\", \\\"{x:1473,y:691,t:1528143946767};\\\", \\\"{x:1473,y:692,t:1528143946816};\\\", \\\"{x:1474,y:692,t:1528143946826};\\\", \\\"{x:1475,y:692,t:1528143946843};\\\", \\\"{x:1476,y:692,t:1528143946859};\\\", \\\"{x:1477,y:692,t:1528143946876};\\\", \\\"{x:1478,y:692,t:1528143946967};\\\", \\\"{x:1479,y:692,t:1528143966408};\\\", \\\"{x:1480,y:692,t:1528143973835};\\\", \\\"{x:1483,y:677,t:1528143973849};\\\", \\\"{x:1486,y:663,t:1528143973866};\\\", \\\"{x:1488,y:646,t:1528143973884};\\\", \\\"{x:1491,y:627,t:1528143973900};\\\", \\\"{x:1492,y:609,t:1528143973917};\\\", \\\"{x:1497,y:599,t:1528143973934};\\\", \\\"{x:1498,y:592,t:1528143973949};\\\", \\\"{x:1500,y:583,t:1528143973966};\\\", \\\"{x:1501,y:580,t:1528143973983};\\\", \\\"{x:1501,y:579,t:1528143973999};\\\", \\\"{x:1502,y:578,t:1528143974034};\\\", \\\"{x:1502,y:576,t:1528143974050};\\\", \\\"{x:1504,y:576,t:1528143974066};\\\", \\\"{x:1507,y:574,t:1528143974089};\\\", \\\"{x:1509,y:574,t:1528143974130};\\\", \\\"{x:1512,y:574,t:1528143974137};\\\", \\\"{x:1514,y:573,t:1528143974150};\\\", \\\"{x:1517,y:572,t:1528143974167};\\\", \\\"{x:1524,y:569,t:1528143974184};\\\", \\\"{x:1526,y:569,t:1528143974200};\\\", \\\"{x:1528,y:568,t:1528143974225};\\\", \\\"{x:1531,y:567,t:1528143974233};\\\", \\\"{x:1536,y:565,t:1528143974250};\\\", \\\"{x:1546,y:563,t:1528143974267};\\\", \\\"{x:1559,y:561,t:1528143974284};\\\", \\\"{x:1572,y:560,t:1528143974301};\\\", \\\"{x:1583,y:558,t:1528143974316};\\\", \\\"{x:1596,y:555,t:1528143974334};\\\", \\\"{x:1599,y:555,t:1528143974351};\\\", \\\"{x:1600,y:555,t:1528143974366};\\\", \\\"{x:1602,y:555,t:1528143974394};\\\", \\\"{x:1603,y:555,t:1528143974402};\\\", \\\"{x:1607,y:555,t:1528143974417};\\\", \\\"{x:1613,y:555,t:1528143974434};\\\", \\\"{x:1616,y:555,t:1528143974450};\\\", \\\"{x:1618,y:555,t:1528143974467};\\\", \\\"{x:1619,y:555,t:1528143974484};\\\", \\\"{x:1620,y:555,t:1528143974500};\\\", \\\"{x:1622,y:555,t:1528143974517};\\\", \\\"{x:1624,y:555,t:1528143974534};\\\", \\\"{x:1628,y:555,t:1528143974550};\\\", \\\"{x:1633,y:555,t:1528143974566};\\\", \\\"{x:1635,y:556,t:1528143974582};\\\", \\\"{x:1641,y:557,t:1528143974600};\\\", \\\"{x:1647,y:559,t:1528143974616};\\\", \\\"{x:1658,y:560,t:1528143974633};\\\", \\\"{x:1662,y:561,t:1528143974650};\\\", \\\"{x:1666,y:561,t:1528143974667};\\\", \\\"{x:1667,y:562,t:1528143974683};\\\", \\\"{x:1668,y:562,t:1528143974700};\\\", \\\"{x:1670,y:562,t:1528143974717};\\\", \\\"{x:1671,y:562,t:1528143974746};\\\", \\\"{x:1672,y:562,t:1528143974834};\\\", \\\"{x:1673,y:562,t:1528143974850};\\\", \\\"{x:1674,y:562,t:1528143975130};\\\", \\\"{x:1674,y:563,t:1528143975138};\\\", \\\"{x:1676,y:563,t:1528143975154};\\\", \\\"{x:1677,y:564,t:1528143975168};\\\", \\\"{x:1680,y:565,t:1528143975185};\\\", \\\"{x:1682,y:566,t:1528143975201};\\\", \\\"{x:1684,y:567,t:1528143975218};\\\", \\\"{x:1685,y:567,t:1528143975235};\\\", \\\"{x:1686,y:567,t:1528143975251};\\\", \\\"{x:1687,y:568,t:1528143975268};\\\", \\\"{x:1688,y:568,t:1528143975313};\\\", \\\"{x:1689,y:568,t:1528143975434};\\\", \\\"{x:1690,y:569,t:1528143975451};\\\", \\\"{x:1691,y:569,t:1528143975938};\\\", \\\"{x:1693,y:570,t:1528143976026};\\\", \\\"{x:1694,y:570,t:1528143976105};\\\", \\\"{x:1696,y:570,t:1528143976145};\\\", \\\"{x:1697,y:570,t:1528143976762};\\\", \\\"{x:1696,y:570,t:1528143977257};\\\", \\\"{x:1695,y:570,t:1528143977273};\\\", \\\"{x:1694,y:570,t:1528143977286};\\\", \\\"{x:1693,y:570,t:1528143977303};\\\", \\\"{x:1691,y:570,t:1528143977319};\\\", \\\"{x:1690,y:570,t:1528143977336};\\\", \\\"{x:1685,y:569,t:1528143977353};\\\", \\\"{x:1681,y:568,t:1528143977370};\\\", \\\"{x:1677,y:568,t:1528143977386};\\\", \\\"{x:1673,y:565,t:1528143977403};\\\", \\\"{x:1665,y:564,t:1528143977420};\\\", \\\"{x:1662,y:562,t:1528143977436};\\\", \\\"{x:1658,y:558,t:1528143977453};\\\", \\\"{x:1654,y:557,t:1528143977470};\\\", \\\"{x:1650,y:555,t:1528143977486};\\\", \\\"{x:1648,y:555,t:1528143977503};\\\", \\\"{x:1649,y:555,t:1528143977714};\\\", \\\"{x:1651,y:555,t:1528143977721};\\\", \\\"{x:1653,y:555,t:1528143977735};\\\", \\\"{x:1654,y:555,t:1528143977753};\\\", \\\"{x:1656,y:555,t:1528143977770};\\\", \\\"{x:1657,y:557,t:1528143977858};\\\", \\\"{x:1659,y:557,t:1528143977874};\\\", \\\"{x:1660,y:558,t:1528143977887};\\\", \\\"{x:1662,y:558,t:1528143977903};\\\", \\\"{x:1663,y:558,t:1528143977920};\\\", \\\"{x:1664,y:559,t:1528143977937};\\\", \\\"{x:1665,y:559,t:1528143977953};\\\", \\\"{x:1667,y:560,t:1528143977970};\\\", \\\"{x:1669,y:560,t:1528143977987};\\\", \\\"{x:1670,y:560,t:1528143978003};\\\", \\\"{x:1670,y:561,t:1528143978033};\\\", \\\"{x:1671,y:561,t:1528143978041};\\\", \\\"{x:1672,y:561,t:1528143978052};\\\", \\\"{x:1673,y:562,t:1528143978070};\\\", \\\"{x:1674,y:562,t:1528143978122};\\\", \\\"{x:1675,y:563,t:1528143978137};\\\", \\\"{x:1675,y:564,t:1528143978250};\\\", \\\"{x:1676,y:564,t:1528143978274};\\\", \\\"{x:1676,y:565,t:1528143978338};\\\", \\\"{x:1676,y:566,t:1528143978354};\\\", \\\"{x:1676,y:567,t:1528143978410};\\\", \\\"{x:1676,y:568,t:1528143978618};\\\", \\\"{x:1676,y:570,t:1528143978625};\\\", \\\"{x:1675,y:571,t:1528143978664};\\\", \\\"{x:1675,y:572,t:1528143978681};\\\", \\\"{x:1675,y:573,t:1528143978728};\\\", \\\"{x:1675,y:574,t:1528143978737};\\\", \\\"{x:1675,y:575,t:1528143978801};\\\", \\\"{x:1675,y:576,t:1528143978833};\\\", \\\"{x:1675,y:577,t:1528143978849};\\\", \\\"{x:1675,y:578,t:1528143978864};\\\", \\\"{x:1675,y:579,t:1528143978881};\\\", \\\"{x:1675,y:580,t:1528143978898};\\\", \\\"{x:1675,y:581,t:1528143978922};\\\", \\\"{x:1675,y:582,t:1528143978937};\\\", \\\"{x:1675,y:583,t:1528143978986};\\\", \\\"{x:1675,y:584,t:1528143979003};\\\", \\\"{x:1675,y:585,t:1528143979021};\\\", \\\"{x:1675,y:586,t:1528143979066};\\\", \\\"{x:1675,y:587,t:1528143979081};\\\", \\\"{x:1675,y:588,t:1528143979106};\\\", \\\"{x:1675,y:589,t:1528143979130};\\\", \\\"{x:1675,y:590,t:1528143979138};\\\", \\\"{x:1675,y:591,t:1528143979154};\\\", \\\"{x:1675,y:592,t:1528143979178};\\\", \\\"{x:1675,y:593,t:1528143979194};\\\", \\\"{x:1675,y:594,t:1528143979209};\\\", \\\"{x:1675,y:595,t:1528143979242};\\\", \\\"{x:1675,y:597,t:1528143979282};\\\", \\\"{x:1675,y:598,t:1528143979330};\\\", \\\"{x:1675,y:599,t:1528143979681};\\\", \\\"{x:1676,y:599,t:1528143979697};\\\", \\\"{x:1678,y:598,t:1528143979705};\\\", \\\"{x:1679,y:595,t:1528143979720};\\\", \\\"{x:1679,y:593,t:1528143979737};\\\", \\\"{x:1684,y:590,t:1528143979755};\\\", \\\"{x:1685,y:587,t:1528143979771};\\\", \\\"{x:1686,y:585,t:1528143979788};\\\", \\\"{x:1686,y:584,t:1528143979805};\\\", \\\"{x:1687,y:583,t:1528143979821};\\\", \\\"{x:1687,y:581,t:1528143979842};\\\", \\\"{x:1688,y:581,t:1528143979855};\\\", \\\"{x:1688,y:580,t:1528143979888};\\\", \\\"{x:1688,y:578,t:1528143979913};\\\", \\\"{x:1688,y:577,t:1528143979920};\\\", \\\"{x:1688,y:576,t:1528143979937};\\\", \\\"{x:1689,y:576,t:1528143979968};\\\", \\\"{x:1689,y:575,t:1528143979976};\\\", \\\"{x:1689,y:574,t:1528143980001};\\\", \\\"{x:1689,y:575,t:1528143980234};\\\", \\\"{x:1689,y:579,t:1528143980241};\\\", \\\"{x:1690,y:586,t:1528143980255};\\\", \\\"{x:1690,y:590,t:1528143980272};\\\", \\\"{x:1690,y:599,t:1528143980288};\\\", \\\"{x:1691,y:607,t:1528143980305};\\\", \\\"{x:1693,y:621,t:1528143980321};\\\", \\\"{x:1694,y:631,t:1528143980338};\\\", \\\"{x:1695,y:641,t:1528143980355};\\\", \\\"{x:1695,y:649,t:1528143980372};\\\", \\\"{x:1695,y:657,t:1528143980388};\\\", \\\"{x:1695,y:665,t:1528143980405};\\\", \\\"{x:1695,y:671,t:1528143980422};\\\", \\\"{x:1695,y:681,t:1528143980439};\\\", \\\"{x:1696,y:691,t:1528143980455};\\\", \\\"{x:1697,y:697,t:1528143980472};\\\", \\\"{x:1701,y:712,t:1528143980489};\\\", \\\"{x:1702,y:722,t:1528143980506};\\\", \\\"{x:1703,y:725,t:1528143980522};\\\", \\\"{x:1705,y:731,t:1528143980539};\\\", \\\"{x:1706,y:740,t:1528143980555};\\\", \\\"{x:1706,y:749,t:1528143980572};\\\", \\\"{x:1706,y:755,t:1528143980589};\\\", \\\"{x:1706,y:762,t:1528143980605};\\\", \\\"{x:1706,y:766,t:1528143980622};\\\", \\\"{x:1706,y:769,t:1528143980639};\\\", \\\"{x:1706,y:774,t:1528143980655};\\\", \\\"{x:1706,y:777,t:1528143980672};\\\", \\\"{x:1706,y:781,t:1528143980688};\\\", \\\"{x:1706,y:790,t:1528143980705};\\\", \\\"{x:1706,y:795,t:1528143980722};\\\", \\\"{x:1708,y:800,t:1528143980739};\\\", \\\"{x:1710,y:805,t:1528143980755};\\\", \\\"{x:1711,y:809,t:1528143980772};\\\", \\\"{x:1713,y:815,t:1528143980789};\\\", \\\"{x:1713,y:817,t:1528143980805};\\\", \\\"{x:1715,y:821,t:1528143980822};\\\", \\\"{x:1716,y:823,t:1528143980839};\\\", \\\"{x:1719,y:827,t:1528143980855};\\\", \\\"{x:1719,y:830,t:1528143980872};\\\", \\\"{x:1720,y:836,t:1528143980890};\\\", \\\"{x:1722,y:839,t:1528143980905};\\\", \\\"{x:1722,y:842,t:1528143980922};\\\", \\\"{x:1723,y:843,t:1528143980939};\\\", \\\"{x:1725,y:846,t:1528143980955};\\\", \\\"{x:1726,y:847,t:1528143980972};\\\", \\\"{x:1726,y:850,t:1528143981017};\\\", \\\"{x:1726,y:851,t:1528143981066};\\\", \\\"{x:1726,y:852,t:1528143981073};\\\", \\\"{x:1726,y:853,t:1528143981105};\\\", \\\"{x:1727,y:854,t:1528143981121};\\\", \\\"{x:1727,y:855,t:1528143981138};\\\", \\\"{x:1728,y:856,t:1528143982665};\\\", \\\"{x:1728,y:858,t:1528143982673};\\\", \\\"{x:1729,y:860,t:1528143982689};\\\", \\\"{x:1730,y:863,t:1528143982706};\\\", \\\"{x:1730,y:869,t:1528143982723};\\\", \\\"{x:1732,y:871,t:1528143982739};\\\", \\\"{x:1732,y:874,t:1528143982756};\\\", \\\"{x:1733,y:879,t:1528143982773};\\\", \\\"{x:1734,y:884,t:1528143982789};\\\", \\\"{x:1736,y:886,t:1528143982806};\\\", \\\"{x:1736,y:888,t:1528143982832};\\\", \\\"{x:1736,y:891,t:1528143982849};\\\", \\\"{x:1737,y:892,t:1528143982873};\\\", \\\"{x:1737,y:893,t:1528143982889};\\\", \\\"{x:1738,y:895,t:1528143982907};\\\", \\\"{x:1738,y:896,t:1528143982937};\\\", \\\"{x:1738,y:897,t:1528143982945};\\\", \\\"{x:1739,y:898,t:1528143982957};\\\", \\\"{x:1739,y:899,t:1528143982974};\\\", \\\"{x:1739,y:901,t:1528143982990};\\\", \\\"{x:1739,y:903,t:1528143983017};\\\", \\\"{x:1739,y:904,t:1528143983033};\\\", \\\"{x:1740,y:905,t:1528143983041};\\\", \\\"{x:1740,y:906,t:1528143983057};\\\", \\\"{x:1740,y:907,t:1528143983073};\\\", \\\"{x:1740,y:909,t:1528143983090};\\\", \\\"{x:1740,y:911,t:1528143983107};\\\", \\\"{x:1740,y:912,t:1528143983124};\\\", \\\"{x:1740,y:914,t:1528143983140};\\\", \\\"{x:1740,y:916,t:1528143983162};\\\", \\\"{x:1740,y:917,t:1528143983193};\\\", \\\"{x:1741,y:919,t:1528143983209};\\\", \\\"{x:1741,y:920,t:1528143983224};\\\", \\\"{x:1741,y:924,t:1528143983241};\\\", \\\"{x:1741,y:927,t:1528143983257};\\\", \\\"{x:1742,y:930,t:1528143983274};\\\", \\\"{x:1742,y:933,t:1528143983292};\\\", \\\"{x:1742,y:935,t:1528143983307};\\\", \\\"{x:1742,y:937,t:1528143983324};\\\", \\\"{x:1742,y:938,t:1528143983341};\\\", \\\"{x:1742,y:939,t:1528143983357};\\\", \\\"{x:1742,y:940,t:1528143983374};\\\", \\\"{x:1742,y:941,t:1528143983393};\\\", \\\"{x:1742,y:942,t:1528143983417};\\\", \\\"{x:1742,y:943,t:1528143983433};\\\", \\\"{x:1742,y:944,t:1528143983458};\\\", \\\"{x:1741,y:946,t:1528143983474};\\\", \\\"{x:1740,y:950,t:1528143983492};\\\", \\\"{x:1739,y:953,t:1528143983507};\\\", \\\"{x:1738,y:957,t:1528143983523};\\\", \\\"{x:1736,y:961,t:1528143983541};\\\", \\\"{x:1735,y:966,t:1528143983557};\\\", \\\"{x:1735,y:968,t:1528143983573};\\\", \\\"{x:1734,y:970,t:1528143983591};\\\", \\\"{x:1734,y:971,t:1528143983617};\\\", \\\"{x:1734,y:968,t:1528143984130};\\\", \\\"{x:1732,y:963,t:1528143984142};\\\", \\\"{x:1731,y:953,t:1528143984158};\\\", \\\"{x:1730,y:937,t:1528143984176};\\\", \\\"{x:1727,y:909,t:1528143984191};\\\", \\\"{x:1724,y:883,t:1528143984208};\\\", \\\"{x:1723,y:816,t:1528143984226};\\\", \\\"{x:1723,y:766,t:1528143984242};\\\", \\\"{x:1723,y:737,t:1528143984258};\\\", \\\"{x:1723,y:713,t:1528143984275};\\\", \\\"{x:1730,y:676,t:1528143984291};\\\", \\\"{x:1734,y:656,t:1528143984308};\\\", \\\"{x:1740,y:635,t:1528143984325};\\\", \\\"{x:1745,y:614,t:1528143984341};\\\", \\\"{x:1748,y:597,t:1528143984358};\\\", \\\"{x:1750,y:589,t:1528143984375};\\\", \\\"{x:1750,y:582,t:1528143984392};\\\", \\\"{x:1755,y:575,t:1528143984408};\\\", \\\"{x:1757,y:564,t:1528143984425};\\\", \\\"{x:1757,y:563,t:1528143984441};\\\", \\\"{x:1757,y:562,t:1528143984459};\\\", \\\"{x:1757,y:561,t:1528143984514};\\\", \\\"{x:1756,y:561,t:1528143984525};\\\", \\\"{x:1753,y:562,t:1528143984542};\\\", \\\"{x:1746,y:565,t:1528143984558};\\\", \\\"{x:1739,y:567,t:1528143984575};\\\", \\\"{x:1735,y:567,t:1528143984592};\\\", \\\"{x:1729,y:568,t:1528143984608};\\\", \\\"{x:1725,y:571,t:1528143984625};\\\", \\\"{x:1719,y:573,t:1528143984642};\\\", \\\"{x:1713,y:574,t:1528143984658};\\\", \\\"{x:1707,y:575,t:1528143984675};\\\", \\\"{x:1704,y:576,t:1528143984692};\\\", \\\"{x:1701,y:577,t:1528143984708};\\\", \\\"{x:1699,y:577,t:1528143984725};\\\", \\\"{x:1695,y:577,t:1528143984742};\\\", \\\"{x:1694,y:577,t:1528143984785};\\\", \\\"{x:1693,y:577,t:1528143984801};\\\", \\\"{x:1692,y:577,t:1528143984809};\\\", \\\"{x:1690,y:577,t:1528143984825};\\\", \\\"{x:1687,y:577,t:1528143984842};\\\", \\\"{x:1685,y:577,t:1528143984858};\\\", \\\"{x:1682,y:577,t:1528143984876};\\\", \\\"{x:1681,y:577,t:1528143984893};\\\", \\\"{x:1679,y:576,t:1528143984938};\\\", \\\"{x:1677,y:575,t:1528143984962};\\\", \\\"{x:1677,y:574,t:1528143984978};\\\", \\\"{x:1677,y:573,t:1528143985433};\\\", \\\"{x:1676,y:570,t:1528143985473};\\\", \\\"{x:1674,y:567,t:1528143985513};\\\", \\\"{x:1674,y:566,t:1528143985538};\\\", \\\"{x:1673,y:566,t:1528143985545};\\\", \\\"{x:1673,y:565,t:1528143985562};\\\", \\\"{x:1671,y:563,t:1528143985610};\\\", \\\"{x:1671,y:562,t:1528143985658};\\\", \\\"{x:1670,y:561,t:1528143985673};\\\", \\\"{x:1670,y:560,t:1528143985698};\\\", \\\"{x:1670,y:559,t:1528143985730};\\\", \\\"{x:1670,y:558,t:1528143985753};\\\", \\\"{x:1670,y:557,t:1528143985810};\\\", \\\"{x:1670,y:556,t:1528143985826};\\\", \\\"{x:1670,y:555,t:1528143985890};\\\", \\\"{x:1671,y:555,t:1528143986322};\\\", \\\"{x:1672,y:556,t:1528143986353};\\\", \\\"{x:1672,y:557,t:1528143986370};\\\", \\\"{x:1673,y:557,t:1528143986385};\\\", \\\"{x:1673,y:558,t:1528143986393};\\\", \\\"{x:1674,y:559,t:1528143986530};\\\", \\\"{x:1674,y:560,t:1528143986594};\\\", \\\"{x:1674,y:561,t:1528143986617};\\\", \\\"{x:1674,y:563,t:1528143986666};\\\", \\\"{x:1674,y:564,t:1528143986690};\\\", \\\"{x:1674,y:566,t:1528143986730};\\\", \\\"{x:1674,y:567,t:1528143986746};\\\", \\\"{x:1674,y:569,t:1528143986769};\\\", \\\"{x:1674,y:570,t:1528143986777};\\\", \\\"{x:1674,y:571,t:1528143986793};\\\", \\\"{x:1674,y:572,t:1528143986810};\\\", \\\"{x:1672,y:575,t:1528143986833};\\\", \\\"{x:1672,y:576,t:1528143986858};\\\", \\\"{x:1671,y:577,t:1528143986865};\\\", \\\"{x:1671,y:578,t:1528143986878};\\\", \\\"{x:1671,y:579,t:1528143986893};\\\", \\\"{x:1671,y:580,t:1528143986910};\\\", \\\"{x:1670,y:585,t:1528143986927};\\\", \\\"{x:1670,y:586,t:1528143986943};\\\", \\\"{x:1669,y:588,t:1528143986960};\\\", \\\"{x:1669,y:592,t:1528143986978};\\\", \\\"{x:1669,y:594,t:1528143986994};\\\", \\\"{x:1669,y:596,t:1528143987010};\\\", \\\"{x:1667,y:599,t:1528143987027};\\\", \\\"{x:1667,y:600,t:1528143987043};\\\", \\\"{x:1667,y:604,t:1528143987061};\\\", \\\"{x:1666,y:607,t:1528143987077};\\\", \\\"{x:1665,y:610,t:1528143987093};\\\", \\\"{x:1665,y:612,t:1528143987110};\\\", \\\"{x:1665,y:616,t:1528143987128};\\\", \\\"{x:1665,y:617,t:1528143987144};\\\", \\\"{x:1665,y:619,t:1528143987162};\\\", \\\"{x:1665,y:621,t:1528143987178};\\\", \\\"{x:1665,y:624,t:1528143987193};\\\", \\\"{x:1665,y:627,t:1528143987210};\\\", \\\"{x:1665,y:629,t:1528143987227};\\\", \\\"{x:1665,y:632,t:1528143987245};\\\", \\\"{x:1665,y:637,t:1528143987260};\\\", \\\"{x:1663,y:642,t:1528143987277};\\\", \\\"{x:1663,y:646,t:1528143987294};\\\", \\\"{x:1663,y:651,t:1528143987309};\\\", \\\"{x:1663,y:656,t:1528143987327};\\\", \\\"{x:1663,y:658,t:1528143987344};\\\", \\\"{x:1663,y:662,t:1528143987359};\\\", \\\"{x:1663,y:666,t:1528143987376};\\\", \\\"{x:1664,y:669,t:1528143987393};\\\", \\\"{x:1664,y:673,t:1528143987410};\\\", \\\"{x:1668,y:678,t:1528143987426};\\\", \\\"{x:1668,y:680,t:1528143987444};\\\", \\\"{x:1669,y:684,t:1528143987460};\\\", \\\"{x:1670,y:687,t:1528143987477};\\\", \\\"{x:1671,y:692,t:1528143987494};\\\", \\\"{x:1671,y:696,t:1528143987511};\\\", \\\"{x:1671,y:700,t:1528143987528};\\\", \\\"{x:1671,y:703,t:1528143987544};\\\", \\\"{x:1672,y:708,t:1528143987561};\\\", \\\"{x:1673,y:713,t:1528143987577};\\\", \\\"{x:1673,y:717,t:1528143987594};\\\", \\\"{x:1675,y:720,t:1528143987611};\\\", \\\"{x:1676,y:723,t:1528143987627};\\\", \\\"{x:1676,y:724,t:1528143987645};\\\", \\\"{x:1677,y:728,t:1528143987661};\\\", \\\"{x:1678,y:731,t:1528143987678};\\\", \\\"{x:1679,y:732,t:1528143987695};\\\", \\\"{x:1679,y:734,t:1528143987786};\\\", \\\"{x:1679,y:736,t:1528143987794};\\\", \\\"{x:1679,y:738,t:1528143987812};\\\", \\\"{x:1681,y:743,t:1528143987828};\\\", \\\"{x:1681,y:747,t:1528143987844};\\\", \\\"{x:1681,y:749,t:1528143987861};\\\", \\\"{x:1681,y:754,t:1528143987877};\\\", \\\"{x:1681,y:755,t:1528143987894};\\\", \\\"{x:1681,y:759,t:1528143987912};\\\", \\\"{x:1681,y:763,t:1528143987928};\\\", \\\"{x:1681,y:765,t:1528143987945};\\\", \\\"{x:1680,y:767,t:1528143987961};\\\", \\\"{x:1678,y:770,t:1528143987977};\\\", \\\"{x:1678,y:772,t:1528143987995};\\\", \\\"{x:1677,y:774,t:1528143988011};\\\", \\\"{x:1677,y:778,t:1528143988027};\\\", \\\"{x:1677,y:780,t:1528143988073};\\\", \\\"{x:1676,y:782,t:1528143988082};\\\", \\\"{x:1676,y:783,t:1528143988095};\\\", \\\"{x:1675,y:786,t:1528143988111};\\\", \\\"{x:1674,y:790,t:1528143988128};\\\", \\\"{x:1674,y:794,t:1528143988145};\\\", \\\"{x:1673,y:798,t:1528143988162};\\\", \\\"{x:1673,y:800,t:1528143988178};\\\", \\\"{x:1673,y:803,t:1528143988194};\\\", \\\"{x:1673,y:806,t:1528143988212};\\\", \\\"{x:1673,y:809,t:1528143988228};\\\", \\\"{x:1673,y:811,t:1528143988244};\\\", \\\"{x:1673,y:814,t:1528143988261};\\\", \\\"{x:1673,y:817,t:1528143988279};\\\", \\\"{x:1673,y:819,t:1528143988295};\\\", \\\"{x:1674,y:820,t:1528143988311};\\\", \\\"{x:1674,y:822,t:1528143988328};\\\", \\\"{x:1674,y:823,t:1528143988344};\\\", \\\"{x:1674,y:825,t:1528143988361};\\\", \\\"{x:1674,y:826,t:1528143988385};\\\", \\\"{x:1675,y:828,t:1528143988402};\\\", \\\"{x:1675,y:829,t:1528143988441};\\\", \\\"{x:1676,y:830,t:1528143988449};\\\", \\\"{x:1676,y:832,t:1528143988461};\\\", \\\"{x:1676,y:833,t:1528143988480};\\\", \\\"{x:1676,y:835,t:1528143988495};\\\", \\\"{x:1677,y:837,t:1528143988512};\\\", \\\"{x:1677,y:838,t:1528143988528};\\\", \\\"{x:1677,y:842,t:1528143988545};\\\", \\\"{x:1678,y:846,t:1528143988562};\\\", \\\"{x:1679,y:847,t:1528143988578};\\\", \\\"{x:1679,y:848,t:1528143988595};\\\", \\\"{x:1679,y:851,t:1528143988612};\\\", \\\"{x:1679,y:852,t:1528143988628};\\\", \\\"{x:1679,y:855,t:1528143988646};\\\", \\\"{x:1679,y:857,t:1528143988662};\\\", \\\"{x:1679,y:859,t:1528143988682};\\\", \\\"{x:1679,y:861,t:1528143988695};\\\", \\\"{x:1679,y:863,t:1528143988711};\\\", \\\"{x:1679,y:865,t:1528143988728};\\\", \\\"{x:1679,y:866,t:1528143988778};\\\", \\\"{x:1679,y:868,t:1528143988795};\\\", \\\"{x:1679,y:869,t:1528143988834};\\\", \\\"{x:1678,y:870,t:1528143988846};\\\", \\\"{x:1678,y:871,t:1528143988914};\\\", \\\"{x:1678,y:872,t:1528143988945};\\\", \\\"{x:1677,y:873,t:1528143988978};\\\", \\\"{x:1677,y:874,t:1528143988995};\\\", \\\"{x:1677,y:876,t:1528143989012};\\\", \\\"{x:1676,y:879,t:1528143989028};\\\", \\\"{x:1676,y:882,t:1528143989045};\\\", \\\"{x:1676,y:884,t:1528143989062};\\\", \\\"{x:1676,y:886,t:1528143989079};\\\", \\\"{x:1676,y:887,t:1528143989095};\\\", \\\"{x:1676,y:890,t:1528143989113};\\\", \\\"{x:1675,y:890,t:1528143989128};\\\", \\\"{x:1675,y:893,t:1528143989146};\\\", \\\"{x:1675,y:895,t:1528143989169};\\\", \\\"{x:1675,y:896,t:1528143989179};\\\", \\\"{x:1674,y:901,t:1528143989196};\\\", \\\"{x:1674,y:907,t:1528143989212};\\\", \\\"{x:1674,y:915,t:1528143989228};\\\", \\\"{x:1674,y:916,t:1528143989246};\\\", \\\"{x:1674,y:917,t:1528143989273};\\\", \\\"{x:1674,y:918,t:1528143989346};\\\", \\\"{x:1673,y:918,t:1528143989362};\\\", \\\"{x:1673,y:920,t:1528143989385};\\\", \\\"{x:1673,y:921,t:1528143989395};\\\", \\\"{x:1673,y:922,t:1528143989413};\\\", \\\"{x:1673,y:924,t:1528143989430};\\\", \\\"{x:1673,y:925,t:1528143989445};\\\", \\\"{x:1673,y:926,t:1528143989463};\\\", \\\"{x:1673,y:928,t:1528143989479};\\\", \\\"{x:1673,y:929,t:1528143989498};\\\", \\\"{x:1673,y:930,t:1528143989513};\\\", \\\"{x:1673,y:931,t:1528143989529};\\\", \\\"{x:1673,y:932,t:1528143989545};\\\", \\\"{x:1673,y:933,t:1528143989561};\\\", \\\"{x:1673,y:934,t:1528143989578};\\\", \\\"{x:1673,y:935,t:1528143989595};\\\", \\\"{x:1673,y:930,t:1528143989770};\\\", \\\"{x:1673,y:928,t:1528143989779};\\\", \\\"{x:1676,y:910,t:1528143989797};\\\", \\\"{x:1676,y:905,t:1528143989812};\\\", \\\"{x:1678,y:889,t:1528143989829};\\\", \\\"{x:1680,y:876,t:1528143989846};\\\", \\\"{x:1683,y:858,t:1528143989862};\\\", \\\"{x:1686,y:838,t:1528143989879};\\\", \\\"{x:1690,y:819,t:1528143989896};\\\", \\\"{x:1691,y:800,t:1528143989912};\\\", \\\"{x:1690,y:769,t:1528143989929};\\\", \\\"{x:1690,y:753,t:1528143989946};\\\", \\\"{x:1689,y:742,t:1528143989962};\\\", \\\"{x:1689,y:730,t:1528143989980};\\\", \\\"{x:1689,y:719,t:1528143989996};\\\", \\\"{x:1689,y:707,t:1528143990012};\\\", \\\"{x:1689,y:698,t:1528143990030};\\\", \\\"{x:1688,y:685,t:1528143990047};\\\", \\\"{x:1684,y:673,t:1528143990063};\\\", \\\"{x:1681,y:661,t:1528143990079};\\\", \\\"{x:1680,y:654,t:1528143990096};\\\", \\\"{x:1678,y:641,t:1528143990113};\\\", \\\"{x:1676,y:627,t:1528143990129};\\\", \\\"{x:1676,y:614,t:1528143990146};\\\", \\\"{x:1676,y:606,t:1528143990162};\\\", \\\"{x:1677,y:599,t:1528143990179};\\\", \\\"{x:1677,y:588,t:1528143990196};\\\", \\\"{x:1677,y:580,t:1528143990212};\\\", \\\"{x:1678,y:570,t:1528143990230};\\\", \\\"{x:1678,y:557,t:1528143990246};\\\", \\\"{x:1679,y:549,t:1528143990264};\\\", \\\"{x:1680,y:543,t:1528143990279};\\\", \\\"{x:1681,y:540,t:1528143990296};\\\", \\\"{x:1681,y:531,t:1528143990312};\\\", \\\"{x:1681,y:528,t:1528143990329};\\\", \\\"{x:1681,y:525,t:1528143990346};\\\", \\\"{x:1680,y:522,t:1528143990362};\\\", \\\"{x:1679,y:518,t:1528143990379};\\\", \\\"{x:1679,y:517,t:1528143990396};\\\", \\\"{x:1678,y:515,t:1528143990413};\\\", \\\"{x:1678,y:514,t:1528143990429};\\\", \\\"{x:1678,y:516,t:1528143990690};\\\", \\\"{x:1678,y:518,t:1528143990697};\\\", \\\"{x:1678,y:520,t:1528143990714};\\\", \\\"{x:1680,y:522,t:1528143990729};\\\", \\\"{x:1680,y:525,t:1528143990746};\\\", \\\"{x:1680,y:528,t:1528143990764};\\\", \\\"{x:1680,y:531,t:1528143990780};\\\", \\\"{x:1680,y:533,t:1528143990801};\\\", \\\"{x:1680,y:534,t:1528143990814};\\\", \\\"{x:1680,y:537,t:1528143990830};\\\", \\\"{x:1680,y:540,t:1528143990847};\\\", \\\"{x:1680,y:543,t:1528143990865};\\\", \\\"{x:1680,y:544,t:1528143990881};\\\", \\\"{x:1679,y:546,t:1528143990897};\\\", \\\"{x:1679,y:547,t:1528143990913};\\\", \\\"{x:1679,y:549,t:1528143990938};\\\", \\\"{x:1679,y:550,t:1528143995634};\\\", \\\"{x:1679,y:554,t:1528143995682};\\\", \\\"{x:1679,y:557,t:1528143995690};\\\", \\\"{x:1679,y:559,t:1528143995701};\\\", \\\"{x:1681,y:566,t:1528143995718};\\\", \\\"{x:1681,y:569,t:1528143995734};\\\", \\\"{x:1681,y:573,t:1528143995751};\\\", \\\"{x:1682,y:573,t:1528143995768};\\\", \\\"{x:1683,y:574,t:1528143995784};\\\", \\\"{x:1684,y:574,t:1528143995800};\\\", \\\"{x:1684,y:575,t:1528143995842};\\\", \\\"{x:1684,y:576,t:1528143995882};\\\", \\\"{x:1684,y:577,t:1528143995906};\\\", \\\"{x:1684,y:578,t:1528143995918};\\\", \\\"{x:1684,y:579,t:1528143995934};\\\", \\\"{x:1685,y:582,t:1528143995950};\\\", \\\"{x:1685,y:583,t:1528143995985};\\\", \\\"{x:1686,y:585,t:1528143996098};\\\", \\\"{x:1686,y:586,t:1528143996168};\\\", \\\"{x:1686,y:588,t:1528143996201};\\\", \\\"{x:1686,y:589,t:1528143996225};\\\", \\\"{x:1686,y:591,t:1528143996234};\\\", \\\"{x:1686,y:592,t:1528143996250};\\\", \\\"{x:1687,y:593,t:1528143996267};\\\", \\\"{x:1688,y:595,t:1528143996288};\\\", \\\"{x:1688,y:597,t:1528143996313};\\\", \\\"{x:1688,y:599,t:1528143996321};\\\", \\\"{x:1690,y:601,t:1528143996337};\\\", \\\"{x:1690,y:602,t:1528143996361};\\\", \\\"{x:1690,y:603,t:1528143996377};\\\", \\\"{x:1691,y:605,t:1528143996401};\\\", \\\"{x:1691,y:606,t:1528143996425};\\\", \\\"{x:1691,y:608,t:1528143996435};\\\", \\\"{x:1691,y:610,t:1528143996465};\\\", \\\"{x:1691,y:611,t:1528143996481};\\\", \\\"{x:1691,y:612,t:1528143996490};\\\", \\\"{x:1691,y:613,t:1528143996502};\\\", \\\"{x:1691,y:615,t:1528143996517};\\\", \\\"{x:1691,y:618,t:1528143996535};\\\", \\\"{x:1691,y:621,t:1528143996552};\\\", \\\"{x:1691,y:622,t:1528143996568};\\\", \\\"{x:1691,y:624,t:1528143996585};\\\", \\\"{x:1692,y:627,t:1528143996602};\\\", \\\"{x:1693,y:628,t:1528143996626};\\\", \\\"{x:1693,y:629,t:1528143996641};\\\", \\\"{x:1694,y:630,t:1528143996652};\\\", \\\"{x:1695,y:632,t:1528143996668};\\\", \\\"{x:1695,y:635,t:1528143996684};\\\", \\\"{x:1695,y:638,t:1528143996702};\\\", \\\"{x:1695,y:640,t:1528143996718};\\\", \\\"{x:1694,y:645,t:1528143996735};\\\", \\\"{x:1694,y:647,t:1528143996752};\\\", \\\"{x:1693,y:652,t:1528143996768};\\\", \\\"{x:1690,y:656,t:1528143996785};\\\", \\\"{x:1689,y:659,t:1528143996801};\\\", \\\"{x:1686,y:662,t:1528143996818};\\\", \\\"{x:1686,y:663,t:1528143996835};\\\", \\\"{x:1685,y:667,t:1528143996851};\\\", \\\"{x:1683,y:671,t:1528143996867};\\\", \\\"{x:1683,y:673,t:1528143996884};\\\", \\\"{x:1682,y:677,t:1528143996902};\\\", \\\"{x:1681,y:680,t:1528143996918};\\\", \\\"{x:1680,y:683,t:1528143996935};\\\", \\\"{x:1679,y:685,t:1528143996952};\\\", \\\"{x:1678,y:688,t:1528143996969};\\\", \\\"{x:1676,y:691,t:1528143996985};\\\", \\\"{x:1674,y:695,t:1528143997002};\\\", \\\"{x:1673,y:698,t:1528143997019};\\\", \\\"{x:1672,y:702,t:1528143997035};\\\", \\\"{x:1672,y:704,t:1528143997052};\\\", \\\"{x:1672,y:708,t:1528143997069};\\\", \\\"{x:1672,y:712,t:1528143997085};\\\", \\\"{x:1670,y:717,t:1528143997101};\\\", \\\"{x:1669,y:721,t:1528143997119};\\\", \\\"{x:1668,y:726,t:1528143997136};\\\", \\\"{x:1667,y:729,t:1528143997152};\\\", \\\"{x:1667,y:732,t:1528143997168};\\\", \\\"{x:1665,y:736,t:1528143997184};\\\", \\\"{x:1665,y:743,t:1528143997202};\\\", \\\"{x:1664,y:746,t:1528143997219};\\\", \\\"{x:1663,y:752,t:1528143997235};\\\", \\\"{x:1663,y:755,t:1528143997252};\\\", \\\"{x:1661,y:762,t:1528143997269};\\\", \\\"{x:1660,y:765,t:1528143997285};\\\", \\\"{x:1660,y:768,t:1528143997302};\\\", \\\"{x:1660,y:770,t:1528143997319};\\\", \\\"{x:1658,y:772,t:1528143997335};\\\", \\\"{x:1658,y:774,t:1528143997351};\\\", \\\"{x:1658,y:777,t:1528143997369};\\\", \\\"{x:1657,y:781,t:1528143997386};\\\", \\\"{x:1657,y:784,t:1528143997402};\\\", \\\"{x:1657,y:786,t:1528143997418};\\\", \\\"{x:1656,y:789,t:1528143997435};\\\", \\\"{x:1655,y:790,t:1528143997452};\\\", \\\"{x:1655,y:792,t:1528143997469};\\\", \\\"{x:1654,y:794,t:1528143997486};\\\", \\\"{x:1653,y:796,t:1528143997502};\\\", \\\"{x:1653,y:798,t:1528143997519};\\\", \\\"{x:1653,y:800,t:1528143997536};\\\", \\\"{x:1651,y:802,t:1528143997552};\\\", \\\"{x:1651,y:803,t:1528143997569};\\\", \\\"{x:1651,y:804,t:1528143997585};\\\", \\\"{x:1650,y:806,t:1528143997602};\\\", \\\"{x:1649,y:809,t:1528143997619};\\\", \\\"{x:1649,y:812,t:1528143997636};\\\", \\\"{x:1649,y:813,t:1528143997652};\\\", \\\"{x:1649,y:819,t:1528143997669};\\\", \\\"{x:1647,y:824,t:1528143997686};\\\", \\\"{x:1647,y:828,t:1528143997701};\\\", \\\"{x:1647,y:831,t:1528143997718};\\\", \\\"{x:1646,y:835,t:1528143997736};\\\", \\\"{x:1646,y:841,t:1528143997752};\\\", \\\"{x:1646,y:842,t:1528143997769};\\\", \\\"{x:1646,y:845,t:1528143997786};\\\", \\\"{x:1646,y:846,t:1528143997803};\\\", \\\"{x:1646,y:848,t:1528143997819};\\\", \\\"{x:1642,y:846,t:1528143998041};\\\", \\\"{x:1637,y:840,t:1528143998053};\\\", \\\"{x:1622,y:818,t:1528143998069};\\\", \\\"{x:1605,y:793,t:1528143998086};\\\", \\\"{x:1592,y:774,t:1528143998103};\\\", \\\"{x:1574,y:754,t:1528143998119};\\\", \\\"{x:1562,y:745,t:1528143998136};\\\", \\\"{x:1535,y:724,t:1528143998153};\\\", \\\"{x:1463,y:678,t:1528143998169};\\\", \\\"{x:1418,y:649,t:1528143998186};\\\", \\\"{x:1390,y:625,t:1528143998203};\\\", \\\"{x:1364,y:605,t:1528143998219};\\\", \\\"{x:1350,y:590,t:1528143998236};\\\", \\\"{x:1312,y:567,t:1528143998253};\\\", \\\"{x:1273,y:542,t:1528143998270};\\\", \\\"{x:1253,y:521,t:1528143998285};\\\", \\\"{x:1248,y:511,t:1528143998303};\\\", \\\"{x:1220,y:497,t:1528143998320};\\\", \\\"{x:1193,y:478,t:1528143998336};\\\", \\\"{x:1163,y:457,t:1528143998353};\\\", \\\"{x:1150,y:450,t:1528143998369};\\\", \\\"{x:1145,y:442,t:1528143998386};\\\", \\\"{x:1137,y:438,t:1528143998403};\\\", \\\"{x:1126,y:432,t:1528143998420};\\\", \\\"{x:1111,y:426,t:1528143998435};\\\", \\\"{x:1091,y:417,t:1528143998453};\\\", \\\"{x:1076,y:410,t:1528143998470};\\\", \\\"{x:1069,y:405,t:1528143998486};\\\", \\\"{x:1062,y:400,t:1528143998503};\\\", \\\"{x:1059,y:397,t:1528143998519};\\\", \\\"{x:1058,y:396,t:1528143998535};\\\", \\\"{x:1058,y:395,t:1528143998682};\\\", \\\"{x:1058,y:394,t:1528143998738};\\\", \\\"{x:1058,y:393,t:1528143998761};\\\", \\\"{x:1058,y:392,t:1528143998777};\\\", \\\"{x:1058,y:391,t:1528143998801};\\\", \\\"{x:1058,y:389,t:1528143998810};\\\", \\\"{x:1058,y:388,t:1528143998820};\\\", \\\"{x:1058,y:387,t:1528143998837};\\\", \\\"{x:1058,y:385,t:1528143998853};\\\", \\\"{x:1058,y:384,t:1528143998889};\\\", \\\"{x:1058,y:383,t:1528143998978};\\\", \\\"{x:1056,y:382,t:1528143998987};\\\", \\\"{x:1056,y:380,t:1528143999003};\\\", \\\"{x:1055,y:379,t:1528143999020};\\\", \\\"{x:1055,y:376,t:1528143999037};\\\", \\\"{x:1055,y:375,t:1528143999065};\\\", \\\"{x:1055,y:374,t:1528143999074};\\\", \\\"{x:1055,y:372,t:1528143999097};\\\", \\\"{x:1056,y:370,t:1528143999105};\\\", \\\"{x:1057,y:370,t:1528143999120};\\\", \\\"{x:1061,y:369,t:1528143999137};\\\", \\\"{x:1063,y:369,t:1528143999153};\\\", \\\"{x:1069,y:365,t:1528143999170};\\\", \\\"{x:1076,y:364,t:1528143999187};\\\", \\\"{x:1082,y:361,t:1528143999204};\\\", \\\"{x:1088,y:361,t:1528143999220};\\\", \\\"{x:1096,y:361,t:1528143999237};\\\", \\\"{x:1105,y:361,t:1528143999254};\\\", \\\"{x:1116,y:361,t:1528143999270};\\\", \\\"{x:1123,y:361,t:1528143999287};\\\", \\\"{x:1133,y:362,t:1528143999304};\\\", \\\"{x:1138,y:367,t:1528143999320};\\\", \\\"{x:1139,y:368,t:1528143999337};\\\", \\\"{x:1139,y:369,t:1528143999354};\\\", \\\"{x:1140,y:369,t:1528143999489};\\\", \\\"{x:1139,y:378,t:1528143999503};\\\", \\\"{x:1136,y:418,t:1528143999520};\\\", \\\"{x:1126,y:559,t:1528143999537};\\\", \\\"{x:1126,y:639,t:1528143999554};\\\", \\\"{x:1126,y:692,t:1528143999571};\\\", \\\"{x:1130,y:750,t:1528143999587};\\\", \\\"{x:1134,y:789,t:1528143999604};\\\", \\\"{x:1147,y:816,t:1528143999621};\\\", \\\"{x:1156,y:832,t:1528143999637};\\\", \\\"{x:1162,y:851,t:1528143999654};\\\", \\\"{x:1180,y:895,t:1528143999671};\\\", \\\"{x:1204,y:930,t:1528143999687};\\\", \\\"{x:1232,y:944,t:1528143999704};\\\", \\\"{x:1279,y:945,t:1528143999721};\\\", \\\"{x:1295,y:946,t:1528143999738};\\\", \\\"{x:1335,y:950,t:1528143999754};\\\", \\\"{x:1381,y:965,t:1528143999771};\\\", \\\"{x:1416,y:983,t:1528143999787};\\\", \\\"{x:1436,y:998,t:1528143999804};\\\", \\\"{x:1454,y:1005,t:1528143999821};\\\", \\\"{x:1464,y:1012,t:1528143999836};\\\", \\\"{x:1467,y:1016,t:1528143999854};\\\", \\\"{x:1469,y:1016,t:1528143999871};\\\", \\\"{x:1470,y:1015,t:1528143999922};\\\", \\\"{x:1470,y:1007,t:1528143999937};\\\", \\\"{x:1470,y:993,t:1528143999954};\\\", \\\"{x:1471,y:986,t:1528143999971};\\\", \\\"{x:1473,y:984,t:1528143999987};\\\", \\\"{x:1478,y:976,t:1528144000004};\\\", \\\"{x:1481,y:969,t:1528144000021};\\\", \\\"{x:1483,y:964,t:1528144000038};\\\", \\\"{x:1485,y:961,t:1528144000058};\\\", \\\"{x:1485,y:960,t:1528144000071};\\\", \\\"{x:1486,y:958,t:1528144000088};\\\", \\\"{x:1487,y:957,t:1528144000104};\\\", \\\"{x:1492,y:953,t:1528144000122};\\\", \\\"{x:1493,y:952,t:1528144000137};\\\", \\\"{x:1495,y:950,t:1528144000162};\\\", \\\"{x:1496,y:949,t:1528144000177};\\\", \\\"{x:1497,y:948,t:1528144000225};\\\", \\\"{x:1498,y:952,t:1528144001210};\\\", \\\"{x:1498,y:955,t:1528144001222};\\\", \\\"{x:1500,y:959,t:1528144001238};\\\", \\\"{x:1502,y:962,t:1528144001255};\\\", \\\"{x:1503,y:966,t:1528144001272};\\\", \\\"{x:1505,y:968,t:1528144001288};\\\", \\\"{x:1505,y:969,t:1528144001305};\\\", \\\"{x:1506,y:969,t:1528144001323};\\\", \\\"{x:1506,y:970,t:1528144001338};\\\", \\\"{x:1506,y:971,t:1528144001626};\\\", \\\"{x:1503,y:970,t:1528144001650};\\\", \\\"{x:1503,y:969,t:1528144001690};\\\", \\\"{x:1503,y:968,t:1528144001777};\\\", \\\"{x:1503,y:966,t:1528144001789};\\\", \\\"{x:1500,y:963,t:1528144001806};\\\", \\\"{x:1497,y:961,t:1528144001822};\\\", \\\"{x:1496,y:960,t:1528144001839};\\\", \\\"{x:1496,y:959,t:1528144001946};\\\", \\\"{x:1496,y:957,t:1528144001962};\\\", \\\"{x:1495,y:956,t:1528144001972};\\\", \\\"{x:1493,y:952,t:1528144001989};\\\", \\\"{x:1493,y:949,t:1528144002006};\\\", \\\"{x:1493,y:945,t:1528144002022};\\\", \\\"{x:1492,y:938,t:1528144002039};\\\", \\\"{x:1490,y:933,t:1528144002057};\\\", \\\"{x:1489,y:930,t:1528144002072};\\\", \\\"{x:1489,y:922,t:1528144002088};\\\", \\\"{x:1489,y:920,t:1528144002105};\\\", \\\"{x:1489,y:918,t:1528144002121};\\\", \\\"{x:1488,y:916,t:1528144002138};\\\", \\\"{x:1488,y:913,t:1528144002156};\\\", \\\"{x:1488,y:911,t:1528144002176};\\\", \\\"{x:1486,y:908,t:1528144002188};\\\", \\\"{x:1485,y:905,t:1528144002205};\\\", \\\"{x:1484,y:898,t:1528144002222};\\\", \\\"{x:1482,y:894,t:1528144002239};\\\", \\\"{x:1481,y:885,t:1528144002255};\\\", \\\"{x:1478,y:872,t:1528144002272};\\\", \\\"{x:1477,y:870,t:1528144002288};\\\", \\\"{x:1476,y:867,t:1528144002306};\\\", \\\"{x:1474,y:865,t:1528144002323};\\\", \\\"{x:1474,y:864,t:1528144002339};\\\", \\\"{x:1474,y:862,t:1528144002394};\\\", \\\"{x:1474,y:861,t:1528144002406};\\\", \\\"{x:1474,y:857,t:1528144002423};\\\", \\\"{x:1474,y:855,t:1528144002438};\\\", \\\"{x:1474,y:854,t:1528144002457};\\\", \\\"{x:1474,y:850,t:1528144002474};\\\", \\\"{x:1474,y:846,t:1528144002489};\\\", \\\"{x:1474,y:842,t:1528144002506};\\\", \\\"{x:1474,y:840,t:1528144002523};\\\", \\\"{x:1474,y:836,t:1528144002539};\\\", \\\"{x:1474,y:832,t:1528144002556};\\\", \\\"{x:1474,y:830,t:1528144002573};\\\", \\\"{x:1474,y:829,t:1528144002589};\\\", \\\"{x:1474,y:827,t:1528144002606};\\\", \\\"{x:1474,y:826,t:1528144002623};\\\", \\\"{x:1474,y:825,t:1528144002639};\\\", \\\"{x:1474,y:824,t:1528144002656};\\\", \\\"{x:1474,y:822,t:1528144002689};\\\", \\\"{x:1475,y:822,t:1528144002707};\\\", \\\"{x:1475,y:820,t:1528144002745};\\\", \\\"{x:1475,y:819,t:1528144002801};\\\", \\\"{x:1475,y:817,t:1528144002826};\\\", \\\"{x:1475,y:816,t:1528144002858};\\\", \\\"{x:1475,y:814,t:1528144002874};\\\", \\\"{x:1475,y:813,t:1528144002891};\\\", \\\"{x:1477,y:811,t:1528144002906};\\\", \\\"{x:1477,y:809,t:1528144002924};\\\", \\\"{x:1477,y:806,t:1528144002940};\\\", \\\"{x:1477,y:804,t:1528144002956};\\\", \\\"{x:1477,y:801,t:1528144002973};\\\", \\\"{x:1478,y:798,t:1528144002990};\\\", \\\"{x:1478,y:796,t:1528144003006};\\\", \\\"{x:1478,y:794,t:1528144003023};\\\", \\\"{x:1478,y:790,t:1528144003041};\\\", \\\"{x:1478,y:787,t:1528144003056};\\\", \\\"{x:1479,y:780,t:1528144003073};\\\", \\\"{x:1479,y:776,t:1528144003089};\\\", \\\"{x:1479,y:771,t:1528144003106};\\\", \\\"{x:1479,y:764,t:1528144003123};\\\", \\\"{x:1479,y:761,t:1528144003140};\\\", \\\"{x:1479,y:757,t:1528144003157};\\\", \\\"{x:1479,y:749,t:1528144003172};\\\", \\\"{x:1479,y:741,t:1528144003190};\\\", \\\"{x:1481,y:732,t:1528144003206};\\\", \\\"{x:1481,y:725,t:1528144003222};\\\", \\\"{x:1481,y:720,t:1528144003239};\\\", \\\"{x:1481,y:713,t:1528144003257};\\\", \\\"{x:1481,y:708,t:1528144003272};\\\", \\\"{x:1481,y:702,t:1528144003290};\\\", \\\"{x:1481,y:696,t:1528144003306};\\\", \\\"{x:1481,y:694,t:1528144003322};\\\", \\\"{x:1481,y:690,t:1528144003339};\\\", \\\"{x:1481,y:686,t:1528144003356};\\\", \\\"{x:1480,y:683,t:1528144003372};\\\", \\\"{x:1480,y:680,t:1528144003390};\\\", \\\"{x:1480,y:679,t:1528144003406};\\\", \\\"{x:1480,y:678,t:1528144003422};\\\", \\\"{x:1478,y:680,t:1528144003833};\\\", \\\"{x:1477,y:686,t:1528144003840};\\\", \\\"{x:1473,y:702,t:1528144003856};\\\", \\\"{x:1472,y:721,t:1528144003874};\\\", \\\"{x:1470,y:732,t:1528144003889};\\\", \\\"{x:1466,y:753,t:1528144003906};\\\", \\\"{x:1462,y:774,t:1528144003924};\\\", \\\"{x:1461,y:795,t:1528144003939};\\\", \\\"{x:1457,y:819,t:1528144003956};\\\", \\\"{x:1453,y:847,t:1528144003974};\\\", \\\"{x:1445,y:868,t:1528144003991};\\\", \\\"{x:1443,y:881,t:1528144004007};\\\", \\\"{x:1442,y:892,t:1528144004023};\\\", \\\"{x:1444,y:907,t:1528144004040};\\\", \\\"{x:1445,y:917,t:1528144004056};\\\", \\\"{x:1445,y:930,t:1528144004073};\\\", \\\"{x:1445,y:940,t:1528144004090};\\\", \\\"{x:1445,y:945,t:1528144004106};\\\", \\\"{x:1447,y:951,t:1528144004123};\\\", \\\"{x:1448,y:955,t:1528144004141};\\\", \\\"{x:1449,y:958,t:1528144004157};\\\", \\\"{x:1449,y:961,t:1528144004174};\\\", \\\"{x:1449,y:962,t:1528144004191};\\\", \\\"{x:1449,y:964,t:1528144004207};\\\", \\\"{x:1449,y:966,t:1528144004224};\\\", \\\"{x:1449,y:968,t:1528144004241};\\\", \\\"{x:1449,y:969,t:1528144004289};\\\", \\\"{x:1449,y:967,t:1528144004466};\\\", \\\"{x:1449,y:965,t:1528144004474};\\\", \\\"{x:1450,y:962,t:1528144004491};\\\", \\\"{x:1452,y:957,t:1528144004509};\\\", \\\"{x:1453,y:954,t:1528144004524};\\\", \\\"{x:1453,y:951,t:1528144004541};\\\", \\\"{x:1454,y:946,t:1528144004557};\\\", \\\"{x:1454,y:942,t:1528144004574};\\\", \\\"{x:1457,y:936,t:1528144004590};\\\", \\\"{x:1457,y:933,t:1528144004607};\\\", \\\"{x:1457,y:929,t:1528144004623};\\\", \\\"{x:1457,y:924,t:1528144004640};\\\", \\\"{x:1457,y:920,t:1528144004658};\\\", \\\"{x:1457,y:914,t:1528144004674};\\\", \\\"{x:1457,y:906,t:1528144004691};\\\", \\\"{x:1457,y:899,t:1528144004708};\\\", \\\"{x:1457,y:894,t:1528144004724};\\\", \\\"{x:1460,y:890,t:1528144004741};\\\", \\\"{x:1460,y:882,t:1528144004758};\\\", \\\"{x:1460,y:876,t:1528144004774};\\\", \\\"{x:1460,y:869,t:1528144004792};\\\", \\\"{x:1461,y:864,t:1528144004808};\\\", \\\"{x:1461,y:859,t:1528144004824};\\\", \\\"{x:1464,y:851,t:1528144004841};\\\", \\\"{x:1464,y:848,t:1528144004858};\\\", \\\"{x:1464,y:844,t:1528144004874};\\\", \\\"{x:1465,y:840,t:1528144004892};\\\", \\\"{x:1466,y:837,t:1528144004908};\\\", \\\"{x:1467,y:833,t:1528144004925};\\\", \\\"{x:1468,y:826,t:1528144004941};\\\", \\\"{x:1468,y:821,t:1528144004959};\\\", \\\"{x:1470,y:815,t:1528144004975};\\\", \\\"{x:1472,y:806,t:1528144004991};\\\", \\\"{x:1473,y:798,t:1528144005008};\\\", \\\"{x:1477,y:783,t:1528144005025};\\\", \\\"{x:1477,y:774,t:1528144005041};\\\", \\\"{x:1478,y:769,t:1528144005058};\\\", \\\"{x:1479,y:761,t:1528144005075};\\\", \\\"{x:1479,y:756,t:1528144005091};\\\", \\\"{x:1479,y:751,t:1528144005108};\\\", \\\"{x:1479,y:746,t:1528144005125};\\\", \\\"{x:1479,y:742,t:1528144005141};\\\", \\\"{x:1479,y:736,t:1528144005158};\\\", \\\"{x:1479,y:728,t:1528144005175};\\\", \\\"{x:1479,y:723,t:1528144005192};\\\", \\\"{x:1479,y:719,t:1528144005208};\\\", \\\"{x:1477,y:714,t:1528144005226};\\\", \\\"{x:1476,y:712,t:1528144005241};\\\", \\\"{x:1476,y:711,t:1528144005298};\\\", \\\"{x:1476,y:710,t:1528144005308};\\\", \\\"{x:1476,y:709,t:1528144005325};\\\", \\\"{x:1476,y:708,t:1528144005341};\\\", \\\"{x:1474,y:706,t:1528144005361};\\\", \\\"{x:1474,y:704,t:1528144005385};\\\", \\\"{x:1473,y:702,t:1528144005402};\\\", \\\"{x:1473,y:701,t:1528144005417};\\\", \\\"{x:1473,y:700,t:1528144005426};\\\", \\\"{x:1473,y:699,t:1528144005449};\\\", \\\"{x:1473,y:698,t:1528144005465};\\\", \\\"{x:1473,y:696,t:1528144005482};\\\", \\\"{x:1472,y:695,t:1528144005522};\\\", \\\"{x:1462,y:692,t:1528144006530};\\\", \\\"{x:1451,y:690,t:1528144006543};\\\", \\\"{x:1370,y:674,t:1528144006559};\\\", \\\"{x:1270,y:658,t:1528144006576};\\\", \\\"{x:1130,y:621,t:1528144006592};\\\", \\\"{x:950,y:573,t:1528144006609};\\\", \\\"{x:823,y:539,t:1528144006628};\\\", \\\"{x:716,y:511,t:1528144006643};\\\", \\\"{x:615,y:482,t:1528144006676};\\\", \\\"{x:610,y:481,t:1528144006694};\\\", \\\"{x:608,y:481,t:1528144006737};\\\", \\\"{x:605,y:481,t:1528144006744};\\\", \\\"{x:600,y:481,t:1528144006761};\\\", \\\"{x:597,y:481,t:1528144006778};\\\", \\\"{x:586,y:481,t:1528144006794};\\\", \\\"{x:577,y:481,t:1528144006810};\\\", \\\"{x:568,y:482,t:1528144006828};\\\", \\\"{x:565,y:483,t:1528144006844};\\\", \\\"{x:561,y:484,t:1528144006882};\\\", \\\"{x:559,y:487,t:1528144006897};\\\", \\\"{x:558,y:487,t:1528144006911};\\\", \\\"{x:558,y:492,t:1528144006928};\\\", \\\"{x:553,y:501,t:1528144006945};\\\", \\\"{x:548,y:513,t:1528144006961};\\\", \\\"{x:540,y:528,t:1528144006977};\\\", \\\"{x:526,y:545,t:1528144006995};\\\", \\\"{x:516,y:557,t:1528144007011};\\\", \\\"{x:497,y:569,t:1528144007028};\\\", \\\"{x:481,y:576,t:1528144007045};\\\", \\\"{x:475,y:578,t:1528144007061};\\\", \\\"{x:463,y:583,t:1528144007077};\\\", \\\"{x:448,y:588,t:1528144007095};\\\", \\\"{x:433,y:591,t:1528144007110};\\\", \\\"{x:419,y:591,t:1528144007127};\\\", \\\"{x:402,y:591,t:1528144007144};\\\", \\\"{x:392,y:589,t:1528144007161};\\\", \\\"{x:385,y:588,t:1528144007177};\\\", \\\"{x:383,y:588,t:1528144007195};\\\", \\\"{x:375,y:587,t:1528144007210};\\\", \\\"{x:366,y:587,t:1528144007227};\\\", \\\"{x:358,y:584,t:1528144007245};\\\", \\\"{x:352,y:582,t:1528144007260};\\\", \\\"{x:345,y:582,t:1528144007277};\\\", \\\"{x:340,y:582,t:1528144007294};\\\", \\\"{x:334,y:579,t:1528144007311};\\\", \\\"{x:330,y:578,t:1528144007328};\\\", \\\"{x:314,y:578,t:1528144007345};\\\", \\\"{x:308,y:578,t:1528144007362};\\\", \\\"{x:293,y:578,t:1528144007377};\\\", \\\"{x:281,y:578,t:1528144007395};\\\", \\\"{x:263,y:578,t:1528144007412};\\\", \\\"{x:248,y:578,t:1528144007428};\\\", \\\"{x:227,y:578,t:1528144007444};\\\", \\\"{x:215,y:578,t:1528144007462};\\\", \\\"{x:204,y:578,t:1528144007478};\\\", \\\"{x:198,y:580,t:1528144007495};\\\", \\\"{x:192,y:581,t:1528144007512};\\\", \\\"{x:185,y:581,t:1528144007527};\\\", \\\"{x:175,y:584,t:1528144007544};\\\", \\\"{x:170,y:586,t:1528144007562};\\\", \\\"{x:163,y:587,t:1528144007578};\\\", \\\"{x:150,y:590,t:1528144007595};\\\", \\\"{x:139,y:592,t:1528144007613};\\\", \\\"{x:133,y:594,t:1528144007628};\\\", \\\"{x:129,y:594,t:1528144007644};\\\", \\\"{x:126,y:595,t:1528144007662};\\\", \\\"{x:126,y:596,t:1528144007678};\\\", \\\"{x:125,y:596,t:1528144007695};\\\", \\\"{x:125,y:597,t:1528144007712};\\\", \\\"{x:124,y:598,t:1528144007793};\\\", \\\"{x:124,y:599,t:1528144007809};\\\", \\\"{x:124,y:600,t:1528144007841};\\\", \\\"{x:124,y:601,t:1528144007865};\\\", \\\"{x:125,y:603,t:1528144007881};\\\", \\\"{x:128,y:604,t:1528144007895};\\\", \\\"{x:135,y:607,t:1528144007912};\\\", \\\"{x:140,y:609,t:1528144007930};\\\", \\\"{x:143,y:611,t:1528144007945};\\\", \\\"{x:144,y:611,t:1528144007962};\\\", \\\"{x:146,y:611,t:1528144007979};\\\", \\\"{x:147,y:611,t:1528144007994};\\\", \\\"{x:154,y:611,t:1528144008012};\\\", \\\"{x:160,y:611,t:1528144008029};\\\", \\\"{x:168,y:614,t:1528144008045};\\\", \\\"{x:174,y:614,t:1528144008061};\\\", \\\"{x:185,y:614,t:1528144008079};\\\", \\\"{x:196,y:614,t:1528144008096};\\\", \\\"{x:206,y:614,t:1528144008112};\\\", \\\"{x:220,y:614,t:1528144008129};\\\", \\\"{x:222,y:614,t:1528144008145};\\\", \\\"{x:226,y:614,t:1528144008162};\\\", \\\"{x:231,y:614,t:1528144008179};\\\", \\\"{x:238,y:614,t:1528144008196};\\\", \\\"{x:259,y:614,t:1528144008212};\\\", \\\"{x:282,y:613,t:1528144008229};\\\", \\\"{x:312,y:612,t:1528144008246};\\\", \\\"{x:339,y:612,t:1528144008262};\\\", \\\"{x:365,y:612,t:1528144008279};\\\", \\\"{x:393,y:612,t:1528144008296};\\\", \\\"{x:417,y:612,t:1528144008312};\\\", \\\"{x:450,y:612,t:1528144008329};\\\", \\\"{x:468,y:612,t:1528144008346};\\\", \\\"{x:487,y:612,t:1528144008361};\\\", \\\"{x:494,y:612,t:1528144008379};\\\", \\\"{x:500,y:612,t:1528144008396};\\\", \\\"{x:510,y:612,t:1528144008412};\\\", \\\"{x:516,y:612,t:1528144008429};\\\", \\\"{x:523,y:612,t:1528144008447};\\\", \\\"{x:538,y:612,t:1528144008463};\\\", \\\"{x:550,y:612,t:1528144008479};\\\", \\\"{x:558,y:612,t:1528144008497};\\\", \\\"{x:566,y:610,t:1528144008513};\\\", \\\"{x:573,y:608,t:1528144008529};\\\", \\\"{x:579,y:605,t:1528144008548};\\\", \\\"{x:586,y:604,t:1528144008563};\\\", \\\"{x:595,y:601,t:1528144008579};\\\", \\\"{x:601,y:599,t:1528144008596};\\\", \\\"{x:603,y:598,t:1528144008611};\\\", \\\"{x:604,y:597,t:1528144008628};\\\", \\\"{x:613,y:593,t:1528144008645};\\\", \\\"{x:621,y:589,t:1528144008661};\\\", \\\"{x:627,y:585,t:1528144008679};\\\", \\\"{x:633,y:583,t:1528144008696};\\\", \\\"{x:644,y:579,t:1528144008712};\\\", \\\"{x:652,y:577,t:1528144008729};\\\", \\\"{x:659,y:575,t:1528144008746};\\\", \\\"{x:667,y:572,t:1528144008762};\\\", \\\"{x:672,y:571,t:1528144008779};\\\", \\\"{x:676,y:569,t:1528144008797};\\\", \\\"{x:684,y:566,t:1528144008813};\\\", \\\"{x:694,y:564,t:1528144008829};\\\", \\\"{x:703,y:562,t:1528144008846};\\\", \\\"{x:716,y:562,t:1528144008863};\\\", \\\"{x:734,y:562,t:1528144008880};\\\", \\\"{x:749,y:562,t:1528144008895};\\\", \\\"{x:767,y:562,t:1528144008912};\\\", \\\"{x:778,y:563,t:1528144008928};\\\", \\\"{x:788,y:565,t:1528144008945};\\\", \\\"{x:796,y:566,t:1528144008962};\\\", \\\"{x:800,y:567,t:1528144008979};\\\", \\\"{x:801,y:567,t:1528144008995};\\\", \\\"{x:802,y:567,t:1528144009033};\\\", \\\"{x:803,y:567,t:1528144009048};\\\", \\\"{x:804,y:567,t:1528144009063};\\\", \\\"{x:806,y:567,t:1528144009079};\\\", \\\"{x:809,y:567,t:1528144009096};\\\", \\\"{x:815,y:565,t:1528144009113};\\\", \\\"{x:819,y:563,t:1528144009130};\\\", \\\"{x:824,y:560,t:1528144009147};\\\", \\\"{x:827,y:559,t:1528144009162};\\\", \\\"{x:829,y:556,t:1528144009179};\\\", \\\"{x:832,y:554,t:1528144009196};\\\", \\\"{x:834,y:552,t:1528144009213};\\\", \\\"{x:836,y:549,t:1528144009230};\\\", \\\"{x:836,y:546,t:1528144009246};\\\", \\\"{x:837,y:544,t:1528144009263};\\\", \\\"{x:838,y:542,t:1528144009280};\\\", \\\"{x:839,y:541,t:1528144009297};\\\", \\\"{x:840,y:538,t:1528144009313};\\\", \\\"{x:840,y:535,t:1528144009330};\\\", \\\"{x:841,y:531,t:1528144009346};\\\", \\\"{x:841,y:530,t:1528144009363};\\\", \\\"{x:841,y:528,t:1528144009380};\\\", \\\"{x:841,y:527,t:1528144009396};\\\", \\\"{x:841,y:524,t:1528144009413};\\\", \\\"{x:841,y:522,t:1528144009440};\\\", \\\"{x:841,y:521,t:1528144009448};\\\", \\\"{x:841,y:520,t:1528144009465};\\\", \\\"{x:841,y:519,t:1528144009480};\\\", \\\"{x:839,y:518,t:1528144009496};\\\", \\\"{x:839,y:517,t:1528144012010};\\\", \\\"{x:834,y:518,t:1528144012017};\\\", \\\"{x:827,y:523,t:1528144012032};\\\", \\\"{x:814,y:531,t:1528144012049};\\\", \\\"{x:801,y:550,t:1528144012067};\\\", \\\"{x:785,y:574,t:1528144012098};\\\", \\\"{x:775,y:586,t:1528144012115};\\\", \\\"{x:768,y:596,t:1528144012132};\\\", \\\"{x:760,y:611,t:1528144012149};\\\", \\\"{x:747,y:628,t:1528144012165};\\\", \\\"{x:738,y:639,t:1528144012181};\\\", \\\"{x:729,y:648,t:1528144012199};\\\", \\\"{x:717,y:659,t:1528144012215};\\\", \\\"{x:703,y:670,t:1528144012232};\\\", \\\"{x:691,y:680,t:1528144012248};\\\", \\\"{x:673,y:695,t:1528144012265};\\\", \\\"{x:657,y:707,t:1528144012282};\\\", \\\"{x:643,y:716,t:1528144012298};\\\", \\\"{x:622,y:724,t:1528144012315};\\\", \\\"{x:599,y:733,t:1528144012331};\\\", \\\"{x:587,y:740,t:1528144012348};\\\", \\\"{x:575,y:745,t:1528144012365};\\\", \\\"{x:557,y:750,t:1528144012382};\\\", \\\"{x:549,y:755,t:1528144012399};\\\", \\\"{x:543,y:755,t:1528144012415};\\\", \\\"{x:538,y:758,t:1528144012432};\\\", \\\"{x:529,y:762,t:1528144012448};\\\", \\\"{x:523,y:763,t:1528144012466};\\\", \\\"{x:521,y:764,t:1528144012482};\\\", \\\"{x:520,y:764,t:1528144012499};\\\", \\\"{x:519,y:765,t:1528144012516};\\\", \\\"{x:519,y:766,t:1528144012533};\\\", \\\"{x:518,y:766,t:1528144013106};\\\", \\\"{x:528,y:769,t:1528144015363};\\\", \\\"{x:546,y:770,t:1528144015372};\\\", \\\"{x:601,y:785,t:1528144015389};\\\", \\\"{x:666,y:797,t:1528144015401};\\\", \\\"{x:731,y:811,t:1528144015418};\\\", \\\"{x:813,y:828,t:1528144015434};\\\", \\\"{x:903,y:843,t:1528144015451};\\\", \\\"{x:992,y:856,t:1528144015468};\\\", \\\"{x:1046,y:859,t:1528144015484};\\\", \\\"{x:1077,y:859,t:1528144015501};\\\", \\\"{x:1093,y:860,t:1528144015518};\\\", \\\"{x:1114,y:860,t:1528144015535};\\\", \\\"{x:1120,y:860,t:1528144015551};\\\", \\\"{x:1127,y:860,t:1528144015568};\\\", \\\"{x:1131,y:860,t:1528144015584};\\\", \\\"{x:1133,y:860,t:1528144015601};\\\", \\\"{x:1134,y:859,t:1528144015619};\\\", \\\"{x:1135,y:858,t:1528144015635};\\\", \\\"{x:1135,y:857,t:1528144015713};\\\", \\\"{x:1135,y:856,t:1528144015721};\\\", \\\"{x:1135,y:854,t:1528144015737};\\\", \\\"{x:1135,y:851,t:1528144015752};\\\", \\\"{x:1134,y:845,t:1528144015769};\\\", \\\"{x:1130,y:840,t:1528144015785};\\\", \\\"{x:1126,y:837,t:1528144015801};\\\", \\\"{x:1122,y:832,t:1528144015819};\\\", \\\"{x:1119,y:827,t:1528144015835};\\\", \\\"{x:1116,y:824,t:1528144015852};\\\", \\\"{x:1113,y:822,t:1528144015869};\\\", \\\"{x:1111,y:820,t:1528144015885};\\\", \\\"{x:1109,y:818,t:1528144015902};\\\", \\\"{x:1108,y:817,t:1528144015918};\\\", \\\"{x:1107,y:815,t:1528144015936};\\\", \\\"{x:1106,y:815,t:1528144015986};\\\", \\\"{x:1105,y:815,t:1528144016009};\\\", \\\"{x:1104,y:815,t:1528144016081};\\\", \\\"{x:1104,y:813,t:1528144016226};\\\", \\\"{x:1110,y:813,t:1528144016236};\\\", \\\"{x:1115,y:810,t:1528144016253};\\\", \\\"{x:1120,y:810,t:1528144016268};\\\", \\\"{x:1137,y:809,t:1528144016286};\\\", \\\"{x:1153,y:807,t:1528144016303};\\\", \\\"{x:1163,y:806,t:1528144016318};\\\", \\\"{x:1183,y:806,t:1528144016336};\\\", \\\"{x:1222,y:806,t:1528144016352};\\\", \\\"{x:1238,y:807,t:1528144016368};\\\", \\\"{x:1263,y:813,t:1528144016386};\\\", \\\"{x:1312,y:824,t:1528144016402};\\\", \\\"{x:1342,y:835,t:1528144016418};\\\", \\\"{x:1378,y:847,t:1528144016435};\\\", \\\"{x:1425,y:861,t:1528144016453};\\\", \\\"{x:1453,y:869,t:1528144016469};\\\", \\\"{x:1476,y:878,t:1528144016486};\\\", \\\"{x:1494,y:884,t:1528144016502};\\\", \\\"{x:1510,y:886,t:1528144016520};\\\", \\\"{x:1519,y:888,t:1528144016536};\\\", \\\"{x:1527,y:891,t:1528144016553};\\\", \\\"{x:1530,y:892,t:1528144016569};\\\", \\\"{x:1532,y:893,t:1528144016585};\\\", \\\"{x:1533,y:893,t:1528144016603};\\\", \\\"{x:1533,y:895,t:1528144016620};\\\", \\\"{x:1535,y:896,t:1528144016636};\\\", \\\"{x:1537,y:900,t:1528144016653};\\\", \\\"{x:1539,y:903,t:1528144016670};\\\", \\\"{x:1541,y:910,t:1528144016686};\\\", \\\"{x:1545,y:921,t:1528144016703};\\\", \\\"{x:1550,y:930,t:1528144016720};\\\", \\\"{x:1551,y:937,t:1528144016736};\\\", \\\"{x:1552,y:947,t:1528144016753};\\\", \\\"{x:1555,y:951,t:1528144016769};\\\", \\\"{x:1555,y:955,t:1528144016786};\\\", \\\"{x:1558,y:959,t:1528144016803};\\\", \\\"{x:1560,y:961,t:1528144016820};\\\", \\\"{x:1561,y:962,t:1528144016836};\\\", \\\"{x:1560,y:962,t:1528144017066};\\\", \\\"{x:1559,y:962,t:1528144017073};\\\", \\\"{x:1558,y:963,t:1528144017114};\\\", \\\"{x:1557,y:963,t:1528144017121};\\\", \\\"{x:1556,y:963,t:1528144017136};\\\", \\\"{x:1554,y:963,t:1528144017162};\\\", \\\"{x:1552,y:964,t:1528144017185};\\\", \\\"{x:1551,y:964,t:1528144017193};\\\", \\\"{x:1549,y:965,t:1528144017217};\\\", \\\"{x:1547,y:966,t:1528144017250};\\\", \\\"{x:1546,y:966,t:1528144017281};\\\", \\\"{x:1544,y:968,t:1528144017722};\\\", \\\"{x:1543,y:969,t:1528144017737};\\\", \\\"{x:1537,y:969,t:1528144017753};\\\", \\\"{x:1536,y:969,t:1528144017777};\\\", \\\"{x:1535,y:969,t:1528144017801};\\\", \\\"{x:1534,y:970,t:1528144017810};\\\", \\\"{x:1531,y:970,t:1528144018025};\\\", \\\"{x:1531,y:971,t:1528144018042};\\\", \\\"{x:1530,y:971,t:1528144018057};\\\", \\\"{x:1529,y:971,t:1528144018071};\\\", \\\"{x:1527,y:971,t:1528144018088};\\\", \\\"{x:1521,y:971,t:1528144018104};\\\", \\\"{x:1517,y:971,t:1528144018121};\\\", \\\"{x:1513,y:971,t:1528144018137};\\\", \\\"{x:1508,y:968,t:1528144018153};\\\", \\\"{x:1499,y:967,t:1528144018171};\\\", \\\"{x:1496,y:966,t:1528144018186};\\\", \\\"{x:1494,y:965,t:1528144018204};\\\", \\\"{x:1493,y:965,t:1528144018221};\\\", \\\"{x:1489,y:965,t:1528144018237};\\\", \\\"{x:1479,y:963,t:1528144018254};\\\", \\\"{x:1471,y:962,t:1528144018272};\\\", \\\"{x:1463,y:960,t:1528144018288};\\\", \\\"{x:1461,y:959,t:1528144018304};\\\", \\\"{x:1459,y:959,t:1528144018321};\\\", \\\"{x:1458,y:959,t:1528144018361};\\\", \\\"{x:1458,y:958,t:1528144018577};\\\", \\\"{x:1459,y:956,t:1528144018593};\\\", \\\"{x:1460,y:954,t:1528144018604};\\\", \\\"{x:1463,y:952,t:1528144018621};\\\", \\\"{x:1467,y:949,t:1528144018638};\\\", \\\"{x:1467,y:948,t:1528144018654};\\\", \\\"{x:1469,y:946,t:1528144018674};\\\", \\\"{x:1470,y:946,t:1528144018688};\\\", \\\"{x:1470,y:945,t:1528144018705};\\\", \\\"{x:1471,y:943,t:1528144018753};\\\", \\\"{x:1473,y:941,t:1528144018778};\\\", \\\"{x:1473,y:940,t:1528144018788};\\\", \\\"{x:1473,y:939,t:1528144018805};\\\", \\\"{x:1473,y:938,t:1528144018821};\\\", \\\"{x:1474,y:934,t:1528144018838};\\\", \\\"{x:1474,y:933,t:1528144018855};\\\", \\\"{x:1474,y:932,t:1528144018871};\\\", \\\"{x:1474,y:930,t:1528144018887};\\\", \\\"{x:1475,y:924,t:1528144018905};\\\", \\\"{x:1475,y:920,t:1528144018921};\\\", \\\"{x:1475,y:919,t:1528144018938};\\\", \\\"{x:1475,y:915,t:1528144018955};\\\", \\\"{x:1475,y:914,t:1528144018985};\\\", \\\"{x:1474,y:912,t:1528144018993};\\\", \\\"{x:1474,y:910,t:1528144019005};\\\", \\\"{x:1474,y:909,t:1528144019021};\\\", \\\"{x:1474,y:904,t:1528144019038};\\\", \\\"{x:1474,y:899,t:1528144019055};\\\", \\\"{x:1473,y:894,t:1528144019071};\\\", \\\"{x:1473,y:888,t:1528144019088};\\\", \\\"{x:1471,y:880,t:1528144019105};\\\", \\\"{x:1471,y:877,t:1528144019121};\\\", \\\"{x:1471,y:873,t:1528144019138};\\\", \\\"{x:1471,y:869,t:1528144019155};\\\", \\\"{x:1470,y:869,t:1528144019171};\\\", \\\"{x:1470,y:867,t:1528144019188};\\\", \\\"{x:1469,y:866,t:1528144019205};\\\", \\\"{x:1467,y:865,t:1528144019221};\\\", \\\"{x:1467,y:864,t:1528144019238};\\\", \\\"{x:1467,y:862,t:1528144019255};\\\", \\\"{x:1467,y:859,t:1528144019272};\\\", \\\"{x:1467,y:854,t:1528144019288};\\\", \\\"{x:1467,y:850,t:1528144019305};\\\", \\\"{x:1467,y:847,t:1528144019321};\\\", \\\"{x:1467,y:846,t:1528144019338};\\\", \\\"{x:1468,y:844,t:1528144019355};\\\", \\\"{x:1468,y:842,t:1528144019372};\\\", \\\"{x:1468,y:839,t:1528144019388};\\\", \\\"{x:1468,y:836,t:1528144019405};\\\", \\\"{x:1468,y:833,t:1528144019422};\\\", \\\"{x:1470,y:831,t:1528144019438};\\\", \\\"{x:1470,y:829,t:1528144019455};\\\", \\\"{x:1470,y:825,t:1528144019473};\\\", \\\"{x:1470,y:824,t:1528144019488};\\\", \\\"{x:1470,y:822,t:1528144019505};\\\", \\\"{x:1471,y:821,t:1528144019521};\\\", \\\"{x:1472,y:819,t:1528144019538};\\\", \\\"{x:1472,y:817,t:1528144019555};\\\", \\\"{x:1472,y:816,t:1528144019572};\\\", \\\"{x:1472,y:814,t:1528144019588};\\\", \\\"{x:1472,y:813,t:1528144019604};\\\", \\\"{x:1473,y:812,t:1528144019621};\\\", \\\"{x:1473,y:811,t:1528144019638};\\\", \\\"{x:1473,y:810,t:1528144019654};\\\", \\\"{x:1473,y:809,t:1528144019672};\\\", \\\"{x:1473,y:804,t:1528144019689};\\\", \\\"{x:1473,y:801,t:1528144019704};\\\", \\\"{x:1473,y:800,t:1528144019721};\\\", \\\"{x:1473,y:798,t:1528144019738};\\\", \\\"{x:1473,y:797,t:1528144019768};\\\", \\\"{x:1472,y:795,t:1528144019785};\\\", \\\"{x:1472,y:793,t:1528144019793};\\\", \\\"{x:1470,y:790,t:1528144019804};\\\", \\\"{x:1469,y:788,t:1528144019822};\\\", \\\"{x:1469,y:786,t:1528144019839};\\\", \\\"{x:1469,y:785,t:1528144019855};\\\", \\\"{x:1468,y:783,t:1528144019872};\\\", \\\"{x:1467,y:776,t:1528144019889};\\\", \\\"{x:1466,y:771,t:1528144019905};\\\", \\\"{x:1465,y:765,t:1528144019922};\\\", \\\"{x:1464,y:760,t:1528144019938};\\\", \\\"{x:1463,y:753,t:1528144019955};\\\", \\\"{x:1461,y:749,t:1528144019972};\\\", \\\"{x:1460,y:746,t:1528144019989};\\\", \\\"{x:1460,y:743,t:1528144020005};\\\", \\\"{x:1459,y:740,t:1528144020022};\\\", \\\"{x:1459,y:737,t:1528144020040};\\\", \\\"{x:1459,y:735,t:1528144020056};\\\", \\\"{x:1459,y:733,t:1528144020072};\\\", \\\"{x:1459,y:727,t:1528144020089};\\\", \\\"{x:1459,y:723,t:1528144020105};\\\", \\\"{x:1459,y:719,t:1528144020122};\\\", \\\"{x:1459,y:712,t:1528144020139};\\\", \\\"{x:1458,y:707,t:1528144020156};\\\", \\\"{x:1458,y:704,t:1528144020172};\\\", \\\"{x:1458,y:697,t:1528144020189};\\\", \\\"{x:1458,y:695,t:1528144020206};\\\", \\\"{x:1457,y:693,t:1528144020222};\\\", \\\"{x:1455,y:687,t:1528144020239};\\\", \\\"{x:1455,y:683,t:1528144020256};\\\", \\\"{x:1455,y:678,t:1528144020272};\\\", \\\"{x:1455,y:670,t:1528144020289};\\\", \\\"{x:1455,y:665,t:1528144020305};\\\", \\\"{x:1454,y:664,t:1528144020337};\\\", \\\"{x:1454,y:663,t:1528144020850};\\\", \\\"{x:1454,y:666,t:1528144020866};\\\", \\\"{x:1455,y:676,t:1528144020873};\\\", \\\"{x:1462,y:702,t:1528144020889};\\\", \\\"{x:1468,y:718,t:1528144020906};\\\", \\\"{x:1474,y:741,t:1528144020923};\\\", \\\"{x:1478,y:762,t:1528144020940};\\\", \\\"{x:1480,y:778,t:1528144020956};\\\", \\\"{x:1486,y:792,t:1528144020973};\\\", \\\"{x:1486,y:806,t:1528144020990};\\\", \\\"{x:1486,y:820,t:1528144021006};\\\", \\\"{x:1486,y:828,t:1528144021023};\\\", \\\"{x:1487,y:833,t:1528144021042};\\\", \\\"{x:1487,y:842,t:1528144021056};\\\", \\\"{x:1489,y:861,t:1528144021073};\\\", \\\"{x:1493,y:873,t:1528144021090};\\\", \\\"{x:1493,y:877,t:1528144021106};\\\", \\\"{x:1493,y:880,t:1528144021122};\\\", \\\"{x:1493,y:882,t:1528144021139};\\\", \\\"{x:1493,y:885,t:1528144021156};\\\", \\\"{x:1494,y:888,t:1528144021172};\\\", \\\"{x:1494,y:890,t:1528144021190};\\\", \\\"{x:1493,y:896,t:1528144021206};\\\", \\\"{x:1492,y:902,t:1528144021223};\\\", \\\"{x:1491,y:912,t:1528144021239};\\\", \\\"{x:1491,y:916,t:1528144021256};\\\", \\\"{x:1491,y:921,t:1528144021272};\\\", \\\"{x:1491,y:924,t:1528144021290};\\\", \\\"{x:1491,y:927,t:1528144021306};\\\", \\\"{x:1491,y:928,t:1528144021329};\\\", \\\"{x:1491,y:927,t:1528144021481};\\\", \\\"{x:1491,y:923,t:1528144021489};\\\", \\\"{x:1491,y:914,t:1528144021507};\\\", \\\"{x:1491,y:907,t:1528144021523};\\\", \\\"{x:1486,y:891,t:1528144021540};\\\", \\\"{x:1486,y:885,t:1528144021557};\\\", \\\"{x:1485,y:877,t:1528144021572};\\\", \\\"{x:1485,y:874,t:1528144021590};\\\", \\\"{x:1482,y:867,t:1528144021607};\\\", \\\"{x:1482,y:863,t:1528144021623};\\\", \\\"{x:1481,y:859,t:1528144021640};\\\", \\\"{x:1481,y:854,t:1528144021657};\\\", \\\"{x:1481,y:851,t:1528144021673};\\\", \\\"{x:1481,y:849,t:1528144021691};\\\", \\\"{x:1479,y:846,t:1528144021707};\\\", \\\"{x:1478,y:842,t:1528144021723};\\\", \\\"{x:1478,y:840,t:1528144021740};\\\", \\\"{x:1478,y:837,t:1528144021757};\\\", \\\"{x:1476,y:835,t:1528144021773};\\\", \\\"{x:1476,y:832,t:1528144021790};\\\", \\\"{x:1476,y:831,t:1528144021807};\\\", \\\"{x:1476,y:829,t:1528144021823};\\\", \\\"{x:1476,y:828,t:1528144021840};\\\", \\\"{x:1476,y:827,t:1528144021857};\\\", \\\"{x:1476,y:824,t:1528144021874};\\\", \\\"{x:1476,y:821,t:1528144021890};\\\", \\\"{x:1476,y:817,t:1528144021907};\\\", \\\"{x:1476,y:816,t:1528144021924};\\\", \\\"{x:1476,y:812,t:1528144021940};\\\", \\\"{x:1476,y:810,t:1528144021958};\\\", \\\"{x:1476,y:809,t:1528144021974};\\\", \\\"{x:1475,y:807,t:1528144021990};\\\", \\\"{x:1474,y:806,t:1528144022007};\\\", \\\"{x:1471,y:799,t:1528144022025};\\\", \\\"{x:1471,y:797,t:1528144022040};\\\", \\\"{x:1471,y:792,t:1528144022057};\\\", \\\"{x:1471,y:791,t:1528144022074};\\\", \\\"{x:1471,y:790,t:1528144022089};\\\", \\\"{x:1471,y:787,t:1528144022106};\\\", \\\"{x:1471,y:783,t:1528144022124};\\\", \\\"{x:1471,y:779,t:1528144022139};\\\", \\\"{x:1471,y:774,t:1528144022156};\\\", \\\"{x:1470,y:767,t:1528144022174};\\\", \\\"{x:1470,y:761,t:1528144022189};\\\", \\\"{x:1467,y:757,t:1528144022206};\\\", \\\"{x:1467,y:754,t:1528144022224};\\\", \\\"{x:1467,y:752,t:1528144022240};\\\", \\\"{x:1466,y:749,t:1528144022257};\\\", \\\"{x:1465,y:746,t:1528144022289};\\\", \\\"{x:1465,y:745,t:1528144022305};\\\", \\\"{x:1465,y:743,t:1528144022321};\\\", \\\"{x:1465,y:742,t:1528144022345};\\\", \\\"{x:1465,y:740,t:1528144022385};\\\", \\\"{x:1465,y:738,t:1528144022402};\\\", \\\"{x:1464,y:737,t:1528144022410};\\\", \\\"{x:1464,y:736,t:1528144022425};\\\", \\\"{x:1464,y:728,t:1528144022441};\\\", \\\"{x:1464,y:726,t:1528144022458};\\\", \\\"{x:1465,y:721,t:1528144022474};\\\", \\\"{x:1466,y:717,t:1528144022491};\\\", \\\"{x:1466,y:713,t:1528144022507};\\\", \\\"{x:1468,y:707,t:1528144022524};\\\", \\\"{x:1468,y:704,t:1528144022542};\\\", \\\"{x:1468,y:702,t:1528144022558};\\\", \\\"{x:1469,y:700,t:1528144022574};\\\", \\\"{x:1470,y:698,t:1528144022591};\\\", \\\"{x:1471,y:698,t:1528144022607};\\\", \\\"{x:1471,y:696,t:1528144022624};\\\", \\\"{x:1472,y:694,t:1528144022641};\\\", \\\"{x:1473,y:693,t:1528144022657};\\\", \\\"{x:1474,y:692,t:1528144022730};\\\", \\\"{x:1475,y:692,t:1528144023817};\\\", \\\"{x:1475,y:690,t:1528144023825};\\\", \\\"{x:1475,y:683,t:1528144023842};\\\", \\\"{x:1475,y:676,t:1528144023859};\\\", \\\"{x:1475,y:671,t:1528144023875};\\\", \\\"{x:1475,y:665,t:1528144023893};\\\", \\\"{x:1475,y:656,t:1528144023909};\\\", \\\"{x:1475,y:650,t:1528144023925};\\\", \\\"{x:1475,y:643,t:1528144023942};\\\", \\\"{x:1475,y:637,t:1528144023959};\\\", \\\"{x:1475,y:630,t:1528144023976};\\\", \\\"{x:1475,y:627,t:1528144023993};\\\", \\\"{x:1475,y:622,t:1528144024008};\\\", \\\"{x:1475,y:620,t:1528144024025};\\\", \\\"{x:1475,y:619,t:1528144024057};\\\", \\\"{x:1475,y:618,t:1528144025761};\\\", \\\"{x:1475,y:617,t:1528144025777};\\\", \\\"{x:1476,y:617,t:1528144025793};\\\", \\\"{x:1476,y:616,t:1528144025817};\\\", \\\"{x:1476,y:615,t:1528144025827};\\\", \\\"{x:1478,y:611,t:1528144025843};\\\", \\\"{x:1479,y:610,t:1528144025865};\\\", \\\"{x:1479,y:609,t:1528144025878};\\\", \\\"{x:1479,y:607,t:1528144025893};\\\", \\\"{x:1481,y:604,t:1528144025910};\\\", \\\"{x:1482,y:601,t:1528144025927};\\\", \\\"{x:1482,y:597,t:1528144025943};\\\", \\\"{x:1483,y:594,t:1528144025959};\\\", \\\"{x:1484,y:590,t:1528144025976};\\\", \\\"{x:1484,y:586,t:1528144025993};\\\", \\\"{x:1485,y:584,t:1528144026010};\\\", \\\"{x:1485,y:583,t:1528144026027};\\\", \\\"{x:1485,y:581,t:1528144026042};\\\", \\\"{x:1485,y:580,t:1528144026064};\\\", \\\"{x:1485,y:579,t:1528144026076};\\\", \\\"{x:1485,y:578,t:1528144026093};\\\", \\\"{x:1485,y:577,t:1528144026109};\\\", \\\"{x:1485,y:575,t:1528144026169};\\\", \\\"{x:1485,y:574,t:1528144026234};\\\", \\\"{x:1485,y:573,t:1528144026265};\\\", \\\"{x:1485,y:572,t:1528144026281};\\\", \\\"{x:1485,y:571,t:1528144026329};\\\", \\\"{x:1484,y:570,t:1528144026344};\\\", \\\"{x:1484,y:569,t:1528144026369};\\\", \\\"{x:1484,y:568,t:1528144026377};\\\", \\\"{x:1484,y:567,t:1528144026402};\\\", \\\"{x:1482,y:565,t:1528144026417};\\\", \\\"{x:1482,y:564,t:1528144026449};\\\", \\\"{x:1481,y:564,t:1528144026461};\\\", \\\"{x:1481,y:563,t:1528144026478};\\\", \\\"{x:1481,y:562,t:1528144026592};\\\", \\\"{x:1481,y:561,t:1528144026601};\\\", \\\"{x:1477,y:563,t:1528144061653};\\\", \\\"{x:1452,y:570,t:1528144061661};\\\", \\\"{x:1401,y:578,t:1528144061676};\\\", \\\"{x:1231,y:582,t:1528144061692};\\\", \\\"{x:1065,y:582,t:1528144061708};\\\", \\\"{x:874,y:576,t:1528144061725};\\\", \\\"{x:642,y:571,t:1528144061742};\\\", \\\"{x:412,y:564,t:1528144061759};\\\", \\\"{x:231,y:556,t:1528144061774};\\\", \\\"{x:32,y:556,t:1528144061791};\\\", \\\"{x:0,y:538,t:1528144061809};\\\", \\\"{x:0,y:533,t:1528144061825};\\\", \\\"{x:0,y:532,t:1528144061841};\\\", \\\"{x:0,y:531,t:1528144061858};\\\", \\\"{x:1,y:531,t:1528144061956};\\\", \\\"{x:10,y:531,t:1528144061964};\\\", \\\"{x:21,y:531,t:1528144061976};\\\", \\\"{x:53,y:531,t:1528144061992};\\\", \\\"{x:82,y:531,t:1528144062008};\\\", \\\"{x:126,y:531,t:1528144062025};\\\", \\\"{x:165,y:531,t:1528144062043};\\\", \\\"{x:214,y:528,t:1528144062059};\\\", \\\"{x:309,y:525,t:1528144062077};\\\", \\\"{x:337,y:522,t:1528144062091};\\\", \\\"{x:366,y:521,t:1528144062110};\\\", \\\"{x:377,y:519,t:1528144062126};\\\", \\\"{x:390,y:519,t:1528144062142};\\\", \\\"{x:394,y:516,t:1528144062159};\\\", \\\"{x:405,y:515,t:1528144062176};\\\", \\\"{x:420,y:512,t:1528144062192};\\\", \\\"{x:429,y:511,t:1528144062209};\\\", \\\"{x:434,y:510,t:1528144062225};\\\", \\\"{x:443,y:510,t:1528144062243};\\\", \\\"{x:446,y:510,t:1528144062259};\\\", \\\"{x:447,y:510,t:1528144062325};\\\", \\\"{x:450,y:510,t:1528144062331};\\\", \\\"{x:457,y:510,t:1528144062343};\\\", \\\"{x:472,y:514,t:1528144062359};\\\", \\\"{x:506,y:521,t:1528144062378};\\\", \\\"{x:534,y:531,t:1528144062393};\\\", \\\"{x:556,y:538,t:1528144062410};\\\", \\\"{x:574,y:541,t:1528144062427};\\\", \\\"{x:584,y:541,t:1528144062442};\\\", \\\"{x:586,y:541,t:1528144062460};\\\", \\\"{x:589,y:541,t:1528144062587};\\\", \\\"{x:591,y:540,t:1528144062603};\\\", \\\"{x:592,y:539,t:1528144062619};\\\", \\\"{x:592,y:538,t:1528144062627};\\\", \\\"{x:595,y:534,t:1528144062643};\\\", \\\"{x:596,y:531,t:1528144062660};\\\", \\\"{x:599,y:527,t:1528144062676};\\\", \\\"{x:603,y:524,t:1528144062694};\\\", \\\"{x:605,y:522,t:1528144062709};\\\", \\\"{x:608,y:519,t:1528144062726};\\\", \\\"{x:609,y:518,t:1528144062744};\\\", \\\"{x:610,y:518,t:1528144062764};\\\", \\\"{x:611,y:518,t:1528144063093};\\\", \\\"{x:611,y:521,t:1528144063110};\\\", \\\"{x:611,y:525,t:1528144063127};\\\", \\\"{x:610,y:534,t:1528144063144};\\\", \\\"{x:607,y:556,t:1528144063161};\\\", \\\"{x:604,y:569,t:1528144063176};\\\", \\\"{x:598,y:591,t:1528144063194};\\\", \\\"{x:593,y:611,t:1528144063211};\\\", \\\"{x:589,y:628,t:1528144063227};\\\", \\\"{x:583,y:643,t:1528144063243};\\\", \\\"{x:579,y:657,t:1528144063261};\\\", \\\"{x:573,y:668,t:1528144063276};\\\", \\\"{x:567,y:679,t:1528144063293};\\\", \\\"{x:562,y:687,t:1528144063311};\\\", \\\"{x:559,y:693,t:1528144063328};\\\", \\\"{x:555,y:701,t:1528144063343};\\\", \\\"{x:548,y:710,t:1528144063361};\\\", \\\"{x:543,y:715,t:1528144063378};\\\", \\\"{x:540,y:721,t:1528144063395};\\\", \\\"{x:537,y:727,t:1528144063411};\\\", \\\"{x:533,y:733,t:1528144063428};\\\", \\\"{x:533,y:734,t:1528144063446};\\\", \\\"{x:531,y:736,t:1528144063461};\\\", \\\"{x:531,y:737,t:1528144063478};\\\", \\\"{x:529,y:740,t:1528144063494};\\\", \\\"{x:528,y:742,t:1528144063511};\\\", \\\"{x:527,y:743,t:1528144063527};\\\", \\\"{x:526,y:744,t:1528144063596};\\\" ] }, { \\\"rt\\\": 84684, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1142035, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"look for dots aligned with the dash on the x-axis corresponding to the 12 PM \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10863, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States of America\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1153905, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 11368, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1166292, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 29209, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1196840, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"Z5GWP\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"Z5GWP\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}}]}]}]},{\"nodeType\":3,\"id\":2303,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2304,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2305},{\"nodeType\":3,\"id\":2306,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2307,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2308,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2309,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2310,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 34, dom: 72, initialDom: 92",
  "javascriptErrors": []
}