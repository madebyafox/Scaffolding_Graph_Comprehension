var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052525226b8a38985807229623365ab4b1020656"] = {
  "startTime": "2018-05-25T18:13:25.283191Z",
  "websitePageUrl": "/16",
  "visitTime": 78033,
  "engagementTime": 77309,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "bc9d4c1e1919d19b56ca49d33b4ac803",
    "created": "2018-05-25T18:13:25.283191+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=DFQLY",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "5f109e40e74d58e6788a0de8a4224b76",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/bc9d4c1e1919d19b56ca49d33b4ac803/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 182,
      "e": 182,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 601,
      "e": 601,
      "ty": 2,
      "x": 493,
      "y": 740
    },
    {
      "t": 764,
      "e": 764,
      "ty": 2,
      "x": 494,
      "y": 738
    },
    {
      "t": 765,
      "e": 765,
      "ty": 41,
      "x": 44616,
      "y": 40440,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 494,
      "y": 727
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 43941,
      "y": 38611,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 486,
      "y": 690
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 486,
      "y": 635
    },
    {
      "t": 3484,
      "e": 3484,
      "ty": 6,
      "x": 510,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 2,
      "x": 516,
      "y": 588
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 47089,
      "y": 52804,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 537,
      "y": 570
    },
    {
      "t": 3751,
      "e": 3751,
      "ty": 41,
      "x": 49449,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3788,
      "e": 3788,
      "ty": 3,
      "x": 537,
      "y": 570,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3790,
      "e": 3790,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3892,
      "e": 3892,
      "ty": 4,
      "x": 49449,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3892,
      "e": 3892,
      "ty": 5,
      "x": 537,
      "y": 570,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5353,
      "e": 5353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 5536,
      "e": 5536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 5537,
      "e": 5537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5599,
      "e": 5599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 5632,
      "e": 5632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 5655,
      "e": 5655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 5655,
      "e": 5655,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5735,
      "e": 5735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fo"
    },
    {
      "t": 5760,
      "e": 5760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 5760,
      "e": 5760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5839,
      "e": 5839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For"
    },
    {
      "t": 5872,
      "e": 5872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 5872,
      "e": 5872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5935,
      "e": 5935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For "
    },
    {
      "t": 5959,
      "e": 5959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 5959,
      "e": 5959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6023,
      "e": 6023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 6024,
      "e": 6024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 6024,
      "e": 6024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6096,
      "e": 6096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 6112,
      "e": 6112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 6113,
      "e": 6113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6191,
      "e": 6191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 6191,
      "e": 6191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6199,
      "e": 6199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 6288,
      "e": 6288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 6616,
      "e": 6616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 6617,
      "e": 6617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6696,
      "e": 6696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 6803,
      "e": 6803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the l"
    },
    {
      "t": 6848,
      "e": 6848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 6848,
      "e": 6848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6912,
      "e": 6912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 7048,
      "e": 7048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 7048,
      "e": 7048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7144,
      "e": 7144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 7176,
      "e": 7176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 7176,
      "e": 7176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7224,
      "e": 7224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 7336,
      "e": 7336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 7337,
      "e": 7337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7431,
      "e": 7431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 7896,
      "e": 7896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7897,
      "e": 7897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7983,
      "e": 7983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8144,
      "e": 8144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 8145,
      "e": 8145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8215,
      "e": 8215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 8303,
      "e": 8303,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 8303,
      "e": 8303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8400,
      "e": 8400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 8424,
      "e": 8424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 8425,
      "e": 8425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8520,
      "e": 8520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 8543,
      "e": 8543,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 8543,
      "e": 8543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8623,
      "e": 8623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 8655,
      "e": 8655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 8656,
      "e": 8656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8703,
      "e": 8703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 8759,
      "e": 8759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8760,
      "e": 8760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8840,
      "e": 8840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8887,
      "e": 8887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 8887,
      "e": 8887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8959,
      "e": 8959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 8975,
      "e": 8975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 8975,
      "e": 8975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9039,
      "e": 9039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 9079,
      "e": 9079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 9079,
      "e": 9079,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9159,
      "e": 9159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 9167,
      "e": 9167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 9168,
      "e": 9168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9248,
      "e": 9248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 9320,
      "e": 9320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9321,
      "e": 9321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9383,
      "e": 9383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 9464,
      "e": 9464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9464,
      "e": 9464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9595,
      "e": 9595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9639,
      "e": 9639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 9639,
      "e": 9639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9711,
      "e": 9711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 9743,
      "e": 9743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9743,
      "e": 9743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9840,
      "e": 9840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10425,
      "e": 10425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10487,
      "e": 10487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right c"
    },
    {
      "t": 10584,
      "e": 10584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10696,
      "e": 10696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right "
    },
    {
      "t": 10967,
      "e": 10967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11015,
      "e": 11015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right"
    },
    {
      "t": 11384,
      "e": 11384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11385,
      "e": 11385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11488,
      "e": 11488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11583,
      "e": 11583,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 11583,
      "e": 11583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11663,
      "e": 11663,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 11688,
      "e": 11688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 11688,
      "e": 11688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11760,
      "e": 11760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 11808,
      "e": 11808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11809,
      "e": 11809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11895,
      "e": 11895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 11895,
      "e": 11895,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11903,
      "e": 11903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 11975,
      "e": 11975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12055,
      "e": 12055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12056,
      "e": 12056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12112,
      "e": 12112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12113,
      "e": 12113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12127,
      "e": 12127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 12159,
      "e": 12159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12199,
      "e": 12199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 12199,
      "e": 12199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12264,
      "e": 12264,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 12272,
      "e": 12272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 12272,
      "e": 12272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12327,
      "e": 12327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 12360,
      "e": 12360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12360,
      "e": 12360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12423,
      "e": 12423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12480,
      "e": 12480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 12480,
      "e": 12480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12552,
      "e": 12552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 12567,
      "e": 12567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12569,
      "e": 12569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12631,
      "e": 12631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 12672,
      "e": 12672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 12672,
      "e": 12672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12743,
      "e": 12743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 12743,
      "e": 12743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12744,
      "e": 12744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12832,
      "e": 12832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 12864,
      "e": 12864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12865,
      "e": 12865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12952,
      "e": 12952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 12976,
      "e": 12976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 12977,
      "e": 12977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13056,
      "e": 13056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13056,
      "e": 13056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13096,
      "e": 13096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||, "
    },
    {
      "t": 13120,
      "e": 13120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13160,
      "e": 13160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13160,
      "e": 13160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13239,
      "e": 13239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13256,
      "e": 13256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13256,
      "e": 13256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13319,
      "e": 13319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 13327,
      "e": 13327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13328,
      "e": 13328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13407,
      "e": 13407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 13448,
      "e": 13448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13448,
      "e": 13448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13536,
      "e": 13536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13536,
      "e": 13536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13537,
      "e": 13537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13632,
      "e": 13632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 13752,
      "e": 13752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 13753,
      "e": 13753,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13855,
      "e": 13855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 13896,
      "e": 13896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13896,
      "e": 13896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14002,
      "e": 14002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right slanting right, the eve"
    },
    {
      "t": 14025,
      "e": 14025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14025,
      "e": 14025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14032,
      "e": 14032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 14088,
      "e": 14088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14088,
      "e": 14088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14111,
      "e": 14111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14167,
      "e": 14167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14247,
      "e": 14247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14249,
      "e": 14249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14360,
      "e": 14360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14360,
      "e": 14360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14367,
      "e": 14367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 14431,
      "e": 14431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14463,
      "e": 14463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14464,
      "e": 14464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14519,
      "e": 14519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14536,
      "e": 14536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14536,
      "e": 14536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14616,
      "e": 14616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14680,
      "e": 14680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14681,
      "e": 14681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14688,
      "e": 14688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 14728,
      "e": 14728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 14752,
      "e": 14752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14791,
      "e": 14791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14791,
      "e": 14791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14895,
      "e": 14895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 14976,
      "e": 14976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14976,
      "e": 14976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15087,
      "e": 15087,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15192,
      "e": 15192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15193,
      "e": 15193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15287,
      "e": 15287,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 15488,
      "e": 15488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15512,
      "e": 15488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right slanting right, the events thaT "
    },
    {
      "t": 15591,
      "e": 15567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15639,
      "e": 15615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right slanting right, the events thaT"
    },
    {
      "t": 15720,
      "e": 15696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15775,
      "e": 15751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right slanting right, the events tha"
    },
    {
      "t": 16072,
      "e": 16048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16073,
      "e": 16049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16151,
      "e": 16127,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 16336,
      "e": 16312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16337,
      "e": 16313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16415,
      "e": 16391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16712,
      "e": 16688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16735,
      "e": 16711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right slanting right, the events thaT"
    },
    {
      "t": 16824,
      "e": 16800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16880,
      "e": 16856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right slanting right, the events tha"
    },
    {
      "t": 17003,
      "e": 16979,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right slanting right, the events tha"
    },
    {
      "t": 17017,
      "e": 16993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 17104,
      "e": 17080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17633,
      "e": 17609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17634,
      "e": 17610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17704,
      "e": 17680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18104,
      "e": 18080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18105,
      "e": 18081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18175,
      "e": 18151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18344,
      "e": 18320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18345,
      "e": 18321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18423,
      "e": 18399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 18455,
      "e": 18431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18455,
      "e": 18431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18511,
      "e": 18487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18559,
      "e": 18535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18560,
      "e": 18536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18640,
      "e": 18616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18736,
      "e": 18712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18736,
      "e": 18712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18800,
      "e": 18776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 18936,
      "e": 18912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18937,
      "e": 18913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18999,
      "e": 18975,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19176,
      "e": 19152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19177,
      "e": 19153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19263,
      "e": 19239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19320,
      "e": 19296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19320,
      "e": 19296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19432,
      "e": 19408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19528,
      "e": 19504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19529,
      "e": 19505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19591,
      "e": 19567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19647,
      "e": 19623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19647,
      "e": 19623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19704,
      "e": 19680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20271,
      "e": 20247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "97"
    },
    {
      "t": 20271,
      "e": 20247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20344,
      "e": 20320,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "98"
    },
    {
      "t": 20345,
      "e": 20321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20375,
      "e": 20351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 20407,
      "e": 20383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20471,
      "e": 20447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20472,
      "e": 20448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20560,
      "e": 20536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20631,
      "e": 20607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 20744,
      "e": 20720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 20745,
      "e": 20721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20831,
      "e": 20807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 20952,
      "e": 20928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 20952,
      "e": 20928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21023,
      "e": 20999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 21127,
      "e": 21103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21128,
      "e": 21104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21128,
      "e": 21104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21224,
      "e": 21200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21384,
      "e": 21360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 21385,
      "e": 21361,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21488,
      "e": 21464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 21496,
      "e": 21472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21496,
      "e": 21472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21592,
      "e": 21568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 21680,
      "e": 21656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21680,
      "e": 21656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21735,
      "e": 21711,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 21799,
      "e": 21775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21800,
      "e": 21776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21863,
      "e": 21839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 21936,
      "e": 21912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21936,
      "e": 21912,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22023,
      "e": 21999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22080,
      "e": 22000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 22081,
      "e": 22001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22159,
      "e": 22079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 22199,
      "e": 22119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22199,
      "e": 22119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22287,
      "e": 22207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22432,
      "e": 22352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 22432,
      "e": 22352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22504,
      "e": 22424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 22519,
      "e": 22439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22520,
      "e": 22440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22551,
      "e": 22471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22615,
      "e": 22535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22615,
      "e": 22535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22695,
      "e": 22615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 22804,
      "e": 22724,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right slanting right, the events that start at 12 PM will begin"
    },
    {
      "t": 22808,
      "e": 22728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22809,
      "e": 22729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22919,
      "e": 22839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23216,
      "e": 23136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23216,
      "e": 23136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23319,
      "e": 23239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23488,
      "e": 23408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23488,
      "e": 23408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23543,
      "e": 23463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23575,
      "e": 23495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23575,
      "e": 23495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23656,
      "e": 23576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23679,
      "e": 23599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 23679,
      "e": 23599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23803,
      "e": 23723,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right slanting right, the events that start at 12 PM will begin at 1"
    },
    {
      "t": 23808,
      "e": 23728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 23808,
      "e": 23728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23856,
      "e": 23776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 23896,
      "e": 23816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23912,
      "e": 23832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23912,
      "e": 23832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23991,
      "e": 23911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24192,
      "e": 24112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24480,
      "e": 24400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24792,
      "e": 24712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24880,
      "e": 24800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 24880,
      "e": 24800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24951,
      "e": 24871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 24999,
      "e": 24919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 24999,
      "e": 24919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25088,
      "e": 25008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 25128,
      "e": 25048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25129,
      "e": 25049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25151,
      "e": 25071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25215,
      "e": 25135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25239,
      "e": 25159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25240,
      "e": 25160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25311,
      "e": 25231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25359,
      "e": 25279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25361,
      "e": 25281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25415,
      "e": 25335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25415,
      "e": 25335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25447,
      "e": 25367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n "
    },
    {
      "t": 25463,
      "e": 25383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25536,
      "e": 25456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25537,
      "e": 25457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25623,
      "e": 25543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 25631,
      "e": 25551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 25631,
      "e": 25551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25696,
      "e": 25616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 25735,
      "e": 25655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25736,
      "e": 25656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25824,
      "e": 25744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25856,
      "e": 25776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25857,
      "e": 25777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25943,
      "e": 25863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26200,
      "e": 26120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 26201,
      "e": 26121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26263,
      "e": 26183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 26415,
      "e": 26335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 26417,
      "e": 26337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26495,
      "e": 26415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 26567,
      "e": 26487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26568,
      "e": 26488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26672,
      "e": 26592,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26824,
      "e": 26744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 26825,
      "e": 26745,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26903,
      "e": 26823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 26903,
      "e": 26823,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26903,
      "e": 26823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26984,
      "e": 26904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 27072,
      "e": 26992,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 27072,
      "e": 26992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27151,
      "e": 27071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 27239,
      "e": 27159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27239,
      "e": 27159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27320,
      "e": 27240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27408,
      "e": 27328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27410,
      "e": 27330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27455,
      "e": 27375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 27479,
      "e": 27399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27479,
      "e": 27399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27552,
      "e": 27472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 27608,
      "e": 27528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27608,
      "e": 27528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27687,
      "e": 27607,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 27704,
      "e": 27624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27704,
      "e": 27624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27783,
      "e": 27703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27864,
      "e": 27784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27865,
      "e": 27785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27912,
      "e": 27832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27913,
      "e": 27833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27936,
      "e": 27834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 27991,
      "e": 27889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28055,
      "e": 27953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28055,
      "e": 27953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28127,
      "e": 28025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28128,
      "e": 28026,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28152,
      "e": 28050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 28225,
      "e": 28123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28271,
      "e": 28169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28272,
      "e": 28170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28375,
      "e": 28273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29808,
      "e": 29706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 29809,
      "e": 29707,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29887,
      "e": 29785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 29935,
      "e": 29833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29935,
      "e": 29833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30007,
      "e": 29905,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 30007,
      "e": 29905,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30023,
      "e": 29921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ov"
    },
    {
      "t": 30152,
      "e": 30050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30208,
      "e": 30106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30209,
      "e": 30107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30304,
      "e": 30202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30335,
      "e": 30233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30336,
      "e": 30234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30423,
      "e": 30321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30952,
      "e": 30850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 30952,
      "e": 30850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31023,
      "e": 30921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 31127,
      "e": 31025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 31127,
      "e": 31025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31215,
      "e": 31113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 31271,
      "e": 31169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 31272,
      "e": 31170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31359,
      "e": 31257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 31448,
      "e": 31346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31448,
      "e": 31346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31544,
      "e": 31442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31552,
      "e": 31450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31553,
      "e": 31451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31615,
      "e": 31513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 31703,
      "e": 31601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 31703,
      "e": 31601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31816,
      "e": 31714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 31816,
      "e": 31714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31863,
      "e": 31761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 31927,
      "e": 31825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32047,
      "e": 31945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 32048,
      "e": 31946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32144,
      "e": 32042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 32248,
      "e": 32146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32249,
      "e": 32147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32351,
      "e": 32249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32359,
      "e": 32257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32359,
      "e": 32257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32447,
      "e": 32345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 32536,
      "e": 32434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32536,
      "e": 32434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32583,
      "e": 32481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32703,
      "e": 32601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 32704,
      "e": 32602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32767,
      "e": 32665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 32775,
      "e": 32673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32775,
      "e": 32673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32864,
      "e": 32762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32896,
      "e": 32794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32896,
      "e": 32794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32975,
      "e": 32873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32999,
      "e": 32897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 32999,
      "e": 32897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33103,
      "e": 33001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33103,
      "e": 33001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33127,
      "e": 33025,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wi"
    },
    {
      "t": 33175,
      "e": 33073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33215,
      "e": 33113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33216,
      "e": 33114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33319,
      "e": 33217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33351,
      "e": 33249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33352,
      "e": 33250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33456,
      "e": 33354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 33488,
      "e": 33386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33488,
      "e": 33386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33535,
      "e": 33433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33568,
      "e": 33466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33569,
      "e": 33467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33663,
      "e": 33561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33711,
      "e": 33609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33712,
      "e": 33610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33800,
      "e": 33698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 33840,
      "e": 33738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33842,
      "e": 33740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33935,
      "e": 33833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 33951,
      "e": 33849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33951,
      "e": 33849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34031,
      "e": 33929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34112,
      "e": 34010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 34112,
      "e": 34010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34215,
      "e": 34113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 34271,
      "e": 34169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34272,
      "e": 34170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34376,
      "e": 34274,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34512,
      "e": 34410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34513,
      "e": 34411,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34583,
      "e": 34481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34680,
      "e": 34578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34680,
      "e": 34578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34736,
      "e": 34634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34857,
      "e": 34755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34857,
      "e": 34755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34904,
      "e": 34802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 34904,
      "e": 34802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34976,
      "e": 34874,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 35000,
      "e": 34898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35112,
      "e": 35010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 35113,
      "e": 35011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35216,
      "e": 35114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 35256,
      "e": 35154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35256,
      "e": 35154,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35328,
      "e": 35226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36832,
      "e": 36730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 37332,
      "e": 37230,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 37344,
      "e": 37242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 37345,
      "e": 37243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37424,
      "e": 37322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 37448,
      "e": 37346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37488,
      "e": 37386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37488,
      "e": 37386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37568,
      "e": 37466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37624,
      "e": 37522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37624,
      "e": 37522,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37687,
      "e": 37585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37688,
      "e": 37586,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37719,
      "e": 37617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 37760,
      "e": 37658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37799,
      "e": 37697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 37800,
      "e": 37698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37872,
      "e": 37770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37873,
      "e": 37771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37879,
      "e": 37777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 37936,
      "e": 37834,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37993,
      "e": 37891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 38088,
      "e": 37986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38089,
      "e": 37987,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38151,
      "e": 38049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 38256,
      "e": 38154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38760,
      "e": 38658,
      "ty": 41,
      "x": 49449,
      "y": 30959,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38810,
      "e": 38708,
      "ty": 2,
      "x": 500,
      "y": 595
    },
    {
      "t": 38822,
      "e": 38720,
      "ty": 7,
      "x": 493,
      "y": 609,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38909,
      "e": 38807,
      "ty": 2,
      "x": 484,
      "y": 635
    },
    {
      "t": 39010,
      "e": 38908,
      "ty": 41,
      "x": 43492,
      "y": 34734,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 39071,
      "e": 38969,
      "ty": 6,
      "x": 449,
      "y": 658,
      "ta": "#strategyButton"
    },
    {
      "t": 39109,
      "e": 39007,
      "ty": 2,
      "x": 440,
      "y": 665
    },
    {
      "t": 39210,
      "e": 39108,
      "ty": 2,
      "x": 425,
      "y": 678
    },
    {
      "t": 39260,
      "e": 39158,
      "ty": 41,
      "x": 47188,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 39261,
      "e": 39159,
      "ty": 3,
      "x": 425,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 39263,
      "e": 39161,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "For the lines going right slanting right, the events that start at 12 PM will begin at 12 PM on the x-axis and then move upwards, like with the letters M and L"
    },
    {
      "t": 39264,
      "e": 39162,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39265,
      "e": 39163,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 39363,
      "e": 39261,
      "ty": 4,
      "x": 47188,
      "y": 44844,
      "ta": "#strategyButton"
    },
    {
      "t": 39374,
      "e": 39272,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 39376,
      "e": 39274,
      "ty": 5,
      "x": 425,
      "y": 678,
      "ta": "#strategyButton"
    },
    {
      "t": 39385,
      "e": 39283,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 40383,
      "e": 40281,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 41110,
      "e": 41008,
      "ty": 2,
      "x": 465,
      "y": 661
    },
    {
      "t": 41209,
      "e": 41107,
      "ty": 2,
      "x": 775,
      "y": 607
    },
    {
      "t": 41259,
      "e": 41157,
      "ty": 41,
      "x": 5407,
      "y": 6342,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 41309,
      "e": 41207,
      "ty": 2,
      "x": 863,
      "y": 586
    },
    {
      "t": 41357,
      "e": 41255,
      "ty": 6,
      "x": 910,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41409,
      "e": 41307,
      "ty": 2,
      "x": 920,
      "y": 561
    },
    {
      "t": 41424,
      "e": 41322,
      "ty": 7,
      "x": 924,
      "y": 551,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41509,
      "e": 41407,
      "ty": 2,
      "x": 925,
      "y": 541
    },
    {
      "t": 41509,
      "e": 41407,
      "ty": 41,
      "x": 25305,
      "y": 35938,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 41564,
      "e": 41462,
      "ty": 3,
      "x": 925,
      "y": 540,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 41608,
      "e": 41506,
      "ty": 2,
      "x": 925,
      "y": 539
    },
    {
      "t": 41676,
      "e": 41574,
      "ty": 4,
      "x": 25305,
      "y": 34529,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 41676,
      "e": 41574,
      "ty": 5,
      "x": 925,
      "y": 539,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 41760,
      "e": 41658,
      "ty": 41,
      "x": 25305,
      "y": 34529,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 41892,
      "e": 41790,
      "ty": 3,
      "x": 925,
      "y": 539,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 41894,
      "e": 41792,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41996,
      "e": 41894,
      "ty": 4,
      "x": 25305,
      "y": 34529,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 41996,
      "e": 41894,
      "ty": 5,
      "x": 925,
      "y": 539,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 42109,
      "e": 42007,
      "ty": 2,
      "x": 926,
      "y": 543
    },
    {
      "t": 42209,
      "e": 42107,
      "ty": 2,
      "x": 922,
      "y": 553
    },
    {
      "t": 42224,
      "e": 42122,
      "ty": 6,
      "x": 921,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42259,
      "e": 42157,
      "ty": 41,
      "x": 24224,
      "y": 12482,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42309,
      "e": 42207,
      "ty": 2,
      "x": 919,
      "y": 562
    },
    {
      "t": 42364,
      "e": 42262,
      "ty": 3,
      "x": 919,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42408,
      "e": 42306,
      "ty": 2,
      "x": 919,
      "y": 565
    },
    {
      "t": 42484,
      "e": 42382,
      "ty": 4,
      "x": 24007,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42484,
      "e": 42382,
      "ty": 5,
      "x": 919,
      "y": 565,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42509,
      "e": 42407,
      "ty": 41,
      "x": 24007,
      "y": 34327,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43240,
      "e": 43138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 43241,
      "e": 43139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43303,
      "e": 43201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 43410,
      "e": 43308,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 43709,
      "e": 43607,
      "ty": 2,
      "x": 919,
      "y": 573
    },
    {
      "t": 43726,
      "e": 43624,
      "ty": 7,
      "x": 919,
      "y": 578,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43744,
      "e": 43642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 43745,
      "e": 43643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43760,
      "e": 43658,
      "ty": 41,
      "x": 24007,
      "y": 1409,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 43809,
      "e": 43707,
      "ty": 2,
      "x": 918,
      "y": 589
    },
    {
      "t": 43816,
      "e": 43714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 43909,
      "e": 43807,
      "ty": 2,
      "x": 925,
      "y": 616
    },
    {
      "t": 44009,
      "e": 43907,
      "ty": 2,
      "x": 933,
      "y": 636
    },
    {
      "t": 44009,
      "e": 43907,
      "ty": 41,
      "x": 27035,
      "y": 37347,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 44109,
      "e": 44007,
      "ty": 2,
      "x": 938,
      "y": 645
    },
    {
      "t": 44141,
      "e": 44039,
      "ty": 6,
      "x": 941,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44209,
      "e": 44107,
      "ty": 2,
      "x": 941,
      "y": 650
    },
    {
      "t": 44260,
      "e": 44158,
      "ty": 41,
      "x": 28766,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44269,
      "e": 44167,
      "ty": 3,
      "x": 940,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44271,
      "e": 44169,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 44271,
      "e": 44169,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44272,
      "e": 44170,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44309,
      "e": 44207,
      "ty": 2,
      "x": 940,
      "y": 666
    },
    {
      "t": 44427,
      "e": 44325,
      "ty": 4,
      "x": 28549,
      "y": 59293,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44428,
      "e": 44326,
      "ty": 5,
      "x": 940,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44510,
      "e": 44408,
      "ty": 41,
      "x": 28549,
      "y": 59293,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45744,
      "e": 45642,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 45960,
      "e": 45858,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 45961,
      "e": 45859,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46025,
      "e": 45923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 46272,
      "e": 46170,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 46440,
      "e": 46338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "190"
    },
    {
      "t": 46441,
      "e": 46339,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46553,
      "e": 46451,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U."
    },
    {
      "t": 46560,
      "e": 46458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 46680,
      "e": 46578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 46681,
      "e": 46579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46800,
      "e": 46698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U.S"
    },
    {
      "t": 46801,
      "e": 46699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U.S"
    },
    {
      "t": 47109,
      "e": 47007,
      "ty": 2,
      "x": 934,
      "y": 666
    },
    {
      "t": 47209,
      "e": 47107,
      "ty": 2,
      "x": 917,
      "y": 666
    },
    {
      "t": 47260,
      "e": 47158,
      "ty": 41,
      "x": 23575,
      "y": 59293,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47397,
      "e": 47295,
      "ty": 7,
      "x": 921,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47409,
      "e": 47307,
      "ty": 2,
      "x": 921,
      "y": 669
    },
    {
      "t": 47429,
      "e": 47327,
      "ty": 6,
      "x": 930,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47509,
      "e": 47327,
      "ty": 2,
      "x": 941,
      "y": 683
    },
    {
      "t": 47510,
      "e": 47328,
      "ty": 41,
      "x": 23232,
      "y": 13901,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 47609,
      "e": 47427,
      "ty": 2,
      "x": 951,
      "y": 691
    },
    {
      "t": 47709,
      "e": 47527,
      "ty": 2,
      "x": 954,
      "y": 692
    },
    {
      "t": 47759,
      "e": 47577,
      "ty": 41,
      "x": 29932,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50316,
      "e": 50134,
      "ty": 3,
      "x": 954,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50316,
      "e": 50134,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U.S"
    },
    {
      "t": 50316,
      "e": 50134,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50316,
      "e": 50134,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50411,
      "e": 50229,
      "ty": 4,
      "x": 29932,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50412,
      "e": 50230,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50412,
      "e": 50230,
      "ty": 5,
      "x": 954,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50412,
      "e": 50230,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 51424,
      "e": 51242,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 52109,
      "e": 51927,
      "ty": 2,
      "x": 986,
      "y": 550
    },
    {
      "t": 52209,
      "e": 52027,
      "ty": 2,
      "x": 889,
      "y": 255
    },
    {
      "t": 52259,
      "e": 52077,
      "ty": 41,
      "x": 16037,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 53009,
      "e": 52827,
      "ty": 2,
      "x": 867,
      "y": 250
    },
    {
      "t": 53010,
      "e": 52828,
      "ty": 41,
      "x": 10816,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 53109,
      "e": 52927,
      "ty": 2,
      "x": 858,
      "y": 249
    },
    {
      "t": 53209,
      "e": 53027,
      "ty": 2,
      "x": 857,
      "y": 247
    },
    {
      "t": 53259,
      "e": 53077,
      "ty": 41,
      "x": 29133,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 53410,
      "e": 53228,
      "ty": 2,
      "x": 857,
      "y": 245
    },
    {
      "t": 53509,
      "e": 53327,
      "ty": 2,
      "x": 849,
      "y": 237
    },
    {
      "t": 53509,
      "e": 53327,
      "ty": 41,
      "x": 22582,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 53609,
      "e": 53427,
      "ty": 2,
      "x": 848,
      "y": 237
    },
    {
      "t": 53760,
      "e": 53578,
      "ty": 41,
      "x": 21763,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 53910,
      "e": 53728,
      "ty": 2,
      "x": 843,
      "y": 232
    },
    {
      "t": 54009,
      "e": 53827,
      "ty": 2,
      "x": 837,
      "y": 230
    },
    {
      "t": 54009,
      "e": 53827,
      "ty": 41,
      "x": 12756,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 54110,
      "e": 53928,
      "ty": 2,
      "x": 836,
      "y": 230
    },
    {
      "t": 54179,
      "e": 53997,
      "ty": 6,
      "x": 835,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54209,
      "e": 54027,
      "ty": 2,
      "x": 835,
      "y": 235
    },
    {
      "t": 54260,
      "e": 54078,
      "ty": 41,
      "x": 28120,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54309,
      "e": 54127,
      "ty": 2,
      "x": 832,
      "y": 242
    },
    {
      "t": 54410,
      "e": 54228,
      "ty": 2,
      "x": 831,
      "y": 242
    },
    {
      "t": 54435,
      "e": 54253,
      "ty": 3,
      "x": 831,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54435,
      "e": 54253,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54509,
      "e": 54327,
      "ty": 41,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54587,
      "e": 54405,
      "ty": 4,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54587,
      "e": 54405,
      "ty": 5,
      "x": 831,
      "y": 242,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54587,
      "e": 54405,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 54884,
      "e": 54702,
      "ty": 7,
      "x": 834,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 54909,
      "e": 54727,
      "ty": 2,
      "x": 843,
      "y": 265
    },
    {
      "t": 55009,
      "e": 54827,
      "ty": 2,
      "x": 897,
      "y": 499
    },
    {
      "t": 55009,
      "e": 54827,
      "ty": 41,
      "x": 17936,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 55109,
      "e": 54927,
      "ty": 2,
      "x": 872,
      "y": 491
    },
    {
      "t": 55168,
      "e": 54986,
      "ty": 6,
      "x": 833,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 55185,
      "e": 55003,
      "ty": 7,
      "x": 831,
      "y": 434,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 55209,
      "e": 55027,
      "ty": 2,
      "x": 831,
      "y": 427
    },
    {
      "t": 55234,
      "e": 55052,
      "ty": 6,
      "x": 829,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 55259,
      "e": 55077,
      "ty": 41,
      "x": 12996,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 55309,
      "e": 55127,
      "ty": 2,
      "x": 829,
      "y": 416
    },
    {
      "t": 55402,
      "e": 55220,
      "ty": 7,
      "x": 829,
      "y": 422,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 55409,
      "e": 55227,
      "ty": 2,
      "x": 829,
      "y": 422
    },
    {
      "t": 55468,
      "e": 55286,
      "ty": 6,
      "x": 832,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 55509,
      "e": 55327,
      "ty": 2,
      "x": 832,
      "y": 448
    },
    {
      "t": 55509,
      "e": 55327,
      "ty": 41,
      "x": 28120,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 55518,
      "e": 55336,
      "ty": 7,
      "x": 832,
      "y": 450,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 55609,
      "e": 55427,
      "ty": 2,
      "x": 835,
      "y": 454
    },
    {
      "t": 55709,
      "e": 55527,
      "ty": 2,
      "x": 840,
      "y": 462
    },
    {
      "t": 55760,
      "e": 55578,
      "ty": 41,
      "x": 19637,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 55809,
      "e": 55627,
      "ty": 2,
      "x": 841,
      "y": 467
    },
    {
      "t": 55851,
      "e": 55627,
      "ty": 6,
      "x": 839,
      "y": 475,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 55869,
      "e": 55645,
      "ty": 7,
      "x": 839,
      "y": 477,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 55909,
      "e": 55685,
      "ty": 2,
      "x": 837,
      "y": 479
    },
    {
      "t": 56009,
      "e": 55785,
      "ty": 41,
      "x": 16466,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 56155,
      "e": 55931,
      "ty": 6,
      "x": 837,
      "y": 476,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 56209,
      "e": 55985,
      "ty": 2,
      "x": 837,
      "y": 469
    },
    {
      "t": 56235,
      "e": 56011,
      "ty": 7,
      "x": 842,
      "y": 458,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 56260,
      "e": 56036,
      "ty": 41,
      "x": 18833,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 56309,
      "e": 56085,
      "ty": 2,
      "x": 845,
      "y": 451
    },
    {
      "t": 56509,
      "e": 56285,
      "ty": 2,
      "x": 845,
      "y": 450
    },
    {
      "t": 56510,
      "e": 56286,
      "ty": 41,
      "x": 18833,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 56610,
      "e": 56386,
      "ty": 2,
      "x": 844,
      "y": 447
    },
    {
      "t": 56709,
      "e": 56485,
      "ty": 2,
      "x": 842,
      "y": 446
    },
    {
      "t": 56740,
      "e": 56516,
      "ty": 6,
      "x": 839,
      "y": 446,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56756,
      "e": 56532,
      "ty": 3,
      "x": 839,
      "y": 446,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56756,
      "e": 56532,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56756,
      "e": 56532,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56760,
      "e": 56536,
      "ty": 41,
      "x": 63408,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56809,
      "e": 56585,
      "ty": 2,
      "x": 839,
      "y": 446
    },
    {
      "t": 56899,
      "e": 56675,
      "ty": 4,
      "x": 58367,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56899,
      "e": 56675,
      "ty": 5,
      "x": 838,
      "y": 446,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56899,
      "e": 56675,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 56910,
      "e": 56686,
      "ty": 2,
      "x": 838,
      "y": 446
    },
    {
      "t": 57009,
      "e": 56785,
      "ty": 2,
      "x": 836,
      "y": 446
    },
    {
      "t": 57009,
      "e": 56785,
      "ty": 41,
      "x": 48284,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 57285,
      "e": 57061,
      "ty": 7,
      "x": 836,
      "y": 457,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 57310,
      "e": 57086,
      "ty": 2,
      "x": 840,
      "y": 475
    },
    {
      "t": 57409,
      "e": 57185,
      "ty": 2,
      "x": 859,
      "y": 558
    },
    {
      "t": 57509,
      "e": 57285,
      "ty": 2,
      "x": 861,
      "y": 578
    },
    {
      "t": 57509,
      "e": 57285,
      "ty": 41,
      "x": 39289,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 57609,
      "e": 57385,
      "ty": 2,
      "x": 838,
      "y": 655
    },
    {
      "t": 57619,
      "e": 57395,
      "ty": 6,
      "x": 835,
      "y": 675,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 57635,
      "e": 57411,
      "ty": 7,
      "x": 833,
      "y": 687,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 57653,
      "e": 57429,
      "ty": 6,
      "x": 830,
      "y": 700,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 57670,
      "e": 57446,
      "ty": 7,
      "x": 829,
      "y": 712,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 57709,
      "e": 57485,
      "ty": 2,
      "x": 824,
      "y": 724
    },
    {
      "t": 57759,
      "e": 57535,
      "ty": 41,
      "x": 145,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 57809,
      "e": 57585,
      "ty": 2,
      "x": 822,
      "y": 727
    },
    {
      "t": 57869,
      "e": 57645,
      "ty": 6,
      "x": 826,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 57909,
      "e": 57685,
      "ty": 2,
      "x": 827,
      "y": 698
    },
    {
      "t": 57919,
      "e": 57695,
      "ty": 7,
      "x": 827,
      "y": 695,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58010,
      "e": 57786,
      "ty": 2,
      "x": 825,
      "y": 694
    },
    {
      "t": 58010,
      "e": 57786,
      "ty": 41,
      "x": 901,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 58109,
      "e": 57885,
      "ty": 2,
      "x": 823,
      "y": 685
    },
    {
      "t": 58210,
      "e": 57986,
      "ty": 2,
      "x": 824,
      "y": 678
    },
    {
      "t": 58260,
      "e": 58036,
      "ty": 41,
      "x": 692,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 58710,
      "e": 58486,
      "ty": 2,
      "x": 827,
      "y": 688
    },
    {
      "t": 58759,
      "e": 58535,
      "ty": 41,
      "x": 1657,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 58804,
      "e": 58580,
      "ty": 6,
      "x": 830,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 58810,
      "e": 58586,
      "ty": 2,
      "x": 830,
      "y": 696
    },
    {
      "t": 58909,
      "e": 58685,
      "ty": 2,
      "x": 830,
      "y": 697
    },
    {
      "t": 59010,
      "e": 58686,
      "ty": 2,
      "x": 829,
      "y": 702
    },
    {
      "t": 59011,
      "e": 58687,
      "ty": 41,
      "x": 12996,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 59210,
      "e": 58886,
      "ty": 2,
      "x": 830,
      "y": 703
    },
    {
      "t": 59259,
      "e": 58935,
      "ty": 3,
      "x": 830,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 59259,
      "e": 58935,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 59260,
      "e": 58936,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 59261,
      "e": 58937,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 59371,
      "e": 59047,
      "ty": 4,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 59371,
      "e": 59047,
      "ty": 5,
      "x": 830,
      "y": 703,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 59371,
      "e": 59047,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 60005,
      "e": 59681,
      "ty": 7,
      "x": 837,
      "y": 711,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 60009,
      "e": 59685,
      "ty": 2,
      "x": 837,
      "y": 711
    },
    {
      "t": 60009,
      "e": 59685,
      "ty": 41,
      "x": 3925,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 60110,
      "e": 59786,
      "ty": 2,
      "x": 874,
      "y": 783
    },
    {
      "t": 60209,
      "e": 59885,
      "ty": 2,
      "x": 874,
      "y": 785
    },
    {
      "t": 60259,
      "e": 59935,
      "ty": 41,
      "x": 28874,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 60310,
      "e": 59986,
      "ty": 2,
      "x": 866,
      "y": 793
    },
    {
      "t": 60409,
      "e": 60085,
      "ty": 2,
      "x": 841,
      "y": 841
    },
    {
      "t": 60510,
      "e": 60186,
      "ty": 2,
      "x": 813,
      "y": 909
    },
    {
      "t": 60510,
      "e": 60186,
      "ty": 41,
      "x": 27722,
      "y": 49912,
      "ta": "html > body"
    },
    {
      "t": 60610,
      "e": 60286,
      "ty": 2,
      "x": 810,
      "y": 938
    },
    {
      "t": 60710,
      "e": 60386,
      "ty": 2,
      "x": 809,
      "y": 943
    },
    {
      "t": 60760,
      "e": 60436,
      "ty": 41,
      "x": 27584,
      "y": 51796,
      "ta": "html > body"
    },
    {
      "t": 60810,
      "e": 60486,
      "ty": 2,
      "x": 813,
      "y": 944
    },
    {
      "t": 60871,
      "e": 60547,
      "ty": 6,
      "x": 826,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 60909,
      "e": 60585,
      "ty": 2,
      "x": 827,
      "y": 938
    },
    {
      "t": 61010,
      "e": 60686,
      "ty": 2,
      "x": 830,
      "y": 937
    },
    {
      "t": 61010,
      "e": 60686,
      "ty": 41,
      "x": 18037,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 61013,
      "e": 60689,
      "ty": 3,
      "x": 830,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 61015,
      "e": 60691,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 61015,
      "e": 60691,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 61092,
      "e": 60768,
      "ty": 4,
      "x": 18037,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 61092,
      "e": 60768,
      "ty": 5,
      "x": 830,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 61092,
      "e": 60768,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 61309,
      "e": 60985,
      "ty": 2,
      "x": 833,
      "y": 937
    },
    {
      "t": 61373,
      "e": 61049,
      "ty": 7,
      "x": 847,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 61409,
      "e": 61085,
      "ty": 2,
      "x": 870,
      "y": 955
    },
    {
      "t": 61509,
      "e": 61185,
      "ty": 2,
      "x": 897,
      "y": 997
    },
    {
      "t": 61509,
      "e": 61185,
      "ty": 41,
      "x": 17936,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 61574,
      "e": 61250,
      "ty": 6,
      "x": 897,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61609,
      "e": 61285,
      "ty": 2,
      "x": 897,
      "y": 1007
    },
    {
      "t": 61710,
      "e": 61386,
      "ty": 2,
      "x": 899,
      "y": 1016
    },
    {
      "t": 61760,
      "e": 61436,
      "ty": 41,
      "x": 35859,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61810,
      "e": 61486,
      "ty": 2,
      "x": 899,
      "y": 1023
    },
    {
      "t": 61836,
      "e": 61512,
      "ty": 3,
      "x": 899,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61838,
      "e": 61514,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 61838,
      "e": 61514,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61924,
      "e": 61600,
      "ty": 4,
      "x": 35859,
      "y": 35746,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61924,
      "e": 61600,
      "ty": 5,
      "x": 899,
      "y": 1023,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61926,
      "e": 61602,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 61926,
      "e": 61602,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 61927,
      "e": 61603,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 62009,
      "e": 61685,
      "ty": 41,
      "x": 30684,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 62260,
      "e": 61936,
      "ty": 41,
      "x": 31820,
      "y": 50799,
      "ta": "html > body"
    },
    {
      "t": 62310,
      "e": 61986,
      "ty": 2,
      "x": 949,
      "y": 773
    },
    {
      "t": 62410,
      "e": 62086,
      "ty": 2,
      "x": 881,
      "y": 550
    },
    {
      "t": 62510,
      "e": 62186,
      "ty": 2,
      "x": 863,
      "y": 508
    },
    {
      "t": 62510,
      "e": 62186,
      "ty": 41,
      "x": 29444,
      "y": 27698,
      "ta": "html > body"
    },
    {
      "t": 62610,
      "e": 62286,
      "ty": 2,
      "x": 863,
      "y": 495
    },
    {
      "t": 62710,
      "e": 62386,
      "ty": 2,
      "x": 864,
      "y": 493
    },
    {
      "t": 62760,
      "e": 62436,
      "ty": 41,
      "x": 29478,
      "y": 26867,
      "ta": "html > body"
    },
    {
      "t": 63241,
      "e": 62917,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 66260,
      "e": 65936,
      "ty": 41,
      "x": 28069,
      "y": 3321,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66309,
      "e": 65985,
      "ty": 2,
      "x": 937,
      "y": 526
    },
    {
      "t": 66409,
      "e": 66085,
      "ty": 2,
      "x": 938,
      "y": 526
    },
    {
      "t": 66509,
      "e": 66185,
      "ty": 41,
      "x": 31709,
      "y": 16974,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66759,
      "e": 66435,
      "ty": 41,
      "x": 31709,
      "y": 15414,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66809,
      "e": 66485,
      "ty": 2,
      "x": 938,
      "y": 522
    },
    {
      "t": 66909,
      "e": 66585,
      "ty": 2,
      "x": 935,
      "y": 524
    },
    {
      "t": 67009,
      "e": 66685,
      "ty": 2,
      "x": 891,
      "y": 670
    },
    {
      "t": 67010,
      "e": 66686,
      "ty": 41,
      "x": 29397,
      "y": 886,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 67109,
      "e": 66785,
      "ty": 2,
      "x": 840,
      "y": 829
    },
    {
      "t": 67209,
      "e": 66885,
      "ty": 2,
      "x": 838,
      "y": 901
    },
    {
      "t": 67259,
      "e": 66935,
      "ty": 41,
      "x": 26986,
      "y": 54061,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 67309,
      "e": 66985,
      "ty": 2,
      "x": 843,
      "y": 907
    },
    {
      "t": 67409,
      "e": 67085,
      "ty": 2,
      "x": 861,
      "y": 900
    },
    {
      "t": 67509,
      "e": 67185,
      "ty": 41,
      "x": 27921,
      "y": 64401,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 70009,
      "e": 69685,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 72909,
      "e": 72185,
      "ty": 2,
      "x": 841,
      "y": 907
    },
    {
      "t": 73009,
      "e": 72285,
      "ty": 2,
      "x": 841,
      "y": 909
    },
    {
      "t": 73009,
      "e": 72285,
      "ty": 41,
      "x": 26937,
      "y": 54200,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73109,
      "e": 72385,
      "ty": 2,
      "x": 854,
      "y": 927
    },
    {
      "t": 73209,
      "e": 72485,
      "ty": 2,
      "x": 884,
      "y": 966
    },
    {
      "t": 73259,
      "e": 72535,
      "ty": 41,
      "x": 30529,
      "y": 61055,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 73309,
      "e": 72585,
      "ty": 2,
      "x": 929,
      "y": 1037
    },
    {
      "t": 73409,
      "e": 72685,
      "ty": 2,
      "x": 941,
      "y": 1059
    },
    {
      "t": 73446,
      "e": 72722,
      "ty": 6,
      "x": 952,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 73509,
      "e": 72785,
      "ty": 2,
      "x": 958,
      "y": 1079
    },
    {
      "t": 73509,
      "e": 72785,
      "ty": 41,
      "x": 26487,
      "y": 12167,
      "ta": "#start"
    },
    {
      "t": 73609,
      "e": 72885,
      "ty": 2,
      "x": 965,
      "y": 1090
    },
    {
      "t": 73709,
      "e": 72985,
      "ty": 2,
      "x": 973,
      "y": 1090
    },
    {
      "t": 73760,
      "e": 73036,
      "ty": 41,
      "x": 35225,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 73809,
      "e": 73085,
      "ty": 2,
      "x": 975,
      "y": 1086
    },
    {
      "t": 73909,
      "e": 73185,
      "ty": 2,
      "x": 975,
      "y": 1078
    },
    {
      "t": 73984,
      "e": 73260,
      "ty": 7,
      "x": 981,
      "y": 1070,
      "ta": "#start"
    },
    {
      "t": 74009,
      "e": 73285,
      "ty": 2,
      "x": 982,
      "y": 1069
    },
    {
      "t": 74010,
      "e": 73286,
      "ty": 41,
      "x": 33874,
      "y": 65279,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74109,
      "e": 73385,
      "ty": 2,
      "x": 984,
      "y": 1067
    },
    {
      "t": 74260,
      "e": 73536,
      "ty": 41,
      "x": 33972,
      "y": 65141,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74409,
      "e": 73685,
      "ty": 2,
      "x": 984,
      "y": 1070
    },
    {
      "t": 74420,
      "e": 73696,
      "ty": 6,
      "x": 984,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 74509,
      "e": 73785,
      "ty": 2,
      "x": 988,
      "y": 1084
    },
    {
      "t": 74509,
      "e": 73785,
      "ty": 41,
      "x": 42870,
      "y": 21804,
      "ta": "#start"
    },
    {
      "t": 74609,
      "e": 73885,
      "ty": 2,
      "x": 991,
      "y": 1090
    },
    {
      "t": 74760,
      "e": 74036,
      "ty": 41,
      "x": 44509,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 75870,
      "e": 75146,
      "ty": 3,
      "x": 991,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 75870,
      "e": 75146,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 75963,
      "e": 75239,
      "ty": 4,
      "x": 44509,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 75964,
      "e": 75240,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 75964,
      "e": 75240,
      "ty": 5,
      "x": 991,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 75964,
      "e": 75240,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 76509,
      "e": 75785,
      "ty": 2,
      "x": 990,
      "y": 1091
    },
    {
      "t": 76510,
      "e": 75786,
      "ty": 41,
      "x": 33817,
      "y": 59995,
      "ta": "html > body"
    },
    {
      "t": 76610,
      "e": 75886,
      "ty": 2,
      "x": 988,
      "y": 1071
    },
    {
      "t": 76709,
      "e": 75985,
      "ty": 2,
      "x": 988,
      "y": 1069
    },
    {
      "t": 76760,
      "e": 76036,
      "ty": 41,
      "x": 33748,
      "y": 58776,
      "ta": "html > body"
    },
    {
      "t": 76999,
      "e": 76275,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 78033,
      "e": 77309,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 383224, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 383230, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 13301, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 397893, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 21133, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"NOVEMBER\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 420033, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 6350, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 427465, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 6394, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 434860, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 59586, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 495836, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-09 AM-12 PM-12 PM-11 AM-11 AM-12 PM-F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1135,y:1000,t:1527271756858};\\\", \\\"{x:1137,y:1000,t:1527271756860};\\\", \\\"{x:1137,y:996,t:1527271757621};\\\", \\\"{x:1137,y:993,t:1527271757628};\\\", \\\"{x:1136,y:985,t:1527271757645};\\\", \\\"{x:1130,y:974,t:1527271757661};\\\", \\\"{x:1119,y:963,t:1527271757678};\\\", \\\"{x:1108,y:951,t:1527271757694};\\\", \\\"{x:1097,y:937,t:1527271757711};\\\", \\\"{x:1082,y:915,t:1527271757727};\\\", \\\"{x:1066,y:889,t:1527271757744};\\\", \\\"{x:1041,y:860,t:1527271757761};\\\", \\\"{x:1023,y:836,t:1527271757777};\\\", \\\"{x:1012,y:820,t:1527271757794};\\\", \\\"{x:1006,y:814,t:1527271757811};\\\", \\\"{x:1003,y:811,t:1527271757827};\\\", \\\"{x:1003,y:807,t:1527271757844};\\\", \\\"{x:1003,y:804,t:1527271757861};\\\", \\\"{x:1003,y:802,t:1527271757907};\\\", \\\"{x:1006,y:803,t:1527271757924};\\\", \\\"{x:1006,y:804,t:1527271757931};\\\", \\\"{x:1010,y:809,t:1527271757944};\\\", \\\"{x:1010,y:810,t:1527271757961};\\\", \\\"{x:1011,y:810,t:1527271758452};\\\", \\\"{x:1011,y:811,t:1527271758508};\\\", \\\"{x:1011,y:812,t:1527271758516};\\\", \\\"{x:1011,y:813,t:1527271758557};\\\", \\\"{x:1011,y:815,t:1527271758564};\\\", \\\"{x:1011,y:818,t:1527271758579};\\\", \\\"{x:1013,y:826,t:1527271758596};\\\", \\\"{x:1013,y:832,t:1527271758612};\\\", \\\"{x:1013,y:838,t:1527271758629};\\\", \\\"{x:1013,y:841,t:1527271758646};\\\", \\\"{x:1013,y:845,t:1527271758662};\\\", \\\"{x:1013,y:848,t:1527271758679};\\\", \\\"{x:1013,y:856,t:1527271758696};\\\", \\\"{x:1013,y:861,t:1527271758712};\\\", \\\"{x:1010,y:870,t:1527271758729};\\\", \\\"{x:1009,y:875,t:1527271758746};\\\", \\\"{x:1009,y:878,t:1527271758762};\\\", \\\"{x:1009,y:879,t:1527271758892};\\\", \\\"{x:1009,y:880,t:1527271758947};\\\", \\\"{x:1008,y:881,t:1527271759133};\\\", \\\"{x:1007,y:881,t:1527271759146};\\\", \\\"{x:1004,y:884,t:1527271759163};\\\", \\\"{x:1004,y:885,t:1527271760379};\\\", \\\"{x:1006,y:889,t:1527271760403};\\\", \\\"{x:1011,y:894,t:1527271760413};\\\", \\\"{x:1023,y:903,t:1527271760429};\\\", \\\"{x:1032,y:909,t:1527271760446};\\\", \\\"{x:1053,y:921,t:1527271760463};\\\", \\\"{x:1066,y:930,t:1527271760480};\\\", \\\"{x:1084,y:940,t:1527271760497};\\\", \\\"{x:1096,y:949,t:1527271760513};\\\", \\\"{x:1109,y:958,t:1527271760529};\\\", \\\"{x:1119,y:967,t:1527271760546};\\\", \\\"{x:1128,y:974,t:1527271760564};\\\", \\\"{x:1129,y:974,t:1527271760644};\\\", \\\"{x:1131,y:975,t:1527271760660};\\\", \\\"{x:1132,y:975,t:1527271760668};\\\", \\\"{x:1133,y:975,t:1527271760680};\\\", \\\"{x:1134,y:975,t:1527271760739};\\\", \\\"{x:1134,y:974,t:1527271760803};\\\", \\\"{x:1134,y:973,t:1527271760818};\\\", \\\"{x:1134,y:972,t:1527271760830};\\\", \\\"{x:1133,y:971,t:1527271760846};\\\", \\\"{x:1133,y:970,t:1527271760864};\\\", \\\"{x:1132,y:969,t:1527271760880};\\\", \\\"{x:1130,y:968,t:1527271760956};\\\", \\\"{x:1129,y:966,t:1527271760995};\\\", \\\"{x:1129,y:965,t:1527271761019};\\\", \\\"{x:1128,y:965,t:1527271761031};\\\", \\\"{x:1127,y:964,t:1527271761046};\\\", \\\"{x:1126,y:963,t:1527271761064};\\\", \\\"{x:1125,y:962,t:1527271761081};\\\", \\\"{x:1124,y:962,t:1527271761096};\\\", \\\"{x:1123,y:962,t:1527271761113};\\\", \\\"{x:1122,y:962,t:1527271761130};\\\", \\\"{x:1122,y:961,t:1527271761147};\\\", \\\"{x:1121,y:961,t:1527271761164};\\\", \\\"{x:1120,y:960,t:1527271761180};\\\", \\\"{x:1119,y:959,t:1527271761197};\\\", \\\"{x:1119,y:958,t:1527271761214};\\\", \\\"{x:1118,y:958,t:1527271761244};\\\", \\\"{x:1117,y:958,t:1527271762965};\\\", \\\"{x:1116,y:958,t:1527271763029};\\\", \\\"{x:1115,y:958,t:1527271763035};\\\", \\\"{x:1114,y:958,t:1527271763049};\\\", \\\"{x:1112,y:958,t:1527271763065};\\\", \\\"{x:1109,y:959,t:1527271763081};\\\", \\\"{x:1107,y:960,t:1527271763099};\\\", \\\"{x:1106,y:960,t:1527271763387};\\\", \\\"{x:1105,y:960,t:1527271763399};\\\", \\\"{x:1101,y:960,t:1527271763416};\\\", \\\"{x:1100,y:960,t:1527271763432};\\\", \\\"{x:1098,y:961,t:1527271763448};\\\", \\\"{x:1098,y:960,t:1527271763604};\\\", \\\"{x:1098,y:958,t:1527271763616};\\\", \\\"{x:1098,y:955,t:1527271763633};\\\", \\\"{x:1100,y:952,t:1527271763650};\\\", \\\"{x:1102,y:950,t:1527271763665};\\\", \\\"{x:1102,y:948,t:1527271763683};\\\", \\\"{x:1105,y:943,t:1527271763699};\\\", \\\"{x:1109,y:935,t:1527271763715};\\\", \\\"{x:1114,y:928,t:1527271763732};\\\", \\\"{x:1117,y:922,t:1527271763748};\\\", \\\"{x:1122,y:915,t:1527271763766};\\\", \\\"{x:1124,y:910,t:1527271763783};\\\", \\\"{x:1126,y:907,t:1527271763799};\\\", \\\"{x:1127,y:904,t:1527271763815};\\\", \\\"{x:1128,y:902,t:1527271763833};\\\", \\\"{x:1130,y:898,t:1527271763848};\\\", \\\"{x:1131,y:894,t:1527271763866};\\\", \\\"{x:1131,y:891,t:1527271763883};\\\", \\\"{x:1130,y:891,t:1527271764245};\\\", \\\"{x:1129,y:892,t:1527271764252};\\\", \\\"{x:1128,y:892,t:1527271764340};\\\", \\\"{x:1127,y:893,t:1527271764350};\\\", \\\"{x:1126,y:894,t:1527271764367};\\\", \\\"{x:1124,y:895,t:1527271764383};\\\", \\\"{x:1123,y:895,t:1527271764400};\\\", \\\"{x:1121,y:897,t:1527271764417};\\\", \\\"{x:1120,y:898,t:1527271764452};\\\", \\\"{x:1120,y:900,t:1527271764500};\\\", \\\"{x:1120,y:901,t:1527271764524};\\\", \\\"{x:1119,y:902,t:1527271764533};\\\", \\\"{x:1118,y:902,t:1527271765355};\\\", \\\"{x:1117,y:902,t:1527271765692};\\\", \\\"{x:1116,y:902,t:1527271766075};\\\", \\\"{x:1116,y:903,t:1527271766452};\\\", \\\"{x:1116,y:904,t:1527271766475};\\\", \\\"{x:1116,y:905,t:1527271768349};\\\", \\\"{x:1115,y:905,t:1527271768356};\\\", \\\"{x:1114,y:905,t:1527271768411};\\\", \\\"{x:1113,y:905,t:1527271769188};\\\", \\\"{x:1113,y:904,t:1527271769203};\\\", \\\"{x:1113,y:905,t:1527271769340};\\\", \\\"{x:1114,y:908,t:1527271769355};\\\", \\\"{x:1119,y:921,t:1527271769370};\\\", \\\"{x:1119,y:925,t:1527271769388};\\\", \\\"{x:1114,y:939,t:1527271769404};\\\", \\\"{x:1111,y:944,t:1527271769420};\\\", \\\"{x:1108,y:948,t:1527271769438};\\\", \\\"{x:1106,y:951,t:1527271769455};\\\", \\\"{x:1106,y:953,t:1527271769470};\\\", \\\"{x:1106,y:954,t:1527271769533};\\\", \\\"{x:1105,y:954,t:1527271769540};\\\", \\\"{x:1104,y:954,t:1527271769554};\\\", \\\"{x:1103,y:956,t:1527271769604};\\\", \\\"{x:1102,y:957,t:1527271769622};\\\", \\\"{x:1101,y:957,t:1527271769638};\\\", \\\"{x:1100,y:959,t:1527271769654};\\\", \\\"{x:1100,y:960,t:1527271769748};\\\", \\\"{x:1100,y:959,t:1527271770052};\\\", \\\"{x:1100,y:958,t:1527271770060};\\\", \\\"{x:1100,y:957,t:1527271770072};\\\", \\\"{x:1100,y:954,t:1527271770088};\\\", \\\"{x:1100,y:953,t:1527271770104};\\\", \\\"{x:1100,y:951,t:1527271770122};\\\", \\\"{x:1100,y:949,t:1527271770138};\\\", \\\"{x:1100,y:947,t:1527271770155};\\\", \\\"{x:1101,y:945,t:1527271770171};\\\", \\\"{x:1101,y:944,t:1527271770204};\\\", \\\"{x:1101,y:943,t:1527271770228};\\\", \\\"{x:1101,y:942,t:1527271770308};\\\", \\\"{x:1102,y:940,t:1527271770853};\\\", \\\"{x:1105,y:938,t:1527271770860};\\\", \\\"{x:1112,y:935,t:1527271770871};\\\", \\\"{x:1134,y:934,t:1527271770888};\\\", \\\"{x:1163,y:931,t:1527271770905};\\\", \\\"{x:1189,y:931,t:1527271770921};\\\", \\\"{x:1225,y:931,t:1527271770937};\\\", \\\"{x:1248,y:932,t:1527271770955};\\\", \\\"{x:1262,y:932,t:1527271770971};\\\", \\\"{x:1277,y:932,t:1527271770988};\\\", \\\"{x:1286,y:932,t:1527271771005};\\\", \\\"{x:1291,y:932,t:1527271771021};\\\", \\\"{x:1293,y:932,t:1527271771037};\\\", \\\"{x:1296,y:932,t:1527271771055};\\\", \\\"{x:1300,y:932,t:1527271771071};\\\", \\\"{x:1305,y:931,t:1527271771088};\\\", \\\"{x:1311,y:931,t:1527271771104};\\\", \\\"{x:1316,y:930,t:1527271771122};\\\", \\\"{x:1317,y:930,t:1527271771137};\\\", \\\"{x:1326,y:929,t:1527271771155};\\\", \\\"{x:1332,y:930,t:1527271771171};\\\", \\\"{x:1337,y:933,t:1527271771188};\\\", \\\"{x:1339,y:934,t:1527271771204};\\\", \\\"{x:1343,y:935,t:1527271771221};\\\", \\\"{x:1347,y:937,t:1527271771238};\\\", \\\"{x:1350,y:939,t:1527271771254};\\\", \\\"{x:1351,y:940,t:1527271771272};\\\", \\\"{x:1354,y:941,t:1527271771288};\\\", \\\"{x:1356,y:943,t:1527271771305};\\\", \\\"{x:1356,y:944,t:1527271771322};\\\", \\\"{x:1357,y:945,t:1527271771339};\\\", \\\"{x:1359,y:948,t:1527271771354};\\\", \\\"{x:1363,y:956,t:1527271771371};\\\", \\\"{x:1364,y:961,t:1527271771389};\\\", \\\"{x:1365,y:976,t:1527271771405};\\\", \\\"{x:1367,y:982,t:1527271771421};\\\", \\\"{x:1369,y:987,t:1527271771439};\\\", \\\"{x:1369,y:988,t:1527271771455};\\\", \\\"{x:1369,y:989,t:1527271771472};\\\", \\\"{x:1369,y:990,t:1527271771499};\\\", \\\"{x:1369,y:991,t:1527271771596};\\\", \\\"{x:1370,y:991,t:1527271771606};\\\", \\\"{x:1372,y:991,t:1527271771622};\\\", \\\"{x:1374,y:991,t:1527271771639};\\\", \\\"{x:1378,y:990,t:1527271771656};\\\", \\\"{x:1382,y:989,t:1527271771673};\\\", \\\"{x:1385,y:988,t:1527271771689};\\\", \\\"{x:1386,y:987,t:1527271771705};\\\", \\\"{x:1387,y:986,t:1527271771721};\\\", \\\"{x:1388,y:985,t:1527271771739};\\\", \\\"{x:1388,y:984,t:1527271771779};\\\", \\\"{x:1388,y:983,t:1527271771818};\\\", \\\"{x:1387,y:983,t:1527271771835};\\\", \\\"{x:1383,y:982,t:1527271771843};\\\", \\\"{x:1380,y:982,t:1527271771856};\\\", \\\"{x:1378,y:980,t:1527271771872};\\\", \\\"{x:1371,y:980,t:1527271771889};\\\", \\\"{x:1369,y:980,t:1527271771906};\\\", \\\"{x:1365,y:980,t:1527271771922};\\\", \\\"{x:1363,y:981,t:1527271771939};\\\", \\\"{x:1360,y:981,t:1527271771955};\\\", \\\"{x:1359,y:982,t:1527271772044};\\\", \\\"{x:1358,y:983,t:1527271772056};\\\", \\\"{x:1356,y:983,t:1527271772073};\\\", \\\"{x:1353,y:983,t:1527271772090};\\\", \\\"{x:1352,y:983,t:1527271772106};\\\", \\\"{x:1349,y:983,t:1527271772122};\\\", \\\"{x:1344,y:983,t:1527271772138};\\\", \\\"{x:1343,y:983,t:1527271772156};\\\", \\\"{x:1340,y:983,t:1527271772172};\\\", \\\"{x:1334,y:983,t:1527271772189};\\\", \\\"{x:1331,y:983,t:1527271772206};\\\", \\\"{x:1325,y:983,t:1527271772222};\\\", \\\"{x:1321,y:983,t:1527271772238};\\\", \\\"{x:1318,y:983,t:1527271772255};\\\", \\\"{x:1315,y:983,t:1527271772273};\\\", \\\"{x:1314,y:983,t:1527271772289};\\\", \\\"{x:1312,y:983,t:1527271772305};\\\", \\\"{x:1306,y:983,t:1527271772323};\\\", \\\"{x:1300,y:984,t:1527271772340};\\\", \\\"{x:1295,y:984,t:1527271772356};\\\", \\\"{x:1291,y:984,t:1527271772373};\\\", \\\"{x:1289,y:984,t:1527271772389};\\\", \\\"{x:1287,y:982,t:1527271772406};\\\", \\\"{x:1285,y:982,t:1527271772422};\\\", \\\"{x:1285,y:981,t:1527271772439};\\\", \\\"{x:1284,y:979,t:1527271772456};\\\", \\\"{x:1284,y:978,t:1527271772473};\\\", \\\"{x:1284,y:977,t:1527271772489};\\\", \\\"{x:1284,y:976,t:1527271772506};\\\", \\\"{x:1284,y:975,t:1527271772523};\\\", \\\"{x:1284,y:974,t:1527271772612};\\\", \\\"{x:1284,y:971,t:1527271772627};\\\", \\\"{x:1283,y:970,t:1527271772660};\\\", \\\"{x:1282,y:969,t:1527271772676};\\\", \\\"{x:1282,y:968,t:1527271772700};\\\", \\\"{x:1282,y:967,t:1527271772732};\\\", \\\"{x:1282,y:966,t:1527271772764};\\\", \\\"{x:1281,y:965,t:1527271772774};\\\", \\\"{x:1281,y:963,t:1527271774717};\\\", \\\"{x:1279,y:961,t:1527271774724};\\\", \\\"{x:1279,y:959,t:1527271774756};\\\", \\\"{x:1279,y:958,t:1527271774763};\\\", \\\"{x:1276,y:957,t:1527271776132};\\\", \\\"{x:1272,y:958,t:1527271776147};\\\", \\\"{x:1271,y:959,t:1527271776159};\\\", \\\"{x:1268,y:961,t:1527271776176};\\\", \\\"{x:1267,y:962,t:1527271776193};\\\", \\\"{x:1267,y:964,t:1527271776210};\\\", \\\"{x:1266,y:965,t:1527271776227};\\\", \\\"{x:1266,y:966,t:1527271776242};\\\", \\\"{x:1268,y:966,t:1527271776372};\\\", \\\"{x:1271,y:966,t:1527271776380};\\\", \\\"{x:1275,y:966,t:1527271776392};\\\", \\\"{x:1282,y:968,t:1527271776410};\\\", \\\"{x:1288,y:968,t:1527271776427};\\\", \\\"{x:1289,y:968,t:1527271776443};\\\", \\\"{x:1291,y:968,t:1527271776459};\\\", \\\"{x:1292,y:968,t:1527271776516};\\\", \\\"{x:1294,y:969,t:1527271776526};\\\", \\\"{x:1296,y:969,t:1527271776542};\\\", \\\"{x:1298,y:970,t:1527271776559};\\\", \\\"{x:1299,y:970,t:1527271776764};\\\", \\\"{x:1302,y:970,t:1527271776777};\\\", \\\"{x:1305,y:970,t:1527271776793};\\\", \\\"{x:1306,y:970,t:1527271776810};\\\", \\\"{x:1307,y:970,t:1527271776836};\\\", \\\"{x:1308,y:970,t:1527271776843};\\\", \\\"{x:1309,y:970,t:1527271776859};\\\", \\\"{x:1311,y:970,t:1527271776876};\\\", \\\"{x:1312,y:970,t:1527271776893};\\\", \\\"{x:1314,y:970,t:1527271776909};\\\", \\\"{x:1315,y:970,t:1527271776926};\\\", \\\"{x:1316,y:970,t:1527271776987};\\\", \\\"{x:1316,y:969,t:1527271777019};\\\", \\\"{x:1317,y:969,t:1527271777026};\\\", \\\"{x:1318,y:969,t:1527271777075};\\\", \\\"{x:1320,y:969,t:1527271777099};\\\", \\\"{x:1322,y:969,t:1527271777110};\\\", \\\"{x:1325,y:969,t:1527271777126};\\\", \\\"{x:1327,y:969,t:1527271777195};\\\", \\\"{x:1328,y:969,t:1527271777211};\\\", \\\"{x:1324,y:969,t:1527271777317};\\\", \\\"{x:1323,y:969,t:1527271777326};\\\", \\\"{x:1318,y:969,t:1527271777344};\\\", \\\"{x:1312,y:969,t:1527271777361};\\\", \\\"{x:1306,y:969,t:1527271777377};\\\", \\\"{x:1302,y:969,t:1527271777394};\\\", \\\"{x:1301,y:968,t:1527271777411};\\\", \\\"{x:1300,y:968,t:1527271777516};\\\", \\\"{x:1299,y:968,t:1527271777588};\\\", \\\"{x:1298,y:968,t:1527271777604};\\\", \\\"{x:1297,y:968,t:1527271777611};\\\", \\\"{x:1295,y:968,t:1527271777628};\\\", \\\"{x:1294,y:968,t:1527271777644};\\\", \\\"{x:1296,y:968,t:1527271787052};\\\", \\\"{x:1299,y:968,t:1527271787068};\\\", \\\"{x:1302,y:968,t:1527271787085};\\\", \\\"{x:1306,y:966,t:1527271787101};\\\", \\\"{x:1310,y:964,t:1527271787118};\\\", \\\"{x:1317,y:962,t:1527271787136};\\\", \\\"{x:1321,y:961,t:1527271787151};\\\", \\\"{x:1324,y:958,t:1527271787167};\\\", \\\"{x:1325,y:957,t:1527271787185};\\\", \\\"{x:1327,y:955,t:1527271787201};\\\", \\\"{x:1329,y:953,t:1527271787217};\\\", \\\"{x:1331,y:951,t:1527271787234};\\\", \\\"{x:1331,y:949,t:1527271787250};\\\", \\\"{x:1332,y:948,t:1527271787267};\\\", \\\"{x:1331,y:948,t:1527271788284};\\\", \\\"{x:1330,y:948,t:1527271788396};\\\", \\\"{x:1330,y:946,t:1527271788579};\\\", \\\"{x:1330,y:944,t:1527271788587};\\\", \\\"{x:1331,y:932,t:1527271788603};\\\", \\\"{x:1333,y:915,t:1527271788619};\\\", \\\"{x:1336,y:902,t:1527271788635};\\\", \\\"{x:1339,y:884,t:1527271788653};\\\", \\\"{x:1343,y:874,t:1527271788668};\\\", \\\"{x:1346,y:860,t:1527271788687};\\\", \\\"{x:1348,y:844,t:1527271788703};\\\", \\\"{x:1351,y:827,t:1527271788719};\\\", \\\"{x:1357,y:808,t:1527271788736};\\\", \\\"{x:1362,y:787,t:1527271788753};\\\", \\\"{x:1368,y:771,t:1527271788768};\\\", \\\"{x:1370,y:759,t:1527271788786};\\\", \\\"{x:1378,y:744,t:1527271788803};\\\", \\\"{x:1383,y:736,t:1527271788820};\\\", \\\"{x:1389,y:725,t:1527271788836};\\\", \\\"{x:1394,y:717,t:1527271788853};\\\", \\\"{x:1396,y:713,t:1527271788869};\\\", \\\"{x:1398,y:710,t:1527271788887};\\\", \\\"{x:1400,y:706,t:1527271788903};\\\", \\\"{x:1402,y:704,t:1527271788919};\\\", \\\"{x:1404,y:702,t:1527271788936};\\\", \\\"{x:1407,y:701,t:1527271788953};\\\", \\\"{x:1409,y:700,t:1527271788971};\\\", \\\"{x:1411,y:698,t:1527271788986};\\\", \\\"{x:1414,y:695,t:1527271789004};\\\", \\\"{x:1415,y:695,t:1527271789020};\\\", \\\"{x:1415,y:694,t:1527271789037};\\\", \\\"{x:1416,y:693,t:1527271789054};\\\", \\\"{x:1418,y:692,t:1527271789070};\\\", \\\"{x:1419,y:691,t:1527271789087};\\\", \\\"{x:1420,y:690,t:1527271789103};\\\", \\\"{x:1422,y:689,t:1527271789120};\\\", \\\"{x:1424,y:687,t:1527271789136};\\\", \\\"{x:1424,y:685,t:1527271789156};\\\", \\\"{x:1426,y:683,t:1527271789170};\\\", \\\"{x:1427,y:682,t:1527271789187};\\\", \\\"{x:1427,y:683,t:1527271789316};\\\", \\\"{x:1427,y:684,t:1527271789332};\\\", \\\"{x:1425,y:685,t:1527271789340};\\\", \\\"{x:1423,y:688,t:1527271789353};\\\", \\\"{x:1419,y:691,t:1527271789370};\\\", \\\"{x:1418,y:693,t:1527271789387};\\\", \\\"{x:1418,y:694,t:1527271789404};\\\", \\\"{x:1418,y:696,t:1527271789469};\\\", \\\"{x:1416,y:697,t:1527271789476};\\\", \\\"{x:1415,y:698,t:1527271789490};\\\", \\\"{x:1415,y:700,t:1527271789506};\\\", \\\"{x:1414,y:700,t:1527271789530};\\\", \\\"{x:1413,y:702,t:1527271789571};\\\", \\\"{x:1412,y:703,t:1527271789587};\\\", \\\"{x:1412,y:704,t:1527271789603};\\\", \\\"{x:1411,y:706,t:1527271789619};\\\", \\\"{x:1410,y:706,t:1527271789643};\\\", \\\"{x:1410,y:707,t:1527271789659};\\\", \\\"{x:1409,y:708,t:1527271789670};\\\", \\\"{x:1409,y:709,t:1527271789687};\\\", \\\"{x:1406,y:714,t:1527271789703};\\\", \\\"{x:1401,y:720,t:1527271789719};\\\", \\\"{x:1392,y:728,t:1527271789736};\\\", \\\"{x:1380,y:737,t:1527271789753};\\\", \\\"{x:1368,y:754,t:1527271789770};\\\", \\\"{x:1275,y:795,t:1527271789787};\\\", \\\"{x:1159,y:809,t:1527271789803};\\\", \\\"{x:1056,y:809,t:1527271789820};\\\", \\\"{x:997,y:809,t:1527271789837};\\\", \\\"{x:923,y:806,t:1527271789854};\\\", \\\"{x:840,y:795,t:1527271789869};\\\", \\\"{x:770,y:783,t:1527271789887};\\\", \\\"{x:712,y:768,t:1527271789904};\\\", \\\"{x:661,y:749,t:1527271789919};\\\", \\\"{x:634,y:733,t:1527271789937};\\\", \\\"{x:617,y:723,t:1527271789953};\\\", \\\"{x:605,y:716,t:1527271789970};\\\", \\\"{x:593,y:710,t:1527271789987};\\\", \\\"{x:589,y:708,t:1527271790003};\\\", \\\"{x:589,y:706,t:1527271790019};\\\", \\\"{x:588,y:705,t:1527271790042};\\\", \\\"{x:586,y:704,t:1527271790054};\\\", \\\"{x:579,y:695,t:1527271790069};\\\", \\\"{x:574,y:689,t:1527271790086};\\\", \\\"{x:571,y:685,t:1527271790103};\\\", \\\"{x:559,y:679,t:1527271790120};\\\", \\\"{x:543,y:671,t:1527271790136};\\\", \\\"{x:527,y:666,t:1527271790154};\\\", \\\"{x:508,y:657,t:1527271790170};\\\", \\\"{x:489,y:646,t:1527271790187};\\\", \\\"{x:482,y:644,t:1527271790203};\\\", \\\"{x:478,y:642,t:1527271790219};\\\", \\\"{x:470,y:637,t:1527271790238};\\\", \\\"{x:463,y:632,t:1527271790253};\\\", \\\"{x:454,y:626,t:1527271790270};\\\", \\\"{x:442,y:621,t:1527271790287};\\\", \\\"{x:431,y:614,t:1527271790305};\\\", \\\"{x:426,y:611,t:1527271790321};\\\", \\\"{x:424,y:610,t:1527271790337};\\\", \\\"{x:423,y:607,t:1527271790354};\\\", \\\"{x:423,y:601,t:1527271790370};\\\", \\\"{x:423,y:600,t:1527271790387};\\\", \\\"{x:421,y:598,t:1527271790403};\\\", \\\"{x:421,y:597,t:1527271790420};\\\", \\\"{x:421,y:593,t:1527271790437};\\\", \\\"{x:421,y:590,t:1527271790454};\\\", \\\"{x:422,y:587,t:1527271790470};\\\", \\\"{x:422,y:584,t:1527271790487};\\\", \\\"{x:422,y:581,t:1527271790505};\\\", \\\"{x:422,y:580,t:1527271790538};\\\", \\\"{x:422,y:578,t:1527271790603};\\\", \\\"{x:422,y:577,t:1527271790627};\\\", \\\"{x:421,y:577,t:1527271790638};\\\", \\\"{x:418,y:576,t:1527271790654};\\\", \\\"{x:417,y:574,t:1527271790673};\\\", \\\"{x:415,y:573,t:1527271790688};\\\", \\\"{x:413,y:572,t:1527271790704};\\\", \\\"{x:410,y:571,t:1527271790720};\\\", \\\"{x:407,y:569,t:1527271790738};\\\", \\\"{x:405,y:568,t:1527271790754};\\\", \\\"{x:404,y:566,t:1527271790794};\\\", \\\"{x:404,y:565,t:1527271790805};\\\", \\\"{x:402,y:564,t:1527271790827};\\\", \\\"{x:401,y:563,t:1527271790843};\\\", \\\"{x:400,y:563,t:1527271790854};\\\", \\\"{x:400,y:562,t:1527271790871};\\\", \\\"{x:402,y:562,t:1527271791226};\\\", \\\"{x:408,y:563,t:1527271791238};\\\", \\\"{x:417,y:570,t:1527271791255};\\\", \\\"{x:432,y:587,t:1527271791272};\\\", \\\"{x:449,y:608,t:1527271791288};\\\", \\\"{x:463,y:630,t:1527271791305};\\\", \\\"{x:478,y:645,t:1527271791321};\\\", \\\"{x:488,y:658,t:1527271791339};\\\", \\\"{x:494,y:667,t:1527271791355};\\\", \\\"{x:497,y:671,t:1527271791372};\\\", \\\"{x:497,y:678,t:1527271791389};\\\", \\\"{x:498,y:684,t:1527271791404};\\\", \\\"{x:498,y:687,t:1527271791421};\\\", \\\"{x:500,y:689,t:1527271791438};\\\", \\\"{x:500,y:690,t:1527271791454};\\\", \\\"{x:500,y:694,t:1527271791667};\\\", \\\"{x:502,y:697,t:1527271791684};\\\", \\\"{x:504,y:700,t:1527271791692};\\\", \\\"{x:504,y:703,t:1527271791707};\\\", \\\"{x:505,y:706,t:1527271791721};\\\", \\\"{x:505,y:708,t:1527271791738};\\\", \\\"{x:505,y:710,t:1527271791755};\\\", \\\"{x:505,y:712,t:1527271791772};\\\", \\\"{x:505,y:713,t:1527271791788};\\\" ] }, { \\\"rt\\\": 10072, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 507467, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-K -K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:704,t:1527271818953};\\\", \\\"{x:536,y:662,t:1527271818962};\\\", \\\"{x:590,y:590,t:1527271818976};\\\", \\\"{x:831,y:362,t:1527271818991};\\\", \\\"{x:929,y:303,t:1527271819006};\\\", \\\"{x:1237,y:223,t:1527271819023};\\\", \\\"{x:1342,y:214,t:1527271819040};\\\", \\\"{x:1343,y:214,t:1527271819057};\\\", \\\"{x:1344,y:214,t:1527271819937};\\\", \\\"{x:1348,y:214,t:1527271819944};\\\", \\\"{x:1354,y:216,t:1527271819957};\\\", \\\"{x:1366,y:220,t:1527271819974};\\\", \\\"{x:1379,y:227,t:1527271819990};\\\", \\\"{x:1390,y:233,t:1527271820008};\\\", \\\"{x:1412,y:251,t:1527271820024};\\\", \\\"{x:1438,y:264,t:1527271820041};\\\", \\\"{x:1448,y:274,t:1527271820058};\\\", \\\"{x:1475,y:289,t:1527271820075};\\\", \\\"{x:1498,y:299,t:1527271820090};\\\", \\\"{x:1520,y:309,t:1527271820107};\\\", \\\"{x:1547,y:319,t:1527271820124};\\\", \\\"{x:1573,y:323,t:1527271820140};\\\", \\\"{x:1595,y:328,t:1527271820157};\\\", \\\"{x:1603,y:330,t:1527271820175};\\\", \\\"{x:1603,y:341,t:1527271820190};\\\", \\\"{x:1574,y:380,t:1527271820207};\\\", \\\"{x:1498,y:486,t:1527271820224};\\\", \\\"{x:1461,y:548,t:1527271820240};\\\", \\\"{x:1451,y:605,t:1527271820257};\\\", \\\"{x:1441,y:680,t:1527271820274};\\\", \\\"{x:1431,y:739,t:1527271820290};\\\", \\\"{x:1425,y:789,t:1527271820308};\\\", \\\"{x:1425,y:816,t:1527271820324};\\\", \\\"{x:1427,y:831,t:1527271820339};\\\", \\\"{x:1428,y:833,t:1527271820356};\\\", \\\"{x:1429,y:832,t:1527271820856};\\\", \\\"{x:1442,y:823,t:1527271820874};\\\", \\\"{x:1451,y:811,t:1527271820890};\\\", \\\"{x:1466,y:796,t:1527271820907};\\\", \\\"{x:1478,y:777,t:1527271820924};\\\", \\\"{x:1485,y:761,t:1527271820940};\\\", \\\"{x:1492,y:747,t:1527271820957};\\\", \\\"{x:1500,y:731,t:1527271820973};\\\", \\\"{x:1504,y:715,t:1527271820990};\\\", \\\"{x:1511,y:691,t:1527271821007};\\\", \\\"{x:1515,y:676,t:1527271821023};\\\", \\\"{x:1516,y:664,t:1527271821040};\\\", \\\"{x:1518,y:658,t:1527271821057};\\\", \\\"{x:1520,y:654,t:1527271821074};\\\", \\\"{x:1521,y:651,t:1527271821090};\\\", \\\"{x:1524,y:648,t:1527271821107};\\\", \\\"{x:1528,y:645,t:1527271821127};\\\", \\\"{x:1531,y:639,t:1527271821140};\\\", \\\"{x:1544,y:625,t:1527271821156};\\\", \\\"{x:1560,y:612,t:1527271821174};\\\", \\\"{x:1576,y:603,t:1527271821190};\\\", \\\"{x:1595,y:589,t:1527271821206};\\\", \\\"{x:1609,y:579,t:1527271821223};\\\", \\\"{x:1617,y:573,t:1527271821239};\\\", \\\"{x:1621,y:570,t:1527271821257};\\\", \\\"{x:1624,y:567,t:1527271821274};\\\", \\\"{x:1626,y:562,t:1527271821290};\\\", \\\"{x:1628,y:557,t:1527271821307};\\\", \\\"{x:1630,y:551,t:1527271821324};\\\", \\\"{x:1630,y:557,t:1527271821383};\\\", \\\"{x:1630,y:567,t:1527271821391};\\\", \\\"{x:1625,y:620,t:1527271821407};\\\", \\\"{x:1623,y:701,t:1527271821423};\\\", \\\"{x:1616,y:773,t:1527271821440};\\\", \\\"{x:1616,y:831,t:1527271821457};\\\", \\\"{x:1616,y:865,t:1527271821474};\\\", \\\"{x:1622,y:887,t:1527271821490};\\\", \\\"{x:1630,y:901,t:1527271821507};\\\", \\\"{x:1634,y:906,t:1527271821524};\\\", \\\"{x:1633,y:907,t:1527271821592};\\\", \\\"{x:1630,y:907,t:1527271821607};\\\", \\\"{x:1614,y:908,t:1527271821624};\\\", \\\"{x:1599,y:908,t:1527271821641};\\\", \\\"{x:1579,y:908,t:1527271821657};\\\", \\\"{x:1569,y:902,t:1527271821674};\\\", \\\"{x:1553,y:893,t:1527271821690};\\\", \\\"{x:1540,y:886,t:1527271821707};\\\", \\\"{x:1531,y:877,t:1527271821724};\\\", \\\"{x:1526,y:868,t:1527271821739};\\\", \\\"{x:1522,y:855,t:1527271821757};\\\", \\\"{x:1519,y:844,t:1527271821774};\\\", \\\"{x:1518,y:839,t:1527271821789};\\\", \\\"{x:1517,y:837,t:1527271821807};\\\", \\\"{x:1517,y:835,t:1527271821823};\\\", \\\"{x:1517,y:830,t:1527271821840};\\\", \\\"{x:1517,y:818,t:1527271821857};\\\", \\\"{x:1517,y:807,t:1527271821874};\\\", \\\"{x:1517,y:793,t:1527271821890};\\\", \\\"{x:1514,y:788,t:1527271821907};\\\", \\\"{x:1513,y:786,t:1527271821923};\\\", \\\"{x:1511,y:785,t:1527271821940};\\\", \\\"{x:1507,y:785,t:1527271821957};\\\", \\\"{x:1499,y:787,t:1527271821974};\\\", \\\"{x:1493,y:795,t:1527271821990};\\\", \\\"{x:1456,y:873,t:1527271822007};\\\", \\\"{x:1438,y:936,t:1527271822023};\\\", \\\"{x:1428,y:983,t:1527271822040};\\\", \\\"{x:1424,y:1006,t:1527271822058};\\\", \\\"{x:1422,y:1020,t:1527271822074};\\\", \\\"{x:1422,y:1025,t:1527271822090};\\\", \\\"{x:1420,y:1028,t:1527271822108};\\\", \\\"{x:1418,y:1027,t:1527271822143};\\\", \\\"{x:1411,y:1020,t:1527271822157};\\\", \\\"{x:1396,y:999,t:1527271822174};\\\", \\\"{x:1375,y:970,t:1527271822190};\\\", \\\"{x:1351,y:938,t:1527271822207};\\\", \\\"{x:1339,y:921,t:1527271822223};\\\", \\\"{x:1330,y:910,t:1527271822240};\\\", \\\"{x:1323,y:903,t:1527271822257};\\\", \\\"{x:1320,y:900,t:1527271822274};\\\", \\\"{x:1318,y:899,t:1527271822290};\\\", \\\"{x:1310,y:901,t:1527271822307};\\\", \\\"{x:1304,y:911,t:1527271822324};\\\", \\\"{x:1298,y:919,t:1527271822340};\\\", \\\"{x:1284,y:927,t:1527271822357};\\\", \\\"{x:1280,y:930,t:1527271822374};\\\", \\\"{x:1276,y:931,t:1527271822390};\\\", \\\"{x:1275,y:932,t:1527271822407};\\\", \\\"{x:1273,y:929,t:1527271822424};\\\", \\\"{x:1272,y:920,t:1527271822440};\\\", \\\"{x:1266,y:903,t:1527271822457};\\\", \\\"{x:1263,y:880,t:1527271822475};\\\", \\\"{x:1263,y:857,t:1527271822490};\\\", \\\"{x:1265,y:830,t:1527271822508};\\\", \\\"{x:1280,y:790,t:1527271822524};\\\", \\\"{x:1307,y:737,t:1527271822540};\\\", \\\"{x:1331,y:689,t:1527271822557};\\\", \\\"{x:1342,y:657,t:1527271822575};\\\", \\\"{x:1356,y:628,t:1527271822590};\\\", \\\"{x:1364,y:612,t:1527271822608};\\\", \\\"{x:1367,y:606,t:1527271822624};\\\", \\\"{x:1369,y:602,t:1527271822641};\\\", \\\"{x:1369,y:600,t:1527271822657};\\\", \\\"{x:1371,y:595,t:1527271822674};\\\", \\\"{x:1373,y:589,t:1527271822691};\\\", \\\"{x:1377,y:579,t:1527271822708};\\\", \\\"{x:1382,y:568,t:1527271822724};\\\", \\\"{x:1386,y:561,t:1527271822740};\\\", \\\"{x:1386,y:558,t:1527271822758};\\\", \\\"{x:1387,y:555,t:1527271822774};\\\", \\\"{x:1387,y:553,t:1527271822790};\\\", \\\"{x:1391,y:545,t:1527271822807};\\\", \\\"{x:1397,y:535,t:1527271822824};\\\", \\\"{x:1404,y:519,t:1527271822841};\\\", \\\"{x:1411,y:506,t:1527271822857};\\\", \\\"{x:1421,y:494,t:1527271822874};\\\", \\\"{x:1428,y:485,t:1527271822890};\\\", \\\"{x:1432,y:480,t:1527271822907};\\\", \\\"{x:1436,y:478,t:1527271822924};\\\", \\\"{x:1439,y:475,t:1527271822940};\\\", \\\"{x:1441,y:475,t:1527271822956};\\\", \\\"{x:1449,y:471,t:1527271822974};\\\", \\\"{x:1458,y:468,t:1527271822990};\\\", \\\"{x:1467,y:468,t:1527271823006};\\\", \\\"{x:1470,y:469,t:1527271823023};\\\", \\\"{x:1472,y:470,t:1527271823040};\\\", \\\"{x:1473,y:471,t:1527271823057};\\\", \\\"{x:1475,y:471,t:1527271823079};\\\", \\\"{x:1476,y:471,t:1527271823096};\\\", \\\"{x:1477,y:471,t:1527271823107};\\\", \\\"{x:1479,y:471,t:1527271823124};\\\", \\\"{x:1482,y:471,t:1527271823140};\\\", \\\"{x:1490,y:471,t:1527271823157};\\\", \\\"{x:1497,y:471,t:1527271823174};\\\", \\\"{x:1512,y:468,t:1527271823190};\\\", \\\"{x:1539,y:466,t:1527271823207};\\\", \\\"{x:1546,y:466,t:1527271823223};\\\", \\\"{x:1555,y:464,t:1527271823240};\\\", \\\"{x:1569,y:460,t:1527271823257};\\\", \\\"{x:1590,y:456,t:1527271823274};\\\", \\\"{x:1604,y:453,t:1527271823290};\\\", \\\"{x:1616,y:451,t:1527271823307};\\\", \\\"{x:1621,y:450,t:1527271823324};\\\", \\\"{x:1625,y:449,t:1527271823340};\\\", \\\"{x:1626,y:448,t:1527271823536};\\\", \\\"{x:1626,y:446,t:1527271823543};\\\", \\\"{x:1626,y:445,t:1527271823557};\\\", \\\"{x:1626,y:444,t:1527271823574};\\\", \\\"{x:1624,y:444,t:1527271823623};\\\", \\\"{x:1623,y:444,t:1527271823647};\\\", \\\"{x:1620,y:444,t:1527271823657};\\\", \\\"{x:1613,y:449,t:1527271823674};\\\", \\\"{x:1603,y:461,t:1527271823690};\\\", \\\"{x:1592,y:477,t:1527271823707};\\\", \\\"{x:1582,y:493,t:1527271823724};\\\", \\\"{x:1571,y:512,t:1527271823740};\\\", \\\"{x:1567,y:524,t:1527271823757};\\\", \\\"{x:1557,y:538,t:1527271823775};\\\", \\\"{x:1551,y:549,t:1527271823790};\\\", \\\"{x:1543,y:567,t:1527271823808};\\\", \\\"{x:1536,y:579,t:1527271823824};\\\", \\\"{x:1526,y:595,t:1527271823840};\\\", \\\"{x:1524,y:602,t:1527271823857};\\\", \\\"{x:1524,y:606,t:1527271823874};\\\", \\\"{x:1522,y:610,t:1527271823890};\\\", \\\"{x:1522,y:611,t:1527271823908};\\\", \\\"{x:1520,y:614,t:1527271823924};\\\", \\\"{x:1518,y:617,t:1527271823941};\\\", \\\"{x:1518,y:620,t:1527271823957};\\\", \\\"{x:1515,y:623,t:1527271823974};\\\", \\\"{x:1515,y:625,t:1527271823993};\\\", \\\"{x:1514,y:626,t:1527271824007};\\\", \\\"{x:1513,y:628,t:1527271824023};\\\", \\\"{x:1509,y:634,t:1527271824041};\\\", \\\"{x:1505,y:641,t:1527271824057};\\\", \\\"{x:1503,y:647,t:1527271824074};\\\", \\\"{x:1502,y:651,t:1527271824090};\\\", \\\"{x:1501,y:655,t:1527271824108};\\\", \\\"{x:1500,y:657,t:1527271824124};\\\", \\\"{x:1498,y:664,t:1527271824140};\\\", \\\"{x:1493,y:671,t:1527271824157};\\\", \\\"{x:1486,y:685,t:1527271824174};\\\", \\\"{x:1474,y:703,t:1527271824191};\\\", \\\"{x:1462,y:724,t:1527271824207};\\\", \\\"{x:1461,y:731,t:1527271824224};\\\", \\\"{x:1457,y:742,t:1527271824240};\\\", \\\"{x:1452,y:756,t:1527271824257};\\\", \\\"{x:1449,y:768,t:1527271824274};\\\", \\\"{x:1445,y:784,t:1527271824290};\\\", \\\"{x:1443,y:796,t:1527271824308};\\\", \\\"{x:1442,y:805,t:1527271824324};\\\", \\\"{x:1440,y:811,t:1527271824340};\\\", \\\"{x:1438,y:817,t:1527271824357};\\\", \\\"{x:1433,y:824,t:1527271824375};\\\", \\\"{x:1425,y:835,t:1527271824390};\\\", \\\"{x:1390,y:855,t:1527271824408};\\\", \\\"{x:1344,y:864,t:1527271824424};\\\", \\\"{x:1261,y:865,t:1527271824440};\\\", \\\"{x:1137,y:839,t:1527271824457};\\\", \\\"{x:981,y:808,t:1527271824474};\\\", \\\"{x:824,y:769,t:1527271824490};\\\", \\\"{x:704,y:744,t:1527271824507};\\\", \\\"{x:619,y:725,t:1527271824523};\\\", \\\"{x:594,y:718,t:1527271824540};\\\", \\\"{x:585,y:717,t:1527271824557};\\\", \\\"{x:582,y:718,t:1527271824574};\\\", \\\"{x:583,y:721,t:1527271824590};\\\", \\\"{x:587,y:724,t:1527271824607};\\\", \\\"{x:587,y:722,t:1527271824663};\\\", \\\"{x:587,y:715,t:1527271824674};\\\", \\\"{x:583,y:693,t:1527271824691};\\\", \\\"{x:579,y:674,t:1527271824707};\\\", \\\"{x:572,y:662,t:1527271824724};\\\", \\\"{x:561,y:653,t:1527271824741};\\\", \\\"{x:547,y:646,t:1527271824757};\\\", \\\"{x:532,y:642,t:1527271824774};\\\", \\\"{x:521,y:637,t:1527271824790};\\\", \\\"{x:502,y:633,t:1527271824811};\\\", \\\"{x:489,y:630,t:1527271824829};\\\", \\\"{x:479,y:626,t:1527271824845};\\\", \\\"{x:471,y:623,t:1527271824861};\\\", \\\"{x:458,y:621,t:1527271824879};\\\", \\\"{x:452,y:621,t:1527271824895};\\\", \\\"{x:446,y:617,t:1527271824913};\\\", \\\"{x:440,y:615,t:1527271824928};\\\", \\\"{x:439,y:615,t:1527271824946};\\\", \\\"{x:439,y:617,t:1527271824999};\\\", \\\"{x:437,y:617,t:1527271825088};\\\", \\\"{x:435,y:617,t:1527271825095};\\\", \\\"{x:426,y:617,t:1527271825113};\\\", \\\"{x:422,y:615,t:1527271825129};\\\", \\\"{x:419,y:614,t:1527271825147};\\\", \\\"{x:418,y:614,t:1527271825164};\\\", \\\"{x:416,y:614,t:1527271825216};\\\", \\\"{x:413,y:614,t:1527271825230};\\\", \\\"{x:411,y:614,t:1527271825246};\\\", \\\"{x:410,y:614,t:1527271825263};\\\", \\\"{x:408,y:614,t:1527271825368};\\\", \\\"{x:406,y:614,t:1527271825392};\\\", \\\"{x:406,y:614,t:1527271825413};\\\", \\\"{x:404,y:612,t:1527271825431};\\\", \\\"{x:401,y:608,t:1527271825446};\\\", \\\"{x:399,y:602,t:1527271825463};\\\", \\\"{x:399,y:601,t:1527271825480};\\\", \\\"{x:397,y:599,t:1527271825495};\\\", \\\"{x:396,y:597,t:1527271825513};\\\", \\\"{x:395,y:597,t:1527271825530};\\\", \\\"{x:394,y:597,t:1527271825655};\\\", \\\"{x:393,y:597,t:1527271825671};\\\", \\\"{x:393,y:597,t:1527271825688};\\\", \\\"{x:393,y:599,t:1527271825768};\\\", \\\"{x:399,y:603,t:1527271825781};\\\", \\\"{x:413,y:614,t:1527271825798};\\\", \\\"{x:426,y:627,t:1527271825813};\\\", \\\"{x:441,y:642,t:1527271825829};\\\", \\\"{x:462,y:670,t:1527271825847};\\\", \\\"{x:471,y:684,t:1527271825863};\\\", \\\"{x:474,y:692,t:1527271825880};\\\", \\\"{x:478,y:698,t:1527271825896};\\\", \\\"{x:481,y:701,t:1527271825914};\\\", \\\"{x:482,y:704,t:1527271825930};\\\", \\\"{x:485,y:707,t:1527271825946};\\\", \\\"{x:489,y:712,t:1527271825963};\\\", \\\"{x:490,y:716,t:1527271825980};\\\", \\\"{x:493,y:719,t:1527271825997};\\\", \\\"{x:494,y:719,t:1527271826014};\\\", \\\"{x:494,y:720,t:1527271826030};\\\", \\\"{x:494,y:716,t:1527271826152};\\\", \\\"{x:492,y:706,t:1527271826165};\\\", \\\"{x:484,y:690,t:1527271826181};\\\", \\\"{x:472,y:674,t:1527271826198};\\\", \\\"{x:460,y:662,t:1527271826214};\\\", \\\"{x:444,y:651,t:1527271826231};\\\", \\\"{x:425,y:627,t:1527271826249};\\\", \\\"{x:414,y:616,t:1527271826265};\\\", \\\"{x:409,y:609,t:1527271826280};\\\", \\\"{x:405,y:605,t:1527271826297};\\\", \\\"{x:403,y:603,t:1527271826314};\\\", \\\"{x:400,y:602,t:1527271826391};\\\", \\\"{x:398,y:600,t:1527271826398};\\\", \\\"{x:395,y:600,t:1527271826414};\\\", \\\"{x:391,y:598,t:1527271826431};\\\", \\\"{x:389,y:598,t:1527271826447};\\\", \\\"{x:395,y:601,t:1527271826751};\\\", \\\"{x:406,y:607,t:1527271826764};\\\", \\\"{x:426,y:619,t:1527271826782};\\\", \\\"{x:440,y:633,t:1527271826797};\\\", \\\"{x:451,y:647,t:1527271826814};\\\", \\\"{x:461,y:655,t:1527271826832};\\\", \\\"{x:464,y:659,t:1527271826847};\\\", \\\"{x:464,y:664,t:1527271826864};\\\", \\\"{x:464,y:669,t:1527271826881};\\\", \\\"{x:464,y:677,t:1527271826897};\\\", \\\"{x:464,y:679,t:1527271826914};\\\", \\\"{x:464,y:681,t:1527271826931};\\\", \\\"{x:465,y:682,t:1527271826947};\\\", \\\"{x:466,y:684,t:1527271826967};\\\", \\\"{x:466,y:686,t:1527271826991};\\\", \\\"{x:466,y:687,t:1527271826999};\\\", \\\"{x:466,y:689,t:1527271827014};\\\", \\\"{x:466,y:691,t:1527271827031};\\\", \\\"{x:466,y:693,t:1527271827047};\\\", \\\"{x:466,y:694,t:1527271827079};\\\", \\\"{x:466,y:696,t:1527271827087};\\\", \\\"{x:466,y:697,t:1527271827098};\\\", \\\"{x:464,y:710,t:1527271827115};\\\", \\\"{x:462,y:717,t:1527271827131};\\\", \\\"{x:457,y:728,t:1527271827148};\\\", \\\"{x:456,y:729,t:1527271827164};\\\", \\\"{x:456,y:730,t:1527271827216};\\\", \\\"{x:457,y:730,t:1527271827232};\\\", \\\"{x:459,y:730,t:1527271827264};\\\", \\\"{x:460,y:730,t:1527271827282};\\\", \\\"{x:463,y:730,t:1527271827559};\\\", \\\"{x:465,y:730,t:1527271827647};\\\", \\\"{x:465,y:729,t:1527271827663};\\\", \\\"{x:466,y:728,t:1527271827671};\\\", \\\"{x:468,y:727,t:1527271827784};\\\", \\\"{x:471,y:723,t:1527271827798};\\\", \\\"{x:490,y:715,t:1527271827816};\\\", \\\"{x:514,y:707,t:1527271827831};\\\", \\\"{x:540,y:702,t:1527271827848};\\\", \\\"{x:557,y:697,t:1527271827865};\\\", \\\"{x:577,y:691,t:1527271827881};\\\", \\\"{x:593,y:687,t:1527271827899};\\\", \\\"{x:604,y:678,t:1527271827915};\\\", \\\"{x:606,y:677,t:1527271827932};\\\" ] }, { \\\"rt\\\": 8468, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 517157, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-C -11 AM-F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:606,y:674,t:1527271829367};\\\", \\\"{x:606,y:670,t:1527271829383};\\\", \\\"{x:606,y:662,t:1527271829399};\\\", \\\"{x:606,y:655,t:1527271829416};\\\", \\\"{x:606,y:644,t:1527271829434};\\\", \\\"{x:606,y:633,t:1527271829449};\\\", \\\"{x:602,y:614,t:1527271829467};\\\", \\\"{x:596,y:592,t:1527271829484};\\\", \\\"{x:586,y:569,t:1527271829500};\\\", \\\"{x:582,y:558,t:1527271829516};\\\", \\\"{x:577,y:543,t:1527271829533};\\\", \\\"{x:575,y:536,t:1527271829550};\\\", \\\"{x:572,y:531,t:1527271829566};\\\", \\\"{x:571,y:523,t:1527271829583};\\\", \\\"{x:571,y:519,t:1527271829599};\\\", \\\"{x:571,y:515,t:1527271829616};\\\", \\\"{x:571,y:511,t:1527271829634};\\\", \\\"{x:571,y:507,t:1527271829649};\\\", \\\"{x:574,y:498,t:1527271829667};\\\", \\\"{x:579,y:492,t:1527271829683};\\\", \\\"{x:584,y:486,t:1527271829700};\\\", \\\"{x:587,y:483,t:1527271829716};\\\", \\\"{x:590,y:480,t:1527271829733};\\\", \\\"{x:593,y:479,t:1527271829750};\\\", \\\"{x:593,y:480,t:1527271829864};\\\", \\\"{x:593,y:482,t:1527271829880};\\\", \\\"{x:594,y:486,t:1527271829888};\\\", \\\"{x:595,y:487,t:1527271829900};\\\", \\\"{x:602,y:492,t:1527271829917};\\\", \\\"{x:622,y:498,t:1527271829933};\\\", \\\"{x:649,y:500,t:1527271829950};\\\", \\\"{x:670,y:505,t:1527271829966};\\\", \\\"{x:703,y:510,t:1527271829984};\\\", \\\"{x:724,y:514,t:1527271830001};\\\", \\\"{x:746,y:519,t:1527271830016};\\\", \\\"{x:757,y:523,t:1527271830033};\\\", \\\"{x:759,y:524,t:1527271830050};\\\", \\\"{x:759,y:526,t:1527271830079};\\\", \\\"{x:757,y:527,t:1527271830087};\\\", \\\"{x:748,y:528,t:1527271830100};\\\", \\\"{x:730,y:529,t:1527271830116};\\\", \\\"{x:721,y:531,t:1527271830134};\\\", \\\"{x:702,y:532,t:1527271830150};\\\", \\\"{x:682,y:532,t:1527271830166};\\\", \\\"{x:671,y:532,t:1527271830183};\\\", \\\"{x:668,y:531,t:1527271830207};\\\", \\\"{x:664,y:531,t:1527271830216};\\\", \\\"{x:661,y:530,t:1527271830233};\\\", \\\"{x:656,y:527,t:1527271830250};\\\", \\\"{x:655,y:527,t:1527271830312};\\\", \\\"{x:655,y:526,t:1527271830319};\\\", \\\"{x:660,y:525,t:1527271830334};\\\", \\\"{x:687,y:522,t:1527271830351};\\\", \\\"{x:721,y:519,t:1527271830366};\\\", \\\"{x:835,y:519,t:1527271830383};\\\", \\\"{x:900,y:520,t:1527271830400};\\\", \\\"{x:967,y:530,t:1527271830418};\\\", \\\"{x:1059,y:555,t:1527271830433};\\\", \\\"{x:1113,y:565,t:1527271830450};\\\", \\\"{x:1161,y:579,t:1527271830467};\\\", \\\"{x:1211,y:593,t:1527271830483};\\\", \\\"{x:1236,y:602,t:1527271830500};\\\", \\\"{x:1262,y:611,t:1527271830518};\\\", \\\"{x:1279,y:619,t:1527271830535};\\\", \\\"{x:1290,y:627,t:1527271830551};\\\", \\\"{x:1318,y:647,t:1527271830567};\\\", \\\"{x:1336,y:660,t:1527271830584};\\\", \\\"{x:1354,y:677,t:1527271830601};\\\", \\\"{x:1371,y:699,t:1527271830617};\\\", \\\"{x:1384,y:721,t:1527271830634};\\\", \\\"{x:1395,y:734,t:1527271830650};\\\", \\\"{x:1407,y:747,t:1527271830668};\\\", \\\"{x:1413,y:760,t:1527271830684};\\\", \\\"{x:1418,y:773,t:1527271830700};\\\", \\\"{x:1419,y:785,t:1527271830718};\\\", \\\"{x:1419,y:797,t:1527271830734};\\\", \\\"{x:1419,y:807,t:1527271830750};\\\", \\\"{x:1420,y:818,t:1527271830767};\\\", \\\"{x:1421,y:827,t:1527271830784};\\\", \\\"{x:1424,y:832,t:1527271830801};\\\", \\\"{x:1425,y:837,t:1527271830817};\\\", \\\"{x:1426,y:843,t:1527271830835};\\\", \\\"{x:1427,y:850,t:1527271830851};\\\", \\\"{x:1428,y:856,t:1527271830867};\\\", \\\"{x:1432,y:864,t:1527271830884};\\\", \\\"{x:1432,y:869,t:1527271830901};\\\", \\\"{x:1433,y:874,t:1527271830918};\\\", \\\"{x:1433,y:876,t:1527271830934};\\\", \\\"{x:1435,y:881,t:1527271830951};\\\", \\\"{x:1433,y:887,t:1527271830967};\\\", \\\"{x:1429,y:895,t:1527271830985};\\\", \\\"{x:1423,y:900,t:1527271831002};\\\", \\\"{x:1420,y:902,t:1527271831018};\\\", \\\"{x:1418,y:905,t:1527271831034};\\\", \\\"{x:1417,y:906,t:1527271831055};\\\", \\\"{x:1416,y:906,t:1527271831068};\\\", \\\"{x:1415,y:907,t:1527271831085};\\\", \\\"{x:1414,y:907,t:1527271831112};\\\", \\\"{x:1413,y:907,t:1527271831120};\\\", \\\"{x:1411,y:903,t:1527271831135};\\\", \\\"{x:1400,y:875,t:1527271831152};\\\", \\\"{x:1391,y:852,t:1527271831168};\\\", \\\"{x:1375,y:823,t:1527271831185};\\\", \\\"{x:1356,y:786,t:1527271831201};\\\", \\\"{x:1351,y:755,t:1527271831219};\\\", \\\"{x:1340,y:737,t:1527271831235};\\\", \\\"{x:1332,y:725,t:1527271831251};\\\", \\\"{x:1329,y:717,t:1527271831269};\\\", \\\"{x:1326,y:707,t:1527271831284};\\\", \\\"{x:1326,y:701,t:1527271831302};\\\", \\\"{x:1326,y:699,t:1527271831318};\\\", \\\"{x:1326,y:694,t:1527271831334};\\\", \\\"{x:1328,y:689,t:1527271831351};\\\", \\\"{x:1329,y:688,t:1527271831369};\\\", \\\"{x:1330,y:684,t:1527271831385};\\\", \\\"{x:1333,y:676,t:1527271831401};\\\", \\\"{x:1336,y:675,t:1527271831418};\\\", \\\"{x:1337,y:671,t:1527271831434};\\\", \\\"{x:1337,y:669,t:1527271831451};\\\", \\\"{x:1338,y:666,t:1527271831468};\\\", \\\"{x:1339,y:665,t:1527271831485};\\\", \\\"{x:1339,y:664,t:1527271831544};\\\", \\\"{x:1341,y:664,t:1527271831568};\\\", \\\"{x:1343,y:664,t:1527271831575};\\\", \\\"{x:1347,y:664,t:1527271831585};\\\", \\\"{x:1358,y:665,t:1527271831601};\\\", \\\"{x:1380,y:677,t:1527271831618};\\\", \\\"{x:1393,y:691,t:1527271831635};\\\", \\\"{x:1412,y:709,t:1527271831652};\\\", \\\"{x:1432,y:728,t:1527271831668};\\\", \\\"{x:1444,y:747,t:1527271831686};\\\", \\\"{x:1450,y:768,t:1527271831702};\\\", \\\"{x:1453,y:789,t:1527271831719};\\\", \\\"{x:1453,y:807,t:1527271831735};\\\", \\\"{x:1445,y:823,t:1527271831751};\\\", \\\"{x:1438,y:832,t:1527271831768};\\\", \\\"{x:1427,y:840,t:1527271831786};\\\", \\\"{x:1421,y:845,t:1527271831801};\\\", \\\"{x:1414,y:850,t:1527271831819};\\\", \\\"{x:1409,y:853,t:1527271831836};\\\", \\\"{x:1408,y:855,t:1527271831853};\\\", \\\"{x:1408,y:858,t:1527271831868};\\\", \\\"{x:1407,y:859,t:1527271831885};\\\", \\\"{x:1406,y:860,t:1527271831975};\\\", \\\"{x:1401,y:862,t:1527271831986};\\\", \\\"{x:1392,y:862,t:1527271832003};\\\", \\\"{x:1364,y:862,t:1527271832019};\\\", \\\"{x:1350,y:863,t:1527271832035};\\\", \\\"{x:1330,y:861,t:1527271832052};\\\", \\\"{x:1322,y:858,t:1527271832068};\\\", \\\"{x:1310,y:856,t:1527271832085};\\\", \\\"{x:1299,y:853,t:1527271832102};\\\", \\\"{x:1296,y:852,t:1527271832118};\\\", \\\"{x:1295,y:852,t:1527271832167};\\\", \\\"{x:1293,y:852,t:1527271832176};\\\", \\\"{x:1292,y:853,t:1527271832200};\\\", \\\"{x:1291,y:853,t:1527271832215};\\\", \\\"{x:1290,y:853,t:1527271832223};\\\", \\\"{x:1288,y:854,t:1527271832235};\\\", \\\"{x:1285,y:854,t:1527271832252};\\\", \\\"{x:1280,y:854,t:1527271832269};\\\", \\\"{x:1273,y:854,t:1527271832286};\\\", \\\"{x:1266,y:854,t:1527271832303};\\\", \\\"{x:1250,y:854,t:1527271832319};\\\", \\\"{x:1243,y:854,t:1527271832335};\\\", \\\"{x:1237,y:854,t:1527271832352};\\\", \\\"{x:1231,y:854,t:1527271832370};\\\", \\\"{x:1225,y:852,t:1527271832386};\\\", \\\"{x:1219,y:851,t:1527271832402};\\\", \\\"{x:1216,y:848,t:1527271832419};\\\", \\\"{x:1214,y:847,t:1527271832435};\\\", \\\"{x:1211,y:844,t:1527271832455};\\\", \\\"{x:1210,y:844,t:1527271832470};\\\", \\\"{x:1210,y:843,t:1527271832496};\\\", \\\"{x:1209,y:842,t:1527271832504};\\\", \\\"{x:1209,y:841,t:1527271832519};\\\", \\\"{x:1209,y:840,t:1527271832543};\\\", \\\"{x:1209,y:839,t:1527271832552};\\\", \\\"{x:1210,y:837,t:1527271832570};\\\", \\\"{x:1211,y:834,t:1527271832587};\\\", \\\"{x:1212,y:831,t:1527271832602};\\\", \\\"{x:1212,y:828,t:1527271832620};\\\", \\\"{x:1214,y:826,t:1527271832637};\\\", \\\"{x:1214,y:825,t:1527271832652};\\\", \\\"{x:1215,y:825,t:1527271832960};\\\", \\\"{x:1217,y:828,t:1527271832984};\\\", \\\"{x:1220,y:833,t:1527271833001};\\\", \\\"{x:1221,y:835,t:1527271833008};\\\", \\\"{x:1222,y:838,t:1527271833019};\\\", \\\"{x:1225,y:845,t:1527271833037};\\\", \\\"{x:1226,y:851,t:1527271833053};\\\", \\\"{x:1230,y:859,t:1527271833069};\\\", \\\"{x:1232,y:864,t:1527271833086};\\\", \\\"{x:1239,y:876,t:1527271833103};\\\", \\\"{x:1245,y:884,t:1527271833119};\\\", \\\"{x:1246,y:889,t:1527271833136};\\\", \\\"{x:1247,y:891,t:1527271833154};\\\", \\\"{x:1249,y:896,t:1527271833169};\\\", \\\"{x:1252,y:902,t:1527271833186};\\\", \\\"{x:1256,y:908,t:1527271833203};\\\", \\\"{x:1259,y:910,t:1527271833220};\\\", \\\"{x:1260,y:915,t:1527271833236};\\\", \\\"{x:1260,y:918,t:1527271833253};\\\", \\\"{x:1262,y:923,t:1527271833269};\\\", \\\"{x:1263,y:929,t:1527271833286};\\\", \\\"{x:1264,y:934,t:1527271833303};\\\", \\\"{x:1264,y:938,t:1527271833320};\\\", \\\"{x:1265,y:941,t:1527271833337};\\\", \\\"{x:1267,y:948,t:1527271833353};\\\", \\\"{x:1268,y:952,t:1527271833370};\\\", \\\"{x:1269,y:955,t:1527271833387};\\\", \\\"{x:1269,y:958,t:1527271833403};\\\", \\\"{x:1270,y:964,t:1527271833420};\\\", \\\"{x:1271,y:967,t:1527271833437};\\\", \\\"{x:1271,y:970,t:1527271833453};\\\", \\\"{x:1272,y:971,t:1527271833471};\\\", \\\"{x:1273,y:973,t:1527271833487};\\\", \\\"{x:1274,y:975,t:1527271833503};\\\", \\\"{x:1275,y:975,t:1527271833656};\\\", \\\"{x:1276,y:975,t:1527271833671};\\\", \\\"{x:1278,y:973,t:1527271833687};\\\", \\\"{x:1279,y:972,t:1527271833704};\\\", \\\"{x:1280,y:970,t:1527271833721};\\\", \\\"{x:1281,y:970,t:1527271833738};\\\", \\\"{x:1281,y:969,t:1527271833754};\\\", \\\"{x:1281,y:968,t:1527271833808};\\\", \\\"{x:1281,y:967,t:1527271833880};\\\", \\\"{x:1281,y:965,t:1527271833904};\\\", \\\"{x:1281,y:963,t:1527271833952};\\\", \\\"{x:1281,y:962,t:1527271833960};\\\", \\\"{x:1282,y:960,t:1527271833971};\\\", \\\"{x:1283,y:957,t:1527271833988};\\\", \\\"{x:1285,y:954,t:1527271834004};\\\", \\\"{x:1287,y:950,t:1527271834021};\\\", \\\"{x:1288,y:947,t:1527271834038};\\\", \\\"{x:1289,y:943,t:1527271834055};\\\", \\\"{x:1291,y:941,t:1527271834071};\\\", \\\"{x:1294,y:935,t:1527271834088};\\\", \\\"{x:1295,y:932,t:1527271834105};\\\", \\\"{x:1299,y:925,t:1527271834121};\\\", \\\"{x:1303,y:915,t:1527271834138};\\\", \\\"{x:1308,y:907,t:1527271834154};\\\", \\\"{x:1313,y:899,t:1527271834171};\\\", \\\"{x:1314,y:894,t:1527271834188};\\\", \\\"{x:1321,y:883,t:1527271834205};\\\", \\\"{x:1328,y:874,t:1527271834221};\\\", \\\"{x:1334,y:864,t:1527271834238};\\\", \\\"{x:1336,y:861,t:1527271834254};\\\", \\\"{x:1341,y:853,t:1527271834270};\\\", \\\"{x:1345,y:840,t:1527271834287};\\\", \\\"{x:1346,y:836,t:1527271834305};\\\", \\\"{x:1349,y:832,t:1527271834320};\\\", \\\"{x:1351,y:827,t:1527271834338};\\\", \\\"{x:1353,y:823,t:1527271834354};\\\", \\\"{x:1357,y:817,t:1527271834371};\\\", \\\"{x:1362,y:810,t:1527271834387};\\\", \\\"{x:1366,y:804,t:1527271834405};\\\", \\\"{x:1368,y:801,t:1527271834421};\\\", \\\"{x:1371,y:797,t:1527271834437};\\\", \\\"{x:1373,y:795,t:1527271834454};\\\", \\\"{x:1375,y:791,t:1527271834470};\\\", \\\"{x:1379,y:786,t:1527271834487};\\\", \\\"{x:1382,y:781,t:1527271834505};\\\", \\\"{x:1384,y:777,t:1527271834521};\\\", \\\"{x:1388,y:773,t:1527271834537};\\\", \\\"{x:1390,y:767,t:1527271834554};\\\", \\\"{x:1392,y:764,t:1527271834571};\\\", \\\"{x:1395,y:761,t:1527271834588};\\\", \\\"{x:1398,y:757,t:1527271834605};\\\", \\\"{x:1400,y:754,t:1527271834621};\\\", \\\"{x:1401,y:752,t:1527271834637};\\\", \\\"{x:1403,y:748,t:1527271834654};\\\", \\\"{x:1403,y:747,t:1527271834672};\\\", \\\"{x:1403,y:746,t:1527271834703};\\\", \\\"{x:1397,y:748,t:1527271834711};\\\", \\\"{x:1377,y:753,t:1527271834721};\\\", \\\"{x:1315,y:776,t:1527271834739};\\\", \\\"{x:1217,y:793,t:1527271834755};\\\", \\\"{x:1119,y:795,t:1527271834772};\\\", \\\"{x:1055,y:797,t:1527271834788};\\\", \\\"{x:985,y:780,t:1527271834805};\\\", \\\"{x:967,y:771,t:1527271834821};\\\", \\\"{x:936,y:757,t:1527271834839};\\\", \\\"{x:913,y:744,t:1527271834854};\\\", \\\"{x:887,y:716,t:1527271834871};\\\", \\\"{x:874,y:703,t:1527271834889};\\\", \\\"{x:863,y:692,t:1527271834904};\\\", \\\"{x:845,y:678,t:1527271834922};\\\", \\\"{x:830,y:668,t:1527271834939};\\\", \\\"{x:809,y:656,t:1527271834954};\\\", \\\"{x:790,y:647,t:1527271834972};\\\", \\\"{x:772,y:637,t:1527271834989};\\\", \\\"{x:747,y:631,t:1527271835004};\\\", \\\"{x:718,y:625,t:1527271835022};\\\", \\\"{x:693,y:623,t:1527271835039};\\\", \\\"{x:664,y:612,t:1527271835054};\\\", \\\"{x:658,y:612,t:1527271835069};\\\", \\\"{x:638,y:606,t:1527271835087};\\\", \\\"{x:618,y:596,t:1527271835103};\\\", \\\"{x:592,y:589,t:1527271835121};\\\", \\\"{x:583,y:584,t:1527271835137};\\\", \\\"{x:563,y:577,t:1527271835154};\\\", \\\"{x:548,y:569,t:1527271835173};\\\", \\\"{x:540,y:568,t:1527271835187};\\\", \\\"{x:528,y:565,t:1527271835204};\\\", \\\"{x:522,y:562,t:1527271835220};\\\", \\\"{x:519,y:561,t:1527271835237};\\\", \\\"{x:514,y:560,t:1527271835254};\\\", \\\"{x:511,y:560,t:1527271835270};\\\", \\\"{x:505,y:560,t:1527271835287};\\\", \\\"{x:496,y:560,t:1527271835305};\\\", \\\"{x:491,y:560,t:1527271835321};\\\", \\\"{x:486,y:560,t:1527271835337};\\\", \\\"{x:484,y:560,t:1527271835355};\\\", \\\"{x:477,y:562,t:1527271835372};\\\", \\\"{x:471,y:563,t:1527271835387};\\\", \\\"{x:462,y:566,t:1527271835404};\\\", \\\"{x:455,y:567,t:1527271835422};\\\", \\\"{x:447,y:567,t:1527271835437};\\\", \\\"{x:444,y:567,t:1527271835455};\\\", \\\"{x:439,y:567,t:1527271835470};\\\", \\\"{x:435,y:566,t:1527271835487};\\\", \\\"{x:428,y:566,t:1527271835504};\\\", \\\"{x:420,y:566,t:1527271835522};\\\", \\\"{x:417,y:566,t:1527271835538};\\\", \\\"{x:416,y:566,t:1527271835555};\\\", \\\"{x:414,y:566,t:1527271835571};\\\", \\\"{x:414,y:565,t:1527271835607};\\\", \\\"{x:413,y:565,t:1527271835800};\\\", \\\"{x:412,y:565,t:1527271835823};\\\", \\\"{x:411,y:563,t:1527271835838};\\\", \\\"{x:410,y:563,t:1527271835855};\\\", \\\"{x:409,y:563,t:1527271835871};\\\", \\\"{x:408,y:563,t:1527271835944};\\\", \\\"{x:407,y:563,t:1527271835968};\\\", \\\"{x:406,y:563,t:1527271836031};\\\", \\\"{x:406,y:564,t:1527271836528};\\\", \\\"{x:413,y:571,t:1527271836540};\\\", \\\"{x:432,y:597,t:1527271836556};\\\", \\\"{x:450,y:620,t:1527271836573};\\\", \\\"{x:467,y:638,t:1527271836588};\\\", \\\"{x:479,y:660,t:1527271836605};\\\", \\\"{x:488,y:674,t:1527271836623};\\\", \\\"{x:496,y:683,t:1527271836638};\\\", \\\"{x:497,y:689,t:1527271836655};\\\", \\\"{x:501,y:695,t:1527271836673};\\\", \\\"{x:501,y:700,t:1527271836688};\\\", \\\"{x:502,y:705,t:1527271836706};\\\", \\\"{x:502,y:712,t:1527271836723};\\\", \\\"{x:502,y:718,t:1527271836739};\\\", \\\"{x:502,y:723,t:1527271836756};\\\", \\\"{x:502,y:725,t:1527271836773};\\\", \\\"{x:502,y:727,t:1527271836790};\\\", \\\"{x:502,y:730,t:1527271836807};\\\", \\\"{x:502,y:731,t:1527271836823};\\\", \\\"{x:502,y:735,t:1527271836839};\\\", \\\"{x:502,y:738,t:1527271836857};\\\", \\\"{x:502,y:737,t:1527271836920};\\\", \\\"{x:502,y:734,t:1527271836928};\\\", \\\"{x:502,y:732,t:1527271836939};\\\", \\\"{x:505,y:723,t:1527271836955};\\\", \\\"{x:509,y:715,t:1527271836972};\\\", \\\"{x:512,y:711,t:1527271836990};\\\", \\\"{x:514,y:709,t:1527271837005};\\\" ] }, { \\\"rt\\\": 5240, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 523705, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -02 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:708,t:1527271838511};\\\", \\\"{x:517,y:707,t:1527271838583};\\\", \\\"{x:520,y:705,t:1527271838879};\\\", \\\"{x:520,y:704,t:1527271838890};\\\", \\\"{x:522,y:701,t:1527271838907};\\\", \\\"{x:522,y:700,t:1527271838923};\\\", \\\"{x:523,y:699,t:1527271838940};\\\", \\\"{x:524,y:697,t:1527271838957};\\\", \\\"{x:524,y:696,t:1527271838974};\\\", \\\"{x:524,y:693,t:1527271838991};\\\", \\\"{x:524,y:690,t:1527271839007};\\\", \\\"{x:526,y:688,t:1527271839023};\\\", \\\"{x:527,y:687,t:1527271839041};\\\", \\\"{x:527,y:686,t:1527271839058};\\\", \\\"{x:527,y:683,t:1527271839074};\\\", \\\"{x:527,y:680,t:1527271839090};\\\", \\\"{x:528,y:674,t:1527271839107};\\\", \\\"{x:529,y:667,t:1527271839124};\\\", \\\"{x:530,y:660,t:1527271839141};\\\", \\\"{x:530,y:656,t:1527271839158};\\\", \\\"{x:532,y:650,t:1527271839175};\\\", \\\"{x:538,y:639,t:1527271839190};\\\", \\\"{x:548,y:629,t:1527271839207};\\\", \\\"{x:563,y:617,t:1527271839225};\\\", \\\"{x:584,y:602,t:1527271839241};\\\", \\\"{x:619,y:583,t:1527271839257};\\\", \\\"{x:643,y:572,t:1527271839275};\\\", \\\"{x:699,y:567,t:1527271839290};\\\", \\\"{x:755,y:559,t:1527271839309};\\\", \\\"{x:797,y:559,t:1527271839324};\\\", \\\"{x:908,y:559,t:1527271839340};\\\", \\\"{x:998,y:563,t:1527271839358};\\\", \\\"{x:1071,y:580,t:1527271839375};\\\", \\\"{x:1087,y:590,t:1527271839391};\\\", \\\"{x:1101,y:602,t:1527271839408};\\\", \\\"{x:1113,y:617,t:1527271839425};\\\", \\\"{x:1119,y:634,t:1527271839441};\\\", \\\"{x:1129,y:652,t:1527271839458};\\\", \\\"{x:1135,y:678,t:1527271839475};\\\", \\\"{x:1146,y:705,t:1527271839491};\\\", \\\"{x:1158,y:734,t:1527271839507};\\\", \\\"{x:1169,y:766,t:1527271839524};\\\", \\\"{x:1188,y:792,t:1527271839540};\\\", \\\"{x:1203,y:813,t:1527271839557};\\\", \\\"{x:1217,y:831,t:1527271839576};\\\", \\\"{x:1223,y:836,t:1527271839592};\\\", \\\"{x:1228,y:841,t:1527271839608};\\\", \\\"{x:1232,y:847,t:1527271839625};\\\", \\\"{x:1235,y:850,t:1527271839642};\\\", \\\"{x:1240,y:853,t:1527271839658};\\\", \\\"{x:1243,y:855,t:1527271839674};\\\", \\\"{x:1246,y:859,t:1527271839691};\\\", \\\"{x:1252,y:867,t:1527271839708};\\\", \\\"{x:1261,y:880,t:1527271839725};\\\", \\\"{x:1273,y:894,t:1527271839741};\\\", \\\"{x:1288,y:910,t:1527271839757};\\\", \\\"{x:1309,y:921,t:1527271839775};\\\", \\\"{x:1323,y:933,t:1527271839791};\\\", \\\"{x:1334,y:940,t:1527271839808};\\\", \\\"{x:1345,y:945,t:1527271839824};\\\", \\\"{x:1361,y:949,t:1527271839841};\\\", \\\"{x:1365,y:950,t:1527271839858};\\\", \\\"{x:1372,y:951,t:1527271839875};\\\", \\\"{x:1385,y:954,t:1527271839892};\\\", \\\"{x:1401,y:958,t:1527271839908};\\\", \\\"{x:1406,y:960,t:1527271839925};\\\", \\\"{x:1426,y:965,t:1527271839942};\\\", \\\"{x:1446,y:971,t:1527271839958};\\\", \\\"{x:1471,y:977,t:1527271839975};\\\", \\\"{x:1492,y:981,t:1527271839991};\\\", \\\"{x:1510,y:983,t:1527271840009};\\\", \\\"{x:1529,y:990,t:1527271840025};\\\", \\\"{x:1538,y:992,t:1527271840042};\\\", \\\"{x:1554,y:994,t:1527271840059};\\\", \\\"{x:1572,y:994,t:1527271840074};\\\", \\\"{x:1577,y:994,t:1527271840092};\\\", \\\"{x:1584,y:994,t:1527271840109};\\\", \\\"{x:1598,y:994,t:1527271840125};\\\", \\\"{x:1609,y:994,t:1527271840141};\\\", \\\"{x:1625,y:992,t:1527271840159};\\\", \\\"{x:1627,y:991,t:1527271840175};\\\", \\\"{x:1636,y:991,t:1527271840191};\\\", \\\"{x:1637,y:991,t:1527271840209};\\\", \\\"{x:1640,y:991,t:1527271840225};\\\", \\\"{x:1641,y:991,t:1527271840242};\\\", \\\"{x:1642,y:991,t:1527271840259};\\\", \\\"{x:1645,y:991,t:1527271840275};\\\", \\\"{x:1648,y:991,t:1527271840291};\\\", \\\"{x:1653,y:993,t:1527271840308};\\\", \\\"{x:1654,y:995,t:1527271840324};\\\", \\\"{x:1655,y:995,t:1527271840432};\\\", \\\"{x:1654,y:993,t:1527271840442};\\\", \\\"{x:1647,y:986,t:1527271840459};\\\", \\\"{x:1637,y:977,t:1527271840476};\\\", \\\"{x:1625,y:969,t:1527271840492};\\\", \\\"{x:1621,y:966,t:1527271840510};\\\", \\\"{x:1618,y:963,t:1527271840526};\\\", \\\"{x:1616,y:960,t:1527271840542};\\\", \\\"{x:1614,y:959,t:1527271840559};\\\", \\\"{x:1612,y:957,t:1527271840576};\\\", \\\"{x:1610,y:953,t:1527271840592};\\\", \\\"{x:1608,y:953,t:1527271840610};\\\", \\\"{x:1604,y:949,t:1527271840626};\\\", \\\"{x:1602,y:946,t:1527271840642};\\\", \\\"{x:1600,y:944,t:1527271840660};\\\", \\\"{x:1599,y:939,t:1527271840677};\\\", \\\"{x:1597,y:935,t:1527271840692};\\\", \\\"{x:1595,y:927,t:1527271840710};\\\", \\\"{x:1590,y:909,t:1527271840726};\\\", \\\"{x:1586,y:894,t:1527271840742};\\\", \\\"{x:1577,y:869,t:1527271840759};\\\", \\\"{x:1575,y:851,t:1527271840775};\\\", \\\"{x:1574,y:833,t:1527271840792};\\\", \\\"{x:1572,y:823,t:1527271840810};\\\", \\\"{x:1570,y:808,t:1527271840826};\\\", \\\"{x:1566,y:795,t:1527271840843};\\\", \\\"{x:1561,y:780,t:1527271840859};\\\", \\\"{x:1555,y:771,t:1527271840876};\\\", \\\"{x:1551,y:763,t:1527271840893};\\\", \\\"{x:1550,y:760,t:1527271840910};\\\", \\\"{x:1548,y:756,t:1527271840926};\\\", \\\"{x:1541,y:748,t:1527271840943};\\\", \\\"{x:1537,y:745,t:1527271840959};\\\", \\\"{x:1521,y:735,t:1527271840976};\\\", \\\"{x:1512,y:728,t:1527271840993};\\\", \\\"{x:1500,y:717,t:1527271841010};\\\", \\\"{x:1488,y:708,t:1527271841026};\\\", \\\"{x:1476,y:693,t:1527271841044};\\\", \\\"{x:1468,y:678,t:1527271841059};\\\", \\\"{x:1461,y:667,t:1527271841077};\\\", \\\"{x:1452,y:655,t:1527271841093};\\\", \\\"{x:1445,y:639,t:1527271841109};\\\", \\\"{x:1437,y:618,t:1527271841127};\\\", \\\"{x:1430,y:593,t:1527271841143};\\\", \\\"{x:1429,y:582,t:1527271841159};\\\", \\\"{x:1424,y:570,t:1527271841176};\\\", \\\"{x:1422,y:558,t:1527271841193};\\\", \\\"{x:1421,y:548,t:1527271841209};\\\", \\\"{x:1421,y:539,t:1527271841226};\\\", \\\"{x:1421,y:532,t:1527271841244};\\\", \\\"{x:1421,y:528,t:1527271841260};\\\", \\\"{x:1421,y:526,t:1527271841276};\\\", \\\"{x:1420,y:525,t:1527271841296};\\\", \\\"{x:1412,y:525,t:1527271841310};\\\", \\\"{x:1382,y:532,t:1527271841327};\\\", \\\"{x:1312,y:557,t:1527271841344};\\\", \\\"{x:1242,y:581,t:1527271841360};\\\", \\\"{x:1178,y:607,t:1527271841376};\\\", \\\"{x:1106,y:640,t:1527271841394};\\\", \\\"{x:1038,y:678,t:1527271841410};\\\", \\\"{x:983,y:702,t:1527271841426};\\\", \\\"{x:957,y:719,t:1527271841443};\\\", \\\"{x:935,y:722,t:1527271841460};\\\", \\\"{x:925,y:722,t:1527271841476};\\\", \\\"{x:911,y:722,t:1527271841493};\\\", \\\"{x:897,y:722,t:1527271841511};\\\", \\\"{x:873,y:722,t:1527271841526};\\\", \\\"{x:835,y:722,t:1527271841544};\\\", \\\"{x:805,y:717,t:1527271841559};\\\", \\\"{x:783,y:714,t:1527271841576};\\\", \\\"{x:757,y:709,t:1527271841593};\\\", \\\"{x:726,y:699,t:1527271841610};\\\", \\\"{x:697,y:687,t:1527271841626};\\\", \\\"{x:662,y:675,t:1527271841643};\\\", \\\"{x:629,y:663,t:1527271841661};\\\", \\\"{x:610,y:647,t:1527271841677};\\\", \\\"{x:579,y:633,t:1527271841693};\\\", \\\"{x:557,y:621,t:1527271841709};\\\", \\\"{x:532,y:607,t:1527271841727};\\\", \\\"{x:525,y:604,t:1527271841740};\\\", \\\"{x:507,y:594,t:1527271841757};\\\", \\\"{x:497,y:588,t:1527271841774};\\\", \\\"{x:477,y:580,t:1527271841791};\\\", \\\"{x:467,y:579,t:1527271841810};\\\", \\\"{x:463,y:579,t:1527271841826};\\\", \\\"{x:462,y:579,t:1527271841844};\\\", \\\"{x:459,y:579,t:1527271841859};\\\", \\\"{x:455,y:581,t:1527271841876};\\\", \\\"{x:446,y:585,t:1527271841894};\\\", \\\"{x:435,y:589,t:1527271841910};\\\", \\\"{x:416,y:593,t:1527271841927};\\\", \\\"{x:406,y:593,t:1527271841942};\\\", \\\"{x:388,y:596,t:1527271841959};\\\", \\\"{x:369,y:596,t:1527271841977};\\\", \\\"{x:357,y:596,t:1527271841993};\\\", \\\"{x:334,y:596,t:1527271842009};\\\", \\\"{x:305,y:599,t:1527271842027};\\\", \\\"{x:293,y:599,t:1527271842043};\\\", \\\"{x:274,y:597,t:1527271842059};\\\", \\\"{x:259,y:595,t:1527271842078};\\\", \\\"{x:244,y:595,t:1527271842094};\\\", \\\"{x:233,y:595,t:1527271842109};\\\", \\\"{x:216,y:595,t:1527271842127};\\\", \\\"{x:214,y:595,t:1527271842143};\\\", \\\"{x:216,y:595,t:1527271842232};\\\", \\\"{x:223,y:595,t:1527271842243};\\\", \\\"{x:257,y:593,t:1527271842260};\\\", \\\"{x:343,y:584,t:1527271842279};\\\", \\\"{x:470,y:582,t:1527271842293};\\\", \\\"{x:576,y:580,t:1527271842310};\\\", \\\"{x:686,y:583,t:1527271842327};\\\", \\\"{x:712,y:583,t:1527271842344};\\\", \\\"{x:720,y:583,t:1527271842360};\\\", \\\"{x:723,y:583,t:1527271842376};\\\", \\\"{x:724,y:582,t:1527271842439};\\\", \\\"{x:724,y:580,t:1527271842447};\\\", \\\"{x:725,y:579,t:1527271842460};\\\", \\\"{x:725,y:574,t:1527271842477};\\\", \\\"{x:725,y:572,t:1527271842494};\\\", \\\"{x:719,y:567,t:1527271842511};\\\", \\\"{x:695,y:564,t:1527271842527};\\\", \\\"{x:669,y:563,t:1527271842543};\\\", \\\"{x:644,y:562,t:1527271842560};\\\", \\\"{x:625,y:557,t:1527271842577};\\\", \\\"{x:612,y:555,t:1527271842594};\\\", \\\"{x:607,y:553,t:1527271842610};\\\", \\\"{x:605,y:559,t:1527271842958};\\\", \\\"{x:601,y:568,t:1527271842967};\\\", \\\"{x:597,y:577,t:1527271842978};\\\", \\\"{x:585,y:605,t:1527271842994};\\\", \\\"{x:578,y:627,t:1527271843011};\\\", \\\"{x:572,y:645,t:1527271843027};\\\", \\\"{x:568,y:660,t:1527271843044};\\\", \\\"{x:565,y:667,t:1527271843061};\\\", \\\"{x:561,y:670,t:1527271843078};\\\", \\\"{x:559,y:673,t:1527271843094};\\\", \\\"{x:557,y:677,t:1527271843110};\\\", \\\"{x:550,y:679,t:1527271843128};\\\", \\\"{x:544,y:682,t:1527271843145};\\\", \\\"{x:542,y:686,t:1527271843161};\\\", \\\"{x:536,y:690,t:1527271843178};\\\", \\\"{x:527,y:699,t:1527271843194};\\\", \\\"{x:516,y:714,t:1527271843212};\\\", \\\"{x:510,y:727,t:1527271843228};\\\", \\\"{x:507,y:735,t:1527271843244};\\\", \\\"{x:505,y:738,t:1527271843261};\\\", \\\"{x:505,y:739,t:1527271843277};\\\", \\\"{x:505,y:740,t:1527271843294};\\\", \\\"{x:505,y:738,t:1527271843488};\\\", \\\"{x:505,y:737,t:1527271843495};\\\", \\\"{x:505,y:730,t:1527271843512};\\\", \\\"{x:507,y:723,t:1527271843528};\\\", \\\"{x:508,y:720,t:1527271843545};\\\", \\\"{x:509,y:719,t:1527271844631};\\\", \\\"{x:512,y:719,t:1527271844646};\\\", \\\"{x:527,y:719,t:1527271844663};\\\", \\\"{x:534,y:713,t:1527271844680};\\\" ] }, { \\\"rt\\\": 11023, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 536029, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-01 PM-12 PM-12 PM-01 PM-H -I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:712,t:1527271846488};\\\", \\\"{x:534,y:711,t:1527271846511};\\\", \\\"{x:534,y:710,t:1527271846526};\\\", \\\"{x:534,y:709,t:1527271846575};\\\", \\\"{x:534,y:708,t:1527271846591};\\\", \\\"{x:534,y:707,t:1527271846631};\\\", \\\"{x:534,y:706,t:1527271846655};\\\", \\\"{x:534,y:705,t:1527271846687};\\\", \\\"{x:533,y:704,t:1527271846697};\\\", \\\"{x:533,y:702,t:1527271846719};\\\", \\\"{x:533,y:701,t:1527271846759};\\\", \\\"{x:533,y:699,t:1527271846783};\\\", \\\"{x:533,y:698,t:1527271846832};\\\", \\\"{x:533,y:696,t:1527271846896};\\\", \\\"{x:533,y:695,t:1527271846943};\\\", \\\"{x:533,y:693,t:1527271846984};\\\", \\\"{x:533,y:692,t:1527271847040};\\\", \\\"{x:533,y:690,t:1527271847328};\\\", \\\"{x:534,y:688,t:1527271847352};\\\", \\\"{x:535,y:688,t:1527271847364};\\\", \\\"{x:539,y:685,t:1527271847381};\\\", \\\"{x:544,y:682,t:1527271847399};\\\", \\\"{x:551,y:681,t:1527271847414};\\\", \\\"{x:563,y:678,t:1527271847431};\\\", \\\"{x:573,y:676,t:1527271847448};\\\", \\\"{x:583,y:672,t:1527271847464};\\\", \\\"{x:596,y:670,t:1527271847482};\\\", \\\"{x:612,y:666,t:1527271847499};\\\", \\\"{x:627,y:666,t:1527271847514};\\\", \\\"{x:642,y:665,t:1527271847531};\\\", \\\"{x:650,y:665,t:1527271847549};\\\", \\\"{x:660,y:663,t:1527271847566};\\\", \\\"{x:675,y:657,t:1527271847581};\\\", \\\"{x:689,y:655,t:1527271847598};\\\", \\\"{x:706,y:650,t:1527271847614};\\\", \\\"{x:734,y:643,t:1527271847631};\\\", \\\"{x:759,y:636,t:1527271847647};\\\", \\\"{x:778,y:630,t:1527271847664};\\\", \\\"{x:805,y:625,t:1527271847682};\\\", \\\"{x:857,y:618,t:1527271847698};\\\", \\\"{x:894,y:608,t:1527271847715};\\\", \\\"{x:927,y:608,t:1527271847730};\\\", \\\"{x:980,y:615,t:1527271847749};\\\", \\\"{x:1013,y:628,t:1527271847764};\\\", \\\"{x:1035,y:639,t:1527271847781};\\\", \\\"{x:1054,y:656,t:1527271847798};\\\", \\\"{x:1093,y:690,t:1527271847815};\\\", \\\"{x:1116,y:712,t:1527271847831};\\\", \\\"{x:1131,y:728,t:1527271847848};\\\", \\\"{x:1136,y:738,t:1527271847865};\\\", \\\"{x:1142,y:747,t:1527271847881};\\\", \\\"{x:1151,y:762,t:1527271847898};\\\", \\\"{x:1162,y:780,t:1527271847915};\\\", \\\"{x:1171,y:795,t:1527271847931};\\\", \\\"{x:1184,y:812,t:1527271847948};\\\", \\\"{x:1191,y:823,t:1527271847965};\\\", \\\"{x:1202,y:841,t:1527271847981};\\\", \\\"{x:1212,y:870,t:1527271847999};\\\", \\\"{x:1221,y:892,t:1527271848014};\\\", \\\"{x:1229,y:908,t:1527271848031};\\\", \\\"{x:1235,y:920,t:1527271848048};\\\", \\\"{x:1241,y:931,t:1527271848065};\\\", \\\"{x:1247,y:940,t:1527271848081};\\\", \\\"{x:1254,y:951,t:1527271848098};\\\", \\\"{x:1260,y:958,t:1527271848115};\\\", \\\"{x:1263,y:962,t:1527271848132};\\\", \\\"{x:1268,y:969,t:1527271848148};\\\", \\\"{x:1271,y:973,t:1527271848165};\\\", \\\"{x:1277,y:979,t:1527271848181};\\\", \\\"{x:1281,y:980,t:1527271848198};\\\", \\\"{x:1287,y:984,t:1527271848215};\\\", \\\"{x:1291,y:987,t:1527271848232};\\\", \\\"{x:1296,y:991,t:1527271848248};\\\", \\\"{x:1297,y:991,t:1527271848265};\\\", \\\"{x:1306,y:994,t:1527271848282};\\\", \\\"{x:1314,y:996,t:1527271848298};\\\", \\\"{x:1321,y:997,t:1527271848315};\\\", \\\"{x:1328,y:997,t:1527271848332};\\\", \\\"{x:1339,y:997,t:1527271848348};\\\", \\\"{x:1354,y:998,t:1527271848365};\\\", \\\"{x:1362,y:998,t:1527271848383};\\\", \\\"{x:1372,y:998,t:1527271848398};\\\", \\\"{x:1386,y:998,t:1527271848414};\\\", \\\"{x:1389,y:998,t:1527271848432};\\\", \\\"{x:1391,y:998,t:1527271848448};\\\", \\\"{x:1394,y:997,t:1527271848465};\\\", \\\"{x:1398,y:996,t:1527271848482};\\\", \\\"{x:1400,y:995,t:1527271848498};\\\", \\\"{x:1406,y:993,t:1527271848515};\\\", \\\"{x:1408,y:991,t:1527271848532};\\\", \\\"{x:1411,y:991,t:1527271848548};\\\", \\\"{x:1415,y:991,t:1527271848565};\\\", \\\"{x:1418,y:991,t:1527271848583};\\\", \\\"{x:1423,y:991,t:1527271848598};\\\", \\\"{x:1426,y:991,t:1527271848615};\\\", \\\"{x:1430,y:991,t:1527271848632};\\\", \\\"{x:1435,y:991,t:1527271848649};\\\", \\\"{x:1443,y:991,t:1527271848666};\\\", \\\"{x:1445,y:991,t:1527271848682};\\\", \\\"{x:1450,y:991,t:1527271848699};\\\", \\\"{x:1452,y:991,t:1527271848715};\\\", \\\"{x:1456,y:992,t:1527271848732};\\\", \\\"{x:1457,y:992,t:1527271848750};\\\", \\\"{x:1460,y:992,t:1527271848765};\\\", \\\"{x:1464,y:991,t:1527271848783};\\\", \\\"{x:1470,y:991,t:1527271848799};\\\", \\\"{x:1476,y:988,t:1527271848815};\\\", \\\"{x:1477,y:988,t:1527271848839};\\\", \\\"{x:1478,y:988,t:1527271848871};\\\", \\\"{x:1478,y:986,t:1527271848896};\\\", \\\"{x:1472,y:985,t:1527271848903};\\\", \\\"{x:1469,y:985,t:1527271848915};\\\", \\\"{x:1456,y:985,t:1527271848933};\\\", \\\"{x:1440,y:984,t:1527271848951};\\\", \\\"{x:1424,y:983,t:1527271848966};\\\", \\\"{x:1407,y:983,t:1527271848983};\\\", \\\"{x:1385,y:983,t:1527271849000};\\\", \\\"{x:1377,y:983,t:1527271849015};\\\", \\\"{x:1372,y:982,t:1527271849031};\\\", \\\"{x:1367,y:980,t:1527271849049};\\\", \\\"{x:1366,y:980,t:1527271849065};\\\", \\\"{x:1365,y:980,t:1527271849143};\\\", \\\"{x:1363,y:979,t:1527271849159};\\\", \\\"{x:1362,y:978,t:1527271849174};\\\", \\\"{x:1361,y:977,t:1527271849191};\\\", \\\"{x:1359,y:977,t:1527271849198};\\\", \\\"{x:1355,y:975,t:1527271849216};\\\", \\\"{x:1346,y:972,t:1527271849232};\\\", \\\"{x:1338,y:970,t:1527271849249};\\\", \\\"{x:1329,y:967,t:1527271849266};\\\", \\\"{x:1320,y:967,t:1527271849282};\\\", \\\"{x:1312,y:967,t:1527271849299};\\\", \\\"{x:1306,y:966,t:1527271849316};\\\", \\\"{x:1305,y:966,t:1527271849332};\\\", \\\"{x:1304,y:966,t:1527271849350};\\\", \\\"{x:1304,y:965,t:1527271849415};\\\", \\\"{x:1301,y:963,t:1527271849433};\\\", \\\"{x:1298,y:963,t:1527271849449};\\\", \\\"{x:1296,y:962,t:1527271849467};\\\", \\\"{x:1294,y:962,t:1527271849625};\\\", \\\"{x:1292,y:962,t:1527271849632};\\\", \\\"{x:1287,y:962,t:1527271849650};\\\", \\\"{x:1285,y:961,t:1527271849667};\\\", \\\"{x:1284,y:961,t:1527271849684};\\\", \\\"{x:1283,y:961,t:1527271849751};\\\", \\\"{x:1283,y:960,t:1527271849847};\\\", \\\"{x:1281,y:959,t:1527271849878};\\\", \\\"{x:1280,y:958,t:1527271849886};\\\", \\\"{x:1279,y:958,t:1527271849903};\\\", \\\"{x:1278,y:958,t:1527271849915};\\\", \\\"{x:1273,y:957,t:1527271849933};\\\", \\\"{x:1267,y:955,t:1527271849950};\\\", \\\"{x:1263,y:954,t:1527271849966};\\\", \\\"{x:1260,y:954,t:1527271849982};\\\", \\\"{x:1259,y:954,t:1527271849999};\\\", \\\"{x:1258,y:954,t:1527271850016};\\\", \\\"{x:1256,y:954,t:1527271850033};\\\", \\\"{x:1255,y:954,t:1527271850096};\\\", \\\"{x:1261,y:954,t:1527271850168};\\\", \\\"{x:1269,y:955,t:1527271850183};\\\", \\\"{x:1287,y:960,t:1527271850201};\\\", \\\"{x:1306,y:965,t:1527271850217};\\\", \\\"{x:1322,y:969,t:1527271850233};\\\", \\\"{x:1340,y:973,t:1527271850251};\\\", \\\"{x:1350,y:975,t:1527271850267};\\\", \\\"{x:1363,y:978,t:1527271850283};\\\", \\\"{x:1373,y:979,t:1527271850301};\\\", \\\"{x:1381,y:979,t:1527271850316};\\\", \\\"{x:1389,y:980,t:1527271850334};\\\", \\\"{x:1398,y:983,t:1527271850352};\\\", \\\"{x:1405,y:984,t:1527271850367};\\\", \\\"{x:1414,y:984,t:1527271850383};\\\", \\\"{x:1420,y:985,t:1527271850401};\\\", \\\"{x:1429,y:987,t:1527271850417};\\\", \\\"{x:1433,y:987,t:1527271850433};\\\", \\\"{x:1435,y:988,t:1527271850451};\\\", \\\"{x:1436,y:989,t:1527271850467};\\\", \\\"{x:1439,y:988,t:1527271850592};\\\", \\\"{x:1441,y:987,t:1527271850623};\\\", \\\"{x:1442,y:987,t:1527271850633};\\\", \\\"{x:1443,y:986,t:1527271850650};\\\", \\\"{x:1444,y:985,t:1527271850668};\\\", \\\"{x:1443,y:982,t:1527271851344};\\\", \\\"{x:1439,y:976,t:1527271851352};\\\", \\\"{x:1431,y:959,t:1527271851367};\\\", \\\"{x:1420,y:946,t:1527271851384};\\\", \\\"{x:1413,y:930,t:1527271851400};\\\", \\\"{x:1402,y:907,t:1527271851417};\\\", \\\"{x:1399,y:883,t:1527271851434};\\\", \\\"{x:1396,y:861,t:1527271851451};\\\", \\\"{x:1395,y:834,t:1527271851467};\\\", \\\"{x:1395,y:808,t:1527271851484};\\\", \\\"{x:1395,y:789,t:1527271851500};\\\", \\\"{x:1395,y:768,t:1527271851517};\\\", \\\"{x:1395,y:747,t:1527271851534};\\\", \\\"{x:1395,y:725,t:1527271851550};\\\", \\\"{x:1399,y:701,t:1527271851567};\\\", \\\"{x:1402,y:687,t:1527271851584};\\\", \\\"{x:1404,y:670,t:1527271851601};\\\", \\\"{x:1405,y:655,t:1527271851617};\\\", \\\"{x:1409,y:637,t:1527271851634};\\\", \\\"{x:1409,y:619,t:1527271851651};\\\", \\\"{x:1410,y:601,t:1527271851667};\\\", \\\"{x:1411,y:589,t:1527271851684};\\\", \\\"{x:1412,y:584,t:1527271851702};\\\", \\\"{x:1414,y:580,t:1527271851718};\\\", \\\"{x:1416,y:575,t:1527271851734};\\\", \\\"{x:1417,y:569,t:1527271851750};\\\", \\\"{x:1416,y:558,t:1527271851768};\\\", \\\"{x:1407,y:546,t:1527271851784};\\\", \\\"{x:1388,y:538,t:1527271851801};\\\", \\\"{x:1372,y:531,t:1527271851817};\\\", \\\"{x:1353,y:523,t:1527271851834};\\\", \\\"{x:1341,y:514,t:1527271851851};\\\", \\\"{x:1333,y:508,t:1527271851867};\\\", \\\"{x:1322,y:503,t:1527271851884};\\\", \\\"{x:1315,y:501,t:1527271851901};\\\", \\\"{x:1314,y:500,t:1527271851951};\\\", \\\"{x:1314,y:497,t:1527271851982};\\\", \\\"{x:1313,y:496,t:1527271851990};\\\", \\\"{x:1313,y:494,t:1527271852001};\\\", \\\"{x:1311,y:490,t:1527271852018};\\\", \\\"{x:1310,y:490,t:1527271852034};\\\", \\\"{x:1310,y:489,t:1527271852052};\\\", \\\"{x:1309,y:489,t:1527271852136};\\\", \\\"{x:1306,y:490,t:1527271852152};\\\", \\\"{x:1306,y:495,t:1527271852169};\\\", \\\"{x:1306,y:502,t:1527271852184};\\\", \\\"{x:1304,y:511,t:1527271852202};\\\", \\\"{x:1304,y:517,t:1527271852219};\\\", \\\"{x:1304,y:527,t:1527271852235};\\\", \\\"{x:1304,y:534,t:1527271852252};\\\", \\\"{x:1304,y:542,t:1527271852269};\\\", \\\"{x:1303,y:548,t:1527271852285};\\\", \\\"{x:1302,y:554,t:1527271852302};\\\", \\\"{x:1302,y:559,t:1527271852319};\\\", \\\"{x:1300,y:562,t:1527271852335};\\\", \\\"{x:1299,y:571,t:1527271852352};\\\", \\\"{x:1299,y:574,t:1527271852369};\\\", \\\"{x:1299,y:579,t:1527271852385};\\\", \\\"{x:1299,y:584,t:1527271852402};\\\", \\\"{x:1299,y:587,t:1527271852419};\\\", \\\"{x:1299,y:593,t:1527271852435};\\\", \\\"{x:1297,y:596,t:1527271852452};\\\", \\\"{x:1296,y:600,t:1527271852469};\\\", \\\"{x:1296,y:601,t:1527271852485};\\\", \\\"{x:1296,y:603,t:1527271852501};\\\", \\\"{x:1296,y:606,t:1527271852518};\\\", \\\"{x:1296,y:609,t:1527271852534};\\\", \\\"{x:1297,y:614,t:1527271852552};\\\", \\\"{x:1298,y:618,t:1527271852569};\\\", \\\"{x:1298,y:620,t:1527271852585};\\\", \\\"{x:1299,y:621,t:1527271852602};\\\", \\\"{x:1300,y:623,t:1527271852618};\\\", \\\"{x:1301,y:626,t:1527271852635};\\\", \\\"{x:1302,y:630,t:1527271852652};\\\", \\\"{x:1304,y:633,t:1527271852669};\\\", \\\"{x:1304,y:635,t:1527271852685};\\\", \\\"{x:1308,y:639,t:1527271852702};\\\", \\\"{x:1309,y:642,t:1527271852719};\\\", \\\"{x:1312,y:646,t:1527271852735};\\\", \\\"{x:1312,y:647,t:1527271852775};\\\", \\\"{x:1313,y:650,t:1527271852786};\\\", \\\"{x:1314,y:651,t:1527271852802};\\\", \\\"{x:1314,y:653,t:1527271852819};\\\", \\\"{x:1315,y:655,t:1527271852836};\\\", \\\"{x:1315,y:656,t:1527271852851};\\\", \\\"{x:1315,y:659,t:1527271852868};\\\", \\\"{x:1315,y:662,t:1527271852885};\\\", \\\"{x:1317,y:669,t:1527271852901};\\\", \\\"{x:1318,y:670,t:1527271852918};\\\", \\\"{x:1321,y:686,t:1527271852935};\\\", \\\"{x:1321,y:694,t:1527271852953};\\\", \\\"{x:1320,y:704,t:1527271852969};\\\", \\\"{x:1320,y:713,t:1527271852985};\\\", \\\"{x:1319,y:734,t:1527271853002};\\\", \\\"{x:1317,y:750,t:1527271853018};\\\", \\\"{x:1316,y:764,t:1527271853035};\\\", \\\"{x:1316,y:772,t:1527271853053};\\\", \\\"{x:1316,y:776,t:1527271853068};\\\", \\\"{x:1316,y:780,t:1527271853086};\\\", \\\"{x:1316,y:784,t:1527271853103};\\\", \\\"{x:1314,y:787,t:1527271853118};\\\", \\\"{x:1313,y:789,t:1527271853135};\\\", \\\"{x:1309,y:790,t:1527271853153};\\\", \\\"{x:1297,y:794,t:1527271853168};\\\", \\\"{x:1286,y:795,t:1527271853185};\\\", \\\"{x:1262,y:794,t:1527271853202};\\\", \\\"{x:1228,y:784,t:1527271853218};\\\", \\\"{x:1200,y:772,t:1527271853235};\\\", \\\"{x:1177,y:758,t:1527271853253};\\\", \\\"{x:1153,y:748,t:1527271853268};\\\", \\\"{x:1131,y:738,t:1527271853285};\\\", \\\"{x:1118,y:734,t:1527271853302};\\\", \\\"{x:1099,y:728,t:1527271853318};\\\", \\\"{x:1070,y:719,t:1527271853335};\\\", \\\"{x:1053,y:710,t:1527271853352};\\\", \\\"{x:1030,y:697,t:1527271853369};\\\", \\\"{x:995,y:686,t:1527271853385};\\\", \\\"{x:953,y:674,t:1527271853402};\\\", \\\"{x:911,y:663,t:1527271853419};\\\", \\\"{x:853,y:646,t:1527271853435};\\\", \\\"{x:806,y:639,t:1527271853452};\\\", \\\"{x:780,y:636,t:1527271853469};\\\", \\\"{x:759,y:636,t:1527271853485};\\\", \\\"{x:739,y:636,t:1527271853502};\\\", \\\"{x:712,y:649,t:1527271853519};\\\", \\\"{x:691,y:657,t:1527271853535};\\\", \\\"{x:676,y:667,t:1527271853552};\\\", \\\"{x:662,y:677,t:1527271853569};\\\", \\\"{x:651,y:690,t:1527271853586};\\\", \\\"{x:639,y:696,t:1527271853603};\\\", \\\"{x:636,y:699,t:1527271853619};\\\", \\\"{x:634,y:701,t:1527271853637};\\\", \\\"{x:633,y:701,t:1527271853653};\\\", \\\"{x:629,y:702,t:1527271853669};\\\", \\\"{x:624,y:702,t:1527271853686};\\\", \\\"{x:607,y:698,t:1527271853702};\\\", \\\"{x:597,y:689,t:1527271853719};\\\", \\\"{x:586,y:681,t:1527271853736};\\\", \\\"{x:576,y:671,t:1527271853753};\\\", \\\"{x:567,y:661,t:1527271853769};\\\", \\\"{x:561,y:656,t:1527271853786};\\\", \\\"{x:556,y:651,t:1527271853803};\\\", \\\"{x:553,y:645,t:1527271853819};\\\", \\\"{x:549,y:640,t:1527271853836};\\\", \\\"{x:546,y:635,t:1527271853853};\\\", \\\"{x:539,y:625,t:1527271853871};\\\", \\\"{x:527,y:616,t:1527271853886};\\\", \\\"{x:507,y:609,t:1527271853902};\\\", \\\"{x:490,y:607,t:1527271853920};\\\", \\\"{x:477,y:606,t:1527271853936};\\\", \\\"{x:457,y:605,t:1527271853953};\\\", \\\"{x:437,y:605,t:1527271853969};\\\", \\\"{x:425,y:605,t:1527271853986};\\\", \\\"{x:419,y:605,t:1527271854003};\\\", \\\"{x:418,y:606,t:1527271854062};\\\", \\\"{x:424,y:606,t:1527271854078};\\\", \\\"{x:432,y:606,t:1527271854087};\\\", \\\"{x:457,y:606,t:1527271854103};\\\", \\\"{x:514,y:609,t:1527271854120};\\\", \\\"{x:600,y:609,t:1527271854136};\\\", \\\"{x:664,y:609,t:1527271854153};\\\", \\\"{x:706,y:609,t:1527271854170};\\\", \\\"{x:720,y:609,t:1527271854186};\\\", \\\"{x:739,y:609,t:1527271854204};\\\", \\\"{x:753,y:605,t:1527271854220};\\\", \\\"{x:764,y:602,t:1527271854236};\\\", \\\"{x:772,y:600,t:1527271854253};\\\", \\\"{x:775,y:598,t:1527271854270};\\\", \\\"{x:779,y:596,t:1527271854286};\\\", \\\"{x:788,y:589,t:1527271854303};\\\", \\\"{x:798,y:582,t:1527271854320};\\\", \\\"{x:804,y:576,t:1527271854336};\\\", \\\"{x:807,y:571,t:1527271854354};\\\", \\\"{x:809,y:566,t:1527271854370};\\\", \\\"{x:812,y:559,t:1527271854386};\\\", \\\"{x:818,y:550,t:1527271854404};\\\", \\\"{x:821,y:544,t:1527271854420};\\\", \\\"{x:823,y:540,t:1527271854436};\\\", \\\"{x:825,y:538,t:1527271854453};\\\", \\\"{x:826,y:536,t:1527271854470};\\\", \\\"{x:827,y:534,t:1527271854487};\\\", \\\"{x:832,y:530,t:1527271854503};\\\", \\\"{x:837,y:527,t:1527271854520};\\\", \\\"{x:842,y:523,t:1527271854536};\\\", \\\"{x:844,y:521,t:1527271854554};\\\", \\\"{x:845,y:521,t:1527271854570};\\\", \\\"{x:846,y:520,t:1527271854586};\\\", \\\"{x:846,y:522,t:1527271854857};\\\", \\\"{x:846,y:523,t:1527271854871};\\\", \\\"{x:844,y:524,t:1527271854887};\\\", \\\"{x:844,y:526,t:1527271854911};\\\", \\\"{x:844,y:527,t:1527271854975};\\\", \\\"{x:844,y:529,t:1527271854998};\\\", \\\"{x:843,y:530,t:1527271855007};\\\", \\\"{x:841,y:532,t:1527271855020};\\\", \\\"{x:839,y:534,t:1527271855037};\\\", \\\"{x:839,y:535,t:1527271855053};\\\", \\\"{x:835,y:538,t:1527271855335};\\\", \\\"{x:827,y:544,t:1527271855343};\\\", \\\"{x:815,y:553,t:1527271855355};\\\", \\\"{x:789,y:571,t:1527271855371};\\\", \\\"{x:765,y:591,t:1527271855388};\\\", \\\"{x:746,y:603,t:1527271855405};\\\", \\\"{x:721,y:620,t:1527271855421};\\\", \\\"{x:707,y:633,t:1527271855438};\\\", \\\"{x:687,y:646,t:1527271855455};\\\", \\\"{x:675,y:656,t:1527271855470};\\\", \\\"{x:660,y:663,t:1527271855487};\\\", \\\"{x:651,y:668,t:1527271855505};\\\", \\\"{x:640,y:672,t:1527271855520};\\\", \\\"{x:637,y:672,t:1527271855538};\\\", \\\"{x:634,y:673,t:1527271855558};\\\", \\\"{x:631,y:673,t:1527271855583};\\\", \\\"{x:630,y:673,t:1527271855599};\\\", \\\"{x:629,y:673,t:1527271855607};\\\", \\\"{x:628,y:673,t:1527271855621};\\\", \\\"{x:627,y:673,t:1527271855639};\\\", \\\"{x:626,y:673,t:1527271855663};\\\", \\\"{x:623,y:674,t:1527271855671};\\\", \\\"{x:619,y:677,t:1527271855688};\\\", \\\"{x:613,y:682,t:1527271855706};\\\", \\\"{x:603,y:689,t:1527271855722};\\\", \\\"{x:591,y:695,t:1527271855738};\\\", \\\"{x:581,y:699,t:1527271855755};\\\", \\\"{x:573,y:703,t:1527271855772};\\\", \\\"{x:565,y:705,t:1527271855788};\\\", \\\"{x:555,y:708,t:1527271855805};\\\", \\\"{x:540,y:717,t:1527271855826};\\\", \\\"{x:530,y:722,t:1527271855839};\\\", \\\"{x:527,y:723,t:1527271855854};\\\", \\\"{x:525,y:726,t:1527271855871};\\\", \\\"{x:524,y:726,t:1527271856655};\\\", \\\"{x:524,y:725,t:1527271856671};\\\", \\\"{x:525,y:725,t:1527271857103};\\\", \\\"{x:526,y:725,t:1527271857110};\\\" ] }, { \\\"rt\\\": 10512, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 547782, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:722,t:1527271858256};\\\", \\\"{x:532,y:720,t:1527271858263};\\\", \\\"{x:540,y:716,t:1527271858276};\\\", \\\"{x:557,y:707,t:1527271858293};\\\", \\\"{x:580,y:707,t:1527271858306};\\\", \\\"{x:636,y:707,t:1527271858323};\\\", \\\"{x:703,y:708,t:1527271858339};\\\", \\\"{x:757,y:709,t:1527271858357};\\\", \\\"{x:812,y:704,t:1527271858374};\\\", \\\"{x:876,y:704,t:1527271858389};\\\", \\\"{x:997,y:699,t:1527271858407};\\\", \\\"{x:1079,y:695,t:1527271858422};\\\", \\\"{x:1152,y:690,t:1527271858440};\\\", \\\"{x:1206,y:691,t:1527271858456};\\\", \\\"{x:1244,y:690,t:1527271858474};\\\", \\\"{x:1267,y:689,t:1527271858489};\\\", \\\"{x:1269,y:685,t:1527271858507};\\\", \\\"{x:1267,y:685,t:1527271859576};\\\", \\\"{x:1245,y:704,t:1527271859591};\\\", \\\"{x:1229,y:727,t:1527271859607};\\\", \\\"{x:1217,y:746,t:1527271859624};\\\", \\\"{x:1216,y:754,t:1527271859642};\\\", \\\"{x:1215,y:756,t:1527271859658};\\\", \\\"{x:1214,y:757,t:1527271859717};\\\", \\\"{x:1213,y:758,t:1527271859725};\\\", \\\"{x:1212,y:758,t:1527271859741};\\\", \\\"{x:1210,y:758,t:1527271859765};\\\", \\\"{x:1206,y:757,t:1527271859773};\\\", \\\"{x:1203,y:749,t:1527271859789};\\\", \\\"{x:1200,y:742,t:1527271859805};\\\", \\\"{x:1194,y:731,t:1527271859822};\\\", \\\"{x:1188,y:721,t:1527271859839};\\\", \\\"{x:1184,y:712,t:1527271859855};\\\", \\\"{x:1178,y:698,t:1527271859871};\\\", \\\"{x:1174,y:688,t:1527271859889};\\\", \\\"{x:1171,y:682,t:1527271859905};\\\", \\\"{x:1171,y:681,t:1527271859921};\\\", \\\"{x:1171,y:679,t:1527271859938};\\\", \\\"{x:1171,y:678,t:1527271859956};\\\", \\\"{x:1169,y:676,t:1527271860093};\\\", \\\"{x:1168,y:676,t:1527271860106};\\\", \\\"{x:1165,y:674,t:1527271860122};\\\", \\\"{x:1162,y:671,t:1527271860139};\\\", \\\"{x:1156,y:670,t:1527271860156};\\\", \\\"{x:1150,y:670,t:1527271860172};\\\", \\\"{x:1148,y:670,t:1527271860189};\\\", \\\"{x:1147,y:669,t:1527271860237};\\\", \\\"{x:1153,y:657,t:1527271860255};\\\", \\\"{x:1165,y:647,t:1527271860273};\\\", \\\"{x:1187,y:634,t:1527271860288};\\\", \\\"{x:1203,y:624,t:1527271860306};\\\", \\\"{x:1212,y:620,t:1527271860323};\\\", \\\"{x:1215,y:617,t:1527271860339};\\\", \\\"{x:1215,y:616,t:1527271860389};\\\", \\\"{x:1217,y:613,t:1527271860406};\\\", \\\"{x:1219,y:610,t:1527271860423};\\\", \\\"{x:1224,y:606,t:1527271860439};\\\", \\\"{x:1229,y:603,t:1527271860456};\\\", \\\"{x:1233,y:598,t:1527271860473};\\\", \\\"{x:1237,y:596,t:1527271860489};\\\", \\\"{x:1240,y:594,t:1527271860505};\\\", \\\"{x:1242,y:592,t:1527271860523};\\\", \\\"{x:1244,y:590,t:1527271860539};\\\", \\\"{x:1251,y:586,t:1527271860556};\\\", \\\"{x:1259,y:581,t:1527271860573};\\\", \\\"{x:1263,y:579,t:1527271860589};\\\", \\\"{x:1264,y:578,t:1527271860605};\\\", \\\"{x:1266,y:578,t:1527271860623};\\\", \\\"{x:1267,y:577,t:1527271860653};\\\", \\\"{x:1268,y:577,t:1527271860669};\\\", \\\"{x:1269,y:575,t:1527271860684};\\\", \\\"{x:1270,y:575,t:1527271860692};\\\", \\\"{x:1271,y:574,t:1527271860708};\\\", \\\"{x:1272,y:573,t:1527271860722};\\\", \\\"{x:1274,y:572,t:1527271860836};\\\", \\\"{x:1274,y:571,t:1527271860844};\\\", \\\"{x:1276,y:571,t:1527271860900};\\\", \\\"{x:1277,y:571,t:1527271860909};\\\", \\\"{x:1280,y:571,t:1527271860922};\\\", \\\"{x:1283,y:570,t:1527271860939};\\\", \\\"{x:1286,y:570,t:1527271860955};\\\", \\\"{x:1292,y:570,t:1527271860972};\\\", \\\"{x:1293,y:570,t:1527271860989};\\\", \\\"{x:1296,y:570,t:1527271861005};\\\", \\\"{x:1298,y:571,t:1527271861022};\\\", \\\"{x:1300,y:572,t:1527271861039};\\\", \\\"{x:1302,y:573,t:1527271861055};\\\", \\\"{x:1298,y:571,t:1527271861261};\\\", \\\"{x:1296,y:570,t:1527271861277};\\\", \\\"{x:1294,y:569,t:1527271861289};\\\", \\\"{x:1290,y:568,t:1527271861306};\\\", \\\"{x:1288,y:567,t:1527271861323};\\\", \\\"{x:1286,y:567,t:1527271861373};\\\", \\\"{x:1285,y:567,t:1527271861400};\\\", \\\"{x:1282,y:567,t:1527271861422};\\\", \\\"{x:1281,y:567,t:1527271861439};\\\", \\\"{x:1284,y:567,t:1527271862037};\\\", \\\"{x:1286,y:567,t:1527271862054};\\\", \\\"{x:1288,y:567,t:1527271862061};\\\", \\\"{x:1290,y:567,t:1527271862077};\\\", \\\"{x:1292,y:567,t:1527271862089};\\\", \\\"{x:1295,y:567,t:1527271862107};\\\", \\\"{x:1301,y:567,t:1527271862123};\\\", \\\"{x:1309,y:567,t:1527271862140};\\\", \\\"{x:1325,y:567,t:1527271862157};\\\", \\\"{x:1340,y:567,t:1527271862173};\\\", \\\"{x:1354,y:567,t:1527271862190};\\\", \\\"{x:1364,y:567,t:1527271862207};\\\", \\\"{x:1379,y:567,t:1527271862224};\\\", \\\"{x:1397,y:567,t:1527271862240};\\\", \\\"{x:1412,y:567,t:1527271862258};\\\", \\\"{x:1421,y:566,t:1527271862275};\\\", \\\"{x:1427,y:566,t:1527271862289};\\\", \\\"{x:1431,y:566,t:1527271862307};\\\", \\\"{x:1432,y:566,t:1527271862323};\\\", \\\"{x:1417,y:569,t:1527271862374};\\\", \\\"{x:1334,y:594,t:1527271862390};\\\", \\\"{x:1238,y:616,t:1527271862407};\\\", \\\"{x:1125,y:605,t:1527271862423};\\\", \\\"{x:1031,y:605,t:1527271862440};\\\", \\\"{x:997,y:601,t:1527271862457};\\\", \\\"{x:968,y:596,t:1527271862474};\\\", \\\"{x:945,y:593,t:1527271862491};\\\", \\\"{x:931,y:593,t:1527271862505};\\\", \\\"{x:917,y:593,t:1527271862522};\\\", \\\"{x:898,y:595,t:1527271862541};\\\", \\\"{x:892,y:597,t:1527271862557};\\\", \\\"{x:883,y:598,t:1527271862574};\\\", \\\"{x:870,y:598,t:1527271862591};\\\", \\\"{x:860,y:595,t:1527271862607};\\\", \\\"{x:829,y:584,t:1527271862625};\\\", \\\"{x:794,y:581,t:1527271862641};\\\", \\\"{x:761,y:570,t:1527271862658};\\\", \\\"{x:731,y:570,t:1527271862674};\\\", \\\"{x:713,y:565,t:1527271862692};\\\", \\\"{x:673,y:564,t:1527271862708};\\\", \\\"{x:642,y:561,t:1527271862724};\\\", \\\"{x:620,y:559,t:1527271862741};\\\", \\\"{x:610,y:558,t:1527271862757};\\\", \\\"{x:604,y:558,t:1527271862774};\\\", \\\"{x:598,y:557,t:1527271862791};\\\", \\\"{x:595,y:557,t:1527271862807};\\\", \\\"{x:588,y:557,t:1527271862824};\\\", \\\"{x:583,y:556,t:1527271862841};\\\", \\\"{x:579,y:555,t:1527271862858};\\\", \\\"{x:575,y:553,t:1527271862874};\\\", \\\"{x:572,y:552,t:1527271862891};\\\", \\\"{x:570,y:552,t:1527271862908};\\\", \\\"{x:569,y:552,t:1527271862932};\\\", \\\"{x:563,y:552,t:1527271862942};\\\", \\\"{x:551,y:552,t:1527271862958};\\\", \\\"{x:542,y:551,t:1527271862976};\\\", \\\"{x:524,y:549,t:1527271862991};\\\", \\\"{x:518,y:549,t:1527271863008};\\\", \\\"{x:506,y:547,t:1527271863026};\\\", \\\"{x:502,y:544,t:1527271863041};\\\", \\\"{x:494,y:544,t:1527271863059};\\\", \\\"{x:478,y:544,t:1527271863076};\\\", \\\"{x:470,y:543,t:1527271863091};\\\", \\\"{x:459,y:542,t:1527271863107};\\\", \\\"{x:447,y:542,t:1527271863124};\\\", \\\"{x:442,y:542,t:1527271863141};\\\", \\\"{x:435,y:542,t:1527271863158};\\\", \\\"{x:425,y:542,t:1527271863174};\\\", \\\"{x:412,y:545,t:1527271863191};\\\", \\\"{x:403,y:546,t:1527271863208};\\\", \\\"{x:393,y:549,t:1527271863225};\\\", \\\"{x:383,y:553,t:1527271863242};\\\", \\\"{x:379,y:554,t:1527271863258};\\\", \\\"{x:375,y:557,t:1527271863275};\\\", \\\"{x:373,y:558,t:1527271863291};\\\", \\\"{x:372,y:559,t:1527271863308};\\\", \\\"{x:368,y:561,t:1527271863326};\\\", \\\"{x:368,y:562,t:1527271863341};\\\", \\\"{x:368,y:564,t:1527271863359};\\\", \\\"{x:366,y:567,t:1527271863376};\\\", \\\"{x:365,y:570,t:1527271863391};\\\", \\\"{x:365,y:572,t:1527271863408};\\\", \\\"{x:365,y:573,t:1527271863425};\\\", \\\"{x:364,y:577,t:1527271863442};\\\", \\\"{x:361,y:581,t:1527271863459};\\\", \\\"{x:356,y:591,t:1527271863476};\\\", \\\"{x:348,y:598,t:1527271863492};\\\", \\\"{x:334,y:605,t:1527271863509};\\\", \\\"{x:324,y:610,t:1527271863525};\\\", \\\"{x:316,y:610,t:1527271863541};\\\", \\\"{x:306,y:610,t:1527271863558};\\\", \\\"{x:297,y:610,t:1527271863574};\\\", \\\"{x:280,y:610,t:1527271863592};\\\", \\\"{x:270,y:610,t:1527271863609};\\\", \\\"{x:255,y:610,t:1527271863625};\\\", \\\"{x:249,y:610,t:1527271863642};\\\", \\\"{x:242,y:609,t:1527271863658};\\\", \\\"{x:239,y:609,t:1527271863676};\\\", \\\"{x:230,y:609,t:1527271863692};\\\", \\\"{x:223,y:609,t:1527271863709};\\\", \\\"{x:220,y:610,t:1527271863725};\\\", \\\"{x:217,y:611,t:1527271863742};\\\", \\\"{x:214,y:611,t:1527271863759};\\\", \\\"{x:212,y:612,t:1527271863775};\\\", \\\"{x:210,y:612,t:1527271863792};\\\", \\\"{x:205,y:612,t:1527271863809};\\\", \\\"{x:200,y:614,t:1527271863825};\\\", \\\"{x:199,y:614,t:1527271863868};\\\", \\\"{x:197,y:614,t:1527271863884};\\\", \\\"{x:196,y:613,t:1527271863892};\\\", \\\"{x:195,y:602,t:1527271863909};\\\", \\\"{x:192,y:597,t:1527271863927};\\\", \\\"{x:191,y:590,t:1527271863943};\\\", \\\"{x:193,y:580,t:1527271863958};\\\", \\\"{x:195,y:572,t:1527271863975};\\\", \\\"{x:197,y:566,t:1527271863992};\\\", \\\"{x:197,y:560,t:1527271864009};\\\", \\\"{x:199,y:556,t:1527271864025};\\\", \\\"{x:203,y:551,t:1527271864043};\\\", \\\"{x:214,y:546,t:1527271864058};\\\", \\\"{x:238,y:534,t:1527271864075};\\\", \\\"{x:309,y:517,t:1527271864093};\\\", \\\"{x:378,y:510,t:1527271864108};\\\", \\\"{x:428,y:510,t:1527271864125};\\\", \\\"{x:456,y:510,t:1527271864142};\\\", \\\"{x:479,y:509,t:1527271864159};\\\", \\\"{x:489,y:509,t:1527271864175};\\\", \\\"{x:492,y:509,t:1527271864192};\\\", \\\"{x:494,y:509,t:1527271864244};\\\", \\\"{x:499,y:509,t:1527271864260};\\\", \\\"{x:519,y:509,t:1527271864276};\\\", \\\"{x:529,y:509,t:1527271864292};\\\", \\\"{x:533,y:509,t:1527271864308};\\\", \\\"{x:538,y:509,t:1527271864325};\\\", \\\"{x:543,y:507,t:1527271864342};\\\", \\\"{x:560,y:502,t:1527271864358};\\\", \\\"{x:575,y:497,t:1527271864376};\\\", \\\"{x:592,y:493,t:1527271864392};\\\", \\\"{x:602,y:492,t:1527271864409};\\\", \\\"{x:606,y:492,t:1527271864425};\\\", \\\"{x:608,y:493,t:1527271864549};\\\", \\\"{x:608,y:495,t:1527271864559};\\\", \\\"{x:611,y:500,t:1527271864576};\\\", \\\"{x:613,y:501,t:1527271864592};\\\", \\\"{x:614,y:503,t:1527271864609};\\\", \\\"{x:613,y:505,t:1527271864933};\\\", \\\"{x:600,y:512,t:1527271864942};\\\", \\\"{x:580,y:522,t:1527271864959};\\\", \\\"{x:547,y:543,t:1527271864976};\\\", \\\"{x:511,y:558,t:1527271864993};\\\", \\\"{x:492,y:564,t:1527271865009};\\\", \\\"{x:475,y:569,t:1527271865026};\\\", \\\"{x:462,y:575,t:1527271865043};\\\", \\\"{x:440,y:578,t:1527271865059};\\\", \\\"{x:405,y:584,t:1527271865076};\\\", \\\"{x:392,y:586,t:1527271865094};\\\", \\\"{x:378,y:586,t:1527271865109};\\\", \\\"{x:355,y:586,t:1527271865127};\\\", \\\"{x:345,y:586,t:1527271865143};\\\", \\\"{x:343,y:586,t:1527271865160};\\\", \\\"{x:337,y:588,t:1527271865176};\\\", \\\"{x:328,y:588,t:1527271865193};\\\", \\\"{x:322,y:589,t:1527271865210};\\\", \\\"{x:312,y:593,t:1527271865226};\\\", \\\"{x:300,y:595,t:1527271865244};\\\", \\\"{x:283,y:596,t:1527271865260};\\\", \\\"{x:273,y:598,t:1527271865276};\\\", \\\"{x:268,y:598,t:1527271865293};\\\", \\\"{x:263,y:598,t:1527271865310};\\\", \\\"{x:248,y:598,t:1527271865326};\\\", \\\"{x:232,y:598,t:1527271865344};\\\", \\\"{x:226,y:598,t:1527271865359};\\\", \\\"{x:221,y:596,t:1527271865376};\\\", \\\"{x:220,y:596,t:1527271865396};\\\", \\\"{x:220,y:593,t:1527271865413};\\\", \\\"{x:220,y:591,t:1527271865426};\\\", \\\"{x:220,y:587,t:1527271865443};\\\", \\\"{x:237,y:573,t:1527271865459};\\\", \\\"{x:375,y:539,t:1527271865477};\\\", \\\"{x:521,y:524,t:1527271865493};\\\", \\\"{x:664,y:513,t:1527271865511};\\\", \\\"{x:761,y:511,t:1527271865527};\\\", \\\"{x:821,y:515,t:1527271865544};\\\", \\\"{x:835,y:520,t:1527271865560};\\\", \\\"{x:847,y:523,t:1527271865576};\\\", \\\"{x:849,y:523,t:1527271865644};\\\", \\\"{x:853,y:523,t:1527271865660};\\\", \\\"{x:856,y:523,t:1527271865676};\\\", \\\"{x:856,y:524,t:1527271865773};\\\", \\\"{x:854,y:525,t:1527271865782};\\\", \\\"{x:852,y:528,t:1527271865795};\\\", \\\"{x:848,y:532,t:1527271865811};\\\", \\\"{x:845,y:535,t:1527271865826};\\\", \\\"{x:840,y:539,t:1527271865844};\\\", \\\"{x:835,y:542,t:1527271865861};\\\", \\\"{x:825,y:548,t:1527271866514};\\\", \\\"{x:809,y:557,t:1527271866527};\\\", \\\"{x:784,y:567,t:1527271866544};\\\", \\\"{x:760,y:576,t:1527271866560};\\\", \\\"{x:729,y:586,t:1527271866577};\\\", \\\"{x:707,y:592,t:1527271866595};\\\", \\\"{x:685,y:600,t:1527271866611};\\\", \\\"{x:671,y:607,t:1527271866628};\\\", \\\"{x:649,y:616,t:1527271866644};\\\", \\\"{x:630,y:626,t:1527271866660};\\\", \\\"{x:611,y:633,t:1527271866678};\\\", \\\"{x:602,y:639,t:1527271866694};\\\", \\\"{x:583,y:646,t:1527271866711};\\\", \\\"{x:576,y:654,t:1527271866727};\\\", \\\"{x:569,y:657,t:1527271866744};\\\", \\\"{x:563,y:661,t:1527271866761};\\\", \\\"{x:560,y:665,t:1527271866778};\\\", \\\"{x:557,y:666,t:1527271866794};\\\", \\\"{x:554,y:669,t:1527271866812};\\\", \\\"{x:550,y:671,t:1527271866828};\\\", \\\"{x:546,y:676,t:1527271866845};\\\", \\\"{x:542,y:680,t:1527271866861};\\\", \\\"{x:539,y:687,t:1527271866879};\\\", \\\"{x:536,y:692,t:1527271866896};\\\", \\\"{x:532,y:697,t:1527271866911};\\\", \\\"{x:530,y:703,t:1527271866928};\\\", \\\"{x:526,y:710,t:1527271866945};\\\", \\\"{x:519,y:718,t:1527271866962};\\\", \\\"{x:514,y:723,t:1527271866979};\\\", \\\"{x:509,y:729,t:1527271866995};\\\", \\\"{x:506,y:734,t:1527271867010};\\\", \\\"{x:498,y:740,t:1527271867027};\\\", \\\"{x:494,y:744,t:1527271867043};\\\", \\\"{x:487,y:748,t:1527271867060};\\\", \\\"{x:481,y:751,t:1527271867077};\\\", \\\"{x:479,y:751,t:1527271867093};\\\", \\\"{x:477,y:752,t:1527271867110};\\\", \\\"{x:479,y:751,t:1527271867316};\\\", \\\"{x:480,y:750,t:1527271867327};\\\", \\\"{x:483,y:747,t:1527271867344};\\\", \\\"{x:486,y:745,t:1527271867360};\\\", \\\"{x:486,y:744,t:1527271867377};\\\", \\\"{x:487,y:743,t:1527271867393};\\\" ] }, { \\\"rt\\\": 15909, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 564948, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:488,y:741,t:1527271869141};\\\", \\\"{x:488,y:739,t:1527271869156};\\\", \\\"{x:489,y:738,t:1527271869164};\\\", \\\"{x:489,y:737,t:1527271869179};\\\", \\\"{x:488,y:735,t:1527271869197};\\\", \\\"{x:486,y:733,t:1527271869237};\\\", \\\"{x:484,y:726,t:1527271869246};\\\", \\\"{x:481,y:710,t:1527271869264};\\\", \\\"{x:481,y:707,t:1527271869280};\\\", \\\"{x:480,y:706,t:1527271871125};\\\", \\\"{x:479,y:706,t:1527271871140};\\\", \\\"{x:477,y:706,t:1527271871148};\\\", \\\"{x:475,y:706,t:1527271871165};\\\", \\\"{x:472,y:710,t:1527271871413};\\\", \\\"{x:468,y:714,t:1527271871420};\\\", \\\"{x:468,y:723,t:1527271871434};\\\", \\\"{x:487,y:745,t:1527271871448};\\\", \\\"{x:549,y:763,t:1527271871464};\\\", \\\"{x:673,y:780,t:1527271871481};\\\", \\\"{x:776,y:782,t:1527271871499};\\\", \\\"{x:822,y:780,t:1527271871514};\\\", \\\"{x:823,y:778,t:1527271873118};\\\", \\\"{x:833,y:766,t:1527271873133};\\\", \\\"{x:840,y:761,t:1527271873150};\\\", \\\"{x:840,y:760,t:1527271873166};\\\", \\\"{x:850,y:755,t:1527271873183};\\\", \\\"{x:869,y:747,t:1527271873200};\\\", \\\"{x:947,y:733,t:1527271873217};\\\", \\\"{x:1025,y:718,t:1527271873233};\\\", \\\"{x:1122,y:704,t:1527271873250};\\\", \\\"{x:1172,y:682,t:1527271873267};\\\", \\\"{x:1210,y:675,t:1527271873283};\\\", \\\"{x:1225,y:674,t:1527271873300};\\\", \\\"{x:1243,y:671,t:1527271873316};\\\", \\\"{x:1253,y:669,t:1527271873332};\\\", \\\"{x:1256,y:669,t:1527271873349};\\\", \\\"{x:1259,y:668,t:1527271873366};\\\", \\\"{x:1260,y:668,t:1527271873732};\\\", \\\"{x:1261,y:668,t:1527271873747};\\\", \\\"{x:1265,y:667,t:1527271873756};\\\", \\\"{x:1268,y:662,t:1527271873766};\\\", \\\"{x:1280,y:655,t:1527271873784};\\\", \\\"{x:1286,y:651,t:1527271873799};\\\", \\\"{x:1289,y:649,t:1527271873816};\\\", \\\"{x:1290,y:648,t:1527271873833};\\\", \\\"{x:1291,y:648,t:1527271873849};\\\", \\\"{x:1292,y:647,t:1527271873866};\\\", \\\"{x:1295,y:649,t:1527271874436};\\\", \\\"{x:1297,y:651,t:1527271874450};\\\", \\\"{x:1300,y:656,t:1527271874468};\\\", \\\"{x:1303,y:657,t:1527271874484};\\\", \\\"{x:1303,y:659,t:1527271874501};\\\", \\\"{x:1303,y:660,t:1527271874518};\\\", \\\"{x:1304,y:662,t:1527271874548};\\\", \\\"{x:1304,y:663,t:1527271874555};\\\", \\\"{x:1304,y:664,t:1527271874567};\\\", \\\"{x:1305,y:666,t:1527271874583};\\\", \\\"{x:1306,y:670,t:1527271874600};\\\", \\\"{x:1306,y:671,t:1527271874617};\\\", \\\"{x:1308,y:676,t:1527271874634};\\\", \\\"{x:1309,y:680,t:1527271874651};\\\", \\\"{x:1309,y:682,t:1527271874668};\\\", \\\"{x:1310,y:682,t:1527271874683};\\\", \\\"{x:1311,y:684,t:1527271874701};\\\", \\\"{x:1314,y:685,t:1527271874718};\\\", \\\"{x:1315,y:686,t:1527271874740};\\\", \\\"{x:1316,y:687,t:1527271874751};\\\", \\\"{x:1317,y:688,t:1527271874767};\\\", \\\"{x:1318,y:690,t:1527271874784};\\\", \\\"{x:1320,y:692,t:1527271874801};\\\", \\\"{x:1324,y:696,t:1527271874818};\\\", \\\"{x:1326,y:701,t:1527271874834};\\\", \\\"{x:1328,y:707,t:1527271874851};\\\", \\\"{x:1330,y:713,t:1527271874868};\\\", \\\"{x:1331,y:716,t:1527271874884};\\\", \\\"{x:1331,y:718,t:1527271874901};\\\", \\\"{x:1332,y:720,t:1527271874917};\\\", \\\"{x:1333,y:720,t:1527271875004};\\\", \\\"{x:1333,y:719,t:1527271875018};\\\", \\\"{x:1336,y:715,t:1527271875035};\\\", \\\"{x:1339,y:711,t:1527271875051};\\\", \\\"{x:1341,y:707,t:1527271875068};\\\", \\\"{x:1343,y:705,t:1527271875085};\\\", \\\"{x:1345,y:704,t:1527271875101};\\\", \\\"{x:1348,y:702,t:1527271875120};\\\", \\\"{x:1349,y:702,t:1527271875134};\\\", \\\"{x:1351,y:700,t:1527271875187};\\\", \\\"{x:1353,y:699,t:1527271875203};\\\", \\\"{x:1352,y:699,t:1527271879797};\\\", \\\"{x:1349,y:700,t:1527271879813};\\\", \\\"{x:1347,y:700,t:1527271879823};\\\", \\\"{x:1343,y:704,t:1527271879840};\\\", \\\"{x:1332,y:708,t:1527271879855};\\\", \\\"{x:1318,y:713,t:1527271879872};\\\", \\\"{x:1295,y:719,t:1527271879888};\\\", \\\"{x:1274,y:725,t:1527271879905};\\\", \\\"{x:1226,y:737,t:1527271879921};\\\", \\\"{x:1170,y:747,t:1527271879937};\\\", \\\"{x:1093,y:765,t:1527271879955};\\\", \\\"{x:892,y:791,t:1527271879972};\\\", \\\"{x:727,y:806,t:1527271879988};\\\", \\\"{x:566,y:819,t:1527271880005};\\\", \\\"{x:442,y:832,t:1527271880022};\\\", \\\"{x:353,y:841,t:1527271880038};\\\", \\\"{x:292,y:850,t:1527271880055};\\\", \\\"{x:242,y:856,t:1527271880071};\\\", \\\"{x:215,y:859,t:1527271880088};\\\", \\\"{x:193,y:861,t:1527271880104};\\\", \\\"{x:182,y:863,t:1527271880122};\\\", \\\"{x:174,y:863,t:1527271880138};\\\", \\\"{x:172,y:863,t:1527271880154};\\\", \\\"{x:166,y:853,t:1527271880171};\\\", \\\"{x:159,y:843,t:1527271880188};\\\", \\\"{x:150,y:831,t:1527271880205};\\\", \\\"{x:141,y:819,t:1527271880222};\\\", \\\"{x:138,y:808,t:1527271880238};\\\", \\\"{x:137,y:803,t:1527271880255};\\\", \\\"{x:136,y:792,t:1527271880272};\\\", \\\"{x:136,y:775,t:1527271880289};\\\", \\\"{x:141,y:759,t:1527271880305};\\\", \\\"{x:164,y:738,t:1527271880321};\\\", \\\"{x:184,y:722,t:1527271880338};\\\", \\\"{x:205,y:706,t:1527271880355};\\\", \\\"{x:236,y:685,t:1527271880372};\\\", \\\"{x:247,y:671,t:1527271880389};\\\", \\\"{x:264,y:657,t:1527271880405};\\\", \\\"{x:282,y:643,t:1527271880422};\\\", \\\"{x:302,y:628,t:1527271880440};\\\", \\\"{x:320,y:616,t:1527271880455};\\\", \\\"{x:333,y:608,t:1527271880472};\\\", \\\"{x:341,y:602,t:1527271880488};\\\", \\\"{x:344,y:601,t:1527271880505};\\\", \\\"{x:344,y:600,t:1527271880522};\\\", \\\"{x:345,y:600,t:1527271880538};\\\", \\\"{x:345,y:599,t:1527271880604};\\\", \\\"{x:345,y:596,t:1527271880612};\\\", \\\"{x:343,y:595,t:1527271880622};\\\", \\\"{x:328,y:592,t:1527271880639};\\\", \\\"{x:313,y:591,t:1527271880655};\\\", \\\"{x:288,y:591,t:1527271880672};\\\", \\\"{x:263,y:591,t:1527271880689};\\\", \\\"{x:244,y:591,t:1527271880706};\\\", \\\"{x:226,y:591,t:1527271880722};\\\", \\\"{x:218,y:592,t:1527271880739};\\\", \\\"{x:212,y:595,t:1527271880756};\\\", \\\"{x:209,y:597,t:1527271880773};\\\", \\\"{x:207,y:598,t:1527271880789};\\\", \\\"{x:207,y:599,t:1527271880819};\\\", \\\"{x:217,y:595,t:1527271880892};\\\", \\\"{x:235,y:590,t:1527271880907};\\\", \\\"{x:301,y:584,t:1527271880923};\\\", \\\"{x:397,y:580,t:1527271880939};\\\", \\\"{x:547,y:595,t:1527271880956};\\\", \\\"{x:630,y:606,t:1527271880973};\\\", \\\"{x:669,y:610,t:1527271880989};\\\", \\\"{x:685,y:610,t:1527271881005};\\\", \\\"{x:694,y:610,t:1527271881022};\\\", \\\"{x:697,y:610,t:1527271881039};\\\", \\\"{x:697,y:605,t:1527271881056};\\\", \\\"{x:697,y:599,t:1527271881074};\\\", \\\"{x:694,y:593,t:1527271881090};\\\", \\\"{x:693,y:590,t:1527271881106};\\\", \\\"{x:693,y:588,t:1527271881123};\\\", \\\"{x:693,y:585,t:1527271881139};\\\", \\\"{x:691,y:581,t:1527271881155};\\\", \\\"{x:688,y:578,t:1527271881172};\\\", \\\"{x:684,y:577,t:1527271881189};\\\", \\\"{x:678,y:574,t:1527271881206};\\\", \\\"{x:672,y:574,t:1527271881223};\\\", \\\"{x:669,y:574,t:1527271881239};\\\", \\\"{x:671,y:574,t:1527271881315};\\\", \\\"{x:681,y:576,t:1527271881324};\\\", \\\"{x:685,y:576,t:1527271881339};\\\", \\\"{x:714,y:581,t:1527271881356};\\\", \\\"{x:724,y:582,t:1527271881373};\\\", \\\"{x:733,y:582,t:1527271881389};\\\", \\\"{x:737,y:582,t:1527271881405};\\\", \\\"{x:743,y:578,t:1527271881423};\\\", \\\"{x:744,y:577,t:1527271881440};\\\", \\\"{x:745,y:573,t:1527271881455};\\\", \\\"{x:748,y:568,t:1527271881473};\\\", \\\"{x:749,y:563,t:1527271881490};\\\", \\\"{x:752,y:559,t:1527271881506};\\\", \\\"{x:758,y:556,t:1527271881523};\\\", \\\"{x:764,y:553,t:1527271881540};\\\", \\\"{x:770,y:553,t:1527271881556};\\\", \\\"{x:773,y:552,t:1527271881572};\\\", \\\"{x:778,y:552,t:1527271881590};\\\", \\\"{x:786,y:559,t:1527271881607};\\\", \\\"{x:792,y:564,t:1527271881623};\\\", \\\"{x:806,y:570,t:1527271881640};\\\", \\\"{x:821,y:575,t:1527271881655};\\\", \\\"{x:826,y:578,t:1527271881673};\\\", \\\"{x:827,y:578,t:1527271881690};\\\", \\\"{x:826,y:579,t:1527271881996};\\\", \\\"{x:823,y:579,t:1527271882012};\\\", \\\"{x:822,y:579,t:1527271882023};\\\", \\\"{x:815,y:581,t:1527271882040};\\\", \\\"{x:798,y:585,t:1527271882056};\\\", \\\"{x:774,y:594,t:1527271882074};\\\", \\\"{x:718,y:609,t:1527271882090};\\\", \\\"{x:671,y:614,t:1527271882107};\\\", \\\"{x:643,y:620,t:1527271882123};\\\", \\\"{x:607,y:626,t:1527271882140};\\\", \\\"{x:589,y:631,t:1527271882157};\\\", \\\"{x:576,y:637,t:1527271882173};\\\", \\\"{x:561,y:644,t:1527271882190};\\\", \\\"{x:546,y:649,t:1527271882207};\\\", \\\"{x:540,y:654,t:1527271882223};\\\", \\\"{x:534,y:656,t:1527271882240};\\\", \\\"{x:530,y:657,t:1527271882257};\\\", \\\"{x:526,y:657,t:1527271882272};\\\", \\\"{x:523,y:657,t:1527271882290};\\\", \\\"{x:514,y:655,t:1527271882307};\\\", \\\"{x:498,y:651,t:1527271882324};\\\", \\\"{x:484,y:648,t:1527271882339};\\\", \\\"{x:478,y:644,t:1527271882357};\\\", \\\"{x:473,y:641,t:1527271882373};\\\", \\\"{x:470,y:641,t:1527271882390};\\\", \\\"{x:467,y:641,t:1527271882407};\\\", \\\"{x:462,y:641,t:1527271882424};\\\", \\\"{x:457,y:641,t:1527271882439};\\\", \\\"{x:453,y:641,t:1527271882456};\\\", \\\"{x:453,y:642,t:1527271882473};\\\", \\\"{x:452,y:642,t:1527271882489};\\\", \\\"{x:453,y:641,t:1527271882524};\\\", \\\"{x:459,y:638,t:1527271882540};\\\", \\\"{x:460,y:637,t:1527271882557};\\\", \\\"{x:460,y:636,t:1527271882620};\\\", \\\"{x:456,y:634,t:1527271882628};\\\", \\\"{x:448,y:631,t:1527271882642};\\\", \\\"{x:440,y:627,t:1527271882657};\\\", \\\"{x:431,y:623,t:1527271882673};\\\", \\\"{x:427,y:621,t:1527271882691};\\\", \\\"{x:426,y:620,t:1527271882707};\\\", \\\"{x:424,y:619,t:1527271882723};\\\", \\\"{x:421,y:616,t:1527271882741};\\\", \\\"{x:417,y:612,t:1527271882756};\\\", \\\"{x:411,y:606,t:1527271882775};\\\", \\\"{x:408,y:602,t:1527271882791};\\\", \\\"{x:406,y:598,t:1527271882807};\\\", \\\"{x:405,y:598,t:1527271882836};\\\", \\\"{x:401,y:597,t:1527271882860};\\\", \\\"{x:393,y:598,t:1527271882874};\\\", \\\"{x:375,y:601,t:1527271882891};\\\", \\\"{x:357,y:606,t:1527271882907};\\\", \\\"{x:333,y:611,t:1527271882924};\\\", \\\"{x:324,y:615,t:1527271882941};\\\", \\\"{x:319,y:615,t:1527271882957};\\\", \\\"{x:315,y:615,t:1527271882974};\\\", \\\"{x:307,y:620,t:1527271882991};\\\", \\\"{x:291,y:626,t:1527271883007};\\\", \\\"{x:277,y:630,t:1527271883024};\\\", \\\"{x:267,y:633,t:1527271883041};\\\", \\\"{x:266,y:635,t:1527271883058};\\\", \\\"{x:263,y:635,t:1527271883073};\\\", \\\"{x:259,y:637,t:1527271883091};\\\", \\\"{x:254,y:638,t:1527271883107};\\\", \\\"{x:238,y:643,t:1527271883125};\\\", \\\"{x:226,y:648,t:1527271883141};\\\", \\\"{x:221,y:650,t:1527271883157};\\\", \\\"{x:219,y:651,t:1527271883174};\\\", \\\"{x:221,y:651,t:1527271883276};\\\", \\\"{x:231,y:648,t:1527271883291};\\\", \\\"{x:262,y:631,t:1527271883309};\\\", \\\"{x:295,y:621,t:1527271883326};\\\", \\\"{x:325,y:612,t:1527271883341};\\\", \\\"{x:345,y:601,t:1527271883357};\\\", \\\"{x:369,y:592,t:1527271883375};\\\", \\\"{x:386,y:587,t:1527271883391};\\\", \\\"{x:398,y:585,t:1527271883408};\\\", \\\"{x:406,y:581,t:1527271883424};\\\", \\\"{x:415,y:578,t:1527271883440};\\\", \\\"{x:429,y:575,t:1527271883458};\\\", \\\"{x:443,y:572,t:1527271883474};\\\", \\\"{x:461,y:570,t:1527271883491};\\\", \\\"{x:487,y:566,t:1527271883508};\\\", \\\"{x:509,y:566,t:1527271883526};\\\", \\\"{x:529,y:566,t:1527271883541};\\\", \\\"{x:547,y:564,t:1527271883558};\\\", \\\"{x:563,y:560,t:1527271883576};\\\", \\\"{x:577,y:557,t:1527271883591};\\\", \\\"{x:596,y:552,t:1527271883609};\\\", \\\"{x:610,y:547,t:1527271883626};\\\", \\\"{x:627,y:544,t:1527271883641};\\\", \\\"{x:642,y:540,t:1527271883658};\\\", \\\"{x:652,y:537,t:1527271883675};\\\", \\\"{x:660,y:535,t:1527271883691};\\\", \\\"{x:673,y:530,t:1527271883708};\\\", \\\"{x:679,y:528,t:1527271883725};\\\", \\\"{x:681,y:527,t:1527271883741};\\\", \\\"{x:680,y:527,t:1527271883853};\\\", \\\"{x:674,y:533,t:1527271883860};\\\", \\\"{x:659,y:546,t:1527271883875};\\\", \\\"{x:629,y:566,t:1527271883894};\\\", \\\"{x:617,y:575,t:1527271883908};\\\", \\\"{x:603,y:584,t:1527271883925};\\\", \\\"{x:592,y:591,t:1527271883941};\\\", \\\"{x:577,y:597,t:1527271883958};\\\", \\\"{x:575,y:600,t:1527271883975};\\\", \\\"{x:570,y:601,t:1527271883992};\\\", \\\"{x:573,y:599,t:1527271884093};\\\", \\\"{x:577,y:596,t:1527271884108};\\\", \\\"{x:584,y:593,t:1527271884126};\\\", \\\"{x:595,y:589,t:1527271884142};\\\", \\\"{x:600,y:587,t:1527271884159};\\\", \\\"{x:603,y:585,t:1527271884175};\\\", \\\"{x:604,y:585,t:1527271884192};\\\", \\\"{x:605,y:585,t:1527271884208};\\\", \\\"{x:606,y:583,t:1527271884225};\\\", \\\"{x:608,y:582,t:1527271884244};\\\", \\\"{x:605,y:587,t:1527271884476};\\\", \\\"{x:595,y:600,t:1527271884492};\\\", \\\"{x:582,y:617,t:1527271884509};\\\", \\\"{x:564,y:647,t:1527271884525};\\\", \\\"{x:553,y:671,t:1527271884542};\\\", \\\"{x:546,y:694,t:1527271884559};\\\", \\\"{x:543,y:705,t:1527271884575};\\\", \\\"{x:541,y:712,t:1527271884592};\\\", \\\"{x:540,y:717,t:1527271884608};\\\", \\\"{x:540,y:719,t:1527271884625};\\\", \\\"{x:538,y:725,t:1527271884642};\\\", \\\"{x:538,y:728,t:1527271884659};\\\", \\\"{x:537,y:729,t:1527271884675};\\\", \\\"{x:536,y:729,t:1527271884692};\\\" ] }, { \\\"rt\\\": 30489, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 596719, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -O -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:559,y:717,t:1527271887503};\\\", \\\"{x:600,y:689,t:1527271887514};\\\", \\\"{x:726,y:640,t:1527271887530};\\\", \\\"{x:853,y:611,t:1527271887547};\\\", \\\"{x:955,y:583,t:1527271887561};\\\", \\\"{x:1047,y:554,t:1527271887578};\\\", \\\"{x:1148,y:522,t:1527271887594};\\\", \\\"{x:1232,y:505,t:1527271887611};\\\", \\\"{x:1337,y:489,t:1527271887628};\\\", \\\"{x:1386,y:486,t:1527271887644};\\\", \\\"{x:1409,y:482,t:1527271887661};\\\", \\\"{x:1430,y:481,t:1527271887678};\\\", \\\"{x:1446,y:475,t:1527271887694};\\\", \\\"{x:1454,y:475,t:1527271887711};\\\", \\\"{x:1470,y:469,t:1527271887728};\\\", \\\"{x:1495,y:467,t:1527271887744};\\\", \\\"{x:1514,y:465,t:1527271887761};\\\", \\\"{x:1524,y:465,t:1527271887778};\\\", \\\"{x:1546,y:459,t:1527271887795};\\\", \\\"{x:1568,y:449,t:1527271887812};\\\", \\\"{x:1571,y:447,t:1527271887828};\\\", \\\"{x:1565,y:447,t:1527271887860};\\\", \\\"{x:1558,y:447,t:1527271887868};\\\", \\\"{x:1545,y:447,t:1527271887878};\\\", \\\"{x:1523,y:450,t:1527271887895};\\\", \\\"{x:1505,y:457,t:1527271887911};\\\", \\\"{x:1481,y:467,t:1527271887929};\\\", \\\"{x:1453,y:476,t:1527271887946};\\\", \\\"{x:1436,y:484,t:1527271887961};\\\", \\\"{x:1418,y:492,t:1527271887978};\\\", \\\"{x:1411,y:497,t:1527271887995};\\\", \\\"{x:1410,y:498,t:1527271888011};\\\", \\\"{x:1409,y:498,t:1527271888028};\\\", \\\"{x:1408,y:499,t:1527271888101};\\\", \\\"{x:1407,y:501,t:1527271888117};\\\", \\\"{x:1404,y:501,t:1527271888129};\\\", \\\"{x:1401,y:504,t:1527271888145};\\\", \\\"{x:1399,y:505,t:1527271888162};\\\", \\\"{x:1395,y:506,t:1527271888178};\\\", \\\"{x:1393,y:509,t:1527271888195};\\\", \\\"{x:1390,y:511,t:1527271888211};\\\", \\\"{x:1386,y:517,t:1527271888229};\\\", \\\"{x:1385,y:522,t:1527271888245};\\\", \\\"{x:1380,y:531,t:1527271888261};\\\", \\\"{x:1376,y:544,t:1527271888278};\\\", \\\"{x:1375,y:553,t:1527271888296};\\\", \\\"{x:1372,y:558,t:1527271888312};\\\", \\\"{x:1371,y:558,t:1527271888329};\\\", \\\"{x:1370,y:560,t:1527271888381};\\\", \\\"{x:1369,y:560,t:1527271888404};\\\", \\\"{x:1368,y:560,t:1527271890293};\\\", \\\"{x:1366,y:559,t:1527271891013};\\\", \\\"{x:1365,y:557,t:1527271891029};\\\", \\\"{x:1364,y:556,t:1527271891100};\\\", \\\"{x:1361,y:554,t:1527271891411};\\\", \\\"{x:1353,y:552,t:1527271891420};\\\", \\\"{x:1344,y:549,t:1527271891431};\\\", \\\"{x:1330,y:547,t:1527271891447};\\\", \\\"{x:1313,y:541,t:1527271891465};\\\", \\\"{x:1299,y:538,t:1527271891481};\\\", \\\"{x:1295,y:538,t:1527271891497};\\\", \\\"{x:1295,y:539,t:1527271891636};\\\", \\\"{x:1297,y:539,t:1527271891648};\\\", \\\"{x:1299,y:540,t:1527271891665};\\\", \\\"{x:1301,y:541,t:1527271891682};\\\", \\\"{x:1302,y:542,t:1527271891698};\\\", \\\"{x:1302,y:543,t:1527271891714};\\\", \\\"{x:1303,y:543,t:1527271891732};\\\", \\\"{x:1304,y:544,t:1527271891765};\\\", \\\"{x:1305,y:546,t:1527271891789};\\\", \\\"{x:1306,y:546,t:1527271891799};\\\", \\\"{x:1307,y:548,t:1527271891821};\\\", \\\"{x:1308,y:548,t:1527271891832};\\\", \\\"{x:1310,y:549,t:1527271891848};\\\", \\\"{x:1314,y:552,t:1527271891864};\\\", \\\"{x:1319,y:554,t:1527271891881};\\\", \\\"{x:1321,y:556,t:1527271891899};\\\", \\\"{x:1323,y:556,t:1527271891914};\\\", \\\"{x:1327,y:560,t:1527271891932};\\\", \\\"{x:1330,y:561,t:1527271891947};\\\", \\\"{x:1335,y:564,t:1527271891964};\\\", \\\"{x:1338,y:566,t:1527271891982};\\\", \\\"{x:1340,y:567,t:1527271891998};\\\", \\\"{x:1341,y:567,t:1527271892068};\\\", \\\"{x:1342,y:567,t:1527271892082};\\\", \\\"{x:1345,y:570,t:1527271892100};\\\", \\\"{x:1349,y:572,t:1527271892115};\\\", \\\"{x:1365,y:585,t:1527271892132};\\\", \\\"{x:1376,y:592,t:1527271892148};\\\", \\\"{x:1383,y:598,t:1527271892164};\\\", \\\"{x:1392,y:601,t:1527271892182};\\\", \\\"{x:1394,y:604,t:1527271892198};\\\", \\\"{x:1397,y:608,t:1527271892216};\\\", \\\"{x:1398,y:613,t:1527271892231};\\\", \\\"{x:1402,y:629,t:1527271892249};\\\", \\\"{x:1398,y:651,t:1527271892266};\\\", \\\"{x:1386,y:677,t:1527271892282};\\\", \\\"{x:1368,y:696,t:1527271892298};\\\", \\\"{x:1348,y:729,t:1527271892316};\\\", \\\"{x:1343,y:740,t:1527271892332};\\\", \\\"{x:1335,y:757,t:1527271892348};\\\", \\\"{x:1333,y:765,t:1527271892366};\\\", \\\"{x:1332,y:767,t:1527271892381};\\\", \\\"{x:1332,y:768,t:1527271892461};\\\", \\\"{x:1335,y:768,t:1527271892485};\\\", \\\"{x:1336,y:768,t:1527271892499};\\\", \\\"{x:1336,y:767,t:1527271892516};\\\", \\\"{x:1338,y:767,t:1527271892532};\\\", \\\"{x:1339,y:767,t:1527271892604};\\\", \\\"{x:1342,y:767,t:1527271892615};\\\", \\\"{x:1343,y:767,t:1527271892632};\\\", \\\"{x:1345,y:767,t:1527271892869};\\\", \\\"{x:1346,y:765,t:1527271892898};\\\", \\\"{x:1346,y:764,t:1527271892956};\\\", \\\"{x:1347,y:765,t:1527271893340};\\\", \\\"{x:1347,y:767,t:1527271893350};\\\", \\\"{x:1347,y:781,t:1527271893366};\\\", \\\"{x:1346,y:791,t:1527271893382};\\\", \\\"{x:1344,y:796,t:1527271893400};\\\", \\\"{x:1339,y:806,t:1527271893415};\\\", \\\"{x:1335,y:818,t:1527271893432};\\\", \\\"{x:1333,y:825,t:1527271893450};\\\", \\\"{x:1330,y:830,t:1527271893466};\\\", \\\"{x:1328,y:833,t:1527271893482};\\\", \\\"{x:1327,y:835,t:1527271893499};\\\", \\\"{x:1326,y:837,t:1527271893516};\\\", \\\"{x:1325,y:839,t:1527271893580};\\\", \\\"{x:1324,y:840,t:1527271893588};\\\", \\\"{x:1323,y:841,t:1527271893599};\\\", \\\"{x:1322,y:844,t:1527271893616};\\\", \\\"{x:1321,y:845,t:1527271893632};\\\", \\\"{x:1318,y:852,t:1527271893650};\\\", \\\"{x:1314,y:856,t:1527271893667};\\\", \\\"{x:1308,y:865,t:1527271893682};\\\", \\\"{x:1302,y:872,t:1527271893700};\\\", \\\"{x:1294,y:882,t:1527271893716};\\\", \\\"{x:1290,y:890,t:1527271893732};\\\", \\\"{x:1283,y:900,t:1527271893749};\\\", \\\"{x:1280,y:905,t:1527271893766};\\\", \\\"{x:1275,y:915,t:1527271893782};\\\", \\\"{x:1270,y:923,t:1527271893800};\\\", \\\"{x:1267,y:928,t:1527271893816};\\\", \\\"{x:1262,y:936,t:1527271893832};\\\", \\\"{x:1257,y:940,t:1527271893849};\\\", \\\"{x:1251,y:947,t:1527271893866};\\\", \\\"{x:1249,y:949,t:1527271893882};\\\", \\\"{x:1242,y:956,t:1527271893900};\\\", \\\"{x:1240,y:960,t:1527271893917};\\\", \\\"{x:1237,y:962,t:1527271893933};\\\", \\\"{x:1240,y:960,t:1527271894444};\\\", \\\"{x:1241,y:959,t:1527271894476};\\\", \\\"{x:1242,y:959,t:1527271894484};\\\", \\\"{x:1243,y:959,t:1527271894501};\\\", \\\"{x:1243,y:958,t:1527271894517};\\\", \\\"{x:1244,y:957,t:1527271894533};\\\", \\\"{x:1246,y:956,t:1527271894551};\\\", \\\"{x:1249,y:954,t:1527271894566};\\\", \\\"{x:1251,y:953,t:1527271894583};\\\", \\\"{x:1252,y:952,t:1527271894600};\\\", \\\"{x:1253,y:951,t:1527271894616};\\\", \\\"{x:1255,y:950,t:1527271894633};\\\", \\\"{x:1256,y:949,t:1527271894651};\\\", \\\"{x:1257,y:947,t:1527271894666};\\\", \\\"{x:1262,y:943,t:1527271894684};\\\", \\\"{x:1267,y:938,t:1527271894700};\\\", \\\"{x:1271,y:931,t:1527271894716};\\\", \\\"{x:1279,y:921,t:1527271894733};\\\", \\\"{x:1284,y:913,t:1527271894750};\\\", \\\"{x:1289,y:907,t:1527271894766};\\\", \\\"{x:1294,y:900,t:1527271894783};\\\", \\\"{x:1298,y:894,t:1527271894800};\\\", \\\"{x:1306,y:888,t:1527271894817};\\\", \\\"{x:1309,y:881,t:1527271894833};\\\", \\\"{x:1313,y:873,t:1527271894850};\\\", \\\"{x:1321,y:864,t:1527271894867};\\\", \\\"{x:1327,y:854,t:1527271894884};\\\", \\\"{x:1332,y:848,t:1527271894901};\\\", \\\"{x:1335,y:844,t:1527271894918};\\\", \\\"{x:1337,y:841,t:1527271894933};\\\", \\\"{x:1339,y:839,t:1527271894951};\\\", \\\"{x:1339,y:836,t:1527271894968};\\\", \\\"{x:1342,y:831,t:1527271894983};\\\", \\\"{x:1343,y:824,t:1527271895000};\\\", \\\"{x:1346,y:818,t:1527271895017};\\\", \\\"{x:1346,y:816,t:1527271895033};\\\", \\\"{x:1349,y:810,t:1527271895051};\\\", \\\"{x:1350,y:804,t:1527271895067};\\\", \\\"{x:1350,y:801,t:1527271895084};\\\", \\\"{x:1350,y:796,t:1527271895100};\\\", \\\"{x:1350,y:794,t:1527271895118};\\\", \\\"{x:1350,y:790,t:1527271895133};\\\", \\\"{x:1350,y:787,t:1527271895150};\\\", \\\"{x:1349,y:783,t:1527271895168};\\\", \\\"{x:1348,y:779,t:1527271895184};\\\", \\\"{x:1348,y:776,t:1527271895201};\\\", \\\"{x:1348,y:775,t:1527271895217};\\\", \\\"{x:1348,y:774,t:1527271895234};\\\", \\\"{x:1348,y:773,t:1527271895276};\\\", \\\"{x:1348,y:772,t:1527271895284};\\\", \\\"{x:1348,y:771,t:1527271895301};\\\", \\\"{x:1349,y:768,t:1527271895318};\\\", \\\"{x:1349,y:767,t:1527271895334};\\\", \\\"{x:1349,y:766,t:1527271895350};\\\", \\\"{x:1349,y:765,t:1527271895379};\\\", \\\"{x:1349,y:764,t:1527271896780};\\\", \\\"{x:1349,y:763,t:1527271896812};\\\", \\\"{x:1349,y:762,t:1527271896836};\\\", \\\"{x:1349,y:761,t:1527271897075};\\\", \\\"{x:1349,y:760,t:1527271897086};\\\", \\\"{x:1353,y:754,t:1527271897103};\\\", \\\"{x:1356,y:750,t:1527271897119};\\\", \\\"{x:1361,y:742,t:1527271897136};\\\", \\\"{x:1365,y:729,t:1527271897153};\\\", \\\"{x:1369,y:719,t:1527271897169};\\\", \\\"{x:1372,y:711,t:1527271897185};\\\", \\\"{x:1375,y:708,t:1527271897203};\\\", \\\"{x:1377,y:705,t:1527271897219};\\\", \\\"{x:1379,y:700,t:1527271897235};\\\", \\\"{x:1381,y:696,t:1527271897253};\\\", \\\"{x:1383,y:688,t:1527271897268};\\\", \\\"{x:1384,y:686,t:1527271897285};\\\", \\\"{x:1387,y:681,t:1527271897303};\\\", \\\"{x:1391,y:676,t:1527271897318};\\\", \\\"{x:1393,y:673,t:1527271897335};\\\", \\\"{x:1397,y:669,t:1527271897352};\\\", \\\"{x:1402,y:662,t:1527271897369};\\\", \\\"{x:1409,y:652,t:1527271897385};\\\", \\\"{x:1419,y:641,t:1527271897403};\\\", \\\"{x:1427,y:634,t:1527271897419};\\\", \\\"{x:1440,y:617,t:1527271897435};\\\", \\\"{x:1448,y:606,t:1527271897453};\\\", \\\"{x:1453,y:597,t:1527271897469};\\\", \\\"{x:1458,y:587,t:1527271897486};\\\", \\\"{x:1459,y:583,t:1527271897503};\\\", \\\"{x:1461,y:579,t:1527271897520};\\\", \\\"{x:1461,y:576,t:1527271897535};\\\", \\\"{x:1461,y:574,t:1527271897552};\\\", \\\"{x:1462,y:573,t:1527271897569};\\\", \\\"{x:1462,y:572,t:1527271897675};\\\", \\\"{x:1461,y:571,t:1527271897685};\\\", \\\"{x:1459,y:570,t:1527271897703};\\\", \\\"{x:1457,y:569,t:1527271897719};\\\", \\\"{x:1455,y:568,t:1527271897735};\\\", \\\"{x:1450,y:567,t:1527271897752};\\\", \\\"{x:1447,y:566,t:1527271897769};\\\", \\\"{x:1445,y:566,t:1527271897786};\\\", \\\"{x:1444,y:566,t:1527271897811};\\\", \\\"{x:1442,y:566,t:1527271897835};\\\", \\\"{x:1436,y:566,t:1527271897853};\\\", \\\"{x:1433,y:566,t:1527271897870};\\\", \\\"{x:1429,y:566,t:1527271897886};\\\", \\\"{x:1428,y:566,t:1527271897902};\\\", \\\"{x:1427,y:566,t:1527271897919};\\\", \\\"{x:1426,y:566,t:1527271898235};\\\", \\\"{x:1424,y:566,t:1527271898244};\\\", \\\"{x:1423,y:566,t:1527271898259};\\\", \\\"{x:1422,y:566,t:1527271898269};\\\", \\\"{x:1421,y:568,t:1527271904563};\\\", \\\"{x:1421,y:578,t:1527271904575};\\\", \\\"{x:1422,y:597,t:1527271904591};\\\", \\\"{x:1429,y:614,t:1527271904608};\\\", \\\"{x:1434,y:625,t:1527271904625};\\\", \\\"{x:1438,y:631,t:1527271904641};\\\", \\\"{x:1440,y:638,t:1527271904658};\\\", \\\"{x:1441,y:644,t:1527271904675};\\\", \\\"{x:1447,y:655,t:1527271904692};\\\", \\\"{x:1449,y:659,t:1527271904708};\\\", \\\"{x:1450,y:665,t:1527271904725};\\\", \\\"{x:1453,y:669,t:1527271904741};\\\", \\\"{x:1453,y:670,t:1527271904758};\\\", \\\"{x:1453,y:673,t:1527271904795};\\\", \\\"{x:1454,y:674,t:1527271904808};\\\", \\\"{x:1454,y:677,t:1527271904825};\\\", \\\"{x:1456,y:680,t:1527271904842};\\\", \\\"{x:1456,y:688,t:1527271904858};\\\", \\\"{x:1456,y:692,t:1527271904875};\\\", \\\"{x:1456,y:696,t:1527271904892};\\\", \\\"{x:1455,y:700,t:1527271904908};\\\", \\\"{x:1455,y:703,t:1527271904924};\\\", \\\"{x:1452,y:711,t:1527271904942};\\\", \\\"{x:1447,y:720,t:1527271904959};\\\", \\\"{x:1446,y:730,t:1527271904975};\\\", \\\"{x:1446,y:736,t:1527271904991};\\\", \\\"{x:1443,y:752,t:1527271905009};\\\", \\\"{x:1442,y:769,t:1527271905026};\\\", \\\"{x:1442,y:787,t:1527271905042};\\\", \\\"{x:1445,y:798,t:1527271905059};\\\", \\\"{x:1445,y:805,t:1527271905075};\\\", \\\"{x:1453,y:815,t:1527271905092};\\\", \\\"{x:1457,y:820,t:1527271905109};\\\", \\\"{x:1461,y:825,t:1527271905125};\\\", \\\"{x:1461,y:826,t:1527271905142};\\\", \\\"{x:1463,y:828,t:1527271905159};\\\", \\\"{x:1466,y:828,t:1527271905235};\\\", \\\"{x:1471,y:826,t:1527271905244};\\\", \\\"{x:1475,y:825,t:1527271905259};\\\", \\\"{x:1485,y:824,t:1527271905274};\\\", \\\"{x:1499,y:820,t:1527271905292};\\\", \\\"{x:1502,y:817,t:1527271905309};\\\", \\\"{x:1504,y:816,t:1527271905325};\\\", \\\"{x:1505,y:815,t:1527271905342};\\\", \\\"{x:1506,y:814,t:1527271905359};\\\", \\\"{x:1508,y:814,t:1527271905375};\\\", \\\"{x:1509,y:813,t:1527271905391};\\\", \\\"{x:1510,y:812,t:1527271905467};\\\", \\\"{x:1510,y:811,t:1527271905499};\\\", \\\"{x:1510,y:809,t:1527271905515};\\\", \\\"{x:1511,y:807,t:1527271905526};\\\", \\\"{x:1511,y:805,t:1527271905542};\\\", \\\"{x:1512,y:804,t:1527271905559};\\\", \\\"{x:1513,y:800,t:1527271905576};\\\", \\\"{x:1513,y:798,t:1527271905592};\\\", \\\"{x:1514,y:796,t:1527271905608};\\\", \\\"{x:1515,y:794,t:1527271905625};\\\", \\\"{x:1516,y:792,t:1527271905642};\\\", \\\"{x:1519,y:787,t:1527271905659};\\\", \\\"{x:1519,y:786,t:1527271905675};\\\", \\\"{x:1521,y:782,t:1527271905692};\\\", \\\"{x:1522,y:780,t:1527271905709};\\\", \\\"{x:1522,y:778,t:1527271905726};\\\", \\\"{x:1523,y:778,t:1527271905743};\\\", \\\"{x:1525,y:776,t:1527271905787};\\\", \\\"{x:1525,y:774,t:1527271905811};\\\", \\\"{x:1525,y:773,t:1527271905826};\\\", \\\"{x:1524,y:773,t:1527271905884};\\\", \\\"{x:1523,y:773,t:1527271905893};\\\", \\\"{x:1522,y:773,t:1527271905915};\\\", \\\"{x:1521,y:773,t:1527271906019};\\\", \\\"{x:1520,y:773,t:1527271906035};\\\", \\\"{x:1519,y:773,t:1527271906051};\\\", \\\"{x:1518,y:772,t:1527271906316};\\\", \\\"{x:1518,y:770,t:1527271906348};\\\", \\\"{x:1519,y:769,t:1527271906372};\\\", \\\"{x:1519,y:768,t:1527271906979};\\\", \\\"{x:1519,y:767,t:1527271906996};\\\", \\\"{x:1520,y:765,t:1527271907010};\\\", \\\"{x:1520,y:764,t:1527271907052};\\\", \\\"{x:1520,y:762,t:1527271907620};\\\", \\\"{x:1520,y:761,t:1527271907627};\\\", \\\"{x:1520,y:760,t:1527271909805};\\\", \\\"{x:1521,y:760,t:1527271909812};\\\", \\\"{x:1521,y:758,t:1527271909829};\\\", \\\"{x:1522,y:757,t:1527271909860};\\\", \\\"{x:1522,y:755,t:1527271910093};\\\", \\\"{x:1522,y:754,t:1527271910100};\\\", \\\"{x:1522,y:751,t:1527271910112};\\\", \\\"{x:1522,y:750,t:1527271910130};\\\", \\\"{x:1522,y:747,t:1527271910149};\\\", \\\"{x:1522,y:743,t:1527271910163};\\\", \\\"{x:1522,y:733,t:1527271910180};\\\", \\\"{x:1528,y:711,t:1527271910196};\\\", \\\"{x:1528,y:693,t:1527271910214};\\\", \\\"{x:1527,y:672,t:1527271910230};\\\", \\\"{x:1526,y:649,t:1527271910246};\\\", \\\"{x:1520,y:627,t:1527271910263};\\\", \\\"{x:1510,y:600,t:1527271910279};\\\", \\\"{x:1509,y:591,t:1527271910296};\\\", \\\"{x:1509,y:588,t:1527271910313};\\\", \\\"{x:1506,y:583,t:1527271910330};\\\", \\\"{x:1502,y:579,t:1527271910346};\\\", \\\"{x:1497,y:577,t:1527271910364};\\\", \\\"{x:1495,y:577,t:1527271910379};\\\", \\\"{x:1493,y:577,t:1527271910396};\\\", \\\"{x:1492,y:577,t:1527271910413};\\\", \\\"{x:1485,y:577,t:1527271910429};\\\", \\\"{x:1477,y:580,t:1527271910446};\\\", \\\"{x:1472,y:583,t:1527271910463};\\\", \\\"{x:1469,y:584,t:1527271910480};\\\", \\\"{x:1467,y:585,t:1527271910497};\\\", \\\"{x:1466,y:585,t:1527271910573};\\\", \\\"{x:1465,y:585,t:1527271910588};\\\", \\\"{x:1463,y:585,t:1527271910596};\\\", \\\"{x:1460,y:582,t:1527271910614};\\\", \\\"{x:1457,y:581,t:1527271910629};\\\", \\\"{x:1456,y:579,t:1527271910647};\\\", \\\"{x:1455,y:578,t:1527271910773};\\\", \\\"{x:1455,y:577,t:1527271910788};\\\", \\\"{x:1453,y:577,t:1527271910797};\\\", \\\"{x:1451,y:576,t:1527271910814};\\\", \\\"{x:1449,y:574,t:1527271910831};\\\", \\\"{x:1447,y:573,t:1527271910852};\\\", \\\"{x:1447,y:572,t:1527271910867};\\\", \\\"{x:1446,y:572,t:1527271910883};\\\", \\\"{x:1445,y:571,t:1527271910896};\\\", \\\"{x:1444,y:571,t:1527271910913};\\\", \\\"{x:1442,y:571,t:1527271910930};\\\", \\\"{x:1440,y:569,t:1527271910946};\\\", \\\"{x:1437,y:568,t:1527271910963};\\\", \\\"{x:1435,y:568,t:1527271910980};\\\", \\\"{x:1433,y:568,t:1527271910996};\\\", \\\"{x:1430,y:567,t:1527271911013};\\\", \\\"{x:1428,y:566,t:1527271911031};\\\", \\\"{x:1427,y:565,t:1527271911046};\\\", \\\"{x:1426,y:565,t:1527271911076};\\\", \\\"{x:1426,y:564,t:1527271911140};\\\", \\\"{x:1425,y:563,t:1527271911148};\\\", \\\"{x:1425,y:562,t:1527271911164};\\\", \\\"{x:1425,y:561,t:1527271911196};\\\", \\\"{x:1425,y:559,t:1527271911325};\\\", \\\"{x:1423,y:560,t:1527271911573};\\\", \\\"{x:1417,y:564,t:1527271911581};\\\", \\\"{x:1400,y:577,t:1527271911598};\\\", \\\"{x:1370,y:596,t:1527271911615};\\\", \\\"{x:1287,y:618,t:1527271911631};\\\", \\\"{x:1180,y:643,t:1527271911647};\\\", \\\"{x:1150,y:651,t:1527271911664};\\\", \\\"{x:1107,y:654,t:1527271911680};\\\", \\\"{x:1088,y:654,t:1527271911697};\\\", \\\"{x:1050,y:646,t:1527271911714};\\\", \\\"{x:1022,y:640,t:1527271911730};\\\", \\\"{x:992,y:627,t:1527271911747};\\\", \\\"{x:975,y:620,t:1527271911764};\\\", \\\"{x:950,y:604,t:1527271911780};\\\", \\\"{x:930,y:593,t:1527271911798};\\\", \\\"{x:912,y:582,t:1527271911814};\\\", \\\"{x:909,y:576,t:1527271911831};\\\", \\\"{x:907,y:574,t:1527271911848};\\\", \\\"{x:892,y:566,t:1527271911864};\\\", \\\"{x:862,y:560,t:1527271911881};\\\", \\\"{x:837,y:555,t:1527271911898};\\\", \\\"{x:822,y:555,t:1527271911914};\\\", \\\"{x:780,y:551,t:1527271911931};\\\", \\\"{x:761,y:551,t:1527271911948};\\\", \\\"{x:740,y:551,t:1527271911965};\\\", \\\"{x:725,y:551,t:1527271911981};\\\", \\\"{x:719,y:551,t:1527271911999};\\\", \\\"{x:712,y:551,t:1527271912016};\\\", \\\"{x:709,y:551,t:1527271912031};\\\", \\\"{x:708,y:551,t:1527271912048};\\\", \\\"{x:707,y:551,t:1527271912064};\\\", \\\"{x:705,y:551,t:1527271913316};\\\", \\\"{x:693,y:551,t:1527271913332};\\\", \\\"{x:677,y:551,t:1527271913349};\\\", \\\"{x:664,y:551,t:1527271913364};\\\", \\\"{x:646,y:551,t:1527271913382};\\\", \\\"{x:631,y:551,t:1527271913398};\\\", \\\"{x:612,y:553,t:1527271913415};\\\", \\\"{x:585,y:557,t:1527271913433};\\\", \\\"{x:554,y:560,t:1527271913450};\\\", \\\"{x:543,y:565,t:1527271913465};\\\", \\\"{x:532,y:566,t:1527271913482};\\\", \\\"{x:520,y:569,t:1527271913499};\\\", \\\"{x:516,y:570,t:1527271913515};\\\", \\\"{x:512,y:573,t:1527271913533};\\\", \\\"{x:505,y:575,t:1527271913549};\\\", \\\"{x:495,y:584,t:1527271913566};\\\", \\\"{x:487,y:592,t:1527271913582};\\\", \\\"{x:473,y:596,t:1527271913600};\\\", \\\"{x:462,y:597,t:1527271913615};\\\", \\\"{x:456,y:597,t:1527271913632};\\\", \\\"{x:444,y:600,t:1527271913649};\\\", \\\"{x:440,y:603,t:1527271913666};\\\", \\\"{x:433,y:605,t:1527271913682};\\\", \\\"{x:418,y:607,t:1527271913699};\\\", \\\"{x:410,y:607,t:1527271913716};\\\", \\\"{x:397,y:609,t:1527271913732};\\\", \\\"{x:383,y:609,t:1527271913749};\\\", \\\"{x:365,y:609,t:1527271913767};\\\", \\\"{x:343,y:606,t:1527271913782};\\\", \\\"{x:330,y:604,t:1527271913800};\\\", \\\"{x:318,y:604,t:1527271913816};\\\", \\\"{x:305,y:603,t:1527271913832};\\\", \\\"{x:301,y:602,t:1527271913851};\\\", \\\"{x:297,y:602,t:1527271913866};\\\", \\\"{x:289,y:600,t:1527271913883};\\\", \\\"{x:277,y:599,t:1527271913899};\\\", \\\"{x:273,y:599,t:1527271913916};\\\", \\\"{x:266,y:598,t:1527271913932};\\\", \\\"{x:255,y:598,t:1527271913949};\\\", \\\"{x:245,y:596,t:1527271913966};\\\", \\\"{x:243,y:596,t:1527271913982};\\\", \\\"{x:241,y:595,t:1527271914000};\\\", \\\"{x:243,y:592,t:1527271914036};\\\", \\\"{x:252,y:588,t:1527271914049};\\\", \\\"{x:273,y:579,t:1527271914067};\\\", \\\"{x:301,y:568,t:1527271914082};\\\", \\\"{x:432,y:555,t:1527271914100};\\\", \\\"{x:524,y:551,t:1527271914117};\\\", \\\"{x:597,y:549,t:1527271914132};\\\", \\\"{x:678,y:549,t:1527271914150};\\\", \\\"{x:703,y:549,t:1527271914166};\\\", \\\"{x:718,y:547,t:1527271914182};\\\", \\\"{x:727,y:546,t:1527271914200};\\\", \\\"{x:734,y:544,t:1527271914217};\\\", \\\"{x:739,y:542,t:1527271914232};\\\", \\\"{x:742,y:540,t:1527271914250};\\\", \\\"{x:745,y:538,t:1527271914267};\\\", \\\"{x:747,y:537,t:1527271914283};\\\", \\\"{x:751,y:535,t:1527271914299};\\\", \\\"{x:754,y:533,t:1527271914317};\\\", \\\"{x:757,y:532,t:1527271914333};\\\", \\\"{x:758,y:530,t:1527271914350};\\\", \\\"{x:761,y:530,t:1527271914366};\\\", \\\"{x:762,y:528,t:1527271914384};\\\", \\\"{x:765,y:528,t:1527271914401};\\\", \\\"{x:767,y:528,t:1527271914436};\\\", \\\"{x:769,y:528,t:1527271914450};\\\", \\\"{x:775,y:529,t:1527271914467};\\\", \\\"{x:779,y:530,t:1527271914483};\\\", \\\"{x:780,y:531,t:1527271914500};\\\", \\\"{x:782,y:531,t:1527271914517};\\\", \\\"{x:784,y:532,t:1527271914533};\\\", \\\"{x:792,y:535,t:1527271914550};\\\", \\\"{x:801,y:536,t:1527271914567};\\\", \\\"{x:811,y:536,t:1527271914584};\\\", \\\"{x:817,y:536,t:1527271914600};\\\", \\\"{x:819,y:536,t:1527271914617};\\\", \\\"{x:820,y:536,t:1527271914692};\\\", \\\"{x:818,y:536,t:1527271915021};\\\", \\\"{x:815,y:537,t:1527271915035};\\\", \\\"{x:805,y:551,t:1527271915052};\\\", \\\"{x:797,y:562,t:1527271915069};\\\", \\\"{x:792,y:569,t:1527271915086};\\\", \\\"{x:798,y:569,t:1527271915204};\\\", \\\"{x:807,y:566,t:1527271915217};\\\", \\\"{x:826,y:560,t:1527271915233};\\\", \\\"{x:835,y:555,t:1527271915250};\\\", \\\"{x:838,y:554,t:1527271915267};\\\", \\\"{x:838,y:551,t:1527271915358};\\\", \\\"{x:839,y:545,t:1527271915367};\\\", \\\"{x:842,y:535,t:1527271915385};\\\", \\\"{x:843,y:533,t:1527271915400};\\\", \\\"{x:842,y:535,t:1527271915747};\\\", \\\"{x:839,y:540,t:1527271915756};\\\", \\\"{x:832,y:546,t:1527271915767};\\\", \\\"{x:819,y:558,t:1527271915785};\\\", \\\"{x:806,y:568,t:1527271915801};\\\", \\\"{x:793,y:579,t:1527271915818};\\\", \\\"{x:775,y:592,t:1527271915834};\\\", \\\"{x:740,y:621,t:1527271915852};\\\", \\\"{x:710,y:646,t:1527271915868};\\\", \\\"{x:685,y:662,t:1527271915885};\\\", \\\"{x:673,y:673,t:1527271915900};\\\", \\\"{x:663,y:677,t:1527271915918};\\\", \\\"{x:661,y:679,t:1527271915935};\\\", \\\"{x:658,y:681,t:1527271915951};\\\", \\\"{x:649,y:686,t:1527271915968};\\\", \\\"{x:633,y:697,t:1527271915984};\\\", \\\"{x:618,y:709,t:1527271916001};\\\", \\\"{x:609,y:717,t:1527271916017};\\\", \\\"{x:603,y:723,t:1527271916034};\\\", \\\"{x:601,y:724,t:1527271916051};\\\", \\\"{x:601,y:725,t:1527271916108};\\\", \\\"{x:601,y:726,t:1527271916124};\\\", \\\"{x:600,y:726,t:1527271916135};\\\", \\\"{x:599,y:727,t:1527271916152};\\\", \\\"{x:597,y:728,t:1527271916168};\\\", \\\"{x:595,y:729,t:1527271916185};\\\", \\\"{x:594,y:729,t:1527271916201};\\\", \\\"{x:588,y:730,t:1527271916217};\\\", \\\"{x:583,y:730,t:1527271916235};\\\", \\\"{x:580,y:730,t:1527271916252};\\\", \\\"{x:579,y:730,t:1527271916268};\\\", \\\"{x:575,y:733,t:1527271916284};\\\", \\\"{x:573,y:734,t:1527271916302};\\\", \\\"{x:570,y:734,t:1527271916332};\\\", \\\"{x:569,y:734,t:1527271916460};\\\", \\\"{x:567,y:734,t:1527271916468};\\\", \\\"{x:563,y:734,t:1527271916486};\\\", \\\"{x:557,y:734,t:1527271916501};\\\", \\\"{x:553,y:734,t:1527271916517};\\\", \\\"{x:551,y:734,t:1527271916532};\\\", \\\"{x:546,y:734,t:1527271916549};\\\", \\\"{x:541,y:737,t:1527271916566};\\\", \\\"{x:539,y:737,t:1527271916582};\\\", \\\"{x:539,y:738,t:1527271916643};\\\", \\\"{x:539,y:738,t:1527271916745};\\\" ] }, { \\\"rt\\\": 14088, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 612028, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -J -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:736,t:1527271918725};\\\", \\\"{x:540,y:732,t:1527271918737};\\\", \\\"{x:546,y:725,t:1527271918758};\\\", \\\"{x:548,y:721,t:1527271918770};\\\", \\\"{x:552,y:716,t:1527271918787};\\\", \\\"{x:557,y:708,t:1527271918803};\\\", \\\"{x:560,y:703,t:1527271918820};\\\", \\\"{x:571,y:696,t:1527271918837};\\\", \\\"{x:583,y:690,t:1527271918853};\\\", \\\"{x:595,y:687,t:1527271918871};\\\", \\\"{x:610,y:676,t:1527271918887};\\\", \\\"{x:637,y:666,t:1527271918904};\\\", \\\"{x:662,y:660,t:1527271918920};\\\", \\\"{x:686,y:655,t:1527271918936};\\\", \\\"{x:709,y:650,t:1527271918953};\\\", \\\"{x:737,y:647,t:1527271918970};\\\", \\\"{x:762,y:645,t:1527271918986};\\\", \\\"{x:804,y:645,t:1527271919003};\\\", \\\"{x:828,y:645,t:1527271919020};\\\", \\\"{x:847,y:642,t:1527271919037};\\\", \\\"{x:864,y:636,t:1527271919054};\\\", \\\"{x:875,y:630,t:1527271919071};\\\", \\\"{x:885,y:624,t:1527271919087};\\\", \\\"{x:887,y:622,t:1527271919103};\\\", \\\"{x:888,y:621,t:1527271919120};\\\", \\\"{x:893,y:618,t:1527271919136};\\\", \\\"{x:895,y:617,t:1527271919154};\\\", \\\"{x:899,y:615,t:1527271919171};\\\", \\\"{x:905,y:613,t:1527271919187};\\\", \\\"{x:921,y:609,t:1527271919203};\\\", \\\"{x:935,y:604,t:1527271919221};\\\", \\\"{x:951,y:601,t:1527271919237};\\\", \\\"{x:980,y:591,t:1527271919254};\\\", \\\"{x:1025,y:587,t:1527271919270};\\\", \\\"{x:1097,y:576,t:1527271919287};\\\", \\\"{x:1189,y:567,t:1527271919304};\\\", \\\"{x:1236,y:567,t:1527271919320};\\\", \\\"{x:1320,y:567,t:1527271919337};\\\", \\\"{x:1372,y:567,t:1527271919353};\\\", \\\"{x:1396,y:567,t:1527271919370};\\\", \\\"{x:1415,y:567,t:1527271919388};\\\", \\\"{x:1424,y:567,t:1527271919404};\\\", \\\"{x:1431,y:567,t:1527271919421};\\\", \\\"{x:1442,y:570,t:1527271919437};\\\", \\\"{x:1447,y:572,t:1527271919453};\\\", \\\"{x:1461,y:579,t:1527271919470};\\\", \\\"{x:1474,y:587,t:1527271919488};\\\", \\\"{x:1476,y:587,t:1527271919504};\\\", \\\"{x:1478,y:591,t:1527271919520};\\\", \\\"{x:1480,y:597,t:1527271919538};\\\", \\\"{x:1481,y:597,t:1527271919564};\\\", \\\"{x:1481,y:598,t:1527271919571};\\\", \\\"{x:1482,y:594,t:1527271920282};\\\", \\\"{x:1486,y:582,t:1527271920289};\\\", \\\"{x:1491,y:577,t:1527271920303};\\\", \\\"{x:1494,y:575,t:1527271920320};\\\", \\\"{x:1495,y:574,t:1527271920370};\\\", \\\"{x:1499,y:572,t:1527271920386};\\\", \\\"{x:1501,y:570,t:1527271920403};\\\", \\\"{x:1503,y:569,t:1527271920419};\\\", \\\"{x:1504,y:569,t:1527271920436};\\\", \\\"{x:1507,y:567,t:1527271920456};\\\", \\\"{x:1508,y:567,t:1527271920481};\\\", \\\"{x:1510,y:566,t:1527271920513};\\\", \\\"{x:1511,y:566,t:1527271920520};\\\", \\\"{x:1512,y:565,t:1527271920536};\\\", \\\"{x:1512,y:562,t:1527271920552};\\\", \\\"{x:1513,y:561,t:1527271920570};\\\", \\\"{x:1513,y:560,t:1527271920586};\\\", \\\"{x:1513,y:559,t:1527271920954};\\\", \\\"{x:1516,y:560,t:1527271920969};\\\", \\\"{x:1518,y:562,t:1527271920986};\\\", \\\"{x:1518,y:564,t:1527271921194};\\\", \\\"{x:1518,y:565,t:1527271921234};\\\", \\\"{x:1518,y:570,t:1527271921827};\\\", \\\"{x:1517,y:575,t:1527271921837};\\\", \\\"{x:1511,y:595,t:1527271921853};\\\", \\\"{x:1505,y:608,t:1527271921870};\\\", \\\"{x:1496,y:627,t:1527271921886};\\\", \\\"{x:1489,y:637,t:1527271921903};\\\", \\\"{x:1481,y:645,t:1527271921920};\\\", \\\"{x:1471,y:652,t:1527271921936};\\\", \\\"{x:1461,y:662,t:1527271921953};\\\", \\\"{x:1457,y:669,t:1527271921971};\\\", \\\"{x:1447,y:682,t:1527271921987};\\\", \\\"{x:1444,y:694,t:1527271922003};\\\", \\\"{x:1444,y:701,t:1527271922020};\\\", \\\"{x:1443,y:704,t:1527271922036};\\\", \\\"{x:1443,y:709,t:1527271922053};\\\", \\\"{x:1443,y:716,t:1527271922070};\\\", \\\"{x:1443,y:727,t:1527271922086};\\\", \\\"{x:1443,y:729,t:1527271922104};\\\", \\\"{x:1443,y:731,t:1527271922121};\\\", \\\"{x:1453,y:751,t:1527271922137};\\\", \\\"{x:1466,y:767,t:1527271922154};\\\", \\\"{x:1479,y:778,t:1527271922171};\\\", \\\"{x:1495,y:786,t:1527271922188};\\\", \\\"{x:1502,y:790,t:1527271922204};\\\", \\\"{x:1509,y:794,t:1527271922220};\\\", \\\"{x:1513,y:795,t:1527271922237};\\\", \\\"{x:1516,y:795,t:1527271922253};\\\", \\\"{x:1516,y:796,t:1527271922270};\\\", \\\"{x:1518,y:796,t:1527271922337};\\\", \\\"{x:1520,y:796,t:1527271922353};\\\", \\\"{x:1523,y:796,t:1527271922371};\\\", \\\"{x:1524,y:796,t:1527271922387};\\\", \\\"{x:1529,y:796,t:1527271922403};\\\", \\\"{x:1532,y:798,t:1527271922420};\\\", \\\"{x:1543,y:801,t:1527271922437};\\\", \\\"{x:1554,y:807,t:1527271922454};\\\", \\\"{x:1573,y:813,t:1527271922470};\\\", \\\"{x:1588,y:820,t:1527271922487};\\\", \\\"{x:1601,y:826,t:1527271922504};\\\", \\\"{x:1618,y:830,t:1527271922521};\\\", \\\"{x:1637,y:835,t:1527271922538};\\\", \\\"{x:1638,y:836,t:1527271922553};\\\", \\\"{x:1642,y:837,t:1527271922570};\\\", \\\"{x:1641,y:837,t:1527271922658};\\\", \\\"{x:1632,y:836,t:1527271922671};\\\", \\\"{x:1606,y:831,t:1527271922687};\\\", \\\"{x:1577,y:826,t:1527271922705};\\\", \\\"{x:1542,y:821,t:1527271922721};\\\", \\\"{x:1507,y:815,t:1527271922737};\\\", \\\"{x:1486,y:814,t:1527271922755};\\\", \\\"{x:1466,y:813,t:1527271922771};\\\", \\\"{x:1458,y:812,t:1527271922787};\\\", \\\"{x:1452,y:812,t:1527271922804};\\\", \\\"{x:1447,y:812,t:1527271922820};\\\", \\\"{x:1441,y:812,t:1527271922837};\\\", \\\"{x:1438,y:812,t:1527271922855};\\\", \\\"{x:1430,y:812,t:1527271922870};\\\", \\\"{x:1420,y:815,t:1527271922887};\\\", \\\"{x:1408,y:819,t:1527271922904};\\\", \\\"{x:1391,y:825,t:1527271922921};\\\", \\\"{x:1365,y:834,t:1527271922938};\\\", \\\"{x:1336,y:841,t:1527271922954};\\\", \\\"{x:1316,y:849,t:1527271922970};\\\", \\\"{x:1298,y:854,t:1527271922987};\\\", \\\"{x:1283,y:857,t:1527271923004};\\\", \\\"{x:1273,y:859,t:1527271923020};\\\", \\\"{x:1268,y:862,t:1527271923037};\\\", \\\"{x:1264,y:862,t:1527271923054};\\\", \\\"{x:1261,y:863,t:1527271923070};\\\", \\\"{x:1259,y:863,t:1527271923088};\\\", \\\"{x:1252,y:863,t:1527271923105};\\\", \\\"{x:1246,y:863,t:1527271923121};\\\", \\\"{x:1237,y:858,t:1527271923138};\\\", \\\"{x:1229,y:853,t:1527271923154};\\\", \\\"{x:1224,y:850,t:1527271923171};\\\", \\\"{x:1220,y:847,t:1527271923188};\\\", \\\"{x:1218,y:844,t:1527271923204};\\\", \\\"{x:1214,y:836,t:1527271923221};\\\", \\\"{x:1208,y:829,t:1527271923238};\\\", \\\"{x:1203,y:823,t:1527271923254};\\\", \\\"{x:1195,y:820,t:1527271923271};\\\", \\\"{x:1191,y:817,t:1527271923287};\\\", \\\"{x:1190,y:817,t:1527271923305};\\\", \\\"{x:1187,y:814,t:1527271923320};\\\", \\\"{x:1183,y:811,t:1527271923337};\\\", \\\"{x:1181,y:810,t:1527271923355};\\\", \\\"{x:1178,y:808,t:1527271923372};\\\", \\\"{x:1177,y:806,t:1527271923388};\\\", \\\"{x:1174,y:802,t:1527271923404};\\\", \\\"{x:1172,y:800,t:1527271923421};\\\", \\\"{x:1175,y:800,t:1527271923577};\\\", \\\"{x:1180,y:800,t:1527271923588};\\\", \\\"{x:1185,y:802,t:1527271923604};\\\", \\\"{x:1189,y:803,t:1527271923622};\\\", \\\"{x:1196,y:807,t:1527271923639};\\\", \\\"{x:1199,y:810,t:1527271923655};\\\", \\\"{x:1201,y:810,t:1527271923671};\\\", \\\"{x:1205,y:815,t:1527271923689};\\\", \\\"{x:1207,y:818,t:1527271923705};\\\", \\\"{x:1213,y:827,t:1527271923722};\\\", \\\"{x:1218,y:833,t:1527271923739};\\\", \\\"{x:1221,y:836,t:1527271923756};\\\", \\\"{x:1221,y:837,t:1527271923771};\\\", \\\"{x:1222,y:837,t:1527271923889};\\\", \\\"{x:1222,y:833,t:1527271923905};\\\", \\\"{x:1220,y:828,t:1527271923922};\\\", \\\"{x:1217,y:824,t:1527271923939};\\\", \\\"{x:1216,y:822,t:1527271923962};\\\", \\\"{x:1215,y:820,t:1527271923977};\\\", \\\"{x:1214,y:820,t:1527271923988};\\\", \\\"{x:1212,y:817,t:1527271924005};\\\", \\\"{x:1211,y:816,t:1527271924021};\\\", \\\"{x:1209,y:812,t:1527271924039};\\\", \\\"{x:1206,y:811,t:1527271924056};\\\", \\\"{x:1204,y:809,t:1527271924072};\\\", \\\"{x:1204,y:808,t:1527271924088};\\\", \\\"{x:1203,y:808,t:1527271924106};\\\", \\\"{x:1202,y:806,t:1527271924122};\\\", \\\"{x:1199,y:803,t:1527271924139};\\\", \\\"{x:1195,y:798,t:1527271924156};\\\", \\\"{x:1192,y:795,t:1527271924172};\\\", \\\"{x:1189,y:790,t:1527271924189};\\\", \\\"{x:1188,y:788,t:1527271924206};\\\", \\\"{x:1188,y:787,t:1527271924330};\\\", \\\"{x:1188,y:784,t:1527271924345};\\\", \\\"{x:1188,y:781,t:1527271924356};\\\", \\\"{x:1190,y:772,t:1527271924371};\\\", \\\"{x:1197,y:759,t:1527271924388};\\\", \\\"{x:1212,y:742,t:1527271924405};\\\", \\\"{x:1228,y:715,t:1527271924421};\\\", \\\"{x:1241,y:700,t:1527271924438};\\\", \\\"{x:1249,y:689,t:1527271924456};\\\", \\\"{x:1259,y:680,t:1527271924472};\\\", \\\"{x:1266,y:669,t:1527271924489};\\\", \\\"{x:1276,y:652,t:1527271924504};\\\", \\\"{x:1280,y:645,t:1527271924522};\\\", \\\"{x:1285,y:639,t:1527271924539};\\\", \\\"{x:1287,y:637,t:1527271924555};\\\", \\\"{x:1288,y:637,t:1527271924572};\\\", \\\"{x:1289,y:637,t:1527271924589};\\\", \\\"{x:1290,y:636,t:1527271924606};\\\", \\\"{x:1291,y:636,t:1527271924622};\\\", \\\"{x:1294,y:633,t:1527271924639};\\\", \\\"{x:1294,y:632,t:1527271924655};\\\", \\\"{x:1296,y:628,t:1527271924672};\\\", \\\"{x:1297,y:623,t:1527271924689};\\\", \\\"{x:1299,y:619,t:1527271924705};\\\", \\\"{x:1301,y:617,t:1527271924723};\\\", \\\"{x:1302,y:610,t:1527271924738};\\\", \\\"{x:1302,y:608,t:1527271924756};\\\", \\\"{x:1301,y:608,t:1527271924905};\\\", \\\"{x:1300,y:609,t:1527271924923};\\\", \\\"{x:1299,y:610,t:1527271924938};\\\", \\\"{x:1299,y:607,t:1527271925017};\\\", \\\"{x:1303,y:603,t:1527271925025};\\\", \\\"{x:1303,y:602,t:1527271925040};\\\", \\\"{x:1303,y:594,t:1527271925056};\\\", \\\"{x:1303,y:588,t:1527271925073};\\\", \\\"{x:1303,y:587,t:1527271925090};\\\", \\\"{x:1303,y:586,t:1527271925282};\\\", \\\"{x:1304,y:584,t:1527271925290};\\\", \\\"{x:1305,y:582,t:1527271925306};\\\", \\\"{x:1305,y:580,t:1527271925323};\\\", \\\"{x:1305,y:578,t:1527271925340};\\\", \\\"{x:1305,y:577,t:1527271925490};\\\", \\\"{x:1305,y:576,t:1527271925538};\\\", \\\"{x:1305,y:575,t:1527271925554};\\\", \\\"{x:1304,y:575,t:1527271925584};\\\", \\\"{x:1303,y:575,t:1527271925601};\\\", \\\"{x:1303,y:574,t:1527271925616};\\\", \\\"{x:1302,y:574,t:1527271926850};\\\", \\\"{x:1300,y:574,t:1527271927002};\\\", \\\"{x:1299,y:574,t:1527271927025};\\\", \\\"{x:1297,y:573,t:1527271927042};\\\", \\\"{x:1296,y:573,t:1527271927208};\\\", \\\"{x:1294,y:573,t:1527271927970};\\\", \\\"{x:1294,y:574,t:1527271928042};\\\", \\\"{x:1294,y:575,t:1527271929330};\\\", \\\"{x:1293,y:579,t:1527271929342};\\\", \\\"{x:1293,y:584,t:1527271929359};\\\", \\\"{x:1293,y:595,t:1527271929376};\\\", \\\"{x:1292,y:615,t:1527271929394};\\\", \\\"{x:1292,y:630,t:1527271929409};\\\", \\\"{x:1292,y:641,t:1527271929426};\\\", \\\"{x:1291,y:654,t:1527271929443};\\\", \\\"{x:1289,y:664,t:1527271929459};\\\", \\\"{x:1289,y:667,t:1527271929476};\\\", \\\"{x:1289,y:671,t:1527271929493};\\\", \\\"{x:1289,y:673,t:1527271929510};\\\", \\\"{x:1293,y:677,t:1527271929526};\\\", \\\"{x:1294,y:681,t:1527271929543};\\\", \\\"{x:1296,y:685,t:1527271929560};\\\", \\\"{x:1297,y:691,t:1527271929576};\\\", \\\"{x:1300,y:698,t:1527271929593};\\\", \\\"{x:1300,y:700,t:1527271929609};\\\", \\\"{x:1300,y:701,t:1527271929627};\\\", \\\"{x:1300,y:702,t:1527271929658};\\\", \\\"{x:1300,y:703,t:1527271929665};\\\", \\\"{x:1301,y:703,t:1527271929676};\\\", \\\"{x:1301,y:704,t:1527271929694};\\\", \\\"{x:1301,y:708,t:1527271929709};\\\", \\\"{x:1301,y:714,t:1527271929726};\\\", \\\"{x:1301,y:720,t:1527271929743};\\\", \\\"{x:1301,y:725,t:1527271929760};\\\", \\\"{x:1301,y:727,t:1527271929776};\\\", \\\"{x:1301,y:730,t:1527271929792};\\\", \\\"{x:1299,y:730,t:1527271929881};\\\", \\\"{x:1299,y:728,t:1527271929893};\\\", \\\"{x:1295,y:722,t:1527271929910};\\\", \\\"{x:1291,y:717,t:1527271929926};\\\", \\\"{x:1289,y:714,t:1527271929943};\\\", \\\"{x:1288,y:713,t:1527271929959};\\\", \\\"{x:1286,y:713,t:1527271929993};\\\", \\\"{x:1280,y:715,t:1527271930017};\\\", \\\"{x:1272,y:718,t:1527271930026};\\\", \\\"{x:1258,y:727,t:1527271930043};\\\", \\\"{x:1235,y:738,t:1527271930060};\\\", \\\"{x:1218,y:747,t:1527271930076};\\\", \\\"{x:1203,y:757,t:1527271930093};\\\", \\\"{x:1189,y:763,t:1527271930110};\\\", \\\"{x:1175,y:768,t:1527271930126};\\\", \\\"{x:1158,y:770,t:1527271930143};\\\", \\\"{x:1135,y:773,t:1527271930160};\\\", \\\"{x:1102,y:773,t:1527271930176};\\\", \\\"{x:1055,y:757,t:1527271930193};\\\", \\\"{x:980,y:733,t:1527271930210};\\\", \\\"{x:929,y:717,t:1527271930226};\\\", \\\"{x:903,y:708,t:1527271930243};\\\", \\\"{x:876,y:692,t:1527271930260};\\\", \\\"{x:846,y:680,t:1527271930276};\\\", \\\"{x:801,y:665,t:1527271930293};\\\", \\\"{x:763,y:643,t:1527271930310};\\\", \\\"{x:729,y:628,t:1527271930327};\\\", \\\"{x:713,y:619,t:1527271930343};\\\", \\\"{x:706,y:613,t:1527271930360};\\\", \\\"{x:689,y:601,t:1527271930377};\\\", \\\"{x:679,y:596,t:1527271930393};\\\", \\\"{x:672,y:595,t:1527271930411};\\\", \\\"{x:666,y:592,t:1527271930428};\\\", \\\"{x:645,y:583,t:1527271930443};\\\", \\\"{x:628,y:578,t:1527271930461};\\\", \\\"{x:612,y:574,t:1527271930478};\\\", \\\"{x:597,y:573,t:1527271930494};\\\", \\\"{x:580,y:569,t:1527271930510};\\\", \\\"{x:570,y:568,t:1527271930527};\\\", \\\"{x:551,y:565,t:1527271930544};\\\", \\\"{x:531,y:565,t:1527271930561};\\\", \\\"{x:514,y:566,t:1527271930576};\\\", \\\"{x:495,y:566,t:1527271930594};\\\", \\\"{x:480,y:566,t:1527271930610};\\\", \\\"{x:466,y:566,t:1527271930626};\\\", \\\"{x:450,y:566,t:1527271930643};\\\", \\\"{x:445,y:566,t:1527271930660};\\\", \\\"{x:437,y:566,t:1527271930676};\\\", \\\"{x:430,y:566,t:1527271930693};\\\", \\\"{x:424,y:561,t:1527271930711};\\\", \\\"{x:410,y:555,t:1527271930728};\\\", \\\"{x:398,y:548,t:1527271930744};\\\", \\\"{x:381,y:536,t:1527271930760};\\\", \\\"{x:377,y:531,t:1527271930777};\\\", \\\"{x:371,y:528,t:1527271930794};\\\", \\\"{x:357,y:523,t:1527271930811};\\\", \\\"{x:336,y:521,t:1527271930828};\\\", \\\"{x:319,y:521,t:1527271930843};\\\", \\\"{x:308,y:521,t:1527271930861};\\\", \\\"{x:295,y:521,t:1527271930877};\\\", \\\"{x:286,y:521,t:1527271930894};\\\", \\\"{x:277,y:522,t:1527271930911};\\\", \\\"{x:270,y:525,t:1527271930928};\\\", \\\"{x:256,y:530,t:1527271930943};\\\", \\\"{x:245,y:536,t:1527271930960};\\\", \\\"{x:238,y:536,t:1527271930978};\\\", \\\"{x:231,y:536,t:1527271930994};\\\", \\\"{x:225,y:536,t:1527271931010};\\\", \\\"{x:217,y:532,t:1527271931028};\\\", \\\"{x:208,y:526,t:1527271931045};\\\", \\\"{x:195,y:517,t:1527271931061};\\\", \\\"{x:186,y:510,t:1527271931078};\\\", \\\"{x:182,y:506,t:1527271931095};\\\", \\\"{x:174,y:502,t:1527271931110};\\\", \\\"{x:165,y:499,t:1527271931128};\\\", \\\"{x:159,y:499,t:1527271931145};\\\", \\\"{x:157,y:499,t:1527271931161};\\\", \\\"{x:155,y:498,t:1527271931177};\\\", \\\"{x:164,y:498,t:1527271931457};\\\", \\\"{x:174,y:499,t:1527271931465};\\\", \\\"{x:194,y:509,t:1527271931478};\\\", \\\"{x:285,y:530,t:1527271931495};\\\", \\\"{x:373,y:565,t:1527271931512};\\\", \\\"{x:469,y:607,t:1527271931529};\\\", \\\"{x:545,y:659,t:1527271931545};\\\", \\\"{x:559,y:678,t:1527271931562};\\\", \\\"{x:564,y:687,t:1527271931577};\\\", \\\"{x:566,y:695,t:1527271931594};\\\", \\\"{x:566,y:700,t:1527271931611};\\\", \\\"{x:567,y:706,t:1527271931628};\\\", \\\"{x:567,y:709,t:1527271931645};\\\", \\\"{x:566,y:715,t:1527271931661};\\\", \\\"{x:565,y:728,t:1527271931678};\\\", \\\"{x:564,y:739,t:1527271931695};\\\", \\\"{x:564,y:740,t:1527271931710};\\\", \\\"{x:563,y:741,t:1527271931736};\\\", \\\"{x:561,y:742,t:1527271931753};\\\", \\\"{x:560,y:743,t:1527271931761};\\\", \\\"{x:551,y:743,t:1527271931779};\\\", \\\"{x:541,y:744,t:1527271931794};\\\", \\\"{x:529,y:744,t:1527271931811};\\\", \\\"{x:519,y:744,t:1527271931828};\\\", \\\"{x:512,y:741,t:1527271931846};\\\", \\\"{x:507,y:740,t:1527271931862};\\\", \\\"{x:506,y:740,t:1527271931984};\\\", \\\"{x:506,y:740,t:1527271932057};\\\", \\\"{x:507,y:739,t:1527271932706};\\\", \\\"{x:510,y:738,t:1527271932713};\\\", \\\"{x:512,y:736,t:1527271932729};\\\", \\\"{x:518,y:734,t:1527271932745};\\\", \\\"{x:521,y:734,t:1527271932763};\\\", \\\"{x:522,y:733,t:1527271933128};\\\", \\\"{x:525,y:733,t:1527271933136};\\\", \\\"{x:526,y:733,t:1527271933145};\\\", \\\"{x:532,y:730,t:1527271933162};\\\", \\\"{x:534,y:729,t:1527271933178};\\\" ] }, { \\\"rt\\\": 6983, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 620266, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:712,t:1527271933286};\\\", \\\"{x:550,y:709,t:1527271933296};\\\", \\\"{x:554,y:705,t:1527271933313};\\\", \\\"{x:564,y:700,t:1527271933330};\\\", \\\"{x:573,y:696,t:1527271933346};\\\", \\\"{x:586,y:690,t:1527271933375};\\\", \\\"{x:587,y:689,t:1527271933379};\\\", \\\"{x:591,y:687,t:1527271933396};\\\", \\\"{x:602,y:686,t:1527271933413};\\\", \\\"{x:620,y:686,t:1527271933430};\\\", \\\"{x:641,y:691,t:1527271933446};\\\", \\\"{x:662,y:696,t:1527271933462};\\\", \\\"{x:677,y:697,t:1527271933479};\\\", \\\"{x:678,y:697,t:1527271933496};\\\", \\\"{x:679,y:697,t:1527271933512};\\\", \\\"{x:689,y:697,t:1527271934330};\\\", \\\"{x:717,y:698,t:1527271934347};\\\", \\\"{x:750,y:703,t:1527271934364};\\\", \\\"{x:779,y:709,t:1527271934380};\\\", \\\"{x:805,y:712,t:1527271934397};\\\", \\\"{x:825,y:714,t:1527271934414};\\\", \\\"{x:843,y:720,t:1527271934430};\\\", \\\"{x:859,y:723,t:1527271934447};\\\", \\\"{x:873,y:729,t:1527271934464};\\\", \\\"{x:887,y:735,t:1527271934481};\\\", \\\"{x:911,y:741,t:1527271934497};\\\", \\\"{x:944,y:753,t:1527271934514};\\\", \\\"{x:972,y:765,t:1527271934531};\\\", \\\"{x:1013,y:778,t:1527271934547};\\\", \\\"{x:1026,y:785,t:1527271934565};\\\", \\\"{x:1049,y:794,t:1527271934581};\\\", \\\"{x:1061,y:803,t:1527271934598};\\\", \\\"{x:1077,y:809,t:1527271934614};\\\", \\\"{x:1089,y:814,t:1527271934631};\\\", \\\"{x:1096,y:816,t:1527271934648};\\\", \\\"{x:1103,y:819,t:1527271934664};\\\", \\\"{x:1118,y:824,t:1527271934682};\\\", \\\"{x:1130,y:827,t:1527271934698};\\\", \\\"{x:1139,y:828,t:1527271934714};\\\", \\\"{x:1154,y:828,t:1527271934731};\\\", \\\"{x:1176,y:828,t:1527271934747};\\\", \\\"{x:1191,y:828,t:1527271934764};\\\", \\\"{x:1215,y:826,t:1527271934784};\\\", \\\"{x:1229,y:823,t:1527271934797};\\\", \\\"{x:1246,y:812,t:1527271934813};\\\", \\\"{x:1269,y:801,t:1527271934831};\\\", \\\"{x:1291,y:786,t:1527271934847};\\\", \\\"{x:1318,y:767,t:1527271934864};\\\", \\\"{x:1355,y:738,t:1527271934880};\\\", \\\"{x:1379,y:718,t:1527271934898};\\\", \\\"{x:1396,y:691,t:1527271934913};\\\", \\\"{x:1408,y:675,t:1527271934931};\\\", \\\"{x:1424,y:663,t:1527271934948};\\\", \\\"{x:1431,y:658,t:1527271934964};\\\", \\\"{x:1440,y:653,t:1527271934981};\\\", \\\"{x:1447,y:644,t:1527271934998};\\\", \\\"{x:1451,y:640,t:1527271935013};\\\", \\\"{x:1451,y:639,t:1527271935031};\\\", \\\"{x:1453,y:634,t:1527271935048};\\\", \\\"{x:1454,y:630,t:1527271935064};\\\", \\\"{x:1461,y:622,t:1527271935081};\\\", \\\"{x:1463,y:620,t:1527271935097};\\\", \\\"{x:1464,y:620,t:1527271935114};\\\", \\\"{x:1465,y:619,t:1527271935131};\\\", \\\"{x:1466,y:618,t:1527271935153};\\\", \\\"{x:1466,y:616,t:1527271935177};\\\", \\\"{x:1467,y:615,t:1527271935200};\\\", \\\"{x:1467,y:614,t:1527271935216};\\\", \\\"{x:1466,y:614,t:1527271935273};\\\", \\\"{x:1457,y:617,t:1527271935281};\\\", \\\"{x:1445,y:626,t:1527271935299};\\\", \\\"{x:1426,y:638,t:1527271935316};\\\", \\\"{x:1404,y:665,t:1527271935331};\\\", \\\"{x:1382,y:692,t:1527271935348};\\\", \\\"{x:1368,y:716,t:1527271935365};\\\", \\\"{x:1362,y:729,t:1527271935381};\\\", \\\"{x:1362,y:733,t:1527271935398};\\\", \\\"{x:1362,y:738,t:1527271935414};\\\", \\\"{x:1362,y:742,t:1527271935431};\\\", \\\"{x:1362,y:749,t:1527271935448};\\\", \\\"{x:1366,y:760,t:1527271935464};\\\", \\\"{x:1373,y:771,t:1527271935481};\\\", \\\"{x:1380,y:779,t:1527271935498};\\\", \\\"{x:1383,y:785,t:1527271935516};\\\", \\\"{x:1392,y:788,t:1527271935531};\\\", \\\"{x:1395,y:790,t:1527271935548};\\\", \\\"{x:1399,y:792,t:1527271935566};\\\", \\\"{x:1400,y:792,t:1527271935618};\\\", \\\"{x:1400,y:791,t:1527271935632};\\\", \\\"{x:1393,y:776,t:1527271935649};\\\", \\\"{x:1384,y:764,t:1527271935666};\\\", \\\"{x:1381,y:760,t:1527271935682};\\\", \\\"{x:1379,y:758,t:1527271935698};\\\", \\\"{x:1378,y:755,t:1527271935716};\\\", \\\"{x:1375,y:752,t:1527271935733};\\\", \\\"{x:1374,y:749,t:1527271935748};\\\", \\\"{x:1373,y:749,t:1527271935766};\\\", \\\"{x:1373,y:748,t:1527271935782};\\\", \\\"{x:1373,y:746,t:1527271935799};\\\", \\\"{x:1373,y:744,t:1527271935816};\\\", \\\"{x:1371,y:742,t:1527271935832};\\\", \\\"{x:1370,y:740,t:1527271935848};\\\", \\\"{x:1369,y:737,t:1527271935865};\\\", \\\"{x:1366,y:733,t:1527271935882};\\\", \\\"{x:1363,y:728,t:1527271935898};\\\", \\\"{x:1361,y:724,t:1527271935915};\\\", \\\"{x:1357,y:717,t:1527271935932};\\\", \\\"{x:1356,y:712,t:1527271935947};\\\", \\\"{x:1354,y:710,t:1527271935964};\\\", \\\"{x:1353,y:709,t:1527271935985};\\\", \\\"{x:1353,y:708,t:1527271936033};\\\", \\\"{x:1353,y:709,t:1527271936121};\\\", \\\"{x:1353,y:713,t:1527271936132};\\\", \\\"{x:1353,y:717,t:1527271936148};\\\", \\\"{x:1353,y:724,t:1527271936165};\\\", \\\"{x:1358,y:732,t:1527271936182};\\\", \\\"{x:1361,y:735,t:1527271936199};\\\", \\\"{x:1362,y:736,t:1527271936215};\\\", \\\"{x:1362,y:738,t:1527271936232};\\\", \\\"{x:1348,y:736,t:1527271936314};\\\", \\\"{x:1334,y:732,t:1527271936322};\\\", \\\"{x:1310,y:729,t:1527271936333};\\\", \\\"{x:1255,y:723,t:1527271936349};\\\", \\\"{x:1230,y:723,t:1527271936365};\\\", \\\"{x:1213,y:731,t:1527271936383};\\\", \\\"{x:1208,y:734,t:1527271936399};\\\", \\\"{x:1199,y:739,t:1527271936415};\\\", \\\"{x:1194,y:745,t:1527271936432};\\\", \\\"{x:1183,y:752,t:1527271936449};\\\", \\\"{x:1181,y:754,t:1527271936466};\\\", \\\"{x:1175,y:754,t:1527271936482};\\\", \\\"{x:1167,y:753,t:1527271936500};\\\", \\\"{x:1157,y:752,t:1527271936516};\\\", \\\"{x:1151,y:745,t:1527271936532};\\\", \\\"{x:1097,y:724,t:1527271936550};\\\", \\\"{x:1064,y:715,t:1527271936566};\\\", \\\"{x:943,y:683,t:1527271936583};\\\", \\\"{x:838,y:655,t:1527271936600};\\\", \\\"{x:766,y:633,t:1527271936616};\\\", \\\"{x:727,y:620,t:1527271936634};\\\", \\\"{x:705,y:612,t:1527271936651};\\\", \\\"{x:699,y:609,t:1527271936681};\\\", \\\"{x:699,y:608,t:1527271936698};\\\", \\\"{x:699,y:606,t:1527271936715};\\\", \\\"{x:700,y:605,t:1527271936731};\\\", \\\"{x:700,y:601,t:1527271936749};\\\", \\\"{x:699,y:597,t:1527271936766};\\\", \\\"{x:687,y:585,t:1527271936782};\\\", \\\"{x:673,y:573,t:1527271936799};\\\", \\\"{x:657,y:565,t:1527271936816};\\\", \\\"{x:644,y:560,t:1527271936832};\\\", \\\"{x:622,y:547,t:1527271936849};\\\", \\\"{x:607,y:542,t:1527271936866};\\\", \\\"{x:594,y:538,t:1527271936882};\\\", \\\"{x:586,y:534,t:1527271936898};\\\", \\\"{x:582,y:532,t:1527271936916};\\\", \\\"{x:582,y:531,t:1527271936931};\\\", \\\"{x:580,y:530,t:1527271936949};\\\", \\\"{x:580,y:529,t:1527271936966};\\\", \\\"{x:580,y:528,t:1527271936982};\\\", \\\"{x:580,y:526,t:1527271936999};\\\", \\\"{x:580,y:524,t:1527271937017};\\\", \\\"{x:581,y:519,t:1527271937032};\\\", \\\"{x:585,y:516,t:1527271937049};\\\", \\\"{x:597,y:512,t:1527271937066};\\\", \\\"{x:612,y:511,t:1527271937083};\\\", \\\"{x:617,y:511,t:1527271937099};\\\", \\\"{x:621,y:511,t:1527271937116};\\\", \\\"{x:624,y:512,t:1527271937133};\\\", \\\"{x:625,y:513,t:1527271937149};\\\", \\\"{x:625,y:514,t:1527271937166};\\\", \\\"{x:627,y:519,t:1527271937184};\\\", \\\"{x:630,y:524,t:1527271937199};\\\", \\\"{x:635,y:530,t:1527271937216};\\\", \\\"{x:640,y:535,t:1527271937232};\\\", \\\"{x:641,y:536,t:1527271937248};\\\", \\\"{x:642,y:536,t:1527271937321};\\\", \\\"{x:641,y:533,t:1527271937333};\\\", \\\"{x:636,y:526,t:1527271937350};\\\", \\\"{x:632,y:522,t:1527271937367};\\\", \\\"{x:628,y:519,t:1527271937383};\\\", \\\"{x:627,y:519,t:1527271937399};\\\", \\\"{x:627,y:518,t:1527271937416};\\\", \\\"{x:626,y:517,t:1527271937434};\\\", \\\"{x:625,y:516,t:1527271937450};\\\", \\\"{x:624,y:514,t:1527271937466};\\\", \\\"{x:623,y:513,t:1527271937483};\\\", \\\"{x:623,y:512,t:1527271937499};\\\", \\\"{x:619,y:519,t:1527271937811};\\\", \\\"{x:615,y:523,t:1527271937817};\\\", \\\"{x:611,y:547,t:1527271937833};\\\", \\\"{x:609,y:576,t:1527271937850};\\\", \\\"{x:604,y:601,t:1527271937867};\\\", \\\"{x:602,y:620,t:1527271937883};\\\", \\\"{x:598,y:628,t:1527271937900};\\\", \\\"{x:595,y:638,t:1527271937917};\\\", \\\"{x:589,y:657,t:1527271937933};\\\", \\\"{x:581,y:671,t:1527271937950};\\\", \\\"{x:577,y:679,t:1527271937966};\\\", \\\"{x:575,y:683,t:1527271937983};\\\", \\\"{x:573,y:684,t:1527271938057};\\\", \\\"{x:572,y:685,t:1527271938066};\\\", \\\"{x:570,y:686,t:1527271938083};\\\", \\\"{x:568,y:686,t:1527271938104};\\\", \\\"{x:566,y:683,t:1527271938115};\\\", \\\"{x:565,y:665,t:1527271938133};\\\", \\\"{x:565,y:645,t:1527271938150};\\\", \\\"{x:570,y:604,t:1527271938166};\\\", \\\"{x:574,y:589,t:1527271938183};\\\", \\\"{x:574,y:573,t:1527271938200};\\\", \\\"{x:584,y:548,t:1527271938217};\\\", \\\"{x:587,y:534,t:1527271938233};\\\", \\\"{x:591,y:528,t:1527271938249};\\\", \\\"{x:593,y:524,t:1527271938268};\\\", \\\"{x:597,y:519,t:1527271938283};\\\", \\\"{x:598,y:518,t:1527271938299};\\\", \\\"{x:600,y:517,t:1527271938317};\\\", \\\"{x:603,y:516,t:1527271938334};\\\", \\\"{x:609,y:515,t:1527271938350};\\\", \\\"{x:614,y:511,t:1527271938367};\\\", \\\"{x:618,y:506,t:1527271938384};\\\", \\\"{x:620,y:504,t:1527271938400};\\\", \\\"{x:620,y:503,t:1527271938417};\\\", \\\"{x:620,y:502,t:1527271938441};\\\", \\\"{x:620,y:501,t:1527271938465};\\\", \\\"{x:619,y:508,t:1527271938818};\\\", \\\"{x:608,y:539,t:1527271938835};\\\", \\\"{x:599,y:580,t:1527271938851};\\\", \\\"{x:586,y:627,t:1527271938867};\\\", \\\"{x:577,y:655,t:1527271938884};\\\", \\\"{x:570,y:695,t:1527271938901};\\\", \\\"{x:567,y:711,t:1527271938917};\\\", \\\"{x:565,y:720,t:1527271938934};\\\", \\\"{x:563,y:725,t:1527271938951};\\\", \\\"{x:562,y:726,t:1527271938966};\\\", \\\"{x:562,y:727,t:1527271938984};\\\", \\\"{x:560,y:729,t:1527271939000};\\\", \\\"{x:559,y:730,t:1527271939032};\\\", \\\"{x:556,y:733,t:1527271939040};\\\", \\\"{x:554,y:737,t:1527271939051};\\\", \\\"{x:548,y:743,t:1527271939067};\\\", \\\"{x:544,y:745,t:1527271939084};\\\", \\\"{x:543,y:746,t:1527271939101};\\\", \\\"{x:541,y:746,t:1527271939117};\\\", \\\"{x:536,y:744,t:1527271939134};\\\", \\\"{x:533,y:742,t:1527271939150};\\\", \\\"{x:530,y:741,t:1527271939167};\\\", \\\"{x:528,y:741,t:1527271939184};\\\", \\\"{x:524,y:740,t:1527271939201};\\\" ] }, { \\\"rt\\\": 5965, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 627444, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:737,t:1527271942498};\\\", \\\"{x:524,y:733,t:1527271942506};\\\", \\\"{x:532,y:727,t:1527271942521};\\\", \\\"{x:608,y:708,t:1527271942539};\\\", \\\"{x:689,y:695,t:1527271942553};\\\", \\\"{x:736,y:686,t:1527271942570};\\\", \\\"{x:814,y:687,t:1527271942587};\\\", \\\"{x:912,y:691,t:1527271942603};\\\", \\\"{x:997,y:696,t:1527271942620};\\\", \\\"{x:1060,y:703,t:1527271942637};\\\", \\\"{x:1095,y:709,t:1527271942655};\\\", \\\"{x:1124,y:713,t:1527271942670};\\\", \\\"{x:1138,y:721,t:1527271942687};\\\", \\\"{x:1150,y:731,t:1527271942704};\\\", \\\"{x:1157,y:737,t:1527271942720};\\\", \\\"{x:1174,y:752,t:1527271942737};\\\", \\\"{x:1184,y:762,t:1527271942755};\\\", \\\"{x:1196,y:774,t:1527271942771};\\\", \\\"{x:1204,y:785,t:1527271942787};\\\", \\\"{x:1211,y:796,t:1527271942804};\\\", \\\"{x:1221,y:810,t:1527271942820};\\\", \\\"{x:1229,y:824,t:1527271942838};\\\", \\\"{x:1231,y:829,t:1527271942854};\\\", \\\"{x:1235,y:836,t:1527271942870};\\\", \\\"{x:1237,y:839,t:1527271942887};\\\", \\\"{x:1242,y:848,t:1527271942904};\\\", \\\"{x:1246,y:855,t:1527271942921};\\\", \\\"{x:1251,y:863,t:1527271942937};\\\", \\\"{x:1254,y:864,t:1527271942954};\\\", \\\"{x:1255,y:864,t:1527271942971};\\\", \\\"{x:1257,y:864,t:1527271942987};\\\", \\\"{x:1259,y:864,t:1527271943005};\\\", \\\"{x:1263,y:863,t:1527271943021};\\\", \\\"{x:1270,y:860,t:1527271943042};\\\", \\\"{x:1273,y:858,t:1527271943054};\\\", \\\"{x:1283,y:857,t:1527271943071};\\\", \\\"{x:1297,y:857,t:1527271943087};\\\", \\\"{x:1308,y:857,t:1527271943104};\\\", \\\"{x:1321,y:860,t:1527271943121};\\\", \\\"{x:1329,y:864,t:1527271943137};\\\", \\\"{x:1335,y:867,t:1527271943154};\\\", \\\"{x:1343,y:877,t:1527271943171};\\\", \\\"{x:1351,y:888,t:1527271943187};\\\", \\\"{x:1364,y:902,t:1527271943204};\\\", \\\"{x:1382,y:920,t:1527271943222};\\\", \\\"{x:1396,y:932,t:1527271943237};\\\", \\\"{x:1404,y:940,t:1527271943254};\\\", \\\"{x:1408,y:946,t:1527271943271};\\\", \\\"{x:1409,y:947,t:1527271943287};\\\", \\\"{x:1412,y:951,t:1527271943304};\\\", \\\"{x:1414,y:953,t:1527271943321};\\\", \\\"{x:1414,y:954,t:1527271943337};\\\", \\\"{x:1414,y:955,t:1527271943433};\\\", \\\"{x:1414,y:956,t:1527271943441};\\\", \\\"{x:1413,y:958,t:1527271943454};\\\", \\\"{x:1408,y:959,t:1527271943471};\\\", \\\"{x:1401,y:961,t:1527271943487};\\\", \\\"{x:1384,y:962,t:1527271943504};\\\", \\\"{x:1378,y:962,t:1527271943521};\\\", \\\"{x:1374,y:962,t:1527271943538};\\\", \\\"{x:1370,y:960,t:1527271943554};\\\", \\\"{x:1369,y:959,t:1527271943624};\\\", \\\"{x:1369,y:957,t:1527271943639};\\\", \\\"{x:1367,y:952,t:1527271943654};\\\", \\\"{x:1367,y:950,t:1527271943671};\\\", \\\"{x:1367,y:946,t:1527271943688};\\\", \\\"{x:1367,y:941,t:1527271943704};\\\", \\\"{x:1367,y:935,t:1527271943721};\\\", \\\"{x:1372,y:929,t:1527271943738};\\\", \\\"{x:1376,y:924,t:1527271943754};\\\", \\\"{x:1379,y:920,t:1527271943771};\\\", \\\"{x:1380,y:915,t:1527271943788};\\\", \\\"{x:1384,y:911,t:1527271943805};\\\", \\\"{x:1387,y:908,t:1527271943821};\\\", \\\"{x:1387,y:907,t:1527271943838};\\\", \\\"{x:1388,y:904,t:1527271943854};\\\", \\\"{x:1390,y:901,t:1527271943871};\\\", \\\"{x:1394,y:894,t:1527271943888};\\\", \\\"{x:1394,y:893,t:1527271943904};\\\", \\\"{x:1395,y:891,t:1527271943921};\\\", \\\"{x:1394,y:891,t:1527271944586};\\\", \\\"{x:1386,y:891,t:1527271944594};\\\", \\\"{x:1371,y:891,t:1527271944606};\\\", \\\"{x:1297,y:885,t:1527271944622};\\\", \\\"{x:1212,y:867,t:1527271944639};\\\", \\\"{x:1108,y:840,t:1527271944656};\\\", \\\"{x:971,y:815,t:1527271944674};\\\", \\\"{x:807,y:763,t:1527271944689};\\\", \\\"{x:723,y:735,t:1527271944706};\\\", \\\"{x:678,y:721,t:1527271944722};\\\", \\\"{x:660,y:710,t:1527271944738};\\\", \\\"{x:645,y:700,t:1527271944755};\\\", \\\"{x:634,y:692,t:1527271944772};\\\", \\\"{x:628,y:682,t:1527271944788};\\\", \\\"{x:619,y:671,t:1527271944806};\\\", \\\"{x:614,y:663,t:1527271944822};\\\", \\\"{x:610,y:653,t:1527271944839};\\\", \\\"{x:606,y:644,t:1527271944856};\\\", \\\"{x:599,y:633,t:1527271944873};\\\", \\\"{x:592,y:620,t:1527271944891};\\\", \\\"{x:591,y:618,t:1527271944905};\\\", \\\"{x:591,y:617,t:1527271944928};\\\", \\\"{x:591,y:615,t:1527271944939};\\\", \\\"{x:591,y:610,t:1527271944955};\\\", \\\"{x:591,y:604,t:1527271944972};\\\", \\\"{x:591,y:600,t:1527271944989};\\\", \\\"{x:591,y:598,t:1527271945005};\\\", \\\"{x:591,y:595,t:1527271945022};\\\", \\\"{x:591,y:592,t:1527271945040};\\\", \\\"{x:591,y:590,t:1527271945055};\\\", \\\"{x:593,y:586,t:1527271945072};\\\", \\\"{x:595,y:579,t:1527271945089};\\\", \\\"{x:595,y:577,t:1527271945105};\\\", \\\"{x:595,y:575,t:1527271945122};\\\", \\\"{x:593,y:575,t:1527271945152};\\\", \\\"{x:590,y:575,t:1527271945160};\\\", \\\"{x:586,y:575,t:1527271945172};\\\", \\\"{x:573,y:573,t:1527271945189};\\\", \\\"{x:561,y:573,t:1527271945205};\\\", \\\"{x:550,y:573,t:1527271945222};\\\", \\\"{x:541,y:573,t:1527271945240};\\\", \\\"{x:518,y:574,t:1527271945257};\\\", \\\"{x:514,y:575,t:1527271945272};\\\", \\\"{x:498,y:575,t:1527271945290};\\\", \\\"{x:493,y:575,t:1527271945306};\\\", \\\"{x:489,y:575,t:1527271945322};\\\", \\\"{x:486,y:575,t:1527271945339};\\\", \\\"{x:483,y:575,t:1527271945357};\\\", \\\"{x:478,y:575,t:1527271945372};\\\", \\\"{x:472,y:574,t:1527271945390};\\\", \\\"{x:467,y:572,t:1527271945406};\\\", \\\"{x:460,y:567,t:1527271945422};\\\", \\\"{x:447,y:564,t:1527271945439};\\\", \\\"{x:425,y:564,t:1527271945457};\\\", \\\"{x:414,y:564,t:1527271945473};\\\", \\\"{x:405,y:564,t:1527271945489};\\\", \\\"{x:399,y:562,t:1527271945507};\\\", \\\"{x:398,y:561,t:1527271945523};\\\", \\\"{x:397,y:560,t:1527271945539};\\\", \\\"{x:395,y:559,t:1527271945609};\\\", \\\"{x:394,y:557,t:1527271945622};\\\", \\\"{x:391,y:556,t:1527271945639};\\\", \\\"{x:389,y:553,t:1527271945656};\\\", \\\"{x:388,y:553,t:1527271945681};\\\", \\\"{x:388,y:551,t:1527271945713};\\\", \\\"{x:388,y:550,t:1527271945729};\\\", \\\"{x:387,y:550,t:1527271945739};\\\", \\\"{x:386,y:548,t:1527271945768};\\\", \\\"{x:386,y:547,t:1527271946001};\\\", \\\"{x:386,y:550,t:1527271946016};\\\", \\\"{x:385,y:556,t:1527271946025};\\\", \\\"{x:385,y:564,t:1527271946041};\\\", \\\"{x:385,y:571,t:1527271946056};\\\", \\\"{x:385,y:574,t:1527271946073};\\\", \\\"{x:385,y:577,t:1527271946090};\\\", \\\"{x:385,y:582,t:1527271946106};\\\", \\\"{x:385,y:585,t:1527271946123};\\\", \\\"{x:385,y:589,t:1527271946140};\\\", \\\"{x:386,y:591,t:1527271946156};\\\", \\\"{x:386,y:592,t:1527271946173};\\\", \\\"{x:386,y:594,t:1527271946190};\\\", \\\"{x:386,y:596,t:1527271946206};\\\", \\\"{x:386,y:599,t:1527271946223};\\\", \\\"{x:386,y:603,t:1527271946241};\\\", \\\"{x:386,y:605,t:1527271946265};\\\", \\\"{x:386,y:606,t:1527271946273};\\\", \\\"{x:386,y:607,t:1527271946362};\\\", \\\"{x:386,y:609,t:1527271946374};\\\", \\\"{x:386,y:611,t:1527271946391};\\\", \\\"{x:386,y:612,t:1527271946792};\\\", \\\"{x:390,y:614,t:1527271946807};\\\", \\\"{x:398,y:618,t:1527271946823};\\\", \\\"{x:412,y:629,t:1527271946841};\\\", \\\"{x:423,y:637,t:1527271946857};\\\", \\\"{x:432,y:644,t:1527271946874};\\\", \\\"{x:438,y:650,t:1527271946890};\\\", \\\"{x:443,y:659,t:1527271946907};\\\", \\\"{x:447,y:663,t:1527271946924};\\\", \\\"{x:451,y:671,t:1527271946940};\\\", \\\"{x:458,y:677,t:1527271946957};\\\", \\\"{x:464,y:684,t:1527271946973};\\\", \\\"{x:473,y:692,t:1527271946990};\\\", \\\"{x:476,y:698,t:1527271947007};\\\", \\\"{x:483,y:702,t:1527271947023};\\\", \\\"{x:487,y:706,t:1527271947041};\\\", \\\"{x:494,y:712,t:1527271947058};\\\", \\\"{x:500,y:717,t:1527271947073};\\\", \\\"{x:504,y:720,t:1527271947091};\\\", \\\"{x:508,y:724,t:1527271947107};\\\", \\\"{x:513,y:729,t:1527271947123};\\\", \\\"{x:516,y:734,t:1527271947141};\\\", \\\"{x:518,y:737,t:1527271947158};\\\", \\\"{x:520,y:742,t:1527271947174};\\\", \\\"{x:520,y:743,t:1527271947190};\\\", \\\"{x:521,y:746,t:1527271947207};\\\", \\\"{x:522,y:750,t:1527271947224};\\\", \\\"{x:523,y:750,t:1527271948297};\\\" ] }, { \\\"rt\\\": 5182, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 633882, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:749,t:1527271949482};\\\", \\\"{x:532,y:746,t:1527271949494};\\\", \\\"{x:555,y:736,t:1527271949511};\\\", \\\"{x:587,y:723,t:1527271949528};\\\", \\\"{x:684,y:688,t:1527271949544};\\\", \\\"{x:748,y:671,t:1527271949559};\\\", \\\"{x:984,y:641,t:1527271949576};\\\", \\\"{x:1140,y:634,t:1527271949592};\\\", \\\"{x:1278,y:634,t:1527271949609};\\\", \\\"{x:1397,y:634,t:1527271949626};\\\", \\\"{x:1489,y:649,t:1527271949643};\\\", \\\"{x:1551,y:659,t:1527271949660};\\\", \\\"{x:1577,y:663,t:1527271949677};\\\", \\\"{x:1593,y:666,t:1527271949692};\\\", \\\"{x:1594,y:666,t:1527271949709};\\\", \\\"{x:1594,y:668,t:1527271949777};\\\", \\\"{x:1589,y:672,t:1527271949793};\\\", \\\"{x:1582,y:681,t:1527271949810};\\\", \\\"{x:1571,y:692,t:1527271949827};\\\", \\\"{x:1559,y:704,t:1527271949843};\\\", \\\"{x:1549,y:710,t:1527271949860};\\\", \\\"{x:1540,y:713,t:1527271949877};\\\", \\\"{x:1534,y:715,t:1527271949893};\\\", \\\"{x:1527,y:717,t:1527271949910};\\\", \\\"{x:1517,y:722,t:1527271949927};\\\", \\\"{x:1503,y:728,t:1527271949943};\\\", \\\"{x:1494,y:733,t:1527271949960};\\\", \\\"{x:1490,y:735,t:1527271949978};\\\", \\\"{x:1489,y:735,t:1527271950009};\\\", \\\"{x:1480,y:735,t:1527271950027};\\\", \\\"{x:1467,y:735,t:1527271950044};\\\", \\\"{x:1448,y:735,t:1527271950060};\\\", \\\"{x:1430,y:734,t:1527271950077};\\\", \\\"{x:1415,y:730,t:1527271950094};\\\", \\\"{x:1387,y:722,t:1527271950110};\\\", \\\"{x:1374,y:710,t:1527271950127};\\\", \\\"{x:1358,y:702,t:1527271950144};\\\", \\\"{x:1348,y:700,t:1527271950163};\\\", \\\"{x:1341,y:697,t:1527271950177};\\\", \\\"{x:1340,y:697,t:1527271950193};\\\", \\\"{x:1340,y:696,t:1527271950240};\\\", \\\"{x:1340,y:694,t:1527271950248};\\\", \\\"{x:1342,y:693,t:1527271950259};\\\", \\\"{x:1344,y:692,t:1527271950276};\\\", \\\"{x:1347,y:689,t:1527271950294};\\\", \\\"{x:1350,y:687,t:1527271950310};\\\", \\\"{x:1353,y:685,t:1527271950327};\\\", \\\"{x:1358,y:684,t:1527271950343};\\\", \\\"{x:1362,y:683,t:1527271950359};\\\", \\\"{x:1364,y:683,t:1527271950376};\\\", \\\"{x:1365,y:681,t:1527271950514};\\\", \\\"{x:1367,y:679,t:1527271950527};\\\", \\\"{x:1370,y:675,t:1527271950544};\\\", \\\"{x:1381,y:655,t:1527271950561};\\\", \\\"{x:1389,y:641,t:1527271950578};\\\", \\\"{x:1396,y:632,t:1527271950594};\\\", \\\"{x:1405,y:618,t:1527271950612};\\\", \\\"{x:1408,y:609,t:1527271950628};\\\", \\\"{x:1414,y:599,t:1527271950644};\\\", \\\"{x:1416,y:593,t:1527271950661};\\\", \\\"{x:1420,y:587,t:1527271950677};\\\", \\\"{x:1422,y:583,t:1527271950694};\\\", \\\"{x:1423,y:581,t:1527271950712};\\\", \\\"{x:1424,y:580,t:1527271950729};\\\", \\\"{x:1416,y:583,t:1527271950818};\\\", \\\"{x:1404,y:590,t:1527271950827};\\\", \\\"{x:1354,y:623,t:1527271950844};\\\", \\\"{x:1268,y:660,t:1527271950861};\\\", \\\"{x:1183,y:682,t:1527271950878};\\\", \\\"{x:1102,y:696,t:1527271950894};\\\", \\\"{x:1064,y:700,t:1527271950911};\\\", \\\"{x:1054,y:700,t:1527271950928};\\\", \\\"{x:1027,y:701,t:1527271950944};\\\", \\\"{x:990,y:695,t:1527271950961};\\\", \\\"{x:958,y:689,t:1527271950978};\\\", \\\"{x:922,y:679,t:1527271950994};\\\", \\\"{x:905,y:675,t:1527271951011};\\\", \\\"{x:882,y:665,t:1527271951028};\\\", \\\"{x:858,y:663,t:1527271951044};\\\", \\\"{x:846,y:658,t:1527271951060};\\\", \\\"{x:834,y:653,t:1527271951079};\\\", \\\"{x:807,y:646,t:1527271951094};\\\", \\\"{x:788,y:642,t:1527271951110};\\\", \\\"{x:778,y:639,t:1527271951128};\\\", \\\"{x:764,y:636,t:1527271951144};\\\", \\\"{x:746,y:631,t:1527271951165};\\\", \\\"{x:732,y:628,t:1527271951177};\\\", \\\"{x:716,y:623,t:1527271951194};\\\", \\\"{x:699,y:616,t:1527271951210};\\\", \\\"{x:687,y:608,t:1527271951227};\\\", \\\"{x:655,y:596,t:1527271951244};\\\", \\\"{x:635,y:589,t:1527271951261};\\\", \\\"{x:617,y:584,t:1527271951278};\\\", \\\"{x:596,y:581,t:1527271951294};\\\", \\\"{x:575,y:577,t:1527271951310};\\\", \\\"{x:550,y:574,t:1527271951328};\\\", \\\"{x:528,y:572,t:1527271951343};\\\", \\\"{x:509,y:570,t:1527271951360};\\\", \\\"{x:512,y:567,t:1527271951408};\\\", \\\"{x:524,y:562,t:1527271951417};\\\", \\\"{x:540,y:556,t:1527271951427};\\\", \\\"{x:589,y:547,t:1527271951445};\\\", \\\"{x:655,y:538,t:1527271951461};\\\", \\\"{x:684,y:537,t:1527271951477};\\\", \\\"{x:717,y:533,t:1527271951495};\\\", \\\"{x:753,y:532,t:1527271951512};\\\", \\\"{x:772,y:533,t:1527271951527};\\\", \\\"{x:779,y:536,t:1527271951544};\\\", \\\"{x:781,y:537,t:1527271951560};\\\", \\\"{x:783,y:537,t:1527271951577};\\\", \\\"{x:784,y:537,t:1527271951648};\\\", \\\"{x:787,y:537,t:1527271951661};\\\", \\\"{x:792,y:537,t:1527271951678};\\\", \\\"{x:795,y:537,t:1527271951694};\\\", \\\"{x:801,y:537,t:1527271951711};\\\", \\\"{x:802,y:538,t:1527271951727};\\\", \\\"{x:804,y:538,t:1527271951744};\\\", \\\"{x:806,y:539,t:1527271951785};\\\", \\\"{x:811,y:542,t:1527271951794};\\\", \\\"{x:815,y:543,t:1527271951812};\\\", \\\"{x:817,y:543,t:1527271951828};\\\", \\\"{x:819,y:545,t:1527271951844};\\\", \\\"{x:820,y:546,t:1527271951862};\\\", \\\"{x:820,y:547,t:1527271951914};\\\", \\\"{x:822,y:547,t:1527271951937};\\\", \\\"{x:823,y:547,t:1527271951953};\\\", \\\"{x:822,y:549,t:1527271952265};\\\", \\\"{x:814,y:558,t:1527271952280};\\\", \\\"{x:789,y:586,t:1527271952296};\\\", \\\"{x:769,y:607,t:1527271952312};\\\", \\\"{x:736,y:641,t:1527271952328};\\\", \\\"{x:723,y:662,t:1527271952344};\\\", \\\"{x:707,y:680,t:1527271952362};\\\", \\\"{x:690,y:694,t:1527271952378};\\\", \\\"{x:679,y:704,t:1527271952395};\\\", \\\"{x:673,y:708,t:1527271952411};\\\", \\\"{x:673,y:709,t:1527271952428};\\\", \\\"{x:672,y:710,t:1527271952497};\\\", \\\"{x:668,y:710,t:1527271952511};\\\", \\\"{x:642,y:711,t:1527271952528};\\\", \\\"{x:625,y:711,t:1527271952546};\\\", \\\"{x:607,y:711,t:1527271952562};\\\", \\\"{x:602,y:711,t:1527271952578};\\\", \\\"{x:600,y:711,t:1527271952608};\\\", \\\"{x:600,y:700,t:1527271952617};\\\", \\\"{x:608,y:688,t:1527271952628};\\\", \\\"{x:649,y:639,t:1527271952646};\\\", \\\"{x:690,y:596,t:1527271952662};\\\", \\\"{x:734,y:569,t:1527271952679};\\\", \\\"{x:766,y:552,t:1527271952696};\\\", \\\"{x:792,y:540,t:1527271952712};\\\", \\\"{x:804,y:535,t:1527271952728};\\\", \\\"{x:811,y:530,t:1527271952745};\\\", \\\"{x:817,y:527,t:1527271952762};\\\", \\\"{x:822,y:524,t:1527271952779};\\\", \\\"{x:826,y:522,t:1527271952795};\\\", \\\"{x:828,y:521,t:1527271952812};\\\", \\\"{x:828,y:520,t:1527271952873};\\\", \\\"{x:830,y:519,t:1527271952880};\\\", \\\"{x:831,y:519,t:1527271952896};\\\", \\\"{x:832,y:518,t:1527271952912};\\\", \\\"{x:832,y:520,t:1527271952953};\\\", \\\"{x:832,y:524,t:1527271952962};\\\", \\\"{x:832,y:529,t:1527271952979};\\\", \\\"{x:832,y:534,t:1527271952995};\\\", \\\"{x:833,y:535,t:1527271953012};\\\", \\\"{x:835,y:539,t:1527271953028};\\\", \\\"{x:835,y:540,t:1527271953048};\\\", \\\"{x:836,y:541,t:1527271953063};\\\", \\\"{x:827,y:552,t:1527271953304};\\\", \\\"{x:810,y:565,t:1527271953313};\\\", \\\"{x:786,y:579,t:1527271953328};\\\", \\\"{x:734,y:618,t:1527271953346};\\\", \\\"{x:695,y:639,t:1527271953363};\\\", \\\"{x:682,y:647,t:1527271953380};\\\", \\\"{x:668,y:652,t:1527271953396};\\\", \\\"{x:660,y:657,t:1527271953412};\\\", \\\"{x:652,y:666,t:1527271953429};\\\", \\\"{x:637,y:674,t:1527271953445};\\\", \\\"{x:624,y:686,t:1527271953462};\\\", \\\"{x:608,y:696,t:1527271953480};\\\", \\\"{x:591,y:704,t:1527271953496};\\\", \\\"{x:584,y:707,t:1527271953512};\\\", \\\"{x:583,y:707,t:1527271953529};\\\", \\\"{x:578,y:707,t:1527271953546};\\\", \\\"{x:575,y:707,t:1527271953563};\\\", \\\"{x:570,y:710,t:1527271953579};\\\", \\\"{x:567,y:712,t:1527271953597};\\\", \\\"{x:564,y:714,t:1527271953612};\\\", \\\"{x:562,y:714,t:1527271953629};\\\", \\\"{x:558,y:714,t:1527271953647};\\\", \\\"{x:553,y:715,t:1527271953664};\\\", \\\"{x:546,y:717,t:1527271953680};\\\", \\\"{x:533,y:723,t:1527271953697};\\\", \\\"{x:520,y:729,t:1527271953713};\\\", \\\"{x:510,y:736,t:1527271953729};\\\", \\\"{x:508,y:737,t:1527271953747};\\\" ] }, { \\\"rt\\\": 26560, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 661775, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\", \\\"N\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -L -L -H -H -Z -Z -H -N -N -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:736,t:1527271956514};\\\", \\\"{x:514,y:732,t:1527271956527};\\\", \\\"{x:529,y:725,t:1527271956544};\\\", \\\"{x:563,y:707,t:1527271956560};\\\", \\\"{x:607,y:685,t:1527271956578};\\\", \\\"{x:639,y:669,t:1527271956598};\\\", \\\"{x:674,y:651,t:1527271956615};\\\", \\\"{x:753,y:619,t:1527271956633};\\\", \\\"{x:907,y:571,t:1527271956649};\\\", \\\"{x:1020,y:540,t:1527271956665};\\\", \\\"{x:1108,y:529,t:1527271956681};\\\", \\\"{x:1172,y:529,t:1527271956699};\\\", \\\"{x:1198,y:529,t:1527271956715};\\\", \\\"{x:1209,y:529,t:1527271956732};\\\", \\\"{x:1214,y:530,t:1527271956748};\\\", \\\"{x:1217,y:530,t:1527271956765};\\\", \\\"{x:1223,y:530,t:1527271956782};\\\", \\\"{x:1234,y:530,t:1527271956799};\\\", \\\"{x:1249,y:530,t:1527271956816};\\\", \\\"{x:1255,y:530,t:1527271956831};\\\", \\\"{x:1295,y:537,t:1527271956848};\\\", \\\"{x:1332,y:542,t:1527271956865};\\\", \\\"{x:1379,y:548,t:1527271956881};\\\", \\\"{x:1429,y:548,t:1527271956899};\\\", \\\"{x:1471,y:552,t:1527271956915};\\\", \\\"{x:1494,y:555,t:1527271956932};\\\", \\\"{x:1508,y:557,t:1527271956949};\\\", \\\"{x:1511,y:557,t:1527271956966};\\\", \\\"{x:1516,y:557,t:1527271956982};\\\", \\\"{x:1520,y:557,t:1527271956998};\\\", \\\"{x:1521,y:557,t:1527271957025};\\\", \\\"{x:1521,y:559,t:1527271957064};\\\", \\\"{x:1521,y:563,t:1527271957073};\\\", \\\"{x:1519,y:569,t:1527271957082};\\\", \\\"{x:1514,y:581,t:1527271957099};\\\", \\\"{x:1507,y:599,t:1527271957116};\\\", \\\"{x:1501,y:615,t:1527271957133};\\\", \\\"{x:1489,y:634,t:1527271957149};\\\", \\\"{x:1480,y:650,t:1527271957166};\\\", \\\"{x:1470,y:664,t:1527271957183};\\\", \\\"{x:1461,y:677,t:1527271957199};\\\", \\\"{x:1453,y:686,t:1527271957216};\\\", \\\"{x:1440,y:699,t:1527271957232};\\\", \\\"{x:1430,y:711,t:1527271957249};\\\", \\\"{x:1422,y:719,t:1527271957266};\\\", \\\"{x:1412,y:725,t:1527271957283};\\\", \\\"{x:1406,y:730,t:1527271957299};\\\", \\\"{x:1400,y:737,t:1527271957316};\\\", \\\"{x:1392,y:744,t:1527271957334};\\\", \\\"{x:1380,y:755,t:1527271957349};\\\", \\\"{x:1372,y:764,t:1527271957366};\\\", \\\"{x:1362,y:773,t:1527271957383};\\\", \\\"{x:1351,y:782,t:1527271957400};\\\", \\\"{x:1340,y:792,t:1527271957416};\\\", \\\"{x:1320,y:804,t:1527271957433};\\\", \\\"{x:1311,y:809,t:1527271957450};\\\", \\\"{x:1307,y:810,t:1527271957466};\\\", \\\"{x:1304,y:810,t:1527271957483};\\\", \\\"{x:1300,y:815,t:1527271957500};\\\", \\\"{x:1296,y:818,t:1527271957516};\\\", \\\"{x:1287,y:822,t:1527271957533};\\\", \\\"{x:1280,y:824,t:1527271957550};\\\", \\\"{x:1276,y:826,t:1527271957566};\\\", \\\"{x:1273,y:826,t:1527271957583};\\\", \\\"{x:1272,y:828,t:1527271957600};\\\", \\\"{x:1266,y:830,t:1527271957617};\\\", \\\"{x:1256,y:833,t:1527271957633};\\\", \\\"{x:1252,y:833,t:1527271957650};\\\", \\\"{x:1248,y:836,t:1527271957666};\\\", \\\"{x:1248,y:835,t:1527271957738};\\\", \\\"{x:1249,y:831,t:1527271957751};\\\", \\\"{x:1265,y:822,t:1527271957768};\\\", \\\"{x:1299,y:806,t:1527271957784};\\\", \\\"{x:1337,y:791,t:1527271957801};\\\", \\\"{x:1434,y:776,t:1527271957817};\\\", \\\"{x:1478,y:764,t:1527271957833};\\\", \\\"{x:1521,y:757,t:1527271957850};\\\", \\\"{x:1558,y:756,t:1527271957868};\\\", \\\"{x:1581,y:751,t:1527271957883};\\\", \\\"{x:1587,y:750,t:1527271957900};\\\", \\\"{x:1591,y:750,t:1527271957918};\\\", \\\"{x:1593,y:750,t:1527271957985};\\\", \\\"{x:1593,y:754,t:1527271958066};\\\", \\\"{x:1593,y:764,t:1527271958074};\\\", \\\"{x:1593,y:770,t:1527271958084};\\\", \\\"{x:1586,y:790,t:1527271958101};\\\", \\\"{x:1583,y:804,t:1527271958118};\\\", \\\"{x:1578,y:818,t:1527271958134};\\\", \\\"{x:1575,y:827,t:1527271958151};\\\", \\\"{x:1571,y:837,t:1527271958168};\\\", \\\"{x:1570,y:847,t:1527271958185};\\\", \\\"{x:1569,y:852,t:1527271958200};\\\", \\\"{x:1569,y:857,t:1527271958217};\\\", \\\"{x:1569,y:859,t:1527271958235};\\\", \\\"{x:1569,y:860,t:1527271958250};\\\", \\\"{x:1570,y:861,t:1527271958267};\\\", \\\"{x:1573,y:862,t:1527271958297};\\\", \\\"{x:1574,y:863,t:1527271958321};\\\", \\\"{x:1575,y:863,t:1527271958425};\\\", \\\"{x:1579,y:863,t:1527271958440};\\\", \\\"{x:1581,y:863,t:1527271958451};\\\", \\\"{x:1593,y:863,t:1527271958467};\\\", \\\"{x:1607,y:861,t:1527271958483};\\\", \\\"{x:1618,y:858,t:1527271958501};\\\", \\\"{x:1636,y:854,t:1527271958516};\\\", \\\"{x:1648,y:850,t:1527271958534};\\\", \\\"{x:1662,y:848,t:1527271958550};\\\", \\\"{x:1675,y:845,t:1527271958567};\\\", \\\"{x:1683,y:843,t:1527271958584};\\\", \\\"{x:1687,y:841,t:1527271958600};\\\", \\\"{x:1690,y:840,t:1527271958616};\\\", \\\"{x:1691,y:839,t:1527271958634};\\\", \\\"{x:1694,y:837,t:1527271958651};\\\", \\\"{x:1695,y:837,t:1527271958667};\\\", \\\"{x:1696,y:836,t:1527271958684};\\\", \\\"{x:1697,y:835,t:1527271958701};\\\", \\\"{x:1698,y:833,t:1527271958717};\\\", \\\"{x:1698,y:832,t:1527271958733};\\\", \\\"{x:1698,y:831,t:1527271958751};\\\", \\\"{x:1698,y:830,t:1527271958810};\\\", \\\"{x:1697,y:830,t:1527271958825};\\\", \\\"{x:1695,y:830,t:1527271958834};\\\", \\\"{x:1689,y:833,t:1527271958852};\\\", \\\"{x:1681,y:833,t:1527271958870};\\\", \\\"{x:1674,y:832,t:1527271958884};\\\", \\\"{x:1665,y:827,t:1527271958900};\\\", \\\"{x:1660,y:823,t:1527271958918};\\\", \\\"{x:1652,y:815,t:1527271958934};\\\", \\\"{x:1643,y:800,t:1527271958951};\\\", \\\"{x:1636,y:777,t:1527271958968};\\\", \\\"{x:1621,y:737,t:1527271958983};\\\", \\\"{x:1603,y:659,t:1527271959000};\\\", \\\"{x:1597,y:637,t:1527271959018};\\\", \\\"{x:1595,y:622,t:1527271959034};\\\", \\\"{x:1595,y:616,t:1527271959050};\\\", \\\"{x:1596,y:611,t:1527271959068};\\\", \\\"{x:1598,y:606,t:1527271959084};\\\", \\\"{x:1601,y:599,t:1527271959101};\\\", \\\"{x:1603,y:590,t:1527271959118};\\\", \\\"{x:1604,y:584,t:1527271959135};\\\", \\\"{x:1607,y:580,t:1527271959151};\\\", \\\"{x:1607,y:578,t:1527271959168};\\\", \\\"{x:1607,y:577,t:1527271959257};\\\", \\\"{x:1608,y:575,t:1527271959268};\\\", \\\"{x:1608,y:574,t:1527271959286};\\\", \\\"{x:1608,y:571,t:1527271959301};\\\", \\\"{x:1609,y:564,t:1527271959318};\\\", \\\"{x:1609,y:554,t:1527271959336};\\\", \\\"{x:1610,y:534,t:1527271959351};\\\", \\\"{x:1614,y:514,t:1527271959368};\\\", \\\"{x:1615,y:502,t:1527271959385};\\\", \\\"{x:1615,y:501,t:1527271959401};\\\", \\\"{x:1615,y:500,t:1527271959418};\\\", \\\"{x:1613,y:500,t:1527271959441};\\\", \\\"{x:1612,y:500,t:1527271959452};\\\", \\\"{x:1606,y:500,t:1527271959469};\\\", \\\"{x:1601,y:503,t:1527271959485};\\\", \\\"{x:1595,y:507,t:1527271959503};\\\", \\\"{x:1587,y:511,t:1527271959519};\\\", \\\"{x:1580,y:514,t:1527271959535};\\\", \\\"{x:1574,y:517,t:1527271959552};\\\", \\\"{x:1569,y:519,t:1527271959567};\\\", \\\"{x:1561,y:522,t:1527271959585};\\\", \\\"{x:1560,y:524,t:1527271959602};\\\", \\\"{x:1557,y:526,t:1527271959618};\\\", \\\"{x:1553,y:529,t:1527271959635};\\\", \\\"{x:1548,y:530,t:1527271959651};\\\", \\\"{x:1541,y:533,t:1527271959668};\\\", \\\"{x:1538,y:534,t:1527271959685};\\\", \\\"{x:1535,y:535,t:1527271959701};\\\", \\\"{x:1531,y:535,t:1527271959718};\\\", \\\"{x:1529,y:537,t:1527271959735};\\\", \\\"{x:1528,y:537,t:1527271959752};\\\", \\\"{x:1523,y:537,t:1527271959793};\\\", \\\"{x:1520,y:537,t:1527271959802};\\\", \\\"{x:1512,y:537,t:1527271959819};\\\", \\\"{x:1508,y:537,t:1527271959835};\\\", \\\"{x:1491,y:537,t:1527271959852};\\\", \\\"{x:1474,y:537,t:1527271959869};\\\", \\\"{x:1461,y:537,t:1527271959886};\\\", \\\"{x:1450,y:537,t:1527271959902};\\\", \\\"{x:1443,y:537,t:1527271959919};\\\", \\\"{x:1431,y:538,t:1527271959935};\\\", \\\"{x:1417,y:542,t:1527271959952};\\\", \\\"{x:1402,y:548,t:1527271959969};\\\", \\\"{x:1394,y:551,t:1527271959985};\\\", \\\"{x:1384,y:554,t:1527271960002};\\\", \\\"{x:1367,y:556,t:1527271960019};\\\", \\\"{x:1354,y:556,t:1527271960035};\\\", \\\"{x:1343,y:556,t:1527271960052};\\\", \\\"{x:1339,y:556,t:1527271960069};\\\", \\\"{x:1338,y:556,t:1527271960086};\\\", \\\"{x:1336,y:556,t:1527271960103};\\\", \\\"{x:1333,y:552,t:1527271960119};\\\", \\\"{x:1332,y:539,t:1527271960137};\\\", \\\"{x:1335,y:530,t:1527271960152};\\\", \\\"{x:1342,y:519,t:1527271960169};\\\", \\\"{x:1352,y:509,t:1527271960187};\\\", \\\"{x:1366,y:500,t:1527271960202};\\\", \\\"{x:1379,y:492,t:1527271960220};\\\", \\\"{x:1394,y:484,t:1527271960237};\\\", \\\"{x:1406,y:479,t:1527271960252};\\\", \\\"{x:1417,y:477,t:1527271960270};\\\", \\\"{x:1429,y:473,t:1527271960286};\\\", \\\"{x:1433,y:472,t:1527271960303};\\\", \\\"{x:1442,y:468,t:1527271960320};\\\", \\\"{x:1452,y:464,t:1527271960337};\\\", \\\"{x:1464,y:458,t:1527271960353};\\\", \\\"{x:1465,y:456,t:1527271960369};\\\", \\\"{x:1473,y:451,t:1527271960386};\\\", \\\"{x:1481,y:442,t:1527271960403};\\\", \\\"{x:1491,y:433,t:1527271960419};\\\", \\\"{x:1497,y:425,t:1527271960436};\\\", \\\"{x:1501,y:414,t:1527271960453};\\\", \\\"{x:1506,y:404,t:1527271960469};\\\", \\\"{x:1508,y:395,t:1527271960486};\\\", \\\"{x:1512,y:387,t:1527271960504};\\\", \\\"{x:1515,y:379,t:1527271960520};\\\", \\\"{x:1517,y:373,t:1527271960537};\\\", \\\"{x:1518,y:367,t:1527271960553};\\\", \\\"{x:1520,y:364,t:1527271960569};\\\", \\\"{x:1522,y:362,t:1527271960587};\\\", \\\"{x:1524,y:360,t:1527271960603};\\\", \\\"{x:1526,y:359,t:1527271960619};\\\", \\\"{x:1529,y:357,t:1527271960637};\\\", \\\"{x:1530,y:357,t:1527271960653};\\\", \\\"{x:1531,y:357,t:1527271960669};\\\", \\\"{x:1533,y:356,t:1527271960686};\\\", \\\"{x:1536,y:355,t:1527271960703};\\\", \\\"{x:1539,y:355,t:1527271960720};\\\", \\\"{x:1546,y:355,t:1527271960736};\\\", \\\"{x:1550,y:355,t:1527271960752};\\\", \\\"{x:1555,y:355,t:1527271960769};\\\", \\\"{x:1558,y:358,t:1527271960785};\\\", \\\"{x:1562,y:362,t:1527271960802};\\\", \\\"{x:1567,y:369,t:1527271960819};\\\", \\\"{x:1568,y:373,t:1527271960836};\\\", \\\"{x:1570,y:376,t:1527271960852};\\\", \\\"{x:1571,y:381,t:1527271960869};\\\", \\\"{x:1573,y:392,t:1527271960886};\\\", \\\"{x:1574,y:408,t:1527271960903};\\\", \\\"{x:1575,y:426,t:1527271960920};\\\", \\\"{x:1575,y:451,t:1527271960936};\\\", \\\"{x:1576,y:483,t:1527271960953};\\\", \\\"{x:1576,y:496,t:1527271960971};\\\", \\\"{x:1576,y:511,t:1527271960987};\\\", \\\"{x:1576,y:520,t:1527271961002};\\\", \\\"{x:1576,y:532,t:1527271961020};\\\", \\\"{x:1578,y:543,t:1527271961036};\\\", \\\"{x:1579,y:555,t:1527271961052};\\\", \\\"{x:1581,y:563,t:1527271961070};\\\", \\\"{x:1581,y:568,t:1527271961087};\\\", \\\"{x:1581,y:577,t:1527271961102};\\\", \\\"{x:1583,y:591,t:1527271961120};\\\", \\\"{x:1582,y:607,t:1527271961136};\\\", \\\"{x:1579,y:618,t:1527271961153};\\\", \\\"{x:1578,y:628,t:1527271961170};\\\", \\\"{x:1577,y:638,t:1527271961187};\\\", \\\"{x:1572,y:653,t:1527271961203};\\\", \\\"{x:1566,y:665,t:1527271961220};\\\", \\\"{x:1561,y:683,t:1527271961237};\\\", \\\"{x:1556,y:702,t:1527271961253};\\\", \\\"{x:1545,y:724,t:1527271961270};\\\", \\\"{x:1538,y:742,t:1527271961287};\\\", \\\"{x:1533,y:753,t:1527271961303};\\\", \\\"{x:1530,y:764,t:1527271961319};\\\", \\\"{x:1529,y:772,t:1527271961337};\\\", \\\"{x:1527,y:776,t:1527271961353};\\\", \\\"{x:1525,y:781,t:1527271961370};\\\", \\\"{x:1523,y:787,t:1527271961387};\\\", \\\"{x:1523,y:789,t:1527271961404};\\\", \\\"{x:1523,y:793,t:1527271961420};\\\", \\\"{x:1522,y:794,t:1527271961437};\\\", \\\"{x:1522,y:796,t:1527271961454};\\\", \\\"{x:1522,y:797,t:1527271961470};\\\", \\\"{x:1521,y:799,t:1527271961488};\\\", \\\"{x:1521,y:805,t:1527271961505};\\\", \\\"{x:1520,y:810,t:1527271961520};\\\", \\\"{x:1517,y:815,t:1527271961537};\\\", \\\"{x:1516,y:820,t:1527271961554};\\\", \\\"{x:1514,y:827,t:1527271961570};\\\", \\\"{x:1510,y:834,t:1527271961587};\\\", \\\"{x:1508,y:837,t:1527271961604};\\\", \\\"{x:1503,y:845,t:1527271961620};\\\", \\\"{x:1498,y:852,t:1527271961637};\\\", \\\"{x:1495,y:857,t:1527271961654};\\\", \\\"{x:1489,y:860,t:1527271961670};\\\", \\\"{x:1483,y:863,t:1527271961687};\\\", \\\"{x:1464,y:870,t:1527271961704};\\\", \\\"{x:1459,y:872,t:1527271961720};\\\", \\\"{x:1454,y:875,t:1527271961737};\\\", \\\"{x:1440,y:880,t:1527271961754};\\\", \\\"{x:1427,y:885,t:1527271961771};\\\", \\\"{x:1413,y:889,t:1527271961787};\\\", \\\"{x:1404,y:890,t:1527271961804};\\\", \\\"{x:1401,y:890,t:1527271961821};\\\", \\\"{x:1401,y:891,t:1527271961840};\\\", \\\"{x:1402,y:891,t:1527271961945};\\\", \\\"{x:1413,y:891,t:1527271961954};\\\", \\\"{x:1431,y:886,t:1527271961972};\\\", \\\"{x:1455,y:881,t:1527271961987};\\\", \\\"{x:1498,y:876,t:1527271962005};\\\", \\\"{x:1511,y:866,t:1527271962022};\\\", \\\"{x:1543,y:866,t:1527271962037};\\\", \\\"{x:1571,y:866,t:1527271962054};\\\", \\\"{x:1592,y:866,t:1527271962072};\\\", \\\"{x:1607,y:866,t:1527271962088};\\\", \\\"{x:1625,y:865,t:1527271962104};\\\", \\\"{x:1633,y:864,t:1527271962121};\\\", \\\"{x:1636,y:862,t:1527271962138};\\\", \\\"{x:1638,y:861,t:1527271962154};\\\", \\\"{x:1639,y:861,t:1527271962171};\\\", \\\"{x:1641,y:861,t:1527271962189};\\\", \\\"{x:1645,y:861,t:1527271962204};\\\", \\\"{x:1651,y:861,t:1527271962221};\\\", \\\"{x:1658,y:861,t:1527271962238};\\\", \\\"{x:1666,y:861,t:1527271962254};\\\", \\\"{x:1668,y:861,t:1527271962272};\\\", \\\"{x:1669,y:861,t:1527271962289};\\\", \\\"{x:1670,y:861,t:1527271962337};\\\", \\\"{x:1672,y:861,t:1527271962355};\\\", \\\"{x:1673,y:858,t:1527271962371};\\\", \\\"{x:1673,y:855,t:1527271962389};\\\", \\\"{x:1673,y:854,t:1527271962405};\\\", \\\"{x:1673,y:852,t:1527271962421};\\\", \\\"{x:1673,y:851,t:1527271962438};\\\", \\\"{x:1671,y:848,t:1527271962457};\\\", \\\"{x:1669,y:846,t:1527271962472};\\\", \\\"{x:1666,y:842,t:1527271962489};\\\", \\\"{x:1662,y:840,t:1527271962505};\\\", \\\"{x:1659,y:838,t:1527271962522};\\\", \\\"{x:1658,y:835,t:1527271962537};\\\", \\\"{x:1655,y:832,t:1527271962555};\\\", \\\"{x:1650,y:826,t:1527271962570};\\\", \\\"{x:1644,y:818,t:1527271962588};\\\", \\\"{x:1635,y:808,t:1527271962605};\\\", \\\"{x:1628,y:801,t:1527271962621};\\\", \\\"{x:1617,y:792,t:1527271962638};\\\", \\\"{x:1610,y:784,t:1527271962655};\\\", \\\"{x:1599,y:778,t:1527271962671};\\\", \\\"{x:1592,y:773,t:1527271962688};\\\", \\\"{x:1591,y:771,t:1527271962705};\\\", \\\"{x:1590,y:771,t:1527271962720};\\\", \\\"{x:1589,y:771,t:1527271962776};\\\", \\\"{x:1588,y:771,t:1527271962788};\\\", \\\"{x:1587,y:771,t:1527271962809};\\\", \\\"{x:1585,y:771,t:1527271962822};\\\", \\\"{x:1584,y:771,t:1527271962838};\\\", \\\"{x:1581,y:772,t:1527271962855};\\\", \\\"{x:1572,y:775,t:1527271962872};\\\", \\\"{x:1562,y:779,t:1527271962888};\\\", \\\"{x:1538,y:791,t:1527271962905};\\\", \\\"{x:1527,y:796,t:1527271962922};\\\", \\\"{x:1518,y:802,t:1527271962938};\\\", \\\"{x:1503,y:810,t:1527271962955};\\\", \\\"{x:1489,y:817,t:1527271962972};\\\", \\\"{x:1472,y:821,t:1527271962988};\\\", \\\"{x:1461,y:826,t:1527271963005};\\\", \\\"{x:1449,y:830,t:1527271963022};\\\", \\\"{x:1436,y:835,t:1527271963038};\\\", \\\"{x:1418,y:838,t:1527271963055};\\\", \\\"{x:1400,y:843,t:1527271963073};\\\", \\\"{x:1389,y:846,t:1527271963088};\\\", \\\"{x:1377,y:848,t:1527271963105};\\\", \\\"{x:1372,y:849,t:1527271963122};\\\", \\\"{x:1367,y:849,t:1527271963139};\\\", \\\"{x:1365,y:850,t:1527271963156};\\\", \\\"{x:1364,y:850,t:1527271963172};\\\", \\\"{x:1361,y:851,t:1527271963189};\\\", \\\"{x:1359,y:851,t:1527271963205};\\\", \\\"{x:1356,y:851,t:1527271963222};\\\", \\\"{x:1355,y:851,t:1527271963240};\\\", \\\"{x:1353,y:851,t:1527271963273};\\\", \\\"{x:1351,y:847,t:1527271963289};\\\", \\\"{x:1350,y:842,t:1527271963306};\\\", \\\"{x:1349,y:833,t:1527271963322};\\\", \\\"{x:1349,y:817,t:1527271963340};\\\", \\\"{x:1350,y:799,t:1527271963355};\\\", \\\"{x:1356,y:787,t:1527271963372};\\\", \\\"{x:1365,y:777,t:1527271963390};\\\", \\\"{x:1373,y:768,t:1527271963406};\\\", \\\"{x:1377,y:765,t:1527271963423};\\\", \\\"{x:1380,y:762,t:1527271963440};\\\", \\\"{x:1382,y:757,t:1527271963457};\\\", \\\"{x:1386,y:748,t:1527271963473};\\\", \\\"{x:1390,y:738,t:1527271963490};\\\", \\\"{x:1394,y:726,t:1527271963506};\\\", \\\"{x:1398,y:718,t:1527271963522};\\\", \\\"{x:1402,y:709,t:1527271963539};\\\", \\\"{x:1404,y:703,t:1527271963556};\\\", \\\"{x:1406,y:696,t:1527271963572};\\\", \\\"{x:1412,y:686,t:1527271963589};\\\", \\\"{x:1414,y:680,t:1527271963606};\\\", \\\"{x:1417,y:668,t:1527271963621};\\\", \\\"{x:1421,y:656,t:1527271963639};\\\", \\\"{x:1426,y:635,t:1527271963656};\\\", \\\"{x:1429,y:623,t:1527271963672};\\\", \\\"{x:1432,y:617,t:1527271963689};\\\", \\\"{x:1433,y:609,t:1527271963706};\\\", \\\"{x:1435,y:602,t:1527271963722};\\\", \\\"{x:1437,y:597,t:1527271963739};\\\", \\\"{x:1438,y:590,t:1527271963756};\\\", \\\"{x:1439,y:581,t:1527271963773};\\\", \\\"{x:1440,y:572,t:1527271963789};\\\", \\\"{x:1440,y:568,t:1527271963806};\\\", \\\"{x:1440,y:564,t:1527271963823};\\\", \\\"{x:1440,y:558,t:1527271963839};\\\", \\\"{x:1440,y:553,t:1527271963856};\\\", \\\"{x:1441,y:547,t:1527271963872};\\\", \\\"{x:1444,y:542,t:1527271963889};\\\", \\\"{x:1445,y:537,t:1527271963906};\\\", \\\"{x:1446,y:534,t:1527271963923};\\\", \\\"{x:1448,y:533,t:1527271963939};\\\", \\\"{x:1454,y:529,t:1527271963956};\\\", \\\"{x:1456,y:528,t:1527271963973};\\\", \\\"{x:1459,y:525,t:1527271963989};\\\", \\\"{x:1463,y:523,t:1527271964006};\\\", \\\"{x:1470,y:522,t:1527271964023};\\\", \\\"{x:1479,y:519,t:1527271964039};\\\", \\\"{x:1484,y:517,t:1527271964056};\\\", \\\"{x:1486,y:517,t:1527271964073};\\\", \\\"{x:1489,y:515,t:1527271964090};\\\", \\\"{x:1493,y:514,t:1527271964106};\\\", \\\"{x:1498,y:511,t:1527271964123};\\\", \\\"{x:1501,y:510,t:1527271964140};\\\", \\\"{x:1503,y:505,t:1527271964156};\\\", \\\"{x:1507,y:498,t:1527271964173};\\\", \\\"{x:1510,y:491,t:1527271964190};\\\", \\\"{x:1510,y:484,t:1527271964207};\\\", \\\"{x:1512,y:474,t:1527271964223};\\\", \\\"{x:1512,y:458,t:1527271964241};\\\", \\\"{x:1512,y:443,t:1527271964257};\\\", \\\"{x:1507,y:421,t:1527271964273};\\\", \\\"{x:1498,y:398,t:1527271964290};\\\", \\\"{x:1496,y:384,t:1527271964306};\\\", \\\"{x:1491,y:374,t:1527271964323};\\\", \\\"{x:1488,y:366,t:1527271964340};\\\", \\\"{x:1488,y:363,t:1527271964356};\\\", \\\"{x:1487,y:359,t:1527271964374};\\\", \\\"{x:1482,y:354,t:1527271964390};\\\", \\\"{x:1480,y:350,t:1527271964407};\\\", \\\"{x:1480,y:346,t:1527271964424};\\\", \\\"{x:1480,y:344,t:1527271964441};\\\", \\\"{x:1480,y:343,t:1527271964498};\\\", \\\"{x:1479,y:342,t:1527271964507};\\\", \\\"{x:1479,y:341,t:1527271964523};\\\", \\\"{x:1479,y:340,t:1527271964540};\\\", \\\"{x:1479,y:338,t:1527271964557};\\\", \\\"{x:1479,y:337,t:1527271964573};\\\", \\\"{x:1479,y:336,t:1527271964590};\\\", \\\"{x:1479,y:335,t:1527271964608};\\\", \\\"{x:1479,y:334,t:1527271965641};\\\", \\\"{x:1478,y:334,t:1527271965673};\\\", \\\"{x:1477,y:334,t:1527271965689};\\\", \\\"{x:1476,y:336,t:1527271965705};\\\", \\\"{x:1474,y:338,t:1527271965721};\\\", \\\"{x:1473,y:338,t:1527271965729};\\\", \\\"{x:1472,y:339,t:1527271965742};\\\", \\\"{x:1472,y:341,t:1527271965758};\\\", \\\"{x:1470,y:341,t:1527271965776};\\\", \\\"{x:1469,y:344,t:1527271965792};\\\", \\\"{x:1466,y:349,t:1527271965809};\\\", \\\"{x:1463,y:357,t:1527271965826};\\\", \\\"{x:1460,y:361,t:1527271965842};\\\", \\\"{x:1456,y:368,t:1527271965859};\\\", \\\"{x:1453,y:373,t:1527271965875};\\\", \\\"{x:1448,y:380,t:1527271965892};\\\", \\\"{x:1445,y:385,t:1527271965908};\\\", \\\"{x:1442,y:396,t:1527271965926};\\\", \\\"{x:1432,y:413,t:1527271965941};\\\", \\\"{x:1426,y:427,t:1527271965958};\\\", \\\"{x:1419,y:447,t:1527271965976};\\\", \\\"{x:1411,y:468,t:1527271965992};\\\", \\\"{x:1399,y:502,t:1527271966009};\\\", \\\"{x:1390,y:523,t:1527271966025};\\\", \\\"{x:1385,y:539,t:1527271966042};\\\", \\\"{x:1381,y:546,t:1527271966058};\\\", \\\"{x:1379,y:555,t:1527271966076};\\\", \\\"{x:1376,y:566,t:1527271966093};\\\", \\\"{x:1371,y:575,t:1527271966108};\\\", \\\"{x:1366,y:581,t:1527271966126};\\\", \\\"{x:1360,y:586,t:1527271966143};\\\", \\\"{x:1356,y:590,t:1527271966158};\\\", \\\"{x:1352,y:593,t:1527271966176};\\\", \\\"{x:1345,y:598,t:1527271966193};\\\", \\\"{x:1337,y:600,t:1527271966209};\\\", \\\"{x:1333,y:603,t:1527271966226};\\\", \\\"{x:1329,y:606,t:1527271966243};\\\", \\\"{x:1326,y:608,t:1527271966259};\\\", \\\"{x:1325,y:608,t:1527271966276};\\\", \\\"{x:1322,y:609,t:1527271966293};\\\", \\\"{x:1319,y:611,t:1527271966308};\\\", \\\"{x:1311,y:615,t:1527271966326};\\\", \\\"{x:1307,y:618,t:1527271966342};\\\", \\\"{x:1303,y:621,t:1527271966359};\\\", \\\"{x:1299,y:623,t:1527271966376};\\\", \\\"{x:1296,y:628,t:1527271966393};\\\", \\\"{x:1294,y:631,t:1527271966409};\\\", \\\"{x:1292,y:635,t:1527271966426};\\\", \\\"{x:1291,y:636,t:1527271966442};\\\", \\\"{x:1291,y:637,t:1527271966460};\\\", \\\"{x:1291,y:638,t:1527271966476};\\\", \\\"{x:1291,y:639,t:1527271966493};\\\", \\\"{x:1291,y:640,t:1527271966510};\\\", \\\"{x:1291,y:642,t:1527271966526};\\\", \\\"{x:1291,y:644,t:1527271966543};\\\", \\\"{x:1291,y:646,t:1527271966560};\\\", \\\"{x:1292,y:648,t:1527271966576};\\\", \\\"{x:1295,y:655,t:1527271966593};\\\", \\\"{x:1299,y:661,t:1527271966609};\\\", \\\"{x:1299,y:669,t:1527271966626};\\\", \\\"{x:1302,y:681,t:1527271966643};\\\", \\\"{x:1303,y:690,t:1527271966660};\\\", \\\"{x:1305,y:696,t:1527271966676};\\\", \\\"{x:1305,y:703,t:1527271966693};\\\", \\\"{x:1308,y:710,t:1527271966710};\\\", \\\"{x:1308,y:717,t:1527271966726};\\\", \\\"{x:1308,y:724,t:1527271966742};\\\", \\\"{x:1308,y:732,t:1527271966760};\\\", \\\"{x:1310,y:753,t:1527271966777};\\\", \\\"{x:1312,y:765,t:1527271966793};\\\", \\\"{x:1313,y:775,t:1527271966810};\\\", \\\"{x:1317,y:784,t:1527271966826};\\\", \\\"{x:1318,y:789,t:1527271966843};\\\", \\\"{x:1322,y:797,t:1527271966859};\\\", \\\"{x:1326,y:803,t:1527271966876};\\\", \\\"{x:1331,y:810,t:1527271966892};\\\", \\\"{x:1340,y:821,t:1527271966909};\\\", \\\"{x:1350,y:830,t:1527271966926};\\\", \\\"{x:1360,y:839,t:1527271966942};\\\", \\\"{x:1366,y:844,t:1527271966959};\\\", \\\"{x:1374,y:851,t:1527271966976};\\\", \\\"{x:1378,y:855,t:1527271966992};\\\", \\\"{x:1381,y:860,t:1527271967009};\\\", \\\"{x:1384,y:866,t:1527271967026};\\\", \\\"{x:1391,y:874,t:1527271967042};\\\", \\\"{x:1396,y:881,t:1527271967059};\\\", \\\"{x:1401,y:886,t:1527271967076};\\\", \\\"{x:1406,y:890,t:1527271967093};\\\", \\\"{x:1407,y:891,t:1527271967109};\\\", \\\"{x:1409,y:893,t:1527271967126};\\\", \\\"{x:1410,y:893,t:1527271967185};\\\", \\\"{x:1411,y:893,t:1527271967216};\\\", \\\"{x:1412,y:893,t:1527271967226};\\\", \\\"{x:1416,y:893,t:1527271967243};\\\", \\\"{x:1420,y:890,t:1527271967259};\\\", \\\"{x:1425,y:887,t:1527271967276};\\\", \\\"{x:1428,y:886,t:1527271967294};\\\", \\\"{x:1431,y:884,t:1527271967309};\\\", \\\"{x:1435,y:881,t:1527271967327};\\\", \\\"{x:1437,y:880,t:1527271967344};\\\", \\\"{x:1441,y:875,t:1527271967360};\\\", \\\"{x:1449,y:870,t:1527271967377};\\\", \\\"{x:1456,y:867,t:1527271967393};\\\", \\\"{x:1462,y:865,t:1527271967410};\\\", \\\"{x:1466,y:863,t:1527271967427};\\\", \\\"{x:1476,y:863,t:1527271967443};\\\", \\\"{x:1494,y:862,t:1527271967460};\\\", \\\"{x:1506,y:862,t:1527271967477};\\\", \\\"{x:1522,y:862,t:1527271967493};\\\", \\\"{x:1542,y:862,t:1527271967510};\\\", \\\"{x:1558,y:862,t:1527271967526};\\\", \\\"{x:1566,y:862,t:1527271967544};\\\", \\\"{x:1581,y:860,t:1527271967560};\\\", \\\"{x:1588,y:857,t:1527271967576};\\\", \\\"{x:1594,y:856,t:1527271967594};\\\", \\\"{x:1598,y:854,t:1527271967610};\\\", \\\"{x:1603,y:853,t:1527271967626};\\\", \\\"{x:1606,y:852,t:1527271967644};\\\", \\\"{x:1608,y:850,t:1527271967660};\\\", \\\"{x:1611,y:847,t:1527271967677};\\\", \\\"{x:1614,y:845,t:1527271967694};\\\", \\\"{x:1617,y:838,t:1527271967710};\\\", \\\"{x:1618,y:837,t:1527271967727};\\\", \\\"{x:1618,y:835,t:1527271967744};\\\", \\\"{x:1619,y:830,t:1527271967761};\\\", \\\"{x:1619,y:828,t:1527271967777};\\\", \\\"{x:1619,y:821,t:1527271967793};\\\", \\\"{x:1619,y:813,t:1527271967811};\\\", \\\"{x:1620,y:810,t:1527271967828};\\\", \\\"{x:1620,y:806,t:1527271967844};\\\", \\\"{x:1620,y:801,t:1527271967860};\\\", \\\"{x:1620,y:795,t:1527271967878};\\\", \\\"{x:1619,y:789,t:1527271967894};\\\", \\\"{x:1618,y:779,t:1527271967910};\\\", \\\"{x:1615,y:765,t:1527271967928};\\\", \\\"{x:1611,y:752,t:1527271967944};\\\", \\\"{x:1607,y:739,t:1527271967961};\\\", \\\"{x:1606,y:734,t:1527271967977};\\\", \\\"{x:1606,y:727,t:1527271967994};\\\", \\\"{x:1605,y:721,t:1527271968011};\\\", \\\"{x:1603,y:718,t:1527271968028};\\\", \\\"{x:1603,y:716,t:1527271968043};\\\", \\\"{x:1602,y:715,t:1527271968061};\\\", \\\"{x:1602,y:713,t:1527271968106};\\\", \\\"{x:1602,y:712,t:1527271968121};\\\", \\\"{x:1602,y:710,t:1527271968145};\\\", \\\"{x:1602,y:709,t:1527271968201};\\\", \\\"{x:1602,y:707,t:1527271968233};\\\", \\\"{x:1602,y:705,t:1527271968249};\\\", \\\"{x:1604,y:705,t:1527271968265};\\\", \\\"{x:1604,y:704,t:1527271968289};\\\", \\\"{x:1605,y:702,t:1527271968465};\\\", \\\"{x:1606,y:702,t:1527271968520};\\\", \\\"{x:1606,y:701,t:1527271968527};\\\", \\\"{x:1606,y:700,t:1527271968544};\\\", \\\"{x:1608,y:699,t:1527271968561};\\\", \\\"{x:1609,y:699,t:1527271968584};\\\", \\\"{x:1609,y:698,t:1527271968594};\\\", \\\"{x:1609,y:697,t:1527271968736};\\\", \\\"{x:1609,y:696,t:1527271969713};\\\", \\\"{x:1614,y:694,t:1527271969728};\\\", \\\"{x:1616,y:693,t:1527271969745};\\\", \\\"{x:1617,y:693,t:1527271969762};\\\", \\\"{x:1618,y:693,t:1527271972930};\\\", \\\"{x:1618,y:694,t:1527271972944};\\\", \\\"{x:1620,y:695,t:1527271972952};\\\", \\\"{x:1620,y:697,t:1527271972968};\\\", \\\"{x:1620,y:698,t:1527271973417};\\\", \\\"{x:1620,y:699,t:1527271973442};\\\", \\\"{x:1620,y:700,t:1527271973450};\\\", \\\"{x:1620,y:701,t:1527271973473};\\\", \\\"{x:1620,y:702,t:1527271973483};\\\", \\\"{x:1620,y:703,t:1527271973500};\\\", \\\"{x:1621,y:704,t:1527271973520};\\\", \\\"{x:1621,y:705,t:1527271973544};\\\", \\\"{x:1621,y:706,t:1527271973576};\\\", \\\"{x:1621,y:704,t:1527271973818};\\\", \\\"{x:1621,y:701,t:1527271973834};\\\", \\\"{x:1621,y:695,t:1527271973850};\\\", \\\"{x:1618,y:691,t:1527271973867};\\\", \\\"{x:1618,y:688,t:1527271973884};\\\", \\\"{x:1618,y:687,t:1527271973901};\\\", \\\"{x:1617,y:684,t:1527271973917};\\\", \\\"{x:1616,y:683,t:1527271973933};\\\", \\\"{x:1615,y:681,t:1527271973949};\\\", \\\"{x:1612,y:676,t:1527271973967};\\\", \\\"{x:1608,y:670,t:1527271973983};\\\", \\\"{x:1604,y:665,t:1527271973999};\\\", \\\"{x:1600,y:656,t:1527271974016};\\\", \\\"{x:1596,y:651,t:1527271974033};\\\", \\\"{x:1594,y:647,t:1527271974049};\\\", \\\"{x:1592,y:645,t:1527271974066};\\\", \\\"{x:1587,y:639,t:1527271974083};\\\", \\\"{x:1583,y:635,t:1527271974100};\\\", \\\"{x:1583,y:634,t:1527271974116};\\\", \\\"{x:1582,y:633,t:1527271974133};\\\", \\\"{x:1581,y:632,t:1527271974152};\\\", \\\"{x:1581,y:631,t:1527271974168};\\\", \\\"{x:1581,y:629,t:1527271974200};\\\", \\\"{x:1581,y:628,t:1527271974241};\\\", \\\"{x:1581,y:629,t:1527271974425};\\\", \\\"{x:1582,y:632,t:1527271974434};\\\", \\\"{x:1582,y:636,t:1527271974450};\\\", \\\"{x:1586,y:643,t:1527271974467};\\\", \\\"{x:1587,y:646,t:1527271974483};\\\", \\\"{x:1589,y:650,t:1527271974500};\\\", \\\"{x:1590,y:654,t:1527271974517};\\\", \\\"{x:1592,y:659,t:1527271974533};\\\", \\\"{x:1594,y:662,t:1527271974550};\\\", \\\"{x:1594,y:666,t:1527271974567};\\\", \\\"{x:1594,y:670,t:1527271974584};\\\", \\\"{x:1595,y:673,t:1527271974601};\\\", \\\"{x:1596,y:676,t:1527271974617};\\\", \\\"{x:1598,y:679,t:1527271974633};\\\", \\\"{x:1600,y:685,t:1527271974651};\\\", \\\"{x:1601,y:690,t:1527271974668};\\\", \\\"{x:1602,y:696,t:1527271974684};\\\", \\\"{x:1605,y:701,t:1527271974701};\\\", \\\"{x:1608,y:708,t:1527271974717};\\\", \\\"{x:1609,y:712,t:1527271974734};\\\", \\\"{x:1609,y:716,t:1527271974750};\\\", \\\"{x:1610,y:722,t:1527271974768};\\\", \\\"{x:1610,y:726,t:1527271974784};\\\", \\\"{x:1611,y:730,t:1527271974800};\\\", \\\"{x:1612,y:736,t:1527271974818};\\\", \\\"{x:1613,y:740,t:1527271974834};\\\", \\\"{x:1614,y:742,t:1527271974851};\\\", \\\"{x:1614,y:744,t:1527271974867};\\\", \\\"{x:1616,y:747,t:1527271974884};\\\", \\\"{x:1621,y:754,t:1527271974900};\\\", \\\"{x:1623,y:759,t:1527271974917};\\\", \\\"{x:1628,y:765,t:1527271974934};\\\", \\\"{x:1631,y:770,t:1527271974951};\\\", \\\"{x:1637,y:777,t:1527271974967};\\\", \\\"{x:1639,y:781,t:1527271974984};\\\", \\\"{x:1647,y:790,t:1527271975000};\\\", \\\"{x:1658,y:804,t:1527271975017};\\\", \\\"{x:1662,y:812,t:1527271975034};\\\", \\\"{x:1670,y:823,t:1527271975051};\\\", \\\"{x:1679,y:834,t:1527271975068};\\\", \\\"{x:1685,y:843,t:1527271975084};\\\", \\\"{x:1689,y:852,t:1527271975100};\\\", \\\"{x:1693,y:858,t:1527271975118};\\\", \\\"{x:1694,y:861,t:1527271975134};\\\", \\\"{x:1695,y:864,t:1527271975152};\\\", \\\"{x:1695,y:867,t:1527271975168};\\\", \\\"{x:1697,y:869,t:1527271975184};\\\", \\\"{x:1697,y:873,t:1527271975202};\\\", \\\"{x:1698,y:875,t:1527271975217};\\\", \\\"{x:1699,y:878,t:1527271975235};\\\", \\\"{x:1700,y:879,t:1527271975252};\\\", \\\"{x:1701,y:879,t:1527271975268};\\\", \\\"{x:1703,y:881,t:1527271975450};\\\", \\\"{x:1703,y:882,t:1527271975455};\\\", \\\"{x:1704,y:883,t:1527271975468};\\\", \\\"{x:1706,y:884,t:1527271975484};\\\", \\\"{x:1709,y:885,t:1527271975501};\\\", \\\"{x:1710,y:886,t:1527271975519};\\\", \\\"{x:1712,y:886,t:1527271975576};\\\", \\\"{x:1713,y:886,t:1527271975584};\\\", \\\"{x:1714,y:882,t:1527271975602};\\\", \\\"{x:1717,y:878,t:1527271975618};\\\", \\\"{x:1717,y:876,t:1527271975634};\\\", \\\"{x:1717,y:873,t:1527271975651};\\\", \\\"{x:1717,y:870,t:1527271975669};\\\", \\\"{x:1717,y:865,t:1527271975684};\\\", \\\"{x:1715,y:861,t:1527271975701};\\\", \\\"{x:1711,y:853,t:1527271975718};\\\", \\\"{x:1706,y:846,t:1527271975735};\\\", \\\"{x:1702,y:841,t:1527271975751};\\\", \\\"{x:1699,y:837,t:1527271975768};\\\", \\\"{x:1696,y:836,t:1527271975785};\\\", \\\"{x:1695,y:834,t:1527271975801};\\\", \\\"{x:1694,y:830,t:1527271975819};\\\", \\\"{x:1692,y:828,t:1527271975835};\\\", \\\"{x:1689,y:824,t:1527271975852};\\\", \\\"{x:1687,y:822,t:1527271975868};\\\", \\\"{x:1686,y:822,t:1527271975954};\\\", \\\"{x:1685,y:822,t:1527271975993};\\\", \\\"{x:1686,y:822,t:1527271976401};\\\", \\\"{x:1687,y:823,t:1527271976432};\\\", \\\"{x:1688,y:823,t:1527271976473};\\\", \\\"{x:1688,y:824,t:1527271976497};\\\", \\\"{x:1689,y:825,t:1527271976505};\\\", \\\"{x:1690,y:826,t:1527271976561};\\\", \\\"{x:1687,y:822,t:1527271976826};\\\", \\\"{x:1684,y:816,t:1527271976837};\\\", \\\"{x:1679,y:799,t:1527271976854};\\\", \\\"{x:1667,y:778,t:1527271976870};\\\", \\\"{x:1648,y:752,t:1527271976887};\\\", \\\"{x:1616,y:714,t:1527271976903};\\\", \\\"{x:1609,y:696,t:1527271976920};\\\", \\\"{x:1598,y:682,t:1527271976937};\\\", \\\"{x:1588,y:677,t:1527271976952};\\\", \\\"{x:1578,y:674,t:1527271976970};\\\", \\\"{x:1555,y:673,t:1527271976987};\\\", \\\"{x:1524,y:672,t:1527271977003};\\\", \\\"{x:1489,y:665,t:1527271977019};\\\", \\\"{x:1451,y:657,t:1527271977037};\\\", \\\"{x:1408,y:650,t:1527271977053};\\\", \\\"{x:1381,y:650,t:1527271977070};\\\", \\\"{x:1333,y:650,t:1527271977087};\\\", \\\"{x:1296,y:650,t:1527271977103};\\\", \\\"{x:1271,y:650,t:1527271977120};\\\", \\\"{x:1209,y:653,t:1527271977136};\\\", \\\"{x:1159,y:661,t:1527271977154};\\\", \\\"{x:1102,y:662,t:1527271977170};\\\", \\\"{x:1048,y:665,t:1527271977187};\\\", \\\"{x:970,y:665,t:1527271977204};\\\", \\\"{x:930,y:665,t:1527271977220};\\\", \\\"{x:897,y:665,t:1527271977237};\\\", \\\"{x:874,y:665,t:1527271977253};\\\", \\\"{x:847,y:665,t:1527271977270};\\\", \\\"{x:815,y:665,t:1527271977287};\\\", \\\"{x:806,y:665,t:1527271977304};\\\", \\\"{x:777,y:665,t:1527271977320};\\\", \\\"{x:754,y:668,t:1527271977337};\\\", \\\"{x:751,y:669,t:1527271977354};\\\", \\\"{x:748,y:669,t:1527271977921};\\\", \\\"{x:732,y:672,t:1527271977938};\\\", \\\"{x:711,y:661,t:1527271977953};\\\", \\\"{x:695,y:653,t:1527271977970};\\\", \\\"{x:649,y:634,t:1527271977987};\\\", \\\"{x:578,y:619,t:1527271978004};\\\", \\\"{x:542,y:605,t:1527271978020};\\\", \\\"{x:524,y:599,t:1527271978038};\\\", \\\"{x:507,y:597,t:1527271978049};\\\", \\\"{x:497,y:596,t:1527271978065};\\\", \\\"{x:495,y:596,t:1527271978083};\\\", \\\"{x:493,y:596,t:1527271978100};\\\", \\\"{x:493,y:601,t:1527271978116};\\\", \\\"{x:493,y:606,t:1527271978132};\\\", \\\"{x:496,y:609,t:1527271978150};\\\", \\\"{x:498,y:610,t:1527271978165};\\\", \\\"{x:498,y:611,t:1527271978182};\\\", \\\"{x:500,y:611,t:1527271978200};\\\", \\\"{x:501,y:611,t:1527271978215};\\\", \\\"{x:506,y:608,t:1527271978232};\\\", \\\"{x:507,y:604,t:1527271978250};\\\", \\\"{x:510,y:598,t:1527271978266};\\\", \\\"{x:512,y:593,t:1527271978283};\\\", \\\"{x:513,y:590,t:1527271978299};\\\", \\\"{x:511,y:586,t:1527271978320};\\\", \\\"{x:508,y:585,t:1527271978332};\\\", \\\"{x:496,y:585,t:1527271978351};\\\", \\\"{x:479,y:585,t:1527271978365};\\\", \\\"{x:460,y:583,t:1527271978382};\\\", \\\"{x:422,y:577,t:1527271978399};\\\", \\\"{x:377,y:566,t:1527271978416};\\\", \\\"{x:361,y:564,t:1527271978433};\\\", \\\"{x:356,y:561,t:1527271978450};\\\", \\\"{x:355,y:561,t:1527271978467};\\\", \\\"{x:354,y:560,t:1527271978512};\\\", \\\"{x:354,y:559,t:1527271978528};\\\", \\\"{x:354,y:557,t:1527271978535};\\\", \\\"{x:359,y:555,t:1527271978550};\\\", \\\"{x:372,y:550,t:1527271978566};\\\", \\\"{x:381,y:547,t:1527271978583};\\\", \\\"{x:391,y:544,t:1527271978600};\\\", \\\"{x:400,y:542,t:1527271978616};\\\", \\\"{x:403,y:542,t:1527271978633};\\\", \\\"{x:404,y:541,t:1527271978650};\\\", \\\"{x:398,y:543,t:1527271978688};\\\", \\\"{x:392,y:547,t:1527271978699};\\\", \\\"{x:371,y:556,t:1527271978717};\\\", \\\"{x:348,y:561,t:1527271978733};\\\", \\\"{x:331,y:563,t:1527271978749};\\\", \\\"{x:311,y:564,t:1527271978766};\\\", \\\"{x:295,y:564,t:1527271978782};\\\", \\\"{x:271,y:565,t:1527271978800};\\\", \\\"{x:255,y:565,t:1527271978817};\\\", \\\"{x:241,y:563,t:1527271978832};\\\", \\\"{x:238,y:563,t:1527271978850};\\\", \\\"{x:224,y:562,t:1527271978867};\\\", \\\"{x:221,y:561,t:1527271978883};\\\", \\\"{x:208,y:558,t:1527271978900};\\\", \\\"{x:193,y:557,t:1527271978917};\\\", \\\"{x:189,y:557,t:1527271978934};\\\", \\\"{x:178,y:557,t:1527271978949};\\\", \\\"{x:166,y:556,t:1527271978966};\\\", \\\"{x:164,y:556,t:1527271978983};\\\", \\\"{x:162,y:556,t:1527271978999};\\\", \\\"{x:161,y:556,t:1527271979017};\\\", \\\"{x:161,y:560,t:1527271979034};\\\", \\\"{x:159,y:567,t:1527271979050};\\\", \\\"{x:157,y:574,t:1527271979067};\\\", \\\"{x:154,y:584,t:1527271979083};\\\", \\\"{x:146,y:602,t:1527271979102};\\\", \\\"{x:140,y:625,t:1527271979116};\\\", \\\"{x:139,y:643,t:1527271979134};\\\", \\\"{x:139,y:649,t:1527271979150};\\\", \\\"{x:139,y:653,t:1527271979167};\\\", \\\"{x:140,y:653,t:1527271979337};\\\", \\\"{x:141,y:653,t:1527271979351};\\\", \\\"{x:143,y:652,t:1527271979367};\\\", \\\"{x:146,y:651,t:1527271979384};\\\", \\\"{x:151,y:650,t:1527271979401};\\\", \\\"{x:155,y:649,t:1527271979417};\\\", \\\"{x:157,y:649,t:1527271979434};\\\", \\\"{x:158,y:649,t:1527271979497};\\\", \\\"{x:160,y:649,t:1527271979504};\\\", \\\"{x:161,y:649,t:1527271979517};\\\", \\\"{x:163,y:649,t:1527271979838};\\\", \\\"{x:164,y:649,t:1527271979849};\\\", \\\"{x:174,y:644,t:1527271979866};\\\", \\\"{x:200,y:641,t:1527271979882};\\\", \\\"{x:221,y:637,t:1527271979900};\\\", \\\"{x:255,y:636,t:1527271979916};\\\", \\\"{x:297,y:636,t:1527271979932};\\\", \\\"{x:321,y:636,t:1527271979949};\\\", \\\"{x:351,y:634,t:1527271979966};\\\", \\\"{x:380,y:628,t:1527271979983};\\\", \\\"{x:440,y:620,t:1527271979999};\\\", \\\"{x:476,y:610,t:1527271980016};\\\", \\\"{x:507,y:601,t:1527271980033};\\\", \\\"{x:517,y:592,t:1527271980049};\\\", \\\"{x:544,y:590,t:1527271980066};\\\", \\\"{x:571,y:585,t:1527271980082};\\\", \\\"{x:579,y:585,t:1527271980098};\\\", \\\"{x:606,y:575,t:1527271980116};\\\", \\\"{x:629,y:568,t:1527271980133};\\\", \\\"{x:648,y:559,t:1527271980150};\\\", \\\"{x:676,y:547,t:1527271980167};\\\", \\\"{x:687,y:542,t:1527271980182};\\\", \\\"{x:698,y:534,t:1527271980199};\\\", \\\"{x:705,y:533,t:1527271980216};\\\", \\\"{x:710,y:527,t:1527271980233};\\\", \\\"{x:718,y:520,t:1527271980250};\\\", \\\"{x:721,y:517,t:1527271980267};\\\", \\\"{x:724,y:513,t:1527271980284};\\\", \\\"{x:730,y:508,t:1527271980300};\\\", \\\"{x:740,y:499,t:1527271980316};\\\", \\\"{x:748,y:494,t:1527271980333};\\\", \\\"{x:755,y:490,t:1527271980349};\\\", \\\"{x:760,y:489,t:1527271980366};\\\", \\\"{x:760,y:494,t:1527271980407};\\\", \\\"{x:759,y:506,t:1527271980417};\\\", \\\"{x:736,y:531,t:1527271980435};\\\", \\\"{x:716,y:544,t:1527271980450};\\\", \\\"{x:703,y:552,t:1527271980466};\\\", \\\"{x:693,y:553,t:1527271980483};\\\", \\\"{x:679,y:554,t:1527271980499};\\\", \\\"{x:662,y:557,t:1527271980517};\\\", \\\"{x:652,y:557,t:1527271980533};\\\", \\\"{x:638,y:557,t:1527271980549};\\\", \\\"{x:620,y:557,t:1527271980566};\\\", \\\"{x:619,y:557,t:1527271980583};\\\", \\\"{x:617,y:557,t:1527271980599};\\\", \\\"{x:613,y:557,t:1527271980616};\\\", \\\"{x:609,y:557,t:1527271980672};\\\", \\\"{x:606,y:557,t:1527271980683};\\\", \\\"{x:601,y:560,t:1527271980700};\\\", \\\"{x:599,y:563,t:1527271980717};\\\", \\\"{x:598,y:564,t:1527271980733};\\\", \\\"{x:598,y:567,t:1527271980751};\\\", \\\"{x:600,y:573,t:1527271980767};\\\", \\\"{x:604,y:581,t:1527271980783};\\\", \\\"{x:608,y:589,t:1527271980800};\\\", \\\"{x:612,y:593,t:1527271980816};\\\", \\\"{x:613,y:594,t:1527271980846};\\\", \\\"{x:613,y:597,t:1527271980878};\\\", \\\"{x:614,y:598,t:1527271980886};\\\", \\\"{x:616,y:601,t:1527271980900};\\\", \\\"{x:616,y:603,t:1527271980916};\\\", \\\"{x:616,y:605,t:1527271980935};\\\", \\\"{x:616,y:608,t:1527271980950};\\\", \\\"{x:616,y:610,t:1527271980966};\\\", \\\"{x:616,y:611,t:1527271980983};\\\", \\\"{x:616,y:612,t:1527271980999};\\\", \\\"{x:616,y:613,t:1527271981016};\\\", \\\"{x:616,y:614,t:1527271981033};\\\", \\\"{x:616,y:617,t:1527271981050};\\\", \\\"{x:617,y:619,t:1527271981067};\\\", \\\"{x:618,y:622,t:1527271981366};\\\", \\\"{x:607,y:633,t:1527271981384};\\\", \\\"{x:597,y:642,t:1527271981399};\\\", \\\"{x:586,y:654,t:1527271981417};\\\", \\\"{x:574,y:669,t:1527271981433};\\\", \\\"{x:566,y:681,t:1527271981450};\\\", \\\"{x:560,y:691,t:1527271981467};\\\", \\\"{x:554,y:702,t:1527271981484};\\\", \\\"{x:551,y:711,t:1527271981500};\\\", \\\"{x:543,y:722,t:1527271981518};\\\", \\\"{x:536,y:730,t:1527271981534};\\\", \\\"{x:533,y:735,t:1527271981550};\\\", \\\"{x:525,y:742,t:1527271981566};\\\", \\\"{x:519,y:748,t:1527271981584};\\\", \\\"{x:516,y:749,t:1527271981600};\\\", \\\"{x:512,y:749,t:1527271981617};\\\", \\\"{x:511,y:749,t:1527271981646};\\\", \\\"{x:510,y:749,t:1527271981846};\\\", \\\"{x:512,y:749,t:1527271982319};\\\", \\\"{x:512,y:747,t:1527271982391};\\\", \\\"{x:514,y:743,t:1527271982401};\\\", \\\"{x:518,y:736,t:1527271982418};\\\", \\\"{x:525,y:728,t:1527271982434};\\\", \\\"{x:531,y:725,t:1527271982451};\\\", \\\"{x:538,y:722,t:1527271982468};\\\", \\\"{x:544,y:722,t:1527271982484};\\\", \\\"{x:550,y:721,t:1527271982501};\\\", \\\"{x:555,y:720,t:1527271982518};\\\", \\\"{x:558,y:718,t:1527271982534};\\\", \\\"{x:559,y:718,t:1527271982551};\\\", \\\"{x:563,y:715,t:1527271982568};\\\", \\\"{x:567,y:713,t:1527271982585};\\\", \\\"{x:571,y:710,t:1527271982601};\\\", \\\"{x:573,y:709,t:1527271982619};\\\", \\\"{x:577,y:707,t:1527271982634};\\\", \\\"{x:581,y:704,t:1527271982652};\\\", \\\"{x:586,y:701,t:1527271982668};\\\", \\\"{x:589,y:698,t:1527271982684};\\\", \\\"{x:592,y:696,t:1527271982701};\\\", \\\"{x:596,y:694,t:1527271982719};\\\", \\\"{x:598,y:692,t:1527271982735};\\\", \\\"{x:605,y:687,t:1527271982751};\\\", \\\"{x:610,y:683,t:1527271982768};\\\", \\\"{x:622,y:678,t:1527271982785};\\\", \\\"{x:628,y:676,t:1527271982809};\\\" ] }, { \\\"rt\\\": 9330, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 672311, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:631,y:675,t:1527271982990};\\\", \\\"{x:632,y:675,t:1527271984703};\\\", \\\"{x:641,y:669,t:1527271984719};\\\", \\\"{x:655,y:659,t:1527271984736};\\\", \\\"{x:671,y:648,t:1527271984753};\\\", \\\"{x:685,y:640,t:1527271984769};\\\", \\\"{x:705,y:630,t:1527271984787};\\\", \\\"{x:717,y:623,t:1527271984803};\\\", \\\"{x:729,y:620,t:1527271984820};\\\", \\\"{x:740,y:615,t:1527271984836};\\\", \\\"{x:742,y:614,t:1527271984853};\\\", \\\"{x:748,y:611,t:1527271984870};\\\", \\\"{x:752,y:608,t:1527271984886};\\\", \\\"{x:760,y:598,t:1527271984903};\\\", \\\"{x:765,y:590,t:1527271984920};\\\", \\\"{x:771,y:584,t:1527271984935};\\\", \\\"{x:775,y:580,t:1527271984953};\\\", \\\"{x:777,y:579,t:1527271984969};\\\", \\\"{x:780,y:579,t:1527271984986};\\\", \\\"{x:786,y:577,t:1527271985003};\\\", \\\"{x:793,y:575,t:1527271985019};\\\", \\\"{x:801,y:575,t:1527271985036};\\\", \\\"{x:810,y:576,t:1527271985053};\\\", \\\"{x:824,y:577,t:1527271985069};\\\", \\\"{x:864,y:578,t:1527271985086};\\\", \\\"{x:927,y:578,t:1527271985103};\\\", \\\"{x:1002,y:578,t:1527271985121};\\\", \\\"{x:1068,y:578,t:1527271985136};\\\", \\\"{x:1148,y:595,t:1527271985153};\\\", \\\"{x:1233,y:617,t:1527271985170};\\\", \\\"{x:1317,y:642,t:1527271985186};\\\", \\\"{x:1366,y:661,t:1527271985203};\\\", \\\"{x:1429,y:697,t:1527271985220};\\\", \\\"{x:1480,y:725,t:1527271985238};\\\", \\\"{x:1497,y:739,t:1527271985253};\\\", \\\"{x:1510,y:761,t:1527271985271};\\\", \\\"{x:1516,y:775,t:1527271985288};\\\", \\\"{x:1521,y:789,t:1527271985303};\\\", \\\"{x:1522,y:799,t:1527271985320};\\\", \\\"{x:1522,y:803,t:1527271985337};\\\", \\\"{x:1522,y:805,t:1527271985358};\\\", \\\"{x:1522,y:806,t:1527271985370};\\\", \\\"{x:1522,y:812,t:1527271985387};\\\", \\\"{x:1517,y:824,t:1527271985403};\\\", \\\"{x:1511,y:835,t:1527271985420};\\\", \\\"{x:1507,y:845,t:1527271985437};\\\", \\\"{x:1501,y:858,t:1527271985453};\\\", \\\"{x:1494,y:870,t:1527271985470};\\\", \\\"{x:1492,y:875,t:1527271985487};\\\", \\\"{x:1489,y:877,t:1527271985504};\\\", \\\"{x:1489,y:879,t:1527271985520};\\\", \\\"{x:1489,y:886,t:1527271985537};\\\", \\\"{x:1490,y:891,t:1527271985554};\\\", \\\"{x:1493,y:894,t:1527271985570};\\\", \\\"{x:1494,y:901,t:1527271985587};\\\", \\\"{x:1499,y:907,t:1527271985604};\\\", \\\"{x:1501,y:916,t:1527271985620};\\\", \\\"{x:1503,y:920,t:1527271985637};\\\", \\\"{x:1506,y:927,t:1527271985654};\\\", \\\"{x:1507,y:928,t:1527271985670};\\\", \\\"{x:1507,y:930,t:1527271985687};\\\", \\\"{x:1509,y:931,t:1527271985735};\\\", \\\"{x:1514,y:935,t:1527271985743};\\\", \\\"{x:1515,y:937,t:1527271985754};\\\", \\\"{x:1521,y:945,t:1527271985772};\\\", \\\"{x:1531,y:951,t:1527271985787};\\\", \\\"{x:1537,y:954,t:1527271985805};\\\", \\\"{x:1543,y:956,t:1527271985821};\\\", \\\"{x:1543,y:957,t:1527271986007};\\\", \\\"{x:1544,y:957,t:1527271986022};\\\", \\\"{x:1544,y:956,t:1527271986038};\\\", \\\"{x:1544,y:954,t:1527271986054};\\\", \\\"{x:1544,y:950,t:1527271986071};\\\", \\\"{x:1544,y:948,t:1527271986093};\\\", \\\"{x:1543,y:947,t:1527271986104};\\\", \\\"{x:1541,y:943,t:1527271986121};\\\", \\\"{x:1536,y:939,t:1527271986138};\\\", \\\"{x:1527,y:929,t:1527271986154};\\\", \\\"{x:1515,y:917,t:1527271986170};\\\", \\\"{x:1502,y:908,t:1527271986188};\\\", \\\"{x:1491,y:898,t:1527271986204};\\\", \\\"{x:1484,y:893,t:1527271986221};\\\", \\\"{x:1480,y:885,t:1527271986237};\\\", \\\"{x:1477,y:881,t:1527271986254};\\\", \\\"{x:1474,y:873,t:1527271986271};\\\", \\\"{x:1472,y:863,t:1527271986288};\\\", \\\"{x:1471,y:856,t:1527271986304};\\\", \\\"{x:1469,y:843,t:1527271986321};\\\", \\\"{x:1465,y:833,t:1527271986338};\\\", \\\"{x:1463,y:828,t:1527271986355};\\\", \\\"{x:1463,y:827,t:1527271986371};\\\", \\\"{x:1463,y:825,t:1527271986390};\\\", \\\"{x:1463,y:824,t:1527271986405};\\\", \\\"{x:1463,y:823,t:1527271986421};\\\", \\\"{x:1463,y:822,t:1527271986552};\\\", \\\"{x:1463,y:821,t:1527271986560};\\\", \\\"{x:1463,y:819,t:1527271986572};\\\", \\\"{x:1463,y:817,t:1527271986589};\\\", \\\"{x:1463,y:813,t:1527271986606};\\\", \\\"{x:1463,y:811,t:1527271986622};\\\", \\\"{x:1459,y:799,t:1527271986639};\\\", \\\"{x:1458,y:795,t:1527271986655};\\\", \\\"{x:1456,y:789,t:1527271986673};\\\", \\\"{x:1454,y:784,t:1527271986689};\\\", \\\"{x:1454,y:780,t:1527271986719};\\\", \\\"{x:1452,y:773,t:1527271986726};\\\", \\\"{x:1452,y:771,t:1527271986739};\\\", \\\"{x:1451,y:764,t:1527271986756};\\\", \\\"{x:1447,y:757,t:1527271986772};\\\", \\\"{x:1445,y:746,t:1527271986789};\\\", \\\"{x:1440,y:732,t:1527271986805};\\\", \\\"{x:1430,y:710,t:1527271986823};\\\", \\\"{x:1424,y:702,t:1527271986838};\\\", \\\"{x:1421,y:694,t:1527271986855};\\\", \\\"{x:1419,y:692,t:1527271986872};\\\", \\\"{x:1419,y:690,t:1527271986889};\\\", \\\"{x:1418,y:689,t:1527271988015};\\\", \\\"{x:1417,y:689,t:1527271988582};\\\", \\\"{x:1417,y:690,t:1527271988606};\\\", \\\"{x:1417,y:692,t:1527271988614};\\\", \\\"{x:1418,y:692,t:1527271988624};\\\", \\\"{x:1423,y:702,t:1527271988642};\\\", \\\"{x:1425,y:708,t:1527271988657};\\\", \\\"{x:1427,y:715,t:1527271988674};\\\", \\\"{x:1429,y:721,t:1527271988691};\\\", \\\"{x:1431,y:730,t:1527271988707};\\\", \\\"{x:1433,y:737,t:1527271988724};\\\", \\\"{x:1436,y:742,t:1527271988741};\\\", \\\"{x:1437,y:746,t:1527271988757};\\\", \\\"{x:1438,y:748,t:1527271988774};\\\", \\\"{x:1438,y:751,t:1527271988792};\\\", \\\"{x:1439,y:752,t:1527271988807};\\\", \\\"{x:1443,y:752,t:1527271988824};\\\", \\\"{x:1445,y:752,t:1527271988841};\\\", \\\"{x:1448,y:761,t:1527271988858};\\\", \\\"{x:1452,y:768,t:1527271988874};\\\", \\\"{x:1456,y:774,t:1527271988891};\\\", \\\"{x:1457,y:778,t:1527271988908};\\\", \\\"{x:1460,y:781,t:1527271988925};\\\", \\\"{x:1464,y:785,t:1527271988941};\\\", \\\"{x:1470,y:793,t:1527271988958};\\\", \\\"{x:1472,y:796,t:1527271988975};\\\", \\\"{x:1475,y:799,t:1527271988992};\\\", \\\"{x:1476,y:801,t:1527271989014};\\\", \\\"{x:1477,y:804,t:1527271989030};\\\", \\\"{x:1477,y:807,t:1527271989047};\\\", \\\"{x:1479,y:809,t:1527271989058};\\\", \\\"{x:1479,y:811,t:1527271989074};\\\", \\\"{x:1481,y:815,t:1527271989091};\\\", \\\"{x:1482,y:818,t:1527271989109};\\\", \\\"{x:1482,y:820,t:1527271989127};\\\", \\\"{x:1483,y:821,t:1527271989142};\\\", \\\"{x:1485,y:825,t:1527271989160};\\\", \\\"{x:1486,y:825,t:1527271989175};\\\", \\\"{x:1487,y:826,t:1527271989192};\\\", \\\"{x:1488,y:827,t:1527271989209};\\\", \\\"{x:1488,y:828,t:1527271989311};\\\", \\\"{x:1486,y:829,t:1527271989327};\\\", \\\"{x:1468,y:829,t:1527271989343};\\\", \\\"{x:1357,y:787,t:1527271989359};\\\", \\\"{x:1248,y:750,t:1527271989376};\\\", \\\"{x:1129,y:719,t:1527271989391};\\\", \\\"{x:988,y:673,t:1527271989408};\\\", \\\"{x:857,y:632,t:1527271989425};\\\", \\\"{x:747,y:601,t:1527271989442};\\\", \\\"{x:658,y:578,t:1527271989459};\\\", \\\"{x:620,y:563,t:1527271989473};\\\", \\\"{x:613,y:554,t:1527271989489};\\\", \\\"{x:611,y:552,t:1527271989506};\\\", \\\"{x:610,y:549,t:1527271989523};\\\", \\\"{x:613,y:543,t:1527271989540};\\\", \\\"{x:623,y:533,t:1527271989556};\\\", \\\"{x:634,y:525,t:1527271989573};\\\", \\\"{x:651,y:514,t:1527271989591};\\\", \\\"{x:661,y:509,t:1527271989606};\\\", \\\"{x:670,y:503,t:1527271989623};\\\", \\\"{x:680,y:500,t:1527271989640};\\\", \\\"{x:696,y:498,t:1527271989657};\\\", \\\"{x:721,y:498,t:1527271989673};\\\", \\\"{x:740,y:498,t:1527271989691};\\\", \\\"{x:770,y:503,t:1527271989707};\\\", \\\"{x:793,y:513,t:1527271989723};\\\", \\\"{x:808,y:517,t:1527271989740};\\\", \\\"{x:817,y:524,t:1527271989758};\\\", \\\"{x:819,y:529,t:1527271989774};\\\", \\\"{x:819,y:533,t:1527271989805};\\\", \\\"{x:816,y:540,t:1527271989814};\\\", \\\"{x:808,y:549,t:1527271989823};\\\", \\\"{x:782,y:566,t:1527271989841};\\\", \\\"{x:753,y:589,t:1527271989857};\\\", \\\"{x:731,y:600,t:1527271989873};\\\", \\\"{x:710,y:610,t:1527271989890};\\\", \\\"{x:697,y:615,t:1527271989907};\\\", \\\"{x:688,y:616,t:1527271989923};\\\", \\\"{x:681,y:617,t:1527271989940};\\\", \\\"{x:674,y:617,t:1527271989957};\\\", \\\"{x:670,y:618,t:1527271989974};\\\", \\\"{x:664,y:618,t:1527271989990};\\\", \\\"{x:656,y:618,t:1527271990007};\\\", \\\"{x:643,y:615,t:1527271990024};\\\", \\\"{x:633,y:612,t:1527271990040};\\\", \\\"{x:625,y:610,t:1527271990057};\\\", \\\"{x:614,y:606,t:1527271990074};\\\", \\\"{x:610,y:605,t:1527271990090};\\\", \\\"{x:606,y:603,t:1527271990107};\\\", \\\"{x:600,y:601,t:1527271990124};\\\", \\\"{x:592,y:601,t:1527271990140};\\\", \\\"{x:586,y:601,t:1527271990157};\\\", \\\"{x:579,y:602,t:1527271990173};\\\", \\\"{x:578,y:602,t:1527271990190};\\\", \\\"{x:576,y:602,t:1527271990207};\\\", \\\"{x:577,y:599,t:1527271990271};\\\", \\\"{x:580,y:598,t:1527271990310};\\\", \\\"{x:581,y:597,t:1527271990324};\\\", \\\"{x:583,y:595,t:1527271990340};\\\", \\\"{x:584,y:594,t:1527271990358};\\\", \\\"{x:588,y:592,t:1527271990374};\\\", \\\"{x:591,y:591,t:1527271990390};\\\", \\\"{x:593,y:590,t:1527271990407};\\\", \\\"{x:593,y:589,t:1527271990424};\\\", \\\"{x:595,y:589,t:1527271990470};\\\", \\\"{x:596,y:589,t:1527271990478};\\\", \\\"{x:597,y:588,t:1527271990502};\\\", \\\"{x:598,y:588,t:1527271990542};\\\", \\\"{x:599,y:588,t:1527271990566};\\\", \\\"{x:599,y:594,t:1527271990817};\\\", \\\"{x:599,y:600,t:1527271990824};\\\", \\\"{x:595,y:614,t:1527271990842};\\\", \\\"{x:588,y:635,t:1527271990857};\\\", \\\"{x:584,y:651,t:1527271990874};\\\", \\\"{x:577,y:667,t:1527271990891};\\\", \\\"{x:571,y:676,t:1527271990907};\\\", \\\"{x:568,y:681,t:1527271990924};\\\", \\\"{x:567,y:687,t:1527271990941};\\\", \\\"{x:563,y:692,t:1527271990958};\\\", \\\"{x:562,y:694,t:1527271990989};\\\", \\\"{x:561,y:694,t:1527271990997};\\\", \\\"{x:560,y:697,t:1527271991013};\\\", \\\"{x:559,y:698,t:1527271991024};\\\", \\\"{x:556,y:701,t:1527271991041};\\\", \\\"{x:554,y:704,t:1527271991058};\\\", \\\"{x:553,y:705,t:1527271991074};\\\", \\\"{x:553,y:703,t:1527271991102};\\\", \\\"{x:553,y:696,t:1527271991110};\\\", \\\"{x:555,y:690,t:1527271991124};\\\", \\\"{x:559,y:674,t:1527271991141};\\\", \\\"{x:567,y:656,t:1527271991158};\\\", \\\"{x:576,y:646,t:1527271991174};\\\", \\\"{x:583,y:637,t:1527271991191};\\\", \\\"{x:586,y:631,t:1527271991208};\\\", \\\"{x:588,y:625,t:1527271991224};\\\", \\\"{x:590,y:620,t:1527271991241};\\\", \\\"{x:592,y:613,t:1527271991258};\\\", \\\"{x:597,y:605,t:1527271991275};\\\", \\\"{x:601,y:599,t:1527271991293};\\\", \\\"{x:604,y:596,t:1527271991309};\\\", \\\"{x:611,y:588,t:1527271991325};\\\", \\\"{x:621,y:580,t:1527271991341};\\\", \\\"{x:628,y:571,t:1527271991358};\\\", \\\"{x:629,y:568,t:1527271991375};\\\", \\\"{x:629,y:570,t:1527271991678};\\\", \\\"{x:627,y:571,t:1527271991691};\\\", \\\"{x:624,y:575,t:1527271991708};\\\", \\\"{x:623,y:576,t:1527271991726};\\\", \\\"{x:621,y:577,t:1527271991741};\\\", \\\"{x:620,y:579,t:1527271991758};\\\", \\\"{x:620,y:580,t:1527271991815};\\\", \\\"{x:617,y:583,t:1527271991825};\\\", \\\"{x:611,y:590,t:1527271991843};\\\", \\\"{x:599,y:610,t:1527271991859};\\\", \\\"{x:577,y:653,t:1527271991875};\\\", \\\"{x:554,y:690,t:1527271991892};\\\", \\\"{x:529,y:719,t:1527271991908};\\\", \\\"{x:509,y:747,t:1527271991926};\\\", \\\"{x:494,y:768,t:1527271991943};\\\", \\\"{x:493,y:770,t:1527271991958};\\\", \\\"{x:493,y:768,t:1527271992094};\\\", \\\"{x:493,y:764,t:1527271992109};\\\", \\\"{x:494,y:745,t:1527271992126};\\\", \\\"{x:498,y:730,t:1527271992142};\\\", \\\"{x:498,y:729,t:1527271992159};\\\", \\\"{x:500,y:728,t:1527271993031};\\\", \\\"{x:500,y:726,t:1527271993044};\\\", \\\"{x:502,y:723,t:1527271993059};\\\", \\\"{x:505,y:721,t:1527271993077};\\\", \\\"{x:506,y:718,t:1527271993093};\\\", \\\"{x:507,y:718,t:1527271993109};\\\", \\\"{x:507,y:717,t:1527271993127};\\\" ] }, { \\\"rt\\\": 10746, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 684288, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-01 PM-01 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:715,t:1527271993790};\\\", \\\"{x:511,y:711,t:1527271995502};\\\", \\\"{x:519,y:708,t:1527271995512};\\\", \\\"{x:523,y:702,t:1527271995529};\\\", \\\"{x:526,y:700,t:1527271995545};\\\", \\\"{x:538,y:696,t:1527271995561};\\\", \\\"{x:548,y:691,t:1527271995578};\\\", \\\"{x:562,y:687,t:1527271995595};\\\", \\\"{x:576,y:686,t:1527271995611};\\\", \\\"{x:594,y:686,t:1527271995628};\\\", \\\"{x:615,y:686,t:1527271995644};\\\", \\\"{x:649,y:695,t:1527271995661};\\\", \\\"{x:725,y:722,t:1527271995678};\\\", \\\"{x:768,y:739,t:1527271995696};\\\", \\\"{x:795,y:748,t:1527271995711};\\\", \\\"{x:869,y:776,t:1527271995728};\\\", \\\"{x:954,y:797,t:1527271995745};\\\", \\\"{x:1017,y:810,t:1527271995762};\\\", \\\"{x:1054,y:827,t:1527271995779};\\\", \\\"{x:1084,y:838,t:1527271995795};\\\", \\\"{x:1103,y:845,t:1527271995811};\\\", \\\"{x:1127,y:854,t:1527271995828};\\\", \\\"{x:1142,y:865,t:1527271995846};\\\", \\\"{x:1161,y:877,t:1527271995861};\\\", \\\"{x:1191,y:900,t:1527271995879};\\\", \\\"{x:1214,y:918,t:1527271995896};\\\", \\\"{x:1231,y:932,t:1527271995911};\\\", \\\"{x:1247,y:948,t:1527271995928};\\\", \\\"{x:1260,y:963,t:1527271995946};\\\", \\\"{x:1276,y:977,t:1527271995962};\\\", \\\"{x:1287,y:989,t:1527271995979};\\\", \\\"{x:1297,y:999,t:1527271995996};\\\", \\\"{x:1300,y:1001,t:1527271996011};\\\", \\\"{x:1302,y:1005,t:1527271996029};\\\", \\\"{x:1304,y:1007,t:1527271996046};\\\", \\\"{x:1309,y:1013,t:1527271996062};\\\", \\\"{x:1310,y:1014,t:1527271996079};\\\", \\\"{x:1312,y:1016,t:1527271996095};\\\", \\\"{x:1313,y:1017,t:1527271996175};\\\", \\\"{x:1315,y:1017,t:1527271996183};\\\", \\\"{x:1317,y:1017,t:1527271996196};\\\", \\\"{x:1323,y:1019,t:1527271996214};\\\", \\\"{x:1329,y:1019,t:1527271996229};\\\", \\\"{x:1331,y:1019,t:1527271996246};\\\", \\\"{x:1334,y:1019,t:1527271996263};\\\", \\\"{x:1335,y:1019,t:1527271996279};\\\", \\\"{x:1342,y:1017,t:1527271996296};\\\", \\\"{x:1349,y:1011,t:1527271996313};\\\", \\\"{x:1359,y:1004,t:1527271996330};\\\", \\\"{x:1366,y:1000,t:1527271996346};\\\", \\\"{x:1378,y:993,t:1527271996363};\\\", \\\"{x:1385,y:990,t:1527271996378};\\\", \\\"{x:1389,y:988,t:1527271996396};\\\", \\\"{x:1391,y:987,t:1527271996413};\\\", \\\"{x:1393,y:985,t:1527271996429};\\\", \\\"{x:1397,y:982,t:1527271996445};\\\", \\\"{x:1399,y:980,t:1527271996462};\\\", \\\"{x:1401,y:977,t:1527271996479};\\\", \\\"{x:1404,y:974,t:1527271996496};\\\", \\\"{x:1407,y:971,t:1527271996513};\\\", \\\"{x:1410,y:969,t:1527271996528};\\\", \\\"{x:1411,y:967,t:1527271996546};\\\", \\\"{x:1412,y:967,t:1527271996562};\\\", \\\"{x:1413,y:967,t:1527271996580};\\\", \\\"{x:1414,y:966,t:1527271996595};\\\", \\\"{x:1416,y:965,t:1527271996613};\\\", \\\"{x:1417,y:965,t:1527271996630};\\\", \\\"{x:1418,y:965,t:1527271996646};\\\", \\\"{x:1419,y:964,t:1527271996663};\\\", \\\"{x:1419,y:965,t:1527271996799};\\\", \\\"{x:1419,y:967,t:1527271996813};\\\", \\\"{x:1417,y:969,t:1527271996831};\\\", \\\"{x:1414,y:974,t:1527271996846};\\\", \\\"{x:1414,y:979,t:1527271996862};\\\", \\\"{x:1412,y:987,t:1527271996880};\\\", \\\"{x:1420,y:1002,t:1527271996896};\\\", \\\"{x:1444,y:1015,t:1527271996913};\\\", \\\"{x:1468,y:1026,t:1527271996930};\\\", \\\"{x:1496,y:1038,t:1527271996946};\\\", \\\"{x:1518,y:1044,t:1527271996963};\\\", \\\"{x:1539,y:1048,t:1527271996980};\\\", \\\"{x:1548,y:1048,t:1527271996997};\\\", \\\"{x:1550,y:1048,t:1527271997013};\\\", \\\"{x:1552,y:1048,t:1527271997030};\\\", \\\"{x:1553,y:1045,t:1527271997047};\\\", \\\"{x:1553,y:1040,t:1527271997063};\\\", \\\"{x:1551,y:1032,t:1527271997080};\\\", \\\"{x:1549,y:1025,t:1527271997098};\\\", \\\"{x:1547,y:1021,t:1527271997113};\\\", \\\"{x:1543,y:1015,t:1527271997131};\\\", \\\"{x:1538,y:1010,t:1527271997147};\\\", \\\"{x:1530,y:1005,t:1527271997162};\\\", \\\"{x:1516,y:997,t:1527271997180};\\\", \\\"{x:1505,y:991,t:1527271997197};\\\", \\\"{x:1494,y:984,t:1527271997212};\\\", \\\"{x:1489,y:980,t:1527271997229};\\\", \\\"{x:1487,y:979,t:1527271997247};\\\", \\\"{x:1486,y:979,t:1527271997263};\\\", \\\"{x:1485,y:979,t:1527271997279};\\\", \\\"{x:1485,y:978,t:1527271997297};\\\", \\\"{x:1485,y:976,t:1527271997313};\\\", \\\"{x:1485,y:975,t:1527271997330};\\\", \\\"{x:1484,y:974,t:1527271997346};\\\", \\\"{x:1484,y:973,t:1527271997363};\\\", \\\"{x:1484,y:971,t:1527271997380};\\\", \\\"{x:1484,y:970,t:1527271997398};\\\", \\\"{x:1484,y:969,t:1527271997422};\\\", \\\"{x:1484,y:968,t:1527271997430};\\\", \\\"{x:1484,y:967,t:1527271997446};\\\", \\\"{x:1484,y:966,t:1527271997464};\\\", \\\"{x:1485,y:962,t:1527271997480};\\\", \\\"{x:1486,y:960,t:1527271997496};\\\", \\\"{x:1489,y:954,t:1527271997513};\\\", \\\"{x:1490,y:946,t:1527271997530};\\\", \\\"{x:1490,y:941,t:1527271997547};\\\", \\\"{x:1490,y:936,t:1527271997564};\\\", \\\"{x:1490,y:934,t:1527271997579};\\\", \\\"{x:1490,y:930,t:1527271997597};\\\", \\\"{x:1490,y:926,t:1527271997614};\\\", \\\"{x:1490,y:920,t:1527271997629};\\\", \\\"{x:1490,y:915,t:1527271997646};\\\", \\\"{x:1490,y:911,t:1527271997664};\\\", \\\"{x:1489,y:908,t:1527271997679};\\\", \\\"{x:1489,y:906,t:1527271997697};\\\", \\\"{x:1489,y:905,t:1527271997714};\\\", \\\"{x:1489,y:903,t:1527271997730};\\\", \\\"{x:1489,y:902,t:1527271997747};\\\", \\\"{x:1489,y:900,t:1527271997764};\\\", \\\"{x:1489,y:897,t:1527271997781};\\\", \\\"{x:1489,y:895,t:1527271997797};\\\", \\\"{x:1489,y:892,t:1527271997814};\\\", \\\"{x:1489,y:886,t:1527271997831};\\\", \\\"{x:1488,y:880,t:1527271997847};\\\", \\\"{x:1488,y:877,t:1527271997864};\\\", \\\"{x:1488,y:874,t:1527271997881};\\\", \\\"{x:1488,y:867,t:1527271997897};\\\", \\\"{x:1488,y:862,t:1527271997914};\\\", \\\"{x:1488,y:853,t:1527271997931};\\\", \\\"{x:1488,y:847,t:1527271997947};\\\", \\\"{x:1488,y:844,t:1527271997964};\\\", \\\"{x:1487,y:841,t:1527271997981};\\\", \\\"{x:1487,y:839,t:1527271997997};\\\", \\\"{x:1487,y:836,t:1527271998014};\\\", \\\"{x:1487,y:834,t:1527271998030};\\\", \\\"{x:1487,y:833,t:1527271998047};\\\", \\\"{x:1487,y:831,t:1527271998064};\\\", \\\"{x:1488,y:829,t:1527271998081};\\\", \\\"{x:1488,y:828,t:1527271998102};\\\", \\\"{x:1488,y:827,t:1527271998114};\\\", \\\"{x:1489,y:827,t:1527271998131};\\\", \\\"{x:1490,y:823,t:1527271998239};\\\", \\\"{x:1490,y:821,t:1527271998359};\\\", \\\"{x:1490,y:818,t:1527271998367};\\\", \\\"{x:1490,y:817,t:1527271998381};\\\", \\\"{x:1491,y:816,t:1527271998407};\\\", \\\"{x:1491,y:814,t:1527271998495};\\\", \\\"{x:1491,y:813,t:1527271998502};\\\", \\\"{x:1490,y:811,t:1527271998514};\\\", \\\"{x:1489,y:810,t:1527271998531};\\\", \\\"{x:1489,y:807,t:1527271998547};\\\", \\\"{x:1489,y:805,t:1527271998574};\\\", \\\"{x:1489,y:804,t:1527271998590};\\\", \\\"{x:1489,y:803,t:1527271998622};\\\", \\\"{x:1489,y:802,t:1527271998637};\\\", \\\"{x:1489,y:801,t:1527271998647};\\\", \\\"{x:1489,y:799,t:1527271998663};\\\", \\\"{x:1489,y:797,t:1527271998681};\\\", \\\"{x:1488,y:793,t:1527271998698};\\\", \\\"{x:1488,y:792,t:1527271998715};\\\", \\\"{x:1488,y:789,t:1527271998731};\\\", \\\"{x:1488,y:788,t:1527271998748};\\\", \\\"{x:1487,y:785,t:1527271998765};\\\", \\\"{x:1486,y:783,t:1527271998781};\\\", \\\"{x:1485,y:778,t:1527271998797};\\\", \\\"{x:1485,y:773,t:1527271998814};\\\", \\\"{x:1484,y:769,t:1527271998831};\\\", \\\"{x:1483,y:766,t:1527271998847};\\\", \\\"{x:1483,y:763,t:1527271998864};\\\", \\\"{x:1483,y:759,t:1527271998881};\\\", \\\"{x:1483,y:752,t:1527271998898};\\\", \\\"{x:1483,y:743,t:1527271998915};\\\", \\\"{x:1483,y:739,t:1527271998930};\\\", \\\"{x:1483,y:734,t:1527271998948};\\\", \\\"{x:1483,y:731,t:1527271998965};\\\", \\\"{x:1481,y:727,t:1527271998980};\\\", \\\"{x:1481,y:722,t:1527271998998};\\\", \\\"{x:1481,y:714,t:1527271999014};\\\", \\\"{x:1481,y:708,t:1527271999030};\\\", \\\"{x:1481,y:700,t:1527271999048};\\\", \\\"{x:1481,y:692,t:1527271999064};\\\", \\\"{x:1479,y:684,t:1527271999080};\\\", \\\"{x:1478,y:675,t:1527271999098};\\\", \\\"{x:1477,y:667,t:1527271999114};\\\", \\\"{x:1477,y:662,t:1527271999132};\\\", \\\"{x:1477,y:655,t:1527271999148};\\\", \\\"{x:1477,y:648,t:1527271999165};\\\", \\\"{x:1477,y:638,t:1527271999182};\\\", \\\"{x:1477,y:633,t:1527271999198};\\\", \\\"{x:1479,y:631,t:1527271999214};\\\", \\\"{x:1479,y:630,t:1527271999231};\\\", \\\"{x:1479,y:624,t:1527271999248};\\\", \\\"{x:1479,y:620,t:1527271999265};\\\", \\\"{x:1480,y:612,t:1527271999282};\\\", \\\"{x:1480,y:603,t:1527271999297};\\\", \\\"{x:1480,y:597,t:1527271999315};\\\", \\\"{x:1480,y:592,t:1527271999331};\\\", \\\"{x:1480,y:589,t:1527271999348};\\\", \\\"{x:1480,y:585,t:1527271999365};\\\", \\\"{x:1480,y:578,t:1527271999382};\\\", \\\"{x:1480,y:574,t:1527271999398};\\\", \\\"{x:1478,y:560,t:1527271999415};\\\", \\\"{x:1476,y:547,t:1527271999432};\\\", \\\"{x:1474,y:538,t:1527271999448};\\\", \\\"{x:1473,y:523,t:1527271999464};\\\", \\\"{x:1472,y:508,t:1527271999482};\\\", \\\"{x:1469,y:491,t:1527271999498};\\\", \\\"{x:1468,y:482,t:1527271999514};\\\", \\\"{x:1468,y:464,t:1527271999531};\\\", \\\"{x:1468,y:453,t:1527271999548};\\\", \\\"{x:1464,y:439,t:1527271999565};\\\", \\\"{x:1464,y:414,t:1527271999582};\\\", \\\"{x:1464,y:405,t:1527271999598};\\\", \\\"{x:1464,y:391,t:1527271999615};\\\", \\\"{x:1466,y:378,t:1527271999632};\\\", \\\"{x:1469,y:365,t:1527271999649};\\\", \\\"{x:1470,y:355,t:1527271999665};\\\", \\\"{x:1472,y:346,t:1527271999681};\\\", \\\"{x:1474,y:338,t:1527271999699};\\\", \\\"{x:1475,y:333,t:1527271999714};\\\", \\\"{x:1478,y:328,t:1527271999732};\\\", \\\"{x:1482,y:322,t:1527271999749};\\\", \\\"{x:1484,y:318,t:1527271999764};\\\", \\\"{x:1484,y:316,t:1527271999782};\\\", \\\"{x:1484,y:314,t:1527271999798};\\\", \\\"{x:1484,y:313,t:1527271999823};\\\", \\\"{x:1484,y:311,t:1527271999846};\\\", \\\"{x:1481,y:311,t:1527271999887};\\\", \\\"{x:1466,y:320,t:1527271999899};\\\", \\\"{x:1426,y:348,t:1527271999916};\\\", \\\"{x:1348,y:396,t:1527271999932};\\\", \\\"{x:1269,y:462,t:1527271999950};\\\", \\\"{x:1186,y:539,t:1527271999965};\\\", \\\"{x:1122,y:621,t:1527271999982};\\\", \\\"{x:1046,y:696,t:1527271999999};\\\", \\\"{x:999,y:740,t:1527272000015};\\\", \\\"{x:970,y:755,t:1527272000033};\\\", \\\"{x:958,y:770,t:1527272000049};\\\", \\\"{x:949,y:782,t:1527272000066};\\\", \\\"{x:945,y:784,t:1527272000082};\\\", \\\"{x:928,y:788,t:1527272000099};\\\", \\\"{x:915,y:788,t:1527272000116};\\\", \\\"{x:881,y:788,t:1527272000131};\\\", \\\"{x:842,y:781,t:1527272000150};\\\", \\\"{x:743,y:768,t:1527272000166};\\\", \\\"{x:691,y:749,t:1527272000182};\\\", \\\"{x:660,y:735,t:1527272000198};\\\", \\\"{x:621,y:720,t:1527272000216};\\\", \\\"{x:604,y:712,t:1527272000232};\\\", \\\"{x:590,y:704,t:1527272000249};\\\", \\\"{x:578,y:697,t:1527272000266};\\\", \\\"{x:571,y:693,t:1527272000282};\\\", \\\"{x:560,y:684,t:1527272000299};\\\", \\\"{x:546,y:673,t:1527272000316};\\\", \\\"{x:526,y:655,t:1527272000332};\\\", \\\"{x:511,y:641,t:1527272000350};\\\", \\\"{x:481,y:619,t:1527272000367};\\\", \\\"{x:468,y:608,t:1527272000382};\\\", \\\"{x:455,y:591,t:1527272000399};\\\", \\\"{x:449,y:583,t:1527272000415};\\\", \\\"{x:448,y:583,t:1527272000879};\\\", \\\"{x:446,y:583,t:1527272000910};\\\", \\\"{x:443,y:586,t:1527272000918};\\\", \\\"{x:441,y:592,t:1527272000933};\\\", \\\"{x:437,y:603,t:1527272000950};\\\", \\\"{x:432,y:610,t:1527272000966};\\\", \\\"{x:425,y:624,t:1527272000982};\\\", \\\"{x:422,y:635,t:1527272000999};\\\", \\\"{x:420,y:648,t:1527272001017};\\\", \\\"{x:418,y:661,t:1527272001033};\\\", \\\"{x:418,y:671,t:1527272001049};\\\", \\\"{x:418,y:675,t:1527272001065};\\\", \\\"{x:416,y:677,t:1527272001083};\\\", \\\"{x:415,y:677,t:1527272001190};\\\", \\\"{x:411,y:671,t:1527272001200};\\\", \\\"{x:405,y:658,t:1527272001215};\\\", \\\"{x:400,y:649,t:1527272001233};\\\", \\\"{x:397,y:642,t:1527272001250};\\\", \\\"{x:395,y:638,t:1527272001267};\\\", \\\"{x:394,y:632,t:1527272001283};\\\", \\\"{x:391,y:626,t:1527272001300};\\\", \\\"{x:387,y:615,t:1527272001317};\\\", \\\"{x:384,y:607,t:1527272001333};\\\", \\\"{x:380,y:600,t:1527272001350};\\\", \\\"{x:379,y:599,t:1527272001373};\\\", \\\"{x:379,y:597,t:1527272001437};\\\", \\\"{x:378,y:596,t:1527272001453};\\\", \\\"{x:378,y:593,t:1527272001510};\\\", \\\"{x:380,y:592,t:1527272001518};\\\", \\\"{x:382,y:591,t:1527272001533};\\\", \\\"{x:396,y:583,t:1527272001550};\\\", \\\"{x:412,y:575,t:1527272001567};\\\", \\\"{x:426,y:571,t:1527272001583};\\\", \\\"{x:444,y:568,t:1527272001600};\\\", \\\"{x:470,y:568,t:1527272001617};\\\", \\\"{x:498,y:568,t:1527272001633};\\\", \\\"{x:521,y:570,t:1527272001649};\\\", \\\"{x:528,y:571,t:1527272001666};\\\", \\\"{x:542,y:571,t:1527272001684};\\\", \\\"{x:551,y:573,t:1527272001700};\\\", \\\"{x:555,y:573,t:1527272001716};\\\", \\\"{x:556,y:573,t:1527272001733};\\\", \\\"{x:558,y:573,t:1527272001814};\\\", \\\"{x:560,y:573,t:1527272001822};\\\", \\\"{x:561,y:573,t:1527272001838};\\\", \\\"{x:561,y:575,t:1527272001950};\\\", \\\"{x:544,y:590,t:1527272001968};\\\", \\\"{x:520,y:611,t:1527272001984};\\\", \\\"{x:495,y:623,t:1527272002001};\\\", \\\"{x:478,y:629,t:1527272002017};\\\", \\\"{x:464,y:629,t:1527272002034};\\\", \\\"{x:454,y:629,t:1527272002049};\\\", \\\"{x:446,y:629,t:1527272002067};\\\", \\\"{x:437,y:629,t:1527272002083};\\\", \\\"{x:427,y:629,t:1527272002100};\\\", \\\"{x:410,y:625,t:1527272002117};\\\", \\\"{x:388,y:618,t:1527272002134};\\\", \\\"{x:380,y:616,t:1527272002151};\\\", \\\"{x:377,y:614,t:1527272002167};\\\", \\\"{x:375,y:612,t:1527272002184};\\\", \\\"{x:375,y:609,t:1527272002262};\\\", \\\"{x:375,y:603,t:1527272002271};\\\", \\\"{x:376,y:603,t:1527272002284};\\\", \\\"{x:376,y:599,t:1527272002301};\\\", \\\"{x:376,y:598,t:1527272002317};\\\", \\\"{x:378,y:596,t:1527272002597};\\\", \\\"{x:386,y:596,t:1527272002606};\\\", \\\"{x:395,y:592,t:1527272002618};\\\", \\\"{x:417,y:592,t:1527272002634};\\\", \\\"{x:437,y:591,t:1527272002651};\\\", \\\"{x:461,y:593,t:1527272002668};\\\", \\\"{x:479,y:598,t:1527272002684};\\\", \\\"{x:492,y:604,t:1527272002700};\\\", \\\"{x:496,y:604,t:1527272002718};\\\", \\\"{x:499,y:604,t:1527272002743};\\\", \\\"{x:502,y:604,t:1527272002758};\\\", \\\"{x:505,y:604,t:1527272002773};\\\", \\\"{x:507,y:604,t:1527272002783};\\\", \\\"{x:509,y:603,t:1527272002800};\\\", \\\"{x:519,y:602,t:1527272002818};\\\", \\\"{x:528,y:599,t:1527272002834};\\\", \\\"{x:538,y:597,t:1527272002851};\\\", \\\"{x:545,y:593,t:1527272002867};\\\", \\\"{x:551,y:593,t:1527272002883};\\\", \\\"{x:553,y:592,t:1527272002901};\\\", \\\"{x:559,y:589,t:1527272002917};\\\", \\\"{x:563,y:586,t:1527272002934};\\\", \\\"{x:567,y:583,t:1527272002951};\\\", \\\"{x:576,y:580,t:1527272002968};\\\", \\\"{x:586,y:577,t:1527272002984};\\\", \\\"{x:590,y:577,t:1527272003001};\\\", \\\"{x:593,y:577,t:1527272003017};\\\", \\\"{x:594,y:577,t:1527272003034};\\\", \\\"{x:596,y:576,t:1527272003052};\\\", \\\"{x:597,y:574,t:1527272003068};\\\", \\\"{x:599,y:574,t:1527272003085};\\\", \\\"{x:601,y:574,t:1527272003101};\\\", \\\"{x:604,y:575,t:1527272003118};\\\", \\\"{x:608,y:578,t:1527272003134};\\\", \\\"{x:611,y:580,t:1527272003151};\\\", \\\"{x:611,y:581,t:1527272003167};\\\", \\\"{x:613,y:581,t:1527272003184};\\\", \\\"{x:614,y:581,t:1527272003261};\\\", \\\"{x:614,y:581,t:1527272003351};\\\", \\\"{x:614,y:582,t:1527272003591};\\\", \\\"{x:612,y:585,t:1527272003602};\\\", \\\"{x:605,y:598,t:1527272003617};\\\", \\\"{x:590,y:614,t:1527272003635};\\\", \\\"{x:557,y:666,t:1527272003652};\\\", \\\"{x:529,y:699,t:1527272003667};\\\", \\\"{x:516,y:719,t:1527272003685};\\\", \\\"{x:507,y:735,t:1527272003703};\\\", \\\"{x:502,y:747,t:1527272003718};\\\", \\\"{x:500,y:752,t:1527272003735};\\\", \\\"{x:498,y:759,t:1527272003752};\\\", \\\"{x:496,y:767,t:1527272003767};\\\", \\\"{x:495,y:769,t:1527272003785};\\\", \\\"{x:495,y:770,t:1527272003877};\\\", \\\"{x:495,y:769,t:1527272004086};\\\", \\\"{x:495,y:766,t:1527272004103};\\\", \\\"{x:496,y:765,t:1527272004119};\\\", \\\"{x:497,y:763,t:1527272004135};\\\", \\\"{x:497,y:758,t:1527272004390};\\\", \\\"{x:495,y:758,t:1527272004401};\\\", \\\"{x:493,y:757,t:1527272004419};\\\", \\\"{x:493,y:755,t:1527272004445};\\\", \\\"{x:491,y:754,t:1527272004454};\\\", \\\"{x:490,y:753,t:1527272004468};\\\", \\\"{x:485,y:753,t:1527272004485};\\\", \\\"{x:481,y:751,t:1527272004502};\\\", \\\"{x:480,y:751,t:1527272004519};\\\" ] }, { \\\"rt\\\": 39185, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 724679, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"For the lines going right slanting right, the events that start at 12 PM will begin at 12 PM on the x-axis and then move upwards, like with the letters M and L\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10031, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"U.S\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 735715, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 10503, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 747229, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 12731, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 761267, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"DFQLY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"november\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"DFQLY\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 131, dom: 752, initialDom: 854",
  "javascriptErrors": []
}