var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f62c1d31bb1ef48f9e10fad463474f27",
  "created": "2018-06-04T13:06:59.3237828-07:00",
  "lastActivity": "2018-06-04T13:17:10.5532022-07:00",
  "pageViews": [
    {
      "id": "060459076a0d8cd0683f59cce3bf9981d461af00",
      "startTime": "2018-06-04T13:06:59.5723151-07:00",
      "endTime": "2018-06-04T13:17:10.5532022-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 611271,
      "engagementTime": 78992,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 611271,
  "engagementTime": 78992,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7ef6d3b929a6a048b746602dbb6a7015",
  "gdpr": false
}