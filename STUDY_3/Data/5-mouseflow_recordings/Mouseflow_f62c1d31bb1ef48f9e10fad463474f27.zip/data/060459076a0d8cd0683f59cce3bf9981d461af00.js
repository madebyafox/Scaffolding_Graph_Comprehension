var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060459076a0d8cd0683f59cce3bf9981d461af00"] = {
  "startTime": "2018-06-04T20:06:59.5723151Z",
  "websitePageUrl": "/",
  "visitTime": 611271,
  "engagementTime": 78992,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1068,
  "viewportHeight": 1047,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "f62c1d31bb1ef48f9e10fad463474f27",
    "created": "2018-06-04T20:06:59.3237828+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "7ef6d3b929a6a048b746602dbb6a7015",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f62c1d31bb1ef48f9e10fad463474f27/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1068,
      "y": 1047
    },
    {
      "t": 147,
      "e": 147,
      "ty": 14,
      "x": 0,
      "y": 1046
    },
    {
      "t": 700,
      "e": 700,
      "ty": 2,
      "x": 363,
      "y": 73
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 22135,
      "y": 7253,
      "ta": "html > body"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 371,
      "y": 171
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 409,
      "y": 306
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 437,
      "y": 505
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 27497,
      "y": 31292,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 434,
      "y": 584
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 434,
      "y": 586
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 27333,
      "y": 37928,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10000,
      "e": 6250,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 197310,
      "e": 6250,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 197310,
      "e": 6250,
      "ty": 2,
      "x": 583,
      "y": 671
    },
    {
      "t": 197510,
      "e": 6450,
      "ty": 41,
      "x": 12205,
      "y": 38624,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 210014,
      "e": 11450,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 543629,
      "e": 11450,
      "ty": 1,
      "x": 0,
      "y": 3
    },
    {
      "t": 543729,
      "e": 11550,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 546730,
      "e": 14551,
      "ty": 2,
      "x": 911,
      "y": 866
    },
    {
      "t": 546780,
      "e": 14601,
      "ty": 41,
      "x": 31562,
      "y": 62042,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 546830,
      "e": 14651,
      "ty": 2,
      "x": 935,
      "y": 884
    },
    {
      "t": 546930,
      "e": 14751,
      "ty": 2,
      "x": 779,
      "y": 906
    },
    {
      "t": 547030,
      "e": 14851,
      "ty": 2,
      "x": 629,
      "y": 931
    },
    {
      "t": 547031,
      "e": 14852,
      "ty": 41,
      "x": 16507,
      "y": 58790,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 547129,
      "e": 14950,
      "ty": 2,
      "x": 661,
      "y": 929
    },
    {
      "t": 547230,
      "e": 15051,
      "ty": 2,
      "x": 799,
      "y": 924
    },
    {
      "t": 547280,
      "e": 15101,
      "ty": 41,
      "x": 1843,
      "y": 39372,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 547330,
      "e": 15151,
      "ty": 2,
      "x": 805,
      "y": 923
    },
    {
      "t": 547429,
      "e": 15250,
      "ty": 2,
      "x": 815,
      "y": 920
    },
    {
      "t": 547530,
      "e": 15351,
      "ty": 41,
      "x": 37887,
      "y": 29541,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 548434,
      "e": 16255,
      "ty": 3,
      "x": 815,
      "y": 920,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 548585,
      "e": 16406,
      "ty": 4,
      "x": 37887,
      "y": 29541,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 548585,
      "e": 16406,
      "ty": 5,
      "x": 815,
      "y": 920,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 548586,
      "e": 16407,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 548591,
      "e": 16412,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 549129,
      "e": 16950,
      "ty": 2,
      "x": 816,
      "y": 920
    },
    {
      "t": 549230,
      "e": 17051,
      "ty": 2,
      "x": 817,
      "y": 920
    },
    {
      "t": 549281,
      "e": 17102,
      "ty": 41,
      "x": 44440,
      "y": 29541,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 549731,
      "e": 17552,
      "ty": 2,
      "x": 825,
      "y": 932
    },
    {
      "t": 549780,
      "e": 17601,
      "ty": 41,
      "x": 27478,
      "y": 57870,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 549829,
      "e": 17650,
      "ty": 2,
      "x": 874,
      "y": 982
    },
    {
      "t": 549930,
      "e": 17751,
      "ty": 2,
      "x": 985,
      "y": 1071
    },
    {
      "t": 550030,
      "e": 17851,
      "ty": 2,
      "x": 1008,
      "y": 1089
    },
    {
      "t": 550031,
      "e": 17852,
      "ty": 41,
      "x": 53793,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 550031,
      "e": 17852,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 550129,
      "e": 17950,
      "ty": 2,
      "x": 1009,
      "y": 1089
    },
    {
      "t": 550229,
      "e": 18050,
      "ty": 2,
      "x": 1011,
      "y": 1092
    },
    {
      "t": 550280,
      "e": 18101,
      "ty": 41,
      "x": 55431,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 550329,
      "e": 18150,
      "ty": 2,
      "x": 1012,
      "y": 1094
    },
    {
      "t": 550530,
      "e": 18351,
      "ty": 41,
      "x": 55977,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 550698,
      "e": 18519,
      "ty": 3,
      "x": 1012,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 550699,
      "e": 18520,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 550699,
      "e": 18520,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 550921,
      "e": 18742,
      "ty": 4,
      "x": 55977,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 550924,
      "e": 18745,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 550927,
      "e": 18748,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 550928,
      "e": 18749,
      "ty": 5,
      "x": 1012,
      "y": 1094,
      "ta": "#start"
    },
    {
      "t": 551930,
      "e": 19751,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 552229,
      "e": 20050,
      "ty": 2,
      "x": 1012,
      "y": 1096
    },
    {
      "t": 552280,
      "e": 20101,
      "ty": 41,
      "x": 34265,
      "y": 60327,
      "ta": "html > body"
    },
    {
      "t": 552329,
      "e": 20150,
      "ty": 2,
      "x": 995,
      "y": 1099
    },
    {
      "t": 552529,
      "e": 20350,
      "ty": 41,
      "x": 33990,
      "y": 60438,
      "ta": "html > body"
    },
    {
      "t": 552780,
      "e": 20601,
      "ty": 41,
      "x": 33473,
      "y": 54843,
      "ta": "html > body"
    },
    {
      "t": 552829,
      "e": 20650,
      "ty": 2,
      "x": 960,
      "y": 789
    },
    {
      "t": 552849,
      "e": 20670,
      "ty": 6,
      "x": 950,
      "y": 721,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 552929,
      "e": 20750,
      "ty": 2,
      "x": 951,
      "y": 717
    },
    {
      "t": 553029,
      "e": 20850,
      "ty": 2,
      "x": 937,
      "y": 739
    },
    {
      "t": 553029,
      "e": 20850,
      "ty": 41,
      "x": 21171,
      "y": 61563,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 553033,
      "e": 20854,
      "ty": 7,
      "x": 929,
      "y": 755,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 553120,
      "e": 20941,
      "ty": 6,
      "x": 929,
      "y": 736,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 553128,
      "e": 20949,
      "ty": 2,
      "x": 929,
      "y": 736
    },
    {
      "t": 553149,
      "e": 20970,
      "ty": 7,
      "x": 929,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 553149,
      "e": 20970,
      "ty": 6,
      "x": 929,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 553165,
      "e": 20986,
      "ty": 7,
      "x": 929,
      "y": 638,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 553183,
      "e": 21004,
      "ty": 6,
      "x": 929,
      "y": 597,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 553199,
      "e": 21020,
      "ty": 7,
      "x": 929,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 553228,
      "e": 21049,
      "ty": 2,
      "x": 929,
      "y": 551
    },
    {
      "t": 553279,
      "e": 21100,
      "ty": 41,
      "x": 26170,
      "y": 7751,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 553329,
      "e": 21150,
      "ty": 2,
      "x": 929,
      "y": 533
    },
    {
      "t": 553529,
      "e": 21350,
      "ty": 2,
      "x": 929,
      "y": 581
    },
    {
      "t": 553529,
      "e": 21350,
      "ty": 41,
      "x": 26170,
      "y": 41575,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 553534,
      "e": 21355,
      "ty": 6,
      "x": 929,
      "y": 589,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 553600,
      "e": 21421,
      "ty": 7,
      "x": 929,
      "y": 608,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 553629,
      "e": 21450,
      "ty": 2,
      "x": 929,
      "y": 608
    },
    {
      "t": 553729,
      "e": 21550,
      "ty": 2,
      "x": 930,
      "y": 609
    },
    {
      "t": 553779,
      "e": 21600,
      "ty": 41,
      "x": 26387,
      "y": 61306,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 553829,
      "e": 21650,
      "ty": 2,
      "x": 932,
      "y": 607
    },
    {
      "t": 553834,
      "e": 21655,
      "ty": 6,
      "x": 939,
      "y": 602,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 553929,
      "e": 21750,
      "ty": 2,
      "x": 941,
      "y": 600
    },
    {
      "t": 553953,
      "e": 21774,
      "ty": 3,
      "x": 941,
      "y": 600,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 553953,
      "e": 21774,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 554029,
      "e": 21850,
      "ty": 41,
      "x": 28766,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 554105,
      "e": 21926,
      "ty": 4,
      "x": 28766,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 554106,
      "e": 21927,
      "ty": 5,
      "x": 941,
      "y": 600,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 554728,
      "e": 22549,
      "ty": 2,
      "x": 988,
      "y": 602
    },
    {
      "t": 554780,
      "e": 22601,
      "ty": 41,
      "x": 40661,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 554829,
      "e": 22650,
      "ty": 2,
      "x": 1001,
      "y": 604
    },
    {
      "t": 554930,
      "e": 22751,
      "ty": 2,
      "x": 1006,
      "y": 605
    },
    {
      "t": 555001,
      "e": 22822,
      "ty": 7,
      "x": 1038,
      "y": 610,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 555029,
      "e": 22850,
      "ty": 2,
      "x": 1058,
      "y": 612
    },
    {
      "t": 555030,
      "e": 22851,
      "ty": 41,
      "x": 54071,
      "y": 63420,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 555129,
      "e": 22950,
      "ty": 2,
      "x": 1156,
      "y": 618
    },
    {
      "t": 555280,
      "e": 23101,
      "ty": 41,
      "x": 39534,
      "y": 33792,
      "ta": "html > body"
    },
    {
      "t": 557048,
      "e": 24869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 557181,
      "e": 25002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 557646,
      "e": 25467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "90"
    },
    {
      "t": 557646,
      "e": 25467,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 557781,
      "e": 25602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Z"
    },
    {
      "t": 557789,
      "e": 25610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "85"
    },
    {
      "t": 557789,
      "e": 25610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 557901,
      "e": 25722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ZU"
    },
    {
      "t": 558189,
      "e": 26010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 558190,
      "e": 26011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 558333,
      "e": 26154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ZUL"
    },
    {
      "t": 558509,
      "e": 26330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "85"
    },
    {
      "t": 558510,
      "e": 26331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 558589,
      "e": 26410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ZULU"
    },
    {
      "t": 560029,
      "e": 27850,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 560429,
      "e": 28250,
      "ty": 2,
      "x": 1136,
      "y": 651
    },
    {
      "t": 560529,
      "e": 28350,
      "ty": 2,
      "x": 1131,
      "y": 656
    },
    {
      "t": 560530,
      "e": 28351,
      "ty": 41,
      "x": 38673,
      "y": 35897,
      "ta": "html > body"
    },
    {
      "t": 560629,
      "e": 28450,
      "ty": 2,
      "x": 1126,
      "y": 658
    },
    {
      "t": 560729,
      "e": 28550,
      "ty": 2,
      "x": 1096,
      "y": 669
    },
    {
      "t": 560779,
      "e": 28600,
      "ty": 41,
      "x": 61425,
      "y": 40166,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 560829,
      "e": 28650,
      "ty": 2,
      "x": 1089,
      "y": 675
    },
    {
      "t": 560858,
      "e": 28679,
      "ty": 6,
      "x": 1086,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 560933,
      "e": 28754,
      "ty": 2,
      "x": 1086,
      "y": 681
    },
    {
      "t": 561033,
      "e": 28854,
      "ty": 41,
      "x": 60127,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 561133,
      "e": 28954,
      "ty": 3,
      "x": 1086,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 561134,
      "e": 28955,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ZULU"
    },
    {
      "t": 561135,
      "e": 28956,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 561136,
      "e": 28957,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 561275,
      "e": 29096,
      "ty": 4,
      "x": 60127,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 561276,
      "e": 29097,
      "ty": 5,
      "x": 1086,
      "y": 681,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 562359,
      "e": 30180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "98"
    },
    {
      "t": 562360,
      "e": 30181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 562512,
      "e": 30333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "2"
    },
    {
      "t": 562641,
      "e": 30462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 562641,
      "e": 30462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 562713,
      "e": 30534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21"
    },
    {
      "t": 562835,
      "e": 30656,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21"
    },
    {
      "t": 562864,
      "e": 30685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 562865,
      "e": 30686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 562944,
      "e": 30765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21*"
    },
    {
      "t": 563608,
      "e": 31429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 563687,
      "e": 31508,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21"
    },
    {
      "t": 563768,
      "e": 31589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 563848,
      "e": 31669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "2"
    },
    {
      "t": 563936,
      "e": 31757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 564024,
      "e": 31845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 564088,
      "e": 31909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 564151,
      "e": 31972,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 564264,
      "e": 32085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 564266,
      "e": 32087,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 564408,
      "e": 32229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 564408,
      "e": 32229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 564472,
      "e": 32293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21"
    },
    {
      "t": 564528,
      "e": 32349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21"
    },
    {
      "t": 564776,
      "e": 32597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 564777,
      "e": 32598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 564880,
      "e": 32701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21*"
    },
    {
      "t": 565033,
      "e": 32854,
      "ty": 2,
      "x": 1075,
      "y": 685
    },
    {
      "t": 565033,
      "e": 32854,
      "ty": 41,
      "x": 57748,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 565046,
      "e": 32867,
      "ty": 7,
      "x": 1074,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 565133,
      "e": 32954,
      "ty": 2,
      "x": 1069,
      "y": 723
    },
    {
      "t": 565232,
      "e": 33053,
      "ty": 2,
      "x": 1067,
      "y": 726
    },
    {
      "t": 565283,
      "e": 33104,
      "ty": 41,
      "x": 36366,
      "y": 39996,
      "ta": "html > body"
    },
    {
      "t": 565333,
      "e": 33154,
      "ty": 2,
      "x": 1047,
      "y": 715
    },
    {
      "t": 565433,
      "e": 33254,
      "ty": 2,
      "x": 946,
      "y": 704
    },
    {
      "t": 565533,
      "e": 33354,
      "ty": 41,
      "x": 29847,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 565613,
      "e": 33434,
      "ty": 6,
      "x": 949,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 565632,
      "e": 33453,
      "ty": 2,
      "x": 950,
      "y": 714
    },
    {
      "t": 565733,
      "e": 33554,
      "ty": 2,
      "x": 954,
      "y": 720
    },
    {
      "t": 565783,
      "e": 33604,
      "ty": 41,
      "x": 29932,
      "y": 23830,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 566233,
      "e": 34054,
      "ty": 2,
      "x": 958,
      "y": 726
    },
    {
      "t": 566284,
      "e": 34105,
      "ty": 41,
      "x": 32509,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 566333,
      "e": 34154,
      "ty": 2,
      "x": 959,
      "y": 728
    },
    {
      "t": 566605,
      "e": 34426,
      "ty": 3,
      "x": 959,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 566607,
      "e": 34428,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21*"
    },
    {
      "t": 566608,
      "e": 34429,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 566609,
      "e": 34430,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 566763,
      "e": 34584,
      "ty": 4,
      "x": 32509,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 566766,
      "e": 34587,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 566767,
      "e": 34588,
      "ty": 5,
      "x": 959,
      "y": 728,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 566767,
      "e": 34588,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 567863,
      "e": 35684,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 567891,
      "e": 35712,
      "ty": 6,
      "x": 959,
      "y": 728,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 569532,
      "e": 37353,
      "ty": 7,
      "x": 931,
      "y": 760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 569533,
      "e": 37354,
      "ty": 6,
      "x": 931,
      "y": 760,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 569534,
      "e": 37355,
      "ty": 2,
      "x": 931,
      "y": 760
    },
    {
      "t": 569534,
      "e": 37355,
      "ty": 41,
      "x": 30346,
      "y": 11739,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 569632,
      "e": 37453,
      "ty": 7,
      "x": 873,
      "y": 783,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 569632,
      "e": 37453,
      "ty": 2,
      "x": 873,
      "y": 783
    },
    {
      "t": 569733,
      "e": 37554,
      "ty": 2,
      "x": 867,
      "y": 783
    },
    {
      "t": 569782,
      "e": 37603,
      "ty": 41,
      "x": 28167,
      "y": 58410,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 569832,
      "e": 37653,
      "ty": 2,
      "x": 862,
      "y": 783
    },
    {
      "t": 569932,
      "e": 37753,
      "ty": 2,
      "x": 855,
      "y": 785
    },
    {
      "t": 570032,
      "e": 37853,
      "ty": 2,
      "x": 844,
      "y": 791
    },
    {
      "t": 570032,
      "e": 37853,
      "ty": 41,
      "x": 27085,
      "y": 59650,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 570032,
      "e": 37853,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 570133,
      "e": 37954,
      "ty": 2,
      "x": 822,
      "y": 798
    },
    {
      "t": 570232,
      "e": 38053,
      "ty": 2,
      "x": 810,
      "y": 803
    },
    {
      "t": 570282,
      "e": 38103,
      "ty": 41,
      "x": 24871,
      "y": 16420,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 570333,
      "e": 38154,
      "ty": 2,
      "x": 788,
      "y": 811
    },
    {
      "t": 570433,
      "e": 38254,
      "ty": 2,
      "x": 786,
      "y": 811
    },
    {
      "t": 570534,
      "e": 38355,
      "ty": 41,
      "x": 24231,
      "y": 23441,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 570633,
      "e": 38454,
      "ty": 2,
      "x": 785,
      "y": 811
    },
    {
      "t": 570783,
      "e": 38604,
      "ty": 41,
      "x": 24084,
      "y": 23441,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 570833,
      "e": 38654,
      "ty": 2,
      "x": 781,
      "y": 812
    },
    {
      "t": 570933,
      "e": 38754,
      "ty": 2,
      "x": 778,
      "y": 814
    },
    {
      "t": 571033,
      "e": 38854,
      "ty": 2,
      "x": 777,
      "y": 815
    },
    {
      "t": 571033,
      "e": 38854,
      "ty": 41,
      "x": 23789,
      "y": 32804,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 571133,
      "e": 38954,
      "ty": 2,
      "x": 764,
      "y": 817
    },
    {
      "t": 571233,
      "e": 39054,
      "ty": 2,
      "x": 748,
      "y": 817
    },
    {
      "t": 571283,
      "e": 39104,
      "ty": 41,
      "x": 22313,
      "y": 37485,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 571333,
      "e": 39154,
      "ty": 2,
      "x": 741,
      "y": 816
    },
    {
      "t": 571384,
      "e": 39205,
      "ty": 6,
      "x": 696,
      "y": 778,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 571417,
      "e": 39238,
      "ty": 7,
      "x": 674,
      "y": 748,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 571418,
      "e": 39239,
      "ty": 6,
      "x": 674,
      "y": 748,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 571433,
      "e": 39254,
      "ty": 2,
      "x": 674,
      "y": 748
    },
    {
      "t": 571452,
      "e": 39273,
      "ty": 7,
      "x": 649,
      "y": 716,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 571452,
      "e": 39273,
      "ty": 6,
      "x": 649,
      "y": 716,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 571484,
      "e": 39305,
      "ty": 7,
      "x": 636,
      "y": 689,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 571485,
      "e": 39306,
      "ty": 6,
      "x": 636,
      "y": 689,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 571517,
      "e": 39338,
      "ty": 7,
      "x": 623,
      "y": 667,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 571533,
      "e": 39354,
      "ty": 2,
      "x": 623,
      "y": 667
    },
    {
      "t": 571534,
      "e": 39355,
      "ty": 41,
      "x": 16212,
      "y": 40438,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 571633,
      "e": 39454,
      "ty": 2,
      "x": 618,
      "y": 656
    },
    {
      "t": 571733,
      "e": 39554,
      "ty": 2,
      "x": 603,
      "y": 656
    },
    {
      "t": 571783,
      "e": 39604,
      "ty": 41,
      "x": 14982,
      "y": 38734,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 571833,
      "e": 39654,
      "ty": 2,
      "x": 591,
      "y": 656
    },
    {
      "t": 571932,
      "e": 39753,
      "ty": 2,
      "x": 570,
      "y": 661
    },
    {
      "t": 572033,
      "e": 39854,
      "ty": 2,
      "x": 559,
      "y": 666
    },
    {
      "t": 572034,
      "e": 39855,
      "ty": 41,
      "x": 13064,
      "y": 40283,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 572333,
      "e": 40154,
      "ty": 2,
      "x": 556,
      "y": 669
    },
    {
      "t": 572351,
      "e": 40172,
      "ty": 6,
      "x": 554,
      "y": 671,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 572434,
      "e": 40255,
      "ty": 2,
      "x": 553,
      "y": 673
    },
    {
      "t": 572534,
      "e": 40355,
      "ty": 41,
      "x": 11195,
      "y": 4717,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 572633,
      "e": 40454,
      "ty": 2,
      "x": 549,
      "y": 679
    },
    {
      "t": 572733,
      "e": 40554,
      "ty": 2,
      "x": 548,
      "y": 681
    },
    {
      "t": 572784,
      "e": 40605,
      "ty": 41,
      "x": 23393,
      "y": 19711,
      "ta": "> div.masterdiv > div:[2] > div > ul > li > i:[2]"
    },
    {
      "t": 572833,
      "e": 40654,
      "ty": 2,
      "x": 547,
      "y": 681
    },
    {
      "t": 572933,
      "e": 40754,
      "ty": 2,
      "x": 544,
      "y": 685
    },
    {
      "t": 573033,
      "e": 40854,
      "ty": 2,
      "x": 540,
      "y": 691
    },
    {
      "t": 573034,
      "e": 40855,
      "ty": 41,
      "x": 15570,
      "y": 52479,
      "ta": "> div.masterdiv > div:[2] > div > ul > li > i:[2]"
    },
    {
      "t": 573133,
      "e": 40954,
      "ty": 2,
      "x": 539,
      "y": 693
    },
    {
      "t": 573284,
      "e": 41105,
      "ty": 41,
      "x": 14592,
      "y": 59032,
      "ta": "> div.masterdiv > div:[2] > div > ul > li > i:[2]"
    },
    {
      "t": 573534,
      "e": 41355,
      "ty": 2,
      "x": 537,
      "y": 698
    },
    {
      "t": 573534,
      "e": 41355,
      "ty": 41,
      "x": 10385,
      "y": 63231,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 573536,
      "e": 41357,
      "ty": 7,
      "x": 536,
      "y": 701,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 573536,
      "e": 41357,
      "ty": 6,
      "x": 536,
      "y": 701,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 573634,
      "e": 41455,
      "ty": 2,
      "x": 525,
      "y": 724
    },
    {
      "t": 573733,
      "e": 41554,
      "ty": 2,
      "x": 524,
      "y": 726
    },
    {
      "t": 573752,
      "e": 41573,
      "ty": 7,
      "x": 522,
      "y": 728,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 573753,
      "e": 41574,
      "ty": 6,
      "x": 522,
      "y": 728,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 573784,
      "e": 41605,
      "ty": 41,
      "x": 9574,
      "y": 4717,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 573832,
      "e": 41653,
      "ty": 2,
      "x": 519,
      "y": 732
    },
    {
      "t": 573931,
      "e": 41752,
      "ty": 2,
      "x": 512,
      "y": 741
    },
    {
      "t": 574032,
      "e": 41853,
      "ty": 2,
      "x": 505,
      "y": 748
    },
    {
      "t": 574032,
      "e": 41853,
      "ty": 41,
      "x": 8764,
      "y": 49187,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 574233,
      "e": 42054,
      "ty": 2,
      "x": 503,
      "y": 748
    },
    {
      "t": 574282,
      "e": 42103,
      "ty": 41,
      "x": 8662,
      "y": 49187,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 575019,
      "e": 42840,
      "ty": 7,
      "x": 503,
      "y": 716,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 575019,
      "e": 42840,
      "ty": 6,
      "x": 503,
      "y": 716,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 575032,
      "e": 42853,
      "ty": 2,
      "x": 503,
      "y": 716
    },
    {
      "t": 575032,
      "e": 42853,
      "ty": 41,
      "x": 8662,
      "y": 39825,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 575053,
      "e": 42874,
      "ty": 7,
      "x": 503,
      "y": 690,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 575053,
      "e": 42874,
      "ty": 6,
      "x": 503,
      "y": 690,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 575086,
      "e": 42907,
      "ty": 7,
      "x": 501,
      "y": 663,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 575132,
      "e": 42953,
      "ty": 2,
      "x": 499,
      "y": 654
    },
    {
      "t": 575232,
      "e": 43053,
      "ty": 2,
      "x": 499,
      "y": 653
    },
    {
      "t": 575282,
      "e": 43103,
      "ty": 41,
      "x": 10112,
      "y": 38269,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 575532,
      "e": 43353,
      "ty": 2,
      "x": 488,
      "y": 667
    },
    {
      "t": 575533,
      "e": 43354,
      "ty": 41,
      "x": 9571,
      "y": 40438,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 575732,
      "e": 43553,
      "ty": 2,
      "x": 485,
      "y": 665
    },
    {
      "t": 575782,
      "e": 43603,
      "ty": 41,
      "x": 8980,
      "y": 38734,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 575833,
      "e": 43654,
      "ty": 2,
      "x": 461,
      "y": 644
    },
    {
      "t": 575932,
      "e": 43753,
      "ty": 2,
      "x": 381,
      "y": 563
    },
    {
      "t": 576032,
      "e": 43853,
      "ty": 2,
      "x": 379,
      "y": 535
    },
    {
      "t": 576033,
      "e": 43854,
      "ty": 41,
      "x": 4966,
      "y": 63231,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[2] > td"
    },
    {
      "t": 576232,
      "e": 44053,
      "ty": 2,
      "x": 378,
      "y": 535
    },
    {
      "t": 576282,
      "e": 44103,
      "ty": 41,
      "x": 4857,
      "y": 63231,
      "ta": "> div.masterdiv > div:[2] > div > table > tbody > tr:[2] > td"
    },
    {
      "t": 576505,
      "e": 44326,
      "ty": 6,
      "x": 381,
      "y": 531,
      "ta": "#da1"
    },
    {
      "t": 576532,
      "e": 44353,
      "ty": 2,
      "x": 386,
      "y": 525
    },
    {
      "t": 576533,
      "e": 44354,
      "ty": 41,
      "x": 5736,
      "y": 42648,
      "ta": "#da1"
    },
    {
      "t": 576587,
      "e": 44408,
      "ty": 7,
      "x": 403,
      "y": 506,
      "ta": "#da1"
    },
    {
      "t": 576632,
      "e": 44453,
      "ty": 2,
      "x": 409,
      "y": 496
    },
    {
      "t": 576732,
      "e": 44553,
      "ty": 2,
      "x": 418,
      "y": 476
    },
    {
      "t": 576782,
      "e": 44603,
      "ty": 41,
      "x": 6373,
      "y": 9143,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 576832,
      "e": 44653,
      "ty": 2,
      "x": 427,
      "y": 460
    },
    {
      "t": 576932,
      "e": 44753,
      "ty": 2,
      "x": 431,
      "y": 457
    },
    {
      "t": 577032,
      "e": 44853,
      "ty": 2,
      "x": 432,
      "y": 457
    },
    {
      "t": 577033,
      "e": 44854,
      "ty": 41,
      "x": 6816,
      "y": 59701,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 577132,
      "e": 44953,
      "ty": 2,
      "x": 469,
      "y": 448
    },
    {
      "t": 577232,
      "e": 45053,
      "ty": 2,
      "x": 475,
      "y": 448
    },
    {
      "t": 577283,
      "e": 45104,
      "ty": 41,
      "x": 8931,
      "y": 49169,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 577783,
      "e": 45604,
      "ty": 41,
      "x": 8980,
      "y": 49169,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 577832,
      "e": 45653,
      "ty": 2,
      "x": 476,
      "y": 448
    },
    {
      "t": 578032,
      "e": 45853,
      "ty": 2,
      "x": 483,
      "y": 448
    },
    {
      "t": 578033,
      "e": 45854,
      "ty": 41,
      "x": 9325,
      "y": 49169,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 578132,
      "e": 45953,
      "ty": 2,
      "x": 554,
      "y": 456
    },
    {
      "t": 578232,
      "e": 46053,
      "ty": 2,
      "x": 568,
      "y": 459
    },
    {
      "t": 578282,
      "e": 46103,
      "ty": 41,
      "x": 13556,
      "y": 62042,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 578333,
      "e": 46154,
      "ty": 2,
      "x": 569,
      "y": 459
    },
    {
      "t": 578932,
      "e": 46753,
      "ty": 2,
      "x": 572,
      "y": 459
    },
    {
      "t": 579032,
      "e": 46853,
      "ty": 2,
      "x": 685,
      "y": 457
    },
    {
      "t": 579033,
      "e": 46854,
      "ty": 41,
      "x": 19262,
      "y": 59701,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 579132,
      "e": 46953,
      "ty": 2,
      "x": 776,
      "y": 456
    },
    {
      "t": 579233,
      "e": 47054,
      "ty": 2,
      "x": 848,
      "y": 456
    },
    {
      "t": 579283,
      "e": 47104,
      "ty": 41,
      "x": 28413,
      "y": 58531,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 579333,
      "e": 47154,
      "ty": 2,
      "x": 882,
      "y": 456
    },
    {
      "t": 579433,
      "e": 47254,
      "ty": 2,
      "x": 908,
      "y": 456
    },
    {
      "t": 579533,
      "e": 47354,
      "ty": 41,
      "x": 30233,
      "y": 58531,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 579783,
      "e": 47604,
      "ty": 41,
      "x": 30086,
      "y": 59701,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 579832,
      "e": 47653,
      "ty": 2,
      "x": 905,
      "y": 457
    },
    {
      "t": 579933,
      "e": 47754,
      "ty": 2,
      "x": 904,
      "y": 462
    },
    {
      "t": 580032,
      "e": 47853,
      "ty": 2,
      "x": 902,
      "y": 467
    },
    {
      "t": 580034,
      "e": 47855,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 580036,
      "e": 47857,
      "ty": 41,
      "x": 29938,
      "y": 9453,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 580133,
      "e": 47954,
      "ty": 2,
      "x": 1066,
      "y": 453
    },
    {
      "t": 580232,
      "e": 48053,
      "ty": 2,
      "x": 1257,
      "y": 425
    },
    {
      "t": 580283,
      "e": 48104,
      "ty": 41,
      "x": 47403,
      "y": 22253,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 580532,
      "e": 48353,
      "ty": 2,
      "x": 1235,
      "y": 439
    },
    {
      "t": 580532,
      "e": 48353,
      "ty": 41,
      "x": 46321,
      "y": 38637,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 580632,
      "e": 48453,
      "ty": 2,
      "x": 1205,
      "y": 456
    },
    {
      "t": 580733,
      "e": 48554,
      "ty": 2,
      "x": 1198,
      "y": 461
    },
    {
      "t": 580782,
      "e": 48603,
      "ty": 41,
      "x": 44500,
      "y": 64383,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 581633,
      "e": 49454,
      "ty": 2,
      "x": 1180,
      "y": 467
    },
    {
      "t": 581709,
      "e": 49530,
      "ty": 6,
      "x": 887,
      "y": 523,
      "ta": "#da1"
    },
    {
      "t": 581732,
      "e": 49553,
      "ty": 2,
      "x": 859,
      "y": 527
    },
    {
      "t": 581783,
      "e": 49604,
      "ty": 41,
      "x": 51802,
      "y": 55755,
      "ta": "#da1"
    },
    {
      "t": 581833,
      "e": 49654,
      "ty": 2,
      "x": 769,
      "y": 531
    },
    {
      "t": 581932,
      "e": 49753,
      "ty": 2,
      "x": 685,
      "y": 531
    },
    {
      "t": 582032,
      "e": 49853,
      "ty": 2,
      "x": 658,
      "y": 531
    },
    {
      "t": 582033,
      "e": 49854,
      "ty": 41,
      "x": 35428,
      "y": 62309,
      "ta": "#da1"
    },
    {
      "t": 582332,
      "e": 50153,
      "ty": 2,
      "x": 660,
      "y": 526
    },
    {
      "t": 582432,
      "e": 50253,
      "ty": 2,
      "x": 660,
      "y": 523
    },
    {
      "t": 582532,
      "e": 50353,
      "ty": 2,
      "x": 660,
      "y": 515
    },
    {
      "t": 582532,
      "e": 50353,
      "ty": 41,
      "x": 35646,
      "y": 9881,
      "ta": "#da1"
    },
    {
      "t": 582558,
      "e": 50379,
      "ty": 7,
      "x": 670,
      "y": 510,
      "ta": "#da1"
    },
    {
      "t": 582633,
      "e": 50454,
      "ty": 2,
      "x": 838,
      "y": 487
    },
    {
      "t": 582733,
      "e": 50554,
      "ty": 2,
      "x": 1004,
      "y": 469
    },
    {
      "t": 582783,
      "e": 50604,
      "ty": 41,
      "x": 35497,
      "y": 9608,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 582833,
      "e": 50654,
      "ty": 2,
      "x": 1043,
      "y": 467
    },
    {
      "t": 582932,
      "e": 50753,
      "ty": 2,
      "x": 1079,
      "y": 451
    },
    {
      "t": 583033,
      "e": 50854,
      "ty": 2,
      "x": 1084,
      "y": 449
    },
    {
      "t": 583033,
      "e": 50854,
      "ty": 41,
      "x": 38892,
      "y": 50339,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 583232,
      "e": 51053,
      "ty": 2,
      "x": 1063,
      "y": 458
    },
    {
      "t": 583283,
      "e": 51104,
      "ty": 41,
      "x": 33333,
      "y": 7748,
      "ta": "> div.masterdiv > div:[2] > div > table"
    },
    {
      "t": 583293,
      "e": 51114,
      "ty": 6,
      "x": 931,
      "y": 512,
      "ta": "#da1"
    },
    {
      "t": 583310,
      "e": 51131,
      "ty": 7,
      "x": 875,
      "y": 538,
      "ta": "#da1"
    },
    {
      "t": 583333,
      "e": 51154,
      "ty": 2,
      "x": 817,
      "y": 565
    },
    {
      "t": 583432,
      "e": 51253,
      "ty": 2,
      "x": 696,
      "y": 625
    },
    {
      "t": 583533,
      "e": 51354,
      "ty": 2,
      "x": 662,
      "y": 636
    },
    {
      "t": 583533,
      "e": 51354,
      "ty": 41,
      "x": 18131,
      "y": 25782,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 583633,
      "e": 51454,
      "ty": 2,
      "x": 617,
      "y": 668
    },
    {
      "t": 583783,
      "e": 51604,
      "ty": 41,
      "x": 15917,
      "y": 40593,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 583964,
      "e": 51785,
      "ty": 6,
      "x": 618,
      "y": 673,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 584032,
      "e": 51853,
      "ty": 2,
      "x": 695,
      "y": 671
    },
    {
      "t": 584033,
      "e": 51854,
      "ty": 41,
      "x": 18390,
      "y": 36,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 584044,
      "e": 51865,
      "ty": 7,
      "x": 738,
      "y": 664,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 584133,
      "e": 51954,
      "ty": 2,
      "x": 834,
      "y": 634
    },
    {
      "t": 584232,
      "e": 52053,
      "ty": 2,
      "x": 863,
      "y": 612
    },
    {
      "t": 584282,
      "e": 52103,
      "ty": 41,
      "x": 28019,
      "y": 31917,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 586233,
      "e": 54054,
      "ty": 2,
      "x": 358,
      "y": 467
    },
    {
      "t": 586283,
      "e": 54104,
      "ty": 41,
      "x": 0,
      "y": 8364,
      "ta": "html"
    },
    {
      "t": 586333,
      "e": 54154,
      "ty": 2,
      "x": 0,
      "y": 16
    },
    {
      "t": 586533,
      "e": 54354,
      "ty": 41,
      "x": 0,
      "y": 886,
      "ta": "html"
    },
    {
      "t": 587733,
      "e": 55554,
      "ty": 2,
      "x": 31,
      "y": 30
    },
    {
      "t": 587783,
      "e": 55604,
      "ty": 41,
      "x": 4408,
      "y": 8475,
      "ta": "> div.masterdiv"
    },
    {
      "t": 587833,
      "e": 55654,
      "ty": 2,
      "x": 185,
      "y": 509
    },
    {
      "t": 587932,
      "e": 55753,
      "ty": 2,
      "x": 350,
      "y": 956
    },
    {
      "t": 588033,
      "e": 55854,
      "ty": 2,
      "x": 373,
      "y": 983
    },
    {
      "t": 588033,
      "e": 55854,
      "ty": 41,
      "x": 3913,
      "y": 59324,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 588533,
      "e": 56354,
      "ty": 2,
      "x": 425,
      "y": 880
    },
    {
      "t": 588533,
      "e": 56354,
      "ty": 41,
      "x": 6471,
      "y": 52191,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 588633,
      "e": 56454,
      "ty": 2,
      "x": 474,
      "y": 824
    },
    {
      "t": 588733,
      "e": 56554,
      "ty": 2,
      "x": 495,
      "y": 808
    },
    {
      "t": 588783,
      "e": 56604,
      "ty": 41,
      "x": 11243,
      "y": 60269,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 588832,
      "e": 56653,
      "ty": 2,
      "x": 527,
      "y": 786
    },
    {
      "t": 588864,
      "e": 56685,
      "ty": 6,
      "x": 529,
      "y": 780,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 588933,
      "e": 56754,
      "ty": 2,
      "x": 533,
      "y": 772
    },
    {
      "t": 589033,
      "e": 56854,
      "ty": 2,
      "x": 533,
      "y": 766
    },
    {
      "t": 589034,
      "e": 56855,
      "ty": 41,
      "x": 10182,
      "y": 25782,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 589898,
      "e": 57719,
      "ty": 7,
      "x": 506,
      "y": 784,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 589933,
      "e": 57754,
      "ty": 2,
      "x": 498,
      "y": 791
    },
    {
      "t": 590033,
      "e": 57854,
      "ty": 2,
      "x": 499,
      "y": 794
    },
    {
      "t": 590034,
      "e": 57855,
      "ty": 41,
      "x": 10112,
      "y": 60114,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 590034,
      "e": 57855,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 590433,
      "e": 58254,
      "ty": 2,
      "x": 563,
      "y": 821
    },
    {
      "t": 590534,
      "e": 58355,
      "ty": 2,
      "x": 660,
      "y": 860
    },
    {
      "t": 590534,
      "e": 58355,
      "ty": 41,
      "x": 18033,
      "y": 50806,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 590633,
      "e": 58454,
      "ty": 2,
      "x": 767,
      "y": 935
    },
    {
      "t": 590733,
      "e": 58554,
      "ty": 2,
      "x": 907,
      "y": 1027
    },
    {
      "t": 590783,
      "e": 58604,
      "ty": 41,
      "x": 31906,
      "y": 63963,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 590833,
      "e": 58654,
      "ty": 2,
      "x": 946,
      "y": 1055
    },
    {
      "t": 591033,
      "e": 58854,
      "ty": 41,
      "x": 32103,
      "y": 64310,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 591132,
      "e": 58953,
      "ty": 2,
      "x": 770,
      "y": 952
    },
    {
      "t": 591232,
      "e": 59053,
      "ty": 2,
      "x": 545,
      "y": 841
    },
    {
      "t": 591283,
      "e": 59104,
      "ty": 41,
      "x": 12375,
      "y": 49491,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 591333,
      "e": 59154,
      "ty": 2,
      "x": 544,
      "y": 840
    },
    {
      "t": 591533,
      "e": 59354,
      "ty": 2,
      "x": 569,
      "y": 839
    },
    {
      "t": 591533,
      "e": 59354,
      "ty": 41,
      "x": 13556,
      "y": 49352,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 591633,
      "e": 59454,
      "ty": 2,
      "x": 572,
      "y": 839
    },
    {
      "t": 591783,
      "e": 59604,
      "ty": 41,
      "x": 13703,
      "y": 49352,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 592033,
      "e": 59854,
      "ty": 2,
      "x": 581,
      "y": 831
    },
    {
      "t": 592034,
      "e": 59855,
      "ty": 41,
      "x": 14146,
      "y": 48798,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 592133,
      "e": 59954,
      "ty": 2,
      "x": 602,
      "y": 816
    },
    {
      "t": 592233,
      "e": 60054,
      "ty": 2,
      "x": 610,
      "y": 812
    },
    {
      "t": 592283,
      "e": 60104,
      "ty": 41,
      "x": 15720,
      "y": 21101,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 592332,
      "e": 60153,
      "ty": 2,
      "x": 622,
      "y": 804
    },
    {
      "t": 592433,
      "e": 60254,
      "ty": 2,
      "x": 637,
      "y": 796
    },
    {
      "t": 592533,
      "e": 60354,
      "ty": 2,
      "x": 639,
      "y": 795
    },
    {
      "t": 592533,
      "e": 60354,
      "ty": 41,
      "x": 16999,
      "y": 60269,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 592633,
      "e": 60454,
      "ty": 2,
      "x": 646,
      "y": 791
    },
    {
      "t": 592733,
      "e": 60554,
      "ty": 2,
      "x": 651,
      "y": 789
    },
    {
      "t": 592784,
      "e": 60605,
      "ty": 41,
      "x": 17836,
      "y": 58875,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 592833,
      "e": 60654,
      "ty": 2,
      "x": 661,
      "y": 786
    },
    {
      "t": 592933,
      "e": 60754,
      "ty": 2,
      "x": 664,
      "y": 786
    },
    {
      "t": 593033,
      "e": 60854,
      "ty": 2,
      "x": 666,
      "y": 786
    },
    {
      "t": 593034,
      "e": 60855,
      "ty": 41,
      "x": 18328,
      "y": 58875,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 593133,
      "e": 60954,
      "ty": 2,
      "x": 668,
      "y": 786
    },
    {
      "t": 593233,
      "e": 61054,
      "ty": 2,
      "x": 673,
      "y": 786
    },
    {
      "t": 593283,
      "e": 61104,
      "ty": 41,
      "x": 18672,
      "y": 58875,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 593433,
      "e": 61254,
      "ty": 2,
      "x": 699,
      "y": 804
    },
    {
      "t": 593533,
      "e": 61354,
      "ty": 2,
      "x": 754,
      "y": 835
    },
    {
      "t": 593534,
      "e": 61355,
      "ty": 41,
      "x": 22657,
      "y": 49075,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 593633,
      "e": 61454,
      "ty": 2,
      "x": 769,
      "y": 854
    },
    {
      "t": 593733,
      "e": 61554,
      "ty": 2,
      "x": 774,
      "y": 861
    },
    {
      "t": 593783,
      "e": 61604,
      "ty": 41,
      "x": 23936,
      "y": 50945,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 593833,
      "e": 61654,
      "ty": 2,
      "x": 789,
      "y": 851
    },
    {
      "t": 593933,
      "e": 61754,
      "ty": 2,
      "x": 801,
      "y": 836
    },
    {
      "t": 594033,
      "e": 61854,
      "ty": 2,
      "x": 802,
      "y": 835
    },
    {
      "t": 594033,
      "e": 61854,
      "ty": 41,
      "x": 25018,
      "y": 49075,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 594133,
      "e": 61954,
      "ty": 2,
      "x": 885,
      "y": 858
    },
    {
      "t": 594233,
      "e": 62054,
      "ty": 2,
      "x": 966,
      "y": 889
    },
    {
      "t": 594283,
      "e": 62104,
      "ty": 41,
      "x": 33825,
      "y": 53438,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 594332,
      "e": 62153,
      "ty": 2,
      "x": 990,
      "y": 905
    },
    {
      "t": 594433,
      "e": 62254,
      "ty": 2,
      "x": 1006,
      "y": 932
    },
    {
      "t": 594532,
      "e": 62353,
      "ty": 2,
      "x": 1026,
      "y": 992
    },
    {
      "t": 594532,
      "e": 62353,
      "ty": 41,
      "x": 36039,
      "y": 59947,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 594633,
      "e": 62454,
      "ty": 2,
      "x": 1037,
      "y": 1053
    },
    {
      "t": 594733,
      "e": 62554,
      "ty": 2,
      "x": 1028,
      "y": 1118
    },
    {
      "t": 594784,
      "e": 62605,
      "ty": 41,
      "x": 63896,
      "y": 33966,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 594832,
      "e": 62653,
      "ty": 2,
      "x": 1023,
      "y": 1147
    },
    {
      "t": 594932,
      "e": 62753,
      "ty": 2,
      "x": 1022,
      "y": 1151
    },
    {
      "t": 595033,
      "e": 62854,
      "ty": 2,
      "x": 1007,
      "y": 1118
    },
    {
      "t": 595033,
      "e": 62854,
      "ty": 41,
      "x": 55002,
      "y": 25102,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 595068,
      "e": 62889,
      "ty": 6,
      "x": 1005,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 595132,
      "e": 62953,
      "ty": 2,
      "x": 1005,
      "y": 1098
    },
    {
      "t": 595232,
      "e": 63053,
      "ty": 2,
      "x": 1005,
      "y": 1095
    },
    {
      "t": 595282,
      "e": 63103,
      "ty": 41,
      "x": 52154,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 595949,
      "e": 63770,
      "ty": 3,
      "x": 1005,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 595951,
      "e": 63772,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 596131,
      "e": 63952,
      "ty": 4,
      "x": 52154,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 596133,
      "e": 63954,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 596134,
      "e": 63955,
      "ty": 5,
      "x": 1005,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 596137,
      "e": 63958,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 597132,
      "e": 64953,
      "ty": 2,
      "x": 1006,
      "y": 1094
    },
    {
      "t": 597138,
      "e": 64959,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 597282,
      "e": 65103,
      "ty": 41,
      "x": 34368,
      "y": 60161,
      "ta": "html > body"
    },
    {
      "t": 600033,
      "e": 67854,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 600783,
      "e": 68604,
      "ty": 41,
      "x": 34403,
      "y": 60050,
      "ta": "html > body"
    },
    {
      "t": 600832,
      "e": 68653,
      "ty": 2,
      "x": 1008,
      "y": 1092
    },
    {
      "t": 601033,
      "e": 68854,
      "ty": 41,
      "x": 34437,
      "y": 60050,
      "ta": "html > body"
    },
    {
      "t": 606133,
      "e": 73854,
      "ty": 2,
      "x": 1007,
      "y": 1085
    },
    {
      "t": 606233,
      "e": 73954,
      "ty": 2,
      "x": 1007,
      "y": 1084
    },
    {
      "t": 606282,
      "e": 74003,
      "ty": 41,
      "x": 34403,
      "y": 59607,
      "ta": "html > body"
    },
    {
      "t": 606433,
      "e": 74154,
      "ty": 2,
      "x": 1005,
      "y": 1070
    },
    {
      "t": 606533,
      "e": 74254,
      "ty": 2,
      "x": 1000,
      "y": 1053
    },
    {
      "t": 606533,
      "e": 74254,
      "ty": 41,
      "x": 34162,
      "y": 57890,
      "ta": "html > body"
    },
    {
      "t": 606632,
      "e": 74353,
      "ty": 2,
      "x": 999,
      "y": 1050
    },
    {
      "t": 606732,
      "e": 74453,
      "ty": 2,
      "x": 999,
      "y": 1048
    },
    {
      "t": 606783,
      "e": 74504,
      "ty": 41,
      "x": 34093,
      "y": 57557,
      "ta": "html > body"
    },
    {
      "t": 606833,
      "e": 74554,
      "ty": 2,
      "x": 998,
      "y": 1047
    },
    {
      "t": 606933,
      "e": 74654,
      "ty": 2,
      "x": 996,
      "y": 1031
    },
    {
      "t": 607033,
      "e": 74754,
      "ty": 2,
      "x": 987,
      "y": 974
    },
    {
      "t": 607033,
      "e": 74754,
      "ty": 41,
      "x": 34102,
      "y": 64331,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 607133,
      "e": 74854,
      "ty": 2,
      "x": 987,
      "y": 917
    },
    {
      "t": 607232,
      "e": 74953,
      "ty": 2,
      "x": 989,
      "y": 894
    },
    {
      "t": 607283,
      "e": 75004,
      "ty": 41,
      "x": 34248,
      "y": 57964,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 607332,
      "e": 75053,
      "ty": 2,
      "x": 991,
      "y": 891
    },
    {
      "t": 607533,
      "e": 75254,
      "ty": 2,
      "x": 991,
      "y": 890
    },
    {
      "t": 607533,
      "e": 75254,
      "ty": 41,
      "x": 34296,
      "y": 57809,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 607633,
      "e": 75354,
      "ty": 2,
      "x": 992,
      "y": 888
    },
    {
      "t": 607733,
      "e": 75454,
      "ty": 2,
      "x": 992,
      "y": 885
    },
    {
      "t": 607783,
      "e": 75504,
      "ty": 41,
      "x": 34393,
      "y": 57187,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 607833,
      "e": 75554,
      "ty": 2,
      "x": 993,
      "y": 882
    },
    {
      "t": 608283,
      "e": 76004,
      "ty": 41,
      "x": 34393,
      "y": 57110,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 608332,
      "e": 76053,
      "ty": 2,
      "x": 993,
      "y": 878
    },
    {
      "t": 608533,
      "e": 76254,
      "ty": 2,
      "x": 994,
      "y": 920
    },
    {
      "t": 608533,
      "e": 76254,
      "ty": 41,
      "x": 34442,
      "y": 60138,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 608633,
      "e": 76354,
      "ty": 2,
      "x": 994,
      "y": 976
    },
    {
      "t": 608733,
      "e": 76454,
      "ty": 2,
      "x": 994,
      "y": 979
    },
    {
      "t": 608783,
      "e": 76504,
      "ty": 41,
      "x": 34442,
      "y": 64719,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 608932,
      "e": 76653,
      "ty": 2,
      "x": 994,
      "y": 981
    },
    {
      "t": 609033,
      "e": 76754,
      "ty": 2,
      "x": 994,
      "y": 989
    },
    {
      "t": 609033,
      "e": 76754,
      "ty": 41,
      "x": 34442,
      "y": 65496,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 609833,
      "e": 77554,
      "ty": 2,
      "x": 994,
      "y": 985
    },
    {
      "t": 609933,
      "e": 77654,
      "ty": 2,
      "x": 993,
      "y": 979
    },
    {
      "t": 610033,
      "e": 77754,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 610034,
      "e": 77755,
      "ty": 41,
      "x": 34393,
      "y": 64719,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 610266,
      "e": 77987,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 611271,
      "e": 78992,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 222, dom: 756, initialDom: 765",
  "javascriptErrors": []
}