var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "53cec0c9b7625614409fbe188fd4d22a",
  "created": "2018-05-29T15:07:23.957256-07:00",
  "lastActivity": "2018-05-29T15:07:58.036256-07:00",
  "pageViews": [
    {
      "id": "0529230784a5875411dc23e566197a4ad71423d1",
      "startTime": "2018-05-29T15:07:23.9627555-07:00",
      "endTime": "2018-05-29T15:07:58.036256-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 34322,
      "engagementTime": 34222,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 34322,
  "engagementTime": 34222,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=9PKA7",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b73c853d65e1e9b280cc02f12d3aa18e",
  "gdpr": false
}