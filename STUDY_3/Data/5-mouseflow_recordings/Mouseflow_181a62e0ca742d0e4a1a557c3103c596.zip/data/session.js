var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "181a62e0ca742d0e4a1a557c3103c596",
  "created": "2018-06-01T10:15:16.727398-07:00",
  "lastActivity": "2018-06-01T10:15:32.2023821-07:00",
  "pageViews": [
    {
      "id": "06011685307a552911277f9431005c9470747831",
      "startTime": "2018-06-01T10:15:16.9480939-07:00",
      "endTime": "2018-06-01T10:15:32.2023821-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 15449,
      "engagementTime": 15299,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15449,
  "engagementTime": 15299,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=1Z2H9",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "818bfeed0c189d3beeefb663181e52a0",
  "gdpr": false
}