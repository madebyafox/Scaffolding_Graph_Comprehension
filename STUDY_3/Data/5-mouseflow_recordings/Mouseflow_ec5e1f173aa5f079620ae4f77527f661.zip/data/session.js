var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ec5e1f173aa5f079620ae4f77527f661",
  "created": "2018-05-25T09:11:20.5876778-07:00",
  "lastActivity": "2018-05-25T09:13:53.7266778-07:00",
  "pageViews": [
    {
      "id": "05252055c84be0c24adef8b22b07778ff479e59c",
      "startTime": "2018-05-25T09:11:20.5876778-07:00",
      "endTime": "2018-05-25T09:13:53.7266778-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 153139,
      "engagementTime": 60008,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 153139,
  "engagementTime": 60008,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=EJPRM",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e6cd241e98d87dcdfde8e0beba6cc530",
  "gdpr": false
}