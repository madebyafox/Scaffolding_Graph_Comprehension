var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5d4f017bb7779f3d122e89d6c11fe5d4",
  "created": "2018-05-22T15:18:40.7219711-07:00",
  "lastActivity": "2018-05-22T15:18:51.1639711-07:00",
  "pageViews": [
    {
      "id": "052241213962f65de719a6b582016f2c6e90a059",
      "startTime": "2018-05-22T15:18:40.7219711-07:00",
      "endTime": "2018-05-22T15:18:51.1639711-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 10442,
      "engagementTime": 10393,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 10442,
  "engagementTime": 10393,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=C30CF",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "450ce0be25b69a4bf5a536e5d67df446",
  "gdpr": false
}