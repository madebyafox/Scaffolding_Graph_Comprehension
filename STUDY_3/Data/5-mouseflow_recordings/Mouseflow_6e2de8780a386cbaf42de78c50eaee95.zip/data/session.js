var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6e2de8780a386cbaf42de78c50eaee95",
  "created": "2018-05-25T11:23:13.4183279-07:00",
  "lastActivity": "2018-05-25T11:23:39.2483279-07:00",
  "pageViews": [
    {
      "id": "05251310e2792714a14c569e31f344306bf7b48b",
      "startTime": "2018-05-25T11:23:13.4183279-07:00",
      "endTime": "2018-05-25T11:23:39.2483279-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 25830,
      "engagementTime": 25830,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 25830,
  "engagementTime": 25830,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.43",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ESMO3",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "94a5d5736bb67e7bf0ebe666c67a4bf1",
  "gdpr": false
}