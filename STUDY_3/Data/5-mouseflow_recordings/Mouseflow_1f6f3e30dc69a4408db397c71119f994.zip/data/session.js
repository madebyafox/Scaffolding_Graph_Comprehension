var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1f6f3e30dc69a4408db397c71119f994",
  "created": "2018-06-01T10:14:44.3604176-07:00",
  "lastActivity": "2018-06-01T10:15:20.7929771-07:00",
  "pageViews": [
    {
      "id": "06014448fde9ec707434859da328671866fe0ab1",
      "startTime": "2018-06-01T10:14:44.6293772-07:00",
      "endTime": "2018-06-01T10:15:20.7929771-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 36605,
      "engagementTime": 34351,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 36605,
  "engagementTime": 34351,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MWJFN",
    "CONDITION=115",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "dde5922c4f4ad7c5c264f8f7dd72ee29",
  "gdpr": false
}