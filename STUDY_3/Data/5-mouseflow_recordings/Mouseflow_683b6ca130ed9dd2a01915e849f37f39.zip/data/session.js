var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "683b6ca130ed9dd2a01915e849f37f39",
  "created": "2018-05-15T17:16:51.9748435-07:00",
  "lastActivity": "2018-05-15T17:17:21.3119714-07:00",
  "pageViews": [
    {
      "id": "0515522431409ef0870b47b9dd0a6401dccc5fa3",
      "startTime": "2018-05-15T17:16:52.3307054-07:00",
      "endTime": "2018-05-15T17:17:21.3119714-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 28994,
      "engagementTime": 28994,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 28994,
  "engagementTime": 28994,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=6MWHZ",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "bf3f29d754b2ece9a8559fdb55e1fadb",
  "gdpr": false
}