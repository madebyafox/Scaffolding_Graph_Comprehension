var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "de8a2bf8d767d4e1dd6cd6440158f4bc",
  "created": "2018-05-29T14:07:57.3223141-07:00",
  "lastActivity": "2018-05-29T14:08:22.5913141-07:00",
  "pageViews": [
    {
      "id": "0529561674572de21828dba44feca93c738a6d02",
      "startTime": "2018-05-29T14:07:57.3223141-07:00",
      "endTime": "2018-05-29T14:08:22.5913141-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 25269,
      "engagementTime": 25269,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 25269,
  "engagementTime": 25269,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8TCFP",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6085351d9a00cdadcaeb31f5d4613123",
  "gdpr": false
}