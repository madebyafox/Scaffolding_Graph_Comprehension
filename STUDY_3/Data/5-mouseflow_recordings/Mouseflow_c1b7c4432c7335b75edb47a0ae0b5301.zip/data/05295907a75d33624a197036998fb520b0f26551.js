var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05295907a75d33624a197036998fb520b0f26551"] = {
  "startTime": "2018-05-29T21:13:58.91749Z",
  "websitePageUrl": "/16",
  "visitTime": 80052,
  "engagementTime": 79840,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "c1b7c4432c7335b75edb47a0ae0b5301",
    "created": "2018-05-29T21:13:58.91749+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=XD9UF",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "5e860dfb78360595aee1505de84ec8c7",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c1b7c4432c7335b75edb47a0ae0b5301/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 253,
      "e": 253,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 510,
      "y": 781
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 45403,
      "y": 42046,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 465,
      "y": 726
    },
    {
      "t": 848,
      "e": 848,
      "ty": 6,
      "x": 428,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 898,
      "e": 898,
      "ty": 7,
      "x": 397,
      "y": 641,
      "ta": "#strategyButton"
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 397,
      "y": 641
    },
    {
      "t": 964,
      "e": 964,
      "ty": 6,
      "x": 371,
      "y": 593,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 366,
      "y": 573
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 30227,
      "y": 40668,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 360,
      "y": 556
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 360,
      "y": 555
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 29553,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 359,
      "y": 555
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 28766,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 351,
      "y": 555
    },
    {
      "t": 2478,
      "e": 2478,
      "ty": 3,
      "x": 351,
      "y": 555,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2480,
      "e": 2480,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 28541,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2597,
      "e": 2597,
      "ty": 4,
      "x": 28541,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2597,
      "e": 2597,
      "ty": 5,
      "x": 351,
      "y": 555,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 351,
      "y": 551
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 369,
      "y": 528
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 31127,
      "y": 214,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3283,
      "e": 3283,
      "ty": 7,
      "x": 378,
      "y": 519,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 380,
      "y": 518
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 387,
      "y": 514
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 411,
      "y": 508
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 35286,
      "y": 31048,
      "ta": "#.strategy > p"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 430,
      "y": 507
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 452,
      "y": 507
    },
    {
      "t": 3752,
      "e": 3752,
      "ty": 41,
      "x": 39894,
      "y": 28708,
      "ta": "#.strategy > p"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 455,
      "y": 505
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 479,
      "y": 505
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 2,
      "x": 508,
      "y": 506
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 46189,
      "y": 26367,
      "ta": "#.strategy > p"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 522,
      "y": 508
    },
    {
      "t": 4201,
      "e": 4201,
      "ty": 2,
      "x": 564,
      "y": 516
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 56756,
      "y": 59135,
      "ta": "#.strategy > p"
    },
    {
      "t": 4268,
      "e": 4268,
      "ty": 6,
      "x": 613,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 628,
      "y": 525
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 641,
      "y": 530
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 2,
      "x": 676,
      "y": 549
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 41,
      "x": 65074,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4517,
      "e": 4517,
      "ty": 7,
      "x": 687,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4601,
      "e": 4601,
      "ty": 2,
      "x": 751,
      "y": 592
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 846,
      "y": 639
    },
    {
      "t": 4751,
      "e": 4751,
      "ty": 41,
      "x": 5990,
      "y": 37100,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 894,
      "y": 670
    },
    {
      "t": 4902,
      "e": 4902,
      "ty": 2,
      "x": 927,
      "y": 704
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 967,
      "y": 762
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 12755,
      "y": 44692,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 995,
      "y": 799
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 1008,
      "y": 820
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 9187,
      "y": 45510,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[7] > g:[10] > circle"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 1018,
      "y": 840
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1024,
      "y": 853
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1032,
      "y": 870
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 17336,
      "y": 52428,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5601,
      "e": 5601,
      "ty": 2,
      "x": 1045,
      "y": 886
    },
    {
      "t": 5701,
      "e": 5701,
      "ty": 2,
      "x": 1084,
      "y": 917
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 21634,
      "y": 56367,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 1107,
      "y": 930
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1126,
      "y": 938
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 2,
      "x": 1132,
      "y": 942
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 24382,
      "y": 57584,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 1141,
      "y": 947
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 1147,
      "y": 952
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 25721,
      "y": 58444,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1155,
      "y": 955
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1159,
      "y": 957
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1161,
      "y": 958
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 26426,
      "y": 58730,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 1159,
      "y": 962
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 1152,
      "y": 964
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1151,
      "y": 965
    },
    {
      "t": 7502,
      "e": 7502,
      "ty": 41,
      "x": 25721,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 1151,
      "y": 966
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 1154,
      "y": 966
    },
    {
      "t": 8252,
      "e": 8252,
      "ty": 41,
      "x": 26003,
      "y": 59447,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8301,
      "e": 8301,
      "ty": 2,
      "x": 1156,
      "y": 968
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 1159,
      "y": 975
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 2,
      "x": 1159,
      "y": 984
    },
    {
      "t": 8502,
      "e": 8502,
      "ty": 41,
      "x": 42230,
      "y": 61695,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 1159,
      "y": 990
    },
    {
      "t": 8752,
      "e": 8752,
      "ty": 41,
      "x": 26285,
      "y": 61094,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 8802,
      "e": 8802,
      "ty": 2,
      "x": 1159,
      "y": 991
    },
    {
      "t": 8900,
      "e": 8900,
      "ty": 2,
      "x": 1157,
      "y": 980
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 2,
      "x": 1156,
      "y": 969
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 37370,
      "y": 255,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[9] > text"
    },
    {
      "t": 9102,
      "e": 9102,
      "ty": 2,
      "x": 1155,
      "y": 961
    },
    {
      "t": 9201,
      "e": 9201,
      "ty": 2,
      "x": 1154,
      "y": 950
    },
    {
      "t": 9251,
      "e": 9251,
      "ty": 41,
      "x": 25721,
      "y": 57226,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9301,
      "e": 9301,
      "ty": 2,
      "x": 1151,
      "y": 922
    },
    {
      "t": 9401,
      "e": 9401,
      "ty": 2,
      "x": 1151,
      "y": 886
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 2,
      "x": 1151,
      "y": 858
    },
    {
      "t": 9502,
      "e": 9502,
      "ty": 41,
      "x": 25721,
      "y": 51568,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9601,
      "e": 9601,
      "ty": 2,
      "x": 1153,
      "y": 833
    },
    {
      "t": 9701,
      "e": 9701,
      "ty": 2,
      "x": 1174,
      "y": 787
    },
    {
      "t": 9752,
      "e": 9752,
      "ty": 41,
      "x": 27413,
      "y": 45767,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 9801,
      "e": 9801,
      "ty": 2,
      "x": 1175,
      "y": 771
    },
    {
      "t": 9901,
      "e": 9901,
      "ty": 2,
      "x": 1177,
      "y": 749
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 2,
      "x": 1166,
      "y": 718
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10002,
      "e": 10002,
      "ty": 41,
      "x": 26778,
      "y": 41541,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10102,
      "e": 10102,
      "ty": 2,
      "x": 1161,
      "y": 697
    },
    {
      "t": 10201,
      "e": 10201,
      "ty": 2,
      "x": 1158,
      "y": 674
    },
    {
      "t": 10251,
      "e": 10251,
      "ty": 41,
      "x": 26144,
      "y": 36599,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10301,
      "e": 10301,
      "ty": 2,
      "x": 1154,
      "y": 636
    },
    {
      "t": 10402,
      "e": 10402,
      "ty": 2,
      "x": 1152,
      "y": 616
    },
    {
      "t": 10501,
      "e": 10501,
      "ty": 2,
      "x": 1152,
      "y": 606
    },
    {
      "t": 10502,
      "e": 10502,
      "ty": 41,
      "x": 25792,
      "y": 33519,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10601,
      "e": 10601,
      "ty": 2,
      "x": 1155,
      "y": 601
    },
    {
      "t": 10701,
      "e": 10701,
      "ty": 2,
      "x": 1157,
      "y": 594
    },
    {
      "t": 10752,
      "e": 10752,
      "ty": 41,
      "x": 26144,
      "y": 32301,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 10801,
      "e": 10801,
      "ty": 2,
      "x": 1158,
      "y": 586
    },
    {
      "t": 10901,
      "e": 10901,
      "ty": 2,
      "x": 1159,
      "y": 584
    },
    {
      "t": 11001,
      "e": 11001,
      "ty": 41,
      "x": 26285,
      "y": 31943,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11251,
      "e": 11251,
      "ty": 41,
      "x": 25792,
      "y": 32087,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 11301,
      "e": 11301,
      "ty": 2,
      "x": 1013,
      "y": 603
    },
    {
      "t": 11356,
      "e": 11356,
      "ty": 6,
      "x": 587,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11401,
      "e": 11401,
      "ty": 2,
      "x": 391,
      "y": 603
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 2,
      "x": 375,
      "y": 603
    },
    {
      "t": 11501,
      "e": 11501,
      "ty": 41,
      "x": 31239,
      "y": 64940,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11701,
      "e": 11701,
      "ty": 2,
      "x": 374,
      "y": 586
    },
    {
      "t": 11751,
      "e": 11751,
      "ty": 41,
      "x": 31127,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11802,
      "e": 11802,
      "ty": 2,
      "x": 374,
      "y": 582
    },
    {
      "t": 11815,
      "e": 11815,
      "ty": 3,
      "x": 374,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11949,
      "e": 11949,
      "ty": 4,
      "x": 31127,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11949,
      "e": 11949,
      "ty": 5,
      "x": 374,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12762,
      "e": 12762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12977,
      "e": 12977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12978,
      "e": 12978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13032,
      "e": 13032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 13041,
      "e": 13041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 13210,
      "e": 13210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 13210,
      "e": 13210,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13296,
      "e": 13296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ig"
    },
    {
      "t": 13402,
      "e": 13402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ig"
    },
    {
      "t": 13626,
      "e": 13626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13697,
      "e": 13697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "I"
    },
    {
      "t": 13738,
      "e": 13738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 13738,
      "e": 13738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13865,
      "e": 13865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If"
    },
    {
      "t": 15040,
      "e": 15040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15040,
      "e": 15040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15113,
      "e": 15113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If "
    },
    {
      "t": 19042,
      "e": 19042,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19042,
      "e": 19042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19097,
      "e": 19097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If i"
    },
    {
      "t": 19130,
      "e": 19130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19131,
      "e": 19131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19193,
      "e": 19193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19313,
      "e": 19313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 19313,
      "e": 19313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19394,
      "e": 19394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19394,
      "e": 19394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19416,
      "e": 19416,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 19465,
      "e": 19465,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19841,
      "e": 19841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 19842,
      "e": 19842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19913,
      "e": 19913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20017,
      "e": 20017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20017,
      "e": 20017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20073,
      "e": 20073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20194,
      "e": 20194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20194,
      "e": 20194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20249,
      "e": 20249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20352,
      "e": 20352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20353,
      "e": 20353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20417,
      "e": 20417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20482,
      "e": 20482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20482,
      "e": 20482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20506,
      "e": 20506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20506,
      "e": 20506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20552,
      "e": 20552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 20569,
      "e": 20569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20698,
      "e": 20698,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 20698,
      "e": 20698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20768,
      "e": 20768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 20865,
      "e": 20865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20865,
      "e": 20865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20921,
      "e": 20921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20994,
      "e": 20994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20994,
      "e": 20994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21073,
      "e": 21073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21080,
      "e": 21080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21080,
      "e": 21080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21161,
      "e": 21161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21193,
      "e": 21193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 21193,
      "e": 21193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21265,
      "e": 21265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 21280,
      "e": 21280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 21280,
      "e": 21280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21360,
      "e": 21360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21377,
      "e": 21377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21377,
      "e": 21377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21441,
      "e": 21441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21761,
      "e": 21761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 21762,
      "e": 21762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21832,
      "e": 21832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 21873,
      "e": 21873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21873,
      "e": 21873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21945,
      "e": 21945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 22066,
      "e": 22066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22066,
      "e": 22066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22152,
      "e": 22152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 22153,
      "e": 22153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22184,
      "e": 22184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ap"
    },
    {
      "t": 22224,
      "e": 22224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22377,
      "e": 22377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22378,
      "e": 22378,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22425,
      "e": 22425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22528,
      "e": 22528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22529,
      "e": 22529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22594,
      "e": 22594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22705,
      "e": 22705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22706,
      "e": 22706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22768,
      "e": 22768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22784,
      "e": 22784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22785,
      "e": 22785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22889,
      "e": 22889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 22937,
      "e": 22937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22938,
      "e": 22938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22977,
      "e": 22977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23673,
      "e": 23673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23674,
      "e": 23674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23762,
      "e": 23762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 23762,
      "e": 23762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23800,
      "e": 23800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||af"
    },
    {
      "t": 23808,
      "e": 23808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23929,
      "e": 23929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23929,
      "e": 23929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23977,
      "e": 23977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24009,
      "e": 24009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24010,
      "e": 24010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24073,
      "e": 24073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 24168,
      "e": 24168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 24169,
      "e": 24169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24233,
      "e": 24233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 24257,
      "e": 24257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24258,
      "e": 24258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24312,
      "e": 24312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24825,
      "e": 24825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 24825,
      "e": 24825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24929,
      "e": 24929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 24930,
      "e": 24930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25009,
      "e": 25009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 25072,
      "e": 25072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25272,
      "e": 25272,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25273,
      "e": 25273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25337,
      "e": 25337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26089,
      "e": 26089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26202,
      "e": 26202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12"
    },
    {
      "t": 26208,
      "e": 26208,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12"
    },
    {
      "t": 26713,
      "e": 26713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 26713,
      "e": 26713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26769,
      "e": 26769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 26945,
      "e": 26945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 26946,
      "e": 26946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26985,
      "e": 26985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 27089,
      "e": 27089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27090,
      "e": 27090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27136,
      "e": 27136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27297,
      "e": 27297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27297,
      "e": 27297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27385,
      "e": 27385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27385,
      "e": 27385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27409,
      "e": 27409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 27448,
      "e": 27448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27578,
      "e": 27578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27578,
      "e": 27578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27632,
      "e": 27632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 29425,
      "e": 29425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29426,
      "e": 29426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29521,
      "e": 29521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30001,
      "e": 30001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 32294,
      "e": 32294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32294,
      "e": 32294,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32364,
      "e": 32364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32412,
      "e": 32412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32412,
      "e": 32412,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32477,
      "e": 32477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 32501,
      "e": 32501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32501,
      "e": 32501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32565,
      "e": 32565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32637,
      "e": 32637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32637,
      "e": 32637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32708,
      "e": 32708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32789,
      "e": 32789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 32789,
      "e": 32789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32917,
      "e": 32917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 32925,
      "e": 32925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 32925,
      "e": 32925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32964,
      "e": 32964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 33957,
      "e": 33957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33958,
      "e": 33958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34020,
      "e": 34020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 34149,
      "e": 34149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34149,
      "e": 34149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34221,
      "e": 34221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34373,
      "e": 34373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 34374,
      "e": 34374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34436,
      "e": 34436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 34597,
      "e": 34597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 34597,
      "e": 34597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34668,
      "e": 34668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 34684,
      "e": 34684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34685,
      "e": 34685,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34757,
      "e": 34757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35156,
      "e": 35156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35156,
      "e": 35156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35229,
      "e": 35229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35261,
      "e": 35261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35262,
      "e": 35262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35333,
      "e": 35333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 35365,
      "e": 35365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35366,
      "e": 35366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35461,
      "e": 35461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 35510,
      "e": 35510,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35510,
      "e": 35510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35580,
      "e": 35580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35789,
      "e": 35789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 35790,
      "e": 35790,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35900,
      "e": 35900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 35932,
      "e": 35932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 35933,
      "e": 35933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35997,
      "e": 35997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 36069,
      "e": 36069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 36069,
      "e": 36069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36140,
      "e": 36140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 36269,
      "e": 36269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36270,
      "e": 36270,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36388,
      "e": 36388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36557,
      "e": 36557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36560,
      "e": 36560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36644,
      "e": 36644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 36645,
      "e": 36645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36645,
      "e": 36645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36700,
      "e": 36700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 36773,
      "e": 36773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 36773,
      "e": 36773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36852,
      "e": 36852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 36965,
      "e": 36965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36966,
      "e": 36966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37012,
      "e": 37012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37100,
      "e": 37100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37101,
      "e": 37101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37173,
      "e": 37173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37180,
      "e": 37180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37181,
      "e": 37181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37293,
      "e": 37293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 37333,
      "e": 37333,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37334,
      "e": 37334,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37388,
      "e": 37388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37420,
      "e": 37420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 37420,
      "e": 37420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37517,
      "e": 37517,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 37548,
      "e": 37548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37549,
      "e": 37549,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37612,
      "e": 37612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37668,
      "e": 37668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 37668,
      "e": 37668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37781,
      "e": 37781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 37796,
      "e": 37796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 37797,
      "e": 37797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37852,
      "e": 37852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 37965,
      "e": 37965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 37965,
      "e": 37965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38020,
      "e": 38020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 38109,
      "e": 38109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38109,
      "e": 38109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38156,
      "e": 38156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 38260,
      "e": 38260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38261,
      "e": 38261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38332,
      "e": 38332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 38373,
      "e": 38373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 38373,
      "e": 38373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38436,
      "e": 38436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 38476,
      "e": 38476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38476,
      "e": 38476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38540,
      "e": 38540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38580,
      "e": 38580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38580,
      "e": 38580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38652,
      "e": 38652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40005,
      "e": 40005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40013,
      "e": 40013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40013,
      "e": 40013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40093,
      "e": 40093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 40108,
      "e": 40108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40109,
      "e": 40109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40180,
      "e": 40180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 40292,
      "e": 40292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 40292,
      "e": 40292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40372,
      "e": 40372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 40397,
      "e": 40397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 40397,
      "e": 40397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40492,
      "e": 40492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 40516,
      "e": 40516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40517,
      "e": 40517,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40572,
      "e": 40572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40773,
      "e": 40773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40860,
      "e": 40860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and current time"
    },
    {
      "t": 40941,
      "e": 40941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41021,
      "e": 41021,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and current tim"
    },
    {
      "t": 41092,
      "e": 41092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41156,
      "e": 41156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and current ti"
    },
    {
      "t": 41229,
      "e": 41229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41292,
      "e": 41292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and current t"
    },
    {
      "t": 41357,
      "e": 41357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41420,
      "e": 41420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and current "
    },
    {
      "t": 41508,
      "e": 41508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41549,
      "e": 41549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and current"
    },
    {
      "t": 41636,
      "e": 41636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41693,
      "e": 41693,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and curren"
    },
    {
      "t": 41797,
      "e": 41797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41836,
      "e": 41836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and curre"
    },
    {
      "t": 41925,
      "e": 41925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41988,
      "e": 41988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and curr"
    },
    {
      "t": 42069,
      "e": 42069,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42127,
      "e": 42071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and cur"
    },
    {
      "t": 42220,
      "e": 42164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42252,
      "e": 42196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and cu"
    },
    {
      "t": 42349,
      "e": 42293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42404,
      "e": 42348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and c"
    },
    {
      "t": 42580,
      "e": 42524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42604,
      "e": 42548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and "
    },
    {
      "t": 42813,
      "e": 42757,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42813,
      "e": 42757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42908,
      "e": 42852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 43077,
      "e": 43021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43077,
      "e": 43021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43132,
      "e": 43076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43189,
      "e": 43133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43190,
      "e": 43134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43252,
      "e": 43196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43332,
      "e": 43276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43333,
      "e": 43277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43405,
      "e": 43349,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43405,
      "e": 43349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43405,
      "e": 43349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43460,
      "e": 43404,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 43565,
      "e": 43509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 43565,
      "e": 43509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43628,
      "e": 43572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 43684,
      "e": 43628,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43684,
      "e": 43628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43781,
      "e": 43725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 43789,
      "e": 43733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43789,
      "e": 43733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43876,
      "e": 43820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44045,
      "e": 43989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44045,
      "e": 43989,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44156,
      "e": 44100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 44204,
      "e": 44148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 44204,
      "e": 44148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44260,
      "e": 44204,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 44445,
      "e": 44389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44445,
      "e": 44389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44516,
      "e": 44460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44596,
      "e": 44540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 44597,
      "e": 44541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44692,
      "e": 44636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 44693,
      "e": 44637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44694,
      "e": 44638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44747,
      "e": 44691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 44860,
      "e": 44804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44860,
      "e": 44804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44924,
      "e": 44868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 45013,
      "e": 44957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 45014,
      "e": 44958,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45100,
      "e": 45044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 45100,
      "e": 45044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45108,
      "e": 45052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 45148,
      "e": 45092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45253,
      "e": 45197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45254,
      "e": 45198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45324,
      "e": 45268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45476,
      "e": 45420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 45477,
      "e": 45421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45540,
      "e": 45484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 45908,
      "e": 45852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45911,
      "e": 45855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45988,
      "e": 45932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46085,
      "e": 46029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 46085,
      "e": 46029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46157,
      "e": 46101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46413,
      "e": 46357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 46414,
      "e": 46358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46492,
      "e": 46436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 46516,
      "e": 46460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46516,
      "e": 46460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46580,
      "e": 46524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46628,
      "e": 46572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 46629,
      "e": 46573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46701,
      "e": 46645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 46701,
      "e": 46645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46739,
      "e": 46683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 46763,
      "e": 46707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46860,
      "e": 46804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 46861,
      "e": 46805,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46909,
      "e": 46853,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 46932,
      "e": 46876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 46934,
      "e": 46878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47037,
      "e": 46981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 47084,
      "e": 47028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47085,
      "e": 47029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47156,
      "e": 47100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47340,
      "e": 47284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 47342,
      "e": 47286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47412,
      "e": 47356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 47900,
      "e": 47844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 47900,
      "e": 47844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48007,
      "e": 47847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 48036,
      "e": 47876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48036,
      "e": 47876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48092,
      "e": 47932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48206,
      "e": 48046,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and at time at which it starts is "
    },
    {
      "t": 48220,
      "e": 48060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 48221,
      "e": 48061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48293,
      "e": 48133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 48349,
      "e": 48189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48350,
      "e": 48190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48411,
      "e": 48251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 48532,
      "e": 48372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 48532,
      "e": 48372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48595,
      "e": 48435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 48652,
      "e": 48492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48652,
      "e": 48492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48716,
      "e": 48556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 48756,
      "e": 48596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 48756,
      "e": 48596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48853,
      "e": 48693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48854,
      "e": 48694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48884,
      "e": 48724,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 48964,
      "e": 48804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49509,
      "e": 49349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49510,
      "e": 49350,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49556,
      "e": 49396,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49757,
      "e": 49597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49757,
      "e": 49597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49828,
      "e": 49668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 49860,
      "e": 49700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49860,
      "e": 49700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49924,
      "e": 49764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 49989,
      "e": 49829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49989,
      "e": 49829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50044,
      "e": 49884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 50349,
      "e": 50189,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 50350,
      "e": 50190,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50420,
      "e": 50260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 50573,
      "e": 50413,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50573,
      "e": 50413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50628,
      "e": 50468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 50716,
      "e": 50556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50716,
      "e": 50556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50780,
      "e": 50620,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51597,
      "e": 51437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "56"
    },
    {
      "t": 51598,
      "e": 51438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51659,
      "e": 51499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||8"
    },
    {
      "t": 52125,
      "e": 51965,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 52125,
      "e": 51965,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52180,
      "e": 52020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 52316,
      "e": 52156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 52317,
      "e": 52157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52324,
      "e": 52164,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 52324,
      "e": 52164,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52348,
      "e": 52188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,m"
    },
    {
      "t": 52363,
      "e": 52203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52509,
      "e": 52349,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52509,
      "e": 52349,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52540,
      "e": 52380,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52789,
      "e": 52629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52843,
      "e": 52683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and at time at which it starts is before or on 8p,m"
    },
    {
      "t": 52931,
      "e": 52771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 52996,
      "e": 52836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and at time at which it starts is before or on 8p,"
    },
    {
      "t": 53108,
      "e": 52948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 53148,
      "e": 52988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and at time at which it starts is before or on 8p"
    },
    {
      "t": 53916,
      "e": 53756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 53917,
      "e": 53757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53988,
      "e": 53828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 54896,
      "e": 54736,
      "ty": 7,
      "x": 372,
      "y": 612,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54904,
      "e": 54744,
      "ty": 2,
      "x": 372,
      "y": 612
    },
    {
      "t": 55004,
      "e": 54844,
      "ty": 2,
      "x": 376,
      "y": 646
    },
    {
      "t": 55007,
      "e": 54845,
      "ty": 41,
      "x": 26872,
      "y": 15902,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 55095,
      "e": 54933,
      "ty": 6,
      "x": 376,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 55105,
      "e": 54943,
      "ty": 2,
      "x": 376,
      "y": 654
    },
    {
      "t": 55205,
      "e": 55043,
      "ty": 2,
      "x": 376,
      "y": 660
    },
    {
      "t": 55255,
      "e": 55093,
      "ty": 41,
      "x": 20428,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 55305,
      "e": 55143,
      "ty": 2,
      "x": 376,
      "y": 667
    },
    {
      "t": 55313,
      "e": 55151,
      "ty": 3,
      "x": 376,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 55315,
      "e": 55153,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "If its point on the graph is after 12pm and the sum of the duration and at time at which it starts is before or on 8pm"
    },
    {
      "t": 55316,
      "e": 55154,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55316,
      "e": 55154,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 55416,
      "e": 55254,
      "ty": 4,
      "x": 20428,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 55426,
      "e": 55264,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 55427,
      "e": 55265,
      "ty": 5,
      "x": 376,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 55431,
      "e": 55269,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 56435,
      "e": 56273,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 56605,
      "e": 56443,
      "ty": 2,
      "x": 545,
      "y": 574
    },
    {
      "t": 56705,
      "e": 56543,
      "ty": 2,
      "x": 1712,
      "y": 478
    },
    {
      "t": 56755,
      "e": 56593,
      "ty": 41,
      "x": 60093,
      "y": 26424,
      "ta": "html > body"
    },
    {
      "t": 56805,
      "e": 56643,
      "ty": 2,
      "x": 1753,
      "y": 508
    },
    {
      "t": 56905,
      "e": 56743,
      "ty": 2,
      "x": 1670,
      "y": 618
    },
    {
      "t": 57004,
      "e": 56842,
      "ty": 2,
      "x": 1519,
      "y": 685
    },
    {
      "t": 57004,
      "e": 56842,
      "ty": 41,
      "x": 52035,
      "y": 37503,
      "ta": "html > body"
    },
    {
      "t": 57105,
      "e": 56943,
      "ty": 2,
      "x": 1150,
      "y": 748
    },
    {
      "t": 57198,
      "e": 57036,
      "ty": 6,
      "x": 1023,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57205,
      "e": 57043,
      "ty": 2,
      "x": 1023,
      "y": 687
    },
    {
      "t": 57214,
      "e": 57052,
      "ty": 7,
      "x": 982,
      "y": 650,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 57215,
      "e": 57053,
      "ty": 6,
      "x": 982,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57231,
      "e": 57069,
      "ty": 7,
      "x": 955,
      "y": 623,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57255,
      "e": 57093,
      "ty": 41,
      "x": 27684,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 57280,
      "e": 57118,
      "ty": 6,
      "x": 918,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57305,
      "e": 57143,
      "ty": 2,
      "x": 917,
      "y": 565
    },
    {
      "t": 57348,
      "e": 57186,
      "ty": 7,
      "x": 915,
      "y": 551,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 57405,
      "e": 57243,
      "ty": 2,
      "x": 915,
      "y": 533
    },
    {
      "t": 57505,
      "e": 57343,
      "ty": 2,
      "x": 915,
      "y": 530
    },
    {
      "t": 57505,
      "e": 57343,
      "ty": 41,
      "x": 23142,
      "y": 51491,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 57605,
      "e": 57443,
      "ty": 2,
      "x": 915,
      "y": 534
    },
    {
      "t": 57705,
      "e": 57543,
      "ty": 2,
      "x": 907,
      "y": 552
    },
    {
      "t": 57755,
      "e": 57593,
      "ty": 41,
      "x": 21412,
      "y": 43690,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 57784,
      "e": 57622,
      "ty": 3,
      "x": 907,
      "y": 552,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 57913,
      "e": 57751,
      "ty": 4,
      "x": 21412,
      "y": 43690,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 57913,
      "e": 57751,
      "ty": 5,
      "x": 907,
      "y": 552,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 57985,
      "e": 57823,
      "ty": 6,
      "x": 907,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58005,
      "e": 57843,
      "ty": 2,
      "x": 907,
      "y": 555
    },
    {
      "t": 58005,
      "e": 57843,
      "ty": 41,
      "x": 21412,
      "y": 3120,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58097,
      "e": 57935,
      "ty": 3,
      "x": 907,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58098,
      "e": 57936,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58105,
      "e": 57943,
      "ty": 2,
      "x": 907,
      "y": 557
    },
    {
      "t": 58224,
      "e": 58062,
      "ty": 4,
      "x": 21412,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58224,
      "e": 58062,
      "ty": 5,
      "x": 907,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58256,
      "e": 58094,
      "ty": 41,
      "x": 21412,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59531,
      "e": 59369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 59531,
      "e": 59369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59619,
      "e": 59457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 59619,
      "e": 59457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59667,
      "e": 59505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 59684,
      "e": 59522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 59806,
      "e": 59644,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 60466,
      "e": 60304,
      "ty": 7,
      "x": 898,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60505,
      "e": 60343,
      "ty": 2,
      "x": 893,
      "y": 593
    },
    {
      "t": 60505,
      "e": 60343,
      "ty": 41,
      "x": 18384,
      "y": 7046,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 60605,
      "e": 60443,
      "ty": 2,
      "x": 885,
      "y": 630
    },
    {
      "t": 60634,
      "e": 60472,
      "ty": 6,
      "x": 880,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60705,
      "e": 60543,
      "ty": 2,
      "x": 874,
      "y": 661
    },
    {
      "t": 60755,
      "e": 60593,
      "ty": 41,
      "x": 14274,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60856,
      "e": 60694,
      "ty": 3,
      "x": 874,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60856,
      "e": 60694,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 60856,
      "e": 60694,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60856,
      "e": 60694,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60944,
      "e": 60782,
      "ty": 4,
      "x": 14274,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60944,
      "e": 60782,
      "ty": 5,
      "x": 874,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61380,
      "e": 61218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 61596,
      "e": 61434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 61596,
      "e": 61434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61652,
      "e": 61490,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "I"
    },
    {
      "t": 61667,
      "e": 61505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "I"
    },
    {
      "t": 61772,
      "e": 61610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 61772,
      "e": 61610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61852,
      "e": 61690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "In"
    },
    {
      "t": 61876,
      "e": 61714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 61876,
      "e": 61714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61956,
      "e": 61794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ind"
    },
    {
      "t": 61996,
      "e": 61834,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 61996,
      "e": 61834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62059,
      "e": 61897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Indi"
    },
    {
      "t": 62099,
      "e": 61937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 62099,
      "e": 61937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62206,
      "e": 62044,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "India"
    },
    {
      "t": 62227,
      "e": 62065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 62785,
      "e": 62623,
      "ty": 7,
      "x": 875,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62805,
      "e": 62643,
      "ty": 2,
      "x": 879,
      "y": 676
    },
    {
      "t": 62905,
      "e": 62743,
      "ty": 2,
      "x": 892,
      "y": 687
    },
    {
      "t": 62952,
      "e": 62790,
      "ty": 6,
      "x": 897,
      "y": 688,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63005,
      "e": 62843,
      "ty": 2,
      "x": 902,
      "y": 692
    },
    {
      "t": 63006,
      "e": 62844,
      "ty": 41,
      "x": 3132,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63105,
      "e": 62943,
      "ty": 2,
      "x": 906,
      "y": 693
    },
    {
      "t": 63160,
      "e": 62998,
      "ty": 3,
      "x": 906,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63161,
      "e": 62999,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "India"
    },
    {
      "t": 63161,
      "e": 62999,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63161,
      "e": 62999,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63247,
      "e": 63085,
      "ty": 4,
      "x": 5709,
      "y": 33760,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63248,
      "e": 63086,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63248,
      "e": 63086,
      "ty": 5,
      "x": 907,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63249,
      "e": 63087,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 63255,
      "e": 63093,
      "ty": 41,
      "x": 30959,
      "y": 37947,
      "ta": "html > body"
    },
    {
      "t": 63305,
      "e": 63143,
      "ty": 2,
      "x": 907,
      "y": 693
    },
    {
      "t": 63405,
      "e": 63243,
      "ty": 2,
      "x": 904,
      "y": 704
    },
    {
      "t": 63505,
      "e": 63343,
      "ty": 2,
      "x": 829,
      "y": 842
    },
    {
      "t": 63505,
      "e": 63343,
      "ty": 41,
      "x": 28273,
      "y": 46201,
      "ta": "html > body"
    },
    {
      "t": 63605,
      "e": 63443,
      "ty": 2,
      "x": 731,
      "y": 893
    },
    {
      "t": 63705,
      "e": 63543,
      "ty": 2,
      "x": 674,
      "y": 826
    },
    {
      "t": 63755,
      "e": 63593,
      "ty": 41,
      "x": 22625,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 63805,
      "e": 63643,
      "ty": 2,
      "x": 721,
      "y": 633
    },
    {
      "t": 63905,
      "e": 63743,
      "ty": 2,
      "x": 968,
      "y": 542
    },
    {
      "t": 64005,
      "e": 63843,
      "ty": 2,
      "x": 1026,
      "y": 643
    },
    {
      "t": 64005,
      "e": 63843,
      "ty": 41,
      "x": 35057,
      "y": 35177,
      "ta": "html > body"
    },
    {
      "t": 64105,
      "e": 63943,
      "ty": 2,
      "x": 1033,
      "y": 666
    },
    {
      "t": 64204,
      "e": 64042,
      "ty": 2,
      "x": 953,
      "y": 706
    },
    {
      "t": 64260,
      "e": 64098,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 64264,
      "e": 64102,
      "ty": 41,
      "x": 10579,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 64305,
      "e": 64143,
      "ty": 2,
      "x": 781,
      "y": 713
    },
    {
      "t": 64405,
      "e": 64243,
      "ty": 2,
      "x": 661,
      "y": 631
    },
    {
      "t": 64505,
      "e": 64343,
      "ty": 2,
      "x": 648,
      "y": 494
    },
    {
      "t": 64505,
      "e": 64343,
      "ty": 41,
      "x": 22040,
      "y": 26923,
      "ta": "html > body"
    },
    {
      "t": 64605,
      "e": 64443,
      "ty": 2,
      "x": 716,
      "y": 422
    },
    {
      "t": 64705,
      "e": 64543,
      "ty": 2,
      "x": 730,
      "y": 409
    },
    {
      "t": 64755,
      "e": 64593,
      "ty": 41,
      "x": 24864,
      "y": 22158,
      "ta": "html > body"
    },
    {
      "t": 64805,
      "e": 64643,
      "ty": 2,
      "x": 730,
      "y": 408
    },
    {
      "t": 64905,
      "e": 64743,
      "ty": 2,
      "x": 731,
      "y": 407
    },
    {
      "t": 65005,
      "e": 64843,
      "ty": 41,
      "x": 24898,
      "y": 22103,
      "ta": "html > body"
    },
    {
      "t": 65105,
      "e": 64943,
      "ty": 2,
      "x": 811,
      "y": 311
    },
    {
      "t": 65120,
      "e": 64958,
      "ty": 6,
      "x": 826,
      "y": 290,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 65138,
      "e": 64976,
      "ty": 7,
      "x": 834,
      "y": 279,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 65204,
      "e": 65042,
      "ty": 2,
      "x": 857,
      "y": 247
    },
    {
      "t": 65255,
      "e": 65093,
      "ty": 41,
      "x": 32409,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 65305,
      "e": 65143,
      "ty": 2,
      "x": 866,
      "y": 236
    },
    {
      "t": 65405,
      "e": 65243,
      "ty": 2,
      "x": 874,
      "y": 230
    },
    {
      "t": 65506,
      "e": 65344,
      "ty": 41,
      "x": 43054,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 65671,
      "e": 65509,
      "ty": 3,
      "x": 874,
      "y": 230,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 65776,
      "e": 65614,
      "ty": 4,
      "x": 43054,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 65776,
      "e": 65614,
      "ty": 5,
      "x": 874,
      "y": 230,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 65776,
      "e": 65614,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 65777,
      "e": 65615,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 65904,
      "e": 65742,
      "ty": 2,
      "x": 873,
      "y": 231
    },
    {
      "t": 66005,
      "e": 65843,
      "ty": 2,
      "x": 869,
      "y": 235
    },
    {
      "t": 66005,
      "e": 65843,
      "ty": 41,
      "x": 38960,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 66205,
      "e": 66043,
      "ty": 2,
      "x": 862,
      "y": 292
    },
    {
      "t": 66254,
      "e": 66092,
      "ty": 41,
      "x": 37304,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 66305,
      "e": 66143,
      "ty": 2,
      "x": 859,
      "y": 363
    },
    {
      "t": 66404,
      "e": 66242,
      "ty": 2,
      "x": 859,
      "y": 386
    },
    {
      "t": 66505,
      "e": 66343,
      "ty": 2,
      "x": 861,
      "y": 400
    },
    {
      "t": 66506,
      "e": 66344,
      "ty": 41,
      "x": 9392,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 67505,
      "e": 67343,
      "ty": 2,
      "x": 861,
      "y": 401
    },
    {
      "t": 67505,
      "e": 67343,
      "ty": 41,
      "x": 9392,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 67705,
      "e": 67543,
      "ty": 2,
      "x": 874,
      "y": 391
    },
    {
      "t": 67755,
      "e": 67593,
      "ty": 41,
      "x": 12715,
      "y": 9749,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 67805,
      "e": 67643,
      "ty": 2,
      "x": 880,
      "y": 406
    },
    {
      "t": 67905,
      "e": 67743,
      "ty": 2,
      "x": 887,
      "y": 433
    },
    {
      "t": 68006,
      "e": 67844,
      "ty": 2,
      "x": 879,
      "y": 468
    },
    {
      "t": 68006,
      "e": 67844,
      "ty": 41,
      "x": 60861,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 68106,
      "e": 67944,
      "ty": 2,
      "x": 875,
      "y": 481
    },
    {
      "t": 68256,
      "e": 68094,
      "ty": 41,
      "x": 12478,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 68305,
      "e": 68143,
      "ty": 2,
      "x": 873,
      "y": 474
    },
    {
      "t": 68376,
      "e": 68214,
      "ty": 3,
      "x": 872,
      "y": 474,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 68376,
      "e": 68214,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68405,
      "e": 68243,
      "ty": 2,
      "x": 872,
      "y": 474
    },
    {
      "t": 68455,
      "e": 68243,
      "ty": 4,
      "x": 53461,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 68456,
      "e": 68244,
      "ty": 5,
      "x": 872,
      "y": 474,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 68456,
      "e": 68244,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 68457,
      "e": 68245,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 68506,
      "e": 68294,
      "ty": 41,
      "x": 53461,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 68605,
      "e": 68393,
      "ty": 2,
      "x": 860,
      "y": 494
    },
    {
      "t": 68705,
      "e": 68493,
      "ty": 2,
      "x": 859,
      "y": 591
    },
    {
      "t": 68755,
      "e": 68543,
      "ty": 41,
      "x": 8918,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 68806,
      "e": 68594,
      "ty": 2,
      "x": 859,
      "y": 625
    },
    {
      "t": 68905,
      "e": 68693,
      "ty": 2,
      "x": 859,
      "y": 626
    },
    {
      "t": 69006,
      "e": 68794,
      "ty": 41,
      "x": 8918,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 69506,
      "e": 69294,
      "ty": 2,
      "x": 859,
      "y": 627
    },
    {
      "t": 69506,
      "e": 69294,
      "ty": 41,
      "x": 8918,
      "y": 28086,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 69705,
      "e": 69493,
      "ty": 2,
      "x": 826,
      "y": 634
    },
    {
      "t": 69756,
      "e": 69544,
      "ty": 41,
      "x": 849,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 69805,
      "e": 69593,
      "ty": 2,
      "x": 825,
      "y": 634
    },
    {
      "t": 69905,
      "e": 69693,
      "ty": 2,
      "x": 825,
      "y": 639
    },
    {
      "t": 70005,
      "e": 69793,
      "ty": 41,
      "x": 849,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 70006,
      "e": 69794,
      "ty": 2,
      "x": 825,
      "y": 659
    },
    {
      "t": 70105,
      "e": 69893,
      "ty": 2,
      "x": 829,
      "y": 667
    },
    {
      "t": 70111,
      "e": 69899,
      "ty": 6,
      "x": 829,
      "y": 668,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70205,
      "e": 69993,
      "ty": 2,
      "x": 830,
      "y": 669
    },
    {
      "t": 70255,
      "e": 70043,
      "ty": 41,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70279,
      "e": 70067,
      "ty": 3,
      "x": 831,
      "y": 669,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70280,
      "e": 70068,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 70280,
      "e": 70068,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70305,
      "e": 70093,
      "ty": 2,
      "x": 831,
      "y": 669
    },
    {
      "t": 70352,
      "e": 70140,
      "ty": 4,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70352,
      "e": 70140,
      "ty": 5,
      "x": 831,
      "y": 669,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70352,
      "e": 70140,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 70491,
      "e": 70279,
      "ty": 7,
      "x": 836,
      "y": 684,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 70505,
      "e": 70293,
      "ty": 2,
      "x": 836,
      "y": 684
    },
    {
      "t": 70505,
      "e": 70293,
      "ty": 41,
      "x": 3914,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 70605,
      "e": 70393,
      "ty": 2,
      "x": 849,
      "y": 733
    },
    {
      "t": 70705,
      "e": 70493,
      "ty": 2,
      "x": 853,
      "y": 754
    },
    {
      "t": 70755,
      "e": 70543,
      "ty": 41,
      "x": 13176,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 70805,
      "e": 70593,
      "ty": 2,
      "x": 854,
      "y": 786
    },
    {
      "t": 70905,
      "e": 70693,
      "ty": 2,
      "x": 854,
      "y": 814
    },
    {
      "t": 71006,
      "e": 70794,
      "ty": 2,
      "x": 854,
      "y": 815
    },
    {
      "t": 71006,
      "e": 70794,
      "ty": 41,
      "x": 19228,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 71405,
      "e": 71193,
      "ty": 2,
      "x": 854,
      "y": 816
    },
    {
      "t": 71505,
      "e": 71293,
      "ty": 2,
      "x": 854,
      "y": 870
    },
    {
      "t": 71505,
      "e": 71293,
      "ty": 41,
      "x": 7731,
      "y": 52980,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 71605,
      "e": 71393,
      "ty": 2,
      "x": 852,
      "y": 899
    },
    {
      "t": 71705,
      "e": 71493,
      "ty": 2,
      "x": 847,
      "y": 917
    },
    {
      "t": 71755,
      "e": 71543,
      "ty": 41,
      "x": 6070,
      "y": 22181,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 71805,
      "e": 71593,
      "ty": 2,
      "x": 847,
      "y": 927
    },
    {
      "t": 72005,
      "e": 71793,
      "ty": 41,
      "x": 27937,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 72031,
      "e": 71819,
      "ty": 3,
      "x": 847,
      "y": 927,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 72032,
      "e": 71820,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 72120,
      "e": 71908,
      "ty": 4,
      "x": 27937,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 72120,
      "e": 71908,
      "ty": 5,
      "x": 847,
      "y": 927,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 72121,
      "e": 71909,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 72121,
      "e": 71909,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 72205,
      "e": 71993,
      "ty": 2,
      "x": 850,
      "y": 933
    },
    {
      "t": 72255,
      "e": 72043,
      "ty": 41,
      "x": 35251,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 72305,
      "e": 72093,
      "ty": 2,
      "x": 881,
      "y": 972
    },
    {
      "t": 72406,
      "e": 72194,
      "ty": 2,
      "x": 901,
      "y": 994
    },
    {
      "t": 72506,
      "e": 72294,
      "ty": 2,
      "x": 903,
      "y": 996
    },
    {
      "t": 72506,
      "e": 72294,
      "ty": 41,
      "x": 19360,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 72605,
      "e": 72393,
      "ty": 2,
      "x": 910,
      "y": 1003
    },
    {
      "t": 72627,
      "e": 72415,
      "ty": 6,
      "x": 912,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72705,
      "e": 72493,
      "ty": 2,
      "x": 913,
      "y": 1011
    },
    {
      "t": 72756,
      "e": 72544,
      "ty": 41,
      "x": 43075,
      "y": 11915,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72806,
      "e": 72594,
      "ty": 2,
      "x": 916,
      "y": 1013
    },
    {
      "t": 72841,
      "e": 72629,
      "ty": 3,
      "x": 917,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72842,
      "e": 72630,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 72842,
      "e": 72630,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72904,
      "e": 72692,
      "ty": 4,
      "x": 45136,
      "y": 17873,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72904,
      "e": 72692,
      "ty": 5,
      "x": 917,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72906,
      "e": 72694,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 72906,
      "e": 72694,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 72907,
      "e": 72695,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 72908,
      "e": 72696,
      "ty": 2,
      "x": 917,
      "y": 1014
    },
    {
      "t": 73005,
      "e": 72793,
      "ty": 41,
      "x": 31303,
      "y": 55729,
      "ta": "html > body"
    },
    {
      "t": 73206,
      "e": 72994,
      "ty": 2,
      "x": 917,
      "y": 1015
    },
    {
      "t": 73256,
      "e": 73044,
      "ty": 41,
      "x": 30959,
      "y": 55231,
      "ta": "html > body"
    },
    {
      "t": 73306,
      "e": 73094,
      "ty": 2,
      "x": 865,
      "y": 971
    },
    {
      "t": 73406,
      "e": 73194,
      "ty": 2,
      "x": 729,
      "y": 750
    },
    {
      "t": 73505,
      "e": 73293,
      "ty": 2,
      "x": 542,
      "y": 425
    },
    {
      "t": 73506,
      "e": 73294,
      "ty": 41,
      "x": 18389,
      "y": 23100,
      "ta": "html > body"
    },
    {
      "t": 73604,
      "e": 73392,
      "ty": 2,
      "x": 540,
      "y": 291
    },
    {
      "t": 73705,
      "e": 73493,
      "ty": 2,
      "x": 686,
      "y": 160
    },
    {
      "t": 73755,
      "e": 73543,
      "ty": 41,
      "x": 25793,
      "y": 7090,
      "ta": "html > body"
    },
    {
      "t": 73805,
      "e": 73593,
      "ty": 2,
      "x": 763,
      "y": 136
    },
    {
      "t": 74005,
      "e": 73793,
      "ty": 41,
      "x": 26000,
      "y": 7090,
      "ta": "html > body"
    },
    {
      "t": 74307,
      "e": 74095,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 74404,
      "e": 74192,
      "ty": 2,
      "x": 768,
      "y": 140
    },
    {
      "t": 74504,
      "e": 74292,
      "ty": 2,
      "x": 769,
      "y": 146
    },
    {
      "t": 74505,
      "e": 74293,
      "ty": 41,
      "x": 23395,
      "y": 1364,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74604,
      "e": 74392,
      "ty": 2,
      "x": 772,
      "y": 156
    },
    {
      "t": 74704,
      "e": 74492,
      "ty": 2,
      "x": 777,
      "y": 169
    },
    {
      "t": 74755,
      "e": 74543,
      "ty": 41,
      "x": 23985,
      "y": 3441,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 74804,
      "e": 74592,
      "ty": 2,
      "x": 781,
      "y": 181
    },
    {
      "t": 74904,
      "e": 74692,
      "ty": 2,
      "x": 787,
      "y": 192
    },
    {
      "t": 75005,
      "e": 74793,
      "ty": 2,
      "x": 787,
      "y": 193
    },
    {
      "t": 75005,
      "e": 74793,
      "ty": 41,
      "x": 24281,
      "y": 4619,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 75105,
      "e": 74893,
      "ty": 2,
      "x": 787,
      "y": 204
    },
    {
      "t": 75204,
      "e": 74992,
      "ty": 2,
      "x": 801,
      "y": 295
    },
    {
      "t": 75254,
      "e": 75042,
      "ty": 41,
      "x": 24969,
      "y": 11682,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 75905,
      "e": 75693,
      "ty": 2,
      "x": 827,
      "y": 524
    },
    {
      "t": 76005,
      "e": 75793,
      "ty": 2,
      "x": 911,
      "y": 978
    },
    {
      "t": 76005,
      "e": 75793,
      "ty": 41,
      "x": 30381,
      "y": 58978,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 76097,
      "e": 75885,
      "ty": 6,
      "x": 947,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 76104,
      "e": 75892,
      "ty": 2,
      "x": 947,
      "y": 1075
    },
    {
      "t": 76163,
      "e": 75951,
      "ty": 7,
      "x": 961,
      "y": 1111,
      "ta": "#start"
    },
    {
      "t": 76205,
      "e": 75993,
      "ty": 2,
      "x": 965,
      "y": 1121
    },
    {
      "t": 76255,
      "e": 76043,
      "ty": 41,
      "x": 35810,
      "y": 29534,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 76305,
      "e": 76093,
      "ty": 2,
      "x": 969,
      "y": 1128
    },
    {
      "t": 76404,
      "e": 76192,
      "ty": 2,
      "x": 972,
      "y": 1131
    },
    {
      "t": 76497,
      "e": 76285,
      "ty": 6,
      "x": 976,
      "y": 1101,
      "ta": "#start"
    },
    {
      "t": 76505,
      "e": 76293,
      "ty": 2,
      "x": 976,
      "y": 1101
    },
    {
      "t": 76505,
      "e": 76293,
      "ty": 41,
      "x": 36317,
      "y": 54572,
      "ta": "#start"
    },
    {
      "t": 76605,
      "e": 76393,
      "ty": 2,
      "x": 976,
      "y": 1098
    },
    {
      "t": 76754,
      "e": 76542,
      "ty": 41,
      "x": 36317,
      "y": 48789,
      "ta": "#start"
    },
    {
      "t": 76805,
      "e": 76593,
      "ty": 2,
      "x": 976,
      "y": 1096
    },
    {
      "t": 76921,
      "e": 76709,
      "ty": 3,
      "x": 976,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 76922,
      "e": 76710,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 77005,
      "e": 76793,
      "ty": 41,
      "x": 36317,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 77008,
      "e": 76796,
      "ty": 4,
      "x": 36317,
      "y": 44934,
      "ta": "#start"
    },
    {
      "t": 77008,
      "e": 76796,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 77008,
      "e": 76796,
      "ty": 5,
      "x": 976,
      "y": 1096,
      "ta": "#start"
    },
    {
      "t": 77009,
      "e": 76797,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 78047,
      "e": 77835,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 79804,
      "e": 79592,
      "ty": 2,
      "x": 974,
      "y": 1095
    },
    {
      "t": 79904,
      "e": 79692,
      "ty": 2,
      "x": 966,
      "y": 1097
    },
    {
      "t": 80005,
      "e": 79793,
      "ty": 2,
      "x": 898,
      "y": 1067
    },
    {
      "t": 80005,
      "e": 79793,
      "ty": 41,
      "x": 29705,
      "y": 32853,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 80005,
      "e": 79793,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80052,
      "e": 79840,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 120791, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 120797, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 3716, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 125853, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 13056, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"romeo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 139916, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 43964, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 184977, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 15944, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 201925, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 89370, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 292925, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-11 AM-H -H -11 AM-A -A -A -H -H -K -K -1-Z -Z -Z -10 AM-11 AM-12 PM-11 AM-11 AM-10 AM-6-A -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:362,y:662,t:1527627957740};\\\", \\\"{x:366,y:662,t:1527627957748};\\\", \\\"{x:381,y:662,t:1527627957766};\\\", \\\"{x:392,y:662,t:1527627957783};\\\", \\\"{x:407,y:662,t:1527627957798};\\\", \\\"{x:431,y:665,t:1527627957816};\\\", \\\"{x:455,y:667,t:1527627957833};\\\", \\\"{x:480,y:670,t:1527627957848};\\\", \\\"{x:512,y:680,t:1527627957866};\\\", \\\"{x:554,y:682,t:1527627957883};\\\", \\\"{x:583,y:689,t:1527627957899};\\\", \\\"{x:604,y:698,t:1527627957915};\\\", \\\"{x:627,y:709,t:1527627957933};\\\", \\\"{x:647,y:720,t:1527627957949};\\\", \\\"{x:667,y:732,t:1527627957966};\\\", \\\"{x:692,y:746,t:1527627957982};\\\", \\\"{x:721,y:761,t:1527627957998};\\\", \\\"{x:745,y:770,t:1527627958015};\\\", \\\"{x:772,y:787,t:1527627958033};\\\", \\\"{x:803,y:806,t:1527627958049};\\\", \\\"{x:822,y:819,t:1527627958066};\\\", \\\"{x:857,y:841,t:1527627958083};\\\", \\\"{x:869,y:848,t:1527627958099};\\\", \\\"{x:884,y:858,t:1527627958116};\\\", \\\"{x:901,y:867,t:1527627958133};\\\", \\\"{x:912,y:874,t:1527627958149};\\\", \\\"{x:929,y:883,t:1527627958166};\\\", \\\"{x:941,y:887,t:1527627958183};\\\", \\\"{x:958,y:895,t:1527627958199};\\\", \\\"{x:972,y:902,t:1527627958216};\\\", \\\"{x:982,y:903,t:1527627958232};\\\", \\\"{x:999,y:908,t:1527627958249};\\\", \\\"{x:1015,y:912,t:1527627958266};\\\", \\\"{x:1024,y:914,t:1527627958283};\\\", \\\"{x:1042,y:918,t:1527627958299};\\\", \\\"{x:1057,y:923,t:1527627958316};\\\", \\\"{x:1066,y:925,t:1527627958333};\\\", \\\"{x:1076,y:928,t:1527627958349};\\\", \\\"{x:1087,y:932,t:1527627958365};\\\", \\\"{x:1094,y:933,t:1527627958382};\\\", \\\"{x:1100,y:936,t:1527627958399};\\\", \\\"{x:1104,y:937,t:1527627958415};\\\", \\\"{x:1109,y:937,t:1527627958432};\\\", \\\"{x:1117,y:940,t:1527627958449};\\\", \\\"{x:1126,y:941,t:1527627958465};\\\", \\\"{x:1148,y:948,t:1527627958482};\\\", \\\"{x:1167,y:956,t:1527627958499};\\\", \\\"{x:1182,y:959,t:1527627958516};\\\", \\\"{x:1189,y:961,t:1527627958533};\\\", \\\"{x:1201,y:963,t:1527627958549};\\\", \\\"{x:1210,y:966,t:1527627958565};\\\", \\\"{x:1223,y:970,t:1527627958583};\\\", \\\"{x:1234,y:972,t:1527627958600};\\\", \\\"{x:1249,y:976,t:1527627958616};\\\", \\\"{x:1256,y:977,t:1527627958632};\\\", \\\"{x:1262,y:980,t:1527627958650};\\\", \\\"{x:1268,y:983,t:1527627958665};\\\", \\\"{x:1274,y:987,t:1527627958683};\\\", \\\"{x:1278,y:988,t:1527627958699};\\\", \\\"{x:1280,y:988,t:1527627958716};\\\", \\\"{x:1280,y:989,t:1527627958732};\\\", \\\"{x:1283,y:991,t:1527627958795};\\\", \\\"{x:1284,y:992,t:1527627958803};\\\", \\\"{x:1285,y:993,t:1527627958816};\\\", \\\"{x:1287,y:994,t:1527627958833};\\\", \\\"{x:1289,y:996,t:1527627958850};\\\", \\\"{x:1293,y:999,t:1527627958867};\\\", \\\"{x:1295,y:1000,t:1527627958907};\\\", \\\"{x:1296,y:1003,t:1527627958917};\\\", \\\"{x:1298,y:1005,t:1527627958933};\\\", \\\"{x:1302,y:1007,t:1527627958950};\\\", \\\"{x:1304,y:1010,t:1527627958967};\\\", \\\"{x:1305,y:1012,t:1527627958983};\\\", \\\"{x:1307,y:1014,t:1527627959000};\\\", \\\"{x:1309,y:1016,t:1527627959016};\\\", \\\"{x:1310,y:1016,t:1527627959033};\\\", \\\"{x:1311,y:1018,t:1527627959050};\\\", \\\"{x:1312,y:1019,t:1527627959067};\\\", \\\"{x:1315,y:1021,t:1527627959083};\\\", \\\"{x:1317,y:1023,t:1527627959100};\\\", \\\"{x:1318,y:1025,t:1527627959117};\\\", \\\"{x:1320,y:1027,t:1527627959133};\\\", \\\"{x:1321,y:1028,t:1527627959150};\\\", \\\"{x:1321,y:1030,t:1527627959166};\\\", \\\"{x:1322,y:1030,t:1527627959259};\\\", \\\"{x:1320,y:1030,t:1527627959756};\\\", \\\"{x:1318,y:1027,t:1527627959767};\\\", \\\"{x:1313,y:1026,t:1527627959784};\\\", \\\"{x:1299,y:1020,t:1527627959801};\\\", \\\"{x:1283,y:1010,t:1527627959816};\\\", \\\"{x:1252,y:994,t:1527627959834};\\\", \\\"{x:1136,y:951,t:1527627959851};\\\", \\\"{x:1056,y:927,t:1527627959867};\\\", \\\"{x:997,y:910,t:1527627959884};\\\", \\\"{x:972,y:903,t:1527627959900};\\\", \\\"{x:958,y:895,t:1527627959916};\\\", \\\"{x:949,y:888,t:1527627959934};\\\", \\\"{x:942,y:883,t:1527627959951};\\\", \\\"{x:936,y:877,t:1527627959966};\\\", \\\"{x:933,y:871,t:1527627959984};\\\", \\\"{x:931,y:865,t:1527627960001};\\\", \\\"{x:927,y:857,t:1527627960017};\\\", \\\"{x:923,y:849,t:1527627960034};\\\", \\\"{x:923,y:846,t:1527627960050};\\\", \\\"{x:923,y:844,t:1527627960066};\\\", \\\"{x:923,y:840,t:1527627960084};\\\", \\\"{x:926,y:834,t:1527627960100};\\\", \\\"{x:936,y:827,t:1527627960117};\\\", \\\"{x:949,y:819,t:1527627960133};\\\", \\\"{x:961,y:814,t:1527627960150};\\\", \\\"{x:970,y:807,t:1527627960167};\\\", \\\"{x:980,y:800,t:1527627960183};\\\", \\\"{x:986,y:795,t:1527627960200};\\\", \\\"{x:994,y:789,t:1527627960218};\\\", \\\"{x:1005,y:778,t:1527627960234};\\\", \\\"{x:1013,y:766,t:1527627960250};\\\", \\\"{x:1014,y:765,t:1527627960267};\\\", \\\"{x:1016,y:762,t:1527627960283};\\\", \\\"{x:1016,y:761,t:1527627960300};\\\", \\\"{x:1017,y:760,t:1527627960323};\\\", \\\"{x:1020,y:757,t:1527627973716};\\\", \\\"{x:1027,y:755,t:1527627973727};\\\", \\\"{x:1044,y:747,t:1527627973745};\\\", \\\"{x:1055,y:743,t:1527627973761};\\\", \\\"{x:1059,y:741,t:1527627973777};\\\", \\\"{x:1063,y:740,t:1527627973794};\\\", \\\"{x:1063,y:739,t:1527627973811};\\\", \\\"{x:1065,y:738,t:1527627973827};\\\", \\\"{x:1068,y:737,t:1527627973844};\\\", \\\"{x:1070,y:736,t:1527627973860};\\\", \\\"{x:1074,y:734,t:1527627973877};\\\", \\\"{x:1087,y:732,t:1527627973895};\\\", \\\"{x:1094,y:731,t:1527627973912};\\\", \\\"{x:1111,y:727,t:1527627973927};\\\", \\\"{x:1131,y:721,t:1527627973943};\\\", \\\"{x:1153,y:718,t:1527627973960};\\\", \\\"{x:1176,y:718,t:1527627973976};\\\", \\\"{x:1216,y:718,t:1527627973994};\\\", \\\"{x:1239,y:718,t:1527627974010};\\\", \\\"{x:1257,y:717,t:1527627974026};\\\", \\\"{x:1276,y:717,t:1527627974044};\\\", \\\"{x:1291,y:717,t:1527627974061};\\\", \\\"{x:1306,y:717,t:1527627974077};\\\", \\\"{x:1318,y:717,t:1527627974093};\\\", \\\"{x:1325,y:717,t:1527627974110};\\\", \\\"{x:1337,y:717,t:1527627974126};\\\", \\\"{x:1349,y:719,t:1527627974144};\\\", \\\"{x:1360,y:721,t:1527627974161};\\\", \\\"{x:1370,y:722,t:1527627974177};\\\", \\\"{x:1381,y:724,t:1527627974194};\\\", \\\"{x:1383,y:724,t:1527627974211};\\\", \\\"{x:1387,y:724,t:1527627974227};\\\", \\\"{x:1394,y:724,t:1527627974244};\\\", \\\"{x:1408,y:720,t:1527627974261};\\\", \\\"{x:1429,y:716,t:1527627974277};\\\", \\\"{x:1442,y:710,t:1527627974294};\\\", \\\"{x:1464,y:709,t:1527627974311};\\\", \\\"{x:1481,y:703,t:1527627974328};\\\", \\\"{x:1503,y:701,t:1527627974344};\\\", \\\"{x:1519,y:697,t:1527627974361};\\\", \\\"{x:1544,y:692,t:1527627974378};\\\", \\\"{x:1560,y:689,t:1527627974394};\\\", \\\"{x:1572,y:688,t:1527627974411};\\\", \\\"{x:1582,y:687,t:1527627974428};\\\", \\\"{x:1585,y:686,t:1527627974444};\\\", \\\"{x:1586,y:686,t:1527627974462};\\\", \\\"{x:1587,y:686,t:1527627974479};\\\", \\\"{x:1585,y:686,t:1527627975003};\\\", \\\"{x:1581,y:684,t:1527627975012};\\\", \\\"{x:1566,y:678,t:1527627975029};\\\", \\\"{x:1555,y:670,t:1527627975046};\\\", \\\"{x:1545,y:665,t:1527627975062};\\\", \\\"{x:1543,y:663,t:1527627975078};\\\", \\\"{x:1539,y:661,t:1527627975096};\\\", \\\"{x:1531,y:659,t:1527627975111};\\\", \\\"{x:1526,y:654,t:1527627975129};\\\", \\\"{x:1514,y:643,t:1527627975145};\\\", \\\"{x:1497,y:629,t:1527627975160};\\\", \\\"{x:1468,y:611,t:1527627975177};\\\", \\\"{x:1453,y:600,t:1527627975195};\\\", \\\"{x:1445,y:596,t:1527627975211};\\\", \\\"{x:1438,y:591,t:1527627975228};\\\", \\\"{x:1432,y:585,t:1527627975245};\\\", \\\"{x:1430,y:583,t:1527627975261};\\\", \\\"{x:1426,y:580,t:1527627975278};\\\", \\\"{x:1422,y:577,t:1527627975295};\\\", \\\"{x:1420,y:575,t:1527627975311};\\\", \\\"{x:1419,y:573,t:1527627975330};\\\", \\\"{x:1417,y:572,t:1527627975346};\\\", \\\"{x:1415,y:570,t:1527627975362};\\\", \\\"{x:1414,y:568,t:1527627975380};\\\", \\\"{x:1410,y:563,t:1527627975395};\\\", \\\"{x:1403,y:556,t:1527627975412};\\\", \\\"{x:1400,y:553,t:1527627975427};\\\", \\\"{x:1398,y:552,t:1527627975445};\\\", \\\"{x:1395,y:548,t:1527627975462};\\\", \\\"{x:1394,y:547,t:1527627975477};\\\", \\\"{x:1391,y:543,t:1527627975495};\\\", \\\"{x:1390,y:541,t:1527627975511};\\\", \\\"{x:1389,y:540,t:1527627975528};\\\", \\\"{x:1388,y:538,t:1527627975545};\\\", \\\"{x:1386,y:536,t:1527627975562};\\\", \\\"{x:1385,y:535,t:1527627975578};\\\", \\\"{x:1384,y:534,t:1527627975595};\\\", \\\"{x:1383,y:533,t:1527627975627};\\\", \\\"{x:1383,y:532,t:1527627975635};\\\", \\\"{x:1382,y:531,t:1527627975651};\\\", \\\"{x:1382,y:530,t:1527627975662};\\\", \\\"{x:1382,y:529,t:1527627975679};\\\", \\\"{x:1381,y:528,t:1527627975695};\\\", \\\"{x:1380,y:525,t:1527627975713};\\\", \\\"{x:1379,y:523,t:1527627975729};\\\", \\\"{x:1378,y:522,t:1527627975745};\\\", \\\"{x:1378,y:521,t:1527627975762};\\\", \\\"{x:1378,y:520,t:1527627975843};\\\", \\\"{x:1378,y:519,t:1527627975875};\\\", \\\"{x:1378,y:518,t:1527627975907};\\\", \\\"{x:1378,y:517,t:1527627975947};\\\", \\\"{x:1378,y:516,t:1527627975962};\\\", \\\"{x:1378,y:515,t:1527627975978};\\\", \\\"{x:1379,y:514,t:1527627975995};\\\", \\\"{x:1379,y:513,t:1527627976019};\\\", \\\"{x:1379,y:512,t:1527627976035};\\\", \\\"{x:1381,y:509,t:1527627976045};\\\", \\\"{x:1384,y:506,t:1527627976062};\\\", \\\"{x:1386,y:500,t:1527627976079};\\\", \\\"{x:1387,y:496,t:1527627976096};\\\", \\\"{x:1391,y:490,t:1527627976113};\\\", \\\"{x:1392,y:487,t:1527627976130};\\\", \\\"{x:1393,y:487,t:1527627976146};\\\", \\\"{x:1393,y:486,t:1527627976162};\\\", \\\"{x:1392,y:486,t:1527627976595};\\\", \\\"{x:1390,y:487,t:1527627976613};\\\", \\\"{x:1387,y:487,t:1527627976629};\\\", \\\"{x:1381,y:491,t:1527627976646};\\\", \\\"{x:1376,y:492,t:1527627976663};\\\", \\\"{x:1371,y:495,t:1527627976679};\\\", \\\"{x:1368,y:497,t:1527627976696};\\\", \\\"{x:1367,y:498,t:1527627976714};\\\", \\\"{x:1365,y:499,t:1527627976730};\\\", \\\"{x:1364,y:500,t:1527627976787};\\\", \\\"{x:1363,y:500,t:1527627976818};\\\", \\\"{x:1362,y:502,t:1527627976971};\\\", \\\"{x:1362,y:503,t:1527627976987};\\\", \\\"{x:1362,y:504,t:1527627977003};\\\", \\\"{x:1362,y:505,t:1527627977014};\\\", \\\"{x:1362,y:506,t:1527627977051};\\\", \\\"{x:1362,y:507,t:1527627977075};\\\", \\\"{x:1362,y:508,t:1527627977115};\\\", \\\"{x:1362,y:510,t:1527627977139};\\\", \\\"{x:1362,y:511,t:1527627977147};\\\", \\\"{x:1363,y:514,t:1527627977162};\\\", \\\"{x:1367,y:519,t:1527627977180};\\\", \\\"{x:1369,y:525,t:1527627977196};\\\", \\\"{x:1373,y:528,t:1527627977213};\\\", \\\"{x:1377,y:533,t:1527627977230};\\\", \\\"{x:1379,y:535,t:1527627977246};\\\", \\\"{x:1380,y:536,t:1527627977263};\\\", \\\"{x:1381,y:539,t:1527627977279};\\\", \\\"{x:1384,y:542,t:1527627977296};\\\", \\\"{x:1387,y:546,t:1527627977313};\\\", \\\"{x:1397,y:556,t:1527627977330};\\\", \\\"{x:1411,y:564,t:1527627977347};\\\", \\\"{x:1417,y:569,t:1527627977363};\\\", \\\"{x:1423,y:573,t:1527627977380};\\\", \\\"{x:1427,y:576,t:1527627977396};\\\", \\\"{x:1436,y:584,t:1527627977413};\\\", \\\"{x:1445,y:591,t:1527627977430};\\\", \\\"{x:1450,y:594,t:1527627977446};\\\", \\\"{x:1452,y:597,t:1527627977464};\\\", \\\"{x:1453,y:597,t:1527627977531};\\\", \\\"{x:1454,y:598,t:1527627977546};\\\", \\\"{x:1455,y:601,t:1527627977563};\\\", \\\"{x:1457,y:605,t:1527627977581};\\\", \\\"{x:1460,y:611,t:1527627977597};\\\", \\\"{x:1463,y:616,t:1527627977614};\\\", \\\"{x:1466,y:621,t:1527627977630};\\\", \\\"{x:1468,y:627,t:1527627977647};\\\", \\\"{x:1470,y:631,t:1527627977664};\\\", \\\"{x:1472,y:633,t:1527627977680};\\\", \\\"{x:1473,y:636,t:1527627977697};\\\", \\\"{x:1474,y:636,t:1527627978219};\\\", \\\"{x:1474,y:637,t:1527627978259};\\\", \\\"{x:1474,y:638,t:1527627978267};\\\", \\\"{x:1473,y:639,t:1527627978283};\\\", \\\"{x:1473,y:640,t:1527627978298};\\\", \\\"{x:1472,y:646,t:1527627978315};\\\", \\\"{x:1472,y:648,t:1527627978331};\\\", \\\"{x:1470,y:652,t:1527627978348};\\\", \\\"{x:1470,y:655,t:1527627978365};\\\", \\\"{x:1470,y:660,t:1527627978380};\\\", \\\"{x:1470,y:666,t:1527627978397};\\\", \\\"{x:1470,y:672,t:1527627978415};\\\", \\\"{x:1470,y:678,t:1527627978431};\\\", \\\"{x:1468,y:685,t:1527627978448};\\\", \\\"{x:1463,y:699,t:1527627978465};\\\", \\\"{x:1457,y:712,t:1527627978481};\\\", \\\"{x:1454,y:720,t:1527627978497};\\\", \\\"{x:1446,y:746,t:1527627978514};\\\", \\\"{x:1440,y:758,t:1527627978531};\\\", \\\"{x:1438,y:760,t:1527627978548};\\\", \\\"{x:1435,y:765,t:1527627978565};\\\", \\\"{x:1434,y:771,t:1527627978580};\\\", \\\"{x:1430,y:777,t:1527627978598};\\\", \\\"{x:1427,y:785,t:1527627978615};\\\", \\\"{x:1425,y:787,t:1527627978631};\\\", \\\"{x:1424,y:788,t:1527627978647};\\\", \\\"{x:1423,y:789,t:1527627978664};\\\", \\\"{x:1422,y:791,t:1527627978681};\\\", \\\"{x:1421,y:793,t:1527627978706};\\\", \\\"{x:1421,y:794,t:1527627978713};\\\", \\\"{x:1416,y:799,t:1527627978731};\\\", \\\"{x:1412,y:805,t:1527627978747};\\\", \\\"{x:1408,y:812,t:1527627978764};\\\", \\\"{x:1406,y:814,t:1527627978781};\\\", \\\"{x:1402,y:819,t:1527627978797};\\\", \\\"{x:1400,y:822,t:1527627978815};\\\", \\\"{x:1398,y:824,t:1527627978831};\\\", \\\"{x:1397,y:826,t:1527627978847};\\\", \\\"{x:1396,y:827,t:1527627978883};\\\", \\\"{x:1395,y:827,t:1527627978899};\\\", \\\"{x:1395,y:828,t:1527627978923};\\\", \\\"{x:1394,y:829,t:1527627978931};\\\", \\\"{x:1393,y:829,t:1527627978948};\\\", \\\"{x:1392,y:829,t:1527627979179};\\\", \\\"{x:1384,y:829,t:1527627979186};\\\", \\\"{x:1368,y:827,t:1527627979199};\\\", \\\"{x:1328,y:814,t:1527627979214};\\\", \\\"{x:1300,y:805,t:1527627979232};\\\", \\\"{x:1267,y:795,t:1527627979249};\\\", \\\"{x:1229,y:786,t:1527627979264};\\\", \\\"{x:1205,y:779,t:1527627979282};\\\", \\\"{x:1173,y:769,t:1527627979298};\\\", \\\"{x:1154,y:762,t:1527627979315};\\\", \\\"{x:1142,y:757,t:1527627979332};\\\", \\\"{x:1133,y:753,t:1527627979348};\\\", \\\"{x:1129,y:750,t:1527627979365};\\\", \\\"{x:1128,y:750,t:1527627979382};\\\", \\\"{x:1127,y:749,t:1527627979399};\\\", \\\"{x:1127,y:748,t:1527627979415};\\\", \\\"{x:1125,y:747,t:1527627979432};\\\", \\\"{x:1123,y:742,t:1527627979448};\\\", \\\"{x:1121,y:739,t:1527627979464};\\\", \\\"{x:1119,y:736,t:1527627979482};\\\", \\\"{x:1114,y:730,t:1527627979498};\\\", \\\"{x:1113,y:728,t:1527627979514};\\\", \\\"{x:1111,y:725,t:1527627979531};\\\", \\\"{x:1109,y:722,t:1527627979549};\\\", \\\"{x:1107,y:721,t:1527627979565};\\\", \\\"{x:1106,y:720,t:1527627979582};\\\", \\\"{x:1105,y:719,t:1527627979598};\\\", \\\"{x:1104,y:719,t:1527627979616};\\\", \\\"{x:1102,y:717,t:1527627979632};\\\", \\\"{x:1101,y:716,t:1527627979659};\\\", \\\"{x:1100,y:716,t:1527627979675};\\\", \\\"{x:1100,y:715,t:1527627979683};\\\", \\\"{x:1098,y:714,t:1527627979699};\\\", \\\"{x:1096,y:713,t:1527627979715};\\\", \\\"{x:1095,y:713,t:1527627979731};\\\", \\\"{x:1093,y:712,t:1527627979763};\\\", \\\"{x:1092,y:711,t:1527627979867};\\\", \\\"{x:1091,y:711,t:1527627979883};\\\", \\\"{x:1090,y:709,t:1527627979899};\\\", \\\"{x:1089,y:708,t:1527627979931};\\\", \\\"{x:1088,y:708,t:1527627979948};\\\", \\\"{x:1088,y:707,t:1527627980009};\\\", \\\"{x:1087,y:707,t:1527627980026};\\\", \\\"{x:1086,y:706,t:1527627980034};\\\", \\\"{x:1085,y:706,t:1527627980048};\\\", \\\"{x:1085,y:705,t:1527627980065};\\\", \\\"{x:1083,y:704,t:1527627980082};\\\", \\\"{x:1083,y:703,t:1527627980098};\\\", \\\"{x:1082,y:703,t:1527627980171};\\\", \\\"{x:1083,y:702,t:1527627982299};\\\", \\\"{x:1085,y:701,t:1527627982317};\\\", \\\"{x:1088,y:699,t:1527627982333};\\\", \\\"{x:1090,y:699,t:1527627982350};\\\", \\\"{x:1093,y:698,t:1527627982367};\\\", \\\"{x:1095,y:698,t:1527627982384};\\\", \\\"{x:1102,y:703,t:1527627982400};\\\", \\\"{x:1116,y:712,t:1527627982418};\\\", \\\"{x:1130,y:724,t:1527627982433};\\\", \\\"{x:1146,y:734,t:1527627982451};\\\", \\\"{x:1162,y:745,t:1527627982467};\\\", \\\"{x:1177,y:756,t:1527627982484};\\\", \\\"{x:1191,y:764,t:1527627982501};\\\", \\\"{x:1199,y:768,t:1527627982517};\\\", \\\"{x:1204,y:772,t:1527627982534};\\\", \\\"{x:1206,y:774,t:1527627982550};\\\", \\\"{x:1212,y:779,t:1527627982567};\\\", \\\"{x:1216,y:784,t:1527627982582};\\\", \\\"{x:1220,y:789,t:1527627982600};\\\", \\\"{x:1223,y:793,t:1527627982617};\\\", \\\"{x:1228,y:799,t:1527627982634};\\\", \\\"{x:1237,y:812,t:1527627982650};\\\", \\\"{x:1243,y:825,t:1527627982667};\\\", \\\"{x:1246,y:829,t:1527627982683};\\\", \\\"{x:1247,y:830,t:1527627982700};\\\", \\\"{x:1249,y:834,t:1527627982717};\\\", \\\"{x:1250,y:837,t:1527627982733};\\\", \\\"{x:1250,y:839,t:1527627982750};\\\", \\\"{x:1251,y:842,t:1527627982767};\\\", \\\"{x:1254,y:848,t:1527627982783};\\\", \\\"{x:1256,y:851,t:1527627982800};\\\", \\\"{x:1257,y:853,t:1527627982817};\\\", \\\"{x:1258,y:855,t:1527627982833};\\\", \\\"{x:1258,y:858,t:1527627982850};\\\", \\\"{x:1260,y:860,t:1527627982868};\\\", \\\"{x:1261,y:862,t:1527627982885};\\\", \\\"{x:1262,y:865,t:1527627982900};\\\", \\\"{x:1264,y:871,t:1527627982918};\\\", \\\"{x:1265,y:873,t:1527627982935};\\\", \\\"{x:1266,y:877,t:1527627982951};\\\", \\\"{x:1268,y:881,t:1527627982968};\\\", \\\"{x:1268,y:883,t:1527627982985};\\\", \\\"{x:1269,y:884,t:1527627983003};\\\", \\\"{x:1270,y:885,t:1527627983027};\\\", \\\"{x:1270,y:886,t:1527627983067};\\\", \\\"{x:1271,y:887,t:1527627983090};\\\", \\\"{x:1271,y:889,t:1527627983107};\\\", \\\"{x:1271,y:890,t:1527627983117};\\\", \\\"{x:1272,y:893,t:1527627983137};\\\", \\\"{x:1274,y:897,t:1527627983150};\\\", \\\"{x:1275,y:899,t:1527627983167};\\\", \\\"{x:1277,y:903,t:1527627983184};\\\", \\\"{x:1277,y:904,t:1527627983200};\\\", \\\"{x:1278,y:905,t:1527627983217};\\\", \\\"{x:1279,y:906,t:1527627983234};\\\", \\\"{x:1280,y:906,t:1527627983250};\\\", \\\"{x:1281,y:907,t:1527627983267};\\\", \\\"{x:1281,y:909,t:1527627983290};\\\", \\\"{x:1281,y:910,t:1527627983306};\\\", \\\"{x:1281,y:912,t:1527627983322};\\\", \\\"{x:1281,y:913,t:1527627983346};\\\", \\\"{x:1281,y:915,t:1527627983353};\\\", \\\"{x:1282,y:917,t:1527627983378};\\\", \\\"{x:1282,y:920,t:1527627983394};\\\", \\\"{x:1283,y:920,t:1527627983402};\\\", \\\"{x:1284,y:922,t:1527627983417};\\\", \\\"{x:1285,y:923,t:1527627983434};\\\", \\\"{x:1285,y:925,t:1527627983466};\\\", \\\"{x:1285,y:926,t:1527627983484};\\\", \\\"{x:1285,y:927,t:1527627983502};\\\", \\\"{x:1285,y:928,t:1527627983522};\\\", \\\"{x:1285,y:929,t:1527627983535};\\\", \\\"{x:1285,y:930,t:1527627983551};\\\", \\\"{x:1285,y:932,t:1527627983567};\\\", \\\"{x:1285,y:933,t:1527627983585};\\\", \\\"{x:1285,y:935,t:1527627983602};\\\", \\\"{x:1285,y:937,t:1527627983627};\\\", \\\"{x:1285,y:938,t:1527627983642};\\\", \\\"{x:1285,y:939,t:1527627983658};\\\", \\\"{x:1285,y:940,t:1527627983668};\\\", \\\"{x:1284,y:942,t:1527627983684};\\\", \\\"{x:1284,y:943,t:1527627983714};\\\", \\\"{x:1284,y:944,t:1527627983739};\\\", \\\"{x:1284,y:945,t:1527627983762};\\\", \\\"{x:1284,y:946,t:1527627983778};\\\", \\\"{x:1284,y:947,t:1527627983802};\\\", \\\"{x:1284,y:948,t:1527627984004};\\\", \\\"{x:1284,y:949,t:1527627984027};\\\", \\\"{x:1284,y:950,t:1527627984035};\\\", \\\"{x:1284,y:951,t:1527627984051};\\\", \\\"{x:1284,y:953,t:1527627984075};\\\", \\\"{x:1284,y:954,t:1527627984091};\\\", \\\"{x:1284,y:956,t:1527627984107};\\\", \\\"{x:1285,y:958,t:1527627984147};\\\", \\\"{x:1286,y:960,t:1527627984179};\\\", \\\"{x:1287,y:961,t:1527627984203};\\\", \\\"{x:1287,y:962,t:1527627984499};\\\", \\\"{x:1287,y:963,t:1527627984538};\\\", \\\"{x:1287,y:966,t:1527627984586};\\\", \\\"{x:1287,y:967,t:1527627984633};\\\", \\\"{x:1286,y:967,t:1527627984642};\\\", \\\"{x:1286,y:969,t:1527627984698};\\\", \\\"{x:1286,y:970,t:1527627984746};\\\", \\\"{x:1286,y:972,t:1527627984778};\\\", \\\"{x:1286,y:973,t:1527627984794};\\\", \\\"{x:1286,y:975,t:1527627984835};\\\", \\\"{x:1286,y:974,t:1527627985819};\\\", \\\"{x:1286,y:973,t:1527627985883};\\\", \\\"{x:1286,y:972,t:1527627985915};\\\", \\\"{x:1286,y:971,t:1527627985986};\\\", \\\"{x:1286,y:969,t:1527627986098};\\\", \\\"{x:1286,y:968,t:1527627986148};\\\", \\\"{x:1286,y:967,t:1527627986187};\\\", \\\"{x:1286,y:966,t:1527627986291};\\\", \\\"{x:1286,y:963,t:1527627986307};\\\", \\\"{x:1286,y:962,t:1527627986323};\\\", \\\"{x:1286,y:961,t:1527627986339};\\\", \\\"{x:1285,y:960,t:1527627986354};\\\", \\\"{x:1284,y:959,t:1527627986370};\\\", \\\"{x:1282,y:954,t:1527627986387};\\\", \\\"{x:1278,y:949,t:1527627986404};\\\", \\\"{x:1273,y:944,t:1527627986420};\\\", \\\"{x:1268,y:941,t:1527627986437};\\\", \\\"{x:1262,y:937,t:1527627986453};\\\", \\\"{x:1260,y:935,t:1527627986470};\\\", \\\"{x:1246,y:931,t:1527627986487};\\\", \\\"{x:1229,y:923,t:1527627986504};\\\", \\\"{x:1210,y:908,t:1527627986520};\\\", \\\"{x:1182,y:896,t:1527627986537};\\\", \\\"{x:1161,y:885,t:1527627986554};\\\", \\\"{x:1117,y:864,t:1527627986570};\\\", \\\"{x:1047,y:837,t:1527627986586};\\\", \\\"{x:1014,y:827,t:1527627986604};\\\", \\\"{x:1004,y:822,t:1527627986620};\\\", \\\"{x:980,y:810,t:1527627986637};\\\", \\\"{x:955,y:799,t:1527627986653};\\\", \\\"{x:939,y:792,t:1527627986670};\\\", \\\"{x:928,y:788,t:1527627986687};\\\", \\\"{x:925,y:784,t:1527627986704};\\\", \\\"{x:919,y:780,t:1527627986724};\\\", \\\"{x:909,y:774,t:1527627986736};\\\", \\\"{x:896,y:767,t:1527627986754};\\\", \\\"{x:882,y:756,t:1527627986770};\\\", \\\"{x:855,y:741,t:1527627986786};\\\", \\\"{x:828,y:730,t:1527627986802};\\\", \\\"{x:800,y:713,t:1527627986820};\\\", \\\"{x:752,y:691,t:1527627986836};\\\", \\\"{x:672,y:660,t:1527627986854};\\\", \\\"{x:624,y:635,t:1527627986870};\\\", \\\"{x:587,y:616,t:1527627986887};\\\", \\\"{x:562,y:608,t:1527627986903};\\\", \\\"{x:530,y:598,t:1527627986922};\\\", \\\"{x:519,y:590,t:1527627986939};\\\", \\\"{x:515,y:587,t:1527627986956};\\\", \\\"{x:513,y:586,t:1527627986972};\\\", \\\"{x:513,y:585,t:1527627986989};\\\", \\\"{x:512,y:585,t:1527627987006};\\\", \\\"{x:514,y:583,t:1527627987026};\\\", \\\"{x:518,y:580,t:1527627987040};\\\", \\\"{x:525,y:576,t:1527627987056};\\\", \\\"{x:530,y:570,t:1527627987073};\\\", \\\"{x:533,y:569,t:1527627987089};\\\", \\\"{x:537,y:566,t:1527627987105};\\\", \\\"{x:543,y:564,t:1527627987123};\\\", \\\"{x:552,y:560,t:1527627987139};\\\", \\\"{x:556,y:556,t:1527627987156};\\\", \\\"{x:559,y:554,t:1527627987173};\\\", \\\"{x:563,y:552,t:1527627987189};\\\", \\\"{x:566,y:549,t:1527627987206};\\\", \\\"{x:567,y:548,t:1527627987223};\\\", \\\"{x:569,y:547,t:1527627987240};\\\", \\\"{x:570,y:546,t:1527627987307};\\\", \\\"{x:571,y:546,t:1527627987363};\\\", \\\"{x:574,y:545,t:1527627987374};\\\", \\\"{x:575,y:544,t:1527627987394};\\\", \\\"{x:576,y:543,t:1527627987436};\\\", \\\"{x:574,y:543,t:1527627987611};\\\", \\\"{x:558,y:543,t:1527627987622};\\\", \\\"{x:540,y:539,t:1527627987640};\\\", \\\"{x:496,y:532,t:1527627987657};\\\", \\\"{x:459,y:529,t:1527627987672};\\\", \\\"{x:416,y:526,t:1527627987689};\\\", \\\"{x:402,y:525,t:1527627987706};\\\", \\\"{x:399,y:524,t:1527627987723};\\\", \\\"{x:398,y:525,t:1527627988234};\\\", \\\"{x:399,y:526,t:1527627988242};\\\", \\\"{x:404,y:530,t:1527627988258};\\\", \\\"{x:418,y:539,t:1527627988274};\\\", \\\"{x:435,y:550,t:1527627988291};\\\", \\\"{x:448,y:557,t:1527627988308};\\\", \\\"{x:456,y:561,t:1527627988323};\\\", \\\"{x:462,y:564,t:1527627988340};\\\", \\\"{x:465,y:566,t:1527627988357};\\\", \\\"{x:468,y:567,t:1527627988373};\\\", \\\"{x:470,y:569,t:1527627988391};\\\", \\\"{x:471,y:569,t:1527627988425};\\\", \\\"{x:472,y:569,t:1527627988474};\\\", \\\"{x:473,y:569,t:1527627988490};\\\", \\\"{x:475,y:568,t:1527627988746};\\\", \\\"{x:478,y:561,t:1527627988757};\\\", \\\"{x:478,y:554,t:1527627988775};\\\", \\\"{x:479,y:549,t:1527627988791};\\\", \\\"{x:483,y:543,t:1527627988808};\\\", \\\"{x:486,y:539,t:1527627988824};\\\", \\\"{x:489,y:536,t:1527627988841};\\\", \\\"{x:499,y:519,t:1527627988859};\\\", \\\"{x:506,y:512,t:1527627988873};\\\", \\\"{x:512,y:504,t:1527627988891};\\\", \\\"{x:522,y:492,t:1527627988907};\\\", \\\"{x:525,y:487,t:1527627988925};\\\", \\\"{x:529,y:482,t:1527627988942};\\\", \\\"{x:531,y:479,t:1527627988957};\\\", \\\"{x:532,y:479,t:1527627988974};\\\", \\\"{x:532,y:478,t:1527627989387};\\\", \\\"{x:534,y:475,t:1527627989402};\\\", \\\"{x:539,y:471,t:1527627989409};\\\", \\\"{x:545,y:467,t:1527627989425};\\\", \\\"{x:547,y:465,t:1527627989441};\\\", \\\"{x:550,y:463,t:1527627989458};\\\", \\\"{x:552,y:461,t:1527627989474};\\\", \\\"{x:554,y:460,t:1527627989492};\\\", \\\"{x:556,y:457,t:1527627989679};\\\", \\\"{x:557,y:456,t:1527627989703};\\\", \\\"{x:557,y:455,t:1527627989719};\\\", \\\"{x:558,y:454,t:1527627989727};\\\", \\\"{x:568,y:457,t:1527627996920};\\\", \\\"{x:595,y:470,t:1527627996930};\\\", \\\"{x:657,y:502,t:1527627996946};\\\", \\\"{x:707,y:525,t:1527627996964};\\\", \\\"{x:729,y:536,t:1527627996980};\\\", \\\"{x:759,y:553,t:1527627996996};\\\", \\\"{x:769,y:558,t:1527627997006};\\\", \\\"{x:791,y:574,t:1527627997023};\\\", \\\"{x:812,y:589,t:1527627997040};\\\", \\\"{x:829,y:607,t:1527627997056};\\\", \\\"{x:841,y:619,t:1527627997079};\\\", \\\"{x:844,y:623,t:1527627997095};\\\", \\\"{x:848,y:628,t:1527627997112};\\\", \\\"{x:853,y:639,t:1527627997129};\\\", \\\"{x:857,y:650,t:1527627997145};\\\", \\\"{x:872,y:669,t:1527627997162};\\\", \\\"{x:888,y:692,t:1527627997180};\\\", \\\"{x:907,y:709,t:1527627997195};\\\", \\\"{x:915,y:719,t:1527627997212};\\\", \\\"{x:925,y:728,t:1527627997229};\\\", \\\"{x:939,y:739,t:1527627997245};\\\", \\\"{x:954,y:751,t:1527627997263};\\\", \\\"{x:984,y:769,t:1527627997279};\\\", \\\"{x:1008,y:779,t:1527627997296};\\\", \\\"{x:1025,y:789,t:1527627997312};\\\", \\\"{x:1041,y:794,t:1527627997329};\\\", \\\"{x:1053,y:802,t:1527627997346};\\\", \\\"{x:1070,y:807,t:1527627997362};\\\", \\\"{x:1086,y:811,t:1527627997380};\\\", \\\"{x:1102,y:815,t:1527627997397};\\\", \\\"{x:1110,y:816,t:1527627997413};\\\", \\\"{x:1119,y:817,t:1527627997430};\\\", \\\"{x:1132,y:816,t:1527627997447};\\\", \\\"{x:1146,y:813,t:1527627997464};\\\", \\\"{x:1151,y:813,t:1527627997480};\\\", \\\"{x:1161,y:809,t:1527627997497};\\\", \\\"{x:1170,y:806,t:1527627997514};\\\", \\\"{x:1177,y:805,t:1527627997530};\\\", \\\"{x:1185,y:804,t:1527627997547};\\\", \\\"{x:1188,y:804,t:1527627997564};\\\", \\\"{x:1196,y:803,t:1527627997581};\\\", \\\"{x:1201,y:802,t:1527627997597};\\\", \\\"{x:1204,y:802,t:1527627997614};\\\", \\\"{x:1206,y:802,t:1527627997631};\\\", \\\"{x:1212,y:801,t:1527627997647};\\\", \\\"{x:1225,y:803,t:1527627997664};\\\", \\\"{x:1235,y:808,t:1527627997681};\\\", \\\"{x:1248,y:812,t:1527627997697};\\\", \\\"{x:1263,y:814,t:1527627997714};\\\", \\\"{x:1275,y:820,t:1527627997731};\\\", \\\"{x:1279,y:822,t:1527627997748};\\\", \\\"{x:1283,y:823,t:1527627997764};\\\", \\\"{x:1284,y:823,t:1527627997781};\\\", \\\"{x:1285,y:824,t:1527627997857};\\\", \\\"{x:1285,y:825,t:1527627997864};\\\", \\\"{x:1285,y:826,t:1527627997881};\\\", \\\"{x:1286,y:828,t:1527627997898};\\\", \\\"{x:1287,y:829,t:1527627997916};\\\", \\\"{x:1289,y:830,t:1527627997969};\\\", \\\"{x:1289,y:831,t:1527627998743};\\\", \\\"{x:1289,y:832,t:1527627998776};\\\", \\\"{x:1286,y:832,t:1527627998783};\\\", \\\"{x:1284,y:832,t:1527627998816};\\\", \\\"{x:1281,y:833,t:1527627998833};\\\", \\\"{x:1280,y:833,t:1527627998850};\\\", \\\"{x:1278,y:835,t:1527627998867};\\\", \\\"{x:1275,y:837,t:1527627998884};\\\", \\\"{x:1270,y:839,t:1527627998899};\\\", \\\"{x:1267,y:840,t:1527627998917};\\\", \\\"{x:1263,y:841,t:1527627998934};\\\", \\\"{x:1260,y:842,t:1527627998950};\\\", \\\"{x:1258,y:842,t:1527627998966};\\\", \\\"{x:1256,y:843,t:1527627998984};\\\", \\\"{x:1255,y:843,t:1527627999008};\\\", \\\"{x:1254,y:843,t:1527627999056};\\\", \\\"{x:1253,y:843,t:1527627999067};\\\", \\\"{x:1252,y:843,t:1527627999209};\\\", \\\"{x:1251,y:844,t:1527627999218};\\\", \\\"{x:1254,y:844,t:1527627999312};\\\", \\\"{x:1257,y:844,t:1527627999320};\\\", \\\"{x:1259,y:842,t:1527627999334};\\\", \\\"{x:1262,y:840,t:1527627999351};\\\", \\\"{x:1264,y:838,t:1527627999368};\\\", \\\"{x:1266,y:838,t:1527627999433};\\\", \\\"{x:1268,y:839,t:1527627999448};\\\", \\\"{x:1269,y:839,t:1527627999456};\\\", \\\"{x:1271,y:839,t:1527627999468};\\\", \\\"{x:1274,y:839,t:1527627999486};\\\", \\\"{x:1276,y:839,t:1527627999502};\\\", \\\"{x:1278,y:839,t:1527627999518};\\\", \\\"{x:1278,y:840,t:1527627999535};\\\", \\\"{x:1279,y:840,t:1527628000944};\\\", \\\"{x:1279,y:839,t:1527628000992};\\\", \\\"{x:1279,y:838,t:1527628001960};\\\", \\\"{x:1278,y:837,t:1527628001984};\\\", \\\"{x:1277,y:837,t:1527628002040};\\\", \\\"{x:1277,y:838,t:1527628004576};\\\", \\\"{x:1279,y:841,t:1527628004584};\\\", \\\"{x:1281,y:842,t:1527628004598};\\\", \\\"{x:1285,y:846,t:1527628004614};\\\", \\\"{x:1287,y:848,t:1527628004632};\\\", \\\"{x:1288,y:849,t:1527628004647};\\\", \\\"{x:1290,y:852,t:1527628004664};\\\", \\\"{x:1290,y:854,t:1527628004682};\\\", \\\"{x:1291,y:854,t:1527628004697};\\\", \\\"{x:1292,y:858,t:1527628004714};\\\", \\\"{x:1293,y:860,t:1527628004731};\\\", \\\"{x:1294,y:860,t:1527628004753};\\\", \\\"{x:1295,y:861,t:1527628004873};\\\", \\\"{x:1296,y:863,t:1527628004882};\\\", \\\"{x:1297,y:863,t:1527628004899};\\\", \\\"{x:1300,y:866,t:1527628004916};\\\", \\\"{x:1304,y:868,t:1527628004931};\\\", \\\"{x:1306,y:873,t:1527628004948};\\\", \\\"{x:1311,y:875,t:1527628004965};\\\", \\\"{x:1313,y:877,t:1527628004982};\\\", \\\"{x:1314,y:877,t:1527628004999};\\\", \\\"{x:1315,y:879,t:1527628005016};\\\", \\\"{x:1316,y:879,t:1527628005032};\\\", \\\"{x:1317,y:880,t:1527628005049};\\\", \\\"{x:1318,y:881,t:1527628005066};\\\", \\\"{x:1319,y:882,t:1527628005082};\\\", \\\"{x:1320,y:882,t:1527628005129};\\\", \\\"{x:1321,y:882,t:1527628005136};\\\", \\\"{x:1323,y:882,t:1527628005439};\\\", \\\"{x:1324,y:879,t:1527628005448};\\\", \\\"{x:1325,y:876,t:1527628005466};\\\", \\\"{x:1325,y:867,t:1527628005483};\\\", \\\"{x:1328,y:856,t:1527628005499};\\\", \\\"{x:1331,y:845,t:1527628005516};\\\", \\\"{x:1332,y:835,t:1527628005533};\\\", \\\"{x:1338,y:816,t:1527628005549};\\\", \\\"{x:1341,y:797,t:1527628005566};\\\", \\\"{x:1345,y:780,t:1527628005582};\\\", \\\"{x:1338,y:729,t:1527628005599};\\\", \\\"{x:1336,y:695,t:1527628005615};\\\", \\\"{x:1336,y:672,t:1527628005633};\\\", \\\"{x:1335,y:653,t:1527628005650};\\\", \\\"{x:1333,y:632,t:1527628005666};\\\", \\\"{x:1333,y:617,t:1527628005682};\\\", \\\"{x:1335,y:601,t:1527628005699};\\\", \\\"{x:1336,y:594,t:1527628005717};\\\", \\\"{x:1336,y:584,t:1527628005733};\\\", \\\"{x:1340,y:572,t:1527628005750};\\\", \\\"{x:1344,y:566,t:1527628005766};\\\", \\\"{x:1345,y:564,t:1527628005783};\\\", \\\"{x:1350,y:558,t:1527628005800};\\\", \\\"{x:1354,y:554,t:1527628005816};\\\", \\\"{x:1356,y:553,t:1527628005834};\\\", \\\"{x:1358,y:553,t:1527628005850};\\\", \\\"{x:1363,y:551,t:1527628005867};\\\", \\\"{x:1365,y:550,t:1527628005884};\\\", \\\"{x:1366,y:550,t:1527628005899};\\\", \\\"{x:1369,y:547,t:1527628005917};\\\", \\\"{x:1372,y:546,t:1527628005933};\\\", \\\"{x:1373,y:545,t:1527628005950};\\\", \\\"{x:1374,y:544,t:1527628006295};\\\", \\\"{x:1376,y:544,t:1527628006303};\\\", \\\"{x:1377,y:545,t:1527628006317};\\\", \\\"{x:1383,y:546,t:1527628006335};\\\", \\\"{x:1387,y:548,t:1527628006351};\\\", \\\"{x:1392,y:549,t:1527628006368};\\\", \\\"{x:1394,y:549,t:1527628006385};\\\", \\\"{x:1397,y:551,t:1527628006402};\\\", \\\"{x:1398,y:551,t:1527628006424};\\\", \\\"{x:1399,y:551,t:1527628006439};\\\", \\\"{x:1400,y:551,t:1527628006452};\\\", \\\"{x:1401,y:551,t:1527628006468};\\\", \\\"{x:1401,y:552,t:1527628006485};\\\", \\\"{x:1405,y:553,t:1527628006502};\\\", \\\"{x:1407,y:555,t:1527628006518};\\\", \\\"{x:1409,y:556,t:1527628006535};\\\", \\\"{x:1412,y:557,t:1527628006551};\\\", \\\"{x:1415,y:559,t:1527628006569};\\\", \\\"{x:1424,y:564,t:1527628006585};\\\", \\\"{x:1430,y:569,t:1527628006602};\\\", \\\"{x:1441,y:572,t:1527628006619};\\\", \\\"{x:1450,y:576,t:1527628006635};\\\", \\\"{x:1457,y:578,t:1527628006652};\\\", \\\"{x:1460,y:580,t:1527628006669};\\\", \\\"{x:1464,y:581,t:1527628006686};\\\", \\\"{x:1468,y:583,t:1527628006702};\\\", \\\"{x:1469,y:583,t:1527628006719};\\\", \\\"{x:1471,y:584,t:1527628006736};\\\", \\\"{x:1473,y:586,t:1527628006752};\\\", \\\"{x:1474,y:586,t:1527628006769};\\\", \\\"{x:1477,y:588,t:1527628006786};\\\", \\\"{x:1478,y:590,t:1527628006802};\\\", \\\"{x:1481,y:592,t:1527628006819};\\\", \\\"{x:1485,y:595,t:1527628006837};\\\", \\\"{x:1493,y:601,t:1527628006854};\\\", \\\"{x:1497,y:603,t:1527628006869};\\\", \\\"{x:1500,y:606,t:1527628006886};\\\", \\\"{x:1502,y:609,t:1527628006904};\\\", \\\"{x:1505,y:611,t:1527628006920};\\\", \\\"{x:1507,y:613,t:1527628006937};\\\", \\\"{x:1508,y:615,t:1527628006954};\\\", \\\"{x:1508,y:618,t:1527628006971};\\\", \\\"{x:1511,y:620,t:1527628006986};\\\", \\\"{x:1512,y:622,t:1527628007003};\\\", \\\"{x:1514,y:624,t:1527628007020};\\\", \\\"{x:1515,y:626,t:1527628007037};\\\", \\\"{x:1515,y:627,t:1527628007053};\\\", \\\"{x:1517,y:630,t:1527628007070};\\\", \\\"{x:1520,y:635,t:1527628007087};\\\", \\\"{x:1522,y:642,t:1527628007103};\\\", \\\"{x:1526,y:653,t:1527628007120};\\\", \\\"{x:1529,y:661,t:1527628007138};\\\", \\\"{x:1530,y:666,t:1527628007153};\\\", \\\"{x:1531,y:669,t:1527628007170};\\\", \\\"{x:1533,y:671,t:1527628007188};\\\", \\\"{x:1533,y:673,t:1527628007204};\\\", \\\"{x:1534,y:675,t:1527628007221};\\\", \\\"{x:1534,y:676,t:1527628007237};\\\", \\\"{x:1534,y:677,t:1527628007345};\\\", \\\"{x:1530,y:679,t:1527628007355};\\\", \\\"{x:1529,y:687,t:1527628007370};\\\", \\\"{x:1529,y:688,t:1527628007424};\\\", \\\"{x:1528,y:689,t:1527628007437};\\\", \\\"{x:1523,y:690,t:1527628007454};\\\", \\\"{x:1517,y:691,t:1527628007472};\\\", \\\"{x:1502,y:693,t:1527628007488};\\\", \\\"{x:1480,y:696,t:1527628007504};\\\", \\\"{x:1456,y:700,t:1527628007522};\\\", \\\"{x:1438,y:702,t:1527628007538};\\\", \\\"{x:1412,y:706,t:1527628007554};\\\", \\\"{x:1394,y:711,t:1527628007571};\\\", \\\"{x:1382,y:716,t:1527628007588};\\\", \\\"{x:1369,y:719,t:1527628007605};\\\", \\\"{x:1359,y:726,t:1527628007622};\\\", \\\"{x:1355,y:726,t:1527628007638};\\\", \\\"{x:1348,y:727,t:1527628007655};\\\", \\\"{x:1344,y:727,t:1527628007671};\\\", \\\"{x:1309,y:734,t:1527628007688};\\\", \\\"{x:1279,y:738,t:1527628007705};\\\", \\\"{x:1246,y:738,t:1527628007722};\\\", \\\"{x:1207,y:738,t:1527628007739};\\\", \\\"{x:1156,y:738,t:1527628007754};\\\", \\\"{x:1111,y:738,t:1527628007771};\\\", \\\"{x:1069,y:738,t:1527628007788};\\\", \\\"{x:1041,y:738,t:1527628007804};\\\", \\\"{x:1013,y:738,t:1527628007822};\\\", \\\"{x:987,y:735,t:1527628007838};\\\", \\\"{x:973,y:735,t:1527628007855};\\\", \\\"{x:947,y:734,t:1527628007871};\\\", \\\"{x:938,y:733,t:1527628007888};\\\", \\\"{x:933,y:733,t:1527628007905};\\\", \\\"{x:931,y:733,t:1527628007921};\\\", \\\"{x:930,y:733,t:1527628007942};\\\", \\\"{x:927,y:735,t:1527628008063};\\\", \\\"{x:926,y:735,t:1527628008072};\\\", \\\"{x:925,y:736,t:1527628008089};\\\", \\\"{x:923,y:737,t:1527628008126};\\\", \\\"{x:921,y:738,t:1527628008138};\\\", \\\"{x:920,y:739,t:1527628008156};\\\", \\\"{x:917,y:745,t:1527628008172};\\\", \\\"{x:913,y:751,t:1527628008189};\\\", \\\"{x:911,y:754,t:1527628008206};\\\", \\\"{x:910,y:757,t:1527628008222};\\\", \\\"{x:909,y:758,t:1527628008303};\\\", \\\"{x:907,y:759,t:1527628008384};\\\", \\\"{x:906,y:759,t:1527628008432};\\\", \\\"{x:905,y:760,t:1527628008530};\\\", \\\"{x:904,y:761,t:1527628008888};\\\", \\\"{x:903,y:762,t:1527628008968};\\\", \\\"{x:903,y:764,t:1527628010288};\\\", \\\"{x:903,y:774,t:1527628010296};\\\", \\\"{x:924,y:788,t:1527628010311};\\\", \\\"{x:939,y:801,t:1527628010328};\\\", \\\"{x:960,y:815,t:1527628010344};\\\", \\\"{x:980,y:825,t:1527628010361};\\\", \\\"{x:995,y:832,t:1527628010379};\\\", \\\"{x:1005,y:838,t:1527628010395};\\\", \\\"{x:1010,y:843,t:1527628010411};\\\", \\\"{x:1015,y:846,t:1527628010428};\\\", \\\"{x:1015,y:847,t:1527628010445};\\\", \\\"{x:1015,y:850,t:1527628010462};\\\", \\\"{x:1015,y:851,t:1527628010479};\\\", \\\"{x:1015,y:853,t:1527628010496};\\\", \\\"{x:1015,y:856,t:1527628010512};\\\", \\\"{x:1018,y:866,t:1527628010528};\\\", \\\"{x:1020,y:868,t:1527628010545};\\\", \\\"{x:1023,y:871,t:1527628010561};\\\", \\\"{x:1024,y:871,t:1527628010578};\\\", \\\"{x:1025,y:871,t:1527628010595};\\\", \\\"{x:1028,y:873,t:1527628010612};\\\", \\\"{x:1034,y:875,t:1527628010628};\\\", \\\"{x:1046,y:882,t:1527628010644};\\\", \\\"{x:1048,y:884,t:1527628010662};\\\", \\\"{x:1049,y:884,t:1527628010678};\\\", \\\"{x:1049,y:886,t:1527628010695};\\\", \\\"{x:1051,y:889,t:1527628010712};\\\", \\\"{x:1058,y:893,t:1527628010728};\\\", \\\"{x:1063,y:894,t:1527628010746};\\\", \\\"{x:1067,y:897,t:1527628010762};\\\", \\\"{x:1073,y:897,t:1527628010779};\\\", \\\"{x:1078,y:895,t:1527628010795};\\\", \\\"{x:1084,y:888,t:1527628010812};\\\", \\\"{x:1086,y:885,t:1527628010829};\\\", \\\"{x:1086,y:884,t:1527628011264};\\\", \\\"{x:1084,y:877,t:1527628011280};\\\", \\\"{x:1075,y:871,t:1527628011297};\\\", \\\"{x:1054,y:853,t:1527628011314};\\\", \\\"{x:1024,y:833,t:1527628011330};\\\", \\\"{x:997,y:802,t:1527628011347};\\\", \\\"{x:943,y:774,t:1527628011364};\\\", \\\"{x:915,y:745,t:1527628011380};\\\", \\\"{x:889,y:727,t:1527628011397};\\\", \\\"{x:875,y:716,t:1527628011413};\\\", \\\"{x:860,y:705,t:1527628011430};\\\", \\\"{x:832,y:682,t:1527628011447};\\\", \\\"{x:803,y:659,t:1527628011467};\\\", \\\"{x:777,y:630,t:1527628011479};\\\", \\\"{x:759,y:618,t:1527628011497};\\\", \\\"{x:741,y:607,t:1527628011514};\\\", \\\"{x:727,y:598,t:1527628011530};\\\", \\\"{x:722,y:593,t:1527628011541};\\\", \\\"{x:704,y:578,t:1527628011557};\\\", \\\"{x:691,y:568,t:1527628011574};\\\", \\\"{x:674,y:556,t:1527628011591};\\\", \\\"{x:664,y:550,t:1527628011607};\\\", \\\"{x:662,y:548,t:1527628011624};\\\", \\\"{x:660,y:545,t:1527628011641};\\\", \\\"{x:659,y:543,t:1527628011657};\\\", \\\"{x:660,y:543,t:1527628011719};\\\", \\\"{x:660,y:542,t:1527628011727};\\\", \\\"{x:662,y:540,t:1527628011739};\\\", \\\"{x:666,y:537,t:1527628011756};\\\", \\\"{x:672,y:536,t:1527628011774};\\\", \\\"{x:681,y:530,t:1527628011790};\\\", \\\"{x:704,y:520,t:1527628011807};\\\", \\\"{x:708,y:518,t:1527628011823};\\\", \\\"{x:716,y:513,t:1527628011840};\\\", \\\"{x:736,y:513,t:1527628011859};\\\", \\\"{x:755,y:512,t:1527628011874};\\\", \\\"{x:776,y:514,t:1527628011890};\\\", \\\"{x:790,y:513,t:1527628011907};\\\", \\\"{x:805,y:511,t:1527628011924};\\\", \\\"{x:816,y:507,t:1527628011941};\\\", \\\"{x:824,y:503,t:1527628011959};\\\", \\\"{x:830,y:502,t:1527628011974};\\\", \\\"{x:837,y:499,t:1527628011991};\\\", \\\"{x:839,y:499,t:1527628012007};\\\", \\\"{x:840,y:499,t:1527628012025};\\\", \\\"{x:842,y:498,t:1527628012072};\\\", \\\"{x:847,y:497,t:1527628012384};\\\", \\\"{x:859,y:489,t:1527628012392};\\\", \\\"{x:910,y:448,t:1527628012408};\\\", \\\"{x:977,y:403,t:1527628012425};\\\", \\\"{x:1014,y:376,t:1527628012442};\\\", \\\"{x:1087,y:337,t:1527628012459};\\\", \\\"{x:1144,y:306,t:1527628012476};\\\", \\\"{x:1161,y:291,t:1527628012493};\\\", \\\"{x:1168,y:281,t:1527628012510};\\\", \\\"{x:1175,y:276,t:1527628012525};\\\", \\\"{x:1180,y:273,t:1527628012542};\\\", \\\"{x:1183,y:272,t:1527628012560};\\\", \\\"{x:1183,y:273,t:1527628012624};\\\", \\\"{x:1190,y:284,t:1527628012632};\\\", \\\"{x:1199,y:300,t:1527628012642};\\\", \\\"{x:1224,y:356,t:1527628012660};\\\", \\\"{x:1244,y:431,t:1527628012676};\\\", \\\"{x:1258,y:481,t:1527628012693};\\\", \\\"{x:1278,y:540,t:1527628012710};\\\", \\\"{x:1289,y:576,t:1527628012727};\\\", \\\"{x:1298,y:625,t:1527628012743};\\\", \\\"{x:1308,y:680,t:1527628012760};\\\", \\\"{x:1312,y:695,t:1527628012776};\\\", \\\"{x:1312,y:719,t:1527628012792};\\\", \\\"{x:1317,y:749,t:1527628012809};\\\", \\\"{x:1318,y:765,t:1527628012827};\\\", \\\"{x:1319,y:781,t:1527628012842};\\\", \\\"{x:1319,y:796,t:1527628012860};\\\", \\\"{x:1319,y:804,t:1527628012877};\\\", \\\"{x:1319,y:808,t:1527628012893};\\\", \\\"{x:1319,y:815,t:1527628012910};\\\", \\\"{x:1319,y:821,t:1527628012927};\\\", \\\"{x:1319,y:827,t:1527628012944};\\\", \\\"{x:1319,y:830,t:1527628012960};\\\", \\\"{x:1316,y:835,t:1527628012976};\\\", \\\"{x:1309,y:844,t:1527628012993};\\\", \\\"{x:1306,y:847,t:1527628013010};\\\", \\\"{x:1301,y:850,t:1527628013027};\\\", \\\"{x:1299,y:852,t:1527628013044};\\\", \\\"{x:1297,y:852,t:1527628013059};\\\", \\\"{x:1296,y:852,t:1527628014048};\\\", \\\"{x:1296,y:854,t:1527628014062};\\\", \\\"{x:1299,y:856,t:1527628014079};\\\", \\\"{x:1303,y:858,t:1527628014094};\\\", \\\"{x:1305,y:858,t:1527628014112};\\\", \\\"{x:1307,y:859,t:1527628014208};\\\", \\\"{x:1308,y:860,t:1527628014216};\\\", \\\"{x:1310,y:861,t:1527628014228};\\\", \\\"{x:1312,y:862,t:1527628014246};\\\", \\\"{x:1315,y:864,t:1527628014261};\\\", \\\"{x:1317,y:866,t:1527628014278};\\\", \\\"{x:1322,y:869,t:1527628014296};\\\", \\\"{x:1324,y:870,t:1527628014311};\\\", \\\"{x:1325,y:870,t:1527628014392};\\\", \\\"{x:1327,y:871,t:1527628014472};\\\", \\\"{x:1328,y:871,t:1527628014496};\\\", \\\"{x:1330,y:871,t:1527628014519};\\\", \\\"{x:1332,y:871,t:1527628014648};\\\", \\\"{x:1332,y:872,t:1527628014663};\\\", \\\"{x:1335,y:875,t:1527628014680};\\\", \\\"{x:1338,y:877,t:1527628014695};\\\", \\\"{x:1342,y:880,t:1527628014713};\\\", \\\"{x:1345,y:882,t:1527628014730};\\\", \\\"{x:1348,y:884,t:1527628014745};\\\", \\\"{x:1352,y:887,t:1527628014763};\\\", \\\"{x:1355,y:891,t:1527628014779};\\\", \\\"{x:1357,y:891,t:1527628014795};\\\", \\\"{x:1357,y:892,t:1527628014813};\\\", \\\"{x:1357,y:893,t:1527628015304};\\\", \\\"{x:1359,y:895,t:1527628015313};\\\", \\\"{x:1359,y:896,t:1527628015331};\\\", \\\"{x:1359,y:897,t:1527628015347};\\\", \\\"{x:1360,y:898,t:1527628015364};\\\", \\\"{x:1360,y:899,t:1527628015381};\\\", \\\"{x:1361,y:900,t:1527628015424};\\\", \\\"{x:1363,y:903,t:1527628015456};\\\", \\\"{x:1361,y:902,t:1527628016456};\\\", \\\"{x:1358,y:902,t:1527628016465};\\\", \\\"{x:1354,y:900,t:1527628016482};\\\", \\\"{x:1349,y:897,t:1527628016499};\\\", \\\"{x:1348,y:896,t:1527628016515};\\\", \\\"{x:1347,y:896,t:1527628016575};\\\", \\\"{x:1346,y:895,t:1527628016582};\\\", \\\"{x:1346,y:894,t:1527628016598};\\\", \\\"{x:1344,y:892,t:1527628016614};\\\", \\\"{x:1343,y:891,t:1527628016632};\\\", \\\"{x:1341,y:890,t:1527628016648};\\\", \\\"{x:1339,y:889,t:1527628016664};\\\", \\\"{x:1338,y:888,t:1527628016686};\\\", \\\"{x:1337,y:886,t:1527628016702};\\\", \\\"{x:1336,y:885,t:1527628016715};\\\", \\\"{x:1333,y:883,t:1527628016732};\\\", \\\"{x:1329,y:880,t:1527628016748};\\\", \\\"{x:1325,y:877,t:1527628016765};\\\", \\\"{x:1323,y:875,t:1527628016782};\\\", \\\"{x:1321,y:873,t:1527628016799};\\\", \\\"{x:1320,y:873,t:1527628016814};\\\", \\\"{x:1320,y:872,t:1527628016832};\\\", \\\"{x:1317,y:871,t:1527628016849};\\\", \\\"{x:1313,y:869,t:1527628016866};\\\", \\\"{x:1311,y:869,t:1527628016883};\\\", \\\"{x:1309,y:869,t:1527628016899};\\\", \\\"{x:1308,y:869,t:1527628016944};\\\", \\\"{x:1308,y:868,t:1527628019848};\\\", \\\"{x:1308,y:867,t:1527628019880};\\\", \\\"{x:1308,y:866,t:1527628019888};\\\", \\\"{x:1308,y:865,t:1527628019928};\\\", \\\"{x:1309,y:868,t:1527628020679};\\\", \\\"{x:1310,y:869,t:1527628020694};\\\", \\\"{x:1310,y:870,t:1527628020751};\\\", \\\"{x:1310,y:872,t:1527628020775};\\\", \\\"{x:1309,y:873,t:1527628020880};\\\", \\\"{x:1308,y:875,t:1527628020920};\\\", \\\"{x:1308,y:877,t:1527628020960};\\\", \\\"{x:1307,y:878,t:1527628020973};\\\", \\\"{x:1306,y:878,t:1527628021056};\\\", \\\"{x:1305,y:879,t:1527628021073};\\\", \\\"{x:1303,y:879,t:1527628021089};\\\", \\\"{x:1295,y:879,t:1527628021106};\\\", \\\"{x:1281,y:879,t:1527628021123};\\\", \\\"{x:1264,y:876,t:1527628021140};\\\", \\\"{x:1247,y:870,t:1527628021156};\\\", \\\"{x:1232,y:865,t:1527628021173};\\\", \\\"{x:1228,y:863,t:1527628021190};\\\", \\\"{x:1220,y:860,t:1527628021205};\\\", \\\"{x:1214,y:857,t:1527628021223};\\\", \\\"{x:1212,y:855,t:1527628021239};\\\", \\\"{x:1210,y:853,t:1527628021255};\\\", \\\"{x:1209,y:851,t:1527628021383};\\\", \\\"{x:1209,y:850,t:1527628021512};\\\", \\\"{x:1209,y:849,t:1527628021527};\\\", \\\"{x:1208,y:848,t:1527628021539};\\\", \\\"{x:1208,y:846,t:1527628021559};\\\", \\\"{x:1208,y:845,t:1527628021573};\\\", \\\"{x:1207,y:843,t:1527628021589};\\\", \\\"{x:1207,y:842,t:1527628021631};\\\", \\\"{x:1207,y:840,t:1527628022864};\\\", \\\"{x:1198,y:832,t:1527628022876};\\\", \\\"{x:1139,y:818,t:1527628022892};\\\", \\\"{x:1046,y:795,t:1527628022909};\\\", \\\"{x:925,y:766,t:1527628022926};\\\", \\\"{x:809,y:739,t:1527628022941};\\\", \\\"{x:666,y:716,t:1527628022960};\\\", \\\"{x:619,y:699,t:1527628022975};\\\", \\\"{x:594,y:689,t:1527628022991};\\\", \\\"{x:575,y:679,t:1527628023009};\\\", \\\"{x:563,y:673,t:1527628023026};\\\", \\\"{x:555,y:669,t:1527628023042};\\\", \\\"{x:552,y:668,t:1527628023059};\\\", \\\"{x:550,y:666,t:1527628023075};\\\", \\\"{x:548,y:664,t:1527628023093};\\\", \\\"{x:539,y:660,t:1527628023109};\\\", \\\"{x:525,y:650,t:1527628023127};\\\", \\\"{x:514,y:642,t:1527628023142};\\\", \\\"{x:494,y:636,t:1527628023158};\\\", \\\"{x:479,y:632,t:1527628023183};\\\", \\\"{x:468,y:627,t:1527628023199};\\\", \\\"{x:461,y:627,t:1527628023216};\\\", \\\"{x:453,y:621,t:1527628023233};\\\", \\\"{x:443,y:617,t:1527628023251};\\\", \\\"{x:438,y:613,t:1527628023266};\\\", \\\"{x:434,y:612,t:1527628023284};\\\", \\\"{x:425,y:609,t:1527628023300};\\\", \\\"{x:411,y:603,t:1527628023316};\\\", \\\"{x:400,y:598,t:1527628023333};\\\", \\\"{x:391,y:594,t:1527628023350};\\\", \\\"{x:376,y:589,t:1527628023366};\\\", \\\"{x:371,y:586,t:1527628023383};\\\", \\\"{x:370,y:586,t:1527628023407};\\\", \\\"{x:370,y:585,t:1527628023423};\\\", \\\"{x:372,y:582,t:1527628023496};\\\", \\\"{x:373,y:581,t:1527628023505};\\\", \\\"{x:375,y:579,t:1527628023517};\\\", \\\"{x:384,y:575,t:1527628023533};\\\", \\\"{x:404,y:564,t:1527628023550};\\\", \\\"{x:422,y:556,t:1527628023567};\\\", \\\"{x:438,y:546,t:1527628023583};\\\", \\\"{x:450,y:541,t:1527628023600};\\\", \\\"{x:464,y:532,t:1527628023618};\\\", \\\"{x:484,y:523,t:1527628023633};\\\", \\\"{x:500,y:518,t:1527628023651};\\\", \\\"{x:519,y:516,t:1527628023667};\\\", \\\"{x:535,y:516,t:1527628023685};\\\", \\\"{x:553,y:517,t:1527628023700};\\\", \\\"{x:567,y:517,t:1527628023717};\\\", \\\"{x:571,y:520,t:1527628023734};\\\", \\\"{x:572,y:520,t:1527628023759};\\\", \\\"{x:572,y:521,t:1527628023767};\\\", \\\"{x:574,y:523,t:1527628023784};\\\", \\\"{x:577,y:527,t:1527628023801};\\\", \\\"{x:582,y:533,t:1527628023817};\\\", \\\"{x:586,y:540,t:1527628023835};\\\", \\\"{x:591,y:545,t:1527628023851};\\\", \\\"{x:595,y:549,t:1527628023867};\\\", \\\"{x:601,y:557,t:1527628023885};\\\", \\\"{x:605,y:563,t:1527628023901};\\\", \\\"{x:613,y:573,t:1527628023918};\\\", \\\"{x:619,y:583,t:1527628023935};\\\", \\\"{x:622,y:587,t:1527628023950};\\\", \\\"{x:633,y:603,t:1527628023967};\\\", \\\"{x:643,y:615,t:1527628023985};\\\", \\\"{x:652,y:625,t:1527628024001};\\\", \\\"{x:661,y:633,t:1527628024017};\\\", \\\"{x:669,y:640,t:1527628024034};\\\", \\\"{x:676,y:645,t:1527628024051};\\\", \\\"{x:685,y:650,t:1527628024067};\\\", \\\"{x:689,y:652,t:1527628024085};\\\", \\\"{x:693,y:653,t:1527628024102};\\\", \\\"{x:701,y:659,t:1527628024118};\\\", \\\"{x:713,y:668,t:1527628024134};\\\", \\\"{x:724,y:676,t:1527628024150};\\\", \\\"{x:742,y:687,t:1527628024168};\\\", \\\"{x:760,y:699,t:1527628024185};\\\", \\\"{x:781,y:714,t:1527628024201};\\\", \\\"{x:809,y:732,t:1527628024217};\\\", \\\"{x:828,y:744,t:1527628024234};\\\", \\\"{x:843,y:753,t:1527628024251};\\\", \\\"{x:861,y:764,t:1527628024268};\\\", \\\"{x:876,y:772,t:1527628024284};\\\", \\\"{x:887,y:779,t:1527628024302};\\\", \\\"{x:888,y:781,t:1527628024318};\\\", \\\"{x:890,y:783,t:1527628024334};\\\", \\\"{x:891,y:784,t:1527628025119};\\\", \\\"{x:892,y:784,t:1527628025135};\\\", \\\"{x:893,y:786,t:1527628025152};\\\", \\\"{x:900,y:787,t:1527628025168};\\\", \\\"{x:902,y:789,t:1527628025185};\\\", \\\"{x:904,y:790,t:1527628025202};\\\", \\\"{x:905,y:791,t:1527628025222};\\\", \\\"{x:906,y:791,t:1527628025246};\\\", \\\"{x:907,y:791,t:1527628025263};\\\", \\\"{x:907,y:792,t:1527628025360};\\\", \\\"{x:908,y:792,t:1527628025536};\\\", \\\"{x:909,y:792,t:1527628025760};\\\", \\\"{x:910,y:791,t:1527628025952};\\\", \\\"{x:910,y:790,t:1527628025970};\\\", \\\"{x:910,y:789,t:1527628025999};\\\", \\\"{x:910,y:786,t:1527628026015};\\\", \\\"{x:910,y:785,t:1527628026024};\\\", \\\"{x:910,y:782,t:1527628026036};\\\", \\\"{x:910,y:780,t:1527628026053};\\\", \\\"{x:910,y:779,t:1527628026080};\\\", \\\"{x:911,y:779,t:1527628026160};\\\", \\\"{x:911,y:777,t:1527628026170};\\\", \\\"{x:911,y:776,t:1527628026187};\\\", \\\"{x:912,y:776,t:1527628026204};\\\", \\\"{x:913,y:774,t:1527628026219};\\\", \\\"{x:914,y:772,t:1527628026237};\\\", \\\"{x:915,y:770,t:1527628026254};\\\", \\\"{x:915,y:767,t:1527628026270};\\\", \\\"{x:916,y:764,t:1527628026287};\\\", \\\"{x:917,y:762,t:1527628026304};\\\", \\\"{x:917,y:760,t:1527628026320};\\\", \\\"{x:917,y:759,t:1527628026392};\\\", \\\"{x:917,y:758,t:1527628026404};\\\", \\\"{x:917,y:757,t:1527628026419};\\\", \\\"{x:918,y:756,t:1527628026437};\\\", \\\"{x:918,y:754,t:1527628026544};\\\", \\\"{x:918,y:753,t:1527628026559};\\\", \\\"{x:920,y:755,t:1527628026776};\\\", \\\"{x:941,y:764,t:1527628026787};\\\", \\\"{x:971,y:790,t:1527628026804};\\\", \\\"{x:999,y:807,t:1527628026822};\\\", \\\"{x:1023,y:819,t:1527628026837};\\\", \\\"{x:1049,y:830,t:1527628026854};\\\", \\\"{x:1076,y:848,t:1527628026871};\\\", \\\"{x:1099,y:859,t:1527628026887};\\\", \\\"{x:1117,y:874,t:1527628026904};\\\", \\\"{x:1129,y:883,t:1527628026921};\\\", \\\"{x:1143,y:893,t:1527628026938};\\\", \\\"{x:1155,y:907,t:1527628026954};\\\", \\\"{x:1161,y:913,t:1527628026971};\\\", \\\"{x:1168,y:916,t:1527628026988};\\\", \\\"{x:1173,y:921,t:1527628027004};\\\", \\\"{x:1182,y:929,t:1527628027021};\\\", \\\"{x:1189,y:937,t:1527628027038};\\\", \\\"{x:1195,y:945,t:1527628027054};\\\", \\\"{x:1211,y:957,t:1527628027071};\\\", \\\"{x:1221,y:962,t:1527628027088};\\\", \\\"{x:1229,y:966,t:1527628027104};\\\", \\\"{x:1235,y:971,t:1527628027121};\\\", \\\"{x:1242,y:972,t:1527628027138};\\\", \\\"{x:1249,y:972,t:1527628027153};\\\", \\\"{x:1254,y:973,t:1527628027171};\\\", \\\"{x:1261,y:973,t:1527628027188};\\\", \\\"{x:1262,y:973,t:1527628027204};\\\", \\\"{x:1264,y:973,t:1527628027220};\\\", \\\"{x:1267,y:973,t:1527628027237};\\\", \\\"{x:1267,y:972,t:1527628027270};\\\", \\\"{x:1267,y:970,t:1527628027544};\\\", \\\"{x:1267,y:967,t:1527628027555};\\\", \\\"{x:1266,y:965,t:1527628027571};\\\", \\\"{x:1265,y:960,t:1527628027588};\\\", \\\"{x:1264,y:948,t:1527628027605};\\\", \\\"{x:1261,y:942,t:1527628027622};\\\", \\\"{x:1253,y:933,t:1527628027638};\\\", \\\"{x:1250,y:923,t:1527628027655};\\\", \\\"{x:1246,y:922,t:1527628027671};\\\", \\\"{x:1243,y:919,t:1527628027688};\\\", \\\"{x:1243,y:914,t:1527628027706};\\\", \\\"{x:1241,y:908,t:1527628027722};\\\", \\\"{x:1240,y:904,t:1527628027738};\\\", \\\"{x:1239,y:902,t:1527628027754};\\\", \\\"{x:1239,y:901,t:1527628027772};\\\", \\\"{x:1238,y:901,t:1527628027787};\\\", \\\"{x:1238,y:898,t:1527628027804};\\\", \\\"{x:1237,y:897,t:1527628027821};\\\", \\\"{x:1237,y:895,t:1527628027837};\\\", \\\"{x:1237,y:889,t:1527628027855};\\\", \\\"{x:1239,y:884,t:1527628027871};\\\", \\\"{x:1243,y:881,t:1527628027887};\\\", \\\"{x:1245,y:875,t:1527628027905};\\\", \\\"{x:1249,y:866,t:1527628027922};\\\", \\\"{x:1255,y:858,t:1527628027938};\\\", \\\"{x:1259,y:852,t:1527628027954};\\\", \\\"{x:1264,y:841,t:1527628027972};\\\", \\\"{x:1265,y:831,t:1527628027989};\\\", \\\"{x:1270,y:817,t:1527628028004};\\\", \\\"{x:1272,y:808,t:1527628028022};\\\", \\\"{x:1272,y:793,t:1527628028039};\\\", \\\"{x:1272,y:777,t:1527628028055};\\\", \\\"{x:1272,y:759,t:1527628028072};\\\", \\\"{x:1272,y:746,t:1527628028090};\\\", \\\"{x:1270,y:731,t:1527628028105};\\\", \\\"{x:1266,y:711,t:1527628028122};\\\", \\\"{x:1265,y:700,t:1527628028139};\\\", \\\"{x:1265,y:686,t:1527628028155};\\\", \\\"{x:1265,y:679,t:1527628028172};\\\", \\\"{x:1265,y:674,t:1527628028189};\\\", \\\"{x:1265,y:668,t:1527628028205};\\\", \\\"{x:1265,y:663,t:1527628028222};\\\", \\\"{x:1268,y:657,t:1527628028240};\\\", \\\"{x:1270,y:650,t:1527628028255};\\\", \\\"{x:1272,y:645,t:1527628028272};\\\", \\\"{x:1274,y:639,t:1527628028290};\\\", \\\"{x:1275,y:636,t:1527628028305};\\\", \\\"{x:1276,y:633,t:1527628028322};\\\", \\\"{x:1276,y:631,t:1527628028340};\\\", \\\"{x:1277,y:626,t:1527628028357};\\\", \\\"{x:1277,y:621,t:1527628028372};\\\", \\\"{x:1278,y:614,t:1527628028389};\\\", \\\"{x:1279,y:612,t:1527628028407};\\\", \\\"{x:1279,y:611,t:1527628029136};\\\", \\\"{x:1277,y:611,t:1527628029144};\\\", \\\"{x:1275,y:612,t:1527628029156};\\\", \\\"{x:1274,y:623,t:1527628029173};\\\", \\\"{x:1274,y:639,t:1527628029190};\\\", \\\"{x:1274,y:657,t:1527628029206};\\\", \\\"{x:1279,y:681,t:1527628029223};\\\", \\\"{x:1284,y:697,t:1527628029239};\\\", \\\"{x:1288,y:710,t:1527628029256};\\\", \\\"{x:1290,y:722,t:1527628029273};\\\", \\\"{x:1298,y:736,t:1527628029290};\\\", \\\"{x:1302,y:748,t:1527628029307};\\\", \\\"{x:1307,y:759,t:1527628029323};\\\", \\\"{x:1311,y:764,t:1527628029340};\\\", \\\"{x:1312,y:769,t:1527628029356};\\\", \\\"{x:1314,y:774,t:1527628029373};\\\", \\\"{x:1314,y:776,t:1527628029391};\\\", \\\"{x:1314,y:779,t:1527628030128};\\\", \\\"{x:1314,y:781,t:1527628030141};\\\", \\\"{x:1314,y:786,t:1527628030157};\\\", \\\"{x:1314,y:792,t:1527628030173};\\\", \\\"{x:1313,y:809,t:1527628030191};\\\", \\\"{x:1310,y:831,t:1527628030206};\\\", \\\"{x:1310,y:847,t:1527628030223};\\\", \\\"{x:1313,y:863,t:1527628030240};\\\", \\\"{x:1317,y:880,t:1527628030256};\\\", \\\"{x:1325,y:891,t:1527628030274};\\\", \\\"{x:1331,y:908,t:1527628030293};\\\", \\\"{x:1342,y:923,t:1527628030306};\\\", \\\"{x:1353,y:941,t:1527628030323};\\\", \\\"{x:1359,y:954,t:1527628030340};\\\", \\\"{x:1363,y:960,t:1527628030356};\\\", \\\"{x:1363,y:962,t:1527628030373};\\\", \\\"{x:1363,y:966,t:1527628030479};\\\", \\\"{x:1361,y:968,t:1527628030491};\\\", \\\"{x:1359,y:969,t:1527628030508};\\\", \\\"{x:1356,y:971,t:1527628030524};\\\", \\\"{x:1355,y:971,t:1527628030541};\\\", \\\"{x:1355,y:972,t:1527628030558};\\\", \\\"{x:1354,y:974,t:1527628030633};\\\", \\\"{x:1352,y:978,t:1527628030641};\\\", \\\"{x:1352,y:983,t:1527628030658};\\\", \\\"{x:1352,y:986,t:1527628030675};\\\", \\\"{x:1351,y:989,t:1527628030691};\\\", \\\"{x:1351,y:990,t:1527628030719};\\\", \\\"{x:1351,y:991,t:1527628030728};\\\", \\\"{x:1351,y:992,t:1527628030767};\\\", \\\"{x:1351,y:994,t:1527628030775};\\\", \\\"{x:1351,y:996,t:1527628030791};\\\", \\\"{x:1351,y:1000,t:1527628030808};\\\", \\\"{x:1351,y:1002,t:1527628030825};\\\", \\\"{x:1353,y:1006,t:1527628030841};\\\", \\\"{x:1357,y:1012,t:1527628030858};\\\", \\\"{x:1361,y:1016,t:1527628030874};\\\", \\\"{x:1366,y:1018,t:1527628030891};\\\", \\\"{x:1369,y:1020,t:1527628030908};\\\", \\\"{x:1372,y:1021,t:1527628030925};\\\", \\\"{x:1375,y:1022,t:1527628030941};\\\", \\\"{x:1376,y:1023,t:1527628030959};\\\", \\\"{x:1371,y:1022,t:1527628031079};\\\", \\\"{x:1364,y:1020,t:1527628031091};\\\", \\\"{x:1344,y:1016,t:1527628031108};\\\", \\\"{x:1331,y:1014,t:1527628031125};\\\", \\\"{x:1317,y:1012,t:1527628031141};\\\", \\\"{x:1301,y:1007,t:1527628031157};\\\", \\\"{x:1283,y:1004,t:1527628031174};\\\", \\\"{x:1278,y:1000,t:1527628031192};\\\", \\\"{x:1277,y:990,t:1527628031208};\\\", \\\"{x:1277,y:981,t:1527628031225};\\\", \\\"{x:1285,y:970,t:1527628031241};\\\", \\\"{x:1292,y:962,t:1527628031258};\\\", \\\"{x:1297,y:962,t:1527628031274};\\\", \\\"{x:1308,y:961,t:1527628031291};\\\", \\\"{x:1314,y:959,t:1527628031308};\\\", \\\"{x:1315,y:958,t:1527628031324};\\\", \\\"{x:1316,y:958,t:1527628031341};\\\", \\\"{x:1317,y:958,t:1527628031357};\\\", \\\"{x:1318,y:958,t:1527628031407};\\\", \\\"{x:1319,y:958,t:1527628031439};\\\", \\\"{x:1319,y:961,t:1527628031447};\\\", \\\"{x:1317,y:964,t:1527628031458};\\\", \\\"{x:1316,y:966,t:1527628031474};\\\", \\\"{x:1316,y:967,t:1527628031491};\\\", \\\"{x:1314,y:968,t:1527628031518};\\\", \\\"{x:1313,y:969,t:1527628031543};\\\", \\\"{x:1312,y:970,t:1527628031558};\\\", \\\"{x:1309,y:972,t:1527628031574};\\\", \\\"{x:1307,y:974,t:1527628031591};\\\", \\\"{x:1305,y:974,t:1527628031609};\\\", \\\"{x:1301,y:976,t:1527628031625};\\\", \\\"{x:1300,y:977,t:1527628031642};\\\", \\\"{x:1299,y:977,t:1527628031659};\\\", \\\"{x:1298,y:978,t:1527628031855};\\\", \\\"{x:1298,y:979,t:1527628031992};\\\", \\\"{x:1298,y:980,t:1527628032031};\\\", \\\"{x:1298,y:981,t:1527628032088};\\\", \\\"{x:1298,y:982,t:1527628032135};\\\", \\\"{x:1301,y:986,t:1527628032143};\\\", \\\"{x:1322,y:997,t:1527628032159};\\\", \\\"{x:1405,y:1008,t:1527628032176};\\\", \\\"{x:1515,y:1016,t:1527628032191};\\\", \\\"{x:1616,y:1011,t:1527628032209};\\\", \\\"{x:1697,y:1011,t:1527628032226};\\\", \\\"{x:1733,y:1004,t:1527628032243};\\\", \\\"{x:1740,y:1004,t:1527628032259};\\\", \\\"{x:1740,y:1006,t:1527628032312};\\\", \\\"{x:1739,y:1007,t:1527628032326};\\\", \\\"{x:1723,y:1015,t:1527628032343};\\\", \\\"{x:1719,y:1021,t:1527628032359};\\\", \\\"{x:1707,y:1024,t:1527628032376};\\\", \\\"{x:1695,y:1029,t:1527628032394};\\\", \\\"{x:1684,y:1032,t:1527628032409};\\\", \\\"{x:1664,y:1035,t:1527628032426};\\\", \\\"{x:1658,y:1037,t:1527628032444};\\\", \\\"{x:1648,y:1038,t:1527628032459};\\\", \\\"{x:1641,y:1041,t:1527628032476};\\\", \\\"{x:1638,y:1041,t:1527628032493};\\\", \\\"{x:1637,y:1042,t:1527628032509};\\\", \\\"{x:1636,y:1042,t:1527628032526};\\\", \\\"{x:1634,y:1043,t:1527628032544};\\\", \\\"{x:1632,y:1043,t:1527628032615};\\\", \\\"{x:1631,y:1043,t:1527628032626};\\\", \\\"{x:1620,y:1043,t:1527628032644};\\\", \\\"{x:1601,y:1043,t:1527628032661};\\\", \\\"{x:1584,y:1043,t:1527628032676};\\\", \\\"{x:1566,y:1043,t:1527628032693};\\\", \\\"{x:1546,y:1043,t:1527628032711};\\\", \\\"{x:1531,y:1043,t:1527628032726};\\\", \\\"{x:1513,y:1043,t:1527628032744};\\\", \\\"{x:1496,y:1043,t:1527628032759};\\\", \\\"{x:1481,y:1039,t:1527628032776};\\\", \\\"{x:1464,y:1036,t:1527628032793};\\\", \\\"{x:1451,y:1036,t:1527628032810};\\\", \\\"{x:1440,y:1036,t:1527628032826};\\\", \\\"{x:1437,y:1036,t:1527628032843};\\\", \\\"{x:1435,y:1036,t:1527628032861};\\\", \\\"{x:1434,y:1036,t:1527628032876};\\\", \\\"{x:1432,y:1036,t:1527628033342};\\\", \\\"{x:1431,y:1036,t:1527628033359};\\\", \\\"{x:1429,y:1035,t:1527628033759};\\\", \\\"{x:1426,y:1033,t:1527628033766};\\\", \\\"{x:1425,y:1032,t:1527628033782};\\\", \\\"{x:1424,y:1032,t:1527628033794};\\\", \\\"{x:1424,y:1031,t:1527628033811};\\\", \\\"{x:1423,y:1031,t:1527628034071};\\\", \\\"{x:1414,y:1028,t:1527628034080};\\\", \\\"{x:1403,y:1025,t:1527628034095};\\\", \\\"{x:1361,y:1018,t:1527628034111};\\\", \\\"{x:1340,y:1014,t:1527628034127};\\\", \\\"{x:1320,y:1011,t:1527628034145};\\\", \\\"{x:1309,y:1010,t:1527628034162};\\\", \\\"{x:1300,y:1008,t:1527628034178};\\\", \\\"{x:1299,y:1008,t:1527628034194};\\\", \\\"{x:1298,y:1008,t:1527628034211};\\\", \\\"{x:1293,y:1008,t:1527628034574};\\\", \\\"{x:1284,y:1004,t:1527628034582};\\\", \\\"{x:1274,y:1000,t:1527628034595};\\\", \\\"{x:1250,y:991,t:1527628034611};\\\", \\\"{x:1220,y:983,t:1527628034628};\\\", \\\"{x:1203,y:976,t:1527628034645};\\\", \\\"{x:1187,y:968,t:1527628034662};\\\", \\\"{x:1176,y:966,t:1527628034678};\\\", \\\"{x:1172,y:963,t:1527628034695};\\\", \\\"{x:1170,y:961,t:1527628034727};\\\", \\\"{x:1170,y:960,t:1527628034734};\\\", \\\"{x:1169,y:958,t:1527628034745};\\\", \\\"{x:1166,y:952,t:1527628034762};\\\", \\\"{x:1166,y:951,t:1527628034778};\\\", \\\"{x:1165,y:950,t:1527628034795};\\\", \\\"{x:1165,y:949,t:1527628034847};\\\", \\\"{x:1165,y:948,t:1527628034879};\\\", \\\"{x:1165,y:947,t:1527628034895};\\\", \\\"{x:1165,y:945,t:1527628034912};\\\", \\\"{x:1165,y:943,t:1527628034929};\\\", \\\"{x:1165,y:941,t:1527628034945};\\\", \\\"{x:1165,y:940,t:1527628034962};\\\", \\\"{x:1165,y:937,t:1527628034978};\\\", \\\"{x:1166,y:932,t:1527628034996};\\\", \\\"{x:1166,y:925,t:1527628035012};\\\", \\\"{x:1167,y:920,t:1527628035028};\\\", \\\"{x:1168,y:911,t:1527628035045};\\\", \\\"{x:1171,y:902,t:1527628035062};\\\", \\\"{x:1172,y:890,t:1527628035079};\\\", \\\"{x:1172,y:885,t:1527628035095};\\\", \\\"{x:1172,y:882,t:1527628035112};\\\", \\\"{x:1172,y:878,t:1527628035129};\\\", \\\"{x:1172,y:876,t:1527628035146};\\\", \\\"{x:1171,y:876,t:1527628035816};\\\", \\\"{x:1170,y:876,t:1527628035832};\\\", \\\"{x:1169,y:876,t:1527628035847};\\\", \\\"{x:1167,y:876,t:1527628035863};\\\", \\\"{x:1166,y:876,t:1527628035879};\\\", \\\"{x:1164,y:876,t:1527628035896};\\\", \\\"{x:1158,y:876,t:1527628035913};\\\", \\\"{x:1144,y:876,t:1527628035929};\\\", \\\"{x:1132,y:876,t:1527628035945};\\\", \\\"{x:1113,y:876,t:1527628035963};\\\", \\\"{x:1096,y:873,t:1527628035979};\\\", \\\"{x:1082,y:867,t:1527628035995};\\\", \\\"{x:1069,y:861,t:1527628036013};\\\", \\\"{x:1061,y:857,t:1527628036028};\\\", \\\"{x:1058,y:854,t:1527628036046};\\\", \\\"{x:1045,y:836,t:1527628036062};\\\", \\\"{x:1027,y:815,t:1527628036080};\\\", \\\"{x:1011,y:791,t:1527628036095};\\\", \\\"{x:999,y:771,t:1527628036113};\\\", \\\"{x:995,y:766,t:1527628036130};\\\", \\\"{x:993,y:762,t:1527628036145};\\\", \\\"{x:992,y:757,t:1527628036162};\\\", \\\"{x:992,y:751,t:1527628036180};\\\", \\\"{x:992,y:738,t:1527628036196};\\\", \\\"{x:992,y:729,t:1527628036213};\\\", \\\"{x:992,y:720,t:1527628036230};\\\", \\\"{x:990,y:706,t:1527628036246};\\\", \\\"{x:990,y:695,t:1527628036263};\\\", \\\"{x:993,y:688,t:1527628036281};\\\", \\\"{x:996,y:679,t:1527628036296};\\\", \\\"{x:1000,y:668,t:1527628036314};\\\", \\\"{x:1003,y:663,t:1527628036330};\\\", \\\"{x:1009,y:655,t:1527628036347};\\\", \\\"{x:1011,y:651,t:1527628036363};\\\", \\\"{x:1013,y:648,t:1527628036380};\\\", \\\"{x:1015,y:641,t:1527628036396};\\\", \\\"{x:1016,y:635,t:1527628036413};\\\", \\\"{x:1017,y:633,t:1527628036430};\\\", \\\"{x:1018,y:624,t:1527628036447};\\\", \\\"{x:1019,y:619,t:1527628036463};\\\", \\\"{x:1021,y:615,t:1527628036481};\\\", \\\"{x:1021,y:613,t:1527628036497};\\\", \\\"{x:1021,y:610,t:1527628036513};\\\", \\\"{x:1022,y:606,t:1527628036530};\\\", \\\"{x:1022,y:602,t:1527628036547};\\\", \\\"{x:1022,y:598,t:1527628036563};\\\", \\\"{x:1022,y:595,t:1527628036580};\\\", \\\"{x:1022,y:592,t:1527628036597};\\\", \\\"{x:1022,y:588,t:1527628036613};\\\", \\\"{x:1022,y:583,t:1527628036630};\\\", \\\"{x:1022,y:571,t:1527628036647};\\\", \\\"{x:1022,y:568,t:1527628036664};\\\", \\\"{x:1022,y:565,t:1527628036681};\\\", \\\"{x:1024,y:563,t:1527628036727};\\\", \\\"{x:1026,y:562,t:1527628036736};\\\", \\\"{x:1027,y:561,t:1527628036748};\\\", \\\"{x:1032,y:559,t:1527628036764};\\\", \\\"{x:1035,y:558,t:1527628036781};\\\", \\\"{x:1058,y:563,t:1527628036797};\\\", \\\"{x:1095,y:590,t:1527628036815};\\\", \\\"{x:1135,y:617,t:1527628036830};\\\", \\\"{x:1172,y:640,t:1527628036847};\\\", \\\"{x:1207,y:660,t:1527628036863};\\\", \\\"{x:1229,y:680,t:1527628036880};\\\", \\\"{x:1247,y:695,t:1527628036898};\\\", \\\"{x:1264,y:720,t:1527628036914};\\\", \\\"{x:1275,y:738,t:1527628036931};\\\", \\\"{x:1285,y:758,t:1527628036947};\\\", \\\"{x:1293,y:774,t:1527628036965};\\\", \\\"{x:1299,y:790,t:1527628036980};\\\", \\\"{x:1306,y:805,t:1527628036998};\\\", \\\"{x:1309,y:816,t:1527628037014};\\\", \\\"{x:1311,y:824,t:1527628037030};\\\", \\\"{x:1318,y:839,t:1527628037047};\\\", \\\"{x:1318,y:846,t:1527628037065};\\\", \\\"{x:1320,y:849,t:1527628037081};\\\", \\\"{x:1320,y:856,t:1527628037098};\\\", \\\"{x:1320,y:859,t:1527628037114};\\\", \\\"{x:1320,y:863,t:1527628037131};\\\", \\\"{x:1320,y:866,t:1527628037148};\\\", \\\"{x:1320,y:867,t:1527628037164};\\\", \\\"{x:1320,y:869,t:1527628037180};\\\", \\\"{x:1320,y:870,t:1527628037198};\\\", \\\"{x:1320,y:872,t:1527628037214};\\\", \\\"{x:1320,y:873,t:1527628037231};\\\", \\\"{x:1320,y:874,t:1527628037248};\\\", \\\"{x:1317,y:870,t:1527628037743};\\\", \\\"{x:1316,y:870,t:1527628037751};\\\", \\\"{x:1315,y:868,t:1527628037765};\\\", \\\"{x:1313,y:866,t:1527628037781};\\\", \\\"{x:1312,y:864,t:1527628037799};\\\", \\\"{x:1311,y:864,t:1527628037814};\\\", \\\"{x:1311,y:863,t:1527628037831};\\\", \\\"{x:1311,y:862,t:1527628037848};\\\", \\\"{x:1310,y:861,t:1527628037865};\\\", \\\"{x:1310,y:858,t:1527628037882};\\\", \\\"{x:1308,y:857,t:1527628037898};\\\", \\\"{x:1307,y:856,t:1527628037916};\\\", \\\"{x:1306,y:855,t:1527628038032};\\\", \\\"{x:1306,y:854,t:1527628038049};\\\", \\\"{x:1305,y:852,t:1527628038066};\\\", \\\"{x:1304,y:851,t:1527628038081};\\\", \\\"{x:1303,y:848,t:1527628038099};\\\", \\\"{x:1302,y:848,t:1527628038115};\\\", \\\"{x:1301,y:846,t:1527628038132};\\\", \\\"{x:1300,y:845,t:1527628038148};\\\", \\\"{x:1299,y:843,t:1527628038175};\\\", \\\"{x:1298,y:842,t:1527628038191};\\\", \\\"{x:1298,y:841,t:1527628038215};\\\", \\\"{x:1297,y:840,t:1527628038232};\\\", \\\"{x:1296,y:838,t:1527628038248};\\\", \\\"{x:1296,y:836,t:1527628038271};\\\", \\\"{x:1294,y:834,t:1527628038282};\\\", \\\"{x:1294,y:832,t:1527628038298};\\\", \\\"{x:1293,y:830,t:1527628038316};\\\", \\\"{x:1293,y:829,t:1527628038332};\\\", \\\"{x:1292,y:825,t:1527628038348};\\\", \\\"{x:1291,y:824,t:1527628038366};\\\", \\\"{x:1291,y:823,t:1527628038392};\\\", \\\"{x:1291,y:822,t:1527628038407};\\\", \\\"{x:1290,y:821,t:1527628038416};\\\", \\\"{x:1290,y:820,t:1527628038432};\\\", \\\"{x:1290,y:819,t:1527628038448};\\\", \\\"{x:1290,y:818,t:1527628038472};\\\", \\\"{x:1290,y:817,t:1527628038487};\\\", \\\"{x:1290,y:816,t:1527628038511};\\\", \\\"{x:1290,y:814,t:1527628038536};\\\", \\\"{x:1291,y:813,t:1527628038552};\\\", \\\"{x:1292,y:812,t:1527628038566};\\\", \\\"{x:1294,y:811,t:1527628038583};\\\", \\\"{x:1298,y:808,t:1527628038599};\\\", \\\"{x:1301,y:806,t:1527628038615};\\\", \\\"{x:1304,y:805,t:1527628038632};\\\", \\\"{x:1307,y:804,t:1527628038649};\\\", \\\"{x:1309,y:804,t:1527628038666};\\\", \\\"{x:1309,y:803,t:1527628038695};\\\", \\\"{x:1311,y:804,t:1527628039008};\\\", \\\"{x:1311,y:805,t:1527628039023};\\\", \\\"{x:1312,y:806,t:1527628039033};\\\", \\\"{x:1312,y:808,t:1527628039049};\\\", \\\"{x:1314,y:810,t:1527628039087};\\\", \\\"{x:1315,y:811,t:1527628039119};\\\", \\\"{x:1315,y:812,t:1527628039143};\\\", \\\"{x:1315,y:813,t:1527628039151};\\\", \\\"{x:1316,y:815,t:1527628039166};\\\", \\\"{x:1317,y:815,t:1527628039182};\\\", \\\"{x:1317,y:816,t:1527628039200};\\\", \\\"{x:1317,y:817,t:1527628039223};\\\", \\\"{x:1317,y:818,t:1527628039232};\\\", \\\"{x:1317,y:819,t:1527628039271};\\\", \\\"{x:1317,y:821,t:1527628039283};\\\", \\\"{x:1316,y:822,t:1527628039311};\\\", \\\"{x:1314,y:823,t:1527628039328};\\\", \\\"{x:1313,y:824,t:1527628039343};\\\", \\\"{x:1312,y:826,t:1527628039351};\\\", \\\"{x:1311,y:829,t:1527628039367};\\\", \\\"{x:1308,y:833,t:1527628039383};\\\", \\\"{x:1306,y:835,t:1527628039399};\\\", \\\"{x:1303,y:837,t:1527628039417};\\\", \\\"{x:1302,y:837,t:1527628039433};\\\", \\\"{x:1302,y:838,t:1527628039450};\\\", \\\"{x:1300,y:839,t:1527628039466};\\\", \\\"{x:1300,y:840,t:1527628039483};\\\", \\\"{x:1299,y:840,t:1527628039499};\\\", \\\"{x:1298,y:840,t:1527628039672};\\\", \\\"{x:1297,y:840,t:1527628039684};\\\", \\\"{x:1294,y:840,t:1527628039701};\\\", \\\"{x:1291,y:840,t:1527628039716};\\\", \\\"{x:1290,y:840,t:1527628039735};\\\", \\\"{x:1289,y:840,t:1527628039752};\\\", \\\"{x:1289,y:839,t:1527628039766};\\\", \\\"{x:1287,y:839,t:1527628039783};\\\", \\\"{x:1286,y:838,t:1527628039801};\\\", \\\"{x:1285,y:838,t:1527628039816};\\\", \\\"{x:1284,y:838,t:1527628039834};\\\", \\\"{x:1284,y:837,t:1527628040504};\\\", \\\"{x:1284,y:836,t:1527628040517};\\\", \\\"{x:1280,y:835,t:1527628040536};\\\", \\\"{x:1280,y:834,t:1527628040840};\\\", \\\"{x:1280,y:832,t:1527628041671};\\\", \\\"{x:1280,y:831,t:1527628041695};\\\", \\\"{x:1280,y:830,t:1527628041752};\\\", \\\"{x:1280,y:829,t:1527628041839};\\\", \\\"{x:1279,y:827,t:1527628041943};\\\", \\\"{x:1279,y:826,t:1527628042015};\\\", \\\"{x:1278,y:826,t:1527628042143};\\\", \\\"{x:1277,y:825,t:1527628042160};\\\", \\\"{x:1275,y:823,t:1527628042424};\\\", \\\"{x:1264,y:821,t:1527628042436};\\\", \\\"{x:1215,y:813,t:1527628042453};\\\", \\\"{x:1112,y:799,t:1527628042470};\\\", \\\"{x:987,y:780,t:1527628042486};\\\", \\\"{x:839,y:768,t:1527628042503};\\\", \\\"{x:638,y:757,t:1527628042519};\\\", \\\"{x:533,y:757,t:1527628042537};\\\", \\\"{x:446,y:758,t:1527628042553};\\\", \\\"{x:412,y:758,t:1527628042569};\\\", \\\"{x:394,y:758,t:1527628042586};\\\", \\\"{x:390,y:758,t:1527628042602};\\\", \\\"{x:401,y:757,t:1527628042792};\\\", \\\"{x:406,y:753,t:1527628042803};\\\", \\\"{x:426,y:747,t:1527628042820};\\\", \\\"{x:450,y:738,t:1527628042836};\\\", \\\"{x:462,y:733,t:1527628042855};\\\", \\\"{x:469,y:732,t:1527628042869};\\\", \\\"{x:472,y:731,t:1527628042886};\\\", \\\"{x:474,y:730,t:1527628042900};\\\", \\\"{x:476,y:730,t:1527628042916};\\\", \\\"{x:476,y:729,t:1527628043271};\\\", \\\"{x:474,y:730,t:1527628043283};\\\", \\\"{x:474,y:740,t:1527628043300};\\\", \\\"{x:474,y:746,t:1527628043316};\\\", \\\"{x:474,y:757,t:1527628043332};\\\", \\\"{x:474,y:768,t:1527628043350};\\\", \\\"{x:474,y:780,t:1527628043366};\\\", \\\"{x:476,y:785,t:1527628043383};\\\", \\\"{x:476,y:788,t:1527628043407};\\\", \\\"{x:478,y:792,t:1527628043417};\\\", \\\"{x:481,y:802,t:1527628043433};\\\", \\\"{x:486,y:817,t:1527628043450};\\\", \\\"{x:490,y:823,t:1527628043467};\\\", \\\"{x:491,y:831,t:1527628043483};\\\", \\\"{x:492,y:837,t:1527628043500};\\\", \\\"{x:493,y:843,t:1527628043517};\\\", \\\"{x:494,y:848,t:1527628043533};\\\", \\\"{x:495,y:851,t:1527628043550};\\\", \\\"{x:496,y:853,t:1527628043566};\\\", \\\"{x:497,y:854,t:1527628044179};\\\" ] }, { \\\"rt\\\": 74230, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 368727, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -E -E -D -04 PM-Z -Z -F -U -U -F -H -H -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:809,t:1527628044679};\\\", \\\"{x:494,y:775,t:1527628044686};\\\", \\\"{x:488,y:711,t:1527628044703};\\\", \\\"{x:465,y:631,t:1527628044718};\\\", \\\"{x:438,y:560,t:1527628044734};\\\", \\\"{x:421,y:524,t:1527628044751};\\\", \\\"{x:338,y:322,t:1527628044875};\\\", \\\"{x:332,y:315,t:1527628044885};\\\", \\\"{x:330,y:310,t:1527628044901};\\\", \\\"{x:329,y:308,t:1527628044918};\\\", \\\"{x:328,y:308,t:1527628044942};\\\", \\\"{x:328,y:307,t:1527628045999};\\\", \\\"{x:328,y:314,t:1527628046015};\\\", \\\"{x:337,y:324,t:1527628046023};\\\", \\\"{x:346,y:335,t:1527628046036};\\\", \\\"{x:358,y:357,t:1527628046052};\\\", \\\"{x:369,y:368,t:1527628046069};\\\", \\\"{x:374,y:381,t:1527628046085};\\\", \\\"{x:383,y:390,t:1527628046103};\\\", \\\"{x:386,y:395,t:1527628046119};\\\", \\\"{x:388,y:400,t:1527628046135};\\\", \\\"{x:388,y:411,t:1527628046153};\\\", \\\"{x:390,y:423,t:1527628046169};\\\", \\\"{x:392,y:433,t:1527628046185};\\\", \\\"{x:392,y:439,t:1527628046202};\\\", \\\"{x:392,y:441,t:1527628046219};\\\", \\\"{x:392,y:442,t:1527628046245};\\\", \\\"{x:392,y:443,t:1527628046254};\\\", \\\"{x:390,y:448,t:1527628046269};\\\", \\\"{x:389,y:450,t:1527628046286};\\\", \\\"{x:387,y:453,t:1527628046302};\\\", \\\"{x:384,y:459,t:1527628046319};\\\", \\\"{x:383,y:459,t:1527628046336};\\\", \\\"{x:382,y:460,t:1527628046399};\\\", \\\"{x:382,y:461,t:1527628046590};\\\", \\\"{x:387,y:463,t:1527628046602};\\\", \\\"{x:393,y:466,t:1527628046619};\\\", \\\"{x:399,y:467,t:1527628046636};\\\", \\\"{x:400,y:468,t:1527628046653};\\\", \\\"{x:402,y:468,t:1527628046807};\\\", \\\"{x:404,y:469,t:1527628046819};\\\", \\\"{x:411,y:473,t:1527628046836};\\\", \\\"{x:422,y:476,t:1527628046853};\\\", \\\"{x:437,y:480,t:1527628046869};\\\", \\\"{x:458,y:485,t:1527628046886};\\\", \\\"{x:472,y:486,t:1527628046902};\\\", \\\"{x:480,y:487,t:1527628046919};\\\", \\\"{x:485,y:487,t:1527628046936};\\\", \\\"{x:486,y:487,t:1527628046954};\\\", \\\"{x:488,y:487,t:1527628047143};\\\", \\\"{x:494,y:486,t:1527628047153};\\\", \\\"{x:506,y:484,t:1527628047170};\\\", \\\"{x:525,y:480,t:1527628047186};\\\", \\\"{x:528,y:480,t:1527628047203};\\\", \\\"{x:531,y:480,t:1527628047221};\\\", \\\"{x:538,y:479,t:1527628047237};\\\", \\\"{x:539,y:478,t:1527628047311};\\\", \\\"{x:540,y:478,t:1527628047321};\\\", \\\"{x:543,y:475,t:1527628047336};\\\", \\\"{x:546,y:475,t:1527628047353};\\\", \\\"{x:547,y:475,t:1527628047370};\\\", \\\"{x:548,y:474,t:1527628047387};\\\", \\\"{x:550,y:473,t:1527628047402};\\\", \\\"{x:552,y:472,t:1527628047420};\\\", \\\"{x:555,y:472,t:1527628047436};\\\", \\\"{x:560,y:469,t:1527628047453};\\\", \\\"{x:569,y:467,t:1527628047470};\\\", \\\"{x:583,y:465,t:1527628047486};\\\", \\\"{x:592,y:465,t:1527628047503};\\\", \\\"{x:607,y:464,t:1527628047520};\\\", \\\"{x:629,y:464,t:1527628047537};\\\", \\\"{x:656,y:464,t:1527628047553};\\\", \\\"{x:690,y:466,t:1527628047570};\\\", \\\"{x:733,y:474,t:1527628047587};\\\", \\\"{x:756,y:477,t:1527628047603};\\\", \\\"{x:771,y:480,t:1527628047620};\\\", \\\"{x:796,y:486,t:1527628047637};\\\", \\\"{x:814,y:488,t:1527628047653};\\\", \\\"{x:839,y:492,t:1527628047671};\\\", \\\"{x:849,y:493,t:1527628047687};\\\", \\\"{x:854,y:497,t:1527628047703};\\\", \\\"{x:860,y:499,t:1527628047721};\\\", \\\"{x:873,y:501,t:1527628047737};\\\", \\\"{x:892,y:504,t:1527628047753};\\\", \\\"{x:918,y:512,t:1527628047772};\\\", \\\"{x:942,y:518,t:1527628047787};\\\", \\\"{x:965,y:523,t:1527628047805};\\\", \\\"{x:979,y:529,t:1527628047820};\\\", \\\"{x:1000,y:535,t:1527628047837};\\\", \\\"{x:1031,y:543,t:1527628047853};\\\", \\\"{x:1073,y:559,t:1527628047870};\\\", \\\"{x:1095,y:569,t:1527628047887};\\\", \\\"{x:1119,y:579,t:1527628047904};\\\", \\\"{x:1137,y:589,t:1527628047920};\\\", \\\"{x:1153,y:600,t:1527628047937};\\\", \\\"{x:1163,y:609,t:1527628047954};\\\", \\\"{x:1171,y:620,t:1527628047970};\\\", \\\"{x:1182,y:633,t:1527628047987};\\\", \\\"{x:1194,y:644,t:1527628048005};\\\", \\\"{x:1206,y:655,t:1527628048020};\\\", \\\"{x:1216,y:666,t:1527628048037};\\\", \\\"{x:1228,y:682,t:1527628048055};\\\", \\\"{x:1231,y:684,t:1527628048070};\\\", \\\"{x:1234,y:687,t:1527628048087};\\\", \\\"{x:1238,y:690,t:1527628048105};\\\", \\\"{x:1240,y:696,t:1527628048121};\\\", \\\"{x:1248,y:706,t:1527628048138};\\\", \\\"{x:1260,y:721,t:1527628048154};\\\", \\\"{x:1272,y:733,t:1527628048170};\\\", \\\"{x:1278,y:743,t:1527628048187};\\\", \\\"{x:1287,y:750,t:1527628048203};\\\", \\\"{x:1290,y:751,t:1527628048221};\\\", \\\"{x:1291,y:752,t:1527628048237};\\\", \\\"{x:1292,y:752,t:1527628048302};\\\", \\\"{x:1293,y:752,t:1527628048310};\\\", \\\"{x:1294,y:752,t:1527628048326};\\\", \\\"{x:1296,y:751,t:1527628049015};\\\", \\\"{x:1297,y:751,t:1527628049056};\\\", \\\"{x:1300,y:749,t:1527628049071};\\\", \\\"{x:1306,y:747,t:1527628049088};\\\", \\\"{x:1311,y:745,t:1527628049105};\\\", \\\"{x:1321,y:740,t:1527628049121};\\\", \\\"{x:1321,y:739,t:1527628049138};\\\", \\\"{x:1321,y:738,t:1527628049155};\\\", \\\"{x:1327,y:730,t:1527628049171};\\\", \\\"{x:1333,y:725,t:1527628049188};\\\", \\\"{x:1350,y:720,t:1527628049205};\\\", \\\"{x:1366,y:710,t:1527628049222};\\\", \\\"{x:1377,y:702,t:1527628049238};\\\", \\\"{x:1388,y:695,t:1527628049255};\\\", \\\"{x:1396,y:687,t:1527628049272};\\\", \\\"{x:1408,y:671,t:1527628049289};\\\", \\\"{x:1428,y:651,t:1527628049305};\\\", \\\"{x:1445,y:632,t:1527628049323};\\\", \\\"{x:1465,y:607,t:1527628049339};\\\", \\\"{x:1477,y:589,t:1527628049355};\\\", \\\"{x:1489,y:568,t:1527628049373};\\\", \\\"{x:1500,y:551,t:1527628049389};\\\", \\\"{x:1507,y:534,t:1527628049405};\\\", \\\"{x:1520,y:512,t:1527628049422};\\\", \\\"{x:1528,y:499,t:1527628049438};\\\", \\\"{x:1536,y:486,t:1527628049456};\\\", \\\"{x:1547,y:470,t:1527628049472};\\\", \\\"{x:1551,y:460,t:1527628049489};\\\", \\\"{x:1555,y:454,t:1527628049505};\\\", \\\"{x:1560,y:447,t:1527628049522};\\\", \\\"{x:1562,y:444,t:1527628049537};\\\", \\\"{x:1564,y:442,t:1527628049554};\\\", \\\"{x:1564,y:440,t:1527628049570};\\\", \\\"{x:1565,y:440,t:1527628049595};\\\", \\\"{x:1566,y:439,t:1527628049604};\\\", \\\"{x:1568,y:437,t:1527628049620};\\\", \\\"{x:1569,y:437,t:1527628049637};\\\", \\\"{x:1569,y:436,t:1527628049653};\\\", \\\"{x:1572,y:434,t:1527628049670};\\\", \\\"{x:1573,y:433,t:1527628049687};\\\", \\\"{x:1576,y:431,t:1527628049703};\\\", \\\"{x:1580,y:428,t:1527628049720};\\\", \\\"{x:1582,y:426,t:1527628049737};\\\", \\\"{x:1584,y:424,t:1527628049753};\\\", \\\"{x:1584,y:423,t:1527628049770};\\\", \\\"{x:1585,y:423,t:1527628049787};\\\", \\\"{x:1586,y:422,t:1527628049804};\\\", \\\"{x:1587,y:421,t:1527628049837};\\\", \\\"{x:1589,y:421,t:1527628049853};\\\", \\\"{x:1594,y:421,t:1527628049871};\\\", \\\"{x:1603,y:421,t:1527628049887};\\\", \\\"{x:1615,y:423,t:1527628049905};\\\", \\\"{x:1628,y:427,t:1527628049921};\\\", \\\"{x:1637,y:428,t:1527628049938};\\\", \\\"{x:1639,y:429,t:1527628049954};\\\", \\\"{x:1643,y:430,t:1527628049970};\\\", \\\"{x:1643,y:431,t:1527628050174};\\\", \\\"{x:1642,y:431,t:1527628050187};\\\", \\\"{x:1637,y:431,t:1527628050205};\\\", \\\"{x:1633,y:431,t:1527628050220};\\\", \\\"{x:1632,y:431,t:1527628050245};\\\", \\\"{x:1630,y:431,t:1527628050301};\\\", \\\"{x:1629,y:431,t:1527628050533};\\\", \\\"{x:1628,y:437,t:1527628050589};\\\", \\\"{x:1626,y:447,t:1527628050605};\\\", \\\"{x:1625,y:455,t:1527628050621};\\\", \\\"{x:1625,y:459,t:1527628050639};\\\", \\\"{x:1625,y:464,t:1527628050654};\\\", \\\"{x:1625,y:471,t:1527628050672};\\\", \\\"{x:1626,y:478,t:1527628050688};\\\", \\\"{x:1627,y:488,t:1527628050704};\\\", \\\"{x:1631,y:505,t:1527628050722};\\\", \\\"{x:1632,y:519,t:1527628050739};\\\", \\\"{x:1632,y:533,t:1527628050754};\\\", \\\"{x:1635,y:545,t:1527628050772};\\\", \\\"{x:1637,y:555,t:1527628050788};\\\", \\\"{x:1637,y:566,t:1527628050804};\\\", \\\"{x:1637,y:579,t:1527628050821};\\\", \\\"{x:1637,y:586,t:1527628050839};\\\", \\\"{x:1637,y:590,t:1527628050856};\\\", \\\"{x:1637,y:595,t:1527628050872};\\\", \\\"{x:1637,y:597,t:1527628050888};\\\", \\\"{x:1637,y:599,t:1527628050905};\\\", \\\"{x:1637,y:602,t:1527628050922};\\\", \\\"{x:1637,y:603,t:1527628050939};\\\", \\\"{x:1637,y:605,t:1527628050956};\\\", \\\"{x:1636,y:605,t:1527628051094};\\\", \\\"{x:1635,y:605,t:1527628051109};\\\", \\\"{x:1633,y:604,t:1527628051262};\\\", \\\"{x:1630,y:604,t:1527628051284};\\\", \\\"{x:1629,y:604,t:1527628051317};\\\", \\\"{x:1627,y:604,t:1527628051349};\\\", \\\"{x:1626,y:604,t:1527628051373};\\\", \\\"{x:1626,y:607,t:1527628051389};\\\", \\\"{x:1626,y:611,t:1527628051406};\\\", \\\"{x:1625,y:615,t:1527628051423};\\\", \\\"{x:1625,y:619,t:1527628051438};\\\", \\\"{x:1625,y:623,t:1527628051456};\\\", \\\"{x:1625,y:627,t:1527628051473};\\\", \\\"{x:1626,y:630,t:1527628051489};\\\", \\\"{x:1626,y:633,t:1527628051505};\\\", \\\"{x:1627,y:636,t:1527628051522};\\\", \\\"{x:1627,y:640,t:1527628051540};\\\", \\\"{x:1627,y:645,t:1527628051556};\\\", \\\"{x:1627,y:651,t:1527628051571};\\\", \\\"{x:1628,y:654,t:1527628051589};\\\", \\\"{x:1628,y:662,t:1527628051605};\\\", \\\"{x:1628,y:670,t:1527628051623};\\\", \\\"{x:1628,y:683,t:1527628051639};\\\", \\\"{x:1625,y:690,t:1527628051655};\\\", \\\"{x:1624,y:692,t:1527628051672};\\\", \\\"{x:1624,y:696,t:1527628051689};\\\", \\\"{x:1622,y:701,t:1527628051706};\\\", \\\"{x:1622,y:704,t:1527628051722};\\\", \\\"{x:1622,y:706,t:1527628051739};\\\", \\\"{x:1622,y:709,t:1527628051756};\\\", \\\"{x:1622,y:711,t:1527628051773};\\\", \\\"{x:1622,y:713,t:1527628051790};\\\", \\\"{x:1622,y:715,t:1527628051805};\\\", \\\"{x:1622,y:717,t:1527628051823};\\\", \\\"{x:1621,y:721,t:1527628051840};\\\", \\\"{x:1620,y:723,t:1527628051857};\\\", \\\"{x:1620,y:725,t:1527628051873};\\\", \\\"{x:1620,y:726,t:1527628051893};\\\", \\\"{x:1619,y:727,t:1527628051907};\\\", \\\"{x:1618,y:730,t:1527628051923};\\\", \\\"{x:1618,y:732,t:1527628051939};\\\", \\\"{x:1617,y:735,t:1527628051957};\\\", \\\"{x:1617,y:737,t:1527628051972};\\\", \\\"{x:1617,y:739,t:1527628051990};\\\", \\\"{x:1616,y:742,t:1527628052007};\\\", \\\"{x:1616,y:743,t:1527628052029};\\\", \\\"{x:1616,y:746,t:1527628052040};\\\", \\\"{x:1615,y:747,t:1527628052056};\\\", \\\"{x:1615,y:749,t:1527628052072};\\\", \\\"{x:1615,y:751,t:1527628052089};\\\", \\\"{x:1615,y:755,t:1527628052106};\\\", \\\"{x:1614,y:758,t:1527628052124};\\\", \\\"{x:1614,y:759,t:1527628052140};\\\", \\\"{x:1614,y:763,t:1527628052157};\\\", \\\"{x:1613,y:763,t:1527628052172};\\\", \\\"{x:1612,y:765,t:1527628052189};\\\", \\\"{x:1611,y:767,t:1527628052207};\\\", \\\"{x:1611,y:769,t:1527628052224};\\\", \\\"{x:1611,y:775,t:1527628052239};\\\", \\\"{x:1611,y:780,t:1527628052257};\\\", \\\"{x:1611,y:788,t:1527628052274};\\\", \\\"{x:1611,y:797,t:1527628052290};\\\", \\\"{x:1611,y:802,t:1527628052307};\\\", \\\"{x:1611,y:805,t:1527628052324};\\\", \\\"{x:1611,y:809,t:1527628052340};\\\", \\\"{x:1611,y:816,t:1527628052357};\\\", \\\"{x:1610,y:823,t:1527628052374};\\\", \\\"{x:1610,y:831,t:1527628052390};\\\", \\\"{x:1610,y:836,t:1527628052406};\\\", \\\"{x:1610,y:843,t:1527628052424};\\\", \\\"{x:1609,y:850,t:1527628052440};\\\", \\\"{x:1609,y:855,t:1527628052457};\\\", \\\"{x:1608,y:859,t:1527628052474};\\\", \\\"{x:1608,y:861,t:1527628052490};\\\", \\\"{x:1609,y:865,t:1527628052507};\\\", \\\"{x:1610,y:866,t:1527628052524};\\\", \\\"{x:1612,y:871,t:1527628052541};\\\", \\\"{x:1612,y:872,t:1527628052556};\\\", \\\"{x:1615,y:877,t:1527628052574};\\\", \\\"{x:1616,y:882,t:1527628052590};\\\", \\\"{x:1617,y:890,t:1527628052607};\\\", \\\"{x:1619,y:899,t:1527628052623};\\\", \\\"{x:1621,y:901,t:1527628052640};\\\", \\\"{x:1622,y:904,t:1527628052656};\\\", \\\"{x:1622,y:907,t:1527628052673};\\\", \\\"{x:1623,y:909,t:1527628052691};\\\", \\\"{x:1623,y:910,t:1527628052706};\\\", \\\"{x:1623,y:912,t:1527628052724};\\\", \\\"{x:1624,y:915,t:1527628052740};\\\", \\\"{x:1624,y:917,t:1527628052756};\\\", \\\"{x:1624,y:918,t:1527628052796};\\\", \\\"{x:1624,y:919,t:1527628052812};\\\", \\\"{x:1624,y:920,t:1527628052837};\\\", \\\"{x:1624,y:922,t:1527628052853};\\\", \\\"{x:1624,y:923,t:1527628052869};\\\", \\\"{x:1624,y:925,t:1527628052877};\\\", \\\"{x:1626,y:927,t:1527628052893};\\\", \\\"{x:1626,y:928,t:1527628052907};\\\", \\\"{x:1626,y:931,t:1527628052924};\\\", \\\"{x:1626,y:935,t:1527628052940};\\\", \\\"{x:1626,y:940,t:1527628052957};\\\", \\\"{x:1626,y:944,t:1527628052974};\\\", \\\"{x:1626,y:946,t:1527628052991};\\\", \\\"{x:1626,y:947,t:1527628053008};\\\", \\\"{x:1626,y:950,t:1527628053023};\\\", \\\"{x:1626,y:952,t:1527628053041};\\\", \\\"{x:1626,y:955,t:1527628053061};\\\", \\\"{x:1626,y:956,t:1527628053073};\\\", \\\"{x:1626,y:957,t:1527628053090};\\\", \\\"{x:1626,y:959,t:1527628053133};\\\", \\\"{x:1626,y:960,t:1527628053724};\\\", \\\"{x:1625,y:960,t:1527628053741};\\\", \\\"{x:1624,y:960,t:1527628053758};\\\", \\\"{x:1623,y:959,t:1527628054029};\\\", \\\"{x:1623,y:957,t:1527628054042};\\\", \\\"{x:1625,y:949,t:1527628054059};\\\", \\\"{x:1626,y:942,t:1527628054075};\\\", \\\"{x:1627,y:936,t:1527628054092};\\\", \\\"{x:1627,y:923,t:1527628054108};\\\", \\\"{x:1627,y:910,t:1527628054125};\\\", \\\"{x:1627,y:901,t:1527628054141};\\\", \\\"{x:1627,y:897,t:1527628054159};\\\", \\\"{x:1627,y:892,t:1527628054176};\\\", \\\"{x:1627,y:886,t:1527628054191};\\\", \\\"{x:1627,y:881,t:1527628054209};\\\", \\\"{x:1626,y:876,t:1527628054225};\\\", \\\"{x:1623,y:864,t:1527628054241};\\\", \\\"{x:1621,y:855,t:1527628054259};\\\", \\\"{x:1619,y:851,t:1527628054276};\\\", \\\"{x:1618,y:846,t:1527628054291};\\\", \\\"{x:1617,y:833,t:1527628054307};\\\", \\\"{x:1616,y:822,t:1527628054325};\\\", \\\"{x:1614,y:809,t:1527628054341};\\\", \\\"{x:1611,y:797,t:1527628054359};\\\", \\\"{x:1610,y:789,t:1527628054375};\\\", \\\"{x:1610,y:780,t:1527628054391};\\\", \\\"{x:1609,y:767,t:1527628054408};\\\", \\\"{x:1607,y:742,t:1527628054426};\\\", \\\"{x:1604,y:718,t:1527628054442};\\\", \\\"{x:1604,y:698,t:1527628054459};\\\", \\\"{x:1604,y:686,t:1527628054475};\\\", \\\"{x:1604,y:670,t:1527628054492};\\\", \\\"{x:1604,y:647,t:1527628054508};\\\", \\\"{x:1604,y:640,t:1527628054526};\\\", \\\"{x:1604,y:631,t:1527628054543};\\\", \\\"{x:1604,y:623,t:1527628054558};\\\", \\\"{x:1604,y:611,t:1527628054576};\\\", \\\"{x:1603,y:605,t:1527628054593};\\\", \\\"{x:1602,y:598,t:1527628054609};\\\", \\\"{x:1602,y:596,t:1527628054626};\\\", \\\"{x:1602,y:593,t:1527628054643};\\\", \\\"{x:1602,y:590,t:1527628054658};\\\", \\\"{x:1602,y:584,t:1527628054676};\\\", \\\"{x:1602,y:576,t:1527628054692};\\\", \\\"{x:1602,y:574,t:1527628054709};\\\", \\\"{x:1602,y:572,t:1527628054726};\\\", \\\"{x:1602,y:571,t:1527628054813};\\\", \\\"{x:1602,y:570,t:1527628054861};\\\", \\\"{x:1602,y:568,t:1527628055005};\\\", \\\"{x:1603,y:568,t:1527628055029};\\\", \\\"{x:1604,y:567,t:1527628055043};\\\", \\\"{x:1605,y:567,t:1527628055068};\\\", \\\"{x:1606,y:567,t:1527628055093};\\\", \\\"{x:1607,y:567,t:1527628055349};\\\", \\\"{x:1608,y:566,t:1527628055388};\\\", \\\"{x:1609,y:566,t:1527628055837};\\\", \\\"{x:1612,y:564,t:1527628058960};\\\", \\\"{x:1618,y:562,t:1527628058979};\\\", \\\"{x:1625,y:560,t:1527628058997};\\\", \\\"{x:1627,y:560,t:1527628059013};\\\", \\\"{x:1625,y:560,t:1527628059333};\\\", \\\"{x:1622,y:560,t:1527628059349};\\\", \\\"{x:1621,y:560,t:1527628059373};\\\", \\\"{x:1620,y:560,t:1527628059381};\\\", \\\"{x:1620,y:561,t:1527628059403};\\\", \\\"{x:1619,y:561,t:1527628059468};\\\", \\\"{x:1618,y:561,t:1527628059516};\\\", \\\"{x:1617,y:561,t:1527628059636};\\\", \\\"{x:1616,y:561,t:1527628076956};\\\", \\\"{x:1567,y:561,t:1527628076966};\\\", \\\"{x:1403,y:562,t:1527628076982};\\\", \\\"{x:1232,y:578,t:1527628076998};\\\", \\\"{x:1041,y:570,t:1527628077015};\\\", \\\"{x:867,y:552,t:1527628077033};\\\", \\\"{x:740,y:553,t:1527628077049};\\\", \\\"{x:654,y:553,t:1527628077066};\\\", \\\"{x:619,y:553,t:1527628077075};\\\", \\\"{x:598,y:554,t:1527628077092};\\\", \\\"{x:584,y:556,t:1527628077109};\\\", \\\"{x:580,y:557,t:1527628077125};\\\", \\\"{x:579,y:558,t:1527628077142};\\\", \\\"{x:571,y:560,t:1527628077171};\\\", \\\"{x:558,y:562,t:1527628077179};\\\", \\\"{x:546,y:567,t:1527628077192};\\\", \\\"{x:531,y:574,t:1527628077209};\\\", \\\"{x:502,y:591,t:1527628077226};\\\", \\\"{x:480,y:604,t:1527628077243};\\\", \\\"{x:421,y:616,t:1527628077259};\\\", \\\"{x:401,y:616,t:1527628077275};\\\", \\\"{x:310,y:615,t:1527628077291};\\\", \\\"{x:287,y:614,t:1527628077309};\\\", \\\"{x:283,y:614,t:1527628077325};\\\", \\\"{x:281,y:613,t:1527628077396};\\\", \\\"{x:278,y:612,t:1527628077410};\\\", \\\"{x:269,y:610,t:1527628077427};\\\", \\\"{x:255,y:608,t:1527628077442};\\\", \\\"{x:231,y:608,t:1527628077459};\\\", \\\"{x:213,y:608,t:1527628077475};\\\", \\\"{x:200,y:610,t:1527628077492};\\\", \\\"{x:188,y:617,t:1527628077509};\\\", \\\"{x:183,y:620,t:1527628077527};\\\", \\\"{x:182,y:621,t:1527628077541};\\\", \\\"{x:180,y:621,t:1527628077563};\\\", \\\"{x:179,y:623,t:1527628077603};\\\", \\\"{x:177,y:624,t:1527628077619};\\\", \\\"{x:177,y:625,t:1527628077627};\\\", \\\"{x:176,y:625,t:1527628077642};\\\", \\\"{x:175,y:627,t:1527628077659};\\\", \\\"{x:171,y:628,t:1527628077716};\\\", \\\"{x:167,y:631,t:1527628077726};\\\", \\\"{x:164,y:633,t:1527628077742};\\\", \\\"{x:161,y:634,t:1527628077759};\\\", \\\"{x:160,y:636,t:1527628077995};\\\", \\\"{x:160,y:637,t:1527628078008};\\\", \\\"{x:169,y:644,t:1527628078026};\\\", \\\"{x:181,y:652,t:1527628078044};\\\", \\\"{x:188,y:657,t:1527628078059};\\\", \\\"{x:209,y:667,t:1527628078076};\\\", \\\"{x:230,y:677,t:1527628078094};\\\", \\\"{x:256,y:686,t:1527628078109};\\\", \\\"{x:278,y:697,t:1527628078126};\\\", \\\"{x:313,y:709,t:1527628078143};\\\", \\\"{x:340,y:721,t:1527628078159};\\\", \\\"{x:360,y:726,t:1527628078176};\\\", \\\"{x:382,y:728,t:1527628078194};\\\", \\\"{x:398,y:736,t:1527628078209};\\\", \\\"{x:418,y:738,t:1527628078227};\\\", \\\"{x:438,y:741,t:1527628078244};\\\", \\\"{x:458,y:741,t:1527628078259};\\\", \\\"{x:476,y:740,t:1527628078276};\\\", \\\"{x:479,y:740,t:1527628078293};\\\", \\\"{x:480,y:738,t:1527628078309};\\\", \\\"{x:481,y:738,t:1527628078327};\\\", \\\"{x:483,y:738,t:1527628078372};\\\", \\\"{x:486,y:738,t:1527628078380};\\\", \\\"{x:491,y:738,t:1527628078394};\\\", \\\"{x:496,y:738,t:1527628078409};\\\", \\\"{x:501,y:738,t:1527628078427};\\\", \\\"{x:502,y:738,t:1527628078443};\\\", \\\"{x:506,y:735,t:1527628078461};\\\", \\\"{x:506,y:734,t:1527628078476};\\\", \\\"{x:506,y:731,t:1527628078493};\\\", \\\"{x:507,y:728,t:1527628078510};\\\", \\\"{x:507,y:726,t:1527628078526};\\\", \\\"{x:508,y:724,t:1527628078543};\\\", \\\"{x:508,y:723,t:1527628078560};\\\", \\\"{x:508,y:722,t:1527628078577};\\\", \\\"{x:509,y:721,t:1527628078593};\\\", \\\"{x:510,y:718,t:1527628078620};\\\", \\\"{x:510,y:717,t:1527628078668};\\\", \\\"{x:510,y:716,t:1527628078678};\\\", \\\"{x:510,y:715,t:1527628078707};\\\", \\\"{x:510,y:714,t:1527628078748};\\\", \\\"{x:510,y:711,t:1527628084516};\\\", \\\"{x:535,y:683,t:1527628084533};\\\", \\\"{x:553,y:669,t:1527628084549};\\\", \\\"{x:575,y:650,t:1527628084566};\\\", \\\"{x:594,y:631,t:1527628084581};\\\", \\\"{x:613,y:618,t:1527628084599};\\\", \\\"{x:630,y:605,t:1527628084615};\\\", \\\"{x:645,y:594,t:1527628084631};\\\", \\\"{x:663,y:578,t:1527628084648};\\\", \\\"{x:687,y:566,t:1527628084665};\\\", \\\"{x:713,y:558,t:1527628084681};\\\", \\\"{x:757,y:548,t:1527628084698};\\\", \\\"{x:842,y:529,t:1527628084716};\\\", \\\"{x:913,y:514,t:1527628084731};\\\", \\\"{x:958,y:510,t:1527628084748};\\\", \\\"{x:1016,y:503,t:1527628084765};\\\", \\\"{x:1069,y:496,t:1527628084782};\\\", \\\"{x:1125,y:488,t:1527628084799};\\\", \\\"{x:1168,y:484,t:1527628084816};\\\", \\\"{x:1195,y:484,t:1527628084832};\\\", \\\"{x:1218,y:484,t:1527628084848};\\\", \\\"{x:1240,y:484,t:1527628084865};\\\", \\\"{x:1264,y:484,t:1527628084882};\\\", \\\"{x:1280,y:483,t:1527628084899};\\\", \\\"{x:1294,y:482,t:1527628084915};\\\", \\\"{x:1309,y:482,t:1527628084933};\\\", \\\"{x:1326,y:481,t:1527628084950};\\\", \\\"{x:1340,y:481,t:1527628084967};\\\", \\\"{x:1346,y:481,t:1527628084983};\\\", \\\"{x:1347,y:481,t:1527628085000};\\\", \\\"{x:1349,y:481,t:1527628085125};\\\", \\\"{x:1351,y:482,t:1527628085205};\\\", \\\"{x:1355,y:482,t:1527628085218};\\\", \\\"{x:1369,y:481,t:1527628085234};\\\", \\\"{x:1389,y:470,t:1527628085251};\\\", \\\"{x:1403,y:457,t:1527628085268};\\\", \\\"{x:1412,y:448,t:1527628085284};\\\", \\\"{x:1420,y:441,t:1527628085301};\\\", \\\"{x:1426,y:437,t:1527628085318};\\\", \\\"{x:1432,y:433,t:1527628085335};\\\", \\\"{x:1442,y:427,t:1527628085351};\\\", \\\"{x:1452,y:422,t:1527628085368};\\\", \\\"{x:1459,y:417,t:1527628085385};\\\", \\\"{x:1463,y:415,t:1527628085401};\\\", \\\"{x:1467,y:414,t:1527628085418};\\\", \\\"{x:1471,y:414,t:1527628085435};\\\", \\\"{x:1473,y:412,t:1527628085452};\\\", \\\"{x:1474,y:412,t:1527628085476};\\\", \\\"{x:1477,y:412,t:1527628085492};\\\", \\\"{x:1478,y:412,t:1527628085502};\\\", \\\"{x:1492,y:413,t:1527628085519};\\\", \\\"{x:1511,y:414,t:1527628085536};\\\", \\\"{x:1530,y:418,t:1527628085552};\\\", \\\"{x:1555,y:420,t:1527628085569};\\\", \\\"{x:1570,y:423,t:1527628085586};\\\", \\\"{x:1582,y:424,t:1527628085603};\\\", \\\"{x:1586,y:425,t:1527628085619};\\\", \\\"{x:1591,y:425,t:1527628085636};\\\", \\\"{x:1592,y:426,t:1527628085652};\\\", \\\"{x:1593,y:426,t:1527628085669};\\\", \\\"{x:1594,y:426,t:1527628085757};\\\", \\\"{x:1596,y:426,t:1527628085772};\\\", \\\"{x:1597,y:426,t:1527628085787};\\\", \\\"{x:1602,y:430,t:1527628085803};\\\", \\\"{x:1604,y:431,t:1527628085820};\\\", \\\"{x:1605,y:431,t:1527628085844};\\\", \\\"{x:1607,y:432,t:1527628085876};\\\", \\\"{x:1607,y:433,t:1527628085892};\\\", \\\"{x:1608,y:433,t:1527628085904};\\\", \\\"{x:1609,y:433,t:1527628085920};\\\", \\\"{x:1612,y:433,t:1527628085947};\\\", \\\"{x:1614,y:433,t:1527628086011};\\\", \\\"{x:1615,y:434,t:1527628086156};\\\", \\\"{x:1615,y:443,t:1527628088982};\\\", \\\"{x:1618,y:457,t:1527628088989};\\\", \\\"{x:1620,y:476,t:1527628089000};\\\", \\\"{x:1621,y:503,t:1527628089016};\\\", \\\"{x:1624,y:523,t:1527628089033};\\\", \\\"{x:1626,y:534,t:1527628089049};\\\", \\\"{x:1628,y:545,t:1527628089067};\\\", \\\"{x:1632,y:557,t:1527628089083};\\\", \\\"{x:1635,y:570,t:1527628089101};\\\", \\\"{x:1637,y:588,t:1527628089117};\\\", \\\"{x:1640,y:602,t:1527628089133};\\\", \\\"{x:1642,y:614,t:1527628089150};\\\", \\\"{x:1645,y:625,t:1527628089167};\\\", \\\"{x:1650,y:635,t:1527628089183};\\\", \\\"{x:1651,y:642,t:1527628089200};\\\", \\\"{x:1652,y:645,t:1527628089218};\\\", \\\"{x:1652,y:649,t:1527628089234};\\\", \\\"{x:1653,y:650,t:1527628089250};\\\", \\\"{x:1653,y:647,t:1527628089612};\\\", \\\"{x:1648,y:633,t:1527628089619};\\\", \\\"{x:1639,y:589,t:1527628089636};\\\", \\\"{x:1632,y:568,t:1527628089653};\\\", \\\"{x:1627,y:547,t:1527628089670};\\\", \\\"{x:1623,y:529,t:1527628089686};\\\", \\\"{x:1621,y:508,t:1527628089703};\\\", \\\"{x:1620,y:500,t:1527628089720};\\\", \\\"{x:1620,y:488,t:1527628089736};\\\", \\\"{x:1616,y:470,t:1527628089753};\\\", \\\"{x:1615,y:467,t:1527628089770};\\\", \\\"{x:1614,y:466,t:1527628089787};\\\", \\\"{x:1614,y:465,t:1527628089803};\\\", \\\"{x:1612,y:466,t:1527628089988};\\\", \\\"{x:1610,y:476,t:1527628090004};\\\", \\\"{x:1608,y:492,t:1527628090021};\\\", \\\"{x:1606,y:504,t:1527628090037};\\\", \\\"{x:1605,y:509,t:1527628090054};\\\", \\\"{x:1605,y:516,t:1527628090070};\\\", \\\"{x:1604,y:523,t:1527628090087};\\\", \\\"{x:1604,y:531,t:1527628090104};\\\", \\\"{x:1601,y:538,t:1527628090121};\\\", \\\"{x:1601,y:547,t:1527628090137};\\\", \\\"{x:1601,y:553,t:1527628090155};\\\", \\\"{x:1601,y:568,t:1527628090171};\\\", \\\"{x:1601,y:582,t:1527628090188};\\\", \\\"{x:1601,y:590,t:1527628090204};\\\", \\\"{x:1602,y:603,t:1527628090221};\\\", \\\"{x:1606,y:614,t:1527628090238};\\\", \\\"{x:1607,y:624,t:1527628090255};\\\", \\\"{x:1608,y:634,t:1527628090272};\\\", \\\"{x:1610,y:643,t:1527628090288};\\\", \\\"{x:1611,y:647,t:1527628090305};\\\", \\\"{x:1611,y:654,t:1527628090321};\\\", \\\"{x:1614,y:663,t:1527628090338};\\\", \\\"{x:1616,y:670,t:1527628090355};\\\", \\\"{x:1618,y:673,t:1527628090372};\\\", \\\"{x:1618,y:674,t:1527628090396};\\\", \\\"{x:1618,y:676,t:1527628090420};\\\", \\\"{x:1618,y:677,t:1527628090428};\\\", \\\"{x:1618,y:679,t:1527628090439};\\\", \\\"{x:1618,y:683,t:1527628090455};\\\", \\\"{x:1618,y:686,t:1527628090472};\\\", \\\"{x:1618,y:690,t:1527628090489};\\\", \\\"{x:1618,y:696,t:1527628090505};\\\", \\\"{x:1618,y:701,t:1527628090523};\\\", \\\"{x:1618,y:703,t:1527628090540};\\\", \\\"{x:1618,y:705,t:1527628090556};\\\", \\\"{x:1618,y:710,t:1527628090573};\\\", \\\"{x:1618,y:715,t:1527628090590};\\\", \\\"{x:1617,y:727,t:1527628090607};\\\", \\\"{x:1617,y:732,t:1527628090623};\\\", \\\"{x:1616,y:734,t:1527628090640};\\\", \\\"{x:1616,y:736,t:1527628090657};\\\", \\\"{x:1615,y:742,t:1527628090674};\\\", \\\"{x:1615,y:745,t:1527628090689};\\\", \\\"{x:1614,y:753,t:1527628090707};\\\", \\\"{x:1611,y:771,t:1527628090723};\\\", \\\"{x:1609,y:783,t:1527628090741};\\\", \\\"{x:1609,y:791,t:1527628090757};\\\", \\\"{x:1607,y:806,t:1527628090774};\\\", \\\"{x:1604,y:819,t:1527628090791};\\\", \\\"{x:1604,y:829,t:1527628090808};\\\", \\\"{x:1604,y:839,t:1527628090824};\\\", \\\"{x:1604,y:846,t:1527628090841};\\\", \\\"{x:1604,y:853,t:1527628090859};\\\", \\\"{x:1605,y:859,t:1527628090874};\\\", \\\"{x:1607,y:868,t:1527628090891};\\\", \\\"{x:1610,y:882,t:1527628090908};\\\", \\\"{x:1613,y:890,t:1527628090926};\\\", \\\"{x:1614,y:896,t:1527628090942};\\\", \\\"{x:1614,y:902,t:1527628090958};\\\", \\\"{x:1617,y:908,t:1527628090975};\\\", \\\"{x:1618,y:912,t:1527628090992};\\\", \\\"{x:1619,y:914,t:1527628091008};\\\", \\\"{x:1619,y:915,t:1527628091025};\\\", \\\"{x:1621,y:919,t:1527628091042};\\\", \\\"{x:1622,y:922,t:1527628091059};\\\", \\\"{x:1623,y:926,t:1527628091075};\\\", \\\"{x:1626,y:930,t:1527628091091};\\\", \\\"{x:1627,y:933,t:1527628091109};\\\", \\\"{x:1627,y:935,t:1527628091126};\\\", \\\"{x:1628,y:937,t:1527628091142};\\\", \\\"{x:1629,y:940,t:1527628091159};\\\", \\\"{x:1629,y:942,t:1527628091177};\\\", \\\"{x:1629,y:943,t:1527628091193};\\\", \\\"{x:1629,y:946,t:1527628091209};\\\", \\\"{x:1629,y:949,t:1527628091226};\\\", \\\"{x:1629,y:951,t:1527628091243};\\\", \\\"{x:1629,y:952,t:1527628091260};\\\", \\\"{x:1628,y:953,t:1527628091277};\\\", \\\"{x:1628,y:954,t:1527628091293};\\\", \\\"{x:1628,y:955,t:1527628091316};\\\", \\\"{x:1628,y:956,t:1527628091326};\\\", \\\"{x:1628,y:957,t:1527628091343};\\\", \\\"{x:1628,y:958,t:1527628091360};\\\", \\\"{x:1626,y:961,t:1527628091380};\\\", \\\"{x:1625,y:961,t:1527628091392};\\\", \\\"{x:1624,y:963,t:1527628091467};\\\", \\\"{x:1624,y:964,t:1527628091477};\\\", \\\"{x:1623,y:965,t:1527628091493};\\\", \\\"{x:1621,y:969,t:1527628091510};\\\", \\\"{x:1618,y:970,t:1527628091526};\\\", \\\"{x:1618,y:971,t:1527628091543};\\\", \\\"{x:1618,y:973,t:1527628091594};\\\", \\\"{x:1617,y:973,t:1527628093420};\\\", \\\"{x:1616,y:974,t:1527628093436};\\\", \\\"{x:1615,y:974,t:1527628093451};\\\", \\\"{x:1615,y:973,t:1527628093475};\\\", \\\"{x:1614,y:972,t:1527628093485};\\\", \\\"{x:1613,y:970,t:1527628093502};\\\", \\\"{x:1610,y:967,t:1527628093520};\\\", \\\"{x:1606,y:960,t:1527628093537};\\\", \\\"{x:1599,y:952,t:1527628093552};\\\", \\\"{x:1591,y:945,t:1527628093569};\\\", \\\"{x:1580,y:939,t:1527628093587};\\\", \\\"{x:1550,y:920,t:1527628093603};\\\", \\\"{x:1512,y:898,t:1527628093619};\\\", \\\"{x:1472,y:877,t:1527628093636};\\\", \\\"{x:1432,y:855,t:1527628093654};\\\", \\\"{x:1403,y:846,t:1527628093670};\\\", \\\"{x:1380,y:841,t:1527628093686};\\\", \\\"{x:1369,y:838,t:1527628093703};\\\", \\\"{x:1367,y:837,t:1527628093720};\\\", \\\"{x:1366,y:837,t:1527628094044};\\\", \\\"{x:1365,y:837,t:1527628094187};\\\", \\\"{x:1364,y:837,t:1527628094291};\\\", \\\"{x:1363,y:837,t:1527628094315};\\\", \\\"{x:1362,y:837,t:1527628094363};\\\", \\\"{x:1360,y:837,t:1527628094427};\\\", \\\"{x:1357,y:842,t:1527628094439};\\\", \\\"{x:1347,y:852,t:1527628094455};\\\", \\\"{x:1343,y:859,t:1527628094473};\\\", \\\"{x:1335,y:861,t:1527628094489};\\\", \\\"{x:1331,y:861,t:1527628094505};\\\", \\\"{x:1324,y:862,t:1527628094522};\\\", \\\"{x:1323,y:862,t:1527628094540};\\\", \\\"{x:1320,y:861,t:1527628095148};\\\", \\\"{x:1316,y:861,t:1527628095159};\\\", \\\"{x:1309,y:861,t:1527628095177};\\\", \\\"{x:1302,y:861,t:1527628095193};\\\", \\\"{x:1295,y:861,t:1527628095209};\\\", \\\"{x:1287,y:859,t:1527628095226};\\\", \\\"{x:1284,y:859,t:1527628095244};\\\", \\\"{x:1283,y:859,t:1527628095260};\\\", \\\"{x:1282,y:858,t:1527628095284};\\\", \\\"{x:1281,y:858,t:1527628095294};\\\", \\\"{x:1278,y:858,t:1527628095315};\\\", \\\"{x:1276,y:858,t:1527628095326};\\\", \\\"{x:1272,y:858,t:1527628095343};\\\", \\\"{x:1268,y:856,t:1527628095360};\\\", \\\"{x:1265,y:856,t:1527628095379};\\\", \\\"{x:1258,y:855,t:1527628095393};\\\", \\\"{x:1248,y:854,t:1527628095410};\\\", \\\"{x:1235,y:851,t:1527628095427};\\\", \\\"{x:1221,y:849,t:1527628095443};\\\", \\\"{x:1205,y:845,t:1527628095460};\\\", \\\"{x:1199,y:844,t:1527628095477};\\\", \\\"{x:1195,y:844,t:1527628095494};\\\", \\\"{x:1195,y:843,t:1527628096012};\\\", \\\"{x:1195,y:842,t:1527628096043};\\\", \\\"{x:1195,y:841,t:1527628096052};\\\", \\\"{x:1197,y:841,t:1527628096068};\\\", \\\"{x:1199,y:841,t:1527628096080};\\\", \\\"{x:1200,y:841,t:1527628096100};\\\", \\\"{x:1201,y:841,t:1527628096113};\\\", \\\"{x:1202,y:841,t:1527628096132};\\\", \\\"{x:1203,y:841,t:1527628096204};\\\", \\\"{x:1204,y:841,t:1527628096220};\\\", \\\"{x:1206,y:839,t:1527628096230};\\\", \\\"{x:1210,y:839,t:1527628096248};\\\", \\\"{x:1214,y:838,t:1527628096265};\\\", \\\"{x:1219,y:837,t:1527628096281};\\\", \\\"{x:1224,y:836,t:1527628096298};\\\", \\\"{x:1229,y:835,t:1527628096315};\\\", \\\"{x:1230,y:835,t:1527628096356};\\\", \\\"{x:1232,y:835,t:1527628096380};\\\", \\\"{x:1233,y:835,t:1527628096396};\\\", \\\"{x:1235,y:835,t:1527628096412};\\\", \\\"{x:1236,y:835,t:1527628096420};\\\", \\\"{x:1240,y:835,t:1527628096431};\\\", \\\"{x:1247,y:836,t:1527628096448};\\\", \\\"{x:1256,y:836,t:1527628096465};\\\", \\\"{x:1265,y:840,t:1527628096481};\\\", \\\"{x:1275,y:841,t:1527628096499};\\\", \\\"{x:1298,y:846,t:1527628096516};\\\", \\\"{x:1304,y:846,t:1527628096531};\\\", \\\"{x:1315,y:850,t:1527628096548};\\\", \\\"{x:1321,y:851,t:1527628096565};\\\", \\\"{x:1322,y:851,t:1527628096587};\\\", \\\"{x:1323,y:853,t:1527628096604};\\\", \\\"{x:1326,y:855,t:1527628096616};\\\", \\\"{x:1329,y:862,t:1527628096632};\\\", \\\"{x:1334,y:869,t:1527628096649};\\\", \\\"{x:1340,y:876,t:1527628096665};\\\", \\\"{x:1346,y:886,t:1527628096683};\\\", \\\"{x:1353,y:894,t:1527628096700};\\\", \\\"{x:1354,y:894,t:1527628096717};\\\", \\\"{x:1355,y:894,t:1527628096732};\\\", \\\"{x:1356,y:895,t:1527628096779};\\\", \\\"{x:1356,y:896,t:1527628096788};\\\", \\\"{x:1356,y:897,t:1527628096805};\\\", \\\"{x:1357,y:899,t:1527628096820};\\\", \\\"{x:1357,y:900,t:1527628097180};\\\", \\\"{x:1357,y:901,t:1527628097244};\\\", \\\"{x:1357,y:902,t:1527628097268};\\\", \\\"{x:1357,y:903,t:1527628097285};\\\", \\\"{x:1358,y:902,t:1527628098132};\\\", \\\"{x:1359,y:901,t:1527628098140};\\\", \\\"{x:1360,y:899,t:1527628098156};\\\", \\\"{x:1362,y:894,t:1527628098171};\\\", \\\"{x:1362,y:892,t:1527628098188};\\\", \\\"{x:1363,y:889,t:1527628098205};\\\", \\\"{x:1364,y:887,t:1527628098222};\\\", \\\"{x:1365,y:885,t:1527628098240};\\\", \\\"{x:1366,y:882,t:1527628098256};\\\", \\\"{x:1366,y:879,t:1527628098272};\\\", \\\"{x:1366,y:875,t:1527628098289};\\\", \\\"{x:1366,y:874,t:1527628098306};\\\", \\\"{x:1367,y:869,t:1527628098323};\\\", \\\"{x:1367,y:863,t:1527628098340};\\\", \\\"{x:1369,y:857,t:1527628098355};\\\", \\\"{x:1370,y:852,t:1527628098373};\\\", \\\"{x:1370,y:847,t:1527628098389};\\\", \\\"{x:1371,y:838,t:1527628098406};\\\", \\\"{x:1371,y:834,t:1527628098423};\\\", \\\"{x:1373,y:830,t:1527628098440};\\\", \\\"{x:1373,y:826,t:1527628098457};\\\", \\\"{x:1374,y:821,t:1527628098473};\\\", \\\"{x:1374,y:815,t:1527628098491};\\\", \\\"{x:1376,y:810,t:1527628098507};\\\", \\\"{x:1377,y:802,t:1527628098524};\\\", \\\"{x:1377,y:800,t:1527628098540};\\\", \\\"{x:1378,y:797,t:1527628098557};\\\", \\\"{x:1378,y:795,t:1527628098574};\\\", \\\"{x:1379,y:791,t:1527628098590};\\\", \\\"{x:1379,y:786,t:1527628098607};\\\", \\\"{x:1380,y:782,t:1527628098625};\\\", \\\"{x:1380,y:777,t:1527628098640};\\\", \\\"{x:1380,y:774,t:1527628098658};\\\", \\\"{x:1380,y:771,t:1527628098675};\\\", \\\"{x:1382,y:768,t:1527628098691};\\\", \\\"{x:1382,y:767,t:1527628098708};\\\", \\\"{x:1385,y:767,t:1527628099516};\\\", \\\"{x:1388,y:768,t:1527628099528};\\\", \\\"{x:1389,y:769,t:1527628099545};\\\", \\\"{x:1391,y:770,t:1527628099561};\\\", \\\"{x:1394,y:772,t:1527628099580};\\\", \\\"{x:1395,y:773,t:1527628099596};\\\", \\\"{x:1395,y:775,t:1527628099620};\\\", \\\"{x:1396,y:778,t:1527628099636};\\\", \\\"{x:1396,y:779,t:1527628099660};\\\", \\\"{x:1397,y:779,t:1527628099668};\\\", \\\"{x:1397,y:780,t:1527628099691};\\\", \\\"{x:1398,y:781,t:1527628099740};\\\", \\\"{x:1399,y:782,t:1527628099756};\\\", \\\"{x:1401,y:785,t:1527628099772};\\\", \\\"{x:1401,y:786,t:1527628099788};\\\", \\\"{x:1402,y:786,t:1527628099796};\\\", \\\"{x:1402,y:787,t:1527628099917};\\\", \\\"{x:1404,y:791,t:1527628099932};\\\", \\\"{x:1405,y:791,t:1527628099946};\\\", \\\"{x:1409,y:793,t:1527628099961};\\\", \\\"{x:1412,y:795,t:1527628099978};\\\", \\\"{x:1415,y:795,t:1527628099996};\\\", \\\"{x:1418,y:798,t:1527628101021};\\\", \\\"{x:1421,y:804,t:1527628101034};\\\", \\\"{x:1433,y:813,t:1527628101050};\\\", \\\"{x:1445,y:823,t:1527628101067};\\\", \\\"{x:1451,y:827,t:1527628101084};\\\", \\\"{x:1455,y:830,t:1527628101101};\\\", \\\"{x:1456,y:830,t:1527628101118};\\\", \\\"{x:1457,y:830,t:1527628101172};\\\", \\\"{x:1459,y:831,t:1527628101185};\\\", \\\"{x:1459,y:832,t:1527628101204};\\\", \\\"{x:1460,y:832,t:1527628101218};\\\", \\\"{x:1462,y:834,t:1527628101234};\\\", \\\"{x:1463,y:834,t:1527628101364};\\\", \\\"{x:1465,y:834,t:1527628101500};\\\", \\\"{x:1466,y:834,t:1527628101604};\\\", \\\"{x:1468,y:834,t:1527628101628};\\\", \\\"{x:1469,y:834,t:1527628101660};\\\", \\\"{x:1470,y:834,t:1527628101700};\\\", \\\"{x:1471,y:834,t:1527628101715};\\\", \\\"{x:1472,y:834,t:1527628101724};\\\", \\\"{x:1474,y:834,t:1527628102316};\\\", \\\"{x:1475,y:834,t:1527628102412};\\\", \\\"{x:1477,y:834,t:1527628102564};\\\", \\\"{x:1471,y:832,t:1527628103141};\\\", \\\"{x:1468,y:829,t:1527628103148};\\\", \\\"{x:1458,y:827,t:1527628103159};\\\", \\\"{x:1435,y:814,t:1527628103177};\\\", \\\"{x:1395,y:807,t:1527628103194};\\\", \\\"{x:1284,y:789,t:1527628103210};\\\", \\\"{x:1183,y:769,t:1527628103227};\\\", \\\"{x:1032,y:737,t:1527628103244};\\\", \\\"{x:958,y:721,t:1527628103260};\\\", \\\"{x:897,y:697,t:1527628103276};\\\", \\\"{x:875,y:692,t:1527628103294};\\\", \\\"{x:866,y:690,t:1527628103310};\\\", \\\"{x:854,y:684,t:1527628103326};\\\", \\\"{x:839,y:677,t:1527628103343};\\\", \\\"{x:823,y:670,t:1527628103360};\\\", \\\"{x:801,y:666,t:1527628103378};\\\", \\\"{x:773,y:665,t:1527628103394};\\\", \\\"{x:754,y:665,t:1527628103410};\\\", \\\"{x:724,y:665,t:1527628103428};\\\", \\\"{x:701,y:665,t:1527628103444};\\\", \\\"{x:684,y:665,t:1527628103460};\\\", \\\"{x:638,y:660,t:1527628103477};\\\", \\\"{x:573,y:650,t:1527628103496};\\\", \\\"{x:519,y:639,t:1527628103510};\\\", \\\"{x:443,y:639,t:1527628103528};\\\", \\\"{x:344,y:643,t:1527628103546};\\\", \\\"{x:314,y:642,t:1527628103564};\\\", \\\"{x:289,y:641,t:1527628103580};\\\", \\\"{x:271,y:641,t:1527628103598};\\\", \\\"{x:260,y:641,t:1527628103613};\\\", \\\"{x:253,y:641,t:1527628103630};\\\", \\\"{x:250,y:641,t:1527628103646};\\\", \\\"{x:244,y:640,t:1527628103663};\\\", \\\"{x:237,y:638,t:1527628103681};\\\", \\\"{x:233,y:637,t:1527628103698};\\\", \\\"{x:230,y:635,t:1527628103714};\\\", \\\"{x:229,y:635,t:1527628103730};\\\", \\\"{x:225,y:635,t:1527628103779};\\\", \\\"{x:217,y:635,t:1527628103787};\\\", \\\"{x:213,y:632,t:1527628103798};\\\", \\\"{x:200,y:630,t:1527628103815};\\\", \\\"{x:188,y:628,t:1527628103832};\\\", \\\"{x:182,y:626,t:1527628103848};\\\", \\\"{x:181,y:626,t:1527628103864};\\\", \\\"{x:179,y:626,t:1527628103898};\\\", \\\"{x:178,y:626,t:1527628103915};\\\", \\\"{x:176,y:626,t:1527628103930};\\\", \\\"{x:174,y:626,t:1527628103981};\\\", \\\"{x:173,y:626,t:1527628103996};\\\", \\\"{x:173,y:626,t:1527628104068};\\\", \\\"{x:174,y:626,t:1527628104139};\\\", \\\"{x:175,y:626,t:1527628104148};\\\", \\\"{x:176,y:626,t:1527628104164};\\\", \\\"{x:177,y:626,t:1527628104180};\\\", \\\"{x:180,y:626,t:1527628104198};\\\", \\\"{x:188,y:626,t:1527628104214};\\\", \\\"{x:201,y:626,t:1527628104231};\\\", \\\"{x:216,y:626,t:1527628104248};\\\", \\\"{x:232,y:618,t:1527628104264};\\\", \\\"{x:243,y:614,t:1527628104281};\\\", \\\"{x:254,y:610,t:1527628104298};\\\", \\\"{x:274,y:607,t:1527628104314};\\\", \\\"{x:319,y:597,t:1527628104330};\\\", \\\"{x:345,y:591,t:1527628104348};\\\", \\\"{x:379,y:590,t:1527628104365};\\\", \\\"{x:418,y:590,t:1527628104381};\\\", \\\"{x:452,y:590,t:1527628104398};\\\", \\\"{x:488,y:590,t:1527628104415};\\\", \\\"{x:537,y:585,t:1527628104432};\\\", \\\"{x:580,y:576,t:1527628104449};\\\", \\\"{x:601,y:570,t:1527628104464};\\\", \\\"{x:612,y:569,t:1527628104481};\\\", \\\"{x:615,y:569,t:1527628104498};\\\", \\\"{x:618,y:568,t:1527628104514};\\\", \\\"{x:629,y:566,t:1527628104531};\\\", \\\"{x:644,y:565,t:1527628104548};\\\", \\\"{x:652,y:565,t:1527628104565};\\\", \\\"{x:656,y:563,t:1527628104581};\\\", \\\"{x:660,y:563,t:1527628104598};\\\", \\\"{x:661,y:562,t:1527628104615};\\\", \\\"{x:662,y:562,t:1527628104683};\\\", \\\"{x:663,y:563,t:1527628104699};\\\", \\\"{x:663,y:571,t:1527628104715};\\\", \\\"{x:663,y:577,t:1527628104733};\\\", \\\"{x:659,y:584,t:1527628104748};\\\", \\\"{x:651,y:594,t:1527628104765};\\\", \\\"{x:642,y:600,t:1527628104781};\\\", \\\"{x:639,y:603,t:1527628104798};\\\", \\\"{x:638,y:604,t:1527628104815};\\\", \\\"{x:640,y:604,t:1527628105204};\\\", \\\"{x:653,y:605,t:1527628105215};\\\", \\\"{x:684,y:606,t:1527628105232};\\\", \\\"{x:732,y:611,t:1527628105249};\\\", \\\"{x:787,y:615,t:1527628105265};\\\", \\\"{x:853,y:629,t:1527628105282};\\\", \\\"{x:994,y:641,t:1527628105299};\\\", \\\"{x:1085,y:650,t:1527628105315};\\\", \\\"{x:1147,y:660,t:1527628105332};\\\", \\\"{x:1175,y:670,t:1527628105348};\\\", \\\"{x:1200,y:674,t:1527628105366};\\\", \\\"{x:1229,y:678,t:1527628105383};\\\", \\\"{x:1257,y:686,t:1527628105398};\\\", \\\"{x:1290,y:699,t:1527628105415};\\\", \\\"{x:1344,y:710,t:1527628105432};\\\", \\\"{x:1379,y:724,t:1527628105449};\\\", \\\"{x:1412,y:736,t:1527628105465};\\\", \\\"{x:1451,y:745,t:1527628105483};\\\", \\\"{x:1477,y:752,t:1527628105499};\\\", \\\"{x:1483,y:756,t:1527628105515};\\\", \\\"{x:1487,y:758,t:1527628105532};\\\", \\\"{x:1491,y:764,t:1527628105549};\\\", \\\"{x:1496,y:776,t:1527628105565};\\\", \\\"{x:1504,y:787,t:1527628105582};\\\", \\\"{x:1507,y:798,t:1527628105599};\\\", \\\"{x:1510,y:803,t:1527628105615};\\\", \\\"{x:1510,y:804,t:1527628105635};\\\", \\\"{x:1511,y:805,t:1527628105651};\\\", \\\"{x:1511,y:806,t:1527628105667};\\\", \\\"{x:1511,y:809,t:1527628105699};\\\", \\\"{x:1511,y:810,t:1527628105723};\\\", \\\"{x:1511,y:812,t:1527628105732};\\\", \\\"{x:1511,y:814,t:1527628105749};\\\", \\\"{x:1510,y:815,t:1527628105765};\\\", \\\"{x:1509,y:817,t:1527628105782};\\\", \\\"{x:1507,y:819,t:1527628105799};\\\", \\\"{x:1507,y:820,t:1527628105815};\\\", \\\"{x:1505,y:821,t:1527628105833};\\\", \\\"{x:1504,y:821,t:1527628105859};\\\", \\\"{x:1503,y:821,t:1527628105876};\\\", \\\"{x:1502,y:821,t:1527628105891};\\\", \\\"{x:1501,y:821,t:1527628105916};\\\", \\\"{x:1499,y:822,t:1527628105933};\\\", \\\"{x:1498,y:822,t:1527628105964};\\\", \\\"{x:1497,y:822,t:1527628105979};\\\", \\\"{x:1494,y:822,t:1527628105987};\\\", \\\"{x:1493,y:822,t:1527628106000};\\\", \\\"{x:1489,y:822,t:1527628106017};\\\", \\\"{x:1477,y:821,t:1527628106033};\\\", \\\"{x:1460,y:812,t:1527628106050};\\\", \\\"{x:1440,y:801,t:1527628106066};\\\", \\\"{x:1429,y:791,t:1527628106083};\\\", \\\"{x:1398,y:767,t:1527628106100};\\\", \\\"{x:1386,y:756,t:1527628106117};\\\", \\\"{x:1381,y:747,t:1527628106133};\\\", \\\"{x:1375,y:734,t:1527628106155};\\\", \\\"{x:1369,y:718,t:1527628106166};\\\", \\\"{x:1363,y:706,t:1527628106183};\\\", \\\"{x:1356,y:692,t:1527628106199};\\\", \\\"{x:1350,y:679,t:1527628106215};\\\", \\\"{x:1348,y:672,t:1527628106233};\\\", \\\"{x:1347,y:672,t:1527628106248};\\\", \\\"{x:1347,y:670,t:1527628106266};\\\", \\\"{x:1347,y:669,t:1527628106283};\\\", \\\"{x:1346,y:665,t:1527628106299};\\\", \\\"{x:1346,y:664,t:1527628106316};\\\", \\\"{x:1343,y:659,t:1527628106333};\\\", \\\"{x:1339,y:655,t:1527628106350};\\\", \\\"{x:1334,y:651,t:1527628106367};\\\", \\\"{x:1328,y:647,t:1527628106383};\\\", \\\"{x:1325,y:645,t:1527628106399};\\\", \\\"{x:1324,y:644,t:1527628106420};\\\", \\\"{x:1323,y:644,t:1527628106435};\\\", \\\"{x:1322,y:644,t:1527628106450};\\\", \\\"{x:1322,y:643,t:1527628106492};\\\", \\\"{x:1321,y:642,t:1527628106501};\\\", \\\"{x:1319,y:642,t:1527628106516};\\\", \\\"{x:1318,y:640,t:1527628106533};\\\", \\\"{x:1313,y:639,t:1527628106549};\\\", \\\"{x:1312,y:637,t:1527628106566};\\\", \\\"{x:1311,y:637,t:1527628106583};\\\", \\\"{x:1311,y:636,t:1527628106708};\\\", \\\"{x:1311,y:638,t:1527628107164};\\\", \\\"{x:1311,y:640,t:1527628107172};\\\", \\\"{x:1311,y:641,t:1527628107187};\\\", \\\"{x:1311,y:643,t:1527628107202};\\\", \\\"{x:1311,y:645,t:1527628107216};\\\", \\\"{x:1311,y:646,t:1527628107233};\\\", \\\"{x:1311,y:648,t:1527628107250};\\\", \\\"{x:1311,y:654,t:1527628107267};\\\", \\\"{x:1311,y:659,t:1527628107283};\\\", \\\"{x:1311,y:661,t:1527628107306};\\\", \\\"{x:1311,y:663,t:1527628107331};\\\", \\\"{x:1311,y:664,t:1527628107355};\\\", \\\"{x:1311,y:665,t:1527628107367};\\\", \\\"{x:1311,y:666,t:1527628107384};\\\", \\\"{x:1311,y:668,t:1527628107400};\\\", \\\"{x:1311,y:669,t:1527628107417};\\\", \\\"{x:1311,y:671,t:1527628107434};\\\", \\\"{x:1311,y:674,t:1527628107450};\\\", \\\"{x:1311,y:675,t:1527628107467};\\\", \\\"{x:1311,y:677,t:1527628107484};\\\", \\\"{x:1311,y:680,t:1527628107501};\\\", \\\"{x:1311,y:687,t:1527628107517};\\\", \\\"{x:1311,y:693,t:1527628107535};\\\", \\\"{x:1311,y:698,t:1527628107550};\\\", \\\"{x:1311,y:702,t:1527628107568};\\\", \\\"{x:1311,y:707,t:1527628107585};\\\", \\\"{x:1311,y:711,t:1527628107600};\\\", \\\"{x:1311,y:716,t:1527628107617};\\\", \\\"{x:1311,y:722,t:1527628107635};\\\", \\\"{x:1311,y:726,t:1527628107651};\\\", \\\"{x:1311,y:735,t:1527628107667};\\\", \\\"{x:1311,y:744,t:1527628107684};\\\", \\\"{x:1311,y:751,t:1527628107701};\\\", \\\"{x:1311,y:757,t:1527628107718};\\\", \\\"{x:1311,y:761,t:1527628107735};\\\", \\\"{x:1311,y:765,t:1527628107751};\\\", \\\"{x:1311,y:770,t:1527628107768};\\\", \\\"{x:1311,y:781,t:1527628107785};\\\", \\\"{x:1311,y:792,t:1527628107802};\\\", \\\"{x:1311,y:806,t:1527628107818};\\\", \\\"{x:1311,y:812,t:1527628107835};\\\", \\\"{x:1311,y:816,t:1527628107851};\\\", \\\"{x:1311,y:820,t:1527628107867};\\\", \\\"{x:1311,y:822,t:1527628107885};\\\", \\\"{x:1311,y:824,t:1527628107902};\\\", \\\"{x:1311,y:826,t:1527628107917};\\\", \\\"{x:1311,y:827,t:1527628107934};\\\", \\\"{x:1311,y:830,t:1527628107952};\\\", \\\"{x:1311,y:834,t:1527628107968};\\\", \\\"{x:1311,y:837,t:1527628107984};\\\", \\\"{x:1311,y:839,t:1527628108002};\\\", \\\"{x:1311,y:841,t:1527628108020};\\\", \\\"{x:1311,y:843,t:1527628108035};\\\", \\\"{x:1313,y:847,t:1527628108052};\\\", \\\"{x:1315,y:854,t:1527628108068};\\\", \\\"{x:1316,y:858,t:1527628108085};\\\", \\\"{x:1318,y:864,t:1527628108101};\\\", \\\"{x:1318,y:868,t:1527628108118};\\\", \\\"{x:1320,y:872,t:1527628108135};\\\", \\\"{x:1320,y:873,t:1527628108228};\\\", \\\"{x:1320,y:875,t:1527628108235};\\\", \\\"{x:1321,y:877,t:1527628108252};\\\", \\\"{x:1321,y:879,t:1527628108268};\\\", \\\"{x:1321,y:881,t:1527628108284};\\\", \\\"{x:1321,y:885,t:1527628108302};\\\", \\\"{x:1323,y:887,t:1527628108319};\\\", \\\"{x:1323,y:889,t:1527628108335};\\\", \\\"{x:1324,y:890,t:1527628108356};\\\", \\\"{x:1325,y:890,t:1527628108372};\\\", \\\"{x:1325,y:891,t:1527628108387};\\\", \\\"{x:1325,y:892,t:1527628108436};\\\", \\\"{x:1325,y:891,t:1527628108531};\\\", \\\"{x:1325,y:887,t:1527628108540};\\\", \\\"{x:1325,y:883,t:1527628108551};\\\", \\\"{x:1322,y:874,t:1527628108569};\\\", \\\"{x:1320,y:858,t:1527628108586};\\\", \\\"{x:1317,y:843,t:1527628108601};\\\", \\\"{x:1315,y:829,t:1527628108619};\\\", \\\"{x:1313,y:800,t:1527628108636};\\\", \\\"{x:1313,y:787,t:1527628108652};\\\", \\\"{x:1314,y:777,t:1527628108669};\\\", \\\"{x:1317,y:757,t:1527628108685};\\\", \\\"{x:1319,y:735,t:1527628108702};\\\", \\\"{x:1323,y:710,t:1527628108719};\\\", \\\"{x:1324,y:696,t:1527628108736};\\\", \\\"{x:1324,y:676,t:1527628108752};\\\", \\\"{x:1324,y:659,t:1527628108769};\\\", \\\"{x:1324,y:645,t:1527628108786};\\\", \\\"{x:1324,y:631,t:1527628108802};\\\", \\\"{x:1324,y:619,t:1527628108819};\\\", \\\"{x:1326,y:598,t:1527628108835};\\\", \\\"{x:1329,y:577,t:1527628108851};\\\", \\\"{x:1331,y:562,t:1527628108869};\\\", \\\"{x:1333,y:549,t:1527628108886};\\\", \\\"{x:1333,y:546,t:1527628108902};\\\", \\\"{x:1333,y:543,t:1527628108918};\\\", \\\"{x:1333,y:540,t:1527628108936};\\\", \\\"{x:1333,y:539,t:1527628108952};\\\", \\\"{x:1333,y:538,t:1527628108969};\\\", \\\"{x:1333,y:536,t:1527628108986};\\\", \\\"{x:1333,y:535,t:1527628109020};\\\", \\\"{x:1332,y:532,t:1527628109172};\\\", \\\"{x:1331,y:531,t:1527628109187};\\\", \\\"{x:1329,y:530,t:1527628109202};\\\", \\\"{x:1329,y:528,t:1527628109219};\\\", \\\"{x:1327,y:527,t:1527628109235};\\\", \\\"{x:1325,y:525,t:1527628109252};\\\", \\\"{x:1324,y:524,t:1527628109291};\\\", \\\"{x:1323,y:521,t:1527628109315};\\\", \\\"{x:1323,y:520,t:1527628109322};\\\", \\\"{x:1323,y:519,t:1527628109335};\\\", \\\"{x:1322,y:519,t:1527628109353};\\\", \\\"{x:1320,y:518,t:1527628109369};\\\", \\\"{x:1319,y:516,t:1527628109386};\\\", \\\"{x:1319,y:515,t:1527628109403};\\\", \\\"{x:1318,y:513,t:1527628109418};\\\", \\\"{x:1317,y:512,t:1527628109435};\\\", \\\"{x:1316,y:512,t:1527628109452};\\\", \\\"{x:1316,y:511,t:1527628109470};\\\", \\\"{x:1314,y:510,t:1527628109486};\\\", \\\"{x:1314,y:509,t:1527628109502};\\\", \\\"{x:1313,y:509,t:1527628109520};\\\", \\\"{x:1313,y:508,t:1527628110365};\\\", \\\"{x:1316,y:508,t:1527628110372};\\\", \\\"{x:1329,y:508,t:1527628110389};\\\", \\\"{x:1329,y:510,t:1527628110404};\\\", \\\"{x:1342,y:517,t:1527628110420};\\\", \\\"{x:1351,y:519,t:1527628110438};\\\", \\\"{x:1362,y:522,t:1527628110455};\\\", \\\"{x:1372,y:526,t:1527628110471};\\\", \\\"{x:1379,y:532,t:1527628110488};\\\", \\\"{x:1384,y:535,t:1527628110505};\\\", \\\"{x:1386,y:537,t:1527628110520};\\\", \\\"{x:1391,y:541,t:1527628110537};\\\", \\\"{x:1393,y:545,t:1527628110554};\\\", \\\"{x:1395,y:546,t:1527628110572};\\\", \\\"{x:1395,y:547,t:1527628110587};\\\", \\\"{x:1399,y:550,t:1527628110604};\\\", \\\"{x:1400,y:551,t:1527628110621};\\\", \\\"{x:1401,y:554,t:1527628110638};\\\", \\\"{x:1405,y:559,t:1527628110654};\\\", \\\"{x:1410,y:565,t:1527628110672};\\\", \\\"{x:1412,y:566,t:1527628110688};\\\", \\\"{x:1412,y:567,t:1527628110705};\\\", \\\"{x:1413,y:568,t:1527628110721};\\\", \\\"{x:1413,y:566,t:1527628111965};\\\", \\\"{x:1413,y:562,t:1527628111972};\\\", \\\"{x:1413,y:552,t:1527628111989};\\\", \\\"{x:1413,y:544,t:1527628112006};\\\", \\\"{x:1413,y:535,t:1527628112024};\\\", \\\"{x:1414,y:521,t:1527628112039};\\\", \\\"{x:1417,y:513,t:1527628112056};\\\", \\\"{x:1417,y:502,t:1527628112073};\\\", \\\"{x:1417,y:488,t:1527628112089};\\\", \\\"{x:1417,y:480,t:1527628112106};\\\", \\\"{x:1417,y:475,t:1527628112123};\\\", \\\"{x:1417,y:473,t:1527628112139};\\\", \\\"{x:1417,y:469,t:1527628112156};\\\", \\\"{x:1417,y:468,t:1527628112174};\\\", \\\"{x:1417,y:467,t:1527628112349};\\\", \\\"{x:1417,y:463,t:1527628112365};\\\", \\\"{x:1417,y:462,t:1527628112372};\\\", \\\"{x:1416,y:459,t:1527628112391};\\\", \\\"{x:1416,y:457,t:1527628112406};\\\", \\\"{x:1416,y:456,t:1527628112533};\\\", \\\"{x:1415,y:456,t:1527628113310};\\\", \\\"{x:1415,y:462,t:1527628113325};\\\", \\\"{x:1419,y:469,t:1527628113340};\\\", \\\"{x:1423,y:478,t:1527628113357};\\\", \\\"{x:1426,y:484,t:1527628113374};\\\", \\\"{x:1427,y:491,t:1527628113391};\\\", \\\"{x:1431,y:501,t:1527628113407};\\\", \\\"{x:1432,y:515,t:1527628113424};\\\", \\\"{x:1437,y:532,t:1527628113441};\\\", \\\"{x:1442,y:554,t:1527628113457};\\\", \\\"{x:1449,y:576,t:1527628113474};\\\", \\\"{x:1458,y:596,t:1527628113491};\\\", \\\"{x:1462,y:610,t:1527628113507};\\\", \\\"{x:1465,y:618,t:1527628113525};\\\", \\\"{x:1474,y:645,t:1527628113540};\\\", \\\"{x:1478,y:659,t:1527628113557};\\\", \\\"{x:1483,y:672,t:1527628113575};\\\", \\\"{x:1486,y:680,t:1527628113591};\\\", \\\"{x:1487,y:688,t:1527628113607};\\\", \\\"{x:1489,y:691,t:1527628113624};\\\", \\\"{x:1490,y:695,t:1527628113641};\\\", \\\"{x:1490,y:698,t:1527628113657};\\\", \\\"{x:1492,y:700,t:1527628113674};\\\", \\\"{x:1492,y:703,t:1527628113691};\\\", \\\"{x:1492,y:705,t:1527628113707};\\\", \\\"{x:1492,y:707,t:1527628113724};\\\", \\\"{x:1493,y:716,t:1527628113741};\\\", \\\"{x:1495,y:721,t:1527628113757};\\\", \\\"{x:1495,y:731,t:1527628113774};\\\", \\\"{x:1495,y:742,t:1527628113791};\\\", \\\"{x:1494,y:757,t:1527628113807};\\\", \\\"{x:1483,y:786,t:1527628113823};\\\", \\\"{x:1474,y:816,t:1527628113840};\\\", \\\"{x:1449,y:864,t:1527628113858};\\\", \\\"{x:1421,y:904,t:1527628113874};\\\", \\\"{x:1388,y:939,t:1527628113891};\\\", \\\"{x:1335,y:979,t:1527628113908};\\\", \\\"{x:1294,y:1005,t:1527628113924};\\\", \\\"{x:1180,y:1054,t:1527628113940};\\\", \\\"{x:1096,y:1069,t:1527628113958};\\\", \\\"{x:1012,y:1072,t:1527628113974};\\\", \\\"{x:987,y:1073,t:1527628113991};\\\", \\\"{x:978,y:1071,t:1527628114008};\\\", \\\"{x:958,y:1066,t:1527628114024};\\\", \\\"{x:936,y:1056,t:1527628114041};\\\", \\\"{x:910,y:1041,t:1527628114058};\\\", \\\"{x:874,y:1019,t:1527628114073};\\\", \\\"{x:818,y:994,t:1527628114091};\\\", \\\"{x:764,y:963,t:1527628114108};\\\", \\\"{x:727,y:943,t:1527628114124};\\\", \\\"{x:680,y:929,t:1527628114141};\\\", \\\"{x:669,y:925,t:1527628114158};\\\", \\\"{x:669,y:924,t:1527628114182};\\\", \\\"{x:668,y:922,t:1527628114191};\\\", \\\"{x:664,y:913,t:1527628114208};\\\", \\\"{x:659,y:903,t:1527628114223};\\\", \\\"{x:650,y:885,t:1527628114241};\\\", \\\"{x:641,y:870,t:1527628114258};\\\", \\\"{x:632,y:857,t:1527628114275};\\\", \\\"{x:624,y:844,t:1527628114291};\\\", \\\"{x:617,y:834,t:1527628114308};\\\", \\\"{x:611,y:818,t:1527628114324};\\\", \\\"{x:606,y:805,t:1527628114341};\\\", \\\"{x:600,y:793,t:1527628114358};\\\", \\\"{x:594,y:779,t:1527628114374};\\\", \\\"{x:589,y:770,t:1527628114391};\\\", \\\"{x:583,y:761,t:1527628114408};\\\", \\\"{x:577,y:755,t:1527628114425};\\\", \\\"{x:573,y:750,t:1527628114441};\\\", \\\"{x:562,y:738,t:1527628114458};\\\", \\\"{x:549,y:726,t:1527628114476};\\\", \\\"{x:542,y:721,t:1527628114490};\\\", \\\"{x:534,y:713,t:1527628114507};\\\", \\\"{x:534,y:712,t:1527628114523};\\\", \\\"{x:532,y:711,t:1527628114541};\\\", \\\"{x:534,y:704,t:1527628116141};\\\", \\\"{x:537,y:698,t:1527628116149};\\\", \\\"{x:538,y:694,t:1527628116159};\\\", \\\"{x:549,y:678,t:1527628116176};\\\", \\\"{x:557,y:664,t:1527628116192};\\\", \\\"{x:558,y:663,t:1527628116209};\\\", \\\"{x:559,y:661,t:1527628116225};\\\", \\\"{x:562,y:656,t:1527628116242};\\\", \\\"{x:565,y:651,t:1527628116258};\\\", \\\"{x:566,y:648,t:1527628116276};\\\", \\\"{x:567,y:648,t:1527628116291};\\\", \\\"{x:568,y:648,t:1527628116941};\\\", \\\"{x:568,y:656,t:1527628116957};\\\", \\\"{x:566,y:667,t:1527628116975};\\\", \\\"{x:562,y:689,t:1527628116993};\\\", \\\"{x:554,y:707,t:1527628117010};\\\", \\\"{x:550,y:733,t:1527628117026};\\\", \\\"{x:541,y:751,t:1527628117043};\\\", \\\"{x:541,y:757,t:1527628117059};\\\", \\\"{x:541,y:760,t:1527628117075};\\\", \\\"{x:540,y:755,t:1527628117397};\\\", \\\"{x:539,y:747,t:1527628117410};\\\", \\\"{x:536,y:733,t:1527628117427};\\\", \\\"{x:535,y:722,t:1527628117442};\\\", \\\"{x:534,y:717,t:1527628117460};\\\", \\\"{x:534,y:716,t:1527628117476};\\\", \\\"{x:534,y:715,t:1527628117492};\\\", \\\"{x:532,y:712,t:1527628117556};\\\", \\\"{x:532,y:711,t:1527628117564};\\\", \\\"{x:532,y:709,t:1527628117576};\\\", \\\"{x:532,y:707,t:1527628117593};\\\", \\\"{x:532,y:706,t:1527628117653};\\\", \\\"{x:530,y:706,t:1527628118069};\\\", \\\"{x:527,y:710,t:1527628118076};\\\", \\\"{x:519,y:719,t:1527628118093};\\\", \\\"{x:513,y:725,t:1527628118111};\\\", \\\"{x:510,y:726,t:1527628118125};\\\", \\\"{x:510,y:727,t:1527628118172};\\\", \\\"{x:507,y:727,t:1527628119516};\\\", \\\"{x:485,y:717,t:1527628119528};\\\", \\\"{x:423,y:686,t:1527628119544};\\\", \\\"{x:337,y:657,t:1527628119562};\\\", \\\"{x:228,y:624,t:1527628119577};\\\", \\\"{x:143,y:589,t:1527628119594};\\\", \\\"{x:101,y:553,t:1527628119611};\\\", \\\"{x:98,y:549,t:1527628119628};\\\", \\\"{x:97,y:548,t:1527628119676};\\\", \\\"{x:96,y:547,t:1527628119692};\\\", \\\"{x:96,y:546,t:1527628119708};\\\", \\\"{x:95,y:546,t:1527628119716};\\\", \\\"{x:95,y:545,t:1527628119727};\\\", \\\"{x:95,y:543,t:1527628119745};\\\", \\\"{x:95,y:541,t:1527628119763};\\\", \\\"{x:95,y:540,t:1527628119780};\\\", \\\"{x:95,y:537,t:1527628119795};\\\", \\\"{x:95,y:535,t:1527628119811};\\\", \\\"{x:97,y:533,t:1527628120188};\\\", \\\"{x:97,y:532,t:1527628120196};\\\", \\\"{x:98,y:530,t:1527628120212};\\\", \\\"{x:99,y:529,t:1527628120244};\\\", \\\"{x:99,y:528,t:1527628120260};\\\" ] }, { \\\"rt\\\": 17888, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 388156, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -A -Z -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:102,y:523,t:1527628120453};\\\", \\\"{x:102,y:522,t:1527628121420};\\\", \\\"{x:103,y:522,t:1527628121451};\\\", \\\"{x:104,y:522,t:1527628121462};\\\", \\\"{x:105,y:520,t:1527628122020};\\\", \\\"{x:106,y:520,t:1527628122030};\\\", \\\"{x:113,y:516,t:1527628122047};\\\", \\\"{x:117,y:514,t:1527628122064};\\\", \\\"{x:121,y:511,t:1527628122080};\\\", \\\"{x:142,y:508,t:1527628122097};\\\", \\\"{x:162,y:503,t:1527628122115};\\\", \\\"{x:177,y:500,t:1527628122130};\\\", \\\"{x:199,y:496,t:1527628122146};\\\", \\\"{x:210,y:493,t:1527628122162};\\\", \\\"{x:217,y:491,t:1527628122179};\\\", \\\"{x:220,y:491,t:1527628122196};\\\", \\\"{x:221,y:490,t:1527628122212};\\\", \\\"{x:222,y:490,t:1527628122236};\\\", \\\"{x:223,y:490,t:1527628122246};\\\", \\\"{x:225,y:489,t:1527628122262};\\\", \\\"{x:235,y:489,t:1527628122279};\\\", \\\"{x:253,y:489,t:1527628122296};\\\", \\\"{x:272,y:489,t:1527628122312};\\\", \\\"{x:282,y:489,t:1527628122329};\\\", \\\"{x:297,y:487,t:1527628122346};\\\", \\\"{x:313,y:487,t:1527628122362};\\\", \\\"{x:323,y:487,t:1527628122379};\\\", \\\"{x:330,y:487,t:1527628122396};\\\", \\\"{x:330,y:488,t:1527628122412};\\\", \\\"{x:330,y:489,t:1527628122773};\\\", \\\"{x:329,y:491,t:1527628122780};\\\", \\\"{x:330,y:501,t:1527628122796};\\\", \\\"{x:332,y:507,t:1527628122814};\\\", \\\"{x:333,y:512,t:1527628122828};\\\", \\\"{x:334,y:515,t:1527628122847};\\\", \\\"{x:334,y:516,t:1527628122864};\\\", \\\"{x:336,y:516,t:1527628124029};\\\", \\\"{x:338,y:516,t:1527628124036};\\\", \\\"{x:342,y:515,t:1527628124049};\\\", \\\"{x:347,y:513,t:1527628124065};\\\", \\\"{x:353,y:511,t:1527628124083};\\\", \\\"{x:356,y:510,t:1527628124099};\\\", \\\"{x:361,y:507,t:1527628124116};\\\", \\\"{x:368,y:503,t:1527628124133};\\\", \\\"{x:376,y:499,t:1527628124149};\\\", \\\"{x:388,y:493,t:1527628124165};\\\", \\\"{x:401,y:488,t:1527628124182};\\\", \\\"{x:416,y:487,t:1527628124198};\\\", \\\"{x:428,y:484,t:1527628124215};\\\", \\\"{x:447,y:481,t:1527628124232};\\\", \\\"{x:453,y:479,t:1527628124249};\\\", \\\"{x:458,y:479,t:1527628124265};\\\", \\\"{x:461,y:478,t:1527628124282};\\\", \\\"{x:465,y:477,t:1527628124299};\\\", \\\"{x:467,y:476,t:1527628124315};\\\", \\\"{x:472,y:475,t:1527628124331};\\\", \\\"{x:477,y:475,t:1527628124349};\\\", \\\"{x:481,y:475,t:1527628124365};\\\", \\\"{x:482,y:475,t:1527628124382};\\\", \\\"{x:483,y:475,t:1527628124400};\\\", \\\"{x:484,y:475,t:1527628124637};\\\", \\\"{x:486,y:475,t:1527628124649};\\\", \\\"{x:491,y:475,t:1527628124665};\\\", \\\"{x:498,y:475,t:1527628124683};\\\", \\\"{x:505,y:477,t:1527628124699};\\\", \\\"{x:524,y:482,t:1527628124716};\\\", \\\"{x:545,y:486,t:1527628124732};\\\", \\\"{x:576,y:494,t:1527628124750};\\\", \\\"{x:618,y:507,t:1527628124768};\\\", \\\"{x:661,y:522,t:1527628124782};\\\", \\\"{x:727,y:538,t:1527628124800};\\\", \\\"{x:779,y:549,t:1527628124817};\\\", \\\"{x:819,y:556,t:1527628124832};\\\", \\\"{x:848,y:565,t:1527628124850};\\\", \\\"{x:872,y:572,t:1527628124867};\\\", \\\"{x:894,y:582,t:1527628124884};\\\", \\\"{x:918,y:590,t:1527628124899};\\\", \\\"{x:946,y:600,t:1527628124916};\\\", \\\"{x:960,y:607,t:1527628124934};\\\", \\\"{x:974,y:616,t:1527628124950};\\\", \\\"{x:985,y:621,t:1527628124967};\\\", \\\"{x:994,y:627,t:1527628124984};\\\", \\\"{x:1001,y:634,t:1527628124999};\\\", \\\"{x:1011,y:638,t:1527628125017};\\\", \\\"{x:1018,y:642,t:1527628125034};\\\", \\\"{x:1022,y:646,t:1527628125049};\\\", \\\"{x:1026,y:648,t:1527628125066};\\\", \\\"{x:1031,y:651,t:1527628125084};\\\", \\\"{x:1033,y:654,t:1527628125100};\\\", \\\"{x:1039,y:657,t:1527628125117};\\\", \\\"{x:1043,y:657,t:1527628125133};\\\", \\\"{x:1046,y:659,t:1527628125533};\\\", \\\"{x:1053,y:664,t:1527628125551};\\\", \\\"{x:1069,y:667,t:1527628125567};\\\", \\\"{x:1079,y:672,t:1527628125583};\\\", \\\"{x:1087,y:677,t:1527628125600};\\\", \\\"{x:1090,y:680,t:1527628125616};\\\", \\\"{x:1097,y:684,t:1527628125633};\\\", \\\"{x:1113,y:690,t:1527628125650};\\\", \\\"{x:1131,y:700,t:1527628125667};\\\", \\\"{x:1141,y:705,t:1527628125683};\\\", \\\"{x:1166,y:718,t:1527628125699};\\\", \\\"{x:1178,y:723,t:1527628125717};\\\", \\\"{x:1183,y:728,t:1527628125733};\\\", \\\"{x:1187,y:731,t:1527628125750};\\\", \\\"{x:1190,y:733,t:1527628125767};\\\", \\\"{x:1192,y:735,t:1527628125796};\\\", \\\"{x:1192,y:736,t:1527628125804};\\\", \\\"{x:1193,y:736,t:1527628125817};\\\", \\\"{x:1193,y:740,t:1527628125833};\\\", \\\"{x:1196,y:744,t:1527628125850};\\\", \\\"{x:1197,y:744,t:1527628125867};\\\", \\\"{x:1199,y:747,t:1527628125884};\\\", \\\"{x:1200,y:750,t:1527628125899};\\\", \\\"{x:1200,y:751,t:1527628125917};\\\", \\\"{x:1200,y:753,t:1527628125934};\\\", \\\"{x:1201,y:756,t:1527628125950};\\\", \\\"{x:1202,y:759,t:1527628125968};\\\", \\\"{x:1203,y:763,t:1527628125985};\\\", \\\"{x:1204,y:765,t:1527628126001};\\\", \\\"{x:1205,y:766,t:1527628126017};\\\", \\\"{x:1205,y:767,t:1527628126034};\\\", \\\"{x:1206,y:767,t:1527628126050};\\\", \\\"{x:1206,y:769,t:1527628126067};\\\", \\\"{x:1207,y:771,t:1527628126084};\\\", \\\"{x:1208,y:775,t:1527628126100};\\\", \\\"{x:1209,y:776,t:1527628126118};\\\", \\\"{x:1210,y:777,t:1527628126135};\\\", \\\"{x:1210,y:778,t:1527628126151};\\\", \\\"{x:1211,y:780,t:1527628126325};\\\", \\\"{x:1213,y:781,t:1527628126356};\\\", \\\"{x:1213,y:782,t:1527628126368};\\\", \\\"{x:1213,y:784,t:1527628126384};\\\", \\\"{x:1214,y:785,t:1527628126404};\\\", \\\"{x:1215,y:787,t:1527628126437};\\\", \\\"{x:1215,y:788,t:1527628126469};\\\", \\\"{x:1216,y:788,t:1527628126484};\\\", \\\"{x:1216,y:790,t:1527628126508};\\\", \\\"{x:1217,y:791,t:1527628126517};\\\", \\\"{x:1218,y:794,t:1527628126534};\\\", \\\"{x:1219,y:796,t:1527628126551};\\\", \\\"{x:1220,y:797,t:1527628126568};\\\", \\\"{x:1220,y:798,t:1527628127348};\\\", \\\"{x:1220,y:799,t:1527628127372};\\\", \\\"{x:1220,y:800,t:1527628127387};\\\", \\\"{x:1220,y:801,t:1527628127404};\\\", \\\"{x:1220,y:802,t:1527628127418};\\\", \\\"{x:1219,y:804,t:1527628127436};\\\", \\\"{x:1218,y:806,t:1527628127452};\\\", \\\"{x:1218,y:807,t:1527628127484};\\\", \\\"{x:1216,y:810,t:1527628127492};\\\", \\\"{x:1215,y:810,t:1527628127502};\\\", \\\"{x:1215,y:814,t:1527628127520};\\\", \\\"{x:1215,y:816,t:1527628127535};\\\", \\\"{x:1215,y:820,t:1527628127553};\\\", \\\"{x:1215,y:822,t:1527628127569};\\\", \\\"{x:1213,y:824,t:1527628127586};\\\", \\\"{x:1213,y:825,t:1527628127605};\\\", \\\"{x:1212,y:827,t:1527628127619};\\\", \\\"{x:1212,y:829,t:1527628127636};\\\", \\\"{x:1211,y:830,t:1527628127660};\\\", \\\"{x:1211,y:832,t:1527628128165};\\\", \\\"{x:1211,y:833,t:1527628128196};\\\", \\\"{x:1211,y:835,t:1527628128205};\\\", \\\"{x:1211,y:836,t:1527628128221};\\\", \\\"{x:1211,y:837,t:1527628128236};\\\", \\\"{x:1211,y:838,t:1527628128254};\\\", \\\"{x:1212,y:840,t:1527628128269};\\\", \\\"{x:1213,y:840,t:1527628128287};\\\", \\\"{x:1213,y:841,t:1527628128303};\\\", \\\"{x:1213,y:842,t:1527628128320};\\\", \\\"{x:1214,y:843,t:1527628128337};\\\", \\\"{x:1214,y:845,t:1527628128357};\\\", \\\"{x:1214,y:846,t:1527628128372};\\\", \\\"{x:1214,y:847,t:1527628128388};\\\", \\\"{x:1214,y:848,t:1527628128404};\\\", \\\"{x:1215,y:849,t:1527628128420};\\\", \\\"{x:1216,y:850,t:1527628128453};\\\", \\\"{x:1216,y:851,t:1527628128471};\\\", \\\"{x:1216,y:852,t:1527628128492};\\\", \\\"{x:1217,y:853,t:1527628128504};\\\", \\\"{x:1217,y:855,t:1527628128524};\\\", \\\"{x:1217,y:857,t:1527628128541};\\\", \\\"{x:1218,y:858,t:1527628128556};\\\", \\\"{x:1218,y:860,t:1527628128580};\\\", \\\"{x:1219,y:861,t:1527628128588};\\\", \\\"{x:1221,y:862,t:1527628128604};\\\", \\\"{x:1223,y:864,t:1527628128620};\\\", \\\"{x:1223,y:865,t:1527628128661};\\\", \\\"{x:1223,y:866,t:1527628128685};\\\", \\\"{x:1223,y:867,t:1527628128709};\\\", \\\"{x:1224,y:867,t:1527628128772};\\\", \\\"{x:1224,y:868,t:1527628128787};\\\", \\\"{x:1225,y:868,t:1527628128804};\\\", \\\"{x:1225,y:869,t:1527628128820};\\\", \\\"{x:1226,y:871,t:1527628128838};\\\", \\\"{x:1226,y:872,t:1527628128949};\\\", \\\"{x:1226,y:873,t:1527628128957};\\\", \\\"{x:1227,y:873,t:1527628128972};\\\", \\\"{x:1227,y:874,t:1527628129021};\\\", \\\"{x:1227,y:875,t:1527628129037};\\\", \\\"{x:1228,y:875,t:1527628129055};\\\", \\\"{x:1229,y:877,t:1527628129085};\\\", \\\"{x:1229,y:878,t:1527628129093};\\\", \\\"{x:1230,y:879,t:1527628129389};\\\", \\\"{x:1231,y:880,t:1527628129461};\\\", \\\"{x:1232,y:881,t:1527628129549};\\\", \\\"{x:1231,y:880,t:1527628129828};\\\", \\\"{x:1227,y:878,t:1527628129839};\\\", \\\"{x:1221,y:874,t:1527628129855};\\\", \\\"{x:1213,y:868,t:1527628129871};\\\", \\\"{x:1209,y:865,t:1527628129889};\\\", \\\"{x:1205,y:864,t:1527628129905};\\\", \\\"{x:1204,y:863,t:1527628129922};\\\", \\\"{x:1203,y:862,t:1527628129939};\\\", \\\"{x:1202,y:861,t:1527628129972};\\\", \\\"{x:1200,y:859,t:1527628130004};\\\", \\\"{x:1199,y:858,t:1527628130068};\\\", \\\"{x:1198,y:857,t:1527628130083};\\\", \\\"{x:1198,y:856,t:1527628130092};\\\", \\\"{x:1197,y:856,t:1527628130108};\\\", \\\"{x:1196,y:856,t:1527628130124};\\\", \\\"{x:1196,y:855,t:1527628130138};\\\", \\\"{x:1193,y:855,t:1527628130155};\\\", \\\"{x:1191,y:855,t:1527628130549};\\\", \\\"{x:1191,y:854,t:1527628131045};\\\", \\\"{x:1191,y:852,t:1527628131057};\\\", \\\"{x:1191,y:848,t:1527628131072};\\\", \\\"{x:1193,y:845,t:1527628131090};\\\", \\\"{x:1195,y:842,t:1527628131107};\\\", \\\"{x:1197,y:839,t:1527628131123};\\\", \\\"{x:1199,y:838,t:1527628131140};\\\", \\\"{x:1199,y:837,t:1527628131156};\\\", \\\"{x:1200,y:835,t:1527628131173};\\\", \\\"{x:1202,y:834,t:1527628131197};\\\", \\\"{x:1203,y:832,t:1527628131207};\\\", \\\"{x:1205,y:832,t:1527628131223};\\\", \\\"{x:1206,y:831,t:1527628131240};\\\", \\\"{x:1207,y:830,t:1527628131257};\\\", \\\"{x:1209,y:829,t:1527628131274};\\\", \\\"{x:1213,y:827,t:1527628131290};\\\", \\\"{x:1220,y:826,t:1527628131308};\\\", \\\"{x:1226,y:825,t:1527628131324};\\\", \\\"{x:1232,y:822,t:1527628131341};\\\", \\\"{x:1236,y:822,t:1527628131357};\\\", \\\"{x:1238,y:820,t:1527628131374};\\\", \\\"{x:1240,y:820,t:1527628131390};\\\", \\\"{x:1241,y:818,t:1527628131407};\\\", \\\"{x:1244,y:818,t:1527628131424};\\\", \\\"{x:1248,y:818,t:1527628131440};\\\", \\\"{x:1253,y:818,t:1527628131457};\\\", \\\"{x:1261,y:818,t:1527628131473};\\\", \\\"{x:1268,y:818,t:1527628131490};\\\", \\\"{x:1275,y:819,t:1527628131507};\\\", \\\"{x:1281,y:820,t:1527628131524};\\\", \\\"{x:1284,y:821,t:1527628131540};\\\", \\\"{x:1287,y:822,t:1527628131557};\\\", \\\"{x:1289,y:822,t:1527628131574};\\\", \\\"{x:1290,y:823,t:1527628131612};\\\", \\\"{x:1291,y:823,t:1527628131623};\\\", \\\"{x:1292,y:824,t:1527628131641};\\\", \\\"{x:1293,y:824,t:1527628131668};\\\", \\\"{x:1293,y:825,t:1527628132029};\\\", \\\"{x:1293,y:826,t:1527628132139};\\\", \\\"{x:1293,y:827,t:1527628132276};\\\", \\\"{x:1293,y:828,t:1527628132290};\\\", \\\"{x:1293,y:829,t:1527628132308};\\\", \\\"{x:1293,y:830,t:1527628132326};\\\", \\\"{x:1292,y:831,t:1527628132341};\\\", \\\"{x:1291,y:832,t:1527628132358};\\\", \\\"{x:1290,y:832,t:1527628132604};\\\", \\\"{x:1296,y:832,t:1527628133012};\\\", \\\"{x:1302,y:834,t:1527628133025};\\\", \\\"{x:1311,y:836,t:1527628133042};\\\", \\\"{x:1326,y:839,t:1527628133059};\\\", \\\"{x:1335,y:840,t:1527628133075};\\\", \\\"{x:1339,y:842,t:1527628133092};\\\", \\\"{x:1343,y:843,t:1527628133108};\\\", \\\"{x:1343,y:842,t:1527628133852};\\\", \\\"{x:1343,y:841,t:1527628133861};\\\", \\\"{x:1343,y:838,t:1527628133876};\\\", \\\"{x:1343,y:836,t:1527628133893};\\\", \\\"{x:1343,y:835,t:1527628133910};\\\", \\\"{x:1343,y:834,t:1527628133926};\\\", \\\"{x:1343,y:836,t:1527628134108};\\\", \\\"{x:1342,y:841,t:1527628134116};\\\", \\\"{x:1342,y:845,t:1527628134127};\\\", \\\"{x:1342,y:850,t:1527628134142};\\\", \\\"{x:1343,y:856,t:1527628134160};\\\", \\\"{x:1343,y:861,t:1527628134177};\\\", \\\"{x:1344,y:869,t:1527628134192};\\\", \\\"{x:1347,y:873,t:1527628134209};\\\", \\\"{x:1347,y:874,t:1527628134226};\\\", \\\"{x:1348,y:880,t:1527628134242};\\\", \\\"{x:1350,y:886,t:1527628134260};\\\", \\\"{x:1351,y:891,t:1527628134276};\\\", \\\"{x:1352,y:893,t:1527628134293};\\\", \\\"{x:1353,y:894,t:1527628134309};\\\", \\\"{x:1357,y:896,t:1527628134328};\\\", \\\"{x:1358,y:899,t:1527628134344};\\\", \\\"{x:1358,y:900,t:1527628134359};\\\", \\\"{x:1358,y:903,t:1527628134377};\\\", \\\"{x:1358,y:904,t:1527628134394};\\\", \\\"{x:1358,y:905,t:1527628134410};\\\", \\\"{x:1359,y:906,t:1527628134427};\\\", \\\"{x:1359,y:907,t:1527628134452};\\\", \\\"{x:1361,y:909,t:1527628134460};\\\", \\\"{x:1362,y:909,t:1527628134557};\\\", \\\"{x:1362,y:910,t:1527628134564};\\\", \\\"{x:1362,y:912,t:1527628134577};\\\", \\\"{x:1363,y:916,t:1527628134596};\\\", \\\"{x:1364,y:918,t:1527628134612};\\\", \\\"{x:1364,y:919,t:1527628134627};\\\", \\\"{x:1364,y:924,t:1527628134644};\\\", \\\"{x:1364,y:928,t:1527628134661};\\\", \\\"{x:1364,y:929,t:1527628134676};\\\", \\\"{x:1364,y:931,t:1527628134694};\\\", \\\"{x:1364,y:932,t:1527628134712};\\\", \\\"{x:1364,y:933,t:1527628134757};\\\", \\\"{x:1364,y:934,t:1527628134773};\\\", \\\"{x:1364,y:935,t:1527628134812};\\\", \\\"{x:1364,y:936,t:1527628134861};\\\", \\\"{x:1364,y:937,t:1527628134892};\\\", \\\"{x:1364,y:938,t:1527628134948};\\\", \\\"{x:1364,y:939,t:1527628134973};\\\", \\\"{x:1364,y:942,t:1527628135036};\\\", \\\"{x:1364,y:943,t:1527628135108};\\\", \\\"{x:1364,y:942,t:1527628135437};\\\", \\\"{x:1364,y:941,t:1527628135444};\\\", \\\"{x:1364,y:940,t:1527628135461};\\\", \\\"{x:1364,y:938,t:1527628135478};\\\", \\\"{x:1364,y:932,t:1527628135495};\\\", \\\"{x:1357,y:924,t:1527628135511};\\\", \\\"{x:1347,y:914,t:1527628135528};\\\", \\\"{x:1328,y:900,t:1527628135545};\\\", \\\"{x:1292,y:883,t:1527628135561};\\\", \\\"{x:1257,y:864,t:1527628135578};\\\", \\\"{x:1215,y:841,t:1527628135595};\\\", \\\"{x:1144,y:809,t:1527628135612};\\\", \\\"{x:1117,y:789,t:1527628135628};\\\", \\\"{x:1097,y:774,t:1527628135645};\\\", \\\"{x:1077,y:760,t:1527628135662};\\\", \\\"{x:1061,y:745,t:1527628135678};\\\", \\\"{x:1054,y:738,t:1527628135695};\\\", \\\"{x:1046,y:731,t:1527628135712};\\\", \\\"{x:1038,y:726,t:1527628135728};\\\", \\\"{x:1027,y:718,t:1527628135745};\\\", \\\"{x:1011,y:711,t:1527628135762};\\\", \\\"{x:980,y:702,t:1527628135777};\\\", \\\"{x:939,y:692,t:1527628135794};\\\", \\\"{x:871,y:677,t:1527628135811};\\\", \\\"{x:836,y:665,t:1527628135827};\\\", \\\"{x:816,y:657,t:1527628135844};\\\", \\\"{x:800,y:649,t:1527628135861};\\\", \\\"{x:784,y:647,t:1527628135877};\\\", \\\"{x:771,y:643,t:1527628135895};\\\", \\\"{x:757,y:638,t:1527628135912};\\\", \\\"{x:748,y:633,t:1527628135929};\\\", \\\"{x:738,y:630,t:1527628135944};\\\", \\\"{x:734,y:629,t:1527628135961};\\\", \\\"{x:733,y:629,t:1527628135979};\\\", \\\"{x:732,y:629,t:1527628135995};\\\", \\\"{x:728,y:630,t:1527628136292};\\\", \\\"{x:701,y:631,t:1527628136301};\\\", \\\"{x:662,y:631,t:1527628136311};\\\", \\\"{x:574,y:631,t:1527628136328};\\\", \\\"{x:495,y:629,t:1527628136343};\\\", \\\"{x:449,y:627,t:1527628136358};\\\", \\\"{x:408,y:622,t:1527628136376};\\\", \\\"{x:359,y:620,t:1527628136392};\\\", \\\"{x:327,y:613,t:1527628136408};\\\", \\\"{x:303,y:608,t:1527628136425};\\\", \\\"{x:280,y:607,t:1527628136442};\\\", \\\"{x:259,y:603,t:1527628136459};\\\", \\\"{x:229,y:601,t:1527628136475};\\\", \\\"{x:215,y:599,t:1527628136492};\\\", \\\"{x:196,y:599,t:1527628136508};\\\", \\\"{x:190,y:599,t:1527628136526};\\\", \\\"{x:187,y:598,t:1527628136542};\\\", \\\"{x:186,y:598,t:1527628136558};\\\", \\\"{x:185,y:598,t:1527628136661};\\\", \\\"{x:184,y:598,t:1527628136724};\\\", \\\"{x:183,y:598,t:1527628136732};\\\", \\\"{x:182,y:598,t:1527628136742};\\\", \\\"{x:175,y:598,t:1527628136759};\\\", \\\"{x:166,y:598,t:1527628136775};\\\", \\\"{x:161,y:598,t:1527628136791};\\\", \\\"{x:154,y:595,t:1527628136809};\\\", \\\"{x:149,y:592,t:1527628136825};\\\", \\\"{x:144,y:588,t:1527628136841};\\\", \\\"{x:143,y:587,t:1527628136858};\\\", \\\"{x:141,y:583,t:1527628136875};\\\", \\\"{x:141,y:582,t:1527628136892};\\\", \\\"{x:141,y:580,t:1527628136909};\\\", \\\"{x:140,y:579,t:1527628136925};\\\", \\\"{x:140,y:578,t:1527628136979};\\\", \\\"{x:140,y:577,t:1527628136993};\\\", \\\"{x:140,y:576,t:1527628137009};\\\", \\\"{x:140,y:574,t:1527628137028};\\\", \\\"{x:140,y:573,t:1527628137042};\\\", \\\"{x:141,y:571,t:1527628137059};\\\", \\\"{x:142,y:570,t:1527628137075};\\\", \\\"{x:142,y:569,t:1527628137100};\\\", \\\"{x:143,y:566,t:1527628137110};\\\", \\\"{x:146,y:564,t:1527628137125};\\\", \\\"{x:148,y:562,t:1527628137142};\\\", \\\"{x:150,y:560,t:1527628137161};\\\", \\\"{x:150,y:559,t:1527628137176};\\\", \\\"{x:151,y:559,t:1527628137323};\\\", \\\"{x:154,y:560,t:1527628137331};\\\", \\\"{x:160,y:565,t:1527628137343};\\\", \\\"{x:173,y:577,t:1527628137359};\\\", \\\"{x:190,y:589,t:1527628137377};\\\", \\\"{x:213,y:604,t:1527628137392};\\\", \\\"{x:246,y:619,t:1527628137410};\\\", \\\"{x:284,y:639,t:1527628137427};\\\", \\\"{x:300,y:649,t:1527628137442};\\\", \\\"{x:344,y:665,t:1527628137460};\\\", \\\"{x:360,y:672,t:1527628137476};\\\", \\\"{x:371,y:677,t:1527628137493};\\\", \\\"{x:388,y:686,t:1527628137510};\\\", \\\"{x:398,y:690,t:1527628137526};\\\", \\\"{x:404,y:694,t:1527628137542};\\\", \\\"{x:408,y:697,t:1527628137560};\\\", \\\"{x:410,y:698,t:1527628137576};\\\", \\\"{x:411,y:700,t:1527628137592};\\\", \\\"{x:415,y:706,t:1527628137609};\\\", \\\"{x:422,y:715,t:1527628137627};\\\", \\\"{x:427,y:719,t:1527628137643};\\\", \\\"{x:433,y:723,t:1527628137660};\\\", \\\"{x:436,y:725,t:1527628137677};\\\", \\\"{x:438,y:726,t:1527628137700};\\\", \\\"{x:439,y:726,t:1527628137709};\\\", \\\"{x:442,y:727,t:1527628137727};\\\", \\\"{x:450,y:729,t:1527628137744};\\\", \\\"{x:454,y:729,t:1527628137760};\\\", \\\"{x:455,y:729,t:1527628137776};\\\", \\\"{x:456,y:729,t:1527628137793};\\\", \\\"{x:458,y:729,t:1527628137843};\\\", \\\"{x:459,y:729,t:1527628137876};\\\", \\\"{x:460,y:729,t:1527628138395};\\\", \\\"{x:459,y:728,t:1527628138589};\\\", \\\"{x:456,y:728,t:1527628138596};\\\", \\\"{x:452,y:728,t:1527628138611};\\\", \\\"{x:427,y:723,t:1527628138628};\\\", \\\"{x:407,y:719,t:1527628138644};\\\", \\\"{x:388,y:715,t:1527628138661};\\\", \\\"{x:362,y:714,t:1527628138678};\\\", \\\"{x:339,y:707,t:1527628138693};\\\", \\\"{x:317,y:703,t:1527628138711};\\\", \\\"{x:295,y:696,t:1527628138728};\\\", \\\"{x:279,y:687,t:1527628138743};\\\", \\\"{x:255,y:679,t:1527628138760};\\\", \\\"{x:238,y:674,t:1527628138777};\\\", \\\"{x:229,y:669,t:1527628138793};\\\", \\\"{x:226,y:666,t:1527628138810};\\\", \\\"{x:224,y:665,t:1527628138828};\\\", \\\"{x:223,y:663,t:1527628138843};\\\", \\\"{x:221,y:659,t:1527628138860};\\\", \\\"{x:220,y:654,t:1527628138878};\\\", \\\"{x:217,y:648,t:1527628138893};\\\", \\\"{x:215,y:643,t:1527628138911};\\\", \\\"{x:212,y:639,t:1527628138927};\\\", \\\"{x:209,y:636,t:1527628138944};\\\", \\\"{x:206,y:631,t:1527628138961};\\\", \\\"{x:203,y:627,t:1527628138978};\\\", \\\"{x:202,y:627,t:1527628138995};\\\", \\\"{x:201,y:624,t:1527628139020};\\\", \\\"{x:200,y:622,t:1527628139028};\\\", \\\"{x:198,y:618,t:1527628139044};\\\", \\\"{x:195,y:602,t:1527628139060};\\\", \\\"{x:189,y:589,t:1527628139078};\\\", \\\"{x:188,y:585,t:1527628139095};\\\", \\\"{x:188,y:584,t:1527628139111};\\\", \\\"{x:186,y:579,t:1527628139127};\\\", \\\"{x:185,y:575,t:1527628139144};\\\", \\\"{x:184,y:571,t:1527628139160};\\\", \\\"{x:184,y:570,t:1527628139178};\\\", \\\"{x:183,y:568,t:1527628139195};\\\", \\\"{x:182,y:567,t:1527628139210};\\\", \\\"{x:181,y:560,t:1527628139227};\\\", \\\"{x:181,y:558,t:1527628139252};\\\" ] }, { \\\"rt\\\": 38291, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 427661, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"U\\\", \\\"D\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-E -H -01 PM-3\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:181,y:556,t:1527628140140};\\\", \\\"{x:181,y:551,t:1527628140151};\\\", \\\"{x:182,y:548,t:1527628140160};\\\", \\\"{x:186,y:543,t:1527628140177};\\\", \\\"{x:196,y:541,t:1527628140194};\\\", \\\"{x:219,y:525,t:1527628140212};\\\", \\\"{x:226,y:520,t:1527628140229};\\\", \\\"{x:239,y:511,t:1527628140244};\\\", \\\"{x:258,y:502,t:1527628140262};\\\", \\\"{x:276,y:490,t:1527628140278};\\\", \\\"{x:294,y:483,t:1527628140295};\\\", \\\"{x:308,y:479,t:1527628140311};\\\", \\\"{x:325,y:472,t:1527628140328};\\\", \\\"{x:342,y:468,t:1527628140345};\\\", \\\"{x:356,y:463,t:1527628140362};\\\", \\\"{x:365,y:460,t:1527628140378};\\\", \\\"{x:379,y:457,t:1527628140395};\\\", \\\"{x:383,y:457,t:1527628140412};\\\", \\\"{x:386,y:457,t:1527628140429};\\\", \\\"{x:388,y:457,t:1527628140445};\\\", \\\"{x:396,y:459,t:1527628140463};\\\", \\\"{x:404,y:464,t:1527628140479};\\\", \\\"{x:411,y:469,t:1527628140495};\\\", \\\"{x:425,y:476,t:1527628140513};\\\", \\\"{x:436,y:485,t:1527628140529};\\\", \\\"{x:450,y:491,t:1527628140545};\\\", \\\"{x:454,y:494,t:1527628140562};\\\", \\\"{x:461,y:499,t:1527628140796};\\\", \\\"{x:469,y:504,t:1527628140813};\\\", \\\"{x:479,y:513,t:1527628140831};\\\", \\\"{x:486,y:516,t:1527628140847};\\\", \\\"{x:488,y:513,t:1527628141468};\\\", \\\"{x:488,y:510,t:1527628141484};\\\", \\\"{x:488,y:508,t:1527628141495};\\\", \\\"{x:488,y:504,t:1527628141513};\\\", \\\"{x:488,y:500,t:1527628141529};\\\", \\\"{x:488,y:495,t:1527628141545};\\\", \\\"{x:488,y:492,t:1527628141562};\\\", \\\"{x:488,y:486,t:1527628141579};\\\", \\\"{x:488,y:482,t:1527628141597};\\\", \\\"{x:488,y:480,t:1527628141612};\\\", \\\"{x:488,y:478,t:1527628141630};\\\", \\\"{x:488,y:476,t:1527628141647};\\\", \\\"{x:488,y:473,t:1527628141663};\\\", \\\"{x:489,y:471,t:1527628141679};\\\", \\\"{x:489,y:470,t:1527628141696};\\\", \\\"{x:489,y:469,t:1527628141820};\\\", \\\"{x:492,y:466,t:1527628141830};\\\", \\\"{x:494,y:465,t:1527628141884};\\\", \\\"{x:495,y:465,t:1527628141897};\\\", \\\"{x:496,y:465,t:1527628141913};\\\", \\\"{x:496,y:464,t:1527628141932};\\\", \\\"{x:497,y:464,t:1527628141947};\\\", \\\"{x:499,y:463,t:1527628142340};\\\", \\\"{x:502,y:463,t:1527628142347};\\\", \\\"{x:518,y:463,t:1527628142364};\\\", \\\"{x:532,y:463,t:1527628142380};\\\", \\\"{x:537,y:463,t:1527628142396};\\\", \\\"{x:547,y:463,t:1527628142414};\\\", \\\"{x:564,y:463,t:1527628142430};\\\", \\\"{x:587,y:464,t:1527628142447};\\\", \\\"{x:607,y:465,t:1527628142464};\\\", \\\"{x:632,y:465,t:1527628142480};\\\", \\\"{x:660,y:465,t:1527628142496};\\\", \\\"{x:697,y:465,t:1527628142513};\\\", \\\"{x:734,y:466,t:1527628142531};\\\", \\\"{x:796,y:469,t:1527628142546};\\\", \\\"{x:904,y:487,t:1527628142563};\\\", \\\"{x:992,y:506,t:1527628142581};\\\", \\\"{x:1063,y:524,t:1527628142597};\\\", \\\"{x:1140,y:552,t:1527628142613};\\\", \\\"{x:1235,y:583,t:1527628142630};\\\", \\\"{x:1322,y:614,t:1527628142647};\\\", \\\"{x:1386,y:646,t:1527628142664};\\\", \\\"{x:1421,y:662,t:1527628142680};\\\", \\\"{x:1444,y:674,t:1527628142696};\\\", \\\"{x:1465,y:690,t:1527628142714};\\\", \\\"{x:1482,y:701,t:1527628142731};\\\", \\\"{x:1492,y:715,t:1527628142747};\\\", \\\"{x:1506,y:743,t:1527628142764};\\\", \\\"{x:1514,y:761,t:1527628142781};\\\", \\\"{x:1519,y:785,t:1527628142797};\\\", \\\"{x:1524,y:807,t:1527628142814};\\\", \\\"{x:1534,y:836,t:1527628142831};\\\", \\\"{x:1537,y:857,t:1527628142846};\\\", \\\"{x:1540,y:876,t:1527628142863};\\\", \\\"{x:1540,y:890,t:1527628142881};\\\", \\\"{x:1541,y:900,t:1527628142898};\\\", \\\"{x:1541,y:905,t:1527628142914};\\\", \\\"{x:1541,y:907,t:1527628142931};\\\", \\\"{x:1541,y:910,t:1527628142947};\\\", \\\"{x:1541,y:915,t:1527628142964};\\\", \\\"{x:1540,y:919,t:1527628142981};\\\", \\\"{x:1539,y:923,t:1527628142997};\\\", \\\"{x:1538,y:927,t:1527628143013};\\\", \\\"{x:1538,y:928,t:1527628143031};\\\", \\\"{x:1538,y:930,t:1527628143048};\\\", \\\"{x:1539,y:934,t:1527628143064};\\\", \\\"{x:1541,y:936,t:1527628143081};\\\", \\\"{x:1542,y:939,t:1527628143098};\\\", \\\"{x:1544,y:941,t:1527628143115};\\\", \\\"{x:1545,y:943,t:1527628143131};\\\", \\\"{x:1546,y:945,t:1527628143148};\\\", \\\"{x:1547,y:945,t:1527628143164};\\\", \\\"{x:1547,y:946,t:1527628143188};\\\", \\\"{x:1548,y:946,t:1527628143198};\\\", \\\"{x:1550,y:948,t:1527628143214};\\\", \\\"{x:1551,y:948,t:1527628143231};\\\", \\\"{x:1552,y:949,t:1527628143248};\\\", \\\"{x:1554,y:951,t:1527628143264};\\\", \\\"{x:1556,y:952,t:1527628143281};\\\", \\\"{x:1558,y:954,t:1527628143298};\\\", \\\"{x:1560,y:954,t:1527628143315};\\\", \\\"{x:1562,y:956,t:1527628143332};\\\", \\\"{x:1566,y:958,t:1527628143348};\\\", \\\"{x:1571,y:960,t:1527628143365};\\\", \\\"{x:1572,y:962,t:1527628143381};\\\", \\\"{x:1576,y:962,t:1527628143398};\\\", \\\"{x:1580,y:963,t:1527628143415};\\\", \\\"{x:1584,y:965,t:1527628143431};\\\", \\\"{x:1588,y:965,t:1527628143448};\\\", \\\"{x:1590,y:967,t:1527628143466};\\\", \\\"{x:1592,y:967,t:1527628143481};\\\", \\\"{x:1596,y:968,t:1527628143498};\\\", \\\"{x:1600,y:968,t:1527628143515};\\\", \\\"{x:1600,y:969,t:1527628143532};\\\", \\\"{x:1601,y:969,t:1527628143636};\\\", \\\"{x:1602,y:970,t:1527628143660};\\\", \\\"{x:1603,y:970,t:1527628143749};\\\", \\\"{x:1605,y:970,t:1527628143772};\\\", \\\"{x:1608,y:970,t:1527628143795};\\\", \\\"{x:1609,y:970,t:1527628143827};\\\", \\\"{x:1610,y:970,t:1527628143982};\\\", \\\"{x:1610,y:968,t:1527628143999};\\\", \\\"{x:1610,y:965,t:1527628144015};\\\", \\\"{x:1613,y:958,t:1527628144032};\\\", \\\"{x:1613,y:957,t:1527628144049};\\\", \\\"{x:1613,y:956,t:1527628144065};\\\", \\\"{x:1613,y:954,t:1527628144083};\\\", \\\"{x:1613,y:951,t:1527628144098};\\\", \\\"{x:1613,y:950,t:1527628144115};\\\", \\\"{x:1612,y:947,t:1527628144131};\\\", \\\"{x:1612,y:946,t:1527628144148};\\\", \\\"{x:1612,y:945,t:1527628144171};\\\", \\\"{x:1611,y:944,t:1527628144181};\\\", \\\"{x:1611,y:943,t:1527628144259};\\\", \\\"{x:1610,y:942,t:1527628144268};\\\", \\\"{x:1609,y:941,t:1527628144365};\\\", \\\"{x:1609,y:942,t:1527628144820};\\\", \\\"{x:1610,y:942,t:1527628144861};\\\", \\\"{x:1611,y:943,t:1527628144900};\\\", \\\"{x:1611,y:945,t:1527628144916};\\\", \\\"{x:1613,y:947,t:1527628144932};\\\", \\\"{x:1613,y:948,t:1527628144950};\\\", \\\"{x:1613,y:950,t:1527628144967};\\\", \\\"{x:1613,y:952,t:1527628144988};\\\", \\\"{x:1614,y:952,t:1527628144999};\\\", \\\"{x:1615,y:952,t:1527628145053};\\\", \\\"{x:1616,y:954,t:1527628145067};\\\", \\\"{x:1618,y:958,t:1527628145084};\\\", \\\"{x:1619,y:962,t:1527628145099};\\\", \\\"{x:1619,y:964,t:1527628145116};\\\", \\\"{x:1619,y:966,t:1527628145701};\\\", \\\"{x:1616,y:966,t:1527628145716};\\\", \\\"{x:1616,y:967,t:1527628145733};\\\", \\\"{x:1615,y:968,t:1527628145751};\\\", \\\"{x:1614,y:968,t:1527628145796};\\\", \\\"{x:1613,y:969,t:1527628145820};\\\", \\\"{x:1612,y:969,t:1527628145852};\\\", \\\"{x:1611,y:969,t:1527628145900};\\\", \\\"{x:1610,y:969,t:1527628146117};\\\", \\\"{x:1610,y:968,t:1527628146134};\\\", \\\"{x:1610,y:967,t:1527628146150};\\\", \\\"{x:1610,y:966,t:1527628146167};\\\", \\\"{x:1610,y:964,t:1527628146184};\\\", \\\"{x:1610,y:963,t:1527628146200};\\\", \\\"{x:1610,y:962,t:1527628146217};\\\", \\\"{x:1610,y:960,t:1527628146233};\\\", \\\"{x:1610,y:959,t:1527628146251};\\\", \\\"{x:1610,y:956,t:1527628146268};\\\", \\\"{x:1609,y:953,t:1527628146284};\\\", \\\"{x:1609,y:949,t:1527628146301};\\\", \\\"{x:1609,y:947,t:1527628146318};\\\", \\\"{x:1609,y:946,t:1527628146334};\\\", \\\"{x:1609,y:945,t:1527628146350};\\\", \\\"{x:1609,y:942,t:1527628146367};\\\", \\\"{x:1609,y:940,t:1527628146385};\\\", \\\"{x:1609,y:937,t:1527628146400};\\\", \\\"{x:1609,y:933,t:1527628146418};\\\", \\\"{x:1610,y:932,t:1527628146434};\\\", \\\"{x:1610,y:930,t:1527628146451};\\\", \\\"{x:1610,y:926,t:1527628146468};\\\", \\\"{x:1611,y:922,t:1527628146484};\\\", \\\"{x:1611,y:918,t:1527628146500};\\\", \\\"{x:1612,y:912,t:1527628146517};\\\", \\\"{x:1613,y:907,t:1527628146534};\\\", \\\"{x:1613,y:905,t:1527628146550};\\\", \\\"{x:1615,y:900,t:1527628146567};\\\", \\\"{x:1615,y:898,t:1527628146584};\\\", \\\"{x:1617,y:895,t:1527628146601};\\\", \\\"{x:1617,y:892,t:1527628146617};\\\", \\\"{x:1617,y:889,t:1527628146634};\\\", \\\"{x:1619,y:885,t:1527628146651};\\\", \\\"{x:1619,y:880,t:1527628146668};\\\", \\\"{x:1620,y:872,t:1527628146683};\\\", \\\"{x:1621,y:867,t:1527628146700};\\\", \\\"{x:1622,y:864,t:1527628146717};\\\", \\\"{x:1622,y:860,t:1527628146733};\\\", \\\"{x:1623,y:858,t:1527628146750};\\\", \\\"{x:1623,y:853,t:1527628146767};\\\", \\\"{x:1623,y:847,t:1527628146783};\\\", \\\"{x:1623,y:844,t:1527628146800};\\\", \\\"{x:1623,y:838,t:1527628146817};\\\", \\\"{x:1623,y:829,t:1527628146833};\\\", \\\"{x:1623,y:821,t:1527628146851};\\\", \\\"{x:1623,y:818,t:1527628146866};\\\", \\\"{x:1621,y:811,t:1527628146883};\\\", \\\"{x:1617,y:805,t:1527628146901};\\\", \\\"{x:1616,y:802,t:1527628146917};\\\", \\\"{x:1614,y:799,t:1527628146934};\\\", \\\"{x:1613,y:797,t:1527628146951};\\\", \\\"{x:1613,y:796,t:1527628146967};\\\", \\\"{x:1613,y:795,t:1527628146988};\\\", \\\"{x:1613,y:794,t:1527628147028};\\\", \\\"{x:1613,y:793,t:1527628147044};\\\", \\\"{x:1613,y:792,t:1527628147060};\\\", \\\"{x:1613,y:790,t:1527628147067};\\\", \\\"{x:1613,y:793,t:1527628147508};\\\", \\\"{x:1613,y:798,t:1527628147518};\\\", \\\"{x:1613,y:805,t:1527628147535};\\\", \\\"{x:1613,y:809,t:1527628147551};\\\", \\\"{x:1614,y:815,t:1527628147568};\\\", \\\"{x:1614,y:818,t:1527628147584};\\\", \\\"{x:1614,y:824,t:1527628147601};\\\", \\\"{x:1614,y:829,t:1527628147619};\\\", \\\"{x:1615,y:837,t:1527628147635};\\\", \\\"{x:1617,y:843,t:1527628147651};\\\", \\\"{x:1617,y:852,t:1527628147668};\\\", \\\"{x:1617,y:857,t:1527628147685};\\\", \\\"{x:1617,y:860,t:1527628147701};\\\", \\\"{x:1617,y:866,t:1527628147718};\\\", \\\"{x:1617,y:870,t:1527628147735};\\\", \\\"{x:1617,y:877,t:1527628147751};\\\", \\\"{x:1617,y:883,t:1527628147769};\\\", \\\"{x:1617,y:892,t:1527628147785};\\\", \\\"{x:1617,y:899,t:1527628147802};\\\", \\\"{x:1617,y:905,t:1527628147818};\\\", \\\"{x:1617,y:910,t:1527628147835};\\\", \\\"{x:1617,y:914,t:1527628147852};\\\", \\\"{x:1617,y:917,t:1527628147868};\\\", \\\"{x:1617,y:921,t:1527628147886};\\\", \\\"{x:1617,y:925,t:1527628147901};\\\", \\\"{x:1617,y:927,t:1527628147918};\\\", \\\"{x:1617,y:928,t:1527628147935};\\\", \\\"{x:1617,y:932,t:1527628147952};\\\", \\\"{x:1617,y:934,t:1527628147968};\\\", \\\"{x:1617,y:935,t:1527628147985};\\\", \\\"{x:1617,y:936,t:1527628148001};\\\", \\\"{x:1617,y:938,t:1527628148018};\\\", \\\"{x:1617,y:941,t:1527628148036};\\\", \\\"{x:1617,y:945,t:1527628148052};\\\", \\\"{x:1617,y:947,t:1527628148069};\\\", \\\"{x:1617,y:948,t:1527628148085};\\\", \\\"{x:1617,y:950,t:1527628148101};\\\", \\\"{x:1617,y:951,t:1527628148119};\\\", \\\"{x:1617,y:952,t:1527628148140};\\\", \\\"{x:1618,y:953,t:1527628148156};\\\", \\\"{x:1618,y:951,t:1527628148357};\\\", \\\"{x:1618,y:949,t:1527628148369};\\\", \\\"{x:1619,y:945,t:1527628148385};\\\", \\\"{x:1619,y:940,t:1527628148402};\\\", \\\"{x:1619,y:934,t:1527628148419};\\\", \\\"{x:1619,y:929,t:1527628148436};\\\", \\\"{x:1620,y:926,t:1527628148452};\\\", \\\"{x:1620,y:924,t:1527628148468};\\\", \\\"{x:1621,y:920,t:1527628148485};\\\", \\\"{x:1621,y:917,t:1527628148502};\\\", \\\"{x:1621,y:913,t:1527628148519};\\\", \\\"{x:1621,y:911,t:1527628148536};\\\", \\\"{x:1621,y:908,t:1527628148553};\\\", \\\"{x:1622,y:905,t:1527628148569};\\\", \\\"{x:1622,y:901,t:1527628148586};\\\", \\\"{x:1623,y:899,t:1527628148603};\\\", \\\"{x:1624,y:895,t:1527628148620};\\\", \\\"{x:1624,y:894,t:1527628148636};\\\", \\\"{x:1624,y:889,t:1527628148652};\\\", \\\"{x:1624,y:884,t:1527628148670};\\\", \\\"{x:1624,y:881,t:1527628148686};\\\", \\\"{x:1624,y:878,t:1527628148702};\\\", \\\"{x:1623,y:875,t:1527628148720};\\\", \\\"{x:1622,y:870,t:1527628148736};\\\", \\\"{x:1622,y:867,t:1527628148752};\\\", \\\"{x:1621,y:862,t:1527628148769};\\\", \\\"{x:1620,y:855,t:1527628148785};\\\", \\\"{x:1619,y:850,t:1527628148802};\\\", \\\"{x:1619,y:844,t:1527628148819};\\\", \\\"{x:1619,y:839,t:1527628148835};\\\", \\\"{x:1616,y:835,t:1527628148852};\\\", \\\"{x:1616,y:831,t:1527628148869};\\\", \\\"{x:1615,y:828,t:1527628148885};\\\", \\\"{x:1614,y:827,t:1527628148902};\\\", \\\"{x:1613,y:826,t:1527628148919};\\\", \\\"{x:1613,y:825,t:1527628148936};\\\", \\\"{x:1613,y:822,t:1527628148952};\\\", \\\"{x:1612,y:819,t:1527628148969};\\\", \\\"{x:1610,y:814,t:1527628148986};\\\", \\\"{x:1609,y:810,t:1527628149002};\\\", \\\"{x:1606,y:802,t:1527628149019};\\\", \\\"{x:1605,y:793,t:1527628149035};\\\", \\\"{x:1605,y:786,t:1527628149052};\\\", \\\"{x:1605,y:779,t:1527628149069};\\\", \\\"{x:1605,y:775,t:1527628149087};\\\", \\\"{x:1605,y:771,t:1527628149101};\\\", \\\"{x:1605,y:768,t:1527628149119};\\\", \\\"{x:1605,y:763,t:1527628149136};\\\", \\\"{x:1605,y:759,t:1527628149152};\\\", \\\"{x:1605,y:754,t:1527628149168};\\\", \\\"{x:1605,y:747,t:1527628149186};\\\", \\\"{x:1605,y:743,t:1527628149201};\\\", \\\"{x:1605,y:734,t:1527628149219};\\\", \\\"{x:1605,y:726,t:1527628149236};\\\", \\\"{x:1605,y:719,t:1527628149252};\\\", \\\"{x:1604,y:712,t:1527628149269};\\\", \\\"{x:1604,y:707,t:1527628149286};\\\", \\\"{x:1604,y:694,t:1527628149302};\\\", \\\"{x:1604,y:693,t:1527628149320};\\\", \\\"{x:1604,y:689,t:1527628149340};\\\", \\\"{x:1604,y:685,t:1527628149352};\\\", \\\"{x:1604,y:679,t:1527628149369};\\\", \\\"{x:1604,y:674,t:1527628149386};\\\", \\\"{x:1604,y:667,t:1527628149403};\\\", \\\"{x:1604,y:659,t:1527628149420};\\\", \\\"{x:1604,y:656,t:1527628149436};\\\", \\\"{x:1604,y:652,t:1527628149452};\\\", \\\"{x:1605,y:647,t:1527628149469};\\\", \\\"{x:1606,y:643,t:1527628149486};\\\", \\\"{x:1607,y:638,t:1527628149503};\\\", \\\"{x:1607,y:635,t:1527628149520};\\\", \\\"{x:1607,y:630,t:1527628149537};\\\", \\\"{x:1608,y:626,t:1527628149554};\\\", \\\"{x:1608,y:621,t:1527628149570};\\\", \\\"{x:1608,y:615,t:1527628149587};\\\", \\\"{x:1608,y:614,t:1527628149604};\\\", \\\"{x:1608,y:612,t:1527628149619};\\\", \\\"{x:1608,y:608,t:1527628149636};\\\", \\\"{x:1608,y:605,t:1527628149654};\\\", \\\"{x:1609,y:602,t:1527628149670};\\\", \\\"{x:1610,y:594,t:1527628149687};\\\", \\\"{x:1611,y:589,t:1527628149704};\\\", \\\"{x:1611,y:585,t:1527628149720};\\\", \\\"{x:1611,y:582,t:1527628149737};\\\", \\\"{x:1612,y:580,t:1527628149753};\\\", \\\"{x:1612,y:578,t:1527628149770};\\\", \\\"{x:1613,y:577,t:1527628149787};\\\", \\\"{x:1613,y:574,t:1527628149803};\\\", \\\"{x:1614,y:572,t:1527628149819};\\\", \\\"{x:1614,y:570,t:1527628149837};\\\", \\\"{x:1614,y:567,t:1527628149856};\\\", \\\"{x:1614,y:566,t:1527628149898};\\\", \\\"{x:1614,y:565,t:1527628150012};\\\", \\\"{x:1614,y:564,t:1527628150028};\\\", \\\"{x:1613,y:562,t:1527628150051};\\\", \\\"{x:1613,y:561,t:1527628150060};\\\", \\\"{x:1613,y:560,t:1527628150084};\\\", \\\"{x:1613,y:559,t:1527628150108};\\\", \\\"{x:1613,y:558,t:1527628150196};\\\", \\\"{x:1598,y:565,t:1527628155494};\\\", \\\"{x:1491,y:591,t:1527628155507};\\\", \\\"{x:1387,y:609,t:1527628155524};\\\", \\\"{x:1271,y:624,t:1527628155541};\\\", \\\"{x:1127,y:626,t:1527628155558};\\\", \\\"{x:1011,y:626,t:1527628155575};\\\", \\\"{x:901,y:619,t:1527628155592};\\\", \\\"{x:799,y:619,t:1527628155608};\\\", \\\"{x:732,y:619,t:1527628155625};\\\", \\\"{x:687,y:616,t:1527628155642};\\\", \\\"{x:657,y:612,t:1527628155659};\\\", \\\"{x:630,y:608,t:1527628155674};\\\", \\\"{x:589,y:596,t:1527628155691};\\\", \\\"{x:570,y:593,t:1527628155708};\\\", \\\"{x:553,y:590,t:1527628155724};\\\", \\\"{x:541,y:588,t:1527628155741};\\\", \\\"{x:524,y:588,t:1527628155758};\\\", \\\"{x:514,y:588,t:1527628155773};\\\", \\\"{x:510,y:588,t:1527628155791};\\\", \\\"{x:509,y:588,t:1527628155808};\\\", \\\"{x:509,y:586,t:1527628155948};\\\", \\\"{x:511,y:585,t:1527628155959};\\\", \\\"{x:516,y:581,t:1527628155976};\\\", \\\"{x:520,y:579,t:1527628155991};\\\", \\\"{x:521,y:578,t:1527628156008};\\\", \\\"{x:523,y:578,t:1527628156025};\\\", \\\"{x:525,y:578,t:1527628156180};\\\", \\\"{x:528,y:577,t:1527628156191};\\\", \\\"{x:537,y:575,t:1527628156209};\\\", \\\"{x:539,y:575,t:1527628156225};\\\", \\\"{x:541,y:574,t:1527628156243};\\\", \\\"{x:543,y:574,t:1527628156258};\\\", \\\"{x:544,y:574,t:1527628156475};\\\", \\\"{x:617,y:571,t:1527628156492};\\\", \\\"{x:736,y:554,t:1527628156510};\\\", \\\"{x:851,y:544,t:1527628156526};\\\", \\\"{x:964,y:534,t:1527628156544};\\\", \\\"{x:1072,y:522,t:1527628156558};\\\", \\\"{x:1154,y:515,t:1527628156575};\\\", \\\"{x:1189,y:512,t:1527628156592};\\\", \\\"{x:1218,y:509,t:1527628156608};\\\", \\\"{x:1241,y:509,t:1527628156626};\\\", \\\"{x:1251,y:509,t:1527628156642};\\\", \\\"{x:1255,y:509,t:1527628156658};\\\", \\\"{x:1257,y:509,t:1527628156675};\\\", \\\"{x:1261,y:511,t:1527628156693};\\\", \\\"{x:1269,y:515,t:1527628156708};\\\", \\\"{x:1298,y:526,t:1527628156725};\\\", \\\"{x:1325,y:531,t:1527628156742};\\\", \\\"{x:1359,y:542,t:1527628156759};\\\", \\\"{x:1388,y:549,t:1527628156775};\\\", \\\"{x:1417,y:555,t:1527628156792};\\\", \\\"{x:1442,y:557,t:1527628156809};\\\", \\\"{x:1464,y:562,t:1527628156826};\\\", \\\"{x:1477,y:565,t:1527628156843};\\\", \\\"{x:1483,y:565,t:1527628156859};\\\", \\\"{x:1484,y:565,t:1527628156876};\\\", \\\"{x:1486,y:565,t:1527628156956};\\\", \\\"{x:1486,y:563,t:1527628156980};\\\", \\\"{x:1486,y:562,t:1527628156993};\\\", \\\"{x:1487,y:560,t:1527628157009};\\\", \\\"{x:1487,y:556,t:1527628157026};\\\", \\\"{x:1486,y:553,t:1527628157043};\\\", \\\"{x:1479,y:547,t:1527628157060};\\\", \\\"{x:1470,y:545,t:1527628157076};\\\", \\\"{x:1462,y:544,t:1527628157093};\\\", \\\"{x:1457,y:544,t:1527628157110};\\\", \\\"{x:1453,y:543,t:1527628157126};\\\", \\\"{x:1446,y:543,t:1527628157143};\\\", \\\"{x:1436,y:543,t:1527628157159};\\\", \\\"{x:1430,y:544,t:1527628157176};\\\", \\\"{x:1428,y:544,t:1527628157193};\\\", \\\"{x:1426,y:544,t:1527628157210};\\\", \\\"{x:1424,y:545,t:1527628157228};\\\", \\\"{x:1423,y:545,t:1527628157260};\\\", \\\"{x:1423,y:546,t:1527628157276};\\\", \\\"{x:1421,y:546,t:1527628157293};\\\", \\\"{x:1420,y:546,t:1527628157557};\\\", \\\"{x:1413,y:538,t:1527628157563};\\\", \\\"{x:1410,y:532,t:1527628157575};\\\", \\\"{x:1406,y:528,t:1527628157593};\\\", \\\"{x:1405,y:527,t:1527628157612};\\\", \\\"{x:1405,y:525,t:1527628157625};\\\", \\\"{x:1404,y:522,t:1527628157642};\\\", \\\"{x:1404,y:521,t:1527628157660};\\\", \\\"{x:1403,y:519,t:1527628157683};\\\", \\\"{x:1402,y:518,t:1527628157693};\\\", \\\"{x:1400,y:516,t:1527628157710};\\\", \\\"{x:1399,y:514,t:1527628157727};\\\", \\\"{x:1398,y:514,t:1527628157743};\\\", \\\"{x:1397,y:511,t:1527628157760};\\\", \\\"{x:1397,y:510,t:1527628157777};\\\", \\\"{x:1396,y:509,t:1527628157792};\\\", \\\"{x:1396,y:507,t:1527628157810};\\\", \\\"{x:1396,y:506,t:1527628157827};\\\", \\\"{x:1396,y:505,t:1527628157844};\\\", \\\"{x:1396,y:503,t:1527628157859};\\\", \\\"{x:1396,y:502,t:1527628157884};\\\", \\\"{x:1396,y:500,t:1527628157908};\\\", \\\"{x:1396,y:499,t:1527628157924};\\\", \\\"{x:1394,y:497,t:1527628157940};\\\", \\\"{x:1394,y:496,t:1527628157964};\\\", \\\"{x:1393,y:493,t:1527628157977};\\\", \\\"{x:1392,y:493,t:1527628157993};\\\", \\\"{x:1392,y:491,t:1527628158010};\\\", \\\"{x:1390,y:489,t:1527628158027};\\\", \\\"{x:1389,y:489,t:1527628158043};\\\", \\\"{x:1387,y:489,t:1527628158100};\\\", \\\"{x:1383,y:488,t:1527628158110};\\\", \\\"{x:1367,y:488,t:1527628158127};\\\", \\\"{x:1326,y:488,t:1527628158143};\\\", \\\"{x:1240,y:498,t:1527628158159};\\\", \\\"{x:1129,y:514,t:1527628158177};\\\", \\\"{x:1003,y:527,t:1527628158193};\\\", \\\"{x:882,y:537,t:1527628158210};\\\", \\\"{x:769,y:545,t:1527628158227};\\\", \\\"{x:654,y:552,t:1527628158243};\\\", \\\"{x:600,y:560,t:1527628158260};\\\", \\\"{x:574,y:563,t:1527628158276};\\\", \\\"{x:555,y:565,t:1527628158293};\\\", \\\"{x:546,y:567,t:1527628158310};\\\", \\\"{x:543,y:567,t:1527628158326};\\\", \\\"{x:541,y:568,t:1527628158343};\\\", \\\"{x:538,y:568,t:1527628158419};\\\", \\\"{x:533,y:571,t:1527628158427};\\\", \\\"{x:521,y:572,t:1527628158443};\\\", \\\"{x:509,y:573,t:1527628158460};\\\", \\\"{x:485,y:576,t:1527628158477};\\\", \\\"{x:471,y:576,t:1527628158493};\\\", \\\"{x:455,y:576,t:1527628158510};\\\", \\\"{x:433,y:574,t:1527628158528};\\\", \\\"{x:410,y:574,t:1527628158543};\\\", \\\"{x:388,y:572,t:1527628158560};\\\", \\\"{x:372,y:569,t:1527628158576};\\\", \\\"{x:367,y:568,t:1527628158593};\\\", \\\"{x:366,y:567,t:1527628158610};\\\", \\\"{x:363,y:563,t:1527628158628};\\\", \\\"{x:361,y:562,t:1527628158644};\\\", \\\"{x:359,y:559,t:1527628158660};\\\", \\\"{x:358,y:553,t:1527628158678};\\\", \\\"{x:356,y:551,t:1527628158694};\\\", \\\"{x:355,y:549,t:1527628158711};\\\", \\\"{x:354,y:549,t:1527628158727};\\\", \\\"{x:353,y:548,t:1527628158743};\\\", \\\"{x:350,y:548,t:1527628158835};\\\", \\\"{x:348,y:549,t:1527628158844};\\\", \\\"{x:340,y:549,t:1527628158860};\\\", \\\"{x:325,y:553,t:1527628158877};\\\", \\\"{x:311,y:560,t:1527628158893};\\\", \\\"{x:297,y:562,t:1527628158911};\\\", \\\"{x:281,y:566,t:1527628158927};\\\", \\\"{x:269,y:569,t:1527628158945};\\\", \\\"{x:253,y:572,t:1527628158960};\\\", \\\"{x:241,y:574,t:1527628158977};\\\", \\\"{x:238,y:575,t:1527628158994};\\\", \\\"{x:237,y:575,t:1527628159067};\\\", \\\"{x:235,y:576,t:1527628159083};\\\", \\\"{x:233,y:577,t:1527628159094};\\\", \\\"{x:231,y:584,t:1527628159111};\\\", \\\"{x:228,y:589,t:1527628159127};\\\", \\\"{x:223,y:595,t:1527628159144};\\\", \\\"{x:218,y:604,t:1527628159160};\\\", \\\"{x:214,y:610,t:1527628159177};\\\", \\\"{x:209,y:618,t:1527628159194};\\\", \\\"{x:205,y:625,t:1527628159211};\\\", \\\"{x:200,y:630,t:1527628159227};\\\", \\\"{x:198,y:632,t:1527628159244};\\\", \\\"{x:197,y:632,t:1527628159274};\\\", \\\"{x:196,y:632,t:1527628159315};\\\", \\\"{x:196,y:633,t:1527628159327};\\\", \\\"{x:195,y:633,t:1527628159344};\\\", \\\"{x:193,y:633,t:1527628159360};\\\", \\\"{x:188,y:636,t:1527628159378};\\\", \\\"{x:187,y:636,t:1527628159394};\\\", \\\"{x:186,y:636,t:1527628159411};\\\", \\\"{x:185,y:637,t:1527628159523};\\\", \\\"{x:185,y:637,t:1527628159570};\\\", \\\"{x:206,y:634,t:1527628159652};\\\", \\\"{x:255,y:627,t:1527628159661};\\\", \\\"{x:363,y:611,t:1527628159678};\\\", \\\"{x:488,y:590,t:1527628159694};\\\", \\\"{x:583,y:574,t:1527628159712};\\\", \\\"{x:656,y:562,t:1527628159727};\\\", \\\"{x:716,y:546,t:1527628159744};\\\", \\\"{x:770,y:539,t:1527628159761};\\\", \\\"{x:794,y:533,t:1527628159778};\\\", \\\"{x:812,y:527,t:1527628159795};\\\", \\\"{x:829,y:526,t:1527628159811};\\\", \\\"{x:845,y:522,t:1527628159828};\\\", \\\"{x:857,y:522,t:1527628159845};\\\", \\\"{x:866,y:519,t:1527628159862};\\\", \\\"{x:874,y:517,t:1527628159878};\\\", \\\"{x:875,y:517,t:1527628159894};\\\", \\\"{x:872,y:517,t:1527628159995};\\\", \\\"{x:871,y:519,t:1527628160012};\\\", \\\"{x:869,y:523,t:1527628160030};\\\", \\\"{x:867,y:526,t:1527628160044};\\\", \\\"{x:862,y:529,t:1527628160061};\\\", \\\"{x:859,y:532,t:1527628160079};\\\", \\\"{x:853,y:535,t:1527628160094};\\\", \\\"{x:849,y:538,t:1527628160112};\\\", \\\"{x:847,y:540,t:1527628160129};\\\", \\\"{x:844,y:540,t:1527628160144};\\\", \\\"{x:843,y:540,t:1527628160161};\\\", \\\"{x:841,y:540,t:1527628160228};\\\", \\\"{x:837,y:540,t:1527628160245};\\\", \\\"{x:835,y:540,t:1527628160262};\\\", \\\"{x:833,y:540,t:1527628160279};\\\", \\\"{x:832,y:540,t:1527628160323};\\\", \\\"{x:831,y:540,t:1527628160339};\\\", \\\"{x:829,y:543,t:1527628160348};\\\", \\\"{x:829,y:545,t:1527628160363};\\\", \\\"{x:826,y:552,t:1527628160380};\\\", \\\"{x:824,y:558,t:1527628160395};\\\", \\\"{x:819,y:561,t:1527628160411};\\\", \\\"{x:812,y:566,t:1527628160428};\\\", \\\"{x:792,y:575,t:1527628160445};\\\", \\\"{x:776,y:586,t:1527628160461};\\\", \\\"{x:770,y:596,t:1527628160478};\\\", \\\"{x:767,y:601,t:1527628160495};\\\", \\\"{x:767,y:604,t:1527628160511};\\\", \\\"{x:771,y:605,t:1527628160529};\\\", \\\"{x:777,y:606,t:1527628160545};\\\", \\\"{x:787,y:606,t:1527628160561};\\\", \\\"{x:799,y:604,t:1527628160579};\\\", \\\"{x:803,y:603,t:1527628160595};\\\", \\\"{x:807,y:601,t:1527628160611};\\\", \\\"{x:810,y:601,t:1527628160628};\\\", \\\"{x:813,y:600,t:1527628160652};\\\", \\\"{x:814,y:599,t:1527628160662};\\\", \\\"{x:815,y:599,t:1527628160692};\\\", \\\"{x:818,y:598,t:1527628160707};\\\", \\\"{x:820,y:597,t:1527628160723};\\\", \\\"{x:821,y:597,t:1527628160740};\\\", \\\"{x:822,y:596,t:1527628160763};\\\", \\\"{x:823,y:596,t:1527628160787};\\\", \\\"{x:825,y:595,t:1527628160820};\\\", \\\"{x:827,y:595,t:1527628160835};\\\", \\\"{x:828,y:595,t:1527628160845};\\\", \\\"{x:830,y:594,t:1527628160862};\\\", \\\"{x:833,y:594,t:1527628160878};\\\", \\\"{x:834,y:594,t:1527628160895};\\\", \\\"{x:835,y:594,t:1527628160915};\\\", \\\"{x:836,y:594,t:1527628160931};\\\", \\\"{x:837,y:595,t:1527628160955};\\\", \\\"{x:843,y:595,t:1527628161251};\\\", \\\"{x:857,y:595,t:1527628161264};\\\", \\\"{x:906,y:595,t:1527628161281};\\\", \\\"{x:983,y:592,t:1527628161295};\\\", \\\"{x:1085,y:580,t:1527628161312};\\\", \\\"{x:1180,y:576,t:1527628161329};\\\", \\\"{x:1291,y:576,t:1527628161345};\\\", \\\"{x:1393,y:589,t:1527628161362};\\\", \\\"{x:1497,y:623,t:1527628161379};\\\", \\\"{x:1558,y:649,t:1527628161395};\\\", \\\"{x:1600,y:678,t:1527628161412};\\\", \\\"{x:1627,y:707,t:1527628161429};\\\", \\\"{x:1641,y:726,t:1527628161445};\\\", \\\"{x:1652,y:747,t:1527628161462};\\\", \\\"{x:1658,y:763,t:1527628161479};\\\", \\\"{x:1660,y:775,t:1527628161496};\\\", \\\"{x:1662,y:784,t:1527628161512};\\\", \\\"{x:1662,y:790,t:1527628161530};\\\", \\\"{x:1662,y:799,t:1527628161546};\\\", \\\"{x:1662,y:811,t:1527628161563};\\\", \\\"{x:1655,y:826,t:1527628161580};\\\", \\\"{x:1649,y:840,t:1527628161596};\\\", \\\"{x:1643,y:850,t:1527628161612};\\\", \\\"{x:1638,y:857,t:1527628161630};\\\", \\\"{x:1634,y:863,t:1527628161645};\\\", \\\"{x:1631,y:866,t:1527628161663};\\\", \\\"{x:1628,y:871,t:1527628161679};\\\", \\\"{x:1623,y:877,t:1527628161696};\\\", \\\"{x:1617,y:885,t:1527628161713};\\\", \\\"{x:1608,y:896,t:1527628161730};\\\", \\\"{x:1604,y:901,t:1527628161747};\\\", \\\"{x:1599,y:906,t:1527628161763};\\\", \\\"{x:1595,y:908,t:1527628161780};\\\", \\\"{x:1592,y:912,t:1527628161795};\\\", \\\"{x:1590,y:912,t:1527628161813};\\\", \\\"{x:1586,y:915,t:1527628161829};\\\", \\\"{x:1575,y:920,t:1527628161846};\\\", \\\"{x:1571,y:922,t:1527628161863};\\\", \\\"{x:1568,y:923,t:1527628161880};\\\", \\\"{x:1562,y:923,t:1527628161896};\\\", \\\"{x:1553,y:927,t:1527628161912};\\\", \\\"{x:1544,y:932,t:1527628161929};\\\", \\\"{x:1543,y:932,t:1527628161946};\\\", \\\"{x:1541,y:932,t:1527628162076};\\\", \\\"{x:1540,y:932,t:1527628162083};\\\", \\\"{x:1537,y:932,t:1527628162096};\\\", \\\"{x:1525,y:936,t:1527628162113};\\\", \\\"{x:1518,y:937,t:1527628162130};\\\", \\\"{x:1508,y:940,t:1527628162146};\\\", \\\"{x:1499,y:942,t:1527628162163};\\\", \\\"{x:1493,y:942,t:1527628162180};\\\", \\\"{x:1492,y:942,t:1527628162196};\\\", \\\"{x:1489,y:942,t:1527628162214};\\\", \\\"{x:1488,y:943,t:1527628162260};\\\", \\\"{x:1488,y:944,t:1527628162268};\\\", \\\"{x:1487,y:944,t:1527628162280};\\\", \\\"{x:1486,y:945,t:1527628162300};\\\", \\\"{x:1485,y:945,t:1527628162313};\\\", \\\"{x:1480,y:948,t:1527628162331};\\\", \\\"{x:1475,y:951,t:1527628162347};\\\", \\\"{x:1467,y:957,t:1527628162364};\\\", \\\"{x:1449,y:966,t:1527628162381};\\\", \\\"{x:1442,y:971,t:1527628162397};\\\", \\\"{x:1436,y:974,t:1527628162413};\\\", \\\"{x:1434,y:976,t:1527628162431};\\\", \\\"{x:1432,y:976,t:1527628162548};\\\", \\\"{x:1430,y:975,t:1527628162563};\\\", \\\"{x:1426,y:972,t:1527628162581};\\\", \\\"{x:1421,y:961,t:1527628162598};\\\", \\\"{x:1414,y:947,t:1527628162613};\\\", \\\"{x:1408,y:933,t:1527628162630};\\\", \\\"{x:1402,y:919,t:1527628162647};\\\", \\\"{x:1397,y:898,t:1527628162663};\\\", \\\"{x:1395,y:883,t:1527628162680};\\\", \\\"{x:1392,y:867,t:1527628162697};\\\", \\\"{x:1392,y:849,t:1527628162713};\\\", \\\"{x:1392,y:833,t:1527628162730};\\\", \\\"{x:1392,y:825,t:1527628162748};\\\", \\\"{x:1392,y:821,t:1527628162763};\\\", \\\"{x:1390,y:812,t:1527628162780};\\\", \\\"{x:1390,y:804,t:1527628162797};\\\", \\\"{x:1390,y:794,t:1527628162812};\\\", \\\"{x:1390,y:775,t:1527628162829};\\\", \\\"{x:1390,y:750,t:1527628162846};\\\", \\\"{x:1390,y:735,t:1527628162862};\\\", \\\"{x:1389,y:715,t:1527628162879};\\\", \\\"{x:1389,y:696,t:1527628162896};\\\", \\\"{x:1389,y:677,t:1527628162913};\\\", \\\"{x:1389,y:664,t:1527628162929};\\\", \\\"{x:1389,y:657,t:1527628162947};\\\", \\\"{x:1390,y:652,t:1527628162963};\\\", \\\"{x:1390,y:647,t:1527628162979};\\\", \\\"{x:1391,y:644,t:1527628162996};\\\", \\\"{x:1392,y:642,t:1527628163012};\\\", \\\"{x:1393,y:637,t:1527628163030};\\\", \\\"{x:1396,y:630,t:1527628163047};\\\", \\\"{x:1396,y:627,t:1527628163063};\\\", \\\"{x:1398,y:621,t:1527628163079};\\\", \\\"{x:1400,y:613,t:1527628163097};\\\", \\\"{x:1402,y:605,t:1527628163112};\\\", \\\"{x:1405,y:598,t:1527628163129};\\\", \\\"{x:1406,y:591,t:1527628163146};\\\", \\\"{x:1406,y:589,t:1527628163163};\\\", \\\"{x:1407,y:587,t:1527628163179};\\\", \\\"{x:1407,y:586,t:1527628163197};\\\", \\\"{x:1408,y:585,t:1527628163213};\\\", \\\"{x:1409,y:583,t:1527628163260};\\\", \\\"{x:1409,y:582,t:1527628163284};\\\", \\\"{x:1410,y:582,t:1527628163299};\\\", \\\"{x:1410,y:580,t:1527628163372};\\\", \\\"{x:1410,y:579,t:1527628163380};\\\", \\\"{x:1410,y:577,t:1527628163435};\\\", \\\"{x:1410,y:576,t:1527628163467};\\\", \\\"{x:1410,y:579,t:1527628164381};\\\", \\\"{x:1413,y:584,t:1527628164397};\\\", \\\"{x:1417,y:590,t:1527628164414};\\\", \\\"{x:1418,y:594,t:1527628164430};\\\", \\\"{x:1422,y:600,t:1527628164447};\\\", \\\"{x:1427,y:610,t:1527628164464};\\\", \\\"{x:1434,y:626,t:1527628164480};\\\", \\\"{x:1442,y:647,t:1527628164497};\\\", \\\"{x:1451,y:669,t:1527628164514};\\\", \\\"{x:1459,y:689,t:1527628164530};\\\", \\\"{x:1465,y:710,t:1527628164547};\\\", \\\"{x:1477,y:750,t:1527628164564};\\\", \\\"{x:1483,y:778,t:1527628164581};\\\", \\\"{x:1489,y:803,t:1527628164597};\\\", \\\"{x:1498,y:830,t:1527628164614};\\\", \\\"{x:1503,y:858,t:1527628164631};\\\", \\\"{x:1506,y:877,t:1527628164647};\\\", \\\"{x:1510,y:893,t:1527628164664};\\\", \\\"{x:1513,y:905,t:1527628164680};\\\", \\\"{x:1515,y:914,t:1527628164697};\\\", \\\"{x:1518,y:921,t:1527628164714};\\\", \\\"{x:1518,y:929,t:1527628164731};\\\", \\\"{x:1519,y:939,t:1527628164748};\\\", \\\"{x:1519,y:945,t:1527628164764};\\\", \\\"{x:1519,y:948,t:1527628164781};\\\", \\\"{x:1519,y:950,t:1527628164797};\\\", \\\"{x:1519,y:952,t:1527628164814};\\\", \\\"{x:1519,y:953,t:1527628164831};\\\", \\\"{x:1518,y:955,t:1527628164847};\\\", \\\"{x:1518,y:956,t:1527628164900};\\\", \\\"{x:1517,y:957,t:1527628164915};\\\", \\\"{x:1517,y:958,t:1527628164930};\\\", \\\"{x:1515,y:958,t:1527628164947};\\\", \\\"{x:1515,y:959,t:1527628164964};\\\", \\\"{x:1514,y:960,t:1527628164995};\\\", \\\"{x:1513,y:960,t:1527628165004};\\\", \\\"{x:1512,y:960,t:1527628165068};\\\", \\\"{x:1510,y:960,t:1527628165081};\\\", \\\"{x:1505,y:956,t:1527628165097};\\\", \\\"{x:1501,y:950,t:1527628165114};\\\", \\\"{x:1493,y:941,t:1527628165131};\\\", \\\"{x:1491,y:937,t:1527628165147};\\\", \\\"{x:1486,y:931,t:1527628165164};\\\", \\\"{x:1484,y:925,t:1527628165181};\\\", \\\"{x:1480,y:918,t:1527628165197};\\\", \\\"{x:1480,y:912,t:1527628165214};\\\", \\\"{x:1476,y:906,t:1527628165231};\\\", \\\"{x:1474,y:897,t:1527628165247};\\\", \\\"{x:1469,y:883,t:1527628165264};\\\", \\\"{x:1469,y:878,t:1527628165281};\\\", \\\"{x:1467,y:871,t:1527628165297};\\\", \\\"{x:1466,y:865,t:1527628165314};\\\", \\\"{x:1464,y:863,t:1527628165332};\\\", \\\"{x:1464,y:855,t:1527628165348};\\\", \\\"{x:1463,y:852,t:1527628165364};\\\", \\\"{x:1463,y:849,t:1527628165381};\\\", \\\"{x:1463,y:848,t:1527628165596};\\\", \\\"{x:1465,y:848,t:1527628165748};\\\", \\\"{x:1468,y:844,t:1527628165764};\\\", \\\"{x:1468,y:843,t:1527628165782};\\\", \\\"{x:1469,y:841,t:1527628165797};\\\", \\\"{x:1469,y:840,t:1527628165828};\\\", \\\"{x:1469,y:838,t:1527628165860};\\\", \\\"{x:1468,y:838,t:1527628165868};\\\", \\\"{x:1466,y:837,t:1527628165881};\\\", \\\"{x:1458,y:833,t:1527628165897};\\\", \\\"{x:1439,y:828,t:1527628165914};\\\", \\\"{x:1419,y:821,t:1527628165932};\\\", \\\"{x:1399,y:818,t:1527628165948};\\\", \\\"{x:1358,y:814,t:1527628165964};\\\", \\\"{x:1323,y:811,t:1527628165981};\\\", \\\"{x:1264,y:802,t:1527628165998};\\\", \\\"{x:1201,y:795,t:1527628166015};\\\", \\\"{x:1154,y:788,t:1527628166031};\\\", \\\"{x:1110,y:776,t:1527628166048};\\\", \\\"{x:1066,y:765,t:1527628166064};\\\", \\\"{x:1033,y:758,t:1527628166081};\\\", \\\"{x:1010,y:750,t:1527628166098};\\\", \\\"{x:983,y:740,t:1527628166114};\\\", \\\"{x:948,y:725,t:1527628166132};\\\", \\\"{x:928,y:718,t:1527628166147};\\\", \\\"{x:903,y:707,t:1527628166164};\\\", \\\"{x:895,y:701,t:1527628166180};\\\", \\\"{x:885,y:697,t:1527628166198};\\\", \\\"{x:876,y:693,t:1527628166213};\\\", \\\"{x:870,y:691,t:1527628166231};\\\", \\\"{x:865,y:688,t:1527628166248};\\\", \\\"{x:860,y:685,t:1527628166264};\\\", \\\"{x:849,y:680,t:1527628166280};\\\", \\\"{x:827,y:668,t:1527628166299};\\\", \\\"{x:809,y:662,t:1527628166314};\\\", \\\"{x:782,y:650,t:1527628166331};\\\", \\\"{x:762,y:641,t:1527628166348};\\\", \\\"{x:744,y:632,t:1527628166363};\\\", \\\"{x:731,y:625,t:1527628166381};\\\", \\\"{x:724,y:621,t:1527628166400};\\\", \\\"{x:713,y:616,t:1527628166414};\\\", \\\"{x:702,y:611,t:1527628166430};\\\", \\\"{x:688,y:606,t:1527628166466};\\\", \\\"{x:683,y:604,t:1527628166482};\\\", \\\"{x:683,y:603,t:1527628166500};\\\", \\\"{x:682,y:603,t:1527628166516};\\\", \\\"{x:678,y:601,t:1527628166562};\\\", \\\"{x:677,y:600,t:1527628166570};\\\", \\\"{x:674,y:597,t:1527628166584};\\\", \\\"{x:668,y:592,t:1527628166600};\\\", \\\"{x:664,y:591,t:1527628166617};\\\", \\\"{x:662,y:590,t:1527628166633};\\\", \\\"{x:661,y:590,t:1527628166651};\\\", \\\"{x:656,y:590,t:1527628166699};\\\", \\\"{x:651,y:590,t:1527628166707};\\\", \\\"{x:644,y:590,t:1527628166717};\\\", \\\"{x:629,y:590,t:1527628166734};\\\", \\\"{x:620,y:593,t:1527628166750};\\\", \\\"{x:616,y:594,t:1527628166767};\\\", \\\"{x:616,y:595,t:1527628166784};\\\", \\\"{x:615,y:595,t:1527628166843};\\\", \\\"{x:615,y:595,t:1527628166920};\\\", \\\"{x:615,y:596,t:1527628166947};\\\", \\\"{x:616,y:598,t:1527628166955};\\\", \\\"{x:618,y:600,t:1527628166966};\\\", \\\"{x:621,y:603,t:1527628166984};\\\", \\\"{x:625,y:611,t:1527628167001};\\\", \\\"{x:630,y:623,t:1527628167017};\\\", \\\"{x:640,y:634,t:1527628167033};\\\", \\\"{x:653,y:645,t:1527628167051};\\\", \\\"{x:673,y:663,t:1527628167067};\\\", \\\"{x:687,y:672,t:1527628167083};\\\", \\\"{x:700,y:678,t:1527628167100};\\\", \\\"{x:712,y:684,t:1527628167118};\\\", \\\"{x:741,y:693,t:1527628167133};\\\", \\\"{x:776,y:705,t:1527628167151};\\\", \\\"{x:828,y:715,t:1527628167167};\\\", \\\"{x:881,y:732,t:1527628167183};\\\", \\\"{x:937,y:741,t:1527628167200};\\\", \\\"{x:988,y:749,t:1527628167218};\\\", \\\"{x:1028,y:764,t:1527628167233};\\\", \\\"{x:1063,y:770,t:1527628167251};\\\", \\\"{x:1144,y:776,t:1527628167267};\\\", \\\"{x:1168,y:779,t:1527628167284};\\\", \\\"{x:1193,y:781,t:1527628167300};\\\", \\\"{x:1227,y:789,t:1527628167318};\\\", \\\"{x:1284,y:796,t:1527628167333};\\\", \\\"{x:1344,y:801,t:1527628167351};\\\", \\\"{x:1372,y:802,t:1527628167368};\\\", \\\"{x:1395,y:806,t:1527628167384};\\\", \\\"{x:1417,y:807,t:1527628167401};\\\", \\\"{x:1427,y:807,t:1527628167418};\\\", \\\"{x:1433,y:807,t:1527628167434};\\\", \\\"{x:1438,y:807,t:1527628167450};\\\", \\\"{x:1451,y:805,t:1527628167468};\\\", \\\"{x:1466,y:800,t:1527628167484};\\\", \\\"{x:1486,y:796,t:1527628167501};\\\", \\\"{x:1495,y:792,t:1527628167518};\\\", \\\"{x:1502,y:791,t:1527628167535};\\\", \\\"{x:1503,y:790,t:1527628167551};\\\", \\\"{x:1504,y:790,t:1527628167596};\\\", \\\"{x:1507,y:787,t:1527628167611};\\\", \\\"{x:1509,y:782,t:1527628167619};\\\", \\\"{x:1514,y:776,t:1527628167635};\\\", \\\"{x:1521,y:767,t:1527628167651};\\\", \\\"{x:1529,y:757,t:1527628167668};\\\", \\\"{x:1533,y:750,t:1527628167685};\\\", \\\"{x:1535,y:747,t:1527628167701};\\\", \\\"{x:1536,y:745,t:1527628167718};\\\", \\\"{x:1536,y:743,t:1527628167735};\\\", \\\"{x:1536,y:738,t:1527628167752};\\\", \\\"{x:1536,y:730,t:1527628167768};\\\", \\\"{x:1536,y:722,t:1527628167785};\\\", \\\"{x:1536,y:720,t:1527628167801};\\\", \\\"{x:1537,y:718,t:1527628167818};\\\", \\\"{x:1537,y:717,t:1527628167844};\\\", \\\"{x:1537,y:715,t:1527628167852};\\\", \\\"{x:1537,y:713,t:1527628167868};\\\", \\\"{x:1537,y:711,t:1527628167885};\\\", \\\"{x:1539,y:706,t:1527628167902};\\\", \\\"{x:1540,y:697,t:1527628167918};\\\", \\\"{x:1540,y:692,t:1527628167936};\\\", \\\"{x:1540,y:688,t:1527628167951};\\\", \\\"{x:1540,y:685,t:1527628167968};\\\", \\\"{x:1540,y:679,t:1527628167985};\\\", \\\"{x:1540,y:675,t:1527628168002};\\\", \\\"{x:1540,y:673,t:1527628168018};\\\", \\\"{x:1540,y:670,t:1527628168035};\\\", \\\"{x:1540,y:663,t:1527628168051};\\\", \\\"{x:1539,y:660,t:1527628168068};\\\", \\\"{x:1536,y:656,t:1527628168085};\\\", \\\"{x:1534,y:650,t:1527628168102};\\\", \\\"{x:1533,y:648,t:1527628168118};\\\", \\\"{x:1531,y:646,t:1527628168136};\\\", \\\"{x:1531,y:643,t:1527628168152};\\\", \\\"{x:1524,y:640,t:1527628168676};\\\", \\\"{x:1513,y:637,t:1527628168685};\\\", \\\"{x:1492,y:631,t:1527628168703};\\\", \\\"{x:1475,y:627,t:1527628168720};\\\", \\\"{x:1459,y:624,t:1527628168735};\\\", \\\"{x:1449,y:622,t:1527628168752};\\\", \\\"{x:1444,y:622,t:1527628168769};\\\", \\\"{x:1443,y:622,t:1527628168785};\\\", \\\"{x:1442,y:622,t:1527628168801};\\\", \\\"{x:1441,y:622,t:1527628168818};\\\", \\\"{x:1440,y:622,t:1527628168835};\\\", \\\"{x:1437,y:623,t:1527628168852};\\\", \\\"{x:1435,y:625,t:1527628168868};\\\", \\\"{x:1430,y:632,t:1527628168885};\\\", \\\"{x:1423,y:644,t:1527628168902};\\\", \\\"{x:1415,y:660,t:1527628168919};\\\", \\\"{x:1402,y:679,t:1527628168936};\\\", \\\"{x:1391,y:693,t:1527628168951};\\\", \\\"{x:1382,y:701,t:1527628168969};\\\", \\\"{x:1374,y:712,t:1527628168985};\\\", \\\"{x:1368,y:728,t:1527628169002};\\\", \\\"{x:1358,y:744,t:1527628169019};\\\", \\\"{x:1352,y:756,t:1527628169035};\\\", \\\"{x:1346,y:766,t:1527628169052};\\\", \\\"{x:1339,y:777,t:1527628169069};\\\", \\\"{x:1334,y:785,t:1527628169086};\\\", \\\"{x:1332,y:790,t:1527628169102};\\\", \\\"{x:1330,y:796,t:1527628169119};\\\", \\\"{x:1327,y:802,t:1527628169136};\\\", \\\"{x:1321,y:810,t:1527628169152};\\\", \\\"{x:1317,y:819,t:1527628169168};\\\", \\\"{x:1314,y:825,t:1527628169186};\\\", \\\"{x:1311,y:828,t:1527628169202};\\\", \\\"{x:1308,y:834,t:1527628169219};\\\", \\\"{x:1307,y:835,t:1527628169235};\\\", \\\"{x:1306,y:836,t:1527628169252};\\\", \\\"{x:1305,y:837,t:1527628169268};\\\", \\\"{x:1303,y:839,t:1527628169286};\\\", \\\"{x:1299,y:842,t:1527628169303};\\\", \\\"{x:1299,y:843,t:1527628169319};\\\", \\\"{x:1295,y:845,t:1527628169336};\\\", \\\"{x:1292,y:847,t:1527628169353};\\\", \\\"{x:1290,y:848,t:1527628169369};\\\", \\\"{x:1288,y:851,t:1527628169386};\\\", \\\"{x:1286,y:855,t:1527628169402};\\\", \\\"{x:1283,y:857,t:1527628169418};\\\", \\\"{x:1282,y:858,t:1527628169436};\\\", \\\"{x:1279,y:862,t:1527628169452};\\\", \\\"{x:1278,y:864,t:1527628169468};\\\", \\\"{x:1278,y:865,t:1527628169485};\\\", \\\"{x:1277,y:867,t:1527628169503};\\\", \\\"{x:1277,y:869,t:1527628169519};\\\", \\\"{x:1277,y:870,t:1527628169535};\\\", \\\"{x:1277,y:871,t:1527628169553};\\\", \\\"{x:1277,y:869,t:1527628170094};\\\", \\\"{x:1277,y:865,t:1527628170102};\\\", \\\"{x:1277,y:863,t:1527628170113};\\\", \\\"{x:1279,y:859,t:1527628170130};\\\", \\\"{x:1279,y:858,t:1527628170146};\\\", \\\"{x:1280,y:856,t:1527628170164};\\\", \\\"{x:1280,y:855,t:1527628170229};\\\", \\\"{x:1282,y:853,t:1527628170247};\\\", \\\"{x:1286,y:848,t:1527628170263};\\\", \\\"{x:1291,y:841,t:1527628170281};\\\", \\\"{x:1296,y:835,t:1527628170297};\\\", \\\"{x:1303,y:830,t:1527628170313};\\\", \\\"{x:1310,y:824,t:1527628170330};\\\", \\\"{x:1315,y:820,t:1527628170347};\\\", \\\"{x:1318,y:818,t:1527628170364};\\\", \\\"{x:1322,y:814,t:1527628170380};\\\", \\\"{x:1323,y:814,t:1527628170397};\\\", \\\"{x:1324,y:814,t:1527628170413};\\\", \\\"{x:1325,y:813,t:1527628170430};\\\", \\\"{x:1326,y:813,t:1527628170447};\\\", \\\"{x:1327,y:813,t:1527628170478};\\\", \\\"{x:1328,y:813,t:1527628170485};\\\", \\\"{x:1329,y:813,t:1527628170497};\\\", \\\"{x:1335,y:814,t:1527628170513};\\\", \\\"{x:1344,y:821,t:1527628170530};\\\", \\\"{x:1358,y:829,t:1527628170548};\\\", \\\"{x:1367,y:836,t:1527628170564};\\\", \\\"{x:1377,y:840,t:1527628170580};\\\", \\\"{x:1380,y:842,t:1527628170597};\\\", \\\"{x:1381,y:843,t:1527628170645};\\\", \\\"{x:1382,y:844,t:1527628170654};\\\", \\\"{x:1382,y:845,t:1527628170664};\\\", \\\"{x:1382,y:848,t:1527628170680};\\\", \\\"{x:1382,y:853,t:1527628170697};\\\", \\\"{x:1382,y:855,t:1527628170714};\\\", \\\"{x:1383,y:856,t:1527628170730};\\\", \\\"{x:1384,y:858,t:1527628170747};\\\", \\\"{x:1384,y:860,t:1527628170764};\\\", \\\"{x:1384,y:863,t:1527628170780};\\\", \\\"{x:1382,y:868,t:1527628170798};\\\", \\\"{x:1382,y:872,t:1527628170814};\\\", \\\"{x:1382,y:875,t:1527628170830};\\\", \\\"{x:1381,y:881,t:1527628170847};\\\", \\\"{x:1381,y:884,t:1527628170865};\\\", \\\"{x:1379,y:888,t:1527628170880};\\\", \\\"{x:1379,y:889,t:1527628170897};\\\", \\\"{x:1379,y:890,t:1527628171150};\\\", \\\"{x:1379,y:892,t:1527628171165};\\\", \\\"{x:1381,y:894,t:1527628171182};\\\", \\\"{x:1381,y:896,t:1527628171198};\\\", \\\"{x:1384,y:896,t:1527628171214};\\\", \\\"{x:1387,y:896,t:1527628171231};\\\", \\\"{x:1388,y:896,t:1527628171247};\\\", \\\"{x:1390,y:896,t:1527628171264};\\\", \\\"{x:1389,y:896,t:1527628171518};\\\", \\\"{x:1389,y:892,t:1527628171532};\\\", \\\"{x:1387,y:888,t:1527628171548};\\\", \\\"{x:1387,y:887,t:1527628171564};\\\", \\\"{x:1386,y:881,t:1527628171582};\\\", \\\"{x:1386,y:877,t:1527628171597};\\\", \\\"{x:1385,y:871,t:1527628171613};\\\", \\\"{x:1383,y:864,t:1527628171631};\\\", \\\"{x:1383,y:857,t:1527628171647};\\\", \\\"{x:1382,y:848,t:1527628171664};\\\", \\\"{x:1378,y:837,t:1527628171681};\\\", \\\"{x:1376,y:825,t:1527628171697};\\\", \\\"{x:1374,y:820,t:1527628171713};\\\", \\\"{x:1373,y:813,t:1527628171731};\\\", \\\"{x:1373,y:810,t:1527628171748};\\\", \\\"{x:1373,y:808,t:1527628171763};\\\", \\\"{x:1373,y:804,t:1527628171781};\\\", \\\"{x:1373,y:802,t:1527628171798};\\\", \\\"{x:1373,y:799,t:1527628171814};\\\", \\\"{x:1372,y:796,t:1527628171831};\\\", \\\"{x:1370,y:792,t:1527628171847};\\\", \\\"{x:1369,y:789,t:1527628171869};\\\", \\\"{x:1369,y:787,t:1527628171881};\\\", \\\"{x:1367,y:783,t:1527628171898};\\\", \\\"{x:1367,y:781,t:1527628171915};\\\", \\\"{x:1365,y:774,t:1527628171931};\\\", \\\"{x:1363,y:766,t:1527628171948};\\\", \\\"{x:1357,y:750,t:1527628171965};\\\", \\\"{x:1352,y:744,t:1527628171981};\\\", \\\"{x:1349,y:735,t:1527628171998};\\\", \\\"{x:1347,y:731,t:1527628172015};\\\", \\\"{x:1345,y:725,t:1527628172031};\\\", \\\"{x:1344,y:719,t:1527628172048};\\\", \\\"{x:1340,y:711,t:1527628172066};\\\", \\\"{x:1336,y:703,t:1527628172081};\\\", \\\"{x:1334,y:697,t:1527628172098};\\\", \\\"{x:1333,y:693,t:1527628172115};\\\", \\\"{x:1332,y:690,t:1527628172131};\\\", \\\"{x:1330,y:686,t:1527628172148};\\\", \\\"{x:1326,y:677,t:1527628172165};\\\", \\\"{x:1324,y:673,t:1527628172182};\\\", \\\"{x:1323,y:671,t:1527628172199};\\\", \\\"{x:1322,y:668,t:1527628172215};\\\", \\\"{x:1321,y:666,t:1527628172231};\\\", \\\"{x:1320,y:665,t:1527628172248};\\\", \\\"{x:1320,y:663,t:1527628172265};\\\", \\\"{x:1320,y:661,t:1527628172282};\\\", \\\"{x:1319,y:660,t:1527628172298};\\\", \\\"{x:1318,y:658,t:1527628172314};\\\", \\\"{x:1317,y:658,t:1527628172331};\\\", \\\"{x:1317,y:656,t:1527628172348};\\\", \\\"{x:1317,y:655,t:1527628172365};\\\", \\\"{x:1317,y:652,t:1527628172381};\\\", \\\"{x:1317,y:649,t:1527628172397};\\\", \\\"{x:1315,y:646,t:1527628172414};\\\", \\\"{x:1314,y:645,t:1527628172431};\\\", \\\"{x:1314,y:644,t:1527628172469};\\\", \\\"{x:1313,y:644,t:1527628173630};\\\", \\\"{x:1312,y:648,t:1527628173639};\\\", \\\"{x:1312,y:650,t:1527628173649};\\\", \\\"{x:1312,y:659,t:1527628173666};\\\", \\\"{x:1312,y:668,t:1527628173683};\\\", \\\"{x:1312,y:681,t:1527628173700};\\\", \\\"{x:1312,y:698,t:1527628173716};\\\", \\\"{x:1312,y:721,t:1527628173733};\\\", \\\"{x:1312,y:738,t:1527628173749};\\\", \\\"{x:1312,y:749,t:1527628173766};\\\", \\\"{x:1311,y:759,t:1527628173783};\\\", \\\"{x:1310,y:764,t:1527628173799};\\\", \\\"{x:1310,y:776,t:1527628173816};\\\", \\\"{x:1310,y:792,t:1527628173833};\\\", \\\"{x:1310,y:797,t:1527628173848};\\\", \\\"{x:1310,y:809,t:1527628173865};\\\", \\\"{x:1310,y:819,t:1527628173883};\\\", \\\"{x:1310,y:830,t:1527628173899};\\\", \\\"{x:1310,y:841,t:1527628173915};\\\", \\\"{x:1310,y:858,t:1527628173932};\\\", \\\"{x:1310,y:865,t:1527628173950};\\\", \\\"{x:1310,y:871,t:1527628173965};\\\", \\\"{x:1310,y:877,t:1527628173982};\\\", \\\"{x:1311,y:884,t:1527628173998};\\\", \\\"{x:1311,y:890,t:1527628174016};\\\", \\\"{x:1312,y:893,t:1527628174033};\\\", \\\"{x:1312,y:900,t:1527628174050};\\\", \\\"{x:1312,y:905,t:1527628174065};\\\", \\\"{x:1312,y:908,t:1527628174083};\\\", \\\"{x:1311,y:912,t:1527628174099};\\\", \\\"{x:1311,y:919,t:1527628174115};\\\", \\\"{x:1311,y:922,t:1527628174133};\\\", \\\"{x:1311,y:923,t:1527628174150};\\\", \\\"{x:1311,y:924,t:1527628174558};\\\", \\\"{x:1311,y:923,t:1527628174589};\\\", \\\"{x:1311,y:922,t:1527628174605};\\\", \\\"{x:1311,y:920,t:1527628174617};\\\", \\\"{x:1311,y:916,t:1527628174633};\\\", \\\"{x:1312,y:912,t:1527628174650};\\\", \\\"{x:1314,y:906,t:1527628174667};\\\", \\\"{x:1314,y:903,t:1527628174683};\\\", \\\"{x:1316,y:900,t:1527628174700};\\\", \\\"{x:1316,y:897,t:1527628174718};\\\", \\\"{x:1317,y:895,t:1527628174733};\\\", \\\"{x:1318,y:892,t:1527628174758};\\\", \\\"{x:1318,y:891,t:1527628174767};\\\", \\\"{x:1319,y:886,t:1527628174783};\\\", \\\"{x:1320,y:879,t:1527628174800};\\\", \\\"{x:1320,y:874,t:1527628174818};\\\", \\\"{x:1323,y:869,t:1527628174834};\\\", \\\"{x:1323,y:867,t:1527628174868};\\\", \\\"{x:1325,y:863,t:1527628174884};\\\", \\\"{x:1329,y:849,t:1527628174899};\\\", \\\"{x:1334,y:832,t:1527628174916};\\\", \\\"{x:1336,y:821,t:1527628174934};\\\", \\\"{x:1341,y:809,t:1527628174949};\\\", \\\"{x:1343,y:803,t:1527628174967};\\\", \\\"{x:1343,y:800,t:1527628174983};\\\", \\\"{x:1347,y:790,t:1527628174999};\\\", \\\"{x:1347,y:786,t:1527628175017};\\\", \\\"{x:1350,y:781,t:1527628175034};\\\", \\\"{x:1351,y:780,t:1527628175050};\\\", \\\"{x:1352,y:779,t:1527628175067};\\\", \\\"{x:1352,y:778,t:1527628175118};\\\", \\\"{x:1353,y:777,t:1527628175165};\\\", \\\"{x:1353,y:776,t:1527628175206};\\\", \\\"{x:1354,y:775,t:1527628175217};\\\", \\\"{x:1354,y:774,t:1527628175235};\\\", \\\"{x:1357,y:771,t:1527628175251};\\\", \\\"{x:1358,y:768,t:1527628175267};\\\", \\\"{x:1359,y:766,t:1527628175284};\\\", \\\"{x:1359,y:762,t:1527628175301};\\\", \\\"{x:1360,y:748,t:1527628175317};\\\", \\\"{x:1361,y:741,t:1527628175334};\\\", \\\"{x:1361,y:735,t:1527628175351};\\\", \\\"{x:1361,y:727,t:1527628175367};\\\", \\\"{x:1361,y:718,t:1527628175384};\\\", \\\"{x:1361,y:712,t:1527628175402};\\\", \\\"{x:1361,y:703,t:1527628175417};\\\", \\\"{x:1361,y:698,t:1527628175434};\\\", \\\"{x:1361,y:695,t:1527628175451};\\\", \\\"{x:1361,y:691,t:1527628175467};\\\", \\\"{x:1361,y:688,t:1527628175485};\\\", \\\"{x:1361,y:684,t:1527628175501};\\\", \\\"{x:1360,y:679,t:1527628175517};\\\", \\\"{x:1360,y:669,t:1527628175534};\\\", \\\"{x:1358,y:656,t:1527628175551};\\\", \\\"{x:1356,y:652,t:1527628175567};\\\", \\\"{x:1354,y:644,t:1527628175585};\\\", \\\"{x:1352,y:637,t:1527628175602};\\\", \\\"{x:1348,y:631,t:1527628175617};\\\", \\\"{x:1344,y:621,t:1527628175635};\\\", \\\"{x:1342,y:618,t:1527628175651};\\\", \\\"{x:1342,y:616,t:1527628175668};\\\", \\\"{x:1342,y:615,t:1527628176508};\\\", \\\"{x:1342,y:613,t:1527628176524};\\\", \\\"{x:1342,y:612,t:1527628176540};\\\", \\\"{x:1342,y:611,t:1527628176550};\\\", \\\"{x:1344,y:610,t:1527628176568};\\\", \\\"{x:1345,y:610,t:1527628176605};\\\", \\\"{x:1345,y:609,t:1527628176620};\\\", \\\"{x:1346,y:609,t:1527628176644};\\\", \\\"{x:1345,y:613,t:1527628176772};\\\", \\\"{x:1343,y:630,t:1527628176784};\\\", \\\"{x:1340,y:654,t:1527628176801};\\\", \\\"{x:1333,y:678,t:1527628176817};\\\", \\\"{x:1322,y:703,t:1527628176834};\\\", \\\"{x:1310,y:721,t:1527628176852};\\\", \\\"{x:1298,y:738,t:1527628176868};\\\", \\\"{x:1258,y:762,t:1527628176885};\\\", \\\"{x:1203,y:777,t:1527628176902};\\\", \\\"{x:1131,y:796,t:1527628176918};\\\", \\\"{x:1065,y:825,t:1527628176935};\\\", \\\"{x:982,y:846,t:1527628176952};\\\", \\\"{x:942,y:862,t:1527628176967};\\\", \\\"{x:904,y:877,t:1527628176984};\\\", \\\"{x:892,y:882,t:1527628177001};\\\", \\\"{x:890,y:882,t:1527628177018};\\\", \\\"{x:887,y:882,t:1527628177035};\\\", \\\"{x:880,y:880,t:1527628177051};\\\", \\\"{x:854,y:863,t:1527628177068};\\\", \\\"{x:813,y:832,t:1527628177085};\\\", \\\"{x:750,y:792,t:1527628177102};\\\", \\\"{x:694,y:756,t:1527628177119};\\\", \\\"{x:649,y:723,t:1527628177134};\\\", \\\"{x:599,y:690,t:1527628177151};\\\", \\\"{x:577,y:676,t:1527628177168};\\\", \\\"{x:554,y:668,t:1527628177185};\\\", \\\"{x:535,y:662,t:1527628177202};\\\", \\\"{x:531,y:662,t:1527628177219};\\\", \\\"{x:530,y:662,t:1527628177234};\\\", \\\"{x:527,y:662,t:1527628177251};\\\", \\\"{x:519,y:666,t:1527628177268};\\\", \\\"{x:512,y:671,t:1527628177285};\\\", \\\"{x:506,y:682,t:1527628177301};\\\", \\\"{x:504,y:693,t:1527628177319};\\\", \\\"{x:496,y:709,t:1527628177335};\\\", \\\"{x:494,y:719,t:1527628177352};\\\", \\\"{x:494,y:728,t:1527628177368};\\\", \\\"{x:495,y:733,t:1527628177385};\\\", \\\"{x:496,y:736,t:1527628177402};\\\", \\\"{x:496,y:738,t:1527628177419};\\\", \\\"{x:497,y:740,t:1527628177435};\\\", \\\"{x:498,y:742,t:1527628177452};\\\", \\\"{x:499,y:743,t:1527628177469};\\\", \\\"{x:500,y:743,t:1527628177620};\\\", \\\"{x:500,y:740,t:1527628177637};\\\", \\\"{x:500,y:736,t:1527628177652};\\\", \\\"{x:500,y:731,t:1527628177669};\\\", \\\"{x:500,y:730,t:1527628177686};\\\", \\\"{x:500,y:729,t:1527628177725};\\\", \\\"{x:500,y:729,t:1527628177751};\\\", \\\"{x:500,y:730,t:1527628178068};\\\", \\\"{x:505,y:737,t:1527628178086};\\\", \\\"{x:507,y:744,t:1527628178102};\\\", \\\"{x:511,y:752,t:1527628178118};\\\", \\\"{x:516,y:763,t:1527628178134};\\\", \\\"{x:520,y:767,t:1527628178152};\\\", \\\"{x:521,y:770,t:1527628178169};\\\", \\\"{x:524,y:775,t:1527628178184};\\\", \\\"{x:529,y:781,t:1527628178202};\\\", \\\"{x:532,y:787,t:1527628178219};\\\", \\\"{x:534,y:791,t:1527628178235};\\\", \\\"{x:540,y:797,t:1527628178252};\\\", \\\"{x:550,y:808,t:1527628178268};\\\", \\\"{x:556,y:816,t:1527628178285};\\\", \\\"{x:566,y:822,t:1527628178302};\\\", \\\"{x:570,y:828,t:1527628178319};\\\", \\\"{x:573,y:832,t:1527628178335};\\\", \\\"{x:576,y:837,t:1527628178351};\\\", \\\"{x:580,y:841,t:1527628178368};\\\", \\\"{x:584,y:844,t:1527628178385};\\\", \\\"{x:586,y:847,t:1527628178402};\\\", \\\"{x:588,y:849,t:1527628178417};\\\", \\\"{x:588,y:850,t:1527628178436};\\\", \\\"{x:589,y:850,t:1527628178493};\\\", \\\"{x:589,y:851,t:1527628178501};\\\", \\\"{x:589,y:854,t:1527628178518};\\\", \\\"{x:589,y:855,t:1527628178535};\\\", \\\"{x:589,y:856,t:1527628178612};\\\" ] }, { \\\"rt\\\": 69849, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 498731, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -6-I -7-7-I -I -O -O -03 PM-Z -K -K -K -F -F -G -B -B -B -E -K -J \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:587,y:855,t:1527628179141};\\\", \\\"{x:586,y:853,t:1527628179154};\\\", \\\"{x:582,y:843,t:1527628179170};\\\", \\\"{x:568,y:820,t:1527628179203};\\\", \\\"{x:556,y:799,t:1527628179220};\\\", \\\"{x:549,y:782,t:1527628179237};\\\", \\\"{x:535,y:762,t:1527628179253};\\\", \\\"{x:512,y:724,t:1527628179270};\\\", \\\"{x:486,y:675,t:1527628179286};\\\", \\\"{x:471,y:653,t:1527628179304};\\\", \\\"{x:464,y:637,t:1527628179319};\\\", \\\"{x:460,y:628,t:1527628179337};\\\", \\\"{x:455,y:622,t:1527628179354};\\\", \\\"{x:452,y:615,t:1527628179370};\\\", \\\"{x:451,y:609,t:1527628179387};\\\", \\\"{x:449,y:597,t:1527628179404};\\\", \\\"{x:444,y:586,t:1527628179420};\\\", \\\"{x:443,y:580,t:1527628179437};\\\", \\\"{x:442,y:574,t:1527628179453};\\\", \\\"{x:440,y:569,t:1527628179470};\\\", \\\"{x:439,y:564,t:1527628179487};\\\", \\\"{x:439,y:558,t:1527628179504};\\\", \\\"{x:439,y:551,t:1527628179521};\\\", \\\"{x:439,y:542,t:1527628179536};\\\", \\\"{x:439,y:535,t:1527628179554};\\\", \\\"{x:439,y:513,t:1527628179651};\\\", \\\"{x:439,y:512,t:1527628179654};\\\", \\\"{x:439,y:509,t:1527628179671};\\\", \\\"{x:439,y:507,t:1527628179687};\\\", \\\"{x:439,y:506,t:1527628179703};\\\", \\\"{x:439,y:503,t:1527628179720};\\\", \\\"{x:439,y:502,t:1527628179741};\\\", \\\"{x:439,y:501,t:1527628179805};\\\", \\\"{x:439,y:500,t:1527628179956};\\\", \\\"{x:439,y:499,t:1527628179969};\\\", \\\"{x:438,y:496,t:1527628179987};\\\", \\\"{x:436,y:495,t:1527628180003};\\\", \\\"{x:434,y:493,t:1527628180020};\\\", \\\"{x:426,y:489,t:1527628180036};\\\", \\\"{x:424,y:488,t:1527628180052};\\\", \\\"{x:421,y:486,t:1527628180070};\\\", \\\"{x:417,y:483,t:1527628180087};\\\", \\\"{x:417,y:482,t:1527628180103};\\\", \\\"{x:415,y:482,t:1527628180120};\\\", \\\"{x:415,y:481,t:1527628180137};\\\", \\\"{x:414,y:481,t:1527628180181};\\\", \\\"{x:414,y:480,t:1527628180188};\\\", \\\"{x:413,y:480,t:1527628180202};\\\", \\\"{x:411,y:478,t:1527628180220};\\\", \\\"{x:409,y:476,t:1527628180236};\\\", \\\"{x:408,y:475,t:1527628180252};\\\", \\\"{x:406,y:474,t:1527628180270};\\\", \\\"{x:404,y:473,t:1527628180285};\\\", \\\"{x:403,y:472,t:1527628180303};\\\", \\\"{x:401,y:472,t:1527628180320};\\\", \\\"{x:399,y:471,t:1527628180336};\\\", \\\"{x:398,y:471,t:1527628180353};\\\", \\\"{x:397,y:471,t:1527628180372};\\\", \\\"{x:395,y:470,t:1527628180396};\\\", \\\"{x:392,y:470,t:1527628180412};\\\", \\\"{x:390,y:470,t:1527628180420};\\\", \\\"{x:388,y:470,t:1527628180435};\\\", \\\"{x:384,y:470,t:1527628180452};\\\", \\\"{x:382,y:469,t:1527628180469};\\\", \\\"{x:380,y:468,t:1527628180485};\\\", \\\"{x:378,y:468,t:1527628180503};\\\", \\\"{x:375,y:468,t:1527628180518};\\\", \\\"{x:373,y:468,t:1527628180535};\\\", \\\"{x:372,y:468,t:1527628180552};\\\", \\\"{x:372,y:467,t:1527628180569};\\\", \\\"{x:371,y:467,t:1527628180596};\\\", \\\"{x:372,y:466,t:1527628186805};\\\", \\\"{x:380,y:462,t:1527628186812};\\\", \\\"{x:406,y:465,t:1527628186827};\\\", \\\"{x:435,y:470,t:1527628186845};\\\", \\\"{x:483,y:476,t:1527628186861};\\\", \\\"{x:509,y:482,t:1527628186878};\\\", \\\"{x:538,y:487,t:1527628186895};\\\", \\\"{x:559,y:491,t:1527628186910};\\\", \\\"{x:579,y:493,t:1527628186928};\\\", \\\"{x:607,y:500,t:1527628186945};\\\", \\\"{x:645,y:507,t:1527628186961};\\\", \\\"{x:676,y:517,t:1527628186978};\\\", \\\"{x:699,y:528,t:1527628186994};\\\", \\\"{x:741,y:546,t:1527628187011};\\\", \\\"{x:783,y:565,t:1527628187027};\\\", \\\"{x:815,y:580,t:1527628187043};\\\", \\\"{x:863,y:604,t:1527628187061};\\\", \\\"{x:911,y:634,t:1527628187078};\\\", \\\"{x:968,y:665,t:1527628187092};\\\", \\\"{x:1020,y:697,t:1527628187110};\\\", \\\"{x:1068,y:728,t:1527628187127};\\\", \\\"{x:1113,y:753,t:1527628187142};\\\", \\\"{x:1162,y:779,t:1527628187160};\\\", \\\"{x:1214,y:802,t:1527628187177};\\\", \\\"{x:1241,y:818,t:1527628187193};\\\", \\\"{x:1267,y:832,t:1527628187210};\\\", \\\"{x:1292,y:843,t:1527628187227};\\\", \\\"{x:1311,y:856,t:1527628187243};\\\", \\\"{x:1342,y:871,t:1527628187260};\\\", \\\"{x:1358,y:880,t:1527628187277};\\\", \\\"{x:1371,y:890,t:1527628187294};\\\", \\\"{x:1379,y:898,t:1527628187310};\\\", \\\"{x:1389,y:902,t:1527628187327};\\\", \\\"{x:1395,y:906,t:1527628187344};\\\", \\\"{x:1396,y:907,t:1527628187372};\\\", \\\"{x:1384,y:902,t:1527628188941};\\\", \\\"{x:1344,y:889,t:1527628188948};\\\", \\\"{x:1295,y:877,t:1527628188963};\\\", \\\"{x:1187,y:846,t:1527628188979};\\\", \\\"{x:1008,y:800,t:1527628188996};\\\", \\\"{x:895,y:769,t:1527628189013};\\\", \\\"{x:790,y:743,t:1527628189029};\\\", \\\"{x:696,y:716,t:1527628189046};\\\", \\\"{x:616,y:682,t:1527628189063};\\\", \\\"{x:557,y:656,t:1527628189080};\\\", \\\"{x:525,y:639,t:1527628189096};\\\", \\\"{x:507,y:628,t:1527628189111};\\\", \\\"{x:496,y:621,t:1527628189128};\\\", \\\"{x:491,y:617,t:1527628189145};\\\", \\\"{x:486,y:611,t:1527628189161};\\\", \\\"{x:477,y:602,t:1527628189178};\\\", \\\"{x:467,y:593,t:1527628189195};\\\", \\\"{x:454,y:582,t:1527628189212};\\\", \\\"{x:441,y:574,t:1527628189228};\\\", \\\"{x:430,y:566,t:1527628189245};\\\", \\\"{x:423,y:560,t:1527628189262};\\\", \\\"{x:418,y:557,t:1527628189278};\\\", \\\"{x:413,y:551,t:1527628189295};\\\", \\\"{x:403,y:543,t:1527628189312};\\\", \\\"{x:395,y:537,t:1527628189327};\\\", \\\"{x:387,y:528,t:1527628189344};\\\", \\\"{x:383,y:525,t:1527628189362};\\\", \\\"{x:381,y:522,t:1527628189379};\\\", \\\"{x:378,y:517,t:1527628189395};\\\", \\\"{x:374,y:510,t:1527628189411};\\\", \\\"{x:370,y:504,t:1527628189428};\\\", \\\"{x:367,y:501,t:1527628189445};\\\", \\\"{x:365,y:498,t:1527628189462};\\\", \\\"{x:365,y:497,t:1527628189478};\\\", \\\"{x:365,y:496,t:1527628189516};\\\", \\\"{x:365,y:495,t:1527628189556};\\\", \\\"{x:366,y:493,t:1527628189564};\\\", \\\"{x:367,y:491,t:1527628189580};\\\", \\\"{x:368,y:490,t:1527628189595};\\\", \\\"{x:377,y:483,t:1527628189612};\\\", \\\"{x:391,y:477,t:1527628189628};\\\", \\\"{x:412,y:471,t:1527628189645};\\\", \\\"{x:430,y:462,t:1527628189661};\\\", \\\"{x:453,y:456,t:1527628189678};\\\", \\\"{x:463,y:451,t:1527628189695};\\\", \\\"{x:470,y:449,t:1527628189712};\\\", \\\"{x:471,y:449,t:1527628189772};\\\", \\\"{x:472,y:448,t:1527628189780};\\\", \\\"{x:473,y:448,t:1527628189795};\\\", \\\"{x:475,y:448,t:1527628189812};\\\", \\\"{x:480,y:448,t:1527628189828};\\\", \\\"{x:485,y:448,t:1527628189845};\\\", \\\"{x:488,y:448,t:1527628189862};\\\", \\\"{x:490,y:448,t:1527628189878};\\\", \\\"{x:491,y:448,t:1527628189895};\\\", \\\"{x:491,y:450,t:1527628190124};\\\", \\\"{x:491,y:452,t:1527628190131};\\\", \\\"{x:488,y:459,t:1527628190145};\\\", \\\"{x:486,y:460,t:1527628190162};\\\", \\\"{x:480,y:465,t:1527628190178};\\\", \\\"{x:478,y:469,t:1527628190195};\\\", \\\"{x:475,y:471,t:1527628190212};\\\", \\\"{x:474,y:471,t:1527628190229};\\\", \\\"{x:473,y:471,t:1527628190508};\\\", \\\"{x:472,y:471,t:1527628190524};\\\", \\\"{x:471,y:471,t:1527628190539};\\\", \\\"{x:470,y:471,t:1527628190548};\\\", \\\"{x:468,y:471,t:1527628190562};\\\", \\\"{x:459,y:471,t:1527628190579};\\\", \\\"{x:455,y:471,t:1527628190595};\\\", \\\"{x:446,y:471,t:1527628190611};\\\", \\\"{x:444,y:471,t:1527628190628};\\\", \\\"{x:441,y:471,t:1527628190645};\\\", \\\"{x:442,y:471,t:1527628190996};\\\", \\\"{x:445,y:471,t:1527628191012};\\\", \\\"{x:452,y:469,t:1527628191029};\\\", \\\"{x:464,y:467,t:1527628191045};\\\", \\\"{x:475,y:465,t:1527628191062};\\\", \\\"{x:482,y:465,t:1527628191079};\\\", \\\"{x:488,y:465,t:1527628191095};\\\", \\\"{x:491,y:464,t:1527628191112};\\\", \\\"{x:492,y:464,t:1527628191156};\\\", \\\"{x:495,y:464,t:1527628191172};\\\", \\\"{x:498,y:464,t:1527628191180};\\\", \\\"{x:503,y:464,t:1527628191195};\\\", \\\"{x:529,y:464,t:1527628191212};\\\", \\\"{x:543,y:464,t:1527628191229};\\\", \\\"{x:555,y:465,t:1527628191246};\\\", \\\"{x:559,y:465,t:1527628191262};\\\", \\\"{x:563,y:464,t:1527628191278};\\\", \\\"{x:565,y:464,t:1527628191296};\\\", \\\"{x:566,y:463,t:1527628191312};\\\", \\\"{x:567,y:463,t:1527628191331};\\\", \\\"{x:569,y:463,t:1527628191346};\\\", \\\"{x:571,y:463,t:1527628191362};\\\", \\\"{x:574,y:463,t:1527628191379};\\\", \\\"{x:578,y:463,t:1527628191396};\\\", \\\"{x:581,y:463,t:1527628191412};\\\", \\\"{x:582,y:463,t:1527628191429};\\\", \\\"{x:583,y:463,t:1527628191446};\\\", \\\"{x:581,y:464,t:1527628191620};\\\", \\\"{x:575,y:464,t:1527628191629};\\\", \\\"{x:558,y:471,t:1527628191646};\\\", \\\"{x:539,y:472,t:1527628191662};\\\", \\\"{x:514,y:474,t:1527628191679};\\\", \\\"{x:501,y:474,t:1527628191696};\\\", \\\"{x:485,y:474,t:1527628191712};\\\", \\\"{x:476,y:474,t:1527628191729};\\\", \\\"{x:468,y:474,t:1527628191746};\\\", \\\"{x:464,y:474,t:1527628191761};\\\", \\\"{x:461,y:474,t:1527628191779};\\\", \\\"{x:454,y:474,t:1527628191796};\\\", \\\"{x:446,y:474,t:1527628191812};\\\", \\\"{x:437,y:474,t:1527628191829};\\\", \\\"{x:432,y:474,t:1527628191846};\\\", \\\"{x:425,y:474,t:1527628191862};\\\", \\\"{x:422,y:474,t:1527628191879};\\\", \\\"{x:418,y:475,t:1527628191896};\\\", \\\"{x:415,y:476,t:1527628191911};\\\", \\\"{x:410,y:476,t:1527628191928};\\\", \\\"{x:408,y:476,t:1527628191945};\\\", \\\"{x:407,y:476,t:1527628191962};\\\", \\\"{x:405,y:477,t:1527628191979};\\\", \\\"{x:405,y:478,t:1527628191996};\\\", \\\"{x:405,y:479,t:1527628192180};\\\", \\\"{x:425,y:484,t:1527628192196};\\\", \\\"{x:449,y:485,t:1527628192212};\\\", \\\"{x:479,y:489,t:1527628192228};\\\", \\\"{x:509,y:491,t:1527628192246};\\\", \\\"{x:527,y:493,t:1527628192262};\\\", \\\"{x:539,y:494,t:1527628192279};\\\", \\\"{x:548,y:494,t:1527628192296};\\\", \\\"{x:555,y:494,t:1527628192312};\\\", \\\"{x:561,y:494,t:1527628192329};\\\", \\\"{x:567,y:495,t:1527628192346};\\\", \\\"{x:580,y:495,t:1527628192362};\\\", \\\"{x:597,y:495,t:1527628192379};\\\", \\\"{x:626,y:496,t:1527628192396};\\\", \\\"{x:642,y:496,t:1527628192413};\\\", \\\"{x:655,y:496,t:1527628192429};\\\", \\\"{x:661,y:496,t:1527628192446};\\\", \\\"{x:669,y:495,t:1527628192463};\\\", \\\"{x:675,y:494,t:1527628192478};\\\", \\\"{x:678,y:496,t:1527628192972};\\\", \\\"{x:687,y:501,t:1527628192980};\\\", \\\"{x:711,y:509,t:1527628192996};\\\", \\\"{x:736,y:513,t:1527628193013};\\\", \\\"{x:764,y:519,t:1527628193029};\\\", \\\"{x:795,y:524,t:1527628193046};\\\", \\\"{x:827,y:525,t:1527628193062};\\\", \\\"{x:856,y:530,t:1527628193081};\\\", \\\"{x:875,y:531,t:1527628193098};\\\", \\\"{x:897,y:533,t:1527628193115};\\\", \\\"{x:925,y:533,t:1527628193131};\\\", \\\"{x:961,y:539,t:1527628193148};\\\", \\\"{x:983,y:548,t:1527628193165};\\\", \\\"{x:1004,y:552,t:1527628193181};\\\", \\\"{x:1024,y:555,t:1527628193198};\\\", \\\"{x:1042,y:557,t:1527628193215};\\\", \\\"{x:1059,y:563,t:1527628193231};\\\", \\\"{x:1076,y:567,t:1527628193248};\\\", \\\"{x:1095,y:571,t:1527628193265};\\\", \\\"{x:1116,y:575,t:1527628193281};\\\", \\\"{x:1130,y:575,t:1527628193298};\\\", \\\"{x:1140,y:575,t:1527628193315};\\\", \\\"{x:1144,y:575,t:1527628193331};\\\", \\\"{x:1148,y:575,t:1527628193348};\\\", \\\"{x:1151,y:572,t:1527628193365};\\\", \\\"{x:1161,y:568,t:1527628193381};\\\", \\\"{x:1170,y:562,t:1527628193398};\\\", \\\"{x:1186,y:554,t:1527628193416};\\\", \\\"{x:1196,y:548,t:1527628193431};\\\", \\\"{x:1204,y:544,t:1527628193448};\\\", \\\"{x:1213,y:539,t:1527628193465};\\\", \\\"{x:1223,y:532,t:1527628193481};\\\", \\\"{x:1234,y:524,t:1527628193498};\\\", \\\"{x:1240,y:520,t:1527628193515};\\\", \\\"{x:1255,y:511,t:1527628193532};\\\", \\\"{x:1263,y:508,t:1527628193548};\\\", \\\"{x:1270,y:504,t:1527628193565};\\\", \\\"{x:1275,y:502,t:1527628193582};\\\", \\\"{x:1279,y:501,t:1527628193598};\\\", \\\"{x:1283,y:498,t:1527628193615};\\\", \\\"{x:1284,y:498,t:1527628193632};\\\", \\\"{x:1285,y:498,t:1527628193660};\\\", \\\"{x:1286,y:498,t:1527628193675};\\\", \\\"{x:1288,y:495,t:1527628193683};\\\", \\\"{x:1290,y:494,t:1527628193708};\\\", \\\"{x:1291,y:494,t:1527628193716};\\\", \\\"{x:1294,y:494,t:1527628193740};\\\", \\\"{x:1295,y:494,t:1527628193763};\\\", \\\"{x:1297,y:494,t:1527628193772};\\\", \\\"{x:1298,y:494,t:1527628193782};\\\", \\\"{x:1305,y:494,t:1527628193798};\\\", \\\"{x:1310,y:496,t:1527628193815};\\\", \\\"{x:1312,y:499,t:1527628193832};\\\", \\\"{x:1315,y:499,t:1527628193848};\\\", \\\"{x:1316,y:503,t:1527628195684};\\\", \\\"{x:1318,y:519,t:1527628195700};\\\", \\\"{x:1319,y:527,t:1527628195716};\\\", \\\"{x:1319,y:530,t:1527628195733};\\\", \\\"{x:1319,y:531,t:1527628195750};\\\", \\\"{x:1319,y:533,t:1527628195766};\\\", \\\"{x:1320,y:536,t:1527628195783};\\\", \\\"{x:1321,y:538,t:1527628195800};\\\", \\\"{x:1323,y:543,t:1527628195816};\\\", \\\"{x:1323,y:545,t:1527628195833};\\\", \\\"{x:1324,y:546,t:1527628195850};\\\", \\\"{x:1325,y:548,t:1527628195867};\\\", \\\"{x:1326,y:551,t:1527628195883};\\\", \\\"{x:1326,y:557,t:1527628195900};\\\", \\\"{x:1326,y:561,t:1527628195917};\\\", \\\"{x:1326,y:564,t:1527628195933};\\\", \\\"{x:1326,y:566,t:1527628195950};\\\", \\\"{x:1324,y:570,t:1527628195967};\\\", \\\"{x:1324,y:573,t:1527628195983};\\\", \\\"{x:1325,y:575,t:1527628196000};\\\", \\\"{x:1326,y:579,t:1527628196017};\\\", \\\"{x:1327,y:585,t:1527628196033};\\\", \\\"{x:1327,y:592,t:1527628196051};\\\", \\\"{x:1327,y:598,t:1527628196067};\\\", \\\"{x:1327,y:603,t:1527628196083};\\\", \\\"{x:1326,y:616,t:1527628196100};\\\", \\\"{x:1324,y:623,t:1527628196117};\\\", \\\"{x:1323,y:629,t:1527628196133};\\\", \\\"{x:1322,y:637,t:1527628196150};\\\", \\\"{x:1321,y:643,t:1527628196168};\\\", \\\"{x:1319,y:651,t:1527628196183};\\\", \\\"{x:1319,y:658,t:1527628196200};\\\", \\\"{x:1317,y:663,t:1527628196217};\\\", \\\"{x:1315,y:675,t:1527628196233};\\\", \\\"{x:1314,y:683,t:1527628196250};\\\", \\\"{x:1312,y:696,t:1527628196267};\\\", \\\"{x:1309,y:708,t:1527628196283};\\\", \\\"{x:1307,y:726,t:1527628196300};\\\", \\\"{x:1304,y:738,t:1527628196317};\\\", \\\"{x:1304,y:744,t:1527628196334};\\\", \\\"{x:1304,y:753,t:1527628196350};\\\", \\\"{x:1304,y:764,t:1527628196367};\\\", \\\"{x:1304,y:772,t:1527628196384};\\\", \\\"{x:1304,y:781,t:1527628196400};\\\", \\\"{x:1304,y:792,t:1527628196417};\\\", \\\"{x:1304,y:797,t:1527628196434};\\\", \\\"{x:1304,y:803,t:1527628196450};\\\", \\\"{x:1304,y:807,t:1527628196467};\\\", \\\"{x:1305,y:813,t:1527628196483};\\\", \\\"{x:1306,y:819,t:1527628196501};\\\", \\\"{x:1306,y:823,t:1527628196517};\\\", \\\"{x:1306,y:827,t:1527628196534};\\\", \\\"{x:1309,y:832,t:1527628196550};\\\", \\\"{x:1309,y:834,t:1527628196567};\\\", \\\"{x:1310,y:839,t:1527628196584};\\\", \\\"{x:1310,y:842,t:1527628196600};\\\", \\\"{x:1310,y:845,t:1527628196617};\\\", \\\"{x:1312,y:850,t:1527628196634};\\\", \\\"{x:1312,y:855,t:1527628196650};\\\", \\\"{x:1312,y:858,t:1527628196667};\\\", \\\"{x:1312,y:864,t:1527628196683};\\\", \\\"{x:1312,y:870,t:1527628196700};\\\", \\\"{x:1312,y:874,t:1527628196717};\\\", \\\"{x:1312,y:879,t:1527628196734};\\\", \\\"{x:1312,y:886,t:1527628196750};\\\", \\\"{x:1312,y:893,t:1527628196767};\\\", \\\"{x:1312,y:894,t:1527628196784};\\\", \\\"{x:1312,y:902,t:1527628196801};\\\", \\\"{x:1312,y:911,t:1527628196817};\\\", \\\"{x:1312,y:915,t:1527628196834};\\\", \\\"{x:1312,y:920,t:1527628196851};\\\", \\\"{x:1312,y:925,t:1527628196867};\\\", \\\"{x:1314,y:930,t:1527628196884};\\\", \\\"{x:1314,y:932,t:1527628196901};\\\", \\\"{x:1314,y:934,t:1527628196931};\\\", \\\"{x:1314,y:935,t:1527628196940};\\\", \\\"{x:1314,y:936,t:1527628196951};\\\", \\\"{x:1314,y:939,t:1527628196968};\\\", \\\"{x:1316,y:942,t:1527628196984};\\\", \\\"{x:1317,y:945,t:1527628197001};\\\", \\\"{x:1319,y:947,t:1527628197017};\\\", \\\"{x:1319,y:948,t:1527628197034};\\\", \\\"{x:1319,y:951,t:1527628197051};\\\", \\\"{x:1319,y:953,t:1527628197067};\\\", \\\"{x:1320,y:958,t:1527628197084};\\\", \\\"{x:1320,y:959,t:1527628197101};\\\", \\\"{x:1320,y:961,t:1527628197117};\\\", \\\"{x:1321,y:964,t:1527628197134};\\\", \\\"{x:1321,y:966,t:1527628197151};\\\", \\\"{x:1321,y:967,t:1527628197171};\\\", \\\"{x:1321,y:968,t:1527628197188};\\\", \\\"{x:1321,y:969,t:1527628197212};\\\", \\\"{x:1322,y:971,t:1527628197220};\\\", \\\"{x:1323,y:973,t:1527628197244};\\\", \\\"{x:1324,y:975,t:1527628197276};\\\", \\\"{x:1324,y:976,t:1527628197284};\\\", \\\"{x:1325,y:976,t:1527628197301};\\\", \\\"{x:1325,y:977,t:1527628197436};\\\", \\\"{x:1325,y:978,t:1527628197500};\\\", \\\"{x:1325,y:979,t:1527628197516};\\\", \\\"{x:1323,y:979,t:1527628197556};\\\", \\\"{x:1322,y:979,t:1527628197612};\\\", \\\"{x:1321,y:979,t:1527628197644};\\\", \\\"{x:1319,y:980,t:1527628197668};\\\", \\\"{x:1318,y:980,t:1527628197740};\\\", \\\"{x:1317,y:980,t:1527628197751};\\\", \\\"{x:1316,y:979,t:1527628197779};\\\", \\\"{x:1314,y:979,t:1527628197796};\\\", \\\"{x:1314,y:978,t:1527628197812};\\\", \\\"{x:1313,y:978,t:1527628197868};\\\", \\\"{x:1313,y:977,t:1527628198084};\\\", \\\"{x:1313,y:976,t:1527628198099};\\\", \\\"{x:1313,y:975,t:1527628198107};\\\", \\\"{x:1313,y:974,t:1527628198132};\\\", \\\"{x:1313,y:973,t:1527628206659};\\\", \\\"{x:1315,y:972,t:1527628206675};\\\", \\\"{x:1323,y:962,t:1527628206691};\\\", \\\"{x:1323,y:959,t:1527628206708};\\\", \\\"{x:1325,y:956,t:1527628206725};\\\", \\\"{x:1326,y:950,t:1527628206741};\\\", \\\"{x:1327,y:945,t:1527628206758};\\\", \\\"{x:1327,y:941,t:1527628206774};\\\", \\\"{x:1327,y:940,t:1527628206791};\\\", \\\"{x:1328,y:939,t:1527628206809};\\\", \\\"{x:1329,y:938,t:1527628206825};\\\", \\\"{x:1329,y:937,t:1527628206844};\\\", \\\"{x:1329,y:935,t:1527628206859};\\\", \\\"{x:1329,y:934,t:1527628206875};\\\", \\\"{x:1331,y:931,t:1527628206891};\\\", \\\"{x:1333,y:928,t:1527628206908};\\\", \\\"{x:1333,y:926,t:1527628206925};\\\", \\\"{x:1334,y:924,t:1527628206941};\\\", \\\"{x:1335,y:924,t:1527628206959};\\\", \\\"{x:1335,y:923,t:1527628206974};\\\", \\\"{x:1335,y:922,t:1527628207388};\\\", \\\"{x:1335,y:928,t:1527628207403};\\\", \\\"{x:1335,y:934,t:1527628207411};\\\", \\\"{x:1335,y:938,t:1527628207425};\\\", \\\"{x:1335,y:945,t:1527628207441};\\\", \\\"{x:1335,y:949,t:1527628207458};\\\", \\\"{x:1335,y:950,t:1527628207475};\\\", \\\"{x:1335,y:952,t:1527628207555};\\\", \\\"{x:1334,y:953,t:1527628207563};\\\", \\\"{x:1334,y:955,t:1527628207576};\\\", \\\"{x:1332,y:957,t:1527628207592};\\\", \\\"{x:1332,y:958,t:1527628207609};\\\", \\\"{x:1332,y:959,t:1527628207626};\\\", \\\"{x:1331,y:956,t:1527628208028};\\\", \\\"{x:1328,y:946,t:1527628208042};\\\", \\\"{x:1321,y:930,t:1527628208059};\\\", \\\"{x:1312,y:900,t:1527628208075};\\\", \\\"{x:1305,y:872,t:1527628208093};\\\", \\\"{x:1295,y:830,t:1527628208108};\\\", \\\"{x:1289,y:788,t:1527628208125};\\\", \\\"{x:1263,y:684,t:1527628208142};\\\", \\\"{x:1236,y:569,t:1527628208160};\\\", \\\"{x:1202,y:489,t:1527628208175};\\\", \\\"{x:1169,y:447,t:1527628208192};\\\", \\\"{x:1131,y:408,t:1527628208209};\\\", \\\"{x:1100,y:367,t:1527628208225};\\\", \\\"{x:1086,y:349,t:1527628208243};\\\", \\\"{x:1084,y:349,t:1527628208259};\\\", \\\"{x:1083,y:347,t:1527628208275};\\\", \\\"{x:1081,y:346,t:1527628208299};\\\", \\\"{x:1080,y:347,t:1527628208339};\\\", \\\"{x:1080,y:352,t:1527628208347};\\\", \\\"{x:1079,y:360,t:1527628208359};\\\", \\\"{x:1076,y:370,t:1527628208375};\\\", \\\"{x:1076,y:389,t:1527628208393};\\\", \\\"{x:1076,y:405,t:1527628208409};\\\", \\\"{x:1075,y:415,t:1527628208425};\\\", \\\"{x:1072,y:427,t:1527628208443};\\\", \\\"{x:1069,y:437,t:1527628208459};\\\", \\\"{x:1069,y:441,t:1527628208475};\\\", \\\"{x:1069,y:454,t:1527628208492};\\\", \\\"{x:1071,y:459,t:1527628208509};\\\", \\\"{x:1072,y:461,t:1527628208526};\\\", \\\"{x:1073,y:463,t:1527628208542};\\\", \\\"{x:1074,y:464,t:1527628208559};\\\", \\\"{x:1075,y:466,t:1527628208604};\\\", \\\"{x:1075,y:468,t:1527628208611};\\\", \\\"{x:1075,y:470,t:1527628208626};\\\", \\\"{x:1076,y:477,t:1527628208643};\\\", \\\"{x:1076,y:482,t:1527628208659};\\\", \\\"{x:1076,y:483,t:1527628208676};\\\", \\\"{x:1076,y:484,t:1527628208755};\\\", \\\"{x:1075,y:486,t:1527628208763};\\\", \\\"{x:1075,y:488,t:1527628208788};\\\", \\\"{x:1074,y:489,t:1527628208795};\\\", \\\"{x:1074,y:490,t:1527628209219};\\\", \\\"{x:1072,y:491,t:1527628209227};\\\", \\\"{x:1071,y:491,t:1527628209308};\\\", \\\"{x:1071,y:492,t:1527628209364};\\\", \\\"{x:1070,y:492,t:1527628209377};\\\", \\\"{x:1066,y:493,t:1527628209393};\\\", \\\"{x:1061,y:495,t:1527628209410};\\\", \\\"{x:1057,y:496,t:1527628209426};\\\", \\\"{x:1055,y:497,t:1527628209444};\\\", \\\"{x:1052,y:498,t:1527628209460};\\\", \\\"{x:1063,y:498,t:1527628210516};\\\", \\\"{x:1085,y:498,t:1527628210528};\\\", \\\"{x:1138,y:498,t:1527628210545};\\\", \\\"{x:1212,y:501,t:1527628210560};\\\", \\\"{x:1279,y:501,t:1527628210578};\\\", \\\"{x:1319,y:501,t:1527628210594};\\\", \\\"{x:1338,y:501,t:1527628210611};\\\", \\\"{x:1346,y:501,t:1527628210628};\\\", \\\"{x:1345,y:503,t:1527628210924};\\\", \\\"{x:1341,y:504,t:1527628210931};\\\", \\\"{x:1337,y:504,t:1527628210945};\\\", \\\"{x:1330,y:506,t:1527628210961};\\\", \\\"{x:1329,y:507,t:1527628210977};\\\", \\\"{x:1328,y:506,t:1527628211396};\\\", \\\"{x:1324,y:503,t:1527628211411};\\\", \\\"{x:1322,y:502,t:1527628211427};\\\", \\\"{x:1320,y:501,t:1527628211668};\\\", \\\"{x:1319,y:501,t:1527628211678};\\\", \\\"{x:1319,y:500,t:1527628211694};\\\", \\\"{x:1318,y:500,t:1527628211729};\\\", \\\"{x:1316,y:499,t:1527628211747};\\\", \\\"{x:1314,y:499,t:1527628211956};\\\", \\\"{x:1312,y:499,t:1527628211964};\\\", \\\"{x:1311,y:499,t:1527628211978};\\\", \\\"{x:1309,y:499,t:1527628211995};\\\", \\\"{x:1307,y:499,t:1527628212052};\\\", \\\"{x:1309,y:499,t:1527628212532};\\\", \\\"{x:1310,y:499,t:1527628212562};\\\", \\\"{x:1311,y:499,t:1527628212579};\\\", \\\"{x:1312,y:499,t:1527628212683};\\\", \\\"{x:1313,y:500,t:1527628213212};\\\", \\\"{x:1313,y:503,t:1527628213220};\\\", \\\"{x:1313,y:507,t:1527628213229};\\\", \\\"{x:1313,y:513,t:1527628213246};\\\", \\\"{x:1313,y:516,t:1527628213262};\\\", \\\"{x:1313,y:521,t:1527628213280};\\\", \\\"{x:1314,y:526,t:1527628213296};\\\", \\\"{x:1314,y:528,t:1527628213313};\\\", \\\"{x:1315,y:531,t:1527628213330};\\\", \\\"{x:1315,y:533,t:1527628213347};\\\", \\\"{x:1315,y:534,t:1527628213363};\\\", \\\"{x:1315,y:539,t:1527628213379};\\\", \\\"{x:1314,y:541,t:1527628213396};\\\", \\\"{x:1314,y:543,t:1527628213413};\\\", \\\"{x:1313,y:545,t:1527628213430};\\\", \\\"{x:1313,y:547,t:1527628213447};\\\", \\\"{x:1312,y:549,t:1527628213462};\\\", \\\"{x:1312,y:551,t:1527628213480};\\\", \\\"{x:1311,y:553,t:1527628213507};\\\", \\\"{x:1310,y:554,t:1527628213539};\\\", \\\"{x:1310,y:556,t:1527628213547};\\\", \\\"{x:1310,y:558,t:1527628213563};\\\", \\\"{x:1309,y:564,t:1527628213580};\\\", \\\"{x:1309,y:566,t:1527628213596};\\\", \\\"{x:1308,y:571,t:1527628213613};\\\", \\\"{x:1307,y:576,t:1527628213629};\\\", \\\"{x:1307,y:580,t:1527628213646};\\\", \\\"{x:1306,y:582,t:1527628213663};\\\", \\\"{x:1306,y:583,t:1527628213680};\\\", \\\"{x:1306,y:585,t:1527628213697};\\\", \\\"{x:1306,y:587,t:1527628213712};\\\", \\\"{x:1306,y:589,t:1527628213730};\\\", \\\"{x:1306,y:591,t:1527628213747};\\\", \\\"{x:1307,y:595,t:1527628213763};\\\", \\\"{x:1307,y:599,t:1527628213780};\\\", \\\"{x:1309,y:604,t:1527628213797};\\\", \\\"{x:1310,y:608,t:1527628213813};\\\", \\\"{x:1310,y:611,t:1527628213830};\\\", \\\"{x:1311,y:612,t:1527628213859};\\\", \\\"{x:1311,y:615,t:1527628213867};\\\", \\\"{x:1311,y:618,t:1527628213883};\\\", \\\"{x:1312,y:619,t:1527628213897};\\\", \\\"{x:1313,y:622,t:1527628213913};\\\", \\\"{x:1313,y:625,t:1527628213930};\\\", \\\"{x:1313,y:627,t:1527628213946};\\\", \\\"{x:1313,y:630,t:1527628213963};\\\", \\\"{x:1314,y:632,t:1527628213980};\\\", \\\"{x:1314,y:635,t:1527628213996};\\\", \\\"{x:1314,y:638,t:1527628214014};\\\", \\\"{x:1314,y:641,t:1527628214029};\\\", \\\"{x:1314,y:645,t:1527628214046};\\\", \\\"{x:1314,y:649,t:1527628214064};\\\", \\\"{x:1315,y:652,t:1527628214080};\\\", \\\"{x:1315,y:654,t:1527628214096};\\\", \\\"{x:1316,y:655,t:1527628214114};\\\", \\\"{x:1316,y:657,t:1527628214129};\\\", \\\"{x:1316,y:659,t:1527628214146};\\\", \\\"{x:1316,y:662,t:1527628214163};\\\", \\\"{x:1316,y:664,t:1527628214180};\\\", \\\"{x:1316,y:667,t:1527628214197};\\\", \\\"{x:1316,y:668,t:1527628214214};\\\", \\\"{x:1317,y:670,t:1527628214229};\\\", \\\"{x:1317,y:671,t:1527628214246};\\\", \\\"{x:1317,y:673,t:1527628214263};\\\", \\\"{x:1317,y:675,t:1527628214279};\\\", \\\"{x:1318,y:680,t:1527628214297};\\\", \\\"{x:1318,y:684,t:1527628214314};\\\", \\\"{x:1320,y:690,t:1527628214331};\\\", \\\"{x:1320,y:697,t:1527628214346};\\\", \\\"{x:1321,y:708,t:1527628214364};\\\", \\\"{x:1321,y:714,t:1527628214381};\\\", \\\"{x:1321,y:717,t:1527628214397};\\\", \\\"{x:1322,y:722,t:1527628214413};\\\", \\\"{x:1324,y:725,t:1527628214431};\\\", \\\"{x:1324,y:728,t:1527628214447};\\\", \\\"{x:1324,y:729,t:1527628214463};\\\", \\\"{x:1325,y:735,t:1527628214481};\\\", \\\"{x:1325,y:739,t:1527628214497};\\\", \\\"{x:1325,y:742,t:1527628214514};\\\", \\\"{x:1325,y:743,t:1527628214531};\\\", \\\"{x:1325,y:746,t:1527628214547};\\\", \\\"{x:1325,y:752,t:1527628214564};\\\", \\\"{x:1326,y:757,t:1527628214581};\\\", \\\"{x:1327,y:760,t:1527628214596};\\\", \\\"{x:1327,y:765,t:1527628214614};\\\", \\\"{x:1327,y:767,t:1527628214631};\\\", \\\"{x:1328,y:771,t:1527628214647};\\\", \\\"{x:1328,y:774,t:1527628214664};\\\", \\\"{x:1328,y:779,t:1527628214681};\\\", \\\"{x:1324,y:787,t:1527628214696};\\\", \\\"{x:1322,y:795,t:1527628214714};\\\", \\\"{x:1322,y:802,t:1527628214731};\\\", \\\"{x:1322,y:807,t:1527628214747};\\\", \\\"{x:1320,y:810,t:1527628214763};\\\", \\\"{x:1319,y:818,t:1527628214781};\\\", \\\"{x:1319,y:826,t:1527628214797};\\\", \\\"{x:1319,y:838,t:1527628214814};\\\", \\\"{x:1318,y:847,t:1527628214830};\\\", \\\"{x:1318,y:851,t:1527628214848};\\\", \\\"{x:1318,y:863,t:1527628214864};\\\", \\\"{x:1315,y:866,t:1527628214880};\\\", \\\"{x:1314,y:872,t:1527628214898};\\\", \\\"{x:1313,y:882,t:1527628214914};\\\", \\\"{x:1312,y:887,t:1527628214931};\\\", \\\"{x:1311,y:893,t:1527628214947};\\\", \\\"{x:1311,y:895,t:1527628214971};\\\", \\\"{x:1310,y:899,t:1527628214987};\\\", \\\"{x:1310,y:901,t:1527628215004};\\\", \\\"{x:1310,y:903,t:1527628215014};\\\", \\\"{x:1310,y:907,t:1527628215031};\\\", \\\"{x:1310,y:910,t:1527628215048};\\\", \\\"{x:1310,y:912,t:1527628215064};\\\", \\\"{x:1310,y:914,t:1527628215080};\\\", \\\"{x:1310,y:916,t:1527628215098};\\\", \\\"{x:1310,y:920,t:1527628215114};\\\", \\\"{x:1310,y:924,t:1527628215131};\\\", \\\"{x:1310,y:930,t:1527628215148};\\\", \\\"{x:1310,y:934,t:1527628215164};\\\", \\\"{x:1310,y:935,t:1527628215180};\\\", \\\"{x:1310,y:939,t:1527628215197};\\\", \\\"{x:1310,y:942,t:1527628215214};\\\", \\\"{x:1310,y:945,t:1527628215230};\\\", \\\"{x:1307,y:954,t:1527628215248};\\\", \\\"{x:1306,y:968,t:1527628215265};\\\", \\\"{x:1305,y:969,t:1527628215281};\\\", \\\"{x:1305,y:972,t:1527628215298};\\\", \\\"{x:1305,y:973,t:1527628215315};\\\", \\\"{x:1305,y:974,t:1527628215330};\\\", \\\"{x:1307,y:972,t:1527628215700};\\\", \\\"{x:1308,y:971,t:1527628215715};\\\", \\\"{x:1310,y:969,t:1527628215731};\\\", \\\"{x:1311,y:967,t:1527628215748};\\\", \\\"{x:1312,y:967,t:1527628215835};\\\", \\\"{x:1314,y:966,t:1527628215848};\\\", \\\"{x:1314,y:965,t:1527628215987};\\\", \\\"{x:1317,y:965,t:1527628216204};\\\", \\\"{x:1319,y:965,t:1527628216219};\\\", \\\"{x:1320,y:965,t:1527628216232};\\\", \\\"{x:1330,y:965,t:1527628216249};\\\", \\\"{x:1341,y:964,t:1527628216265};\\\", \\\"{x:1345,y:964,t:1527628216282};\\\", \\\"{x:1346,y:964,t:1527628216299};\\\", \\\"{x:1346,y:963,t:1527628216315};\\\", \\\"{x:1348,y:963,t:1527628216332};\\\", \\\"{x:1349,y:963,t:1527628216348};\\\", \\\"{x:1351,y:963,t:1527628216379};\\\", \\\"{x:1353,y:964,t:1527628216387};\\\", \\\"{x:1354,y:964,t:1527628216399};\\\", \\\"{x:1357,y:964,t:1527628216415};\\\", \\\"{x:1358,y:964,t:1527628216432};\\\", \\\"{x:1359,y:964,t:1527628216448};\\\", \\\"{x:1360,y:964,t:1527628216475};\\\", \\\"{x:1363,y:964,t:1527628216483};\\\", \\\"{x:1364,y:964,t:1527628216499};\\\", \\\"{x:1365,y:964,t:1527628216531};\\\", \\\"{x:1366,y:964,t:1527628216539};\\\", \\\"{x:1369,y:963,t:1527628216548};\\\", \\\"{x:1372,y:962,t:1527628216565};\\\", \\\"{x:1375,y:961,t:1527628216582};\\\", \\\"{x:1381,y:961,t:1527628216599};\\\", \\\"{x:1388,y:961,t:1527628216615};\\\", \\\"{x:1398,y:960,t:1527628216631};\\\", \\\"{x:1400,y:960,t:1527628216649};\\\", \\\"{x:1401,y:960,t:1527628216667};\\\", \\\"{x:1404,y:960,t:1527628216683};\\\", \\\"{x:1405,y:960,t:1527628216699};\\\", \\\"{x:1409,y:960,t:1527628216715};\\\", \\\"{x:1412,y:960,t:1527628216731};\\\", \\\"{x:1422,y:956,t:1527628216749};\\\", \\\"{x:1426,y:956,t:1527628216766};\\\", \\\"{x:1432,y:956,t:1527628216781};\\\", \\\"{x:1436,y:955,t:1527628216803};\\\", \\\"{x:1444,y:956,t:1527628216816};\\\", \\\"{x:1456,y:958,t:1527628216832};\\\", \\\"{x:1465,y:960,t:1527628216849};\\\", \\\"{x:1474,y:961,t:1527628216866};\\\", \\\"{x:1481,y:962,t:1527628216882};\\\", \\\"{x:1489,y:964,t:1527628216899};\\\", \\\"{x:1496,y:965,t:1527628216915};\\\", \\\"{x:1500,y:966,t:1527628216932};\\\", \\\"{x:1502,y:967,t:1527628217028};\\\", \\\"{x:1503,y:967,t:1527628217115};\\\", \\\"{x:1507,y:968,t:1527628217132};\\\", \\\"{x:1511,y:970,t:1527628217149};\\\", \\\"{x:1515,y:970,t:1527628217166};\\\", \\\"{x:1516,y:970,t:1527628217595};\\\", \\\"{x:1517,y:969,t:1527628217803};\\\", \\\"{x:1519,y:969,t:1527628217815};\\\", \\\"{x:1522,y:967,t:1527628217833};\\\", \\\"{x:1525,y:966,t:1527628217850};\\\", \\\"{x:1530,y:964,t:1527628217866};\\\", \\\"{x:1532,y:962,t:1527628217883};\\\", \\\"{x:1537,y:958,t:1527628217900};\\\", \\\"{x:1540,y:955,t:1527628217916};\\\", \\\"{x:1542,y:955,t:1527628217933};\\\", \\\"{x:1545,y:952,t:1527628217955};\\\", \\\"{x:1546,y:952,t:1527628217966};\\\", \\\"{x:1546,y:951,t:1527628217983};\\\", \\\"{x:1547,y:951,t:1527628218155};\\\", \\\"{x:1548,y:951,t:1527628218167};\\\", \\\"{x:1550,y:953,t:1527628218183};\\\", \\\"{x:1551,y:956,t:1527628218200};\\\", \\\"{x:1552,y:957,t:1527628218217};\\\", \\\"{x:1552,y:958,t:1527628218233};\\\", \\\"{x:1552,y:960,t:1527628218484};\\\", \\\"{x:1552,y:961,t:1527628218587};\\\", \\\"{x:1552,y:962,t:1527628218600};\\\", \\\"{x:1552,y:964,t:1527628221564};\\\", \\\"{x:1551,y:965,t:1527628221571};\\\", \\\"{x:1550,y:966,t:1527628221586};\\\", \\\"{x:1549,y:968,t:1527628221602};\\\", \\\"{x:1548,y:968,t:1527628221619};\\\", \\\"{x:1547,y:969,t:1527628221636};\\\", \\\"{x:1545,y:969,t:1527628222531};\\\", \\\"{x:1545,y:968,t:1527628222539};\\\", \\\"{x:1545,y:967,t:1527628222553};\\\", \\\"{x:1543,y:964,t:1527628222570};\\\", \\\"{x:1543,y:963,t:1527628222586};\\\", \\\"{x:1543,y:961,t:1527628222603};\\\", \\\"{x:1543,y:959,t:1527628222620};\\\", \\\"{x:1542,y:958,t:1527628222636};\\\", \\\"{x:1541,y:956,t:1527628222653};\\\", \\\"{x:1541,y:955,t:1527628222691};\\\", \\\"{x:1541,y:953,t:1527628222787};\\\", \\\"{x:1540,y:951,t:1527628223003};\\\", \\\"{x:1540,y:948,t:1527628223020};\\\", \\\"{x:1539,y:945,t:1527628223037};\\\", \\\"{x:1536,y:939,t:1527628223053};\\\", \\\"{x:1535,y:937,t:1527628223070};\\\", \\\"{x:1533,y:933,t:1527628223087};\\\", \\\"{x:1532,y:929,t:1527628223103};\\\", \\\"{x:1527,y:925,t:1527628223120};\\\", \\\"{x:1522,y:919,t:1527628223137};\\\", \\\"{x:1514,y:914,t:1527628223153};\\\", \\\"{x:1500,y:903,t:1527628223170};\\\", \\\"{x:1467,y:885,t:1527628223187};\\\", \\\"{x:1426,y:870,t:1527628223203};\\\", \\\"{x:1371,y:851,t:1527628223220};\\\", \\\"{x:1302,y:831,t:1527628223237};\\\", \\\"{x:1235,y:814,t:1527628223253};\\\", \\\"{x:1177,y:797,t:1527628223270};\\\", \\\"{x:1132,y:784,t:1527628223287};\\\", \\\"{x:1073,y:767,t:1527628223304};\\\", \\\"{x:1019,y:757,t:1527628223320};\\\", \\\"{x:951,y:746,t:1527628223337};\\\", \\\"{x:861,y:727,t:1527628223354};\\\", \\\"{x:824,y:717,t:1527628223370};\\\", \\\"{x:772,y:701,t:1527628223387};\\\", \\\"{x:755,y:696,t:1527628223404};\\\", \\\"{x:731,y:690,t:1527628223420};\\\", \\\"{x:714,y:681,t:1527628223437};\\\", \\\"{x:706,y:679,t:1527628223454};\\\", \\\"{x:703,y:676,t:1527628223470};\\\", \\\"{x:702,y:674,t:1527628223491};\\\", \\\"{x:702,y:671,t:1527628223504};\\\", \\\"{x:696,y:664,t:1527628223520};\\\", \\\"{x:687,y:652,t:1527628223537};\\\", \\\"{x:677,y:644,t:1527628223556};\\\", \\\"{x:675,y:641,t:1527628223573};\\\", \\\"{x:672,y:638,t:1527628223589};\\\", \\\"{x:670,y:636,t:1527628223606};\\\", \\\"{x:669,y:631,t:1527628223623};\\\", \\\"{x:666,y:625,t:1527628223639};\\\", \\\"{x:661,y:620,t:1527628223656};\\\", \\\"{x:657,y:616,t:1527628223673};\\\", \\\"{x:651,y:613,t:1527628223690};\\\", \\\"{x:647,y:611,t:1527628223706};\\\", \\\"{x:643,y:610,t:1527628223723};\\\", \\\"{x:639,y:610,t:1527628223740};\\\", \\\"{x:638,y:609,t:1527628223756};\\\", \\\"{x:636,y:609,t:1527628223773};\\\", \\\"{x:634,y:609,t:1527628223790};\\\", \\\"{x:633,y:609,t:1527628223806};\\\", \\\"{x:633,y:609,t:1527628223892};\\\", \\\"{x:634,y:609,t:1527628224067};\\\", \\\"{x:642,y:620,t:1527628224075};\\\", \\\"{x:651,y:627,t:1527628224090};\\\", \\\"{x:691,y:650,t:1527628224107};\\\", \\\"{x:722,y:667,t:1527628224123};\\\", \\\"{x:756,y:676,t:1527628224140};\\\", \\\"{x:788,y:687,t:1527628224157};\\\", \\\"{x:820,y:699,t:1527628224173};\\\", \\\"{x:871,y:714,t:1527628224190};\\\", \\\"{x:914,y:729,t:1527628224207};\\\", \\\"{x:970,y:746,t:1527628224223};\\\", \\\"{x:1005,y:760,t:1527628224240};\\\", \\\"{x:1038,y:772,t:1527628224257};\\\", \\\"{x:1065,y:784,t:1527628224273};\\\", \\\"{x:1100,y:794,t:1527628224290};\\\", \\\"{x:1138,y:806,t:1527628224307};\\\", \\\"{x:1174,y:816,t:1527628224323};\\\", \\\"{x:1205,y:828,t:1527628224340};\\\", \\\"{x:1237,y:838,t:1527628224357};\\\", \\\"{x:1274,y:852,t:1527628224373};\\\", \\\"{x:1316,y:872,t:1527628224390};\\\", \\\"{x:1344,y:882,t:1527628224407};\\\", \\\"{x:1364,y:889,t:1527628224423};\\\", \\\"{x:1377,y:893,t:1527628224440};\\\", \\\"{x:1385,y:896,t:1527628224457};\\\", \\\"{x:1395,y:899,t:1527628224473};\\\", \\\"{x:1400,y:899,t:1527628224490};\\\", \\\"{x:1408,y:899,t:1527628224507};\\\", \\\"{x:1420,y:899,t:1527628224524};\\\", \\\"{x:1426,y:899,t:1527628224540};\\\", \\\"{x:1439,y:898,t:1527628224557};\\\", \\\"{x:1447,y:898,t:1527628224574};\\\", \\\"{x:1457,y:897,t:1527628224590};\\\", \\\"{x:1467,y:897,t:1527628224607};\\\", \\\"{x:1472,y:896,t:1527628224624};\\\", \\\"{x:1475,y:895,t:1527628224640};\\\", \\\"{x:1476,y:895,t:1527628224657};\\\", \\\"{x:1477,y:894,t:1527628224675};\\\", \\\"{x:1479,y:893,t:1527628224690};\\\", \\\"{x:1483,y:890,t:1527628224707};\\\", \\\"{x:1485,y:888,t:1527628224724};\\\", \\\"{x:1486,y:887,t:1527628224740};\\\", \\\"{x:1487,y:886,t:1527628224757};\\\", \\\"{x:1489,y:886,t:1527628224803};\\\", \\\"{x:1489,y:885,t:1527628224819};\\\", \\\"{x:1490,y:885,t:1527628224827};\\\", \\\"{x:1492,y:885,t:1527628224843};\\\", \\\"{x:1493,y:885,t:1527628224857};\\\", \\\"{x:1498,y:887,t:1527628224874};\\\", \\\"{x:1504,y:889,t:1527628224890};\\\", \\\"{x:1512,y:893,t:1527628224906};\\\", \\\"{x:1516,y:895,t:1527628224924};\\\", \\\"{x:1518,y:897,t:1527628224941};\\\", \\\"{x:1520,y:898,t:1527628224957};\\\", \\\"{x:1523,y:899,t:1527628224974};\\\", \\\"{x:1523,y:900,t:1527628224991};\\\", \\\"{x:1524,y:900,t:1527628225007};\\\", \\\"{x:1526,y:900,t:1527628225024};\\\", \\\"{x:1526,y:899,t:1527628226131};\\\", \\\"{x:1526,y:889,t:1527628226142};\\\", \\\"{x:1525,y:881,t:1527628226158};\\\", \\\"{x:1524,y:865,t:1527628226175};\\\", \\\"{x:1524,y:848,t:1527628226191};\\\", \\\"{x:1523,y:834,t:1527628226208};\\\", \\\"{x:1521,y:827,t:1527628226225};\\\", \\\"{x:1520,y:822,t:1527628226242};\\\", \\\"{x:1516,y:803,t:1527628226258};\\\", \\\"{x:1513,y:782,t:1527628226275};\\\", \\\"{x:1511,y:778,t:1527628226292};\\\", \\\"{x:1511,y:775,t:1527628226308};\\\", \\\"{x:1510,y:774,t:1527628226331};\\\", \\\"{x:1510,y:771,t:1527628226342};\\\", \\\"{x:1509,y:767,t:1527628226358};\\\", \\\"{x:1509,y:763,t:1527628226375};\\\", \\\"{x:1505,y:756,t:1527628226392};\\\", \\\"{x:1503,y:749,t:1527628226408};\\\", \\\"{x:1502,y:739,t:1527628226425};\\\", \\\"{x:1502,y:727,t:1527628226442};\\\", \\\"{x:1502,y:712,t:1527628226458};\\\", \\\"{x:1501,y:679,t:1527628226475};\\\", \\\"{x:1501,y:657,t:1527628226493};\\\", \\\"{x:1503,y:654,t:1527628226509};\\\", \\\"{x:1503,y:652,t:1527628226525};\\\", \\\"{x:1504,y:650,t:1527628226542};\\\", \\\"{x:1504,y:649,t:1527628226579};\\\", \\\"{x:1504,y:648,t:1527628226592};\\\", \\\"{x:1504,y:646,t:1527628226608};\\\", \\\"{x:1507,y:642,t:1527628226625};\\\", \\\"{x:1507,y:641,t:1527628226642};\\\", \\\"{x:1507,y:639,t:1527628226658};\\\", \\\"{x:1510,y:633,t:1527628226675};\\\", \\\"{x:1511,y:631,t:1527628226692};\\\", \\\"{x:1513,y:623,t:1527628226710};\\\", \\\"{x:1515,y:618,t:1527628226725};\\\", \\\"{x:1518,y:609,t:1527628226742};\\\", \\\"{x:1519,y:604,t:1527628226759};\\\", \\\"{x:1519,y:603,t:1527628226775};\\\", \\\"{x:1520,y:602,t:1527628226803};\\\", \\\"{x:1520,y:603,t:1527628227099};\\\", \\\"{x:1520,y:604,t:1527628227110};\\\", \\\"{x:1520,y:605,t:1527628227126};\\\", \\\"{x:1520,y:607,t:1527628227142};\\\", \\\"{x:1520,y:608,t:1527628227159};\\\", \\\"{x:1520,y:612,t:1527628227177};\\\", \\\"{x:1520,y:616,t:1527628227192};\\\", \\\"{x:1520,y:622,t:1527628227209};\\\", \\\"{x:1520,y:631,t:1527628227226};\\\", \\\"{x:1520,y:636,t:1527628227242};\\\", \\\"{x:1520,y:642,t:1527628227259};\\\", \\\"{x:1520,y:647,t:1527628227276};\\\", \\\"{x:1520,y:652,t:1527628227292};\\\", \\\"{x:1520,y:658,t:1527628227309};\\\", \\\"{x:1520,y:664,t:1527628227326};\\\", \\\"{x:1520,y:674,t:1527628227342};\\\", \\\"{x:1517,y:684,t:1527628227359};\\\", \\\"{x:1513,y:691,t:1527628227376};\\\", \\\"{x:1512,y:695,t:1527628227392};\\\", \\\"{x:1512,y:696,t:1527628227410};\\\", \\\"{x:1511,y:698,t:1527628227427};\\\", \\\"{x:1510,y:699,t:1527628227450};\\\", \\\"{x:1510,y:700,t:1527628227459};\\\", \\\"{x:1508,y:704,t:1527628227476};\\\", \\\"{x:1504,y:711,t:1527628227492};\\\", \\\"{x:1500,y:717,t:1527628227509};\\\", \\\"{x:1495,y:722,t:1527628227526};\\\", \\\"{x:1492,y:727,t:1527628227543};\\\", \\\"{x:1492,y:729,t:1527628227559};\\\", \\\"{x:1490,y:731,t:1527628227577};\\\", \\\"{x:1488,y:734,t:1527628227593};\\\", \\\"{x:1487,y:737,t:1527628227610};\\\", \\\"{x:1485,y:739,t:1527628227626};\\\", \\\"{x:1484,y:740,t:1527628227643};\\\", \\\"{x:1482,y:743,t:1527628227659};\\\", \\\"{x:1481,y:746,t:1527628227676};\\\", \\\"{x:1479,y:748,t:1527628227694};\\\", \\\"{x:1477,y:750,t:1527628227723};\\\", \\\"{x:1476,y:751,t:1527628227731};\\\", \\\"{x:1474,y:753,t:1527628227743};\\\", \\\"{x:1471,y:756,t:1527628227760};\\\", \\\"{x:1467,y:759,t:1527628227776};\\\", \\\"{x:1463,y:762,t:1527628227793};\\\", \\\"{x:1458,y:763,t:1527628227810};\\\", \\\"{x:1458,y:764,t:1527628227826};\\\", \\\"{x:1456,y:765,t:1527628227843};\\\", \\\"{x:1454,y:767,t:1527628227860};\\\", \\\"{x:1450,y:768,t:1527628227877};\\\", \\\"{x:1447,y:769,t:1527628227893};\\\", \\\"{x:1443,y:770,t:1527628227909};\\\", \\\"{x:1439,y:771,t:1527628227926};\\\", \\\"{x:1433,y:773,t:1527628227943};\\\", \\\"{x:1431,y:773,t:1527628227959};\\\", \\\"{x:1429,y:773,t:1527628227987};\\\", \\\"{x:1427,y:773,t:1527628227995};\\\", \\\"{x:1424,y:773,t:1527628228010};\\\", \\\"{x:1410,y:771,t:1527628228027};\\\", \\\"{x:1375,y:759,t:1527628228043};\\\", \\\"{x:1349,y:756,t:1527628228060};\\\", \\\"{x:1331,y:753,t:1527628228076};\\\", \\\"{x:1318,y:750,t:1527628228093};\\\", \\\"{x:1317,y:750,t:1527628228110};\\\", \\\"{x:1316,y:750,t:1527628228331};\\\", \\\"{x:1316,y:751,t:1527628228344};\\\", \\\"{x:1318,y:754,t:1527628228360};\\\", \\\"{x:1324,y:759,t:1527628228376};\\\", \\\"{x:1326,y:760,t:1527628228394};\\\", \\\"{x:1328,y:760,t:1527628228563};\\\", \\\"{x:1334,y:760,t:1527628228577};\\\", \\\"{x:1351,y:757,t:1527628228593};\\\", \\\"{x:1363,y:756,t:1527628228610};\\\", \\\"{x:1377,y:752,t:1527628228626};\\\", \\\"{x:1379,y:752,t:1527628228875};\\\", \\\"{x:1380,y:752,t:1527628228883};\\\", \\\"{x:1380,y:753,t:1527628228894};\\\", \\\"{x:1380,y:754,t:1527628228910};\\\", \\\"{x:1381,y:755,t:1527628228927};\\\", \\\"{x:1382,y:756,t:1527628228945};\\\", \\\"{x:1384,y:758,t:1527628229171};\\\", \\\"{x:1386,y:762,t:1527628229194};\\\", \\\"{x:1387,y:765,t:1527628229211};\\\", \\\"{x:1389,y:767,t:1527628229227};\\\", \\\"{x:1390,y:767,t:1527628229957};\\\", \\\"{x:1392,y:767,t:1527628230276};\\\", \\\"{x:1393,y:767,t:1527628230341};\\\", \\\"{x:1394,y:767,t:1527628230405};\\\", \\\"{x:1396,y:767,t:1527628230436};\\\", \\\"{x:1397,y:767,t:1527628230461};\\\", \\\"{x:1399,y:767,t:1527628230485};\\\", \\\"{x:1400,y:767,t:1527628230493};\\\", \\\"{x:1402,y:767,t:1527628230505};\\\", \\\"{x:1406,y:767,t:1527628230521};\\\", \\\"{x:1409,y:767,t:1527628230538};\\\", \\\"{x:1411,y:767,t:1527628230555};\\\", \\\"{x:1413,y:767,t:1527628230571};\\\", \\\"{x:1416,y:767,t:1527628230588};\\\", \\\"{x:1417,y:767,t:1527628230605};\\\", \\\"{x:1418,y:767,t:1527628230653};\\\", \\\"{x:1419,y:767,t:1527628230661};\\\", \\\"{x:1420,y:767,t:1527628230672};\\\", \\\"{x:1423,y:767,t:1527628230688};\\\", \\\"{x:1430,y:767,t:1527628230705};\\\", \\\"{x:1434,y:767,t:1527628230722};\\\", \\\"{x:1441,y:767,t:1527628230738};\\\", \\\"{x:1447,y:770,t:1527628230755};\\\", \\\"{x:1450,y:772,t:1527628230772};\\\", \\\"{x:1458,y:777,t:1527628230788};\\\", \\\"{x:1472,y:783,t:1527628230805};\\\", \\\"{x:1479,y:785,t:1527628230822};\\\", \\\"{x:1482,y:787,t:1527628230838};\\\", \\\"{x:1483,y:787,t:1527628230855};\\\", \\\"{x:1484,y:789,t:1527628230924};\\\", \\\"{x:1486,y:790,t:1527628230938};\\\", \\\"{x:1490,y:792,t:1527628230955};\\\", \\\"{x:1493,y:795,t:1527628230972};\\\", \\\"{x:1498,y:798,t:1527628230988};\\\", \\\"{x:1501,y:801,t:1527628231005};\\\", \\\"{x:1502,y:801,t:1527628231061};\\\", \\\"{x:1503,y:801,t:1527628231100};\\\", \\\"{x:1503,y:802,t:1527628234989};\\\", \\\"{x:1503,y:803,t:1527628234997};\\\", \\\"{x:1504,y:804,t:1527628235008};\\\", \\\"{x:1508,y:804,t:1527628235025};\\\", \\\"{x:1511,y:804,t:1527628235042};\\\", \\\"{x:1516,y:800,t:1527628235058};\\\", \\\"{x:1522,y:797,t:1527628235075};\\\", \\\"{x:1526,y:795,t:1527628235092};\\\", \\\"{x:1529,y:794,t:1527628235108};\\\", \\\"{x:1532,y:792,t:1527628235125};\\\", \\\"{x:1534,y:791,t:1527628235142};\\\", \\\"{x:1535,y:790,t:1527628235159};\\\", \\\"{x:1536,y:789,t:1527628235180};\\\", \\\"{x:1538,y:788,t:1527628235193};\\\", \\\"{x:1541,y:788,t:1527628235209};\\\", \\\"{x:1542,y:787,t:1527628235225};\\\", \\\"{x:1544,y:786,t:1527628235242};\\\", \\\"{x:1547,y:786,t:1527628235260};\\\", \\\"{x:1547,y:785,t:1527628235309};\\\", \\\"{x:1550,y:784,t:1527628235325};\\\", \\\"{x:1553,y:783,t:1527628235342};\\\", \\\"{x:1555,y:781,t:1527628235358};\\\", \\\"{x:1557,y:780,t:1527628235376};\\\", \\\"{x:1558,y:779,t:1527628235392};\\\", \\\"{x:1559,y:778,t:1527628235408};\\\", \\\"{x:1560,y:778,t:1527628235437};\\\", \\\"{x:1561,y:778,t:1527628235444};\\\", \\\"{x:1562,y:778,t:1527628235460};\\\", \\\"{x:1565,y:776,t:1527628235477};\\\", \\\"{x:1568,y:775,t:1527628235492};\\\", \\\"{x:1571,y:774,t:1527628235508};\\\", \\\"{x:1573,y:772,t:1527628235526};\\\", \\\"{x:1575,y:771,t:1527628235542};\\\", \\\"{x:1576,y:771,t:1527628235581};\\\", \\\"{x:1577,y:770,t:1527628235596};\\\", \\\"{x:1578,y:770,t:1527628235613};\\\", \\\"{x:1579,y:770,t:1527628235629};\\\", \\\"{x:1580,y:769,t:1527628235948};\\\", \\\"{x:1586,y:773,t:1527628235960};\\\", \\\"{x:1592,y:776,t:1527628235977};\\\", \\\"{x:1593,y:777,t:1527628235992};\\\", \\\"{x:1595,y:778,t:1527628236009};\\\", \\\"{x:1599,y:780,t:1527628236027};\\\", \\\"{x:1602,y:781,t:1527628236042};\\\", \\\"{x:1604,y:781,t:1527628236060};\\\", \\\"{x:1605,y:781,t:1527628236076};\\\", \\\"{x:1606,y:781,t:1527628236093};\\\", \\\"{x:1609,y:781,t:1527628236109};\\\", \\\"{x:1614,y:781,t:1527628236126};\\\", \\\"{x:1616,y:781,t:1527628236142};\\\", \\\"{x:1618,y:781,t:1527628236172};\\\", \\\"{x:1619,y:781,t:1527628236189};\\\", \\\"{x:1621,y:781,t:1527628236277};\\\", \\\"{x:1622,y:781,t:1527628236292};\\\", \\\"{x:1623,y:781,t:1527628236316};\\\", \\\"{x:1624,y:781,t:1527628236340};\\\", \\\"{x:1625,y:780,t:1527628236348};\\\", \\\"{x:1626,y:778,t:1527628236373};\\\", \\\"{x:1627,y:777,t:1527628236381};\\\", \\\"{x:1628,y:776,t:1527628236393};\\\", \\\"{x:1629,y:775,t:1527628236409};\\\", \\\"{x:1632,y:770,t:1527628236426};\\\", \\\"{x:1635,y:769,t:1527628236443};\\\", \\\"{x:1638,y:767,t:1527628236459};\\\", \\\"{x:1639,y:767,t:1527628236509};\\\", \\\"{x:1642,y:766,t:1527628236557};\\\", \\\"{x:1643,y:765,t:1527628236565};\\\", \\\"{x:1644,y:763,t:1527628236612};\\\", \\\"{x:1645,y:763,t:1527628236917};\\\", \\\"{x:1646,y:763,t:1527628237045};\\\", \\\"{x:1646,y:764,t:1527628238388};\\\", \\\"{x:1646,y:766,t:1527628238404};\\\", \\\"{x:1646,y:767,t:1527628238453};\\\", \\\"{x:1647,y:767,t:1527628238461};\\\", \\\"{x:1647,y:769,t:1527628238478};\\\", \\\"{x:1648,y:771,t:1527628238501};\\\", \\\"{x:1649,y:771,t:1527628238512};\\\", \\\"{x:1650,y:774,t:1527628238528};\\\", \\\"{x:1652,y:778,t:1527628238545};\\\", \\\"{x:1654,y:781,t:1527628238562};\\\", \\\"{x:1655,y:783,t:1527628238578};\\\", \\\"{x:1656,y:786,t:1527628238594};\\\", \\\"{x:1658,y:788,t:1527628238612};\\\", \\\"{x:1658,y:789,t:1527628238627};\\\", \\\"{x:1659,y:790,t:1527628238644};\\\", \\\"{x:1662,y:793,t:1527628238661};\\\", \\\"{x:1662,y:794,t:1527628238678};\\\", \\\"{x:1663,y:797,t:1527628238694};\\\", \\\"{x:1664,y:797,t:1527628238711};\\\", \\\"{x:1665,y:799,t:1527628238728};\\\", \\\"{x:1666,y:800,t:1527628238744};\\\", \\\"{x:1668,y:803,t:1527628238780};\\\", \\\"{x:1669,y:804,t:1527628238795};\\\", \\\"{x:1669,y:805,t:1527628238812};\\\", \\\"{x:1671,y:806,t:1527628238829};\\\", \\\"{x:1672,y:810,t:1527628238845};\\\", \\\"{x:1673,y:812,t:1527628238861};\\\", \\\"{x:1674,y:814,t:1527628238879};\\\", \\\"{x:1675,y:815,t:1527628238909};\\\", \\\"{x:1675,y:816,t:1527628238916};\\\", \\\"{x:1676,y:817,t:1527628238929};\\\", \\\"{x:1677,y:817,t:1527628238945};\\\", \\\"{x:1677,y:818,t:1527628238965};\\\", \\\"{x:1677,y:819,t:1527628238979};\\\", \\\"{x:1677,y:820,t:1527628238995};\\\", \\\"{x:1678,y:820,t:1527628239011};\\\", \\\"{x:1679,y:822,t:1527628239028};\\\", \\\"{x:1679,y:823,t:1527628239045};\\\", \\\"{x:1680,y:824,t:1527628239062};\\\", \\\"{x:1681,y:824,t:1527628239164};\\\", \\\"{x:1682,y:824,t:1527628239179};\\\", \\\"{x:1682,y:826,t:1527628239195};\\\", \\\"{x:1682,y:827,t:1527628239252};\\\", \\\"{x:1682,y:828,t:1527628239261};\\\", \\\"{x:1681,y:828,t:1527628240637};\\\", \\\"{x:1679,y:826,t:1527628240647};\\\", \\\"{x:1677,y:824,t:1527628240663};\\\", \\\"{x:1672,y:820,t:1527628240680};\\\", \\\"{x:1669,y:817,t:1527628240697};\\\", \\\"{x:1668,y:815,t:1527628240712};\\\", \\\"{x:1666,y:810,t:1527628240730};\\\", \\\"{x:1663,y:806,t:1527628240746};\\\", \\\"{x:1657,y:797,t:1527628240763};\\\", \\\"{x:1650,y:785,t:1527628240780};\\\", \\\"{x:1640,y:768,t:1527628240797};\\\", \\\"{x:1633,y:761,t:1527628240814};\\\", \\\"{x:1628,y:755,t:1527628240829};\\\", \\\"{x:1625,y:744,t:1527628240846};\\\", \\\"{x:1623,y:739,t:1527628240864};\\\", \\\"{x:1620,y:730,t:1527628240880};\\\", \\\"{x:1617,y:721,t:1527628240897};\\\", \\\"{x:1614,y:706,t:1527628240914};\\\", \\\"{x:1614,y:697,t:1527628240929};\\\", \\\"{x:1613,y:693,t:1527628240946};\\\", \\\"{x:1613,y:689,t:1527628240963};\\\", \\\"{x:1613,y:683,t:1527628240980};\\\", \\\"{x:1614,y:668,t:1527628240997};\\\", \\\"{x:1615,y:650,t:1527628241014};\\\", \\\"{x:1616,y:644,t:1527628241029};\\\", \\\"{x:1617,y:640,t:1527628241047};\\\", \\\"{x:1619,y:631,t:1527628241063};\\\", \\\"{x:1620,y:623,t:1527628241079};\\\", \\\"{x:1620,y:621,t:1527628241097};\\\", \\\"{x:1623,y:613,t:1527628241114};\\\", \\\"{x:1625,y:603,t:1527628241130};\\\", \\\"{x:1626,y:594,t:1527628241147};\\\", \\\"{x:1627,y:590,t:1527628241164};\\\", \\\"{x:1627,y:581,t:1527628241181};\\\", \\\"{x:1627,y:572,t:1527628241197};\\\", \\\"{x:1627,y:566,t:1527628241214};\\\", \\\"{x:1627,y:562,t:1527628241231};\\\", \\\"{x:1626,y:559,t:1527628241247};\\\", \\\"{x:1624,y:558,t:1527628241605};\\\", \\\"{x:1623,y:558,t:1527628241614};\\\", \\\"{x:1622,y:558,t:1527628241631};\\\", \\\"{x:1621,y:558,t:1527628241648};\\\", \\\"{x:1620,y:558,t:1527628241821};\\\", \\\"{x:1620,y:559,t:1527628241836};\\\", \\\"{x:1619,y:559,t:1527628241933};\\\", \\\"{x:1618,y:559,t:1527628241981};\\\", \\\"{x:1618,y:561,t:1527628242565};\\\", \\\"{x:1618,y:562,t:1527628242582};\\\", \\\"{x:1618,y:564,t:1527628242604};\\\", \\\"{x:1618,y:566,t:1527628242668};\\\", \\\"{x:1618,y:568,t:1527628242682};\\\", \\\"{x:1618,y:571,t:1527628242698};\\\", \\\"{x:1618,y:574,t:1527628242715};\\\", \\\"{x:1618,y:577,t:1527628242732};\\\", \\\"{x:1618,y:580,t:1527628242747};\\\", \\\"{x:1619,y:584,t:1527628242765};\\\", \\\"{x:1620,y:588,t:1527628242782};\\\", \\\"{x:1623,y:593,t:1527628242798};\\\", \\\"{x:1623,y:600,t:1527628242815};\\\", \\\"{x:1626,y:606,t:1527628242832};\\\", \\\"{x:1627,y:611,t:1527628242849};\\\", \\\"{x:1630,y:616,t:1527628242864};\\\", \\\"{x:1632,y:622,t:1527628242881};\\\", \\\"{x:1633,y:624,t:1527628242898};\\\", \\\"{x:1633,y:628,t:1527628242915};\\\", \\\"{x:1633,y:631,t:1527628242932};\\\", \\\"{x:1634,y:636,t:1527628242948};\\\", \\\"{x:1634,y:637,t:1527628242965};\\\", \\\"{x:1635,y:639,t:1527628242989};\\\", \\\"{x:1635,y:640,t:1527628242998};\\\", \\\"{x:1635,y:643,t:1527628243015};\\\", \\\"{x:1635,y:645,t:1527628243036};\\\", \\\"{x:1635,y:646,t:1527628243048};\\\", \\\"{x:1635,y:648,t:1527628243065};\\\", \\\"{x:1635,y:649,t:1527628243082};\\\", \\\"{x:1635,y:650,t:1527628243099};\\\", \\\"{x:1636,y:651,t:1527628243115};\\\", \\\"{x:1637,y:651,t:1527628243132};\\\", \\\"{x:1637,y:652,t:1527628243149};\\\", \\\"{x:1637,y:653,t:1527628243197};\\\", \\\"{x:1637,y:655,t:1527628243205};\\\", \\\"{x:1637,y:657,t:1527628243215};\\\", \\\"{x:1637,y:661,t:1527628243231};\\\", \\\"{x:1637,y:662,t:1527628243249};\\\", \\\"{x:1637,y:665,t:1527628243265};\\\", \\\"{x:1636,y:669,t:1527628243282};\\\", \\\"{x:1635,y:671,t:1527628243299};\\\", \\\"{x:1635,y:676,t:1527628243314};\\\", \\\"{x:1633,y:680,t:1527628243332};\\\", \\\"{x:1629,y:691,t:1527628243349};\\\", \\\"{x:1629,y:696,t:1527628243365};\\\", \\\"{x:1627,y:702,t:1527628243382};\\\", \\\"{x:1626,y:708,t:1527628243399};\\\", \\\"{x:1623,y:717,t:1527628243416};\\\", \\\"{x:1622,y:722,t:1527628243432};\\\", \\\"{x:1620,y:729,t:1527628243449};\\\", \\\"{x:1619,y:735,t:1527628243465};\\\", \\\"{x:1618,y:738,t:1527628243481};\\\", \\\"{x:1616,y:744,t:1527628243499};\\\", \\\"{x:1615,y:750,t:1527628243515};\\\", \\\"{x:1615,y:755,t:1527628243532};\\\", \\\"{x:1614,y:760,t:1527628243549};\\\", \\\"{x:1614,y:764,t:1527628243566};\\\", \\\"{x:1612,y:768,t:1527628243581};\\\", \\\"{x:1612,y:774,t:1527628243599};\\\", \\\"{x:1611,y:786,t:1527628243615};\\\", \\\"{x:1609,y:796,t:1527628243632};\\\", \\\"{x:1607,y:801,t:1527628243649};\\\", \\\"{x:1606,y:807,t:1527628243666};\\\", \\\"{x:1606,y:813,t:1527628243682};\\\", \\\"{x:1606,y:817,t:1527628243699};\\\", \\\"{x:1606,y:822,t:1527628243715};\\\", \\\"{x:1606,y:830,t:1527628243732};\\\", \\\"{x:1605,y:837,t:1527628243748};\\\", \\\"{x:1605,y:840,t:1527628243765};\\\", \\\"{x:1605,y:844,t:1527628243782};\\\", \\\"{x:1605,y:847,t:1527628243799};\\\", \\\"{x:1605,y:850,t:1527628243816};\\\", \\\"{x:1605,y:854,t:1527628243833};\\\", \\\"{x:1605,y:860,t:1527628243849};\\\", \\\"{x:1605,y:866,t:1527628243866};\\\", \\\"{x:1605,y:870,t:1527628243883};\\\", \\\"{x:1605,y:873,t:1527628243898};\\\", \\\"{x:1605,y:876,t:1527628243916};\\\", \\\"{x:1605,y:879,t:1527628243932};\\\", \\\"{x:1605,y:880,t:1527628243949};\\\", \\\"{x:1605,y:882,t:1527628243966};\\\", \\\"{x:1605,y:885,t:1527628243983};\\\", \\\"{x:1605,y:888,t:1527628243998};\\\", \\\"{x:1605,y:892,t:1527628244016};\\\", \\\"{x:1604,y:896,t:1527628244032};\\\", \\\"{x:1604,y:901,t:1527628244049};\\\", \\\"{x:1603,y:907,t:1527628244066};\\\", \\\"{x:1602,y:914,t:1527628244082};\\\", \\\"{x:1602,y:915,t:1527628244098};\\\", \\\"{x:1602,y:919,t:1527628244116};\\\", \\\"{x:1602,y:922,t:1527628244133};\\\", \\\"{x:1601,y:923,t:1527628244301};\\\", \\\"{x:1599,y:923,t:1527628244315};\\\", \\\"{x:1587,y:892,t:1527628244332};\\\", \\\"{x:1581,y:869,t:1527628244350};\\\", \\\"{x:1576,y:846,t:1527628244366};\\\", \\\"{x:1571,y:821,t:1527628244383};\\\", \\\"{x:1567,y:786,t:1527628244400};\\\", \\\"{x:1557,y:745,t:1527628244416};\\\", \\\"{x:1550,y:720,t:1527628244433};\\\", \\\"{x:1535,y:688,t:1527628244449};\\\", \\\"{x:1525,y:659,t:1527628244465};\\\", \\\"{x:1513,y:631,t:1527628244483};\\\", \\\"{x:1503,y:607,t:1527628244500};\\\", \\\"{x:1487,y:582,t:1527628244515};\\\", \\\"{x:1474,y:557,t:1527628244533};\\\", \\\"{x:1467,y:540,t:1527628244550};\\\", \\\"{x:1462,y:534,t:1527628244566};\\\", \\\"{x:1460,y:531,t:1527628244583};\\\", \\\"{x:1459,y:530,t:1527628244599};\\\", \\\"{x:1459,y:528,t:1527628244620};\\\", \\\"{x:1458,y:528,t:1527628244636};\\\", \\\"{x:1457,y:527,t:1527628244724};\\\", \\\"{x:1456,y:525,t:1527628244732};\\\", \\\"{x:1453,y:518,t:1527628244750};\\\", \\\"{x:1451,y:515,t:1527628244767};\\\", \\\"{x:1448,y:510,t:1527628244783};\\\", \\\"{x:1447,y:507,t:1527628244800};\\\", \\\"{x:1445,y:506,t:1527628244817};\\\", \\\"{x:1445,y:505,t:1527628244833};\\\", \\\"{x:1444,y:503,t:1527628244850};\\\", \\\"{x:1444,y:501,t:1527628244866};\\\", \\\"{x:1442,y:497,t:1527628244883};\\\", \\\"{x:1439,y:493,t:1527628244900};\\\", \\\"{x:1438,y:490,t:1527628244916};\\\", \\\"{x:1437,y:488,t:1527628244933};\\\", \\\"{x:1437,y:487,t:1527628244964};\\\", \\\"{x:1435,y:485,t:1527628244981};\\\", \\\"{x:1435,y:484,t:1527628244996};\\\", \\\"{x:1435,y:482,t:1527628245005};\\\", \\\"{x:1433,y:480,t:1527628245017};\\\", \\\"{x:1431,y:473,t:1527628245033};\\\", \\\"{x:1427,y:467,t:1527628245050};\\\", \\\"{x:1427,y:463,t:1527628245066};\\\", \\\"{x:1424,y:459,t:1527628245084};\\\", \\\"{x:1424,y:458,t:1527628245101};\\\", \\\"{x:1424,y:456,t:1527628245148};\\\", \\\"{x:1424,y:454,t:1527628245172};\\\", \\\"{x:1423,y:452,t:1527628245189};\\\", \\\"{x:1421,y:451,t:1527628245204};\\\", \\\"{x:1421,y:450,t:1527628245221};\\\", \\\"{x:1421,y:449,t:1527628245245};\\\", \\\"{x:1421,y:448,t:1527628245252};\\\", \\\"{x:1421,y:447,t:1527628245277};\\\", \\\"{x:1421,y:446,t:1527628245309};\\\", \\\"{x:1420,y:446,t:1527628245429};\\\", \\\"{x:1420,y:444,t:1527628245445};\\\", \\\"{x:1420,y:443,t:1527628245452};\\\", \\\"{x:1418,y:441,t:1527628245467};\\\", \\\"{x:1417,y:439,t:1527628245484};\\\", \\\"{x:1416,y:435,t:1527628245500};\\\", \\\"{x:1414,y:434,t:1527628245517};\\\", \\\"{x:1414,y:433,t:1527628245534};\\\", \\\"{x:1409,y:433,t:1527628247774};\\\", \\\"{x:1387,y:451,t:1527628247786};\\\", \\\"{x:1359,y:480,t:1527628247802};\\\", \\\"{x:1311,y:515,t:1527628247819};\\\", \\\"{x:1245,y:555,t:1527628247835};\\\", \\\"{x:1137,y:603,t:1527628247851};\\\", \\\"{x:1011,y:661,t:1527628247869};\\\", \\\"{x:928,y:696,t:1527628247886};\\\", \\\"{x:832,y:736,t:1527628247901};\\\", \\\"{x:748,y:767,t:1527628247918};\\\", \\\"{x:715,y:781,t:1527628247935};\\\", \\\"{x:659,y:796,t:1527628247952};\\\", \\\"{x:582,y:807,t:1527628247969};\\\", \\\"{x:508,y:815,t:1527628247986};\\\", \\\"{x:464,y:817,t:1527628248002};\\\", \\\"{x:446,y:814,t:1527628248018};\\\", \\\"{x:438,y:813,t:1527628248036};\\\", \\\"{x:435,y:810,t:1527628248109};\\\", \\\"{x:434,y:806,t:1527628248119};\\\", \\\"{x:431,y:802,t:1527628248135};\\\", \\\"{x:425,y:796,t:1527628248152};\\\", \\\"{x:425,y:789,t:1527628248169};\\\", \\\"{x:422,y:785,t:1527628248186};\\\", \\\"{x:422,y:782,t:1527628248202};\\\", \\\"{x:422,y:780,t:1527628248236};\\\", \\\"{x:425,y:773,t:1527628248253};\\\", \\\"{x:430,y:768,t:1527628248268};\\\", \\\"{x:439,y:759,t:1527628248285};\\\", \\\"{x:445,y:749,t:1527628248303};\\\", \\\"{x:449,y:746,t:1527628248319};\\\", \\\"{x:459,y:741,t:1527628248336};\\\", \\\"{x:464,y:736,t:1527628248352};\\\", \\\"{x:471,y:732,t:1527628248368};\\\", \\\"{x:479,y:727,t:1527628248385};\\\", \\\"{x:489,y:719,t:1527628248402};\\\", \\\"{x:495,y:714,t:1527628248419};\\\", \\\"{x:502,y:711,t:1527628248435};\\\", \\\"{x:503,y:711,t:1527628248453};\\\", \\\"{x:504,y:710,t:1527628248470};\\\", \\\"{x:507,y:714,t:1527628248669};\\\", \\\"{x:508,y:718,t:1527628248677};\\\", \\\"{x:510,y:723,t:1527628248693};\\\", \\\"{x:511,y:725,t:1527628248703};\\\", \\\"{x:512,y:727,t:1527628248720};\\\", \\\"{x:513,y:729,t:1527628249148};\\\", \\\"{x:514,y:735,t:1527628249156};\\\", \\\"{x:515,y:740,t:1527628249171};\\\", \\\"{x:520,y:747,t:1527628249187};\\\", \\\"{x:522,y:752,t:1527628249203};\\\", \\\"{x:523,y:759,t:1527628249220};\\\", \\\"{x:527,y:764,t:1527628249237};\\\", \\\"{x:530,y:769,t:1527628249254};\\\", \\\"{x:531,y:772,t:1527628249270};\\\", \\\"{x:531,y:773,t:1527628249286};\\\", \\\"{x:532,y:775,t:1527628249303};\\\" ] }, { \\\"rt\\\": 7375, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 507618, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:774,t:1527628251013};\\\", \\\"{x:532,y:761,t:1527628251022};\\\", \\\"{x:526,y:744,t:1527628251040};\\\", \\\"{x:524,y:725,t:1527628251054};\\\", \\\"{x:522,y:705,t:1527628251072};\\\", \\\"{x:519,y:694,t:1527628251088};\\\", \\\"{x:519,y:683,t:1527628251105};\\\", \\\"{x:517,y:668,t:1527628251122};\\\", \\\"{x:516,y:653,t:1527628251139};\\\", \\\"{x:514,y:642,t:1527628251155};\\\", \\\"{x:514,y:633,t:1527628251172};\\\", \\\"{x:512,y:623,t:1527628251189};\\\", \\\"{x:510,y:612,t:1527628251205};\\\", \\\"{x:510,y:601,t:1527628251221};\\\", \\\"{x:510,y:589,t:1527628251239};\\\", \\\"{x:510,y:575,t:1527628251255};\\\", \\\"{x:511,y:564,t:1527628251272};\\\", \\\"{x:514,y:545,t:1527628251289};\\\", \\\"{x:514,y:536,t:1527628251305};\\\", \\\"{x:514,y:525,t:1527628251322};\\\", \\\"{x:514,y:511,t:1527628251340};\\\", \\\"{x:514,y:501,t:1527628251356};\\\", \\\"{x:515,y:486,t:1527628251372};\\\", \\\"{x:515,y:480,t:1527628251389};\\\", \\\"{x:515,y:477,t:1527628251406};\\\", \\\"{x:515,y:476,t:1527628251422};\\\", \\\"{x:515,y:474,t:1527628251445};\\\", \\\"{x:515,y:473,t:1527628251460};\\\", \\\"{x:516,y:473,t:1527628251741};\\\", \\\"{x:515,y:473,t:1527628252029};\\\", \\\"{x:514,y:473,t:1527628252039};\\\", \\\"{x:513,y:473,t:1527628252061};\\\", \\\"{x:511,y:473,t:1527628252076};\\\", \\\"{x:511,y:474,t:1527628252089};\\\", \\\"{x:509,y:475,t:1527628252106};\\\", \\\"{x:508,y:476,t:1527628252132};\\\", \\\"{x:507,y:476,t:1527628252148};\\\", \\\"{x:506,y:476,t:1527628252156};\\\", \\\"{x:500,y:476,t:1527628252173};\\\", \\\"{x:494,y:476,t:1527628252190};\\\", \\\"{x:491,y:475,t:1527628252206};\\\", \\\"{x:489,y:475,t:1527628252223};\\\", \\\"{x:488,y:475,t:1527628252239};\\\", \\\"{x:491,y:472,t:1527628253253};\\\", \\\"{x:495,y:471,t:1527628253260};\\\", \\\"{x:499,y:469,t:1527628253274};\\\", \\\"{x:504,y:467,t:1527628253290};\\\", \\\"{x:534,y:467,t:1527628253307};\\\", \\\"{x:561,y:467,t:1527628253324};\\\", \\\"{x:596,y:467,t:1527628253340};\\\", \\\"{x:680,y:467,t:1527628253357};\\\", \\\"{x:730,y:467,t:1527628253374};\\\", \\\"{x:754,y:463,t:1527628253390};\\\", \\\"{x:774,y:463,t:1527628253407};\\\", \\\"{x:795,y:463,t:1527628253423};\\\", \\\"{x:806,y:463,t:1527628253440};\\\", \\\"{x:822,y:463,t:1527628253457};\\\", \\\"{x:837,y:468,t:1527628253473};\\\", \\\"{x:852,y:473,t:1527628253491};\\\", \\\"{x:864,y:480,t:1527628253506};\\\", \\\"{x:878,y:489,t:1527628253525};\\\", \\\"{x:913,y:507,t:1527628253541};\\\", \\\"{x:935,y:515,t:1527628253557};\\\", \\\"{x:953,y:523,t:1527628253574};\\\", \\\"{x:971,y:530,t:1527628253591};\\\", \\\"{x:986,y:533,t:1527628253607};\\\", \\\"{x:994,y:536,t:1527628253624};\\\", \\\"{x:1002,y:538,t:1527628253641};\\\", \\\"{x:1006,y:540,t:1527628253657};\\\", \\\"{x:1013,y:543,t:1527628253674};\\\", \\\"{x:1019,y:547,t:1527628253692};\\\", \\\"{x:1026,y:550,t:1527628253707};\\\", \\\"{x:1032,y:552,t:1527628253724};\\\", \\\"{x:1059,y:560,t:1527628253740};\\\", \\\"{x:1079,y:563,t:1527628253757};\\\", \\\"{x:1101,y:563,t:1527628253774};\\\", \\\"{x:1112,y:565,t:1527628253791};\\\", \\\"{x:1130,y:566,t:1527628253807};\\\", \\\"{x:1146,y:566,t:1527628253823};\\\", \\\"{x:1171,y:566,t:1527628253841};\\\", \\\"{x:1186,y:566,t:1527628253857};\\\", \\\"{x:1205,y:566,t:1527628253874};\\\", \\\"{x:1223,y:563,t:1527628253891};\\\", \\\"{x:1235,y:560,t:1527628253908};\\\", \\\"{x:1242,y:559,t:1527628253924};\\\", \\\"{x:1257,y:554,t:1527628253942};\\\", \\\"{x:1262,y:551,t:1527628253958};\\\", \\\"{x:1270,y:548,t:1527628253974};\\\", \\\"{x:1279,y:548,t:1527628253991};\\\", \\\"{x:1291,y:548,t:1527628254008};\\\", \\\"{x:1299,y:547,t:1527628254024};\\\", \\\"{x:1305,y:547,t:1527628254041};\\\", \\\"{x:1308,y:546,t:1527628254058};\\\", \\\"{x:1314,y:546,t:1527628254074};\\\", \\\"{x:1322,y:546,t:1527628254091};\\\", \\\"{x:1329,y:546,t:1527628254108};\\\", \\\"{x:1334,y:546,t:1527628254124};\\\", \\\"{x:1340,y:546,t:1527628254141};\\\", \\\"{x:1341,y:546,t:1527628254180};\\\", \\\"{x:1336,y:548,t:1527628254284};\\\", \\\"{x:1336,y:549,t:1527628254292};\\\", \\\"{x:1328,y:552,t:1527628254308};\\\", \\\"{x:1310,y:557,t:1527628254324};\\\", \\\"{x:1278,y:565,t:1527628254342};\\\", \\\"{x:1238,y:569,t:1527628254358};\\\", \\\"{x:1169,y:569,t:1527628254375};\\\", \\\"{x:1113,y:577,t:1527628254391};\\\", \\\"{x:1066,y:581,t:1527628254408};\\\", \\\"{x:1011,y:594,t:1527628254425};\\\", \\\"{x:978,y:595,t:1527628254442};\\\", \\\"{x:965,y:595,t:1527628254458};\\\", \\\"{x:951,y:595,t:1527628254475};\\\", \\\"{x:945,y:595,t:1527628254491};\\\", \\\"{x:937,y:595,t:1527628254508};\\\", \\\"{x:926,y:596,t:1527628254525};\\\", \\\"{x:909,y:599,t:1527628254541};\\\", \\\"{x:891,y:602,t:1527628254559};\\\", \\\"{x:872,y:604,t:1527628254575};\\\", \\\"{x:854,y:604,t:1527628254591};\\\", \\\"{x:815,y:607,t:1527628254608};\\\", \\\"{x:789,y:610,t:1527628254625};\\\", \\\"{x:755,y:613,t:1527628254641};\\\", \\\"{x:718,y:616,t:1527628254658};\\\", \\\"{x:691,y:620,t:1527628254675};\\\", \\\"{x:648,y:624,t:1527628254692};\\\", \\\"{x:634,y:628,t:1527628254708};\\\", \\\"{x:608,y:630,t:1527628254724};\\\", \\\"{x:602,y:630,t:1527628254741};\\\", \\\"{x:596,y:630,t:1527628254758};\\\", \\\"{x:594,y:630,t:1527628254775};\\\", \\\"{x:592,y:630,t:1527628254791};\\\", \\\"{x:590,y:630,t:1527628254807};\\\", \\\"{x:589,y:630,t:1527628254828};\\\", \\\"{x:588,y:630,t:1527628254841};\\\", \\\"{x:585,y:630,t:1527628254858};\\\", \\\"{x:584,y:629,t:1527628254876};\\\", \\\"{x:583,y:628,t:1527628254892};\\\", \\\"{x:575,y:623,t:1527628254908};\\\", \\\"{x:564,y:617,t:1527628254925};\\\", \\\"{x:557,y:611,t:1527628254942};\\\", \\\"{x:549,y:608,t:1527628254958};\\\", \\\"{x:545,y:605,t:1527628254974};\\\", \\\"{x:542,y:602,t:1527628254991};\\\", \\\"{x:542,y:597,t:1527628255008};\\\", \\\"{x:542,y:595,t:1527628255025};\\\", \\\"{x:544,y:586,t:1527628255042};\\\", \\\"{x:551,y:576,t:1527628255058};\\\", \\\"{x:558,y:567,t:1527628255075};\\\", \\\"{x:570,y:552,t:1527628255092};\\\", \\\"{x:579,y:544,t:1527628255108};\\\", \\\"{x:586,y:538,t:1527628255125};\\\", \\\"{x:592,y:531,t:1527628255142};\\\", \\\"{x:596,y:525,t:1527628255159};\\\", \\\"{x:599,y:521,t:1527628255175};\\\", \\\"{x:602,y:518,t:1527628255192};\\\", \\\"{x:602,y:514,t:1527628255208};\\\", \\\"{x:604,y:511,t:1527628255225};\\\", \\\"{x:606,y:509,t:1527628255293};\\\", \\\"{x:607,y:505,t:1527628255309};\\\", \\\"{x:608,y:504,t:1527628255325};\\\", \\\"{x:610,y:501,t:1527628255342};\\\", \\\"{x:611,y:501,t:1527628255597};\\\", \\\"{x:612,y:501,t:1527628255609};\\\", \\\"{x:618,y:507,t:1527628255625};\\\", \\\"{x:627,y:521,t:1527628255642};\\\", \\\"{x:631,y:530,t:1527628255659};\\\", \\\"{x:633,y:540,t:1527628255676};\\\", \\\"{x:633,y:551,t:1527628255692};\\\", \\\"{x:629,y:568,t:1527628255710};\\\", \\\"{x:617,y:585,t:1527628255726};\\\", \\\"{x:590,y:607,t:1527628255743};\\\", \\\"{x:558,y:628,t:1527628255759};\\\", \\\"{x:522,y:637,t:1527628255776};\\\", \\\"{x:500,y:640,t:1527628255792};\\\", \\\"{x:484,y:642,t:1527628255809};\\\", \\\"{x:475,y:642,t:1527628255826};\\\", \\\"{x:472,y:641,t:1527628255842};\\\", \\\"{x:471,y:640,t:1527628255860};\\\", \\\"{x:471,y:639,t:1527628255876};\\\", \\\"{x:484,y:626,t:1527628255893};\\\", \\\"{x:503,y:614,t:1527628255910};\\\", \\\"{x:555,y:595,t:1527628255926};\\\", \\\"{x:626,y:579,t:1527628255943};\\\", \\\"{x:705,y:560,t:1527628255960};\\\", \\\"{x:761,y:544,t:1527628255976};\\\", \\\"{x:812,y:528,t:1527628255992};\\\", \\\"{x:854,y:519,t:1527628256010};\\\", \\\"{x:876,y:515,t:1527628256026};\\\", \\\"{x:892,y:512,t:1527628256043};\\\", \\\"{x:895,y:511,t:1527628256059};\\\", \\\"{x:888,y:514,t:1527628256300};\\\", \\\"{x:878,y:516,t:1527628256309};\\\", \\\"{x:874,y:519,t:1527628256327};\\\", \\\"{x:871,y:520,t:1527628256343};\\\", \\\"{x:871,y:521,t:1527628256525};\\\", \\\"{x:870,y:521,t:1527628256533};\\\", \\\"{x:869,y:521,t:1527628256548};\\\", \\\"{x:868,y:522,t:1527628256560};\\\", \\\"{x:864,y:525,t:1527628256578};\\\", \\\"{x:863,y:528,t:1527628256594};\\\", \\\"{x:862,y:532,t:1527628256611};\\\", \\\"{x:861,y:533,t:1527628256626};\\\", \\\"{x:860,y:535,t:1527628256643};\\\", \\\"{x:860,y:536,t:1527628256948};\\\", \\\"{x:858,y:539,t:1527628256960};\\\", \\\"{x:846,y:545,t:1527628256977};\\\", \\\"{x:824,y:558,t:1527628256993};\\\", \\\"{x:765,y:587,t:1527628257010};\\\", \\\"{x:650,y:631,t:1527628257027};\\\", \\\"{x:543,y:672,t:1527628257044};\\\", \\\"{x:417,y:725,t:1527628257060};\\\", \\\"{x:353,y:756,t:1527628257077};\\\", \\\"{x:339,y:767,t:1527628257093};\\\", \\\"{x:335,y:773,t:1527628257110};\\\", \\\"{x:334,y:777,t:1527628257126};\\\", \\\"{x:332,y:779,t:1527628257148};\\\", \\\"{x:336,y:779,t:1527628257301};\\\", \\\"{x:353,y:779,t:1527628257309};\\\", \\\"{x:390,y:779,t:1527628257326};\\\", \\\"{x:424,y:779,t:1527628257343};\\\", \\\"{x:446,y:776,t:1527628257359};\\\", \\\"{x:467,y:769,t:1527628257376};\\\", \\\"{x:475,y:765,t:1527628257392};\\\", \\\"{x:479,y:763,t:1527628257409};\\\", \\\"{x:480,y:762,t:1527628257430};\\\", \\\"{x:480,y:760,t:1527628257454};\\\", \\\"{x:481,y:758,t:1527628257460};\\\", \\\"{x:482,y:756,t:1527628257475};\\\", \\\"{x:484,y:752,t:1527628257492};\\\", \\\"{x:484,y:751,t:1527628257509};\\\", \\\"{x:484,y:750,t:1527628257527};\\\", \\\"{x:484,y:748,t:1527628257543};\\\", \\\"{x:484,y:746,t:1527628257560};\\\", \\\"{x:484,y:745,t:1527628257577};\\\", \\\"{x:484,y:744,t:1527628257604};\\\", \\\"{x:484,y:741,t:1527628257612};\\\", \\\"{x:484,y:739,t:1527628257628};\\\", \\\"{x:484,y:738,t:1527628257643};\\\", \\\"{x:486,y:732,t:1527628257660};\\\" ] }, { \\\"rt\\\": 20192, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 529043, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:480,y:716,t:1527628260173};\\\", \\\"{x:456,y:652,t:1527628260180};\\\", \\\"{x:387,y:549,t:1527628260196};\\\", \\\"{x:343,y:502,t:1527628260213};\\\", \\\"{x:324,y:482,t:1527628260229};\\\", \\\"{x:299,y:465,t:1527628260246};\\\", \\\"{x:284,y:456,t:1527628260262};\\\", \\\"{x:279,y:450,t:1527628260279};\\\", \\\"{x:277,y:448,t:1527628260296};\\\", \\\"{x:274,y:445,t:1527628260313};\\\", \\\"{x:270,y:442,t:1527628260329};\\\", \\\"{x:269,y:441,t:1527628260428};\\\", \\\"{x:272,y:441,t:1527628260533};\\\", \\\"{x:279,y:440,t:1527628260546};\\\", \\\"{x:282,y:440,t:1527628260563};\\\", \\\"{x:284,y:440,t:1527628260579};\\\", \\\"{x:285,y:440,t:1527628260596};\\\", \\\"{x:286,y:440,t:1527628260613};\\\", \\\"{x:287,y:440,t:1527628260629};\\\", \\\"{x:288,y:440,t:1527628260646};\\\", \\\"{x:290,y:440,t:1527628260663};\\\", \\\"{x:292,y:440,t:1527628260679};\\\", \\\"{x:294,y:440,t:1527628260696};\\\", \\\"{x:296,y:439,t:1527628260713};\\\", \\\"{x:297,y:439,t:1527628260729};\\\", \\\"{x:298,y:439,t:1527628260748};\\\", \\\"{x:300,y:439,t:1527628260820};\\\", \\\"{x:302,y:439,t:1527628260829};\\\", \\\"{x:306,y:444,t:1527628260846};\\\", \\\"{x:312,y:449,t:1527628260863};\\\", \\\"{x:317,y:453,t:1527628260880};\\\", \\\"{x:319,y:458,t:1527628260896};\\\", \\\"{x:320,y:458,t:1527628260913};\\\", \\\"{x:321,y:459,t:1527628261396};\\\", \\\"{x:320,y:461,t:1527628261413};\\\", \\\"{x:317,y:463,t:1527628261430};\\\", \\\"{x:314,y:464,t:1527628261446};\\\", \\\"{x:312,y:464,t:1527628261463};\\\", \\\"{x:311,y:464,t:1527628261480};\\\", \\\"{x:308,y:465,t:1527628261497};\\\", \\\"{x:307,y:466,t:1527628261513};\\\", \\\"{x:303,y:468,t:1527628261530};\\\", \\\"{x:297,y:468,t:1527628261547};\\\", \\\"{x:287,y:468,t:1527628261563};\\\", \\\"{x:279,y:468,t:1527628261579};\\\", \\\"{x:282,y:467,t:1527628261732};\\\", \\\"{x:284,y:467,t:1527628261747};\\\", \\\"{x:288,y:466,t:1527628261763};\\\", \\\"{x:291,y:464,t:1527628261780};\\\", \\\"{x:292,y:464,t:1527628261797};\\\", \\\"{x:293,y:464,t:1527628261827};\\\", \\\"{x:294,y:464,t:1527628261836};\\\", \\\"{x:296,y:463,t:1527628261847};\\\", \\\"{x:304,y:463,t:1527628261863};\\\", \\\"{x:317,y:461,t:1527628261880};\\\", \\\"{x:324,y:459,t:1527628261897};\\\", \\\"{x:328,y:459,t:1527628261913};\\\", \\\"{x:329,y:459,t:1527628261940};\\\", \\\"{x:330,y:459,t:1527628262012};\\\", \\\"{x:331,y:458,t:1527628262068};\\\", \\\"{x:332,y:458,t:1527628262220};\\\", \\\"{x:335,y:456,t:1527628262230};\\\", \\\"{x:358,y:456,t:1527628262247};\\\", \\\"{x:389,y:455,t:1527628262265};\\\", \\\"{x:453,y:448,t:1527628262280};\\\", \\\"{x:503,y:448,t:1527628262297};\\\", \\\"{x:529,y:448,t:1527628262314};\\\", \\\"{x:553,y:447,t:1527628262330};\\\", \\\"{x:560,y:447,t:1527628262348};\\\", \\\"{x:564,y:446,t:1527628262364};\\\", \\\"{x:566,y:446,t:1527628262508};\\\", \\\"{x:567,y:446,t:1527628262532};\\\", \\\"{x:569,y:446,t:1527628262556};\\\", \\\"{x:567,y:447,t:1527628262916};\\\", \\\"{x:566,y:447,t:1527628262931};\\\", \\\"{x:565,y:448,t:1527628262956};\\\", \\\"{x:564,y:448,t:1527628263149};\\\", \\\"{x:564,y:449,t:1527628263252};\\\", \\\"{x:565,y:451,t:1527628263265};\\\", \\\"{x:578,y:456,t:1527628263282};\\\", \\\"{x:584,y:457,t:1527628263297};\\\", \\\"{x:597,y:459,t:1527628263315};\\\", \\\"{x:609,y:460,t:1527628263331};\\\", \\\"{x:622,y:460,t:1527628263347};\\\", \\\"{x:637,y:461,t:1527628263364};\\\", \\\"{x:656,y:461,t:1527628263382};\\\", \\\"{x:669,y:462,t:1527628263397};\\\", \\\"{x:684,y:462,t:1527628263415};\\\", \\\"{x:700,y:465,t:1527628263431};\\\", \\\"{x:714,y:467,t:1527628263448};\\\", \\\"{x:729,y:469,t:1527628263465};\\\", \\\"{x:741,y:471,t:1527628263481};\\\", \\\"{x:751,y:472,t:1527628263498};\\\", \\\"{x:761,y:475,t:1527628263514};\\\", \\\"{x:777,y:475,t:1527628263532};\\\", \\\"{x:804,y:477,t:1527628263548};\\\", \\\"{x:815,y:479,t:1527628263564};\\\", \\\"{x:824,y:479,t:1527628263582};\\\", \\\"{x:827,y:479,t:1527628263599};\\\", \\\"{x:830,y:479,t:1527628263614};\\\", \\\"{x:835,y:479,t:1527628263631};\\\", \\\"{x:840,y:479,t:1527628263648};\\\", \\\"{x:846,y:480,t:1527628263664};\\\", \\\"{x:855,y:480,t:1527628263682};\\\", \\\"{x:866,y:481,t:1527628263699};\\\", \\\"{x:877,y:481,t:1527628263714};\\\", \\\"{x:899,y:485,t:1527628263731};\\\", \\\"{x:928,y:486,t:1527628263748};\\\", \\\"{x:954,y:486,t:1527628263764};\\\", \\\"{x:975,y:486,t:1527628263782};\\\", \\\"{x:1002,y:486,t:1527628263798};\\\", \\\"{x:1028,y:484,t:1527628263815};\\\", \\\"{x:1042,y:484,t:1527628263831};\\\", \\\"{x:1050,y:482,t:1527628263849};\\\", \\\"{x:1053,y:482,t:1527628263864};\\\", \\\"{x:1053,y:481,t:1527628263964};\\\", \\\"{x:1054,y:480,t:1527628263988};\\\", \\\"{x:1056,y:479,t:1527628264004};\\\", \\\"{x:1057,y:479,t:1527628264014};\\\", \\\"{x:1058,y:479,t:1527628264031};\\\", \\\"{x:1061,y:477,t:1527628264048};\\\", \\\"{x:1064,y:477,t:1527628264065};\\\", \\\"{x:1067,y:477,t:1527628264082};\\\", \\\"{x:1071,y:476,t:1527628264098};\\\", \\\"{x:1078,y:475,t:1527628264115};\\\", \\\"{x:1087,y:473,t:1527628264131};\\\", \\\"{x:1096,y:473,t:1527628264148};\\\", \\\"{x:1104,y:473,t:1527628264166};\\\", \\\"{x:1108,y:473,t:1527628264181};\\\", \\\"{x:1114,y:473,t:1527628264199};\\\", \\\"{x:1119,y:477,t:1527628264215};\\\", \\\"{x:1126,y:481,t:1527628264231};\\\", \\\"{x:1135,y:488,t:1527628264248};\\\", \\\"{x:1140,y:492,t:1527628264265};\\\", \\\"{x:1143,y:498,t:1527628264281};\\\", \\\"{x:1145,y:501,t:1527628264298};\\\", \\\"{x:1146,y:503,t:1527628264316};\\\", \\\"{x:1148,y:505,t:1527628264332};\\\", \\\"{x:1150,y:511,t:1527628264348};\\\", \\\"{x:1153,y:517,t:1527628264365};\\\", \\\"{x:1154,y:521,t:1527628264381};\\\", \\\"{x:1157,y:528,t:1527628264399};\\\", \\\"{x:1157,y:532,t:1527628264415};\\\", \\\"{x:1157,y:539,t:1527628264431};\\\", \\\"{x:1158,y:546,t:1527628264448};\\\", \\\"{x:1160,y:553,t:1527628264465};\\\", \\\"{x:1161,y:560,t:1527628264481};\\\", \\\"{x:1162,y:565,t:1527628264499};\\\", \\\"{x:1162,y:569,t:1527628264515};\\\", \\\"{x:1162,y:573,t:1527628264531};\\\", \\\"{x:1164,y:575,t:1527628264548};\\\", \\\"{x:1164,y:577,t:1527628264572};\\\", \\\"{x:1164,y:578,t:1527628264581};\\\", \\\"{x:1165,y:578,t:1527628264598};\\\", \\\"{x:1165,y:579,t:1527628264616};\\\", \\\"{x:1167,y:580,t:1527628264631};\\\", \\\"{x:1167,y:582,t:1527628264649};\\\", \\\"{x:1168,y:584,t:1527628264665};\\\", \\\"{x:1169,y:585,t:1527628264700};\\\", \\\"{x:1170,y:586,t:1527628264715};\\\", \\\"{x:1173,y:590,t:1527628264731};\\\", \\\"{x:1177,y:593,t:1527628264748};\\\", \\\"{x:1181,y:596,t:1527628264765};\\\", \\\"{x:1190,y:601,t:1527628264782};\\\", \\\"{x:1194,y:603,t:1527628264798};\\\", \\\"{x:1195,y:604,t:1527628264816};\\\", \\\"{x:1197,y:604,t:1527628264833};\\\", \\\"{x:1197,y:605,t:1527628264848};\\\", \\\"{x:1199,y:605,t:1527628264866};\\\", \\\"{x:1201,y:607,t:1527628264883};\\\", \\\"{x:1202,y:608,t:1527628264908};\\\", \\\"{x:1203,y:610,t:1527628264948};\\\", \\\"{x:1204,y:612,t:1527628264965};\\\", \\\"{x:1207,y:618,t:1527628264982};\\\", \\\"{x:1208,y:621,t:1527628264998};\\\", \\\"{x:1209,y:622,t:1527628265508};\\\", \\\"{x:1211,y:624,t:1527628265516};\\\", \\\"{x:1216,y:626,t:1527628265531};\\\", \\\"{x:1223,y:631,t:1527628265549};\\\", \\\"{x:1231,y:634,t:1527628265566};\\\", \\\"{x:1232,y:634,t:1527628265583};\\\", \\\"{x:1239,y:635,t:1527628265600};\\\", \\\"{x:1250,y:640,t:1527628265616};\\\", \\\"{x:1257,y:643,t:1527628265632};\\\", \\\"{x:1262,y:644,t:1527628265649};\\\", \\\"{x:1265,y:644,t:1527628265665};\\\", \\\"{x:1266,y:644,t:1527628265988};\\\", \\\"{x:1266,y:643,t:1527628266000};\\\", \\\"{x:1264,y:639,t:1527628266016};\\\", \\\"{x:1263,y:637,t:1527628266033};\\\", \\\"{x:1263,y:635,t:1527628266050};\\\", \\\"{x:1261,y:633,t:1527628266172};\\\", \\\"{x:1260,y:632,t:1527628266187};\\\", \\\"{x:1260,y:631,t:1527628266220};\\\", \\\"{x:1258,y:631,t:1527628266276};\\\", \\\"{x:1258,y:630,t:1527628266308};\\\", \\\"{x:1257,y:630,t:1527628266709};\\\", \\\"{x:1257,y:632,t:1527628266756};\\\", \\\"{x:1257,y:633,t:1527628266780};\\\", \\\"{x:1257,y:634,t:1527628266788};\\\", \\\"{x:1258,y:636,t:1527628266800};\\\", \\\"{x:1259,y:638,t:1527628266828};\\\", \\\"{x:1259,y:639,t:1527628266844};\\\", \\\"{x:1260,y:640,t:1527628266852};\\\", \\\"{x:1260,y:641,t:1527628266866};\\\", \\\"{x:1262,y:645,t:1527628266884};\\\", \\\"{x:1265,y:649,t:1527628266900};\\\", \\\"{x:1266,y:654,t:1527628266916};\\\", \\\"{x:1268,y:656,t:1527628266934};\\\", \\\"{x:1270,y:660,t:1527628266950};\\\", \\\"{x:1271,y:660,t:1527628266980};\\\", \\\"{x:1272,y:661,t:1527628266988};\\\", \\\"{x:1273,y:662,t:1527628267004};\\\", \\\"{x:1275,y:664,t:1527628267016};\\\", \\\"{x:1280,y:667,t:1527628267034};\\\", \\\"{x:1284,y:671,t:1527628267050};\\\", \\\"{x:1288,y:674,t:1527628267066};\\\", \\\"{x:1295,y:679,t:1527628267084};\\\", \\\"{x:1303,y:683,t:1527628267100};\\\", \\\"{x:1313,y:686,t:1527628267117};\\\", \\\"{x:1314,y:688,t:1527628267134};\\\", \\\"{x:1315,y:690,t:1527628267349};\\\", \\\"{x:1317,y:692,t:1527628267356};\\\", \\\"{x:1319,y:693,t:1527628267366};\\\", \\\"{x:1323,y:695,t:1527628267384};\\\", \\\"{x:1328,y:696,t:1527628267401};\\\", \\\"{x:1330,y:698,t:1527628267417};\\\", \\\"{x:1331,y:698,t:1527628267433};\\\", \\\"{x:1332,y:698,t:1527628267636};\\\", \\\"{x:1332,y:699,t:1527628267692};\\\", \\\"{x:1333,y:699,t:1527628267716};\\\", \\\"{x:1335,y:699,t:1527628267733};\\\", \\\"{x:1336,y:697,t:1527628267751};\\\", \\\"{x:1337,y:696,t:1527628267767};\\\", \\\"{x:1338,y:694,t:1527628267796};\\\", \\\"{x:1339,y:694,t:1527628267844};\\\", \\\"{x:1340,y:694,t:1527628267933};\\\", \\\"{x:1342,y:694,t:1527628268004};\\\", \\\"{x:1343,y:694,t:1527628268052};\\\", \\\"{x:1346,y:694,t:1527628268084};\\\", \\\"{x:1347,y:694,t:1527628268132};\\\", \\\"{x:1348,y:696,t:1527628268252};\\\", \\\"{x:1349,y:696,t:1527628268268};\\\", \\\"{x:1349,y:697,t:1527628268283};\\\", \\\"{x:1349,y:699,t:1527628268301};\\\", \\\"{x:1349,y:701,t:1527628268317};\\\", \\\"{x:1350,y:703,t:1527628268334};\\\", \\\"{x:1350,y:704,t:1527628268350};\\\", \\\"{x:1351,y:707,t:1527628268372};\\\", \\\"{x:1352,y:711,t:1527628268388};\\\", \\\"{x:1353,y:712,t:1527628268412};\\\", \\\"{x:1353,y:714,t:1527628268476};\\\", \\\"{x:1353,y:716,t:1527628268508};\\\", \\\"{x:1353,y:717,t:1527628268517};\\\", \\\"{x:1353,y:719,t:1527628268534};\\\", \\\"{x:1353,y:720,t:1527628268551};\\\", \\\"{x:1354,y:725,t:1527628268568};\\\", \\\"{x:1354,y:726,t:1527628268585};\\\", \\\"{x:1356,y:730,t:1527628268600};\\\", \\\"{x:1357,y:733,t:1527628268618};\\\", \\\"{x:1357,y:735,t:1527628268635};\\\", \\\"{x:1357,y:736,t:1527628268651};\\\", \\\"{x:1357,y:739,t:1527628268668};\\\", \\\"{x:1357,y:742,t:1527628268684};\\\", \\\"{x:1358,y:742,t:1527628268701};\\\", \\\"{x:1358,y:745,t:1527628268732};\\\", \\\"{x:1358,y:746,t:1527628268796};\\\", \\\"{x:1358,y:749,t:1527628268956};\\\", \\\"{x:1357,y:752,t:1527628268972};\\\", \\\"{x:1356,y:752,t:1527628268985};\\\", \\\"{x:1355,y:753,t:1527628269001};\\\", \\\"{x:1353,y:753,t:1527628269020};\\\", \\\"{x:1352,y:755,t:1527628269036};\\\", \\\"{x:1351,y:755,t:1527628269172};\\\", \\\"{x:1350,y:755,t:1527628269301};\\\", \\\"{x:1349,y:755,t:1527628269318};\\\", \\\"{x:1347,y:756,t:1527628269334};\\\", \\\"{x:1347,y:757,t:1527628269356};\\\", \\\"{x:1346,y:757,t:1527628269368};\\\", \\\"{x:1345,y:757,t:1527628272444};\\\", \\\"{x:1344,y:754,t:1527628272476};\\\", \\\"{x:1342,y:745,t:1527628272487};\\\", \\\"{x:1340,y:740,t:1527628272503};\\\", \\\"{x:1340,y:736,t:1527628272519};\\\", \\\"{x:1339,y:729,t:1527628272537};\\\", \\\"{x:1339,y:725,t:1527628272553};\\\", \\\"{x:1339,y:723,t:1527628272748};\\\", \\\"{x:1339,y:722,t:1527628272755};\\\", \\\"{x:1338,y:721,t:1527628272769};\\\", \\\"{x:1338,y:719,t:1527628272787};\\\", \\\"{x:1338,y:717,t:1527628272802};\\\", \\\"{x:1338,y:715,t:1527628272819};\\\", \\\"{x:1338,y:713,t:1527628272852};\\\", \\\"{x:1338,y:712,t:1527628272875};\\\", \\\"{x:1338,y:711,t:1527628272887};\\\", \\\"{x:1337,y:711,t:1527628272903};\\\", \\\"{x:1336,y:718,t:1527628273052};\\\", \\\"{x:1336,y:729,t:1527628273060};\\\", \\\"{x:1336,y:743,t:1527628273069};\\\", \\\"{x:1335,y:767,t:1527628273086};\\\", \\\"{x:1336,y:789,t:1527628273104};\\\", \\\"{x:1333,y:819,t:1527628273120};\\\", \\\"{x:1327,y:851,t:1527628273137};\\\", \\\"{x:1324,y:861,t:1527628273154};\\\", \\\"{x:1323,y:870,t:1527628273169};\\\", \\\"{x:1323,y:861,t:1527628273292};\\\", \\\"{x:1323,y:849,t:1527628273304};\\\", \\\"{x:1325,y:816,t:1527628273319};\\\", \\\"{x:1325,y:796,t:1527628273337};\\\", \\\"{x:1325,y:774,t:1527628273353};\\\", \\\"{x:1325,y:764,t:1527628273370};\\\", \\\"{x:1327,y:757,t:1527628273387};\\\", \\\"{x:1328,y:747,t:1527628273404};\\\", \\\"{x:1329,y:744,t:1527628273419};\\\", \\\"{x:1329,y:740,t:1527628273437};\\\", \\\"{x:1329,y:737,t:1527628273453};\\\", \\\"{x:1330,y:736,t:1527628273470};\\\", \\\"{x:1330,y:735,t:1527628273549};\\\", \\\"{x:1329,y:734,t:1527628273564};\\\", \\\"{x:1323,y:731,t:1527628273572};\\\", \\\"{x:1312,y:729,t:1527628273587};\\\", \\\"{x:1233,y:718,t:1527628273604};\\\", \\\"{x:1115,y:710,t:1527628273620};\\\", \\\"{x:954,y:699,t:1527628273636};\\\", \\\"{x:730,y:699,t:1527628273654};\\\", \\\"{x:527,y:683,t:1527628273671};\\\", \\\"{x:378,y:666,t:1527628273686};\\\", \\\"{x:253,y:649,t:1527628273705};\\\", \\\"{x:186,y:637,t:1527628273721};\\\", \\\"{x:175,y:630,t:1527628273742};\\\", \\\"{x:175,y:629,t:1527628273757};\\\", \\\"{x:175,y:626,t:1527628273788};\\\", \\\"{x:175,y:621,t:1527628273796};\\\", \\\"{x:175,y:616,t:1527628273807};\\\", \\\"{x:175,y:603,t:1527628273824};\\\", \\\"{x:175,y:593,t:1527628273841};\\\", \\\"{x:176,y:582,t:1527628273858};\\\", \\\"{x:181,y:574,t:1527628273873};\\\", \\\"{x:185,y:566,t:1527628273890};\\\", \\\"{x:199,y:550,t:1527628273909};\\\", \\\"{x:213,y:541,t:1527628273923};\\\", \\\"{x:232,y:534,t:1527628273941};\\\", \\\"{x:249,y:529,t:1527628273958};\\\", \\\"{x:277,y:526,t:1527628273974};\\\", \\\"{x:295,y:524,t:1527628273991};\\\", \\\"{x:319,y:525,t:1527628274008};\\\", \\\"{x:346,y:529,t:1527628274023};\\\", \\\"{x:378,y:536,t:1527628274041};\\\", \\\"{x:406,y:540,t:1527628274058};\\\", \\\"{x:437,y:544,t:1527628274074};\\\", \\\"{x:447,y:547,t:1527628274090};\\\", \\\"{x:465,y:550,t:1527628274108};\\\", \\\"{x:472,y:550,t:1527628274124};\\\", \\\"{x:474,y:550,t:1527628274140};\\\", \\\"{x:479,y:550,t:1527628274158};\\\", \\\"{x:487,y:551,t:1527628274173};\\\", \\\"{x:502,y:552,t:1527628274191};\\\", \\\"{x:522,y:555,t:1527628274208};\\\", \\\"{x:536,y:557,t:1527628274224};\\\", \\\"{x:557,y:557,t:1527628274240};\\\", \\\"{x:577,y:557,t:1527628274257};\\\", \\\"{x:593,y:557,t:1527628274274};\\\", \\\"{x:610,y:557,t:1527628274291};\\\", \\\"{x:636,y:557,t:1527628274308};\\\", \\\"{x:653,y:554,t:1527628274324};\\\", \\\"{x:672,y:551,t:1527628274341};\\\", \\\"{x:689,y:546,t:1527628274358};\\\", \\\"{x:697,y:542,t:1527628274375};\\\", \\\"{x:707,y:538,t:1527628274391};\\\", \\\"{x:707,y:537,t:1527628274408};\\\", \\\"{x:709,y:536,t:1527628274424};\\\", \\\"{x:712,y:534,t:1527628274524};\\\", \\\"{x:723,y:529,t:1527628274541};\\\", \\\"{x:740,y:523,t:1527628274558};\\\", \\\"{x:762,y:518,t:1527628274574};\\\", \\\"{x:777,y:517,t:1527628274591};\\\", \\\"{x:786,y:515,t:1527628274608};\\\", \\\"{x:792,y:513,t:1527628274624};\\\", \\\"{x:795,y:512,t:1527628274641};\\\", \\\"{x:796,y:511,t:1527628274657};\\\", \\\"{x:797,y:511,t:1527628274674};\\\", \\\"{x:798,y:510,t:1527628274691};\\\", \\\"{x:799,y:508,t:1527628274708};\\\", \\\"{x:801,y:507,t:1527628274725};\\\", \\\"{x:801,y:505,t:1527628274742};\\\", \\\"{x:802,y:505,t:1527628274758};\\\", \\\"{x:804,y:503,t:1527628274779};\\\", \\\"{x:805,y:502,t:1527628274791};\\\", \\\"{x:807,y:501,t:1527628274808};\\\", \\\"{x:809,y:500,t:1527628274825};\\\", \\\"{x:812,y:498,t:1527628274841};\\\", \\\"{x:814,y:498,t:1527628274858};\\\", \\\"{x:817,y:498,t:1527628274874};\\\", \\\"{x:821,y:497,t:1527628274892};\\\", \\\"{x:824,y:496,t:1527628274908};\\\", \\\"{x:825,y:495,t:1527628274924};\\\", \\\"{x:826,y:494,t:1527628274942};\\\", \\\"{x:828,y:493,t:1527628275020};\\\", \\\"{x:829,y:493,t:1527628275044};\\\", \\\"{x:829,y:493,t:1527628275104};\\\", \\\"{x:826,y:495,t:1527628275212};\\\", \\\"{x:820,y:500,t:1527628275225};\\\", \\\"{x:810,y:509,t:1527628275242};\\\", \\\"{x:787,y:521,t:1527628275259};\\\", \\\"{x:760,y:533,t:1527628275275};\\\", \\\"{x:632,y:556,t:1527628275292};\\\", \\\"{x:530,y:570,t:1527628275309};\\\", \\\"{x:448,y:573,t:1527628275326};\\\", \\\"{x:362,y:573,t:1527628275342};\\\", \\\"{x:314,y:573,t:1527628275358};\\\", \\\"{x:297,y:573,t:1527628275376};\\\", \\\"{x:292,y:573,t:1527628275392};\\\", \\\"{x:291,y:573,t:1527628275461};\\\", \\\"{x:288,y:572,t:1527628275476};\\\", \\\"{x:286,y:572,t:1527628275493};\\\", \\\"{x:285,y:572,t:1527628275548};\\\", \\\"{x:282,y:572,t:1527628275587};\\\", \\\"{x:279,y:571,t:1527628275596};\\\", \\\"{x:277,y:571,t:1527628275610};\\\", \\\"{x:270,y:569,t:1527628275627};\\\", \\\"{x:260,y:568,t:1527628275642};\\\", \\\"{x:249,y:565,t:1527628275658};\\\", \\\"{x:238,y:562,t:1527628275676};\\\", \\\"{x:235,y:560,t:1527628275692};\\\", \\\"{x:230,y:558,t:1527628275709};\\\", \\\"{x:227,y:557,t:1527628275725};\\\", \\\"{x:226,y:556,t:1527628275742};\\\", \\\"{x:225,y:556,t:1527628275759};\\\", \\\"{x:224,y:556,t:1527628275776};\\\", \\\"{x:222,y:555,t:1527628275821};\\\", \\\"{x:221,y:555,t:1527628275828};\\\", \\\"{x:220,y:555,t:1527628275844};\\\", \\\"{x:219,y:555,t:1527628275859};\\\", \\\"{x:217,y:555,t:1527628275876};\\\", \\\"{x:216,y:555,t:1527628275893};\\\", \\\"{x:213,y:554,t:1527628275909};\\\", \\\"{x:212,y:554,t:1527628275926};\\\", \\\"{x:208,y:554,t:1527628275943};\\\", \\\"{x:200,y:554,t:1527628275958};\\\", \\\"{x:194,y:553,t:1527628275975};\\\", \\\"{x:189,y:553,t:1527628275992};\\\", \\\"{x:185,y:552,t:1527628276009};\\\", \\\"{x:185,y:551,t:1527628276026};\\\", \\\"{x:184,y:551,t:1527628276315};\\\", \\\"{x:186,y:553,t:1527628276326};\\\", \\\"{x:218,y:570,t:1527628276343};\\\", \\\"{x:258,y:591,t:1527628276359};\\\", \\\"{x:283,y:607,t:1527628276376};\\\", \\\"{x:322,y:623,t:1527628276393};\\\", \\\"{x:357,y:642,t:1527628276409};\\\", \\\"{x:374,y:653,t:1527628276426};\\\", \\\"{x:393,y:666,t:1527628276443};\\\", \\\"{x:422,y:681,t:1527628276460};\\\", \\\"{x:437,y:687,t:1527628276476};\\\", \\\"{x:443,y:690,t:1527628276493};\\\", \\\"{x:445,y:690,t:1527628276510};\\\", \\\"{x:440,y:683,t:1527628276676};\\\", \\\"{x:429,y:668,t:1527628276693};\\\", \\\"{x:411,y:652,t:1527628276710};\\\", \\\"{x:370,y:636,t:1527628276726};\\\", \\\"{x:339,y:626,t:1527628276743};\\\", \\\"{x:309,y:618,t:1527628276760};\\\", \\\"{x:278,y:612,t:1527628276775};\\\", \\\"{x:246,y:607,t:1527628276793};\\\", \\\"{x:219,y:602,t:1527628276810};\\\", \\\"{x:198,y:598,t:1527628276826};\\\", \\\"{x:180,y:593,t:1527628276843};\\\", \\\"{x:171,y:589,t:1527628276859};\\\", \\\"{x:165,y:584,t:1527628276877};\\\", \\\"{x:165,y:582,t:1527628276948};\\\", \\\"{x:165,y:578,t:1527628276960};\\\", \\\"{x:165,y:572,t:1527628276977};\\\", \\\"{x:165,y:567,t:1527628276992};\\\", \\\"{x:165,y:563,t:1527628277010};\\\", \\\"{x:167,y:556,t:1527628277027};\\\", \\\"{x:169,y:554,t:1527628277043};\\\", \\\"{x:169,y:552,t:1527628277067};\\\", \\\"{x:171,y:552,t:1527628277396};\\\", \\\"{x:180,y:558,t:1527628277410};\\\", \\\"{x:218,y:585,t:1527628277427};\\\", \\\"{x:270,y:616,t:1527628277444};\\\", \\\"{x:293,y:631,t:1527628277460};\\\", \\\"{x:319,y:640,t:1527628277477};\\\", \\\"{x:346,y:650,t:1527628277493};\\\", \\\"{x:382,y:666,t:1527628277510};\\\", \\\"{x:415,y:675,t:1527628277527};\\\", \\\"{x:445,y:688,t:1527628277544};\\\", \\\"{x:465,y:697,t:1527628277560};\\\", \\\"{x:479,y:702,t:1527628277577};\\\", \\\"{x:485,y:708,t:1527628277594};\\\", \\\"{x:490,y:711,t:1527628277610};\\\", \\\"{x:492,y:712,t:1527628277627};\\\", \\\"{x:487,y:710,t:1527628277707};\\\", \\\"{x:470,y:701,t:1527628277716};\\\", \\\"{x:447,y:690,t:1527628277726};\\\", \\\"{x:373,y:662,t:1527628277744};\\\", \\\"{x:288,y:643,t:1527628277760};\\\", \\\"{x:218,y:633,t:1527628277777};\\\", \\\"{x:171,y:620,t:1527628277794};\\\", \\\"{x:133,y:612,t:1527628277811};\\\", \\\"{x:109,y:603,t:1527628277827};\\\", \\\"{x:91,y:589,t:1527628277844};\\\", \\\"{x:89,y:586,t:1527628277861};\\\", \\\"{x:87,y:583,t:1527628277876};\\\", \\\"{x:86,y:576,t:1527628277894};\\\", \\\"{x:86,y:574,t:1527628277911};\\\", \\\"{x:86,y:572,t:1527628277927};\\\", \\\"{x:87,y:569,t:1527628277944};\\\", \\\"{x:90,y:568,t:1527628277960};\\\", \\\"{x:93,y:565,t:1527628277977};\\\", \\\"{x:95,y:563,t:1527628277994};\\\", \\\"{x:97,y:561,t:1527628278011};\\\", \\\"{x:98,y:561,t:1527628278027};\\\", \\\"{x:102,y:559,t:1527628278044};\\\", \\\"{x:104,y:559,t:1527628278067};\\\", \\\"{x:106,y:559,t:1527628278077};\\\", \\\"{x:112,y:559,t:1527628278094};\\\", \\\"{x:118,y:558,t:1527628278111};\\\", \\\"{x:119,y:558,t:1527628278127};\\\", \\\"{x:120,y:556,t:1527628278144};\\\", \\\"{x:120,y:555,t:1527628278172};\\\", \\\"{x:120,y:554,t:1527628278196};\\\", \\\"{x:123,y:552,t:1527628278210};\\\", \\\"{x:135,y:550,t:1527628278228};\\\", \\\"{x:146,y:546,t:1527628278244};\\\", \\\"{x:149,y:546,t:1527628278261};\\\", \\\"{x:154,y:543,t:1527628278277};\\\", \\\"{x:158,y:542,t:1527628278293};\\\", \\\"{x:159,y:540,t:1527628278311};\\\", \\\"{x:160,y:540,t:1527628278327};\\\", \\\"{x:160,y:539,t:1527628278460};\\\", \\\"{x:160,y:539,t:1527628278519};\\\", \\\"{x:161,y:539,t:1527628278539};\\\", \\\"{x:163,y:540,t:1527628278548};\\\", \\\"{x:169,y:542,t:1527628278561};\\\", \\\"{x:178,y:550,t:1527628278578};\\\", \\\"{x:187,y:561,t:1527628278596};\\\", \\\"{x:197,y:573,t:1527628278611};\\\", \\\"{x:226,y:595,t:1527628278628};\\\", \\\"{x:248,y:611,t:1527628278645};\\\", \\\"{x:285,y:632,t:1527628278662};\\\", \\\"{x:308,y:647,t:1527628278678};\\\", \\\"{x:326,y:663,t:1527628278694};\\\", \\\"{x:344,y:676,t:1527628278711};\\\", \\\"{x:359,y:687,t:1527628278727};\\\", \\\"{x:375,y:695,t:1527628278745};\\\", \\\"{x:386,y:705,t:1527628278760};\\\", \\\"{x:395,y:708,t:1527628278777};\\\", \\\"{x:401,y:712,t:1527628278795};\\\", \\\"{x:408,y:716,t:1527628278811};\\\", \\\"{x:413,y:719,t:1527628278828};\\\", \\\"{x:416,y:720,t:1527628278844};\\\", \\\"{x:417,y:720,t:1527628278861};\\\", \\\"{x:419,y:720,t:1527628278878};\\\", \\\"{x:422,y:721,t:1527628278894};\\\", \\\"{x:423,y:724,t:1527628278911};\\\", \\\"{x:425,y:726,t:1527628278928};\\\", \\\"{x:429,y:727,t:1527628278945};\\\", \\\"{x:432,y:728,t:1527628278961};\\\", \\\"{x:437,y:731,t:1527628278978};\\\", \\\"{x:441,y:733,t:1527628278995};\\\", \\\"{x:448,y:735,t:1527628279011};\\\", \\\"{x:460,y:739,t:1527628279028};\\\", \\\"{x:466,y:739,t:1527628279045};\\\", \\\"{x:468,y:740,t:1527628279276};\\\", \\\"{x:468,y:741,t:1527628279548};\\\", \\\"{x:468,y:742,t:1527628279561};\\\" ] }, { \\\"rt\\\": 36728, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 566972, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -B -X -B -F -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:468,y:743,t:1527628280740};\\\", \\\"{x:467,y:743,t:1527628280755};\\\", \\\"{x:465,y:743,t:1527628280763};\\\", \\\"{x:461,y:743,t:1527628280779};\\\", \\\"{x:452,y:739,t:1527628280796};\\\", \\\"{x:434,y:729,t:1527628280813};\\\", \\\"{x:315,y:634,t:1527628280878};\\\", \\\"{x:298,y:621,t:1527628280885};\\\", \\\"{x:286,y:612,t:1527628280896};\\\", \\\"{x:278,y:602,t:1527628280913};\\\", \\\"{x:271,y:588,t:1527628280930};\\\", \\\"{x:265,y:571,t:1527628280946};\\\", \\\"{x:259,y:557,t:1527628280963};\\\", \\\"{x:253,y:538,t:1527628280980};\\\", \\\"{x:247,y:518,t:1527628280996};\\\", \\\"{x:240,y:504,t:1527628281014};\\\", \\\"{x:238,y:494,t:1527628281030};\\\", \\\"{x:238,y:487,t:1527628281046};\\\", \\\"{x:235,y:477,t:1527628281064};\\\", \\\"{x:234,y:473,t:1527628281080};\\\", \\\"{x:233,y:469,t:1527628281097};\\\", \\\"{x:233,y:468,t:1527628281113};\\\", \\\"{x:232,y:466,t:1527628281130};\\\", \\\"{x:232,y:465,t:1527628281147};\\\", \\\"{x:232,y:464,t:1527628281163};\\\", \\\"{x:232,y:463,t:1527628281187};\\\", \\\"{x:232,y:462,t:1527628282436};\\\", \\\"{x:232,y:461,t:1527628282468};\\\", \\\"{x:232,y:460,t:1527628282531};\\\", \\\"{x:232,y:459,t:1527628282548};\\\", \\\"{x:232,y:457,t:1527628282565};\\\", \\\"{x:234,y:456,t:1527628282581};\\\", \\\"{x:238,y:454,t:1527628282598};\\\", \\\"{x:238,y:453,t:1527628282615};\\\", \\\"{x:243,y:451,t:1527628282631};\\\", \\\"{x:247,y:447,t:1527628282648};\\\", \\\"{x:259,y:446,t:1527628282665};\\\", \\\"{x:271,y:444,t:1527628282680};\\\", \\\"{x:287,y:442,t:1527628282698};\\\", \\\"{x:297,y:442,t:1527628282715};\\\", \\\"{x:311,y:440,t:1527628282731};\\\", \\\"{x:325,y:438,t:1527628282748};\\\", \\\"{x:325,y:437,t:1527628282765};\\\", \\\"{x:326,y:437,t:1527628282782};\\\", \\\"{x:328,y:437,t:1527628282820};\\\", \\\"{x:330,y:436,t:1527628282844};\\\", \\\"{x:331,y:436,t:1527628282851};\\\", \\\"{x:332,y:436,t:1527628282865};\\\", \\\"{x:335,y:436,t:1527628282882};\\\", \\\"{x:338,y:436,t:1527628282899};\\\", \\\"{x:344,y:438,t:1527628282915};\\\", \\\"{x:353,y:443,t:1527628282931};\\\", \\\"{x:360,y:448,t:1527628282948};\\\", \\\"{x:368,y:451,t:1527628282965};\\\", \\\"{x:377,y:456,t:1527628282982};\\\", \\\"{x:386,y:460,t:1527628282998};\\\", \\\"{x:394,y:464,t:1527628283015};\\\", \\\"{x:398,y:466,t:1527628283032};\\\", \\\"{x:402,y:468,t:1527628283048};\\\", \\\"{x:407,y:470,t:1527628283065};\\\", \\\"{x:412,y:473,t:1527628283082};\\\", \\\"{x:417,y:474,t:1527628283099};\\\", \\\"{x:419,y:474,t:1527628283115};\\\", \\\"{x:421,y:474,t:1527628283132};\\\", \\\"{x:422,y:474,t:1527628283332};\\\", \\\"{x:425,y:474,t:1527628283349};\\\", \\\"{x:428,y:472,t:1527628283372};\\\", \\\"{x:429,y:471,t:1527628283387};\\\", \\\"{x:430,y:469,t:1527628283412};\\\", \\\"{x:431,y:469,t:1527628283427};\\\", \\\"{x:431,y:468,t:1527628283436};\\\", \\\"{x:433,y:467,t:1527628283451};\\\", \\\"{x:435,y:466,t:1527628283468};\\\", \\\"{x:436,y:465,t:1527628283484};\\\", \\\"{x:437,y:465,t:1527628283499};\\\", \\\"{x:438,y:464,t:1527628283516};\\\", \\\"{x:440,y:462,t:1527628283532};\\\", \\\"{x:442,y:462,t:1527628283611};\\\", \\\"{x:443,y:461,t:1527628283643};\\\", \\\"{x:444,y:461,t:1527628283651};\\\", \\\"{x:445,y:460,t:1527628283667};\\\", \\\"{x:446,y:459,t:1527628283682};\\\", \\\"{x:447,y:459,t:1527628283756};\\\", \\\"{x:448,y:459,t:1527628283766};\\\", \\\"{x:448,y:458,t:1527628283782};\\\", \\\"{x:450,y:457,t:1527628283799};\\\", \\\"{x:453,y:456,t:1527628283816};\\\", \\\"{x:454,y:456,t:1527628283833};\\\", \\\"{x:455,y:456,t:1527628283859};\\\", \\\"{x:456,y:456,t:1527628283884};\\\", \\\"{x:457,y:455,t:1527628283899};\\\", \\\"{x:463,y:455,t:1527628283915};\\\", \\\"{x:468,y:455,t:1527628283933};\\\", \\\"{x:475,y:454,t:1527628283949};\\\", \\\"{x:477,y:454,t:1527628283966};\\\", \\\"{x:478,y:454,t:1527628283983};\\\", \\\"{x:479,y:454,t:1527628283999};\\\", \\\"{x:480,y:454,t:1527628284043};\\\", \\\"{x:481,y:454,t:1527628284068};\\\", \\\"{x:483,y:454,t:1527628284116};\\\", \\\"{x:485,y:454,t:1527628284133};\\\", \\\"{x:492,y:454,t:1527628284150};\\\", \\\"{x:497,y:455,t:1527628284166};\\\", \\\"{x:501,y:455,t:1527628284183};\\\", \\\"{x:505,y:456,t:1527628284200};\\\", \\\"{x:507,y:456,t:1527628284216};\\\", \\\"{x:507,y:457,t:1527628284259};\\\", \\\"{x:508,y:457,t:1527628284356};\\\", \\\"{x:511,y:457,t:1527628284371};\\\", \\\"{x:515,y:457,t:1527628284383};\\\", \\\"{x:529,y:457,t:1527628284400};\\\", \\\"{x:552,y:457,t:1527628284417};\\\", \\\"{x:579,y:457,t:1527628284433};\\\", \\\"{x:608,y:457,t:1527628284450};\\\", \\\"{x:628,y:454,t:1527628284467};\\\", \\\"{x:645,y:453,t:1527628284483};\\\", \\\"{x:655,y:453,t:1527628284499};\\\", \\\"{x:662,y:453,t:1527628284517};\\\", \\\"{x:667,y:453,t:1527628284533};\\\", \\\"{x:669,y:453,t:1527628284550};\\\", \\\"{x:670,y:453,t:1527628284567};\\\", \\\"{x:673,y:451,t:1527628284852};\\\", \\\"{x:674,y:450,t:1527628284867};\\\", \\\"{x:679,y:449,t:1527628284883};\\\", \\\"{x:684,y:449,t:1527628284900};\\\", \\\"{x:693,y:449,t:1527628284917};\\\", \\\"{x:700,y:449,t:1527628284934};\\\", \\\"{x:709,y:449,t:1527628284950};\\\", \\\"{x:719,y:449,t:1527628284967};\\\", \\\"{x:728,y:449,t:1527628284984};\\\", \\\"{x:739,y:449,t:1527628285000};\\\", \\\"{x:744,y:449,t:1527628285018};\\\", \\\"{x:750,y:449,t:1527628285034};\\\", \\\"{x:754,y:449,t:1527628285050};\\\", \\\"{x:755,y:449,t:1527628285067};\\\", \\\"{x:754,y:449,t:1527628285524};\\\", \\\"{x:750,y:449,t:1527628285534};\\\", \\\"{x:747,y:451,t:1527628285551};\\\", \\\"{x:742,y:452,t:1527628285568};\\\", \\\"{x:733,y:452,t:1527628285584};\\\", \\\"{x:718,y:452,t:1527628285601};\\\", \\\"{x:697,y:452,t:1527628285618};\\\", \\\"{x:675,y:452,t:1527628285634};\\\", \\\"{x:652,y:452,t:1527628285651};\\\", \\\"{x:621,y:454,t:1527628285667};\\\", \\\"{x:599,y:456,t:1527628285684};\\\", \\\"{x:590,y:456,t:1527628285701};\\\", \\\"{x:579,y:456,t:1527628285718};\\\", \\\"{x:571,y:456,t:1527628285735};\\\", \\\"{x:568,y:455,t:1527628285751};\\\", \\\"{x:566,y:454,t:1527628285768};\\\", \\\"{x:565,y:454,t:1527628285860};\\\", \\\"{x:563,y:454,t:1527628285900};\\\", \\\"{x:562,y:454,t:1527628286188};\\\", \\\"{x:561,y:454,t:1527628286202};\\\", \\\"{x:559,y:455,t:1527628286380};\\\", \\\"{x:556,y:457,t:1527628286387};\\\", \\\"{x:550,y:459,t:1527628286402};\\\", \\\"{x:541,y:462,t:1527628286418};\\\", \\\"{x:527,y:466,t:1527628286435};\\\", \\\"{x:514,y:468,t:1527628286452};\\\", \\\"{x:504,y:471,t:1527628286469};\\\", \\\"{x:497,y:472,t:1527628286485};\\\", \\\"{x:490,y:474,t:1527628286502};\\\", \\\"{x:488,y:475,t:1527628286519};\\\", \\\"{x:486,y:475,t:1527628286535};\\\", \\\"{x:485,y:475,t:1527628286580};\\\", \\\"{x:483,y:475,t:1527628286603};\\\", \\\"{x:480,y:475,t:1527628286619};\\\", \\\"{x:478,y:475,t:1527628286635};\\\", \\\"{x:476,y:475,t:1527628286652};\\\", \\\"{x:474,y:475,t:1527628286669};\\\", \\\"{x:473,y:473,t:1527628286685};\\\", \\\"{x:471,y:471,t:1527628287044};\\\", \\\"{x:466,y:468,t:1527628287052};\\\", \\\"{x:447,y:461,t:1527628287069};\\\", \\\"{x:418,y:455,t:1527628287086};\\\", \\\"{x:375,y:447,t:1527628287103};\\\", \\\"{x:335,y:440,t:1527628287119};\\\", \\\"{x:306,y:436,t:1527628287135};\\\", \\\"{x:291,y:433,t:1527628287153};\\\", \\\"{x:287,y:431,t:1527628287169};\\\", \\\"{x:283,y:431,t:1527628287186};\\\", \\\"{x:281,y:431,t:1527628287348};\\\", \\\"{x:280,y:431,t:1527628287356};\\\", \\\"{x:279,y:433,t:1527628287369};\\\", \\\"{x:277,y:434,t:1527628287386};\\\", \\\"{x:276,y:437,t:1527628287403};\\\", \\\"{x:276,y:444,t:1527628287419};\\\", \\\"{x:283,y:448,t:1527628287436};\\\", \\\"{x:293,y:452,t:1527628287453};\\\", \\\"{x:305,y:456,t:1527628287470};\\\", \\\"{x:317,y:460,t:1527628287486};\\\", \\\"{x:332,y:463,t:1527628287503};\\\", \\\"{x:343,y:465,t:1527628287520};\\\", \\\"{x:352,y:465,t:1527628287536};\\\", \\\"{x:354,y:465,t:1527628287553};\\\", \\\"{x:355,y:465,t:1527628287570};\\\", \\\"{x:356,y:465,t:1527628287586};\\\", \\\"{x:359,y:465,t:1527628287620};\\\", \\\"{x:368,y:465,t:1527628287636};\\\", \\\"{x:393,y:465,t:1527628287653};\\\", \\\"{x:415,y:465,t:1527628287670};\\\", \\\"{x:443,y:465,t:1527628287686};\\\", \\\"{x:520,y:460,t:1527628287703};\\\", \\\"{x:638,y:450,t:1527628287720};\\\", \\\"{x:769,y:431,t:1527628287737};\\\", \\\"{x:903,y:403,t:1527628287753};\\\", \\\"{x:1010,y:374,t:1527628287771};\\\", \\\"{x:1162,y:316,t:1527628287788};\\\", \\\"{x:1218,y:297,t:1527628287804};\\\", \\\"{x:1255,y:286,t:1527628287820};\\\", \\\"{x:1280,y:280,t:1527628287837};\\\", \\\"{x:1297,y:275,t:1527628287853};\\\", \\\"{x:1308,y:274,t:1527628287871};\\\", \\\"{x:1317,y:274,t:1527628287887};\\\", \\\"{x:1325,y:274,t:1527628287903};\\\", \\\"{x:1331,y:276,t:1527628287920};\\\", \\\"{x:1343,y:282,t:1527628287938};\\\", \\\"{x:1359,y:288,t:1527628287953};\\\", \\\"{x:1374,y:298,t:1527628287971};\\\", \\\"{x:1381,y:306,t:1527628287987};\\\", \\\"{x:1390,y:315,t:1527628288003};\\\", \\\"{x:1403,y:334,t:1527628288021};\\\", \\\"{x:1409,y:346,t:1527628288037};\\\", \\\"{x:1413,y:355,t:1527628288054};\\\", \\\"{x:1416,y:367,t:1527628288070};\\\", \\\"{x:1416,y:377,t:1527628288087};\\\", \\\"{x:1416,y:383,t:1527628288104};\\\", \\\"{x:1412,y:390,t:1527628288120};\\\", \\\"{x:1408,y:394,t:1527628288137};\\\", \\\"{x:1405,y:396,t:1527628288154};\\\", \\\"{x:1400,y:401,t:1527628288170};\\\", \\\"{x:1394,y:404,t:1527628288187};\\\", \\\"{x:1362,y:408,t:1527628288203};\\\", \\\"{x:1328,y:408,t:1527628288220};\\\", \\\"{x:1297,y:410,t:1527628288237};\\\", \\\"{x:1244,y:408,t:1527628288254};\\\", \\\"{x:1211,y:408,t:1527628288270};\\\", \\\"{x:1178,y:408,t:1527628288287};\\\", \\\"{x:1159,y:408,t:1527628288304};\\\", \\\"{x:1144,y:407,t:1527628288321};\\\", \\\"{x:1131,y:407,t:1527628288338};\\\", \\\"{x:1126,y:407,t:1527628288354};\\\", \\\"{x:1125,y:407,t:1527628288371};\\\", \\\"{x:1123,y:407,t:1527628288411};\\\", \\\"{x:1122,y:407,t:1527628288427};\\\", \\\"{x:1121,y:407,t:1527628288437};\\\", \\\"{x:1119,y:411,t:1527628288454};\\\", \\\"{x:1116,y:418,t:1527628288472};\\\", \\\"{x:1116,y:428,t:1527628288487};\\\", \\\"{x:1116,y:441,t:1527628288504};\\\", \\\"{x:1115,y:450,t:1527628288521};\\\", \\\"{x:1113,y:454,t:1527628288537};\\\", \\\"{x:1113,y:455,t:1527628288588};\\\", \\\"{x:1113,y:456,t:1527628288604};\\\", \\\"{x:1114,y:463,t:1527628288621};\\\", \\\"{x:1118,y:469,t:1527628288637};\\\", \\\"{x:1122,y:475,t:1527628288655};\\\", \\\"{x:1125,y:478,t:1527628288671};\\\", \\\"{x:1127,y:480,t:1527628288687};\\\", \\\"{x:1128,y:481,t:1527628288704};\\\", \\\"{x:1131,y:481,t:1527628288721};\\\", \\\"{x:1138,y:481,t:1527628288738};\\\", \\\"{x:1156,y:482,t:1527628288754};\\\", \\\"{x:1173,y:482,t:1527628288772};\\\", \\\"{x:1205,y:474,t:1527628288787};\\\", \\\"{x:1225,y:467,t:1527628288804};\\\", \\\"{x:1243,y:462,t:1527628288821};\\\", \\\"{x:1245,y:462,t:1527628288838};\\\", \\\"{x:1247,y:461,t:1527628288854};\\\", \\\"{x:1249,y:461,t:1527628289036};\\\", \\\"{x:1250,y:465,t:1527628289051};\\\", \\\"{x:1250,y:471,t:1527628289059};\\\", \\\"{x:1251,y:473,t:1527628289071};\\\", \\\"{x:1251,y:477,t:1527628289088};\\\", \\\"{x:1251,y:479,t:1527628289105};\\\", \\\"{x:1251,y:480,t:1527628289140};\\\", \\\"{x:1251,y:481,t:1527628289244};\\\", \\\"{x:1251,y:483,t:1527628289256};\\\", \\\"{x:1251,y:486,t:1527628289271};\\\", \\\"{x:1251,y:487,t:1527628289288};\\\", \\\"{x:1251,y:489,t:1527628289305};\\\", \\\"{x:1251,y:490,t:1527628289909};\\\", \\\"{x:1251,y:492,t:1527628289925};\\\", \\\"{x:1251,y:494,t:1527628289934};\\\", \\\"{x:1251,y:495,t:1527628289949};\\\", \\\"{x:1253,y:497,t:1527628289965};\\\", \\\"{x:1255,y:498,t:1527628289982};\\\", \\\"{x:1255,y:499,t:1527628290038};\\\", \\\"{x:1256,y:499,t:1527628290070};\\\", \\\"{x:1257,y:500,t:1527628293590};\\\", \\\"{x:1261,y:510,t:1527628293602};\\\", \\\"{x:1269,y:531,t:1527628293620};\\\", \\\"{x:1276,y:549,t:1527628293636};\\\", \\\"{x:1281,y:563,t:1527628293653};\\\", \\\"{x:1283,y:570,t:1527628293669};\\\", \\\"{x:1287,y:578,t:1527628293686};\\\", \\\"{x:1293,y:589,t:1527628293703};\\\", \\\"{x:1298,y:604,t:1527628293719};\\\", \\\"{x:1300,y:614,t:1527628293737};\\\", \\\"{x:1302,y:623,t:1527628293753};\\\", \\\"{x:1306,y:633,t:1527628293769};\\\", \\\"{x:1310,y:645,t:1527628293786};\\\", \\\"{x:1312,y:654,t:1527628293803};\\\", \\\"{x:1314,y:659,t:1527628293819};\\\", \\\"{x:1315,y:663,t:1527628293836};\\\", \\\"{x:1318,y:672,t:1527628293853};\\\", \\\"{x:1319,y:674,t:1527628293869};\\\", \\\"{x:1321,y:677,t:1527628293886};\\\", \\\"{x:1322,y:681,t:1527628293903};\\\", \\\"{x:1324,y:686,t:1527628293919};\\\", \\\"{x:1328,y:694,t:1527628293936};\\\", \\\"{x:1332,y:702,t:1527628293953};\\\", \\\"{x:1335,y:706,t:1527628293970};\\\", \\\"{x:1335,y:708,t:1527628293986};\\\", \\\"{x:1336,y:711,t:1527628294003};\\\", \\\"{x:1338,y:716,t:1527628294020};\\\", \\\"{x:1339,y:723,t:1527628294036};\\\", \\\"{x:1341,y:728,t:1527628294054};\\\", \\\"{x:1342,y:729,t:1527628294078};\\\", \\\"{x:1342,y:731,t:1527628294093};\\\", \\\"{x:1343,y:732,t:1527628294110};\\\", \\\"{x:1343,y:734,t:1527628294134};\\\", \\\"{x:1344,y:736,t:1527628294150};\\\", \\\"{x:1345,y:736,t:1527628294158};\\\", \\\"{x:1345,y:737,t:1527628294174};\\\", \\\"{x:1345,y:738,t:1527628294186};\\\", \\\"{x:1346,y:739,t:1527628294205};\\\", \\\"{x:1347,y:741,t:1527628294222};\\\", \\\"{x:1348,y:741,t:1527628294237};\\\", \\\"{x:1348,y:742,t:1527628294261};\\\", \\\"{x:1349,y:744,t:1527628294294};\\\", \\\"{x:1349,y:745,t:1527628294374};\\\", \\\"{x:1349,y:746,t:1527628294429};\\\", \\\"{x:1349,y:747,t:1527628294437};\\\", \\\"{x:1349,y:748,t:1527628294469};\\\", \\\"{x:1349,y:749,t:1527628294477};\\\", \\\"{x:1349,y:751,t:1527628294487};\\\", \\\"{x:1349,y:754,t:1527628294517};\\\", \\\"{x:1349,y:755,t:1527628294566};\\\", \\\"{x:1348,y:755,t:1527628294573};\\\", \\\"{x:1347,y:757,t:1527628294637};\\\", \\\"{x:1350,y:757,t:1527628304829};\\\", \\\"{x:1354,y:758,t:1527628304838};\\\", \\\"{x:1358,y:759,t:1527628304848};\\\", \\\"{x:1364,y:759,t:1527628304865};\\\", \\\"{x:1368,y:759,t:1527628304881};\\\", \\\"{x:1372,y:759,t:1527628304897};\\\", \\\"{x:1374,y:759,t:1527628304915};\\\", \\\"{x:1376,y:759,t:1527628304931};\\\", \\\"{x:1378,y:760,t:1527628305029};\\\", \\\"{x:1379,y:762,t:1527628305053};\\\", \\\"{x:1381,y:762,t:1527628305077};\\\", \\\"{x:1382,y:764,t:1527628305486};\\\", \\\"{x:1382,y:766,t:1527628305499};\\\", \\\"{x:1381,y:773,t:1527628305515};\\\", \\\"{x:1386,y:777,t:1527628305532};\\\", \\\"{x:1395,y:786,t:1527628305549};\\\", \\\"{x:1408,y:798,t:1527628305565};\\\", \\\"{x:1417,y:810,t:1527628305582};\\\", \\\"{x:1421,y:817,t:1527628305598};\\\", \\\"{x:1424,y:821,t:1527628305615};\\\", \\\"{x:1426,y:825,t:1527628305631};\\\", \\\"{x:1430,y:829,t:1527628305649};\\\", \\\"{x:1432,y:832,t:1527628305666};\\\", \\\"{x:1433,y:835,t:1527628305682};\\\", \\\"{x:1436,y:839,t:1527628305699};\\\", \\\"{x:1440,y:844,t:1527628305715};\\\", \\\"{x:1444,y:848,t:1527628305732};\\\", \\\"{x:1446,y:850,t:1527628305749};\\\", \\\"{x:1450,y:853,t:1527628305765};\\\", \\\"{x:1452,y:853,t:1527628305813};\\\", \\\"{x:1452,y:854,t:1527628305829};\\\", \\\"{x:1454,y:854,t:1527628305853};\\\", \\\"{x:1456,y:855,t:1527628305866};\\\", \\\"{x:1457,y:855,t:1527628305882};\\\", \\\"{x:1461,y:855,t:1527628305898};\\\", \\\"{x:1461,y:856,t:1527628305915};\\\", \\\"{x:1462,y:856,t:1527628305932};\\\", \\\"{x:1464,y:856,t:1527628305949};\\\", \\\"{x:1466,y:856,t:1527628305965};\\\", \\\"{x:1468,y:856,t:1527628305989};\\\", \\\"{x:1470,y:855,t:1527628306004};\\\", \\\"{x:1470,y:854,t:1527628306015};\\\", \\\"{x:1471,y:854,t:1527628306033};\\\", \\\"{x:1472,y:853,t:1527628306048};\\\", \\\"{x:1474,y:851,t:1527628306101};\\\", \\\"{x:1475,y:849,t:1527628306125};\\\", \\\"{x:1477,y:848,t:1527628306149};\\\", \\\"{x:1477,y:847,t:1527628306166};\\\", \\\"{x:1479,y:845,t:1527628306183};\\\", \\\"{x:1479,y:844,t:1527628306221};\\\", \\\"{x:1480,y:844,t:1527628306233};\\\", \\\"{x:1481,y:842,t:1527628306261};\\\", \\\"{x:1482,y:842,t:1527628306285};\\\", \\\"{x:1483,y:841,t:1527628306298};\\\", \\\"{x:1483,y:840,t:1527628306316};\\\", \\\"{x:1484,y:839,t:1527628306332};\\\", \\\"{x:1487,y:833,t:1527628306349};\\\", \\\"{x:1487,y:832,t:1527628306365};\\\", \\\"{x:1487,y:831,t:1527628306382};\\\", \\\"{x:1489,y:830,t:1527628306613};\\\", \\\"{x:1488,y:830,t:1527628307102};\\\", \\\"{x:1487,y:830,t:1527628307125};\\\", \\\"{x:1486,y:830,t:1527628307150};\\\", \\\"{x:1485,y:830,t:1527628307221};\\\", \\\"{x:1483,y:831,t:1527628307234};\\\", \\\"{x:1482,y:831,t:1527628307250};\\\", \\\"{x:1479,y:832,t:1527628307267};\\\", \\\"{x:1479,y:833,t:1527628307283};\\\", \\\"{x:1481,y:834,t:1527628307429};\\\", \\\"{x:1490,y:835,t:1527628307438};\\\", \\\"{x:1494,y:835,t:1527628307451};\\\", \\\"{x:1508,y:837,t:1527628307467};\\\", \\\"{x:1515,y:837,t:1527628307484};\\\", \\\"{x:1518,y:837,t:1527628307501};\\\", \\\"{x:1520,y:837,t:1527628307517};\\\", \\\"{x:1521,y:837,t:1527628307534};\\\", \\\"{x:1523,y:837,t:1527628307621};\\\", \\\"{x:1524,y:837,t:1527628307653};\\\", \\\"{x:1526,y:837,t:1527628307667};\\\", \\\"{x:1533,y:837,t:1527628307684};\\\", \\\"{x:1545,y:837,t:1527628307701};\\\", \\\"{x:1549,y:837,t:1527628307717};\\\", \\\"{x:1562,y:837,t:1527628307734};\\\", \\\"{x:1565,y:837,t:1527628307751};\\\", \\\"{x:1570,y:836,t:1527628307768};\\\", \\\"{x:1573,y:834,t:1527628307784};\\\", \\\"{x:1574,y:833,t:1527628307853};\\\", \\\"{x:1575,y:833,t:1527628307867};\\\", \\\"{x:1575,y:831,t:1527628308254};\\\", \\\"{x:1575,y:830,t:1527628308268};\\\", \\\"{x:1581,y:829,t:1527628308285};\\\", \\\"{x:1583,y:829,t:1527628308301};\\\", \\\"{x:1586,y:829,t:1527628308318};\\\", \\\"{x:1588,y:829,t:1527628308335};\\\", \\\"{x:1591,y:829,t:1527628308352};\\\", \\\"{x:1595,y:829,t:1527628308367};\\\", \\\"{x:1599,y:829,t:1527628308384};\\\", \\\"{x:1600,y:829,t:1527628308405};\\\", \\\"{x:1604,y:829,t:1527628308685};\\\", \\\"{x:1607,y:829,t:1527628308702};\\\", \\\"{x:1613,y:830,t:1527628308719};\\\", \\\"{x:1619,y:831,t:1527628308735};\\\", \\\"{x:1623,y:831,t:1527628308751};\\\", \\\"{x:1625,y:832,t:1527628308769};\\\", \\\"{x:1626,y:832,t:1527628308784};\\\", \\\"{x:1627,y:832,t:1527628308878};\\\", \\\"{x:1626,y:832,t:1527628309053};\\\", \\\"{x:1622,y:834,t:1527628309069};\\\", \\\"{x:1616,y:835,t:1527628309085};\\\", \\\"{x:1614,y:836,t:1527628309101};\\\", \\\"{x:1612,y:836,t:1527628309119};\\\", \\\"{x:1611,y:837,t:1527628309238};\\\", \\\"{x:1604,y:837,t:1527628309309};\\\", \\\"{x:1592,y:835,t:1527628309319};\\\", \\\"{x:1572,y:822,t:1527628309336};\\\", \\\"{x:1538,y:814,t:1527628309352};\\\", \\\"{x:1494,y:804,t:1527628309369};\\\", \\\"{x:1447,y:792,t:1527628309386};\\\", \\\"{x:1420,y:786,t:1527628309403};\\\", \\\"{x:1405,y:784,t:1527628309419};\\\", \\\"{x:1396,y:782,t:1527628309435};\\\", \\\"{x:1390,y:777,t:1527628309452};\\\", \\\"{x:1383,y:774,t:1527628309469};\\\", \\\"{x:1377,y:770,t:1527628309486};\\\", \\\"{x:1369,y:769,t:1527628309503};\\\", \\\"{x:1365,y:767,t:1527628309519};\\\", \\\"{x:1365,y:766,t:1527628309535};\\\", \\\"{x:1363,y:766,t:1527628309553};\\\", \\\"{x:1358,y:765,t:1527628309766};\\\", \\\"{x:1350,y:765,t:1527628309773};\\\", \\\"{x:1339,y:765,t:1527628309787};\\\", \\\"{x:1306,y:760,t:1527628309803};\\\", \\\"{x:1284,y:758,t:1527628309820};\\\", \\\"{x:1272,y:756,t:1527628309836};\\\", \\\"{x:1267,y:756,t:1527628309853};\\\", \\\"{x:1266,y:755,t:1527628309870};\\\", \\\"{x:1265,y:758,t:1527628310085};\\\", \\\"{x:1263,y:763,t:1527628310093};\\\", \\\"{x:1263,y:767,t:1527628310103};\\\", \\\"{x:1261,y:780,t:1527628310120};\\\", \\\"{x:1261,y:786,t:1527628310137};\\\", \\\"{x:1258,y:794,t:1527628310153};\\\", \\\"{x:1256,y:800,t:1527628310170};\\\", \\\"{x:1253,y:806,t:1527628310187};\\\", \\\"{x:1252,y:807,t:1527628310203};\\\", \\\"{x:1249,y:812,t:1527628310220};\\\", \\\"{x:1244,y:819,t:1527628310237};\\\", \\\"{x:1239,y:824,t:1527628310253};\\\", \\\"{x:1236,y:827,t:1527628310270};\\\", \\\"{x:1236,y:828,t:1527628310287};\\\", \\\"{x:1235,y:829,t:1527628310302};\\\", \\\"{x:1235,y:827,t:1527628310501};\\\", \\\"{x:1238,y:822,t:1527628310509};\\\", \\\"{x:1238,y:821,t:1527628310520};\\\", \\\"{x:1241,y:814,t:1527628310537};\\\", \\\"{x:1242,y:812,t:1527628310554};\\\", \\\"{x:1243,y:811,t:1527628310570};\\\", \\\"{x:1243,y:810,t:1527628310589};\\\", \\\"{x:1243,y:809,t:1527628310621};\\\", \\\"{x:1245,y:808,t:1527628310636};\\\", \\\"{x:1245,y:807,t:1527628310654};\\\", \\\"{x:1248,y:804,t:1527628310671};\\\", \\\"{x:1251,y:800,t:1527628310687};\\\", \\\"{x:1255,y:796,t:1527628310704};\\\", \\\"{x:1259,y:789,t:1527628310721};\\\", \\\"{x:1265,y:783,t:1527628310737};\\\", \\\"{x:1270,y:777,t:1527628310753};\\\", \\\"{x:1277,y:769,t:1527628310770};\\\", \\\"{x:1283,y:764,t:1527628310786};\\\", \\\"{x:1288,y:760,t:1527628310803};\\\", \\\"{x:1296,y:753,t:1527628310821};\\\", \\\"{x:1299,y:750,t:1527628310837};\\\", \\\"{x:1303,y:744,t:1527628310854};\\\", \\\"{x:1308,y:737,t:1527628310870};\\\", \\\"{x:1312,y:733,t:1527628310887};\\\", \\\"{x:1313,y:730,t:1527628310903};\\\", \\\"{x:1316,y:725,t:1527628310921};\\\", \\\"{x:1317,y:725,t:1527628310936};\\\", \\\"{x:1319,y:722,t:1527628310954};\\\", \\\"{x:1322,y:718,t:1527628310971};\\\", \\\"{x:1324,y:714,t:1527628310987};\\\", \\\"{x:1326,y:710,t:1527628311004};\\\", \\\"{x:1330,y:702,t:1527628311021};\\\", \\\"{x:1334,y:697,t:1527628311037};\\\", \\\"{x:1337,y:691,t:1527628311054};\\\", \\\"{x:1338,y:689,t:1527628311071};\\\", \\\"{x:1341,y:685,t:1527628311088};\\\", \\\"{x:1343,y:683,t:1527628311103};\\\", \\\"{x:1344,y:681,t:1527628311121};\\\", \\\"{x:1344,y:680,t:1527628311138};\\\", \\\"{x:1343,y:679,t:1527628311773};\\\", \\\"{x:1336,y:675,t:1527628311788};\\\", \\\"{x:1307,y:665,t:1527628311805};\\\", \\\"{x:1300,y:661,t:1527628311821};\\\", \\\"{x:1298,y:660,t:1527628312253};\\\", \\\"{x:1295,y:658,t:1527628312261};\\\", \\\"{x:1295,y:657,t:1527628312272};\\\", \\\"{x:1293,y:651,t:1527628312289};\\\", \\\"{x:1288,y:641,t:1527628312306};\\\", \\\"{x:1286,y:637,t:1527628312321};\\\", \\\"{x:1285,y:635,t:1527628312341};\\\", \\\"{x:1285,y:633,t:1527628312356};\\\", \\\"{x:1285,y:629,t:1527628312371};\\\", \\\"{x:1285,y:622,t:1527628312388};\\\", \\\"{x:1285,y:617,t:1527628312406};\\\", \\\"{x:1285,y:612,t:1527628312422};\\\", \\\"{x:1285,y:610,t:1527628312439};\\\", \\\"{x:1285,y:608,t:1527628312455};\\\", \\\"{x:1285,y:605,t:1527628312472};\\\", \\\"{x:1285,y:602,t:1527628312488};\\\", \\\"{x:1285,y:595,t:1527628312506};\\\", \\\"{x:1282,y:589,t:1527628312522};\\\", \\\"{x:1282,y:586,t:1527628312539};\\\", \\\"{x:1281,y:583,t:1527628312556};\\\", \\\"{x:1281,y:579,t:1527628312572};\\\", \\\"{x:1281,y:576,t:1527628312589};\\\", \\\"{x:1281,y:575,t:1527628312606};\\\", \\\"{x:1281,y:573,t:1527628312629};\\\", \\\"{x:1281,y:572,t:1527628312639};\\\", \\\"{x:1281,y:570,t:1527628312656};\\\", \\\"{x:1281,y:569,t:1527628312673};\\\", \\\"{x:1278,y:569,t:1527628315029};\\\", \\\"{x:1271,y:569,t:1527628315042};\\\", \\\"{x:1206,y:561,t:1527628315058};\\\", \\\"{x:1108,y:545,t:1527628315075};\\\", \\\"{x:989,y:531,t:1527628315091};\\\", \\\"{x:878,y:515,t:1527628315108};\\\", \\\"{x:741,y:498,t:1527628315124};\\\", \\\"{x:679,y:496,t:1527628315142};\\\", \\\"{x:657,y:496,t:1527628315151};\\\", \\\"{x:633,y:496,t:1527628315168};\\\", \\\"{x:613,y:496,t:1527628315184};\\\", \\\"{x:604,y:496,t:1527628315201};\\\", \\\"{x:602,y:496,t:1527628315218};\\\", \\\"{x:601,y:496,t:1527628315300};\\\", \\\"{x:596,y:499,t:1527628315318};\\\", \\\"{x:593,y:500,t:1527628315334};\\\", \\\"{x:592,y:500,t:1527628315351};\\\", \\\"{x:593,y:502,t:1527628315677};\\\", \\\"{x:594,y:502,t:1527628315701};\\\", \\\"{x:596,y:503,t:1527628315717};\\\", \\\"{x:598,y:504,t:1527628315734};\\\", \\\"{x:599,y:505,t:1527628315751};\\\", \\\"{x:600,y:508,t:1527628315768};\\\", \\\"{x:600,y:509,t:1527628315784};\\\", \\\"{x:601,y:511,t:1527628315801};\\\", \\\"{x:603,y:515,t:1527628315818};\\\", \\\"{x:603,y:517,t:1527628315835};\\\", \\\"{x:604,y:521,t:1527628315851};\\\", \\\"{x:604,y:526,t:1527628315868};\\\", \\\"{x:605,y:536,t:1527628315886};\\\", \\\"{x:605,y:541,t:1527628315901};\\\", \\\"{x:605,y:554,t:1527628315918};\\\", \\\"{x:602,y:569,t:1527628315936};\\\", \\\"{x:600,y:585,t:1527628315951};\\\", \\\"{x:597,y:591,t:1527628315968};\\\", \\\"{x:596,y:593,t:1527628315985};\\\", \\\"{x:596,y:594,t:1527628316001};\\\", \\\"{x:596,y:592,t:1527628316070};\\\", \\\"{x:596,y:582,t:1527628316084};\\\", \\\"{x:600,y:565,t:1527628316102};\\\", \\\"{x:607,y:544,t:1527628316118};\\\", \\\"{x:614,y:529,t:1527628316135};\\\", \\\"{x:619,y:517,t:1527628316152};\\\", \\\"{x:622,y:510,t:1527628316168};\\\", \\\"{x:624,y:506,t:1527628316185};\\\", \\\"{x:624,y:503,t:1527628316202};\\\", \\\"{x:624,y:502,t:1527628316218};\\\", \\\"{x:622,y:503,t:1527628316525};\\\", \\\"{x:619,y:511,t:1527628316536};\\\", \\\"{x:607,y:536,t:1527628316552};\\\", \\\"{x:596,y:561,t:1527628316570};\\\", \\\"{x:586,y:580,t:1527628316585};\\\", \\\"{x:577,y:603,t:1527628316602};\\\", \\\"{x:568,y:620,t:1527628316620};\\\", \\\"{x:564,y:635,t:1527628316635};\\\", \\\"{x:559,y:650,t:1527628316652};\\\", \\\"{x:556,y:661,t:1527628316668};\\\", \\\"{x:554,y:669,t:1527628316685};\\\", \\\"{x:553,y:675,t:1527628316702};\\\", \\\"{x:551,y:680,t:1527628316719};\\\", \\\"{x:550,y:682,t:1527628316735};\\\", \\\"{x:549,y:684,t:1527628316752};\\\", \\\"{x:548,y:687,t:1527628316769};\\\", \\\"{x:548,y:689,t:1527628316785};\\\", \\\"{x:547,y:693,t:1527628316802};\\\", \\\"{x:546,y:702,t:1527628316819};\\\", \\\"{x:544,y:713,t:1527628316836};\\\", \\\"{x:543,y:718,t:1527628316851};\\\", \\\"{x:543,y:721,t:1527628316868};\\\", \\\"{x:543,y:722,t:1527628316886};\\\", \\\"{x:543,y:725,t:1527628316902};\\\", \\\"{x:542,y:727,t:1527628316919};\\\", \\\"{x:542,y:728,t:1527628316936};\\\", \\\"{x:541,y:730,t:1527628316952};\\\", \\\"{x:540,y:733,t:1527628316973};\\\", \\\"{x:539,y:735,t:1527628316986};\\\", \\\"{x:538,y:739,t:1527628317002};\\\", \\\"{x:538,y:742,t:1527628317019};\\\", \\\"{x:538,y:743,t:1527628317036};\\\", \\\"{x:538,y:745,t:1527628317053};\\\", \\\"{x:537,y:746,t:1527628317533};\\\", \\\"{x:533,y:742,t:1527628317549};\\\", \\\"{x:531,y:738,t:1527628317557};\\\", \\\"{x:529,y:734,t:1527628317569};\\\", \\\"{x:521,y:727,t:1527628317586};\\\", \\\"{x:515,y:722,t:1527628317603};\\\", \\\"{x:507,y:716,t:1527628317619};\\\", \\\"{x:503,y:712,t:1527628317635};\\\", \\\"{x:499,y:708,t:1527628317652};\\\", \\\"{x:496,y:702,t:1527628317670};\\\", \\\"{x:495,y:696,t:1527628317686};\\\", \\\"{x:489,y:685,t:1527628317702};\\\", \\\"{x:483,y:675,t:1527628317720};\\\", \\\"{x:474,y:659,t:1527628317736};\\\", \\\"{x:466,y:642,t:1527628317753};\\\", \\\"{x:458,y:628,t:1527628317770};\\\", \\\"{x:453,y:613,t:1527628317786};\\\", \\\"{x:449,y:589,t:1527628317803};\\\", \\\"{x:442,y:568,t:1527628317820};\\\", \\\"{x:439,y:548,t:1527628317836};\\\", \\\"{x:433,y:496,t:1527628317852};\\\", \\\"{x:433,y:439,t:1527628317870};\\\", \\\"{x:433,y:409,t:1527628317885};\\\", \\\"{x:432,y:387,t:1527628317903};\\\", \\\"{x:433,y:370,t:1527628317920};\\\", \\\"{x:440,y:352,t:1527628317936};\\\", \\\"{x:446,y:340,t:1527628317953};\\\", \\\"{x:458,y:323,t:1527628317970};\\\", \\\"{x:470,y:312,t:1527628317985};\\\", \\\"{x:488,y:296,t:1527628318003};\\\", \\\"{x:508,y:285,t:1527628318020};\\\", \\\"{x:539,y:268,t:1527628318036};\\\", \\\"{x:563,y:257,t:1527628318053};\\\", \\\"{x:586,y:247,t:1527628318070};\\\", \\\"{x:604,y:242,t:1527628318086};\\\", \\\"{x:614,y:239,t:1527628318103};\\\", \\\"{x:626,y:236,t:1527628318120};\\\", \\\"{x:631,y:233,t:1527628318137};\\\", \\\"{x:638,y:233,t:1527628318153};\\\", \\\"{x:645,y:233,t:1527628318176};\\\", \\\"{x:647,y:233,t:1527628318187};\\\", \\\"{x:648,y:233,t:1527628318203};\\\" ] }, { \\\"rt\\\": 16576, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 584745, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:647,y:236,t:1527628318677};\\\", \\\"{x:643,y:241,t:1527628318687};\\\", \\\"{x:640,y:252,t:1527628318704};\\\", \\\"{x:637,y:266,t:1527628318719};\\\", \\\"{x:637,y:274,t:1527628318737};\\\", \\\"{x:635,y:280,t:1527628318754};\\\", \\\"{x:634,y:283,t:1527628318770};\\\", \\\"{x:634,y:289,t:1527628318787};\\\", \\\"{x:634,y:296,t:1527628318803};\\\", \\\"{x:634,y:303,t:1527628318820};\\\", \\\"{x:634,y:308,t:1527628318836};\\\", \\\"{x:630,y:318,t:1527628318912};\\\", \\\"{x:628,y:321,t:1527628318922};\\\", \\\"{x:624,y:325,t:1527628318937};\\\", \\\"{x:619,y:329,t:1527628318954};\\\", \\\"{x:614,y:335,t:1527628318971};\\\", \\\"{x:609,y:341,t:1527628318987};\\\", \\\"{x:603,y:348,t:1527628319004};\\\", \\\"{x:591,y:359,t:1527628319021};\\\", \\\"{x:582,y:364,t:1527628319037};\\\", \\\"{x:571,y:372,t:1527628319054};\\\", \\\"{x:558,y:380,t:1527628319071};\\\", \\\"{x:540,y:390,t:1527628319088};\\\", \\\"{x:527,y:399,t:1527628319104};\\\", \\\"{x:514,y:406,t:1527628319121};\\\", \\\"{x:505,y:411,t:1527628319137};\\\", \\\"{x:501,y:414,t:1527628319154};\\\", \\\"{x:496,y:418,t:1527628319171};\\\", \\\"{x:489,y:423,t:1527628319187};\\\", \\\"{x:488,y:424,t:1527628319204};\\\", \\\"{x:484,y:427,t:1527628319221};\\\", \\\"{x:484,y:429,t:1527628319237};\\\", \\\"{x:484,y:441,t:1527628319254};\\\", \\\"{x:488,y:453,t:1527628319271};\\\", \\\"{x:496,y:466,t:1527628319286};\\\", \\\"{x:503,y:473,t:1527628319304};\\\", \\\"{x:509,y:477,t:1527628319321};\\\", \\\"{x:514,y:479,t:1527628319338};\\\", \\\"{x:523,y:481,t:1527628319354};\\\", \\\"{x:531,y:481,t:1527628319371};\\\", \\\"{x:538,y:482,t:1527628319387};\\\", \\\"{x:542,y:484,t:1527628319404};\\\", \\\"{x:546,y:484,t:1527628319421};\\\", \\\"{x:547,y:484,t:1527628319501};\\\", \\\"{x:546,y:480,t:1527628319557};\\\", \\\"{x:539,y:477,t:1527628319571};\\\", \\\"{x:520,y:471,t:1527628319589};\\\", \\\"{x:493,y:464,t:1527628319604};\\\", \\\"{x:457,y:456,t:1527628319621};\\\", \\\"{x:446,y:454,t:1527628319639};\\\", \\\"{x:442,y:452,t:1527628319654};\\\", \\\"{x:441,y:452,t:1527628319709};\\\", \\\"{x:440,y:452,t:1527628319721};\\\", \\\"{x:434,y:452,t:1527628319738};\\\", \\\"{x:419,y:451,t:1527628319755};\\\", \\\"{x:404,y:448,t:1527628319771};\\\", \\\"{x:394,y:447,t:1527628319788};\\\", \\\"{x:384,y:445,t:1527628319805};\\\", \\\"{x:383,y:444,t:1527628319821};\\\", \\\"{x:381,y:444,t:1527628319838};\\\", \\\"{x:375,y:444,t:1527628319855};\\\", \\\"{x:361,y:443,t:1527628319871};\\\", \\\"{x:345,y:442,t:1527628319888};\\\", \\\"{x:331,y:439,t:1527628319905};\\\", \\\"{x:321,y:438,t:1527628319921};\\\", \\\"{x:318,y:437,t:1527628319938};\\\", \\\"{x:314,y:437,t:1527628319955};\\\", \\\"{x:313,y:437,t:1527628319971};\\\", \\\"{x:308,y:439,t:1527628319988};\\\", \\\"{x:301,y:440,t:1527628320004};\\\", \\\"{x:300,y:441,t:1527628320021};\\\", \\\"{x:299,y:442,t:1527628320038};\\\", \\\"{x:297,y:443,t:1527628320055};\\\", \\\"{x:297,y:444,t:1527628320071};\\\", \\\"{x:297,y:446,t:1527628320088};\\\", \\\"{x:299,y:450,t:1527628320105};\\\", \\\"{x:305,y:454,t:1527628320121};\\\", \\\"{x:311,y:457,t:1527628320138};\\\", \\\"{x:314,y:460,t:1527628320155};\\\", \\\"{x:320,y:463,t:1527628320171};\\\", \\\"{x:324,y:465,t:1527628320189};\\\", \\\"{x:325,y:465,t:1527628320204};\\\", \\\"{x:325,y:466,t:1527628320236};\\\", \\\"{x:326,y:466,t:1527628320244};\\\", \\\"{x:327,y:466,t:1527628320261};\\\", \\\"{x:328,y:467,t:1527628320273};\\\", \\\"{x:332,y:468,t:1527628320288};\\\", \\\"{x:336,y:469,t:1527628320305};\\\", \\\"{x:347,y:470,t:1527628320322};\\\", \\\"{x:353,y:471,t:1527628320338};\\\", \\\"{x:357,y:471,t:1527628320355};\\\", \\\"{x:358,y:471,t:1527628320372};\\\", \\\"{x:360,y:471,t:1527628320388};\\\", \\\"{x:367,y:471,t:1527628320404};\\\", \\\"{x:372,y:469,t:1527628320422};\\\", \\\"{x:377,y:468,t:1527628320438};\\\", \\\"{x:379,y:468,t:1527628320455};\\\", \\\"{x:384,y:466,t:1527628320472};\\\", \\\"{x:386,y:465,t:1527628320488};\\\", \\\"{x:389,y:464,t:1527628320505};\\\", \\\"{x:393,y:464,t:1527628320523};\\\", \\\"{x:397,y:462,t:1527628320538};\\\", \\\"{x:399,y:461,t:1527628320555};\\\", \\\"{x:401,y:459,t:1527628320572};\\\", \\\"{x:403,y:459,t:1527628320588};\\\", \\\"{x:405,y:458,t:1527628320605};\\\", \\\"{x:406,y:457,t:1527628320622};\\\", \\\"{x:407,y:457,t:1527628320645};\\\", \\\"{x:409,y:457,t:1527628320741};\\\", \\\"{x:412,y:457,t:1527628320755};\\\", \\\"{x:417,y:457,t:1527628320773};\\\", \\\"{x:426,y:457,t:1527628320789};\\\", \\\"{x:431,y:457,t:1527628320805};\\\", \\\"{x:433,y:457,t:1527628320822};\\\", \\\"{x:434,y:457,t:1527628320885};\\\", \\\"{x:435,y:457,t:1527628320909};\\\", \\\"{x:438,y:457,t:1527628320922};\\\", \\\"{x:447,y:457,t:1527628320939};\\\", \\\"{x:458,y:459,t:1527628320955};\\\", \\\"{x:469,y:459,t:1527628320972};\\\", \\\"{x:473,y:459,t:1527628320989};\\\", \\\"{x:474,y:459,t:1527628321052};\\\", \\\"{x:475,y:459,t:1527628321060};\\\", \\\"{x:476,y:459,t:1527628321077};\\\", \\\"{x:478,y:459,t:1527628321133};\\\", \\\"{x:479,y:459,t:1527628321156};\\\", \\\"{x:480,y:459,t:1527628321172};\\\", \\\"{x:482,y:459,t:1527628321189};\\\", \\\"{x:483,y:459,t:1527628321213};\\\", \\\"{x:486,y:459,t:1527628321229};\\\", \\\"{x:487,y:459,t:1527628321239};\\\", \\\"{x:493,y:457,t:1527628321256};\\\", \\\"{x:501,y:455,t:1527628321272};\\\", \\\"{x:510,y:454,t:1527628321289};\\\", \\\"{x:515,y:453,t:1527628321306};\\\", \\\"{x:518,y:453,t:1527628321322};\\\", \\\"{x:519,y:453,t:1527628321339};\\\", \\\"{x:520,y:453,t:1527628321356};\\\", \\\"{x:522,y:451,t:1527628321381};\\\", \\\"{x:526,y:452,t:1527628321941};\\\", \\\"{x:529,y:454,t:1527628321956};\\\", \\\"{x:543,y:460,t:1527628321973};\\\", \\\"{x:554,y:461,t:1527628321990};\\\", \\\"{x:563,y:462,t:1527628322006};\\\", \\\"{x:568,y:464,t:1527628322023};\\\", \\\"{x:573,y:465,t:1527628322040};\\\", \\\"{x:574,y:465,t:1527628322056};\\\", \\\"{x:576,y:466,t:1527628322073};\\\", \\\"{x:578,y:466,t:1527628322090};\\\", \\\"{x:579,y:466,t:1527628322106};\\\", \\\"{x:581,y:466,t:1527628322123};\\\", \\\"{x:583,y:467,t:1527628322140};\\\", \\\"{x:585,y:467,t:1527628322180};\\\", \\\"{x:586,y:467,t:1527628322196};\\\", \\\"{x:589,y:467,t:1527628322206};\\\", \\\"{x:590,y:467,t:1527628322229};\\\", \\\"{x:592,y:467,t:1527628322541};\\\", \\\"{x:592,y:466,t:1527628322572};\\\", \\\"{x:592,y:464,t:1527628322580};\\\", \\\"{x:591,y:464,t:1527628322590};\\\", \\\"{x:588,y:461,t:1527628322607};\\\", \\\"{x:584,y:460,t:1527628322623};\\\", \\\"{x:578,y:457,t:1527628322640};\\\", \\\"{x:576,y:457,t:1527628322657};\\\", \\\"{x:573,y:456,t:1527628322673};\\\", \\\"{x:569,y:454,t:1527628322690};\\\", \\\"{x:566,y:454,t:1527628322707};\\\", \\\"{x:562,y:453,t:1527628322723};\\\", \\\"{x:556,y:452,t:1527628322740};\\\", \\\"{x:550,y:451,t:1527628322756};\\\", \\\"{x:547,y:451,t:1527628322773};\\\", \\\"{x:546,y:451,t:1527628322790};\\\", \\\"{x:544,y:451,t:1527628323101};\\\", \\\"{x:543,y:451,t:1527628323132};\\\", \\\"{x:541,y:451,t:1527628323141};\\\", \\\"{x:536,y:451,t:1527628323157};\\\", \\\"{x:530,y:452,t:1527628323174};\\\", \\\"{x:514,y:454,t:1527628323190};\\\", \\\"{x:498,y:454,t:1527628323207};\\\", \\\"{x:476,y:454,t:1527628323225};\\\", \\\"{x:456,y:454,t:1527628323241};\\\", \\\"{x:436,y:455,t:1527628323257};\\\", \\\"{x:421,y:455,t:1527628323274};\\\", \\\"{x:416,y:456,t:1527628323291};\\\", \\\"{x:417,y:457,t:1527628323461};\\\", \\\"{x:418,y:457,t:1527628323474};\\\", \\\"{x:427,y:457,t:1527628323491};\\\", \\\"{x:436,y:458,t:1527628323508};\\\", \\\"{x:451,y:460,t:1527628323525};\\\", \\\"{x:473,y:460,t:1527628323541};\\\", \\\"{x:491,y:460,t:1527628323557};\\\", \\\"{x:513,y:460,t:1527628323574};\\\", \\\"{x:530,y:460,t:1527628323591};\\\", \\\"{x:550,y:465,t:1527628323607};\\\", \\\"{x:568,y:465,t:1527628323624};\\\", \\\"{x:583,y:465,t:1527628323641};\\\", \\\"{x:589,y:465,t:1527628323657};\\\", \\\"{x:599,y:465,t:1527628323674};\\\", \\\"{x:605,y:464,t:1527628323691};\\\", \\\"{x:610,y:463,t:1527628323708};\\\", \\\"{x:613,y:463,t:1527628323724};\\\", \\\"{x:621,y:461,t:1527628323741};\\\", \\\"{x:629,y:461,t:1527628323757};\\\", \\\"{x:641,y:461,t:1527628323774};\\\", \\\"{x:658,y:461,t:1527628323791};\\\", \\\"{x:679,y:461,t:1527628323808};\\\", \\\"{x:703,y:461,t:1527628323824};\\\", \\\"{x:729,y:461,t:1527628323841};\\\", \\\"{x:749,y:461,t:1527628323858};\\\", \\\"{x:765,y:461,t:1527628323874};\\\", \\\"{x:774,y:460,t:1527628323891};\\\", \\\"{x:776,y:460,t:1527628323908};\\\", \\\"{x:777,y:460,t:1527628323932};\\\", \\\"{x:781,y:462,t:1527628324276};\\\", \\\"{x:787,y:465,t:1527628324292};\\\", \\\"{x:798,y:467,t:1527628324309};\\\", \\\"{x:800,y:467,t:1527628324325};\\\", \\\"{x:803,y:469,t:1527628324717};\\\", \\\"{x:805,y:469,t:1527628324725};\\\", \\\"{x:809,y:469,t:1527628324743};\\\", \\\"{x:812,y:469,t:1527628324759};\\\", \\\"{x:814,y:470,t:1527628324775};\\\", \\\"{x:817,y:471,t:1527628324792};\\\", \\\"{x:826,y:475,t:1527628324808};\\\", \\\"{x:842,y:480,t:1527628324825};\\\", \\\"{x:863,y:488,t:1527628324842};\\\", \\\"{x:882,y:492,t:1527628324858};\\\", \\\"{x:901,y:497,t:1527628324872};\\\", \\\"{x:916,y:501,t:1527628324889};\\\", \\\"{x:927,y:505,t:1527628324906};\\\", \\\"{x:940,y:508,t:1527628324923};\\\", \\\"{x:952,y:512,t:1527628324940};\\\", \\\"{x:964,y:516,t:1527628324957};\\\", \\\"{x:974,y:521,t:1527628324976};\\\", \\\"{x:984,y:523,t:1527628324992};\\\", \\\"{x:987,y:523,t:1527628325009};\\\", \\\"{x:989,y:524,t:1527628325025};\\\", \\\"{x:994,y:527,t:1527628325042};\\\", \\\"{x:1000,y:530,t:1527628325059};\\\", \\\"{x:1010,y:537,t:1527628325075};\\\", \\\"{x:1024,y:543,t:1527628325093};\\\", \\\"{x:1042,y:549,t:1527628325109};\\\", \\\"{x:1049,y:552,t:1527628325125};\\\", \\\"{x:1053,y:553,t:1527628325142};\\\", \\\"{x:1060,y:556,t:1527628325160};\\\", \\\"{x:1064,y:559,t:1527628325176};\\\", \\\"{x:1068,y:563,t:1527628325193};\\\", \\\"{x:1075,y:567,t:1527628325209};\\\", \\\"{x:1081,y:572,t:1527628325225};\\\", \\\"{x:1087,y:576,t:1527628325242};\\\", \\\"{x:1092,y:580,t:1527628325259};\\\", \\\"{x:1099,y:584,t:1527628325276};\\\", \\\"{x:1104,y:588,t:1527628325292};\\\", \\\"{x:1115,y:595,t:1527628325309};\\\", \\\"{x:1121,y:600,t:1527628325325};\\\", \\\"{x:1131,y:604,t:1527628325342};\\\", \\\"{x:1136,y:608,t:1527628325359};\\\", \\\"{x:1138,y:610,t:1527628325376};\\\", \\\"{x:1141,y:611,t:1527628325393};\\\", \\\"{x:1143,y:613,t:1527628325452};\\\", \\\"{x:1144,y:614,t:1527628325469};\\\", \\\"{x:1147,y:615,t:1527628325477};\\\", \\\"{x:1147,y:616,t:1527628325501};\\\", \\\"{x:1147,y:617,t:1527628325893};\\\", \\\"{x:1150,y:620,t:1527628325909};\\\", \\\"{x:1157,y:624,t:1527628325926};\\\", \\\"{x:1170,y:631,t:1527628325943};\\\", \\\"{x:1176,y:633,t:1527628325959};\\\", \\\"{x:1183,y:635,t:1527628325977};\\\", \\\"{x:1195,y:639,t:1527628325993};\\\", \\\"{x:1207,y:646,t:1527628326010};\\\", \\\"{x:1227,y:655,t:1527628326026};\\\", \\\"{x:1246,y:660,t:1527628326043};\\\", \\\"{x:1259,y:665,t:1527628326059};\\\", \\\"{x:1280,y:675,t:1527628326076};\\\", \\\"{x:1293,y:681,t:1527628326094};\\\", \\\"{x:1301,y:682,t:1527628326109};\\\", \\\"{x:1308,y:686,t:1527628326126};\\\", \\\"{x:1310,y:688,t:1527628326144};\\\", \\\"{x:1314,y:693,t:1527628326159};\\\", \\\"{x:1319,y:694,t:1527628326177};\\\", \\\"{x:1321,y:696,t:1527628326193};\\\", \\\"{x:1322,y:697,t:1527628326210};\\\", \\\"{x:1324,y:698,t:1527628326227};\\\", \\\"{x:1325,y:700,t:1527628326317};\\\", \\\"{x:1326,y:701,t:1527628326326};\\\", \\\"{x:1327,y:703,t:1527628326343};\\\", \\\"{x:1327,y:707,t:1527628326361};\\\", \\\"{x:1328,y:711,t:1527628326377};\\\", \\\"{x:1328,y:714,t:1527628326393};\\\", \\\"{x:1328,y:718,t:1527628326410};\\\", \\\"{x:1330,y:724,t:1527628326427};\\\", \\\"{x:1331,y:729,t:1527628326443};\\\", \\\"{x:1331,y:732,t:1527628326460};\\\", \\\"{x:1331,y:734,t:1527628326485};\\\", \\\"{x:1331,y:735,t:1527628326493};\\\", \\\"{x:1330,y:739,t:1527628326510};\\\", \\\"{x:1329,y:744,t:1527628326527};\\\", \\\"{x:1326,y:747,t:1527628326544};\\\", \\\"{x:1325,y:748,t:1527628326560};\\\", \\\"{x:1325,y:749,t:1527628326577};\\\", \\\"{x:1325,y:750,t:1527628326605};\\\", \\\"{x:1321,y:751,t:1527628326621};\\\", \\\"{x:1320,y:751,t:1527628326645};\\\", \\\"{x:1318,y:756,t:1527628326661};\\\", \\\"{x:1314,y:761,t:1527628326677};\\\", \\\"{x:1310,y:766,t:1527628326694};\\\", \\\"{x:1306,y:766,t:1527628326710};\\\", \\\"{x:1303,y:766,t:1527628326728};\\\", \\\"{x:1302,y:767,t:1527628326743};\\\", \\\"{x:1299,y:768,t:1527628326760};\\\", \\\"{x:1298,y:768,t:1527628326778};\\\", \\\"{x:1294,y:769,t:1527628326794};\\\", \\\"{x:1293,y:769,t:1527628326810};\\\", \\\"{x:1287,y:769,t:1527628326827};\\\", \\\"{x:1283,y:769,t:1527628326843};\\\", \\\"{x:1280,y:769,t:1527628326860};\\\", \\\"{x:1280,y:770,t:1527628326957};\\\", \\\"{x:1280,y:771,t:1527628326997};\\\", \\\"{x:1280,y:772,t:1527628327044};\\\", \\\"{x:1280,y:773,t:1527628327076};\\\", \\\"{x:1279,y:773,t:1527628327652};\\\", \\\"{x:1279,y:774,t:1527628327661};\\\", \\\"{x:1278,y:776,t:1527628327678};\\\", \\\"{x:1275,y:778,t:1527628327694};\\\", \\\"{x:1271,y:779,t:1527628327712};\\\", \\\"{x:1268,y:781,t:1527628327728};\\\", \\\"{x:1263,y:783,t:1527628327745};\\\", \\\"{x:1258,y:786,t:1527628327761};\\\", \\\"{x:1251,y:788,t:1527628327777};\\\", \\\"{x:1238,y:790,t:1527628327794};\\\", \\\"{x:1229,y:791,t:1527628327812};\\\", \\\"{x:1215,y:791,t:1527628327828};\\\", \\\"{x:1197,y:791,t:1527628327844};\\\", \\\"{x:1184,y:792,t:1527628327862};\\\", \\\"{x:1178,y:792,t:1527628327877};\\\", \\\"{x:1176,y:794,t:1527628327894};\\\", \\\"{x:1174,y:794,t:1527628327911};\\\", \\\"{x:1173,y:795,t:1527628327927};\\\", \\\"{x:1169,y:796,t:1527628327944};\\\", \\\"{x:1166,y:798,t:1527628327961};\\\", \\\"{x:1162,y:798,t:1527628327978};\\\", \\\"{x:1158,y:799,t:1527628327995};\\\", \\\"{x:1152,y:800,t:1527628328011};\\\", \\\"{x:1150,y:800,t:1527628328028};\\\", \\\"{x:1149,y:800,t:1527628328052};\\\", \\\"{x:1148,y:801,t:1527628328062};\\\", \\\"{x:1146,y:801,t:1527628328078};\\\", \\\"{x:1145,y:802,t:1527628328094};\\\", \\\"{x:1141,y:802,t:1527628328111};\\\", \\\"{x:1138,y:802,t:1527628328128};\\\", \\\"{x:1129,y:803,t:1527628328144};\\\", \\\"{x:1122,y:803,t:1527628328161};\\\", \\\"{x:1112,y:803,t:1527628328179};\\\", \\\"{x:1107,y:803,t:1527628328195};\\\", \\\"{x:1105,y:803,t:1527628328211};\\\", \\\"{x:1103,y:803,t:1527628328253};\\\", \\\"{x:1102,y:803,t:1527628328309};\\\", \\\"{x:1100,y:803,t:1527628328341};\\\", \\\"{x:1099,y:803,t:1527628328380};\\\", \\\"{x:1098,y:803,t:1527628328405};\\\", \\\"{x:1097,y:804,t:1527628328412};\\\", \\\"{x:1096,y:804,t:1527628328428};\\\", \\\"{x:1096,y:805,t:1527628328469};\\\", \\\"{x:1095,y:805,t:1527628328492};\\\", \\\"{x:1094,y:805,t:1527628328532};\\\", \\\"{x:1093,y:805,t:1527628328548};\\\", \\\"{x:1091,y:805,t:1527628328565};\\\", \\\"{x:1089,y:806,t:1527628328579};\\\", \\\"{x:1088,y:806,t:1527628328595};\\\", \\\"{x:1084,y:806,t:1527628328612};\\\", \\\"{x:1082,y:806,t:1527628328629};\\\", \\\"{x:1081,y:806,t:1527628328645};\\\", \\\"{x:1080,y:808,t:1527628328662};\\\", \\\"{x:1078,y:808,t:1527628328678};\\\", \\\"{x:1073,y:808,t:1527628328695};\\\", \\\"{x:1069,y:809,t:1527628328712};\\\", \\\"{x:1062,y:809,t:1527628328729};\\\", \\\"{x:1054,y:809,t:1527628328746};\\\", \\\"{x:1049,y:809,t:1527628328761};\\\", \\\"{x:1043,y:809,t:1527628328778};\\\", \\\"{x:1039,y:809,t:1527628328796};\\\", \\\"{x:1035,y:809,t:1527628328812};\\\", \\\"{x:1032,y:809,t:1527628328853};\\\", \\\"{x:1031,y:809,t:1527628328868};\\\", \\\"{x:1029,y:809,t:1527628328878};\\\", \\\"{x:1026,y:809,t:1527628328895};\\\", \\\"{x:1021,y:809,t:1527628328913};\\\", \\\"{x:1012,y:808,t:1527628328929};\\\", \\\"{x:1002,y:806,t:1527628328946};\\\", \\\"{x:993,y:804,t:1527628328962};\\\", \\\"{x:985,y:803,t:1527628328978};\\\", \\\"{x:976,y:803,t:1527628328995};\\\", \\\"{x:971,y:802,t:1527628329012};\\\", \\\"{x:970,y:802,t:1527628329052};\\\", \\\"{x:969,y:802,t:1527628329077};\\\", \\\"{x:967,y:802,t:1527628329093};\\\", \\\"{x:966,y:802,t:1527628329100};\\\", \\\"{x:964,y:800,t:1527628329112};\\\", \\\"{x:957,y:799,t:1527628329128};\\\", \\\"{x:950,y:798,t:1527628329145};\\\", \\\"{x:942,y:795,t:1527628329162};\\\", \\\"{x:931,y:793,t:1527628329178};\\\", \\\"{x:922,y:791,t:1527628329196};\\\", \\\"{x:911,y:789,t:1527628329212};\\\", \\\"{x:903,y:787,t:1527628329228};\\\", \\\"{x:894,y:786,t:1527628329246};\\\", \\\"{x:890,y:786,t:1527628329262};\\\", \\\"{x:884,y:785,t:1527628329279};\\\", \\\"{x:880,y:785,t:1527628329295};\\\", \\\"{x:876,y:783,t:1527628329312};\\\", \\\"{x:873,y:783,t:1527628329329};\\\", \\\"{x:870,y:783,t:1527628329345};\\\", \\\"{x:866,y:783,t:1527628329363};\\\", \\\"{x:860,y:781,t:1527628329380};\\\", \\\"{x:858,y:781,t:1527628329395};\\\", \\\"{x:853,y:780,t:1527628329413};\\\", \\\"{x:852,y:780,t:1527628329429};\\\", \\\"{x:851,y:779,t:1527628329445};\\\", \\\"{x:850,y:779,t:1527628329462};\\\", \\\"{x:849,y:778,t:1527628329479};\\\", \\\"{x:848,y:778,t:1527628329496};\\\", \\\"{x:846,y:776,t:1527628329512};\\\", \\\"{x:843,y:776,t:1527628329530};\\\", \\\"{x:839,y:776,t:1527628329545};\\\", \\\"{x:836,y:776,t:1527628329562};\\\", \\\"{x:832,y:775,t:1527628329580};\\\", \\\"{x:829,y:774,t:1527628329596};\\\", \\\"{x:818,y:773,t:1527628329613};\\\", \\\"{x:811,y:772,t:1527628329630};\\\", \\\"{x:802,y:771,t:1527628329645};\\\", \\\"{x:797,y:768,t:1527628329662};\\\", \\\"{x:790,y:767,t:1527628329679};\\\", \\\"{x:787,y:766,t:1527628329697};\\\", \\\"{x:785,y:765,t:1527628329712};\\\", \\\"{x:784,y:765,t:1527628329729};\\\", \\\"{x:783,y:765,t:1527628329746};\\\", \\\"{x:782,y:764,t:1527628329764};\\\", \\\"{x:781,y:764,t:1527628329781};\\\", \\\"{x:780,y:764,t:1527628329805};\\\", \\\"{x:779,y:764,t:1527628329821};\\\", \\\"{x:778,y:764,t:1527628329836};\\\", \\\"{x:777,y:763,t:1527628329852};\\\", \\\"{x:776,y:762,t:1527628329862};\\\", \\\"{x:775,y:762,t:1527628329949};\\\", \\\"{x:774,y:762,t:1527628329973};\\\", \\\"{x:774,y:761,t:1527628330044};\\\", \\\"{x:770,y:760,t:1527628331037};\\\", \\\"{x:762,y:756,t:1527628331047};\\\", \\\"{x:741,y:745,t:1527628331063};\\\", \\\"{x:713,y:737,t:1527628331080};\\\", \\\"{x:681,y:725,t:1527628331098};\\\", \\\"{x:663,y:718,t:1527628331114};\\\", \\\"{x:650,y:712,t:1527628331130};\\\", \\\"{x:644,y:708,t:1527628331147};\\\", \\\"{x:639,y:705,t:1527628331164};\\\", \\\"{x:626,y:696,t:1527628331180};\\\", \\\"{x:615,y:687,t:1527628331198};\\\", \\\"{x:598,y:675,t:1527628331213};\\\", \\\"{x:581,y:664,t:1527628331230};\\\", \\\"{x:570,y:656,t:1527628331247};\\\", \\\"{x:551,y:646,t:1527628331264};\\\", \\\"{x:529,y:633,t:1527628331280};\\\", \\\"{x:509,y:623,t:1527628331298};\\\", \\\"{x:478,y:611,t:1527628331314};\\\", \\\"{x:460,y:602,t:1527628331330};\\\", \\\"{x:447,y:597,t:1527628331348};\\\", \\\"{x:432,y:593,t:1527628331365};\\\", \\\"{x:417,y:586,t:1527628331380};\\\", \\\"{x:407,y:583,t:1527628331397};\\\", \\\"{x:390,y:577,t:1527628331414};\\\", \\\"{x:376,y:573,t:1527628331430};\\\", \\\"{x:371,y:572,t:1527628331448};\\\", \\\"{x:370,y:572,t:1527628331620};\\\", \\\"{x:367,y:570,t:1527628331631};\\\", \\\"{x:363,y:562,t:1527628331648};\\\", \\\"{x:359,y:554,t:1527628331665};\\\", \\\"{x:357,y:547,t:1527628331680};\\\", \\\"{x:356,y:543,t:1527628331698};\\\", \\\"{x:356,y:539,t:1527628331714};\\\", \\\"{x:359,y:534,t:1527628331731};\\\", \\\"{x:361,y:531,t:1527628331747};\\\", \\\"{x:362,y:528,t:1527628331764};\\\", \\\"{x:363,y:524,t:1527628331782};\\\", \\\"{x:363,y:523,t:1527628331829};\\\", \\\"{x:363,y:522,t:1527628331844};\\\", \\\"{x:363,y:521,t:1527628331852};\\\", \\\"{x:361,y:520,t:1527628331865};\\\", \\\"{x:349,y:517,t:1527628331883};\\\", \\\"{x:331,y:515,t:1527628331897};\\\", \\\"{x:305,y:511,t:1527628331914};\\\", \\\"{x:281,y:509,t:1527628331931};\\\", \\\"{x:263,y:508,t:1527628331949};\\\", \\\"{x:261,y:508,t:1527628331989};\\\", \\\"{x:260,y:508,t:1527628331997};\\\", \\\"{x:256,y:508,t:1527628332014};\\\", \\\"{x:253,y:508,t:1527628332032};\\\", \\\"{x:249,y:508,t:1527628332048};\\\", \\\"{x:242,y:506,t:1527628332064};\\\", \\\"{x:238,y:505,t:1527628332082};\\\", \\\"{x:237,y:505,t:1527628332098};\\\", \\\"{x:233,y:505,t:1527628332114};\\\", \\\"{x:228,y:503,t:1527628332132};\\\", \\\"{x:220,y:501,t:1527628332148};\\\", \\\"{x:213,y:500,t:1527628332164};\\\", \\\"{x:211,y:498,t:1527628332182};\\\", \\\"{x:210,y:498,t:1527628332199};\\\", \\\"{x:211,y:498,t:1527628332405};\\\", \\\"{x:224,y:509,t:1527628332415};\\\", \\\"{x:252,y:531,t:1527628332432};\\\", \\\"{x:276,y:551,t:1527628332449};\\\", \\\"{x:304,y:577,t:1527628332465};\\\", \\\"{x:322,y:600,t:1527628332482};\\\", \\\"{x:340,y:615,t:1527628332499};\\\", \\\"{x:356,y:627,t:1527628332514};\\\", \\\"{x:374,y:641,t:1527628332533};\\\", \\\"{x:403,y:657,t:1527628332549};\\\", \\\"{x:417,y:666,t:1527628332566};\\\", \\\"{x:429,y:673,t:1527628332582};\\\", \\\"{x:434,y:676,t:1527628332599};\\\", \\\"{x:435,y:676,t:1527628332615};\\\", \\\"{x:437,y:678,t:1527628332632};\\\", \\\"{x:441,y:682,t:1527628332649};\\\", \\\"{x:457,y:692,t:1527628332665};\\\", \\\"{x:476,y:703,t:1527628332681};\\\", \\\"{x:489,y:709,t:1527628332699};\\\", \\\"{x:492,y:711,t:1527628332715};\\\", \\\"{x:489,y:711,t:1527628332772};\\\", \\\"{x:477,y:700,t:1527628332782};\\\", \\\"{x:425,y:670,t:1527628332798};\\\", \\\"{x:372,y:641,t:1527628332816};\\\", \\\"{x:301,y:604,t:1527628332832};\\\", \\\"{x:236,y:579,t:1527628332849};\\\", \\\"{x:215,y:564,t:1527628332865};\\\", \\\"{x:201,y:551,t:1527628332882};\\\", \\\"{x:188,y:535,t:1527628332898};\\\", \\\"{x:175,y:518,t:1527628332916};\\\", \\\"{x:162,y:504,t:1527628332933};\\\", \\\"{x:155,y:494,t:1527628332948};\\\", \\\"{x:154,y:494,t:1527628332966};\\\", \\\"{x:153,y:492,t:1527628332983};\\\", \\\"{x:153,y:489,t:1527628332999};\\\", \\\"{x:153,y:485,t:1527628333016};\\\", \\\"{x:152,y:483,t:1527628333032};\\\", \\\"{x:152,y:482,t:1527628333049};\\\", \\\"{x:152,y:484,t:1527628333301};\\\", \\\"{x:154,y:488,t:1527628333317};\\\", \\\"{x:156,y:492,t:1527628333332};\\\", \\\"{x:157,y:493,t:1527628333349};\\\", \\\"{x:157,y:494,t:1527628333366};\\\", \\\"{x:157,y:495,t:1527628333749};\\\", \\\"{x:165,y:503,t:1527628333757};\\\", \\\"{x:176,y:512,t:1527628333765};\\\", \\\"{x:202,y:530,t:1527628333783};\\\", \\\"{x:253,y:555,t:1527628333799};\\\", \\\"{x:296,y:578,t:1527628333816};\\\", \\\"{x:346,y:611,t:1527628333833};\\\", \\\"{x:375,y:629,t:1527628333849};\\\", \\\"{x:396,y:640,t:1527628333867};\\\", \\\"{x:414,y:652,t:1527628333883};\\\", \\\"{x:431,y:665,t:1527628333900};\\\", \\\"{x:455,y:681,t:1527628333916};\\\", \\\"{x:464,y:688,t:1527628333933};\\\", \\\"{x:468,y:691,t:1527628333950};\\\", \\\"{x:470,y:692,t:1527628333966};\\\", \\\"{x:470,y:693,t:1527628333983};\\\", \\\"{x:471,y:693,t:1527628334093};\\\", \\\"{x:471,y:695,t:1527628334101};\\\", \\\"{x:476,y:705,t:1527628334117};\\\", \\\"{x:484,y:714,t:1527628334133};\\\", \\\"{x:490,y:725,t:1527628334151};\\\", \\\"{x:495,y:733,t:1527628334166};\\\", \\\"{x:498,y:743,t:1527628334183};\\\", \\\"{x:501,y:749,t:1527628334200};\\\", \\\"{x:502,y:751,t:1527628334217};\\\", \\\"{x:503,y:756,t:1527628334234};\\\", \\\"{x:507,y:759,t:1527628334249};\\\", \\\"{x:507,y:762,t:1527628334267};\\\", \\\"{x:509,y:764,t:1527628334284};\\\", \\\"{x:511,y:765,t:1527628334300};\\\", \\\"{x:512,y:767,t:1527628334317};\\\", \\\"{x:513,y:769,t:1527628334333};\\\", \\\"{x:514,y:771,t:1527628334349};\\\", \\\"{x:513,y:769,t:1527628334477};\\\", \\\"{x:512,y:768,t:1527628334486};\\\", \\\"{x:511,y:766,t:1527628334500};\\\", \\\"{x:509,y:759,t:1527628334518};\\\", \\\"{x:507,y:756,t:1527628334534};\\\", \\\"{x:506,y:755,t:1527628334709};\\\", \\\"{x:505,y:751,t:1527628334716};\\\", \\\"{x:505,y:751,t:1527628334717};\\\", \\\"{x:503,y:747,t:1527628334734};\\\", \\\"{x:503,y:740,t:1527628334750};\\\", \\\"{x:503,y:736,t:1527628334767};\\\", \\\"{x:503,y:734,t:1527628334783};\\\", \\\"{x:503,y:737,t:1527628335214};\\\", \\\"{x:501,y:742,t:1527628335221};\\\", \\\"{x:501,y:744,t:1527628335234};\\\", \\\"{x:501,y:750,t:1527628335251};\\\", \\\"{x:501,y:757,t:1527628335268};\\\", \\\"{x:501,y:765,t:1527628335284};\\\", \\\"{x:501,y:777,t:1527628335301};\\\", \\\"{x:501,y:781,t:1527628335319};\\\", \\\"{x:501,y:784,t:1527628335334};\\\", \\\"{x:501,y:786,t:1527628335351};\\\", \\\"{x:501,y:788,t:1527628335368};\\\" ] }, { \\\"rt\\\": 15662, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 601626, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:780,t:1527628336146};\\\", \\\"{x:497,y:779,t:1527628336181};\\\", \\\"{x:497,y:778,t:1527628336268};\\\", \\\"{x:492,y:767,t:1527628336285};\\\", \\\"{x:486,y:757,t:1527628336302};\\\", \\\"{x:481,y:744,t:1527628336318};\\\", \\\"{x:472,y:731,t:1527628336335};\\\", \\\"{x:465,y:715,t:1527628336352};\\\", \\\"{x:457,y:696,t:1527628336368};\\\", \\\"{x:454,y:682,t:1527628336385};\\\", \\\"{x:445,y:664,t:1527628336402};\\\", \\\"{x:434,y:642,t:1527628336417};\\\", \\\"{x:416,y:604,t:1527628336435};\\\", \\\"{x:398,y:575,t:1527628336452};\\\", \\\"{x:391,y:563,t:1527628336469};\\\", \\\"{x:388,y:548,t:1527628336485};\\\", \\\"{x:380,y:528,t:1527628336502};\\\", \\\"{x:372,y:511,t:1527628336519};\\\", \\\"{x:364,y:468,t:1527628336590};\\\", \\\"{x:364,y:466,t:1527628336661};\\\", \\\"{x:364,y:465,t:1527628336701};\\\", \\\"{x:364,y:464,t:1527628336725};\\\", \\\"{x:364,y:463,t:1527628336734};\\\", \\\"{x:365,y:462,t:1527628337118};\\\", \\\"{x:366,y:462,t:1527628337174};\\\", \\\"{x:367,y:462,t:1527628337246};\\\", \\\"{x:369,y:462,t:1527628337277};\\\", \\\"{x:371,y:462,t:1527628337294};\\\", \\\"{x:371,y:463,t:1527628337302};\\\", \\\"{x:372,y:463,t:1527628337318};\\\", \\\"{x:373,y:464,t:1527628337335};\\\", \\\"{x:374,y:464,t:1527628337353};\\\", \\\"{x:375,y:464,t:1527628337369};\\\", \\\"{x:376,y:464,t:1527628337386};\\\", \\\"{x:379,y:464,t:1527628337402};\\\", \\\"{x:383,y:464,t:1527628337418};\\\", \\\"{x:386,y:464,t:1527628337436};\\\", \\\"{x:393,y:464,t:1527628337453};\\\", \\\"{x:398,y:464,t:1527628337469};\\\", \\\"{x:408,y:464,t:1527628337485};\\\", \\\"{x:409,y:464,t:1527628337502};\\\", \\\"{x:413,y:464,t:1527628337517};\\\", \\\"{x:414,y:464,t:1527628337541};\\\", \\\"{x:415,y:464,t:1527628337552};\\\", \\\"{x:419,y:463,t:1527628337567};\\\", \\\"{x:424,y:461,t:1527628337585};\\\", \\\"{x:437,y:460,t:1527628337601};\\\", \\\"{x:444,y:459,t:1527628337618};\\\", \\\"{x:450,y:458,t:1527628337635};\\\", \\\"{x:452,y:457,t:1527628337652};\\\", \\\"{x:453,y:457,t:1527628337668};\\\", \\\"{x:458,y:454,t:1527628337685};\\\", \\\"{x:459,y:454,t:1527628337702};\\\", \\\"{x:460,y:454,t:1527628337718};\\\", \\\"{x:461,y:454,t:1527628337735};\\\", \\\"{x:462,y:454,t:1527628337752};\\\", \\\"{x:466,y:454,t:1527628338246};\\\", \\\"{x:483,y:454,t:1527628338253};\\\", \\\"{x:502,y:454,t:1527628338268};\\\", \\\"{x:569,y:459,t:1527628338285};\\\", \\\"{x:599,y:460,t:1527628338302};\\\", \\\"{x:627,y:460,t:1527628338318};\\\", \\\"{x:667,y:457,t:1527628338335};\\\", \\\"{x:699,y:453,t:1527628338352};\\\", \\\"{x:751,y:440,t:1527628338368};\\\", \\\"{x:807,y:430,t:1527628338385};\\\", \\\"{x:861,y:421,t:1527628338402};\\\", \\\"{x:901,y:409,t:1527628338418};\\\", \\\"{x:958,y:400,t:1527628338435};\\\", \\\"{x:1026,y:386,t:1527628338453};\\\", \\\"{x:1066,y:385,t:1527628338468};\\\", \\\"{x:1150,y:376,t:1527628338485};\\\", \\\"{x:1216,y:371,t:1527628338502};\\\", \\\"{x:1272,y:363,t:1527628338518};\\\", \\\"{x:1320,y:363,t:1527628338535};\\\", \\\"{x:1357,y:363,t:1527628338552};\\\", \\\"{x:1387,y:363,t:1527628338568};\\\", \\\"{x:1408,y:363,t:1527628338585};\\\", \\\"{x:1413,y:363,t:1527628338602};\\\", \\\"{x:1418,y:364,t:1527628338618};\\\", \\\"{x:1428,y:368,t:1527628338635};\\\", \\\"{x:1444,y:374,t:1527628338652};\\\", \\\"{x:1459,y:377,t:1527628338668};\\\", \\\"{x:1468,y:382,t:1527628338684};\\\", \\\"{x:1470,y:383,t:1527628338702};\\\", \\\"{x:1472,y:384,t:1527628338718};\\\", \\\"{x:1475,y:388,t:1527628338735};\\\", \\\"{x:1478,y:390,t:1527628338751};\\\", \\\"{x:1480,y:396,t:1527628338768};\\\", \\\"{x:1484,y:404,t:1527628338785};\\\", \\\"{x:1488,y:420,t:1527628338801};\\\", \\\"{x:1493,y:439,t:1527628338819};\\\", \\\"{x:1499,y:455,t:1527628338836};\\\", \\\"{x:1504,y:476,t:1527628338851};\\\", \\\"{x:1509,y:500,t:1527628338869};\\\", \\\"{x:1515,y:536,t:1527628338885};\\\", \\\"{x:1517,y:559,t:1527628338902};\\\", \\\"{x:1520,y:576,t:1527628338919};\\\", \\\"{x:1520,y:582,t:1527628338936};\\\", \\\"{x:1520,y:587,t:1527628338951};\\\", \\\"{x:1520,y:591,t:1527628338968};\\\", \\\"{x:1520,y:595,t:1527628338985};\\\", \\\"{x:1519,y:600,t:1527628339001};\\\", \\\"{x:1518,y:606,t:1527628339018};\\\", \\\"{x:1515,y:615,t:1527628339035};\\\", \\\"{x:1512,y:623,t:1527628339052};\\\", \\\"{x:1509,y:629,t:1527628339068};\\\", \\\"{x:1507,y:635,t:1527628339085};\\\", \\\"{x:1506,y:639,t:1527628339101};\\\", \\\"{x:1503,y:642,t:1527628339133};\\\", \\\"{x:1503,y:643,t:1527628339141};\\\", \\\"{x:1503,y:645,t:1527628339152};\\\", \\\"{x:1500,y:649,t:1527628339168};\\\", \\\"{x:1498,y:652,t:1527628339185};\\\", \\\"{x:1495,y:656,t:1527628339202};\\\", \\\"{x:1491,y:660,t:1527628339219};\\\", \\\"{x:1486,y:666,t:1527628339235};\\\", \\\"{x:1484,y:667,t:1527628339251};\\\", \\\"{x:1475,y:672,t:1527628339268};\\\", \\\"{x:1449,y:684,t:1527628339285};\\\", \\\"{x:1437,y:693,t:1527628339301};\\\", \\\"{x:1423,y:698,t:1527628339318};\\\", \\\"{x:1412,y:703,t:1527628339335};\\\", \\\"{x:1409,y:704,t:1527628339352};\\\", \\\"{x:1408,y:704,t:1527628339389};\\\", \\\"{x:1407,y:704,t:1527628339402};\\\", \\\"{x:1406,y:704,t:1527628339510};\\\", \\\"{x:1403,y:706,t:1527628339519};\\\", \\\"{x:1402,y:706,t:1527628339536};\\\", \\\"{x:1391,y:706,t:1527628339552};\\\", \\\"{x:1372,y:706,t:1527628339569};\\\", \\\"{x:1347,y:706,t:1527628339585};\\\", \\\"{x:1329,y:706,t:1527628339602};\\\", \\\"{x:1314,y:705,t:1527628339619};\\\", \\\"{x:1303,y:701,t:1527628339635};\\\", \\\"{x:1301,y:701,t:1527628339651};\\\", \\\"{x:1304,y:701,t:1527628339902};\\\", \\\"{x:1308,y:699,t:1527628339918};\\\", \\\"{x:1309,y:699,t:1527628339935};\\\", \\\"{x:1311,y:699,t:1527628340014};\\\", \\\"{x:1314,y:699,t:1527628340030};\\\", \\\"{x:1316,y:698,t:1527628340045};\\\", \\\"{x:1318,y:698,t:1527628340053};\\\", \\\"{x:1319,y:697,t:1527628340068};\\\", \\\"{x:1322,y:696,t:1527628340085};\\\", \\\"{x:1324,y:696,t:1527628340125};\\\", \\\"{x:1325,y:696,t:1527628340135};\\\", \\\"{x:1326,y:696,t:1527628340151};\\\", \\\"{x:1332,y:693,t:1527628340169};\\\", \\\"{x:1333,y:693,t:1527628340207};\\\", \\\"{x:1335,y:693,t:1527628340278};\\\", \\\"{x:1337,y:693,t:1527628340294};\\\", \\\"{x:1339,y:693,t:1527628340325};\\\", \\\"{x:1341,y:693,t:1527628340335};\\\", \\\"{x:1342,y:693,t:1527628340454};\\\", \\\"{x:1343,y:693,t:1527628340471};\\\", \\\"{x:1343,y:696,t:1527628340485};\\\", \\\"{x:1345,y:700,t:1527628340501};\\\", \\\"{x:1345,y:702,t:1527628340519};\\\", \\\"{x:1345,y:703,t:1527628340534};\\\", \\\"{x:1345,y:704,t:1527628340551};\\\", \\\"{x:1345,y:705,t:1527628340982};\\\", \\\"{x:1346,y:711,t:1527628340989};\\\", \\\"{x:1347,y:716,t:1527628341001};\\\", \\\"{x:1348,y:725,t:1527628341019};\\\", \\\"{x:1349,y:735,t:1527628341035};\\\", \\\"{x:1350,y:742,t:1527628341051};\\\", \\\"{x:1350,y:753,t:1527628341069};\\\", \\\"{x:1352,y:772,t:1527628341085};\\\", \\\"{x:1360,y:790,t:1527628341102};\\\", \\\"{x:1361,y:800,t:1527628341118};\\\", \\\"{x:1361,y:801,t:1527628341246};\\\", \\\"{x:1362,y:801,t:1527628341318};\\\", \\\"{x:1363,y:801,t:1527628341966};\\\", \\\"{x:1363,y:802,t:1527628341972};\\\", \\\"{x:1365,y:803,t:1527628341984};\\\", \\\"{x:1368,y:806,t:1527628342001};\\\", \\\"{x:1370,y:806,t:1527628342045};\\\", \\\"{x:1373,y:806,t:1527628342053};\\\", \\\"{x:1377,y:806,t:1527628342067};\\\", \\\"{x:1382,y:806,t:1527628342084};\\\", \\\"{x:1388,y:806,t:1527628342101};\\\", \\\"{x:1389,y:806,t:1527628342117};\\\", \\\"{x:1391,y:806,t:1527628342134};\\\", \\\"{x:1396,y:806,t:1527628342152};\\\", \\\"{x:1409,y:810,t:1527628342167};\\\", \\\"{x:1425,y:821,t:1527628342184};\\\", \\\"{x:1440,y:826,t:1527628342202};\\\", \\\"{x:1459,y:835,t:1527628342217};\\\", \\\"{x:1476,y:844,t:1527628342235};\\\", \\\"{x:1494,y:849,t:1527628342252};\\\", \\\"{x:1504,y:857,t:1527628342268};\\\", \\\"{x:1515,y:863,t:1527628342285};\\\", \\\"{x:1533,y:868,t:1527628342301};\\\", \\\"{x:1538,y:871,t:1527628342318};\\\", \\\"{x:1541,y:872,t:1527628342335};\\\", \\\"{x:1543,y:874,t:1527628342352};\\\", \\\"{x:1545,y:877,t:1527628342367};\\\", \\\"{x:1548,y:878,t:1527628342385};\\\", \\\"{x:1553,y:882,t:1527628342401};\\\", \\\"{x:1558,y:887,t:1527628342418};\\\", \\\"{x:1561,y:890,t:1527628342435};\\\", \\\"{x:1564,y:893,t:1527628342452};\\\", \\\"{x:1565,y:893,t:1527628342469};\\\", \\\"{x:1565,y:894,t:1527628342485};\\\", \\\"{x:1569,y:900,t:1527628342501};\\\", \\\"{x:1576,y:906,t:1527628342518};\\\", \\\"{x:1582,y:910,t:1527628342535};\\\", \\\"{x:1584,y:913,t:1527628342551};\\\", \\\"{x:1590,y:916,t:1527628342567};\\\", \\\"{x:1591,y:918,t:1527628342584};\\\", \\\"{x:1596,y:920,t:1527628342602};\\\", \\\"{x:1598,y:924,t:1527628342617};\\\", \\\"{x:1600,y:927,t:1527628342635};\\\", \\\"{x:1602,y:929,t:1527628342669};\\\", \\\"{x:1603,y:929,t:1527628342685};\\\", \\\"{x:1606,y:931,t:1527628342701};\\\", \\\"{x:1608,y:932,t:1527628342718};\\\", \\\"{x:1610,y:932,t:1527628342734};\\\", \\\"{x:1612,y:933,t:1527628342752};\\\", \\\"{x:1616,y:935,t:1527628342768};\\\", \\\"{x:1619,y:938,t:1527628342785};\\\", \\\"{x:1621,y:940,t:1527628342801};\\\", \\\"{x:1624,y:943,t:1527628342818};\\\", \\\"{x:1626,y:945,t:1527628342835};\\\", \\\"{x:1626,y:944,t:1527628343159};\\\", \\\"{x:1626,y:942,t:1527628343168};\\\", \\\"{x:1626,y:940,t:1527628343185};\\\", \\\"{x:1624,y:937,t:1527628343202};\\\", \\\"{x:1620,y:933,t:1527628343218};\\\", \\\"{x:1616,y:929,t:1527628343234};\\\", \\\"{x:1613,y:925,t:1527628343252};\\\", \\\"{x:1612,y:922,t:1527628343268};\\\", \\\"{x:1612,y:920,t:1527628343285};\\\", \\\"{x:1610,y:917,t:1527628343301};\\\", \\\"{x:1608,y:914,t:1527628343317};\\\", \\\"{x:1606,y:909,t:1527628343335};\\\", \\\"{x:1605,y:906,t:1527628343352};\\\", \\\"{x:1603,y:901,t:1527628343368};\\\", \\\"{x:1602,y:897,t:1527628343385};\\\", \\\"{x:1602,y:894,t:1527628343401};\\\", \\\"{x:1601,y:891,t:1527628343418};\\\", \\\"{x:1601,y:888,t:1527628343435};\\\", \\\"{x:1600,y:883,t:1527628343452};\\\", \\\"{x:1600,y:878,t:1527628343468};\\\", \\\"{x:1599,y:867,t:1527628343484};\\\", \\\"{x:1595,y:852,t:1527628343501};\\\", \\\"{x:1595,y:845,t:1527628343518};\\\", \\\"{x:1595,y:838,t:1527628343535};\\\", \\\"{x:1594,y:832,t:1527628343552};\\\", \\\"{x:1594,y:825,t:1527628343568};\\\", \\\"{x:1595,y:817,t:1527628343585};\\\", \\\"{x:1595,y:808,t:1527628343602};\\\", \\\"{x:1595,y:799,t:1527628343618};\\\", \\\"{x:1595,y:792,t:1527628343635};\\\", \\\"{x:1596,y:788,t:1527628343652};\\\", \\\"{x:1596,y:784,t:1527628343668};\\\", \\\"{x:1597,y:778,t:1527628343685};\\\", \\\"{x:1597,y:775,t:1527628343701};\\\", \\\"{x:1597,y:766,t:1527628343718};\\\", \\\"{x:1597,y:761,t:1527628343735};\\\", \\\"{x:1597,y:755,t:1527628343752};\\\", \\\"{x:1597,y:747,t:1527628343768};\\\", \\\"{x:1597,y:739,t:1527628343784};\\\", \\\"{x:1597,y:729,t:1527628343801};\\\", \\\"{x:1595,y:723,t:1527628343817};\\\", \\\"{x:1593,y:722,t:1527628343835};\\\", \\\"{x:1593,y:720,t:1527628343851};\\\", \\\"{x:1592,y:718,t:1527628343868};\\\", \\\"{x:1590,y:714,t:1527628343886};\\\", \\\"{x:1590,y:711,t:1527628343901};\\\", \\\"{x:1590,y:708,t:1527628343918};\\\", \\\"{x:1590,y:706,t:1527628343938};\\\", \\\"{x:1590,y:705,t:1527628343950};\\\", \\\"{x:1590,y:704,t:1527628343981};\\\", \\\"{x:1590,y:703,t:1527628344182};\\\", \\\"{x:1590,y:702,t:1527628344198};\\\", \\\"{x:1591,y:700,t:1527628344206};\\\", \\\"{x:1591,y:699,t:1527628344230};\\\", \\\"{x:1592,y:698,t:1527628344238};\\\", \\\"{x:1592,y:697,t:1527628344251};\\\", \\\"{x:1592,y:696,t:1527628344318};\\\", \\\"{x:1594,y:694,t:1527628344359};\\\", \\\"{x:1594,y:695,t:1527628345444};\\\", \\\"{x:1594,y:697,t:1527628345452};\\\", \\\"{x:1594,y:698,t:1527628345467};\\\", \\\"{x:1592,y:706,t:1527628345484};\\\", \\\"{x:1589,y:714,t:1527628345501};\\\", \\\"{x:1589,y:720,t:1527628345517};\\\", \\\"{x:1584,y:732,t:1527628345533};\\\", \\\"{x:1581,y:742,t:1527628345551};\\\", \\\"{x:1580,y:749,t:1527628345568};\\\", \\\"{x:1577,y:753,t:1527628345583};\\\", \\\"{x:1576,y:754,t:1527628345601};\\\", \\\"{x:1576,y:756,t:1527628345629};\\\", \\\"{x:1576,y:757,t:1527628345662};\\\", \\\"{x:1574,y:758,t:1527628345669};\\\", \\\"{x:1574,y:759,t:1527628345685};\\\", \\\"{x:1574,y:760,t:1527628345700};\\\", \\\"{x:1573,y:762,t:1527628345717};\\\", \\\"{x:1572,y:763,t:1527628345759};\\\", \\\"{x:1571,y:763,t:1527628345789};\\\", \\\"{x:1570,y:765,t:1527628345934};\\\", \\\"{x:1567,y:767,t:1527628345951};\\\", \\\"{x:1556,y:770,t:1527628345968};\\\", \\\"{x:1547,y:774,t:1527628345983};\\\", \\\"{x:1545,y:775,t:1527628346000};\\\", \\\"{x:1541,y:775,t:1527628346017};\\\", \\\"{x:1540,y:776,t:1527628346033};\\\", \\\"{x:1539,y:777,t:1527628346050};\\\", \\\"{x:1538,y:777,t:1527628346068};\\\", \\\"{x:1537,y:777,t:1527628346230};\\\", \\\"{x:1535,y:778,t:1527628346237};\\\", \\\"{x:1533,y:779,t:1527628346253};\\\", \\\"{x:1531,y:780,t:1527628346268};\\\", \\\"{x:1528,y:784,t:1527628346284};\\\", \\\"{x:1522,y:789,t:1527628346301};\\\", \\\"{x:1519,y:793,t:1527628346317};\\\", \\\"{x:1516,y:796,t:1527628346334};\\\", \\\"{x:1515,y:799,t:1527628346351};\\\", \\\"{x:1513,y:801,t:1527628346368};\\\", \\\"{x:1511,y:805,t:1527628346384};\\\", \\\"{x:1509,y:807,t:1527628346401};\\\", \\\"{x:1506,y:811,t:1527628346418};\\\", \\\"{x:1502,y:815,t:1527628346433};\\\", \\\"{x:1499,y:817,t:1527628346451};\\\", \\\"{x:1499,y:820,t:1527628346468};\\\", \\\"{x:1499,y:821,t:1527628346484};\\\", \\\"{x:1498,y:822,t:1527628346501};\\\", \\\"{x:1495,y:827,t:1527628346518};\\\", \\\"{x:1495,y:828,t:1527628346534};\\\", \\\"{x:1493,y:829,t:1527628346550};\\\", \\\"{x:1493,y:830,t:1527628346568};\\\", \\\"{x:1492,y:831,t:1527628346584};\\\", \\\"{x:1491,y:834,t:1527628346601};\\\", \\\"{x:1490,y:834,t:1527628346630};\\\", \\\"{x:1489,y:835,t:1527628346662};\\\", \\\"{x:1487,y:836,t:1527628346685};\\\", \\\"{x:1485,y:838,t:1527628346702};\\\", \\\"{x:1484,y:838,t:1527628346717};\\\", \\\"{x:1483,y:838,t:1527628346982};\\\", \\\"{x:1482,y:838,t:1527628347798};\\\", \\\"{x:1477,y:838,t:1527628348805};\\\", \\\"{x:1471,y:838,t:1527628348817};\\\", \\\"{x:1448,y:838,t:1527628348834};\\\", \\\"{x:1431,y:838,t:1527628348851};\\\", \\\"{x:1401,y:838,t:1527628348867};\\\", \\\"{x:1340,y:838,t:1527628348884};\\\", \\\"{x:1270,y:840,t:1527628348900};\\\", \\\"{x:1169,y:840,t:1527628348917};\\\", \\\"{x:1092,y:840,t:1527628348933};\\\", \\\"{x:1041,y:839,t:1527628348950};\\\", \\\"{x:977,y:839,t:1527628348967};\\\", \\\"{x:939,y:839,t:1527628348984};\\\", \\\"{x:923,y:839,t:1527628349000};\\\", \\\"{x:913,y:839,t:1527628349017};\\\", \\\"{x:910,y:839,t:1527628349034};\\\", \\\"{x:906,y:839,t:1527628349093};\\\", \\\"{x:902,y:839,t:1527628349101};\\\", \\\"{x:878,y:839,t:1527628349117};\\\", \\\"{x:853,y:834,t:1527628349134};\\\", \\\"{x:808,y:819,t:1527628349150};\\\", \\\"{x:753,y:796,t:1527628349166};\\\", \\\"{x:687,y:773,t:1527628349184};\\\", \\\"{x:639,y:749,t:1527628349200};\\\", \\\"{x:597,y:728,t:1527628349216};\\\", \\\"{x:571,y:711,t:1527628349233};\\\", \\\"{x:556,y:695,t:1527628349250};\\\", \\\"{x:550,y:690,t:1527628349267};\\\", \\\"{x:546,y:683,t:1527628349284};\\\", \\\"{x:543,y:676,t:1527628349300};\\\", \\\"{x:543,y:662,t:1527628349317};\\\", \\\"{x:542,y:652,t:1527628349333};\\\", \\\"{x:540,y:645,t:1527628349350};\\\", \\\"{x:538,y:644,t:1527628349367};\\\", \\\"{x:538,y:642,t:1527628349430};\\\", \\\"{x:538,y:641,t:1527628349438};\\\", \\\"{x:538,y:639,t:1527628349449};\\\", \\\"{x:538,y:635,t:1527628349467};\\\", \\\"{x:538,y:632,t:1527628349484};\\\", \\\"{x:538,y:629,t:1527628349501};\\\", \\\"{x:551,y:620,t:1527628349516};\\\", \\\"{x:562,y:615,t:1527628349533};\\\", \\\"{x:566,y:612,t:1527628349546};\\\", \\\"{x:570,y:609,t:1527628349562};\\\", \\\"{x:577,y:604,t:1527628349579};\\\", \\\"{x:581,y:602,t:1527628349596};\\\", \\\"{x:583,y:601,t:1527628349612};\\\", \\\"{x:586,y:600,t:1527628349630};\\\", \\\"{x:589,y:598,t:1527628349646};\\\", \\\"{x:590,y:597,t:1527628349662};\\\", \\\"{x:591,y:596,t:1527628349680};\\\", \\\"{x:591,y:594,t:1527628349696};\\\", \\\"{x:592,y:594,t:1527628349713};\\\", \\\"{x:592,y:593,t:1527628349749};\\\", \\\"{x:592,y:592,t:1527628349765};\\\", \\\"{x:592,y:591,t:1527628349781};\\\", \\\"{x:591,y:591,t:1527628350054};\\\", \\\"{x:589,y:591,t:1527628350062};\\\", \\\"{x:587,y:597,t:1527628350074};\\\", \\\"{x:585,y:611,t:1527628350089};\\\", \\\"{x:578,y:633,t:1527628350106};\\\", \\\"{x:572,y:650,t:1527628350123};\\\", \\\"{x:567,y:671,t:1527628350139};\\\", \\\"{x:564,y:681,t:1527628350156};\\\", \\\"{x:558,y:692,t:1527628350173};\\\", \\\"{x:553,y:700,t:1527628350188};\\\", \\\"{x:550,y:706,t:1527628350206};\\\", \\\"{x:550,y:704,t:1527628350271};\\\", \\\"{x:550,y:700,t:1527628350278};\\\", \\\"{x:551,y:693,t:1527628350288};\\\", \\\"{x:564,y:671,t:1527628350306};\\\", \\\"{x:585,y:645,t:1527628350323};\\\", \\\"{x:609,y:616,t:1527628350341};\\\", \\\"{x:622,y:597,t:1527628350356};\\\", \\\"{x:632,y:588,t:1527628350372};\\\", \\\"{x:635,y:585,t:1527628350389};\\\", \\\"{x:637,y:582,t:1527628350406};\\\", \\\"{x:639,y:579,t:1527628350423};\\\", \\\"{x:639,y:578,t:1527628350445};\\\", \\\"{x:640,y:578,t:1527628350456};\\\", \\\"{x:641,y:577,t:1527628350472};\\\", \\\"{x:641,y:576,t:1527628350488};\\\", \\\"{x:641,y:575,t:1527628350506};\\\", \\\"{x:641,y:574,t:1527628350523};\\\", \\\"{x:642,y:572,t:1527628350539};\\\", \\\"{x:643,y:568,t:1527628350556};\\\", \\\"{x:644,y:565,t:1527628350573};\\\", \\\"{x:642,y:565,t:1527628350686};\\\", \\\"{x:636,y:568,t:1527628350695};\\\", \\\"{x:635,y:568,t:1527628350706};\\\", \\\"{x:631,y:570,t:1527628350723};\\\", \\\"{x:628,y:573,t:1527628350740};\\\", \\\"{x:626,y:574,t:1527628350755};\\\", \\\"{x:624,y:575,t:1527628350926};\\\", \\\"{x:623,y:577,t:1527628350940};\\\", \\\"{x:622,y:577,t:1527628350956};\\\", \\\"{x:618,y:581,t:1527628350982};\\\", \\\"{x:614,y:589,t:1527628350989};\\\", \\\"{x:606,y:606,t:1527628351008};\\\", \\\"{x:589,y:625,t:1527628351023};\\\", \\\"{x:570,y:653,t:1527628351040};\\\", \\\"{x:555,y:676,t:1527628351057};\\\", \\\"{x:538,y:698,t:1527628351073};\\\", \\\"{x:531,y:709,t:1527628351090};\\\", \\\"{x:526,y:715,t:1527628351106};\\\", \\\"{x:522,y:724,t:1527628351123};\\\", \\\"{x:520,y:731,t:1527628351140};\\\", \\\"{x:519,y:740,t:1527628351157};\\\", \\\"{x:515,y:751,t:1527628351174};\\\", \\\"{x:515,y:752,t:1527628351190};\\\", \\\"{x:515,y:753,t:1527628351207};\\\", \\\"{x:515,y:755,t:1527628351296};\\\", \\\"{x:515,y:756,t:1527628351310};\\\", \\\"{x:515,y:757,t:1527628351324};\\\", \\\"{x:515,y:758,t:1527628351446};\\\", \\\"{x:515,y:758,t:1527628351512};\\\", \\\"{x:515,y:756,t:1527628351559};\\\", \\\"{x:516,y:751,t:1527628351575};\\\", \\\"{x:516,y:744,t:1527628351590};\\\", \\\"{x:516,y:741,t:1527628351607};\\\", \\\"{x:516,y:737,t:1527628351624};\\\", \\\"{x:516,y:736,t:1527628351640};\\\", \\\"{x:516,y:735,t:1527628351750};\\\", \\\"{x:516,y:735,t:1527628351831};\\\", \\\"{x:514,y:740,t:1527628352022};\\\", \\\"{x:511,y:749,t:1527628352030};\\\", \\\"{x:509,y:756,t:1527628352041};\\\", \\\"{x:505,y:768,t:1527628352058};\\\", \\\"{x:500,y:781,t:1527628352075};\\\", \\\"{x:499,y:790,t:1527628352092};\\\", \\\"{x:496,y:800,t:1527628352107};\\\", \\\"{x:495,y:807,t:1527628352124};\\\", \\\"{x:494,y:817,t:1527628352141};\\\", \\\"{x:494,y:828,t:1527628352157};\\\", \\\"{x:494,y:837,t:1527628352174};\\\", \\\"{x:494,y:843,t:1527628352192};\\\", \\\"{x:492,y:849,t:1527628352207};\\\", \\\"{x:490,y:854,t:1527628352224};\\\", \\\"{x:490,y:858,t:1527628352242};\\\", \\\"{x:487,y:864,t:1527628352258};\\\", \\\"{x:487,y:868,t:1527628352275};\\\", \\\"{x:482,y:874,t:1527628352291};\\\", \\\"{x:475,y:883,t:1527628352308};\\\", \\\"{x:472,y:887,t:1527628352324};\\\", \\\"{x:469,y:889,t:1527628352341};\\\", \\\"{x:465,y:892,t:1527628352358};\\\", \\\"{x:462,y:895,t:1527628352374};\\\", \\\"{x:459,y:896,t:1527628352391};\\\", \\\"{x:455,y:896,t:1527628352408};\\\", \\\"{x:445,y:896,t:1527628352424};\\\", \\\"{x:430,y:888,t:1527628352441};\\\", \\\"{x:414,y:880,t:1527628352458};\\\", \\\"{x:395,y:869,t:1527628352474};\\\", \\\"{x:380,y:856,t:1527628352491};\\\", \\\"{x:372,y:845,t:1527628352508};\\\", \\\"{x:364,y:829,t:1527628352524};\\\", \\\"{x:360,y:816,t:1527628352541};\\\", \\\"{x:342,y:788,t:1527628352558};\\\", \\\"{x:331,y:759,t:1527628352574};\\\", \\\"{x:317,y:730,t:1527628352591};\\\", \\\"{x:300,y:691,t:1527628352608};\\\", \\\"{x:286,y:668,t:1527628352624};\\\", \\\"{x:275,y:646,t:1527628352641};\\\", \\\"{x:268,y:628,t:1527628352658};\\\", \\\"{x:263,y:603,t:1527628352675};\\\", \\\"{x:260,y:584,t:1527628352692};\\\", \\\"{x:263,y:562,t:1527628352708};\\\", \\\"{x:270,y:549,t:1527628352725};\\\", \\\"{x:274,y:542,t:1527628352741};\\\" ] }, { \\\"rt\\\": 7640, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 610516, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:274,y:539,t:1527628353662};\\\", \\\"{x:274,y:536,t:1527628353676};\\\", \\\"{x:276,y:529,t:1527628353693};\\\", \\\"{x:278,y:520,t:1527628353711};\\\", \\\"{x:280,y:516,t:1527628353728};\\\", \\\"{x:287,y:508,t:1527628353741};\\\", \\\"{x:291,y:505,t:1527628353759};\\\", \\\"{x:300,y:497,t:1527628353775};\\\", \\\"{x:315,y:487,t:1527628353792};\\\", \\\"{x:328,y:479,t:1527628353809};\\\", \\\"{x:338,y:472,t:1527628353825};\\\", \\\"{x:342,y:467,t:1527628353842};\\\", \\\"{x:346,y:464,t:1527628353858};\\\", \\\"{x:354,y:458,t:1527628353876};\\\", \\\"{x:375,y:453,t:1527628353892};\\\", \\\"{x:397,y:447,t:1527628353908};\\\", \\\"{x:430,y:436,t:1527628353925};\\\", \\\"{x:456,y:434,t:1527628353942};\\\", \\\"{x:486,y:425,t:1527628353959};\\\", \\\"{x:517,y:419,t:1527628353976};\\\", \\\"{x:561,y:418,t:1527628353993};\\\", \\\"{x:588,y:418,t:1527628354009};\\\", \\\"{x:603,y:418,t:1527628354025};\\\", \\\"{x:621,y:416,t:1527628354043};\\\", \\\"{x:631,y:416,t:1527628354059};\\\", \\\"{x:636,y:417,t:1527628354077};\\\", \\\"{x:640,y:418,t:1527628354093};\\\", \\\"{x:644,y:418,t:1527628354109};\\\", \\\"{x:647,y:418,t:1527628354743};\\\", \\\"{x:655,y:419,t:1527628354750};\\\", \\\"{x:664,y:421,t:1527628354764};\\\", \\\"{x:682,y:424,t:1527628354780};\\\", \\\"{x:703,y:428,t:1527628354796};\\\", \\\"{x:723,y:432,t:1527628354814};\\\", \\\"{x:749,y:438,t:1527628354831};\\\", \\\"{x:769,y:440,t:1527628354847};\\\", \\\"{x:784,y:444,t:1527628354864};\\\", \\\"{x:799,y:449,t:1527628354880};\\\", \\\"{x:814,y:451,t:1527628354897};\\\", \\\"{x:826,y:456,t:1527628354913};\\\", \\\"{x:842,y:464,t:1527628354930};\\\", \\\"{x:859,y:469,t:1527628354947};\\\", \\\"{x:881,y:477,t:1527628354964};\\\", \\\"{x:912,y:488,t:1527628354982};\\\", \\\"{x:948,y:503,t:1527628354997};\\\", \\\"{x:986,y:514,t:1527628355009};\\\", \\\"{x:1005,y:522,t:1527628355026};\\\", \\\"{x:1045,y:534,t:1527628355043};\\\", \\\"{x:1081,y:548,t:1527628355061};\\\", \\\"{x:1110,y:559,t:1527628355076};\\\", \\\"{x:1125,y:565,t:1527628355093};\\\", \\\"{x:1158,y:585,t:1527628355109};\\\", \\\"{x:1173,y:599,t:1527628355126};\\\", \\\"{x:1198,y:616,t:1527628355143};\\\", \\\"{x:1219,y:629,t:1527628355160};\\\", \\\"{x:1231,y:640,t:1527628355177};\\\", \\\"{x:1244,y:657,t:1527628355193};\\\", \\\"{x:1254,y:671,t:1527628355211};\\\", \\\"{x:1269,y:699,t:1527628355227};\\\", \\\"{x:1286,y:731,t:1527628355244};\\\", \\\"{x:1301,y:755,t:1527628355260};\\\", \\\"{x:1311,y:772,t:1527628355277};\\\", \\\"{x:1321,y:788,t:1527628355293};\\\", \\\"{x:1325,y:803,t:1527628355311};\\\", \\\"{x:1328,y:816,t:1527628355328};\\\", \\\"{x:1336,y:831,t:1527628355343};\\\", \\\"{x:1342,y:845,t:1527628355361};\\\", \\\"{x:1348,y:858,t:1527628355378};\\\", \\\"{x:1353,y:867,t:1527628355394};\\\", \\\"{x:1357,y:875,t:1527628355411};\\\", \\\"{x:1361,y:889,t:1527628355428};\\\", \\\"{x:1365,y:901,t:1527628355444};\\\", \\\"{x:1368,y:914,t:1527628355461};\\\", \\\"{x:1370,y:919,t:1527628355478};\\\", \\\"{x:1372,y:926,t:1527628355494};\\\", \\\"{x:1373,y:932,t:1527628355511};\\\", \\\"{x:1374,y:934,t:1527628355528};\\\", \\\"{x:1374,y:936,t:1527628355551};\\\", \\\"{x:1374,y:938,t:1527628355561};\\\", \\\"{x:1374,y:943,t:1527628355578};\\\", \\\"{x:1374,y:947,t:1527628355594};\\\", \\\"{x:1373,y:951,t:1527628355611};\\\", \\\"{x:1372,y:955,t:1527628355627};\\\", \\\"{x:1370,y:958,t:1527628355644};\\\", \\\"{x:1369,y:960,t:1527628355661};\\\", \\\"{x:1368,y:962,t:1527628355678};\\\", \\\"{x:1367,y:964,t:1527628355694};\\\", \\\"{x:1364,y:968,t:1527628355711};\\\", \\\"{x:1363,y:969,t:1527628355728};\\\", \\\"{x:1362,y:970,t:1527628355745};\\\", \\\"{x:1362,y:971,t:1527628355760};\\\", \\\"{x:1361,y:972,t:1527628355777};\\\", \\\"{x:1359,y:973,t:1527628355795};\\\", \\\"{x:1358,y:973,t:1527628356015};\\\", \\\"{x:1357,y:973,t:1527628356071};\\\", \\\"{x:1355,y:973,t:1527628356078};\\\", \\\"{x:1353,y:973,t:1527628356094};\\\", \\\"{x:1349,y:973,t:1527628356111};\\\", \\\"{x:1347,y:973,t:1527628356127};\\\", \\\"{x:1345,y:972,t:1527628356144};\\\", \\\"{x:1344,y:972,t:1527628356161};\\\", \\\"{x:1344,y:970,t:1527628356198};\\\", \\\"{x:1344,y:969,t:1527628356211};\\\", \\\"{x:1343,y:966,t:1527628356228};\\\", \\\"{x:1341,y:959,t:1527628356244};\\\", \\\"{x:1338,y:951,t:1527628356261};\\\", \\\"{x:1334,y:937,t:1527628356278};\\\", \\\"{x:1328,y:915,t:1527628356294};\\\", \\\"{x:1322,y:901,t:1527628356312};\\\", \\\"{x:1312,y:882,t:1527628356327};\\\", \\\"{x:1301,y:860,t:1527628356345};\\\", \\\"{x:1290,y:840,t:1527628356362};\\\", \\\"{x:1282,y:823,t:1527628356378};\\\", \\\"{x:1274,y:807,t:1527628356395};\\\", \\\"{x:1258,y:786,t:1527628356412};\\\", \\\"{x:1239,y:770,t:1527628356428};\\\", \\\"{x:1203,y:737,t:1527628356444};\\\", \\\"{x:1154,y:709,t:1527628356462};\\\", \\\"{x:1099,y:675,t:1527628356478};\\\", \\\"{x:1007,y:634,t:1527628356494};\\\", \\\"{x:963,y:616,t:1527628356511};\\\", \\\"{x:895,y:591,t:1527628356529};\\\", \\\"{x:839,y:575,t:1527628356545};\\\", \\\"{x:787,y:562,t:1527628356563};\\\", \\\"{x:749,y:550,t:1527628356578};\\\", \\\"{x:715,y:539,t:1527628356595};\\\", \\\"{x:680,y:526,t:1527628356611};\\\", \\\"{x:660,y:517,t:1527628356629};\\\", \\\"{x:644,y:511,t:1527628356645};\\\", \\\"{x:635,y:506,t:1527628356662};\\\", \\\"{x:623,y:502,t:1527628356677};\\\", \\\"{x:618,y:499,t:1527628356694};\\\", \\\"{x:610,y:496,t:1527628356711};\\\", \\\"{x:603,y:492,t:1527628356728};\\\", \\\"{x:598,y:487,t:1527628356744};\\\", \\\"{x:596,y:485,t:1527628356762};\\\", \\\"{x:596,y:486,t:1527628356951};\\\", \\\"{x:596,y:487,t:1527628356967};\\\", \\\"{x:596,y:488,t:1527628356978};\\\", \\\"{x:597,y:489,t:1527628356995};\\\", \\\"{x:600,y:491,t:1527628357011};\\\", \\\"{x:602,y:493,t:1527628357028};\\\", \\\"{x:606,y:497,t:1527628357045};\\\", \\\"{x:610,y:501,t:1527628357061};\\\", \\\"{x:624,y:506,t:1527628357078};\\\", \\\"{x:636,y:510,t:1527628357096};\\\", \\\"{x:651,y:514,t:1527628357111};\\\", \\\"{x:670,y:519,t:1527628357129};\\\", \\\"{x:684,y:520,t:1527628357145};\\\", \\\"{x:693,y:520,t:1527628357161};\\\", \\\"{x:698,y:519,t:1527628357178};\\\", \\\"{x:705,y:519,t:1527628357195};\\\", \\\"{x:711,y:519,t:1527628357211};\\\", \\\"{x:716,y:519,t:1527628357229};\\\", \\\"{x:726,y:519,t:1527628357245};\\\", \\\"{x:737,y:518,t:1527628357261};\\\", \\\"{x:755,y:516,t:1527628357279};\\\", \\\"{x:762,y:515,t:1527628357296};\\\", \\\"{x:766,y:513,t:1527628357312};\\\", \\\"{x:774,y:511,t:1527628357328};\\\", \\\"{x:786,y:511,t:1527628357345};\\\", \\\"{x:796,y:509,t:1527628357363};\\\", \\\"{x:802,y:507,t:1527628357378};\\\", \\\"{x:810,y:505,t:1527628357396};\\\", \\\"{x:814,y:504,t:1527628357412};\\\", \\\"{x:818,y:504,t:1527628357428};\\\", \\\"{x:821,y:502,t:1527628357446};\\\", \\\"{x:823,y:501,t:1527628357463};\\\", \\\"{x:824,y:501,t:1527628357550};\\\", \\\"{x:825,y:501,t:1527628357566};\\\", \\\"{x:827,y:500,t:1527628357596};\\\", \\\"{x:829,y:499,t:1527628357612};\\\", \\\"{x:831,y:498,t:1527628357637};\\\", \\\"{x:831,y:498,t:1527628357678};\\\", \\\"{x:831,y:497,t:1527628357709};\\\", \\\"{x:831,y:496,t:1527628357725};\\\", \\\"{x:830,y:496,t:1527628357750};\\\", \\\"{x:829,y:496,t:1527628357762};\\\", \\\"{x:825,y:496,t:1527628357780};\\\", \\\"{x:816,y:500,t:1527628357796};\\\", \\\"{x:801,y:505,t:1527628357813};\\\", \\\"{x:785,y:510,t:1527628357829};\\\", \\\"{x:768,y:520,t:1527628357847};\\\", \\\"{x:729,y:535,t:1527628357863};\\\", \\\"{x:694,y:548,t:1527628357880};\\\", \\\"{x:665,y:554,t:1527628357895};\\\", \\\"{x:631,y:560,t:1527628357913};\\\", \\\"{x:597,y:565,t:1527628357930};\\\", \\\"{x:569,y:572,t:1527628357945};\\\", \\\"{x:545,y:573,t:1527628357963};\\\", \\\"{x:529,y:576,t:1527628357979};\\\", \\\"{x:517,y:577,t:1527628357995};\\\", \\\"{x:506,y:577,t:1527628358012};\\\", \\\"{x:498,y:578,t:1527628358030};\\\", \\\"{x:494,y:578,t:1527628358045};\\\", \\\"{x:481,y:582,t:1527628358062};\\\", \\\"{x:467,y:582,t:1527628358079};\\\", \\\"{x:449,y:582,t:1527628358095};\\\", \\\"{x:438,y:582,t:1527628358112};\\\", \\\"{x:431,y:582,t:1527628358129};\\\", \\\"{x:415,y:582,t:1527628358146};\\\", \\\"{x:406,y:582,t:1527628358162};\\\", \\\"{x:403,y:582,t:1527628358179};\\\", \\\"{x:402,y:581,t:1527628358230};\\\", \\\"{x:400,y:581,t:1527628358254};\\\", \\\"{x:397,y:580,t:1527628358262};\\\", \\\"{x:390,y:576,t:1527628358279};\\\", \\\"{x:376,y:573,t:1527628358296};\\\", \\\"{x:361,y:573,t:1527628358313};\\\", \\\"{x:342,y:573,t:1527628358329};\\\", \\\"{x:329,y:572,t:1527628358346};\\\", \\\"{x:310,y:572,t:1527628358362};\\\", \\\"{x:292,y:572,t:1527628358380};\\\", \\\"{x:272,y:572,t:1527628358397};\\\", \\\"{x:245,y:572,t:1527628358412};\\\", \\\"{x:223,y:570,t:1527628358429};\\\", \\\"{x:203,y:565,t:1527628358446};\\\", \\\"{x:197,y:562,t:1527628358463};\\\", \\\"{x:193,y:561,t:1527628358479};\\\", \\\"{x:192,y:561,t:1527628358497};\\\", \\\"{x:191,y:560,t:1527628358512};\\\", \\\"{x:191,y:559,t:1527628358550};\\\", \\\"{x:191,y:558,t:1527628358562};\\\", \\\"{x:190,y:556,t:1527628358579};\\\", \\\"{x:189,y:554,t:1527628358600};\\\", \\\"{x:188,y:553,t:1527628358830};\\\", \\\"{x:187,y:552,t:1527628358878};\\\", \\\"{x:186,y:551,t:1527628358894};\\\", \\\"{x:184,y:550,t:1527628358919};\\\", \\\"{x:184,y:547,t:1527628359069};\\\", \\\"{x:184,y:546,t:1527628359134};\\\", \\\"{x:184,y:545,t:1527628359146};\\\", \\\"{x:191,y:542,t:1527628359163};\\\", \\\"{x:202,y:539,t:1527628359181};\\\", \\\"{x:226,y:536,t:1527628359196};\\\", \\\"{x:258,y:533,t:1527628359213};\\\", \\\"{x:360,y:527,t:1527628359231};\\\", \\\"{x:429,y:527,t:1527628359246};\\\", \\\"{x:481,y:524,t:1527628359264};\\\", \\\"{x:532,y:515,t:1527628359280};\\\", \\\"{x:550,y:511,t:1527628359297};\\\", \\\"{x:566,y:509,t:1527628359313};\\\", \\\"{x:585,y:506,t:1527628359330};\\\", \\\"{x:610,y:505,t:1527628359346};\\\", \\\"{x:638,y:499,t:1527628359363};\\\", \\\"{x:677,y:499,t:1527628359381};\\\", \\\"{x:698,y:499,t:1527628359397};\\\", \\\"{x:722,y:499,t:1527628359413};\\\", \\\"{x:758,y:499,t:1527628359431};\\\", \\\"{x:781,y:499,t:1527628359447};\\\", \\\"{x:796,y:499,t:1527628359463};\\\", \\\"{x:807,y:499,t:1527628359480};\\\", \\\"{x:822,y:499,t:1527628359497};\\\", \\\"{x:837,y:501,t:1527628359514};\\\", \\\"{x:848,y:501,t:1527628359531};\\\", \\\"{x:852,y:501,t:1527628359547};\\\", \\\"{x:853,y:501,t:1527628359563};\\\", \\\"{x:855,y:501,t:1527628359614};\\\", \\\"{x:857,y:501,t:1527628359631};\\\", \\\"{x:859,y:501,t:1527628359648};\\\", \\\"{x:860,y:500,t:1527628359670};\\\", \\\"{x:848,y:501,t:1527628359973};\\\", \\\"{x:825,y:510,t:1527628359982};\\\", \\\"{x:794,y:520,t:1527628359998};\\\", \\\"{x:686,y:549,t:1527628360014};\\\", \\\"{x:648,y:557,t:1527628360031};\\\", \\\"{x:624,y:559,t:1527628360047};\\\", \\\"{x:588,y:570,t:1527628360065};\\\", \\\"{x:574,y:572,t:1527628360080};\\\", \\\"{x:562,y:577,t:1527628360097};\\\", \\\"{x:561,y:578,t:1527628360114};\\\", \\\"{x:558,y:582,t:1527628360131};\\\", \\\"{x:549,y:591,t:1527628360147};\\\", \\\"{x:537,y:604,t:1527628360166};\\\", \\\"{x:523,y:625,t:1527628360182};\\\", \\\"{x:521,y:628,t:1527628360197};\\\", \\\"{x:521,y:636,t:1527628360215};\\\", \\\"{x:521,y:640,t:1527628360230};\\\", \\\"{x:521,y:649,t:1527628360247};\\\", \\\"{x:525,y:656,t:1527628360265};\\\", \\\"{x:529,y:663,t:1527628360281};\\\", \\\"{x:533,y:669,t:1527628360297};\\\", \\\"{x:540,y:680,t:1527628360314};\\\", \\\"{x:543,y:688,t:1527628360331};\\\", \\\"{x:547,y:692,t:1527628360347};\\\", \\\"{x:550,y:696,t:1527628360365};\\\", \\\"{x:551,y:699,t:1527628360381};\\\", \\\"{x:551,y:704,t:1527628360398};\\\", \\\"{x:553,y:711,t:1527628360415};\\\", \\\"{x:553,y:718,t:1527628360432};\\\", \\\"{x:552,y:722,t:1527628360449};\\\", \\\"{x:552,y:723,t:1527628360464};\\\", \\\"{x:551,y:723,t:1527628360701};\\\", \\\"{x:551,y:723,t:1527628360717};\\\", \\\"{x:550,y:723,t:1527628360822};\\\", \\\"{x:548,y:723,t:1527628360942};\\\", \\\"{x:548,y:724,t:1527628360950};\\\", \\\"{x:547,y:724,t:1527628360998};\\\", \\\"{x:545,y:728,t:1527628361038};\\\", \\\"{x:544,y:728,t:1527628361054};\\\" ] }, { \\\"rt\\\": 6491, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 618244, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:702,t:1527628362372};\\\", \\\"{x:529,y:678,t:1527628362382};\\\", \\\"{x:516,y:649,t:1527628362400};\\\", \\\"{x:511,y:633,t:1527628362416};\\\", \\\"{x:506,y:610,t:1527628362433};\\\", \\\"{x:499,y:574,t:1527628362450};\\\", \\\"{x:497,y:543,t:1527628362467};\\\", \\\"{x:500,y:525,t:1527628362483};\\\", \\\"{x:510,y:507,t:1527628362500};\\\", \\\"{x:522,y:488,t:1527628362517};\\\", \\\"{x:537,y:475,t:1527628362533};\\\", \\\"{x:560,y:455,t:1527628362549};\\\", \\\"{x:574,y:443,t:1527628362565};\\\", \\\"{x:584,y:433,t:1527628362582};\\\", \\\"{x:589,y:428,t:1527628362599};\\\", \\\"{x:593,y:422,t:1527628362616};\\\", \\\"{x:596,y:419,t:1527628362633};\\\", \\\"{x:599,y:418,t:1527628362650};\\\", \\\"{x:602,y:416,t:1527628362666};\\\", \\\"{x:601,y:417,t:1527628363054};\\\", \\\"{x:598,y:419,t:1527628363068};\\\", \\\"{x:597,y:425,t:1527628363085};\\\", \\\"{x:597,y:436,t:1527628363100};\\\", \\\"{x:602,y:445,t:1527628363118};\\\", \\\"{x:611,y:452,t:1527628363134};\\\", \\\"{x:614,y:455,t:1527628363151};\\\", \\\"{x:616,y:458,t:1527628363168};\\\", \\\"{x:618,y:459,t:1527628363184};\\\", \\\"{x:621,y:461,t:1527628363201};\\\", \\\"{x:622,y:462,t:1527628363218};\\\", \\\"{x:623,y:462,t:1527628363234};\\\", \\\"{x:626,y:464,t:1527628363252};\\\", \\\"{x:633,y:466,t:1527628363268};\\\", \\\"{x:639,y:468,t:1527628363285};\\\", \\\"{x:649,y:469,t:1527628363302};\\\", \\\"{x:660,y:469,t:1527628363318};\\\", \\\"{x:678,y:469,t:1527628363334};\\\", \\\"{x:694,y:473,t:1527628363352};\\\", \\\"{x:717,y:473,t:1527628363369};\\\", \\\"{x:739,y:473,t:1527628363384};\\\", \\\"{x:758,y:473,t:1527628363402};\\\", \\\"{x:780,y:473,t:1527628363418};\\\", \\\"{x:804,y:472,t:1527628363434};\\\", \\\"{x:833,y:470,t:1527628363451};\\\", \\\"{x:867,y:470,t:1527628363468};\\\", \\\"{x:912,y:470,t:1527628363485};\\\", \\\"{x:981,y:470,t:1527628363502};\\\", \\\"{x:1079,y:470,t:1527628363518};\\\", \\\"{x:1151,y:480,t:1527628363536};\\\", \\\"{x:1223,y:489,t:1527628363552};\\\", \\\"{x:1280,y:508,t:1527628363568};\\\", \\\"{x:1318,y:522,t:1527628363585};\\\", \\\"{x:1339,y:531,t:1527628363601};\\\", \\\"{x:1352,y:545,t:1527628363619};\\\", \\\"{x:1366,y:561,t:1527628363636};\\\", \\\"{x:1383,y:584,t:1527628363653};\\\", \\\"{x:1400,y:603,t:1527628363669};\\\", \\\"{x:1426,y:635,t:1527628363685};\\\", \\\"{x:1436,y:652,t:1527628363703};\\\", \\\"{x:1441,y:664,t:1527628363719};\\\", \\\"{x:1441,y:671,t:1527628363736};\\\", \\\"{x:1441,y:681,t:1527628363753};\\\", \\\"{x:1441,y:689,t:1527628363769};\\\", \\\"{x:1441,y:702,t:1527628363786};\\\", \\\"{x:1437,y:719,t:1527628363802};\\\", \\\"{x:1428,y:740,t:1527628363820};\\\", \\\"{x:1421,y:749,t:1527628363835};\\\", \\\"{x:1397,y:768,t:1527628363853};\\\", \\\"{x:1372,y:779,t:1527628363870};\\\", \\\"{x:1350,y:781,t:1527628363886};\\\", \\\"{x:1322,y:781,t:1527628363902};\\\", \\\"{x:1299,y:781,t:1527628363919};\\\", \\\"{x:1278,y:776,t:1527628363936};\\\", \\\"{x:1274,y:775,t:1527628363953};\\\", \\\"{x:1274,y:773,t:1527628363991};\\\", \\\"{x:1274,y:770,t:1527628364003};\\\", \\\"{x:1278,y:761,t:1527628364020};\\\", \\\"{x:1286,y:750,t:1527628364037};\\\", \\\"{x:1297,y:738,t:1527628364054};\\\", \\\"{x:1312,y:722,t:1527628364070};\\\", \\\"{x:1333,y:709,t:1527628364087};\\\", \\\"{x:1345,y:704,t:1527628364103};\\\", \\\"{x:1350,y:704,t:1527628364119};\\\", \\\"{x:1353,y:704,t:1527628364223};\\\", \\\"{x:1354,y:704,t:1527628364237};\\\", \\\"{x:1357,y:704,t:1527628364255};\\\", \\\"{x:1358,y:704,t:1527628364271};\\\", \\\"{x:1359,y:704,t:1527628364287};\\\", \\\"{x:1360,y:707,t:1527628364431};\\\", \\\"{x:1360,y:711,t:1527628364438};\\\", \\\"{x:1358,y:716,t:1527628364455};\\\", \\\"{x:1356,y:722,t:1527628364471};\\\", \\\"{x:1352,y:731,t:1527628364488};\\\", \\\"{x:1350,y:736,t:1527628364505};\\\", \\\"{x:1347,y:741,t:1527628364521};\\\", \\\"{x:1347,y:745,t:1527628364538};\\\", \\\"{x:1346,y:748,t:1527628364555};\\\", \\\"{x:1344,y:751,t:1527628364571};\\\", \\\"{x:1344,y:752,t:1527628364588};\\\", \\\"{x:1343,y:754,t:1527628364605};\\\", \\\"{x:1343,y:755,t:1527628364621};\\\", \\\"{x:1343,y:756,t:1527628364638};\\\", \\\"{x:1343,y:757,t:1527628364655};\\\", \\\"{x:1343,y:758,t:1527628364673};\\\", \\\"{x:1342,y:759,t:1527628364710};\\\", \\\"{x:1341,y:759,t:1527628364736};\\\", \\\"{x:1341,y:761,t:1527628364743};\\\", \\\"{x:1340,y:762,t:1527628364781};\\\", \\\"{x:1339,y:764,t:1527628364798};\\\", \\\"{x:1338,y:764,t:1527628364805};\\\", \\\"{x:1327,y:766,t:1527628364821};\\\", \\\"{x:1311,y:769,t:1527628364837};\\\", \\\"{x:1292,y:769,t:1527628364854};\\\", \\\"{x:1254,y:767,t:1527628364871};\\\", \\\"{x:1237,y:761,t:1527628364888};\\\", \\\"{x:1204,y:754,t:1527628364905};\\\", \\\"{x:1182,y:749,t:1527628364921};\\\", \\\"{x:1139,y:743,t:1527628364938};\\\", \\\"{x:1116,y:733,t:1527628364956};\\\", \\\"{x:1082,y:728,t:1527628364971};\\\", \\\"{x:1056,y:726,t:1527628364989};\\\", \\\"{x:1003,y:722,t:1527628365005};\\\", \\\"{x:974,y:718,t:1527628365022};\\\", \\\"{x:956,y:715,t:1527628365038};\\\", \\\"{x:932,y:713,t:1527628365056};\\\", \\\"{x:913,y:711,t:1527628365073};\\\", \\\"{x:900,y:709,t:1527628365088};\\\", \\\"{x:865,y:708,t:1527628365119};\\\", \\\"{x:854,y:708,t:1527628365125};\\\", \\\"{x:843,y:708,t:1527628365138};\\\", \\\"{x:816,y:708,t:1527628365155};\\\", \\\"{x:793,y:708,t:1527628365172};\\\", \\\"{x:771,y:705,t:1527628365188};\\\", \\\"{x:742,y:702,t:1527628365205};\\\", \\\"{x:719,y:702,t:1527628365223};\\\", \\\"{x:701,y:702,t:1527628365240};\\\", \\\"{x:684,y:702,t:1527628365255};\\\", \\\"{x:671,y:702,t:1527628365273};\\\", \\\"{x:655,y:702,t:1527628365289};\\\", \\\"{x:642,y:702,t:1527628365306};\\\", \\\"{x:628,y:702,t:1527628365323};\\\", \\\"{x:618,y:702,t:1527628365340};\\\", \\\"{x:606,y:702,t:1527628365357};\\\", \\\"{x:598,y:702,t:1527628365373};\\\", \\\"{x:583,y:699,t:1527628365390};\\\", \\\"{x:577,y:698,t:1527628365406};\\\", \\\"{x:574,y:696,t:1527628365423};\\\", \\\"{x:567,y:692,t:1527628365440};\\\", \\\"{x:562,y:691,t:1527628365458};\\\", \\\"{x:551,y:686,t:1527628365473};\\\", \\\"{x:542,y:676,t:1527628365490};\\\", \\\"{x:523,y:669,t:1527628365506};\\\", \\\"{x:499,y:665,t:1527628365525};\\\", \\\"{x:483,y:662,t:1527628365540};\\\", \\\"{x:458,y:660,t:1527628365556};\\\", \\\"{x:410,y:645,t:1527628365573};\\\", \\\"{x:374,y:636,t:1527628365598};\\\", \\\"{x:360,y:632,t:1527628365614};\\\", \\\"{x:354,y:630,t:1527628365636};\\\", \\\"{x:352,y:630,t:1527628365652};\\\", \\\"{x:352,y:629,t:1527628365693};\\\", \\\"{x:352,y:628,t:1527628365701};\\\", \\\"{x:352,y:625,t:1527628365718};\\\", \\\"{x:354,y:621,t:1527628365736};\\\", \\\"{x:361,y:615,t:1527628365753};\\\", \\\"{x:369,y:606,t:1527628365769};\\\", \\\"{x:376,y:601,t:1527628365785};\\\", \\\"{x:385,y:596,t:1527628365803};\\\", \\\"{x:389,y:592,t:1527628365820};\\\", \\\"{x:392,y:589,t:1527628365835};\\\", \\\"{x:403,y:584,t:1527628365852};\\\", \\\"{x:417,y:581,t:1527628365869};\\\", \\\"{x:444,y:575,t:1527628365886};\\\", \\\"{x:468,y:569,t:1527628365902};\\\", \\\"{x:491,y:564,t:1527628365919};\\\", \\\"{x:526,y:560,t:1527628365936};\\\", \\\"{x:560,y:556,t:1527628365952};\\\", \\\"{x:590,y:549,t:1527628365969};\\\", \\\"{x:612,y:545,t:1527628365986};\\\", \\\"{x:620,y:543,t:1527628366003};\\\", \\\"{x:624,y:541,t:1527628366018};\\\", \\\"{x:624,y:540,t:1527628366036};\\\", \\\"{x:628,y:539,t:1527628366052};\\\", \\\"{x:631,y:538,t:1527628366069};\\\", \\\"{x:644,y:535,t:1527628366086};\\\", \\\"{x:651,y:535,t:1527628366102};\\\", \\\"{x:671,y:533,t:1527628366118};\\\", \\\"{x:686,y:532,t:1527628366135};\\\", \\\"{x:709,y:532,t:1527628366152};\\\", \\\"{x:728,y:532,t:1527628366171};\\\", \\\"{x:741,y:532,t:1527628366185};\\\", \\\"{x:745,y:533,t:1527628366202};\\\", \\\"{x:749,y:533,t:1527628366218};\\\", \\\"{x:753,y:534,t:1527628366236};\\\", \\\"{x:755,y:534,t:1527628366253};\\\", \\\"{x:756,y:534,t:1527628366270};\\\", \\\"{x:757,y:534,t:1527628366310};\\\", \\\"{x:759,y:534,t:1527628366374};\\\", \\\"{x:760,y:534,t:1527628366386};\\\", \\\"{x:765,y:532,t:1527628366403};\\\", \\\"{x:767,y:530,t:1527628366419};\\\", \\\"{x:768,y:532,t:1527628366494};\\\", \\\"{x:765,y:536,t:1527628366502};\\\", \\\"{x:741,y:549,t:1527628366520};\\\", \\\"{x:673,y:572,t:1527628366538};\\\", \\\"{x:586,y:591,t:1527628366552};\\\", \\\"{x:487,y:597,t:1527628366569};\\\", \\\"{x:391,y:609,t:1527628366586};\\\", \\\"{x:291,y:608,t:1527628366603};\\\", \\\"{x:261,y:607,t:1527628366621};\\\", \\\"{x:243,y:607,t:1527628366636};\\\", \\\"{x:231,y:607,t:1527628366653};\\\", \\\"{x:222,y:607,t:1527628366669};\\\", \\\"{x:221,y:607,t:1527628366686};\\\", \\\"{x:220,y:607,t:1527628366742};\\\", \\\"{x:219,y:607,t:1527628366752};\\\", \\\"{x:214,y:604,t:1527628366951};\\\", \\\"{x:209,y:603,t:1527628366958};\\\", \\\"{x:201,y:598,t:1527628366971};\\\", \\\"{x:189,y:592,t:1527628366987};\\\", \\\"{x:178,y:584,t:1527628367004};\\\", \\\"{x:174,y:580,t:1527628367020};\\\", \\\"{x:173,y:579,t:1527628367036};\\\", \\\"{x:171,y:576,t:1527628367053};\\\", \\\"{x:170,y:572,t:1527628367069};\\\", \\\"{x:169,y:571,t:1527628367086};\\\", \\\"{x:168,y:569,t:1527628367104};\\\", \\\"{x:167,y:567,t:1527628367119};\\\", \\\"{x:166,y:566,t:1527628367137};\\\", \\\"{x:165,y:564,t:1527628367153};\\\", \\\"{x:165,y:562,t:1527628367170};\\\", \\\"{x:164,y:558,t:1527628367187};\\\", \\\"{x:160,y:553,t:1527628367204};\\\", \\\"{x:158,y:546,t:1527628367220};\\\", \\\"{x:157,y:541,t:1527628367237};\\\", \\\"{x:154,y:536,t:1527628367254};\\\", \\\"{x:153,y:535,t:1527628367269};\\\", \\\"{x:157,y:535,t:1527628367493};\\\", \\\"{x:169,y:545,t:1527628367504};\\\", \\\"{x:200,y:567,t:1527628367521};\\\", \\\"{x:227,y:593,t:1527628367536};\\\", \\\"{x:265,y:625,t:1527628367554};\\\", \\\"{x:316,y:661,t:1527628367571};\\\", \\\"{x:352,y:694,t:1527628367587};\\\", \\\"{x:384,y:717,t:1527628367604};\\\", \\\"{x:400,y:727,t:1527628367621};\\\", \\\"{x:411,y:735,t:1527628367637};\\\", \\\"{x:415,y:739,t:1527628367653};\\\", \\\"{x:416,y:740,t:1527628367678};\\\", \\\"{x:419,y:741,t:1527628367694};\\\", \\\"{x:425,y:741,t:1527628367719};\\\", \\\"{x:432,y:741,t:1527628367727};\\\", \\\"{x:435,y:741,t:1527628367737};\\\", \\\"{x:440,y:737,t:1527628367754};\\\", \\\"{x:445,y:733,t:1527628367772};\\\", \\\"{x:447,y:731,t:1527628367788};\\\", \\\"{x:451,y:727,t:1527628367804};\\\", \\\"{x:452,y:726,t:1527628367820};\\\", \\\"{x:454,y:724,t:1527628367837};\\\", \\\"{x:459,y:723,t:1527628367854};\\\", \\\"{x:467,y:721,t:1527628367870};\\\", \\\"{x:470,y:720,t:1527628367887};\\\", \\\"{x:473,y:720,t:1527628367904};\\\", \\\"{x:473,y:719,t:1527628367936};\\\", \\\"{x:474,y:719,t:1527628367954};\\\", \\\"{x:476,y:719,t:1527628367971};\\\", \\\"{x:476,y:719,t:1527628368038};\\\", \\\"{x:477,y:719,t:1527628368254};\\\", \\\"{x:477,y:722,t:1527628368271};\\\", \\\"{x:478,y:724,t:1527628368287};\\\", \\\"{x:481,y:728,t:1527628368303};\\\", \\\"{x:482,y:729,t:1527628368326};\\\", \\\"{x:476,y:727,t:1527628368831};\\\", \\\"{x:467,y:724,t:1527628368838};\\\", \\\"{x:449,y:711,t:1527628368855};\\\", \\\"{x:432,y:700,t:1527628368872};\\\", \\\"{x:422,y:688,t:1527628368888};\\\", \\\"{x:408,y:676,t:1527628368904};\\\", \\\"{x:397,y:659,t:1527628368921};\\\", \\\"{x:387,y:640,t:1527628368938};\\\", \\\"{x:377,y:609,t:1527628368955};\\\", \\\"{x:368,y:576,t:1527628368972};\\\", \\\"{x:356,y:532,t:1527628368988};\\\", \\\"{x:345,y:472,t:1527628369005};\\\", \\\"{x:340,y:429,t:1527628369022};\\\", \\\"{x:340,y:416,t:1527628369038};\\\", \\\"{x:355,y:387,t:1527628369055};\\\", \\\"{x:383,y:343,t:1527628369072};\\\", \\\"{x:411,y:324,t:1527628369089};\\\", \\\"{x:449,y:296,t:1527628369105};\\\", \\\"{x:480,y:275,t:1527628369122};\\\", \\\"{x:530,y:250,t:1527628369138};\\\", \\\"{x:586,y:204,t:1527628369155};\\\", \\\"{x:688,y:147,t:1527628369171};\\\", \\\"{x:769,y:116,t:1527628369188};\\\", \\\"{x:860,y:93,t:1527628369204};\\\", \\\"{x:1012,y:83,t:1527628369221};\\\", \\\"{x:1109,y:98,t:1527628369238};\\\", \\\"{x:1187,y:120,t:1527628369255};\\\", \\\"{x:1240,y:152,t:1527628369272};\\\", \\\"{x:1264,y:181,t:1527628369288};\\\", \\\"{x:1276,y:223,t:1527628369305};\\\", \\\"{x:1284,y:267,t:1527628369321};\\\", \\\"{x:1284,y:311,t:1527628369338};\\\", \\\"{x:1282,y:360,t:1527628369355};\\\", \\\"{x:1261,y:412,t:1527628369372};\\\", \\\"{x:1241,y:459,t:1527628369388};\\\", \\\"{x:1200,y:510,t:1527628369405};\\\", \\\"{x:1158,y:552,t:1527628369421};\\\", \\\"{x:1086,y:583,t:1527628369439};\\\", \\\"{x:986,y:611,t:1527628369455};\\\", \\\"{x:895,y:620,t:1527628369472};\\\", \\\"{x:821,y:618,t:1527628369489};\\\", \\\"{x:749,y:600,t:1527628369505};\\\", \\\"{x:668,y:571,t:1527628369522};\\\" ] }, { \\\"rt\\\": 20451, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 639993, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X -O -X -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:628,y:148,t:1527628369725};\\\", \\\"{x:668,y:133,t:1527628369739};\\\", \\\"{x:692,y:124,t:1527628369757};\\\", \\\"{x:712,y:117,t:1527628369771};\\\", \\\"{x:718,y:117,t:1527628369789};\\\", \\\"{x:719,y:117,t:1527628369811};\\\", \\\"{x:718,y:118,t:1527628370159};\\\", \\\"{x:710,y:124,t:1527628370172};\\\", \\\"{x:705,y:133,t:1527628370189};\\\", \\\"{x:697,y:156,t:1527628370206};\\\", \\\"{x:693,y:166,t:1527628370223};\\\", \\\"{x:669,y:238,t:1527628370304};\\\", \\\"{x:661,y:247,t:1527628370310};\\\", \\\"{x:655,y:253,t:1527628370323};\\\", \\\"{x:640,y:277,t:1527628370339};\\\", \\\"{x:624,y:299,t:1527628370356};\\\", \\\"{x:613,y:312,t:1527628370373};\\\", \\\"{x:597,y:328,t:1527628370389};\\\", \\\"{x:578,y:349,t:1527628370405};\\\", \\\"{x:563,y:362,t:1527628370423};\\\", \\\"{x:550,y:371,t:1527628370440};\\\", \\\"{x:540,y:382,t:1527628370455};\\\", \\\"{x:530,y:391,t:1527628370473};\\\", \\\"{x:527,y:397,t:1527628370489};\\\", \\\"{x:524,y:401,t:1527628370506};\\\", \\\"{x:523,y:402,t:1527628370522};\\\", \\\"{x:522,y:405,t:1527628370539};\\\", \\\"{x:521,y:409,t:1527628370555};\\\", \\\"{x:519,y:415,t:1527628370573};\\\", \\\"{x:519,y:420,t:1527628370589};\\\", \\\"{x:519,y:424,t:1527628370606};\\\", \\\"{x:519,y:428,t:1527628370622};\\\", \\\"{x:519,y:430,t:1527628370639};\\\", \\\"{x:520,y:432,t:1527628370656};\\\", \\\"{x:522,y:434,t:1527628370673};\\\", \\\"{x:522,y:437,t:1527628370690};\\\", \\\"{x:523,y:437,t:1527628370706};\\\", \\\"{x:523,y:438,t:1527628370723};\\\", \\\"{x:523,y:439,t:1527628370750};\\\", \\\"{x:524,y:439,t:1527628370806};\\\", \\\"{x:522,y:439,t:1527628370895};\\\", \\\"{x:517,y:440,t:1527628370907};\\\", \\\"{x:500,y:442,t:1527628370924};\\\", \\\"{x:485,y:444,t:1527628370940};\\\", \\\"{x:470,y:444,t:1527628370958};\\\", \\\"{x:458,y:444,t:1527628370974};\\\", \\\"{x:431,y:444,t:1527628370990};\\\", \\\"{x:413,y:440,t:1527628371007};\\\", \\\"{x:405,y:439,t:1527628371023};\\\", \\\"{x:398,y:438,t:1527628371040};\\\", \\\"{x:394,y:437,t:1527628371057};\\\", \\\"{x:393,y:437,t:1527628371111};\\\", \\\"{x:393,y:438,t:1527628371199};\\\", \\\"{x:391,y:439,t:1527628371207};\\\", \\\"{x:391,y:441,t:1527628371224};\\\", \\\"{x:393,y:445,t:1527628371240};\\\", \\\"{x:399,y:451,t:1527628371257};\\\", \\\"{x:405,y:454,t:1527628371273};\\\", \\\"{x:411,y:455,t:1527628371290};\\\", \\\"{x:415,y:458,t:1527628371307};\\\", \\\"{x:418,y:458,t:1527628371324};\\\", \\\"{x:419,y:459,t:1527628371342};\\\", \\\"{x:420,y:459,t:1527628371357};\\\", \\\"{x:430,y:462,t:1527628371374};\\\", \\\"{x:438,y:466,t:1527628371390};\\\", \\\"{x:447,y:468,t:1527628371407};\\\", \\\"{x:458,y:468,t:1527628371424};\\\", \\\"{x:470,y:468,t:1527628371440};\\\", \\\"{x:479,y:468,t:1527628371457};\\\", \\\"{x:482,y:468,t:1527628371474};\\\", \\\"{x:483,y:468,t:1527628371490};\\\", \\\"{x:484,y:468,t:1527628371507};\\\", \\\"{x:485,y:468,t:1527628371542};\\\", \\\"{x:486,y:468,t:1527628371557};\\\", \\\"{x:498,y:467,t:1527628371574};\\\", \\\"{x:508,y:467,t:1527628371590};\\\", \\\"{x:528,y:467,t:1527628371607};\\\", \\\"{x:547,y:467,t:1527628371624};\\\", \\\"{x:570,y:467,t:1527628371641};\\\", \\\"{x:585,y:467,t:1527628371657};\\\", \\\"{x:592,y:467,t:1527628371674};\\\", \\\"{x:595,y:466,t:1527628371690};\\\", \\\"{x:595,y:464,t:1527628371734};\\\", \\\"{x:597,y:462,t:1527628371742};\\\", \\\"{x:598,y:462,t:1527628371757};\\\", \\\"{x:599,y:461,t:1527628371774};\\\", \\\"{x:600,y:460,t:1527628371790};\\\", \\\"{x:603,y:461,t:1527628371935};\\\", \\\"{x:610,y:466,t:1527628371942};\\\", \\\"{x:615,y:471,t:1527628371958};\\\", \\\"{x:639,y:478,t:1527628371974};\\\", \\\"{x:678,y:489,t:1527628371993};\\\", \\\"{x:720,y:495,t:1527628372007};\\\", \\\"{x:776,y:504,t:1527628372024};\\\", \\\"{x:822,y:506,t:1527628372039};\\\", \\\"{x:872,y:514,t:1527628372056};\\\", \\\"{x:891,y:519,t:1527628372071};\\\", \\\"{x:906,y:527,t:1527628372089};\\\", \\\"{x:933,y:531,t:1527628372106};\\\", \\\"{x:950,y:536,t:1527628372123};\\\", \\\"{x:964,y:539,t:1527628372141};\\\", \\\"{x:985,y:541,t:1527628372157};\\\", \\\"{x:1004,y:541,t:1527628372174};\\\", \\\"{x:1024,y:543,t:1527628372191};\\\", \\\"{x:1047,y:544,t:1527628372208};\\\", \\\"{x:1070,y:547,t:1527628372224};\\\", \\\"{x:1092,y:550,t:1527628372241};\\\", \\\"{x:1112,y:554,t:1527628372258};\\\", \\\"{x:1125,y:556,t:1527628372274};\\\", \\\"{x:1148,y:561,t:1527628372291};\\\", \\\"{x:1176,y:566,t:1527628372308};\\\", \\\"{x:1203,y:572,t:1527628372324};\\\", \\\"{x:1238,y:580,t:1527628372341};\\\", \\\"{x:1314,y:595,t:1527628372358};\\\", \\\"{x:1373,y:605,t:1527628372374};\\\", \\\"{x:1412,y:615,t:1527628372391};\\\", \\\"{x:1438,y:618,t:1527628372407};\\\", \\\"{x:1462,y:623,t:1527628372424};\\\", \\\"{x:1483,y:627,t:1527628372441};\\\", \\\"{x:1502,y:631,t:1527628372458};\\\", \\\"{x:1509,y:636,t:1527628372474};\\\", \\\"{x:1518,y:638,t:1527628372491};\\\", \\\"{x:1522,y:641,t:1527628372509};\\\", \\\"{x:1527,y:644,t:1527628372524};\\\", \\\"{x:1534,y:647,t:1527628372541};\\\", \\\"{x:1543,y:650,t:1527628372558};\\\", \\\"{x:1543,y:652,t:1527628373127};\\\", \\\"{x:1543,y:653,t:1527628373142};\\\", \\\"{x:1543,y:659,t:1527628373158};\\\", \\\"{x:1543,y:660,t:1527628373176};\\\", \\\"{x:1543,y:662,t:1527628373192};\\\", \\\"{x:1543,y:666,t:1527628373209};\\\", \\\"{x:1543,y:675,t:1527628373226};\\\", \\\"{x:1548,y:689,t:1527628373242};\\\", \\\"{x:1555,y:705,t:1527628373258};\\\", \\\"{x:1559,y:716,t:1527628373276};\\\", \\\"{x:1563,y:722,t:1527628373292};\\\", \\\"{x:1566,y:728,t:1527628373308};\\\", \\\"{x:1567,y:731,t:1527628373325};\\\", \\\"{x:1570,y:736,t:1527628373343};\\\", \\\"{x:1572,y:741,t:1527628373359};\\\", \\\"{x:1574,y:743,t:1527628373375};\\\", \\\"{x:1577,y:746,t:1527628373393};\\\", \\\"{x:1579,y:749,t:1527628373409};\\\", \\\"{x:1582,y:753,t:1527628373426};\\\", \\\"{x:1583,y:755,t:1527628373443};\\\", \\\"{x:1584,y:755,t:1527628373459};\\\", \\\"{x:1582,y:754,t:1527628373598};\\\", \\\"{x:1580,y:751,t:1527628373608};\\\", \\\"{x:1573,y:737,t:1527628373625};\\\", \\\"{x:1564,y:718,t:1527628373642};\\\", \\\"{x:1553,y:693,t:1527628373658};\\\", \\\"{x:1541,y:650,t:1527628373674};\\\", \\\"{x:1532,y:589,t:1527628373692};\\\", \\\"{x:1530,y:563,t:1527628373708};\\\", \\\"{x:1528,y:539,t:1527628373725};\\\", \\\"{x:1527,y:525,t:1527628373741};\\\", \\\"{x:1528,y:518,t:1527628373759};\\\", \\\"{x:1529,y:512,t:1527628373775};\\\", \\\"{x:1529,y:508,t:1527628373792};\\\", \\\"{x:1531,y:502,t:1527628373809};\\\", \\\"{x:1533,y:499,t:1527628373825};\\\", \\\"{x:1534,y:493,t:1527628373842};\\\", \\\"{x:1535,y:483,t:1527628373860};\\\", \\\"{x:1537,y:474,t:1527628373875};\\\", \\\"{x:1537,y:469,t:1527628373892};\\\", \\\"{x:1538,y:462,t:1527628373910};\\\", \\\"{x:1541,y:450,t:1527628373926};\\\", \\\"{x:1543,y:440,t:1527628373943};\\\", \\\"{x:1544,y:431,t:1527628373960};\\\", \\\"{x:1545,y:424,t:1527628373976};\\\", \\\"{x:1545,y:415,t:1527628373992};\\\", \\\"{x:1545,y:404,t:1527628374009};\\\", \\\"{x:1545,y:397,t:1527628374026};\\\", \\\"{x:1543,y:386,t:1527628374042};\\\", \\\"{x:1540,y:379,t:1527628374059};\\\", \\\"{x:1537,y:372,t:1527628374075};\\\", \\\"{x:1534,y:367,t:1527628374092};\\\", \\\"{x:1532,y:365,t:1527628374110};\\\", \\\"{x:1530,y:361,t:1527628374126};\\\", \\\"{x:1525,y:357,t:1527628374142};\\\", \\\"{x:1524,y:355,t:1527628374159};\\\", \\\"{x:1522,y:354,t:1527628374182};\\\", \\\"{x:1521,y:354,t:1527628374239};\\\", \\\"{x:1521,y:353,t:1527628374256};\\\", \\\"{x:1515,y:353,t:1527628374263};\\\", \\\"{x:1509,y:353,t:1527628374277};\\\", \\\"{x:1501,y:353,t:1527628374293};\\\", \\\"{x:1494,y:352,t:1527628374309};\\\", \\\"{x:1485,y:352,t:1527628374326};\\\", \\\"{x:1479,y:352,t:1527628374342};\\\", \\\"{x:1475,y:352,t:1527628374360};\\\", \\\"{x:1473,y:352,t:1527628374377};\\\", \\\"{x:1471,y:354,t:1527628374446};\\\", \\\"{x:1471,y:355,t:1527628374470};\\\", \\\"{x:1471,y:356,t:1527628374479};\\\", \\\"{x:1471,y:357,t:1527628374493};\\\", \\\"{x:1471,y:359,t:1527628374510};\\\", \\\"{x:1471,y:363,t:1527628374526};\\\", \\\"{x:1472,y:366,t:1527628374543};\\\", \\\"{x:1476,y:372,t:1527628374560};\\\", \\\"{x:1480,y:379,t:1527628374577};\\\", \\\"{x:1489,y:393,t:1527628374592};\\\", \\\"{x:1501,y:409,t:1527628374610};\\\", \\\"{x:1513,y:426,t:1527628374626};\\\", \\\"{x:1523,y:442,t:1527628374643};\\\", \\\"{x:1532,y:459,t:1527628374659};\\\", \\\"{x:1539,y:478,t:1527628374676};\\\", \\\"{x:1549,y:495,t:1527628374693};\\\", \\\"{x:1555,y:510,t:1527628374710};\\\", \\\"{x:1560,y:529,t:1527628374726};\\\", \\\"{x:1563,y:537,t:1527628374744};\\\", \\\"{x:1563,y:552,t:1527628374760};\\\", \\\"{x:1563,y:567,t:1527628374776};\\\", \\\"{x:1559,y:579,t:1527628374794};\\\", \\\"{x:1556,y:590,t:1527628374809};\\\", \\\"{x:1552,y:606,t:1527628374827};\\\", \\\"{x:1543,y:621,t:1527628374843};\\\", \\\"{x:1537,y:634,t:1527628374859};\\\", \\\"{x:1533,y:649,t:1527628374876};\\\", \\\"{x:1530,y:660,t:1527628374894};\\\", \\\"{x:1530,y:667,t:1527628374910};\\\", \\\"{x:1530,y:677,t:1527628374927};\\\", \\\"{x:1532,y:683,t:1527628374943};\\\", \\\"{x:1537,y:687,t:1527628374960};\\\", \\\"{x:1541,y:690,t:1527628374976};\\\", \\\"{x:1549,y:695,t:1527628374993};\\\", \\\"{x:1558,y:699,t:1527628375010};\\\", \\\"{x:1565,y:702,t:1527628375027};\\\", \\\"{x:1576,y:704,t:1527628375043};\\\", \\\"{x:1584,y:705,t:1527628375059};\\\", \\\"{x:1588,y:706,t:1527628375076};\\\", \\\"{x:1591,y:706,t:1527628375093};\\\", \\\"{x:1592,y:706,t:1527628375109};\\\", \\\"{x:1594,y:706,t:1527628375126};\\\", \\\"{x:1596,y:706,t:1527628375144};\\\", \\\"{x:1597,y:706,t:1527628375159};\\\", \\\"{x:1598,y:706,t:1527628375206};\\\", \\\"{x:1599,y:706,t:1527628375214};\\\", \\\"{x:1601,y:706,t:1527628375226};\\\", \\\"{x:1602,y:706,t:1527628375243};\\\", \\\"{x:1603,y:706,t:1527628375260};\\\", \\\"{x:1604,y:706,t:1527628375277};\\\", \\\"{x:1605,y:706,t:1527628375294};\\\", \\\"{x:1606,y:706,t:1527628375310};\\\", \\\"{x:1607,y:706,t:1527628375383};\\\", \\\"{x:1608,y:706,t:1527628375399};\\\", \\\"{x:1610,y:706,t:1527628375487};\\\", \\\"{x:1611,y:705,t:1527628375527};\\\", \\\"{x:1611,y:704,t:1527628375544};\\\", \\\"{x:1612,y:704,t:1527628375560};\\\", \\\"{x:1612,y:703,t:1527628375598};\\\", \\\"{x:1613,y:704,t:1527628376255};\\\", \\\"{x:1613,y:705,t:1527628376262};\\\", \\\"{x:1613,y:707,t:1527628376278};\\\", \\\"{x:1614,y:713,t:1527628376295};\\\", \\\"{x:1614,y:717,t:1527628376310};\\\", \\\"{x:1614,y:721,t:1527628376327};\\\", \\\"{x:1614,y:728,t:1527628376344};\\\", \\\"{x:1614,y:734,t:1527628376360};\\\", \\\"{x:1614,y:742,t:1527628376377};\\\", \\\"{x:1614,y:758,t:1527628376395};\\\", \\\"{x:1614,y:769,t:1527628376411};\\\", \\\"{x:1614,y:780,t:1527628376428};\\\", \\\"{x:1618,y:795,t:1527628376445};\\\", \\\"{x:1619,y:809,t:1527628376460};\\\", \\\"{x:1619,y:820,t:1527628376478};\\\", \\\"{x:1620,y:834,t:1527628376494};\\\", \\\"{x:1621,y:859,t:1527628376510};\\\", \\\"{x:1621,y:872,t:1527628376528};\\\", \\\"{x:1621,y:883,t:1527628376544};\\\", \\\"{x:1622,y:889,t:1527628376561};\\\", \\\"{x:1622,y:891,t:1527628376578};\\\", \\\"{x:1622,y:894,t:1527628376595};\\\", \\\"{x:1622,y:896,t:1527628376610};\\\", \\\"{x:1622,y:901,t:1527628376627};\\\", \\\"{x:1622,y:904,t:1527628376644};\\\", \\\"{x:1622,y:909,t:1527628376661};\\\", \\\"{x:1622,y:913,t:1527628376678};\\\", \\\"{x:1621,y:918,t:1527628376694};\\\", \\\"{x:1620,y:920,t:1527628376711};\\\", \\\"{x:1619,y:921,t:1527628376728};\\\", \\\"{x:1619,y:922,t:1527628376744};\\\", \\\"{x:1618,y:926,t:1527628376761};\\\", \\\"{x:1618,y:930,t:1527628376777};\\\", \\\"{x:1618,y:935,t:1527628376795};\\\", \\\"{x:1618,y:936,t:1527628376811};\\\", \\\"{x:1618,y:940,t:1527628376828};\\\", \\\"{x:1618,y:942,t:1527628376846};\\\", \\\"{x:1618,y:943,t:1527628376862};\\\", \\\"{x:1616,y:945,t:1527628376878};\\\", \\\"{x:1616,y:946,t:1527628376895};\\\", \\\"{x:1616,y:948,t:1527628376918};\\\", \\\"{x:1616,y:949,t:1527628376967};\\\", \\\"{x:1616,y:950,t:1527628376977};\\\", \\\"{x:1617,y:951,t:1527628376995};\\\", \\\"{x:1617,y:952,t:1527628377012};\\\", \\\"{x:1617,y:954,t:1527628377027};\\\", \\\"{x:1617,y:956,t:1527628377045};\\\", \\\"{x:1619,y:957,t:1527628377062};\\\", \\\"{x:1619,y:958,t:1527628377086};\\\", \\\"{x:1619,y:959,t:1527628377191};\\\", \\\"{x:1619,y:961,t:1527628377295};\\\", \\\"{x:1619,y:962,t:1527628377311};\\\", \\\"{x:1620,y:964,t:1527628377328};\\\", \\\"{x:1619,y:964,t:1527628377469};\\\", \\\"{x:1616,y:961,t:1527628377476};\\\", \\\"{x:1614,y:956,t:1527628377494};\\\", \\\"{x:1608,y:945,t:1527628377510};\\\", \\\"{x:1601,y:937,t:1527628377528};\\\", \\\"{x:1594,y:921,t:1527628377544};\\\", \\\"{x:1586,y:910,t:1527628377561};\\\", \\\"{x:1574,y:897,t:1527628377578};\\\", \\\"{x:1564,y:886,t:1527628377594};\\\", \\\"{x:1552,y:875,t:1527628377611};\\\", \\\"{x:1544,y:870,t:1527628377628};\\\", \\\"{x:1537,y:863,t:1527628377644};\\\", \\\"{x:1531,y:855,t:1527628377661};\\\", \\\"{x:1524,y:845,t:1527628377678};\\\", \\\"{x:1521,y:842,t:1527628377694};\\\", \\\"{x:1519,y:839,t:1527628377711};\\\", \\\"{x:1516,y:835,t:1527628377728};\\\", \\\"{x:1513,y:833,t:1527628377744};\\\", \\\"{x:1509,y:830,t:1527628377761};\\\", \\\"{x:1506,y:828,t:1527628377779};\\\", \\\"{x:1505,y:828,t:1527628377895};\\\", \\\"{x:1504,y:828,t:1527628377991};\\\", \\\"{x:1503,y:828,t:1527628378014};\\\", \\\"{x:1502,y:828,t:1527628378030};\\\", \\\"{x:1500,y:828,t:1527628378046};\\\", \\\"{x:1493,y:828,t:1527628378062};\\\", \\\"{x:1490,y:829,t:1527628378078};\\\", \\\"{x:1488,y:829,t:1527628378096};\\\", \\\"{x:1486,y:830,t:1527628378114};\\\", \\\"{x:1483,y:830,t:1527628378128};\\\", \\\"{x:1481,y:830,t:1527628378510};\\\", \\\"{x:1480,y:830,t:1527628378526};\\\", \\\"{x:1479,y:830,t:1527628378534};\\\", \\\"{x:1478,y:830,t:1527628379983};\\\", \\\"{x:1477,y:830,t:1527628379997};\\\", \\\"{x:1477,y:829,t:1527628380013};\\\", \\\"{x:1477,y:828,t:1527628380029};\\\", \\\"{x:1477,y:826,t:1527628380046};\\\", \\\"{x:1477,y:825,t:1527628380072};\\\", \\\"{x:1476,y:824,t:1527628380119};\\\", \\\"{x:1475,y:822,t:1527628380142};\\\", \\\"{x:1475,y:821,t:1527628380150};\\\", \\\"{x:1474,y:820,t:1527628380163};\\\", \\\"{x:1474,y:819,t:1527628380180};\\\", \\\"{x:1474,y:817,t:1527628380198};\\\", \\\"{x:1474,y:815,t:1527628380214};\\\", \\\"{x:1474,y:813,t:1527628380230};\\\", \\\"{x:1474,y:810,t:1527628380247};\\\", \\\"{x:1474,y:806,t:1527628380264};\\\", \\\"{x:1474,y:802,t:1527628380279};\\\", \\\"{x:1474,y:800,t:1527628380296};\\\", \\\"{x:1474,y:799,t:1527628380314};\\\", \\\"{x:1474,y:797,t:1527628380330};\\\", \\\"{x:1473,y:794,t:1527628380347};\\\", \\\"{x:1473,y:793,t:1527628380364};\\\", \\\"{x:1472,y:790,t:1527628380380};\\\", \\\"{x:1470,y:787,t:1527628380397};\\\", \\\"{x:1470,y:785,t:1527628380414};\\\", \\\"{x:1466,y:780,t:1527628380430};\\\", \\\"{x:1464,y:776,t:1527628380447};\\\", \\\"{x:1464,y:775,t:1527628380464};\\\", \\\"{x:1463,y:773,t:1527628380480};\\\", \\\"{x:1462,y:771,t:1527628380509};\\\", \\\"{x:1461,y:770,t:1527628380533};\\\", \\\"{x:1461,y:769,t:1527628380630};\\\", \\\"{x:1457,y:769,t:1527628380646};\\\", \\\"{x:1444,y:769,t:1527628380663};\\\", \\\"{x:1428,y:769,t:1527628380680};\\\", \\\"{x:1416,y:769,t:1527628380696};\\\", \\\"{x:1402,y:768,t:1527628380713};\\\", \\\"{x:1398,y:768,t:1527628380730};\\\", \\\"{x:1399,y:767,t:1527628380846};\\\", \\\"{x:1403,y:765,t:1527628380864};\\\", \\\"{x:1407,y:764,t:1527628380881};\\\", \\\"{x:1409,y:763,t:1527628380897};\\\", \\\"{x:1410,y:763,t:1527628380914};\\\", \\\"{x:1412,y:761,t:1527628380931};\\\", \\\"{x:1413,y:761,t:1527628380983};\\\", \\\"{x:1415,y:760,t:1527628381062};\\\", \\\"{x:1417,y:759,t:1527628381094};\\\", \\\"{x:1419,y:759,t:1527628381110};\\\", \\\"{x:1420,y:759,t:1527628381134};\\\", \\\"{x:1421,y:758,t:1527628381382};\\\", \\\"{x:1424,y:758,t:1527628381807};\\\", \\\"{x:1429,y:758,t:1527628381814};\\\", \\\"{x:1443,y:758,t:1527628381830};\\\", \\\"{x:1450,y:758,t:1527628381848};\\\", \\\"{x:1457,y:758,t:1527628381865};\\\", \\\"{x:1460,y:758,t:1527628381880};\\\", \\\"{x:1461,y:758,t:1527628381898};\\\", \\\"{x:1463,y:758,t:1527628381942};\\\", \\\"{x:1465,y:758,t:1527628381958};\\\", \\\"{x:1467,y:758,t:1527628381966};\\\", \\\"{x:1471,y:758,t:1527628381981};\\\", \\\"{x:1478,y:758,t:1527628381998};\\\", \\\"{x:1483,y:758,t:1527628382015};\\\", \\\"{x:1486,y:757,t:1527628382032};\\\", \\\"{x:1488,y:755,t:1527628382382};\\\", \\\"{x:1494,y:755,t:1527628382398};\\\", \\\"{x:1503,y:755,t:1527628382415};\\\", \\\"{x:1508,y:755,t:1527628382432};\\\", \\\"{x:1513,y:755,t:1527628382448};\\\", \\\"{x:1515,y:755,t:1527628382464};\\\", \\\"{x:1517,y:755,t:1527628382481};\\\", \\\"{x:1518,y:755,t:1527628382499};\\\", \\\"{x:1520,y:755,t:1527628382515};\\\", \\\"{x:1520,y:754,t:1527628382532};\\\", \\\"{x:1521,y:754,t:1527628382549};\\\", \\\"{x:1522,y:754,t:1527628382565};\\\", \\\"{x:1523,y:753,t:1527628382582};\\\", \\\"{x:1524,y:753,t:1527628382630};\\\", \\\"{x:1525,y:753,t:1527628382694};\\\", \\\"{x:1525,y:752,t:1527628383694};\\\", \\\"{x:1525,y:754,t:1527628383702};\\\", \\\"{x:1525,y:757,t:1527628383715};\\\", \\\"{x:1521,y:768,t:1527628383732};\\\", \\\"{x:1514,y:777,t:1527628383749};\\\", \\\"{x:1510,y:782,t:1527628383766};\\\", \\\"{x:1505,y:791,t:1527628383782};\\\", \\\"{x:1504,y:797,t:1527628383799};\\\", \\\"{x:1499,y:809,t:1527628383816};\\\", \\\"{x:1490,y:821,t:1527628383833};\\\", \\\"{x:1487,y:828,t:1527628383849};\\\", \\\"{x:1482,y:835,t:1527628383866};\\\", \\\"{x:1473,y:846,t:1527628383884};\\\", \\\"{x:1468,y:853,t:1527628383900};\\\", \\\"{x:1462,y:862,t:1527628383916};\\\", \\\"{x:1459,y:867,t:1527628383932};\\\", \\\"{x:1457,y:871,t:1527628383948};\\\", \\\"{x:1454,y:874,t:1527628383965};\\\", \\\"{x:1452,y:876,t:1527628383982};\\\", \\\"{x:1451,y:877,t:1527628383998};\\\", \\\"{x:1448,y:878,t:1527628384015};\\\", \\\"{x:1443,y:882,t:1527628384032};\\\", \\\"{x:1442,y:882,t:1527628384050};\\\", \\\"{x:1441,y:883,t:1527628384069};\\\", \\\"{x:1439,y:884,t:1527628384093};\\\", \\\"{x:1438,y:885,t:1527628384117};\\\", \\\"{x:1437,y:885,t:1527628384133};\\\", \\\"{x:1435,y:885,t:1527628384149};\\\", \\\"{x:1432,y:886,t:1527628384166};\\\", \\\"{x:1431,y:887,t:1527628384191};\\\", \\\"{x:1429,y:888,t:1527628384205};\\\", \\\"{x:1428,y:889,t:1527628384216};\\\", \\\"{x:1423,y:890,t:1527628384232};\\\", \\\"{x:1422,y:890,t:1527628384250};\\\", \\\"{x:1421,y:890,t:1527628384265};\\\", \\\"{x:1420,y:890,t:1527628384282};\\\", \\\"{x:1418,y:891,t:1527628384300};\\\", \\\"{x:1417,y:891,t:1527628384315};\\\", \\\"{x:1414,y:892,t:1527628384332};\\\", \\\"{x:1409,y:894,t:1527628384349};\\\", \\\"{x:1407,y:894,t:1527628384366};\\\", \\\"{x:1403,y:895,t:1527628384383};\\\", \\\"{x:1401,y:895,t:1527628384399};\\\", \\\"{x:1400,y:895,t:1527628384416};\\\", \\\"{x:1399,y:895,t:1527628384438};\\\", \\\"{x:1398,y:895,t:1527628384456};\\\", \\\"{x:1396,y:895,t:1527628384519};\\\", \\\"{x:1394,y:895,t:1527628384533};\\\", \\\"{x:1384,y:895,t:1527628384550};\\\", \\\"{x:1378,y:895,t:1527628384566};\\\", \\\"{x:1373,y:894,t:1527628384584};\\\", \\\"{x:1368,y:893,t:1527628384600};\\\", \\\"{x:1366,y:890,t:1527628384617};\\\", \\\"{x:1362,y:887,t:1527628384632};\\\", \\\"{x:1359,y:885,t:1527628384650};\\\", \\\"{x:1357,y:884,t:1527628384667};\\\", \\\"{x:1355,y:883,t:1527628384683};\\\", \\\"{x:1354,y:879,t:1527628384700};\\\", \\\"{x:1352,y:873,t:1527628384716};\\\", \\\"{x:1351,y:868,t:1527628384732};\\\", \\\"{x:1348,y:859,t:1527628384750};\\\", \\\"{x:1346,y:856,t:1527628384766};\\\", \\\"{x:1344,y:850,t:1527628384782};\\\", \\\"{x:1342,y:845,t:1527628384800};\\\", \\\"{x:1342,y:842,t:1527628384817};\\\", \\\"{x:1341,y:839,t:1527628384833};\\\", \\\"{x:1340,y:834,t:1527628384850};\\\", \\\"{x:1337,y:830,t:1527628384867};\\\", \\\"{x:1337,y:827,t:1527628384883};\\\", \\\"{x:1336,y:823,t:1527628384899};\\\", \\\"{x:1336,y:819,t:1527628384917};\\\", \\\"{x:1336,y:814,t:1527628384933};\\\", \\\"{x:1338,y:806,t:1527628384950};\\\", \\\"{x:1339,y:802,t:1527628384966};\\\", \\\"{x:1342,y:795,t:1527628384983};\\\", \\\"{x:1343,y:790,t:1527628385000};\\\", \\\"{x:1347,y:781,t:1527628385017};\\\", \\\"{x:1350,y:774,t:1527628385033};\\\", \\\"{x:1351,y:771,t:1527628385050};\\\", \\\"{x:1354,y:768,t:1527628385067};\\\", \\\"{x:1356,y:763,t:1527628385084};\\\", \\\"{x:1359,y:758,t:1527628385101};\\\", \\\"{x:1361,y:752,t:1527628385116};\\\", \\\"{x:1366,y:745,t:1527628385134};\\\", \\\"{x:1367,y:742,t:1527628385150};\\\", \\\"{x:1370,y:735,t:1527628385166};\\\", \\\"{x:1374,y:727,t:1527628385184};\\\", \\\"{x:1376,y:721,t:1527628385200};\\\", \\\"{x:1381,y:712,t:1527628385216};\\\", \\\"{x:1384,y:703,t:1527628385234};\\\", \\\"{x:1386,y:698,t:1527628385250};\\\", \\\"{x:1387,y:695,t:1527628385267};\\\", \\\"{x:1388,y:693,t:1527628385284};\\\", \\\"{x:1389,y:692,t:1527628385300};\\\", \\\"{x:1389,y:691,t:1527628385503};\\\", \\\"{x:1387,y:691,t:1527628385517};\\\", \\\"{x:1381,y:691,t:1527628385534};\\\", \\\"{x:1377,y:692,t:1527628385550};\\\", \\\"{x:1376,y:692,t:1527628385567};\\\", \\\"{x:1375,y:692,t:1527628385598};\\\", \\\"{x:1374,y:692,t:1527628385622};\\\", \\\"{x:1372,y:693,t:1527628385687};\\\", \\\"{x:1371,y:693,t:1527628385726};\\\", \\\"{x:1370,y:695,t:1527628385750};\\\", \\\"{x:1369,y:695,t:1527628385774};\\\", \\\"{x:1368,y:695,t:1527628385790};\\\", \\\"{x:1367,y:695,t:1527628385800};\\\", \\\"{x:1366,y:695,t:1527628385822};\\\", \\\"{x:1366,y:696,t:1527628386143};\\\", \\\"{x:1366,y:697,t:1527628386158};\\\", \\\"{x:1364,y:697,t:1527628386279};\\\", \\\"{x:1364,y:698,t:1527628386286};\\\", \\\"{x:1363,y:698,t:1527628386302};\\\", \\\"{x:1362,y:698,t:1527628386422};\\\", \\\"{x:1361,y:698,t:1527628387327};\\\", \\\"{x:1360,y:702,t:1527628387335};\\\", \\\"{x:1341,y:703,t:1527628387352};\\\", \\\"{x:1308,y:707,t:1527628387367};\\\", \\\"{x:1252,y:707,t:1527628387384};\\\", \\\"{x:1173,y:710,t:1527628387401};\\\", \\\"{x:1105,y:706,t:1527628387418};\\\", \\\"{x:1010,y:704,t:1527628387435};\\\", \\\"{x:910,y:693,t:1527628387452};\\\", \\\"{x:816,y:693,t:1527628387468};\\\", \\\"{x:741,y:693,t:1527628387485};\\\", \\\"{x:635,y:693,t:1527628387502};\\\", \\\"{x:608,y:693,t:1527628387518};\\\", \\\"{x:593,y:693,t:1527628387535};\\\", \\\"{x:579,y:693,t:1527628387551};\\\", \\\"{x:572,y:693,t:1527628387568};\\\", \\\"{x:571,y:693,t:1527628387585};\\\", \\\"{x:571,y:691,t:1527628387702};\\\", \\\"{x:571,y:681,t:1527628387718};\\\", \\\"{x:571,y:673,t:1527628387735};\\\", \\\"{x:573,y:664,t:1527628387752};\\\", \\\"{x:577,y:651,t:1527628387769};\\\", \\\"{x:578,y:645,t:1527628387784};\\\", \\\"{x:578,y:639,t:1527628387801};\\\", \\\"{x:578,y:638,t:1527628387818};\\\", \\\"{x:578,y:635,t:1527628387835};\\\", \\\"{x:580,y:630,t:1527628387853};\\\", \\\"{x:581,y:623,t:1527628387868};\\\", \\\"{x:582,y:618,t:1527628387884};\\\", \\\"{x:584,y:610,t:1527628387902};\\\", \\\"{x:584,y:609,t:1527628387919};\\\", \\\"{x:586,y:604,t:1527628387935};\\\", \\\"{x:590,y:596,t:1527628387953};\\\", \\\"{x:592,y:593,t:1527628387970};\\\", \\\"{x:594,y:590,t:1527628387987};\\\", \\\"{x:596,y:584,t:1527628388004};\\\", \\\"{x:600,y:578,t:1527628388021};\\\", \\\"{x:602,y:575,t:1527628388037};\\\", \\\"{x:602,y:574,t:1527628388053};\\\", \\\"{x:604,y:572,t:1527628388070};\\\", \\\"{x:605,y:572,t:1527628388093};\\\", \\\"{x:606,y:572,t:1527628388109};\\\", \\\"{x:607,y:572,t:1527628388126};\\\", \\\"{x:608,y:572,t:1527628388137};\\\", \\\"{x:609,y:570,t:1527628388154};\\\", \\\"{x:610,y:570,t:1527628388270};\\\", \\\"{x:611,y:570,t:1527628388365};\\\", \\\"{x:611,y:565,t:1527628388373};\\\", \\\"{x:611,y:563,t:1527628388387};\\\", \\\"{x:609,y:559,t:1527628388405};\\\", \\\"{x:608,y:552,t:1527628388421};\\\", \\\"{x:605,y:542,t:1527628388438};\\\", \\\"{x:605,y:538,t:1527628388455};\\\", \\\"{x:604,y:538,t:1527628388477};\\\", \\\"{x:604,y:537,t:1527628388509};\\\", \\\"{x:601,y:536,t:1527628388766};\\\", \\\"{x:590,y:537,t:1527628388774};\\\", \\\"{x:579,y:537,t:1527628388788};\\\", \\\"{x:565,y:538,t:1527628388805};\\\", \\\"{x:557,y:538,t:1527628388821};\\\", \\\"{x:568,y:536,t:1527628388861};\\\", \\\"{x:594,y:532,t:1527628388871};\\\", \\\"{x:669,y:519,t:1527628388888};\\\", \\\"{x:717,y:512,t:1527628388905};\\\", \\\"{x:753,y:504,t:1527628388921};\\\", \\\"{x:775,y:500,t:1527628388937};\\\", \\\"{x:784,y:498,t:1527628388954};\\\", \\\"{x:785,y:498,t:1527628388972};\\\", \\\"{x:788,y:497,t:1527628389030};\\\", \\\"{x:792,y:495,t:1527628389037};\\\", \\\"{x:798,y:495,t:1527628389055};\\\", \\\"{x:804,y:494,t:1527628389071};\\\", \\\"{x:807,y:493,t:1527628389087};\\\", \\\"{x:808,y:493,t:1527628389105};\\\", \\\"{x:810,y:493,t:1527628389125};\\\", \\\"{x:812,y:493,t:1527628389137};\\\", \\\"{x:820,y:493,t:1527628389154};\\\", \\\"{x:835,y:491,t:1527628389172};\\\", \\\"{x:842,y:491,t:1527628389188};\\\", \\\"{x:847,y:490,t:1527628389205};\\\", \\\"{x:854,y:490,t:1527628389220};\\\", \\\"{x:856,y:490,t:1527628389238};\\\", \\\"{x:855,y:490,t:1527628389477};\\\", \\\"{x:854,y:491,t:1527628389489};\\\", \\\"{x:850,y:493,t:1527628389504};\\\", \\\"{x:849,y:494,t:1527628389521};\\\", \\\"{x:847,y:495,t:1527628389539};\\\", \\\"{x:840,y:500,t:1527628389554};\\\", \\\"{x:830,y:507,t:1527628389572};\\\", \\\"{x:815,y:524,t:1527628389589};\\\", \\\"{x:792,y:542,t:1527628389605};\\\", \\\"{x:750,y:569,t:1527628389622};\\\", \\\"{x:741,y:583,t:1527628389638};\\\", \\\"{x:725,y:595,t:1527628389655};\\\", \\\"{x:705,y:612,t:1527628389671};\\\", \\\"{x:692,y:625,t:1527628389689};\\\", \\\"{x:670,y:640,t:1527628389705};\\\", \\\"{x:650,y:657,t:1527628389721};\\\", \\\"{x:621,y:673,t:1527628389738};\\\", \\\"{x:608,y:680,t:1527628389754};\\\", \\\"{x:600,y:684,t:1527628389771};\\\", \\\"{x:597,y:685,t:1527628389788};\\\", \\\"{x:595,y:687,t:1527628389805};\\\", \\\"{x:592,y:689,t:1527628389822};\\\", \\\"{x:590,y:689,t:1527628389838};\\\", \\\"{x:586,y:691,t:1527628389856};\\\", \\\"{x:584,y:694,t:1527628389872};\\\", \\\"{x:579,y:698,t:1527628389888};\\\", \\\"{x:570,y:706,t:1527628389904};\\\", \\\"{x:561,y:716,t:1527628389922};\\\", \\\"{x:552,y:722,t:1527628389940};\\\", \\\"{x:545,y:727,t:1527628389954};\\\", \\\"{x:545,y:729,t:1527628389972};\\\", \\\"{x:543,y:730,t:1527628389989};\\\", \\\"{x:537,y:733,t:1527628390005};\\\", \\\"{x:531,y:735,t:1527628390023};\\\", \\\"{x:528,y:736,t:1527628390039};\\\" ] }, { \\\"rt\\\": 21656, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 662876, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:735,t:1527628392326};\\\", \\\"{x:533,y:730,t:1527628392340};\\\", \\\"{x:544,y:712,t:1527628392358};\\\", \\\"{x:554,y:696,t:1527628392372};\\\", \\\"{x:566,y:677,t:1527628392392};\\\", \\\"{x:570,y:669,t:1527628392408};\\\", \\\"{x:575,y:660,t:1527628392425};\\\", \\\"{x:583,y:648,t:1527628392441};\\\", \\\"{x:591,y:632,t:1527628392459};\\\", \\\"{x:596,y:621,t:1527628392477};\\\", \\\"{x:597,y:614,t:1527628392490};\\\", \\\"{x:602,y:604,t:1527628392508};\\\", \\\"{x:606,y:597,t:1527628392524};\\\", \\\"{x:610,y:591,t:1527628392541};\\\", \\\"{x:614,y:580,t:1527628392557};\\\", \\\"{x:618,y:573,t:1527628392573};\\\", \\\"{x:620,y:566,t:1527628392591};\\\", \\\"{x:623,y:560,t:1527628392608};\\\", \\\"{x:626,y:556,t:1527628392623};\\\", \\\"{x:629,y:551,t:1527628392640};\\\", \\\"{x:633,y:547,t:1527628392658};\\\", \\\"{x:634,y:546,t:1527628392674};\\\", \\\"{x:640,y:543,t:1527628392690};\\\", \\\"{x:648,y:536,t:1527628392708};\\\", \\\"{x:659,y:533,t:1527628392725};\\\", \\\"{x:667,y:529,t:1527628392740};\\\", \\\"{x:680,y:524,t:1527628392757};\\\", \\\"{x:698,y:515,t:1527628392775};\\\", \\\"{x:717,y:505,t:1527628392791};\\\", \\\"{x:740,y:496,t:1527628392809};\\\", \\\"{x:764,y:490,t:1527628392824};\\\", \\\"{x:791,y:482,t:1527628392841};\\\", \\\"{x:821,y:472,t:1527628392858};\\\", \\\"{x:868,y:460,t:1527628392875};\\\", \\\"{x:918,y:454,t:1527628392891};\\\", \\\"{x:961,y:449,t:1527628392908};\\\", \\\"{x:1021,y:441,t:1527628392925};\\\", \\\"{x:1095,y:434,t:1527628392941};\\\", \\\"{x:1218,y:419,t:1527628392959};\\\", \\\"{x:1281,y:414,t:1527628392975};\\\", \\\"{x:1330,y:411,t:1527628392991};\\\", \\\"{x:1378,y:411,t:1527628393008};\\\", \\\"{x:1422,y:415,t:1527628393025};\\\", \\\"{x:1445,y:419,t:1527628393043};\\\", \\\"{x:1483,y:427,t:1527628393058};\\\", \\\"{x:1525,y:439,t:1527628393075};\\\", \\\"{x:1544,y:456,t:1527628393092};\\\", \\\"{x:1565,y:466,t:1527628393108};\\\", \\\"{x:1580,y:471,t:1527628393125};\\\", \\\"{x:1593,y:480,t:1527628393142};\\\", \\\"{x:1596,y:482,t:1527628393158};\\\", \\\"{x:1598,y:483,t:1527628393175};\\\", \\\"{x:1599,y:484,t:1527628393192};\\\", \\\"{x:1599,y:485,t:1527628393209};\\\", \\\"{x:1601,y:492,t:1527628393226};\\\", \\\"{x:1604,y:505,t:1527628393241};\\\", \\\"{x:1608,y:524,t:1527628393258};\\\", \\\"{x:1612,y:550,t:1527628393275};\\\", \\\"{x:1619,y:575,t:1527628393292};\\\", \\\"{x:1623,y:598,t:1527628393308};\\\", \\\"{x:1628,y:622,t:1527628393325};\\\", \\\"{x:1634,y:660,t:1527628393342};\\\", \\\"{x:1634,y:684,t:1527628393358};\\\", \\\"{x:1634,y:714,t:1527628393375};\\\", \\\"{x:1634,y:737,t:1527628393392};\\\", \\\"{x:1632,y:760,t:1527628393408};\\\", \\\"{x:1628,y:781,t:1527628393425};\\\", \\\"{x:1623,y:803,t:1527628393442};\\\", \\\"{x:1619,y:827,t:1527628393458};\\\", \\\"{x:1613,y:849,t:1527628393475};\\\", \\\"{x:1608,y:871,t:1527628393492};\\\", \\\"{x:1604,y:887,t:1527628393509};\\\", \\\"{x:1599,y:905,t:1527628393525};\\\", \\\"{x:1591,y:923,t:1527628393542};\\\", \\\"{x:1585,y:929,t:1527628393559};\\\", \\\"{x:1573,y:944,t:1527628393574};\\\", \\\"{x:1562,y:954,t:1527628393591};\\\", \\\"{x:1551,y:960,t:1527628393609};\\\", \\\"{x:1547,y:963,t:1527628393624};\\\", \\\"{x:1543,y:967,t:1527628393642};\\\", \\\"{x:1542,y:968,t:1527628393669};\\\", \\\"{x:1542,y:970,t:1527628393766};\\\", \\\"{x:1542,y:971,t:1527628394013};\\\", \\\"{x:1543,y:971,t:1527628394053};\\\", \\\"{x:1544,y:971,t:1527628394077};\\\", \\\"{x:1546,y:971,t:1527628394134};\\\", \\\"{x:1547,y:971,t:1527628394157};\\\", \\\"{x:1549,y:971,t:1527628394173};\\\", \\\"{x:1550,y:971,t:1527628394190};\\\", \\\"{x:1551,y:970,t:1527628394206};\\\", \\\"{x:1552,y:970,t:1527628394246};\\\", \\\"{x:1553,y:969,t:1527628394269};\\\", \\\"{x:1554,y:969,t:1527628394358};\\\", \\\"{x:1556,y:969,t:1527628394381};\\\", \\\"{x:1558,y:969,t:1527628394574};\\\", \\\"{x:1560,y:968,t:1527628394791};\\\", \\\"{x:1561,y:968,t:1527628394806};\\\", \\\"{x:1562,y:968,t:1527628394838};\\\", \\\"{x:1562,y:967,t:1527628395118};\\\", \\\"{x:1562,y:966,t:1527628395126};\\\", \\\"{x:1561,y:965,t:1527628395150};\\\", \\\"{x:1560,y:965,t:1527628395165};\\\", \\\"{x:1559,y:963,t:1527628395176};\\\", \\\"{x:1558,y:963,t:1527628395193};\\\", \\\"{x:1556,y:959,t:1527628395630};\\\", \\\"{x:1554,y:957,t:1527628395646};\\\", \\\"{x:1554,y:953,t:1527628395660};\\\", \\\"{x:1552,y:950,t:1527628395677};\\\", \\\"{x:1552,y:949,t:1527628395694};\\\", \\\"{x:1552,y:947,t:1527628395710};\\\", \\\"{x:1552,y:944,t:1527628395727};\\\", \\\"{x:1552,y:943,t:1527628395744};\\\", \\\"{x:1550,y:938,t:1527628395760};\\\", \\\"{x:1549,y:935,t:1527628395777};\\\", \\\"{x:1549,y:931,t:1527628395793};\\\", \\\"{x:1549,y:929,t:1527628395810};\\\", \\\"{x:1549,y:924,t:1527628395827};\\\", \\\"{x:1549,y:918,t:1527628395844};\\\", \\\"{x:1549,y:915,t:1527628395860};\\\", \\\"{x:1549,y:909,t:1527628395877};\\\", \\\"{x:1549,y:905,t:1527628395893};\\\", \\\"{x:1549,y:898,t:1527628395910};\\\", \\\"{x:1548,y:892,t:1527628395927};\\\", \\\"{x:1548,y:888,t:1527628395944};\\\", \\\"{x:1547,y:883,t:1527628395961};\\\", \\\"{x:1547,y:881,t:1527628395977};\\\", \\\"{x:1547,y:880,t:1527628395994};\\\", \\\"{x:1547,y:878,t:1527628396011};\\\", \\\"{x:1547,y:875,t:1527628396027};\\\", \\\"{x:1547,y:873,t:1527628396044};\\\", \\\"{x:1547,y:870,t:1527628396061};\\\", \\\"{x:1547,y:867,t:1527628396078};\\\", \\\"{x:1547,y:864,t:1527628396094};\\\", \\\"{x:1547,y:861,t:1527628396111};\\\", \\\"{x:1547,y:858,t:1527628396127};\\\", \\\"{x:1547,y:856,t:1527628396144};\\\", \\\"{x:1545,y:854,t:1527628396161};\\\", \\\"{x:1545,y:851,t:1527628396177};\\\", \\\"{x:1544,y:847,t:1527628396194};\\\", \\\"{x:1544,y:843,t:1527628396211};\\\", \\\"{x:1544,y:840,t:1527628396227};\\\", \\\"{x:1544,y:838,t:1527628396254};\\\", \\\"{x:1544,y:837,t:1527628396286};\\\", \\\"{x:1544,y:835,t:1527628396302};\\\", \\\"{x:1543,y:834,t:1527628396374};\\\", \\\"{x:1542,y:833,t:1527628396431};\\\", \\\"{x:1542,y:831,t:1527628396454};\\\", \\\"{x:1542,y:829,t:1527628396478};\\\", \\\"{x:1541,y:827,t:1527628396494};\\\", \\\"{x:1539,y:825,t:1527628396526};\\\", \\\"{x:1536,y:830,t:1527628397006};\\\", \\\"{x:1536,y:833,t:1527628397014};\\\", \\\"{x:1534,y:837,t:1527628397027};\\\", \\\"{x:1529,y:855,t:1527628397044};\\\", \\\"{x:1529,y:871,t:1527628397060};\\\", \\\"{x:1529,y:882,t:1527628397077};\\\", \\\"{x:1530,y:889,t:1527628397094};\\\", \\\"{x:1531,y:896,t:1527628397111};\\\", \\\"{x:1533,y:900,t:1527628397128};\\\", \\\"{x:1535,y:906,t:1527628397144};\\\", \\\"{x:1536,y:908,t:1527628397160};\\\", \\\"{x:1537,y:909,t:1527628397178};\\\", \\\"{x:1537,y:910,t:1527628397194};\\\", \\\"{x:1537,y:912,t:1527628397237};\\\", \\\"{x:1537,y:913,t:1527628397245};\\\", \\\"{x:1537,y:914,t:1527628397270};\\\", \\\"{x:1537,y:915,t:1527628397294};\\\", \\\"{x:1537,y:916,t:1527628397311};\\\", \\\"{x:1538,y:919,t:1527628397328};\\\", \\\"{x:1539,y:920,t:1527628397346};\\\", \\\"{x:1540,y:922,t:1527628397361};\\\", \\\"{x:1540,y:923,t:1527628397378};\\\", \\\"{x:1542,y:927,t:1527628397395};\\\", \\\"{x:1542,y:930,t:1527628397412};\\\", \\\"{x:1544,y:933,t:1527628397428};\\\", \\\"{x:1544,y:937,t:1527628397445};\\\", \\\"{x:1547,y:941,t:1527628397461};\\\", \\\"{x:1547,y:945,t:1527628397478};\\\", \\\"{x:1547,y:944,t:1527628397854};\\\", \\\"{x:1547,y:941,t:1527628397862};\\\", \\\"{x:1546,y:932,t:1527628397878};\\\", \\\"{x:1545,y:922,t:1527628397896};\\\", \\\"{x:1545,y:912,t:1527628397912};\\\", \\\"{x:1545,y:898,t:1527628397928};\\\", \\\"{x:1545,y:890,t:1527628397946};\\\", \\\"{x:1545,y:883,t:1527628397962};\\\", \\\"{x:1544,y:875,t:1527628397978};\\\", \\\"{x:1544,y:868,t:1527628397996};\\\", \\\"{x:1544,y:862,t:1527628398012};\\\", \\\"{x:1544,y:856,t:1527628398029};\\\", \\\"{x:1544,y:849,t:1527628398046};\\\", \\\"{x:1544,y:847,t:1527628398062};\\\", \\\"{x:1542,y:845,t:1527628398078};\\\", \\\"{x:1542,y:843,t:1527628398096};\\\", \\\"{x:1542,y:840,t:1527628398112};\\\", \\\"{x:1542,y:838,t:1527628398129};\\\", \\\"{x:1542,y:834,t:1527628398145};\\\", \\\"{x:1542,y:833,t:1527628398163};\\\", \\\"{x:1542,y:831,t:1527628398179};\\\", \\\"{x:1542,y:823,t:1527628399933};\\\", \\\"{x:1542,y:816,t:1527628399945};\\\", \\\"{x:1542,y:808,t:1527628399963};\\\", \\\"{x:1542,y:795,t:1527628399979};\\\", \\\"{x:1542,y:787,t:1527628399996};\\\", \\\"{x:1541,y:773,t:1527628400013};\\\", \\\"{x:1540,y:766,t:1527628400030};\\\", \\\"{x:1540,y:761,t:1527628400046};\\\", \\\"{x:1540,y:756,t:1527628400063};\\\", \\\"{x:1541,y:749,t:1527628400080};\\\", \\\"{x:1541,y:745,t:1527628400096};\\\", \\\"{x:1542,y:742,t:1527628400113};\\\", \\\"{x:1542,y:741,t:1527628400141};\\\", \\\"{x:1542,y:740,t:1527628400149};\\\", \\\"{x:1542,y:739,t:1527628400163};\\\", \\\"{x:1542,y:738,t:1527628400180};\\\", \\\"{x:1542,y:733,t:1527628400197};\\\", \\\"{x:1542,y:729,t:1527628400214};\\\", \\\"{x:1542,y:728,t:1527628400230};\\\", \\\"{x:1542,y:726,t:1527628400247};\\\", \\\"{x:1541,y:724,t:1527628400263};\\\", \\\"{x:1540,y:722,t:1527628400280};\\\", \\\"{x:1540,y:720,t:1527628400297};\\\", \\\"{x:1540,y:718,t:1527628400313};\\\", \\\"{x:1540,y:717,t:1527628400331};\\\", \\\"{x:1540,y:715,t:1527628400347};\\\", \\\"{x:1540,y:714,t:1527628400364};\\\", \\\"{x:1540,y:713,t:1527628400423};\\\", \\\"{x:1540,y:711,t:1527628400430};\\\", \\\"{x:1541,y:709,t:1527628400454};\\\", \\\"{x:1541,y:708,t:1527628400464};\\\", \\\"{x:1541,y:707,t:1527628400480};\\\", \\\"{x:1543,y:705,t:1527628400497};\\\", \\\"{x:1544,y:704,t:1527628400513};\\\", \\\"{x:1544,y:703,t:1527628400530};\\\", \\\"{x:1544,y:701,t:1527628400547};\\\", \\\"{x:1544,y:700,t:1527628400590};\\\", \\\"{x:1544,y:699,t:1527628400614};\\\", \\\"{x:1545,y:699,t:1527628400630};\\\", \\\"{x:1546,y:697,t:1527628400678};\\\", \\\"{x:1547,y:697,t:1527628404078};\\\", \\\"{x:1547,y:696,t:1527628404806};\\\", \\\"{x:1548,y:688,t:1527628404822};\\\", \\\"{x:1548,y:684,t:1527628404834};\\\", \\\"{x:1548,y:681,t:1527628404851};\\\", \\\"{x:1548,y:677,t:1527628404868};\\\", \\\"{x:1548,y:673,t:1527628404884};\\\", \\\"{x:1548,y:672,t:1527628404901};\\\", \\\"{x:1548,y:671,t:1527628404926};\\\", \\\"{x:1548,y:670,t:1527628404949};\\\", \\\"{x:1548,y:668,t:1527628404968};\\\", \\\"{x:1547,y:664,t:1527628404984};\\\", \\\"{x:1547,y:658,t:1527628405001};\\\", \\\"{x:1545,y:654,t:1527628405018};\\\", \\\"{x:1545,y:650,t:1527628405033};\\\", \\\"{x:1544,y:647,t:1527628405051};\\\", \\\"{x:1543,y:642,t:1527628405068};\\\", \\\"{x:1542,y:639,t:1527628405083};\\\", \\\"{x:1541,y:636,t:1527628405100};\\\", \\\"{x:1541,y:632,t:1527628405118};\\\", \\\"{x:1541,y:630,t:1527628405134};\\\", \\\"{x:1541,y:629,t:1527628405166};\\\", \\\"{x:1541,y:628,t:1527628405182};\\\", \\\"{x:1541,y:627,t:1527628405189};\\\", \\\"{x:1541,y:626,t:1527628405214};\\\", \\\"{x:1541,y:625,t:1527628405221};\\\", \\\"{x:1541,y:624,t:1527628405233};\\\", \\\"{x:1541,y:623,t:1527628405251};\\\", \\\"{x:1541,y:621,t:1527628405268};\\\", \\\"{x:1541,y:618,t:1527628405285};\\\", \\\"{x:1541,y:615,t:1527628405301};\\\", \\\"{x:1541,y:606,t:1527628405317};\\\", \\\"{x:1541,y:601,t:1527628405334};\\\", \\\"{x:1541,y:596,t:1527628405350};\\\", \\\"{x:1541,y:591,t:1527628405368};\\\", \\\"{x:1541,y:588,t:1527628405384};\\\", \\\"{x:1541,y:586,t:1527628405401};\\\", \\\"{x:1541,y:584,t:1527628405418};\\\", \\\"{x:1541,y:583,t:1527628405435};\\\", \\\"{x:1541,y:582,t:1527628405477};\\\", \\\"{x:1541,y:581,t:1527628405574};\\\", \\\"{x:1541,y:580,t:1527628405598};\\\", \\\"{x:1541,y:579,t:1527628405629};\\\", \\\"{x:1541,y:578,t:1527628405638};\\\", \\\"{x:1541,y:576,t:1527628405650};\\\", \\\"{x:1541,y:575,t:1527628405678};\\\", \\\"{x:1541,y:573,t:1527628405686};\\\", \\\"{x:1541,y:572,t:1527628405718};\\\", \\\"{x:1542,y:572,t:1527628405734};\\\", \\\"{x:1542,y:571,t:1527628405752};\\\", \\\"{x:1542,y:570,t:1527628405773};\\\", \\\"{x:1542,y:569,t:1527628405806};\\\", \\\"{x:1542,y:568,t:1527628405821};\\\", \\\"{x:1543,y:566,t:1527628405835};\\\", \\\"{x:1544,y:566,t:1527628405894};\\\", \\\"{x:1544,y:564,t:1527628405917};\\\", \\\"{x:1544,y:563,t:1527628405935};\\\", \\\"{x:1544,y:562,t:1527628405974};\\\", \\\"{x:1544,y:565,t:1527628411870};\\\", \\\"{x:1544,y:567,t:1527628411880};\\\", \\\"{x:1544,y:571,t:1527628411897};\\\", \\\"{x:1544,y:572,t:1527628411974};\\\", \\\"{x:1544,y:573,t:1527628411989};\\\", \\\"{x:1544,y:574,t:1527628411997};\\\", \\\"{x:1544,y:576,t:1527628412013};\\\", \\\"{x:1544,y:578,t:1527628412031};\\\", \\\"{x:1544,y:580,t:1527628412047};\\\", \\\"{x:1544,y:584,t:1527628412065};\\\", \\\"{x:1544,y:586,t:1527628412081};\\\", \\\"{x:1544,y:588,t:1527628412097};\\\", \\\"{x:1544,y:591,t:1527628412114};\\\", \\\"{x:1544,y:594,t:1527628412131};\\\", \\\"{x:1544,y:596,t:1527628412147};\\\", \\\"{x:1544,y:597,t:1527628412164};\\\", \\\"{x:1544,y:598,t:1527628412181};\\\", \\\"{x:1544,y:601,t:1527628412197};\\\", \\\"{x:1544,y:603,t:1527628412222};\\\", \\\"{x:1544,y:607,t:1527628412231};\\\", \\\"{x:1543,y:612,t:1527628412246};\\\", \\\"{x:1537,y:627,t:1527628412264};\\\", \\\"{x:1521,y:641,t:1527628412281};\\\", \\\"{x:1489,y:672,t:1527628412297};\\\", \\\"{x:1450,y:697,t:1527628412314};\\\", \\\"{x:1350,y:746,t:1527628412331};\\\", \\\"{x:1209,y:792,t:1527628412348};\\\", \\\"{x:1082,y:824,t:1527628412364};\\\", \\\"{x:970,y:848,t:1527628412381};\\\", \\\"{x:806,y:863,t:1527628412398};\\\", \\\"{x:731,y:863,t:1527628412413};\\\", \\\"{x:674,y:859,t:1527628412431};\\\", \\\"{x:606,y:855,t:1527628412447};\\\", \\\"{x:574,y:851,t:1527628412463};\\\", \\\"{x:551,y:851,t:1527628412480};\\\", \\\"{x:538,y:851,t:1527628412498};\\\", \\\"{x:530,y:851,t:1527628412514};\\\", \\\"{x:526,y:851,t:1527628412531};\\\", \\\"{x:525,y:851,t:1527628412557};\\\", \\\"{x:525,y:847,t:1527628412630};\\\", \\\"{x:518,y:833,t:1527628412648};\\\", \\\"{x:508,y:814,t:1527628412663};\\\", \\\"{x:503,y:802,t:1527628412681};\\\", \\\"{x:499,y:793,t:1527628412697};\\\", \\\"{x:498,y:789,t:1527628412714};\\\", \\\"{x:496,y:785,t:1527628412731};\\\", \\\"{x:496,y:780,t:1527628412748};\\\", \\\"{x:496,y:775,t:1527628412764};\\\", \\\"{x:497,y:765,t:1527628412781};\\\", \\\"{x:499,y:756,t:1527628412797};\\\", \\\"{x:500,y:752,t:1527628412815};\\\", \\\"{x:500,y:751,t:1527628412830};\\\", \\\"{x:500,y:750,t:1527628412848};\\\", \\\"{x:501,y:748,t:1527628412930};\\\", \\\"{x:503,y:748,t:1527628412949};\\\", \\\"{x:503,y:748,t:1527628413077};\\\", \\\"{x:503,y:750,t:1527628413478};\\\", \\\"{x:503,y:758,t:1527628413485};\\\", \\\"{x:503,y:765,t:1527628413500};\\\", \\\"{x:502,y:778,t:1527628413516};\\\", \\\"{x:502,y:785,t:1527628413533};\\\", \\\"{x:502,y:786,t:1527628413550};\\\", \\\"{x:502,y:788,t:1527628413589};\\\", \\\"{x:502,y:790,t:1527628413605};\\\", \\\"{x:502,y:792,t:1527628413645};\\\", \\\"{x:502,y:793,t:1527628413661};\\\", \\\"{x:503,y:795,t:1527628413686};\\\", \\\"{x:506,y:798,t:1527628413699};\\\", \\\"{x:518,y:805,t:1527628413717};\\\", \\\"{x:533,y:813,t:1527628413733};\\\", \\\"{x:544,y:817,t:1527628413750};\\\" ] }, { \\\"rt\\\": 23645, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 687805, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -M -B -B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:544,y:810,t:1527628414829};\\\", \\\"{x:541,y:806,t:1527628414836};\\\", \\\"{x:537,y:800,t:1527628414850};\\\", \\\"{x:531,y:786,t:1527628414867};\\\", \\\"{x:522,y:774,t:1527628414883};\\\", \\\"{x:515,y:757,t:1527628414901};\\\", \\\"{x:504,y:722,t:1527628414917};\\\", \\\"{x:493,y:682,t:1527628414934};\\\", \\\"{x:481,y:655,t:1527628414950};\\\", \\\"{x:469,y:628,t:1527628414968};\\\", \\\"{x:457,y:606,t:1527628414984};\\\", \\\"{x:445,y:587,t:1527628415000};\\\", \\\"{x:439,y:570,t:1527628415018};\\\", \\\"{x:430,y:558,t:1527628415034};\\\", \\\"{x:426,y:546,t:1527628415050};\\\", \\\"{x:424,y:539,t:1527628415067};\\\", \\\"{x:421,y:535,t:1527628415084};\\\", \\\"{x:419,y:530,t:1527628415101};\\\", \\\"{x:418,y:527,t:1527628415117};\\\", \\\"{x:417,y:526,t:1527628415140};\\\", \\\"{x:416,y:525,t:1527628415181};\\\", \\\"{x:416,y:524,t:1527628415188};\\\", \\\"{x:414,y:522,t:1527628415201};\\\", \\\"{x:413,y:521,t:1527628415217};\\\", \\\"{x:412,y:519,t:1527628415234};\\\", \\\"{x:410,y:518,t:1527628415250};\\\", \\\"{x:408,y:517,t:1527628415268};\\\", \\\"{x:405,y:516,t:1527628415286};\\\", \\\"{x:404,y:515,t:1527628415301};\\\", \\\"{x:396,y:511,t:1527628415317};\\\", \\\"{x:384,y:506,t:1527628415334};\\\", \\\"{x:368,y:497,t:1527628415352};\\\", \\\"{x:353,y:491,t:1527628415366};\\\", \\\"{x:341,y:485,t:1527628415384};\\\", \\\"{x:332,y:479,t:1527628415401};\\\", \\\"{x:325,y:476,t:1527628415417};\\\", \\\"{x:320,y:474,t:1527628415434};\\\", \\\"{x:317,y:473,t:1527628415450};\\\", \\\"{x:314,y:468,t:1527628415509};\\\", \\\"{x:314,y:466,t:1527628415517};\\\", \\\"{x:313,y:464,t:1527628415535};\\\", \\\"{x:313,y:463,t:1527628415551};\\\", \\\"{x:313,y:460,t:1527628415567};\\\", \\\"{x:313,y:454,t:1527628415584};\\\", \\\"{x:313,y:449,t:1527628415600};\\\", \\\"{x:313,y:445,t:1527628415617};\\\", \\\"{x:315,y:443,t:1527628415634};\\\", \\\"{x:317,y:439,t:1527628415651};\\\", \\\"{x:320,y:436,t:1527628415668};\\\", \\\"{x:321,y:434,t:1527628415684};\\\", \\\"{x:321,y:433,t:1527628415725};\\\", \\\"{x:325,y:433,t:1527628416670};\\\", \\\"{x:349,y:439,t:1527628416685};\\\", \\\"{x:371,y:446,t:1527628416701};\\\", \\\"{x:399,y:451,t:1527628416718};\\\", \\\"{x:416,y:456,t:1527628416736};\\\", \\\"{x:430,y:458,t:1527628416751};\\\", \\\"{x:441,y:462,t:1527628416769};\\\", \\\"{x:444,y:462,t:1527628416785};\\\", \\\"{x:447,y:463,t:1527628416802};\\\", \\\"{x:448,y:463,t:1527628416819};\\\", \\\"{x:449,y:464,t:1527628416835};\\\", \\\"{x:450,y:464,t:1527628416861};\\\", \\\"{x:452,y:465,t:1527628416868};\\\", \\\"{x:455,y:466,t:1527628416886};\\\", \\\"{x:461,y:466,t:1527628416902};\\\", \\\"{x:466,y:468,t:1527628416918};\\\", \\\"{x:471,y:468,t:1527628416935};\\\", \\\"{x:473,y:469,t:1527628416951};\\\", \\\"{x:476,y:469,t:1527628416969};\\\", \\\"{x:480,y:469,t:1527628416986};\\\", \\\"{x:483,y:470,t:1527628417001};\\\", \\\"{x:488,y:470,t:1527628417019};\\\", \\\"{x:495,y:470,t:1527628417035};\\\", \\\"{x:503,y:470,t:1527628417053};\\\", \\\"{x:507,y:470,t:1527628417069};\\\", \\\"{x:512,y:470,t:1527628417085};\\\", \\\"{x:517,y:470,t:1527628417103};\\\", \\\"{x:524,y:470,t:1527628417119};\\\", \\\"{x:526,y:470,t:1527628417136};\\\", \\\"{x:527,y:470,t:1527628417189};\\\", \\\"{x:528,y:470,t:1527628417213};\\\", \\\"{x:529,y:470,t:1527628417287};\\\", \\\"{x:531,y:470,t:1527628417303};\\\", \\\"{x:532,y:470,t:1527628417319};\\\", \\\"{x:537,y:470,t:1527628417336};\\\", \\\"{x:543,y:470,t:1527628417353};\\\", \\\"{x:547,y:470,t:1527628417369};\\\", \\\"{x:552,y:470,t:1527628417386};\\\", \\\"{x:563,y:470,t:1527628417403};\\\", \\\"{x:577,y:472,t:1527628417419};\\\", \\\"{x:591,y:472,t:1527628417436};\\\", \\\"{x:601,y:472,t:1527628417454};\\\", \\\"{x:603,y:472,t:1527628417501};\\\", \\\"{x:603,y:473,t:1527628418094};\\\", \\\"{x:599,y:474,t:1527628418103};\\\", \\\"{x:596,y:476,t:1527628418120};\\\", \\\"{x:594,y:477,t:1527628418137};\\\", \\\"{x:593,y:477,t:1527628418153};\\\", \\\"{x:591,y:477,t:1527628418169};\\\", \\\"{x:590,y:477,t:1527628418186};\\\", \\\"{x:589,y:478,t:1527628418203};\\\", \\\"{x:585,y:479,t:1527628418220};\\\", \\\"{x:573,y:479,t:1527628418237};\\\", \\\"{x:558,y:479,t:1527628418253};\\\", \\\"{x:541,y:479,t:1527628418270};\\\", \\\"{x:528,y:479,t:1527628418287};\\\", \\\"{x:521,y:479,t:1527628418303};\\\", \\\"{x:516,y:479,t:1527628418320};\\\", \\\"{x:525,y:482,t:1527628418750};\\\", \\\"{x:542,y:488,t:1527628418757};\\\", \\\"{x:556,y:493,t:1527628418770};\\\", \\\"{x:601,y:507,t:1527628418789};\\\", \\\"{x:666,y:518,t:1527628418804};\\\", \\\"{x:761,y:534,t:1527628418820};\\\", \\\"{x:920,y:572,t:1527628418836};\\\", \\\"{x:1026,y:605,t:1527628418853};\\\", \\\"{x:1123,y:632,t:1527628418870};\\\", \\\"{x:1199,y:656,t:1527628418887};\\\", \\\"{x:1251,y:679,t:1527628418904};\\\", \\\"{x:1293,y:697,t:1527628418921};\\\", \\\"{x:1313,y:710,t:1527628418936};\\\", \\\"{x:1323,y:719,t:1527628418954};\\\", \\\"{x:1333,y:727,t:1527628418971};\\\", \\\"{x:1339,y:735,t:1527628418988};\\\", \\\"{x:1343,y:739,t:1527628419004};\\\", \\\"{x:1352,y:747,t:1527628419020};\\\", \\\"{x:1355,y:751,t:1527628419037};\\\", \\\"{x:1355,y:753,t:1527628419054};\\\", \\\"{x:1358,y:755,t:1527628419190};\\\", \\\"{x:1359,y:759,t:1527628419710};\\\", \\\"{x:1362,y:765,t:1527628419721};\\\", \\\"{x:1364,y:774,t:1527628419739};\\\", \\\"{x:1368,y:783,t:1527628419755};\\\", \\\"{x:1369,y:795,t:1527628419772};\\\", \\\"{x:1370,y:798,t:1527628419789};\\\", \\\"{x:1373,y:803,t:1527628419805};\\\", \\\"{x:1374,y:809,t:1527628419821};\\\", \\\"{x:1376,y:816,t:1527628419838};\\\", \\\"{x:1377,y:824,t:1527628419855};\\\", \\\"{x:1380,y:840,t:1527628419872};\\\", \\\"{x:1381,y:853,t:1527628419888};\\\", \\\"{x:1384,y:869,t:1527628419905};\\\", \\\"{x:1385,y:878,t:1527628419922};\\\", \\\"{x:1385,y:885,t:1527628419938};\\\", \\\"{x:1386,y:890,t:1527628419956};\\\", \\\"{x:1386,y:893,t:1527628419972};\\\", \\\"{x:1386,y:903,t:1527628419988};\\\", \\\"{x:1391,y:915,t:1527628420005};\\\", \\\"{x:1393,y:926,t:1527628420022};\\\", \\\"{x:1395,y:934,t:1527628420038};\\\", \\\"{x:1399,y:940,t:1527628420055};\\\", \\\"{x:1401,y:944,t:1527628420072};\\\", \\\"{x:1402,y:948,t:1527628420089};\\\", \\\"{x:1405,y:952,t:1527628420105};\\\", \\\"{x:1407,y:953,t:1527628420122};\\\", \\\"{x:1409,y:954,t:1527628420140};\\\", \\\"{x:1409,y:955,t:1527628420155};\\\", \\\"{x:1410,y:955,t:1527628420173};\\\", \\\"{x:1412,y:958,t:1527628420189};\\\", \\\"{x:1415,y:960,t:1527628420206};\\\", \\\"{x:1419,y:962,t:1527628420222};\\\", \\\"{x:1421,y:963,t:1527628420239};\\\", \\\"{x:1422,y:964,t:1527628420255};\\\", \\\"{x:1424,y:964,t:1527628420272};\\\", \\\"{x:1426,y:964,t:1527628420294};\\\", \\\"{x:1428,y:964,t:1527628420305};\\\", \\\"{x:1430,y:964,t:1527628420322};\\\", \\\"{x:1435,y:964,t:1527628420339};\\\", \\\"{x:1442,y:964,t:1527628420357};\\\", \\\"{x:1450,y:962,t:1527628420373};\\\", \\\"{x:1456,y:962,t:1527628420389};\\\", \\\"{x:1462,y:961,t:1527628420405};\\\", \\\"{x:1466,y:959,t:1527628420422};\\\", \\\"{x:1468,y:958,t:1527628420439};\\\", \\\"{x:1469,y:957,t:1527628420456};\\\", \\\"{x:1472,y:955,t:1527628420473};\\\", \\\"{x:1474,y:954,t:1527628420489};\\\", \\\"{x:1474,y:951,t:1527628420507};\\\", \\\"{x:1477,y:947,t:1527628420522};\\\", \\\"{x:1477,y:944,t:1527628420540};\\\", \\\"{x:1478,y:941,t:1527628420556};\\\", \\\"{x:1480,y:938,t:1527628420572};\\\", \\\"{x:1480,y:933,t:1527628420589};\\\", \\\"{x:1480,y:932,t:1527628420607};\\\", \\\"{x:1480,y:931,t:1527628420622};\\\", \\\"{x:1480,y:928,t:1527628420640};\\\", \\\"{x:1480,y:927,t:1527628420656};\\\", \\\"{x:1480,y:926,t:1527628420673};\\\", \\\"{x:1478,y:923,t:1527628420690};\\\", \\\"{x:1477,y:921,t:1527628420706};\\\", \\\"{x:1475,y:919,t:1527628420722};\\\", \\\"{x:1474,y:918,t:1527628420739};\\\", \\\"{x:1469,y:915,t:1527628420756};\\\", \\\"{x:1466,y:914,t:1527628420774};\\\", \\\"{x:1465,y:912,t:1527628420789};\\\", \\\"{x:1462,y:910,t:1527628420806};\\\", \\\"{x:1460,y:908,t:1527628420823};\\\", \\\"{x:1457,y:907,t:1527628420839};\\\", \\\"{x:1455,y:906,t:1527628420856};\\\", \\\"{x:1452,y:906,t:1527628420873};\\\", \\\"{x:1448,y:906,t:1527628420890};\\\", \\\"{x:1445,y:906,t:1527628420906};\\\", \\\"{x:1438,y:906,t:1527628420924};\\\", \\\"{x:1431,y:906,t:1527628420940};\\\", \\\"{x:1427,y:906,t:1527628420956};\\\", \\\"{x:1424,y:906,t:1527628420973};\\\", \\\"{x:1423,y:906,t:1527628420990};\\\", \\\"{x:1421,y:906,t:1527628421302};\\\", \\\"{x:1420,y:906,t:1527628421310};\\\", \\\"{x:1418,y:906,t:1527628421323};\\\", \\\"{x:1415,y:903,t:1527628421340};\\\", \\\"{x:1413,y:901,t:1527628421356};\\\", \\\"{x:1409,y:898,t:1527628421372};\\\", \\\"{x:1403,y:896,t:1527628421390};\\\", \\\"{x:1398,y:893,t:1527628421405};\\\", \\\"{x:1397,y:893,t:1527628421423};\\\", \\\"{x:1395,y:893,t:1527628421440};\\\", \\\"{x:1393,y:893,t:1527628421534};\\\", \\\"{x:1390,y:891,t:1527628421846};\\\", \\\"{x:1388,y:890,t:1527628421857};\\\", \\\"{x:1386,y:888,t:1527628421873};\\\", \\\"{x:1382,y:885,t:1527628421890};\\\", \\\"{x:1380,y:882,t:1527628421907};\\\", \\\"{x:1378,y:876,t:1527628421925};\\\", \\\"{x:1376,y:872,t:1527628421940};\\\", \\\"{x:1374,y:865,t:1527628421957};\\\", \\\"{x:1373,y:861,t:1527628421973};\\\", \\\"{x:1373,y:857,t:1527628421990};\\\", \\\"{x:1373,y:845,t:1527628422007};\\\", \\\"{x:1368,y:828,t:1527628422024};\\\", \\\"{x:1368,y:815,t:1527628422040};\\\", \\\"{x:1368,y:803,t:1527628422057};\\\", \\\"{x:1368,y:792,t:1527628422074};\\\", \\\"{x:1368,y:780,t:1527628422090};\\\", \\\"{x:1368,y:772,t:1527628422107};\\\", \\\"{x:1368,y:766,t:1527628422124};\\\", \\\"{x:1368,y:765,t:1527628422141};\\\", \\\"{x:1368,y:764,t:1527628422157};\\\", \\\"{x:1365,y:764,t:1527628422358};\\\", \\\"{x:1361,y:764,t:1527628422375};\\\", \\\"{x:1360,y:764,t:1527628422392};\\\", \\\"{x:1354,y:764,t:1527628422407};\\\", \\\"{x:1345,y:767,t:1527628422427};\\\", \\\"{x:1345,y:768,t:1527628422441};\\\", \\\"{x:1344,y:767,t:1527628425454};\\\", \\\"{x:1344,y:759,t:1527628425461};\\\", \\\"{x:1344,y:748,t:1527628425478};\\\", \\\"{x:1346,y:739,t:1527628425493};\\\", \\\"{x:1347,y:730,t:1527628425510};\\\", \\\"{x:1347,y:728,t:1527628425527};\\\", \\\"{x:1347,y:727,t:1527628425543};\\\", \\\"{x:1347,y:726,t:1527628425560};\\\", \\\"{x:1347,y:724,t:1527628425838};\\\", \\\"{x:1347,y:723,t:1527628425845};\\\", \\\"{x:1347,y:722,t:1527628425860};\\\", \\\"{x:1346,y:717,t:1527628425877};\\\", \\\"{x:1346,y:714,t:1527628425894};\\\", \\\"{x:1346,y:712,t:1527628425918};\\\", \\\"{x:1346,y:711,t:1527628425933};\\\", \\\"{x:1346,y:709,t:1527628426030};\\\", \\\"{x:1346,y:708,t:1527628426078};\\\", \\\"{x:1346,y:706,t:1527628426093};\\\", \\\"{x:1346,y:705,t:1527628426112};\\\", \\\"{x:1346,y:704,t:1527628426127};\\\", \\\"{x:1346,y:702,t:1527628426144};\\\", \\\"{x:1356,y:696,t:1527628426162};\\\", \\\"{x:1360,y:693,t:1527628426178};\\\", \\\"{x:1370,y:688,t:1527628426194};\\\", \\\"{x:1384,y:684,t:1527628426211};\\\", \\\"{x:1396,y:682,t:1527628426228};\\\", \\\"{x:1407,y:680,t:1527628426245};\\\", \\\"{x:1410,y:680,t:1527628426262};\\\", \\\"{x:1412,y:680,t:1527628426277};\\\", \\\"{x:1413,y:680,t:1527628426334};\\\", \\\"{x:1416,y:680,t:1527628426381};\\\", \\\"{x:1417,y:680,t:1527628426394};\\\", \\\"{x:1418,y:680,t:1527628426411};\\\", \\\"{x:1420,y:680,t:1527628426427};\\\", \\\"{x:1429,y:681,t:1527628426445};\\\", \\\"{x:1433,y:684,t:1527628426461};\\\", \\\"{x:1440,y:685,t:1527628426477};\\\", \\\"{x:1442,y:686,t:1527628426494};\\\", \\\"{x:1444,y:687,t:1527628426511};\\\", \\\"{x:1445,y:687,t:1527628426645};\\\", \\\"{x:1448,y:688,t:1527628426669};\\\", \\\"{x:1449,y:689,t:1527628426701};\\\", \\\"{x:1449,y:690,t:1527628426718};\\\", \\\"{x:1449,y:691,t:1527628426758};\\\", \\\"{x:1449,y:692,t:1527628426790};\\\", \\\"{x:1449,y:693,t:1527628426797};\\\", \\\"{x:1449,y:694,t:1527628426838};\\\", \\\"{x:1449,y:695,t:1527628426853};\\\", \\\"{x:1449,y:697,t:1527628426887};\\\", \\\"{x:1448,y:698,t:1527628426926};\\\", \\\"{x:1448,y:699,t:1527628426950};\\\", \\\"{x:1447,y:700,t:1527628426961};\\\", \\\"{x:1447,y:701,t:1527628427022};\\\", \\\"{x:1446,y:702,t:1527628427109};\\\", \\\"{x:1447,y:702,t:1527628427757};\\\", \\\"{x:1449,y:702,t:1527628427765};\\\", \\\"{x:1452,y:702,t:1527628427780};\\\", \\\"{x:1456,y:701,t:1527628427796};\\\", \\\"{x:1459,y:701,t:1527628427813};\\\", \\\"{x:1461,y:701,t:1527628427829};\\\", \\\"{x:1463,y:701,t:1527628427853};\\\", \\\"{x:1464,y:701,t:1527628427863};\\\", \\\"{x:1465,y:701,t:1527628428062};\\\", \\\"{x:1465,y:702,t:1527628429045};\\\", \\\"{x:1463,y:702,t:1527628429109};\\\", \\\"{x:1460,y:702,t:1527628429117};\\\", \\\"{x:1459,y:702,t:1527628429130};\\\", \\\"{x:1451,y:702,t:1527628429147};\\\", \\\"{x:1448,y:702,t:1527628429163};\\\", \\\"{x:1442,y:703,t:1527628429180};\\\", \\\"{x:1436,y:705,t:1527628429196};\\\", \\\"{x:1435,y:705,t:1527628429213};\\\", \\\"{x:1433,y:705,t:1527628429230};\\\", \\\"{x:1432,y:706,t:1527628429247};\\\", \\\"{x:1430,y:706,t:1527628429263};\\\", \\\"{x:1429,y:706,t:1527628429280};\\\", \\\"{x:1424,y:707,t:1527628429297};\\\", \\\"{x:1417,y:710,t:1527628429313};\\\", \\\"{x:1410,y:712,t:1527628429331};\\\", \\\"{x:1405,y:714,t:1527628429348};\\\", \\\"{x:1402,y:714,t:1527628429363};\\\", \\\"{x:1400,y:715,t:1527628429381};\\\", \\\"{x:1398,y:716,t:1527628429454};\\\", \\\"{x:1397,y:716,t:1527628429502};\\\", \\\"{x:1396,y:716,t:1527628429514};\\\", \\\"{x:1396,y:717,t:1527628429557};\\\", \\\"{x:1395,y:718,t:1527628430453};\\\", \\\"{x:1395,y:717,t:1527628430464};\\\", \\\"{x:1395,y:713,t:1527628430481};\\\", \\\"{x:1395,y:708,t:1527628430498};\\\", \\\"{x:1395,y:707,t:1527628430515};\\\", \\\"{x:1396,y:705,t:1527628430531};\\\", \\\"{x:1397,y:703,t:1527628430548};\\\", \\\"{x:1397,y:701,t:1527628430565};\\\", \\\"{x:1397,y:699,t:1527628430582};\\\", \\\"{x:1397,y:698,t:1527628430599};\\\", \\\"{x:1397,y:696,t:1527628430616};\\\", \\\"{x:1397,y:695,t:1527628430632};\\\", \\\"{x:1399,y:692,t:1527628430648};\\\", \\\"{x:1399,y:690,t:1527628430666};\\\", \\\"{x:1399,y:688,t:1527628430682};\\\", \\\"{x:1399,y:687,t:1527628430699};\\\", \\\"{x:1400,y:685,t:1527628430715};\\\", \\\"{x:1400,y:684,t:1527628430733};\\\", \\\"{x:1400,y:683,t:1527628430749};\\\", \\\"{x:1400,y:681,t:1527628430766};\\\", \\\"{x:1400,y:678,t:1527628430782};\\\", \\\"{x:1400,y:675,t:1527628430799};\\\", \\\"{x:1400,y:672,t:1527628430815};\\\", \\\"{x:1402,y:669,t:1527628430832};\\\", \\\"{x:1402,y:668,t:1527628430849};\\\", \\\"{x:1402,y:666,t:1527628430865};\\\", \\\"{x:1402,y:663,t:1527628430882};\\\", \\\"{x:1402,y:660,t:1527628430898};\\\", \\\"{x:1402,y:657,t:1527628430916};\\\", \\\"{x:1402,y:655,t:1527628430932};\\\", \\\"{x:1402,y:651,t:1527628430949};\\\", \\\"{x:1398,y:644,t:1527628430965};\\\", \\\"{x:1395,y:640,t:1527628430983};\\\", \\\"{x:1392,y:631,t:1527628430998};\\\", \\\"{x:1384,y:621,t:1527628431016};\\\", \\\"{x:1379,y:616,t:1527628431033};\\\", \\\"{x:1376,y:613,t:1527628431049};\\\", \\\"{x:1370,y:607,t:1527628431065};\\\", \\\"{x:1364,y:603,t:1527628431082};\\\", \\\"{x:1360,y:597,t:1527628431098};\\\", \\\"{x:1356,y:596,t:1527628431115};\\\", \\\"{x:1348,y:592,t:1527628431132};\\\", \\\"{x:1344,y:591,t:1527628431148};\\\", \\\"{x:1337,y:588,t:1527628431165};\\\", \\\"{x:1332,y:587,t:1527628431182};\\\", \\\"{x:1329,y:586,t:1527628431198};\\\", \\\"{x:1324,y:584,t:1527628431215};\\\", \\\"{x:1323,y:584,t:1527628431232};\\\", \\\"{x:1320,y:584,t:1527628431248};\\\", \\\"{x:1318,y:583,t:1527628431265};\\\", \\\"{x:1316,y:582,t:1527628431282};\\\", \\\"{x:1311,y:580,t:1527628431298};\\\", \\\"{x:1306,y:579,t:1527628431315};\\\", \\\"{x:1296,y:576,t:1527628431332};\\\", \\\"{x:1295,y:576,t:1527628431349};\\\", \\\"{x:1287,y:573,t:1527628431366};\\\", \\\"{x:1284,y:573,t:1527628431382};\\\", \\\"{x:1280,y:571,t:1527628431400};\\\", \\\"{x:1278,y:571,t:1527628431437};\\\", \\\"{x:1278,y:570,t:1527628431449};\\\", \\\"{x:1277,y:570,t:1527628431477};\\\", \\\"{x:1277,y:569,t:1527628432126};\\\", \\\"{x:1276,y:569,t:1527628433102};\\\", \\\"{x:1274,y:569,t:1527628433117};\\\", \\\"{x:1274,y:570,t:1527628433133};\\\", \\\"{x:1273,y:575,t:1527628433151};\\\", \\\"{x:1271,y:583,t:1527628433168};\\\", \\\"{x:1270,y:586,t:1527628433184};\\\", \\\"{x:1270,y:587,t:1527628433201};\\\", \\\"{x:1270,y:589,t:1527628433217};\\\", \\\"{x:1270,y:591,t:1527628433235};\\\", \\\"{x:1270,y:593,t:1527628433251};\\\", \\\"{x:1269,y:594,t:1527628433268};\\\", \\\"{x:1269,y:596,t:1527628433285};\\\", \\\"{x:1269,y:597,t:1527628433301};\\\", \\\"{x:1269,y:599,t:1527628433317};\\\", \\\"{x:1269,y:600,t:1527628433335};\\\", \\\"{x:1269,y:602,t:1527628433351};\\\", \\\"{x:1269,y:603,t:1527628433368};\\\", \\\"{x:1269,y:605,t:1527628433384};\\\", \\\"{x:1267,y:609,t:1527628433401};\\\", \\\"{x:1266,y:613,t:1527628433417};\\\", \\\"{x:1265,y:615,t:1527628433435};\\\", \\\"{x:1263,y:617,t:1527628433450};\\\", \\\"{x:1261,y:620,t:1527628433468};\\\", \\\"{x:1260,y:620,t:1527628433485};\\\", \\\"{x:1256,y:622,t:1527628433501};\\\", \\\"{x:1254,y:623,t:1527628433518};\\\", \\\"{x:1252,y:624,t:1527628433535};\\\", \\\"{x:1250,y:624,t:1527628433551};\\\", \\\"{x:1244,y:626,t:1527628433568};\\\", \\\"{x:1235,y:626,t:1527628433586};\\\", \\\"{x:1219,y:627,t:1527628433600};\\\", \\\"{x:1200,y:627,t:1527628433618};\\\", \\\"{x:1155,y:627,t:1527628433635};\\\", \\\"{x:1085,y:629,t:1527628433652};\\\", \\\"{x:1021,y:629,t:1527628433668};\\\", \\\"{x:965,y:629,t:1527628433685};\\\", \\\"{x:867,y:628,t:1527628433702};\\\", \\\"{x:821,y:625,t:1527628433717};\\\", \\\"{x:781,y:623,t:1527628433734};\\\", \\\"{x:758,y:621,t:1527628433745};\\\", \\\"{x:734,y:617,t:1527628433761};\\\", \\\"{x:713,y:616,t:1527628433778};\\\", \\\"{x:700,y:614,t:1527628433795};\\\", \\\"{x:682,y:614,t:1527628433816};\\\", \\\"{x:669,y:614,t:1527628433833};\\\", \\\"{x:658,y:614,t:1527628433849};\\\", \\\"{x:642,y:614,t:1527628433866};\\\", \\\"{x:629,y:615,t:1527628433883};\\\", \\\"{x:618,y:615,t:1527628433899};\\\", \\\"{x:600,y:615,t:1527628433916};\\\", \\\"{x:587,y:615,t:1527628433932};\\\", \\\"{x:581,y:614,t:1527628433949};\\\", \\\"{x:575,y:611,t:1527628433966};\\\", \\\"{x:571,y:609,t:1527628433983};\\\", \\\"{x:568,y:608,t:1527628433999};\\\", \\\"{x:567,y:607,t:1527628434021};\\\", \\\"{x:567,y:606,t:1527628434052};\\\", \\\"{x:567,y:605,t:1527628434066};\\\", \\\"{x:567,y:603,t:1527628434083};\\\", \\\"{x:567,y:602,t:1527628434099};\\\", \\\"{x:567,y:598,t:1527628434116};\\\", \\\"{x:569,y:595,t:1527628434133};\\\", \\\"{x:572,y:592,t:1527628434149};\\\", \\\"{x:573,y:590,t:1527628434165};\\\", \\\"{x:576,y:586,t:1527628434183};\\\", \\\"{x:580,y:582,t:1527628434199};\\\", \\\"{x:583,y:578,t:1527628434216};\\\", \\\"{x:585,y:575,t:1527628434234};\\\", \\\"{x:589,y:572,t:1527628434249};\\\", \\\"{x:589,y:571,t:1527628434266};\\\", \\\"{x:590,y:570,t:1527628434283};\\\", \\\"{x:592,y:565,t:1527628434301};\\\", \\\"{x:592,y:563,t:1527628434316};\\\", \\\"{x:593,y:561,t:1527628434333};\\\", \\\"{x:594,y:557,t:1527628434350};\\\", \\\"{x:594,y:556,t:1527628434366};\\\", \\\"{x:594,y:550,t:1527628434383};\\\", \\\"{x:594,y:545,t:1527628434400};\\\", \\\"{x:596,y:540,t:1527628434417};\\\", \\\"{x:596,y:538,t:1527628434434};\\\", \\\"{x:597,y:536,t:1527628434450};\\\", \\\"{x:597,y:534,t:1527628434466};\\\", \\\"{x:597,y:530,t:1527628434483};\\\", \\\"{x:596,y:523,t:1527628434500};\\\", \\\"{x:596,y:522,t:1527628434516};\\\", \\\"{x:596,y:518,t:1527628434533};\\\", \\\"{x:597,y:514,t:1527628434550};\\\", \\\"{x:599,y:513,t:1527628434773};\\\", \\\"{x:606,y:513,t:1527628434784};\\\", \\\"{x:614,y:514,t:1527628434800};\\\", \\\"{x:622,y:514,t:1527628434818};\\\", \\\"{x:632,y:514,t:1527628434833};\\\", \\\"{x:640,y:514,t:1527628434850};\\\", \\\"{x:648,y:514,t:1527628434868};\\\", \\\"{x:660,y:514,t:1527628434883};\\\", \\\"{x:677,y:514,t:1527628434900};\\\", \\\"{x:698,y:519,t:1527628434917};\\\", \\\"{x:707,y:522,t:1527628434933};\\\", \\\"{x:715,y:524,t:1527628434950};\\\", \\\"{x:712,y:526,t:1527628435149};\\\", \\\"{x:695,y:529,t:1527628435167};\\\", \\\"{x:674,y:530,t:1527628435183};\\\", \\\"{x:652,y:530,t:1527628435200};\\\", \\\"{x:640,y:530,t:1527628435218};\\\", \\\"{x:627,y:528,t:1527628435234};\\\", \\\"{x:623,y:527,t:1527628435251};\\\", \\\"{x:619,y:527,t:1527628435268};\\\", \\\"{x:612,y:527,t:1527628435284};\\\", \\\"{x:608,y:527,t:1527628435300};\\\", \\\"{x:606,y:527,t:1527628435324};\\\", \\\"{x:605,y:527,t:1527628435396};\\\", \\\"{x:603,y:527,t:1527628435412};\\\", \\\"{x:604,y:526,t:1527628435845};\\\", \\\"{x:605,y:525,t:1527628435853};\\\", \\\"{x:607,y:524,t:1527628435877};\\\", \\\"{x:609,y:523,t:1527628435887};\\\", \\\"{x:613,y:520,t:1527628435902};\\\", \\\"{x:622,y:520,t:1527628435919};\\\", \\\"{x:638,y:515,t:1527628435934};\\\", \\\"{x:645,y:514,t:1527628435952};\\\", \\\"{x:661,y:514,t:1527628435968};\\\", \\\"{x:677,y:512,t:1527628435984};\\\", \\\"{x:696,y:512,t:1527628436002};\\\", \\\"{x:708,y:512,t:1527628436017};\\\", \\\"{x:717,y:512,t:1527628436034};\\\", \\\"{x:724,y:512,t:1527628436053};\\\", \\\"{x:733,y:512,t:1527628436068};\\\", \\\"{x:738,y:512,t:1527628436084};\\\", \\\"{x:748,y:513,t:1527628436101};\\\", \\\"{x:764,y:513,t:1527628436118};\\\", \\\"{x:775,y:513,t:1527628436134};\\\", \\\"{x:794,y:513,t:1527628436151};\\\", \\\"{x:804,y:513,t:1527628436168};\\\", \\\"{x:812,y:513,t:1527628436184};\\\", \\\"{x:814,y:512,t:1527628436202};\\\", \\\"{x:815,y:512,t:1527628436218};\\\", \\\"{x:816,y:512,t:1527628436236};\\\", \\\"{x:819,y:512,t:1527628436253};\\\", \\\"{x:825,y:512,t:1527628436269};\\\", \\\"{x:834,y:511,t:1527628436286};\\\", \\\"{x:839,y:508,t:1527628436302};\\\", \\\"{x:846,y:508,t:1527628436318};\\\", \\\"{x:852,y:508,t:1527628436334};\\\", \\\"{x:855,y:507,t:1527628436351};\\\", \\\"{x:858,y:507,t:1527628436368};\\\", \\\"{x:861,y:507,t:1527628436384};\\\", \\\"{x:867,y:507,t:1527628436401};\\\", \\\"{x:871,y:507,t:1527628436418};\\\", \\\"{x:875,y:507,t:1527628436434};\\\", \\\"{x:876,y:507,t:1527628436451};\\\", \\\"{x:878,y:507,t:1527628436476};\\\", \\\"{x:879,y:507,t:1527628436613};\\\", \\\"{x:879,y:508,t:1527628436677};\\\", \\\"{x:879,y:510,t:1527628436686};\\\", \\\"{x:877,y:512,t:1527628436702};\\\", \\\"{x:873,y:515,t:1527628436718};\\\", \\\"{x:867,y:517,t:1527628436736};\\\", \\\"{x:862,y:519,t:1527628436752};\\\", \\\"{x:857,y:519,t:1527628436768};\\\", \\\"{x:853,y:520,t:1527628436788};\\\", \\\"{x:852,y:520,t:1527628436802};\\\", \\\"{x:850,y:520,t:1527628436818};\\\", \\\"{x:849,y:520,t:1527628436835};\\\", \\\"{x:847,y:520,t:1527628436925};\\\", \\\"{x:847,y:520,t:1527628436989};\\\", \\\"{x:844,y:520,t:1527628437157};\\\", \\\"{x:837,y:520,t:1527628437168};\\\", \\\"{x:815,y:528,t:1527628437185};\\\", \\\"{x:793,y:538,t:1527628437203};\\\", \\\"{x:769,y:549,t:1527628437219};\\\", \\\"{x:745,y:561,t:1527628437235};\\\", \\\"{x:721,y:574,t:1527628437253};\\\", \\\"{x:710,y:580,t:1527628437269};\\\", \\\"{x:701,y:590,t:1527628437286};\\\", \\\"{x:690,y:600,t:1527628437302};\\\", \\\"{x:682,y:607,t:1527628437319};\\\", \\\"{x:674,y:612,t:1527628437335};\\\", \\\"{x:671,y:616,t:1527628437353};\\\", \\\"{x:666,y:623,t:1527628437369};\\\", \\\"{x:660,y:631,t:1527628437384};\\\", \\\"{x:657,y:637,t:1527628437402};\\\", \\\"{x:653,y:641,t:1527628437419};\\\", \\\"{x:650,y:647,t:1527628437436};\\\", \\\"{x:648,y:653,t:1527628437452};\\\", \\\"{x:647,y:655,t:1527628437469};\\\", \\\"{x:645,y:657,t:1527628437486};\\\", \\\"{x:643,y:664,t:1527628437502};\\\", \\\"{x:640,y:669,t:1527628437519};\\\", \\\"{x:637,y:677,t:1527628437536};\\\", \\\"{x:634,y:681,t:1527628437552};\\\", \\\"{x:632,y:691,t:1527628437569};\\\", \\\"{x:631,y:695,t:1527628437586};\\\", \\\"{x:630,y:697,t:1527628437602};\\\", \\\"{x:629,y:701,t:1527628437620};\\\", \\\"{x:624,y:706,t:1527628437636};\\\", \\\"{x:617,y:711,t:1527628437652};\\\", \\\"{x:605,y:720,t:1527628437669};\\\", \\\"{x:589,y:727,t:1527628437686};\\\", \\\"{x:576,y:732,t:1527628437702};\\\", \\\"{x:567,y:734,t:1527628437720};\\\", \\\"{x:560,y:738,t:1527628437736};\\\", \\\"{x:549,y:741,t:1527628437753};\\\", \\\"{x:535,y:743,t:1527628437769};\\\", \\\"{x:524,y:746,t:1527628437786};\\\", \\\"{x:516,y:747,t:1527628437802};\\\", \\\"{x:515,y:747,t:1527628437820};\\\", \\\"{x:514,y:747,t:1527628437845};\\\", \\\"{x:513,y:747,t:1527628438108};\\\", \\\"{x:512,y:751,t:1527628438119};\\\", \\\"{x:511,y:761,t:1527628438136};\\\", \\\"{x:509,y:767,t:1527628438153};\\\", \\\"{x:509,y:778,t:1527628438169};\\\", \\\"{x:509,y:784,t:1527628438186};\\\", \\\"{x:510,y:788,t:1527628438202};\\\", \\\"{x:511,y:789,t:1527628438219};\\\", \\\"{x:512,y:789,t:1527628438236};\\\", \\\"{x:515,y:792,t:1527628438252};\\\", \\\"{x:517,y:792,t:1527628438269};\\\", \\\"{x:518,y:792,t:1527628438286};\\\" ] }, { \\\"rt\\\": 55166, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 744239, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"If its point on the graph is after 12pm and the sum of the duration and at time at which it starts is before or on 8pm\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6815, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"India\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 752060, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8647, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Math or Computer Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 761718, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 2708, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 765820, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"XD9UF\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"romeo\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"XD9UF\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 233, dom: 837, initialDom: 913",
  "javascriptErrors": []
}