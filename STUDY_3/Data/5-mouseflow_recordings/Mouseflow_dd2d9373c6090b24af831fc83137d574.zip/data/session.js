var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "dd2d9373c6090b24af831fc83137d574",
  "created": "2018-05-21T12:07:56.3309689-07:00",
  "lastActivity": "2018-05-21T12:10:39.6258477-07:00",
  "pageViews": [
    {
      "id": "0521563947f2e58d65cccc942b8c62e6fc6f8553",
      "startTime": "2018-05-21T12:07:56.3309689-07:00",
      "endTime": "2018-05-21T12:10:39.6258477-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 163777,
      "engagementTime": 95284,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 163777,
  "engagementTime": 95284,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a546b00135981e8f7a83ca1f4c6e8bbf",
  "gdpr": false
}