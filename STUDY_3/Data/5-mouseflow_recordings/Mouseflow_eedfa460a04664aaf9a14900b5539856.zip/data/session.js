var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "eedfa460a04664aaf9a14900b5539856",
  "created": "2018-06-04T12:16:39.7516316-07:00",
  "lastActivity": "2018-06-04T12:16:51.3146316-07:00",
  "pageViews": [
    {
      "id": "06044008b91ccb7e1775691b7d3f3f39a7fce2ca",
      "startTime": "2018-06-04T12:16:39.7516316-07:00",
      "endTime": "2018-06-04T12:16:51.3146316-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 11563,
      "engagementTime": 11547,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 11563,
  "engagementTime": 11547,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=JYGX2",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2a3cd5bdb47df418aca530f06a63c643",
  "gdpr": false
}