var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "bdf7dc622231f2a71e4951b31a54b9cd",
  "created": "2018-05-25T11:14:03.9543721-07:00",
  "lastActivity": "2018-05-25T11:14:13.9131139-07:00",
  "pageViews": [
    {
      "id": "05250483998c8b942eaf45c1455f148f508a28d5",
      "startTime": "2018-05-25T11:14:04.0371139-07:00",
      "endTime": "2018-05-25T11:14:13.9131139-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/6",
      "visitTime": 9876,
      "engagementTime": 9876,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 9876,
  "engagementTime": 9876,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=KYY96",
    "CONDITION=114",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b465266e71a2a62a45d53a6b8da2e531",
  "gdpr": false
}