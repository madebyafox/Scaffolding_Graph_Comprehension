var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052957388a5e535924635026097817b83f15c9f5"] = {
  "startTime": "2018-05-29T17:16:57.7199408Z",
  "websitePageUrl": "/16",
  "visitTime": 89616,
  "engagementTime": 68946,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "447f70903b0e2e4c6f4f30e82c99ec18",
    "created": "2018-05-29T17:16:57.3169623+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=1FK1X",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "2a86b76a36379096e0dd7bd9840a088e",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/447f70903b0e2e4c6f4f30e82c99ec18/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 181,
      "e": 181,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 181,
      "e": 181,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 660,
      "e": 660,
      "ty": 2,
      "x": 475,
      "y": 865
    },
    {
      "t": 753,
      "e": 753,
      "ty": 41,
      "x": 42480,
      "y": 47475,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 42592,
      "y": 47253,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1802,
      "e": 1802,
      "ty": 2,
      "x": 477,
      "y": 854
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 492,
      "y": 827
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 514,
      "y": 788
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 46864,
      "y": 43209,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 561,
      "y": 670
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 564,
      "y": 640
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 52709,
      "y": 34512,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 566,
      "y": 624
    },
    {
      "t": 2363,
      "e": 2363,
      "ty": 6,
      "x": 573,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 577,
      "y": 587
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 2,
      "x": 581,
      "y": 569
    },
    {
      "t": 2502,
      "e": 2502,
      "ty": 41,
      "x": 54395,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2602,
      "e": 2602,
      "ty": 2,
      "x": 582,
      "y": 564
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 54508,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3680,
      "e": 3680,
      "ty": 3,
      "x": 582,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3680,
      "e": 3680,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3871,
      "e": 3871,
      "ty": 4,
      "x": 54508,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3871,
      "e": 3871,
      "ty": 5,
      "x": 582,
      "y": 564,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 8871,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 17724,
      "e": 8871,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 17724,
      "e": 8871,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17795,
      "e": 8942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "i"
    },
    {
      "t": 17867,
      "e": 9014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 17867,
      "e": 9014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17931,
      "e": 9078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if"
    },
    {
      "t": 17971,
      "e": 9118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17972,
      "e": 9119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18075,
      "e": 9222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if "
    },
    {
      "t": 18115,
      "e": 9262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18122,
      "e": 9269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18195,
      "e": 9342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if t"
    },
    {
      "t": 18268,
      "e": 9415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18268,
      "e": 9415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18347,
      "e": 9494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 18379,
      "e": 9526,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18380,
      "e": 9527,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18467,
      "e": 9614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19011,
      "e": 10158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19011,
      "e": 10158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19164,
      "e": 10311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19387,
      "e": 10534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 19388,
      "e": 10535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19459,
      "e": 10606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 19579,
      "e": 10726,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19579,
      "e": 10726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19659,
      "e": 10806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 19731,
      "e": 10878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 19731,
      "e": 10878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19732,
      "e": 10879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19732,
      "e": 10879,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19739,
      "e": 10886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rt"
    },
    {
      "t": 19755,
      "e": 10902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19787,
      "e": 10934,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19787,
      "e": 10934,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19899,
      "e": 11046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20235,
      "e": 11382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20282,
      "e": 11429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the dort"
    },
    {
      "t": 20401,
      "e": 11548,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the dort"
    },
    {
      "t": 20403,
      "e": 11550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20451,
      "e": 11598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the dor"
    },
    {
      "t": 20547,
      "e": 11694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20627,
      "e": 11774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the do"
    },
    {
      "t": 20835,
      "e": 11982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20836,
      "e": 11983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20939,
      "e": 12086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21115,
      "e": 12262,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21116,
      "e": 12263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21267,
      "e": 12414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22315,
      "e": 13462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22316,
      "e": 13463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22379,
      "e": 13526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22475,
      "e": 13622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22475,
      "e": 13622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22539,
      "e": 13686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22539,
      "e": 13686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22547,
      "e": 13694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 22635,
      "e": 13782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22731,
      "e": 13878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22731,
      "e": 13878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22835,
      "e": 13982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23699,
      "e": 14846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 23802,
      "e": 14949,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the dot is "
    },
    {
      "t": 23827,
      "e": 14974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the dot is "
    },
    {
      "t": 24755,
      "e": 15902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 24755,
      "e": 15902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24827,
      "e": 15974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 24987,
      "e": 16134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24987,
      "e": 16134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25059,
      "e": 16206,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25091,
      "e": 16238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25091,
      "e": 16238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25155,
      "e": 16302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 25259,
      "e": 16406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25259,
      "e": 16406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25339,
      "e": 16486,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 25491,
      "e": 16638,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 25492,
      "e": 16639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25571,
      "e": 16718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 25827,
      "e": 16974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25827,
      "e": 16974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25899,
      "e": 17046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26002,
      "e": 17149,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the dot is direct"
    },
    {
      "t": 26499,
      "e": 17646,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 26500,
      "e": 17647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26571,
      "e": 17718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 26603,
      "e": 17750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 26603,
      "e": 17750,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26667,
      "e": 17814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 26707,
      "e": 17854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26707,
      "e": 17854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26811,
      "e": 17958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27939,
      "e": 19086,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 27939,
      "e": 19086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28043,
      "e": 19190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28098,
      "e": 19245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 28099,
      "e": 19246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28187,
      "e": 19334,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 28355,
      "e": 19502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28356,
      "e": 19503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28443,
      "e": 19590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28683,
      "e": 19830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 28684,
      "e": 19831,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28763,
      "e": 19910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28763,
      "e": 19910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28811,
      "e": 19958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 28915,
      "e": 20062,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28923,
      "e": 20070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28923,
      "e": 20070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29035,
      "e": 20182,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29107,
      "e": 20254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29107,
      "e": 20254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29171,
      "e": 20318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29219,
      "e": 20366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29219,
      "e": 20366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29227,
      "e": 20374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 29227,
      "e": 20374,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29275,
      "e": 20422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hj"
    },
    {
      "t": 29282,
      "e": 20429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29315,
      "e": 20462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29315,
      "e": 20462,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29410,
      "e": 20557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29411,
      "e": 20557,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29419,
      "e": 20565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 29514,
      "e": 20660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29747,
      "e": 20893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29811,
      "e": 20957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the dot is directly above thje"
    },
    {
      "t": 29907,
      "e": 21053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29979,
      "e": 21125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the dot is directly above thj"
    },
    {
      "t": 30059,
      "e": 21205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30138,
      "e": 21284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the dot is directly above th"
    },
    {
      "t": 30666,
      "e": 21812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30667,
      "e": 21813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30755,
      "e": 21901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 31483,
      "e": 22629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31483,
      "e": 22629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31603,
      "e": 22749,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the dot is directly above the "
    },
    {
      "t": 31627,
      "e": 22773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32244,
      "e": 23390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 32244,
      "e": 23390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32323,
      "e": 23469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 32323,
      "e": 23469,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32379,
      "e": 23525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 32459,
      "e": 23605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32795,
      "e": 23941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 32971,
      "e": 24117,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32971,
      "e": 24117,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33051,
      "e": 24197,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 33243,
      "e": 24389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33244,
      "e": 24390,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33315,
      "e": 24461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 33315,
      "e": 24461,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35747,
      "e": 26893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35747,
      "e": 26893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35892,
      "e": 27038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36179,
      "e": 27325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 36179,
      "e": 27325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36251,
      "e": 27397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 36347,
      "e": 27493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36347,
      "e": 27493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36451,
      "e": 27597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36587,
      "e": 27733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 36587,
      "e": 27733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36660,
      "e": 27806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 36995,
      "e": 28141,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 36995,
      "e": 28141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37067,
      "e": 28213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 38001,
      "e": 29147,
      "ty": 2,
      "x": 580,
      "y": 565
    },
    {
      "t": 38001,
      "e": 29147,
      "ty": 41,
      "x": 54283,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38025,
      "e": 29171,
      "ty": 7,
      "x": 471,
      "y": 624,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38092,
      "e": 29238,
      "ty": 6,
      "x": 378,
      "y": 654,
      "ta": "#strategyButton"
    },
    {
      "t": 38101,
      "e": 29247,
      "ty": 2,
      "x": 378,
      "y": 654
    },
    {
      "t": 38201,
      "e": 29347,
      "ty": 2,
      "x": 377,
      "y": 658
    },
    {
      "t": 38251,
      "e": 29397,
      "ty": 41,
      "x": 19882,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 38301,
      "e": 29447,
      "ty": 2,
      "x": 375,
      "y": 672
    },
    {
      "t": 38401,
      "e": 29547,
      "ty": 2,
      "x": 375,
      "y": 673
    },
    {
      "t": 38501,
      "e": 29647,
      "ty": 41,
      "x": 19882,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 38608,
      "e": 29754,
      "ty": 3,
      "x": 375,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 38608,
      "e": 29754,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "if the dot is directly above the 12PM mark"
    },
    {
      "t": 38608,
      "e": 29754,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38608,
      "e": 29754,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 38719,
      "e": 29865,
      "ty": 4,
      "x": 19882,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 38729,
      "e": 29875,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 38730,
      "e": 29876,
      "ty": 5,
      "x": 375,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 38739,
      "e": 29885,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 39733,
      "e": 30879,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 40001,
      "e": 31147,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40501,
      "e": 31647,
      "ty": 2,
      "x": 391,
      "y": 675
    },
    {
      "t": 40501,
      "e": 31647,
      "ty": 41,
      "x": 13189,
      "y": 36949,
      "ta": "html > body"
    },
    {
      "t": 40576,
      "e": 31722,
      "ty": 6,
      "x": 948,
      "y": 684,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40594,
      "e": 31740,
      "ty": 7,
      "x": 1046,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40602,
      "e": 31748,
      "ty": 2,
      "x": 1046,
      "y": 687
    },
    {
      "t": 40701,
      "e": 31847,
      "ty": 2,
      "x": 1126,
      "y": 690
    },
    {
      "t": 40751,
      "e": 31897,
      "ty": 41,
      "x": 38294,
      "y": 36783,
      "ta": "html > body"
    },
    {
      "t": 40777,
      "e": 31923,
      "ty": 6,
      "x": 1106,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40794,
      "e": 31940,
      "ty": 7,
      "x": 1091,
      "y": 640,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40801,
      "e": 31947,
      "ty": 2,
      "x": 1091,
      "y": 640
    },
    {
      "t": 40901,
      "e": 32047,
      "ty": 2,
      "x": 1059,
      "y": 622
    },
    {
      "t": 41001,
      "e": 32147,
      "ty": 2,
      "x": 1037,
      "y": 597
    },
    {
      "t": 41002,
      "e": 32148,
      "ty": 41,
      "x": 49529,
      "y": 9865,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 41101,
      "e": 32247,
      "ty": 2,
      "x": 1035,
      "y": 584
    },
    {
      "t": 41178,
      "e": 32324,
      "ty": 6,
      "x": 1035,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41201,
      "e": 32347,
      "ty": 2,
      "x": 1035,
      "y": 571
    },
    {
      "t": 41252,
      "e": 32398,
      "ty": 41,
      "x": 49313,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41302,
      "e": 32448,
      "ty": 2,
      "x": 1037,
      "y": 561
    },
    {
      "t": 41401,
      "e": 32547,
      "ty": 2,
      "x": 1037,
      "y": 560
    },
    {
      "t": 41447,
      "e": 32593,
      "ty": 3,
      "x": 1037,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41447,
      "e": 32593,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41501,
      "e": 32647,
      "ty": 41,
      "x": 49529,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41551,
      "e": 32697,
      "ty": 4,
      "x": 49529,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41551,
      "e": 32697,
      "ty": 5,
      "x": 1037,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42651,
      "e": 33797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 42651,
      "e": 33797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42723,
      "e": 33869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 42810,
      "e": 33956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 42811,
      "e": 33957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42835,
      "e": 33981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 43001,
      "e": 34147,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 43947,
      "e": 35093,
      "ty": 7,
      "x": 1054,
      "y": 579,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44002,
      "e": 35148,
      "ty": 2,
      "x": 1047,
      "y": 622
    },
    {
      "t": 44002,
      "e": 35148,
      "ty": 41,
      "x": 51692,
      "y": 49151,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 44102,
      "e": 35248,
      "ty": 2,
      "x": 1042,
      "y": 634
    },
    {
      "t": 44201,
      "e": 35347,
      "ty": 2,
      "x": 1036,
      "y": 637
    },
    {
      "t": 44251,
      "e": 35397,
      "ty": 41,
      "x": 48448,
      "y": 41575,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 44297,
      "e": 35443,
      "ty": 6,
      "x": 1029,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44302,
      "e": 35448,
      "ty": 2,
      "x": 1029,
      "y": 647
    },
    {
      "t": 44401,
      "e": 35547,
      "ty": 2,
      "x": 1027,
      "y": 652
    },
    {
      "t": 44501,
      "e": 35647,
      "ty": 2,
      "x": 1025,
      "y": 654
    },
    {
      "t": 44501,
      "e": 35647,
      "ty": 41,
      "x": 46934,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44602,
      "e": 35748,
      "ty": 2,
      "x": 1024,
      "y": 663
    },
    {
      "t": 44687,
      "e": 35833,
      "ty": 3,
      "x": 1024,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44687,
      "e": 35833,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 44687,
      "e": 35833,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44688,
      "e": 35834,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44751,
      "e": 35897,
      "ty": 41,
      "x": 46718,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44823,
      "e": 35969,
      "ty": 4,
      "x": 46718,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44823,
      "e": 35969,
      "ty": 5,
      "x": 1024,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45371,
      "e": 36517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 45643,
      "e": 36789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 45643,
      "e": 36789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45723,
      "e": 36869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 45731,
      "e": 36877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 45875,
      "e": 37021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 45875,
      "e": 37021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45947,
      "e": 37093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 46051,
      "e": 37197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 46051,
      "e": 37197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46123,
      "e": 37269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 46163,
      "e": 37309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 46163,
      "e": 37309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46251,
      "e": 37397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 46419,
      "e": 37565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 46419,
      "e": 37565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46499,
      "e": 37645,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 46602,
      "e": 37748,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 46746,
      "e": 37892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 46747,
      "e": 37893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46827,
      "e": 37973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 46891,
      "e": 38037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 46891,
      "e": 38037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47001,
      "e": 38147,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United "
    },
    {
      "t": 47010,
      "e": 38156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 47027,
      "e": 38173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 47155,
      "e": 38301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 47155,
      "e": 38301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47202,
      "e": 38348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 47299,
      "e": 38445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 47451,
      "e": 38597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 47451,
      "e": 38597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47523,
      "e": 38669,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 47755,
      "e": 38901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 47755,
      "e": 38901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 47835,
      "e": 38981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 48011,
      "e": 39157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 48011,
      "e": 39157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48067,
      "e": 39213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 48202,
      "e": 39348,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United Stat"
    },
    {
      "t": 48699,
      "e": 39845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 48699,
      "e": 39845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48802,
      "e": 39948,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United State"
    },
    {
      "t": 48811,
      "e": 39957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 48946,
      "e": 40092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 48947,
      "e": 40093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49042,
      "e": 40188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||s"
    },
    {
      "t": 49701,
      "e": 40847,
      "ty": 2,
      "x": 1023,
      "y": 664
    },
    {
      "t": 49750,
      "e": 40896,
      "ty": 41,
      "x": 44987,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49751,
      "e": 40897,
      "ty": 7,
      "x": 1013,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49800,
      "e": 40946,
      "ty": 2,
      "x": 1013,
      "y": 669
    },
    {
      "t": 49868,
      "e": 41014,
      "ty": 6,
      "x": 1007,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 49900,
      "e": 41046,
      "ty": 2,
      "x": 1006,
      "y": 678
    },
    {
      "t": 50001,
      "e": 41147,
      "ty": 2,
      "x": 1000,
      "y": 690
    },
    {
      "t": 50001,
      "e": 41147,
      "ty": 41,
      "x": 53640,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50001,
      "e": 41147,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50127,
      "e": 41273,
      "ty": 3,
      "x": 1000,
      "y": 690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50127,
      "e": 41273,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 50127,
      "e": 41273,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50127,
      "e": 41273,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50183,
      "e": 41329,
      "ty": 4,
      "x": 53640,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50184,
      "e": 41330,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50184,
      "e": 41330,
      "ty": 5,
      "x": 1000,
      "y": 690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 50184,
      "e": 41330,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 51195,
      "e": 42341,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 52401,
      "e": 43547,
      "ty": 2,
      "x": 1048,
      "y": 577
    },
    {
      "t": 52501,
      "e": 43647,
      "ty": 2,
      "x": 1077,
      "y": 351
    },
    {
      "t": 52501,
      "e": 43647,
      "ty": 41,
      "x": 60655,
      "y": 14198,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 52601,
      "e": 43747,
      "ty": 2,
      "x": 1003,
      "y": 245
    },
    {
      "t": 52701,
      "e": 43847,
      "ty": 2,
      "x": 978,
      "y": 231
    },
    {
      "t": 52751,
      "e": 43897,
      "ty": 41,
      "x": 36210,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 52801,
      "e": 43947,
      "ty": 2,
      "x": 951,
      "y": 242
    },
    {
      "t": 52901,
      "e": 44047,
      "ty": 2,
      "x": 921,
      "y": 243
    },
    {
      "t": 53001,
      "e": 44147,
      "ty": 2,
      "x": 883,
      "y": 246
    },
    {
      "t": 53001,
      "e": 44147,
      "ty": 41,
      "x": 50424,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 53101,
      "e": 44247,
      "ty": 2,
      "x": 842,
      "y": 241
    },
    {
      "t": 53159,
      "e": 44305,
      "ty": 6,
      "x": 839,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53201,
      "e": 44347,
      "ty": 2,
      "x": 839,
      "y": 241
    },
    {
      "t": 53251,
      "e": 44397,
      "ty": 41,
      "x": 63408,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53501,
      "e": 44647,
      "ty": 2,
      "x": 837,
      "y": 241
    },
    {
      "t": 53501,
      "e": 44647,
      "ty": 41,
      "x": 53325,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53601,
      "e": 44747,
      "ty": 2,
      "x": 828,
      "y": 237
    },
    {
      "t": 53750,
      "e": 44896,
      "ty": 41,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53847,
      "e": 44993,
      "ty": 3,
      "x": 828,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53847,
      "e": 44993,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53998,
      "e": 45144,
      "ty": 4,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53998,
      "e": 45144,
      "ty": 5,
      "x": 828,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53999,
      "e": 45145,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 56001,
      "e": 47147,
      "ty": 2,
      "x": 828,
      "y": 240
    },
    {
      "t": 56001,
      "e": 47147,
      "ty": 41,
      "x": 7955,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56022,
      "e": 47168,
      "ty": 7,
      "x": 831,
      "y": 252,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 56039,
      "e": 47185,
      "ty": 6,
      "x": 833,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 56101,
      "e": 47247,
      "ty": 2,
      "x": 835,
      "y": 272
    },
    {
      "t": 56106,
      "e": 47252,
      "ty": 7,
      "x": 835,
      "y": 276,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 56174,
      "e": 47320,
      "ty": 6,
      "x": 837,
      "y": 288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 56201,
      "e": 47347,
      "ty": 2,
      "x": 837,
      "y": 291
    },
    {
      "t": 56240,
      "e": 47386,
      "ty": 7,
      "x": 837,
      "y": 304,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 56251,
      "e": 47397,
      "ty": 41,
      "x": 4882,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 56291,
      "e": 47437,
      "ty": 6,
      "x": 838,
      "y": 321,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56300,
      "e": 47446,
      "ty": 2,
      "x": 838,
      "y": 321
    },
    {
      "t": 56306,
      "e": 47452,
      "ty": 7,
      "x": 838,
      "y": 329,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 56401,
      "e": 47547,
      "ty": 2,
      "x": 841,
      "y": 372
    },
    {
      "t": 56501,
      "e": 47647,
      "ty": 2,
      "x": 841,
      "y": 409
    },
    {
      "t": 56501,
      "e": 47647,
      "ty": 41,
      "x": 22918,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 56591,
      "e": 47648,
      "ty": 6,
      "x": 838,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56601,
      "e": 47658,
      "ty": 2,
      "x": 838,
      "y": 436
    },
    {
      "t": 56640,
      "e": 47697,
      "ty": 7,
      "x": 838,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 56701,
      "e": 47758,
      "ty": 2,
      "x": 838,
      "y": 459
    },
    {
      "t": 56723,
      "e": 47780,
      "ty": 6,
      "x": 836,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 56751,
      "e": 47808,
      "ty": 41,
      "x": 48284,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 56801,
      "e": 47858,
      "ty": 2,
      "x": 836,
      "y": 465
    },
    {
      "t": 56901,
      "e": 47958,
      "ty": 2,
      "x": 836,
      "y": 467
    },
    {
      "t": 57001,
      "e": 48058,
      "ty": 41,
      "x": 48284,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 57047,
      "e": 48104,
      "ty": 3,
      "x": 836,
      "y": 467,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 57047,
      "e": 48104,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 57047,
      "e": 48104,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 57159,
      "e": 48216,
      "ty": 4,
      "x": 48284,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 57159,
      "e": 48216,
      "ty": 5,
      "x": 836,
      "y": 467,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 57159,
      "e": 48216,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 58461,
      "e": 49518,
      "ty": 7,
      "x": 836,
      "y": 481,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 58495,
      "e": 49552,
      "ty": 6,
      "x": 836,
      "y": 499,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58504,
      "e": 49561,
      "ty": 2,
      "x": 836,
      "y": 499
    },
    {
      "t": 58504,
      "e": 49561,
      "ty": 41,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58527,
      "e": 49584,
      "ty": 7,
      "x": 836,
      "y": 510,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 58562,
      "e": 49619,
      "ty": 6,
      "x": 832,
      "y": 523,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 58595,
      "e": 49652,
      "ty": 7,
      "x": 828,
      "y": 537,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 58604,
      "e": 49661,
      "ty": 2,
      "x": 828,
      "y": 537
    },
    {
      "t": 58628,
      "e": 49685,
      "ty": 6,
      "x": 826,
      "y": 549,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 58644,
      "e": 49701,
      "ty": 7,
      "x": 825,
      "y": 555,
      "ta": "jspsych-survey-multi-choice-response-1[5]_mf"
    },
    {
      "t": 58704,
      "e": 49761,
      "ty": 2,
      "x": 825,
      "y": 570
    },
    {
      "t": 58754,
      "e": 49811,
      "ty": 41,
      "x": 849,
      "y": 33253,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 58803,
      "e": 49860,
      "ty": 2,
      "x": 825,
      "y": 683
    },
    {
      "t": 58904,
      "e": 49961,
      "ty": 2,
      "x": 820,
      "y": 761
    },
    {
      "t": 59004,
      "e": 50061,
      "ty": 2,
      "x": 820,
      "y": 763
    },
    {
      "t": 59004,
      "e": 50061,
      "ty": 41,
      "x": 27963,
      "y": 41824,
      "ta": "html > body"
    },
    {
      "t": 59104,
      "e": 50161,
      "ty": 2,
      "x": 820,
      "y": 773
    },
    {
      "t": 59204,
      "e": 50261,
      "ty": 2,
      "x": 820,
      "y": 777
    },
    {
      "t": 59254,
      "e": 50311,
      "ty": 41,
      "x": 0,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 59304,
      "e": 50361,
      "ty": 2,
      "x": 821,
      "y": 780
    },
    {
      "t": 59404,
      "e": 50461,
      "ty": 2,
      "x": 823,
      "y": 787
    },
    {
      "t": 59504,
      "e": 50561,
      "ty": 41,
      "x": 883,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 61604,
      "e": 52661,
      "ty": 2,
      "x": 823,
      "y": 785
    },
    {
      "t": 61704,
      "e": 52761,
      "ty": 2,
      "x": 823,
      "y": 769
    },
    {
      "t": 61754,
      "e": 52811,
      "ty": 41,
      "x": 658,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 61804,
      "e": 52861,
      "ty": 2,
      "x": 825,
      "y": 736
    },
    {
      "t": 61904,
      "e": 52961,
      "ty": 2,
      "x": 824,
      "y": 700
    },
    {
      "t": 62004,
      "e": 53061,
      "ty": 2,
      "x": 825,
      "y": 693
    },
    {
      "t": 62004,
      "e": 53061,
      "ty": 41,
      "x": 901,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 62204,
      "e": 53261,
      "ty": 2,
      "x": 826,
      "y": 694
    },
    {
      "t": 62230,
      "e": 53261,
      "ty": 6,
      "x": 826,
      "y": 697,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62254,
      "e": 53285,
      "ty": 41,
      "x": 0,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 62304,
      "e": 53335,
      "ty": 2,
      "x": 828,
      "y": 701
    },
    {
      "t": 62504,
      "e": 53535,
      "ty": 41,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65514,
      "e": 56545,
      "ty": 3,
      "x": 828,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65514,
      "e": 56545,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 65515,
      "e": 56546,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65674,
      "e": 56705,
      "ty": 4,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65674,
      "e": 56705,
      "ty": 5,
      "x": 828,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 65674,
      "e": 56705,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 66004,
      "e": 57035,
      "ty": 2,
      "x": 828,
      "y": 702
    },
    {
      "t": 66004,
      "e": 57035,
      "ty": 41,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66017,
      "e": 57048,
      "ty": 7,
      "x": 824,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 66105,
      "e": 57136,
      "ty": 2,
      "x": 822,
      "y": 705
    },
    {
      "t": 66204,
      "e": 57235,
      "ty": 2,
      "x": 818,
      "y": 708
    },
    {
      "t": 66254,
      "e": 57285,
      "ty": 41,
      "x": 27791,
      "y": 39830,
      "ta": "html > body"
    },
    {
      "t": 66284,
      "e": 57315,
      "ty": 6,
      "x": 828,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 66301,
      "e": 57332,
      "ty": 7,
      "x": 837,
      "y": 780,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 66301,
      "e": 57332,
      "ty": 6,
      "x": 837,
      "y": 780,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 66305,
      "e": 57336,
      "ty": 2,
      "x": 837,
      "y": 780
    },
    {
      "t": 66317,
      "e": 57348,
      "ty": 7,
      "x": 839,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 66404,
      "e": 57435,
      "ty": 2,
      "x": 860,
      "y": 867
    },
    {
      "t": 66503,
      "e": 57534,
      "ty": 2,
      "x": 890,
      "y": 922
    },
    {
      "t": 66503,
      "e": 57534,
      "ty": 41,
      "x": 16275,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 67254,
      "e": 58285,
      "ty": 41,
      "x": 15325,
      "y": 14043,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 67304,
      "e": 58335,
      "ty": 2,
      "x": 886,
      "y": 927
    },
    {
      "t": 67404,
      "e": 58435,
      "ty": 2,
      "x": 875,
      "y": 939
    },
    {
      "t": 67503,
      "e": 58534,
      "ty": 2,
      "x": 848,
      "y": 948
    },
    {
      "t": 67503,
      "e": 58534,
      "ty": 41,
      "x": 6307,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 67603,
      "e": 58634,
      "ty": 2,
      "x": 838,
      "y": 951
    },
    {
      "t": 67703,
      "e": 58734,
      "ty": 2,
      "x": 832,
      "y": 953
    },
    {
      "t": 67753,
      "e": 58784,
      "ty": 41,
      "x": 8556,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 67803,
      "e": 58834,
      "ty": 2,
      "x": 831,
      "y": 955
    },
    {
      "t": 67849,
      "e": 58880,
      "ty": 6,
      "x": 831,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 67905,
      "e": 58936,
      "ty": 2,
      "x": 831,
      "y": 956
    },
    {
      "t": 67929,
      "e": 58960,
      "ty": 3,
      "x": 831,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 67929,
      "e": 58960,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 67931,
      "e": 58962,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68003,
      "e": 59034,
      "ty": 2,
      "x": 831,
      "y": 957
    },
    {
      "t": 68003,
      "e": 59034,
      "ty": 41,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68066,
      "e": 59097,
      "ty": 4,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68066,
      "e": 59097,
      "ty": 5,
      "x": 831,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68066,
      "e": 59097,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 68168,
      "e": 59199,
      "ty": 7,
      "x": 833,
      "y": 969,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68203,
      "e": 59234,
      "ty": 2,
      "x": 840,
      "y": 989
    },
    {
      "t": 68254,
      "e": 59285,
      "ty": 41,
      "x": 6307,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 68269,
      "e": 59300,
      "ty": 6,
      "x": 850,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68303,
      "e": 59334,
      "ty": 2,
      "x": 852,
      "y": 1013
    },
    {
      "t": 68404,
      "e": 59435,
      "ty": 2,
      "x": 854,
      "y": 1016
    },
    {
      "t": 68503,
      "e": 59534,
      "ty": 41,
      "x": 12667,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68554,
      "e": 59585,
      "ty": 3,
      "x": 854,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68554,
      "e": 59585,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 68554,
      "e": 59585,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68690,
      "e": 59721,
      "ty": 4,
      "x": 13182,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68690,
      "e": 59721,
      "ty": 5,
      "x": 855,
      "y": 1017,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68692,
      "e": 59723,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 68693,
      "e": 59724,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 68694,
      "e": 59725,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 68703,
      "e": 59734,
      "ty": 2,
      "x": 855,
      "y": 1017
    },
    {
      "t": 68753,
      "e": 59784,
      "ty": 41,
      "x": 29168,
      "y": 55895,
      "ta": "html > body"
    },
    {
      "t": 69304,
      "e": 60335,
      "ty": 2,
      "x": 856,
      "y": 1017
    },
    {
      "t": 69504,
      "e": 60535,
      "ty": 41,
      "x": 29203,
      "y": 55895,
      "ta": "html > body"
    },
    {
      "t": 70003,
      "e": 61034,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70012,
      "e": 61043,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 80004,
      "e": 65535,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 86205,
      "e": 65535,
      "ty": 2,
      "x": 869,
      "y": 1023
    },
    {
      "t": 86254,
      "e": 65584,
      "ty": 41,
      "x": 28856,
      "y": 62509,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86304,
      "e": 65634,
      "ty": 2,
      "x": 938,
      "y": 1045
    },
    {
      "t": 86404,
      "e": 65734,
      "ty": 2,
      "x": 955,
      "y": 1054
    },
    {
      "t": 86504,
      "e": 65834,
      "ty": 2,
      "x": 959,
      "y": 1062
    },
    {
      "t": 86504,
      "e": 65834,
      "ty": 41,
      "x": 32742,
      "y": 64794,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86604,
      "e": 65934,
      "ty": 2,
      "x": 962,
      "y": 1064
    },
    {
      "t": 86704,
      "e": 66034,
      "ty": 2,
      "x": 957,
      "y": 1070
    },
    {
      "t": 86754,
      "e": 66084,
      "ty": 41,
      "x": 32644,
      "y": 65348,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 86804,
      "e": 66134,
      "ty": 2,
      "x": 957,
      "y": 1071
    },
    {
      "t": 86810,
      "e": 66140,
      "ty": 6,
      "x": 957,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 86904,
      "e": 66234,
      "ty": 2,
      "x": 956,
      "y": 1076
    },
    {
      "t": 87004,
      "e": 66334,
      "ty": 2,
      "x": 956,
      "y": 1080
    },
    {
      "t": 87004,
      "e": 66334,
      "ty": 41,
      "x": 25394,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 87105,
      "e": 66435,
      "ty": 2,
      "x": 956,
      "y": 1081
    },
    {
      "t": 87122,
      "e": 66452,
      "ty": 3,
      "x": 956,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 87122,
      "e": 66452,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 87254,
      "e": 66584,
      "ty": 41,
      "x": 25394,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 87265,
      "e": 66595,
      "ty": 4,
      "x": 25394,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 87265,
      "e": 66595,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 87266,
      "e": 66596,
      "ty": 5,
      "x": 956,
      "y": 1081,
      "ta": "#start"
    },
    {
      "t": 87267,
      "e": 66597,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 88300,
      "e": 67630,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 89616,
      "e": 68946,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 1942, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 1946, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 5850, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 8885, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 8070, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"oscar\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 17964, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 2082, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 21169, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 1161, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 23333, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 7659, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 32287, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1051,y:945,t:1527613700903};\\\", \\\"{x:1046,y:939,t:1527613700910};\\\", \\\"{x:1040,y:932,t:1527613700922};\\\", \\\"{x:1031,y:923,t:1527613700937};\\\", \\\"{x:1018,y:913,t:1527613700954};\\\", \\\"{x:997,y:898,t:1527613700971};\\\", \\\"{x:978,y:885,t:1527613700987};\\\", \\\"{x:952,y:867,t:1527613701004};\\\", \\\"{x:912,y:842,t:1527613701021};\\\", \\\"{x:889,y:832,t:1527613701038};\\\", \\\"{x:876,y:827,t:1527613701054};\\\", \\\"{x:873,y:825,t:1527613701070};\\\", \\\"{x:872,y:825,t:1527613701087};\\\", \\\"{x:873,y:819,t:1527613701910};\\\", \\\"{x:887,y:811,t:1527613701924};\\\", \\\"{x:918,y:787,t:1527613701938};\\\", \\\"{x:973,y:741,t:1527613701956};\\\", \\\"{x:1028,y:670,t:1527613701973};\\\", \\\"{x:1083,y:566,t:1527613701988};\\\", \\\"{x:1163,y:378,t:1527613702005};\\\", \\\"{x:1217,y:238,t:1527613702021};\\\", \\\"{x:1249,y:135,t:1527613702039};\\\", \\\"{x:1271,y:68,t:1527613702055};\\\", \\\"{x:1283,y:35,t:1527613702073};\\\", \\\"{x:1290,y:16,t:1527613702088};\\\", \\\"{x:1294,y:16,t:1527613702106};\\\", \\\"{x:1296,y:16,t:1527613702126};\\\", \\\"{x:1297,y:16,t:1527613702138};\\\", \\\"{x:1298,y:16,t:1527613702155};\\\", \\\"{x:1302,y:16,t:1527613702172};\\\", \\\"{x:1307,y:16,t:1527613702188};\\\", \\\"{x:1313,y:16,t:1527613702205};\\\", \\\"{x:1317,y:16,t:1527613702222};\\\", \\\"{x:1323,y:19,t:1527613702238};\\\", \\\"{x:1330,y:23,t:1527613702255};\\\", \\\"{x:1338,y:35,t:1527613702272};\\\", \\\"{x:1351,y:46,t:1527613702288};\\\", \\\"{x:1360,y:59,t:1527613702305};\\\", \\\"{x:1369,y:68,t:1527613702322};\\\", \\\"{x:1377,y:78,t:1527613702338};\\\", \\\"{x:1383,y:83,t:1527613702355};\\\", \\\"{x:1386,y:86,t:1527613702372};\\\", \\\"{x:1389,y:89,t:1527613702388};\\\", \\\"{x:1392,y:92,t:1527613702405};\\\", \\\"{x:1396,y:95,t:1527613702422};\\\", \\\"{x:1400,y:99,t:1527613702438};\\\", \\\"{x:1405,y:103,t:1527613702455};\\\", \\\"{x:1408,y:104,t:1527613702472};\\\", \\\"{x:1410,y:105,t:1527613702489};\\\", \\\"{x:1410,y:106,t:1527613702505};\\\", \\\"{x:1414,y:108,t:1527613702522};\\\", \\\"{x:1418,y:111,t:1527613702539};\\\", \\\"{x:1423,y:114,t:1527613702556};\\\", \\\"{x:1428,y:117,t:1527613702572};\\\", \\\"{x:1432,y:121,t:1527613702590};\\\", \\\"{x:1433,y:122,t:1527613702606};\\\", \\\"{x:1434,y:123,t:1527613702622};\\\", \\\"{x:1436,y:125,t:1527613702640};\\\", \\\"{x:1436,y:126,t:1527613702655};\\\", \\\"{x:1437,y:127,t:1527613702673};\\\", \\\"{x:1437,y:128,t:1527613702689};\\\", \\\"{x:1439,y:130,t:1527613702706};\\\", \\\"{x:1440,y:132,t:1527613702723};\\\", \\\"{x:1441,y:132,t:1527613702813};\\\", \\\"{x:1442,y:133,t:1527613702853};\\\", \\\"{x:1443,y:135,t:1527613702869};\\\", \\\"{x:1444,y:136,t:1527613702877};\\\", \\\"{x:1445,y:139,t:1527613702889};\\\", \\\"{x:1446,y:145,t:1527613702905};\\\", \\\"{x:1451,y:156,t:1527613702922};\\\", \\\"{x:1455,y:175,t:1527613702939};\\\", \\\"{x:1458,y:198,t:1527613702956};\\\", \\\"{x:1461,y:230,t:1527613702972};\\\", \\\"{x:1466,y:312,t:1527613702989};\\\", \\\"{x:1466,y:390,t:1527613703006};\\\", \\\"{x:1466,y:476,t:1527613703022};\\\", \\\"{x:1466,y:557,t:1527613703040};\\\", \\\"{x:1462,y:628,t:1527613703056};\\\", \\\"{x:1462,y:697,t:1527613703072};\\\", \\\"{x:1462,y:745,t:1527613703089};\\\", \\\"{x:1462,y:775,t:1527613703107};\\\", \\\"{x:1461,y:804,t:1527613703123};\\\", \\\"{x:1455,y:827,t:1527613703140};\\\", \\\"{x:1447,y:849,t:1527613703157};\\\", \\\"{x:1443,y:864,t:1527613703172};\\\", \\\"{x:1433,y:879,t:1527613703190};\\\", \\\"{x:1424,y:885,t:1527613703207};\\\", \\\"{x:1409,y:890,t:1527613703222};\\\", \\\"{x:1396,y:895,t:1527613703239};\\\", \\\"{x:1385,y:901,t:1527613703256};\\\", \\\"{x:1381,y:902,t:1527613703272};\\\", \\\"{x:1377,y:904,t:1527613703289};\\\", \\\"{x:1376,y:904,t:1527613703307};\\\", \\\"{x:1376,y:905,t:1527613703349};\\\", \\\"{x:1373,y:907,t:1527613703357};\\\", \\\"{x:1369,y:909,t:1527613703372};\\\", \\\"{x:1360,y:919,t:1527613703389};\\\", \\\"{x:1350,y:925,t:1527613703406};\\\", \\\"{x:1344,y:929,t:1527613703422};\\\", \\\"{x:1336,y:933,t:1527613703440};\\\", \\\"{x:1330,y:935,t:1527613703456};\\\", \\\"{x:1322,y:938,t:1527613703473};\\\", \\\"{x:1316,y:941,t:1527613703490};\\\", \\\"{x:1311,y:944,t:1527613703507};\\\", \\\"{x:1304,y:948,t:1527613703523};\\\", \\\"{x:1295,y:950,t:1527613703539};\\\", \\\"{x:1286,y:952,t:1527613703556};\\\", \\\"{x:1276,y:954,t:1527613703574};\\\", \\\"{x:1272,y:955,t:1527613703589};\\\", \\\"{x:1270,y:955,t:1527613703613};\\\", \\\"{x:1269,y:955,t:1527613703623};\\\", \\\"{x:1269,y:956,t:1527613703640};\\\", \\\"{x:1268,y:956,t:1527613703656};\\\", \\\"{x:1268,y:957,t:1527613703674};\\\", \\\"{x:1267,y:958,t:1527613703690};\\\", \\\"{x:1269,y:958,t:1527613703830};\\\", \\\"{x:1270,y:958,t:1527613703854};\\\", \\\"{x:1271,y:958,t:1527613703862};\\\", \\\"{x:1272,y:958,t:1527613703873};\\\", \\\"{x:1277,y:959,t:1527613703890};\\\", \\\"{x:1281,y:961,t:1527613703906};\\\", \\\"{x:1283,y:961,t:1527613703923};\\\", \\\"{x:1285,y:961,t:1527613703940};\\\", \\\"{x:1286,y:961,t:1527613703981};\\\", \\\"{x:1287,y:961,t:1527613703996};\\\", \\\"{x:1288,y:961,t:1527613704020};\\\", \\\"{x:1289,y:961,t:1527613704093};\\\", \\\"{x:1291,y:961,t:1527613704109};\\\", \\\"{x:1292,y:961,t:1527613704141};\\\", \\\"{x:1292,y:959,t:1527613704156};\\\", \\\"{x:1293,y:945,t:1527613704172};\\\", \\\"{x:1294,y:935,t:1527613704190};\\\", \\\"{x:1295,y:925,t:1527613704206};\\\", \\\"{x:1295,y:911,t:1527613704223};\\\", \\\"{x:1294,y:903,t:1527613704241};\\\", \\\"{x:1292,y:895,t:1527613704256};\\\", \\\"{x:1285,y:888,t:1527613704273};\\\", \\\"{x:1281,y:877,t:1527613704290};\\\", \\\"{x:1276,y:865,t:1527613704306};\\\", \\\"{x:1274,y:856,t:1527613704324};\\\", \\\"{x:1273,y:852,t:1527613704340};\\\", \\\"{x:1271,y:844,t:1527613704357};\\\", \\\"{x:1271,y:839,t:1527613704373};\\\", \\\"{x:1270,y:834,t:1527613704390};\\\", \\\"{x:1269,y:830,t:1527613704408};\\\", \\\"{x:1269,y:825,t:1527613704423};\\\", \\\"{x:1268,y:822,t:1527613704440};\\\", \\\"{x:1268,y:819,t:1527613704457};\\\", \\\"{x:1268,y:817,t:1527613704473};\\\", \\\"{x:1268,y:816,t:1527613704490};\\\", \\\"{x:1268,y:814,t:1527613704508};\\\", \\\"{x:1269,y:810,t:1527613704523};\\\", \\\"{x:1269,y:807,t:1527613704541};\\\", \\\"{x:1270,y:804,t:1527613704557};\\\", \\\"{x:1270,y:803,t:1527613704574};\\\", \\\"{x:1271,y:802,t:1527613704678};\\\", \\\"{x:1272,y:801,t:1527613704691};\\\", \\\"{x:1272,y:800,t:1527613704710};\\\", \\\"{x:1273,y:801,t:1527613704854};\\\", \\\"{x:1273,y:802,t:1527613704862};\\\", \\\"{x:1273,y:804,t:1527613704874};\\\", \\\"{x:1273,y:807,t:1527613704891};\\\", \\\"{x:1273,y:809,t:1527613704907};\\\", \\\"{x:1273,y:811,t:1527613704925};\\\", \\\"{x:1272,y:812,t:1527613704941};\\\", \\\"{x:1270,y:812,t:1527613704958};\\\", \\\"{x:1264,y:812,t:1527613704978};\\\", \\\"{x:1247,y:812,t:1527613704989};\\\", \\\"{x:1202,y:805,t:1527613705007};\\\", \\\"{x:1124,y:796,t:1527613705025};\\\", \\\"{x:1023,y:792,t:1527613705040};\\\", \\\"{x:924,y:792,t:1527613705057};\\\", \\\"{x:811,y:784,t:1527613705074};\\\", \\\"{x:700,y:766,t:1527613705090};\\\", \\\"{x:596,y:746,t:1527613705107};\\\", \\\"{x:515,y:729,t:1527613705125};\\\", \\\"{x:485,y:726,t:1527613705140};\\\", \\\"{x:449,y:718,t:1527613705157};\\\", \\\"{x:438,y:716,t:1527613705174};\\\", \\\"{x:432,y:713,t:1527613705191};\\\", \\\"{x:429,y:712,t:1527613705207};\\\", \\\"{x:425,y:711,t:1527613705224};\\\", \\\"{x:419,y:708,t:1527613705241};\\\", \\\"{x:406,y:702,t:1527613705257};\\\", \\\"{x:390,y:692,t:1527613705274};\\\", \\\"{x:374,y:684,t:1527613705291};\\\", \\\"{x:359,y:674,t:1527613705307};\\\", \\\"{x:348,y:666,t:1527613705324};\\\", \\\"{x:326,y:650,t:1527613705342};\\\", \\\"{x:314,y:639,t:1527613705358};\\\", \\\"{x:294,y:630,t:1527613705374};\\\", \\\"{x:276,y:622,t:1527613705391};\\\", \\\"{x:262,y:614,t:1527613705409};\\\", \\\"{x:246,y:609,t:1527613705426};\\\", \\\"{x:235,y:604,t:1527613705441};\\\", \\\"{x:225,y:600,t:1527613705458};\\\", \\\"{x:221,y:598,t:1527613705475};\\\", \\\"{x:218,y:596,t:1527613705491};\\\", \\\"{x:218,y:595,t:1527613705542};\\\", \\\"{x:215,y:595,t:1527613705582};\\\", \\\"{x:213,y:594,t:1527613705598};\\\", \\\"{x:212,y:594,t:1527613705608};\\\", \\\"{x:211,y:594,t:1527613705624};\\\", \\\"{x:210,y:594,t:1527613705642};\\\", \\\"{x:213,y:594,t:1527613705702};\\\", \\\"{x:219,y:597,t:1527613705710};\\\", \\\"{x:225,y:598,t:1527613705725};\\\", \\\"{x:258,y:601,t:1527613705742};\\\", \\\"{x:281,y:601,t:1527613705761};\\\", \\\"{x:296,y:600,t:1527613705774};\\\", \\\"{x:306,y:595,t:1527613705791};\\\", \\\"{x:312,y:590,t:1527613705808};\\\", \\\"{x:315,y:585,t:1527613705825};\\\", \\\"{x:317,y:580,t:1527613705842};\\\", \\\"{x:320,y:572,t:1527613705859};\\\", \\\"{x:325,y:563,t:1527613705875};\\\", \\\"{x:328,y:555,t:1527613705891};\\\", \\\"{x:332,y:545,t:1527613705908};\\\", \\\"{x:334,y:536,t:1527613705926};\\\", \\\"{x:334,y:529,t:1527613705941};\\\", \\\"{x:337,y:524,t:1527613705958};\\\", \\\"{x:341,y:520,t:1527613705975};\\\", \\\"{x:347,y:518,t:1527613705992};\\\", \\\"{x:355,y:512,t:1527613706008};\\\", \\\"{x:359,y:511,t:1527613706025};\\\", \\\"{x:364,y:507,t:1527613706043};\\\", \\\"{x:367,y:507,t:1527613706058};\\\", \\\"{x:369,y:505,t:1527613706076};\\\", \\\"{x:371,y:505,t:1527613706102};\\\", \\\"{x:372,y:504,t:1527613706110};\\\", \\\"{x:374,y:504,t:1527613706125};\\\", \\\"{x:376,y:504,t:1527613706182};\\\", \\\"{x:377,y:504,t:1527613706191};\\\", \\\"{x:381,y:504,t:1527613706208};\\\", \\\"{x:387,y:506,t:1527613706226};\\\", \\\"{x:388,y:507,t:1527613706242};\\\", \\\"{x:388,y:508,t:1527613706430};\\\", \\\"{x:388,y:509,t:1527613706494};\\\", \\\"{x:388,y:510,t:1527613706592};\\\", \\\"{x:388,y:510,t:1527613706714};\\\", \\\"{x:389,y:513,t:1527613706797};\\\", \\\"{x:390,y:517,t:1527613706809};\\\", \\\"{x:391,y:527,t:1527613706825};\\\", \\\"{x:400,y:541,t:1527613706843};\\\", \\\"{x:406,y:559,t:1527613706859};\\\", \\\"{x:419,y:583,t:1527613706875};\\\", \\\"{x:429,y:603,t:1527613706892};\\\", \\\"{x:459,y:638,t:1527613706912};\\\", \\\"{x:480,y:654,t:1527613706925};\\\", \\\"{x:496,y:666,t:1527613706942};\\\", \\\"{x:513,y:680,t:1527613706959};\\\", \\\"{x:524,y:693,t:1527613706976};\\\", \\\"{x:530,y:700,t:1527613706992};\\\", \\\"{x:532,y:703,t:1527613707009};\\\", \\\"{x:534,y:704,t:1527613707025};\\\", \\\"{x:535,y:705,t:1527613707212};\\\", \\\"{x:535,y:706,t:1527613707245};\\\", \\\"{x:536,y:706,t:1527613707260};\\\" ] }, { \\\"rt\\\": 9845, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 43455, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -D -A -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:709,t:1527613711918};\\\", \\\"{x:545,y:710,t:1527613711928};\\\", \\\"{x:564,y:720,t:1527613711946};\\\", \\\"{x:587,y:731,t:1527613711964};\\\", \\\"{x:620,y:743,t:1527613711978};\\\", \\\"{x:651,y:758,t:1527613711995};\\\", \\\"{x:708,y:779,t:1527613712013};\\\", \\\"{x:738,y:790,t:1527613712030};\\\", \\\"{x:763,y:801,t:1527613712046};\\\", \\\"{x:789,y:810,t:1527613712063};\\\", \\\"{x:816,y:817,t:1527613712080};\\\", \\\"{x:847,y:826,t:1527613712097};\\\", \\\"{x:900,y:832,t:1527613712113};\\\", \\\"{x:930,y:833,t:1527613712130};\\\", \\\"{x:947,y:838,t:1527613712147};\\\", \\\"{x:954,y:838,t:1527613712164};\\\", \\\"{x:955,y:838,t:1527613712181};\\\", \\\"{x:960,y:838,t:1527613712205};\\\", \\\"{x:970,y:838,t:1527613712213};\\\", \\\"{x:991,y:841,t:1527613712231};\\\", \\\"{x:1012,y:848,t:1527613712247};\\\", \\\"{x:1029,y:850,t:1527613712264};\\\", \\\"{x:1048,y:852,t:1527613712280};\\\", \\\"{x:1070,y:857,t:1527613712297};\\\", \\\"{x:1091,y:863,t:1527613712314};\\\", \\\"{x:1112,y:869,t:1527613712331};\\\", \\\"{x:1131,y:874,t:1527613712348};\\\", \\\"{x:1149,y:880,t:1527613712364};\\\", \\\"{x:1169,y:884,t:1527613712381};\\\", \\\"{x:1200,y:894,t:1527613712397};\\\", \\\"{x:1215,y:900,t:1527613712414};\\\", \\\"{x:1230,y:904,t:1527613712430};\\\", \\\"{x:1240,y:905,t:1527613712447};\\\", \\\"{x:1253,y:908,t:1527613712463};\\\", \\\"{x:1268,y:911,t:1527613712480};\\\", \\\"{x:1286,y:915,t:1527613712498};\\\", \\\"{x:1310,y:915,t:1527613712513};\\\", \\\"{x:1331,y:915,t:1527613712530};\\\", \\\"{x:1358,y:915,t:1527613712548};\\\", \\\"{x:1383,y:915,t:1527613712564};\\\", \\\"{x:1410,y:915,t:1527613712581};\\\", \\\"{x:1445,y:915,t:1527613712597};\\\", \\\"{x:1467,y:915,t:1527613712614};\\\", \\\"{x:1489,y:915,t:1527613712630};\\\", \\\"{x:1506,y:915,t:1527613712648};\\\", \\\"{x:1522,y:912,t:1527613712665};\\\", \\\"{x:1538,y:909,t:1527613712681};\\\", \\\"{x:1549,y:906,t:1527613712698};\\\", \\\"{x:1567,y:901,t:1527613712715};\\\", \\\"{x:1581,y:896,t:1527613712731};\\\", \\\"{x:1596,y:887,t:1527613712748};\\\", \\\"{x:1603,y:883,t:1527613712765};\\\", \\\"{x:1615,y:872,t:1527613712781};\\\", \\\"{x:1630,y:852,t:1527613712797};\\\", \\\"{x:1639,y:840,t:1527613712815};\\\", \\\"{x:1648,y:824,t:1527613712832};\\\", \\\"{x:1654,y:805,t:1527613712848};\\\", \\\"{x:1659,y:788,t:1527613712865};\\\", \\\"{x:1660,y:778,t:1527613712881};\\\", \\\"{x:1662,y:767,t:1527613712898};\\\", \\\"{x:1662,y:757,t:1527613712915};\\\", \\\"{x:1662,y:742,t:1527613712931};\\\", \\\"{x:1662,y:728,t:1527613712948};\\\", \\\"{x:1661,y:702,t:1527613712965};\\\", \\\"{x:1654,y:653,t:1527613712982};\\\", \\\"{x:1649,y:625,t:1527613712998};\\\", \\\"{x:1646,y:601,t:1527613713014};\\\", \\\"{x:1644,y:579,t:1527613713032};\\\", \\\"{x:1639,y:553,t:1527613713049};\\\", \\\"{x:1637,y:532,t:1527613713065};\\\", \\\"{x:1635,y:515,t:1527613713082};\\\", \\\"{x:1633,y:500,t:1527613713099};\\\", \\\"{x:1633,y:490,t:1527613713115};\\\", \\\"{x:1633,y:481,t:1527613713132};\\\", \\\"{x:1633,y:471,t:1527613713149};\\\", \\\"{x:1633,y:470,t:1527613713165};\\\", \\\"{x:1633,y:469,t:1527613713182};\\\", \\\"{x:1633,y:468,t:1527613713207};\\\", \\\"{x:1633,y:467,t:1527613713238};\\\", \\\"{x:1632,y:467,t:1527613713249};\\\", \\\"{x:1632,y:464,t:1527613713266};\\\", \\\"{x:1631,y:460,t:1527613713282};\\\", \\\"{x:1630,y:457,t:1527613713299};\\\", \\\"{x:1628,y:451,t:1527613713316};\\\", \\\"{x:1626,y:445,t:1527613713332};\\\", \\\"{x:1624,y:438,t:1527613713350};\\\", \\\"{x:1622,y:432,t:1527613713366};\\\", \\\"{x:1618,y:427,t:1527613713386};\\\", \\\"{x:1617,y:424,t:1527613713399};\\\", \\\"{x:1615,y:421,t:1527613713415};\\\", \\\"{x:1614,y:419,t:1527613713433};\\\", \\\"{x:1614,y:418,t:1527613713453};\\\", \\\"{x:1614,y:422,t:1527613713573};\\\", \\\"{x:1614,y:427,t:1527613713583};\\\", \\\"{x:1613,y:434,t:1527613713600};\\\", \\\"{x:1613,y:441,t:1527613713616};\\\", \\\"{x:1613,y:446,t:1527613713633};\\\", \\\"{x:1613,y:455,t:1527613713650};\\\", \\\"{x:1613,y:464,t:1527613713666};\\\", \\\"{x:1613,y:478,t:1527613713683};\\\", \\\"{x:1611,y:494,t:1527613713700};\\\", \\\"{x:1610,y:509,t:1527613713716};\\\", \\\"{x:1610,y:522,t:1527613713733};\\\", \\\"{x:1608,y:531,t:1527613713749};\\\", \\\"{x:1605,y:540,t:1527613713766};\\\", \\\"{x:1605,y:546,t:1527613713783};\\\", \\\"{x:1602,y:553,t:1527613713800};\\\", \\\"{x:1602,y:555,t:1527613713816};\\\", \\\"{x:1601,y:561,t:1527613713833};\\\", \\\"{x:1601,y:563,t:1527613713850};\\\", \\\"{x:1600,y:569,t:1527613713867};\\\", \\\"{x:1599,y:573,t:1527613713883};\\\", \\\"{x:1599,y:574,t:1527613713900};\\\", \\\"{x:1599,y:575,t:1527613713917};\\\", \\\"{x:1599,y:578,t:1527613713933};\\\", \\\"{x:1599,y:580,t:1527613713950};\\\", \\\"{x:1599,y:581,t:1527613713967};\\\", \\\"{x:1596,y:586,t:1527613714397};\\\", \\\"{x:1587,y:595,t:1527613714405};\\\", \\\"{x:1579,y:606,t:1527613714417};\\\", \\\"{x:1545,y:632,t:1527613714434};\\\", \\\"{x:1506,y:659,t:1527613714451};\\\", \\\"{x:1475,y:679,t:1527613714468};\\\", \\\"{x:1463,y:689,t:1527613714483};\\\", \\\"{x:1450,y:699,t:1527613714500};\\\", \\\"{x:1428,y:711,t:1527613714516};\\\", \\\"{x:1416,y:718,t:1527613714534};\\\", \\\"{x:1406,y:725,t:1527613714550};\\\", \\\"{x:1402,y:728,t:1527613714568};\\\", \\\"{x:1398,y:731,t:1527613714583};\\\", \\\"{x:1392,y:735,t:1527613714600};\\\", \\\"{x:1387,y:738,t:1527613714617};\\\", \\\"{x:1383,y:742,t:1527613714635};\\\", \\\"{x:1374,y:748,t:1527613714650};\\\", \\\"{x:1364,y:755,t:1527613714668};\\\", \\\"{x:1354,y:764,t:1527613714684};\\\", \\\"{x:1349,y:768,t:1527613714700};\\\", \\\"{x:1343,y:771,t:1527613714717};\\\", \\\"{x:1335,y:776,t:1527613714733};\\\", \\\"{x:1324,y:783,t:1527613714751};\\\", \\\"{x:1308,y:792,t:1527613714768};\\\", \\\"{x:1294,y:804,t:1527613714785};\\\", \\\"{x:1280,y:813,t:1527613714801};\\\", \\\"{x:1270,y:820,t:1527613714817};\\\", \\\"{x:1262,y:824,t:1527613714835};\\\", \\\"{x:1251,y:829,t:1527613714852};\\\", \\\"{x:1236,y:832,t:1527613714868};\\\", \\\"{x:1216,y:834,t:1527613714885};\\\", \\\"{x:1164,y:834,t:1527613714901};\\\", \\\"{x:1130,y:834,t:1527613714918};\\\", \\\"{x:1101,y:837,t:1527613714935};\\\", \\\"{x:1077,y:838,t:1527613714952};\\\", \\\"{x:1055,y:838,t:1527613714969};\\\", \\\"{x:1032,y:838,t:1527613714985};\\\", \\\"{x:1005,y:838,t:1527613715002};\\\", \\\"{x:981,y:838,t:1527613715017};\\\", \\\"{x:962,y:843,t:1527613715035};\\\", \\\"{x:950,y:849,t:1527613715052};\\\", \\\"{x:944,y:856,t:1527613715068};\\\", \\\"{x:940,y:863,t:1527613715085};\\\", \\\"{x:940,y:868,t:1527613715101};\\\", \\\"{x:941,y:872,t:1527613715119};\\\", \\\"{x:941,y:875,t:1527613715134};\\\", \\\"{x:941,y:877,t:1527613715152};\\\", \\\"{x:941,y:881,t:1527613715169};\\\", \\\"{x:941,y:882,t:1527613715185};\\\", \\\"{x:941,y:883,t:1527613715222};\\\", \\\"{x:941,y:884,t:1527613715573};\\\", \\\"{x:937,y:884,t:1527613715585};\\\", \\\"{x:925,y:884,t:1527613715602};\\\", \\\"{x:913,y:883,t:1527613715619};\\\", \\\"{x:905,y:883,t:1527613715636};\\\", \\\"{x:894,y:882,t:1527613715653};\\\", \\\"{x:891,y:882,t:1527613715669};\\\", \\\"{x:888,y:881,t:1527613715686};\\\", \\\"{x:886,y:881,t:1527613715703};\\\", \\\"{x:880,y:880,t:1527613715720};\\\", \\\"{x:872,y:879,t:1527613715735};\\\", \\\"{x:859,y:878,t:1527613715753};\\\", \\\"{x:844,y:875,t:1527613715770};\\\", \\\"{x:826,y:873,t:1527613715786};\\\", \\\"{x:810,y:870,t:1527613715803};\\\", \\\"{x:791,y:868,t:1527613715820};\\\", \\\"{x:770,y:863,t:1527613715836};\\\", \\\"{x:737,y:857,t:1527613715853};\\\", \\\"{x:716,y:852,t:1527613715869};\\\", \\\"{x:698,y:849,t:1527613715886};\\\", \\\"{x:690,y:848,t:1527613715903};\\\", \\\"{x:688,y:848,t:1527613716006};\\\", \\\"{x:687,y:848,t:1527613716020};\\\", \\\"{x:686,y:848,t:1527613716037};\\\", \\\"{x:684,y:847,t:1527613716102};\\\", \\\"{x:684,y:841,t:1527613716109};\\\", \\\"{x:684,y:838,t:1527613716120};\\\", \\\"{x:684,y:831,t:1527613716137};\\\", \\\"{x:684,y:818,t:1527613716154};\\\", \\\"{x:695,y:803,t:1527613716170};\\\", \\\"{x:706,y:788,t:1527613716187};\\\", \\\"{x:720,y:778,t:1527613716203};\\\", \\\"{x:731,y:768,t:1527613716220};\\\", \\\"{x:746,y:756,t:1527613716237};\\\", \\\"{x:752,y:751,t:1527613716254};\\\", \\\"{x:754,y:748,t:1527613716270};\\\", \\\"{x:754,y:745,t:1527613716287};\\\", \\\"{x:754,y:744,t:1527613716304};\\\", \\\"{x:754,y:742,t:1527613716321};\\\", \\\"{x:753,y:738,t:1527613716337};\\\", \\\"{x:741,y:731,t:1527613716354};\\\", \\\"{x:719,y:717,t:1527613716371};\\\", \\\"{x:678,y:700,t:1527613716387};\\\", \\\"{x:646,y:683,t:1527613716404};\\\", \\\"{x:604,y:654,t:1527613716422};\\\", \\\"{x:581,y:637,t:1527613716439};\\\", \\\"{x:566,y:628,t:1527613716453};\\\", \\\"{x:561,y:622,t:1527613716470};\\\", \\\"{x:560,y:622,t:1527613716483};\\\", \\\"{x:559,y:621,t:1527613716499};\\\", \\\"{x:557,y:621,t:1527613716540};\\\", \\\"{x:554,y:620,t:1527613716549};\\\", \\\"{x:548,y:619,t:1527613716567};\\\", \\\"{x:541,y:619,t:1527613716584};\\\", \\\"{x:537,y:619,t:1527613716600};\\\", \\\"{x:535,y:619,t:1527613716616};\\\", \\\"{x:529,y:623,t:1527613716634};\\\", \\\"{x:520,y:625,t:1527613716649};\\\", \\\"{x:508,y:628,t:1527613716667};\\\", \\\"{x:494,y:630,t:1527613716685};\\\", \\\"{x:480,y:632,t:1527613716700};\\\", \\\"{x:466,y:633,t:1527613716716};\\\", \\\"{x:456,y:634,t:1527613716733};\\\", \\\"{x:442,y:634,t:1527613716749};\\\", \\\"{x:423,y:634,t:1527613716767};\\\", \\\"{x:406,y:634,t:1527613716784};\\\", \\\"{x:399,y:634,t:1527613716800};\\\", \\\"{x:396,y:634,t:1527613716817};\\\", \\\"{x:394,y:634,t:1527613716834};\\\", \\\"{x:393,y:634,t:1527613716853};\\\", \\\"{x:391,y:634,t:1527613716869};\\\", \\\"{x:389,y:634,t:1527613716884};\\\", \\\"{x:378,y:634,t:1527613716901};\\\", \\\"{x:371,y:634,t:1527613716917};\\\", \\\"{x:353,y:633,t:1527613716933};\\\", \\\"{x:340,y:632,t:1527613716951};\\\", \\\"{x:326,y:628,t:1527613716967};\\\", \\\"{x:317,y:625,t:1527613716984};\\\", \\\"{x:303,y:621,t:1527613717000};\\\", \\\"{x:288,y:617,t:1527613717018};\\\", \\\"{x:275,y:615,t:1527613717034};\\\", \\\"{x:268,y:612,t:1527613717052};\\\", \\\"{x:264,y:612,t:1527613717067};\\\", \\\"{x:262,y:612,t:1527613717083};\\\", \\\"{x:261,y:612,t:1527613717101};\\\", \\\"{x:259,y:612,t:1527613717117};\\\", \\\"{x:253,y:612,t:1527613717133};\\\", \\\"{x:244,y:611,t:1527613717151};\\\", \\\"{x:231,y:611,t:1527613717166};\\\", \\\"{x:224,y:611,t:1527613717183};\\\", \\\"{x:222,y:611,t:1527613717201};\\\", \\\"{x:220,y:611,t:1527613717217};\\\", \\\"{x:219,y:611,t:1527613717245};\\\", \\\"{x:217,y:611,t:1527613717253};\\\", \\\"{x:216,y:611,t:1527613717268};\\\", \\\"{x:210,y:612,t:1527613717284};\\\", \\\"{x:203,y:612,t:1527613717301};\\\", \\\"{x:193,y:612,t:1527613717318};\\\", \\\"{x:186,y:612,t:1527613717333};\\\", \\\"{x:182,y:612,t:1527613717351};\\\", \\\"{x:178,y:612,t:1527613717370};\\\", \\\"{x:177,y:612,t:1527613717384};\\\", \\\"{x:176,y:613,t:1527613717431};\\\", \\\"{x:174,y:614,t:1527613717450};\\\", \\\"{x:173,y:614,t:1527613717468};\\\", \\\"{x:171,y:616,t:1527613717484};\\\", \\\"{x:170,y:617,t:1527613717500};\\\", \\\"{x:168,y:619,t:1527613717517};\\\", \\\"{x:167,y:620,t:1527613717534};\\\", \\\"{x:167,y:622,t:1527613717550};\\\", \\\"{x:166,y:623,t:1527613717569};\\\", \\\"{x:165,y:623,t:1527613717583};\\\", \\\"{x:165,y:624,t:1527613717621};\\\", \\\"{x:164,y:625,t:1527613717644};\\\", \\\"{x:164,y:626,t:1527613717670};\\\", \\\"{x:162,y:626,t:1527613717684};\\\", \\\"{x:162,y:627,t:1527613717734};\\\", \\\"{x:161,y:628,t:1527613717751};\\\", \\\"{x:162,y:628,t:1527613718037};\\\", \\\"{x:171,y:632,t:1527613718051};\\\", \\\"{x:191,y:639,t:1527613718068};\\\", \\\"{x:240,y:653,t:1527613718086};\\\", \\\"{x:257,y:658,t:1527613718101};\\\", \\\"{x:276,y:662,t:1527613718118};\\\", \\\"{x:296,y:668,t:1527613718135};\\\", \\\"{x:315,y:673,t:1527613718151};\\\", \\\"{x:332,y:678,t:1527613718169};\\\", \\\"{x:349,y:681,t:1527613718185};\\\", \\\"{x:371,y:689,t:1527613718202};\\\", \\\"{x:385,y:692,t:1527613718217};\\\", \\\"{x:394,y:694,t:1527613718235};\\\", \\\"{x:408,y:696,t:1527613718252};\\\", \\\"{x:414,y:697,t:1527613718268};\\\", \\\"{x:415,y:697,t:1527613718285};\\\", \\\"{x:416,y:697,t:1527613718326};\\\", \\\"{x:417,y:698,t:1527613718335};\\\", \\\"{x:420,y:700,t:1527613718352};\\\", \\\"{x:425,y:703,t:1527613718369};\\\", \\\"{x:429,y:706,t:1527613718385};\\\", \\\"{x:432,y:707,t:1527613718402};\\\", \\\"{x:433,y:709,t:1527613718418};\\\", \\\"{x:438,y:712,t:1527613718435};\\\", \\\"{x:443,y:717,t:1527613718452};\\\", \\\"{x:455,y:722,t:1527613718469};\\\", \\\"{x:472,y:726,t:1527613718485};\\\", \\\"{x:477,y:726,t:1527613718501};\\\", \\\"{x:479,y:726,t:1527613718518};\\\", \\\"{x:479,y:727,t:1527613718540};\\\", \\\"{x:481,y:727,t:1527613718597};\\\", \\\"{x:483,y:727,t:1527613718605};\\\", \\\"{x:485,y:727,t:1527613718645};\\\" ] }, { \\\"rt\\\": 41776, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 86456, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-C -C -C -C -C -C -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:486,y:727,t:1527613721878};\\\", \\\"{x:489,y:727,t:1527613721889};\\\", \\\"{x:493,y:729,t:1527613721904};\\\", \\\"{x:498,y:730,t:1527613721921};\\\", \\\"{x:502,y:732,t:1527613721938};\\\", \\\"{x:510,y:734,t:1527613721955};\\\", \\\"{x:521,y:737,t:1527613721972};\\\", \\\"{x:545,y:745,t:1527613721988};\\\", \\\"{x:591,y:757,t:1527613722005};\\\", \\\"{x:640,y:772,t:1527613722020};\\\", \\\"{x:703,y:786,t:1527613722038};\\\", \\\"{x:783,y:810,t:1527613722054};\\\", \\\"{x:869,y:831,t:1527613722070};\\\", \\\"{x:960,y:858,t:1527613722087};\\\", \\\"{x:1043,y:881,t:1527613722104};\\\", \\\"{x:1127,y:906,t:1527613722120};\\\", \\\"{x:1173,y:917,t:1527613722138};\\\", \\\"{x:1221,y:930,t:1527613722155};\\\", \\\"{x:1252,y:937,t:1527613722171};\\\", \\\"{x:1273,y:942,t:1527613722188};\\\", \\\"{x:1304,y:949,t:1527613722205};\\\", \\\"{x:1323,y:953,t:1527613722221};\\\", \\\"{x:1345,y:958,t:1527613722238};\\\", \\\"{x:1362,y:961,t:1527613722255};\\\", \\\"{x:1375,y:965,t:1527613722271};\\\", \\\"{x:1395,y:968,t:1527613722288};\\\", \\\"{x:1414,y:970,t:1527613722305};\\\", \\\"{x:1434,y:973,t:1527613722321};\\\", \\\"{x:1449,y:973,t:1527613722339};\\\", \\\"{x:1456,y:973,t:1527613722355};\\\", \\\"{x:1459,y:973,t:1527613722371};\\\", \\\"{x:1461,y:973,t:1527613722388};\\\", \\\"{x:1465,y:973,t:1527613722406};\\\", \\\"{x:1470,y:972,t:1527613722421};\\\", \\\"{x:1474,y:972,t:1527613722438};\\\", \\\"{x:1476,y:970,t:1527613722455};\\\", \\\"{x:1477,y:970,t:1527613722518};\\\", \\\"{x:1479,y:969,t:1527613722526};\\\", \\\"{x:1480,y:968,t:1527613722542};\\\", \\\"{x:1482,y:967,t:1527613722556};\\\", \\\"{x:1483,y:966,t:1527613722572};\\\", \\\"{x:1484,y:966,t:1527613722589};\\\", \\\"{x:1485,y:966,t:1527613722606};\\\", \\\"{x:1486,y:965,t:1527613722629};\\\", \\\"{x:1488,y:965,t:1527613722652};\\\", \\\"{x:1488,y:964,t:1527613722660};\\\", \\\"{x:1489,y:963,t:1527613722672};\\\", \\\"{x:1489,y:962,t:1527613722758};\\\", \\\"{x:1489,y:960,t:1527613723254};\\\", \\\"{x:1490,y:960,t:1527613723262};\\\", \\\"{x:1490,y:959,t:1527613723293};\\\", \\\"{x:1490,y:958,t:1527613723390};\\\", \\\"{x:1490,y:957,t:1527613723406};\\\", \\\"{x:1490,y:956,t:1527613723446};\\\", \\\"{x:1490,y:955,t:1527613723461};\\\", \\\"{x:1489,y:954,t:1527613723485};\\\", \\\"{x:1488,y:953,t:1527613723526};\\\", \\\"{x:1487,y:952,t:1527613723550};\\\", \\\"{x:1485,y:950,t:1527613723574};\\\", \\\"{x:1484,y:950,t:1527613723614};\\\", \\\"{x:1482,y:950,t:1527613723630};\\\", \\\"{x:1482,y:949,t:1527613723652};\\\", \\\"{x:1481,y:948,t:1527613723669};\\\", \\\"{x:1481,y:947,t:1527613723709};\\\", \\\"{x:1479,y:947,t:1527613723722};\\\", \\\"{x:1478,y:947,t:1527613723739};\\\", \\\"{x:1475,y:945,t:1527613723756};\\\", \\\"{x:1475,y:944,t:1527613723772};\\\", \\\"{x:1473,y:941,t:1527613723789};\\\", \\\"{x:1471,y:940,t:1527613723806};\\\", \\\"{x:1471,y:939,t:1527613723846};\\\", \\\"{x:1471,y:938,t:1527613723885};\\\", \\\"{x:1470,y:936,t:1527613723893};\\\", \\\"{x:1470,y:935,t:1527613723907};\\\", \\\"{x:1470,y:933,t:1527613723923};\\\", \\\"{x:1469,y:931,t:1527613723940};\\\", \\\"{x:1468,y:930,t:1527613723958};\\\", \\\"{x:1468,y:929,t:1527613725286};\\\", \\\"{x:1468,y:927,t:1527613725406};\\\", \\\"{x:1468,y:925,t:1527613725422};\\\", \\\"{x:1469,y:923,t:1527613725446};\\\", \\\"{x:1470,y:923,t:1527613725462};\\\", \\\"{x:1470,y:921,t:1527613725475};\\\", \\\"{x:1471,y:920,t:1527613725491};\\\", \\\"{x:1473,y:917,t:1527613725508};\\\", \\\"{x:1473,y:914,t:1527613725525};\\\", \\\"{x:1476,y:910,t:1527613725541};\\\", \\\"{x:1483,y:899,t:1527613725558};\\\", \\\"{x:1488,y:884,t:1527613725574};\\\", \\\"{x:1490,y:858,t:1527613725590};\\\", \\\"{x:1497,y:800,t:1527613725607};\\\", \\\"{x:1499,y:705,t:1527613725624};\\\", \\\"{x:1499,y:627,t:1527613725641};\\\", \\\"{x:1505,y:542,t:1527613725657};\\\", \\\"{x:1505,y:470,t:1527613725674};\\\", \\\"{x:1501,y:413,t:1527613725691};\\\", \\\"{x:1488,y:370,t:1527613725708};\\\", \\\"{x:1483,y:343,t:1527613725724};\\\", \\\"{x:1476,y:309,t:1527613725741};\\\", \\\"{x:1473,y:295,t:1527613725757};\\\", \\\"{x:1472,y:281,t:1527613725774};\\\", \\\"{x:1471,y:262,t:1527613725791};\\\", \\\"{x:1469,y:253,t:1527613725807};\\\", \\\"{x:1468,y:250,t:1527613725824};\\\", \\\"{x:1468,y:248,t:1527613725841};\\\", \\\"{x:1468,y:244,t:1527613725857};\\\", \\\"{x:1468,y:242,t:1527613725874};\\\", \\\"{x:1469,y:241,t:1527613725891};\\\", \\\"{x:1469,y:239,t:1527613725908};\\\", \\\"{x:1469,y:237,t:1527613725925};\\\", \\\"{x:1469,y:233,t:1527613725942};\\\", \\\"{x:1471,y:231,t:1527613725957};\\\", \\\"{x:1471,y:230,t:1527613725975};\\\", \\\"{x:1471,y:228,t:1527613725992};\\\", \\\"{x:1472,y:228,t:1527613726008};\\\", \\\"{x:1473,y:226,t:1527613726025};\\\", \\\"{x:1473,y:225,t:1527613726042};\\\", \\\"{x:1473,y:223,t:1527613726058};\\\", \\\"{x:1475,y:220,t:1527613726075};\\\", \\\"{x:1476,y:217,t:1527613726092};\\\", \\\"{x:1476,y:212,t:1527613726108};\\\", \\\"{x:1479,y:207,t:1527613726125};\\\", \\\"{x:1480,y:196,t:1527613726141};\\\", \\\"{x:1482,y:192,t:1527613726158};\\\", \\\"{x:1482,y:190,t:1527613726175};\\\", \\\"{x:1482,y:188,t:1527613726192};\\\", \\\"{x:1482,y:186,t:1527613726208};\\\", \\\"{x:1482,y:184,t:1527613726225};\\\", \\\"{x:1483,y:181,t:1527613726242};\\\", \\\"{x:1483,y:180,t:1527613726259};\\\", \\\"{x:1484,y:178,t:1527613726275};\\\", \\\"{x:1484,y:177,t:1527613726291};\\\", \\\"{x:1484,y:175,t:1527613726309};\\\", \\\"{x:1487,y:174,t:1527613726325};\\\", \\\"{x:1488,y:173,t:1527613726342};\\\", \\\"{x:1488,y:172,t:1527613726446};\\\", \\\"{x:1488,y:173,t:1527613727126};\\\", \\\"{x:1488,y:174,t:1527613727142};\\\", \\\"{x:1488,y:175,t:1527613727270};\\\", \\\"{x:1488,y:176,t:1527613727318};\\\", \\\"{x:1488,y:177,t:1527613727325};\\\", \\\"{x:1488,y:178,t:1527613727365};\\\", \\\"{x:1487,y:178,t:1527613727382};\\\", \\\"{x:1487,y:179,t:1527613727393};\\\", \\\"{x:1486,y:180,t:1527613727438};\\\", \\\"{x:1485,y:181,t:1527613727494};\\\", \\\"{x:1485,y:182,t:1527613727518};\\\", \\\"{x:1485,y:183,t:1527613727533};\\\", \\\"{x:1483,y:184,t:1527613727542};\\\", \\\"{x:1482,y:186,t:1527613727726};\\\", \\\"{x:1482,y:187,t:1527613727742};\\\", \\\"{x:1480,y:189,t:1527613727760};\\\", \\\"{x:1478,y:193,t:1527613727775};\\\", \\\"{x:1478,y:197,t:1527613727792};\\\", \\\"{x:1475,y:201,t:1527613727809};\\\", \\\"{x:1471,y:210,t:1527613727825};\\\", \\\"{x:1463,y:226,t:1527613727842};\\\", \\\"{x:1454,y:239,t:1527613727859};\\\", \\\"{x:1444,y:255,t:1527613727875};\\\", \\\"{x:1439,y:268,t:1527613727892};\\\", \\\"{x:1430,y:288,t:1527613727909};\\\", \\\"{x:1427,y:294,t:1527613727926};\\\", \\\"{x:1424,y:301,t:1527613727942};\\\", \\\"{x:1422,y:307,t:1527613727959};\\\", \\\"{x:1420,y:314,t:1527613727976};\\\", \\\"{x:1414,y:327,t:1527613727992};\\\", \\\"{x:1406,y:349,t:1527613728009};\\\", \\\"{x:1397,y:383,t:1527613728027};\\\", \\\"{x:1383,y:419,t:1527613728043};\\\", \\\"{x:1364,y:458,t:1527613728059};\\\", \\\"{x:1351,y:486,t:1527613728077};\\\", \\\"{x:1340,y:512,t:1527613728093};\\\", \\\"{x:1326,y:548,t:1527613728109};\\\", \\\"{x:1314,y:570,t:1527613728127};\\\", \\\"{x:1303,y:589,t:1527613728143};\\\", \\\"{x:1293,y:608,t:1527613728160};\\\", \\\"{x:1284,y:622,t:1527613728176};\\\", \\\"{x:1276,y:636,t:1527613728192};\\\", \\\"{x:1268,y:649,t:1527613728210};\\\", \\\"{x:1262,y:661,t:1527613728227};\\\", \\\"{x:1257,y:672,t:1527613728242};\\\", \\\"{x:1254,y:680,t:1527613728259};\\\", \\\"{x:1252,y:684,t:1527613728277};\\\", \\\"{x:1246,y:693,t:1527613728293};\\\", \\\"{x:1241,y:703,t:1527613728310};\\\", \\\"{x:1235,y:711,t:1527613728326};\\\", \\\"{x:1232,y:715,t:1527613728344};\\\", \\\"{x:1229,y:720,t:1527613728360};\\\", \\\"{x:1227,y:723,t:1527613728377};\\\", \\\"{x:1224,y:730,t:1527613728394};\\\", \\\"{x:1222,y:735,t:1527613728410};\\\", \\\"{x:1220,y:743,t:1527613728427};\\\", \\\"{x:1218,y:746,t:1527613728443};\\\", \\\"{x:1215,y:754,t:1527613728460};\\\", \\\"{x:1214,y:759,t:1527613728477};\\\", \\\"{x:1211,y:769,t:1527613728494};\\\", \\\"{x:1210,y:771,t:1527613728509};\\\", \\\"{x:1209,y:776,t:1527613728527};\\\", \\\"{x:1209,y:778,t:1527613728543};\\\", \\\"{x:1209,y:780,t:1527613728560};\\\", \\\"{x:1209,y:781,t:1527613728576};\\\", \\\"{x:1209,y:783,t:1527613728593};\\\", \\\"{x:1209,y:786,t:1527613728610};\\\", \\\"{x:1209,y:788,t:1527613728627};\\\", \\\"{x:1211,y:794,t:1527613728643};\\\", \\\"{x:1212,y:795,t:1527613728660};\\\", \\\"{x:1212,y:797,t:1527613728676};\\\", \\\"{x:1216,y:801,t:1527613728694};\\\", \\\"{x:1216,y:802,t:1527613728711};\\\", \\\"{x:1216,y:807,t:1527613728727};\\\", \\\"{x:1217,y:810,t:1527613728744};\\\", \\\"{x:1219,y:814,t:1527613728760};\\\", \\\"{x:1220,y:817,t:1527613728777};\\\", \\\"{x:1220,y:818,t:1527613728793};\\\", \\\"{x:1221,y:819,t:1527613728810};\\\", \\\"{x:1222,y:820,t:1527613728861};\\\", \\\"{x:1222,y:821,t:1527613728893};\\\", \\\"{x:1222,y:822,t:1527613728958};\\\", \\\"{x:1222,y:823,t:1527613729030};\\\", \\\"{x:1221,y:823,t:1527613729044};\\\", \\\"{x:1220,y:823,t:1527613729061};\\\", \\\"{x:1219,y:823,t:1527613729078};\\\", \\\"{x:1218,y:823,t:1527613729102};\\\", \\\"{x:1217,y:823,t:1527613729126};\\\", \\\"{x:1216,y:823,t:1527613729421};\\\", \\\"{x:1215,y:823,t:1527613729558};\\\", \\\"{x:1213,y:823,t:1527613729566};\\\", \\\"{x:1210,y:823,t:1527613729578};\\\", \\\"{x:1206,y:823,t:1527613729595};\\\", \\\"{x:1206,y:824,t:1527613730774};\\\", \\\"{x:1206,y:825,t:1527613730789};\\\", \\\"{x:1206,y:826,t:1527613730797};\\\", \\\"{x:1206,y:827,t:1527613730812};\\\", \\\"{x:1206,y:828,t:1527613730860};\\\", \\\"{x:1206,y:829,t:1527613730893};\\\", \\\"{x:1206,y:830,t:1527613730901};\\\", \\\"{x:1206,y:831,t:1527613730941};\\\", \\\"{x:1207,y:831,t:1527613733814};\\\", \\\"{x:1208,y:831,t:1527613733831};\\\", \\\"{x:1209,y:831,t:1527613733918};\\\", \\\"{x:1209,y:829,t:1527613735593};\\\", \\\"{x:1210,y:829,t:1527613735603};\\\", \\\"{x:1210,y:827,t:1527613735619};\\\", \\\"{x:1211,y:826,t:1527613735640};\\\", \\\"{x:1211,y:825,t:1527613735664};\\\", \\\"{x:1212,y:824,t:1527613736362};\\\", \\\"{x:1212,y:823,t:1527613736417};\\\", \\\"{x:1212,y:822,t:1527613736441};\\\", \\\"{x:1214,y:821,t:1527613736513};\\\", \\\"{x:1215,y:821,t:1527613744096};\\\", \\\"{x:1215,y:820,t:1527613744112};\\\", \\\"{x:1217,y:819,t:1527613744136};\\\", \\\"{x:1217,y:818,t:1527613744257};\\\", \\\"{x:1217,y:817,t:1527613744297};\\\", \\\"{x:1218,y:817,t:1527613744311};\\\", \\\"{x:1218,y:816,t:1527613744325};\\\", \\\"{x:1218,y:815,t:1527613744342};\\\", \\\"{x:1218,y:814,t:1527613744359};\\\", \\\"{x:1218,y:813,t:1527613744375};\\\", \\\"{x:1219,y:811,t:1527613744392};\\\", \\\"{x:1219,y:809,t:1527613744410};\\\", \\\"{x:1220,y:808,t:1527613744426};\\\", \\\"{x:1220,y:806,t:1527613744443};\\\", \\\"{x:1220,y:805,t:1527613744460};\\\", \\\"{x:1220,y:802,t:1527613744476};\\\", \\\"{x:1220,y:801,t:1527613744492};\\\", \\\"{x:1220,y:800,t:1527613744509};\\\", \\\"{x:1220,y:799,t:1527613744526};\\\", \\\"{x:1220,y:797,t:1527613744543};\\\", \\\"{x:1220,y:794,t:1527613744560};\\\", \\\"{x:1219,y:792,t:1527613744576};\\\", \\\"{x:1219,y:788,t:1527613744593};\\\", \\\"{x:1219,y:787,t:1527613744610};\\\", \\\"{x:1219,y:784,t:1527613744626};\\\", \\\"{x:1219,y:781,t:1527613744643};\\\", \\\"{x:1218,y:778,t:1527613744661};\\\", \\\"{x:1217,y:773,t:1527613744677};\\\", \\\"{x:1216,y:771,t:1527613744693};\\\", \\\"{x:1214,y:769,t:1527613744710};\\\", \\\"{x:1213,y:768,t:1527613744727};\\\", \\\"{x:1213,y:764,t:1527613744743};\\\", \\\"{x:1213,y:763,t:1527613744760};\\\", \\\"{x:1213,y:760,t:1527613744777};\\\", \\\"{x:1213,y:757,t:1527613744793};\\\", \\\"{x:1212,y:754,t:1527613744809};\\\", \\\"{x:1210,y:749,t:1527613744828};\\\", \\\"{x:1210,y:748,t:1527613744843};\\\", \\\"{x:1210,y:746,t:1527613744860};\\\", \\\"{x:1209,y:745,t:1527613744877};\\\", \\\"{x:1209,y:744,t:1527613744905};\\\", \\\"{x:1209,y:743,t:1527613744921};\\\", \\\"{x:1209,y:742,t:1527613744928};\\\", \\\"{x:1209,y:740,t:1527613744945};\\\", \\\"{x:1208,y:738,t:1527613744961};\\\", \\\"{x:1208,y:737,t:1527613744976};\\\", \\\"{x:1207,y:735,t:1527613744992};\\\", \\\"{x:1207,y:734,t:1527613745009};\\\", \\\"{x:1207,y:732,t:1527613745026};\\\", \\\"{x:1207,y:730,t:1527613745042};\\\", \\\"{x:1207,y:729,t:1527613745059};\\\", \\\"{x:1207,y:727,t:1527613745076};\\\", \\\"{x:1207,y:725,t:1527613745093};\\\", \\\"{x:1207,y:724,t:1527613745109};\\\", \\\"{x:1207,y:722,t:1527613745127};\\\", \\\"{x:1207,y:721,t:1527613745144};\\\", \\\"{x:1207,y:718,t:1527613745201};\\\", \\\"{x:1207,y:717,t:1527613745241};\\\", \\\"{x:1207,y:716,t:1527613745257};\\\", \\\"{x:1207,y:715,t:1527613745281};\\\", \\\"{x:1207,y:714,t:1527613745305};\\\", \\\"{x:1207,y:713,t:1527613745312};\\\", \\\"{x:1207,y:712,t:1527613745327};\\\", \\\"{x:1208,y:711,t:1527613745343};\\\", \\\"{x:1208,y:710,t:1527613745359};\\\", \\\"{x:1210,y:707,t:1527613745377};\\\", \\\"{x:1210,y:706,t:1527613745400};\\\", \\\"{x:1211,y:704,t:1527613745416};\\\", \\\"{x:1211,y:703,t:1527613745448};\\\", \\\"{x:1211,y:702,t:1527613745489};\\\", \\\"{x:1211,y:701,t:1527613745504};\\\", \\\"{x:1212,y:700,t:1527613745546};\\\", \\\"{x:1213,y:699,t:1527613745642};\\\", \\\"{x:1213,y:698,t:1527613745665};\\\", \\\"{x:1213,y:697,t:1527613745745};\\\", \\\"{x:1213,y:696,t:1527613745833};\\\", \\\"{x:1214,y:696,t:1527613747144};\\\", \\\"{x:1214,y:698,t:1527613748665};\\\", \\\"{x:1214,y:701,t:1527613748679};\\\", \\\"{x:1213,y:705,t:1527613748696};\\\", \\\"{x:1213,y:712,t:1527613748713};\\\", \\\"{x:1212,y:716,t:1527613748730};\\\", \\\"{x:1210,y:725,t:1527613748746};\\\", \\\"{x:1203,y:737,t:1527613748763};\\\", \\\"{x:1198,y:747,t:1527613748779};\\\", \\\"{x:1197,y:751,t:1527613748796};\\\", \\\"{x:1196,y:755,t:1527613748812};\\\", \\\"{x:1195,y:758,t:1527613748829};\\\", \\\"{x:1195,y:760,t:1527613748846};\\\", \\\"{x:1195,y:763,t:1527613748863};\\\", \\\"{x:1195,y:766,t:1527613748879};\\\", \\\"{x:1195,y:773,t:1527613748896};\\\", \\\"{x:1196,y:781,t:1527613748912};\\\", \\\"{x:1199,y:789,t:1527613748930};\\\", \\\"{x:1200,y:798,t:1527613748945};\\\", \\\"{x:1205,y:805,t:1527613748963};\\\", \\\"{x:1205,y:809,t:1527613748979};\\\", \\\"{x:1206,y:814,t:1527613748996};\\\", \\\"{x:1209,y:819,t:1527613749012};\\\", \\\"{x:1211,y:828,t:1527613749030};\\\", \\\"{x:1213,y:835,t:1527613749047};\\\", \\\"{x:1214,y:838,t:1527613749062};\\\", \\\"{x:1215,y:840,t:1527613749079};\\\", \\\"{x:1216,y:842,t:1527613749096};\\\", \\\"{x:1216,y:839,t:1527613749400};\\\", \\\"{x:1216,y:837,t:1527613749424};\\\", \\\"{x:1215,y:836,t:1527613749441};\\\", \\\"{x:1215,y:835,t:1527613749449};\\\", \\\"{x:1214,y:834,t:1527613749463};\\\", \\\"{x:1213,y:833,t:1527613749480};\\\", \\\"{x:1212,y:830,t:1527613749496};\\\", \\\"{x:1212,y:829,t:1527613749513};\\\", \\\"{x:1212,y:827,t:1527613749530};\\\", \\\"{x:1211,y:827,t:1527613749546};\\\", \\\"{x:1211,y:826,t:1527613749585};\\\", \\\"{x:1211,y:824,t:1527613750048};\\\", \\\"{x:1213,y:822,t:1527613755649};\\\", \\\"{x:1214,y:822,t:1527613755665};\\\", \\\"{x:1214,y:821,t:1527613755673};\\\", \\\"{x:1215,y:821,t:1527613755705};\\\", \\\"{x:1216,y:820,t:1527613755761};\\\", \\\"{x:1217,y:820,t:1527613755865};\\\", \\\"{x:1217,y:819,t:1527613755872};\\\", \\\"{x:1218,y:818,t:1527613755889};\\\", \\\"{x:1219,y:818,t:1527613755902};\\\", \\\"{x:1219,y:817,t:1527613755919};\\\", \\\"{x:1221,y:815,t:1527613755936};\\\", \\\"{x:1224,y:813,t:1527613755952};\\\", \\\"{x:1227,y:810,t:1527613755969};\\\", \\\"{x:1229,y:809,t:1527613755986};\\\", \\\"{x:1230,y:807,t:1527613756003};\\\", \\\"{x:1231,y:807,t:1527613756019};\\\", \\\"{x:1232,y:806,t:1527613756035};\\\", \\\"{x:1234,y:803,t:1527613756053};\\\", \\\"{x:1235,y:802,t:1527613756068};\\\", \\\"{x:1236,y:800,t:1527613756086};\\\", \\\"{x:1238,y:798,t:1527613756102};\\\", \\\"{x:1239,y:797,t:1527613756118};\\\", \\\"{x:1242,y:794,t:1527613756136};\\\", \\\"{x:1244,y:790,t:1527613756153};\\\", \\\"{x:1248,y:787,t:1527613756168};\\\", \\\"{x:1250,y:783,t:1527613756185};\\\", \\\"{x:1253,y:779,t:1527613756201};\\\", \\\"{x:1258,y:772,t:1527613756219};\\\", \\\"{x:1262,y:766,t:1527613756235};\\\", \\\"{x:1268,y:758,t:1527613756252};\\\", \\\"{x:1274,y:750,t:1527613756269};\\\", \\\"{x:1280,y:739,t:1527613756285};\\\", \\\"{x:1284,y:730,t:1527613756302};\\\", \\\"{x:1290,y:715,t:1527613756319};\\\", \\\"{x:1298,y:704,t:1527613756335};\\\", \\\"{x:1308,y:688,t:1527613756352};\\\", \\\"{x:1312,y:678,t:1527613756369};\\\", \\\"{x:1313,y:672,t:1527613756385};\\\", \\\"{x:1318,y:661,t:1527613756402};\\\", \\\"{x:1319,y:658,t:1527613756419};\\\", \\\"{x:1322,y:653,t:1527613756435};\\\", \\\"{x:1322,y:651,t:1527613756452};\\\", \\\"{x:1322,y:650,t:1527613756473};\\\", \\\"{x:1323,y:649,t:1527613756489};\\\", \\\"{x:1323,y:648,t:1527613756512};\\\", \\\"{x:1324,y:647,t:1527613756536};\\\", \\\"{x:1324,y:646,t:1527613756569};\\\", \\\"{x:1325,y:645,t:1527613756586};\\\", \\\"{x:1325,y:643,t:1527613756648};\\\", \\\"{x:1325,y:642,t:1527613756672};\\\", \\\"{x:1325,y:640,t:1527613756688};\\\", \\\"{x:1325,y:638,t:1527613756712};\\\", \\\"{x:1325,y:637,t:1527613756769};\\\", \\\"{x:1325,y:636,t:1527613757256};\\\", \\\"{x:1325,y:635,t:1527613757269};\\\", \\\"{x:1322,y:634,t:1527613757286};\\\", \\\"{x:1321,y:633,t:1527613757303};\\\", \\\"{x:1317,y:632,t:1527613757319};\\\", \\\"{x:1315,y:631,t:1527613757336};\\\", \\\"{x:1311,y:631,t:1527613757353};\\\", \\\"{x:1305,y:631,t:1527613757370};\\\", \\\"{x:1296,y:631,t:1527613757386};\\\", \\\"{x:1288,y:631,t:1527613757403};\\\", \\\"{x:1281,y:631,t:1527613757419};\\\", \\\"{x:1268,y:631,t:1527613757436};\\\", \\\"{x:1259,y:631,t:1527613757453};\\\", \\\"{x:1253,y:631,t:1527613757470};\\\", \\\"{x:1252,y:631,t:1527613757487};\\\", \\\"{x:1249,y:631,t:1527613757504};\\\", \\\"{x:1245,y:631,t:1527613757519};\\\", \\\"{x:1238,y:632,t:1527613757536};\\\", \\\"{x:1234,y:633,t:1527613757553};\\\", \\\"{x:1230,y:633,t:1527613757570};\\\", \\\"{x:1225,y:634,t:1527613757586};\\\", \\\"{x:1221,y:634,t:1527613757603};\\\", \\\"{x:1216,y:636,t:1527613757619};\\\", \\\"{x:1207,y:638,t:1527613757636};\\\", \\\"{x:1192,y:639,t:1527613757653};\\\", \\\"{x:1170,y:641,t:1527613757670};\\\", \\\"{x:1150,y:642,t:1527613757686};\\\", \\\"{x:1128,y:644,t:1527613757703};\\\", \\\"{x:1095,y:647,t:1527613757720};\\\", \\\"{x:1077,y:648,t:1527613757736};\\\", \\\"{x:1060,y:653,t:1527613757753};\\\", \\\"{x:1040,y:654,t:1527613757770};\\\", \\\"{x:1023,y:655,t:1527613757786};\\\", \\\"{x:1002,y:655,t:1527613757803};\\\", \\\"{x:981,y:655,t:1527613757821};\\\", \\\"{x:959,y:655,t:1527613757836};\\\", \\\"{x:939,y:657,t:1527613757853};\\\", \\\"{x:922,y:657,t:1527613757870};\\\", \\\"{x:910,y:657,t:1527613757886};\\\", \\\"{x:898,y:658,t:1527613757903};\\\", \\\"{x:883,y:659,t:1527613757920};\\\", \\\"{x:873,y:660,t:1527613757937};\\\", \\\"{x:867,y:662,t:1527613757954};\\\", \\\"{x:858,y:664,t:1527613757971};\\\", \\\"{x:852,y:666,t:1527613757988};\\\", \\\"{x:844,y:667,t:1527613758003};\\\", \\\"{x:839,y:667,t:1527613758020};\\\", \\\"{x:831,y:668,t:1527613758038};\\\", \\\"{x:818,y:671,t:1527613758054};\\\", \\\"{x:807,y:671,t:1527613758070};\\\", \\\"{x:797,y:672,t:1527613758087};\\\", \\\"{x:781,y:676,t:1527613758104};\\\", \\\"{x:770,y:678,t:1527613758121};\\\", \\\"{x:765,y:678,t:1527613758137};\\\", \\\"{x:763,y:678,t:1527613758153};\\\", \\\"{x:758,y:678,t:1527613758170};\\\", \\\"{x:752,y:678,t:1527613758187};\\\", \\\"{x:748,y:678,t:1527613758203};\\\", \\\"{x:741,y:678,t:1527613758220};\\\", \\\"{x:735,y:678,t:1527613758237};\\\", \\\"{x:729,y:678,t:1527613758252};\\\", \\\"{x:724,y:678,t:1527613758270};\\\", \\\"{x:720,y:678,t:1527613758287};\\\", \\\"{x:718,y:678,t:1527613758302};\\\", \\\"{x:717,y:678,t:1527613758320};\\\", \\\"{x:716,y:678,t:1527613758337};\\\", \\\"{x:715,y:678,t:1527613758368};\\\", \\\"{x:714,y:678,t:1527613758425};\\\", \\\"{x:713,y:678,t:1527613758705};\\\", \\\"{x:712,y:678,t:1527613759680};\\\", \\\"{x:708,y:678,t:1527613759688};\\\", \\\"{x:698,y:676,t:1527613759705};\\\", \\\"{x:694,y:674,t:1527613759721};\\\", \\\"{x:679,y:667,t:1527613759738};\\\", \\\"{x:663,y:661,t:1527613759755};\\\", \\\"{x:652,y:657,t:1527613759772};\\\", \\\"{x:650,y:656,t:1527613759788};\\\", \\\"{x:650,y:654,t:1527613759849};\\\", \\\"{x:649,y:654,t:1527613759856};\\\", \\\"{x:649,y:653,t:1527613759872};\\\", \\\"{x:648,y:650,t:1527613759890};\\\", \\\"{x:647,y:648,t:1527613759905};\\\", \\\"{x:644,y:645,t:1527613759921};\\\", \\\"{x:641,y:641,t:1527613759938};\\\", \\\"{x:637,y:635,t:1527613759953};\\\", \\\"{x:630,y:627,t:1527613759971};\\\", \\\"{x:621,y:620,t:1527613759988};\\\", \\\"{x:614,y:614,t:1527613760006};\\\", \\\"{x:607,y:608,t:1527613760023};\\\", \\\"{x:602,y:606,t:1527613760038};\\\", \\\"{x:597,y:604,t:1527613760055};\\\", \\\"{x:593,y:603,t:1527613760072};\\\", \\\"{x:591,y:603,t:1527613760088};\\\", \\\"{x:590,y:603,t:1527613760105};\\\", \\\"{x:588,y:602,t:1527613760122};\\\", \\\"{x:592,y:600,t:1527613760233};\\\", \\\"{x:600,y:598,t:1527613760240};\\\", \\\"{x:612,y:597,t:1527613760255};\\\", \\\"{x:651,y:588,t:1527613760272};\\\", \\\"{x:677,y:581,t:1527613760289};\\\", \\\"{x:693,y:573,t:1527613760305};\\\", \\\"{x:696,y:571,t:1527613760322};\\\", \\\"{x:697,y:571,t:1527613760344};\\\", \\\"{x:699,y:569,t:1527613760360};\\\", \\\"{x:701,y:568,t:1527613760372};\\\", \\\"{x:705,y:567,t:1527613760389};\\\", \\\"{x:709,y:565,t:1527613760405};\\\", \\\"{x:713,y:563,t:1527613760422};\\\", \\\"{x:716,y:561,t:1527613760440};\\\", \\\"{x:718,y:561,t:1527613760455};\\\", \\\"{x:721,y:560,t:1527613760472};\\\", \\\"{x:733,y:555,t:1527613760492};\\\", \\\"{x:755,y:549,t:1527613760505};\\\", \\\"{x:777,y:544,t:1527613760521};\\\", \\\"{x:798,y:539,t:1527613760538};\\\", \\\"{x:815,y:536,t:1527613760555};\\\", \\\"{x:829,y:534,t:1527613760572};\\\", \\\"{x:837,y:533,t:1527613760589};\\\", \\\"{x:839,y:532,t:1527613760605};\\\", \\\"{x:840,y:532,t:1527613760622};\\\", \\\"{x:841,y:531,t:1527613760648};\\\", \\\"{x:841,y:530,t:1527613760817};\\\", \\\"{x:840,y:529,t:1527613760824};\\\", \\\"{x:839,y:529,t:1527613760840};\\\", \\\"{x:838,y:528,t:1527613760857};\\\", \\\"{x:836,y:528,t:1527613761119};\\\", \\\"{x:833,y:529,t:1527613761128};\\\", \\\"{x:831,y:530,t:1527613761139};\\\", \\\"{x:825,y:532,t:1527613761156};\\\", \\\"{x:810,y:539,t:1527613761173};\\\", \\\"{x:788,y:552,t:1527613761190};\\\", \\\"{x:760,y:575,t:1527613761207};\\\", \\\"{x:736,y:597,t:1527613761223};\\\", \\\"{x:724,y:615,t:1527613761240};\\\", \\\"{x:711,y:630,t:1527613761256};\\\", \\\"{x:706,y:638,t:1527613761273};\\\", \\\"{x:701,y:644,t:1527613761288};\\\", \\\"{x:695,y:649,t:1527613761306};\\\", \\\"{x:688,y:658,t:1527613761324};\\\", \\\"{x:682,y:665,t:1527613761339};\\\", \\\"{x:674,y:671,t:1527613761357};\\\", \\\"{x:671,y:675,t:1527613761373};\\\", \\\"{x:669,y:679,t:1527613761390};\\\", \\\"{x:667,y:680,t:1527613761406};\\\", \\\"{x:662,y:684,t:1527613761424};\\\", \\\"{x:651,y:688,t:1527613761440};\\\", \\\"{x:643,y:692,t:1527613761457};\\\", \\\"{x:633,y:698,t:1527613761474};\\\", \\\"{x:625,y:700,t:1527613761491};\\\", \\\"{x:610,y:707,t:1527613761507};\\\", \\\"{x:593,y:713,t:1527613761524};\\\", \\\"{x:577,y:715,t:1527613761541};\\\", \\\"{x:566,y:715,t:1527613761557};\\\", \\\"{x:554,y:715,t:1527613761576};\\\", \\\"{x:546,y:715,t:1527613761590};\\\", \\\"{x:541,y:715,t:1527613761606};\\\", \\\"{x:533,y:715,t:1527613761623};\\\", \\\"{x:523,y:715,t:1527613761639};\\\", \\\"{x:512,y:715,t:1527613761656};\\\", \\\"{x:505,y:715,t:1527613761673};\\\", \\\"{x:501,y:715,t:1527613761690};\\\" ] }, { \\\"rt\\\": 34774, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 122530, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-E -04 PM-E -E -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:716,t:1527613766609};\\\", \\\"{x:501,y:718,t:1527613766622};\\\", \\\"{x:501,y:722,t:1527613766633};\\\", \\\"{x:501,y:727,t:1527613766649};\\\", \\\"{x:505,y:736,t:1527613766665};\\\", \\\"{x:516,y:750,t:1527613766682};\\\", \\\"{x:525,y:756,t:1527613766693};\\\", \\\"{x:552,y:775,t:1527613766710};\\\", \\\"{x:579,y:797,t:1527613766727};\\\", \\\"{x:601,y:811,t:1527613766743};\\\", \\\"{x:632,y:831,t:1527613766760};\\\", \\\"{x:668,y:856,t:1527613766777};\\\", \\\"{x:686,y:858,t:1527613766793};\\\", \\\"{x:688,y:858,t:1527613766810};\\\", \\\"{x:695,y:863,t:1527613766827};\\\", \\\"{x:704,y:869,t:1527613766843};\\\", \\\"{x:717,y:878,t:1527613766860};\\\", \\\"{x:722,y:879,t:1527613766878};\\\", \\\"{x:728,y:882,t:1527613766894};\\\", \\\"{x:729,y:882,t:1527613766910};\\\", \\\"{x:729,y:884,t:1527613766927};\\\", \\\"{x:729,y:885,t:1527613766976};\\\", \\\"{x:734,y:888,t:1527613766985};\\\", \\\"{x:738,y:889,t:1527613766995};\\\", \\\"{x:757,y:896,t:1527613767011};\\\", \\\"{x:772,y:904,t:1527613767028};\\\", \\\"{x:790,y:906,t:1527613767045};\\\", \\\"{x:807,y:910,t:1527613767061};\\\", \\\"{x:834,y:912,t:1527613767078};\\\", \\\"{x:856,y:917,t:1527613767095};\\\", \\\"{x:876,y:921,t:1527613767112};\\\", \\\"{x:900,y:924,t:1527613767128};\\\", \\\"{x:931,y:928,t:1527613767144};\\\", \\\"{x:962,y:929,t:1527613767162};\\\", \\\"{x:993,y:933,t:1527613767178};\\\", \\\"{x:1034,y:940,t:1527613767195};\\\", \\\"{x:1088,y:951,t:1527613767212};\\\", \\\"{x:1159,y:965,t:1527613767228};\\\", \\\"{x:1237,y:976,t:1527613767245};\\\", \\\"{x:1314,y:985,t:1527613767262};\\\", \\\"{x:1388,y:991,t:1527613767278};\\\", \\\"{x:1439,y:992,t:1527613767295};\\\", \\\"{x:1474,y:992,t:1527613767312};\\\", \\\"{x:1497,y:993,t:1527613767328};\\\", \\\"{x:1527,y:993,t:1527613767344};\\\", \\\"{x:1538,y:993,t:1527613767361};\\\", \\\"{x:1554,y:993,t:1527613767377};\\\", \\\"{x:1571,y:992,t:1527613767394};\\\", \\\"{x:1588,y:989,t:1527613767412};\\\", \\\"{x:1602,y:984,t:1527613767428};\\\", \\\"{x:1609,y:980,t:1527613767445};\\\", \\\"{x:1610,y:979,t:1527613767461};\\\", \\\"{x:1611,y:978,t:1527613767479};\\\", \\\"{x:1611,y:977,t:1527613767494};\\\", \\\"{x:1611,y:976,t:1527613767512};\\\", \\\"{x:1611,y:975,t:1527613767544};\\\", \\\"{x:1611,y:974,t:1527613767568};\\\", \\\"{x:1611,y:973,t:1527613767579};\\\", \\\"{x:1611,y:972,t:1527613767595};\\\", \\\"{x:1610,y:969,t:1527613767612};\\\", \\\"{x:1610,y:965,t:1527613767629};\\\", \\\"{x:1610,y:963,t:1527613767645};\\\", \\\"{x:1610,y:962,t:1527613767663};\\\", \\\"{x:1610,y:960,t:1527613768241};\\\", \\\"{x:1610,y:958,t:1527613768256};\\\", \\\"{x:1610,y:957,t:1527613768273};\\\", \\\"{x:1610,y:956,t:1527613768280};\\\", \\\"{x:1610,y:954,t:1527613768297};\\\", \\\"{x:1610,y:953,t:1527613768313};\\\", \\\"{x:1610,y:952,t:1527613768330};\\\", \\\"{x:1610,y:951,t:1527613768346};\\\", \\\"{x:1610,y:950,t:1527613768363};\\\", \\\"{x:1610,y:949,t:1527613768391};\\\", \\\"{x:1610,y:948,t:1527613768416};\\\", \\\"{x:1609,y:947,t:1527613768429};\\\", \\\"{x:1609,y:946,t:1527613768445};\\\", \\\"{x:1608,y:944,t:1527613768463};\\\", \\\"{x:1606,y:938,t:1527613768480};\\\", \\\"{x:1604,y:931,t:1527613768496};\\\", \\\"{x:1601,y:925,t:1527613768512};\\\", \\\"{x:1600,y:920,t:1527613768529};\\\", \\\"{x:1597,y:916,t:1527613768545};\\\", \\\"{x:1597,y:911,t:1527613768563};\\\", \\\"{x:1596,y:905,t:1527613768580};\\\", \\\"{x:1593,y:900,t:1527613768596};\\\", \\\"{x:1592,y:897,t:1527613768613};\\\", \\\"{x:1591,y:894,t:1527613768630};\\\", \\\"{x:1591,y:893,t:1527613768645};\\\", \\\"{x:1591,y:892,t:1527613768663};\\\", \\\"{x:1591,y:891,t:1527613768680};\\\", \\\"{x:1591,y:889,t:1527613768697};\\\", \\\"{x:1591,y:887,t:1527613768713};\\\", \\\"{x:1590,y:886,t:1527613768730};\\\", \\\"{x:1590,y:885,t:1527613768747};\\\", \\\"{x:1589,y:884,t:1527613768763};\\\", \\\"{x:1589,y:881,t:1527613768780};\\\", \\\"{x:1589,y:878,t:1527613768797};\\\", \\\"{x:1589,y:877,t:1527613768816};\\\", \\\"{x:1589,y:876,t:1527613768830};\\\", \\\"{x:1587,y:874,t:1527613768847};\\\", \\\"{x:1587,y:873,t:1527613768865};\\\", \\\"{x:1587,y:872,t:1527613768921};\\\", \\\"{x:1587,y:871,t:1527613768961};\\\", \\\"{x:1587,y:870,t:1527613768969};\\\", \\\"{x:1587,y:869,t:1527613769017};\\\", \\\"{x:1587,y:868,t:1527613769057};\\\", \\\"{x:1587,y:867,t:1527613769081};\\\", \\\"{x:1587,y:866,t:1527613769145};\\\", \\\"{x:1587,y:865,t:1527613769169};\\\", \\\"{x:1587,y:863,t:1527613769241};\\\", \\\"{x:1586,y:862,t:1527613769248};\\\", \\\"{x:1585,y:862,t:1527613769424};\\\", \\\"{x:1584,y:861,t:1527613769431};\\\", \\\"{x:1584,y:860,t:1527613769488};\\\", \\\"{x:1584,y:859,t:1527613769528};\\\", \\\"{x:1584,y:858,t:1527613769585};\\\", \\\"{x:1584,y:857,t:1527613769633};\\\", \\\"{x:1585,y:856,t:1527613769648};\\\", \\\"{x:1585,y:854,t:1527613769714};\\\", \\\"{x:1585,y:853,t:1527613769744};\\\", \\\"{x:1585,y:851,t:1527613769801};\\\", \\\"{x:1585,y:850,t:1527613769857};\\\", \\\"{x:1586,y:850,t:1527613769865};\\\", \\\"{x:1586,y:848,t:1527613769881};\\\", \\\"{x:1586,y:847,t:1527613769920};\\\", \\\"{x:1586,y:845,t:1527613769999};\\\", \\\"{x:1586,y:844,t:1527613770080};\\\", \\\"{x:1587,y:843,t:1527613770136};\\\", \\\"{x:1587,y:842,t:1527613770193};\\\", \\\"{x:1587,y:841,t:1527613770216};\\\", \\\"{x:1587,y:840,t:1527613770282};\\\", \\\"{x:1587,y:839,t:1527613770361};\\\", \\\"{x:1587,y:838,t:1527613770408};\\\", \\\"{x:1587,y:837,t:1527613770681};\\\", \\\"{x:1587,y:836,t:1527613770729};\\\", \\\"{x:1587,y:835,t:1527613770769};\\\", \\\"{x:1587,y:834,t:1527613770905};\\\", \\\"{x:1587,y:832,t:1527613771088};\\\", \\\"{x:1587,y:831,t:1527613771169};\\\", \\\"{x:1587,y:830,t:1527613771209};\\\", \\\"{x:1587,y:829,t:1527613771233};\\\", \\\"{x:1587,y:828,t:1527613771264};\\\", \\\"{x:1587,y:827,t:1527613771283};\\\", \\\"{x:1587,y:826,t:1527613771305};\\\", \\\"{x:1587,y:825,t:1527613771329};\\\", \\\"{x:1587,y:823,t:1527613771337};\\\", \\\"{x:1587,y:821,t:1527613771369};\\\", \\\"{x:1587,y:820,t:1527613771384};\\\", \\\"{x:1587,y:818,t:1527613771409};\\\", \\\"{x:1587,y:817,t:1527613771431};\\\", \\\"{x:1587,y:815,t:1527613771455};\\\", \\\"{x:1587,y:813,t:1527613771480};\\\", \\\"{x:1587,y:812,t:1527613771536};\\\", \\\"{x:1586,y:811,t:1527613771576};\\\", \\\"{x:1586,y:810,t:1527613771616};\\\", \\\"{x:1586,y:809,t:1527613771632};\\\", \\\"{x:1586,y:808,t:1527613771663};\\\", \\\"{x:1585,y:808,t:1527613771672};\\\", \\\"{x:1585,y:807,t:1527613771704};\\\", \\\"{x:1583,y:807,t:1527613771841};\\\", \\\"{x:1583,y:811,t:1527613771850};\\\", \\\"{x:1577,y:818,t:1527613771867};\\\", \\\"{x:1574,y:831,t:1527613771883};\\\", \\\"{x:1573,y:839,t:1527613771901};\\\", \\\"{x:1573,y:845,t:1527613771918};\\\", \\\"{x:1573,y:854,t:1527613771934};\\\", \\\"{x:1574,y:860,t:1527613771950};\\\", \\\"{x:1574,y:863,t:1527613771967};\\\", \\\"{x:1576,y:874,t:1527613771984};\\\", \\\"{x:1578,y:882,t:1527613772000};\\\", \\\"{x:1580,y:888,t:1527613772017};\\\", \\\"{x:1583,y:895,t:1527613772034};\\\", \\\"{x:1588,y:902,t:1527613772051};\\\", \\\"{x:1589,y:904,t:1527613772067};\\\", \\\"{x:1591,y:906,t:1527613772084};\\\", \\\"{x:1592,y:907,t:1527613772100};\\\", \\\"{x:1593,y:910,t:1527613772117};\\\", \\\"{x:1596,y:914,t:1527613772134};\\\", \\\"{x:1602,y:920,t:1527613772150};\\\", \\\"{x:1608,y:926,t:1527613772167};\\\", \\\"{x:1622,y:939,t:1527613772185};\\\", \\\"{x:1627,y:946,t:1527613772201};\\\", \\\"{x:1630,y:951,t:1527613772217};\\\", \\\"{x:1631,y:954,t:1527613772234};\\\", \\\"{x:1631,y:956,t:1527613772251};\\\", \\\"{x:1631,y:957,t:1527613772267};\\\", \\\"{x:1633,y:960,t:1527613772284};\\\", \\\"{x:1635,y:963,t:1527613772301};\\\", \\\"{x:1635,y:965,t:1527613772317};\\\", \\\"{x:1636,y:966,t:1527613772334};\\\", \\\"{x:1636,y:967,t:1527613772351};\\\", \\\"{x:1636,y:968,t:1527613772401};\\\", \\\"{x:1635,y:969,t:1527613772433};\\\", \\\"{x:1633,y:970,t:1527613772448};\\\", \\\"{x:1631,y:970,t:1527613772463};\\\", \\\"{x:1630,y:970,t:1527613772480};\\\", \\\"{x:1628,y:970,t:1527613772488};\\\", \\\"{x:1627,y:970,t:1527613772501};\\\", \\\"{x:1622,y:971,t:1527613772516};\\\", \\\"{x:1620,y:971,t:1527613772534};\\\", \\\"{x:1617,y:971,t:1527613772550};\\\", \\\"{x:1614,y:971,t:1527613772567};\\\", \\\"{x:1613,y:971,t:1527613772584};\\\", \\\"{x:1612,y:971,t:1527613772649};\\\", \\\"{x:1611,y:971,t:1527613772656};\\\", \\\"{x:1610,y:971,t:1527613772672};\\\", \\\"{x:1610,y:970,t:1527613772683};\\\", \\\"{x:1609,y:969,t:1527613772701};\\\", \\\"{x:1609,y:967,t:1527613772718};\\\", \\\"{x:1609,y:965,t:1527613772734};\\\", \\\"{x:1609,y:962,t:1527613772751};\\\", \\\"{x:1607,y:958,t:1527613772768};\\\", \\\"{x:1606,y:952,t:1527613772784};\\\", \\\"{x:1606,y:947,t:1527613772802};\\\", \\\"{x:1606,y:943,t:1527613772818};\\\", \\\"{x:1606,y:938,t:1527613772835};\\\", \\\"{x:1606,y:934,t:1527613772851};\\\", \\\"{x:1606,y:930,t:1527613772868};\\\", \\\"{x:1604,y:925,t:1527613772885};\\\", \\\"{x:1602,y:922,t:1527613772901};\\\", \\\"{x:1602,y:920,t:1527613772918};\\\", \\\"{x:1602,y:918,t:1527613772934};\\\", \\\"{x:1602,y:915,t:1527613772950};\\\", \\\"{x:1602,y:909,t:1527613772968};\\\", \\\"{x:1602,y:906,t:1527613772984};\\\", \\\"{x:1602,y:902,t:1527613773000};\\\", \\\"{x:1601,y:897,t:1527613773017};\\\", \\\"{x:1599,y:892,t:1527613773035};\\\", \\\"{x:1599,y:888,t:1527613773051};\\\", \\\"{x:1599,y:887,t:1527613773068};\\\", \\\"{x:1599,y:884,t:1527613773085};\\\", \\\"{x:1599,y:883,t:1527613773101};\\\", \\\"{x:1599,y:881,t:1527613773118};\\\", \\\"{x:1599,y:878,t:1527613773134};\\\", \\\"{x:1599,y:873,t:1527613773152};\\\", \\\"{x:1599,y:870,t:1527613773168};\\\", \\\"{x:1599,y:866,t:1527613773185};\\\", \\\"{x:1599,y:860,t:1527613773202};\\\", \\\"{x:1599,y:857,t:1527613773219};\\\", \\\"{x:1600,y:854,t:1527613773235};\\\", \\\"{x:1600,y:852,t:1527613773252};\\\", \\\"{x:1603,y:849,t:1527613773269};\\\", \\\"{x:1603,y:845,t:1527613773285};\\\", \\\"{x:1604,y:841,t:1527613773302};\\\", \\\"{x:1605,y:837,t:1527613773318};\\\", \\\"{x:1606,y:832,t:1527613773335};\\\", \\\"{x:1607,y:830,t:1527613773352};\\\", \\\"{x:1607,y:829,t:1527613773385};\\\", \\\"{x:1607,y:827,t:1527613773402};\\\", \\\"{x:1607,y:825,t:1527613773419};\\\", \\\"{x:1607,y:821,t:1527613773436};\\\", \\\"{x:1607,y:819,t:1527613773451};\\\", \\\"{x:1607,y:817,t:1527613773469};\\\", \\\"{x:1607,y:814,t:1527613773484};\\\", \\\"{x:1607,y:811,t:1527613773502};\\\", \\\"{x:1607,y:808,t:1527613773519};\\\", \\\"{x:1607,y:804,t:1527613773535};\\\", \\\"{x:1607,y:796,t:1527613773552};\\\", \\\"{x:1607,y:791,t:1527613773569};\\\", \\\"{x:1607,y:788,t:1527613773585};\\\", \\\"{x:1606,y:782,t:1527613773602};\\\", \\\"{x:1605,y:777,t:1527613773618};\\\", \\\"{x:1605,y:770,t:1527613773635};\\\", \\\"{x:1604,y:762,t:1527613773651};\\\", \\\"{x:1601,y:752,t:1527613773668};\\\", \\\"{x:1600,y:741,t:1527613773684};\\\", \\\"{x:1600,y:734,t:1527613773702};\\\", \\\"{x:1600,y:730,t:1527613773719};\\\", \\\"{x:1600,y:725,t:1527613773735};\\\", \\\"{x:1600,y:723,t:1527613773751};\\\", \\\"{x:1599,y:720,t:1527613773769};\\\", \\\"{x:1599,y:718,t:1527613773785};\\\", \\\"{x:1598,y:715,t:1527613773802};\\\", \\\"{x:1598,y:713,t:1527613773819};\\\", \\\"{x:1598,y:711,t:1527613773836};\\\", \\\"{x:1598,y:708,t:1527613773852};\\\", \\\"{x:1598,y:706,t:1527613773869};\\\", \\\"{x:1598,y:703,t:1527613773886};\\\", \\\"{x:1598,y:699,t:1527613773902};\\\", \\\"{x:1598,y:696,t:1527613773918};\\\", \\\"{x:1597,y:690,t:1527613773936};\\\", \\\"{x:1597,y:686,t:1527613773952};\\\", \\\"{x:1597,y:683,t:1527613773968};\\\", \\\"{x:1597,y:682,t:1527613773985};\\\", \\\"{x:1597,y:680,t:1527613774003};\\\", \\\"{x:1597,y:679,t:1527613774023};\\\", \\\"{x:1597,y:678,t:1527613774036};\\\", \\\"{x:1597,y:677,t:1527613774053};\\\", \\\"{x:1597,y:675,t:1527613774068};\\\", \\\"{x:1597,y:674,t:1527613774086};\\\", \\\"{x:1597,y:671,t:1527613774102};\\\", \\\"{x:1597,y:669,t:1527613774119};\\\", \\\"{x:1597,y:664,t:1527613774135};\\\", \\\"{x:1597,y:661,t:1527613774153};\\\", \\\"{x:1597,y:657,t:1527613774169};\\\", \\\"{x:1597,y:654,t:1527613774186};\\\", \\\"{x:1597,y:649,t:1527613774203};\\\", \\\"{x:1597,y:645,t:1527613774218};\\\", \\\"{x:1596,y:641,t:1527613774235};\\\", \\\"{x:1596,y:639,t:1527613774253};\\\", \\\"{x:1596,y:636,t:1527613774270};\\\", \\\"{x:1596,y:634,t:1527613774285};\\\", \\\"{x:1596,y:631,t:1527613774302};\\\", \\\"{x:1596,y:626,t:1527613774320};\\\", \\\"{x:1596,y:624,t:1527613774336};\\\", \\\"{x:1596,y:621,t:1527613774352};\\\", \\\"{x:1596,y:617,t:1527613774369};\\\", \\\"{x:1597,y:614,t:1527613774385};\\\", \\\"{x:1597,y:612,t:1527613774402};\\\", \\\"{x:1597,y:610,t:1527613774420};\\\", \\\"{x:1597,y:609,t:1527613774436};\\\", \\\"{x:1597,y:607,t:1527613774453};\\\", \\\"{x:1597,y:604,t:1527613774470};\\\", \\\"{x:1597,y:603,t:1527613774486};\\\", \\\"{x:1597,y:601,t:1527613774503};\\\", \\\"{x:1597,y:598,t:1527613774520};\\\", \\\"{x:1597,y:596,t:1527613774535};\\\", \\\"{x:1597,y:595,t:1527613774552};\\\", \\\"{x:1597,y:594,t:1527613774570};\\\", \\\"{x:1597,y:592,t:1527613774586};\\\", \\\"{x:1597,y:590,t:1527613774603};\\\", \\\"{x:1597,y:588,t:1527613774619};\\\", \\\"{x:1597,y:586,t:1527613774636};\\\", \\\"{x:1597,y:585,t:1527613774653};\\\", \\\"{x:1597,y:584,t:1527613774669};\\\", \\\"{x:1597,y:583,t:1527613774703};\\\", \\\"{x:1597,y:582,t:1527613774720};\\\", \\\"{x:1597,y:581,t:1527613774743};\\\", \\\"{x:1597,y:580,t:1527613774767};\\\", \\\"{x:1597,y:579,t:1527613774808};\\\", \\\"{x:1597,y:578,t:1527613774819};\\\", \\\"{x:1598,y:577,t:1527613774848};\\\", \\\"{x:1598,y:576,t:1527613774863};\\\", \\\"{x:1598,y:575,t:1527613774904};\\\", \\\"{x:1599,y:575,t:1527613774920};\\\", \\\"{x:1600,y:574,t:1527613775008};\\\", \\\"{x:1600,y:573,t:1527613775065};\\\", \\\"{x:1601,y:572,t:1527613775128};\\\", \\\"{x:1601,y:570,t:1527613775159};\\\", \\\"{x:1601,y:568,t:1527613775175};\\\", \\\"{x:1601,y:567,t:1527613775186};\\\", \\\"{x:1601,y:566,t:1527613775208};\\\", \\\"{x:1602,y:565,t:1527613775221};\\\", \\\"{x:1603,y:565,t:1527613775495};\\\", \\\"{x:1606,y:563,t:1527613775504};\\\", \\\"{x:1607,y:563,t:1527613775543};\\\", \\\"{x:1609,y:563,t:1527613775804};\\\", \\\"{x:1610,y:565,t:1527613775821};\\\", \\\"{x:1610,y:585,t:1527613775838};\\\", \\\"{x:1610,y:610,t:1527613775855};\\\", \\\"{x:1610,y:629,t:1527613775871};\\\", \\\"{x:1610,y:648,t:1527613775888};\\\", \\\"{x:1610,y:663,t:1527613775904};\\\", \\\"{x:1610,y:678,t:1527613775921};\\\", \\\"{x:1610,y:696,t:1527613775938};\\\", \\\"{x:1610,y:714,t:1527613775955};\\\", \\\"{x:1610,y:730,t:1527613775971};\\\", \\\"{x:1610,y:748,t:1527613775987};\\\", \\\"{x:1611,y:758,t:1527613776005};\\\", \\\"{x:1613,y:773,t:1527613776021};\\\", \\\"{x:1616,y:785,t:1527613776038};\\\", \\\"{x:1616,y:799,t:1527613776055};\\\", \\\"{x:1617,y:817,t:1527613776071};\\\", \\\"{x:1621,y:833,t:1527613776087};\\\", \\\"{x:1622,y:847,t:1527613776105};\\\", \\\"{x:1624,y:863,t:1527613776122};\\\", \\\"{x:1625,y:871,t:1527613776138};\\\", \\\"{x:1626,y:881,t:1527613776155};\\\", \\\"{x:1626,y:891,t:1527613776171};\\\", \\\"{x:1626,y:902,t:1527613776188};\\\", \\\"{x:1626,y:912,t:1527613776205};\\\", \\\"{x:1626,y:922,t:1527613776222};\\\", \\\"{x:1627,y:932,t:1527613776238};\\\", \\\"{x:1628,y:938,t:1527613776255};\\\", \\\"{x:1629,y:945,t:1527613776271};\\\", \\\"{x:1630,y:947,t:1527613776288};\\\", \\\"{x:1630,y:953,t:1527613776305};\\\", \\\"{x:1630,y:957,t:1527613776322};\\\", \\\"{x:1630,y:960,t:1527613776338};\\\", \\\"{x:1630,y:962,t:1527613776355};\\\", \\\"{x:1630,y:964,t:1527613776372};\\\", \\\"{x:1630,y:966,t:1527613776388};\\\", \\\"{x:1629,y:970,t:1527613776405};\\\", \\\"{x:1627,y:973,t:1527613776422};\\\", \\\"{x:1626,y:974,t:1527613776439};\\\", \\\"{x:1625,y:975,t:1527613776471};\\\", \\\"{x:1623,y:976,t:1527613776496};\\\", \\\"{x:1622,y:977,t:1527613776512};\\\", \\\"{x:1620,y:978,t:1527613776522};\\\", \\\"{x:1619,y:978,t:1527613776539};\\\", \\\"{x:1617,y:979,t:1527613776554};\\\", \\\"{x:1616,y:979,t:1527613776576};\\\", \\\"{x:1615,y:979,t:1527613776588};\\\", \\\"{x:1613,y:979,t:1527613776605};\\\", \\\"{x:1611,y:979,t:1527613776622};\\\", \\\"{x:1609,y:979,t:1527613776639};\\\", \\\"{x:1607,y:979,t:1527613776656};\\\", \\\"{x:1606,y:979,t:1527613776712};\\\", \\\"{x:1605,y:978,t:1527613776735};\\\", \\\"{x:1604,y:974,t:1527613776744};\\\", \\\"{x:1604,y:973,t:1527613776759};\\\", \\\"{x:1604,y:971,t:1527613776772};\\\", \\\"{x:1604,y:969,t:1527613776788};\\\", \\\"{x:1603,y:968,t:1527613776805};\\\", \\\"{x:1603,y:965,t:1527613776821};\\\", \\\"{x:1603,y:962,t:1527613776839};\\\", \\\"{x:1603,y:957,t:1527613776856};\\\", \\\"{x:1603,y:956,t:1527613776872};\\\", \\\"{x:1603,y:953,t:1527613776889};\\\", \\\"{x:1603,y:952,t:1527613776927};\\\", \\\"{x:1603,y:951,t:1527613776951};\\\", \\\"{x:1604,y:950,t:1527613776967};\\\", \\\"{x:1604,y:949,t:1527613780625};\\\", \\\"{x:1604,y:948,t:1527613780632};\\\", \\\"{x:1604,y:947,t:1527613780643};\\\", \\\"{x:1604,y:946,t:1527613780672};\\\", \\\"{x:1604,y:945,t:1527613780703};\\\", \\\"{x:1605,y:944,t:1527613780712};\\\", \\\"{x:1606,y:944,t:1527613780760};\\\", \\\"{x:1606,y:943,t:1527613780777};\\\", \\\"{x:1607,y:943,t:1527613780799};\\\", \\\"{x:1607,y:942,t:1527613780815};\\\", \\\"{x:1607,y:941,t:1527613780839};\\\", \\\"{x:1607,y:940,t:1527613780848};\\\", \\\"{x:1607,y:939,t:1527613780860};\\\", \\\"{x:1607,y:938,t:1527613780877};\\\", \\\"{x:1607,y:936,t:1527613780893};\\\", \\\"{x:1607,y:935,t:1527613780913};\\\", \\\"{x:1607,y:934,t:1527613780928};\\\", \\\"{x:1608,y:932,t:1527613780945};\\\", \\\"{x:1609,y:930,t:1527613780960};\\\", \\\"{x:1609,y:929,t:1527613780985};\\\", \\\"{x:1609,y:927,t:1527613780994};\\\", \\\"{x:1609,y:925,t:1527613781010};\\\", \\\"{x:1609,y:923,t:1527613781027};\\\", \\\"{x:1609,y:920,t:1527613781044};\\\", \\\"{x:1609,y:919,t:1527613781060};\\\", \\\"{x:1609,y:917,t:1527613781077};\\\", \\\"{x:1609,y:912,t:1527613781094};\\\", \\\"{x:1609,y:909,t:1527613781110};\\\", \\\"{x:1609,y:906,t:1527613781127};\\\", \\\"{x:1608,y:903,t:1527613781144};\\\", \\\"{x:1608,y:900,t:1527613781161};\\\", \\\"{x:1606,y:898,t:1527613781177};\\\", \\\"{x:1605,y:896,t:1527613781208};\\\", \\\"{x:1605,y:895,t:1527613781232};\\\", \\\"{x:1605,y:893,t:1527613781256};\\\", \\\"{x:1605,y:892,t:1527613781280};\\\", \\\"{x:1605,y:890,t:1527613781321};\\\", \\\"{x:1605,y:889,t:1527613781361};\\\", \\\"{x:1605,y:887,t:1527613781378};\\\", \\\"{x:1605,y:885,t:1527613781394};\\\", \\\"{x:1604,y:883,t:1527613781412};\\\", \\\"{x:1604,y:882,t:1527613781428};\\\", \\\"{x:1604,y:880,t:1527613781445};\\\", \\\"{x:1604,y:879,t:1527613781461};\\\", \\\"{x:1604,y:877,t:1527613781477};\\\", \\\"{x:1604,y:874,t:1527613781494};\\\", \\\"{x:1604,y:872,t:1527613781511};\\\", \\\"{x:1604,y:868,t:1527613781528};\\\", \\\"{x:1603,y:867,t:1527613781544};\\\", \\\"{x:1603,y:865,t:1527613781562};\\\", \\\"{x:1602,y:864,t:1527613781592};\\\", \\\"{x:1602,y:863,t:1527613781608};\\\", \\\"{x:1602,y:862,t:1527613781616};\\\", \\\"{x:1602,y:861,t:1527613781629};\\\", \\\"{x:1602,y:858,t:1527613781644};\\\", \\\"{x:1602,y:856,t:1527613781662};\\\", \\\"{x:1602,y:854,t:1527613781678};\\\", \\\"{x:1602,y:852,t:1527613781694};\\\", \\\"{x:1602,y:851,t:1527613781712};\\\", \\\"{x:1602,y:849,t:1527613781736};\\\", \\\"{x:1602,y:848,t:1527613781759};\\\", \\\"{x:1602,y:846,t:1527613781783};\\\", \\\"{x:1602,y:845,t:1527613781799};\\\", \\\"{x:1602,y:844,t:1527613781811};\\\", \\\"{x:1602,y:843,t:1527613781828};\\\", \\\"{x:1602,y:842,t:1527613781845};\\\", \\\"{x:1603,y:841,t:1527613781861};\\\", \\\"{x:1603,y:840,t:1527613781878};\\\", \\\"{x:1603,y:839,t:1527613781895};\\\", \\\"{x:1605,y:837,t:1527613781911};\\\", \\\"{x:1605,y:836,t:1527613781928};\\\", \\\"{x:1605,y:834,t:1527613781960};\\\", \\\"{x:1606,y:833,t:1527613781968};\\\", \\\"{x:1607,y:832,t:1527613781992};\\\", \\\"{x:1608,y:830,t:1527613782009};\\\", \\\"{x:1609,y:829,t:1527613782017};\\\", \\\"{x:1610,y:827,t:1527613782032};\\\", \\\"{x:1610,y:826,t:1527613782064};\\\", \\\"{x:1611,y:826,t:1527613782079};\\\", \\\"{x:1612,y:825,t:1527613782096};\\\", \\\"{x:1612,y:824,t:1527613782112};\\\", \\\"{x:1613,y:823,t:1527613782137};\\\", \\\"{x:1613,y:822,t:1527613782153};\\\", \\\"{x:1614,y:822,t:1527613782289};\\\", \\\"{x:1615,y:821,t:1527613783321};\\\", \\\"{x:1615,y:820,t:1527613783360};\\\", \\\"{x:1615,y:819,t:1527613783417};\\\", \\\"{x:1614,y:818,t:1527613783440};\\\", \\\"{x:1614,y:817,t:1527613783497};\\\", \\\"{x:1614,y:816,t:1527613783515};\\\", \\\"{x:1614,y:815,t:1527613783530};\\\", \\\"{x:1614,y:814,t:1527613783546};\\\", \\\"{x:1614,y:813,t:1527613783564};\\\", \\\"{x:1613,y:813,t:1527613783616};\\\", \\\"{x:1613,y:812,t:1527613783648};\\\", \\\"{x:1613,y:811,t:1527613784409};\\\", \\\"{x:1613,y:810,t:1527613784425};\\\", \\\"{x:1613,y:808,t:1527613784432};\\\", \\\"{x:1613,y:807,t:1527613784448};\\\", \\\"{x:1613,y:805,t:1527613784464};\\\", \\\"{x:1613,y:804,t:1527613784504};\\\", \\\"{x:1613,y:802,t:1527613784560};\\\", \\\"{x:1612,y:802,t:1527613784576};\\\", \\\"{x:1612,y:801,t:1527613784625};\\\", \\\"{x:1611,y:801,t:1527613784632};\\\", \\\"{x:1611,y:800,t:1527613784657};\\\", \\\"{x:1611,y:799,t:1527613784680};\\\", \\\"{x:1609,y:797,t:1527613784696};\\\", \\\"{x:1609,y:796,t:1527613784728};\\\", \\\"{x:1609,y:795,t:1527613784737};\\\", \\\"{x:1609,y:794,t:1527613784760};\\\", \\\"{x:1609,y:793,t:1527613784768};\\\", \\\"{x:1609,y:792,t:1527613784782};\\\", \\\"{x:1608,y:790,t:1527613784799};\\\", \\\"{x:1608,y:789,t:1527613784815};\\\", \\\"{x:1608,y:788,t:1527613784832};\\\", \\\"{x:1608,y:787,t:1527613784848};\\\", \\\"{x:1608,y:786,t:1527613784866};\\\", \\\"{x:1607,y:786,t:1527613784882};\\\", \\\"{x:1606,y:784,t:1527613784899};\\\", \\\"{x:1606,y:783,t:1527613784937};\\\", \\\"{x:1606,y:782,t:1527613784969};\\\", \\\"{x:1606,y:781,t:1527613784982};\\\", \\\"{x:1606,y:780,t:1527613784999};\\\", \\\"{x:1606,y:779,t:1527613785016};\\\", \\\"{x:1606,y:778,t:1527613785032};\\\", \\\"{x:1606,y:775,t:1527613785048};\\\", \\\"{x:1606,y:774,t:1527613785065};\\\", \\\"{x:1606,y:773,t:1527613785081};\\\", \\\"{x:1606,y:771,t:1527613785098};\\\", \\\"{x:1606,y:770,t:1527613785115};\\\", \\\"{x:1607,y:768,t:1527613785133};\\\", \\\"{x:1607,y:767,t:1527613785152};\\\", \\\"{x:1608,y:767,t:1527613785166};\\\", \\\"{x:1608,y:766,t:1527613785184};\\\", \\\"{x:1609,y:765,t:1527613785199};\\\", \\\"{x:1610,y:764,t:1527613785225};\\\", \\\"{x:1610,y:763,t:1527613785257};\\\", \\\"{x:1610,y:762,t:1527613785266};\\\", \\\"{x:1610,y:760,t:1527613785283};\\\", \\\"{x:1612,y:758,t:1527613785298};\\\", \\\"{x:1612,y:754,t:1527613785316};\\\", \\\"{x:1612,y:751,t:1527613785333};\\\", \\\"{x:1613,y:749,t:1527613785348};\\\", \\\"{x:1613,y:747,t:1527613785365};\\\", \\\"{x:1613,y:745,t:1527613785383};\\\", \\\"{x:1613,y:744,t:1527613785400};\\\", \\\"{x:1613,y:741,t:1527613785416};\\\", \\\"{x:1613,y:739,t:1527613785433};\\\", \\\"{x:1613,y:737,t:1527613785450};\\\", \\\"{x:1613,y:736,t:1527613785466};\\\", \\\"{x:1613,y:735,t:1527613785497};\\\", \\\"{x:1613,y:734,t:1527613785512};\\\", \\\"{x:1613,y:733,t:1527613785528};\\\", \\\"{x:1613,y:732,t:1527613785544};\\\", \\\"{x:1613,y:731,t:1527613785552};\\\", \\\"{x:1613,y:730,t:1527613785566};\\\", \\\"{x:1613,y:728,t:1527613785583};\\\", \\\"{x:1613,y:726,t:1527613785600};\\\", \\\"{x:1613,y:724,t:1527613785617};\\\", \\\"{x:1613,y:723,t:1527613785633};\\\", \\\"{x:1613,y:721,t:1527613785650};\\\", \\\"{x:1613,y:719,t:1527613785666};\\\", \\\"{x:1613,y:716,t:1527613785683};\\\", \\\"{x:1613,y:714,t:1527613785700};\\\", \\\"{x:1613,y:712,t:1527613785717};\\\", \\\"{x:1613,y:711,t:1527613785733};\\\", \\\"{x:1613,y:710,t:1527613785750};\\\", \\\"{x:1613,y:708,t:1527613785767};\\\", \\\"{x:1613,y:706,t:1527613785783};\\\", \\\"{x:1613,y:705,t:1527613785800};\\\", \\\"{x:1612,y:704,t:1527613785815};\\\", \\\"{x:1612,y:702,t:1527613785833};\\\", \\\"{x:1612,y:701,t:1527613785849};\\\", \\\"{x:1612,y:700,t:1527613785866};\\\", \\\"{x:1611,y:699,t:1527613785883};\\\", \\\"{x:1611,y:698,t:1527613785927};\\\", \\\"{x:1611,y:697,t:1527613785952};\\\", \\\"{x:1611,y:696,t:1527613786008};\\\", \\\"{x:1611,y:695,t:1527613786752};\\\", \\\"{x:1611,y:693,t:1527613786767};\\\", \\\"{x:1611,y:692,t:1527613786783};\\\", \\\"{x:1611,y:690,t:1527613786801};\\\", \\\"{x:1611,y:689,t:1527613786817};\\\", \\\"{x:1611,y:688,t:1527613786847};\\\", \\\"{x:1611,y:687,t:1527613786863};\\\", \\\"{x:1611,y:686,t:1527613786896};\\\", \\\"{x:1611,y:685,t:1527613786911};\\\", \\\"{x:1611,y:684,t:1527613786927};\\\", \\\"{x:1611,y:683,t:1527613786943};\\\", \\\"{x:1611,y:682,t:1527613786951};\\\", \\\"{x:1611,y:681,t:1527613786968};\\\", \\\"{x:1611,y:679,t:1527613786984};\\\", \\\"{x:1611,y:677,t:1527613787000};\\\", \\\"{x:1611,y:675,t:1527613787017};\\\", \\\"{x:1611,y:673,t:1527613787034};\\\", \\\"{x:1611,y:671,t:1527613787051};\\\", \\\"{x:1611,y:669,t:1527613787067};\\\", \\\"{x:1611,y:667,t:1527613787085};\\\", \\\"{x:1611,y:665,t:1527613787101};\\\", \\\"{x:1610,y:664,t:1527613787117};\\\", \\\"{x:1610,y:662,t:1527613787135};\\\", \\\"{x:1610,y:659,t:1527613787151};\\\", \\\"{x:1610,y:658,t:1527613787168};\\\", \\\"{x:1610,y:657,t:1527613787185};\\\", \\\"{x:1609,y:655,t:1527613787201};\\\", \\\"{x:1609,y:653,t:1527613787218};\\\", \\\"{x:1609,y:651,t:1527613787235};\\\", \\\"{x:1609,y:649,t:1527613787252};\\\", \\\"{x:1608,y:646,t:1527613787267};\\\", \\\"{x:1608,y:645,t:1527613787287};\\\", \\\"{x:1608,y:643,t:1527613787304};\\\", \\\"{x:1608,y:642,t:1527613787327};\\\", \\\"{x:1608,y:639,t:1527613787344};\\\", \\\"{x:1608,y:638,t:1527613787360};\\\", \\\"{x:1608,y:637,t:1527613787368};\\\", \\\"{x:1608,y:636,t:1527613787384};\\\", \\\"{x:1608,y:634,t:1527613787401};\\\", \\\"{x:1608,y:633,t:1527613787418};\\\", \\\"{x:1608,y:632,t:1527613787434};\\\", \\\"{x:1608,y:631,t:1527613787451};\\\", \\\"{x:1608,y:629,t:1527613787468};\\\", \\\"{x:1608,y:627,t:1527613787484};\\\", \\\"{x:1608,y:623,t:1527613787502};\\\", \\\"{x:1608,y:621,t:1527613787518};\\\", \\\"{x:1608,y:620,t:1527613787535};\\\", \\\"{x:1608,y:617,t:1527613787552};\\\", \\\"{x:1608,y:615,t:1527613787569};\\\", \\\"{x:1608,y:614,t:1527613787585};\\\", \\\"{x:1608,y:612,t:1527613787602};\\\", \\\"{x:1608,y:611,t:1527613787619};\\\", \\\"{x:1608,y:610,t:1527613787635};\\\", \\\"{x:1608,y:609,t:1527613787652};\\\", \\\"{x:1608,y:608,t:1527613787669};\\\", \\\"{x:1608,y:607,t:1527613787684};\\\", \\\"{x:1608,y:606,t:1527613787702};\\\", \\\"{x:1608,y:605,t:1527613787719};\\\", \\\"{x:1608,y:604,t:1527613787743};\\\", \\\"{x:1608,y:602,t:1527613787751};\\\", \\\"{x:1608,y:600,t:1527613787768};\\\", \\\"{x:1609,y:600,t:1527613787784};\\\", \\\"{x:1609,y:599,t:1527613787802};\\\", \\\"{x:1609,y:598,t:1527613787818};\\\", \\\"{x:1609,y:597,t:1527613787835};\\\", \\\"{x:1609,y:596,t:1527613787851};\\\", \\\"{x:1609,y:594,t:1527613787869};\\\", \\\"{x:1609,y:593,t:1527613787888};\\\", \\\"{x:1610,y:591,t:1527613787913};\\\", \\\"{x:1610,y:590,t:1527613787952};\\\", \\\"{x:1610,y:589,t:1527613787968};\\\", \\\"{x:1610,y:588,t:1527613787986};\\\", \\\"{x:1611,y:586,t:1527613788008};\\\", \\\"{x:1612,y:586,t:1527613788024};\\\", \\\"{x:1612,y:585,t:1527613788057};\\\", \\\"{x:1612,y:584,t:1527613788072};\\\", \\\"{x:1612,y:583,t:1527613788097};\\\", \\\"{x:1612,y:582,t:1527613788136};\\\", \\\"{x:1612,y:581,t:1527613788153};\\\", \\\"{x:1612,y:580,t:1527613788169};\\\", \\\"{x:1612,y:579,t:1527613788209};\\\", \\\"{x:1612,y:578,t:1527613788219};\\\", \\\"{x:1612,y:577,t:1527613788249};\\\", \\\"{x:1612,y:576,t:1527613788265};\\\", \\\"{x:1612,y:575,t:1527613788280};\\\", \\\"{x:1612,y:574,t:1527613788345};\\\", \\\"{x:1612,y:573,t:1527613788368};\\\", \\\"{x:1612,y:572,t:1527613788400};\\\", \\\"{x:1612,y:571,t:1527613788481};\\\", \\\"{x:1612,y:570,t:1527613788504};\\\", \\\"{x:1612,y:569,t:1527613788521};\\\", \\\"{x:1612,y:568,t:1527613788554};\\\", \\\"{x:1612,y:567,t:1527613788570};\\\", \\\"{x:1612,y:566,t:1527613788585};\\\", \\\"{x:1612,y:565,t:1527613788616};\\\", \\\"{x:1612,y:564,t:1527613788640};\\\", \\\"{x:1612,y:563,t:1527613788653};\\\", \\\"{x:1612,y:562,t:1527613788680};\\\", \\\"{x:1612,y:561,t:1527613788721};\\\", \\\"{x:1612,y:560,t:1527613788744};\\\", \\\"{x:1612,y:559,t:1527613788800};\\\", \\\"{x:1612,y:558,t:1527613788936};\\\", \\\"{x:1612,y:557,t:1527613789033};\\\", \\\"{x:1612,y:555,t:1527613791816};\\\", \\\"{x:1612,y:554,t:1527613791832};\\\", \\\"{x:1612,y:553,t:1527613791856};\\\", \\\"{x:1612,y:552,t:1527613791881};\\\", \\\"{x:1612,y:550,t:1527613791904};\\\", \\\"{x:1612,y:548,t:1527613791943};\\\", \\\"{x:1612,y:547,t:1527613791956};\\\", \\\"{x:1613,y:545,t:1527613791973};\\\", \\\"{x:1613,y:542,t:1527613791989};\\\", \\\"{x:1613,y:540,t:1527613792007};\\\", \\\"{x:1613,y:537,t:1527613792023};\\\", \\\"{x:1613,y:535,t:1527613792040};\\\", \\\"{x:1613,y:533,t:1527613792071};\\\", \\\"{x:1613,y:532,t:1527613792079};\\\", \\\"{x:1613,y:531,t:1527613792089};\\\", \\\"{x:1613,y:528,t:1527613792107};\\\", \\\"{x:1613,y:525,t:1527613792124};\\\", \\\"{x:1613,y:524,t:1527613792140};\\\", \\\"{x:1613,y:522,t:1527613792157};\\\", \\\"{x:1613,y:519,t:1527613792174};\\\", \\\"{x:1613,y:516,t:1527613792190};\\\", \\\"{x:1611,y:511,t:1527613792207};\\\", \\\"{x:1610,y:506,t:1527613792224};\\\", \\\"{x:1610,y:505,t:1527613792240};\\\", \\\"{x:1609,y:502,t:1527613792257};\\\", \\\"{x:1609,y:500,t:1527613792274};\\\", \\\"{x:1608,y:498,t:1527613792290};\\\", \\\"{x:1608,y:497,t:1527613792307};\\\", \\\"{x:1608,y:496,t:1527613792324};\\\", \\\"{x:1608,y:495,t:1527613792342};\\\", \\\"{x:1608,y:494,t:1527613792357};\\\", \\\"{x:1608,y:492,t:1527613792377};\\\", \\\"{x:1607,y:490,t:1527613792401};\\\", \\\"{x:1607,y:489,t:1527613792441};\\\", \\\"{x:1607,y:487,t:1527613792457};\\\", \\\"{x:1607,y:485,t:1527613792474};\\\", \\\"{x:1607,y:484,t:1527613792491};\\\", \\\"{x:1607,y:483,t:1527613792507};\\\", \\\"{x:1607,y:482,t:1527613792524};\\\", \\\"{x:1607,y:481,t:1527613792541};\\\", \\\"{x:1607,y:480,t:1527613792558};\\\", \\\"{x:1607,y:479,t:1527613792575};\\\", \\\"{x:1607,y:478,t:1527613792591};\\\", \\\"{x:1607,y:477,t:1527613792607};\\\", \\\"{x:1607,y:475,t:1527613792624};\\\", \\\"{x:1607,y:473,t:1527613792641};\\\", \\\"{x:1607,y:472,t:1527613792664};\\\", \\\"{x:1607,y:471,t:1527613792674};\\\", \\\"{x:1607,y:470,t:1527613792692};\\\", \\\"{x:1607,y:469,t:1527613792727};\\\", \\\"{x:1607,y:468,t:1527613792741};\\\", \\\"{x:1607,y:467,t:1527613792758};\\\", \\\"{x:1607,y:466,t:1527613792784};\\\", \\\"{x:1607,y:465,t:1527613792800};\\\", \\\"{x:1607,y:463,t:1527613792807};\\\", \\\"{x:1608,y:463,t:1527613792824};\\\", \\\"{x:1608,y:462,t:1527613792841};\\\", \\\"{x:1608,y:461,t:1527613792872};\\\", \\\"{x:1608,y:460,t:1527613792888};\\\", \\\"{x:1608,y:459,t:1527613792904};\\\", \\\"{x:1608,y:458,t:1527613792913};\\\", \\\"{x:1608,y:457,t:1527613792924};\\\", \\\"{x:1608,y:454,t:1527613792941};\\\", \\\"{x:1608,y:453,t:1527613792957};\\\", \\\"{x:1608,y:452,t:1527613792975};\\\", \\\"{x:1609,y:451,t:1527613792991};\\\", \\\"{x:1609,y:448,t:1527613793008};\\\", \\\"{x:1609,y:447,t:1527613793031};\\\", \\\"{x:1611,y:444,t:1527613793040};\\\", \\\"{x:1612,y:443,t:1527613793064};\\\", \\\"{x:1612,y:442,t:1527613793080};\\\", \\\"{x:1612,y:441,t:1527613793091};\\\", \\\"{x:1612,y:440,t:1527613793112};\\\", \\\"{x:1612,y:439,t:1527613793128};\\\", \\\"{x:1613,y:439,t:1527613793141};\\\", \\\"{x:1613,y:438,t:1527613793158};\\\", \\\"{x:1613,y:437,t:1527613793175};\\\", \\\"{x:1614,y:435,t:1527613793191};\\\", \\\"{x:1615,y:434,t:1527613793232};\\\", \\\"{x:1615,y:433,t:1527613793321};\\\", \\\"{x:1616,y:432,t:1527613793336};\\\", \\\"{x:1616,y:431,t:1527613793488};\\\", \\\"{x:1616,y:430,t:1527613793521};\\\", \\\"{x:1616,y:429,t:1527613794040};\\\", \\\"{x:1610,y:429,t:1527613794504};\\\", \\\"{x:1601,y:429,t:1527613794513};\\\", \\\"{x:1593,y:429,t:1527613794526};\\\", \\\"{x:1576,y:429,t:1527613794542};\\\", \\\"{x:1545,y:430,t:1527613794559};\\\", \\\"{x:1517,y:433,t:1527613794576};\\\", \\\"{x:1472,y:439,t:1527613794592};\\\", \\\"{x:1407,y:449,t:1527613794610};\\\", \\\"{x:1323,y:462,t:1527613794626};\\\", \\\"{x:1251,y:471,t:1527613794643};\\\", \\\"{x:1173,y:475,t:1527613794659};\\\", \\\"{x:1109,y:482,t:1527613794676};\\\", \\\"{x:1051,y:490,t:1527613794693};\\\", \\\"{x:992,y:498,t:1527613794710};\\\", \\\"{x:927,y:510,t:1527613794727};\\\", \\\"{x:845,y:528,t:1527613794743};\\\", \\\"{x:728,y:552,t:1527613794759};\\\", \\\"{x:676,y:561,t:1527613794784};\\\", \\\"{x:638,y:572,t:1527613794799};\\\", \\\"{x:619,y:579,t:1527613794817};\\\", \\\"{x:599,y:588,t:1527613794833};\\\", \\\"{x:580,y:597,t:1527613794850};\\\", \\\"{x:561,y:608,t:1527613794866};\\\", \\\"{x:545,y:619,t:1527613794883};\\\", \\\"{x:540,y:622,t:1527613794900};\\\", \\\"{x:541,y:622,t:1527613795015};\\\", \\\"{x:548,y:619,t:1527613795024};\\\", \\\"{x:558,y:614,t:1527613795034};\\\", \\\"{x:579,y:604,t:1527613795050};\\\", \\\"{x:588,y:602,t:1527613795066};\\\", \\\"{x:594,y:599,t:1527613795082};\\\", \\\"{x:594,y:598,t:1527613795099};\\\", \\\"{x:596,y:598,t:1527613795451};\\\", \\\"{x:598,y:597,t:1527613795459};\\\", \\\"{x:599,y:595,t:1527613795471};\\\", \\\"{x:603,y:594,t:1527613795487};\\\", \\\"{x:607,y:591,t:1527613795503};\\\", \\\"{x:611,y:590,t:1527613795519};\\\", \\\"{x:612,y:588,t:1527613795536};\\\", \\\"{x:614,y:588,t:1527613795553};\\\", \\\"{x:614,y:586,t:1527613796028};\\\", \\\"{x:601,y:584,t:1527613796037};\\\", \\\"{x:572,y:584,t:1527613796054};\\\", \\\"{x:541,y:584,t:1527613796071};\\\", \\\"{x:519,y:584,t:1527613796087};\\\", \\\"{x:514,y:584,t:1527613796104};\\\", \\\"{x:513,y:584,t:1527613796195};\\\", \\\"{x:512,y:584,t:1527613796219};\\\", \\\"{x:511,y:584,t:1527613796235};\\\", \\\"{x:509,y:584,t:1527613796243};\\\", \\\"{x:506,y:584,t:1527613796255};\\\", \\\"{x:497,y:584,t:1527613796272};\\\", \\\"{x:483,y:582,t:1527613796287};\\\", \\\"{x:470,y:581,t:1527613796304};\\\", \\\"{x:453,y:579,t:1527613796320};\\\", \\\"{x:440,y:579,t:1527613796337};\\\", \\\"{x:426,y:579,t:1527613796353};\\\", \\\"{x:413,y:579,t:1527613796370};\\\", \\\"{x:410,y:579,t:1527613796387};\\\", \\\"{x:409,y:579,t:1527613796404};\\\", \\\"{x:405,y:579,t:1527613796421};\\\", \\\"{x:398,y:580,t:1527613796438};\\\", \\\"{x:385,y:580,t:1527613796454};\\\", \\\"{x:378,y:583,t:1527613796472};\\\", \\\"{x:375,y:583,t:1527613796488};\\\", \\\"{x:373,y:583,t:1527613796504};\\\", \\\"{x:372,y:584,t:1527613796521};\\\", \\\"{x:370,y:584,t:1527613796539};\\\", \\\"{x:369,y:584,t:1527613796555};\\\", \\\"{x:368,y:586,t:1527613796587};\\\", \\\"{x:366,y:587,t:1527613796605};\\\", \\\"{x:365,y:589,t:1527613796621};\\\", \\\"{x:365,y:592,t:1527613796638};\\\", \\\"{x:364,y:594,t:1527613796655};\\\", \\\"{x:364,y:595,t:1527613796692};\\\", \\\"{x:365,y:595,t:1527613796731};\\\", \\\"{x:366,y:595,t:1527613796739};\\\", \\\"{x:370,y:595,t:1527613796755};\\\", \\\"{x:375,y:594,t:1527613796772};\\\", \\\"{x:378,y:593,t:1527613796787};\\\", \\\"{x:381,y:592,t:1527613796805};\\\", \\\"{x:381,y:591,t:1527613796821};\\\", \\\"{x:382,y:591,t:1527613796838};\\\", \\\"{x:383,y:591,t:1527613796854};\\\", \\\"{x:384,y:591,t:1527613797054};\\\", \\\"{x:387,y:598,t:1527613797071};\\\", \\\"{x:389,y:611,t:1527613797089};\\\", \\\"{x:394,y:624,t:1527613797106};\\\", \\\"{x:400,y:646,t:1527613797121};\\\", \\\"{x:406,y:667,t:1527613797139};\\\", \\\"{x:421,y:695,t:1527613797155};\\\", \\\"{x:430,y:712,t:1527613797171};\\\", \\\"{x:442,y:731,t:1527613797188};\\\", \\\"{x:455,y:749,t:1527613797205};\\\", \\\"{x:462,y:755,t:1527613797221};\\\", \\\"{x:465,y:756,t:1527613797238};\\\", \\\"{x:466,y:756,t:1527613797255};\\\", \\\"{x:468,y:756,t:1527613797271};\\\", \\\"{x:472,y:753,t:1527613797288};\\\", \\\"{x:479,y:745,t:1527613797305};\\\", \\\"{x:487,y:735,t:1527613797323};\\\", \\\"{x:497,y:725,t:1527613797338};\\\", \\\"{x:506,y:714,t:1527613797354};\\\", \\\"{x:508,y:708,t:1527613797372};\\\", \\\"{x:511,y:704,t:1527613797389};\\\", \\\"{x:511,y:703,t:1527613797405};\\\", \\\"{x:512,y:703,t:1527613797442};\\\", \\\"{x:514,y:707,t:1527613798204};\\\", \\\"{x:514,y:709,t:1527613798212};\\\", \\\"{x:514,y:712,t:1527613798223};\\\", \\\"{x:514,y:715,t:1527613798239};\\\", \\\"{x:514,y:719,t:1527613798255};\\\", \\\"{x:513,y:723,t:1527613798272};\\\", \\\"{x:512,y:727,t:1527613798289};\\\", \\\"{x:509,y:729,t:1527613798306};\\\", \\\"{x:508,y:730,t:1527613798322};\\\", \\\"{x:507,y:730,t:1527613798715};\\\" ] }, { \\\"rt\\\": 57188, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 180931, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -X -X -8-9-10-12-12-11\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:508,y:730,t:1527613803740};\\\", \\\"{x:509,y:732,t:1527613803748};\\\", \\\"{x:515,y:736,t:1527613803765};\\\", \\\"{x:522,y:738,t:1527613803782};\\\", \\\"{x:527,y:740,t:1527613803799};\\\", \\\"{x:531,y:741,t:1527613803816};\\\", \\\"{x:532,y:741,t:1527613803832};\\\", \\\"{x:533,y:741,t:1527613803899};\\\", \\\"{x:534,y:741,t:1527613803915};\\\", \\\"{x:541,y:741,t:1527613803933};\\\", \\\"{x:551,y:741,t:1527613803949};\\\", \\\"{x:565,y:743,t:1527613803965};\\\", \\\"{x:581,y:747,t:1527613803982};\\\", \\\"{x:599,y:751,t:1527613803998};\\\", \\\"{x:621,y:754,t:1527613804010};\\\", \\\"{x:649,y:760,t:1527613804027};\\\", \\\"{x:686,y:767,t:1527613804043};\\\", \\\"{x:720,y:774,t:1527613804061};\\\", \\\"{x:753,y:779,t:1527613804077};\\\", \\\"{x:775,y:783,t:1527613804093};\\\", \\\"{x:800,y:789,t:1527613804110};\\\", \\\"{x:828,y:794,t:1527613804128};\\\", \\\"{x:872,y:798,t:1527613804143};\\\", \\\"{x:918,y:805,t:1527613804160};\\\", \\\"{x:965,y:813,t:1527613804178};\\\", \\\"{x:1012,y:815,t:1527613804194};\\\", \\\"{x:1079,y:823,t:1527613804211};\\\", \\\"{x:1134,y:827,t:1527613804227};\\\", \\\"{x:1192,y:834,t:1527613804244};\\\", \\\"{x:1254,y:842,t:1527613804261};\\\", \\\"{x:1301,y:848,t:1527613804278};\\\", \\\"{x:1333,y:849,t:1527613804293};\\\", \\\"{x:1352,y:849,t:1527613804310};\\\", \\\"{x:1372,y:849,t:1527613804328};\\\", \\\"{x:1395,y:850,t:1527613804344};\\\", \\\"{x:1420,y:853,t:1527613804361};\\\", \\\"{x:1437,y:853,t:1527613804377};\\\", \\\"{x:1451,y:853,t:1527613804395};\\\", \\\"{x:1454,y:853,t:1527613804411};\\\", \\\"{x:1464,y:849,t:1527613804428};\\\", \\\"{x:1477,y:849,t:1527613804445};\\\", \\\"{x:1484,y:849,t:1527613804461};\\\", \\\"{x:1499,y:848,t:1527613804477};\\\", \\\"{x:1505,y:848,t:1527613804495};\\\", \\\"{x:1513,y:848,t:1527613804510};\\\", \\\"{x:1515,y:847,t:1527613804527};\\\", \\\"{x:1516,y:847,t:1527613804545};\\\", \\\"{x:1517,y:846,t:1527613804561};\\\", \\\"{x:1519,y:844,t:1527613804578};\\\", \\\"{x:1524,y:844,t:1527613804595};\\\", \\\"{x:1526,y:844,t:1527613804612};\\\", \\\"{x:1527,y:842,t:1527613804628};\\\", \\\"{x:1528,y:842,t:1527613804668};\\\", \\\"{x:1529,y:842,t:1527613804707};\\\", \\\"{x:1530,y:841,t:1527613804715};\\\", \\\"{x:1531,y:841,t:1527613804728};\\\", \\\"{x:1536,y:838,t:1527613804745};\\\", \\\"{x:1537,y:837,t:1527613804763};\\\", \\\"{x:1539,y:836,t:1527613804778};\\\", \\\"{x:1542,y:835,t:1527613804796};\\\", \\\"{x:1543,y:834,t:1527613804820};\\\", \\\"{x:1531,y:821,t:1527613805692};\\\", \\\"{x:1515,y:805,t:1527613805700};\\\", \\\"{x:1502,y:794,t:1527613805713};\\\", \\\"{x:1473,y:765,t:1527613805728};\\\", \\\"{x:1450,y:744,t:1527613805745};\\\", \\\"{x:1432,y:723,t:1527613805762};\\\", \\\"{x:1402,y:685,t:1527613805778};\\\", \\\"{x:1386,y:664,t:1527613805795};\\\", \\\"{x:1370,y:645,t:1527613805811};\\\", \\\"{x:1356,y:628,t:1527613805829};\\\", \\\"{x:1346,y:612,t:1527613805846};\\\", \\\"{x:1335,y:592,t:1527613805861};\\\", \\\"{x:1326,y:575,t:1527613805878};\\\", \\\"{x:1311,y:553,t:1527613805896};\\\", \\\"{x:1302,y:540,t:1527613805912};\\\", \\\"{x:1296,y:532,t:1527613805929};\\\", \\\"{x:1295,y:529,t:1527613805947};\\\", \\\"{x:1295,y:527,t:1527613805971};\\\", \\\"{x:1297,y:526,t:1527613805980};\\\", \\\"{x:1300,y:524,t:1527613805996};\\\", \\\"{x:1302,y:524,t:1527613806012};\\\", \\\"{x:1306,y:522,t:1527613806028};\\\", \\\"{x:1309,y:520,t:1527613806045};\\\", \\\"{x:1313,y:517,t:1527613806062};\\\", \\\"{x:1315,y:514,t:1527613806078};\\\", \\\"{x:1317,y:513,t:1527613806095};\\\", \\\"{x:1319,y:512,t:1527613806114};\\\", \\\"{x:1320,y:511,t:1527613806131};\\\", \\\"{x:1321,y:511,t:1527613806146};\\\", \\\"{x:1322,y:510,t:1527613806163};\\\", \\\"{x:1323,y:509,t:1527613806187};\\\", \\\"{x:1323,y:508,t:1527613806219};\\\", \\\"{x:1324,y:508,t:1527613806243};\\\", \\\"{x:1324,y:506,t:1527613806275};\\\", \\\"{x:1324,y:505,t:1527613806299};\\\", \\\"{x:1323,y:504,t:1527613806315};\\\", \\\"{x:1322,y:504,t:1527613806347};\\\", \\\"{x:1321,y:503,t:1527613806363};\\\", \\\"{x:1320,y:502,t:1527613806395};\\\", \\\"{x:1319,y:502,t:1527613806413};\\\", \\\"{x:1318,y:501,t:1527613806432};\\\", \\\"{x:1317,y:500,t:1527613806446};\\\", \\\"{x:1317,y:499,t:1527613806463};\\\", \\\"{x:1316,y:499,t:1527613806478};\\\", \\\"{x:1315,y:499,t:1527613806498};\\\", \\\"{x:1315,y:498,t:1527613806635};\\\", \\\"{x:1314,y:498,t:1527613807452};\\\", \\\"{x:1313,y:498,t:1527613808580};\\\", \\\"{x:1312,y:498,t:1527613810060};\\\", \\\"{x:1311,y:498,t:1527613810132};\\\", \\\"{x:1310,y:498,t:1527613810163};\\\", \\\"{x:1309,y:498,t:1527613810315};\\\", \\\"{x:1308,y:498,t:1527613810349};\\\", \\\"{x:1308,y:499,t:1527613815876};\\\", \\\"{x:1301,y:502,t:1527613820780};\\\", \\\"{x:1278,y:513,t:1527613820791};\\\", \\\"{x:1167,y:563,t:1527613820807};\\\", \\\"{x:1015,y:612,t:1527613820825};\\\", \\\"{x:833,y:660,t:1527613820841};\\\", \\\"{x:673,y:700,t:1527613820858};\\\", \\\"{x:493,y:752,t:1527613820876};\\\", \\\"{x:451,y:765,t:1527613820891};\\\", \\\"{x:400,y:790,t:1527613820908};\\\", \\\"{x:388,y:796,t:1527613820924};\\\", \\\"{x:386,y:800,t:1527613820941};\\\", \\\"{x:384,y:801,t:1527613820958};\\\", \\\"{x:384,y:802,t:1527613820975};\\\", \\\"{x:383,y:802,t:1527613820990};\\\", \\\"{x:376,y:802,t:1527613821007};\\\", \\\"{x:375,y:802,t:1527613821025};\\\", \\\"{x:375,y:801,t:1527613821067};\\\", \\\"{x:375,y:798,t:1527613821075};\\\", \\\"{x:385,y:789,t:1527613821091};\\\", \\\"{x:402,y:781,t:1527613821107};\\\", \\\"{x:427,y:771,t:1527613821125};\\\", \\\"{x:455,y:764,t:1527613821141};\\\", \\\"{x:471,y:757,t:1527613821158};\\\", \\\"{x:480,y:754,t:1527613821175};\\\", \\\"{x:488,y:750,t:1527613821191};\\\", \\\"{x:495,y:748,t:1527613821209};\\\", \\\"{x:501,y:745,t:1527613821224};\\\", \\\"{x:515,y:739,t:1527613821241};\\\", \\\"{x:528,y:735,t:1527613821257};\\\", \\\"{x:547,y:729,t:1527613821274};\\\", \\\"{x:556,y:726,t:1527613821290};\\\", \\\"{x:560,y:725,t:1527613821307};\\\", \\\"{x:561,y:725,t:1527613821324};\\\", \\\"{x:562,y:724,t:1527613821396};\\\", \\\"{x:562,y:723,t:1527613821484};\\\", \\\"{x:570,y:721,t:1527613821669};\\\", \\\"{x:581,y:721,t:1527613821675};\\\", \\\"{x:604,y:721,t:1527613821691};\\\", \\\"{x:632,y:721,t:1527613821708};\\\", \\\"{x:661,y:721,t:1527613821724};\\\", \\\"{x:702,y:721,t:1527613821741};\\\", \\\"{x:739,y:721,t:1527613821758};\\\", \\\"{x:770,y:721,t:1527613821774};\\\", \\\"{x:800,y:721,t:1527613821791};\\\", \\\"{x:825,y:721,t:1527613821808};\\\", \\\"{x:840,y:721,t:1527613821824};\\\", \\\"{x:849,y:721,t:1527613821841};\\\", \\\"{x:850,y:721,t:1527613821859};\\\", \\\"{x:851,y:721,t:1527613821874};\\\", \\\"{x:853,y:719,t:1527613822323};\\\", \\\"{x:856,y:717,t:1527613823564};\\\", \\\"{x:863,y:713,t:1527613823577};\\\", \\\"{x:877,y:704,t:1527613823593};\\\", \\\"{x:902,y:691,t:1527613823609};\\\", \\\"{x:949,y:672,t:1527613823627};\\\", \\\"{x:988,y:657,t:1527613823644};\\\", \\\"{x:1033,y:637,t:1527613823660};\\\", \\\"{x:1090,y:613,t:1527613823677};\\\", \\\"{x:1133,y:592,t:1527613823693};\\\", \\\"{x:1182,y:562,t:1527613823709};\\\", \\\"{x:1211,y:547,t:1527613823727};\\\", \\\"{x:1230,y:538,t:1527613823743};\\\", \\\"{x:1251,y:530,t:1527613823760};\\\", \\\"{x:1268,y:525,t:1527613823777};\\\", \\\"{x:1275,y:523,t:1527613823794};\\\", \\\"{x:1279,y:522,t:1527613823809};\\\", \\\"{x:1281,y:521,t:1527613823827};\\\", \\\"{x:1283,y:520,t:1527613823844};\\\", \\\"{x:1285,y:518,t:1527613823859};\\\", \\\"{x:1288,y:515,t:1527613823876};\\\", \\\"{x:1289,y:513,t:1527613823894};\\\", \\\"{x:1290,y:512,t:1527613823910};\\\", \\\"{x:1291,y:511,t:1527613823972};\\\", \\\"{x:1292,y:510,t:1527613823979};\\\", \\\"{x:1293,y:508,t:1527613823994};\\\", \\\"{x:1295,y:507,t:1527613824010};\\\", \\\"{x:1300,y:502,t:1527613824027};\\\", \\\"{x:1303,y:501,t:1527613824043};\\\", \\\"{x:1307,y:498,t:1527613824060};\\\", \\\"{x:1308,y:498,t:1527613824076};\\\", \\\"{x:1310,y:497,t:1527613824095};\\\", \\\"{x:1310,y:496,t:1527613824187};\\\", \\\"{x:1311,y:496,t:1527613836836};\\\", \\\"{x:1314,y:491,t:1527613836844};\\\", \\\"{x:1317,y:486,t:1527613836855};\\\", \\\"{x:1318,y:485,t:1527613836870};\\\", \\\"{x:1322,y:481,t:1527613836887};\\\", \\\"{x:1323,y:479,t:1527613836904};\\\", \\\"{x:1325,y:477,t:1527613836921};\\\", \\\"{x:1326,y:475,t:1527613836937};\\\", \\\"{x:1328,y:473,t:1527613836953};\\\", \\\"{x:1329,y:471,t:1527613836970};\\\", \\\"{x:1331,y:468,t:1527613836987};\\\", \\\"{x:1332,y:466,t:1527613837004};\\\", \\\"{x:1333,y:464,t:1527613837020};\\\", \\\"{x:1335,y:463,t:1527613837037};\\\", \\\"{x:1335,y:462,t:1527613837055};\\\", \\\"{x:1337,y:460,t:1527613837071};\\\", \\\"{x:1338,y:458,t:1527613837088};\\\", \\\"{x:1339,y:457,t:1527613837104};\\\", \\\"{x:1341,y:454,t:1527613837120};\\\", \\\"{x:1342,y:451,t:1527613837137};\\\", \\\"{x:1345,y:448,t:1527613837155};\\\", \\\"{x:1345,y:444,t:1527613837171};\\\", \\\"{x:1348,y:440,t:1527613837187};\\\", \\\"{x:1349,y:436,t:1527613837205};\\\", \\\"{x:1350,y:435,t:1527613837221};\\\", \\\"{x:1352,y:431,t:1527613837238};\\\", \\\"{x:1352,y:428,t:1527613837254};\\\", \\\"{x:1355,y:424,t:1527613837271};\\\", \\\"{x:1355,y:422,t:1527613837288};\\\", \\\"{x:1355,y:420,t:1527613837305};\\\", \\\"{x:1355,y:419,t:1527613837321};\\\", \\\"{x:1356,y:417,t:1527613837338};\\\", \\\"{x:1356,y:416,t:1527613837355};\\\", \\\"{x:1358,y:415,t:1527613837371};\\\", \\\"{x:1359,y:412,t:1527613837388};\\\", \\\"{x:1359,y:409,t:1527613837404};\\\", \\\"{x:1361,y:405,t:1527613837420};\\\", \\\"{x:1363,y:403,t:1527613837437};\\\", \\\"{x:1365,y:399,t:1527613837454};\\\", \\\"{x:1367,y:397,t:1527613837471};\\\", \\\"{x:1369,y:393,t:1527613837488};\\\", \\\"{x:1370,y:391,t:1527613837505};\\\", \\\"{x:1372,y:388,t:1527613837520};\\\", \\\"{x:1373,y:385,t:1527613837537};\\\", \\\"{x:1374,y:382,t:1527613837555};\\\", \\\"{x:1376,y:377,t:1527613837572};\\\", \\\"{x:1377,y:376,t:1527613837588};\\\", \\\"{x:1379,y:373,t:1527613837605};\\\", \\\"{x:1380,y:371,t:1527613837622};\\\", \\\"{x:1380,y:369,t:1527613837638};\\\", \\\"{x:1383,y:366,t:1527613837655};\\\", \\\"{x:1383,y:363,t:1527613837672};\\\", \\\"{x:1387,y:358,t:1527613837688};\\\", \\\"{x:1388,y:356,t:1527613837704};\\\", \\\"{x:1390,y:352,t:1527613837721};\\\", \\\"{x:1391,y:350,t:1527613837738};\\\", \\\"{x:1394,y:346,t:1527613837755};\\\", \\\"{x:1397,y:343,t:1527613837772};\\\", \\\"{x:1397,y:340,t:1527613837788};\\\", \\\"{x:1399,y:336,t:1527613837804};\\\", \\\"{x:1401,y:332,t:1527613837822};\\\", \\\"{x:1403,y:329,t:1527613837838};\\\", \\\"{x:1408,y:323,t:1527613837854};\\\", \\\"{x:1410,y:319,t:1527613837872};\\\", \\\"{x:1412,y:316,t:1527613837889};\\\", \\\"{x:1414,y:314,t:1527613837905};\\\", \\\"{x:1414,y:310,t:1527613837921};\\\", \\\"{x:1416,y:309,t:1527613837938};\\\", \\\"{x:1417,y:304,t:1527613837955};\\\", \\\"{x:1421,y:300,t:1527613837971};\\\", \\\"{x:1423,y:295,t:1527613837989};\\\", \\\"{x:1425,y:291,t:1527613838005};\\\", \\\"{x:1426,y:287,t:1527613838022};\\\", \\\"{x:1427,y:285,t:1527613838038};\\\", \\\"{x:1429,y:284,t:1527613838054};\\\", \\\"{x:1431,y:281,t:1527613838072};\\\", \\\"{x:1432,y:278,t:1527613838088};\\\", \\\"{x:1434,y:275,t:1527613838105};\\\", \\\"{x:1437,y:271,t:1527613838122};\\\", \\\"{x:1439,y:268,t:1527613838139};\\\", \\\"{x:1441,y:262,t:1527613838155};\\\", \\\"{x:1442,y:260,t:1527613838171};\\\", \\\"{x:1443,y:256,t:1527613838188};\\\", \\\"{x:1445,y:252,t:1527613838204};\\\", \\\"{x:1446,y:249,t:1527613838221};\\\", \\\"{x:1447,y:248,t:1527613838238};\\\", \\\"{x:1448,y:245,t:1527613838254};\\\", \\\"{x:1449,y:242,t:1527613838271};\\\", \\\"{x:1449,y:239,t:1527613838288};\\\", \\\"{x:1450,y:237,t:1527613838305};\\\", \\\"{x:1452,y:234,t:1527613838321};\\\", \\\"{x:1452,y:232,t:1527613838338};\\\", \\\"{x:1453,y:230,t:1527613838355};\\\", \\\"{x:1454,y:227,t:1527613838371};\\\", \\\"{x:1455,y:226,t:1527613838389};\\\", \\\"{x:1456,y:224,t:1527613838405};\\\", \\\"{x:1456,y:223,t:1527613838421};\\\", \\\"{x:1458,y:219,t:1527613838439};\\\", \\\"{x:1459,y:217,t:1527613838456};\\\", \\\"{x:1460,y:214,t:1527613838471};\\\", \\\"{x:1462,y:210,t:1527613838488};\\\", \\\"{x:1463,y:205,t:1527613838505};\\\", \\\"{x:1463,y:203,t:1527613838521};\\\", \\\"{x:1466,y:198,t:1527613838538};\\\", \\\"{x:1467,y:194,t:1527613838554};\\\", \\\"{x:1469,y:191,t:1527613838571};\\\", \\\"{x:1470,y:187,t:1527613838588};\\\", \\\"{x:1471,y:186,t:1527613838605};\\\", \\\"{x:1472,y:184,t:1527613838622};\\\", \\\"{x:1473,y:183,t:1527613838638};\\\", \\\"{x:1473,y:181,t:1527613838655};\\\", \\\"{x:1474,y:179,t:1527613838671};\\\", \\\"{x:1475,y:178,t:1527613838688};\\\", \\\"{x:1475,y:177,t:1527613838705};\\\", \\\"{x:1476,y:174,t:1527613838721};\\\", \\\"{x:1477,y:174,t:1527613838739};\\\", \\\"{x:1477,y:172,t:1527613838756};\\\", \\\"{x:1478,y:171,t:1527613838771};\\\", \\\"{x:1479,y:169,t:1527613838803};\\\", \\\"{x:1480,y:168,t:1527613838811};\\\", \\\"{x:1480,y:165,t:1527613838838};\\\", \\\"{x:1481,y:164,t:1527613838855};\\\", \\\"{x:1482,y:163,t:1527613838873};\\\", \\\"{x:1482,y:161,t:1527613838889};\\\", \\\"{x:1483,y:160,t:1527613838907};\\\", \\\"{x:1483,y:159,t:1527613838931};\\\", \\\"{x:1484,y:158,t:1527613838947};\\\", \\\"{x:1485,y:157,t:1527613839100};\\\", \\\"{x:1486,y:155,t:1527613839564};\\\", \\\"{x:1485,y:155,t:1527613841988};\\\", \\\"{x:1478,y:156,t:1527613841996};\\\", \\\"{x:1470,y:162,t:1527613842008};\\\", \\\"{x:1450,y:184,t:1527613842025};\\\", \\\"{x:1421,y:213,t:1527613842042};\\\", \\\"{x:1378,y:257,t:1527613842058};\\\", \\\"{x:1296,y:354,t:1527613842076};\\\", \\\"{x:1225,y:439,t:1527613842092};\\\", \\\"{x:1184,y:488,t:1527613842107};\\\", \\\"{x:1164,y:513,t:1527613842125};\\\", \\\"{x:1157,y:521,t:1527613842142};\\\", \\\"{x:1156,y:523,t:1527613842158};\\\", \\\"{x:1156,y:524,t:1527613842174};\\\", \\\"{x:1156,y:525,t:1527613842251};\\\", \\\"{x:1157,y:526,t:1527613842267};\\\", \\\"{x:1159,y:527,t:1527613842275};\\\", \\\"{x:1161,y:527,t:1527613842291};\\\", \\\"{x:1163,y:527,t:1527613842308};\\\", \\\"{x:1168,y:527,t:1527613842325};\\\", \\\"{x:1181,y:527,t:1527613842342};\\\", \\\"{x:1193,y:521,t:1527613842358};\\\", \\\"{x:1208,y:515,t:1527613842374};\\\", \\\"{x:1221,y:509,t:1527613842392};\\\", \\\"{x:1233,y:504,t:1527613842409};\\\", \\\"{x:1242,y:501,t:1527613842424};\\\", \\\"{x:1250,y:499,t:1527613842442};\\\", \\\"{x:1257,y:496,t:1527613842459};\\\", \\\"{x:1259,y:495,t:1527613842475};\\\", \\\"{x:1264,y:492,t:1527613842492};\\\", \\\"{x:1268,y:492,t:1527613842509};\\\", \\\"{x:1272,y:491,t:1527613842525};\\\", \\\"{x:1275,y:491,t:1527613842542};\\\", \\\"{x:1276,y:490,t:1527613842559};\\\", \\\"{x:1276,y:489,t:1527613842708};\\\", \\\"{x:1275,y:488,t:1527613842739};\\\", \\\"{x:1273,y:488,t:1527613842787};\\\", \\\"{x:1272,y:488,t:1527613842811};\\\", \\\"{x:1271,y:488,t:1527613842826};\\\", \\\"{x:1268,y:488,t:1527613842842};\\\", \\\"{x:1256,y:488,t:1527613842859};\\\", \\\"{x:1247,y:490,t:1527613842875};\\\", \\\"{x:1240,y:496,t:1527613842892};\\\", \\\"{x:1228,y:503,t:1527613842909};\\\", \\\"{x:1213,y:510,t:1527613842925};\\\", \\\"{x:1200,y:515,t:1527613842942};\\\", \\\"{x:1183,y:523,t:1527613842959};\\\", \\\"{x:1167,y:525,t:1527613842975};\\\", \\\"{x:1148,y:527,t:1527613842992};\\\", \\\"{x:1135,y:528,t:1527613843008};\\\", \\\"{x:1126,y:528,t:1527613843026};\\\", \\\"{x:1117,y:528,t:1527613843042};\\\", \\\"{x:1099,y:528,t:1527613843059};\\\", \\\"{x:1080,y:527,t:1527613843075};\\\", \\\"{x:1063,y:525,t:1527613843092};\\\", \\\"{x:1055,y:523,t:1527613843108};\\\", \\\"{x:1048,y:521,t:1527613843126};\\\", \\\"{x:1045,y:521,t:1527613843142};\\\", \\\"{x:1042,y:521,t:1527613843158};\\\", \\\"{x:1040,y:519,t:1527613843176};\\\", \\\"{x:1037,y:517,t:1527613843192};\\\", \\\"{x:1035,y:517,t:1527613843208};\\\", \\\"{x:1035,y:516,t:1527613843226};\\\", \\\"{x:1035,y:514,t:1527613843267};\\\", \\\"{x:1036,y:511,t:1527613843283};\\\", \\\"{x:1037,y:510,t:1527613843293};\\\", \\\"{x:1039,y:507,t:1527613843309};\\\", \\\"{x:1042,y:503,t:1527613843326};\\\", \\\"{x:1043,y:502,t:1527613843343};\\\", \\\"{x:1044,y:501,t:1527613843359};\\\", \\\"{x:1045,y:501,t:1527613843376};\\\", \\\"{x:1046,y:500,t:1527613843393};\\\", \\\"{x:1048,y:500,t:1527613843409};\\\", \\\"{x:1049,y:500,t:1527613843426};\\\", \\\"{x:1051,y:499,t:1527613843443};\\\", \\\"{x:1052,y:498,t:1527613843459};\\\", \\\"{x:1053,y:497,t:1527613843476};\\\", \\\"{x:1054,y:497,t:1527613843523};\\\", \\\"{x:1055,y:496,t:1527613844764};\\\", \\\"{x:1055,y:495,t:1527613844795};\\\", \\\"{x:1055,y:494,t:1527613844883};\\\", \\\"{x:1055,y:493,t:1527613844915};\\\", \\\"{x:1055,y:492,t:1527613844939};\\\", \\\"{x:1055,y:491,t:1527613844955};\\\", \\\"{x:1055,y:489,t:1527613844963};\\\", \\\"{x:1055,y:488,t:1527613844978};\\\", \\\"{x:1054,y:486,t:1527613844993};\\\", \\\"{x:1054,y:485,t:1527613845010};\\\", \\\"{x:1054,y:483,t:1527613845026};\\\", \\\"{x:1054,y:481,t:1527613845043};\\\", \\\"{x:1053,y:479,t:1527613845060};\\\", \\\"{x:1053,y:476,t:1527613845076};\\\", \\\"{x:1053,y:475,t:1527613845093};\\\", \\\"{x:1053,y:473,t:1527613845110};\\\", \\\"{x:1053,y:470,t:1527613845127};\\\", \\\"{x:1053,y:469,t:1527613845143};\\\", \\\"{x:1053,y:466,t:1527613845160};\\\", \\\"{x:1053,y:462,t:1527613845176};\\\", \\\"{x:1053,y:456,t:1527613845194};\\\", \\\"{x:1053,y:451,t:1527613845211};\\\", \\\"{x:1054,y:450,t:1527613845227};\\\", \\\"{x:1055,y:449,t:1527613845244};\\\", \\\"{x:1055,y:446,t:1527613845261};\\\", \\\"{x:1055,y:445,t:1527613845277};\\\", \\\"{x:1056,y:443,t:1527613845293};\\\", \\\"{x:1056,y:442,t:1527613845310};\\\", \\\"{x:1057,y:439,t:1527613845327};\\\", \\\"{x:1058,y:437,t:1527613845344};\\\", \\\"{x:1058,y:436,t:1527613845361};\\\", \\\"{x:1059,y:435,t:1527613845467};\\\", \\\"{x:1059,y:434,t:1527613845531};\\\", \\\"{x:1059,y:432,t:1527613845544};\\\", \\\"{x:1059,y:430,t:1527613845561};\\\", \\\"{x:1059,y:425,t:1527613845577};\\\", \\\"{x:1059,y:413,t:1527613845595};\\\", \\\"{x:1059,y:399,t:1527613845611};\\\", \\\"{x:1059,y:392,t:1527613845627};\\\", \\\"{x:1059,y:388,t:1527613845644};\\\", \\\"{x:1059,y:385,t:1527613845661};\\\", \\\"{x:1059,y:384,t:1527613845678};\\\", \\\"{x:1059,y:382,t:1527613845699};\\\", \\\"{x:1059,y:381,t:1527613845780};\\\", \\\"{x:1059,y:378,t:1527613845795};\\\", \\\"{x:1059,y:376,t:1527613845811};\\\", \\\"{x:1059,y:372,t:1527613845827};\\\", \\\"{x:1059,y:370,t:1527613845845};\\\", \\\"{x:1059,y:368,t:1527613845860};\\\", \\\"{x:1059,y:365,t:1527613845878};\\\", \\\"{x:1059,y:364,t:1527613845895};\\\", \\\"{x:1059,y:362,t:1527613845911};\\\", \\\"{x:1059,y:359,t:1527613845927};\\\", \\\"{x:1059,y:358,t:1527613845947};\\\", \\\"{x:1059,y:357,t:1527613846011};\\\", \\\"{x:1058,y:355,t:1527613846027};\\\", \\\"{x:1058,y:351,t:1527613846046};\\\", \\\"{x:1056,y:341,t:1527613846061};\\\", \\\"{x:1053,y:323,t:1527613846077};\\\", \\\"{x:1052,y:308,t:1527613846095};\\\", \\\"{x:1049,y:295,t:1527613846111};\\\", \\\"{x:1047,y:287,t:1527613846129};\\\", \\\"{x:1046,y:284,t:1527613846145};\\\", \\\"{x:1045,y:281,t:1527613846161};\\\", \\\"{x:1044,y:280,t:1527613846178};\\\", \\\"{x:1044,y:278,t:1527613846194};\\\", \\\"{x:1044,y:277,t:1527613846331};\\\", \\\"{x:1045,y:277,t:1527613846363};\\\", \\\"{x:1045,y:276,t:1527613846396};\\\", \\\"{x:1047,y:275,t:1527613846412};\\\", \\\"{x:1049,y:272,t:1527613846428};\\\", \\\"{x:1052,y:266,t:1527613846445};\\\", \\\"{x:1055,y:259,t:1527613846462};\\\", \\\"{x:1057,y:254,t:1527613846478};\\\", \\\"{x:1059,y:249,t:1527613846495};\\\", \\\"{x:1060,y:244,t:1527613846512};\\\", \\\"{x:1063,y:238,t:1527613846528};\\\", \\\"{x:1064,y:236,t:1527613846545};\\\", \\\"{x:1065,y:233,t:1527613846563};\\\", \\\"{x:1065,y:232,t:1527613846578};\\\", \\\"{x:1065,y:230,t:1527613846595};\\\", \\\"{x:1065,y:229,t:1527613846612};\\\", \\\"{x:1065,y:228,t:1527613846651};\\\", \\\"{x:1065,y:227,t:1527613846675};\\\", \\\"{x:1065,y:226,t:1527613846683};\\\", \\\"{x:1065,y:225,t:1527613846695};\\\", \\\"{x:1065,y:220,t:1527613846712};\\\", \\\"{x:1065,y:212,t:1527613846728};\\\", \\\"{x:1064,y:203,t:1527613846745};\\\", \\\"{x:1058,y:178,t:1527613846763};\\\", \\\"{x:1056,y:163,t:1527613846779};\\\", \\\"{x:1051,y:144,t:1527613846796};\\\", \\\"{x:1046,y:134,t:1527613846812};\\\", \\\"{x:1044,y:128,t:1527613846829};\\\", \\\"{x:1044,y:126,t:1527613846845};\\\", \\\"{x:1044,y:124,t:1527613846862};\\\", \\\"{x:1045,y:123,t:1527613846987};\\\", \\\"{x:1047,y:123,t:1527613847003};\\\", \\\"{x:1049,y:123,t:1527613847018};\\\", \\\"{x:1049,y:124,t:1527613847029};\\\", \\\"{x:1052,y:126,t:1527613847045};\\\", \\\"{x:1053,y:136,t:1527613847061};\\\", \\\"{x:1058,y:159,t:1527613847080};\\\", \\\"{x:1059,y:189,t:1527613847095};\\\", \\\"{x:1060,y:223,t:1527613847112};\\\", \\\"{x:1060,y:255,t:1527613847129};\\\", \\\"{x:1061,y:276,t:1527613847145};\\\", \\\"{x:1066,y:311,t:1527613847163};\\\", \\\"{x:1066,y:336,t:1527613847179};\\\", \\\"{x:1067,y:355,t:1527613847196};\\\", \\\"{x:1067,y:374,t:1527613847212};\\\", \\\"{x:1069,y:391,t:1527613847229};\\\", \\\"{x:1071,y:407,t:1527613847246};\\\", \\\"{x:1072,y:425,t:1527613847262};\\\", \\\"{x:1074,y:437,t:1527613847279};\\\", \\\"{x:1074,y:444,t:1527613847296};\\\", \\\"{x:1075,y:453,t:1527613847312};\\\", \\\"{x:1075,y:457,t:1527613847329};\\\", \\\"{x:1075,y:461,t:1527613847346};\\\", \\\"{x:1075,y:469,t:1527613847363};\\\", \\\"{x:1074,y:476,t:1527613847379};\\\", \\\"{x:1071,y:486,t:1527613847396};\\\", \\\"{x:1069,y:494,t:1527613847412};\\\", \\\"{x:1068,y:498,t:1527613847428};\\\", \\\"{x:1068,y:501,t:1527613847446};\\\", \\\"{x:1067,y:504,t:1527613847462};\\\", \\\"{x:1066,y:506,t:1527613847479};\\\", \\\"{x:1066,y:507,t:1527613847496};\\\", \\\"{x:1066,y:505,t:1527613847843};\\\", \\\"{x:1066,y:503,t:1527613847851};\\\", \\\"{x:1067,y:501,t:1527613847863};\\\", \\\"{x:1069,y:495,t:1527613847880};\\\", \\\"{x:1070,y:493,t:1527613847896};\\\", \\\"{x:1070,y:488,t:1527613847913};\\\", \\\"{x:1071,y:476,t:1527613847929};\\\", \\\"{x:1074,y:468,t:1527613847946};\\\", \\\"{x:1076,y:461,t:1527613847963};\\\", \\\"{x:1078,y:455,t:1527613847979};\\\", \\\"{x:1080,y:448,t:1527613847996};\\\", \\\"{x:1081,y:445,t:1527613848014};\\\", \\\"{x:1081,y:443,t:1527613848030};\\\", \\\"{x:1083,y:441,t:1527613848046};\\\", \\\"{x:1085,y:437,t:1527613848063};\\\", \\\"{x:1085,y:435,t:1527613848079};\\\", \\\"{x:1086,y:433,t:1527613848096};\\\", \\\"{x:1086,y:432,t:1527613848113};\\\", \\\"{x:1086,y:429,t:1527613848130};\\\", \\\"{x:1086,y:427,t:1527613848146};\\\", \\\"{x:1086,y:425,t:1527613848163};\\\", \\\"{x:1086,y:424,t:1527613848179};\\\", \\\"{x:1086,y:423,t:1527613848211};\\\", \\\"{x:1085,y:422,t:1527613848219};\\\", \\\"{x:1085,y:421,t:1527613848235};\\\", \\\"{x:1083,y:420,t:1527613848246};\\\", \\\"{x:1080,y:414,t:1527613848263};\\\", \\\"{x:1077,y:408,t:1527613848280};\\\", \\\"{x:1072,y:398,t:1527613848296};\\\", \\\"{x:1068,y:385,t:1527613848313};\\\", \\\"{x:1066,y:374,t:1527613848330};\\\", \\\"{x:1064,y:368,t:1527613848346};\\\", \\\"{x:1064,y:367,t:1527613848363};\\\", \\\"{x:1064,y:365,t:1527613848380};\\\", \\\"{x:1064,y:364,t:1527613848403};\\\", \\\"{x:1064,y:362,t:1527613848436};\\\", \\\"{x:1064,y:361,t:1527613848467};\\\", \\\"{x:1064,y:360,t:1527613848480};\\\", \\\"{x:1065,y:359,t:1527613848497};\\\", \\\"{x:1066,y:358,t:1527613848515};\\\", \\\"{x:1067,y:357,t:1527613848628};\\\", \\\"{x:1068,y:356,t:1527613848635};\\\", \\\"{x:1068,y:355,t:1527613848647};\\\", \\\"{x:1070,y:351,t:1527613848664};\\\", \\\"{x:1072,y:346,t:1527613848680};\\\", \\\"{x:1075,y:340,t:1527613848698};\\\", \\\"{x:1076,y:336,t:1527613848714};\\\", \\\"{x:1076,y:334,t:1527613848730};\\\", \\\"{x:1076,y:331,t:1527613848747};\\\", \\\"{x:1076,y:330,t:1527613848763};\\\", \\\"{x:1076,y:329,t:1527613848780};\\\", \\\"{x:1076,y:328,t:1527613848851};\\\", \\\"{x:1076,y:326,t:1527613848931};\\\", \\\"{x:1077,y:325,t:1527613848947};\\\", \\\"{x:1077,y:324,t:1527613848970};\\\", \\\"{x:1077,y:323,t:1527613848980};\\\", \\\"{x:1077,y:321,t:1527613848996};\\\", \\\"{x:1077,y:320,t:1527613849013};\\\", \\\"{x:1077,y:319,t:1527613849074};\\\", \\\"{x:1076,y:319,t:1527613852964};\\\", \\\"{x:1071,y:326,t:1527613852971};\\\", \\\"{x:1066,y:333,t:1527613852983};\\\", \\\"{x:1046,y:353,t:1527613853000};\\\", \\\"{x:1027,y:372,t:1527613853017};\\\", \\\"{x:1007,y:387,t:1527613853034};\\\", \\\"{x:987,y:403,t:1527613853051};\\\", \\\"{x:965,y:421,t:1527613853066};\\\", \\\"{x:922,y:458,t:1527613853084};\\\", \\\"{x:907,y:472,t:1527613853100};\\\", \\\"{x:885,y:489,t:1527613853117};\\\", \\\"{x:869,y:504,t:1527613853134};\\\", \\\"{x:856,y:514,t:1527613853151};\\\", \\\"{x:843,y:525,t:1527613853169};\\\", \\\"{x:835,y:535,t:1527613853183};\\\", \\\"{x:825,y:547,t:1527613853200};\\\", \\\"{x:818,y:559,t:1527613853216};\\\", \\\"{x:811,y:570,t:1527613853232};\\\", \\\"{x:807,y:578,t:1527613853250};\\\", \\\"{x:801,y:592,t:1527613853266};\\\", \\\"{x:798,y:600,t:1527613853284};\\\", \\\"{x:794,y:610,t:1527613853299};\\\", \\\"{x:793,y:625,t:1527613853316};\\\", \\\"{x:792,y:642,t:1527613853334};\\\", \\\"{x:789,y:658,t:1527613853351};\\\", \\\"{x:789,y:667,t:1527613853366};\\\", \\\"{x:789,y:673,t:1527613853383};\\\", \\\"{x:788,y:679,t:1527613853400};\\\", \\\"{x:783,y:684,t:1527613853417};\\\", \\\"{x:774,y:692,t:1527613853434};\\\", \\\"{x:767,y:698,t:1527613853450};\\\", \\\"{x:756,y:705,t:1527613853466};\\\", \\\"{x:747,y:710,t:1527613853484};\\\", \\\"{x:743,y:710,t:1527613853500};\\\", \\\"{x:736,y:710,t:1527613853517};\\\", \\\"{x:731,y:710,t:1527613853534};\\\", \\\"{x:728,y:710,t:1527613853550};\\\", \\\"{x:725,y:710,t:1527613853567};\\\", \\\"{x:723,y:710,t:1527613853584};\\\", \\\"{x:717,y:710,t:1527613853600};\\\", \\\"{x:708,y:710,t:1527613853617};\\\", \\\"{x:693,y:710,t:1527613853635};\\\", \\\"{x:688,y:710,t:1527613853651};\\\", \\\"{x:679,y:711,t:1527613853667};\\\", \\\"{x:670,y:715,t:1527613853683};\\\", \\\"{x:666,y:717,t:1527613853701};\\\", \\\"{x:664,y:717,t:1527613853716};\\\", \\\"{x:661,y:718,t:1527613853733};\\\", \\\"{x:660,y:719,t:1527613853750};\\\", \\\"{x:655,y:720,t:1527613853767};\\\", \\\"{x:652,y:720,t:1527613853784};\\\", \\\"{x:643,y:720,t:1527613853801};\\\", \\\"{x:632,y:721,t:1527613853816};\\\", \\\"{x:621,y:721,t:1527613853834};\\\", \\\"{x:601,y:719,t:1527613853851};\\\", \\\"{x:585,y:713,t:1527613853867};\\\", \\\"{x:572,y:708,t:1527613853884};\\\", \\\"{x:565,y:704,t:1527613853901};\\\", \\\"{x:560,y:704,t:1527613853917};\\\", \\\"{x:555,y:702,t:1527613853934};\\\", \\\"{x:548,y:701,t:1527613853950};\\\", \\\"{x:542,y:701,t:1527613853967};\\\", \\\"{x:534,y:700,t:1527613853984};\\\", \\\"{x:524,y:697,t:1527613854001};\\\", \\\"{x:511,y:695,t:1527613854017};\\\", \\\"{x:499,y:692,t:1527613854034};\\\", \\\"{x:482,y:690,t:1527613854050};\\\", \\\"{x:471,y:687,t:1527613854068};\\\", \\\"{x:457,y:686,t:1527613854083};\\\", \\\"{x:447,y:685,t:1527613854101};\\\", \\\"{x:439,y:685,t:1527613854117};\\\", \\\"{x:436,y:684,t:1527613854134};\\\", \\\"{x:433,y:683,t:1527613854151};\\\", \\\"{x:430,y:683,t:1527613854168};\\\", \\\"{x:426,y:683,t:1527613854184};\\\", \\\"{x:421,y:681,t:1527613854202};\\\", \\\"{x:410,y:679,t:1527613854218};\\\", \\\"{x:395,y:679,t:1527613854235};\\\", \\\"{x:387,y:679,t:1527613854251};\\\", \\\"{x:380,y:679,t:1527613854268};\\\", \\\"{x:372,y:679,t:1527613854284};\\\", \\\"{x:363,y:679,t:1527613854301};\\\", \\\"{x:349,y:678,t:1527613854318};\\\", \\\"{x:326,y:673,t:1527613854334};\\\", \\\"{x:302,y:666,t:1527613854351};\\\", \\\"{x:290,y:663,t:1527613854369};\\\", \\\"{x:282,y:663,t:1527613854383};\\\", \\\"{x:272,y:662,t:1527613854401};\\\", \\\"{x:269,y:661,t:1527613854417};\\\", \\\"{x:264,y:661,t:1527613854434};\\\", \\\"{x:260,y:659,t:1527613854451};\\\", \\\"{x:259,y:659,t:1527613854467};\\\", \\\"{x:257,y:659,t:1527613854483};\\\", \\\"{x:256,y:659,t:1527613854522};\\\", \\\"{x:255,y:659,t:1527613854534};\\\", \\\"{x:256,y:659,t:1527613854602};\\\", \\\"{x:263,y:659,t:1527613854618};\\\", \\\"{x:317,y:660,t:1527613854635};\\\", \\\"{x:381,y:660,t:1527613854651};\\\", \\\"{x:462,y:660,t:1527613854668};\\\", \\\"{x:551,y:660,t:1527613854685};\\\", \\\"{x:626,y:660,t:1527613854701};\\\", \\\"{x:668,y:660,t:1527613854717};\\\", \\\"{x:706,y:655,t:1527613854734};\\\", \\\"{x:732,y:651,t:1527613854751};\\\", \\\"{x:751,y:647,t:1527613854768};\\\", \\\"{x:758,y:646,t:1527613854784};\\\", \\\"{x:773,y:640,t:1527613854801};\\\", \\\"{x:785,y:636,t:1527613854818};\\\", \\\"{x:809,y:631,t:1527613854834};\\\", \\\"{x:821,y:628,t:1527613854851};\\\", \\\"{x:832,y:623,t:1527613854868};\\\", \\\"{x:835,y:620,t:1527613854885};\\\", \\\"{x:838,y:618,t:1527613854901};\\\", \\\"{x:839,y:616,t:1527613854918};\\\", \\\"{x:843,y:611,t:1527613854934};\\\", \\\"{x:849,y:604,t:1527613854956};\\\", \\\"{x:855,y:597,t:1527613854968};\\\", \\\"{x:858,y:588,t:1527613854985};\\\", \\\"{x:860,y:583,t:1527613855002};\\\", \\\"{x:861,y:579,t:1527613855017};\\\", \\\"{x:861,y:574,t:1527613855034};\\\", \\\"{x:861,y:573,t:1527613855082};\\\", \\\"{x:861,y:571,t:1527613855171};\\\", \\\"{x:861,y:570,t:1527613855194};\\\", \\\"{x:860,y:570,t:1527613855202};\\\", \\\"{x:859,y:570,t:1527613855218};\\\", \\\"{x:855,y:570,t:1527613855234};\\\", \\\"{x:854,y:569,t:1527613855251};\\\", \\\"{x:853,y:569,t:1527613855268};\\\", \\\"{x:851,y:569,t:1527613855285};\\\", \\\"{x:850,y:568,t:1527613855306};\\\", \\\"{x:849,y:568,t:1527613855322};\\\", \\\"{x:848,y:568,t:1527613855343};\\\", \\\"{x:847,y:568,t:1527613855392};\\\", \\\"{x:846,y:568,t:1527613855415};\\\", \\\"{x:844,y:568,t:1527613855423};\\\", \\\"{x:843,y:568,t:1527613855446};\\\", \\\"{x:843,y:569,t:1527613855455};\\\", \\\"{x:842,y:569,t:1527613855710};\\\", \\\"{x:839,y:569,t:1527613855723};\\\", \\\"{x:829,y:573,t:1527613855738};\\\", \\\"{x:807,y:581,t:1527613855756};\\\", \\\"{x:779,y:592,t:1527613855773};\\\", \\\"{x:753,y:600,t:1527613855789};\\\", \\\"{x:697,y:621,t:1527613855807};\\\", \\\"{x:670,y:634,t:1527613855823};\\\", \\\"{x:648,y:645,t:1527613855839};\\\", \\\"{x:632,y:652,t:1527613855856};\\\", \\\"{x:619,y:657,t:1527613855873};\\\", \\\"{x:602,y:664,t:1527613855889};\\\", \\\"{x:584,y:672,t:1527613855906};\\\", \\\"{x:569,y:678,t:1527613855923};\\\", \\\"{x:555,y:688,t:1527613855939};\\\", \\\"{x:545,y:698,t:1527613855956};\\\", \\\"{x:542,y:702,t:1527613855973};\\\", \\\"{x:539,y:706,t:1527613855989};\\\", \\\"{x:536,y:710,t:1527613856006};\\\", \\\"{x:536,y:713,t:1527613856023};\\\", \\\"{x:533,y:718,t:1527613856040};\\\", \\\"{x:531,y:724,t:1527613856055};\\\", \\\"{x:529,y:727,t:1527613856073};\\\", \\\"{x:529,y:729,t:1527613856089};\\\", \\\"{x:529,y:730,t:1527613856105};\\\", \\\"{x:528,y:732,t:1527613856123};\\\" ] }, { \\\"rt\\\": 43875, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 226015, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\", \\\"E\\\", \\\"M\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-12-J -2-4-1-5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:734,t:1527613858294};\\\", \\\"{x:528,y:735,t:1527613858306};\\\", \\\"{x:542,y:743,t:1527613858323};\\\", \\\"{x:573,y:753,t:1527613858339};\\\", \\\"{x:615,y:764,t:1527613858355};\\\", \\\"{x:712,y:790,t:1527613858375};\\\", \\\"{x:723,y:796,t:1527613858391};\\\", \\\"{x:723,y:797,t:1527613858408};\\\", \\\"{x:731,y:803,t:1527613858424};\\\", \\\"{x:739,y:808,t:1527613858442};\\\", \\\"{x:743,y:810,t:1527613858457};\\\", \\\"{x:748,y:811,t:1527613858475};\\\", \\\"{x:749,y:812,t:1527613858903};\\\", \\\"{x:750,y:812,t:1527613859543};\\\", \\\"{x:752,y:812,t:1527613859560};\\\", \\\"{x:753,y:812,t:1527613859583};\\\", \\\"{x:755,y:812,t:1527613859606};\\\", \\\"{x:756,y:812,t:1527613859623};\\\", \\\"{x:757,y:812,t:1527613859655};\\\", \\\"{x:758,y:812,t:1527613859662};\\\", \\\"{x:760,y:812,t:1527613859679};\\\", \\\"{x:762,y:812,t:1527613859695};\\\", \\\"{x:763,y:811,t:1527613859710};\\\", \\\"{x:765,y:811,t:1527613859727};\\\", \\\"{x:766,y:811,t:1527613859743};\\\", \\\"{x:769,y:811,t:1527613859759};\\\", \\\"{x:773,y:811,t:1527613859777};\\\", \\\"{x:776,y:811,t:1527613859793};\\\", \\\"{x:781,y:811,t:1527613859809};\\\", \\\"{x:783,y:811,t:1527613859826};\\\", \\\"{x:786,y:811,t:1527613859842};\\\", \\\"{x:789,y:811,t:1527613859860};\\\", \\\"{x:790,y:811,t:1527613859876};\\\", \\\"{x:792,y:811,t:1527613859894};\\\", \\\"{x:793,y:811,t:1527613859982};\\\", \\\"{x:794,y:811,t:1527613860014};\\\", \\\"{x:794,y:810,t:1527613860183};\\\", \\\"{x:796,y:808,t:1527613860839};\\\", \\\"{x:797,y:808,t:1527613860855};\\\", \\\"{x:797,y:807,t:1527613860862};\\\", \\\"{x:799,y:806,t:1527613860878};\\\", \\\"{x:803,y:804,t:1527613860895};\\\", \\\"{x:806,y:801,t:1527613860912};\\\", \\\"{x:812,y:796,t:1527613860928};\\\", \\\"{x:820,y:788,t:1527613860945};\\\", \\\"{x:832,y:775,t:1527613860962};\\\", \\\"{x:848,y:753,t:1527613860978};\\\", \\\"{x:876,y:715,t:1527613860996};\\\", \\\"{x:909,y:674,t:1527613861012};\\\", \\\"{x:934,y:631,t:1527613861030};\\\", \\\"{x:949,y:606,t:1527613861044};\\\", \\\"{x:967,y:569,t:1527613861062};\\\", \\\"{x:972,y:560,t:1527613861077};\\\", \\\"{x:979,y:548,t:1527613861093};\\\", \\\"{x:989,y:533,t:1527613861110};\\\", \\\"{x:993,y:528,t:1527613861127};\\\", \\\"{x:1001,y:521,t:1527613861142};\\\", \\\"{x:1005,y:516,t:1527613861160};\\\", \\\"{x:1011,y:511,t:1527613861177};\\\", \\\"{x:1016,y:505,t:1527613861193};\\\", \\\"{x:1021,y:503,t:1527613861210};\\\", \\\"{x:1026,y:500,t:1527613861227};\\\", \\\"{x:1029,y:498,t:1527613861243};\\\", \\\"{x:1031,y:498,t:1527613861260};\\\", \\\"{x:1036,y:497,t:1527613861277};\\\", \\\"{x:1039,y:497,t:1527613861294};\\\", \\\"{x:1043,y:496,t:1527613861311};\\\", \\\"{x:1046,y:496,t:1527613861327};\\\", \\\"{x:1051,y:496,t:1527613861344};\\\", \\\"{x:1055,y:496,t:1527613861361};\\\", \\\"{x:1059,y:496,t:1527613861378};\\\", \\\"{x:1062,y:496,t:1527613861394};\\\", \\\"{x:1065,y:496,t:1527613861411};\\\", \\\"{x:1067,y:497,t:1527613861430};\\\", \\\"{x:1069,y:498,t:1527613861444};\\\", \\\"{x:1069,y:499,t:1527613861460};\\\", \\\"{x:1069,y:504,t:1527613861477};\\\", \\\"{x:1069,y:510,t:1527613861494};\\\", \\\"{x:1069,y:516,t:1527613861510};\\\", \\\"{x:1069,y:524,t:1527613861527};\\\", \\\"{x:1069,y:532,t:1527613861544};\\\", \\\"{x:1069,y:538,t:1527613861560};\\\", \\\"{x:1069,y:544,t:1527613861577};\\\", \\\"{x:1068,y:548,t:1527613861594};\\\", \\\"{x:1067,y:554,t:1527613861610};\\\", \\\"{x:1067,y:557,t:1527613861627};\\\", \\\"{x:1066,y:559,t:1527613861644};\\\", \\\"{x:1066,y:562,t:1527613861660};\\\", \\\"{x:1064,y:565,t:1527613861677};\\\", \\\"{x:1064,y:566,t:1527613861694};\\\", \\\"{x:1064,y:567,t:1527613861711};\\\", \\\"{x:1064,y:566,t:1527613862551};\\\", \\\"{x:1064,y:565,t:1527613862561};\\\", \\\"{x:1065,y:563,t:1527613862578};\\\", \\\"{x:1065,y:560,t:1527613862595};\\\", \\\"{x:1066,y:554,t:1527613862612};\\\", \\\"{x:1066,y:551,t:1527613862629};\\\", \\\"{x:1069,y:545,t:1527613862644};\\\", \\\"{x:1069,y:543,t:1527613862662};\\\", \\\"{x:1070,y:537,t:1527613862679};\\\", \\\"{x:1071,y:532,t:1527613862695};\\\", \\\"{x:1072,y:529,t:1527613862711};\\\", \\\"{x:1072,y:525,t:1527613862729};\\\", \\\"{x:1073,y:521,t:1527613862745};\\\", \\\"{x:1074,y:517,t:1527613862762};\\\", \\\"{x:1075,y:516,t:1527613862779};\\\", \\\"{x:1075,y:512,t:1527613862795};\\\", \\\"{x:1076,y:506,t:1527613862811};\\\", \\\"{x:1076,y:500,t:1527613862829};\\\", \\\"{x:1077,y:497,t:1527613862846};\\\", \\\"{x:1077,y:496,t:1527613862862};\\\", \\\"{x:1077,y:495,t:1527613862879};\\\", \\\"{x:1078,y:493,t:1527613862896};\\\", \\\"{x:1078,y:492,t:1527613862983};\\\", \\\"{x:1078,y:490,t:1527613862995};\\\", \\\"{x:1078,y:488,t:1527613863011};\\\", \\\"{x:1078,y:484,t:1527613863028};\\\", \\\"{x:1077,y:478,t:1527613863045};\\\", \\\"{x:1076,y:470,t:1527613863061};\\\", \\\"{x:1074,y:462,t:1527613863078};\\\", \\\"{x:1072,y:456,t:1527613863095};\\\", \\\"{x:1071,y:455,t:1527613863111};\\\", \\\"{x:1067,y:454,t:1527613863129};\\\", \\\"{x:1065,y:451,t:1527613863146};\\\", \\\"{x:1065,y:450,t:1527613863161};\\\", \\\"{x:1065,y:448,t:1527613863179};\\\", \\\"{x:1065,y:447,t:1527613863196};\\\", \\\"{x:1065,y:445,t:1527613863212};\\\", \\\"{x:1065,y:444,t:1527613863230};\\\", \\\"{x:1065,y:442,t:1527613863246};\\\", \\\"{x:1064,y:440,t:1527613863263};\\\", \\\"{x:1064,y:439,t:1527613863335};\\\", \\\"{x:1064,y:437,t:1527613863359};\\\", \\\"{x:1064,y:436,t:1527613863367};\\\", \\\"{x:1064,y:434,t:1527613863379};\\\", \\\"{x:1064,y:430,t:1527613863396};\\\", \\\"{x:1064,y:425,t:1527613863413};\\\", \\\"{x:1064,y:419,t:1527613863429};\\\", \\\"{x:1064,y:416,t:1527613863446};\\\", \\\"{x:1063,y:412,t:1527613863462};\\\", \\\"{x:1063,y:411,t:1527613863479};\\\", \\\"{x:1063,y:409,t:1527613863495};\\\", \\\"{x:1061,y:407,t:1527613863513};\\\", \\\"{x:1061,y:405,t:1527613863529};\\\", \\\"{x:1061,y:402,t:1527613863545};\\\", \\\"{x:1061,y:398,t:1527613863562};\\\", \\\"{x:1061,y:395,t:1527613863578};\\\", \\\"{x:1061,y:392,t:1527613863596};\\\", \\\"{x:1061,y:389,t:1527613863613};\\\", \\\"{x:1061,y:384,t:1527613863628};\\\", \\\"{x:1062,y:381,t:1527613863646};\\\", \\\"{x:1063,y:376,t:1527613863662};\\\", \\\"{x:1063,y:373,t:1527613863679};\\\", \\\"{x:1064,y:370,t:1527613863696};\\\", \\\"{x:1064,y:367,t:1527613863712};\\\", \\\"{x:1065,y:363,t:1527613863730};\\\", \\\"{x:1065,y:362,t:1527613863839};\\\", \\\"{x:1065,y:360,t:1527613863847};\\\", \\\"{x:1066,y:354,t:1527613863863};\\\", \\\"{x:1066,y:344,t:1527613863879};\\\", \\\"{x:1068,y:335,t:1527613863895};\\\", \\\"{x:1068,y:327,t:1527613863913};\\\", \\\"{x:1068,y:318,t:1527613863930};\\\", \\\"{x:1069,y:311,t:1527613863946};\\\", \\\"{x:1071,y:305,t:1527613863963};\\\", \\\"{x:1072,y:302,t:1527613863979};\\\", \\\"{x:1073,y:299,t:1527613863996};\\\", \\\"{x:1074,y:298,t:1527613864015};\\\", \\\"{x:1074,y:295,t:1527613864111};\\\", \\\"{x:1075,y:295,t:1527613864127};\\\", \\\"{x:1076,y:294,t:1527613864134};\\\", \\\"{x:1076,y:293,t:1527613864146};\\\", \\\"{x:1076,y:289,t:1527613864163};\\\", \\\"{x:1076,y:285,t:1527613864179};\\\", \\\"{x:1077,y:279,t:1527613864195};\\\", \\\"{x:1077,y:271,t:1527613864212};\\\", \\\"{x:1077,y:260,t:1527613864229};\\\", \\\"{x:1075,y:246,t:1527613864246};\\\", \\\"{x:1075,y:243,t:1527613864262};\\\", \\\"{x:1074,y:242,t:1527613864279};\\\", \\\"{x:1074,y:240,t:1527613864296};\\\", \\\"{x:1074,y:239,t:1527613864326};\\\", \\\"{x:1074,y:237,t:1527613864350};\\\", \\\"{x:1074,y:236,t:1527613864362};\\\", \\\"{x:1074,y:234,t:1527613864379};\\\", \\\"{x:1074,y:233,t:1527613864396};\\\", \\\"{x:1074,y:232,t:1527613864422};\\\", \\\"{x:1075,y:231,t:1527613864438};\\\", \\\"{x:1075,y:230,t:1527613864462};\\\", \\\"{x:1075,y:227,t:1527613864480};\\\", \\\"{x:1075,y:224,t:1527613864496};\\\", \\\"{x:1075,y:217,t:1527613864512};\\\", \\\"{x:1075,y:207,t:1527613864530};\\\", \\\"{x:1075,y:203,t:1527613864547};\\\", \\\"{x:1076,y:186,t:1527613864563};\\\", \\\"{x:1082,y:168,t:1527613864580};\\\", \\\"{x:1083,y:163,t:1527613864597};\\\", \\\"{x:1084,y:156,t:1527613864613};\\\", \\\"{x:1085,y:152,t:1527613864629};\\\", \\\"{x:1085,y:151,t:1527613864831};\\\", \\\"{x:1081,y:152,t:1527613864879};\\\", \\\"{x:1071,y:157,t:1527613864897};\\\", \\\"{x:1062,y:167,t:1527613864914};\\\", \\\"{x:1050,y:178,t:1527613864930};\\\", \\\"{x:1029,y:189,t:1527613864947};\\\", \\\"{x:1011,y:199,t:1527613864964};\\\", \\\"{x:994,y:209,t:1527613864980};\\\", \\\"{x:980,y:218,t:1527613864997};\\\", \\\"{x:963,y:228,t:1527613865013};\\\", \\\"{x:941,y:242,t:1527613865030};\\\", \\\"{x:913,y:258,t:1527613865047};\\\", \\\"{x:898,y:270,t:1527613865063};\\\", \\\"{x:883,y:281,t:1527613865080};\\\", \\\"{x:867,y:292,t:1527613865096};\\\", \\\"{x:846,y:305,t:1527613865113};\\\", \\\"{x:833,y:316,t:1527613865131};\\\", \\\"{x:819,y:331,t:1527613865147};\\\", \\\"{x:806,y:349,t:1527613865163};\\\", \\\"{x:797,y:361,t:1527613865181};\\\", \\\"{x:788,y:371,t:1527613865197};\\\", \\\"{x:778,y:383,t:1527613865214};\\\", \\\"{x:762,y:398,t:1527613865230};\\\", \\\"{x:754,y:408,t:1527613865246};\\\", \\\"{x:748,y:416,t:1527613865265};\\\", \\\"{x:746,y:418,t:1527613865280};\\\", \\\"{x:744,y:422,t:1527613865297};\\\", \\\"{x:739,y:428,t:1527613865314};\\\", \\\"{x:734,y:433,t:1527613865330};\\\", \\\"{x:725,y:438,t:1527613865346};\\\", \\\"{x:719,y:442,t:1527613865364};\\\", \\\"{x:715,y:446,t:1527613865381};\\\", \\\"{x:710,y:450,t:1527613865396};\\\", \\\"{x:705,y:453,t:1527613865414};\\\", \\\"{x:694,y:463,t:1527613865431};\\\", \\\"{x:678,y:470,t:1527613865447};\\\", \\\"{x:656,y:482,t:1527613865464};\\\", \\\"{x:634,y:495,t:1527613865483};\\\", \\\"{x:613,y:507,t:1527613865497};\\\", \\\"{x:596,y:515,t:1527613865513};\\\", \\\"{x:584,y:520,t:1527613865530};\\\", \\\"{x:573,y:525,t:1527613865547};\\\", \\\"{x:560,y:530,t:1527613865563};\\\", \\\"{x:551,y:534,t:1527613865580};\\\", \\\"{x:546,y:537,t:1527613865597};\\\", \\\"{x:542,y:539,t:1527613865614};\\\", \\\"{x:540,y:540,t:1527613865630};\\\", \\\"{x:534,y:544,t:1527613865647};\\\", \\\"{x:528,y:546,t:1527613865664};\\\", \\\"{x:524,y:549,t:1527613865681};\\\", \\\"{x:523,y:549,t:1527613865697};\\\", \\\"{x:523,y:550,t:1527613865775};\\\", \\\"{x:523,y:551,t:1527613865782};\\\", \\\"{x:523,y:552,t:1527613865798};\\\", \\\"{x:532,y:555,t:1527613865814};\\\", \\\"{x:545,y:557,t:1527613865831};\\\", \\\"{x:558,y:558,t:1527613865848};\\\", \\\"{x:568,y:561,t:1527613865864};\\\", \\\"{x:584,y:561,t:1527613865881};\\\", \\\"{x:598,y:561,t:1527613865897};\\\", \\\"{x:609,y:561,t:1527613865914};\\\", \\\"{x:621,y:561,t:1527613865931};\\\", \\\"{x:630,y:559,t:1527613865948};\\\", \\\"{x:635,y:555,t:1527613865964};\\\", \\\"{x:642,y:550,t:1527613865981};\\\", \\\"{x:649,y:543,t:1527613865998};\\\", \\\"{x:651,y:540,t:1527613866014};\\\", \\\"{x:651,y:537,t:1527613866030};\\\", \\\"{x:651,y:536,t:1527613866048};\\\", \\\"{x:651,y:534,t:1527613866064};\\\", \\\"{x:651,y:533,t:1527613866081};\\\", \\\"{x:650,y:527,t:1527613866097};\\\", \\\"{x:646,y:525,t:1527613866114};\\\", \\\"{x:643,y:522,t:1527613866131};\\\", \\\"{x:640,y:521,t:1527613866148};\\\", \\\"{x:639,y:519,t:1527613866164};\\\", \\\"{x:637,y:517,t:1527613866182};\\\", \\\"{x:636,y:512,t:1527613866198};\\\", \\\"{x:630,y:503,t:1527613866213};\\\", \\\"{x:629,y:500,t:1527613866232};\\\", \\\"{x:627,y:496,t:1527613866265};\\\", \\\"{x:626,y:496,t:1527613866281};\\\", \\\"{x:625,y:495,t:1527613866298};\\\", \\\"{x:624,y:494,t:1527613866314};\\\", \\\"{x:624,y:493,t:1527613866331};\\\", \\\"{x:623,y:492,t:1527613866348};\\\", \\\"{x:617,y:490,t:1527613866364};\\\", \\\"{x:615,y:490,t:1527613866381};\\\", \\\"{x:611,y:488,t:1527613866398};\\\", \\\"{x:610,y:488,t:1527613866655};\\\", \\\"{x:613,y:490,t:1527613867479};\\\", \\\"{x:615,y:490,t:1527613867485};\\\", \\\"{x:615,y:491,t:1527613867498};\\\", \\\"{x:616,y:491,t:1527613867515};\\\", \\\"{x:617,y:491,t:1527613867582};\\\", \\\"{x:617,y:492,t:1527613867599};\\\", \\\"{x:617,y:494,t:1527613867615};\\\", \\\"{x:615,y:495,t:1527613867632};\\\", \\\"{x:613,y:497,t:1527613867649};\\\", \\\"{x:613,y:498,t:1527613867671};\\\", \\\"{x:613,y:500,t:1527613867710};\\\", \\\"{x:612,y:500,t:1527613867759};\\\", \\\"{x:611,y:500,t:1527613867823};\\\", \\\"{x:611,y:501,t:1527613867855};\\\", \\\"{x:610,y:501,t:1527613867867};\\\", \\\"{x:609,y:502,t:1527613867886};\\\", \\\"{x:608,y:503,t:1527613868287};\\\", \\\"{x:607,y:504,t:1527613868831};\\\", \\\"{x:607,y:506,t:1527613868983};\\\", \\\"{x:605,y:509,t:1527613869001};\\\", \\\"{x:605,y:513,t:1527613869017};\\\", \\\"{x:605,y:516,t:1527613869035};\\\", \\\"{x:605,y:520,t:1527613869051};\\\", \\\"{x:605,y:528,t:1527613869067};\\\", \\\"{x:611,y:545,t:1527613869083};\\\", \\\"{x:620,y:568,t:1527613869101};\\\", \\\"{x:641,y:602,t:1527613869116};\\\", \\\"{x:679,y:645,t:1527613869134};\\\", \\\"{x:775,y:733,t:1527613869150};\\\", \\\"{x:860,y:789,t:1527613869167};\\\", \\\"{x:942,y:833,t:1527613869183};\\\", \\\"{x:1005,y:860,t:1527613869201};\\\", \\\"{x:1048,y:883,t:1527613869217};\\\", \\\"{x:1092,y:901,t:1527613869233};\\\", \\\"{x:1114,y:915,t:1527613869250};\\\", \\\"{x:1127,y:923,t:1527613869266};\\\", \\\"{x:1139,y:928,t:1527613869284};\\\", \\\"{x:1146,y:930,t:1527613869301};\\\", \\\"{x:1152,y:930,t:1527613869316};\\\", \\\"{x:1154,y:930,t:1527613869335};\\\", \\\"{x:1155,y:930,t:1527613869351};\\\", \\\"{x:1159,y:929,t:1527613869367};\\\", \\\"{x:1162,y:926,t:1527613869384};\\\", \\\"{x:1168,y:920,t:1527613869401};\\\", \\\"{x:1173,y:913,t:1527613869417};\\\", \\\"{x:1175,y:903,t:1527613869434};\\\", \\\"{x:1179,y:894,t:1527613869450};\\\", \\\"{x:1186,y:882,t:1527613869467};\\\", \\\"{x:1195,y:869,t:1527613869484};\\\", \\\"{x:1203,y:860,t:1527613869501};\\\", \\\"{x:1207,y:854,t:1527613869517};\\\", \\\"{x:1209,y:850,t:1527613869533};\\\", \\\"{x:1210,y:845,t:1527613869551};\\\", \\\"{x:1212,y:842,t:1527613869568};\\\", \\\"{x:1213,y:838,t:1527613869584};\\\", \\\"{x:1214,y:838,t:1527613869600};\\\", \\\"{x:1214,y:837,t:1527613869618};\\\", \\\"{x:1214,y:836,t:1527613869647};\\\", \\\"{x:1214,y:834,t:1527613869855};\\\", \\\"{x:1213,y:834,t:1527613869884};\\\", \\\"{x:1211,y:834,t:1527613869943};\\\", \\\"{x:1210,y:834,t:1527613869960};\\\", \\\"{x:1208,y:834,t:1527613869968};\\\", \\\"{x:1205,y:834,t:1527613869983};\\\", \\\"{x:1203,y:834,t:1527613870000};\\\", \\\"{x:1202,y:834,t:1527613870018};\\\", \\\"{x:1201,y:834,t:1527613870054};\\\", \\\"{x:1200,y:834,t:1527613870070};\\\", \\\"{x:1199,y:834,t:1527613870085};\\\", \\\"{x:1194,y:834,t:1527613870100};\\\", \\\"{x:1191,y:834,t:1527613870117};\\\", \\\"{x:1187,y:834,t:1527613870135};\\\", \\\"{x:1185,y:835,t:1527613870151};\\\", \\\"{x:1181,y:835,t:1527613870168};\\\", \\\"{x:1175,y:836,t:1527613870185};\\\", \\\"{x:1172,y:836,t:1527613870200};\\\", \\\"{x:1166,y:836,t:1527613870218};\\\", \\\"{x:1162,y:836,t:1527613870234};\\\", \\\"{x:1157,y:838,t:1527613870251};\\\", \\\"{x:1154,y:838,t:1527613870267};\\\", \\\"{x:1151,y:838,t:1527613870285};\\\", \\\"{x:1148,y:838,t:1527613870301};\\\", \\\"{x:1141,y:838,t:1527613870318};\\\", \\\"{x:1136,y:838,t:1527613870335};\\\", \\\"{x:1131,y:838,t:1527613870351};\\\", \\\"{x:1129,y:838,t:1527613870368};\\\", \\\"{x:1126,y:838,t:1527613870385};\\\", \\\"{x:1119,y:838,t:1527613870401};\\\", \\\"{x:1110,y:838,t:1527613870417};\\\", \\\"{x:1102,y:838,t:1527613870434};\\\", \\\"{x:1097,y:838,t:1527613870452};\\\", \\\"{x:1091,y:838,t:1527613870468};\\\", \\\"{x:1089,y:839,t:1527613870485};\\\", \\\"{x:1086,y:839,t:1527613870501};\\\", \\\"{x:1084,y:839,t:1527613870517};\\\", \\\"{x:1075,y:839,t:1527613870535};\\\", \\\"{x:1067,y:839,t:1527613870552};\\\", \\\"{x:1061,y:838,t:1527613870568};\\\", \\\"{x:1056,y:837,t:1527613870585};\\\", \\\"{x:1055,y:837,t:1527613870602};\\\", \\\"{x:1054,y:837,t:1527613870617};\\\", \\\"{x:1054,y:835,t:1527613870976};\\\", \\\"{x:1054,y:834,t:1527613870985};\\\", \\\"{x:1054,y:831,t:1527613871002};\\\", \\\"{x:1054,y:827,t:1527613871019};\\\", \\\"{x:1054,y:820,t:1527613871035};\\\", \\\"{x:1054,y:813,t:1527613871052};\\\", \\\"{x:1054,y:808,t:1527613871069};\\\", \\\"{x:1054,y:806,t:1527613871085};\\\", \\\"{x:1054,y:804,t:1527613871102};\\\", \\\"{x:1054,y:801,t:1527613871119};\\\", \\\"{x:1055,y:796,t:1527613871135};\\\", \\\"{x:1057,y:793,t:1527613871152};\\\", \\\"{x:1057,y:788,t:1527613871169};\\\", \\\"{x:1060,y:785,t:1527613871185};\\\", \\\"{x:1060,y:782,t:1527613871202};\\\", \\\"{x:1062,y:779,t:1527613871219};\\\", \\\"{x:1064,y:776,t:1527613871235};\\\", \\\"{x:1064,y:773,t:1527613871252};\\\", \\\"{x:1067,y:765,t:1527613871269};\\\", \\\"{x:1068,y:762,t:1527613871286};\\\", \\\"{x:1069,y:757,t:1527613871303};\\\", \\\"{x:1070,y:756,t:1527613871319};\\\", \\\"{x:1070,y:755,t:1527613871335};\\\", \\\"{x:1070,y:753,t:1527613871471};\\\", \\\"{x:1070,y:752,t:1527613871485};\\\", \\\"{x:1070,y:748,t:1527613871502};\\\", \\\"{x:1069,y:740,t:1527613871519};\\\", \\\"{x:1068,y:735,t:1527613871536};\\\", \\\"{x:1067,y:729,t:1527613871552};\\\", \\\"{x:1066,y:720,t:1527613871569};\\\", \\\"{x:1066,y:715,t:1527613871586};\\\", \\\"{x:1066,y:711,t:1527613871602};\\\", \\\"{x:1065,y:706,t:1527613871619};\\\", \\\"{x:1063,y:702,t:1527613871636};\\\", \\\"{x:1063,y:700,t:1527613871652};\\\", \\\"{x:1063,y:698,t:1527613871669};\\\", \\\"{x:1063,y:697,t:1527613871686};\\\", \\\"{x:1063,y:696,t:1527613871702};\\\", \\\"{x:1063,y:695,t:1527613871719};\\\", \\\"{x:1063,y:694,t:1527613871759};\\\", \\\"{x:1062,y:694,t:1527613871769};\\\", \\\"{x:1062,y:693,t:1527613871786};\\\", \\\"{x:1062,y:692,t:1527613871847};\\\", \\\"{x:1062,y:691,t:1527613871870};\\\", \\\"{x:1062,y:690,t:1527613871886};\\\", \\\"{x:1062,y:689,t:1527613871919};\\\", \\\"{x:1063,y:687,t:1527613872024};\\\", \\\"{x:1063,y:686,t:1527613872036};\\\", \\\"{x:1064,y:682,t:1527613872053};\\\", \\\"{x:1064,y:675,t:1527613872069};\\\", \\\"{x:1068,y:663,t:1527613872086};\\\", \\\"{x:1069,y:651,t:1527613872102};\\\", \\\"{x:1071,y:642,t:1527613872119};\\\", \\\"{x:1072,y:636,t:1527613872136};\\\", \\\"{x:1073,y:632,t:1527613872153};\\\", \\\"{x:1073,y:629,t:1527613872169};\\\", \\\"{x:1073,y:624,t:1527613872186};\\\", \\\"{x:1073,y:622,t:1527613872202};\\\", \\\"{x:1075,y:617,t:1527613872219};\\\", \\\"{x:1076,y:613,t:1527613872235};\\\", \\\"{x:1076,y:610,t:1527613872253};\\\", \\\"{x:1077,y:608,t:1527613872269};\\\", \\\"{x:1077,y:606,t:1527613872472};\\\", \\\"{x:1077,y:604,t:1527613872486};\\\", \\\"{x:1076,y:595,t:1527613872503};\\\", \\\"{x:1075,y:589,t:1527613872520};\\\", \\\"{x:1074,y:582,t:1527613872537};\\\", \\\"{x:1073,y:575,t:1527613872553};\\\", \\\"{x:1072,y:570,t:1527613872570};\\\", \\\"{x:1072,y:568,t:1527613872586};\\\", \\\"{x:1071,y:561,t:1527613872602};\\\", \\\"{x:1071,y:557,t:1527613872619};\\\", \\\"{x:1071,y:556,t:1527613872636};\\\", \\\"{x:1071,y:554,t:1527613872653};\\\", \\\"{x:1071,y:553,t:1527613872758};\\\", \\\"{x:1071,y:552,t:1527613872895};\\\", \\\"{x:1071,y:550,t:1527613873639};\\\", \\\"{x:1071,y:548,t:1527613873759};\\\", \\\"{x:1071,y:547,t:1527613873967};\\\", \\\"{x:1071,y:545,t:1527613877359};\\\", \\\"{x:1073,y:538,t:1527613877377};\\\", \\\"{x:1075,y:533,t:1527613877390};\\\", \\\"{x:1075,y:532,t:1527613877405};\\\", \\\"{x:1076,y:530,t:1527613877423};\\\", \\\"{x:1076,y:529,t:1527613877440};\\\", \\\"{x:1076,y:528,t:1527613877470};\\\", \\\"{x:1076,y:527,t:1527613877510};\\\", \\\"{x:1076,y:526,t:1527613877522};\\\", \\\"{x:1076,y:525,t:1527613877540};\\\", \\\"{x:1076,y:522,t:1527613877556};\\\", \\\"{x:1076,y:518,t:1527613877573};\\\", \\\"{x:1075,y:512,t:1527613877591};\\\", \\\"{x:1074,y:505,t:1527613877606};\\\", \\\"{x:1073,y:500,t:1527613877623};\\\", \\\"{x:1072,y:496,t:1527613877640};\\\", \\\"{x:1072,y:493,t:1527613877657};\\\", \\\"{x:1071,y:492,t:1527613877673};\\\", \\\"{x:1071,y:490,t:1527613877967};\\\", \\\"{x:1071,y:487,t:1527613877975};\\\", \\\"{x:1071,y:480,t:1527613877989};\\\", \\\"{x:1069,y:473,t:1527613878007};\\\", \\\"{x:1067,y:465,t:1527613878023};\\\", \\\"{x:1067,y:461,t:1527613878040};\\\", \\\"{x:1066,y:459,t:1527613878056};\\\", \\\"{x:1066,y:458,t:1527613878073};\\\", \\\"{x:1066,y:457,t:1527613878090};\\\", \\\"{x:1066,y:456,t:1527613878107};\\\", \\\"{x:1064,y:454,t:1527613878123};\\\", \\\"{x:1064,y:453,t:1527613878140};\\\", \\\"{x:1064,y:451,t:1527613878156};\\\", \\\"{x:1064,y:448,t:1527613878175};\\\", \\\"{x:1063,y:447,t:1527613878311};\\\", \\\"{x:1060,y:447,t:1527613878324};\\\", \\\"{x:1045,y:456,t:1527613878341};\\\", \\\"{x:1029,y:462,t:1527613878357};\\\", \\\"{x:998,y:470,t:1527613878376};\\\", \\\"{x:973,y:476,t:1527613878391};\\\", \\\"{x:957,y:481,t:1527613878408};\\\", \\\"{x:930,y:491,t:1527613878426};\\\", \\\"{x:905,y:501,t:1527613878440};\\\", \\\"{x:877,y:515,t:1527613878457};\\\", \\\"{x:857,y:526,t:1527613878472};\\\", \\\"{x:819,y:550,t:1527613878489};\\\", \\\"{x:790,y:564,t:1527613878508};\\\", \\\"{x:773,y:572,t:1527613878524};\\\", \\\"{x:750,y:583,t:1527613878541};\\\", \\\"{x:734,y:594,t:1527613878558};\\\", \\\"{x:733,y:594,t:1527613878574};\\\", \\\"{x:726,y:597,t:1527613878614};\\\", \\\"{x:715,y:601,t:1527613878625};\\\", \\\"{x:700,y:605,t:1527613878640};\\\", \\\"{x:686,y:605,t:1527613878658};\\\", \\\"{x:682,y:605,t:1527613878674};\\\", \\\"{x:681,y:605,t:1527613878691};\\\", \\\"{x:679,y:603,t:1527613878708};\\\", \\\"{x:676,y:596,t:1527613878726};\\\", \\\"{x:666,y:591,t:1527613878742};\\\", \\\"{x:650,y:584,t:1527613878757};\\\", \\\"{x:630,y:580,t:1527613878775};\\\", \\\"{x:618,y:577,t:1527613878791};\\\", \\\"{x:607,y:576,t:1527613878807};\\\", \\\"{x:598,y:574,t:1527613878824};\\\", \\\"{x:586,y:574,t:1527613878841};\\\", \\\"{x:567,y:574,t:1527613878858};\\\", \\\"{x:545,y:574,t:1527613878875};\\\", \\\"{x:523,y:580,t:1527613878891};\\\", \\\"{x:504,y:584,t:1527613878908};\\\", \\\"{x:483,y:590,t:1527613878926};\\\", \\\"{x:467,y:592,t:1527613878941};\\\", \\\"{x:457,y:594,t:1527613878958};\\\", \\\"{x:451,y:597,t:1527613878975};\\\", \\\"{x:445,y:598,t:1527613878991};\\\", \\\"{x:442,y:599,t:1527613879008};\\\", \\\"{x:440,y:600,t:1527613879025};\\\", \\\"{x:439,y:601,t:1527613879041};\\\", \\\"{x:437,y:602,t:1527613879058};\\\", \\\"{x:434,y:605,t:1527613879074};\\\", \\\"{x:429,y:607,t:1527613879090};\\\", \\\"{x:424,y:609,t:1527613879107};\\\", \\\"{x:421,y:610,t:1527613879124};\\\", \\\"{x:419,y:611,t:1527613879142};\\\", \\\"{x:418,y:612,t:1527613879158};\\\", \\\"{x:416,y:612,t:1527613879190};\\\", \\\"{x:415,y:613,t:1527613879199};\\\", \\\"{x:412,y:613,t:1527613879208};\\\", \\\"{x:405,y:615,t:1527613879225};\\\", \\\"{x:403,y:617,t:1527613879242};\\\", \\\"{x:400,y:618,t:1527613879257};\\\", \\\"{x:398,y:619,t:1527613879275};\\\", \\\"{x:396,y:619,t:1527613879292};\\\", \\\"{x:394,y:620,t:1527613879308};\\\", \\\"{x:392,y:620,t:1527613879326};\\\", \\\"{x:390,y:621,t:1527613879342};\\\", \\\"{x:388,y:622,t:1527613879358};\\\", \\\"{x:387,y:623,t:1527613879376};\\\", \\\"{x:386,y:623,t:1527613879398};\\\", \\\"{x:385,y:623,t:1527613879414};\\\", \\\"{x:384,y:623,t:1527613879438};\\\", \\\"{x:382,y:623,t:1527613879454};\\\", \\\"{x:380,y:622,t:1527613879479};\\\", \\\"{x:378,y:620,t:1527613879492};\\\", \\\"{x:372,y:607,t:1527613879509};\\\", \\\"{x:367,y:597,t:1527613879525};\\\", \\\"{x:361,y:582,t:1527613879542};\\\", \\\"{x:358,y:572,t:1527613879558};\\\", \\\"{x:357,y:565,t:1527613879574};\\\", \\\"{x:357,y:562,t:1527613879592};\\\", \\\"{x:357,y:560,t:1527613879608};\\\", \\\"{x:357,y:559,t:1527613879625};\\\", \\\"{x:357,y:556,t:1527613879642};\\\", \\\"{x:358,y:555,t:1527613879658};\\\", \\\"{x:358,y:553,t:1527613879675};\\\", \\\"{x:360,y:549,t:1527613879691};\\\", \\\"{x:362,y:547,t:1527613879708};\\\", \\\"{x:365,y:545,t:1527613879724};\\\", \\\"{x:368,y:542,t:1527613879741};\\\", \\\"{x:370,y:541,t:1527613879798};\\\", \\\"{x:372,y:539,t:1527613879815};\\\", \\\"{x:373,y:538,t:1527613879831};\\\", \\\"{x:375,y:536,t:1527613879842};\\\", \\\"{x:377,y:534,t:1527613879859};\\\", \\\"{x:380,y:532,t:1527613879875};\\\", \\\"{x:382,y:531,t:1527613879892};\\\", \\\"{x:384,y:530,t:1527613879909};\\\", \\\"{x:385,y:529,t:1527613879942};\\\", \\\"{x:385,y:528,t:1527613879959};\\\", \\\"{x:386,y:528,t:1527613879977};\\\", \\\"{x:389,y:526,t:1527613879992};\\\", \\\"{x:390,y:525,t:1527613880008};\\\", \\\"{x:390,y:524,t:1527613880026};\\\", \\\"{x:390,y:523,t:1527613880041};\\\", \\\"{x:391,y:522,t:1527613880059};\\\", \\\"{x:391,y:520,t:1527613880077};\\\", \\\"{x:392,y:518,t:1527613880092};\\\", \\\"{x:394,y:513,t:1527613880110};\\\", \\\"{x:395,y:508,t:1527613880126};\\\", \\\"{x:396,y:506,t:1527613880142};\\\", \\\"{x:396,y:505,t:1527613880158};\\\", \\\"{x:396,y:503,t:1527613880176};\\\", \\\"{x:396,y:502,t:1527613880191};\\\", \\\"{x:396,y:501,t:1527613880209};\\\", \\\"{x:396,y:500,t:1527613880230};\\\", \\\"{x:396,y:499,t:1527613880254};\\\", \\\"{x:396,y:498,t:1527613880270};\\\", \\\"{x:396,y:497,t:1527613880279};\\\", \\\"{x:396,y:496,t:1527613880391};\\\", \\\"{x:394,y:496,t:1527613880646};\\\", \\\"{x:392,y:496,t:1527613880662};\\\", \\\"{x:391,y:496,t:1527613880678};\\\", \\\"{x:389,y:496,t:1527613880693};\\\", \\\"{x:388,y:496,t:1527613880710};\\\", \\\"{x:387,y:497,t:1527613880726};\\\", \\\"{x:388,y:499,t:1527613882527};\\\", \\\"{x:392,y:499,t:1527613882544};\\\", \\\"{x:394,y:500,t:1527613882561};\\\", \\\"{x:395,y:500,t:1527613882578};\\\", \\\"{x:396,y:501,t:1527613882595};\\\", \\\"{x:397,y:501,t:1527613882612};\\\", \\\"{x:398,y:501,t:1527613882627};\\\", \\\"{x:405,y:501,t:1527613882644};\\\", \\\"{x:417,y:503,t:1527613882662};\\\", \\\"{x:437,y:508,t:1527613882678};\\\", \\\"{x:452,y:508,t:1527613882694};\\\", \\\"{x:473,y:509,t:1527613882711};\\\", \\\"{x:492,y:509,t:1527613882727};\\\", \\\"{x:512,y:509,t:1527613882744};\\\", \\\"{x:531,y:509,t:1527613882761};\\\", \\\"{x:546,y:509,t:1527613882777};\\\", \\\"{x:563,y:509,t:1527613882793};\\\", \\\"{x:574,y:509,t:1527613882811};\\\", \\\"{x:578,y:509,t:1527613882828};\\\", \\\"{x:579,y:509,t:1527613882843};\\\", \\\"{x:581,y:509,t:1527613882878};\\\", \\\"{x:582,y:509,t:1527613882902};\\\", \\\"{x:583,y:509,t:1527613882911};\\\", \\\"{x:584,y:508,t:1527613882928};\\\", \\\"{x:586,y:507,t:1527613882944};\\\", \\\"{x:587,y:506,t:1527613882982};\\\", \\\"{x:588,y:505,t:1527613882995};\\\", \\\"{x:594,y:503,t:1527613883011};\\\", \\\"{x:600,y:501,t:1527613883029};\\\", \\\"{x:607,y:497,t:1527613883044};\\\", \\\"{x:609,y:496,t:1527613883061};\\\", \\\"{x:610,y:496,t:1527613883079};\\\", \\\"{x:612,y:496,t:1527613883791};\\\", \\\"{x:618,y:498,t:1527613883799};\\\", \\\"{x:625,y:505,t:1527613883813};\\\", \\\"{x:638,y:522,t:1527613883830};\\\", \\\"{x:658,y:530,t:1527613883845};\\\", \\\"{x:695,y:545,t:1527613883862};\\\", \\\"{x:719,y:561,t:1527613883880};\\\", \\\"{x:749,y:574,t:1527613883895};\\\", \\\"{x:783,y:592,t:1527613883912};\\\", \\\"{x:806,y:603,t:1527613883929};\\\", \\\"{x:822,y:612,t:1527613883945};\\\", \\\"{x:830,y:617,t:1527613883962};\\\", \\\"{x:834,y:620,t:1527613883978};\\\", \\\"{x:836,y:621,t:1527613883994};\\\", \\\"{x:837,y:623,t:1527613884012};\\\", \\\"{x:838,y:623,t:1527613884038};\\\", \\\"{x:838,y:624,t:1527613884061};\\\", \\\"{x:839,y:626,t:1527613884079};\\\", \\\"{x:841,y:632,t:1527613884096};\\\", \\\"{x:842,y:633,t:1527613884112};\\\", \\\"{x:845,y:638,t:1527613884129};\\\", \\\"{x:846,y:640,t:1527613884145};\\\", \\\"{x:847,y:644,t:1527613884162};\\\", \\\"{x:848,y:647,t:1527613884179};\\\", \\\"{x:848,y:650,t:1527613884198};\\\", \\\"{x:849,y:650,t:1527613884212};\\\", \\\"{x:850,y:653,t:1527613884229};\\\", \\\"{x:850,y:655,t:1527613884245};\\\", \\\"{x:851,y:657,t:1527613884262};\\\", \\\"{x:851,y:659,t:1527613884279};\\\", \\\"{x:851,y:661,t:1527613884296};\\\", \\\"{x:851,y:663,t:1527613884312};\\\", \\\"{x:851,y:665,t:1527613884329};\\\", \\\"{x:851,y:666,t:1527613884346};\\\", \\\"{x:851,y:668,t:1527613884363};\\\", \\\"{x:851,y:669,t:1527613884379};\\\", \\\"{x:852,y:670,t:1527613884396};\\\", \\\"{x:852,y:671,t:1527613884412};\\\", \\\"{x:852,y:672,t:1527613884429};\\\", \\\"{x:854,y:674,t:1527613884445};\\\", \\\"{x:855,y:675,t:1527613884462};\\\", \\\"{x:856,y:676,t:1527613884494};\\\", \\\"{x:857,y:677,t:1527613884517};\\\", \\\"{x:858,y:677,t:1527613884529};\\\", \\\"{x:859,y:678,t:1527613884546};\\\", \\\"{x:860,y:678,t:1527613884622};\\\", \\\"{x:861,y:679,t:1527613884654};\\\", \\\"{x:863,y:680,t:1527613884686};\\\", \\\"{x:864,y:681,t:1527613884696};\\\", \\\"{x:865,y:682,t:1527613884719};\\\", \\\"{x:866,y:683,t:1527613884799};\\\", \\\"{x:867,y:683,t:1527613884822};\\\", \\\"{x:867,y:684,t:1527613884847};\\\", \\\"{x:867,y:685,t:1527613884879};\\\", \\\"{x:867,y:687,t:1527613885615};\\\", \\\"{x:867,y:688,t:1527613885630};\\\", \\\"{x:866,y:689,t:1527613885647};\\\", \\\"{x:866,y:690,t:1527613885663};\\\", \\\"{x:866,y:691,t:1527613885680};\\\", \\\"{x:866,y:693,t:1527613885696};\\\", \\\"{x:866,y:694,t:1527613885713};\\\", \\\"{x:864,y:695,t:1527613885731};\\\", \\\"{x:864,y:696,t:1527613885747};\\\", \\\"{x:864,y:698,t:1527613887871};\\\", \\\"{x:864,y:704,t:1527613887883};\\\", \\\"{x:872,y:720,t:1527613887899};\\\", \\\"{x:888,y:739,t:1527613887915};\\\", \\\"{x:911,y:757,t:1527613887933};\\\", \\\"{x:934,y:772,t:1527613887949};\\\", \\\"{x:950,y:785,t:1527613887965};\\\", \\\"{x:981,y:801,t:1527613887983};\\\", \\\"{x:995,y:809,t:1527613887998};\\\", \\\"{x:1001,y:813,t:1527613888016};\\\", \\\"{x:1003,y:817,t:1527613888033};\\\", \\\"{x:1003,y:819,t:1527613888054};\\\", \\\"{x:1003,y:822,t:1527613888070};\\\", \\\"{x:1004,y:823,t:1527613888087};\\\", \\\"{x:1004,y:824,t:1527613888100};\\\", \\\"{x:1004,y:829,t:1527613888116};\\\", \\\"{x:1006,y:834,t:1527613888133};\\\", \\\"{x:1011,y:846,t:1527613888150};\\\", \\\"{x:1016,y:859,t:1527613888166};\\\", \\\"{x:1026,y:872,t:1527613888182};\\\", \\\"{x:1027,y:876,t:1527613888199};\\\", \\\"{x:1030,y:880,t:1527613888216};\\\", \\\"{x:1034,y:886,t:1527613888233};\\\", \\\"{x:1037,y:888,t:1527613888250};\\\", \\\"{x:1045,y:893,t:1527613888266};\\\", \\\"{x:1054,y:896,t:1527613888283};\\\", \\\"{x:1057,y:896,t:1527613888300};\\\", \\\"{x:1058,y:896,t:1527613888383};\\\", \\\"{x:1059,y:895,t:1527613888399};\\\", \\\"{x:1059,y:893,t:1527613888415};\\\", \\\"{x:1060,y:893,t:1527613888432};\\\", \\\"{x:1061,y:892,t:1527613888449};\\\", \\\"{x:1062,y:892,t:1527613888466};\\\", \\\"{x:1064,y:892,t:1527613888583};\\\", \\\"{x:1065,y:892,t:1527613888606};\\\", \\\"{x:1066,y:891,t:1527613888631};\\\", \\\"{x:1067,y:890,t:1527613889335};\\\", \\\"{x:1067,y:889,t:1527613890567};\\\", \\\"{x:1063,y:887,t:1527613890585};\\\", \\\"{x:1062,y:886,t:1527613890602};\\\", \\\"{x:1061,y:886,t:1527613890618};\\\", \\\"{x:1061,y:884,t:1527613891279};\\\", \\\"{x:1061,y:882,t:1527613891286};\\\", \\\"{x:1062,y:880,t:1527613891302};\\\", \\\"{x:1063,y:875,t:1527613891319};\\\", \\\"{x:1064,y:868,t:1527613891335};\\\", \\\"{x:1065,y:863,t:1527613891352};\\\", \\\"{x:1065,y:859,t:1527613891368};\\\", \\\"{x:1065,y:856,t:1527613891386};\\\", \\\"{x:1065,y:853,t:1527613891401};\\\", \\\"{x:1066,y:849,t:1527613891418};\\\", \\\"{x:1067,y:841,t:1527613891436};\\\", \\\"{x:1067,y:835,t:1527613891452};\\\", \\\"{x:1067,y:829,t:1527613891469};\\\", \\\"{x:1068,y:826,t:1527613891486};\\\", \\\"{x:1068,y:825,t:1527613891501};\\\", \\\"{x:1068,y:824,t:1527613891518};\\\", \\\"{x:1068,y:823,t:1527613891607};\\\", \\\"{x:1068,y:822,t:1527613891623};\\\", \\\"{x:1068,y:820,t:1527613891636};\\\", \\\"{x:1068,y:816,t:1527613891652};\\\", \\\"{x:1068,y:806,t:1527613891669};\\\", \\\"{x:1068,y:789,t:1527613891687};\\\", \\\"{x:1069,y:782,t:1527613891702};\\\", \\\"{x:1070,y:770,t:1527613891718};\\\", \\\"{x:1071,y:762,t:1527613891735};\\\", \\\"{x:1074,y:753,t:1527613891752};\\\", \\\"{x:1075,y:748,t:1527613891769};\\\", \\\"{x:1075,y:744,t:1527613891786};\\\", \\\"{x:1075,y:743,t:1527613891803};\\\", \\\"{x:1075,y:741,t:1527613891819};\\\", \\\"{x:1075,y:740,t:1527613891836};\\\", \\\"{x:1075,y:739,t:1527613891853};\\\", \\\"{x:1075,y:738,t:1527613891976};\\\", \\\"{x:1075,y:736,t:1527613891998};\\\", \\\"{x:1075,y:735,t:1527613892007};\\\", \\\"{x:1075,y:733,t:1527613892019};\\\", \\\"{x:1075,y:731,t:1527613892036};\\\", \\\"{x:1075,y:725,t:1527613892054};\\\", \\\"{x:1077,y:717,t:1527613892069};\\\", \\\"{x:1078,y:713,t:1527613892087};\\\", \\\"{x:1078,y:709,t:1527613892102};\\\", \\\"{x:1078,y:707,t:1527613892119};\\\", \\\"{x:1078,y:705,t:1527613892136};\\\", \\\"{x:1078,y:703,t:1527613892153};\\\", \\\"{x:1078,y:702,t:1527613892169};\\\", \\\"{x:1078,y:700,t:1527613892185};\\\", \\\"{x:1078,y:699,t:1527613892246};\\\", \\\"{x:1077,y:698,t:1527613892326};\\\", \\\"{x:1077,y:697,t:1527613892336};\\\", \\\"{x:1076,y:692,t:1527613892353};\\\", \\\"{x:1075,y:685,t:1527613892369};\\\", \\\"{x:1073,y:668,t:1527613892385};\\\", \\\"{x:1067,y:651,t:1527613892403};\\\", \\\"{x:1066,y:640,t:1527613892419};\\\", \\\"{x:1062,y:629,t:1527613892436};\\\", \\\"{x:1061,y:625,t:1527613892453};\\\", \\\"{x:1061,y:622,t:1527613892470};\\\", \\\"{x:1061,y:621,t:1527613892486};\\\", \\\"{x:1061,y:619,t:1527613892534};\\\", \\\"{x:1060,y:619,t:1527613892687};\\\", \\\"{x:1060,y:613,t:1527613892702};\\\", \\\"{x:1060,y:602,t:1527613892720};\\\", \\\"{x:1062,y:593,t:1527613892737};\\\", \\\"{x:1065,y:583,t:1527613892753};\\\", \\\"{x:1067,y:574,t:1527613892770};\\\", \\\"{x:1071,y:562,t:1527613892787};\\\", \\\"{x:1071,y:560,t:1527613892803};\\\", \\\"{x:1071,y:557,t:1527613892820};\\\", \\\"{x:1071,y:555,t:1527613892837};\\\", \\\"{x:1072,y:554,t:1527613892853};\\\", \\\"{x:1073,y:552,t:1527613892871};\\\", \\\"{x:1074,y:551,t:1527613892895};\\\", \\\"{x:1074,y:549,t:1527613892967};\\\", \\\"{x:1074,y:548,t:1527613892975};\\\", \\\"{x:1074,y:545,t:1527613892987};\\\", \\\"{x:1077,y:539,t:1527613893003};\\\", \\\"{x:1077,y:531,t:1527613893020};\\\", \\\"{x:1078,y:523,t:1527613893036};\\\", \\\"{x:1078,y:512,t:1527613893053};\\\", \\\"{x:1078,y:505,t:1527613893070};\\\", \\\"{x:1078,y:502,t:1527613893087};\\\", \\\"{x:1077,y:500,t:1527613893104};\\\", \\\"{x:1077,y:499,t:1527613893167};\\\", \\\"{x:1077,y:498,t:1527613893471};\\\", \\\"{x:1081,y:499,t:1527613893487};\\\", \\\"{x:1084,y:505,t:1527613893503};\\\", \\\"{x:1084,y:529,t:1527613893520};\\\", \\\"{x:1077,y:557,t:1527613893536};\\\", \\\"{x:1063,y:592,t:1527613893553};\\\", \\\"{x:1041,y:637,t:1527613893570};\\\", \\\"{x:1013,y:683,t:1527613893586};\\\", \\\"{x:996,y:713,t:1527613893604};\\\", \\\"{x:985,y:732,t:1527613893621};\\\", \\\"{x:981,y:737,t:1527613893636};\\\", \\\"{x:977,y:744,t:1527613893654};\\\", \\\"{x:970,y:751,t:1527613893670};\\\", \\\"{x:957,y:759,t:1527613893687};\\\", \\\"{x:941,y:767,t:1527613893704};\\\", \\\"{x:921,y:776,t:1527613893720};\\\", \\\"{x:902,y:786,t:1527613893736};\\\", \\\"{x:883,y:793,t:1527613893754};\\\", \\\"{x:866,y:796,t:1527613893770};\\\", \\\"{x:857,y:798,t:1527613893786};\\\", \\\"{x:853,y:798,t:1527613893803};\\\", \\\"{x:838,y:798,t:1527613893821};\\\", \\\"{x:806,y:792,t:1527613893838};\\\", \\\"{x:791,y:786,t:1527613893854};\\\", \\\"{x:779,y:782,t:1527613893870};\\\", \\\"{x:776,y:778,t:1527613893887};\\\", \\\"{x:772,y:774,t:1527613893903};\\\", \\\"{x:768,y:769,t:1527613893921};\\\", \\\"{x:759,y:754,t:1527613893937};\\\", \\\"{x:751,y:738,t:1527613893953};\\\", \\\"{x:741,y:719,t:1527613893971};\\\", \\\"{x:734,y:703,t:1527613893987};\\\", \\\"{x:727,y:686,t:1527613894004};\\\", \\\"{x:720,y:668,t:1527613894020};\\\", \\\"{x:710,y:645,t:1527613894038};\\\", \\\"{x:705,y:631,t:1527613894055};\\\", \\\"{x:705,y:624,t:1527613894070};\\\", \\\"{x:704,y:621,t:1527613894088};\\\", \\\"{x:703,y:619,t:1527613894102};\\\", \\\"{x:701,y:619,t:1527613894119};\\\", \\\"{x:701,y:618,t:1527613894136};\\\", \\\"{x:699,y:617,t:1527613894262};\\\", \\\"{x:696,y:617,t:1527613894270};\\\", \\\"{x:690,y:616,t:1527613894286};\\\", \\\"{x:684,y:616,t:1527613894303};\\\", \\\"{x:679,y:615,t:1527613894319};\\\", \\\"{x:676,y:615,t:1527613894336};\\\", \\\"{x:673,y:615,t:1527613894354};\\\", \\\"{x:671,y:616,t:1527613894369};\\\", \\\"{x:670,y:616,t:1527613894398};\\\", \\\"{x:669,y:617,t:1527613894414};\\\", \\\"{x:669,y:618,t:1527613894422};\\\", \\\"{x:668,y:619,t:1527613894445};\\\", \\\"{x:668,y:621,t:1527613894495};\\\", \\\"{x:666,y:622,t:1527613894503};\\\", \\\"{x:666,y:623,t:1527613894526};\\\", \\\"{x:664,y:623,t:1527613894542};\\\", \\\"{x:663,y:623,t:1527613894558};\\\", \\\"{x:662,y:624,t:1527613894570};\\\", \\\"{x:658,y:626,t:1527613894587};\\\", \\\"{x:656,y:626,t:1527613894604};\\\", \\\"{x:649,y:627,t:1527613894619};\\\", \\\"{x:639,y:627,t:1527613894637};\\\", \\\"{x:625,y:627,t:1527613894654};\\\", \\\"{x:606,y:624,t:1527613894671};\\\", \\\"{x:595,y:621,t:1527613894687};\\\", \\\"{x:587,y:620,t:1527613894704};\\\", \\\"{x:584,y:620,t:1527613894721};\\\", \\\"{x:576,y:620,t:1527613894738};\\\", \\\"{x:566,y:620,t:1527613894754};\\\", \\\"{x:544,y:620,t:1527613894771};\\\", \\\"{x:522,y:620,t:1527613894788};\\\", \\\"{x:512,y:619,t:1527613894804};\\\", \\\"{x:509,y:619,t:1527613894821};\\\", \\\"{x:505,y:619,t:1527613894839};\\\", \\\"{x:504,y:618,t:1527613894854};\\\", \\\"{x:503,y:617,t:1527613894871};\\\", \\\"{x:501,y:616,t:1527613894888};\\\", \\\"{x:497,y:613,t:1527613894905};\\\", \\\"{x:490,y:610,t:1527613894921};\\\", \\\"{x:488,y:607,t:1527613894937};\\\", \\\"{x:483,y:606,t:1527613894953};\\\", \\\"{x:474,y:601,t:1527613894970};\\\", \\\"{x:467,y:600,t:1527613894988};\\\", \\\"{x:457,y:596,t:1527613895005};\\\", \\\"{x:447,y:592,t:1527613895020};\\\", \\\"{x:431,y:588,t:1527613895038};\\\", \\\"{x:422,y:585,t:1527613895054};\\\", \\\"{x:417,y:583,t:1527613895071};\\\", \\\"{x:414,y:582,t:1527613895088};\\\", \\\"{x:412,y:580,t:1527613895103};\\\", \\\"{x:410,y:579,t:1527613895121};\\\", \\\"{x:407,y:577,t:1527613895138};\\\", \\\"{x:400,y:572,t:1527613895153};\\\", \\\"{x:391,y:566,t:1527613895170};\\\", \\\"{x:384,y:561,t:1527613895189};\\\", \\\"{x:378,y:558,t:1527613895204};\\\", \\\"{x:374,y:555,t:1527613895221};\\\", \\\"{x:374,y:554,t:1527613895237};\\\", \\\"{x:373,y:554,t:1527613895279};\\\", \\\"{x:373,y:552,t:1527613895303};\\\", \\\"{x:373,y:550,t:1527613895319};\\\", \\\"{x:372,y:548,t:1527613895338};\\\", \\\"{x:372,y:546,t:1527613895355};\\\", \\\"{x:372,y:544,t:1527613895372};\\\", \\\"{x:372,y:543,t:1527613895388};\\\", \\\"{x:372,y:542,t:1527613895429};\\\", \\\"{x:372,y:540,t:1527613895446};\\\", \\\"{x:372,y:539,t:1527613895461};\\\", \\\"{x:373,y:537,t:1527613895472};\\\", \\\"{x:375,y:536,t:1527613895488};\\\", \\\"{x:376,y:535,t:1527613895518};\\\", \\\"{x:376,y:536,t:1527613900302};\\\", \\\"{x:376,y:550,t:1527613900311};\\\", \\\"{x:376,y:565,t:1527613900326};\\\", \\\"{x:385,y:610,t:1527613900343};\\\", \\\"{x:398,y:648,t:1527613900376};\\\", \\\"{x:401,y:663,t:1527613900391};\\\", \\\"{x:401,y:673,t:1527613900409};\\\", \\\"{x:401,y:685,t:1527613900425};\\\", \\\"{x:396,y:703,t:1527613900442};\\\", \\\"{x:392,y:722,t:1527613900459};\\\", \\\"{x:383,y:740,t:1527613900474};\\\", \\\"{x:380,y:751,t:1527613900491};\\\", \\\"{x:378,y:756,t:1527613900509};\\\", \\\"{x:378,y:757,t:1527613900525};\\\", \\\"{x:378,y:758,t:1527613900542};\\\", \\\"{x:378,y:759,t:1527613900558};\\\", \\\"{x:378,y:760,t:1527613900574};\\\", \\\"{x:382,y:761,t:1527613900592};\\\", \\\"{x:399,y:764,t:1527613900607};\\\", \\\"{x:414,y:765,t:1527613900625};\\\", \\\"{x:425,y:765,t:1527613900642};\\\", \\\"{x:432,y:765,t:1527613900658};\\\", \\\"{x:439,y:764,t:1527613900675};\\\", \\\"{x:443,y:761,t:1527613900692};\\\", \\\"{x:447,y:759,t:1527613900708};\\\", \\\"{x:450,y:757,t:1527613900725};\\\", \\\"{x:455,y:753,t:1527613900743};\\\", \\\"{x:456,y:753,t:1527613900757};\\\", \\\"{x:456,y:752,t:1527613900814};\\\", \\\"{x:457,y:752,t:1527613900826};\\\", \\\"{x:460,y:750,t:1527613900842};\\\", \\\"{x:463,y:749,t:1527613900859};\\\", \\\"{x:467,y:747,t:1527613900876};\\\", \\\"{x:472,y:745,t:1527613900891};\\\", \\\"{x:474,y:743,t:1527613900908};\\\", \\\"{x:480,y:740,t:1527613900925};\\\", \\\"{x:481,y:739,t:1527613900950};\\\", \\\"{x:480,y:739,t:1527613901830};\\\", \\\"{x:479,y:739,t:1527613902174};\\\" ] }, { \\\"rt\\\": 38423, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 265759, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:479,y:740,t:1527613905271};\\\", \\\"{x:475,y:744,t:1527613905298};\\\", \\\"{x:475,y:750,t:1527613905312};\\\", \\\"{x:475,y:754,t:1527613905329};\\\", \\\"{x:475,y:757,t:1527613905346};\\\", \\\"{x:475,y:761,t:1527613905362};\\\", \\\"{x:475,y:764,t:1527613905379};\\\", \\\"{x:475,y:768,t:1527613905395};\\\", \\\"{x:475,y:772,t:1527613905411};\\\", \\\"{x:477,y:779,t:1527613905429};\\\", \\\"{x:482,y:787,t:1527613905445};\\\", \\\"{x:489,y:794,t:1527613905462};\\\", \\\"{x:496,y:800,t:1527613905479};\\\", \\\"{x:503,y:809,t:1527613905496};\\\", \\\"{x:513,y:817,t:1527613905512};\\\", \\\"{x:526,y:826,t:1527613905529};\\\", \\\"{x:545,y:839,t:1527613905546};\\\", \\\"{x:564,y:850,t:1527613905563};\\\", \\\"{x:581,y:858,t:1527613905579};\\\", \\\"{x:598,y:866,t:1527613905596};\\\", \\\"{x:615,y:871,t:1527613905613};\\\", \\\"{x:631,y:878,t:1527613905630};\\\", \\\"{x:658,y:887,t:1527613905646};\\\", \\\"{x:673,y:891,t:1527613905663};\\\", \\\"{x:679,y:894,t:1527613905679};\\\", \\\"{x:684,y:894,t:1527613905696};\\\", \\\"{x:686,y:895,t:1527613905714};\\\", \\\"{x:690,y:896,t:1527613905730};\\\", \\\"{x:695,y:899,t:1527613905746};\\\", \\\"{x:698,y:902,t:1527613905764};\\\", \\\"{x:703,y:905,t:1527613905779};\\\", \\\"{x:709,y:908,t:1527613905797};\\\", \\\"{x:717,y:912,t:1527613905814};\\\", \\\"{x:721,y:913,t:1527613905830};\\\", \\\"{x:728,y:915,t:1527613905846};\\\", \\\"{x:729,y:917,t:1527613907231};\\\", \\\"{x:729,y:916,t:1527613910655};\\\", \\\"{x:729,y:915,t:1527613910669};\\\", \\\"{x:729,y:913,t:1527613910687};\\\", \\\"{x:729,y:912,t:1527613910710};\\\", \\\"{x:729,y:911,t:1527613914791};\\\", \\\"{x:728,y:911,t:1527613914871};\\\", \\\"{x:727,y:911,t:1527613914910};\\\", \\\"{x:727,y:912,t:1527613914924};\\\", \\\"{x:725,y:912,t:1527613916145};\\\", \\\"{x:725,y:913,t:1527613916545};\\\", \\\"{x:722,y:914,t:1527613916562};\\\", \\\"{x:719,y:916,t:1527613916578};\\\", \\\"{x:718,y:916,t:1527613916595};\\\", \\\"{x:716,y:917,t:1527613916611};\\\", \\\"{x:715,y:917,t:1527613924649};\\\", \\\"{x:713,y:917,t:1527613927607};\\\", \\\"{x:713,y:916,t:1527613929336};\\\", \\\"{x:714,y:916,t:1527613929368};\\\", \\\"{x:715,y:915,t:1527613929375};\\\", \\\"{x:716,y:915,t:1527613929392};\\\", \\\"{x:719,y:913,t:1527613929410};\\\", \\\"{x:721,y:912,t:1527613929431};\\\", \\\"{x:722,y:912,t:1527613929442};\\\", \\\"{x:723,y:912,t:1527613929459};\\\", \\\"{x:724,y:912,t:1527613929503};\\\", \\\"{x:724,y:911,t:1527613929511};\\\", \\\"{x:725,y:910,t:1527613929526};\\\", \\\"{x:727,y:908,t:1527613929543};\\\", \\\"{x:728,y:908,t:1527613929559};\\\", \\\"{x:731,y:906,t:1527613929575};\\\", \\\"{x:734,y:905,t:1527613929592};\\\", \\\"{x:735,y:903,t:1527613929615};\\\", \\\"{x:737,y:903,t:1527613929627};\\\", \\\"{x:741,y:901,t:1527613929642};\\\", \\\"{x:746,y:899,t:1527613929659};\\\", \\\"{x:754,y:897,t:1527613929676};\\\", \\\"{x:767,y:897,t:1527613929692};\\\", \\\"{x:779,y:897,t:1527613929710};\\\", \\\"{x:794,y:896,t:1527613929726};\\\", \\\"{x:813,y:894,t:1527613929743};\\\", \\\"{x:834,y:894,t:1527613929760};\\\", \\\"{x:869,y:893,t:1527613929777};\\\", \\\"{x:911,y:893,t:1527613929793};\\\", \\\"{x:955,y:893,t:1527613929810};\\\", \\\"{x:1005,y:888,t:1527613929827};\\\", \\\"{x:1036,y:888,t:1527613929843};\\\", \\\"{x:1059,y:888,t:1527613929859};\\\", \\\"{x:1081,y:887,t:1527613929877};\\\", \\\"{x:1101,y:887,t:1527613929894};\\\", \\\"{x:1122,y:887,t:1527613929910};\\\", \\\"{x:1146,y:881,t:1527613929927};\\\", \\\"{x:1178,y:874,t:1527613929943};\\\", \\\"{x:1193,y:871,t:1527613929960};\\\", \\\"{x:1209,y:869,t:1527613929976};\\\", \\\"{x:1218,y:863,t:1527613929994};\\\", \\\"{x:1235,y:860,t:1527613930010};\\\", \\\"{x:1250,y:854,t:1527613930026};\\\", \\\"{x:1258,y:845,t:1527613930044};\\\", \\\"{x:1261,y:835,t:1527613930061};\\\", \\\"{x:1262,y:826,t:1527613930076};\\\", \\\"{x:1267,y:817,t:1527613930093};\\\", \\\"{x:1271,y:809,t:1527613930111};\\\", \\\"{x:1274,y:801,t:1527613930127};\\\", \\\"{x:1274,y:795,t:1527613930143};\\\", \\\"{x:1274,y:794,t:1527613930160};\\\", \\\"{x:1276,y:789,t:1527613930177};\\\", \\\"{x:1278,y:786,t:1527613930193};\\\", \\\"{x:1281,y:782,t:1527613930210};\\\", \\\"{x:1284,y:781,t:1527613930226};\\\", \\\"{x:1287,y:779,t:1527613930244};\\\", \\\"{x:1290,y:778,t:1527613930260};\\\", \\\"{x:1298,y:778,t:1527613930277};\\\", \\\"{x:1310,y:775,t:1527613930294};\\\", \\\"{x:1318,y:774,t:1527613930310};\\\", \\\"{x:1323,y:772,t:1527613930327};\\\", \\\"{x:1325,y:772,t:1527613930408};\\\", \\\"{x:1326,y:771,t:1527613930423};\\\", \\\"{x:1327,y:770,t:1527613930448};\\\", \\\"{x:1328,y:770,t:1527613930536};\\\", \\\"{x:1329,y:770,t:1527613930543};\\\", \\\"{x:1329,y:769,t:1527613930584};\\\", \\\"{x:1330,y:769,t:1527613930594};\\\", \\\"{x:1331,y:769,t:1527613930610};\\\", \\\"{x:1332,y:769,t:1527613930639};\\\", \\\"{x:1333,y:768,t:1527613930647};\\\", \\\"{x:1333,y:767,t:1527613930660};\\\", \\\"{x:1336,y:767,t:1527613930678};\\\", \\\"{x:1338,y:766,t:1527613930695};\\\", \\\"{x:1339,y:766,t:1527613930710};\\\", \\\"{x:1339,y:764,t:1527613930776};\\\", \\\"{x:1339,y:763,t:1527613930783};\\\", \\\"{x:1339,y:760,t:1527613930794};\\\", \\\"{x:1338,y:757,t:1527613930811};\\\", \\\"{x:1338,y:752,t:1527613930827};\\\", \\\"{x:1338,y:746,t:1527613930844};\\\", \\\"{x:1338,y:741,t:1527613930861};\\\", \\\"{x:1336,y:728,t:1527613930878};\\\", \\\"{x:1327,y:714,t:1527613930894};\\\", \\\"{x:1320,y:707,t:1527613930911};\\\", \\\"{x:1317,y:702,t:1527613930927};\\\", \\\"{x:1315,y:700,t:1527613930945};\\\", \\\"{x:1315,y:699,t:1527613930983};\\\", \\\"{x:1316,y:699,t:1527613931039};\\\", \\\"{x:1312,y:699,t:1527613931152};\\\", \\\"{x:1307,y:699,t:1527613931162};\\\", \\\"{x:1289,y:703,t:1527613931177};\\\", \\\"{x:1266,y:707,t:1527613931194};\\\", \\\"{x:1228,y:709,t:1527613931212};\\\", \\\"{x:1177,y:709,t:1527613931228};\\\", \\\"{x:1108,y:709,t:1527613931244};\\\", \\\"{x:1060,y:709,t:1527613931262};\\\", \\\"{x:1020,y:709,t:1527613931279};\\\", \\\"{x:988,y:708,t:1527613931295};\\\", \\\"{x:952,y:699,t:1527613931311};\\\", \\\"{x:942,y:696,t:1527613931328};\\\", \\\"{x:939,y:694,t:1527613931344};\\\", \\\"{x:935,y:692,t:1527613931362};\\\", \\\"{x:932,y:690,t:1527613931378};\\\", \\\"{x:927,y:688,t:1527613931394};\\\", \\\"{x:922,y:686,t:1527613931412};\\\", \\\"{x:915,y:685,t:1527613931428};\\\", \\\"{x:907,y:685,t:1527613931444};\\\", \\\"{x:899,y:684,t:1527613931461};\\\", \\\"{x:886,y:684,t:1527613931479};\\\", \\\"{x:862,y:684,t:1527613931495};\\\", \\\"{x:841,y:684,t:1527613931511};\\\", \\\"{x:819,y:683,t:1527613931528};\\\", \\\"{x:796,y:678,t:1527613931545};\\\", \\\"{x:770,y:673,t:1527613931562};\\\", \\\"{x:744,y:666,t:1527613931579};\\\", \\\"{x:723,y:658,t:1527613931595};\\\", \\\"{x:697,y:649,t:1527613931611};\\\", \\\"{x:674,y:636,t:1527613931629};\\\", \\\"{x:639,y:595,t:1527613931645};\\\", \\\"{x:616,y:578,t:1527613931662};\\\", \\\"{x:602,y:568,t:1527613931678};\\\", \\\"{x:595,y:563,t:1527613931702};\\\", \\\"{x:594,y:560,t:1527613931719};\\\", \\\"{x:593,y:559,t:1527613931736};\\\", \\\"{x:593,y:558,t:1527613931784};\\\", \\\"{x:593,y:556,t:1527613931800};\\\", \\\"{x:593,y:555,t:1527613931816};\\\", \\\"{x:594,y:554,t:1527613931823};\\\", \\\"{x:595,y:553,t:1527613931837};\\\", \\\"{x:598,y:552,t:1527613931852};\\\", \\\"{x:604,y:548,t:1527613931870};\\\", \\\"{x:611,y:544,t:1527613931886};\\\", \\\"{x:616,y:541,t:1527613931903};\\\", \\\"{x:624,y:535,t:1527613931920};\\\", \\\"{x:629,y:531,t:1527613931935};\\\", \\\"{x:636,y:525,t:1527613931953};\\\", \\\"{x:648,y:520,t:1527613931971};\\\", \\\"{x:661,y:515,t:1527613931987};\\\", \\\"{x:677,y:508,t:1527613932002};\\\", \\\"{x:689,y:503,t:1527613932019};\\\", \\\"{x:697,y:499,t:1527613932036};\\\", \\\"{x:706,y:494,t:1527613932052};\\\", \\\"{x:713,y:491,t:1527613932070};\\\", \\\"{x:725,y:486,t:1527613932088};\\\", \\\"{x:735,y:483,t:1527613932102};\\\", \\\"{x:754,y:476,t:1527613932120};\\\", \\\"{x:765,y:470,t:1527613932137};\\\", \\\"{x:774,y:467,t:1527613932153};\\\", \\\"{x:781,y:465,t:1527613932169};\\\", \\\"{x:787,y:465,t:1527613932187};\\\", \\\"{x:798,y:462,t:1527613932203};\\\", \\\"{x:802,y:462,t:1527613932220};\\\", \\\"{x:804,y:461,t:1527613932236};\\\", \\\"{x:805,y:461,t:1527613932255};\\\", \\\"{x:806,y:461,t:1527613932269};\\\", \\\"{x:812,y:463,t:1527613932287};\\\", \\\"{x:815,y:466,t:1527613932303};\\\", \\\"{x:822,y:471,t:1527613932320};\\\", \\\"{x:824,y:472,t:1527613932336};\\\", \\\"{x:826,y:474,t:1527613932353};\\\", \\\"{x:829,y:478,t:1527613932370};\\\", \\\"{x:834,y:479,t:1527613932387};\\\", \\\"{x:836,y:482,t:1527613932402};\\\", \\\"{x:838,y:484,t:1527613932420};\\\", \\\"{x:841,y:486,t:1527613932436};\\\", \\\"{x:847,y:489,t:1527613932454};\\\", \\\"{x:852,y:492,t:1527613932469};\\\", \\\"{x:854,y:492,t:1527613932486};\\\", \\\"{x:856,y:493,t:1527613932503};\\\", \\\"{x:856,y:494,t:1527613932544};\\\", \\\"{x:857,y:495,t:1527613932575};\\\", \\\"{x:857,y:497,t:1527613932616};\\\", \\\"{x:857,y:498,t:1527613932632};\\\", \\\"{x:855,y:499,t:1527613932656};\\\", \\\"{x:853,y:500,t:1527613932688};\\\", \\\"{x:851,y:500,t:1527613932720};\\\", \\\"{x:849,y:500,t:1527613932728};\\\", \\\"{x:847,y:500,t:1527613932736};\\\", \\\"{x:842,y:500,t:1527613932754};\\\", \\\"{x:839,y:500,t:1527613932771};\\\", \\\"{x:835,y:499,t:1527613932786};\\\", \\\"{x:834,y:497,t:1527613932804};\\\", \\\"{x:833,y:497,t:1527613933136};\\\", \\\"{x:831,y:500,t:1527613933143};\\\", \\\"{x:821,y:506,t:1527613933153};\\\", \\\"{x:805,y:512,t:1527613933171};\\\", \\\"{x:794,y:517,t:1527613933186};\\\", \\\"{x:785,y:519,t:1527613933204};\\\", \\\"{x:781,y:521,t:1527613933221};\\\", \\\"{x:766,y:529,t:1527613933238};\\\", \\\"{x:754,y:537,t:1527613933253};\\\", \\\"{x:736,y:544,t:1527613933270};\\\", \\\"{x:711,y:552,t:1527613933287};\\\", \\\"{x:648,y:575,t:1527613933304};\\\", \\\"{x:601,y:587,t:1527613933321};\\\", \\\"{x:557,y:598,t:1527613933338};\\\", \\\"{x:523,y:608,t:1527613933354};\\\", \\\"{x:500,y:613,t:1527613933370};\\\", \\\"{x:488,y:618,t:1527613933388};\\\", \\\"{x:474,y:622,t:1527613933403};\\\", \\\"{x:467,y:625,t:1527613933420};\\\", \\\"{x:466,y:627,t:1527613933438};\\\", \\\"{x:464,y:628,t:1527613933454};\\\", \\\"{x:463,y:630,t:1527613933471};\\\", \\\"{x:461,y:633,t:1527613933488};\\\", \\\"{x:459,y:635,t:1527613933504};\\\", \\\"{x:457,y:635,t:1527613933520};\\\", \\\"{x:456,y:635,t:1527613933538};\\\", \\\"{x:455,y:636,t:1527613933554};\\\", \\\"{x:452,y:636,t:1527613933571};\\\", \\\"{x:446,y:636,t:1527613933587};\\\", \\\"{x:435,y:636,t:1527613933603};\\\", \\\"{x:424,y:636,t:1527613933621};\\\", \\\"{x:412,y:634,t:1527613933638};\\\", \\\"{x:394,y:627,t:1527613933654};\\\", \\\"{x:376,y:623,t:1527613933671};\\\", \\\"{x:348,y:612,t:1527613933688};\\\", \\\"{x:334,y:605,t:1527613933704};\\\", \\\"{x:317,y:601,t:1527613933721};\\\", \\\"{x:302,y:596,t:1527613933738};\\\", \\\"{x:294,y:594,t:1527613933755};\\\", \\\"{x:285,y:591,t:1527613933771};\\\", \\\"{x:274,y:589,t:1527613933788};\\\", \\\"{x:267,y:585,t:1527613933805};\\\", \\\"{x:260,y:583,t:1527613933820};\\\", \\\"{x:253,y:581,t:1527613933838};\\\", \\\"{x:241,y:576,t:1527613933854};\\\", \\\"{x:229,y:573,t:1527613933871};\\\", \\\"{x:205,y:567,t:1527613933888};\\\", \\\"{x:188,y:562,t:1527613933905};\\\", \\\"{x:171,y:560,t:1527613933921};\\\", \\\"{x:157,y:560,t:1527613933938};\\\", \\\"{x:146,y:557,t:1527613933955};\\\", \\\"{x:133,y:555,t:1527613933971};\\\", \\\"{x:123,y:553,t:1527613933988};\\\", \\\"{x:114,y:552,t:1527613934004};\\\", \\\"{x:109,y:552,t:1527613934021};\\\", \\\"{x:107,y:551,t:1527613934038};\\\", \\\"{x:106,y:551,t:1527613934055};\\\", \\\"{x:106,y:550,t:1527613934095};\\\", \\\"{x:107,y:549,t:1527613934105};\\\", \\\"{x:113,y:546,t:1527613934121};\\\", \\\"{x:121,y:542,t:1527613934138};\\\", \\\"{x:124,y:540,t:1527613934155};\\\", \\\"{x:130,y:536,t:1527613934171};\\\", \\\"{x:134,y:536,t:1527613934187};\\\", \\\"{x:135,y:534,t:1527613934204};\\\", \\\"{x:136,y:534,t:1527613934239};\\\", \\\"{x:137,y:534,t:1527613934254};\\\", \\\"{x:141,y:534,t:1527613934271};\\\", \\\"{x:145,y:534,t:1527613934288};\\\", \\\"{x:146,y:534,t:1527613934304};\\\", \\\"{x:148,y:534,t:1527613934327};\\\", \\\"{x:149,y:534,t:1527613934352};\\\", \\\"{x:151,y:534,t:1527613934376};\\\", \\\"{x:152,y:534,t:1527613934388};\\\", \\\"{x:159,y:538,t:1527613934404};\\\", \\\"{x:165,y:540,t:1527613934421};\\\", \\\"{x:166,y:540,t:1527613934438};\\\", \\\"{x:167,y:540,t:1527613934463};\\\", \\\"{x:167,y:541,t:1527613934559};\\\", \\\"{x:172,y:542,t:1527613934960};\\\", \\\"{x:179,y:552,t:1527613934972};\\\", \\\"{x:192,y:571,t:1527613934989};\\\", \\\"{x:214,y:598,t:1527613935006};\\\", \\\"{x:246,y:629,t:1527613935022};\\\", \\\"{x:278,y:654,t:1527613935040};\\\", \\\"{x:327,y:684,t:1527613935055};\\\", \\\"{x:374,y:712,t:1527613935072};\\\", \\\"{x:393,y:724,t:1527613935088};\\\", \\\"{x:412,y:736,t:1527613935105};\\\", \\\"{x:427,y:750,t:1527613935122};\\\", \\\"{x:440,y:761,t:1527613935139};\\\", \\\"{x:453,y:771,t:1527613935155};\\\", \\\"{x:467,y:781,t:1527613935172};\\\", \\\"{x:481,y:788,t:1527613935188};\\\", \\\"{x:495,y:793,t:1527613935204};\\\", \\\"{x:509,y:802,t:1527613935221};\\\", \\\"{x:533,y:810,t:1527613935238};\\\", \\\"{x:553,y:820,t:1527613935255};\\\", \\\"{x:577,y:827,t:1527613935272};\\\", \\\"{x:585,y:831,t:1527613935288};\\\", \\\"{x:592,y:834,t:1527613935305};\\\", \\\"{x:599,y:836,t:1527613935321};\\\", \\\"{x:604,y:837,t:1527613935338};\\\", \\\"{x:610,y:838,t:1527613935355};\\\", \\\"{x:614,y:841,t:1527613935371};\\\", \\\"{x:618,y:841,t:1527613935388};\\\", \\\"{x:620,y:841,t:1527613935405};\\\", \\\"{x:622,y:841,t:1527613935420};\\\", \\\"{x:625,y:841,t:1527613935437};\\\", \\\"{x:628,y:841,t:1527613935454};\\\", \\\"{x:631,y:841,t:1527613935471};\\\", \\\"{x:640,y:840,t:1527613935487};\\\", \\\"{x:645,y:838,t:1527613935505};\\\", \\\"{x:648,y:836,t:1527613935521};\\\", \\\"{x:651,y:836,t:1527613935538};\\\", \\\"{x:652,y:834,t:1527613935555};\\\", \\\"{x:654,y:834,t:1527613935571};\\\", \\\"{x:655,y:833,t:1527613935587};\\\", \\\"{x:657,y:833,t:1527613935605};\\\", \\\"{x:658,y:831,t:1527613935621};\\\", \\\"{x:659,y:830,t:1527613935638};\\\", \\\"{x:661,y:828,t:1527613935654};\\\", \\\"{x:662,y:827,t:1527613935672};\\\", \\\"{x:663,y:826,t:1527613935711};\\\", \\\"{x:664,y:825,t:1527613935727};\\\", \\\"{x:664,y:824,t:1527613935738};\\\", \\\"{x:669,y:814,t:1527613935754};\\\", \\\"{x:670,y:814,t:1527613940079};\\\", \\\"{x:671,y:813,t:1527613940112};\\\", \\\"{x:671,y:812,t:1527613940119};\\\", \\\"{x:671,y:811,t:1527613940152};\\\", \\\"{x:671,y:810,t:1527613940183};\\\", \\\"{x:671,y:809,t:1527613940200};\\\", \\\"{x:671,y:808,t:1527613940223};\\\", \\\"{x:670,y:808,t:1527613940239};\\\", \\\"{x:668,y:808,t:1527613940247};\\\", \\\"{x:666,y:806,t:1527613940264};\\\", \\\"{x:665,y:805,t:1527613940279};\\\", \\\"{x:657,y:804,t:1527613940296};\\\", \\\"{x:649,y:800,t:1527613940312};\\\", \\\"{x:641,y:797,t:1527613940328};\\\", \\\"{x:633,y:793,t:1527613940346};\\\", \\\"{x:625,y:790,t:1527613940361};\\\", \\\"{x:616,y:781,t:1527613940379};\\\", \\\"{x:604,y:767,t:1527613940395};\\\", \\\"{x:589,y:744,t:1527613940412};\\\", \\\"{x:577,y:729,t:1527613940429};\\\", \\\"{x:570,y:719,t:1527613940445};\\\", \\\"{x:570,y:716,t:1527613940462};\\\", \\\"{x:569,y:716,t:1527613940480};\\\", \\\"{x:569,y:715,t:1527613940495};\\\", \\\"{x:568,y:715,t:1527613940631};\\\", \\\"{x:566,y:715,t:1527613940647};\\\", \\\"{x:565,y:715,t:1527613940662};\\\", \\\"{x:565,y:716,t:1527613940677};\\\", \\\"{x:562,y:717,t:1527613940695};\\\", \\\"{x:557,y:723,t:1527613940711};\\\", \\\"{x:553,y:726,t:1527613940728};\\\", \\\"{x:551,y:726,t:1527613940745};\\\", \\\"{x:548,y:727,t:1527613940759};\\\", \\\"{x:546,y:728,t:1527613940777};\\\", \\\"{x:545,y:729,t:1527613940793};\\\", \\\"{x:542,y:730,t:1527613940810};\\\", \\\"{x:540,y:731,t:1527613940827};\\\", \\\"{x:539,y:731,t:1527613940863};\\\", \\\"{x:537,y:732,t:1527613940876};\\\" ] }, { \\\"rt\\\": 57958, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 324922, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -X -B -O -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:734,t:1527613943000};\\\", \\\"{x:537,y:737,t:1527613943012};\\\", \\\"{x:536,y:745,t:1527613943028};\\\", \\\"{x:536,y:752,t:1527613943045};\\\", \\\"{x:536,y:757,t:1527613943063};\\\", \\\"{x:536,y:764,t:1527613943079};\\\", \\\"{x:540,y:773,t:1527613943096};\\\", \\\"{x:549,y:785,t:1527613943112};\\\", \\\"{x:558,y:795,t:1527613943129};\\\", \\\"{x:561,y:800,t:1527613943178};\\\", \\\"{x:565,y:805,t:1527613943195};\\\", \\\"{x:567,y:805,t:1527613943212};\\\", \\\"{x:568,y:806,t:1527613943264};\\\", \\\"{x:569,y:806,t:1527613943278};\\\", \\\"{x:570,y:806,t:1527613943295};\\\", \\\"{x:570,y:807,t:1527613944121};\\\", \\\"{x:572,y:807,t:1527613944130};\\\", \\\"{x:576,y:807,t:1527613944147};\\\", \\\"{x:581,y:807,t:1527613944163};\\\", \\\"{x:585,y:806,t:1527613944180};\\\", \\\"{x:589,y:805,t:1527613944197};\\\", \\\"{x:593,y:805,t:1527613944213};\\\", \\\"{x:596,y:804,t:1527613944230};\\\", \\\"{x:599,y:804,t:1527613944246};\\\", \\\"{x:600,y:803,t:1527613944263};\\\", \\\"{x:602,y:802,t:1527613944288};\\\", \\\"{x:603,y:802,t:1527613944320};\\\", \\\"{x:604,y:802,t:1527613944330};\\\", \\\"{x:606,y:801,t:1527613944346};\\\", \\\"{x:608,y:799,t:1527613944363};\\\", \\\"{x:611,y:798,t:1527613944379};\\\", \\\"{x:613,y:798,t:1527613944397};\\\", \\\"{x:616,y:795,t:1527613944414};\\\", \\\"{x:621,y:794,t:1527613944430};\\\", \\\"{x:626,y:792,t:1527613944446};\\\", \\\"{x:632,y:790,t:1527613944464};\\\", \\\"{x:641,y:786,t:1527613944480};\\\", \\\"{x:647,y:785,t:1527613944496};\\\", \\\"{x:650,y:785,t:1527613944514};\\\", \\\"{x:656,y:782,t:1527613944529};\\\", \\\"{x:665,y:778,t:1527613944546};\\\", \\\"{x:670,y:777,t:1527613944563};\\\", \\\"{x:678,y:775,t:1527613944579};\\\", \\\"{x:686,y:774,t:1527613944596};\\\", \\\"{x:695,y:773,t:1527613944613};\\\", \\\"{x:702,y:771,t:1527613944629};\\\", \\\"{x:706,y:770,t:1527613944646};\\\", \\\"{x:713,y:769,t:1527613944663};\\\", \\\"{x:713,y:767,t:1527613944719};\\\", \\\"{x:714,y:767,t:1527613944744};\\\", \\\"{x:716,y:766,t:1527613944752};\\\", \\\"{x:717,y:766,t:1527613944764};\\\", \\\"{x:720,y:766,t:1527613944779};\\\", \\\"{x:724,y:765,t:1527613944796};\\\", \\\"{x:731,y:764,t:1527613944814};\\\", \\\"{x:735,y:764,t:1527613944830};\\\", \\\"{x:739,y:764,t:1527613944846};\\\", \\\"{x:743,y:764,t:1527613944864};\\\", \\\"{x:752,y:764,t:1527613944880};\\\", \\\"{x:760,y:764,t:1527613944896};\\\", \\\"{x:772,y:764,t:1527613944913};\\\", \\\"{x:787,y:764,t:1527613944930};\\\", \\\"{x:802,y:764,t:1527613944947};\\\", \\\"{x:811,y:764,t:1527613944964};\\\", \\\"{x:826,y:764,t:1527613944981};\\\", \\\"{x:842,y:764,t:1527613944996};\\\", \\\"{x:856,y:764,t:1527613945013};\\\", \\\"{x:869,y:765,t:1527613945031};\\\", \\\"{x:877,y:767,t:1527613945047};\\\", \\\"{x:894,y:770,t:1527613945064};\\\", \\\"{x:903,y:772,t:1527613945080};\\\", \\\"{x:913,y:773,t:1527613945097};\\\", \\\"{x:925,y:774,t:1527613945113};\\\", \\\"{x:929,y:774,t:1527613945131};\\\", \\\"{x:930,y:774,t:1527613945147};\\\", \\\"{x:932,y:774,t:1527613945889};\\\", \\\"{x:933,y:774,t:1527613945912};\\\", \\\"{x:934,y:774,t:1527613945928};\\\", \\\"{x:936,y:774,t:1527613945937};\\\", \\\"{x:937,y:774,t:1527613945947};\\\", \\\"{x:941,y:774,t:1527613945964};\\\", \\\"{x:946,y:774,t:1527613945981};\\\", \\\"{x:952,y:774,t:1527613945998};\\\", \\\"{x:963,y:774,t:1527613946015};\\\", \\\"{x:971,y:774,t:1527613946030};\\\", \\\"{x:980,y:774,t:1527613946048};\\\", \\\"{x:988,y:774,t:1527613946065};\\\", \\\"{x:994,y:775,t:1527613946081};\\\", \\\"{x:1001,y:776,t:1527613946098};\\\", \\\"{x:1005,y:776,t:1527613946115};\\\", \\\"{x:1011,y:776,t:1527613946131};\\\", \\\"{x:1013,y:776,t:1527613946147};\\\", \\\"{x:1015,y:776,t:1527613946165};\\\", \\\"{x:1018,y:776,t:1527613946181};\\\", \\\"{x:1022,y:776,t:1527613946198};\\\", \\\"{x:1028,y:776,t:1527613946215};\\\", \\\"{x:1038,y:775,t:1527613946231};\\\", \\\"{x:1046,y:775,t:1527613946249};\\\", \\\"{x:1063,y:775,t:1527613946264};\\\", \\\"{x:1080,y:775,t:1527613946281};\\\", \\\"{x:1099,y:775,t:1527613946298};\\\", \\\"{x:1121,y:775,t:1527613946315};\\\", \\\"{x:1147,y:777,t:1527613946332};\\\", \\\"{x:1171,y:779,t:1527613946348};\\\", \\\"{x:1191,y:781,t:1527613946365};\\\", \\\"{x:1204,y:785,t:1527613946382};\\\", \\\"{x:1222,y:789,t:1527613946398};\\\", \\\"{x:1237,y:791,t:1527613946415};\\\", \\\"{x:1250,y:795,t:1527613946431};\\\", \\\"{x:1265,y:798,t:1527613946448};\\\", \\\"{x:1274,y:799,t:1527613946465};\\\", \\\"{x:1280,y:800,t:1527613946482};\\\", \\\"{x:1282,y:800,t:1527613946498};\\\", \\\"{x:1284,y:800,t:1527613946515};\\\", \\\"{x:1285,y:800,t:1527613946553};\\\", \\\"{x:1286,y:800,t:1527613946576};\\\", \\\"{x:1287,y:800,t:1527613946584};\\\", \\\"{x:1288,y:800,t:1527613946599};\\\", \\\"{x:1289,y:800,t:1527613946615};\\\", \\\"{x:1293,y:800,t:1527613946632};\\\", \\\"{x:1296,y:800,t:1527613946648};\\\", \\\"{x:1297,y:800,t:1527613946689};\\\", \\\"{x:1298,y:800,t:1527613946888};\\\", \\\"{x:1299,y:800,t:1527613946928};\\\", \\\"{x:1300,y:800,t:1527613946976};\\\", \\\"{x:1301,y:800,t:1527613946992};\\\", \\\"{x:1302,y:800,t:1527613947024};\\\", \\\"{x:1303,y:801,t:1527613947040};\\\", \\\"{x:1303,y:802,t:1527613947585};\\\", \\\"{x:1304,y:802,t:1527613947599};\\\", \\\"{x:1306,y:803,t:1527613947616};\\\", \\\"{x:1307,y:803,t:1527613947632};\\\", \\\"{x:1309,y:803,t:1527613947649};\\\", \\\"{x:1309,y:805,t:1527613947666};\\\", \\\"{x:1310,y:805,t:1527613947682};\\\", \\\"{x:1311,y:805,t:1527613947705};\\\", \\\"{x:1312,y:805,t:1527613947761};\\\", \\\"{x:1313,y:805,t:1527613947809};\\\", \\\"{x:1314,y:805,t:1527613947824};\\\", \\\"{x:1316,y:805,t:1527613947832};\\\", \\\"{x:1319,y:805,t:1527613947850};\\\", \\\"{x:1321,y:804,t:1527613947866};\\\", \\\"{x:1323,y:802,t:1527613947889};\\\", \\\"{x:1325,y:801,t:1527613947899};\\\", \\\"{x:1325,y:800,t:1527613947916};\\\", \\\"{x:1326,y:799,t:1527613947933};\\\", \\\"{x:1328,y:798,t:1527613947949};\\\", \\\"{x:1330,y:796,t:1527613947966};\\\", \\\"{x:1331,y:795,t:1527613947984};\\\", \\\"{x:1332,y:793,t:1527613948008};\\\", \\\"{x:1333,y:792,t:1527613948025};\\\", \\\"{x:1334,y:791,t:1527613948033};\\\", \\\"{x:1335,y:790,t:1527613948049};\\\", \\\"{x:1335,y:789,t:1527613948066};\\\", \\\"{x:1337,y:786,t:1527613948083};\\\", \\\"{x:1338,y:783,t:1527613948100};\\\", \\\"{x:1339,y:781,t:1527613948116};\\\", \\\"{x:1341,y:779,t:1527613948133};\\\", \\\"{x:1342,y:777,t:1527613948149};\\\", \\\"{x:1342,y:776,t:1527613948167};\\\", \\\"{x:1342,y:774,t:1527613948183};\\\", \\\"{x:1343,y:773,t:1527613948199};\\\", \\\"{x:1344,y:770,t:1527613948216};\\\", \\\"{x:1345,y:769,t:1527613948240};\\\", \\\"{x:1345,y:768,t:1527613948259};\\\", \\\"{x:1346,y:767,t:1527613948283};\\\", \\\"{x:1346,y:766,t:1527613948303};\\\", \\\"{x:1346,y:765,t:1527613948319};\\\", \\\"{x:1347,y:764,t:1527613948336};\\\", \\\"{x:1347,y:763,t:1527613948352};\\\", \\\"{x:1347,y:762,t:1527613948365};\\\", \\\"{x:1348,y:762,t:1527613948382};\\\", \\\"{x:1348,y:761,t:1527613948399};\\\", \\\"{x:1348,y:760,t:1527613948415};\\\", \\\"{x:1348,y:759,t:1527613948432};\\\", \\\"{x:1348,y:758,t:1527613962104};\\\", \\\"{x:1349,y:752,t:1527613962114};\\\", \\\"{x:1351,y:750,t:1527613962128};\\\", \\\"{x:1352,y:748,t:1527613962143};\\\", \\\"{x:1366,y:730,t:1527613962168};\\\", \\\"{x:1386,y:682,t:1527613962176};\\\", \\\"{x:1415,y:596,t:1527613962193};\\\", \\\"{x:1429,y:527,t:1527613962210};\\\", \\\"{x:1441,y:465,t:1527613962227};\\\", \\\"{x:1450,y:411,t:1527613962244};\\\", \\\"{x:1455,y:375,t:1527613962259};\\\", \\\"{x:1463,y:337,t:1527613962276};\\\", \\\"{x:1471,y:310,t:1527613962294};\\\", \\\"{x:1478,y:265,t:1527613962309};\\\", \\\"{x:1491,y:181,t:1527613962326};\\\", \\\"{x:1492,y:161,t:1527613962343};\\\", \\\"{x:1494,y:145,t:1527613962359};\\\", \\\"{x:1502,y:120,t:1527613962376};\\\", \\\"{x:1503,y:106,t:1527613962392};\\\", \\\"{x:1503,y:95,t:1527613962409};\\\", \\\"{x:1503,y:84,t:1527613962426};\\\", \\\"{x:1503,y:77,t:1527613962443};\\\", \\\"{x:1503,y:74,t:1527613962459};\\\", \\\"{x:1503,y:73,t:1527613962476};\\\", \\\"{x:1501,y:75,t:1527613962544};\\\", \\\"{x:1497,y:84,t:1527613962559};\\\", \\\"{x:1486,y:113,t:1527613962576};\\\", \\\"{x:1480,y:124,t:1527613962593};\\\", \\\"{x:1476,y:135,t:1527613962610};\\\", \\\"{x:1475,y:140,t:1527613962626};\\\", \\\"{x:1475,y:146,t:1527613962643};\\\", \\\"{x:1475,y:148,t:1527613962659};\\\", \\\"{x:1474,y:153,t:1527613962677};\\\", \\\"{x:1473,y:156,t:1527613962694};\\\", \\\"{x:1472,y:159,t:1527613962711};\\\", \\\"{x:1472,y:163,t:1527613962726};\\\", \\\"{x:1472,y:165,t:1527613962809};\\\", \\\"{x:1472,y:166,t:1527613962825};\\\", \\\"{x:1476,y:167,t:1527613962832};\\\", \\\"{x:1477,y:169,t:1527613962856};\\\", \\\"{x:1478,y:169,t:1527613962873};\\\", \\\"{x:1479,y:169,t:1527613962881};\\\", \\\"{x:1480,y:169,t:1527613963041};\\\", \\\"{x:1481,y:169,t:1527613963064};\\\", \\\"{x:1482,y:169,t:1527613963077};\\\", \\\"{x:1483,y:169,t:1527613963152};\\\", \\\"{x:1483,y:171,t:1527613964593};\\\", \\\"{x:1483,y:172,t:1527613964600};\\\", \\\"{x:1483,y:173,t:1527613964612};\\\", \\\"{x:1482,y:176,t:1527613964629};\\\", \\\"{x:1482,y:178,t:1527613964645};\\\", \\\"{x:1482,y:179,t:1527613964662};\\\", \\\"{x:1481,y:179,t:1527613964679};\\\", \\\"{x:1480,y:183,t:1527613964694};\\\", \\\"{x:1480,y:188,t:1527613964712};\\\", \\\"{x:1479,y:192,t:1527613964729};\\\", \\\"{x:1478,y:198,t:1527613964745};\\\", \\\"{x:1478,y:205,t:1527613964762};\\\", \\\"{x:1477,y:211,t:1527613964779};\\\", \\\"{x:1477,y:216,t:1527613964795};\\\", \\\"{x:1477,y:223,t:1527613964812};\\\", \\\"{x:1476,y:234,t:1527613964829};\\\", \\\"{x:1476,y:253,t:1527613964845};\\\", \\\"{x:1474,y:271,t:1527613964862};\\\", \\\"{x:1472,y:288,t:1527613964879};\\\", \\\"{x:1471,y:305,t:1527613964895};\\\", \\\"{x:1469,y:326,t:1527613964912};\\\", \\\"{x:1469,y:338,t:1527613964928};\\\", \\\"{x:1468,y:350,t:1527613964945};\\\", \\\"{x:1466,y:364,t:1527613964962};\\\", \\\"{x:1464,y:375,t:1527613964979};\\\", \\\"{x:1463,y:389,t:1527613964995};\\\", \\\"{x:1461,y:398,t:1527613965011};\\\", \\\"{x:1459,y:408,t:1527613965029};\\\", \\\"{x:1459,y:415,t:1527613965045};\\\", \\\"{x:1459,y:422,t:1527613965062};\\\", \\\"{x:1459,y:432,t:1527613965079};\\\", \\\"{x:1459,y:443,t:1527613965097};\\\", \\\"{x:1459,y:450,t:1527613965112};\\\", \\\"{x:1459,y:457,t:1527613965128};\\\", \\\"{x:1459,y:466,t:1527613965146};\\\", \\\"{x:1459,y:474,t:1527613965162};\\\", \\\"{x:1459,y:478,t:1527613965179};\\\", \\\"{x:1459,y:485,t:1527613965196};\\\", \\\"{x:1459,y:494,t:1527613965211};\\\", \\\"{x:1459,y:501,t:1527613965228};\\\", \\\"{x:1460,y:508,t:1527613965245};\\\", \\\"{x:1461,y:515,t:1527613965261};\\\", \\\"{x:1464,y:524,t:1527613965279};\\\", \\\"{x:1465,y:533,t:1527613965295};\\\", \\\"{x:1465,y:542,t:1527613965312};\\\", \\\"{x:1468,y:553,t:1527613965328};\\\", \\\"{x:1470,y:567,t:1527613965345};\\\", \\\"{x:1472,y:579,t:1527613965361};\\\", \\\"{x:1473,y:586,t:1527613965378};\\\", \\\"{x:1475,y:599,t:1527613965395};\\\", \\\"{x:1478,y:609,t:1527613965412};\\\", \\\"{x:1478,y:617,t:1527613965428};\\\", \\\"{x:1479,y:623,t:1527613965445};\\\", \\\"{x:1479,y:629,t:1527613965461};\\\", \\\"{x:1482,y:643,t:1527613965478};\\\", \\\"{x:1482,y:651,t:1527613965496};\\\", \\\"{x:1482,y:659,t:1527613965512};\\\", \\\"{x:1482,y:665,t:1527613965529};\\\", \\\"{x:1483,y:676,t:1527613965545};\\\", \\\"{x:1483,y:687,t:1527613965563};\\\", \\\"{x:1483,y:694,t:1527613965578};\\\", \\\"{x:1483,y:699,t:1527613965595};\\\", \\\"{x:1484,y:706,t:1527613965613};\\\", \\\"{x:1484,y:715,t:1527613965629};\\\", \\\"{x:1486,y:723,t:1527613965645};\\\", \\\"{x:1486,y:728,t:1527613965663};\\\", \\\"{x:1486,y:736,t:1527613965679};\\\", \\\"{x:1490,y:748,t:1527613965696};\\\", \\\"{x:1492,y:756,t:1527613965712};\\\", \\\"{x:1492,y:760,t:1527613965729};\\\", \\\"{x:1492,y:762,t:1527613965746};\\\", \\\"{x:1492,y:764,t:1527613965763};\\\", \\\"{x:1491,y:764,t:1527613965784};\\\", \\\"{x:1489,y:764,t:1527613965808};\\\", \\\"{x:1488,y:764,t:1527613965840};\\\", \\\"{x:1487,y:766,t:1527613965856};\\\", \\\"{x:1487,y:769,t:1527613965864};\\\", \\\"{x:1486,y:771,t:1527613965878};\\\", \\\"{x:1485,y:771,t:1527613965912};\\\", \\\"{x:1485,y:772,t:1527613966561};\\\", \\\"{x:1483,y:772,t:1527613966568};\\\", \\\"{x:1483,y:774,t:1527613966704};\\\", \\\"{x:1485,y:777,t:1527613966713};\\\", \\\"{x:1486,y:782,t:1527613966730};\\\", \\\"{x:1489,y:788,t:1527613966747};\\\", \\\"{x:1489,y:789,t:1527613966763};\\\", \\\"{x:1489,y:790,t:1527613966784};\\\", \\\"{x:1489,y:791,t:1527613966800};\\\", \\\"{x:1489,y:792,t:1527613966813};\\\", \\\"{x:1489,y:796,t:1527613966830};\\\", \\\"{x:1489,y:802,t:1527613966847};\\\", \\\"{x:1489,y:808,t:1527613966862};\\\", \\\"{x:1489,y:813,t:1527613966880};\\\", \\\"{x:1489,y:815,t:1527613966897};\\\", \\\"{x:1489,y:816,t:1527613966913};\\\", \\\"{x:1489,y:817,t:1527613966937};\\\", \\\"{x:1489,y:818,t:1527613966947};\\\", \\\"{x:1489,y:819,t:1527613966968};\\\", \\\"{x:1489,y:820,t:1527613966980};\\\", \\\"{x:1489,y:821,t:1527613966997};\\\", \\\"{x:1489,y:822,t:1527613967014};\\\", \\\"{x:1487,y:825,t:1527613967488};\\\", \\\"{x:1486,y:827,t:1527613967505};\\\", \\\"{x:1485,y:828,t:1527613967553};\\\", \\\"{x:1484,y:828,t:1527613967665};\\\", \\\"{x:1483,y:828,t:1527613969625};\\\", \\\"{x:1482,y:831,t:1527613969631};\\\", \\\"{x:1481,y:831,t:1527613969672};\\\", \\\"{x:1480,y:831,t:1527613969760};\\\", \\\"{x:1477,y:831,t:1527613971048};\\\", \\\"{x:1465,y:827,t:1527613971067};\\\", \\\"{x:1443,y:818,t:1527613971083};\\\", \\\"{x:1410,y:806,t:1527613971100};\\\", \\\"{x:1361,y:785,t:1527613971116};\\\", \\\"{x:1332,y:777,t:1527613971133};\\\", \\\"{x:1311,y:770,t:1527613971151};\\\", \\\"{x:1293,y:761,t:1527613971166};\\\", \\\"{x:1284,y:758,t:1527613971183};\\\", \\\"{x:1278,y:754,t:1527613971200};\\\", \\\"{x:1277,y:754,t:1527613971216};\\\", \\\"{x:1277,y:753,t:1527613971240};\\\", \\\"{x:1278,y:753,t:1527613971289};\\\", \\\"{x:1279,y:753,t:1527613971300};\\\", \\\"{x:1280,y:753,t:1527613971317};\\\", \\\"{x:1283,y:753,t:1527613971332};\\\", \\\"{x:1284,y:754,t:1527613971350};\\\", \\\"{x:1286,y:754,t:1527613971366};\\\", \\\"{x:1287,y:755,t:1527613971382};\\\", \\\"{x:1290,y:757,t:1527613971399};\\\", \\\"{x:1292,y:757,t:1527613971416};\\\", \\\"{x:1297,y:759,t:1527613971433};\\\", \\\"{x:1305,y:761,t:1527613971450};\\\", \\\"{x:1315,y:765,t:1527613971466};\\\", \\\"{x:1326,y:767,t:1527613971483};\\\", \\\"{x:1336,y:768,t:1527613971500};\\\", \\\"{x:1342,y:768,t:1527613971516};\\\", \\\"{x:1350,y:769,t:1527613971532};\\\", \\\"{x:1355,y:772,t:1527613971550};\\\", \\\"{x:1356,y:772,t:1527613971567};\\\", \\\"{x:1355,y:771,t:1527613971775};\\\", \\\"{x:1351,y:770,t:1527613971783};\\\", \\\"{x:1349,y:768,t:1527613971799};\\\", \\\"{x:1349,y:767,t:1527613971816};\\\", \\\"{x:1348,y:766,t:1527613971834};\\\", \\\"{x:1347,y:765,t:1527613971849};\\\", \\\"{x:1346,y:764,t:1527613971977};\\\", \\\"{x:1344,y:764,t:1527613974440};\\\", \\\"{x:1339,y:764,t:1527613974453};\\\", \\\"{x:1329,y:767,t:1527613974469};\\\", \\\"{x:1313,y:772,t:1527613974485};\\\", \\\"{x:1297,y:779,t:1527613974502};\\\", \\\"{x:1281,y:786,t:1527613974519};\\\", \\\"{x:1265,y:794,t:1527613974535};\\\", \\\"{x:1258,y:797,t:1527613974551};\\\", \\\"{x:1258,y:799,t:1527613974569};\\\", \\\"{x:1258,y:800,t:1527613974585};\\\", \\\"{x:1259,y:800,t:1527613974640};\\\", \\\"{x:1260,y:800,t:1527613974696};\\\", \\\"{x:1260,y:799,t:1527613975121};\\\", \\\"{x:1258,y:799,t:1527613975177};\\\", \\\"{x:1257,y:799,t:1527613975216};\\\", \\\"{x:1255,y:799,t:1527613975240};\\\", \\\"{x:1253,y:798,t:1527613975254};\\\", \\\"{x:1252,y:798,t:1527613975269};\\\", \\\"{x:1250,y:798,t:1527613975287};\\\", \\\"{x:1246,y:798,t:1527613975303};\\\", \\\"{x:1239,y:798,t:1527613975319};\\\", \\\"{x:1228,y:798,t:1527613975336};\\\", \\\"{x:1225,y:798,t:1527613975354};\\\", \\\"{x:1223,y:798,t:1527613975369};\\\", \\\"{x:1221,y:798,t:1527613975387};\\\", \\\"{x:1220,y:798,t:1527613975403};\\\", \\\"{x:1219,y:798,t:1527613975420};\\\", \\\"{x:1218,y:798,t:1527613975436};\\\", \\\"{x:1217,y:798,t:1527613975453};\\\", \\\"{x:1216,y:798,t:1527613975469};\\\", \\\"{x:1215,y:798,t:1527613975487};\\\", \\\"{x:1213,y:798,t:1527613975507};\\\", \\\"{x:1211,y:798,t:1527613975556};\\\", \\\"{x:1209,y:798,t:1527613975596};\\\", \\\"{x:1209,y:797,t:1527613977973};\\\", \\\"{x:1209,y:796,t:1527613977987};\\\", \\\"{x:1209,y:795,t:1527613977996};\\\", \\\"{x:1209,y:794,t:1527613978012};\\\", \\\"{x:1209,y:793,t:1527613978043};\\\", \\\"{x:1209,y:792,t:1527613980796};\\\", \\\"{x:1210,y:791,t:1527613980810};\\\", \\\"{x:1220,y:788,t:1527613980827};\\\", \\\"{x:1224,y:788,t:1527613980843};\\\", \\\"{x:1232,y:788,t:1527613980860};\\\", \\\"{x:1246,y:788,t:1527613980877};\\\", \\\"{x:1261,y:788,t:1527613980895};\\\", \\\"{x:1283,y:789,t:1527613980910};\\\", \\\"{x:1312,y:794,t:1527613980927};\\\", \\\"{x:1354,y:796,t:1527613980944};\\\", \\\"{x:1390,y:803,t:1527613980960};\\\", \\\"{x:1419,y:805,t:1527613980977};\\\", \\\"{x:1444,y:809,t:1527613980994};\\\", \\\"{x:1466,y:811,t:1527613981011};\\\", \\\"{x:1487,y:814,t:1527613981027};\\\", \\\"{x:1509,y:818,t:1527613981044};\\\", \\\"{x:1521,y:819,t:1527613981061};\\\", \\\"{x:1525,y:819,t:1527613981077};\\\", \\\"{x:1526,y:819,t:1527613981094};\\\", \\\"{x:1525,y:819,t:1527613981227};\\\", \\\"{x:1516,y:819,t:1527613981244};\\\", \\\"{x:1508,y:819,t:1527613981261};\\\", \\\"{x:1502,y:819,t:1527613981277};\\\", \\\"{x:1496,y:819,t:1527613981294};\\\", \\\"{x:1493,y:818,t:1527613981312};\\\", \\\"{x:1488,y:816,t:1527613981328};\\\", \\\"{x:1486,y:816,t:1527613981344};\\\", \\\"{x:1485,y:813,t:1527613981360};\\\", \\\"{x:1485,y:807,t:1527613981376};\\\", \\\"{x:1485,y:798,t:1527613981394};\\\", \\\"{x:1488,y:778,t:1527613981411};\\\", \\\"{x:1492,y:768,t:1527613981427};\\\", \\\"{x:1495,y:765,t:1527613981444};\\\", \\\"{x:1496,y:764,t:1527613981461};\\\", \\\"{x:1497,y:763,t:1527613981478};\\\", \\\"{x:1498,y:762,t:1527613981494};\\\", \\\"{x:1499,y:761,t:1527613981511};\\\", \\\"{x:1502,y:760,t:1527613981527};\\\", \\\"{x:1503,y:759,t:1527613981544};\\\", \\\"{x:1505,y:759,t:1527613981561};\\\", \\\"{x:1505,y:758,t:1527613981578};\\\", \\\"{x:1506,y:757,t:1527613981594};\\\", \\\"{x:1507,y:757,t:1527613981619};\\\", \\\"{x:1508,y:757,t:1527613981667};\\\", \\\"{x:1509,y:757,t:1527613981678};\\\", \\\"{x:1509,y:756,t:1527613981694};\\\", \\\"{x:1510,y:756,t:1527613981711};\\\", \\\"{x:1511,y:756,t:1527613981728};\\\", \\\"{x:1513,y:756,t:1527613981820};\\\", \\\"{x:1514,y:756,t:1527613981884};\\\", \\\"{x:1516,y:758,t:1527613981908};\\\", \\\"{x:1517,y:759,t:1527613981928};\\\", \\\"{x:1518,y:760,t:1527613981945};\\\", \\\"{x:1520,y:760,t:1527613981965};\\\", \\\"{x:1520,y:759,t:1527613982116};\\\", \\\"{x:1520,y:758,t:1527613982208};\\\", \\\"{x:1519,y:758,t:1527613982235};\\\", \\\"{x:1518,y:758,t:1527613982283};\\\", \\\"{x:1518,y:757,t:1527613982295};\\\", \\\"{x:1517,y:756,t:1527613982403};\\\", \\\"{x:1517,y:755,t:1527613982411};\\\", \\\"{x:1517,y:753,t:1527613982428};\\\", \\\"{x:1516,y:749,t:1527613982445};\\\", \\\"{x:1515,y:747,t:1527613982461};\\\", \\\"{x:1514,y:745,t:1527613982478};\\\", \\\"{x:1514,y:743,t:1527613982495};\\\", \\\"{x:1514,y:739,t:1527613982513};\\\", \\\"{x:1514,y:736,t:1527613982528};\\\", \\\"{x:1514,y:733,t:1527613982545};\\\", \\\"{x:1514,y:730,t:1527613982562};\\\", \\\"{x:1514,y:727,t:1527613982578};\\\", \\\"{x:1514,y:723,t:1527613982596};\\\", \\\"{x:1514,y:720,t:1527613982612};\\\", \\\"{x:1514,y:715,t:1527613982629};\\\", \\\"{x:1514,y:712,t:1527613982645};\\\", \\\"{x:1514,y:708,t:1527613982662};\\\", \\\"{x:1514,y:705,t:1527613982678};\\\", \\\"{x:1514,y:699,t:1527613982695};\\\", \\\"{x:1513,y:694,t:1527613982712};\\\", \\\"{x:1513,y:689,t:1527613982729};\\\", \\\"{x:1513,y:684,t:1527613982745};\\\", \\\"{x:1513,y:680,t:1527613982762};\\\", \\\"{x:1513,y:676,t:1527613982778};\\\", \\\"{x:1512,y:671,t:1527613982796};\\\", \\\"{x:1511,y:666,t:1527613982812};\\\", \\\"{x:1511,y:662,t:1527613982829};\\\", \\\"{x:1511,y:660,t:1527613982845};\\\", \\\"{x:1511,y:658,t:1527613982863};\\\", \\\"{x:1511,y:655,t:1527613982878};\\\", \\\"{x:1511,y:653,t:1527613982895};\\\", \\\"{x:1511,y:651,t:1527613982912};\\\", \\\"{x:1511,y:649,t:1527613982932};\\\", \\\"{x:1511,y:648,t:1527613982948};\\\", \\\"{x:1511,y:646,t:1527613982964};\\\", \\\"{x:1511,y:645,t:1527613982979};\\\", \\\"{x:1511,y:642,t:1527613982996};\\\", \\\"{x:1510,y:640,t:1527613983012};\\\", \\\"{x:1510,y:639,t:1527613983053};\\\", \\\"{x:1510,y:638,t:1527613983063};\\\", \\\"{x:1511,y:636,t:1527613983080};\\\", \\\"{x:1511,y:635,t:1527613983096};\\\", \\\"{x:1511,y:633,t:1527613983112};\\\", \\\"{x:1511,y:632,t:1527613983129};\\\", \\\"{x:1511,y:631,t:1527613983145};\\\", \\\"{x:1511,y:630,t:1527613983162};\\\", \\\"{x:1511,y:628,t:1527613983180};\\\", \\\"{x:1511,y:627,t:1527613983195};\\\", \\\"{x:1510,y:626,t:1527613983213};\\\", \\\"{x:1510,y:625,t:1527613983236};\\\", \\\"{x:1510,y:624,t:1527613983246};\\\", \\\"{x:1510,y:623,t:1527613983268};\\\", \\\"{x:1510,y:621,t:1527613983284};\\\", \\\"{x:1510,y:620,t:1527613983308};\\\", \\\"{x:1510,y:619,t:1527613983340};\\\", \\\"{x:1510,y:618,t:1527613983356};\\\", \\\"{x:1510,y:617,t:1527613983372};\\\", \\\"{x:1510,y:616,t:1527613983380};\\\", \\\"{x:1510,y:614,t:1527613983396};\\\", \\\"{x:1510,y:612,t:1527613983413};\\\", \\\"{x:1510,y:611,t:1527613983430};\\\", \\\"{x:1510,y:609,t:1527613983446};\\\", \\\"{x:1510,y:605,t:1527613983462};\\\", \\\"{x:1510,y:603,t:1527613983479};\\\", \\\"{x:1510,y:599,t:1527613983497};\\\", \\\"{x:1510,y:596,t:1527613983512};\\\", \\\"{x:1510,y:594,t:1527613983530};\\\", \\\"{x:1510,y:591,t:1527613983546};\\\", \\\"{x:1510,y:588,t:1527613983563};\\\", \\\"{x:1510,y:584,t:1527613983580};\\\", \\\"{x:1510,y:581,t:1527613983596};\\\", \\\"{x:1510,y:578,t:1527613983612};\\\", \\\"{x:1510,y:574,t:1527613983629};\\\", \\\"{x:1510,y:568,t:1527613983646};\\\", \\\"{x:1510,y:564,t:1527613983663};\\\", \\\"{x:1510,y:560,t:1527613983680};\\\", \\\"{x:1510,y:554,t:1527613983696};\\\", \\\"{x:1510,y:548,t:1527613983713};\\\", \\\"{x:1510,y:540,t:1527613983730};\\\", \\\"{x:1509,y:533,t:1527613983747};\\\", \\\"{x:1509,y:525,t:1527613983762};\\\", \\\"{x:1509,y:517,t:1527613983780};\\\", \\\"{x:1508,y:511,t:1527613983796};\\\", \\\"{x:1508,y:505,t:1527613983812};\\\", \\\"{x:1507,y:497,t:1527613983829};\\\", \\\"{x:1507,y:487,t:1527613983847};\\\", \\\"{x:1507,y:480,t:1527613983862};\\\", \\\"{x:1507,y:475,t:1527613983879};\\\", \\\"{x:1507,y:466,t:1527613983897};\\\", \\\"{x:1507,y:459,t:1527613983913};\\\", \\\"{x:1507,y:452,t:1527613983930};\\\", \\\"{x:1507,y:448,t:1527613983946};\\\", \\\"{x:1507,y:439,t:1527613983964};\\\", \\\"{x:1506,y:433,t:1527613983980};\\\", \\\"{x:1506,y:428,t:1527613983996};\\\", \\\"{x:1506,y:421,t:1527613984014};\\\", \\\"{x:1506,y:416,t:1527613984029};\\\", \\\"{x:1506,y:410,t:1527613984046};\\\", \\\"{x:1506,y:406,t:1527613984063};\\\", \\\"{x:1506,y:401,t:1527613984078};\\\", \\\"{x:1506,y:396,t:1527613984096};\\\", \\\"{x:1506,y:391,t:1527613984113};\\\", \\\"{x:1506,y:387,t:1527613984129};\\\", \\\"{x:1507,y:381,t:1527613984146};\\\", \\\"{x:1507,y:375,t:1527613984163};\\\", \\\"{x:1507,y:372,t:1527613984179};\\\", \\\"{x:1507,y:368,t:1527613984196};\\\", \\\"{x:1507,y:367,t:1527613984213};\\\", \\\"{x:1508,y:365,t:1527613984229};\\\", \\\"{x:1509,y:365,t:1527613984252};\\\", \\\"{x:1509,y:363,t:1527613984263};\\\", \\\"{x:1510,y:361,t:1527613984280};\\\", \\\"{x:1510,y:360,t:1527613984300};\\\", \\\"{x:1510,y:359,t:1527613984332};\\\", \\\"{x:1508,y:358,t:1527613999276};\\\", \\\"{x:1469,y:374,t:1527613999292};\\\", \\\"{x:1388,y:400,t:1527613999308};\\\", \\\"{x:1309,y:429,t:1527613999324};\\\", \\\"{x:1228,y:453,t:1527613999341};\\\", \\\"{x:1140,y:476,t:1527613999358};\\\", \\\"{x:1055,y:491,t:1527613999374};\\\", \\\"{x:969,y:504,t:1527613999391};\\\", \\\"{x:878,y:515,t:1527613999410};\\\", \\\"{x:805,y:528,t:1527613999424};\\\", \\\"{x:748,y:537,t:1527613999441};\\\", \\\"{x:711,y:550,t:1527613999461};\\\", \\\"{x:697,y:560,t:1527613999477};\\\", \\\"{x:686,y:566,t:1527613999495};\\\", \\\"{x:682,y:569,t:1527613999510};\\\", \\\"{x:679,y:572,t:1527613999527};\\\", \\\"{x:679,y:574,t:1527613999544};\\\", \\\"{x:677,y:578,t:1527613999560};\\\", \\\"{x:673,y:586,t:1527613999577};\\\", \\\"{x:668,y:595,t:1527613999595};\\\", \\\"{x:662,y:606,t:1527613999611};\\\", \\\"{x:654,y:619,t:1527613999627};\\\", \\\"{x:641,y:637,t:1527613999645};\\\", \\\"{x:629,y:655,t:1527613999661};\\\", \\\"{x:625,y:669,t:1527613999678};\\\", \\\"{x:624,y:683,t:1527613999694};\\\", \\\"{x:625,y:701,t:1527613999710};\\\", \\\"{x:627,y:718,t:1527613999728};\\\", \\\"{x:630,y:729,t:1527613999744};\\\", \\\"{x:631,y:735,t:1527613999761};\\\", \\\"{x:631,y:743,t:1527613999778};\\\", \\\"{x:632,y:750,t:1527613999795};\\\", \\\"{x:631,y:751,t:1527613999835};\\\", \\\"{x:629,y:751,t:1527613999845};\\\", \\\"{x:623,y:750,t:1527613999862};\\\", \\\"{x:613,y:746,t:1527613999877};\\\", \\\"{x:604,y:743,t:1527613999895};\\\", \\\"{x:594,y:740,t:1527613999911};\\\", \\\"{x:589,y:739,t:1527613999927};\\\", \\\"{x:585,y:739,t:1527613999944};\\\", \\\"{x:581,y:739,t:1527613999962};\\\", \\\"{x:567,y:738,t:1527613999978};\\\", \\\"{x:546,y:731,t:1527613999995};\\\", \\\"{x:535,y:730,t:1527614000011};\\\", \\\"{x:529,y:730,t:1527614000027};\\\", \\\"{x:526,y:730,t:1527614000044};\\\", \\\"{x:525,y:730,t:1527614000062};\\\", \\\"{x:524,y:730,t:1527614000078};\\\", \\\"{x:521,y:730,t:1527614000094};\\\", \\\"{x:516,y:730,t:1527614000111};\\\", \\\"{x:514,y:730,t:1527614000127};\\\", \\\"{x:513,y:729,t:1527614000144};\\\", \\\"{x:514,y:727,t:1527614001155};\\\", \\\"{x:515,y:727,t:1527614001163};\\\", \\\"{x:515,y:726,t:1527614001178};\\\", \\\"{x:520,y:724,t:1527614001195};\\\", \\\"{x:523,y:723,t:1527614001212};\\\", \\\"{x:527,y:721,t:1527614001229};\\\", \\\"{x:530,y:719,t:1527614001246};\\\", \\\"{x:532,y:718,t:1527614001263};\\\", \\\"{x:538,y:716,t:1527614001279};\\\", \\\"{x:543,y:714,t:1527614001296};\\\", \\\"{x:547,y:712,t:1527614001313};\\\", \\\"{x:550,y:711,t:1527614001329};\\\", \\\"{x:558,y:707,t:1527614001352};\\\", \\\"{x:561,y:705,t:1527614001363};\\\", \\\"{x:564,y:704,t:1527614001379};\\\", \\\"{x:570,y:703,t:1527614001396};\\\", \\\"{x:578,y:701,t:1527614001412};\\\" ] }, { \\\"rt\\\": 59037, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 385152, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I -J -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:619,y:700,t:1527614001522};\\\", \\\"{x:636,y:699,t:1527614001550};\\\", \\\"{x:642,y:697,t:1527614001562};\\\", \\\"{x:645,y:696,t:1527614001578};\\\", \\\"{x:647,y:696,t:1527614001595};\\\", \\\"{x:651,y:695,t:1527614001621};\\\", \\\"{x:655,y:695,t:1527614001629};\\\", \\\"{x:665,y:691,t:1527614001645};\\\", \\\"{x:678,y:691,t:1527614001662};\\\", \\\"{x:684,y:688,t:1527614001679};\\\", \\\"{x:689,y:688,t:1527614001696};\\\", \\\"{x:693,y:687,t:1527614001713};\\\", \\\"{x:698,y:686,t:1527614001730};\\\", \\\"{x:700,y:685,t:1527614001745};\\\", \\\"{x:702,y:684,t:1527614001762};\\\", \\\"{x:703,y:684,t:1527614001899};\\\", \\\"{x:704,y:684,t:1527614006900};\\\", \\\"{x:703,y:692,t:1527614006917};\\\", \\\"{x:702,y:693,t:1527614006933};\\\", \\\"{x:701,y:698,t:1527614006950};\\\", \\\"{x:700,y:702,t:1527614006967};\\\", \\\"{x:699,y:705,t:1527614006983};\\\", \\\"{x:699,y:709,t:1527614007001};\\\", \\\"{x:697,y:712,t:1527614007018};\\\", \\\"{x:696,y:714,t:1527614007034};\\\", \\\"{x:695,y:716,t:1527614007051};\\\", \\\"{x:694,y:717,t:1527614007067};\\\", \\\"{x:693,y:719,t:1527614007276};\\\", \\\"{x:693,y:720,t:1527614007675};\\\", \\\"{x:692,y:721,t:1527614007811};\\\", \\\"{x:691,y:723,t:1527614007819};\\\", \\\"{x:691,y:727,t:1527614007833};\\\", \\\"{x:693,y:739,t:1527614007851};\\\", \\\"{x:696,y:745,t:1527614007867};\\\", \\\"{x:700,y:752,t:1527614007884};\\\", \\\"{x:713,y:768,t:1527614007901};\\\", \\\"{x:726,y:782,t:1527614007917};\\\", \\\"{x:736,y:797,t:1527614007934};\\\", \\\"{x:744,y:806,t:1527614007951};\\\", \\\"{x:752,y:819,t:1527614007967};\\\", \\\"{x:761,y:829,t:1527614007984};\\\", \\\"{x:770,y:836,t:1527614008001};\\\", \\\"{x:783,y:845,t:1527614008017};\\\", \\\"{x:796,y:851,t:1527614008035};\\\", \\\"{x:811,y:857,t:1527614008051};\\\", \\\"{x:819,y:859,t:1527614008067};\\\", \\\"{x:824,y:860,t:1527614008085};\\\", \\\"{x:828,y:861,t:1527614008102};\\\", \\\"{x:835,y:861,t:1527614008117};\\\", \\\"{x:843,y:860,t:1527614008135};\\\", \\\"{x:852,y:858,t:1527614008151};\\\", \\\"{x:860,y:854,t:1527614008168};\\\", \\\"{x:871,y:851,t:1527614008185};\\\", \\\"{x:877,y:850,t:1527614008202};\\\", \\\"{x:882,y:850,t:1527614008218};\\\", \\\"{x:887,y:850,t:1527614008235};\\\", \\\"{x:894,y:849,t:1527614008251};\\\", \\\"{x:900,y:849,t:1527614008268};\\\", \\\"{x:906,y:849,t:1527614008284};\\\", \\\"{x:915,y:849,t:1527614008301};\\\", \\\"{x:925,y:849,t:1527614008318};\\\", \\\"{x:938,y:849,t:1527614008334};\\\", \\\"{x:958,y:850,t:1527614008351};\\\", \\\"{x:983,y:852,t:1527614008369};\\\", \\\"{x:1009,y:857,t:1527614008385};\\\", \\\"{x:1032,y:860,t:1527614008402};\\\", \\\"{x:1064,y:866,t:1527614008418};\\\", \\\"{x:1091,y:871,t:1527614008435};\\\", \\\"{x:1131,y:883,t:1527614008452};\\\", \\\"{x:1159,y:893,t:1527614008468};\\\", \\\"{x:1180,y:898,t:1527614008484};\\\", \\\"{x:1199,y:904,t:1527614008502};\\\", \\\"{x:1216,y:909,t:1527614008518};\\\", \\\"{x:1232,y:913,t:1527614008535};\\\", \\\"{x:1245,y:916,t:1527614008552};\\\", \\\"{x:1250,y:918,t:1527614008569};\\\", \\\"{x:1253,y:918,t:1527614008585};\\\", \\\"{x:1255,y:918,t:1527614008602};\\\", \\\"{x:1257,y:917,t:1527614008619};\\\", \\\"{x:1258,y:917,t:1527614008635};\\\", \\\"{x:1260,y:916,t:1527614008652};\\\", \\\"{x:1261,y:915,t:1527614008724};\\\", \\\"{x:1262,y:915,t:1527614008756};\\\", \\\"{x:1262,y:914,t:1527614008844};\\\", \\\"{x:1262,y:912,t:1527614008860};\\\", \\\"{x:1262,y:911,t:1527614008875};\\\", \\\"{x:1262,y:910,t:1527614008886};\\\", \\\"{x:1263,y:906,t:1527614008902};\\\", \\\"{x:1264,y:904,t:1527614008919};\\\", \\\"{x:1266,y:899,t:1527614008936};\\\", \\\"{x:1266,y:894,t:1527614008951};\\\", \\\"{x:1266,y:889,t:1527614008969};\\\", \\\"{x:1266,y:883,t:1527614008986};\\\", \\\"{x:1266,y:879,t:1527614009002};\\\", \\\"{x:1266,y:875,t:1527614009019};\\\", \\\"{x:1266,y:872,t:1527614009035};\\\", \\\"{x:1266,y:869,t:1527614009052};\\\", \\\"{x:1266,y:866,t:1527614009068};\\\", \\\"{x:1266,y:863,t:1527614009086};\\\", \\\"{x:1266,y:859,t:1527614009102};\\\", \\\"{x:1263,y:855,t:1527614009120};\\\", \\\"{x:1260,y:851,t:1527614009136};\\\", \\\"{x:1258,y:850,t:1527614009152};\\\", \\\"{x:1253,y:847,t:1527614009169};\\\", \\\"{x:1246,y:846,t:1527614009185};\\\", \\\"{x:1240,y:844,t:1527614009202};\\\", \\\"{x:1238,y:844,t:1527614009219};\\\", \\\"{x:1229,y:843,t:1527614009235};\\\", \\\"{x:1227,y:843,t:1527614009252};\\\", \\\"{x:1224,y:843,t:1527614009268};\\\", \\\"{x:1221,y:843,t:1527614009286};\\\", \\\"{x:1220,y:844,t:1527614009303};\\\", \\\"{x:1219,y:844,t:1527614009403};\\\", \\\"{x:1218,y:844,t:1527614009524};\\\", \\\"{x:1215,y:842,t:1527614009536};\\\", \\\"{x:1213,y:837,t:1527614009553};\\\", \\\"{x:1211,y:828,t:1527614009571};\\\", \\\"{x:1209,y:824,t:1527614009585};\\\", \\\"{x:1206,y:820,t:1527614009602};\\\", \\\"{x:1205,y:818,t:1527614009618};\\\", \\\"{x:1203,y:815,t:1527614009635};\\\", \\\"{x:1202,y:815,t:1527614009652};\\\", \\\"{x:1202,y:814,t:1527614009668};\\\", \\\"{x:1200,y:813,t:1527614009685};\\\", \\\"{x:1200,y:812,t:1527614009702};\\\", \\\"{x:1199,y:811,t:1527614009719};\\\", \\\"{x:1197,y:809,t:1527614009735};\\\", \\\"{x:1197,y:807,t:1527614009753};\\\", \\\"{x:1194,y:803,t:1527614009769};\\\", \\\"{x:1192,y:800,t:1527614009786};\\\", \\\"{x:1190,y:795,t:1527614009802};\\\", \\\"{x:1183,y:780,t:1527614009819};\\\", \\\"{x:1180,y:772,t:1527614009835};\\\", \\\"{x:1178,y:769,t:1527614009853};\\\", \\\"{x:1177,y:767,t:1527614009870};\\\", \\\"{x:1176,y:766,t:1527614009886};\\\", \\\"{x:1176,y:765,t:1527614009915};\\\", \\\"{x:1176,y:764,t:1527614010092};\\\", \\\"{x:1176,y:763,t:1527614010156};\\\", \\\"{x:1177,y:762,t:1527614010268};\\\", \\\"{x:1177,y:761,t:1527614013436};\\\", \\\"{x:1176,y:761,t:1527614020706};\\\", \\\"{x:1176,y:762,t:1527614020715};\\\", \\\"{x:1175,y:764,t:1527614020739};\\\", \\\"{x:1174,y:766,t:1527614020755};\\\", \\\"{x:1173,y:767,t:1527614020787};\\\", \\\"{x:1173,y:768,t:1527614021307};\\\", \\\"{x:1173,y:767,t:1527614021339};\\\", \\\"{x:1173,y:766,t:1527614021354};\\\", \\\"{x:1173,y:765,t:1527614021379};\\\", \\\"{x:1172,y:764,t:1527614031852};\\\", \\\"{x:1171,y:764,t:1527614035276};\\\", \\\"{x:1170,y:767,t:1527614049902};\\\", \\\"{x:1171,y:774,t:1527614049918};\\\", \\\"{x:1174,y:781,t:1527614049935};\\\", \\\"{x:1176,y:787,t:1527614049951};\\\", \\\"{x:1179,y:792,t:1527614049967};\\\", \\\"{x:1180,y:793,t:1527614049984};\\\", \\\"{x:1180,y:794,t:1527614050001};\\\", \\\"{x:1180,y:795,t:1527614050017};\\\", \\\"{x:1181,y:796,t:1527614050035};\\\", \\\"{x:1182,y:798,t:1527614050050};\\\", \\\"{x:1186,y:799,t:1527614050067};\\\", \\\"{x:1187,y:801,t:1527614050085};\\\", \\\"{x:1188,y:802,t:1527614050100};\\\", \\\"{x:1189,y:803,t:1527614050117};\\\", \\\"{x:1191,y:805,t:1527614050134};\\\", \\\"{x:1194,y:807,t:1527614050151};\\\", \\\"{x:1198,y:811,t:1527614050167};\\\", \\\"{x:1202,y:815,t:1527614050184};\\\", \\\"{x:1204,y:816,t:1527614050202};\\\", \\\"{x:1208,y:819,t:1527614050217};\\\", \\\"{x:1210,y:821,t:1527614050235};\\\", \\\"{x:1211,y:822,t:1527614050252};\\\", \\\"{x:1211,y:823,t:1527614050334};\\\", \\\"{x:1211,y:825,t:1527614050353};\\\", \\\"{x:1211,y:826,t:1527614050368};\\\", \\\"{x:1212,y:829,t:1527614050384};\\\", \\\"{x:1213,y:830,t:1527614050402};\\\", \\\"{x:1214,y:833,t:1527614050417};\\\", \\\"{x:1214,y:835,t:1527614050435};\\\", \\\"{x:1216,y:839,t:1527614050452};\\\", \\\"{x:1217,y:842,t:1527614050468};\\\", \\\"{x:1217,y:844,t:1527614050484};\\\", \\\"{x:1217,y:845,t:1527614050573};\\\", \\\"{x:1217,y:846,t:1527614050589};\\\", \\\"{x:1216,y:845,t:1527614050605};\\\", \\\"{x:1216,y:843,t:1527614050618};\\\", \\\"{x:1214,y:841,t:1527614050635};\\\", \\\"{x:1213,y:839,t:1527614050652};\\\", \\\"{x:1212,y:836,t:1527614050669};\\\", \\\"{x:1211,y:834,t:1527614050685};\\\", \\\"{x:1210,y:833,t:1527614050701};\\\", \\\"{x:1210,y:832,t:1527614050757};\\\", \\\"{x:1209,y:831,t:1527614050774};\\\", \\\"{x:1194,y:828,t:1527614058821};\\\", \\\"{x:1150,y:820,t:1527614058829};\\\", \\\"{x:1101,y:811,t:1527614058841};\\\", \\\"{x:997,y:789,t:1527614058858};\\\", \\\"{x:914,y:776,t:1527614058874};\\\", \\\"{x:837,y:759,t:1527614058891};\\\", \\\"{x:787,y:743,t:1527614058908};\\\", \\\"{x:754,y:736,t:1527614058924};\\\", \\\"{x:720,y:726,t:1527614058941};\\\", \\\"{x:709,y:722,t:1527614058957};\\\", \\\"{x:708,y:722,t:1527614058974};\\\", \\\"{x:707,y:722,t:1527614058992};\\\", \\\"{x:701,y:722,t:1527614059009};\\\", \\\"{x:691,y:722,t:1527614059024};\\\", \\\"{x:685,y:723,t:1527614059042};\\\", \\\"{x:683,y:724,t:1527614059058};\\\", \\\"{x:676,y:726,t:1527614059074};\\\", \\\"{x:666,y:726,t:1527614059092};\\\", \\\"{x:645,y:726,t:1527614059108};\\\", \\\"{x:624,y:726,t:1527614059125};\\\", \\\"{x:584,y:726,t:1527614059141};\\\", \\\"{x:543,y:726,t:1527614059159};\\\", \\\"{x:509,y:725,t:1527614059174};\\\", \\\"{x:473,y:720,t:1527614059191};\\\", \\\"{x:454,y:717,t:1527614059204};\\\", \\\"{x:424,y:714,t:1527614059220};\\\", \\\"{x:389,y:711,t:1527614059236};\\\", \\\"{x:379,y:708,t:1527614059253};\\\", \\\"{x:378,y:708,t:1527614059317};\\\", \\\"{x:380,y:708,t:1527614059421};\\\", \\\"{x:385,y:708,t:1527614059438};\\\", \\\"{x:390,y:709,t:1527614059454};\\\", \\\"{x:396,y:710,t:1527614059472};\\\", \\\"{x:401,y:710,t:1527614059487};\\\", \\\"{x:405,y:711,t:1527614059505};\\\", \\\"{x:412,y:711,t:1527614059521};\\\", \\\"{x:419,y:711,t:1527614059538};\\\", \\\"{x:426,y:711,t:1527614059554};\\\", \\\"{x:433,y:711,t:1527614059572};\\\", \\\"{x:439,y:711,t:1527614059588};\\\", \\\"{x:445,y:713,t:1527614059605};\\\", \\\"{x:448,y:713,t:1527614059622};\\\", \\\"{x:449,y:713,t:1527614059660};\\\", \\\"{x:451,y:714,t:1527614059676};\\\", \\\"{x:451,y:716,t:1527614059688};\\\", \\\"{x:457,y:717,t:1527614059704};\\\", \\\"{x:464,y:722,t:1527614059721};\\\", \\\"{x:471,y:726,t:1527614059738};\\\", \\\"{x:485,y:734,t:1527614059762};\\\", \\\"{x:494,y:739,t:1527614059779};\\\", \\\"{x:498,y:743,t:1527614059796};\\\", \\\"{x:503,y:746,t:1527614059811};\\\", \\\"{x:503,y:747,t:1527614059829};\\\", \\\"{x:504,y:747,t:1527614061309};\\\", \\\"{x:504,y:748,t:1527614061317};\\\", \\\"{x:503,y:753,t:1527614061330};\\\", \\\"{x:501,y:755,t:1527614061346};\\\", \\\"{x:498,y:759,t:1527614061362};\\\", \\\"{x:496,y:761,t:1527614061380};\\\", \\\"{x:495,y:766,t:1527614061396};\\\", \\\"{x:494,y:767,t:1527614061413};\\\", \\\"{x:493,y:770,t:1527614061430};\\\", \\\"{x:493,y:771,t:1527614061446};\\\" ] }, { \\\"rt\\\": 31715, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 418387, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -G -G -J -09 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:492,y:771,t:1527614062116};\\\", \\\"{x:493,y:772,t:1527614063662};\\\", \\\"{x:499,y:775,t:1527614063669};\\\", \\\"{x:508,y:777,t:1527614063682};\\\", \\\"{x:525,y:782,t:1527614063699};\\\", \\\"{x:544,y:788,t:1527614063716};\\\", \\\"{x:573,y:794,t:1527614063732};\\\", \\\"{x:604,y:804,t:1527614063748};\\\", \\\"{x:721,y:829,t:1527614063765};\\\", \\\"{x:827,y:845,t:1527614063782};\\\", \\\"{x:926,y:855,t:1527614063798};\\\", \\\"{x:1012,y:868,t:1527614063815};\\\", \\\"{x:1107,y:872,t:1527614063832};\\\", \\\"{x:1213,y:874,t:1527614063848};\\\", \\\"{x:1316,y:874,t:1527614063865};\\\", \\\"{x:1411,y:878,t:1527614063882};\\\", \\\"{x:1478,y:878,t:1527614063898};\\\", \\\"{x:1531,y:878,t:1527614063915};\\\", \\\"{x:1564,y:871,t:1527614063932};\\\", \\\"{x:1591,y:869,t:1527614063949};\\\", \\\"{x:1637,y:869,t:1527614063965};\\\", \\\"{x:1660,y:869,t:1527614063983};\\\", \\\"{x:1679,y:869,t:1527614063999};\\\", \\\"{x:1690,y:869,t:1527614064016};\\\", \\\"{x:1694,y:869,t:1527614064033};\\\", \\\"{x:1695,y:869,t:1527614064049};\\\", \\\"{x:1695,y:868,t:1527614064102};\\\", \\\"{x:1694,y:868,t:1527614064133};\\\", \\\"{x:1692,y:867,t:1527614064150};\\\", \\\"{x:1688,y:866,t:1527614064165};\\\", \\\"{x:1687,y:866,t:1527614064183};\\\", \\\"{x:1685,y:866,t:1527614064200};\\\", \\\"{x:1682,y:866,t:1527614064216};\\\", \\\"{x:1678,y:866,t:1527614064233};\\\", \\\"{x:1677,y:866,t:1527614064250};\\\", \\\"{x:1675,y:866,t:1527614064265};\\\", \\\"{x:1674,y:866,t:1527614064283};\\\", \\\"{x:1672,y:866,t:1527614064678};\\\", \\\"{x:1671,y:866,t:1527614064726};\\\", \\\"{x:1670,y:866,t:1527614064964};\\\", \\\"{x:1669,y:866,t:1527614064972};\\\", \\\"{x:1668,y:866,t:1527614065021};\\\", \\\"{x:1665,y:867,t:1527614065158};\\\", \\\"{x:1664,y:867,t:1527614065181};\\\", \\\"{x:1663,y:867,t:1527614065189};\\\", \\\"{x:1662,y:867,t:1527614065327};\\\", \\\"{x:1661,y:867,t:1527614065470};\\\", \\\"{x:1658,y:867,t:1527614065484};\\\", \\\"{x:1650,y:865,t:1527614065501};\\\", \\\"{x:1639,y:863,t:1527614065517};\\\", \\\"{x:1604,y:857,t:1527614065534};\\\", \\\"{x:1580,y:851,t:1527614065551};\\\", \\\"{x:1554,y:842,t:1527614065567};\\\", \\\"{x:1530,y:833,t:1527614065584};\\\", \\\"{x:1502,y:811,t:1527614065600};\\\", \\\"{x:1463,y:775,t:1527614065616};\\\", \\\"{x:1403,y:722,t:1527614065634};\\\", \\\"{x:1339,y:676,t:1527614065651};\\\", \\\"{x:1289,y:634,t:1527614065667};\\\", \\\"{x:1257,y:616,t:1527614065684};\\\", \\\"{x:1247,y:610,t:1527614065701};\\\", \\\"{x:1245,y:608,t:1527614065717};\\\", \\\"{x:1245,y:609,t:1527614065886};\\\", \\\"{x:1245,y:612,t:1527614065901};\\\", \\\"{x:1246,y:616,t:1527614065918};\\\", \\\"{x:1246,y:619,t:1527614065933};\\\", \\\"{x:1247,y:623,t:1527614065951};\\\", \\\"{x:1249,y:627,t:1527614065968};\\\", \\\"{x:1250,y:629,t:1527614065984};\\\", \\\"{x:1251,y:631,t:1527614066001};\\\", \\\"{x:1251,y:634,t:1527614066018};\\\", \\\"{x:1255,y:638,t:1527614066034};\\\", \\\"{x:1257,y:642,t:1527614066050};\\\", \\\"{x:1260,y:649,t:1527614066068};\\\", \\\"{x:1263,y:654,t:1527614066084};\\\", \\\"{x:1265,y:659,t:1527614066101};\\\", \\\"{x:1268,y:663,t:1527614066118};\\\", \\\"{x:1269,y:665,t:1527614066134};\\\", \\\"{x:1270,y:669,t:1527614066150};\\\", \\\"{x:1271,y:673,t:1527614066168};\\\", \\\"{x:1271,y:674,t:1527614066184};\\\", \\\"{x:1272,y:679,t:1527614066201};\\\", \\\"{x:1272,y:682,t:1527614066218};\\\", \\\"{x:1272,y:684,t:1527614066234};\\\", \\\"{x:1272,y:689,t:1527614066251};\\\", \\\"{x:1272,y:691,t:1527614066278};\\\", \\\"{x:1272,y:692,t:1527614066294};\\\", \\\"{x:1272,y:693,t:1527614066302};\\\", \\\"{x:1271,y:694,t:1527614066317};\\\", \\\"{x:1268,y:696,t:1527614066335};\\\", \\\"{x:1261,y:697,t:1527614066351};\\\", \\\"{x:1253,y:697,t:1527614066368};\\\", \\\"{x:1244,y:697,t:1527614066384};\\\", \\\"{x:1239,y:697,t:1527614066400};\\\", \\\"{x:1234,y:697,t:1527614066418};\\\", \\\"{x:1230,y:697,t:1527614066435};\\\", \\\"{x:1229,y:697,t:1527614066470};\\\", \\\"{x:1228,y:696,t:1527614066494};\\\", \\\"{x:1228,y:695,t:1527614066566};\\\", \\\"{x:1228,y:693,t:1527614066638};\\\", \\\"{x:1228,y:692,t:1527614066654};\\\", \\\"{x:1227,y:691,t:1527614066686};\\\", \\\"{x:1227,y:690,t:1527614066854};\\\", \\\"{x:1232,y:690,t:1527614073710};\\\", \\\"{x:1236,y:690,t:1527614073723};\\\", \\\"{x:1247,y:691,t:1527614073740};\\\", \\\"{x:1261,y:693,t:1527614073757};\\\", \\\"{x:1264,y:694,t:1527614073774};\\\", \\\"{x:1266,y:694,t:1527614073790};\\\", \\\"{x:1270,y:695,t:1527614073807};\\\", \\\"{x:1271,y:695,t:1527614073845};\\\", \\\"{x:1273,y:695,t:1527614073862};\\\", \\\"{x:1275,y:695,t:1527614073874};\\\", \\\"{x:1278,y:695,t:1527614073889};\\\", \\\"{x:1281,y:695,t:1527614073906};\\\", \\\"{x:1284,y:695,t:1527614073923};\\\", \\\"{x:1289,y:695,t:1527614073939};\\\", \\\"{x:1297,y:695,t:1527614073956};\\\", \\\"{x:1303,y:695,t:1527614073973};\\\", \\\"{x:1309,y:695,t:1527614073989};\\\", \\\"{x:1314,y:695,t:1527614074007};\\\", \\\"{x:1318,y:693,t:1527614074023};\\\", \\\"{x:1321,y:692,t:1527614074040};\\\", \\\"{x:1323,y:692,t:1527614074056};\\\", \\\"{x:1326,y:690,t:1527614074074};\\\", \\\"{x:1327,y:689,t:1527614074092};\\\", \\\"{x:1329,y:689,t:1527614074107};\\\", \\\"{x:1332,y:688,t:1527614074124};\\\", \\\"{x:1339,y:688,t:1527614074140};\\\", \\\"{x:1346,y:688,t:1527614074157};\\\", \\\"{x:1347,y:688,t:1527614074173};\\\", \\\"{x:1349,y:687,t:1527614074192};\\\", \\\"{x:1348,y:687,t:1527614074822};\\\", \\\"{x:1347,y:688,t:1527614074830};\\\", \\\"{x:1344,y:690,t:1527614074840};\\\", \\\"{x:1342,y:691,t:1527614074858};\\\", \\\"{x:1341,y:693,t:1527614074874};\\\", \\\"{x:1340,y:693,t:1527614074891};\\\", \\\"{x:1340,y:692,t:1527614075006};\\\", \\\"{x:1343,y:688,t:1527614075014};\\\", \\\"{x:1347,y:683,t:1527614075024};\\\", \\\"{x:1356,y:673,t:1527614075041};\\\", \\\"{x:1365,y:663,t:1527614075059};\\\", \\\"{x:1371,y:655,t:1527614075075};\\\", \\\"{x:1378,y:645,t:1527614075091};\\\", \\\"{x:1385,y:634,t:1527614075108};\\\", \\\"{x:1394,y:618,t:1527614075125};\\\", \\\"{x:1398,y:614,t:1527614075141};\\\", \\\"{x:1401,y:607,t:1527614075158};\\\", \\\"{x:1404,y:601,t:1527614075175};\\\", \\\"{x:1407,y:595,t:1527614075192};\\\", \\\"{x:1408,y:591,t:1527614075208};\\\", \\\"{x:1409,y:587,t:1527614075225};\\\", \\\"{x:1410,y:584,t:1527614075242};\\\", \\\"{x:1410,y:582,t:1527614075258};\\\", \\\"{x:1410,y:579,t:1527614075275};\\\", \\\"{x:1410,y:578,t:1527614075292};\\\", \\\"{x:1410,y:574,t:1527614075309};\\\", \\\"{x:1409,y:568,t:1527614075326};\\\", \\\"{x:1407,y:565,t:1527614075341};\\\", \\\"{x:1406,y:563,t:1527614075358};\\\", \\\"{x:1405,y:561,t:1527614075375};\\\", \\\"{x:1404,y:560,t:1527614075397};\\\", \\\"{x:1404,y:559,t:1527614075413};\\\", \\\"{x:1404,y:558,t:1527614075430};\\\", \\\"{x:1404,y:557,t:1527614075590};\\\", \\\"{x:1404,y:555,t:1527614077726};\\\", \\\"{x:1405,y:553,t:1527614077743};\\\", \\\"{x:1407,y:553,t:1527614077760};\\\", \\\"{x:1410,y:551,t:1527614077814};\\\", \\\"{x:1411,y:551,t:1527614077862};\\\", \\\"{x:1412,y:551,t:1527614078262};\\\", \\\"{x:1413,y:551,t:1527614078510};\\\", \\\"{x:1413,y:552,t:1527614078533};\\\", \\\"{x:1413,y:553,t:1527614078544};\\\", \\\"{x:1413,y:554,t:1527614078561};\\\", \\\"{x:1412,y:554,t:1527614078581};\\\", \\\"{x:1412,y:556,t:1527614078597};\\\", \\\"{x:1412,y:557,t:1527614078621};\\\", \\\"{x:1412,y:559,t:1527614078664};\\\", \\\"{x:1412,y:560,t:1527614078709};\\\", \\\"{x:1412,y:562,t:1527614078805};\\\", \\\"{x:1412,y:563,t:1527614078861};\\\", \\\"{x:1413,y:563,t:1527614078934};\\\", \\\"{x:1413,y:566,t:1527614085012};\\\", \\\"{x:1412,y:568,t:1527614085020};\\\", \\\"{x:1411,y:571,t:1527614085033};\\\", \\\"{x:1409,y:579,t:1527614085049};\\\", \\\"{x:1405,y:588,t:1527614085065};\\\", \\\"{x:1403,y:595,t:1527614085082};\\\", \\\"{x:1401,y:601,t:1527614085099};\\\", \\\"{x:1399,y:607,t:1527614085116};\\\", \\\"{x:1398,y:614,t:1527614085132};\\\", \\\"{x:1397,y:620,t:1527614085148};\\\", \\\"{x:1395,y:627,t:1527614085165};\\\", \\\"{x:1391,y:633,t:1527614085182};\\\", \\\"{x:1390,y:636,t:1527614085199};\\\", \\\"{x:1388,y:643,t:1527614085217};\\\", \\\"{x:1386,y:652,t:1527614085232};\\\", \\\"{x:1383,y:662,t:1527614085249};\\\", \\\"{x:1377,y:674,t:1527614085266};\\\", \\\"{x:1372,y:685,t:1527614085282};\\\", \\\"{x:1363,y:697,t:1527614085299};\\\", \\\"{x:1357,y:707,t:1527614085316};\\\", \\\"{x:1351,y:715,t:1527614085332};\\\", \\\"{x:1343,y:723,t:1527614085349};\\\", \\\"{x:1341,y:728,t:1527614085367};\\\", \\\"{x:1340,y:728,t:1527614085382};\\\", \\\"{x:1340,y:729,t:1527614085485};\\\", \\\"{x:1339,y:729,t:1527614085499};\\\", \\\"{x:1335,y:732,t:1527614085516};\\\", \\\"{x:1329,y:736,t:1527614085532};\\\", \\\"{x:1316,y:741,t:1527614085549};\\\", \\\"{x:1307,y:747,t:1527614085566};\\\", \\\"{x:1302,y:750,t:1527614085582};\\\", \\\"{x:1298,y:753,t:1527614085599};\\\", \\\"{x:1295,y:754,t:1527614085616};\\\", \\\"{x:1289,y:758,t:1527614085632};\\\", \\\"{x:1281,y:770,t:1527614085649};\\\", \\\"{x:1268,y:778,t:1527614085666};\\\", \\\"{x:1255,y:783,t:1527614085683};\\\", \\\"{x:1248,y:786,t:1527614085699};\\\", \\\"{x:1236,y:792,t:1527614085716};\\\", \\\"{x:1227,y:798,t:1527614085732};\\\", \\\"{x:1221,y:804,t:1527614085749};\\\", \\\"{x:1215,y:810,t:1527614085766};\\\", \\\"{x:1212,y:811,t:1527614085783};\\\", \\\"{x:1211,y:812,t:1527614085799};\\\", \\\"{x:1211,y:813,t:1527614085836};\\\", \\\"{x:1211,y:814,t:1527614086173};\\\", \\\"{x:1211,y:815,t:1527614086421};\\\", \\\"{x:1211,y:814,t:1527614087252};\\\", \\\"{x:1210,y:812,t:1527614087717};\\\", \\\"{x:1196,y:812,t:1527614087724};\\\", \\\"{x:1170,y:812,t:1527614087734};\\\", \\\"{x:1106,y:804,t:1527614087751};\\\", \\\"{x:1053,y:796,t:1527614087767};\\\", \\\"{x:986,y:786,t:1527614087785};\\\", \\\"{x:936,y:780,t:1527614087801};\\\", \\\"{x:899,y:770,t:1527614087817};\\\", \\\"{x:869,y:764,t:1527614087834};\\\", \\\"{x:835,y:762,t:1527614087851};\\\", \\\"{x:792,y:760,t:1527614087868};\\\", \\\"{x:766,y:754,t:1527614087884};\\\", \\\"{x:726,y:740,t:1527614087901};\\\", \\\"{x:672,y:718,t:1527614087918};\\\", \\\"{x:653,y:706,t:1527614087935};\\\", \\\"{x:648,y:702,t:1527614087951};\\\", \\\"{x:648,y:701,t:1527614087968};\\\", \\\"{x:643,y:697,t:1527614087984};\\\", \\\"{x:636,y:687,t:1527614088001};\\\", \\\"{x:615,y:669,t:1527614088018};\\\", \\\"{x:588,y:646,t:1527614088034};\\\", \\\"{x:547,y:609,t:1527614088052};\\\", \\\"{x:490,y:560,t:1527614088069};\\\", \\\"{x:469,y:545,t:1527614088085};\\\", \\\"{x:454,y:539,t:1527614088101};\\\", \\\"{x:448,y:538,t:1527614088118};\\\", \\\"{x:442,y:535,t:1527614088135};\\\", \\\"{x:434,y:534,t:1527614088151};\\\", \\\"{x:430,y:534,t:1527614088168};\\\", \\\"{x:427,y:534,t:1527614088185};\\\", \\\"{x:420,y:535,t:1527614088201};\\\", \\\"{x:416,y:538,t:1527614088218};\\\", \\\"{x:414,y:541,t:1527614088235};\\\", \\\"{x:414,y:543,t:1527614088251};\\\", \\\"{x:414,y:545,t:1527614088677};\\\", \\\"{x:413,y:544,t:1527614088709};\\\", \\\"{x:411,y:544,t:1527614088757};\\\", \\\"{x:409,y:542,t:1527614088768};\\\", \\\"{x:408,y:542,t:1527614088785};\\\", \\\"{x:404,y:540,t:1527614088802};\\\", \\\"{x:402,y:540,t:1527614088818};\\\", \\\"{x:401,y:539,t:1527614088835};\\\", \\\"{x:396,y:535,t:1527614088852};\\\", \\\"{x:391,y:531,t:1527614088868};\\\", \\\"{x:387,y:528,t:1527614088886};\\\", \\\"{x:383,y:526,t:1527614088902};\\\", \\\"{x:379,y:523,t:1527614088919};\\\", \\\"{x:377,y:520,t:1527614088935};\\\", \\\"{x:375,y:519,t:1527614088952};\\\", \\\"{x:375,y:518,t:1527614088969};\\\", \\\"{x:375,y:517,t:1527614088986};\\\", \\\"{x:373,y:515,t:1527614089002};\\\", \\\"{x:373,y:514,t:1527614089044};\\\", \\\"{x:373,y:513,t:1527614089076};\\\", \\\"{x:373,y:512,t:1527614089092};\\\", \\\"{x:373,y:510,t:1527614089116};\\\", \\\"{x:374,y:510,t:1527614089124};\\\", \\\"{x:376,y:508,t:1527614089140};\\\", \\\"{x:377,y:507,t:1527614089156};\\\", \\\"{x:379,y:507,t:1527614089172};\\\", \\\"{x:379,y:506,t:1527614089185};\\\", \\\"{x:379,y:505,t:1527614089202};\\\", \\\"{x:379,y:504,t:1527614089219};\\\", \\\"{x:380,y:504,t:1527614089235};\\\", \\\"{x:381,y:504,t:1527614089252};\\\", \\\"{x:382,y:503,t:1527614089284};\\\", \\\"{x:382,y:502,t:1527614089301};\\\", \\\"{x:383,y:502,t:1527614089756};\\\", \\\"{x:386,y:502,t:1527614089769};\\\", \\\"{x:388,y:503,t:1527614089786};\\\", \\\"{x:389,y:503,t:1527614089802};\\\", \\\"{x:389,y:504,t:1527614089828};\\\", \\\"{x:396,y:506,t:1527614090653};\\\", \\\"{x:446,y:513,t:1527614090671};\\\", \\\"{x:494,y:521,t:1527614090686};\\\", \\\"{x:520,y:523,t:1527614090703};\\\", \\\"{x:553,y:528,t:1527614090721};\\\", \\\"{x:604,y:535,t:1527614090738};\\\", \\\"{x:673,y:546,t:1527614090753};\\\", \\\"{x:742,y:559,t:1527614090770};\\\", \\\"{x:803,y:570,t:1527614090787};\\\", \\\"{x:859,y:578,t:1527614090803};\\\", \\\"{x:904,y:587,t:1527614090820};\\\", \\\"{x:927,y:590,t:1527614090837};\\\", \\\"{x:954,y:595,t:1527614090853};\\\", \\\"{x:1004,y:603,t:1527614090870};\\\", \\\"{x:1046,y:607,t:1527614090887};\\\", \\\"{x:1072,y:607,t:1527614090904};\\\", \\\"{x:1090,y:604,t:1527614090921};\\\", \\\"{x:1110,y:596,t:1527614090937};\\\", \\\"{x:1138,y:587,t:1527614090953};\\\", \\\"{x:1186,y:574,t:1527614090970};\\\", \\\"{x:1234,y:558,t:1527614090986};\\\", \\\"{x:1270,y:541,t:1527614091003};\\\", \\\"{x:1288,y:525,t:1527614091020};\\\", \\\"{x:1291,y:521,t:1527614091036};\\\", \\\"{x:1293,y:511,t:1527614091053};\\\", \\\"{x:1295,y:501,t:1527614091069};\\\", \\\"{x:1298,y:488,t:1527614091086};\\\", \\\"{x:1305,y:470,t:1527614091103};\\\", \\\"{x:1315,y:453,t:1527614091119};\\\", \\\"{x:1325,y:437,t:1527614091136};\\\", \\\"{x:1339,y:423,t:1527614091153};\\\", \\\"{x:1348,y:412,t:1527614091169};\\\", \\\"{x:1354,y:406,t:1527614091187};\\\", \\\"{x:1356,y:405,t:1527614091203};\\\", \\\"{x:1356,y:404,t:1527614091260};\\\", \\\"{x:1356,y:403,t:1527614091269};\\\", \\\"{x:1367,y:400,t:1527614091286};\\\", \\\"{x:1373,y:398,t:1527614091302};\\\", \\\"{x:1374,y:398,t:1527614091319};\\\", \\\"{x:1374,y:397,t:1527614091336};\\\", \\\"{x:1375,y:397,t:1527614091396};\\\", \\\"{x:1376,y:397,t:1527614091404};\\\", \\\"{x:1377,y:397,t:1527614091419};\\\", \\\"{x:1380,y:398,t:1527614091436};\\\", \\\"{x:1381,y:399,t:1527614091452};\\\", \\\"{x:1383,y:400,t:1527614091469};\\\", \\\"{x:1386,y:400,t:1527614091485};\\\", \\\"{x:1388,y:402,t:1527614091502};\\\", \\\"{x:1389,y:405,t:1527614091519};\\\", \\\"{x:1390,y:409,t:1527614091535};\\\", \\\"{x:1393,y:418,t:1527614091553};\\\", \\\"{x:1396,y:425,t:1527614091569};\\\", \\\"{x:1401,y:434,t:1527614091585};\\\", \\\"{x:1408,y:444,t:1527614091603};\\\", \\\"{x:1413,y:456,t:1527614091618};\\\", \\\"{x:1419,y:467,t:1527614091635};\\\", \\\"{x:1423,y:482,t:1527614091652};\\\", \\\"{x:1431,y:496,t:1527614091668};\\\", \\\"{x:1439,y:510,t:1527614091686};\\\", \\\"{x:1447,y:521,t:1527614091703};\\\", \\\"{x:1451,y:526,t:1527614091718};\\\", \\\"{x:1453,y:531,t:1527614091735};\\\", \\\"{x:1453,y:533,t:1527614091752};\\\", \\\"{x:1453,y:535,t:1527614091772};\\\", \\\"{x:1454,y:537,t:1527614091786};\\\", \\\"{x:1455,y:539,t:1527614091803};\\\", \\\"{x:1455,y:543,t:1527614091818};\\\", \\\"{x:1451,y:548,t:1527614091836};\\\", \\\"{x:1448,y:552,t:1527614091851};\\\", \\\"{x:1442,y:559,t:1527614091868};\\\", \\\"{x:1438,y:566,t:1527614091886};\\\", \\\"{x:1428,y:574,t:1527614091901};\\\", \\\"{x:1413,y:586,t:1527614091919};\\\", \\\"{x:1396,y:596,t:1527614091936};\\\", \\\"{x:1373,y:606,t:1527614091951};\\\", \\\"{x:1358,y:612,t:1527614091968};\\\", \\\"{x:1351,y:617,t:1527614091984};\\\", \\\"{x:1349,y:619,t:1527614092001};\\\", \\\"{x:1349,y:620,t:1527614092018};\\\", \\\"{x:1349,y:621,t:1527614092036};\\\", \\\"{x:1349,y:623,t:1527614092051};\\\", \\\"{x:1349,y:625,t:1527614092068};\\\", \\\"{x:1349,y:626,t:1527614092100};\\\", \\\"{x:1349,y:627,t:1527614092108};\\\", \\\"{x:1350,y:629,t:1527614092124};\\\", \\\"{x:1353,y:629,t:1527614092134};\\\", \\\"{x:1358,y:629,t:1527614092151};\\\", \\\"{x:1361,y:630,t:1527614092168};\\\", \\\"{x:1365,y:631,t:1527614092184};\\\", \\\"{x:1369,y:631,t:1527614092201};\\\", \\\"{x:1371,y:631,t:1527614092217};\\\", \\\"{x:1374,y:631,t:1527614092236};\\\", \\\"{x:1377,y:630,t:1527614092253};\\\", \\\"{x:1379,y:628,t:1527614092267};\\\", \\\"{x:1384,y:620,t:1527614092285};\\\", \\\"{x:1389,y:612,t:1527614092302};\\\", \\\"{x:1392,y:608,t:1527614092318};\\\", \\\"{x:1393,y:602,t:1527614092334};\\\", \\\"{x:1396,y:597,t:1527614092352};\\\", \\\"{x:1396,y:594,t:1527614092368};\\\", \\\"{x:1399,y:589,t:1527614092384};\\\", \\\"{x:1399,y:587,t:1527614092400};\\\", \\\"{x:1399,y:585,t:1527614092417};\\\", \\\"{x:1399,y:583,t:1527614092434};\\\", \\\"{x:1399,y:579,t:1527614092450};\\\", \\\"{x:1399,y:577,t:1527614092467};\\\", \\\"{x:1399,y:574,t:1527614092484};\\\", \\\"{x:1400,y:571,t:1527614092500};\\\", \\\"{x:1400,y:565,t:1527614092518};\\\", \\\"{x:1401,y:561,t:1527614092534};\\\", \\\"{x:1403,y:556,t:1527614092551};\\\", \\\"{x:1403,y:554,t:1527614092568};\\\", \\\"{x:1403,y:553,t:1527614092621};\\\", \\\"{x:1401,y:557,t:1527614092633};\\\", \\\"{x:1388,y:586,t:1527614092650};\\\", \\\"{x:1369,y:630,t:1527614092667};\\\", \\\"{x:1346,y:673,t:1527614092684};\\\", \\\"{x:1325,y:724,t:1527614092701};\\\", \\\"{x:1316,y:741,t:1527614092718};\\\", \\\"{x:1300,y:794,t:1527614092734};\\\", \\\"{x:1280,y:838,t:1527614092750};\\\", \\\"{x:1246,y:891,t:1527614092766};\\\", \\\"{x:1209,y:933,t:1527614092784};\\\", \\\"{x:1171,y:957,t:1527614092800};\\\", \\\"{x:1128,y:972,t:1527614092816};\\\", \\\"{x:1061,y:980,t:1527614092834};\\\", \\\"{x:986,y:980,t:1527614092850};\\\", \\\"{x:871,y:971,t:1527614092866};\\\", \\\"{x:725,y:936,t:1527614092883};\\\", \\\"{x:524,y:885,t:1527614092900};\\\", \\\"{x:435,y:860,t:1527614092916};\\\", \\\"{x:399,y:851,t:1527614092934};\\\", \\\"{x:385,y:845,t:1527614092949};\\\", \\\"{x:382,y:844,t:1527614092967};\\\", \\\"{x:382,y:843,t:1527614092989};\\\", \\\"{x:382,y:842,t:1527614092999};\\\", \\\"{x:382,y:836,t:1527614093016};\\\", \\\"{x:383,y:832,t:1527614093034};\\\", \\\"{x:385,y:823,t:1527614093049};\\\", \\\"{x:394,y:807,t:1527614093067};\\\", \\\"{x:412,y:788,t:1527614093083};\\\", \\\"{x:433,y:772,t:1527614093100};\\\", \\\"{x:461,y:755,t:1527614093116};\\\", \\\"{x:477,y:743,t:1527614093133};\\\", \\\"{x:491,y:734,t:1527614093149};\\\", \\\"{x:498,y:728,t:1527614093166};\\\", \\\"{x:507,y:721,t:1527614093188};\\\", \\\"{x:510,y:718,t:1527614093206};\\\", \\\"{x:513,y:716,t:1527614093222};\\\", \\\"{x:518,y:714,t:1527614093238};\\\", \\\"{x:521,y:712,t:1527614093256};\\\", \\\"{x:524,y:712,t:1527614093272};\\\", \\\"{x:525,y:711,t:1527614093288};\\\", \\\"{x:524,y:713,t:1527614093461};\\\", \\\"{x:522,y:715,t:1527614093477};\\\", \\\"{x:521,y:718,t:1527614093489};\\\", \\\"{x:520,y:722,t:1527614093506};\\\", \\\"{x:517,y:726,t:1527614093522};\\\", \\\"{x:516,y:729,t:1527614093540};\\\", \\\"{x:515,y:731,t:1527614093556};\\\", \\\"{x:514,y:731,t:1527614093573};\\\" ] }, { \\\"rt\\\": 21952, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 441586, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:736,t:1527614096960};\\\", \\\"{x:519,y:746,t:1527614096980};\\\", \\\"{x:521,y:750,t:1527614096986};\\\", \\\"{x:525,y:753,t:1527614096999};\\\", \\\"{x:536,y:759,t:1527614097016};\\\", \\\"{x:547,y:764,t:1527614097032};\\\", \\\"{x:555,y:768,t:1527614097049};\\\", \\\"{x:562,y:770,t:1527614097062};\\\", \\\"{x:590,y:782,t:1527614097079};\\\", \\\"{x:620,y:795,t:1527614097095};\\\", \\\"{x:682,y:815,t:1527614097112};\\\", \\\"{x:727,y:828,t:1527614097129};\\\", \\\"{x:783,y:843,t:1527614097145};\\\", \\\"{x:807,y:850,t:1527614097162};\\\", \\\"{x:835,y:858,t:1527614097179};\\\", \\\"{x:867,y:868,t:1527614097196};\\\", \\\"{x:896,y:880,t:1527614097212};\\\", \\\"{x:931,y:889,t:1527614097229};\\\", \\\"{x:959,y:896,t:1527614097245};\\\", \\\"{x:982,y:902,t:1527614097262};\\\", \\\"{x:1004,y:911,t:1527614097280};\\\", \\\"{x:1015,y:916,t:1527614097295};\\\", \\\"{x:1019,y:917,t:1527614097312};\\\", \\\"{x:1028,y:920,t:1527614097329};\\\", \\\"{x:1044,y:925,t:1527614097345};\\\", \\\"{x:1058,y:927,t:1527614097363};\\\", \\\"{x:1071,y:929,t:1527614097380};\\\", \\\"{x:1081,y:930,t:1527614097396};\\\", \\\"{x:1089,y:934,t:1527614097413};\\\", \\\"{x:1101,y:936,t:1527614097430};\\\", \\\"{x:1120,y:940,t:1527614097445};\\\", \\\"{x:1135,y:941,t:1527614097462};\\\", \\\"{x:1155,y:944,t:1527614097479};\\\", \\\"{x:1175,y:949,t:1527614097496};\\\", \\\"{x:1201,y:950,t:1527614097513};\\\", \\\"{x:1230,y:950,t:1527614097530};\\\", \\\"{x:1249,y:952,t:1527614097547};\\\", \\\"{x:1266,y:952,t:1527614097563};\\\", \\\"{x:1271,y:952,t:1527614097580};\\\", \\\"{x:1273,y:952,t:1527614097596};\\\", \\\"{x:1275,y:952,t:1527614097612};\\\", \\\"{x:1282,y:955,t:1527614097630};\\\", \\\"{x:1285,y:955,t:1527614097646};\\\", \\\"{x:1286,y:955,t:1527614097663};\\\", \\\"{x:1287,y:956,t:1527614097721};\\\", \\\"{x:1290,y:957,t:1527614097730};\\\", \\\"{x:1293,y:958,t:1527614097747};\\\", \\\"{x:1299,y:959,t:1527614097763};\\\", \\\"{x:1304,y:960,t:1527614097780};\\\", \\\"{x:1311,y:962,t:1527614097797};\\\", \\\"{x:1320,y:964,t:1527614097813};\\\", \\\"{x:1333,y:967,t:1527614097830};\\\", \\\"{x:1348,y:967,t:1527614097847};\\\", \\\"{x:1355,y:967,t:1527614097864};\\\", \\\"{x:1359,y:967,t:1527614097879};\\\", \\\"{x:1361,y:967,t:1527614097896};\\\", \\\"{x:1362,y:967,t:1527614097913};\\\", \\\"{x:1364,y:965,t:1527614097929};\\\", \\\"{x:1365,y:964,t:1527614097947};\\\", \\\"{x:1365,y:963,t:1527614097963};\\\", \\\"{x:1365,y:962,t:1527614098128};\\\", \\\"{x:1363,y:960,t:1527614098147};\\\", \\\"{x:1358,y:960,t:1527614098164};\\\", \\\"{x:1354,y:958,t:1527614098180};\\\", \\\"{x:1352,y:958,t:1527614098197};\\\", \\\"{x:1351,y:957,t:1527614098213};\\\", \\\"{x:1349,y:955,t:1527614098441};\\\", \\\"{x:1348,y:955,t:1527614099106};\\\", \\\"{x:1346,y:956,t:1527614099409};\\\", \\\"{x:1346,y:957,t:1527614099465};\\\", \\\"{x:1346,y:958,t:1527614099577};\\\", \\\"{x:1346,y:959,t:1527614099593};\\\", \\\"{x:1345,y:960,t:1527614099681};\\\", \\\"{x:1344,y:961,t:1527614099704};\\\", \\\"{x:1343,y:962,t:1527614099721};\\\", \\\"{x:1343,y:963,t:1527614099760};\\\", \\\"{x:1342,y:963,t:1527614100673};\\\", \\\"{x:1342,y:962,t:1527614100682};\\\", \\\"{x:1341,y:961,t:1527614100699};\\\", \\\"{x:1341,y:960,t:1527614100745};\\\", \\\"{x:1340,y:960,t:1527614100753};\\\", \\\"{x:1340,y:958,t:1527614101881};\\\", \\\"{x:1339,y:956,t:1527614101896};\\\", \\\"{x:1338,y:955,t:1527614101904};\\\", \\\"{x:1338,y:953,t:1527614101920};\\\", \\\"{x:1338,y:952,t:1527614101936};\\\", \\\"{x:1338,y:950,t:1527614101950};\\\", \\\"{x:1338,y:949,t:1527614101977};\\\", \\\"{x:1337,y:948,t:1527614101984};\\\", \\\"{x:1337,y:947,t:1527614102000};\\\", \\\"{x:1334,y:942,t:1527614102017};\\\", \\\"{x:1334,y:939,t:1527614102033};\\\", \\\"{x:1331,y:935,t:1527614102050};\\\", \\\"{x:1331,y:931,t:1527614102067};\\\", \\\"{x:1329,y:926,t:1527614102083};\\\", \\\"{x:1327,y:920,t:1527614102100};\\\", \\\"{x:1325,y:913,t:1527614102117};\\\", \\\"{x:1322,y:901,t:1527614102133};\\\", \\\"{x:1319,y:887,t:1527614102150};\\\", \\\"{x:1317,y:882,t:1527614102167};\\\", \\\"{x:1313,y:872,t:1527614102183};\\\", \\\"{x:1309,y:862,t:1527614102200};\\\", \\\"{x:1308,y:852,t:1527614102216};\\\", \\\"{x:1307,y:849,t:1527614102233};\\\", \\\"{x:1306,y:844,t:1527614102250};\\\", \\\"{x:1304,y:841,t:1527614102267};\\\", \\\"{x:1304,y:837,t:1527614102283};\\\", \\\"{x:1304,y:833,t:1527614102300};\\\", \\\"{x:1304,y:829,t:1527614102316};\\\", \\\"{x:1304,y:826,t:1527614102333};\\\", \\\"{x:1304,y:823,t:1527614102349};\\\", \\\"{x:1304,y:820,t:1527614102366};\\\", \\\"{x:1304,y:818,t:1527614102384};\\\", \\\"{x:1304,y:816,t:1527614102399};\\\", \\\"{x:1304,y:814,t:1527614102416};\\\", \\\"{x:1305,y:813,t:1527614102433};\\\", \\\"{x:1306,y:810,t:1527614102450};\\\", \\\"{x:1306,y:808,t:1527614102472};\\\", \\\"{x:1308,y:807,t:1527614102483};\\\", \\\"{x:1308,y:806,t:1527614102499};\\\", \\\"{x:1308,y:805,t:1527614102516};\\\", \\\"{x:1309,y:804,t:1527614102533};\\\", \\\"{x:1310,y:801,t:1527614102552};\\\", \\\"{x:1311,y:800,t:1527614102568};\\\", \\\"{x:1312,y:800,t:1527614102584};\\\", \\\"{x:1312,y:798,t:1527614102599};\\\", \\\"{x:1312,y:797,t:1527614102632};\\\", \\\"{x:1313,y:795,t:1527614102656};\\\", \\\"{x:1313,y:794,t:1527614102667};\\\", \\\"{x:1314,y:791,t:1527614102683};\\\", \\\"{x:1315,y:789,t:1527614102700};\\\", \\\"{x:1315,y:788,t:1527614102716};\\\", \\\"{x:1316,y:786,t:1527614102734};\\\", \\\"{x:1316,y:785,t:1527614102750};\\\", \\\"{x:1317,y:783,t:1527614102766};\\\", \\\"{x:1317,y:782,t:1527614102783};\\\", \\\"{x:1319,y:781,t:1527614102800};\\\", \\\"{x:1319,y:780,t:1527614102816};\\\", \\\"{x:1321,y:778,t:1527614102834};\\\", \\\"{x:1322,y:778,t:1527614102850};\\\", \\\"{x:1323,y:776,t:1527614102866};\\\", \\\"{x:1324,y:775,t:1527614102883};\\\", \\\"{x:1325,y:774,t:1527614102920};\\\", \\\"{x:1326,y:774,t:1527614102936};\\\", \\\"{x:1326,y:772,t:1527614102950};\\\", \\\"{x:1328,y:771,t:1527614102966};\\\", \\\"{x:1329,y:769,t:1527614102983};\\\", \\\"{x:1329,y:768,t:1527614103016};\\\", \\\"{x:1330,y:768,t:1527614103024};\\\", \\\"{x:1331,y:767,t:1527614103034};\\\", \\\"{x:1332,y:765,t:1527614103051};\\\", \\\"{x:1333,y:765,t:1527614103066};\\\", \\\"{x:1334,y:764,t:1527614103084};\\\", \\\"{x:1335,y:763,t:1527614103101};\\\", \\\"{x:1337,y:761,t:1527614103117};\\\", \\\"{x:1337,y:760,t:1527614103176};\\\", \\\"{x:1338,y:759,t:1527614103191};\\\", \\\"{x:1339,y:759,t:1527614103216};\\\", \\\"{x:1338,y:759,t:1527614103912};\\\", \\\"{x:1336,y:760,t:1527614103920};\\\", \\\"{x:1331,y:762,t:1527614103934};\\\", \\\"{x:1323,y:766,t:1527614103951};\\\", \\\"{x:1296,y:773,t:1527614103968};\\\", \\\"{x:1262,y:778,t:1527614103984};\\\", \\\"{x:1231,y:783,t:1527614104000};\\\", \\\"{x:1186,y:784,t:1527614104018};\\\", \\\"{x:1141,y:784,t:1527614104035};\\\", \\\"{x:1114,y:784,t:1527614104051};\\\", \\\"{x:1081,y:784,t:1527614104067};\\\", \\\"{x:1045,y:779,t:1527614104085};\\\", \\\"{x:992,y:771,t:1527614104101};\\\", \\\"{x:935,y:760,t:1527614104117};\\\", \\\"{x:894,y:751,t:1527614104135};\\\", \\\"{x:823,y:728,t:1527614104152};\\\", \\\"{x:794,y:719,t:1527614104168};\\\", \\\"{x:775,y:713,t:1527614104184};\\\", \\\"{x:754,y:705,t:1527614104201};\\\", \\\"{x:735,y:697,t:1527614104217};\\\", \\\"{x:719,y:689,t:1527614104234};\\\", \\\"{x:702,y:678,t:1527614104252};\\\", \\\"{x:685,y:667,t:1527614104267};\\\", \\\"{x:672,y:657,t:1527614104285};\\\", \\\"{x:662,y:648,t:1527614104301};\\\", \\\"{x:652,y:638,t:1527614104318};\\\", \\\"{x:646,y:629,t:1527614104335};\\\", \\\"{x:637,y:615,t:1527614104352};\\\", \\\"{x:631,y:595,t:1527614104368};\\\", \\\"{x:630,y:582,t:1527614104384};\\\", \\\"{x:628,y:573,t:1527614104401};\\\", \\\"{x:629,y:565,t:1527614104417};\\\", \\\"{x:629,y:558,t:1527614104435};\\\", \\\"{x:629,y:553,t:1527614104452};\\\", \\\"{x:629,y:549,t:1527614104468};\\\", \\\"{x:629,y:548,t:1527614104484};\\\", \\\"{x:629,y:545,t:1527614104501};\\\", \\\"{x:628,y:545,t:1527614104592};\\\", \\\"{x:626,y:545,t:1527614104607};\\\", \\\"{x:625,y:545,t:1527614104648};\\\", \\\"{x:624,y:545,t:1527614104655};\\\", \\\"{x:623,y:545,t:1527614104668};\\\", \\\"{x:621,y:546,t:1527614104685};\\\", \\\"{x:619,y:547,t:1527614104702};\\\", \\\"{x:617,y:548,t:1527614104718};\\\", \\\"{x:617,y:549,t:1527614104751};\\\", \\\"{x:619,y:551,t:1527614104791};\\\", \\\"{x:619,y:552,t:1527614104803};\\\", \\\"{x:630,y:554,t:1527614104819};\\\", \\\"{x:643,y:557,t:1527614104835};\\\", \\\"{x:664,y:558,t:1527614104852};\\\", \\\"{x:684,y:558,t:1527614104869};\\\", \\\"{x:700,y:555,t:1527614104886};\\\", \\\"{x:718,y:551,t:1527614104901};\\\", \\\"{x:746,y:550,t:1527614104919};\\\", \\\"{x:800,y:549,t:1527614104935};\\\", \\\"{x:832,y:545,t:1527614104951};\\\", \\\"{x:862,y:545,t:1527614104969};\\\", \\\"{x:881,y:542,t:1527614104985};\\\", \\\"{x:892,y:537,t:1527614105002};\\\", \\\"{x:900,y:529,t:1527614105018};\\\", \\\"{x:903,y:527,t:1527614105035};\\\", \\\"{x:904,y:524,t:1527614105052};\\\", \\\"{x:904,y:523,t:1527614105069};\\\", \\\"{x:904,y:521,t:1527614105086};\\\", \\\"{x:902,y:519,t:1527614105101};\\\", \\\"{x:897,y:518,t:1527614105119};\\\", \\\"{x:883,y:510,t:1527614105135};\\\", \\\"{x:877,y:509,t:1527614105151};\\\", \\\"{x:870,y:505,t:1527614105168};\\\", \\\"{x:862,y:503,t:1527614105186};\\\", \\\"{x:861,y:503,t:1527614105201};\\\", \\\"{x:859,y:502,t:1527614105218};\\\", \\\"{x:857,y:502,t:1527614105392};\\\", \\\"{x:856,y:502,t:1527614105415};\\\", \\\"{x:854,y:502,t:1527614105424};\\\", \\\"{x:852,y:502,t:1527614105440};\\\", \\\"{x:851,y:502,t:1527614105452};\\\", \\\"{x:849,y:501,t:1527614105468};\\\", \\\"{x:847,y:501,t:1527614105486};\\\", \\\"{x:846,y:501,t:1527614105504};\\\", \\\"{x:845,y:501,t:1527614105520};\\\", \\\"{x:844,y:501,t:1527614105535};\\\", \\\"{x:841,y:501,t:1527614105552};\\\", \\\"{x:840,y:500,t:1527614105569};\\\", \\\"{x:838,y:499,t:1527614105586};\\\", \\\"{x:837,y:499,t:1527614105603};\\\", \\\"{x:834,y:498,t:1527614105619};\\\", \\\"{x:831,y:498,t:1527614105636};\\\", \\\"{x:830,y:496,t:1527614105652};\\\", \\\"{x:829,y:496,t:1527614105681};\\\", \\\"{x:827,y:496,t:1527614107760};\\\", \\\"{x:824,y:496,t:1527614107771};\\\", \\\"{x:814,y:499,t:1527614107787};\\\", \\\"{x:808,y:500,t:1527614107803};\\\", \\\"{x:804,y:501,t:1527614107821};\\\", \\\"{x:800,y:502,t:1527614107837};\\\", \\\"{x:799,y:502,t:1527614107854};\\\", \\\"{x:797,y:502,t:1527614107871};\\\", \\\"{x:789,y:502,t:1527614107887};\\\", \\\"{x:781,y:502,t:1527614107904};\\\", \\\"{x:769,y:502,t:1527614107921};\\\", \\\"{x:758,y:502,t:1527614107937};\\\", \\\"{x:743,y:502,t:1527614107954};\\\", \\\"{x:724,y:502,t:1527614107970};\\\", \\\"{x:706,y:502,t:1527614107988};\\\", \\\"{x:690,y:502,t:1527614108005};\\\", \\\"{x:669,y:502,t:1527614108021};\\\", \\\"{x:654,y:502,t:1527614108037};\\\", \\\"{x:642,y:502,t:1527614108055};\\\", \\\"{x:633,y:502,t:1527614108070};\\\", \\\"{x:625,y:502,t:1527614108087};\\\", \\\"{x:617,y:503,t:1527614108105};\\\", \\\"{x:606,y:507,t:1527614108120};\\\", \\\"{x:591,y:511,t:1527614108138};\\\", \\\"{x:574,y:517,t:1527614108155};\\\", \\\"{x:555,y:521,t:1527614108170};\\\", \\\"{x:543,y:523,t:1527614108188};\\\", \\\"{x:531,y:527,t:1527614108205};\\\", \\\"{x:518,y:528,t:1527614108220};\\\", \\\"{x:510,y:531,t:1527614108238};\\\", \\\"{x:503,y:532,t:1527614108254};\\\", \\\"{x:498,y:535,t:1527614108271};\\\", \\\"{x:492,y:538,t:1527614108287};\\\", \\\"{x:491,y:538,t:1527614108304};\\\", \\\"{x:490,y:539,t:1527614108321};\\\", \\\"{x:489,y:539,t:1527614108383};\\\", \\\"{x:489,y:540,t:1527614108431};\\\", \\\"{x:488,y:541,t:1527614108495};\\\", \\\"{x:488,y:542,t:1527614110815};\\\", \\\"{x:487,y:543,t:1527614110823};\\\", \\\"{x:486,y:544,t:1527614110847};\\\", \\\"{x:485,y:544,t:1527614110857};\\\", \\\"{x:485,y:545,t:1527614110872};\\\", \\\"{x:484,y:545,t:1527614110890};\\\", \\\"{x:482,y:545,t:1527614110907};\\\", \\\"{x:480,y:547,t:1527614110922};\\\", \\\"{x:479,y:547,t:1527614110940};\\\", \\\"{x:478,y:547,t:1527614110957};\\\", \\\"{x:478,y:548,t:1527614110973};\\\", \\\"{x:476,y:550,t:1527614110990};\\\", \\\"{x:475,y:551,t:1527614111006};\\\", \\\"{x:476,y:552,t:1527614111072};\\\", \\\"{x:480,y:552,t:1527614111080};\\\", \\\"{x:489,y:554,t:1527614111090};\\\", \\\"{x:504,y:556,t:1527614111107};\\\", \\\"{x:524,y:560,t:1527614111123};\\\", \\\"{x:544,y:563,t:1527614111140};\\\", \\\"{x:568,y:566,t:1527614111157};\\\", \\\"{x:587,y:567,t:1527614111174};\\\", \\\"{x:610,y:568,t:1527614111190};\\\", \\\"{x:634,y:573,t:1527614111207};\\\", \\\"{x:660,y:577,t:1527614111224};\\\", \\\"{x:675,y:581,t:1527614111240};\\\", \\\"{x:689,y:583,t:1527614111256};\\\", \\\"{x:703,y:586,t:1527614111273};\\\", \\\"{x:711,y:587,t:1527614111289};\\\", \\\"{x:722,y:587,t:1527614111306};\\\", \\\"{x:731,y:587,t:1527614111325};\\\", \\\"{x:736,y:587,t:1527614111341};\\\", \\\"{x:738,y:587,t:1527614111357};\\\", \\\"{x:740,y:587,t:1527614111416};\\\", \\\"{x:742,y:587,t:1527614111423};\\\", \\\"{x:744,y:587,t:1527614111440};\\\", \\\"{x:749,y:587,t:1527614111457};\\\", \\\"{x:752,y:587,t:1527614111474};\\\", \\\"{x:755,y:587,t:1527614111490};\\\", \\\"{x:756,y:587,t:1527614111507};\\\", \\\"{x:757,y:587,t:1527614111528};\\\", \\\"{x:757,y:588,t:1527614111544};\\\", \\\"{x:754,y:591,t:1527614111557};\\\", \\\"{x:741,y:598,t:1527614111575};\\\", \\\"{x:717,y:605,t:1527614111592};\\\", \\\"{x:692,y:607,t:1527614111607};\\\", \\\"{x:655,y:608,t:1527614111624};\\\", \\\"{x:610,y:608,t:1527614111641};\\\", \\\"{x:563,y:608,t:1527614111657};\\\", \\\"{x:541,y:608,t:1527614111674};\\\", \\\"{x:516,y:606,t:1527614111691};\\\", \\\"{x:490,y:600,t:1527614111707};\\\", \\\"{x:476,y:595,t:1527614111724};\\\", \\\"{x:471,y:595,t:1527614111741};\\\", \\\"{x:470,y:595,t:1527614111760};\\\", \\\"{x:468,y:595,t:1527614111865};\\\", \\\"{x:466,y:595,t:1527614111880};\\\", \\\"{x:462,y:595,t:1527614111891};\\\", \\\"{x:455,y:595,t:1527614111907};\\\", \\\"{x:442,y:595,t:1527614111924};\\\", \\\"{x:425,y:595,t:1527614111941};\\\", \\\"{x:407,y:595,t:1527614111957};\\\", \\\"{x:386,y:595,t:1527614111975};\\\", \\\"{x:363,y:595,t:1527614111991};\\\", \\\"{x:343,y:595,t:1527614112007};\\\", \\\"{x:313,y:595,t:1527614112025};\\\", \\\"{x:299,y:593,t:1527614112042};\\\", \\\"{x:288,y:593,t:1527614112057};\\\", \\\"{x:257,y:593,t:1527614112074};\\\", \\\"{x:204,y:593,t:1527614112090};\\\", \\\"{x:142,y:593,t:1527614112108};\\\", \\\"{x:95,y:593,t:1527614112124};\\\", \\\"{x:66,y:587,t:1527614112140};\\\", \\\"{x:47,y:587,t:1527614112158};\\\", \\\"{x:28,y:587,t:1527614112174};\\\", \\\"{x:14,y:587,t:1527614112191};\\\", \\\"{x:0,y:587,t:1527614112208};\\\", \\\"{x:3,y:588,t:1527614112296};\\\", \\\"{x:4,y:589,t:1527614112308};\\\", \\\"{x:12,y:593,t:1527614112324};\\\", \\\"{x:22,y:595,t:1527614112341};\\\", \\\"{x:36,y:600,t:1527614112358};\\\", \\\"{x:51,y:603,t:1527614112376};\\\", \\\"{x:66,y:607,t:1527614112391};\\\", \\\"{x:89,y:614,t:1527614112407};\\\", \\\"{x:104,y:614,t:1527614112425};\\\", \\\"{x:121,y:618,t:1527614112440};\\\", \\\"{x:139,y:619,t:1527614112458};\\\", \\\"{x:154,y:620,t:1527614112475};\\\", \\\"{x:164,y:620,t:1527614112491};\\\", \\\"{x:167,y:620,t:1527614112507};\\\", \\\"{x:168,y:620,t:1527614112525};\\\", \\\"{x:170,y:620,t:1527614112559};\\\", \\\"{x:170,y:619,t:1527614112575};\\\", \\\"{x:173,y:615,t:1527614112590};\\\", \\\"{x:175,y:604,t:1527614112607};\\\", \\\"{x:176,y:596,t:1527614112625};\\\", \\\"{x:176,y:591,t:1527614112641};\\\", \\\"{x:176,y:586,t:1527614112658};\\\", \\\"{x:176,y:583,t:1527614112675};\\\", \\\"{x:176,y:578,t:1527614112691};\\\", \\\"{x:176,y:571,t:1527614112708};\\\", \\\"{x:176,y:564,t:1527614112725};\\\", \\\"{x:174,y:555,t:1527614112741};\\\", \\\"{x:169,y:540,t:1527614112757};\\\", \\\"{x:164,y:522,t:1527614112775};\\\", \\\"{x:158,y:509,t:1527614112792};\\\", \\\"{x:155,y:505,t:1527614112808};\\\", \\\"{x:155,y:504,t:1527614112825};\\\", \\\"{x:153,y:502,t:1527614112841};\\\", \\\"{x:153,y:503,t:1527614113031};\\\", \\\"{x:156,y:508,t:1527614113042};\\\", \\\"{x:164,y:517,t:1527614113059};\\\", \\\"{x:173,y:524,t:1527614113075};\\\", \\\"{x:187,y:533,t:1527614113091};\\\", \\\"{x:197,y:540,t:1527614113108};\\\", \\\"{x:201,y:543,t:1527614113124};\\\", \\\"{x:202,y:544,t:1527614113142};\\\", \\\"{x:203,y:544,t:1527614113158};\\\", \\\"{x:203,y:545,t:1527614113336};\\\", \\\"{x:202,y:545,t:1527614113351};\\\", \\\"{x:201,y:546,t:1527614113359};\\\", \\\"{x:200,y:546,t:1527614113374};\\\", \\\"{x:196,y:548,t:1527614113391};\\\", \\\"{x:195,y:548,t:1527614113408};\\\", \\\"{x:194,y:548,t:1527614113425};\\\", \\\"{x:192,y:548,t:1527614113441};\\\", \\\"{x:190,y:548,t:1527614113458};\\\", \\\"{x:188,y:548,t:1527614113474};\\\", \\\"{x:185,y:548,t:1527614113492};\\\", \\\"{x:184,y:548,t:1527614113511};\\\", \\\"{x:183,y:548,t:1527614113524};\\\", \\\"{x:180,y:548,t:1527614113542};\\\", \\\"{x:176,y:547,t:1527614113559};\\\", \\\"{x:167,y:544,t:1527614113575};\\\", \\\"{x:154,y:541,t:1527614113591};\\\", \\\"{x:148,y:539,t:1527614113609};\\\", \\\"{x:147,y:538,t:1527614113625};\\\", \\\"{x:146,y:538,t:1527614113776};\\\", \\\"{x:147,y:539,t:1527614114832};\\\", \\\"{x:150,y:545,t:1527614114843};\\\", \\\"{x:159,y:565,t:1527614114861};\\\", \\\"{x:175,y:591,t:1527614114876};\\\", \\\"{x:188,y:606,t:1527614114894};\\\", \\\"{x:199,y:621,t:1527614114911};\\\", \\\"{x:215,y:639,t:1527614114927};\\\", \\\"{x:233,y:657,t:1527614114943};\\\", \\\"{x:268,y:686,t:1527614114961};\\\", \\\"{x:291,y:695,t:1527614114977};\\\", \\\"{x:312,y:705,t:1527614114993};\\\", \\\"{x:335,y:716,t:1527614115011};\\\", \\\"{x:352,y:725,t:1527614115026};\\\", \\\"{x:369,y:734,t:1527614115043};\\\", \\\"{x:389,y:743,t:1527614115060};\\\", \\\"{x:412,y:749,t:1527614115076};\\\", \\\"{x:428,y:754,t:1527614115094};\\\", \\\"{x:440,y:757,t:1527614115110};\\\", \\\"{x:452,y:761,t:1527614115127};\\\", \\\"{x:467,y:768,t:1527614115144};\\\", \\\"{x:485,y:775,t:1527614115160};\\\", \\\"{x:501,y:782,t:1527614115178};\\\", \\\"{x:515,y:786,t:1527614115193};\\\", \\\"{x:520,y:787,t:1527614115210};\\\", \\\"{x:523,y:789,t:1527614115227};\\\", \\\"{x:525,y:789,t:1527614115244};\\\", \\\"{x:526,y:789,t:1527614115264};\\\", \\\"{x:528,y:789,t:1527614115400};\\\", \\\"{x:528,y:790,t:1527614115410};\\\", \\\"{x:529,y:792,t:1527614115426};\\\", \\\"{x:531,y:793,t:1527614115444};\\\", \\\"{x:532,y:793,t:1527614115464};\\\", \\\"{x:533,y:794,t:1527614115476};\\\", \\\"{x:533,y:795,t:1527614115496};\\\", \\\"{x:534,y:796,t:1527614115510};\\\", \\\"{x:534,y:797,t:1527614115526};\\\", \\\"{x:535,y:798,t:1527614115545};\\\", \\\"{x:536,y:799,t:1527614115665};\\\", \\\"{x:537,y:799,t:1527614115704};\\\", \\\"{x:538,y:799,t:1527614115728};\\\", \\\"{x:539,y:800,t:1527614115745};\\\", \\\"{x:536,y:798,t:1527614116233};\\\", \\\"{x:531,y:792,t:1527614116243};\\\", \\\"{x:522,y:782,t:1527614116261};\\\", \\\"{x:515,y:767,t:1527614116277};\\\", \\\"{x:512,y:757,t:1527614116293};\\\", \\\"{x:510,y:750,t:1527614116311};\\\", \\\"{x:510,y:749,t:1527614116327};\\\", \\\"{x:510,y:748,t:1527614116343};\\\", \\\"{x:509,y:747,t:1527614116361};\\\", \\\"{x:509,y:746,t:1527614116400};\\\", \\\"{x:509,y:745,t:1527614116585};\\\", \\\"{x:509,y:744,t:1527614116608};\\\", \\\"{x:509,y:743,t:1527614116616};\\\" ] }, { \\\"rt\\\": 14916, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 457719, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-01 PM-03 PM-B -B -F -F -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:742,t:1527614120529};\\\", \\\"{x:521,y:752,t:1527614120545};\\\", \\\"{x:537,y:762,t:1527614120562};\\\", \\\"{x:559,y:769,t:1527614120580};\\\", \\\"{x:577,y:776,t:1527614120595};\\\", \\\"{x:594,y:780,t:1527614120613};\\\", \\\"{x:616,y:784,t:1527614120630};\\\", \\\"{x:642,y:790,t:1527614120648};\\\", \\\"{x:673,y:792,t:1527614120663};\\\", \\\"{x:715,y:797,t:1527614120680};\\\", \\\"{x:739,y:799,t:1527614120697};\\\", \\\"{x:761,y:801,t:1527614120713};\\\", \\\"{x:785,y:805,t:1527614120730};\\\", \\\"{x:813,y:809,t:1527614120748};\\\", \\\"{x:844,y:814,t:1527614120763};\\\", \\\"{x:878,y:820,t:1527614120780};\\\", \\\"{x:914,y:830,t:1527614120798};\\\", \\\"{x:950,y:839,t:1527614120813};\\\", \\\"{x:988,y:851,t:1527614120831};\\\", \\\"{x:1044,y:867,t:1527614120848};\\\", \\\"{x:1066,y:873,t:1527614120863};\\\", \\\"{x:1128,y:886,t:1527614120880};\\\", \\\"{x:1167,y:897,t:1527614120898};\\\", \\\"{x:1198,y:905,t:1527614120914};\\\", \\\"{x:1224,y:915,t:1527614120931};\\\", \\\"{x:1250,y:922,t:1527614120947};\\\", \\\"{x:1272,y:930,t:1527614120963};\\\", \\\"{x:1291,y:937,t:1527614120980};\\\", \\\"{x:1306,y:944,t:1527614120997};\\\", \\\"{x:1322,y:952,t:1527614121014};\\\", \\\"{x:1335,y:958,t:1527614121031};\\\", \\\"{x:1348,y:964,t:1527614121048};\\\", \\\"{x:1362,y:970,t:1527614121064};\\\", \\\"{x:1389,y:979,t:1527614121082};\\\", \\\"{x:1407,y:982,t:1527614121098};\\\", \\\"{x:1420,y:985,t:1527614121115};\\\", \\\"{x:1431,y:988,t:1527614121131};\\\", \\\"{x:1438,y:990,t:1527614121148};\\\", \\\"{x:1445,y:990,t:1527614121166};\\\", \\\"{x:1454,y:992,t:1527614121180};\\\", \\\"{x:1466,y:993,t:1527614121198};\\\", \\\"{x:1479,y:993,t:1527614121215};\\\", \\\"{x:1490,y:993,t:1527614121231};\\\", \\\"{x:1504,y:993,t:1527614121248};\\\", \\\"{x:1517,y:993,t:1527614121265};\\\", \\\"{x:1529,y:991,t:1527614121281};\\\", \\\"{x:1540,y:991,t:1527614121298};\\\", \\\"{x:1550,y:991,t:1527614121315};\\\", \\\"{x:1555,y:991,t:1527614121331};\\\", \\\"{x:1556,y:991,t:1527614121471};\\\", \\\"{x:1556,y:992,t:1527614121576};\\\", \\\"{x:1558,y:992,t:1527614122361};\\\", \\\"{x:1559,y:993,t:1527614122369};\\\", \\\"{x:1556,y:993,t:1527614122593};\\\", \\\"{x:1556,y:991,t:1527614122601};\\\", \\\"{x:1555,y:991,t:1527614122615};\\\", \\\"{x:1553,y:988,t:1527614122632};\\\", \\\"{x:1550,y:984,t:1527614122648};\\\", \\\"{x:1548,y:982,t:1527614122665};\\\", \\\"{x:1545,y:980,t:1527614122682};\\\", \\\"{x:1538,y:977,t:1527614122698};\\\", \\\"{x:1529,y:970,t:1527614122715};\\\", \\\"{x:1518,y:967,t:1527614122732};\\\", \\\"{x:1507,y:962,t:1527614122748};\\\", \\\"{x:1497,y:957,t:1527614122765};\\\", \\\"{x:1489,y:953,t:1527614122782};\\\", \\\"{x:1481,y:951,t:1527614122799};\\\", \\\"{x:1474,y:947,t:1527614122815};\\\", \\\"{x:1464,y:944,t:1527614122832};\\\", \\\"{x:1454,y:939,t:1527614122848};\\\", \\\"{x:1451,y:939,t:1527614122865};\\\", \\\"{x:1449,y:937,t:1527614122882};\\\", \\\"{x:1445,y:937,t:1527614122899};\\\", \\\"{x:1442,y:937,t:1527614122915};\\\", \\\"{x:1439,y:936,t:1527614122932};\\\", \\\"{x:1436,y:935,t:1527614122949};\\\", \\\"{x:1434,y:935,t:1527614122965};\\\", \\\"{x:1432,y:935,t:1527614122982};\\\", \\\"{x:1429,y:934,t:1527614122999};\\\", \\\"{x:1428,y:934,t:1527614123015};\\\", \\\"{x:1427,y:934,t:1527614123048};\\\", \\\"{x:1426,y:934,t:1527614123065};\\\", \\\"{x:1425,y:934,t:1527614123082};\\\", \\\"{x:1424,y:933,t:1527614123099};\\\", \\\"{x:1422,y:933,t:1527614123121};\\\", \\\"{x:1421,y:933,t:1527614123153};\\\", \\\"{x:1420,y:933,t:1527614123165};\\\", \\\"{x:1418,y:932,t:1527614123184};\\\", \\\"{x:1417,y:932,t:1527614123208};\\\", \\\"{x:1416,y:932,t:1527614123273};\\\", \\\"{x:1415,y:932,t:1527614123289};\\\", \\\"{x:1415,y:931,t:1527614123299};\\\", \\\"{x:1414,y:931,t:1527614123315};\\\", \\\"{x:1413,y:930,t:1527614123352};\\\", \\\"{x:1412,y:930,t:1527614123409};\\\", \\\"{x:1411,y:929,t:1527614123472};\\\", \\\"{x:1411,y:928,t:1527614123513};\\\", \\\"{x:1411,y:927,t:1527614123529};\\\", \\\"{x:1411,y:925,t:1527614123545};\\\", \\\"{x:1409,y:924,t:1527614123553};\\\", \\\"{x:1409,y:923,t:1527614123602};\\\", \\\"{x:1409,y:922,t:1527614123626};\\\", \\\"{x:1409,y:921,t:1527614123657};\\\", \\\"{x:1409,y:920,t:1527614123665};\\\", \\\"{x:1409,y:918,t:1527614123682};\\\", \\\"{x:1409,y:917,t:1527614123721};\\\", \\\"{x:1409,y:916,t:1527614123744};\\\", \\\"{x:1409,y:915,t:1527614123761};\\\", \\\"{x:1409,y:914,t:1527614123801};\\\", \\\"{x:1409,y:913,t:1527614123841};\\\", \\\"{x:1409,y:912,t:1527614123897};\\\", \\\"{x:1409,y:911,t:1527614123977};\\\", \\\"{x:1409,y:910,t:1527614124000};\\\", \\\"{x:1409,y:909,t:1527614124026};\\\", \\\"{x:1409,y:908,t:1527614124049};\\\", \\\"{x:1408,y:906,t:1527614124066};\\\", \\\"{x:1408,y:905,t:1527614124089};\\\", \\\"{x:1408,y:904,t:1527614124099};\\\", \\\"{x:1407,y:903,t:1527614124116};\\\", \\\"{x:1407,y:902,t:1527614124132};\\\", \\\"{x:1407,y:901,t:1527614124149};\\\", \\\"{x:1406,y:899,t:1527614124166};\\\", \\\"{x:1406,y:897,t:1527614124241};\\\", \\\"{x:1406,y:895,t:1527614124273};\\\", \\\"{x:1405,y:892,t:1527614124288};\\\", \\\"{x:1404,y:891,t:1527614124299};\\\", \\\"{x:1404,y:890,t:1527614124316};\\\", \\\"{x:1404,y:889,t:1527614124332};\\\", \\\"{x:1404,y:887,t:1527614124349};\\\", \\\"{x:1404,y:886,t:1527614124368};\\\", \\\"{x:1404,y:885,t:1527614124381};\\\", \\\"{x:1404,y:884,t:1527614124398};\\\", \\\"{x:1405,y:882,t:1527614124424};\\\", \\\"{x:1405,y:880,t:1527614125345};\\\", \\\"{x:1406,y:880,t:1527614125369};\\\", \\\"{x:1407,y:879,t:1527614125409};\\\", \\\"{x:1408,y:879,t:1527614125433};\\\", \\\"{x:1409,y:879,t:1527614125537};\\\", \\\"{x:1410,y:879,t:1527614125809};\\\", \\\"{x:1409,y:879,t:1527614125816};\\\", \\\"{x:1409,y:878,t:1527614125834};\\\", \\\"{x:1408,y:878,t:1527614125856};\\\", \\\"{x:1407,y:877,t:1527614125953};\\\", \\\"{x:1404,y:874,t:1527614125967};\\\", \\\"{x:1398,y:865,t:1527614125983};\\\", \\\"{x:1388,y:848,t:1527614126000};\\\", \\\"{x:1380,y:828,t:1527614126016};\\\", \\\"{x:1370,y:808,t:1527614126033};\\\", \\\"{x:1361,y:787,t:1527614126051};\\\", \\\"{x:1352,y:768,t:1527614126066};\\\", \\\"{x:1350,y:758,t:1527614126086};\\\", \\\"{x:1347,y:746,t:1527614126099};\\\", \\\"{x:1344,y:738,t:1527614126116};\\\", \\\"{x:1344,y:734,t:1527614126132};\\\", \\\"{x:1344,y:731,t:1527614126150};\\\", \\\"{x:1343,y:729,t:1527614126166};\\\", \\\"{x:1343,y:727,t:1527614126182};\\\", \\\"{x:1343,y:726,t:1527614126208};\\\", \\\"{x:1343,y:725,t:1527614126224};\\\", \\\"{x:1343,y:724,t:1527614126232};\\\", \\\"{x:1346,y:722,t:1527614126250};\\\", \\\"{x:1350,y:719,t:1527614126267};\\\", \\\"{x:1353,y:717,t:1527614126282};\\\", \\\"{x:1354,y:717,t:1527614126299};\\\", \\\"{x:1355,y:715,t:1527614126316};\\\", \\\"{x:1356,y:714,t:1527614126333};\\\", \\\"{x:1356,y:712,t:1527614126350};\\\", \\\"{x:1356,y:709,t:1527614126367};\\\", \\\"{x:1356,y:705,t:1527614126382};\\\", \\\"{x:1356,y:699,t:1527614126400};\\\", \\\"{x:1355,y:696,t:1527614126416};\\\", \\\"{x:1352,y:693,t:1527614126433};\\\", \\\"{x:1351,y:691,t:1527614126450};\\\", \\\"{x:1350,y:690,t:1527614126467};\\\", \\\"{x:1350,y:688,t:1527614126496};\\\", \\\"{x:1350,y:687,t:1527614126528};\\\", \\\"{x:1350,y:686,t:1527614126535};\\\", \\\"{x:1350,y:687,t:1527614126864};\\\", \\\"{x:1350,y:688,t:1527614126873};\\\", \\\"{x:1350,y:689,t:1527614126883};\\\", \\\"{x:1349,y:692,t:1527614126901};\\\", \\\"{x:1349,y:693,t:1527614126917};\\\", \\\"{x:1349,y:694,t:1527614126933};\\\", \\\"{x:1349,y:696,t:1527614126950};\\\", \\\"{x:1348,y:699,t:1527614126967};\\\", \\\"{x:1348,y:700,t:1527614126982};\\\", \\\"{x:1348,y:701,t:1527614126999};\\\", \\\"{x:1347,y:701,t:1527614127017};\\\", \\\"{x:1347,y:702,t:1527614127080};\\\", \\\"{x:1347,y:704,t:1527614127546};\\\", \\\"{x:1346,y:705,t:1527614127553};\\\", \\\"{x:1345,y:707,t:1527614127567};\\\", \\\"{x:1342,y:719,t:1527614127583};\\\", \\\"{x:1338,y:728,t:1527614127599};\\\", \\\"{x:1335,y:733,t:1527614127616};\\\", \\\"{x:1334,y:737,t:1527614127634};\\\", \\\"{x:1334,y:738,t:1527614127650};\\\", \\\"{x:1334,y:739,t:1527614127667};\\\", \\\"{x:1334,y:741,t:1527614127683};\\\", \\\"{x:1334,y:742,t:1527614127700};\\\", \\\"{x:1334,y:743,t:1527614127716};\\\", \\\"{x:1334,y:745,t:1527614127734};\\\", \\\"{x:1334,y:746,t:1527614127793};\\\", \\\"{x:1335,y:747,t:1527614127801};\\\", \\\"{x:1335,y:748,t:1527614127818};\\\", \\\"{x:1335,y:749,t:1527614127834};\\\", \\\"{x:1335,y:751,t:1527614127850};\\\", \\\"{x:1336,y:752,t:1527614127866};\\\", \\\"{x:1337,y:755,t:1527614127884};\\\", \\\"{x:1337,y:756,t:1527614127904};\\\", \\\"{x:1338,y:757,t:1527614127917};\\\", \\\"{x:1338,y:758,t:1527614127934};\\\", \\\"{x:1339,y:758,t:1527614127960};\\\", \\\"{x:1339,y:759,t:1527614127984};\\\", \\\"{x:1339,y:761,t:1527614128000};\\\", \\\"{x:1339,y:762,t:1527614128025};\\\", \\\"{x:1339,y:763,t:1527614128040};\\\", \\\"{x:1339,y:764,t:1527614128050};\\\", \\\"{x:1339,y:765,t:1527614128072};\\\", \\\"{x:1339,y:766,t:1527614128095};\\\", \\\"{x:1340,y:767,t:1527614128104};\\\", \\\"{x:1340,y:768,t:1527614128117};\\\", \\\"{x:1340,y:769,t:1527614128176};\\\", \\\"{x:1340,y:771,t:1527614128265};\\\", \\\"{x:1339,y:772,t:1527614128280};\\\", \\\"{x:1338,y:772,t:1527614128289};\\\", \\\"{x:1337,y:772,t:1527614128301};\\\", \\\"{x:1330,y:772,t:1527614128317};\\\", \\\"{x:1316,y:772,t:1527614128334};\\\", \\\"{x:1302,y:772,t:1527614128350};\\\", \\\"{x:1291,y:772,t:1527614128366};\\\", \\\"{x:1266,y:772,t:1527614128383};\\\", \\\"{x:1245,y:772,t:1527614128401};\\\", \\\"{x:1220,y:772,t:1527614128416};\\\", \\\"{x:1194,y:772,t:1527614128433};\\\", \\\"{x:1163,y:772,t:1527614128451};\\\", \\\"{x:1116,y:765,t:1527614128467};\\\", \\\"{x:1060,y:758,t:1527614128484};\\\", \\\"{x:1000,y:752,t:1527614128501};\\\", \\\"{x:936,y:746,t:1527614128517};\\\", \\\"{x:872,y:735,t:1527614128534};\\\", \\\"{x:791,y:724,t:1527614128551};\\\", \\\"{x:725,y:718,t:1527614128567};\\\", \\\"{x:657,y:708,t:1527614128583};\\\", \\\"{x:624,y:703,t:1527614128600};\\\", \\\"{x:604,y:697,t:1527614128617};\\\", \\\"{x:591,y:693,t:1527614128634};\\\", \\\"{x:584,y:691,t:1527614128651};\\\", \\\"{x:580,y:690,t:1527614128667};\\\", \\\"{x:578,y:688,t:1527614128684};\\\", \\\"{x:577,y:688,t:1527614128701};\\\", \\\"{x:575,y:686,t:1527614128717};\\\", \\\"{x:574,y:684,t:1527614128737};\\\", \\\"{x:574,y:683,t:1527614128752};\\\", \\\"{x:574,y:671,t:1527614128768};\\\", \\\"{x:574,y:661,t:1527614128784};\\\", \\\"{x:577,y:644,t:1527614128801};\\\", \\\"{x:584,y:630,t:1527614128819};\\\", \\\"{x:591,y:619,t:1527614128833};\\\", \\\"{x:594,y:615,t:1527614128850};\\\", \\\"{x:597,y:607,t:1527614128871};\\\", \\\"{x:600,y:599,t:1527614128888};\\\", \\\"{x:601,y:597,t:1527614128904};\\\", \\\"{x:604,y:595,t:1527614128920};\\\", \\\"{x:604,y:593,t:1527614128939};\\\", \\\"{x:605,y:591,t:1527614128955};\\\", \\\"{x:606,y:589,t:1527614128970};\\\", \\\"{x:607,y:589,t:1527614128987};\\\", \\\"{x:610,y:588,t:1527614129005};\\\", \\\"{x:612,y:586,t:1527614129021};\\\", \\\"{x:615,y:585,t:1527614129038};\\\", \\\"{x:617,y:584,t:1527614129055};\\\", \\\"{x:618,y:582,t:1527614129070};\\\", \\\"{x:624,y:578,t:1527614129088};\\\", \\\"{x:635,y:574,t:1527614129105};\\\", \\\"{x:645,y:569,t:1527614129122};\\\", \\\"{x:665,y:561,t:1527614129139};\\\", \\\"{x:683,y:554,t:1527614129155};\\\", \\\"{x:699,y:547,t:1527614129172};\\\", \\\"{x:715,y:539,t:1527614129188};\\\", \\\"{x:725,y:537,t:1527614129205};\\\", \\\"{x:729,y:534,t:1527614129221};\\\", \\\"{x:733,y:533,t:1527614129237};\\\", \\\"{x:736,y:531,t:1527614129255};\\\", \\\"{x:743,y:529,t:1527614129271};\\\", \\\"{x:748,y:527,t:1527614129289};\\\", \\\"{x:752,y:526,t:1527614129305};\\\", \\\"{x:756,y:526,t:1527614129322};\\\", \\\"{x:760,y:526,t:1527614129339};\\\", \\\"{x:766,y:523,t:1527614129356};\\\", \\\"{x:771,y:523,t:1527614129371};\\\", \\\"{x:776,y:522,t:1527614129388};\\\", \\\"{x:779,y:522,t:1527614129405};\\\", \\\"{x:780,y:522,t:1527614129422};\\\", \\\"{x:779,y:522,t:1527614129488};\\\", \\\"{x:767,y:524,t:1527614129505};\\\", \\\"{x:751,y:528,t:1527614129523};\\\", \\\"{x:727,y:529,t:1527614129539};\\\", \\\"{x:707,y:530,t:1527614129555};\\\", \\\"{x:687,y:531,t:1527614129571};\\\", \\\"{x:672,y:533,t:1527614129589};\\\", \\\"{x:651,y:534,t:1527614129604};\\\", \\\"{x:631,y:534,t:1527614129622};\\\", \\\"{x:615,y:534,t:1527614129639};\\\", \\\"{x:602,y:535,t:1527614129655};\\\", \\\"{x:574,y:536,t:1527614129672};\\\", \\\"{x:556,y:539,t:1527614129688};\\\", \\\"{x:539,y:541,t:1527614129705};\\\", \\\"{x:518,y:545,t:1527614129722};\\\", \\\"{x:501,y:546,t:1527614129738};\\\", \\\"{x:484,y:550,t:1527614129756};\\\", \\\"{x:470,y:552,t:1527614129772};\\\", \\\"{x:460,y:553,t:1527614129789};\\\", \\\"{x:451,y:555,t:1527614129805};\\\", \\\"{x:438,y:556,t:1527614129823};\\\", \\\"{x:424,y:557,t:1527614129839};\\\", \\\"{x:412,y:560,t:1527614129855};\\\", \\\"{x:398,y:562,t:1527614129872};\\\", \\\"{x:392,y:564,t:1527614129890};\\\", \\\"{x:384,y:564,t:1527614129905};\\\", \\\"{x:364,y:565,t:1527614129922};\\\", \\\"{x:342,y:566,t:1527614129938};\\\", \\\"{x:321,y:566,t:1527614129956};\\\", \\\"{x:304,y:566,t:1527614129971};\\\", \\\"{x:285,y:566,t:1527614129988};\\\", \\\"{x:266,y:566,t:1527614130007};\\\", \\\"{x:242,y:566,t:1527614130022};\\\", \\\"{x:215,y:566,t:1527614130038};\\\", \\\"{x:175,y:566,t:1527614130056};\\\", \\\"{x:155,y:566,t:1527614130071};\\\", \\\"{x:148,y:566,t:1527614130089};\\\", \\\"{x:138,y:566,t:1527614130105};\\\", \\\"{x:130,y:566,t:1527614130121};\\\", \\\"{x:123,y:564,t:1527614130139};\\\", \\\"{x:120,y:564,t:1527614130156};\\\", \\\"{x:119,y:564,t:1527614130172};\\\", \\\"{x:118,y:563,t:1527614130249};\\\", \\\"{x:118,y:561,t:1527614130258};\\\", \\\"{x:123,y:555,t:1527614130272};\\\", \\\"{x:136,y:549,t:1527614130288};\\\", \\\"{x:146,y:545,t:1527614130305};\\\", \\\"{x:151,y:543,t:1527614130322};\\\", \\\"{x:152,y:542,t:1527614130339};\\\", \\\"{x:153,y:542,t:1527614130423};\\\", \\\"{x:153,y:541,t:1527614130439};\\\", \\\"{x:155,y:541,t:1527614130455};\\\", \\\"{x:156,y:540,t:1527614130473};\\\", \\\"{x:159,y:541,t:1527614130735};\\\", \\\"{x:168,y:544,t:1527614130744};\\\", \\\"{x:174,y:546,t:1527614130756};\\\", \\\"{x:187,y:552,t:1527614130774};\\\", \\\"{x:203,y:561,t:1527614130789};\\\", \\\"{x:217,y:572,t:1527614130806};\\\", \\\"{x:231,y:581,t:1527614130823};\\\", \\\"{x:243,y:588,t:1527614130838};\\\", \\\"{x:252,y:594,t:1527614130856};\\\", \\\"{x:260,y:600,t:1527614130872};\\\", \\\"{x:276,y:607,t:1527614130890};\\\", \\\"{x:297,y:614,t:1527614130906};\\\", \\\"{x:319,y:622,t:1527614130923};\\\", \\\"{x:341,y:631,t:1527614130939};\\\", \\\"{x:360,y:639,t:1527614130957};\\\", \\\"{x:382,y:649,t:1527614130973};\\\", \\\"{x:402,y:657,t:1527614130990};\\\", \\\"{x:426,y:667,t:1527614131006};\\\", \\\"{x:448,y:678,t:1527614131023};\\\", \\\"{x:472,y:689,t:1527614131040};\\\", \\\"{x:487,y:695,t:1527614131055};\\\", \\\"{x:493,y:700,t:1527614131073};\\\", \\\"{x:501,y:707,t:1527614131090};\\\", \\\"{x:506,y:711,t:1527614131107};\\\", \\\"{x:509,y:712,t:1527614131123};\\\", \\\"{x:514,y:716,t:1527614131140};\\\", \\\"{x:517,y:720,t:1527614131157};\\\", \\\"{x:522,y:725,t:1527614131173};\\\", \\\"{x:525,y:730,t:1527614131189};\\\", \\\"{x:528,y:734,t:1527614131206};\\\", \\\"{x:528,y:735,t:1527614131224};\\\", \\\"{x:529,y:735,t:1527614131248};\\\", \\\"{x:529,y:736,t:1527614131263};\\\" ] }, { \\\"rt\\\": 37108, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 496045, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"C\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -Z -Z -Z -Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:538,y:736,t:1527614137881};\\\", \\\"{x:582,y:739,t:1527614137910};\\\", \\\"{x:601,y:740,t:1527614137919};\\\", \\\"{x:633,y:743,t:1527614137936};\\\", \\\"{x:644,y:743,t:1527614137944};\\\", \\\"{x:662,y:744,t:1527614137961};\\\", \\\"{x:681,y:748,t:1527614137978};\\\", \\\"{x:720,y:752,t:1527614137994};\\\", \\\"{x:777,y:753,t:1527614138011};\\\", \\\"{x:858,y:752,t:1527614138028};\\\", \\\"{x:875,y:747,t:1527614138044};\\\", \\\"{x:888,y:741,t:1527614138061};\\\", \\\"{x:891,y:741,t:1527614138078};\\\", \\\"{x:897,y:741,t:1527614138094};\\\", \\\"{x:919,y:738,t:1527614138111};\\\", \\\"{x:948,y:738,t:1527614138127};\\\", \\\"{x:963,y:737,t:1527614138145};\\\", \\\"{x:972,y:737,t:1527614138161};\\\", \\\"{x:982,y:738,t:1527614138179};\\\", \\\"{x:994,y:738,t:1527614138194};\\\", \\\"{x:1011,y:744,t:1527614138211};\\\", \\\"{x:1022,y:744,t:1527614138228};\\\", \\\"{x:1030,y:744,t:1527614138245};\\\", \\\"{x:1038,y:744,t:1527614138261};\\\", \\\"{x:1042,y:744,t:1527614138278};\\\", \\\"{x:1047,y:744,t:1527614138295};\\\", \\\"{x:1055,y:744,t:1527614138311};\\\", \\\"{x:1068,y:742,t:1527614138328};\\\", \\\"{x:1079,y:739,t:1527614138345};\\\", \\\"{x:1090,y:738,t:1527614138362};\\\", \\\"{x:1103,y:737,t:1527614138378};\\\", \\\"{x:1114,y:736,t:1527614138396};\\\", \\\"{x:1133,y:736,t:1527614138412};\\\", \\\"{x:1151,y:736,t:1527614138428};\\\", \\\"{x:1177,y:736,t:1527614138445};\\\", \\\"{x:1210,y:740,t:1527614138461};\\\", \\\"{x:1241,y:745,t:1527614138479};\\\", \\\"{x:1267,y:747,t:1527614138496};\\\", \\\"{x:1286,y:752,t:1527614138512};\\\", \\\"{x:1300,y:754,t:1527614138529};\\\", \\\"{x:1300,y:752,t:1527614138553};\\\", \\\"{x:1300,y:748,t:1527614138561};\\\", \\\"{x:1295,y:742,t:1527614138578};\\\", \\\"{x:1296,y:742,t:1527614139368};\\\", \\\"{x:1297,y:742,t:1527614139400};\\\", \\\"{x:1298,y:742,t:1527614139416};\\\", \\\"{x:1299,y:742,t:1527614139429};\\\", \\\"{x:1300,y:742,t:1527614139464};\\\", \\\"{x:1301,y:742,t:1527614139480};\\\", \\\"{x:1302,y:742,t:1527614139495};\\\", \\\"{x:1308,y:743,t:1527614139512};\\\", \\\"{x:1324,y:745,t:1527614139529};\\\", \\\"{x:1348,y:748,t:1527614139546};\\\", \\\"{x:1379,y:751,t:1527614139564};\\\", \\\"{x:1409,y:754,t:1527614139579};\\\", \\\"{x:1450,y:757,t:1527614139595};\\\", \\\"{x:1488,y:759,t:1527614139612};\\\", \\\"{x:1541,y:759,t:1527614139629};\\\", \\\"{x:1583,y:759,t:1527614139645};\\\", \\\"{x:1615,y:759,t:1527614139662};\\\", \\\"{x:1645,y:759,t:1527614139679};\\\", \\\"{x:1650,y:758,t:1527614139695};\\\", \\\"{x:1654,y:758,t:1527614139713};\\\", \\\"{x:1654,y:757,t:1527614139735};\\\", \\\"{x:1654,y:756,t:1527614139767};\\\", \\\"{x:1654,y:754,t:1527614139779};\\\", \\\"{x:1654,y:752,t:1527614139795};\\\", \\\"{x:1654,y:749,t:1527614139812};\\\", \\\"{x:1651,y:745,t:1527614139829};\\\", \\\"{x:1645,y:740,t:1527614139846};\\\", \\\"{x:1640,y:737,t:1527614139862};\\\", \\\"{x:1634,y:733,t:1527614139880};\\\", \\\"{x:1632,y:732,t:1527614139896};\\\", \\\"{x:1625,y:726,t:1527614139913};\\\", \\\"{x:1620,y:721,t:1527614139930};\\\", \\\"{x:1615,y:717,t:1527614139946};\\\", \\\"{x:1613,y:714,t:1527614139963};\\\", \\\"{x:1610,y:711,t:1527614139980};\\\", \\\"{x:1609,y:710,t:1527614139996};\\\", \\\"{x:1609,y:709,t:1527614140012};\\\", \\\"{x:1609,y:708,t:1527614140031};\\\", \\\"{x:1609,y:707,t:1527614140046};\\\", \\\"{x:1609,y:706,t:1527614140062};\\\", \\\"{x:1609,y:705,t:1527614140080};\\\", \\\"{x:1607,y:704,t:1527614140095};\\\", \\\"{x:1607,y:702,t:1527614140128};\\\", \\\"{x:1608,y:702,t:1527614140136};\\\", \\\"{x:1609,y:702,t:1527614140152};\\\", \\\"{x:1610,y:701,t:1527614140176};\\\", \\\"{x:1611,y:700,t:1527614140218};\\\", \\\"{x:1612,y:699,t:1527614140264};\\\", \\\"{x:1613,y:699,t:1527614140305};\\\", \\\"{x:1614,y:698,t:1527614140432};\\\", \\\"{x:1613,y:698,t:1527614141041};\\\", \\\"{x:1612,y:698,t:1527614141097};\\\", \\\"{x:1611,y:699,t:1527614141136};\\\", \\\"{x:1610,y:699,t:1527614141176};\\\", \\\"{x:1610,y:700,t:1527614141185};\\\", \\\"{x:1610,y:702,t:1527614141282};\\\", \\\"{x:1609,y:702,t:1527614141336};\\\", \\\"{x:1609,y:703,t:1527614141768};\\\", \\\"{x:1611,y:703,t:1527614141801};\\\", \\\"{x:1613,y:702,t:1527614141816};\\\", \\\"{x:1617,y:701,t:1527614141848};\\\", \\\"{x:1619,y:699,t:1527614141953};\\\", \\\"{x:1618,y:699,t:1527614142296};\\\", \\\"{x:1618,y:698,t:1527614143721};\\\", \\\"{x:1618,y:697,t:1527614143744};\\\", \\\"{x:1617,y:696,t:1527614143760};\\\", \\\"{x:1619,y:697,t:1527614143968};\\\", \\\"{x:1620,y:701,t:1527614143984};\\\", \\\"{x:1623,y:707,t:1527614143999};\\\", \\\"{x:1625,y:711,t:1527614144015};\\\", \\\"{x:1627,y:716,t:1527614144032};\\\", \\\"{x:1627,y:714,t:1527614144304};\\\", \\\"{x:1627,y:713,t:1527614144315};\\\", \\\"{x:1627,y:709,t:1527614144331};\\\", \\\"{x:1627,y:707,t:1527614144349};\\\", \\\"{x:1626,y:705,t:1527614144366};\\\", \\\"{x:1625,y:703,t:1527614144381};\\\", \\\"{x:1625,y:702,t:1527614144398};\\\", \\\"{x:1624,y:701,t:1527614144415};\\\", \\\"{x:1623,y:699,t:1527614144431};\\\", \\\"{x:1622,y:698,t:1527614144449};\\\", \\\"{x:1621,y:696,t:1527614144467};\\\", \\\"{x:1621,y:692,t:1527614144483};\\\", \\\"{x:1621,y:690,t:1527614144499};\\\", \\\"{x:1619,y:688,t:1527614144516};\\\", \\\"{x:1617,y:686,t:1527614144532};\\\", \\\"{x:1616,y:685,t:1527614144553};\\\", \\\"{x:1614,y:684,t:1527614144566};\\\", \\\"{x:1614,y:683,t:1527614144582};\\\", \\\"{x:1613,y:680,t:1527614144598};\\\", \\\"{x:1611,y:675,t:1527614144617};\\\", \\\"{x:1609,y:670,t:1527614144633};\\\", \\\"{x:1608,y:666,t:1527614144649};\\\", \\\"{x:1607,y:663,t:1527614144666};\\\", \\\"{x:1605,y:659,t:1527614144682};\\\", \\\"{x:1605,y:657,t:1527614144699};\\\", \\\"{x:1605,y:655,t:1527614144716};\\\", \\\"{x:1604,y:654,t:1527614144733};\\\", \\\"{x:1604,y:653,t:1527614144784};\\\", \\\"{x:1604,y:651,t:1527614145256};\\\", \\\"{x:1604,y:649,t:1527614145266};\\\", \\\"{x:1604,y:648,t:1527614145283};\\\", \\\"{x:1604,y:646,t:1527614145300};\\\", \\\"{x:1604,y:645,t:1527614145316};\\\", \\\"{x:1604,y:643,t:1527614145333};\\\", \\\"{x:1604,y:642,t:1527614145360};\\\", \\\"{x:1604,y:641,t:1527614145369};\\\", \\\"{x:1604,y:640,t:1527614145385};\\\", \\\"{x:1604,y:639,t:1527614145409};\\\", \\\"{x:1604,y:638,t:1527614145424};\\\", \\\"{x:1604,y:637,t:1527614145448};\\\", \\\"{x:1604,y:636,t:1527614145465};\\\", \\\"{x:1604,y:635,t:1527614145472};\\\", \\\"{x:1604,y:634,t:1527614145483};\\\", \\\"{x:1604,y:633,t:1527614145500};\\\", \\\"{x:1604,y:631,t:1527614145516};\\\", \\\"{x:1605,y:630,t:1527614145533};\\\", \\\"{x:1605,y:629,t:1527614145550};\\\", \\\"{x:1605,y:627,t:1527614145566};\\\", \\\"{x:1605,y:625,t:1527614145583};\\\", \\\"{x:1605,y:624,t:1527614145600};\\\", \\\"{x:1605,y:622,t:1527614145616};\\\", \\\"{x:1605,y:621,t:1527614145633};\\\", \\\"{x:1605,y:617,t:1527614145650};\\\", \\\"{x:1605,y:616,t:1527614145666};\\\", \\\"{x:1606,y:612,t:1527614145683};\\\", \\\"{x:1606,y:610,t:1527614145700};\\\", \\\"{x:1606,y:608,t:1527614145716};\\\", \\\"{x:1606,y:605,t:1527614145733};\\\", \\\"{x:1606,y:602,t:1527614145750};\\\", \\\"{x:1606,y:601,t:1527614145766};\\\", \\\"{x:1606,y:598,t:1527614145783};\\\", \\\"{x:1606,y:595,t:1527614145799};\\\", \\\"{x:1606,y:593,t:1527614145816};\\\", \\\"{x:1606,y:591,t:1527614145832};\\\", \\\"{x:1606,y:589,t:1527614145849};\\\", \\\"{x:1606,y:586,t:1527614145867};\\\", \\\"{x:1606,y:585,t:1527614145883};\\\", \\\"{x:1606,y:584,t:1527614145900};\\\", \\\"{x:1606,y:582,t:1527614145917};\\\", \\\"{x:1606,y:579,t:1527614145933};\\\", \\\"{x:1606,y:577,t:1527614145950};\\\", \\\"{x:1606,y:576,t:1527614145967};\\\", \\\"{x:1607,y:574,t:1527614145982};\\\", \\\"{x:1608,y:573,t:1527614146000};\\\", \\\"{x:1608,y:571,t:1527614146017};\\\", \\\"{x:1608,y:568,t:1527614146032};\\\", \\\"{x:1608,y:565,t:1527614146050};\\\", \\\"{x:1608,y:563,t:1527614146067};\\\", \\\"{x:1608,y:559,t:1527614146083};\\\", \\\"{x:1608,y:557,t:1527614146099};\\\", \\\"{x:1607,y:555,t:1527614146117};\\\", \\\"{x:1607,y:552,t:1527614146133};\\\", \\\"{x:1607,y:550,t:1527614146150};\\\", \\\"{x:1607,y:548,t:1527614146167};\\\", \\\"{x:1605,y:545,t:1527614146183};\\\", \\\"{x:1605,y:542,t:1527614146200};\\\", \\\"{x:1605,y:540,t:1527614146216};\\\", \\\"{x:1604,y:539,t:1527614146233};\\\", \\\"{x:1603,y:537,t:1527614146250};\\\", \\\"{x:1601,y:535,t:1527614146267};\\\", \\\"{x:1601,y:533,t:1527614146289};\\\", \\\"{x:1601,y:532,t:1527614146305};\\\", \\\"{x:1601,y:531,t:1527614146317};\\\", \\\"{x:1601,y:530,t:1527614146337};\\\", \\\"{x:1601,y:529,t:1527614146368};\\\", \\\"{x:1601,y:528,t:1527614146401};\\\", \\\"{x:1601,y:527,t:1527614146767};\\\", \\\"{x:1603,y:529,t:1527614146799};\\\", \\\"{x:1603,y:537,t:1527614146817};\\\", \\\"{x:1603,y:546,t:1527614146833};\\\", \\\"{x:1603,y:552,t:1527614146849};\\\", \\\"{x:1603,y:559,t:1527614146866};\\\", \\\"{x:1603,y:569,t:1527614146884};\\\", \\\"{x:1603,y:576,t:1527614146900};\\\", \\\"{x:1603,y:584,t:1527614146917};\\\", \\\"{x:1603,y:594,t:1527614146934};\\\", \\\"{x:1603,y:602,t:1527614146950};\\\", \\\"{x:1604,y:612,t:1527614146967};\\\", \\\"{x:1606,y:627,t:1527614146984};\\\", \\\"{x:1607,y:632,t:1527614147000};\\\", \\\"{x:1607,y:638,t:1527614147017};\\\", \\\"{x:1609,y:643,t:1527614147034};\\\", \\\"{x:1609,y:648,t:1527614147051};\\\", \\\"{x:1611,y:654,t:1527614147067};\\\", \\\"{x:1613,y:659,t:1527614147084};\\\", \\\"{x:1613,y:664,t:1527614147101};\\\", \\\"{x:1615,y:671,t:1527614147116};\\\", \\\"{x:1618,y:681,t:1527614147134};\\\", \\\"{x:1618,y:687,t:1527614147151};\\\", \\\"{x:1619,y:692,t:1527614147167};\\\", \\\"{x:1619,y:695,t:1527614147184};\\\", \\\"{x:1619,y:697,t:1527614147200};\\\", \\\"{x:1619,y:701,t:1527614147218};\\\", \\\"{x:1619,y:702,t:1527614147234};\\\", \\\"{x:1619,y:706,t:1527614147251};\\\", \\\"{x:1618,y:707,t:1527614147268};\\\", \\\"{x:1618,y:708,t:1527614147284};\\\", \\\"{x:1617,y:709,t:1527614147865};\\\", \\\"{x:1617,y:708,t:1527614147872};\\\", \\\"{x:1614,y:707,t:1527614147884};\\\", \\\"{x:1614,y:705,t:1527614147902};\\\", \\\"{x:1612,y:703,t:1527614147918};\\\", \\\"{x:1611,y:700,t:1527614147934};\\\", \\\"{x:1611,y:699,t:1527614147951};\\\", \\\"{x:1611,y:698,t:1527614147968};\\\", \\\"{x:1611,y:697,t:1527614147983};\\\", \\\"{x:1611,y:696,t:1527614148000};\\\", \\\"{x:1611,y:695,t:1527614148047};\\\", \\\"{x:1611,y:694,t:1527614148087};\\\", \\\"{x:1611,y:693,t:1527614159787};\\\", \\\"{x:1609,y:692,t:1527614161907};\\\", \\\"{x:1596,y:692,t:1527614161914};\\\", \\\"{x:1577,y:694,t:1527614161930};\\\", \\\"{x:1527,y:701,t:1527614161945};\\\", \\\"{x:1434,y:703,t:1527614161962};\\\", \\\"{x:1340,y:703,t:1527614161979};\\\", \\\"{x:1235,y:703,t:1527614161995};\\\", \\\"{x:1126,y:703,t:1527614162012};\\\", \\\"{x:1040,y:707,t:1527614162030};\\\", \\\"{x:983,y:708,t:1527614162046};\\\", \\\"{x:935,y:708,t:1527614162062};\\\", \\\"{x:899,y:705,t:1527614162079};\\\", \\\"{x:873,y:700,t:1527614162095};\\\", \\\"{x:855,y:696,t:1527614162112};\\\", \\\"{x:840,y:694,t:1527614162129};\\\", \\\"{x:821,y:691,t:1527614162146};\\\", \\\"{x:814,y:690,t:1527614162162};\\\", \\\"{x:806,y:690,t:1527614162179};\\\", \\\"{x:799,y:690,t:1527614162197};\\\", \\\"{x:795,y:689,t:1527614162213};\\\", \\\"{x:790,y:688,t:1527614162229};\\\", \\\"{x:780,y:682,t:1527614162246};\\\", \\\"{x:769,y:675,t:1527614162262};\\\", \\\"{x:761,y:670,t:1527614162280};\\\", \\\"{x:750,y:662,t:1527614162297};\\\", \\\"{x:736,y:650,t:1527614162312};\\\", \\\"{x:715,y:625,t:1527614162329};\\\", \\\"{x:705,y:616,t:1527614162345};\\\", \\\"{x:704,y:616,t:1527614162368};\\\", \\\"{x:704,y:615,t:1527614162386};\\\", \\\"{x:704,y:614,t:1527614162402};\\\", \\\"{x:705,y:613,t:1527614162417};\\\", \\\"{x:715,y:608,t:1527614162434};\\\", \\\"{x:728,y:602,t:1527614162451};\\\", \\\"{x:742,y:595,t:1527614162468};\\\", \\\"{x:753,y:590,t:1527614162485};\\\", \\\"{x:765,y:585,t:1527614162501};\\\", \\\"{x:772,y:583,t:1527614162517};\\\", \\\"{x:775,y:580,t:1527614162534};\\\", \\\"{x:778,y:580,t:1527614162551};\\\", \\\"{x:779,y:579,t:1527614162568};\\\", \\\"{x:780,y:579,t:1527614162584};\\\", \\\"{x:782,y:579,t:1527614162601};\\\", \\\"{x:784,y:577,t:1527614162618};\\\", \\\"{x:785,y:577,t:1527614162634};\\\", \\\"{x:786,y:577,t:1527614162731};\\\", \\\"{x:787,y:577,t:1527614162778};\\\", \\\"{x:788,y:577,t:1527614162810};\\\", \\\"{x:790,y:577,t:1527614162818};\\\", \\\"{x:794,y:581,t:1527614162834};\\\", \\\"{x:796,y:586,t:1527614162851};\\\", \\\"{x:796,y:590,t:1527614162868};\\\", \\\"{x:790,y:595,t:1527614162885};\\\", \\\"{x:774,y:601,t:1527614162902};\\\", \\\"{x:746,y:603,t:1527614162918};\\\", \\\"{x:672,y:598,t:1527614162935};\\\", \\\"{x:552,y:580,t:1527614162952};\\\", \\\"{x:436,y:561,t:1527614162968};\\\", \\\"{x:325,y:547,t:1527614162986};\\\", \\\"{x:249,y:535,t:1527614163002};\\\", \\\"{x:178,y:522,t:1527614163018};\\\", \\\"{x:145,y:514,t:1527614163035};\\\", \\\"{x:132,y:511,t:1527614163051};\\\", \\\"{x:127,y:509,t:1527614163068};\\\", \\\"{x:128,y:509,t:1527614163106};\\\", \\\"{x:131,y:509,t:1527614163122};\\\", \\\"{x:132,y:510,t:1527614163135};\\\", \\\"{x:133,y:523,t:1527614163152};\\\", \\\"{x:137,y:532,t:1527614163169};\\\", \\\"{x:144,y:542,t:1527614163185};\\\", \\\"{x:152,y:545,t:1527614163201};\\\", \\\"{x:169,y:545,t:1527614163219};\\\", \\\"{x:189,y:545,t:1527614163236};\\\", \\\"{x:212,y:545,t:1527614163251};\\\", \\\"{x:238,y:545,t:1527614163268};\\\", \\\"{x:268,y:545,t:1527614163285};\\\", \\\"{x:296,y:545,t:1527614163302};\\\", \\\"{x:318,y:545,t:1527614163318};\\\", \\\"{x:325,y:545,t:1527614163336};\\\", \\\"{x:330,y:545,t:1527614163351};\\\", \\\"{x:333,y:545,t:1527614163369};\\\", \\\"{x:336,y:544,t:1527614163546};\\\", \\\"{x:339,y:544,t:1527614163554};\\\", \\\"{x:342,y:541,t:1527614163568};\\\", \\\"{x:351,y:537,t:1527614163585};\\\", \\\"{x:361,y:535,t:1527614163602};\\\", \\\"{x:367,y:533,t:1527614163618};\\\", \\\"{x:368,y:533,t:1527614163658};\\\", \\\"{x:369,y:533,t:1527614163723};\\\", \\\"{x:370,y:533,t:1527614163735};\\\", \\\"{x:371,y:532,t:1527614163834};\\\", \\\"{x:371,y:532,t:1527614164020};\\\", \\\"{x:373,y:528,t:1527614168539};\\\", \\\"{x:379,y:521,t:1527614168557};\\\", \\\"{x:385,y:515,t:1527614168573};\\\", \\\"{x:390,y:510,t:1527614168589};\\\", \\\"{x:395,y:508,t:1527614168605};\\\", \\\"{x:397,y:507,t:1527614168622};\\\", \\\"{x:399,y:506,t:1527614168639};\\\", \\\"{x:407,y:502,t:1527614168656};\\\", \\\"{x:419,y:498,t:1527614168673};\\\", \\\"{x:430,y:495,t:1527614168690};\\\", \\\"{x:438,y:494,t:1527614168706};\\\", \\\"{x:445,y:494,t:1527614168723};\\\", \\\"{x:447,y:495,t:1527614168739};\\\", \\\"{x:451,y:499,t:1527614168757};\\\", \\\"{x:456,y:506,t:1527614168773};\\\", \\\"{x:460,y:513,t:1527614168790};\\\", \\\"{x:463,y:520,t:1527614168807};\\\", \\\"{x:465,y:524,t:1527614168823};\\\", \\\"{x:466,y:528,t:1527614168840};\\\", \\\"{x:466,y:534,t:1527614168857};\\\", \\\"{x:461,y:540,t:1527614168872};\\\", \\\"{x:446,y:547,t:1527614168890};\\\", \\\"{x:420,y:560,t:1527614168907};\\\", \\\"{x:410,y:564,t:1527614168923};\\\", \\\"{x:396,y:567,t:1527614168940};\\\", \\\"{x:380,y:571,t:1527614168957};\\\", \\\"{x:365,y:572,t:1527614168973};\\\", \\\"{x:350,y:572,t:1527614168990};\\\", \\\"{x:340,y:572,t:1527614169007};\\\", \\\"{x:334,y:568,t:1527614169024};\\\", \\\"{x:333,y:568,t:1527614169039};\\\", \\\"{x:333,y:566,t:1527614169057};\\\", \\\"{x:333,y:563,t:1527614169074};\\\", \\\"{x:335,y:559,t:1527614169090};\\\", \\\"{x:339,y:554,t:1527614169107};\\\", \\\"{x:345,y:548,t:1527614169123};\\\", \\\"{x:351,y:543,t:1527614169140};\\\", \\\"{x:356,y:540,t:1527614169156};\\\", \\\"{x:358,y:539,t:1527614169172};\\\", \\\"{x:360,y:539,t:1527614169190};\\\", \\\"{x:361,y:538,t:1527614169206};\\\", \\\"{x:363,y:536,t:1527614169222};\\\", \\\"{x:364,y:536,t:1527614169240};\\\", \\\"{x:366,y:536,t:1527614169257};\\\", \\\"{x:367,y:535,t:1527614169273};\\\", \\\"{x:369,y:535,t:1527614169289};\\\", \\\"{x:370,y:535,t:1527614169322};\\\", \\\"{x:372,y:535,t:1527614169338};\\\", \\\"{x:372,y:534,t:1527614169346};\\\", \\\"{x:373,y:533,t:1527614169356};\\\", \\\"{x:375,y:533,t:1527614169373};\\\", \\\"{x:376,y:533,t:1527614169390};\\\", \\\"{x:379,y:532,t:1527614169410};\\\", \\\"{x:380,y:532,t:1527614169450};\\\", \\\"{x:380,y:531,t:1527614169474};\\\", \\\"{x:374,y:535,t:1527614169723};\\\", \\\"{x:364,y:537,t:1527614169731};\\\", \\\"{x:351,y:542,t:1527614169741};\\\", \\\"{x:326,y:547,t:1527614169757};\\\", \\\"{x:296,y:556,t:1527614169774};\\\", \\\"{x:276,y:559,t:1527614169791};\\\", \\\"{x:258,y:559,t:1527614169807};\\\", \\\"{x:241,y:559,t:1527614169824};\\\", \\\"{x:232,y:559,t:1527614169841};\\\", \\\"{x:229,y:559,t:1527614169857};\\\", \\\"{x:228,y:559,t:1527614169874};\\\", \\\"{x:227,y:560,t:1527614169930};\\\", \\\"{x:225,y:561,t:1527614169940};\\\", \\\"{x:222,y:562,t:1527614169957};\\\", \\\"{x:217,y:566,t:1527614169975};\\\", \\\"{x:212,y:569,t:1527614169991};\\\", \\\"{x:208,y:569,t:1527614170008};\\\", \\\"{x:204,y:572,t:1527614170023};\\\", \\\"{x:202,y:572,t:1527614170040};\\\", \\\"{x:200,y:572,t:1527614170057};\\\", \\\"{x:195,y:573,t:1527614170074};\\\", \\\"{x:189,y:573,t:1527614170091};\\\", \\\"{x:186,y:575,t:1527614170108};\\\", \\\"{x:184,y:576,t:1527614170124};\\\", \\\"{x:181,y:576,t:1527614170141};\\\", \\\"{x:179,y:577,t:1527614170157};\\\", \\\"{x:178,y:578,t:1527614170174};\\\", \\\"{x:176,y:578,t:1527614170202};\\\", \\\"{x:175,y:578,t:1527614170218};\\\", \\\"{x:174,y:578,t:1527614170226};\\\", \\\"{x:173,y:578,t:1527614170241};\\\", \\\"{x:169,y:580,t:1527614170258};\\\", \\\"{x:168,y:580,t:1527614170273};\\\", \\\"{x:166,y:580,t:1527614170290};\\\", \\\"{x:165,y:580,t:1527614170308};\\\", \\\"{x:163,y:580,t:1527614170324};\\\", \\\"{x:162,y:580,t:1527614170341};\\\", \\\"{x:160,y:580,t:1527614170362};\\\", \\\"{x:164,y:580,t:1527614170626};\\\", \\\"{x:174,y:584,t:1527614170641};\\\", \\\"{x:207,y:600,t:1527614170658};\\\", \\\"{x:273,y:622,t:1527614170674};\\\", \\\"{x:308,y:636,t:1527614170691};\\\", \\\"{x:337,y:648,t:1527614170708};\\\", \\\"{x:363,y:659,t:1527614170724};\\\", \\\"{x:392,y:670,t:1527614170741};\\\", \\\"{x:416,y:681,t:1527614170758};\\\", \\\"{x:439,y:691,t:1527614170775};\\\", \\\"{x:459,y:699,t:1527614170791};\\\", \\\"{x:474,y:709,t:1527614170807};\\\", \\\"{x:485,y:715,t:1527614170825};\\\", \\\"{x:489,y:718,t:1527614170840};\\\", \\\"{x:490,y:718,t:1527614170858};\\\", \\\"{x:490,y:721,t:1527614170875};\\\", \\\"{x:491,y:724,t:1527614170891};\\\", \\\"{x:492,y:727,t:1527614170908};\\\", \\\"{x:492,y:728,t:1527614170925};\\\", \\\"{x:493,y:729,t:1527614170942};\\\", \\\"{x:493,y:730,t:1527614170957};\\\", \\\"{x:494,y:731,t:1527614170978};\\\", \\\"{x:495,y:731,t:1527614170994};\\\", \\\"{x:495,y:732,t:1527614171008};\\\", \\\"{x:496,y:733,t:1527614171025};\\\" ] }, { \\\"rt\\\": 26042, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 523287, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:496,y:734,t:1527614172693};\\\", \\\"{x:496,y:736,t:1527614172906};\\\", \\\"{x:495,y:738,t:1527614172914};\\\", \\\"{x:495,y:740,t:1527614172926};\\\", \\\"{x:493,y:743,t:1527614172943};\\\", \\\"{x:492,y:748,t:1527614172960};\\\", \\\"{x:491,y:752,t:1527614172976};\\\", \\\"{x:489,y:757,t:1527614172993};\\\", \\\"{x:487,y:763,t:1527614173010};\\\", \\\"{x:487,y:765,t:1527614173026};\\\", \\\"{x:485,y:769,t:1527614173043};\\\", \\\"{x:483,y:776,t:1527614173130};\\\", \\\"{x:482,y:777,t:1527614173144};\\\", \\\"{x:481,y:778,t:1527614173162};\\\", \\\"{x:481,y:779,t:1527614173177};\\\", \\\"{x:481,y:781,t:1527614173242};\\\", \\\"{x:480,y:782,t:1527614173282};\\\", \\\"{x:479,y:783,t:1527614173330};\\\", \\\"{x:478,y:785,t:1527614173418};\\\", \\\"{x:487,y:794,t:1527614174626};\\\", \\\"{x:519,y:810,t:1527614174634};\\\", \\\"{x:568,y:818,t:1527614174643};\\\", \\\"{x:666,y:835,t:1527614174661};\\\", \\\"{x:750,y:848,t:1527614174677};\\\", \\\"{x:822,y:857,t:1527614174694};\\\", \\\"{x:880,y:857,t:1527614174711};\\\", \\\"{x:971,y:867,t:1527614174728};\\\", \\\"{x:1083,y:885,t:1527614174744};\\\", \\\"{x:1205,y:904,t:1527614174761};\\\", \\\"{x:1359,y:927,t:1527614174778};\\\", \\\"{x:1435,y:942,t:1527614174793};\\\", \\\"{x:1503,y:956,t:1527614174810};\\\", \\\"{x:1567,y:971,t:1527614174828};\\\", \\\"{x:1624,y:993,t:1527614174844};\\\", \\\"{x:1651,y:1005,t:1527614174861};\\\", \\\"{x:1664,y:1012,t:1527614174877};\\\", \\\"{x:1677,y:1014,t:1527614174893};\\\", \\\"{x:1681,y:1014,t:1527614174910};\\\", \\\"{x:1678,y:1015,t:1527614175027};\\\", \\\"{x:1675,y:1015,t:1527614175034};\\\", \\\"{x:1667,y:1015,t:1527614175043};\\\", \\\"{x:1648,y:1015,t:1527614175060};\\\", \\\"{x:1623,y:1011,t:1527614175077};\\\", \\\"{x:1591,y:1004,t:1527614175094};\\\", \\\"{x:1563,y:997,t:1527614175110};\\\", \\\"{x:1542,y:991,t:1527614175128};\\\", \\\"{x:1529,y:987,t:1527614175144};\\\", \\\"{x:1521,y:983,t:1527614175161};\\\", \\\"{x:1518,y:982,t:1527614175178};\\\", \\\"{x:1518,y:981,t:1527614175209};\\\", \\\"{x:1518,y:980,t:1527614175218};\\\", \\\"{x:1518,y:979,t:1527614175298};\\\", \\\"{x:1518,y:977,t:1527614175311};\\\", \\\"{x:1522,y:976,t:1527614175328};\\\", \\\"{x:1528,y:973,t:1527614175345};\\\", \\\"{x:1532,y:971,t:1527614175361};\\\", \\\"{x:1534,y:970,t:1527614175378};\\\", \\\"{x:1535,y:969,t:1527614175434};\\\", \\\"{x:1536,y:969,t:1527614175445};\\\", \\\"{x:1537,y:969,t:1527614175460};\\\", \\\"{x:1539,y:968,t:1527614175478};\\\", \\\"{x:1540,y:968,t:1527614175495};\\\", \\\"{x:1541,y:967,t:1527614175510};\\\", \\\"{x:1541,y:966,t:1527614175562};\\\", \\\"{x:1542,y:964,t:1527614175587};\\\", \\\"{x:1543,y:964,t:1527614175610};\\\", \\\"{x:1543,y:963,t:1527614175667};\\\", \\\"{x:1544,y:963,t:1527614175707};\\\", \\\"{x:1544,y:961,t:1527614175723};\\\", \\\"{x:1545,y:961,t:1527614175738};\\\", \\\"{x:1546,y:960,t:1527614175754};\\\", \\\"{x:1546,y:958,t:1527614176074};\\\", \\\"{x:1546,y:957,t:1527614176090};\\\", \\\"{x:1546,y:956,t:1527614176098};\\\", \\\"{x:1545,y:955,t:1527614176114};\\\", \\\"{x:1545,y:953,t:1527614176138};\\\", \\\"{x:1545,y:950,t:1527614176155};\\\", \\\"{x:1544,y:948,t:1527614176162};\\\", \\\"{x:1543,y:948,t:1527614176178};\\\", \\\"{x:1543,y:946,t:1527614176194};\\\", \\\"{x:1543,y:945,t:1527614176212};\\\", \\\"{x:1542,y:944,t:1527614176227};\\\", \\\"{x:1542,y:942,t:1527614176245};\\\", \\\"{x:1542,y:939,t:1527614176262};\\\", \\\"{x:1541,y:936,t:1527614176279};\\\", \\\"{x:1540,y:934,t:1527614176294};\\\", \\\"{x:1540,y:931,t:1527614176312};\\\", \\\"{x:1540,y:929,t:1527614176329};\\\", \\\"{x:1540,y:926,t:1527614176345};\\\", \\\"{x:1540,y:923,t:1527614176362};\\\", \\\"{x:1540,y:921,t:1527614176379};\\\", \\\"{x:1540,y:918,t:1527614176394};\\\", \\\"{x:1540,y:916,t:1527614176412};\\\", \\\"{x:1540,y:912,t:1527614176429};\\\", \\\"{x:1540,y:906,t:1527614176445};\\\", \\\"{x:1540,y:902,t:1527614176462};\\\", \\\"{x:1540,y:900,t:1527614176479};\\\", \\\"{x:1540,y:897,t:1527614176495};\\\", \\\"{x:1540,y:893,t:1527614176512};\\\", \\\"{x:1540,y:891,t:1527614176528};\\\", \\\"{x:1540,y:888,t:1527614176545};\\\", \\\"{x:1540,y:885,t:1527614176562};\\\", \\\"{x:1540,y:884,t:1527614176579};\\\", \\\"{x:1540,y:883,t:1527614176594};\\\", \\\"{x:1540,y:881,t:1527614176612};\\\", \\\"{x:1540,y:878,t:1527614176628};\\\", \\\"{x:1540,y:877,t:1527614176645};\\\", \\\"{x:1540,y:874,t:1527614176662};\\\", \\\"{x:1540,y:872,t:1527614176678};\\\", \\\"{x:1540,y:871,t:1527614176695};\\\", \\\"{x:1540,y:869,t:1527614176711};\\\", \\\"{x:1540,y:868,t:1527614176729};\\\", \\\"{x:1540,y:866,t:1527614176745};\\\", \\\"{x:1540,y:863,t:1527614176762};\\\", \\\"{x:1540,y:862,t:1527614176779};\\\", \\\"{x:1540,y:860,t:1527614176819};\\\", \\\"{x:1540,y:861,t:1527614177114};\\\", \\\"{x:1540,y:864,t:1527614177129};\\\", \\\"{x:1540,y:888,t:1527614177146};\\\", \\\"{x:1540,y:902,t:1527614177162};\\\", \\\"{x:1540,y:917,t:1527614177179};\\\", \\\"{x:1540,y:928,t:1527614177196};\\\", \\\"{x:1541,y:937,t:1527614177212};\\\", \\\"{x:1541,y:949,t:1527614177229};\\\", \\\"{x:1541,y:956,t:1527614177246};\\\", \\\"{x:1541,y:961,t:1527614177262};\\\", \\\"{x:1541,y:968,t:1527614177279};\\\", \\\"{x:1541,y:972,t:1527614177296};\\\", \\\"{x:1541,y:975,t:1527614177313};\\\", \\\"{x:1541,y:976,t:1527614177329};\\\", \\\"{x:1541,y:978,t:1527614177362};\\\", \\\"{x:1541,y:976,t:1527614177514};\\\", \\\"{x:1540,y:974,t:1527614177529};\\\", \\\"{x:1537,y:972,t:1527614177546};\\\", \\\"{x:1537,y:969,t:1527614177563};\\\", \\\"{x:1536,y:967,t:1527614177579};\\\", \\\"{x:1536,y:965,t:1527614177596};\\\", \\\"{x:1536,y:964,t:1527614177618};\\\", \\\"{x:1536,y:962,t:1527614177650};\\\", \\\"{x:1535,y:962,t:1527614177682};\\\", \\\"{x:1534,y:960,t:1527614177699};\\\", \\\"{x:1534,y:959,t:1527614177714};\\\", \\\"{x:1534,y:958,t:1527614177730};\\\", \\\"{x:1534,y:957,t:1527614177746};\\\", \\\"{x:1534,y:955,t:1527614177763};\\\", \\\"{x:1534,y:953,t:1527614177779};\\\", \\\"{x:1533,y:951,t:1527614177796};\\\", \\\"{x:1533,y:949,t:1527614177813};\\\", \\\"{x:1533,y:946,t:1527614177829};\\\", \\\"{x:1533,y:945,t:1527614177846};\\\", \\\"{x:1533,y:943,t:1527614177863};\\\", \\\"{x:1533,y:941,t:1527614177880};\\\", \\\"{x:1532,y:940,t:1527614177896};\\\", \\\"{x:1532,y:938,t:1527614177922};\\\", \\\"{x:1532,y:937,t:1527614177938};\\\", \\\"{x:1532,y:935,t:1527614177962};\\\", \\\"{x:1532,y:934,t:1527614177986};\\\", \\\"{x:1532,y:933,t:1527614178194};\\\", \\\"{x:1534,y:934,t:1527614178202};\\\", \\\"{x:1534,y:935,t:1527614178213};\\\", \\\"{x:1534,y:939,t:1527614178230};\\\", \\\"{x:1535,y:945,t:1527614178246};\\\", \\\"{x:1536,y:947,t:1527614178263};\\\", \\\"{x:1538,y:949,t:1527614178281};\\\", \\\"{x:1538,y:951,t:1527614178296};\\\", \\\"{x:1539,y:952,t:1527614178330};\\\", \\\"{x:1540,y:952,t:1527614178442};\\\", \\\"{x:1540,y:953,t:1527614178458};\\\", \\\"{x:1540,y:955,t:1527614178474};\\\", \\\"{x:1541,y:956,t:1527614178491};\\\", \\\"{x:1543,y:956,t:1527614178538};\\\", \\\"{x:1543,y:958,t:1527614178547};\\\", \\\"{x:1544,y:959,t:1527614178563};\\\", \\\"{x:1546,y:959,t:1527614178581};\\\", \\\"{x:1547,y:959,t:1527614178635};\\\", \\\"{x:1548,y:959,t:1527614178723};\\\", \\\"{x:1549,y:959,t:1527614178731};\\\", \\\"{x:1552,y:959,t:1527614178802};\\\", \\\"{x:1553,y:959,t:1527614178818};\\\", \\\"{x:1555,y:959,t:1527614178891};\\\", \\\"{x:1555,y:960,t:1527614179058};\\\", \\\"{x:1553,y:960,t:1527614179066};\\\", \\\"{x:1552,y:961,t:1527614179080};\\\", \\\"{x:1552,y:962,t:1527614179097};\\\", \\\"{x:1550,y:962,t:1527614179114};\\\", \\\"{x:1549,y:963,t:1527614179130};\\\", \\\"{x:1547,y:963,t:1527614179474};\\\", \\\"{x:1547,y:961,t:1527614179481};\\\", \\\"{x:1547,y:960,t:1527614179497};\\\", \\\"{x:1545,y:955,t:1527614179514};\\\", \\\"{x:1543,y:950,t:1527614179531};\\\", \\\"{x:1542,y:947,t:1527614179547};\\\", \\\"{x:1542,y:943,t:1527614179565};\\\", \\\"{x:1542,y:941,t:1527614179581};\\\", \\\"{x:1542,y:940,t:1527614179598};\\\", \\\"{x:1542,y:937,t:1527614179614};\\\", \\\"{x:1542,y:936,t:1527614179631};\\\", \\\"{x:1542,y:934,t:1527614179647};\\\", \\\"{x:1542,y:933,t:1527614179664};\\\", \\\"{x:1542,y:932,t:1527614179681};\\\", \\\"{x:1542,y:931,t:1527614179697};\\\", \\\"{x:1542,y:929,t:1527614179714};\\\", \\\"{x:1542,y:928,t:1527614179731};\\\", \\\"{x:1542,y:926,t:1527614179747};\\\", \\\"{x:1542,y:924,t:1527614179764};\\\", \\\"{x:1542,y:923,t:1527614179781};\\\", \\\"{x:1542,y:921,t:1527614179797};\\\", \\\"{x:1542,y:919,t:1527614179814};\\\", \\\"{x:1542,y:917,t:1527614179831};\\\", \\\"{x:1542,y:916,t:1527614179847};\\\", \\\"{x:1542,y:915,t:1527614179864};\\\", \\\"{x:1543,y:912,t:1527614179881};\\\", \\\"{x:1543,y:911,t:1527614179897};\\\", \\\"{x:1543,y:907,t:1527614179913};\\\", \\\"{x:1543,y:906,t:1527614179931};\\\", \\\"{x:1543,y:905,t:1527614179970};\\\", \\\"{x:1543,y:904,t:1527614179981};\\\", \\\"{x:1543,y:903,t:1527614179998};\\\", \\\"{x:1543,y:902,t:1527614180014};\\\", \\\"{x:1543,y:901,t:1527614180032};\\\", \\\"{x:1543,y:900,t:1527614180048};\\\", \\\"{x:1543,y:899,t:1527614180064};\\\", \\\"{x:1543,y:898,t:1527614180081};\\\", \\\"{x:1543,y:897,t:1527614180098};\\\", \\\"{x:1543,y:895,t:1527614180114};\\\", \\\"{x:1543,y:894,t:1527614180132};\\\", \\\"{x:1543,y:893,t:1527614180148};\\\", \\\"{x:1543,y:892,t:1527614180179};\\\", \\\"{x:1543,y:891,t:1527614180187};\\\", \\\"{x:1543,y:890,t:1527614180210};\\\", \\\"{x:1543,y:888,t:1527614180234};\\\", \\\"{x:1543,y:887,t:1527614180250};\\\", \\\"{x:1543,y:886,t:1527614180265};\\\", \\\"{x:1543,y:885,t:1527614180290};\\\", \\\"{x:1543,y:884,t:1527614180306};\\\", \\\"{x:1544,y:883,t:1527614180322};\\\", \\\"{x:1544,y:882,t:1527614180331};\\\", \\\"{x:1544,y:881,t:1527614180348};\\\", \\\"{x:1544,y:880,t:1527614180364};\\\", \\\"{x:1544,y:878,t:1527614180381};\\\", \\\"{x:1545,y:878,t:1527614180398};\\\", \\\"{x:1546,y:875,t:1527614180414};\\\", \\\"{x:1546,y:873,t:1527614180442};\\\", \\\"{x:1546,y:872,t:1527614180457};\\\", \\\"{x:1546,y:870,t:1527614180482};\\\", \\\"{x:1546,y:869,t:1527614180498};\\\", \\\"{x:1546,y:867,t:1527614180515};\\\", \\\"{x:1546,y:866,t:1527614180538};\\\", \\\"{x:1546,y:864,t:1527614180554};\\\", \\\"{x:1546,y:863,t:1527614180577};\\\", \\\"{x:1547,y:862,t:1527614180585};\\\", \\\"{x:1547,y:861,t:1527614180602};\\\", \\\"{x:1547,y:860,t:1527614180626};\\\", \\\"{x:1547,y:858,t:1527614180650};\\\", \\\"{x:1547,y:857,t:1527614180690};\\\", \\\"{x:1547,y:855,t:1527614180706};\\\", \\\"{x:1547,y:854,t:1527614180730};\\\", \\\"{x:1548,y:852,t:1527614180738};\\\", \\\"{x:1548,y:851,t:1527614180762};\\\", \\\"{x:1548,y:850,t:1527614180794};\\\", \\\"{x:1548,y:849,t:1527614180810};\\\", \\\"{x:1548,y:847,t:1527614180842};\\\", \\\"{x:1548,y:846,t:1527614180857};\\\", \\\"{x:1548,y:845,t:1527614180866};\\\", \\\"{x:1548,y:844,t:1527614180890};\\\", \\\"{x:1548,y:843,t:1527614180898};\\\", \\\"{x:1548,y:842,t:1527614180915};\\\", \\\"{x:1548,y:841,t:1527614180938};\\\", \\\"{x:1548,y:840,t:1527614180953};\\\", \\\"{x:1548,y:839,t:1527614180965};\\\", \\\"{x:1547,y:839,t:1527614180981};\\\", \\\"{x:1547,y:838,t:1527614180998};\\\", \\\"{x:1547,y:836,t:1527614181015};\\\", \\\"{x:1546,y:835,t:1527614181032};\\\", \\\"{x:1545,y:834,t:1527614181048};\\\", \\\"{x:1545,y:833,t:1527614181065};\\\", \\\"{x:1545,y:832,t:1527614181081};\\\", \\\"{x:1545,y:831,t:1527614181114};\\\", \\\"{x:1545,y:830,t:1527614181130};\\\", \\\"{x:1545,y:829,t:1527614181177};\\\", \\\"{x:1545,y:828,t:1527614181202};\\\", \\\"{x:1545,y:830,t:1527614181618};\\\", \\\"{x:1545,y:831,t:1527614181632};\\\", \\\"{x:1545,y:833,t:1527614181649};\\\", \\\"{x:1545,y:836,t:1527614181665};\\\", \\\"{x:1545,y:838,t:1527614181683};\\\", \\\"{x:1546,y:840,t:1527614181699};\\\", \\\"{x:1546,y:842,t:1527614181715};\\\", \\\"{x:1546,y:844,t:1527614181732};\\\", \\\"{x:1546,y:846,t:1527614181778};\\\", \\\"{x:1546,y:847,t:1527614181794};\\\", \\\"{x:1546,y:849,t:1527614181818};\\\", \\\"{x:1546,y:850,t:1527614181832};\\\", \\\"{x:1547,y:853,t:1527614181849};\\\", \\\"{x:1548,y:856,t:1527614181865};\\\", \\\"{x:1549,y:857,t:1527614181882};\\\", \\\"{x:1550,y:859,t:1527614181899};\\\", \\\"{x:1550,y:862,t:1527614181915};\\\", \\\"{x:1552,y:863,t:1527614181932};\\\", \\\"{x:1553,y:865,t:1527614181949};\\\", \\\"{x:1554,y:866,t:1527614181965};\\\", \\\"{x:1554,y:869,t:1527614181982};\\\", \\\"{x:1554,y:870,t:1527614181999};\\\", \\\"{x:1554,y:871,t:1527614182015};\\\", \\\"{x:1554,y:873,t:1527614182032};\\\", \\\"{x:1554,y:877,t:1527614182049};\\\", \\\"{x:1554,y:880,t:1527614182066};\\\", \\\"{x:1554,y:883,t:1527614182082};\\\", \\\"{x:1554,y:887,t:1527614182099};\\\", \\\"{x:1554,y:890,t:1527614182116};\\\", \\\"{x:1554,y:892,t:1527614182132};\\\", \\\"{x:1554,y:895,t:1527614182150};\\\", \\\"{x:1554,y:899,t:1527614182166};\\\", \\\"{x:1554,y:900,t:1527614182182};\\\", \\\"{x:1554,y:903,t:1527614182199};\\\", \\\"{x:1554,y:906,t:1527614182216};\\\", \\\"{x:1554,y:907,t:1527614182232};\\\", \\\"{x:1554,y:909,t:1527614182250};\\\", \\\"{x:1554,y:908,t:1527614182386};\\\", \\\"{x:1554,y:906,t:1527614182399};\\\", \\\"{x:1554,y:903,t:1527614182416};\\\", \\\"{x:1554,y:899,t:1527614182432};\\\", \\\"{x:1554,y:896,t:1527614182449};\\\", \\\"{x:1554,y:888,t:1527614182466};\\\", \\\"{x:1554,y:885,t:1527614182483};\\\", \\\"{x:1554,y:882,t:1527614182499};\\\", \\\"{x:1554,y:879,t:1527614182516};\\\", \\\"{x:1554,y:877,t:1527614182533};\\\", \\\"{x:1554,y:875,t:1527614182549};\\\", \\\"{x:1554,y:873,t:1527614182566};\\\", \\\"{x:1554,y:871,t:1527614182583};\\\", \\\"{x:1554,y:868,t:1527614182599};\\\", \\\"{x:1554,y:865,t:1527614182616};\\\", \\\"{x:1553,y:860,t:1527614182633};\\\", \\\"{x:1553,y:859,t:1527614182649};\\\", \\\"{x:1551,y:855,t:1527614182666};\\\", \\\"{x:1550,y:850,t:1527614182683};\\\", \\\"{x:1549,y:847,t:1527614182699};\\\", \\\"{x:1548,y:844,t:1527614182716};\\\", \\\"{x:1548,y:843,t:1527614182733};\\\", \\\"{x:1548,y:841,t:1527614182750};\\\", \\\"{x:1546,y:840,t:1527614182766};\\\", \\\"{x:1545,y:840,t:1527614182784};\\\", \\\"{x:1545,y:838,t:1527614182810};\\\", \\\"{x:1545,y:837,t:1527614183018};\\\", \\\"{x:1545,y:836,t:1527614183163};\\\", \\\"{x:1546,y:835,t:1527614183178};\\\", \\\"{x:1546,y:834,t:1527614183194};\\\", \\\"{x:1546,y:832,t:1527614183234};\\\", \\\"{x:1546,y:834,t:1527614183522};\\\", \\\"{x:1546,y:836,t:1527614183534};\\\", \\\"{x:1546,y:839,t:1527614183550};\\\", \\\"{x:1546,y:843,t:1527614183566};\\\", \\\"{x:1545,y:848,t:1527614183583};\\\", \\\"{x:1545,y:852,t:1527614183601};\\\", \\\"{x:1545,y:857,t:1527614183616};\\\", \\\"{x:1545,y:861,t:1527614183633};\\\", \\\"{x:1545,y:864,t:1527614183650};\\\", \\\"{x:1545,y:867,t:1527614183668};\\\", \\\"{x:1545,y:869,t:1527614183683};\\\", \\\"{x:1545,y:870,t:1527614183700};\\\", \\\"{x:1545,y:873,t:1527614183717};\\\", \\\"{x:1545,y:874,t:1527614183733};\\\", \\\"{x:1545,y:876,t:1527614183751};\\\", \\\"{x:1545,y:878,t:1527614183767};\\\", \\\"{x:1545,y:882,t:1527614183783};\\\", \\\"{x:1545,y:884,t:1527614183800};\\\", \\\"{x:1545,y:887,t:1527614183817};\\\", \\\"{x:1545,y:890,t:1527614183833};\\\", \\\"{x:1545,y:893,t:1527614183851};\\\", \\\"{x:1545,y:897,t:1527614183868};\\\", \\\"{x:1545,y:899,t:1527614183884};\\\", \\\"{x:1545,y:902,t:1527614183901};\\\", \\\"{x:1545,y:903,t:1527614183917};\\\", \\\"{x:1545,y:907,t:1527614183933};\\\", \\\"{x:1545,y:910,t:1527614183950};\\\", \\\"{x:1545,y:914,t:1527614183967};\\\", \\\"{x:1545,y:916,t:1527614183983};\\\", \\\"{x:1545,y:919,t:1527614184000};\\\", \\\"{x:1545,y:920,t:1527614184017};\\\", \\\"{x:1545,y:922,t:1527614184034};\\\", \\\"{x:1545,y:926,t:1527614184050};\\\", \\\"{x:1545,y:928,t:1527614184067};\\\", \\\"{x:1545,y:930,t:1527614184083};\\\", \\\"{x:1545,y:931,t:1527614184101};\\\", \\\"{x:1545,y:934,t:1527614184117};\\\", \\\"{x:1545,y:935,t:1527614184133};\\\", \\\"{x:1545,y:938,t:1527614184150};\\\", \\\"{x:1545,y:941,t:1527614184167};\\\", \\\"{x:1545,y:944,t:1527614184184};\\\", \\\"{x:1545,y:947,t:1527614184201};\\\", \\\"{x:1545,y:948,t:1527614184217};\\\", \\\"{x:1545,y:952,t:1527614184234};\\\", \\\"{x:1544,y:955,t:1527614184250};\\\", \\\"{x:1544,y:958,t:1527614184267};\\\", \\\"{x:1544,y:960,t:1527614184285};\\\", \\\"{x:1544,y:961,t:1527614184300};\\\", \\\"{x:1544,y:962,t:1527614184317};\\\", \\\"{x:1544,y:960,t:1527614184458};\\\", \\\"{x:1544,y:957,t:1527614184467};\\\", \\\"{x:1544,y:953,t:1527614184484};\\\", \\\"{x:1544,y:946,t:1527614184501};\\\", \\\"{x:1544,y:940,t:1527614184518};\\\", \\\"{x:1544,y:934,t:1527614184534};\\\", \\\"{x:1544,y:930,t:1527614184550};\\\", \\\"{x:1544,y:925,t:1527614184567};\\\", \\\"{x:1544,y:920,t:1527614184584};\\\", \\\"{x:1544,y:917,t:1527614184600};\\\", \\\"{x:1544,y:912,t:1527614184617};\\\", \\\"{x:1543,y:907,t:1527614184634};\\\", \\\"{x:1543,y:903,t:1527614184650};\\\", \\\"{x:1543,y:900,t:1527614184667};\\\", \\\"{x:1543,y:898,t:1527614184684};\\\", \\\"{x:1543,y:893,t:1527614184702};\\\", \\\"{x:1543,y:889,t:1527614184717};\\\", \\\"{x:1543,y:885,t:1527614184735};\\\", \\\"{x:1544,y:879,t:1527614184751};\\\", \\\"{x:1545,y:872,t:1527614184767};\\\", \\\"{x:1545,y:866,t:1527614184784};\\\", \\\"{x:1546,y:861,t:1527614184801};\\\", \\\"{x:1547,y:853,t:1527614184817};\\\", \\\"{x:1549,y:845,t:1527614184834};\\\", \\\"{x:1549,y:841,t:1527614184851};\\\", \\\"{x:1549,y:838,t:1527614184867};\\\", \\\"{x:1549,y:836,t:1527614184885};\\\", \\\"{x:1549,y:835,t:1527614184901};\\\", \\\"{x:1549,y:832,t:1527614184917};\\\", \\\"{x:1549,y:831,t:1527614184954};\\\", \\\"{x:1549,y:829,t:1527614184967};\\\", \\\"{x:1549,y:828,t:1527614185018};\\\", \\\"{x:1549,y:826,t:1527614185034};\\\", \\\"{x:1549,y:824,t:1527614185051};\\\", \\\"{x:1549,y:821,t:1527614185067};\\\", \\\"{x:1550,y:818,t:1527614185084};\\\", \\\"{x:1550,y:812,t:1527614185101};\\\", \\\"{x:1550,y:807,t:1527614185117};\\\", \\\"{x:1550,y:801,t:1527614185134};\\\", \\\"{x:1550,y:795,t:1527614185152};\\\", \\\"{x:1550,y:791,t:1527614185168};\\\", \\\"{x:1550,y:785,t:1527614185184};\\\", \\\"{x:1551,y:780,t:1527614185202};\\\", \\\"{x:1551,y:776,t:1527614185218};\\\", \\\"{x:1553,y:772,t:1527614185234};\\\", \\\"{x:1553,y:770,t:1527614185251};\\\", \\\"{x:1553,y:768,t:1527614185268};\\\", \\\"{x:1553,y:767,t:1527614185285};\\\", \\\"{x:1553,y:764,t:1527614185301};\\\", \\\"{x:1552,y:763,t:1527614185318};\\\", \\\"{x:1552,y:762,t:1527614185335};\\\", \\\"{x:1552,y:760,t:1527614185351};\\\", \\\"{x:1552,y:758,t:1527614185368};\\\", \\\"{x:1552,y:757,t:1527614185384};\\\", \\\"{x:1550,y:754,t:1527614185401};\\\", \\\"{x:1549,y:751,t:1527614185418};\\\", \\\"{x:1549,y:747,t:1527614185434};\\\", \\\"{x:1549,y:744,t:1527614185451};\\\", \\\"{x:1549,y:739,t:1527614185468};\\\", \\\"{x:1548,y:735,t:1527614185485};\\\", \\\"{x:1546,y:731,t:1527614185502};\\\", \\\"{x:1546,y:728,t:1527614185519};\\\", \\\"{x:1546,y:724,t:1527614185534};\\\", \\\"{x:1546,y:721,t:1527614185551};\\\", \\\"{x:1545,y:716,t:1527614185568};\\\", \\\"{x:1544,y:715,t:1527614185584};\\\", \\\"{x:1543,y:710,t:1527614185602};\\\", \\\"{x:1542,y:707,t:1527614185618};\\\", \\\"{x:1542,y:705,t:1527614185635};\\\", \\\"{x:1541,y:702,t:1527614185651};\\\", \\\"{x:1541,y:700,t:1527614185668};\\\", \\\"{x:1541,y:699,t:1527614185685};\\\", \\\"{x:1541,y:697,t:1527614185701};\\\", \\\"{x:1541,y:696,t:1527614185719};\\\", \\\"{x:1541,y:694,t:1527614185735};\\\", \\\"{x:1541,y:693,t:1527614185751};\\\", \\\"{x:1541,y:691,t:1527614185768};\\\", \\\"{x:1540,y:689,t:1527614185785};\\\", \\\"{x:1539,y:688,t:1527614185802};\\\", \\\"{x:1539,y:687,t:1527614185819};\\\", \\\"{x:1539,y:686,t:1527614185836};\\\", \\\"{x:1539,y:685,t:1527614185851};\\\", \\\"{x:1539,y:684,t:1527614185868};\\\", \\\"{x:1539,y:683,t:1527614185889};\\\", \\\"{x:1538,y:681,t:1527614185905};\\\", \\\"{x:1538,y:680,t:1527614186098};\\\", \\\"{x:1538,y:679,t:1527614189786};\\\", \\\"{x:1538,y:681,t:1527614190018};\\\", \\\"{x:1538,y:685,t:1527614190025};\\\", \\\"{x:1538,y:689,t:1527614190037};\\\", \\\"{x:1538,y:695,t:1527614190054};\\\", \\\"{x:1538,y:700,t:1527614190071};\\\", \\\"{x:1538,y:702,t:1527614190088};\\\", \\\"{x:1538,y:704,t:1527614190105};\\\", \\\"{x:1538,y:706,t:1527614190122};\\\", \\\"{x:1538,y:707,t:1527614190137};\\\", \\\"{x:1539,y:708,t:1527614190178};\\\", \\\"{x:1541,y:708,t:1527614190234};\\\", \\\"{x:1542,y:709,t:1527614190242};\\\", \\\"{x:1543,y:709,t:1527614190258};\\\", \\\"{x:1544,y:709,t:1527614190306};\\\", \\\"{x:1545,y:709,t:1527614190322};\\\", \\\"{x:1546,y:709,t:1527614190338};\\\", \\\"{x:1548,y:709,t:1527614190355};\\\", \\\"{x:1549,y:709,t:1527614190371};\\\", \\\"{x:1550,y:709,t:1527614190450};\\\", \\\"{x:1551,y:708,t:1527614190570};\\\", \\\"{x:1551,y:707,t:1527614190578};\\\", \\\"{x:1551,y:706,t:1527614190588};\\\", \\\"{x:1551,y:703,t:1527614190605};\\\", \\\"{x:1551,y:701,t:1527614190621};\\\", \\\"{x:1549,y:699,t:1527614190639};\\\", \\\"{x:1548,y:698,t:1527614190655};\\\", \\\"{x:1547,y:696,t:1527614190671};\\\", \\\"{x:1547,y:695,t:1527614190738};\\\", \\\"{x:1546,y:694,t:1527614190850};\\\", \\\"{x:1539,y:694,t:1527614197538};\\\", \\\"{x:1504,y:710,t:1527614197545};\\\", \\\"{x:1458,y:728,t:1527614197560};\\\", \\\"{x:1363,y:764,t:1527614197576};\\\", \\\"{x:1315,y:786,t:1527614197593};\\\", \\\"{x:1252,y:818,t:1527614197610};\\\", \\\"{x:1209,y:841,t:1527614197626};\\\", \\\"{x:1154,y:872,t:1527614197643};\\\", \\\"{x:1106,y:897,t:1527614197660};\\\", \\\"{x:1071,y:923,t:1527614197676};\\\", \\\"{x:1025,y:948,t:1527614197693};\\\", \\\"{x:962,y:977,t:1527614197710};\\\", \\\"{x:869,y:996,t:1527614197726};\\\", \\\"{x:771,y:1012,t:1527614197743};\\\", \\\"{x:653,y:1026,t:1527614197760};\\\", \\\"{x:547,y:1042,t:1527614197775};\\\", \\\"{x:460,y:1048,t:1527614197793};\\\", \\\"{x:334,y:1047,t:1527614197809};\\\", \\\"{x:266,y:1031,t:1527614197826};\\\", \\\"{x:238,y:1023,t:1527614197842};\\\", \\\"{x:226,y:1016,t:1527614197860};\\\", \\\"{x:221,y:1011,t:1527614197877};\\\", \\\"{x:221,y:1004,t:1527614197893};\\\", \\\"{x:222,y:991,t:1527614197910};\\\", \\\"{x:231,y:974,t:1527614197927};\\\", \\\"{x:246,y:958,t:1527614197943};\\\", \\\"{x:270,y:942,t:1527614197959};\\\", \\\"{x:294,y:923,t:1527614197977};\\\", \\\"{x:331,y:899,t:1527614197993};\\\", \\\"{x:369,y:879,t:1527614198010};\\\", \\\"{x:389,y:870,t:1527614198027};\\\", \\\"{x:407,y:862,t:1527614198043};\\\", \\\"{x:423,y:854,t:1527614198060};\\\", \\\"{x:434,y:845,t:1527614198077};\\\", \\\"{x:437,y:843,t:1527614198093};\\\", \\\"{x:439,y:839,t:1527614198110};\\\", \\\"{x:445,y:830,t:1527614198127};\\\", \\\"{x:454,y:820,t:1527614198143};\\\", \\\"{x:464,y:810,t:1527614198160};\\\", \\\"{x:475,y:800,t:1527614198177};\\\", \\\"{x:481,y:791,t:1527614198193};\\\", \\\"{x:487,y:783,t:1527614198210};\\\", \\\"{x:490,y:778,t:1527614198227};\\\", \\\"{x:491,y:775,t:1527614198243};\\\", \\\"{x:493,y:772,t:1527614198260};\\\", \\\"{x:494,y:772,t:1527614198276};\\\", \\\"{x:494,y:769,t:1527614198293};\\\", \\\"{x:494,y:767,t:1527614198310};\\\", \\\"{x:495,y:765,t:1527614198327};\\\", \\\"{x:496,y:762,t:1527614198343};\\\", \\\"{x:498,y:759,t:1527614198359};\\\", \\\"{x:498,y:757,t:1527614198377};\\\", \\\"{x:498,y:756,t:1527614198394};\\\", \\\"{x:501,y:750,t:1527614198410};\\\", \\\"{x:502,y:747,t:1527614198427};\\\", \\\"{x:504,y:742,t:1527614198445};\\\", \\\"{x:505,y:739,t:1527614198462};\\\", \\\"{x:506,y:737,t:1527614198478};\\\", \\\"{x:508,y:733,t:1527614198495};\\\", \\\"{x:509,y:732,t:1527614198512};\\\", \\\"{x:509,y:731,t:1527614198530};\\\", \\\"{x:509,y:733,t:1527614198970};\\\", \\\"{x:513,y:743,t:1527614198980};\\\", \\\"{x:518,y:762,t:1527614198996};\\\", \\\"{x:525,y:784,t:1527614199013};\\\", \\\"{x:534,y:807,t:1527614199029};\\\", \\\"{x:541,y:832,t:1527614199047};\\\", \\\"{x:545,y:854,t:1527614199064};\\\", \\\"{x:549,y:882,t:1527614199081};\\\", \\\"{x:552,y:914,t:1527614199097};\\\", \\\"{x:558,y:950,t:1527614199114};\\\", \\\"{x:559,y:962,t:1527614199131};\\\", \\\"{x:560,y:969,t:1527614199146};\\\", \\\"{x:560,y:973,t:1527614199164};\\\", \\\"{x:560,y:975,t:1527614199181};\\\", \\\"{x:561,y:978,t:1527614199196};\\\", \\\"{x:561,y:979,t:1527614199214};\\\", \\\"{x:561,y:980,t:1527614199231};\\\", \\\"{x:561,y:981,t:1527614199247};\\\", \\\"{x:561,y:982,t:1527614199263};\\\", \\\"{x:561,y:983,t:1527614199402};\\\", \\\"{x:561,y:984,t:1527614199426};\\\", \\\"{x:561,y:985,t:1527614199434};\\\" ] }, { \\\"rt\\\": 16728, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 541210, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:554,y:991,t:1527614199921};\\\", \\\"{x:549,y:993,t:1527614199931};\\\", \\\"{x:545,y:994,t:1527614199947};\\\", \\\"{x:544,y:994,t:1527614199978};\\\", \\\"{x:544,y:995,t:1527614203722};\\\", \\\"{x:541,y:997,t:1527614203735};\\\", \\\"{x:537,y:1000,t:1527614203751};\\\", \\\"{x:534,y:1002,t:1527614203767};\\\", \\\"{x:534,y:1003,t:1527614203784};\\\", \\\"{x:533,y:1003,t:1527614203801};\\\", \\\"{x:533,y:1004,t:1527614203817};\\\", \\\"{x:533,y:1003,t:1527614204010};\\\", \\\"{x:536,y:1002,t:1527614204018};\\\", \\\"{x:547,y:998,t:1527614204035};\\\", \\\"{x:568,y:995,t:1527614204051};\\\", \\\"{x:593,y:993,t:1527614204067};\\\", \\\"{x:627,y:993,t:1527614204084};\\\", \\\"{x:666,y:993,t:1527614204101};\\\", \\\"{x:730,y:993,t:1527614204117};\\\", \\\"{x:791,y:993,t:1527614204134};\\\", \\\"{x:889,y:994,t:1527614204152};\\\", \\\"{x:975,y:996,t:1527614204167};\\\", \\\"{x:1036,y:1007,t:1527614204184};\\\", \\\"{x:1083,y:1013,t:1527614204201};\\\", \\\"{x:1135,y:1027,t:1527614204217};\\\", \\\"{x:1182,y:1033,t:1527614204234};\\\", \\\"{x:1220,y:1041,t:1527614204251};\\\", \\\"{x:1250,y:1043,t:1527614204268};\\\", \\\"{x:1273,y:1046,t:1527614204284};\\\", \\\"{x:1299,y:1049,t:1527614204301};\\\", \\\"{x:1324,y:1053,t:1527614204318};\\\", \\\"{x:1348,y:1057,t:1527614204334};\\\", \\\"{x:1375,y:1058,t:1527614204351};\\\", \\\"{x:1402,y:1063,t:1527614204368};\\\", \\\"{x:1431,y:1065,t:1527614204384};\\\", \\\"{x:1450,y:1068,t:1527614204401};\\\", \\\"{x:1463,y:1069,t:1527614204417};\\\", \\\"{x:1464,y:1069,t:1527614204434};\\\", \\\"{x:1465,y:1069,t:1527614204458};\\\", \\\"{x:1467,y:1069,t:1527614204474};\\\", \\\"{x:1469,y:1068,t:1527614204484};\\\", \\\"{x:1475,y:1065,t:1527614204501};\\\", \\\"{x:1477,y:1064,t:1527614204518};\\\", \\\"{x:1480,y:1061,t:1527614204534};\\\", \\\"{x:1481,y:1060,t:1527614204551};\\\", \\\"{x:1485,y:1058,t:1527614204568};\\\", \\\"{x:1490,y:1056,t:1527614204584};\\\", \\\"{x:1496,y:1053,t:1527614204601};\\\", \\\"{x:1505,y:1048,t:1527614204618};\\\", \\\"{x:1509,y:1046,t:1527614204635};\\\", \\\"{x:1511,y:1045,t:1527614204652};\\\", \\\"{x:1511,y:1043,t:1527614204673};\\\", \\\"{x:1511,y:1042,t:1527614204684};\\\", \\\"{x:1511,y:1039,t:1527614204701};\\\", \\\"{x:1510,y:1033,t:1527614204718};\\\", \\\"{x:1507,y:1028,t:1527614204735};\\\", \\\"{x:1504,y:1021,t:1527614204752};\\\", \\\"{x:1498,y:1010,t:1527614204768};\\\", \\\"{x:1493,y:998,t:1527614204785};\\\", \\\"{x:1488,y:984,t:1527614204801};\\\", \\\"{x:1482,y:974,t:1527614204818};\\\", \\\"{x:1480,y:970,t:1527614204835};\\\", \\\"{x:1479,y:967,t:1527614204852};\\\", \\\"{x:1479,y:964,t:1527614204868};\\\", \\\"{x:1477,y:960,t:1527614204885};\\\", \\\"{x:1477,y:958,t:1527614204937};\\\", \\\"{x:1477,y:957,t:1527614205010};\\\", \\\"{x:1477,y:955,t:1527614205066};\\\", \\\"{x:1477,y:954,t:1527614205106};\\\", \\\"{x:1477,y:952,t:1527614205194};\\\", \\\"{x:1477,y:951,t:1527614205218};\\\", \\\"{x:1476,y:950,t:1527614205233};\\\", \\\"{x:1476,y:949,t:1527614205242};\\\", \\\"{x:1476,y:948,t:1527614205252};\\\", \\\"{x:1475,y:946,t:1527614205268};\\\", \\\"{x:1474,y:942,t:1527614205286};\\\", \\\"{x:1473,y:939,t:1527614205303};\\\", \\\"{x:1472,y:936,t:1527614205318};\\\", \\\"{x:1472,y:932,t:1527614205335};\\\", \\\"{x:1470,y:930,t:1527614205352};\\\", \\\"{x:1470,y:927,t:1527614205369};\\\", \\\"{x:1469,y:922,t:1527614205385};\\\", \\\"{x:1469,y:917,t:1527614205402};\\\", \\\"{x:1469,y:913,t:1527614205419};\\\", \\\"{x:1469,y:909,t:1527614205435};\\\", \\\"{x:1469,y:906,t:1527614205452};\\\", \\\"{x:1469,y:902,t:1527614205468};\\\", \\\"{x:1469,y:899,t:1527614205485};\\\", \\\"{x:1469,y:896,t:1527614205502};\\\", \\\"{x:1469,y:890,t:1527614205518};\\\", \\\"{x:1469,y:886,t:1527614205536};\\\", \\\"{x:1469,y:882,t:1527614205552};\\\", \\\"{x:1469,y:878,t:1527614205568};\\\", \\\"{x:1469,y:876,t:1527614205585};\\\", \\\"{x:1469,y:870,t:1527614205602};\\\", \\\"{x:1469,y:865,t:1527614205618};\\\", \\\"{x:1469,y:862,t:1527614205635};\\\", \\\"{x:1469,y:860,t:1527614205652};\\\", \\\"{x:1469,y:856,t:1527614205668};\\\", \\\"{x:1469,y:854,t:1527614205686};\\\", \\\"{x:1469,y:851,t:1527614205702};\\\", \\\"{x:1469,y:848,t:1527614205719};\\\", \\\"{x:1469,y:845,t:1527614205735};\\\", \\\"{x:1469,y:844,t:1527614205752};\\\", \\\"{x:1469,y:842,t:1527614205769};\\\", \\\"{x:1469,y:840,t:1527614205785};\\\", \\\"{x:1468,y:835,t:1527614205803};\\\", \\\"{x:1468,y:832,t:1527614205819};\\\", \\\"{x:1468,y:830,t:1527614205836};\\\", \\\"{x:1468,y:827,t:1527614205852};\\\", \\\"{x:1468,y:823,t:1527614205870};\\\", \\\"{x:1468,y:821,t:1527614205885};\\\", \\\"{x:1468,y:817,t:1527614205902};\\\", \\\"{x:1468,y:814,t:1527614205919};\\\", \\\"{x:1469,y:811,t:1527614205935};\\\", \\\"{x:1469,y:808,t:1527614205952};\\\", \\\"{x:1470,y:806,t:1527614205969};\\\", \\\"{x:1470,y:803,t:1527614205985};\\\", \\\"{x:1470,y:801,t:1527614206002};\\\", \\\"{x:1470,y:798,t:1527614206019};\\\", \\\"{x:1470,y:796,t:1527614206035};\\\", \\\"{x:1471,y:794,t:1527614206052};\\\", \\\"{x:1471,y:791,t:1527614206069};\\\", \\\"{x:1471,y:789,t:1527614206086};\\\", \\\"{x:1472,y:787,t:1527614206103};\\\", \\\"{x:1472,y:785,t:1527614206119};\\\", \\\"{x:1472,y:780,t:1527614206135};\\\", \\\"{x:1472,y:778,t:1527614206152};\\\", \\\"{x:1472,y:772,t:1527614206169};\\\", \\\"{x:1472,y:763,t:1527614206186};\\\", \\\"{x:1472,y:758,t:1527614206202};\\\", \\\"{x:1472,y:752,t:1527614206219};\\\", \\\"{x:1472,y:748,t:1527614206237};\\\", \\\"{x:1472,y:744,t:1527614206253};\\\", \\\"{x:1472,y:739,t:1527614206269};\\\", \\\"{x:1472,y:736,t:1527614206286};\\\", \\\"{x:1472,y:732,t:1527614206302};\\\", \\\"{x:1472,y:729,t:1527614206319};\\\", \\\"{x:1470,y:725,t:1527614206337};\\\", \\\"{x:1470,y:722,t:1527614206352};\\\", \\\"{x:1470,y:718,t:1527614206369};\\\", \\\"{x:1470,y:715,t:1527614206385};\\\", \\\"{x:1470,y:713,t:1527614206403};\\\", \\\"{x:1470,y:710,t:1527614206419};\\\", \\\"{x:1470,y:708,t:1527614206436};\\\", \\\"{x:1470,y:706,t:1527614206452};\\\", \\\"{x:1470,y:704,t:1527614206469};\\\", \\\"{x:1470,y:702,t:1527614206486};\\\", \\\"{x:1470,y:701,t:1527614206502};\\\", \\\"{x:1470,y:699,t:1527614206519};\\\", \\\"{x:1470,y:697,t:1527614206536};\\\", \\\"{x:1470,y:696,t:1527614206553};\\\", \\\"{x:1470,y:694,t:1527614206570};\\\", \\\"{x:1470,y:693,t:1527614206586};\\\", \\\"{x:1470,y:691,t:1527614206603};\\\", \\\"{x:1472,y:689,t:1527614206633};\\\", \\\"{x:1473,y:687,t:1527614206682};\\\", \\\"{x:1474,y:686,t:1527614207553};\\\", \\\"{x:1475,y:685,t:1527614207571};\\\", \\\"{x:1475,y:684,t:1527614207587};\\\", \\\"{x:1476,y:682,t:1527614207603};\\\", \\\"{x:1476,y:681,t:1527614207620};\\\", \\\"{x:1476,y:680,t:1527614207637};\\\", \\\"{x:1476,y:679,t:1527614212594};\\\", \\\"{x:1471,y:675,t:1527614212608};\\\", \\\"{x:1451,y:668,t:1527614212623};\\\", \\\"{x:1428,y:668,t:1527614212641};\\\", \\\"{x:1391,y:668,t:1527614212658};\\\", \\\"{x:1372,y:668,t:1527614212673};\\\", \\\"{x:1352,y:672,t:1527614212691};\\\", \\\"{x:1327,y:674,t:1527614212707};\\\", \\\"{x:1299,y:675,t:1527614212723};\\\", \\\"{x:1270,y:678,t:1527614212741};\\\", \\\"{x:1239,y:678,t:1527614212758};\\\", \\\"{x:1183,y:678,t:1527614212774};\\\", \\\"{x:1130,y:678,t:1527614212790};\\\", \\\"{x:1099,y:678,t:1527614212808};\\\", \\\"{x:1081,y:673,t:1527614212824};\\\", \\\"{x:1064,y:666,t:1527614212841};\\\", \\\"{x:1054,y:661,t:1527614212858};\\\", \\\"{x:1043,y:659,t:1527614212874};\\\", \\\"{x:1042,y:659,t:1527614212890};\\\", \\\"{x:1034,y:659,t:1527614212908};\\\", \\\"{x:1018,y:659,t:1527614212925};\\\", \\\"{x:1006,y:659,t:1527614212940};\\\", \\\"{x:994,y:657,t:1527614212958};\\\", \\\"{x:988,y:657,t:1527614212975};\\\", \\\"{x:978,y:656,t:1527614212991};\\\", \\\"{x:957,y:656,t:1527614213007};\\\", \\\"{x:933,y:656,t:1527614213024};\\\", \\\"{x:892,y:656,t:1527614213040};\\\", \\\"{x:810,y:664,t:1527614213058};\\\", \\\"{x:774,y:673,t:1527614213075};\\\", \\\"{x:738,y:677,t:1527614213091};\\\", \\\"{x:708,y:680,t:1527614213107};\\\", \\\"{x:659,y:678,t:1527614213125};\\\", \\\"{x:600,y:676,t:1527614213141};\\\", \\\"{x:552,y:671,t:1527614213158};\\\", \\\"{x:501,y:661,t:1527614213175};\\\", \\\"{x:465,y:651,t:1527614213191};\\\", \\\"{x:431,y:639,t:1527614213208};\\\", \\\"{x:400,y:630,t:1527614213224};\\\", \\\"{x:370,y:623,t:1527614213241};\\\", \\\"{x:350,y:623,t:1527614213257};\\\", \\\"{x:333,y:624,t:1527614213274};\\\", \\\"{x:332,y:629,t:1527614213290};\\\", \\\"{x:332,y:640,t:1527614213307};\\\", \\\"{x:332,y:647,t:1527614213324};\\\", \\\"{x:332,y:650,t:1527614213340};\\\", \\\"{x:333,y:650,t:1527614213426};\\\", \\\"{x:345,y:648,t:1527614213441};\\\", \\\"{x:364,y:641,t:1527614213459};\\\", \\\"{x:388,y:631,t:1527614213476};\\\", \\\"{x:405,y:623,t:1527614213492};\\\", \\\"{x:416,y:618,t:1527614213509};\\\", \\\"{x:420,y:615,t:1527614213525};\\\", \\\"{x:422,y:613,t:1527614213542};\\\", \\\"{x:422,y:612,t:1527614213559};\\\", \\\"{x:423,y:612,t:1527614213577};\\\", \\\"{x:423,y:611,t:1527614213594};\\\", \\\"{x:423,y:610,t:1527614213617};\\\", \\\"{x:423,y:606,t:1527614213625};\\\", \\\"{x:416,y:597,t:1527614213643};\\\", \\\"{x:409,y:590,t:1527614213658};\\\", \\\"{x:401,y:582,t:1527614213675};\\\", \\\"{x:396,y:577,t:1527614213693};\\\", \\\"{x:392,y:573,t:1527614213709};\\\", \\\"{x:392,y:571,t:1527614213802};\\\", \\\"{x:394,y:569,t:1527614213817};\\\", \\\"{x:395,y:566,t:1527614213826};\\\", \\\"{x:398,y:561,t:1527614213843};\\\", \\\"{x:398,y:558,t:1527614213859};\\\", \\\"{x:398,y:553,t:1527614213876};\\\", \\\"{x:398,y:551,t:1527614213893};\\\", \\\"{x:398,y:549,t:1527614213921};\\\", \\\"{x:397,y:548,t:1527614213930};\\\", \\\"{x:395,y:548,t:1527614213953};\\\", \\\"{x:394,y:547,t:1527614213962};\\\", \\\"{x:392,y:546,t:1527614213976};\\\", \\\"{x:391,y:546,t:1527614213993};\\\", \\\"{x:390,y:545,t:1527614214009};\\\", \\\"{x:389,y:545,t:1527614214065};\\\", \\\"{x:388,y:545,t:1527614214082};\\\", \\\"{x:387,y:545,t:1527614214092};\\\", \\\"{x:386,y:545,t:1527614214109};\\\", \\\"{x:385,y:545,t:1527614214129};\\\", \\\"{x:384,y:545,t:1527614214154};\\\", \\\"{x:383,y:545,t:1527614214161};\\\", \\\"{x:382,y:545,t:1527614214186};\\\", \\\"{x:381,y:545,t:1527614214210};\\\", \\\"{x:382,y:545,t:1527614214481};\\\", \\\"{x:385,y:546,t:1527614214492};\\\", \\\"{x:395,y:547,t:1527614214510};\\\", \\\"{x:413,y:547,t:1527614214527};\\\", \\\"{x:434,y:547,t:1527614214543};\\\", \\\"{x:447,y:544,t:1527614214560};\\\", \\\"{x:463,y:542,t:1527614214576};\\\", \\\"{x:479,y:538,t:1527614214593};\\\", \\\"{x:497,y:535,t:1527614214609};\\\", \\\"{x:509,y:535,t:1527614214626};\\\", \\\"{x:520,y:535,t:1527614214643};\\\", \\\"{x:535,y:535,t:1527614214659};\\\", \\\"{x:543,y:535,t:1527614214676};\\\", \\\"{x:549,y:535,t:1527614214692};\\\", \\\"{x:552,y:535,t:1527614214710};\\\", \\\"{x:553,y:535,t:1527614214727};\\\", \\\"{x:558,y:538,t:1527614214742};\\\", \\\"{x:571,y:542,t:1527614214760};\\\", \\\"{x:584,y:545,t:1527614214777};\\\", \\\"{x:596,y:550,t:1527614214793};\\\", \\\"{x:609,y:554,t:1527614214809};\\\", \\\"{x:612,y:556,t:1527614214827};\\\", \\\"{x:615,y:559,t:1527614214842};\\\", \\\"{x:621,y:565,t:1527614214860};\\\", \\\"{x:633,y:570,t:1527614214877};\\\", \\\"{x:647,y:576,t:1527614214893};\\\", \\\"{x:655,y:580,t:1527614214910};\\\", \\\"{x:665,y:583,t:1527614214927};\\\", \\\"{x:674,y:583,t:1527614214943};\\\", \\\"{x:694,y:586,t:1527614214959};\\\", \\\"{x:731,y:592,t:1527614214977};\\\", \\\"{x:779,y:593,t:1527614214994};\\\", \\\"{x:806,y:593,t:1527614215009};\\\", \\\"{x:820,y:593,t:1527614215026};\\\", \\\"{x:834,y:593,t:1527614215044};\\\", \\\"{x:841,y:593,t:1527614215060};\\\", \\\"{x:847,y:593,t:1527614215076};\\\", \\\"{x:849,y:593,t:1527614215094};\\\", \\\"{x:850,y:592,t:1527614215110};\\\", \\\"{x:850,y:591,t:1527614215153};\\\", \\\"{x:851,y:591,t:1527614215186};\\\", \\\"{x:851,y:590,t:1527614215281};\\\", \\\"{x:851,y:589,t:1527614215297};\\\", \\\"{x:851,y:588,t:1527614215310};\\\", \\\"{x:851,y:584,t:1527614215326};\\\", \\\"{x:849,y:580,t:1527614215344};\\\", \\\"{x:847,y:577,t:1527614215361};\\\", \\\"{x:847,y:576,t:1527614215377};\\\", \\\"{x:843,y:571,t:1527614215394};\\\", \\\"{x:840,y:567,t:1527614215411};\\\", \\\"{x:839,y:565,t:1527614215427};\\\", \\\"{x:837,y:563,t:1527614215444};\\\", \\\"{x:837,y:562,t:1527614215482};\\\", \\\"{x:837,y:561,t:1527614215494};\\\", \\\"{x:836,y:560,t:1527614215510};\\\", \\\"{x:835,y:560,t:1527614215527};\\\", \\\"{x:834,y:558,t:1527614215544};\\\", \\\"{x:832,y:556,t:1527614215561};\\\", \\\"{x:831,y:556,t:1527614215576};\\\", \\\"{x:828,y:555,t:1527614215853};\\\", \\\"{x:816,y:557,t:1527614215865};\\\", \\\"{x:774,y:576,t:1527614215881};\\\", \\\"{x:721,y:612,t:1527614215898};\\\", \\\"{x:674,y:643,t:1527614215916};\\\", \\\"{x:625,y:669,t:1527614215932};\\\", \\\"{x:588,y:699,t:1527614215947};\\\", \\\"{x:567,y:711,t:1527614215965};\\\", \\\"{x:546,y:727,t:1527614215981};\\\", \\\"{x:536,y:740,t:1527614215998};\\\", \\\"{x:527,y:751,t:1527614216014};\\\", \\\"{x:518,y:762,t:1527614216031};\\\", \\\"{x:515,y:769,t:1527614216048};\\\", \\\"{x:514,y:770,t:1527614216065};\\\", \\\"{x:514,y:771,t:1527614216082};\\\", \\\"{x:514,y:772,t:1527614216133};\\\", \\\"{x:514,y:767,t:1527614216238};\\\", \\\"{x:518,y:762,t:1527614216248};\\\", \\\"{x:523,y:754,t:1527614216265};\\\", \\\"{x:525,y:750,t:1527614216282};\\\", \\\"{x:527,y:747,t:1527614216299};\\\", \\\"{x:527,y:746,t:1527614216317};\\\", \\\"{x:527,y:745,t:1527614216333};\\\", \\\"{x:526,y:745,t:1527614216997};\\\", \\\"{x:526,y:747,t:1527614217005};\\\", \\\"{x:525,y:748,t:1527614217016};\\\", \\\"{x:523,y:750,t:1527614217031};\\\", \\\"{x:522,y:751,t:1527614217048};\\\", \\\"{x:520,y:754,t:1527614217065};\\\", \\\"{x:519,y:756,t:1527614217081};\\\", \\\"{x:517,y:759,t:1527614217098};\\\", \\\"{x:514,y:763,t:1527614217115};\\\", \\\"{x:510,y:771,t:1527614217131};\\\", \\\"{x:508,y:777,t:1527614217148};\\\", \\\"{x:503,y:791,t:1527614217165};\\\", \\\"{x:503,y:800,t:1527614217183};\\\", \\\"{x:503,y:809,t:1527614217198};\\\", \\\"{x:499,y:817,t:1527614217215};\\\", \\\"{x:498,y:823,t:1527614217233};\\\", \\\"{x:497,y:829,t:1527614217249};\\\", \\\"{x:496,y:835,t:1527614217265};\\\", \\\"{x:495,y:839,t:1527614217283};\\\", \\\"{x:494,y:844,t:1527614217298};\\\", \\\"{x:492,y:847,t:1527614217315};\\\", \\\"{x:489,y:851,t:1527614217332};\\\", \\\"{x:488,y:852,t:1527614217348};\\\", \\\"{x:486,y:855,t:1527614217365};\\\", \\\"{x:485,y:855,t:1527614217382};\\\", \\\"{x:483,y:857,t:1527614217398};\\\", \\\"{x:482,y:857,t:1527614217421};\\\", \\\"{x:482,y:858,t:1527614217432};\\\", \\\"{x:480,y:858,t:1527614217448};\\\", \\\"{x:478,y:859,t:1527614217466};\\\", \\\"{x:476,y:860,t:1527614217482};\\\", \\\"{x:475,y:861,t:1527614217509};\\\", \\\"{x:475,y:862,t:1527614217524};\\\", \\\"{x:475,y:863,t:1527614217549};\\\", \\\"{x:475,y:864,t:1527614217565};\\\" ] }, { \\\"rt\\\": 38539, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 580947, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"if the dot is directly above the 12PM mark\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10451, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 592401, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 17499, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 610910, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 17255, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 629483, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"1FK1X\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"1FK1X\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 92, dom: 670, initialDom: 754",
  "javascriptErrors": []
}