var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a8296d48112c723fa1a29ec2b69a0e81",
  "created": "2018-05-15T17:00:51.7128359-07:00",
  "lastActivity": "2018-05-15T17:02:47.9391823-07:00",
  "pageViews": [
    {
      "id": "0515514247d86d0362952905c9e5475a0d4bde24",
      "startTime": "2018-05-15T17:00:51.7128359-07:00",
      "endTime": "2018-05-15T17:02:47.9391823-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 116532,
      "engagementTime": 33853,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 116532,
  "engagementTime": 33853,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "f40982f9fb2d4f7f55c95beaaccee942",
  "gdpr": false
}