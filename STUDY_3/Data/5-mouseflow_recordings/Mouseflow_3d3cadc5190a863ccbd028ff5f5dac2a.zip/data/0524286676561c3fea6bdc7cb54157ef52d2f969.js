var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0524286676561c3fea6bdc7cb54157ef52d2f969"] = {
  "startTime": "2018-05-24T19:22:29.0884952Z",
  "websitePageUrl": "/16",
  "visitTime": 209492,
  "engagementTime": 159552,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "3d3cadc5190a863ccbd028ff5f5dac2a",
    "created": "2018-05-24T19:22:28.8652115+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=NVGH4",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "21ce685fe53de5a339bd26cf494220ab",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/3d3cadc5190a863ccbd028ff5f5dac2a/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 6595,
      "e": 5101,
      "ty": 6,
      "x": 399,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6600,
      "e": 5106,
      "ty": 2,
      "x": 399,
      "y": 591
    },
    {
      "t": 6701,
      "e": 5207,
      "ty": 2,
      "x": 271,
      "y": 523
    },
    {
      "t": 6712,
      "e": 5218,
      "ty": 7,
      "x": 274,
      "y": 520,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6751,
      "e": 5257,
      "ty": 41,
      "x": 20223,
      "y": 49772,
      "ta": "#.strategy > p"
    },
    {
      "t": 6801,
      "e": 5307,
      "ty": 2,
      "x": 277,
      "y": 516
    },
    {
      "t": 6863,
      "e": 5369,
      "ty": 6,
      "x": 277,
      "y": 535,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6901,
      "e": 5407,
      "ty": 2,
      "x": 284,
      "y": 563
    },
    {
      "t": 7001,
      "e": 5507,
      "ty": 2,
      "x": 287,
      "y": 565
    },
    {
      "t": 7001,
      "e": 5507,
      "ty": 41,
      "x": 21347,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7184,
      "e": 5690,
      "ty": 3,
      "x": 287,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7185,
      "e": 5691,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7310,
      "e": 5816,
      "ty": 4,
      "x": 21347,
      "y": 34196,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7310,
      "e": 5816,
      "ty": 5,
      "x": 287,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7701,
      "e": 6207,
      "ty": 2,
      "x": 314,
      "y": 569
    },
    {
      "t": 7751,
      "e": 6257,
      "ty": 41,
      "x": 24382,
      "y": 37432,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10004,
      "e": 8510,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40511,
      "e": 11257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 40701,
      "e": 11447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40702,
      "e": 11448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40805,
      "e": 11551,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 40812,
      "e": 11558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 40836,
      "e": 11582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 44701,
      "e": 15447,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 44702,
      "e": 15448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44797,
      "e": 15543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Th"
    },
    {
      "t": 44852,
      "e": 15598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44853,
      "e": 15599,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44957,
      "e": 15703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The"
    },
    {
      "t": 45069,
      "e": 15815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45070,
      "e": 15816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45180,
      "e": 15926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 45284,
      "e": 16030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 45284,
      "e": 16030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45372,
      "e": 16118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 45445,
      "e": 16191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 45445,
      "e": 16191,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45542,
      "e": 16288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 45638,
      "e": 16384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45638,
      "e": 16384,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45724,
      "e": 16470,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 45788,
      "e": 16534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45789,
      "e": 16535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45868,
      "e": 16614,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47357,
      "e": 18103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47358,
      "e": 18104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47396,
      "e": 18142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 47493,
      "e": 18239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 47493,
      "e": 18239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47565,
      "e": 18311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 47789,
      "e": 18535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 47790,
      "e": 18536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47877,
      "e": 18623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 47917,
      "e": 18663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 47917,
      "e": 18663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47940,
      "e": 18686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 48213,
      "e": 18959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48214,
      "e": 18960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48300,
      "e": 19046,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48373,
      "e": 19119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 48373,
      "e": 19119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48461,
      "e": 19207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 48494,
      "e": 19240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48494,
      "e": 19240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48556,
      "e": 19302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49789,
      "e": 20535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49853,
      "e": 20599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The dot that a"
    },
    {
      "t": 49956,
      "e": 20702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 49997,
      "e": 20743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The dot that "
    },
    {
      "t": 50004,
      "e": 20750,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 54606,
      "e": 25352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54607,
      "e": 25353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54668,
      "e": 25414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 54805,
      "e": 25551,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The dot that t"
    },
    {
      "t": 54845,
      "e": 25591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 54846,
      "e": 25592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54916,
      "e": 25662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 55006,
      "e": 25752,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 55006,
      "e": 25752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55093,
      "e": 25839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 55108,
      "e": 25854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 55109,
      "e": 25855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55188,
      "e": 25934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55590,
      "e": 26336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 55590,
      "e": 26336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55661,
      "e": 26407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 55821,
      "e": 26567,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 55821,
      "e": 26567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55916,
      "e": 26662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 56054,
      "e": 26800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56055,
      "e": 26801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56116,
      "e": 26862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 56180,
      "e": 26926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 56181,
      "e": 26927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56253,
      "e": 26999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 56293,
      "e": 27039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56294,
      "e": 27040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56372,
      "e": 27118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56677,
      "e": 27423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 56678,
      "e": 27424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56764,
      "e": 27510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 56805,
      "e": 27551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 56805,
      "e": 27551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56893,
      "e": 27639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 57005,
      "e": 27751,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The dot that the line wi"
    },
    {
      "t": 57038,
      "e": 27784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57038,
      "e": 27784,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57125,
      "e": 27871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57141,
      "e": 27887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 57141,
      "e": 27887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57237,
      "e": 27983,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 57365,
      "e": 28111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57365,
      "e": 28111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57444,
      "e": 28190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57485,
      "e": 28231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57485,
      "e": 28231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57565,
      "e": 28311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 57589,
      "e": 28335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 57590,
      "e": 28336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57668,
      "e": 28414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 57741,
      "e": 28487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 57741,
      "e": 28487,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57821,
      "e": 28567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 57869,
      "e": 28615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57870,
      "e": 28616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57948,
      "e": 28694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58606,
      "e": 29352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 58607,
      "e": 29353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58677,
      "e": 29423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 58805,
      "e": 29551,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The dot that the line with the p"
    },
    {
      "t": 58806,
      "e": 29552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 58806,
      "e": 29552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58869,
      "e": 29615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 58989,
      "e": 29735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 58989,
      "e": 29735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59061,
      "e": 29807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 59149,
      "e": 29895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 59150,
      "e": 29896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59236,
      "e": 29982,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 59301,
      "e": 30047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59301,
      "e": 30047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59397,
      "e": 30143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 59421,
      "e": 30167,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 59422,
      "e": 30168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59500,
      "e": 30246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 59605,
      "e": 30351,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The dot that the line with the positi"
    },
    {
      "t": 59813,
      "e": 30559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 59814,
      "e": 30560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59860,
      "e": 30606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 59956,
      "e": 30702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 59957,
      "e": 30703,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60003,
      "e": 30749,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60028,
      "e": 30774,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 60508,
      "e": 31254,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "191"
    },
    {
      "t": 60508,
      "e": 31254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60580,
      "e": 31326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||/"
    },
    {
      "t": 60877,
      "e": 31623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 60878,
      "e": 31624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60956,
      "e": 31702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 61068,
      "e": 31814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 61070,
      "e": 31816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61157,
      "e": 31903,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 61310,
      "e": 32056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 61310,
      "e": 32056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61364,
      "e": 32110,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 61493,
      "e": 32239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 61493,
      "e": 32239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61565,
      "e": 32311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 61709,
      "e": 32455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 61710,
      "e": 32456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61789,
      "e": 32535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 62046,
      "e": 32792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 62046,
      "e": 32792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62164,
      "e": 32910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 62173,
      "e": 32919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 62173,
      "e": 32919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62261,
      "e": 33007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 62309,
      "e": 33055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 62310,
      "e": 33056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62413,
      "e": 33159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 62533,
      "e": 33279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 62533,
      "e": 33279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62596,
      "e": 33342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 62620,
      "e": 33366,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 62620,
      "e": 33366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62700,
      "e": 33446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 62733,
      "e": 33479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62734,
      "e": 33480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62812,
      "e": 33558,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 62949,
      "e": 33695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 62950,
      "e": 33696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63053,
      "e": 33799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 63054,
      "e": 33800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63060,
      "e": 33806,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sl"
    },
    {
      "t": 63132,
      "e": 33878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63269,
      "e": 34015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 63269,
      "e": 34015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63340,
      "e": 34086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 63388,
      "e": 34134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 63389,
      "e": 34135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63485,
      "e": 34231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 63533,
      "e": 34279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63534,
      "e": 34280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63636,
      "e": 34382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 63660,
      "e": 34406,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63661,
      "e": 34407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63741,
      "e": 34487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70006,
      "e": 39487,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 74879,
      "e": 39487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 74880,
      "e": 39488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74960,
      "e": 39568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 75048,
      "e": 39656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 75049,
      "e": 39657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75127,
      "e": 39735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 75296,
      "e": 39904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 75296,
      "e": 39904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75351,
      "e": 39959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 75448,
      "e": 40056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 75448,
      "e": 40056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75520,
      "e": 40128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 75656,
      "e": 40264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 75656,
      "e": 40264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75735,
      "e": 40343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 75888,
      "e": 40496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 75889,
      "e": 40497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75967,
      "e": 40575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 76040,
      "e": 40648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76041,
      "e": 40649,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76143,
      "e": 40751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 76352,
      "e": 40960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 76352,
      "e": 40960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76463,
      "e": 41071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 76479,
      "e": 41087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 76480,
      "e": 41088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76559,
      "e": 41167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 76631,
      "e": 41239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 76631,
      "e": 41239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76711,
      "e": 41319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 76784,
      "e": 41392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 76784,
      "e": 41392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76855,
      "e": 41463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 77009,
      "e": 41617,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 77010,
      "e": 41618,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77080,
      "e": 41688,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 77120,
      "e": 41728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 77120,
      "e": 41728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77199,
      "e": 41807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 77208,
      "e": 41816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 77208,
      "e": 41816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77279,
      "e": 41887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 77408,
      "e": 42016,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The dot that the line with the positive/increasing slope passes through"
    },
    {
      "t": 77439,
      "e": 42047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77439,
      "e": 42047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77527,
      "e": 42135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 77623,
      "e": 42231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 77624,
      "e": 42232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77735,
      "e": 42343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 77792,
      "e": 42400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 77793,
      "e": 42401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 77863,
      "e": 42471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 77911,
      "e": 42519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 77911,
      "e": 42519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78009,
      "e": 42617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 78063,
      "e": 42671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 78064,
      "e": 42672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78144,
      "e": 42752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 78376,
      "e": 42984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 78376,
      "e": 42984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78447,
      "e": 43055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 78504,
      "e": 43112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 78504,
      "e": 43112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78575,
      "e": 43183,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 78599,
      "e": 43207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 78600,
      "e": 43208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78688,
      "e": 43296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 78810,
      "e": 43418,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 78810,
      "e": 43418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78871,
      "e": 43479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 79008,
      "e": 43616,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The dot that the line with the positive/increasing slope passes through and begi"
    },
    {
      "t": 79033,
      "e": 43641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 79033,
      "e": 43641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79072,
      "e": 43680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 79104,
      "e": 43712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 79104,
      "e": 43712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79199,
      "e": 43807,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 79336,
      "e": 43944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 79338,
      "e": 43946,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 79423,
      "e": 44031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 79728,
      "e": 44336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79775,
      "e": 44383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The dot that the line with the positive/increasing slope passes through and beging"
    },
    {
      "t": 79879,
      "e": 44487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 79895,
      "e": 44503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The dot that the line with the positive/increasing slope passes through and begin"
    },
    {
      "t": 80006,
      "e": 44614,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80010,
      "e": 44618,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The dot that the line with the positive/increasing slope passes through and begin"
    },
    {
      "t": 80504,
      "e": 45112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 80505,
      "e": 45113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80592,
      "e": 45200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 80768,
      "e": 45376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80769,
      "e": 45377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80847,
      "e": 45455,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 81016,
      "e": 45624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 81017,
      "e": 45625,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81127,
      "e": 45735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 81496,
      "e": 46104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 81497,
      "e": 46105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81567,
      "e": 46175,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 81888,
      "e": 46496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 81889,
      "e": 46497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81967,
      "e": 46575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 83306,
      "e": 47914,
      "ty": 2,
      "x": 314,
      "y": 570
    },
    {
      "t": 83407,
      "e": 48015,
      "ty": 2,
      "x": 312,
      "y": 578
    },
    {
      "t": 83506,
      "e": 48114,
      "ty": 2,
      "x": 230,
      "y": 583
    },
    {
      "t": 83507,
      "e": 48115,
      "ty": 41,
      "x": 14939,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83606,
      "e": 48214,
      "ty": 2,
      "x": 188,
      "y": 583
    },
    {
      "t": 83757,
      "e": 48365,
      "ty": 41,
      "x": 10331,
      "y": 44713,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83806,
      "e": 48414,
      "ty": 2,
      "x": 199,
      "y": 558
    },
    {
      "t": 83906,
      "e": 48514,
      "ty": 2,
      "x": 200,
      "y": 557
    },
    {
      "t": 83964,
      "e": 48572,
      "ty": 3,
      "x": 200,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84007,
      "e": 48615,
      "ty": 41,
      "x": 11567,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84207,
      "e": 48815,
      "ty": 2,
      "x": 177,
      "y": 562
    },
    {
      "t": 84257,
      "e": 48865,
      "ty": 41,
      "x": 6846,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84307,
      "e": 48915,
      "ty": 2,
      "x": 156,
      "y": 564
    },
    {
      "t": 84406,
      "e": 49014,
      "ty": 2,
      "x": 149,
      "y": 564
    },
    {
      "t": 84507,
      "e": 49115,
      "ty": 2,
      "x": 123,
      "y": 564
    },
    {
      "t": 84507,
      "e": 49115,
      "ty": 41,
      "x": 2912,
      "y": 33386,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84607,
      "e": 49215,
      "ty": 2,
      "x": 113,
      "y": 565
    },
    {
      "t": 84706,
      "e": 49314,
      "ty": 2,
      "x": 102,
      "y": 570
    },
    {
      "t": 84757,
      "e": 49365,
      "ty": 41,
      "x": 214,
      "y": 38241,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84807,
      "e": 49415,
      "ty": 2,
      "x": 97,
      "y": 570
    },
    {
      "t": 84815,
      "e": 49423,
      "ty": 7,
      "x": 96,
      "y": 569,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84906,
      "e": 49514,
      "ty": 2,
      "x": 82,
      "y": 563
    },
    {
      "t": 85006,
      "e": 49614,
      "ty": 2,
      "x": 77,
      "y": 560
    },
    {
      "t": 85007,
      "e": 49615,
      "ty": 41,
      "x": 2376,
      "y": 30579,
      "ta": "> div.stimulus"
    },
    {
      "t": 85107,
      "e": 49715,
      "ty": 2,
      "x": 75,
      "y": 558
    },
    {
      "t": 85207,
      "e": 49815,
      "ty": 2,
      "x": 73,
      "y": 548
    },
    {
      "t": 85257,
      "e": 49865,
      "ty": 41,
      "x": 2238,
      "y": 29748,
      "ta": "> div.stimulus"
    },
    {
      "t": 85307,
      "e": 49915,
      "ty": 2,
      "x": 72,
      "y": 541
    },
    {
      "t": 85407,
      "e": 50015,
      "ty": 2,
      "x": 72,
      "y": 534
    },
    {
      "t": 85506,
      "e": 50114,
      "ty": 2,
      "x": 72,
      "y": 530
    },
    {
      "t": 85506,
      "e": 50114,
      "ty": 41,
      "x": 2204,
      "y": 28917,
      "ta": "> div.stimulus"
    },
    {
      "t": 85636,
      "e": 50244,
      "ty": 4,
      "x": 2204,
      "y": 28917,
      "ta": "> div.stimulus"
    },
    {
      "t": 86529,
      "e": 51137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 86824,
      "e": 51432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 87088,
      "e": 51696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 87587,
      "e": 52195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 87607,
      "e": 52215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 87607,
      "e": 52215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87695,
      "e": 52303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "A"
    },
    {
      "t": 87695,
      "e": 52303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "A"
    },
    {
      "t": 87936,
      "e": 52544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 87936,
      "e": 52544,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87998,
      "e": 52606,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "An"
    },
    {
      "t": 88192,
      "e": 52800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 88193,
      "e": 52801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88271,
      "e": 52879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any"
    },
    {
      "t": 88704,
      "e": 53312,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 88704,
      "e": 53312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88767,
      "e": 53375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any "
    },
    {
      "t": 89728,
      "e": 54336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 89776,
      "e": 54384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any"
    },
    {
      "t": 89880,
      "e": 54488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 89928,
      "e": 54536,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "An"
    },
    {
      "t": 90006,
      "e": 54614,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90015,
      "e": 54623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90071,
      "e": 54679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "A"
    },
    {
      "t": 90159,
      "e": 54767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 90231,
      "e": 54839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 94239,
      "e": 58847,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 94409,
      "e": 59017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 94409,
      "e": 59017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94471,
      "e": 59079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "A"
    },
    {
      "t": 94495,
      "e": 59103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "A"
    },
    {
      "t": 94608,
      "e": 59216,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "A"
    },
    {
      "t": 94656,
      "e": 59264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 94656,
      "e": 59264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94711,
      "e": 59319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "An"
    },
    {
      "t": 94856,
      "e": 59464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 94856,
      "e": 59464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 94936,
      "e": 59544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any"
    },
    {
      "t": 95095,
      "e": 59703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 95096,
      "e": 59704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95168,
      "e": 59776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any "
    },
    {
      "t": 95247,
      "e": 59855,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 95248,
      "e": 59856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95327,
      "e": 59935,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 95375,
      "e": 59983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 95377,
      "e": 59985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95463,
      "e": 60071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 95568,
      "e": 60176,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 95568,
      "e": 60176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95695,
      "e": 60303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 95727,
      "e": 60335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 95727,
      "e": 60335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 95832,
      "e": 60440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 96432,
      "e": 61040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 96432,
      "e": 61040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96511,
      "e": 61119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 96536,
      "e": 61144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 96537,
      "e": 61145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96623,
      "e": 61231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 96791,
      "e": 61399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 96793,
      "e": 61401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96888,
      "e": 61496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 96896,
      "e": 61504,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 96896,
      "e": 61504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 96951,
      "e": 61559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 97207,
      "e": 61815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 97207,
      "e": 61815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 97271,
      "e": 61879,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 100006,
      "e": 64614,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 102615,
      "e": 66879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 102616,
      "e": 66880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102687,
      "e": 66951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 102752,
      "e": 67016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 102752,
      "e": 67016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102838,
      "e": 67102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 102911,
      "e": 67175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 102912,
      "e": 67176,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103039,
      "e": 67303,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 103064,
      "e": 67328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 103065,
      "e": 67329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103159,
      "e": 67423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 103680,
      "e": 67944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 103680,
      "e": 67944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 103791,
      "e": 68055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 104064,
      "e": 68328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 104065,
      "e": 68329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104175,
      "e": 68439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 104335,
      "e": 68599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 104337,
      "e": 68601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104438,
      "e": 68702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 104471,
      "e": 68735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 104471,
      "e": 68735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104583,
      "e": 68847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 104615,
      "e": 68879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 104616,
      "e": 68880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 104710,
      "e": 68974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 107337,
      "e": 71601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 107337,
      "e": 71601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107416,
      "e": 71680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 107455,
      "e": 71719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 107456,
      "e": 71720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107535,
      "e": 71799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 107848,
      "e": 72112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 107848,
      "e": 72112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107928,
      "e": 72192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 107929,
      "e": 72193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 107935,
      "e": 72199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gi"
    },
    {
      "t": 108030,
      "e": 72294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 108207,
      "e": 72471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 108208,
      "e": 72472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108263,
      "e": 72527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 108351,
      "e": 72615,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 108352,
      "e": 72616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108422,
      "e": 72686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 108551,
      "e": 72815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 108552,
      "e": 72816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 108616,
      "e": 72880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 109456,
      "e": 73720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 109456,
      "e": 73720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 109535,
      "e": 73799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 110006,
      "e": 74270,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110680,
      "e": 74944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110808,
      "e": 75072,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any dot that the line beginni"
    },
    {
      "t": 111178,
      "e": 75442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111212,
      "e": 75476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111244,
      "e": 75508,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111277,
      "e": 75541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111310,
      "e": 75574,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111343,
      "e": 75607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111375,
      "e": 75639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111409,
      "e": 75673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111442,
      "e": 75706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111475,
      "e": 75739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111508,
      "e": 75772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111542,
      "e": 75806,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111551,
      "e": 75815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any dot that the "
    },
    {
      "t": 113096,
      "e": 77360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 113096,
      "e": 77360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113199,
      "e": 77463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 113215,
      "e": 77479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 113215,
      "e": 77479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113287,
      "e": 77551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 113410,
      "e": 77674,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any dot that the di"
    },
    {
      "t": 113424,
      "e": 77688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 113424,
      "e": 77688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113487,
      "e": 77751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 113488,
      "e": 77752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113519,
      "e": 77783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ag"
    },
    {
      "t": 113559,
      "e": 77823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 113968,
      "e": 78232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 113968,
      "e": 78232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114031,
      "e": 78295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 114175,
      "e": 78439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 114176,
      "e": 78440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114231,
      "e": 78495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 114343,
      "e": 78607,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 114343,
      "e": 78607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114407,
      "e": 78671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 114407,
      "e": 78671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114415,
      "e": 78679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 114495,
      "e": 78759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 114623,
      "e": 78887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 114624,
      "e": 78888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114695,
      "e": 78959,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 114808,
      "e": 79072,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any dot that the diagonal "
    },
    {
      "t": 114864,
      "e": 79128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 114864,
      "e": 79128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114934,
      "e": 79198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 115072,
      "e": 79336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 115072,
      "e": 79336,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115143,
      "e": 79407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 115287,
      "e": 79551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 115288,
      "e": 79552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115360,
      "e": 79624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 115423,
      "e": 79687,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 115424,
      "e": 79688,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115487,
      "e": 79751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 115527,
      "e": 79791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 115527,
      "e": 79791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115574,
      "e": 79838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 115664,
      "e": 79928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 115664,
      "e": 79928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115727,
      "e": 79991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 115751,
      "e": 80015,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 115752,
      "e": 80016,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115816,
      "e": 80080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 115951,
      "e": 80215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 115953,
      "e": 80217,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116047,
      "e": 80311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 116071,
      "e": 80335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 116071,
      "e": 80335,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116151,
      "e": 80415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 116311,
      "e": 80575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 116315,
      "e": 80579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116383,
      "e": 80647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 117023,
      "e": 81287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 117024,
      "e": 81288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117087,
      "e": 81351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 117209,
      "e": 81473,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any dot that the diagonal line with p"
    },
    {
      "t": 117239,
      "e": 81503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 117240,
      "e": 81504,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117312,
      "e": 81576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 117416,
      "e": 81680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 117417,
      "e": 81681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117464,
      "e": 81728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 117537,
      "e": 81801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 117537,
      "e": 81801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117631,
      "e": 81895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 117695,
      "e": 81959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 117695,
      "e": 81959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117799,
      "e": 82063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 117815,
      "e": 82079,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 117816,
      "e": 82080,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117895,
      "e": 82159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 118008,
      "e": 82272,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any dot that the diagonal line with positi"
    },
    {
      "t": 118103,
      "e": 82367,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 118105,
      "e": 82369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118167,
      "e": 82431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 118231,
      "e": 82495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 118231,
      "e": 82495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118295,
      "e": 82559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 118408,
      "e": 82672,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any dot that the diagonal line with positive"
    },
    {
      "t": 119272,
      "e": 83536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "191"
    },
    {
      "t": 119272,
      "e": 83536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119327,
      "e": 83537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||/"
    },
    {
      "t": 119639,
      "e": 83849,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 119640,
      "e": 83850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119711,
      "e": 83921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 119839,
      "e": 84049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 119839,
      "e": 84049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119920,
      "e": 84130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 120120,
      "e": 84330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 120120,
      "e": 84330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120199,
      "e": 84409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 120303,
      "e": 84513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 120303,
      "e": 84513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120383,
      "e": 84593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 120519,
      "e": 84729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 120520,
      "e": 84730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120583,
      "e": 84793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 120647,
      "e": 84857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 120648,
      "e": 84858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120719,
      "e": 84929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 120767,
      "e": 84977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 120767,
      "e": 84977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120847,
      "e": 85057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 121120,
      "e": 85330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 121120,
      "e": 85330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121207,
      "e": 85417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 121344,
      "e": 85554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 121344,
      "e": 85554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121422,
      "e": 85632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 121455,
      "e": 85665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 121455,
      "e": 85665,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121551,
      "e": 85761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 121568,
      "e": 85778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 121569,
      "e": 85779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 121647,
      "e": 85857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 121927,
      "e": 86137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 121928,
      "e": 86138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122007,
      "e": 86217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 122030,
      "e": 86240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 122030,
      "e": 86240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122103,
      "e": 86313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 122208,
      "e": 86418,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any dot that the diagonal line with positive/increasing sl"
    },
    {
      "t": 122255,
      "e": 86465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 122256,
      "e": 86466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122335,
      "e": 86545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 122367,
      "e": 86577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 122367,
      "e": 86577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122463,
      "e": 86673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 122496,
      "e": 86706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 122496,
      "e": 86706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122599,
      "e": 86809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 122663,
      "e": 86873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 122664,
      "e": 86874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 122743,
      "e": 86953,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 126544,
      "e": 90754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 126544,
      "e": 90754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126623,
      "e": 90833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 126679,
      "e": 90889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 126679,
      "e": 90889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126774,
      "e": 90984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 126815,
      "e": 91025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 126815,
      "e": 91025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126888,
      "e": 91098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 127009,
      "e": 91219,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any dot that the diagonal line with positive/increasing slope beg"
    },
    {
      "t": 127064,
      "e": 91274,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 127064,
      "e": 91274,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127152,
      "e": 91362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 127336,
      "e": 91546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 127337,
      "e": 91547,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127383,
      "e": 91593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 127472,
      "e": 91682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 127472,
      "e": 91682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127527,
      "e": 91737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 127631,
      "e": 91841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 127632,
      "e": 91842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127711,
      "e": 91921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 127800,
      "e": 92010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 127800,
      "e": 92010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127879,
      "e": 92089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 127895,
      "e": 92105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 127895,
      "e": 92105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 127999,
      "e": 92209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 128032,
      "e": 92242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 128032,
      "e": 92242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 128111,
      "e": 92321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 129946,
      "e": 94156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 129948,
      "e": 94158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130009,
      "e": 94219,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130017,
      "e": 94227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 130050,
      "e": 94260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 130050,
      "e": 94260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130114,
      "e": 94324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 130450,
      "e": 94660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 130450,
      "e": 94660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 130515,
      "e": 94725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 131987,
      "e": 96197,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 131987,
      "e": 96197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132026,
      "e": 96236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 132058,
      "e": 96268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 132059,
      "e": 96269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132146,
      "e": 96356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 132858,
      "e": 97068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 132860,
      "e": 97070,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 132938,
      "e": 97148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 133098,
      "e": 97308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 133099,
      "e": 97309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133162,
      "e": 97372,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 133266,
      "e": 97476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 133267,
      "e": 97477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133346,
      "e": 97556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 133619,
      "e": 97829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 133619,
      "e": 97829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133705,
      "e": 97915,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 133770,
      "e": 97980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 133770,
      "e": 97980,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 133858,
      "e": 98068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 134018,
      "e": 98228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 134019,
      "e": 98229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134089,
      "e": 98299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 134186,
      "e": 98396,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 134187,
      "e": 98397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134266,
      "e": 98476,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 134394,
      "e": 98604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 134395,
      "e": 98605,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134465,
      "e": 98675,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 134610,
      "e": 98820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 134612,
      "e": 98822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134690,
      "e": 98900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 134706,
      "e": 98916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 134706,
      "e": 98916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 134810,
      "e": 99020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 135283,
      "e": 99493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 135283,
      "e": 99493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135330,
      "e": 99540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 135330,
      "e": 99540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135354,
      "e": 99564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 135434,
      "e": 99644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 135498,
      "e": 99708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 135499,
      "e": 99709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135577,
      "e": 99787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 135594,
      "e": 99804,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 135594,
      "e": 99804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135674,
      "e": 99884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 135835,
      "e": 100045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 135835,
      "e": 100045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135921,
      "e": 100131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 135946,
      "e": 100156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 135946,
      "e": 100156,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136026,
      "e": 100236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 136026,
      "e": 100236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136042,
      "e": 100252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gh"
    },
    {
      "t": 136098,
      "e": 100308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 136212,
      "e": 100422,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any dot that the diagonal line with positive/increasing slope beginning at 12pm passes through"
    },
    {
      "t": 140010,
      "e": 104220,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 153891,
      "e": 105422,
      "ty": 6,
      "x": 109,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153907,
      "e": 105438,
      "ty": 7,
      "x": 127,
      "y": 625,
      "ta": "#strategyAnswer"
    },
    {
      "t": 153909,
      "e": 105440,
      "ty": 2,
      "x": 127,
      "y": 625
    },
    {
      "t": 154010,
      "e": 105541,
      "ty": 2,
      "x": 149,
      "y": 654
    },
    {
      "t": 154010,
      "e": 105541,
      "ty": 41,
      "x": 5834,
      "y": 35786,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 154110,
      "e": 105641,
      "ty": 2,
      "x": 255,
      "y": 714
    },
    {
      "t": 154210,
      "e": 105741,
      "ty": 2,
      "x": 267,
      "y": 710
    },
    {
      "t": 154261,
      "e": 105792,
      "ty": 41,
      "x": 19886,
      "y": 38667,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 154309,
      "e": 105840,
      "ty": 2,
      "x": 293,
      "y": 699
    },
    {
      "t": 154409,
      "e": 105940,
      "ty": 2,
      "x": 315,
      "y": 695
    },
    {
      "t": 154509,
      "e": 106040,
      "ty": 2,
      "x": 344,
      "y": 690
    },
    {
      "t": 154510,
      "e": 106041,
      "ty": 41,
      "x": 11892,
      "y": 44737,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 154542,
      "e": 106073,
      "ty": 6,
      "x": 354,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 154610,
      "e": 106141,
      "ty": 2,
      "x": 354,
      "y": 688
    },
    {
      "t": 154710,
      "e": 106241,
      "ty": 2,
      "x": 372,
      "y": 682
    },
    {
      "t": 154760,
      "e": 106291,
      "ty": 41,
      "x": 18790,
      "y": 50626,
      "ta": "#strategyButton"
    },
    {
      "t": 154809,
      "e": 106340,
      "ty": 2,
      "x": 374,
      "y": 679
    },
    {
      "t": 155010,
      "e": 106541,
      "ty": 41,
      "x": 19336,
      "y": 46771,
      "ta": "#strategyButton"
    },
    {
      "t": 155408,
      "e": 106939,
      "ty": 3,
      "x": 374,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 155409,
      "e": 106940,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Any dot that the diagonal line with positive/increasing slope beginning at 12pm passes through"
    },
    {
      "t": 155410,
      "e": 106941,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 155410,
      "e": 106941,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 155493,
      "e": 107024,
      "ty": 4,
      "x": 19336,
      "y": 46771,
      "ta": "#strategyButton"
    },
    {
      "t": 155505,
      "e": 107036,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 155506,
      "e": 107037,
      "ty": 5,
      "x": 374,
      "y": 679,
      "ta": "#strategyButton"
    },
    {
      "t": 155512,
      "e": 107043,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 156513,
      "e": 108044,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 157309,
      "e": 108840,
      "ty": 2,
      "x": 419,
      "y": 665
    },
    {
      "t": 157411,
      "e": 108942,
      "ty": 2,
      "x": 661,
      "y": 615
    },
    {
      "t": 157511,
      "e": 109042,
      "ty": 2,
      "x": 777,
      "y": 577
    },
    {
      "t": 157511,
      "e": 109042,
      "ty": 41,
      "x": 26482,
      "y": 31521,
      "ta": "html > body"
    },
    {
      "t": 157543,
      "e": 109074,
      "ty": 6,
      "x": 837,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 157610,
      "e": 109141,
      "ty": 2,
      "x": 954,
      "y": 560
    },
    {
      "t": 157627,
      "e": 109158,
      "ty": 7,
      "x": 994,
      "y": 549,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 157710,
      "e": 109241,
      "ty": 2,
      "x": 997,
      "y": 548
    },
    {
      "t": 157760,
      "e": 109291,
      "ty": 41,
      "x": 40878,
      "y": 40871,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 157810,
      "e": 109341,
      "ty": 2,
      "x": 995,
      "y": 548
    },
    {
      "t": 157827,
      "e": 109358,
      "ty": 6,
      "x": 982,
      "y": 555,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 157910,
      "e": 109441,
      "ty": 2,
      "x": 976,
      "y": 559
    },
    {
      "t": 158010,
      "e": 109541,
      "ty": 41,
      "x": 36336,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158070,
      "e": 109601,
      "ty": 3,
      "x": 976,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158072,
      "e": 109603,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158151,
      "e": 109682,
      "ty": 4,
      "x": 36336,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158151,
      "e": 109682,
      "ty": 5,
      "x": 976,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 158946,
      "e": 110477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 158947,
      "e": 110478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 159042,
      "e": 110573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 159363,
      "e": 110894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 159363,
      "e": 110894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 159489,
      "e": 111020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 160010,
      "e": 111541,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 160310,
      "e": 111841,
      "ty": 2,
      "x": 974,
      "y": 564
    },
    {
      "t": 160313,
      "e": 111844,
      "ty": 7,
      "x": 966,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 160396,
      "e": 111927,
      "ty": 6,
      "x": 938,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160411,
      "e": 111942,
      "ty": 2,
      "x": 938,
      "y": 647
    },
    {
      "t": 160510,
      "e": 112041,
      "ty": 2,
      "x": 920,
      "y": 666
    },
    {
      "t": 160510,
      "e": 112041,
      "ty": 41,
      "x": 24224,
      "y": 59293,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160513,
      "e": 112044,
      "ty": 7,
      "x": 912,
      "y": 671,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160546,
      "e": 112077,
      "ty": 6,
      "x": 898,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 160580,
      "e": 112111,
      "ty": 7,
      "x": 892,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 160610,
      "e": 112141,
      "ty": 2,
      "x": 889,
      "y": 679
    },
    {
      "t": 160710,
      "e": 112241,
      "ty": 2,
      "x": 820,
      "y": 674
    },
    {
      "t": 160760,
      "e": 112291,
      "ty": 41,
      "x": 1946,
      "y": 63420,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 160810,
      "e": 112341,
      "ty": 2,
      "x": 816,
      "y": 670
    },
    {
      "t": 160863,
      "e": 112394,
      "ty": 6,
      "x": 817,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 160910,
      "e": 112441,
      "ty": 2,
      "x": 820,
      "y": 662
    },
    {
      "t": 161010,
      "e": 112541,
      "ty": 2,
      "x": 825,
      "y": 656
    },
    {
      "t": 161011,
      "e": 112542,
      "ty": 41,
      "x": 3676,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161142,
      "e": 112673,
      "ty": 3,
      "x": 825,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161143,
      "e": 112674,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 161144,
      "e": 112675,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 161145,
      "e": 112676,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161237,
      "e": 112768,
      "ty": 4,
      "x": 3676,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 161237,
      "e": 112768,
      "ty": 5,
      "x": 825,
      "y": 656,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 162090,
      "e": 113621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162589,
      "e": 114120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162623,
      "e": 114154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162656,
      "e": 114187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162689,
      "e": 114220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162722,
      "e": 114253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162755,
      "e": 114286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162788,
      "e": 114319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162821,
      "e": 114352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162854,
      "e": 114385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162888,
      "e": 114419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162921,
      "e": 114452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162953,
      "e": 114484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 162987,
      "e": 114518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 163019,
      "e": 114550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 163034,
      "e": 114565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 163035,
      "e": 114566,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 163129,
      "e": 114660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 163154,
      "e": 114685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 163363,
      "e": 114894,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 163363,
      "e": 114894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 163426,
      "e": 114957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 163523,
      "e": 115054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 163523,
      "e": 115054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 163593,
      "e": 115124,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 163786,
      "e": 115317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 163787,
      "e": 115318,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 163866,
      "e": 115397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 164090,
      "e": 115621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 164091,
      "e": 115622,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 164211,
      "e": 115742,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unite"
    },
    {
      "t": 164218,
      "e": 115749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 164746,
      "e": 116277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 164843,
      "e": 116374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 165499,
      "e": 117030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 165500,
      "e": 117031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165562,
      "e": 117093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d"
    },
    {
      "t": 165746,
      "e": 117277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 165747,
      "e": 117278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 165817,
      "e": 117348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 166058,
      "e": 117589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 166170,
      "e": 117701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 166171,
      "e": 117702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 166210,
      "e": 117741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 166266,
      "e": 117797,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 166489,
      "e": 118020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 166490,
      "e": 118021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 166577,
      "e": 118108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 166738,
      "e": 118269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 166738,
      "e": 118269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 166809,
      "e": 118340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 166994,
      "e": 118525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 166997,
      "e": 118528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 167074,
      "e": 118605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 167266,
      "e": 118797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 167267,
      "e": 118798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 167346,
      "e": 118877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 167347,
      "e": 118878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 167354,
      "e": 118885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es"
    },
    {
      "t": 167450,
      "e": 118981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 168210,
      "e": 119741,
      "ty": 2,
      "x": 831,
      "y": 656
    },
    {
      "t": 168260,
      "e": 119791,
      "ty": 41,
      "x": 5623,
      "y": 28086,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168309,
      "e": 119840,
      "ty": 2,
      "x": 837,
      "y": 656
    },
    {
      "t": 168336,
      "e": 119867,
      "ty": 7,
      "x": 840,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168409,
      "e": 119940,
      "ty": 2,
      "x": 845,
      "y": 696
    },
    {
      "t": 168509,
      "e": 120040,
      "ty": 2,
      "x": 849,
      "y": 703
    },
    {
      "t": 168510,
      "e": 120041,
      "ty": 41,
      "x": 28962,
      "y": 38501,
      "ta": "html > body"
    },
    {
      "t": 168710,
      "e": 120241,
      "ty": 2,
      "x": 834,
      "y": 671
    },
    {
      "t": 168754,
      "e": 120285,
      "ty": 6,
      "x": 834,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168759,
      "e": 120290,
      "ty": 41,
      "x": 5623,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 168809,
      "e": 120340,
      "ty": 2,
      "x": 834,
      "y": 666
    },
    {
      "t": 169010,
      "e": 120541,
      "ty": 2,
      "x": 834,
      "y": 662
    },
    {
      "t": 169010,
      "e": 120541,
      "ty": 41,
      "x": 5623,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 169198,
      "e": 120729,
      "ty": 3,
      "x": 834,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 169334,
      "e": 120865,
      "ty": 4,
      "x": 5623,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 169335,
      "e": 120866,
      "ty": 5,
      "x": 834,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 169509,
      "e": 121040,
      "ty": 2,
      "x": 834,
      "y": 661
    },
    {
      "t": 169509,
      "e": 121040,
      "ty": 41,
      "x": 5623,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 169910,
      "e": 121441,
      "ty": 2,
      "x": 835,
      "y": 661
    },
    {
      "t": 170010,
      "e": 121541,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 170012,
      "e": 121543,
      "ty": 41,
      "x": 5839,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 170053,
      "e": 121584,
      "ty": 3,
      "x": 835,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 170165,
      "e": 121696,
      "ty": 4,
      "x": 5839,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 170166,
      "e": 121697,
      "ty": 5,
      "x": 835,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 170410,
      "e": 121941,
      "ty": 2,
      "x": 891,
      "y": 661
    },
    {
      "t": 170510,
      "e": 122041,
      "ty": 41,
      "x": 17951,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 170709,
      "e": 122240,
      "ty": 2,
      "x": 857,
      "y": 662
    },
    {
      "t": 170760,
      "e": 122291,
      "ty": 41,
      "x": 10598,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 170810,
      "e": 122341,
      "ty": 2,
      "x": 850,
      "y": 654
    },
    {
      "t": 170909,
      "e": 122440,
      "ty": 2,
      "x": 838,
      "y": 654
    },
    {
      "t": 171010,
      "e": 122541,
      "ty": 2,
      "x": 837,
      "y": 654
    },
    {
      "t": 171010,
      "e": 122541,
      "ty": 41,
      "x": 6272,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171191,
      "e": 122722,
      "ty": 3,
      "x": 837,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171294,
      "e": 122825,
      "ty": 4,
      "x": 6272,
      "y": 21845,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171294,
      "e": 122825,
      "ty": 5,
      "x": 837,
      "y": 654,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171410,
      "e": 122941,
      "ty": 2,
      "x": 829,
      "y": 657
    },
    {
      "t": 171510,
      "e": 123041,
      "ty": 2,
      "x": 824,
      "y": 660
    },
    {
      "t": 171511,
      "e": 123042,
      "ty": 41,
      "x": 3460,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171572,
      "e": 123103,
      "ty": 7,
      "x": 843,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 171610,
      "e": 123141,
      "ty": 2,
      "x": 846,
      "y": 670
    },
    {
      "t": 171759,
      "e": 123290,
      "ty": 41,
      "x": 8218,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 172162,
      "e": 123693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 172163,
      "e": 123694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 172225,
      "e": 123756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 172919,
      "e": 124450,
      "ty": 6,
      "x": 848,
      "y": 660,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 172957,
      "e": 124488,
      "ty": 7,
      "x": 855,
      "y": 645,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 173010,
      "e": 124541,
      "ty": 2,
      "x": 856,
      "y": 645
    },
    {
      "t": 173010,
      "e": 124541,
      "ty": 41,
      "x": 10381,
      "y": 43690,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 173167,
      "e": 124698,
      "ty": 6,
      "x": 856,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 173206,
      "e": 124737,
      "ty": 7,
      "x": 856,
      "y": 702,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 173210,
      "e": 124741,
      "ty": 2,
      "x": 856,
      "y": 702
    },
    {
      "t": 173260,
      "e": 124791,
      "ty": 41,
      "x": 29823,
      "y": 42655,
      "ta": "html > body"
    },
    {
      "t": 173309,
      "e": 124840,
      "ty": 2,
      "x": 903,
      "y": 837
    },
    {
      "t": 173410,
      "e": 124941,
      "ty": 2,
      "x": 955,
      "y": 891
    },
    {
      "t": 173510,
      "e": 125041,
      "ty": 2,
      "x": 959,
      "y": 896
    },
    {
      "t": 173510,
      "e": 125041,
      "ty": 41,
      "x": 32750,
      "y": 49192,
      "ta": "html > body"
    },
    {
      "t": 174209,
      "e": 125740,
      "ty": 2,
      "x": 958,
      "y": 898
    },
    {
      "t": 174260,
      "e": 125791,
      "ty": 41,
      "x": 32681,
      "y": 49248,
      "ta": "html > body"
    },
    {
      "t": 174309,
      "e": 125840,
      "ty": 2,
      "x": 953,
      "y": 896
    },
    {
      "t": 174410,
      "e": 125941,
      "ty": 2,
      "x": 928,
      "y": 837
    },
    {
      "t": 174491,
      "e": 126022,
      "ty": 6,
      "x": 928,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 174510,
      "e": 126041,
      "ty": 2,
      "x": 933,
      "y": 699
    },
    {
      "t": 174510,
      "e": 126041,
      "ty": 41,
      "x": 19109,
      "y": 45675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 174609,
      "e": 126140,
      "ty": 2,
      "x": 941,
      "y": 692
    },
    {
      "t": 174710,
      "e": 126241,
      "ty": 2,
      "x": 943,
      "y": 680
    },
    {
      "t": 174760,
      "e": 126291,
      "ty": 41,
      "x": 24263,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 175135,
      "e": 126666,
      "ty": 3,
      "x": 943,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 175135,
      "e": 126666,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 175137,
      "e": 126668,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 175137,
      "e": 126668,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 175213,
      "e": 126744,
      "ty": 4,
      "x": 24263,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 175214,
      "e": 126745,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 175214,
      "e": 126745,
      "ty": 5,
      "x": 943,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 175214,
      "e": 126745,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 176231,
      "e": 127762,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 177010,
      "e": 128541,
      "ty": 2,
      "x": 944,
      "y": 680
    },
    {
      "t": 177010,
      "e": 128541,
      "ty": 41,
      "x": 32912,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 177110,
      "e": 128641,
      "ty": 2,
      "x": 957,
      "y": 704
    },
    {
      "t": 177260,
      "e": 128791,
      "ty": 41,
      "x": 34163,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 177510,
      "e": 129041,
      "ty": 2,
      "x": 957,
      "y": 675
    },
    {
      "t": 177510,
      "e": 129041,
      "ty": 41,
      "x": 36402,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 177610,
      "e": 129141,
      "ty": 2,
      "x": 834,
      "y": 450
    },
    {
      "t": 177710,
      "e": 129241,
      "ty": 2,
      "x": 767,
      "y": 356
    },
    {
      "t": 177761,
      "e": 129292,
      "ty": 41,
      "x": 26413,
      "y": 17173,
      "ta": "html > body"
    },
    {
      "t": 177810,
      "e": 129341,
      "ty": 2,
      "x": 801,
      "y": 248
    },
    {
      "t": 177910,
      "e": 129441,
      "ty": 2,
      "x": 808,
      "y": 193
    },
    {
      "t": 178010,
      "e": 129541,
      "ty": 41,
      "x": 27550,
      "y": 10248,
      "ta": "html > body"
    },
    {
      "t": 178110,
      "e": 129641,
      "ty": 2,
      "x": 801,
      "y": 217
    },
    {
      "t": 178210,
      "e": 129741,
      "ty": 2,
      "x": 795,
      "y": 235
    },
    {
      "t": 178260,
      "e": 129791,
      "ty": 41,
      "x": 27102,
      "y": 12741,
      "ta": "html > body"
    },
    {
      "t": 178311,
      "e": 129842,
      "ty": 2,
      "x": 813,
      "y": 239
    },
    {
      "t": 178345,
      "e": 129876,
      "ty": 6,
      "x": 835,
      "y": 240,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 178360,
      "e": 129891,
      "ty": 7,
      "x": 846,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 178410,
      "e": 129941,
      "ty": 2,
      "x": 852,
      "y": 247
    },
    {
      "t": 178510,
      "e": 130041,
      "ty": 2,
      "x": 852,
      "y": 256
    },
    {
      "t": 178510,
      "e": 130041,
      "ty": 41,
      "x": 7256,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 178609,
      "e": 130140,
      "ty": 2,
      "x": 852,
      "y": 257
    },
    {
      "t": 178710,
      "e": 130241,
      "ty": 2,
      "x": 846,
      "y": 263
    },
    {
      "t": 178761,
      "e": 130292,
      "ty": 41,
      "x": 16434,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 178795,
      "e": 130326,
      "ty": 6,
      "x": 839,
      "y": 268,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 178810,
      "e": 130341,
      "ty": 2,
      "x": 839,
      "y": 268
    },
    {
      "t": 178910,
      "e": 130441,
      "ty": 2,
      "x": 833,
      "y": 270
    },
    {
      "t": 179011,
      "e": 130542,
      "ty": 41,
      "x": 33161,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 179510,
      "e": 131041,
      "ty": 2,
      "x": 834,
      "y": 265
    },
    {
      "t": 179510,
      "e": 131041,
      "ty": 41,
      "x": 38202,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 179610,
      "e": 131141,
      "ty": 2,
      "x": 835,
      "y": 263
    },
    {
      "t": 179760,
      "e": 131291,
      "ty": 41,
      "x": 43243,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 179910,
      "e": 131441,
      "ty": 2,
      "x": 834,
      "y": 264
    },
    {
      "t": 180010,
      "e": 131541,
      "ty": 2,
      "x": 832,
      "y": 267
    },
    {
      "t": 180011,
      "e": 131542,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 180120,
      "e": 131651,
      "ty": 3,
      "x": 832,
      "y": 267,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 180120,
      "e": 131651,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 180197,
      "e": 131728,
      "ty": 4,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 180197,
      "e": 131728,
      "ty": 5,
      "x": 832,
      "y": 267,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 180198,
      "e": 131729,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 181880,
      "e": 133411,
      "ty": 7,
      "x": 829,
      "y": 278,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 181897,
      "e": 133428,
      "ty": 6,
      "x": 826,
      "y": 288,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 181910,
      "e": 133441,
      "ty": 2,
      "x": 826,
      "y": 288
    },
    {
      "t": 181930,
      "e": 133461,
      "ty": 7,
      "x": 826,
      "y": 310,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 181946,
      "e": 133477,
      "ty": 6,
      "x": 826,
      "y": 323,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 181963,
      "e": 133494,
      "ty": 7,
      "x": 826,
      "y": 335,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 182010,
      "e": 133541,
      "ty": 2,
      "x": 830,
      "y": 354
    },
    {
      "t": 182010,
      "e": 133541,
      "ty": 41,
      "x": 2035,
      "y": 14422,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 182110,
      "e": 133641,
      "ty": 2,
      "x": 849,
      "y": 424
    },
    {
      "t": 182210,
      "e": 133741,
      "ty": 2,
      "x": 861,
      "y": 471
    },
    {
      "t": 182260,
      "e": 133791,
      "ty": 41,
      "x": 41834,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 182310,
      "e": 133841,
      "ty": 2,
      "x": 861,
      "y": 475
    },
    {
      "t": 182397,
      "e": 133928,
      "ty": 6,
      "x": 837,
      "y": 474,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 182410,
      "e": 133941,
      "ty": 2,
      "x": 837,
      "y": 474
    },
    {
      "t": 182446,
      "e": 133977,
      "ty": 7,
      "x": 831,
      "y": 461,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 182510,
      "e": 134041,
      "ty": 2,
      "x": 830,
      "y": 458
    },
    {
      "t": 182510,
      "e": 134041,
      "ty": 41,
      "x": 2035,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 182610,
      "e": 134141,
      "ty": 2,
      "x": 830,
      "y": 451
    },
    {
      "t": 182694,
      "e": 134225,
      "ty": 6,
      "x": 830,
      "y": 448,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 182710,
      "e": 134241,
      "ty": 2,
      "x": 830,
      "y": 448
    },
    {
      "t": 182761,
      "e": 134292,
      "ty": 41,
      "x": 18037,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 182910,
      "e": 134441,
      "ty": 2,
      "x": 830,
      "y": 443
    },
    {
      "t": 182974,
      "e": 134505,
      "ty": 3,
      "x": 830,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 182976,
      "e": 134507,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 182977,
      "e": 134508,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 183010,
      "e": 134541,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 183085,
      "e": 134616,
      "ty": 4,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 183085,
      "e": 134616,
      "ty": 5,
      "x": 830,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 183086,
      "e": 134617,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 184259,
      "e": 135790,
      "ty": 41,
      "x": 18037,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 184270,
      "e": 135801,
      "ty": 7,
      "x": 832,
      "y": 433,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 184282,
      "e": 135813,
      "ty": 6,
      "x": 834,
      "y": 418,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 184299,
      "e": 135830,
      "ty": 7,
      "x": 837,
      "y": 402,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 184309,
      "e": 135840,
      "ty": 2,
      "x": 837,
      "y": 402
    },
    {
      "t": 184409,
      "e": 135940,
      "ty": 2,
      "x": 862,
      "y": 320
    },
    {
      "t": 184509,
      "e": 136040,
      "ty": 2,
      "x": 873,
      "y": 290
    },
    {
      "t": 184509,
      "e": 136040,
      "ty": 41,
      "x": 16164,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 184610,
      "e": 136141,
      "ty": 2,
      "x": 854,
      "y": 269
    },
    {
      "t": 184666,
      "e": 136197,
      "ty": 6,
      "x": 826,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 184683,
      "e": 136214,
      "ty": 7,
      "x": 824,
      "y": 240,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 184710,
      "e": 136215,
      "ty": 2,
      "x": 824,
      "y": 238
    },
    {
      "t": 184759,
      "e": 136264,
      "ty": 41,
      "x": 2930,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 184809,
      "e": 136314,
      "ty": 2,
      "x": 836,
      "y": 220
    },
    {
      "t": 185009,
      "e": 136514,
      "ty": 2,
      "x": 836,
      "y": 223
    },
    {
      "t": 185009,
      "e": 136514,
      "ty": 41,
      "x": 3459,
      "y": 18250,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 185048,
      "e": 136553,
      "ty": 6,
      "x": 832,
      "y": 233,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 185109,
      "e": 136614,
      "ty": 2,
      "x": 831,
      "y": 235
    },
    {
      "t": 185239,
      "e": 136744,
      "ty": 3,
      "x": 831,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 185240,
      "e": 136745,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 185240,
      "e": 136745,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 185259,
      "e": 136764,
      "ty": 41,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 185342,
      "e": 136847,
      "ty": 4,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 185342,
      "e": 136847,
      "ty": 5,
      "x": 831,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 185342,
      "e": 136847,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 185550,
      "e": 137055,
      "ty": 7,
      "x": 818,
      "y": 253,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 185610,
      "e": 137115,
      "ty": 2,
      "x": 800,
      "y": 291
    },
    {
      "t": 185710,
      "e": 137215,
      "ty": 2,
      "x": 773,
      "y": 346
    },
    {
      "t": 185760,
      "e": 137265,
      "ty": 41,
      "x": 26207,
      "y": 19499,
      "ta": "html > body"
    },
    {
      "t": 185809,
      "e": 137314,
      "ty": 2,
      "x": 762,
      "y": 404
    },
    {
      "t": 185909,
      "e": 137414,
      "ty": 2,
      "x": 655,
      "y": 842
    },
    {
      "t": 186010,
      "e": 137515,
      "ty": 2,
      "x": 659,
      "y": 843
    },
    {
      "t": 186010,
      "e": 137515,
      "ty": 41,
      "x": 22418,
      "y": 46256,
      "ta": "html > body"
    },
    {
      "t": 186109,
      "e": 137614,
      "ty": 2,
      "x": 658,
      "y": 815
    },
    {
      "t": 186209,
      "e": 137714,
      "ty": 2,
      "x": 740,
      "y": 703
    },
    {
      "t": 186259,
      "e": 137764,
      "ty": 41,
      "x": 25346,
      "y": 38279,
      "ta": "html > body"
    },
    {
      "t": 186309,
      "e": 137814,
      "ty": 2,
      "x": 744,
      "y": 699
    },
    {
      "t": 190013,
      "e": 141518,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 191713,
      "e": 142814,
      "ty": 2,
      "x": 743,
      "y": 703
    },
    {
      "t": 191763,
      "e": 142864,
      "ty": 41,
      "x": 25311,
      "y": 38722,
      "ta": "html > body"
    },
    {
      "t": 191813,
      "e": 142914,
      "ty": 2,
      "x": 746,
      "y": 710
    },
    {
      "t": 191913,
      "e": 143014,
      "ty": 2,
      "x": 815,
      "y": 710
    },
    {
      "t": 192013,
      "e": 143114,
      "ty": 2,
      "x": 833,
      "y": 710
    },
    {
      "t": 192013,
      "e": 143114,
      "ty": 41,
      "x": 2917,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 192113,
      "e": 143214,
      "ty": 2,
      "x": 835,
      "y": 720
    },
    {
      "t": 192210,
      "e": 143311,
      "ty": 6,
      "x": 835,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 192213,
      "e": 143314,
      "ty": 2,
      "x": 835,
      "y": 724
    },
    {
      "t": 192263,
      "e": 143364,
      "ty": 41,
      "x": 43243,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 192313,
      "e": 143414,
      "ty": 2,
      "x": 834,
      "y": 726
    },
    {
      "t": 192513,
      "e": 143614,
      "ty": 41,
      "x": 38202,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 192613,
      "e": 143714,
      "ty": 2,
      "x": 833,
      "y": 731
    },
    {
      "t": 192755,
      "e": 143856,
      "ty": 3,
      "x": 833,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 192756,
      "e": 143857,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 192757,
      "e": 143858,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 192763,
      "e": 143864,
      "ty": 41,
      "x": 33161,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 192841,
      "e": 143942,
      "ty": 4,
      "x": 33161,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 192841,
      "e": 143942,
      "ty": 5,
      "x": 833,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 192841,
      "e": 143942,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 193178,
      "e": 144279,
      "ty": 7,
      "x": 819,
      "y": 741,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 193213,
      "e": 144314,
      "ty": 2,
      "x": 756,
      "y": 790
    },
    {
      "t": 193263,
      "e": 144364,
      "ty": 41,
      "x": 23968,
      "y": 45370,
      "ta": "html > body"
    },
    {
      "t": 193313,
      "e": 144414,
      "ty": 2,
      "x": 704,
      "y": 827
    },
    {
      "t": 193614,
      "e": 144715,
      "ty": 2,
      "x": 718,
      "y": 851
    },
    {
      "t": 193713,
      "e": 144814,
      "ty": 2,
      "x": 747,
      "y": 876
    },
    {
      "t": 193763,
      "e": 144864,
      "ty": 41,
      "x": 25931,
      "y": 48417,
      "ta": "html > body"
    },
    {
      "t": 193813,
      "e": 144914,
      "ty": 2,
      "x": 780,
      "y": 890
    },
    {
      "t": 193913,
      "e": 145014,
      "ty": 2,
      "x": 790,
      "y": 895
    },
    {
      "t": 194013,
      "e": 145114,
      "ty": 2,
      "x": 811,
      "y": 913
    },
    {
      "t": 194014,
      "e": 145115,
      "ty": 41,
      "x": 27653,
      "y": 50134,
      "ta": "html > body"
    },
    {
      "t": 194113,
      "e": 145214,
      "ty": 2,
      "x": 825,
      "y": 939
    },
    {
      "t": 194193,
      "e": 145294,
      "ty": 6,
      "x": 826,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 194213,
      "e": 145314,
      "ty": 2,
      "x": 826,
      "y": 965
    },
    {
      "t": 194263,
      "e": 145364,
      "ty": 41,
      "x": 2914,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 194313,
      "e": 145414,
      "ty": 2,
      "x": 827,
      "y": 968
    },
    {
      "t": 194387,
      "e": 145488,
      "ty": 7,
      "x": 828,
      "y": 969,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 194413,
      "e": 145514,
      "ty": 2,
      "x": 829,
      "y": 969
    },
    {
      "t": 194425,
      "e": 145526,
      "ty": 6,
      "x": 830,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 194513,
      "e": 145614,
      "ty": 2,
      "x": 832,
      "y": 963
    },
    {
      "t": 194514,
      "e": 145615,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 194613,
      "e": 145714,
      "ty": 2,
      "x": 833,
      "y": 962
    },
    {
      "t": 194690,
      "e": 145791,
      "ty": 3,
      "x": 833,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 194691,
      "e": 145792,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 194692,
      "e": 145793,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 194764,
      "e": 145865,
      "ty": 41,
      "x": 33161,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 194777,
      "e": 145878,
      "ty": 4,
      "x": 33161,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 194777,
      "e": 145878,
      "ty": 5,
      "x": 833,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 194777,
      "e": 145878,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 194961,
      "e": 146062,
      "ty": 7,
      "x": 843,
      "y": 971,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 195013,
      "e": 146114,
      "ty": 2,
      "x": 878,
      "y": 1002
    },
    {
      "t": 195013,
      "e": 146114,
      "ty": 41,
      "x": 13427,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 195029,
      "e": 146130,
      "ty": 6,
      "x": 888,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 195114,
      "e": 146215,
      "ty": 2,
      "x": 892,
      "y": 1009
    },
    {
      "t": 195213,
      "e": 146314,
      "ty": 2,
      "x": 894,
      "y": 1009
    },
    {
      "t": 195264,
      "e": 146365,
      "ty": 41,
      "x": 33282,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 195413,
      "e": 146514,
      "ty": 2,
      "x": 894,
      "y": 1015
    },
    {
      "t": 195513,
      "e": 146614,
      "ty": 2,
      "x": 895,
      "y": 1026
    },
    {
      "t": 195514,
      "e": 146615,
      "ty": 41,
      "x": 33798,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 196098,
      "e": 147199,
      "ty": 3,
      "x": 895,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 196100,
      "e": 147201,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 196100,
      "e": 147201,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 196169,
      "e": 147270,
      "ty": 4,
      "x": 33798,
      "y": 41704,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 196169,
      "e": 147270,
      "ty": 5,
      "x": 895,
      "y": 1026,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 196171,
      "e": 147272,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 196173,
      "e": 147274,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 196173,
      "e": 147274,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 197512,
      "e": 148613,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 200013,
      "e": 151114,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 202214,
      "e": 152274,
      "ty": 2,
      "x": 713,
      "y": 901
    },
    {
      "t": 202264,
      "e": 152324,
      "ty": 41,
      "x": 19804,
      "y": 40995,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 202314,
      "e": 152374,
      "ty": 2,
      "x": 696,
      "y": 890
    },
    {
      "t": 202764,
      "e": 152824,
      "ty": 41,
      "x": 19754,
      "y": 40995,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 202814,
      "e": 152874,
      "ty": 2,
      "x": 707,
      "y": 965
    },
    {
      "t": 202914,
      "e": 152974,
      "ty": 2,
      "x": 741,
      "y": 978
    },
    {
      "t": 203014,
      "e": 153074,
      "ty": 2,
      "x": 756,
      "y": 955
    },
    {
      "t": 203014,
      "e": 153074,
      "ty": 41,
      "x": 22755,
      "y": 57385,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 203114,
      "e": 153174,
      "ty": 2,
      "x": 773,
      "y": 944
    },
    {
      "t": 203214,
      "e": 153274,
      "ty": 2,
      "x": 884,
      "y": 953
    },
    {
      "t": 203264,
      "e": 153324,
      "ty": 41,
      "x": 30627,
      "y": 58285,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 203314,
      "e": 153374,
      "ty": 2,
      "x": 966,
      "y": 1002
    },
    {
      "t": 203414,
      "e": 153474,
      "ty": 2,
      "x": 974,
      "y": 1030
    },
    {
      "t": 203514,
      "e": 153574,
      "ty": 2,
      "x": 960,
      "y": 1063
    },
    {
      "t": 203514,
      "e": 153574,
      "ty": 41,
      "x": 32792,
      "y": 64864,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 203570,
      "e": 153630,
      "ty": 6,
      "x": 959,
      "y": 1074,
      "ta": "#start"
    },
    {
      "t": 203614,
      "e": 153674,
      "ty": 2,
      "x": 957,
      "y": 1077
    },
    {
      "t": 203714,
      "e": 153774,
      "ty": 2,
      "x": 961,
      "y": 1084
    },
    {
      "t": 203764,
      "e": 153824,
      "ty": 41,
      "x": 30309,
      "y": 25659,
      "ta": "#start"
    },
    {
      "t": 203814,
      "e": 153874,
      "ty": 2,
      "x": 968,
      "y": 1089
    },
    {
      "t": 204014,
      "e": 154074,
      "ty": 41,
      "x": 31948,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 207259,
      "e": 157319,
      "ty": 3,
      "x": 968,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 207260,
      "e": 157320,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 207329,
      "e": 157389,
      "ty": 4,
      "x": 31948,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 207329,
      "e": 157389,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 207329,
      "e": 157389,
      "ty": 5,
      "x": 968,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 207330,
      "e": 157390,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 208367,
      "e": 158427,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 209492,
      "e": 159552,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"id\":2593},{\"id\":2594},{\"id\":2595},{\"id\":2596},{\"id\":2597},{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2601},{\"id\":2602},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2603}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 66008, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 66010, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 6727, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 74067, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 14789, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"kilo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 89862, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 32832, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 123780, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 14998, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 139782, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 74973, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 216119, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1044,y:943,t:1527188764638};\\\", \\\"{x:1041,y:942,t:1527188764645};\\\", \\\"{x:1038,y:940,t:1527188764656};\\\", \\\"{x:1037,y:940,t:1527188764673};\\\", \\\"{x:1036,y:940,t:1527188764741};\\\", \\\"{x:1018,y:945,t:1527188764756};\\\", \\\"{x:1010,y:951,t:1527188764773};\\\", \\\"{x:1005,y:952,t:1527188764789};\\\", \\\"{x:1003,y:954,t:1527188764807};\\\", \\\"{x:1001,y:955,t:1527188764823};\\\", \\\"{x:1000,y:955,t:1527188764839};\\\", \\\"{x:999,y:957,t:1527188764856};\\\", \\\"{x:994,y:958,t:1527188764873};\\\", \\\"{x:986,y:958,t:1527188764890};\\\", \\\"{x:973,y:958,t:1527188764907};\\\", \\\"{x:955,y:958,t:1527188764923};\\\", \\\"{x:928,y:958,t:1527188764939};\\\", \\\"{x:881,y:951,t:1527188764957};\\\", \\\"{x:851,y:943,t:1527188764973};\\\", \\\"{x:822,y:933,t:1527188764990};\\\", \\\"{x:796,y:926,t:1527188765006};\\\", \\\"{x:762,y:917,t:1527188765023};\\\", \\\"{x:725,y:898,t:1527188765040};\\\", \\\"{x:685,y:878,t:1527188765056};\\\", \\\"{x:650,y:860,t:1527188765073};\\\", \\\"{x:620,y:843,t:1527188765090};\\\", \\\"{x:583,y:821,t:1527188765106};\\\", \\\"{x:535,y:795,t:1527188765123};\\\", \\\"{x:477,y:774,t:1527188765139};\\\", \\\"{x:450,y:774,t:1527188765155};\\\", \\\"{x:419,y:776,t:1527188765173};\\\", \\\"{x:396,y:783,t:1527188765190};\\\", \\\"{x:391,y:788,t:1527188765205};\\\", \\\"{x:391,y:790,t:1527188765223};\\\", \\\"{x:389,y:790,t:1527188803600};\\\", \\\"{x:385,y:790,t:1527188803607};\\\", \\\"{x:381,y:790,t:1527188803621};\\\", \\\"{x:372,y:790,t:1527188803638};\\\", \\\"{x:362,y:790,t:1527188803655};\\\", \\\"{x:355,y:786,t:1527188803670};\\\", \\\"{x:349,y:776,t:1527188803687};\\\", \\\"{x:343,y:759,t:1527188803705};\\\", \\\"{x:332,y:730,t:1527188803721};\\\", \\\"{x:321,y:704,t:1527188803738};\\\", \\\"{x:307,y:674,t:1527188803755};\\\", \\\"{x:292,y:654,t:1527188803773};\\\", \\\"{x:284,y:643,t:1527188803788};\\\", \\\"{x:280,y:637,t:1527188803804};\\\", \\\"{x:279,y:634,t:1527188803820};\\\", \\\"{x:278,y:627,t:1527188803836};\\\", \\\"{x:278,y:615,t:1527188803851};\\\", \\\"{x:281,y:608,t:1527188803869};\\\", \\\"{x:290,y:598,t:1527188803891};\\\", \\\"{x:295,y:595,t:1527188803907};\\\", \\\"{x:300,y:591,t:1527188803924};\\\", \\\"{x:304,y:588,t:1527188803941};\\\", \\\"{x:308,y:585,t:1527188803957};\\\", \\\"{x:309,y:580,t:1527188803975};\\\", \\\"{x:311,y:574,t:1527188803992};\\\", \\\"{x:312,y:569,t:1527188804007};\\\", \\\"{x:312,y:565,t:1527188804025};\\\", \\\"{x:312,y:564,t:1527188804041};\\\", \\\"{x:311,y:564,t:1527188804062};\\\", \\\"{x:310,y:564,t:1527188804078};\\\", \\\"{x:313,y:564,t:1527188804335};\\\", \\\"{x:317,y:564,t:1527188804342};\\\", \\\"{x:325,y:564,t:1527188804359};\\\", \\\"{x:333,y:564,t:1527188804374};\\\", \\\"{x:338,y:564,t:1527188804392};\\\", \\\"{x:343,y:564,t:1527188804409};\\\", \\\"{x:348,y:564,t:1527188804425};\\\", \\\"{x:351,y:565,t:1527188804442};\\\", \\\"{x:355,y:566,t:1527188804459};\\\", \\\"{x:359,y:566,t:1527188804476};\\\", \\\"{x:363,y:569,t:1527188804492};\\\", \\\"{x:367,y:569,t:1527188804509};\\\", \\\"{x:369,y:569,t:1527188804526};\\\", \\\"{x:370,y:569,t:1527188804542};\\\", \\\"{x:372,y:568,t:1527188804559};\\\", \\\"{x:373,y:568,t:1527188804576};\\\", \\\"{x:375,y:568,t:1527188804592};\\\", \\\"{x:377,y:566,t:1527188804608};\\\", \\\"{x:378,y:566,t:1527188804625};\\\", \\\"{x:379,y:566,t:1527188804641};\\\", \\\"{x:381,y:566,t:1527188804659};\\\", \\\"{x:382,y:566,t:1527188804675};\\\", \\\"{x:381,y:567,t:1527188823175};\\\", \\\"{x:374,y:572,t:1527188823186};\\\", \\\"{x:358,y:581,t:1527188823202};\\\", \\\"{x:340,y:589,t:1527188823218};\\\", \\\"{x:309,y:599,t:1527188823240};\\\", \\\"{x:290,y:603,t:1527188823257};\\\", \\\"{x:279,y:605,t:1527188823273};\\\", \\\"{x:273,y:608,t:1527188823290};\\\", \\\"{x:272,y:608,t:1527188823308};\\\", \\\"{x:270,y:608,t:1527188823342};\\\", \\\"{x:270,y:609,t:1527188823357};\\\", \\\"{x:269,y:610,t:1527188823373};\\\", \\\"{x:266,y:611,t:1527188823390};\\\", \\\"{x:265,y:611,t:1527188823407};\\\", \\\"{x:263,y:611,t:1527188823424};\\\", \\\"{x:253,y:603,t:1527188823440};\\\", \\\"{x:232,y:587,t:1527188823457};\\\", \\\"{x:196,y:554,t:1527188823475};\\\", \\\"{x:155,y:521,t:1527188823491};\\\", \\\"{x:117,y:501,t:1527188823507};\\\", \\\"{x:87,y:490,t:1527188823523};\\\", \\\"{x:69,y:483,t:1527188823540};\\\", \\\"{x:65,y:482,t:1527188823557};\\\", \\\"{x:64,y:482,t:1527188823573};\\\", \\\"{x:67,y:483,t:1527188823751};\\\", \\\"{x:71,y:486,t:1527188823758};\\\", \\\"{x:73,y:487,t:1527188823774};\\\", \\\"{x:84,y:492,t:1527188823791};\\\", \\\"{x:90,y:494,t:1527188823808};\\\", \\\"{x:96,y:495,t:1527188823823};\\\", \\\"{x:104,y:498,t:1527188823840};\\\", \\\"{x:112,y:499,t:1527188823857};\\\", \\\"{x:120,y:500,t:1527188823873};\\\", \\\"{x:132,y:501,t:1527188823890};\\\", \\\"{x:139,y:503,t:1527188823907};\\\", \\\"{x:144,y:503,t:1527188823923};\\\", \\\"{x:149,y:504,t:1527188823940};\\\", \\\"{x:151,y:504,t:1527188823957};\\\", \\\"{x:152,y:504,t:1527188824006};\\\", \\\"{x:153,y:505,t:1527188824024};\\\", \\\"{x:154,y:505,t:1527188824062};\\\", \\\"{x:154,y:506,t:1527188824080};\\\", \\\"{x:156,y:509,t:1527188824091};\\\", \\\"{x:162,y:522,t:1527188824107};\\\", \\\"{x:164,y:528,t:1527188824124};\\\", \\\"{x:165,y:531,t:1527188824141};\\\", \\\"{x:166,y:533,t:1527188824158};\\\", \\\"{x:166,y:536,t:1527188824174};\\\", \\\"{x:167,y:537,t:1527188824198};\\\", \\\"{x:167,y:536,t:1527188824376};\\\", \\\"{x:167,y:532,t:1527188824392};\\\", \\\"{x:166,y:530,t:1527188824407};\\\", \\\"{x:165,y:529,t:1527188824424};\\\", \\\"{x:165,y:528,t:1527188824441};\\\", \\\"{x:165,y:527,t:1527188824461};\\\", \\\"{x:165,y:526,t:1527188824474};\\\", \\\"{x:164,y:525,t:1527188824517};\\\", \\\"{x:166,y:524,t:1527188825221};\\\", \\\"{x:171,y:524,t:1527188825229};\\\", \\\"{x:180,y:524,t:1527188825241};\\\", \\\"{x:197,y:532,t:1527188825258};\\\", \\\"{x:223,y:545,t:1527188825276};\\\", \\\"{x:249,y:559,t:1527188825291};\\\", \\\"{x:287,y:581,t:1527188825308};\\\", \\\"{x:334,y:610,t:1527188825325};\\\", \\\"{x:375,y:636,t:1527188825341};\\\", \\\"{x:435,y:670,t:1527188825358};\\\", \\\"{x:467,y:688,t:1527188825375};\\\", \\\"{x:487,y:700,t:1527188825391};\\\", \\\"{x:498,y:706,t:1527188825409};\\\", \\\"{x:505,y:708,t:1527188825425};\\\", \\\"{x:507,y:710,t:1527188825441};\\\", \\\"{x:508,y:712,t:1527188825695};\\\", \\\"{x:509,y:715,t:1527188825710};\\\", \\\"{x:509,y:716,t:1527188825726};\\\", \\\"{x:512,y:722,t:1527188825742};\\\", \\\"{x:514,y:726,t:1527188825759};\\\", \\\"{x:514,y:728,t:1527188825775};\\\", \\\"{x:517,y:732,t:1527188831127};\\\", \\\"{x:518,y:737,t:1527188831136};\\\", \\\"{x:522,y:744,t:1527188831146};\\\", \\\"{x:524,y:750,t:1527188831163};\\\", \\\"{x:527,y:757,t:1527188831179};\\\", \\\"{x:527,y:758,t:1527188831197};\\\", \\\"{x:528,y:759,t:1527188831213};\\\", \\\"{x:529,y:759,t:1527188831343};\\\", \\\"{x:529,y:758,t:1527188831358};\\\", \\\"{x:529,y:757,t:1527188831366};\\\", \\\"{x:529,y:756,t:1527188831379};\\\", \\\"{x:529,y:754,t:1527188831397};\\\", \\\"{x:529,y:751,t:1527188831415};\\\", \\\"{x:529,y:750,t:1527188831438};\\\", \\\"{x:529,y:749,t:1527188831518};\\\", \\\"{x:529,y:746,t:1527188831529};\\\", \\\"{x:529,y:742,t:1527188831546};\\\", \\\"{x:529,y:739,t:1527188831564};\\\", \\\"{x:529,y:737,t:1527188831582};\\\", \\\"{x:529,y:736,t:1527188831597};\\\", \\\"{x:529,y:735,t:1527188831615};\\\", \\\"{x:529,y:734,t:1527188831637};\\\", \\\"{x:529,y:733,t:1527188831647};\\\", \\\"{x:529,y:732,t:1527188831677};\\\", \\\"{x:530,y:729,t:1527188832182};\\\", \\\"{x:531,y:728,t:1527188832215};\\\" ] }, { \\\"rt\\\": 33255, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 250969, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:721,t:1527188843614};\\\", \\\"{x:513,y:701,t:1527188843623};\\\", \\\"{x:448,y:639,t:1527188843642};\\\", \\\"{x:360,y:578,t:1527188843657};\\\", \\\"{x:276,y:521,t:1527188843673};\\\", \\\"{x:159,y:441,t:1527188843707};\\\", \\\"{x:146,y:426,t:1527188843723};\\\", \\\"{x:144,y:421,t:1527188843740};\\\", \\\"{x:143,y:420,t:1527188843755};\\\", \\\"{x:143,y:419,t:1527188843773};\\\", \\\"{x:143,y:417,t:1527188843789};\\\", \\\"{x:143,y:416,t:1527188843806};\\\", \\\"{x:143,y:415,t:1527188843823};\\\", \\\"{x:144,y:414,t:1527188843840};\\\", \\\"{x:145,y:414,t:1527188843869};\\\", \\\"{x:147,y:414,t:1527188843934};\\\", \\\"{x:149,y:414,t:1527188843942};\\\", \\\"{x:152,y:418,t:1527188843958};\\\", \\\"{x:161,y:435,t:1527188843974};\\\", \\\"{x:183,y:473,t:1527188843990};\\\", \\\"{x:206,y:509,t:1527188844008};\\\", \\\"{x:227,y:532,t:1527188844022};\\\", \\\"{x:241,y:549,t:1527188844040};\\\", \\\"{x:254,y:564,t:1527188844056};\\\", \\\"{x:260,y:574,t:1527188844072};\\\", \\\"{x:260,y:579,t:1527188844090};\\\", \\\"{x:261,y:585,t:1527188844108};\\\", \\\"{x:261,y:593,t:1527188844123};\\\", \\\"{x:262,y:613,t:1527188844140};\\\", \\\"{x:267,y:631,t:1527188844158};\\\", \\\"{x:276,y:648,t:1527188844174};\\\", \\\"{x:277,y:649,t:1527188844190};\\\", \\\"{x:278,y:649,t:1527188844230};\\\", \\\"{x:282,y:649,t:1527188844246};\\\", \\\"{x:284,y:647,t:1527188844257};\\\", \\\"{x:291,y:643,t:1527188844274};\\\", \\\"{x:299,y:639,t:1527188844290};\\\", \\\"{x:306,y:635,t:1527188844307};\\\", \\\"{x:312,y:633,t:1527188844324};\\\", \\\"{x:319,y:630,t:1527188844340};\\\", \\\"{x:324,y:628,t:1527188844357};\\\", \\\"{x:331,y:624,t:1527188844374};\\\", \\\"{x:334,y:622,t:1527188844390};\\\", \\\"{x:336,y:621,t:1527188844407};\\\", \\\"{x:337,y:619,t:1527188844439};\\\", \\\"{x:339,y:618,t:1527188844457};\\\", \\\"{x:343,y:613,t:1527188844474};\\\", \\\"{x:347,y:610,t:1527188844490};\\\", \\\"{x:354,y:606,t:1527188844507};\\\", \\\"{x:357,y:603,t:1527188844524};\\\", \\\"{x:358,y:602,t:1527188844539};\\\", \\\"{x:359,y:602,t:1527188844556};\\\", \\\"{x:361,y:601,t:1527188844573};\\\", \\\"{x:362,y:600,t:1527188844590};\\\", \\\"{x:363,y:600,t:1527188844614};\\\", \\\"{x:364,y:599,t:1527188844695};\\\", \\\"{x:364,y:598,t:1527188844839};\\\", \\\"{x:365,y:598,t:1527188844846};\\\", \\\"{x:367,y:598,t:1527188844858};\\\", \\\"{x:370,y:598,t:1527188844874};\\\", \\\"{x:371,y:598,t:1527188844891};\\\", \\\"{x:372,y:598,t:1527188844907};\\\", \\\"{x:373,y:598,t:1527188844924};\\\", \\\"{x:374,y:598,t:1527188844942};\\\", \\\"{x:375,y:598,t:1527188844957};\\\", \\\"{x:376,y:599,t:1527188844974};\\\", \\\"{x:366,y:599,t:1527188850975};\\\", \\\"{x:330,y:595,t:1527188850995};\\\", \\\"{x:285,y:587,t:1527188851013};\\\", \\\"{x:206,y:578,t:1527188851029};\\\", \\\"{x:168,y:570,t:1527188851045};\\\", \\\"{x:146,y:566,t:1527188851063};\\\", \\\"{x:142,y:565,t:1527188851079};\\\", \\\"{x:141,y:563,t:1527188851095};\\\", \\\"{x:141,y:562,t:1527188851269};\\\", \\\"{x:143,y:560,t:1527188851279};\\\", \\\"{x:149,y:556,t:1527188851296};\\\", \\\"{x:160,y:553,t:1527188851312};\\\", \\\"{x:175,y:549,t:1527188851329};\\\", \\\"{x:190,y:548,t:1527188851347};\\\", \\\"{x:207,y:546,t:1527188851362};\\\", \\\"{x:221,y:544,t:1527188851379};\\\", \\\"{x:226,y:543,t:1527188851397};\\\", \\\"{x:229,y:542,t:1527188851413};\\\", \\\"{x:236,y:541,t:1527188851430};\\\", \\\"{x:246,y:540,t:1527188851446};\\\", \\\"{x:257,y:540,t:1527188851462};\\\", \\\"{x:263,y:538,t:1527188851480};\\\", \\\"{x:264,y:537,t:1527188851497};\\\", \\\"{x:265,y:537,t:1527188851512};\\\", \\\"{x:266,y:537,t:1527188851530};\\\", \\\"{x:273,y:536,t:1527188851547};\\\", \\\"{x:281,y:535,t:1527188851563};\\\", \\\"{x:291,y:533,t:1527188851579};\\\", \\\"{x:298,y:531,t:1527188851597};\\\", \\\"{x:308,y:527,t:1527188851614};\\\", \\\"{x:313,y:527,t:1527188851630};\\\", \\\"{x:315,y:527,t:1527188851646};\\\", \\\"{x:318,y:527,t:1527188851664};\\\", \\\"{x:319,y:525,t:1527188851679};\\\", \\\"{x:320,y:522,t:1527188851697};\\\", \\\"{x:322,y:519,t:1527188851713};\\\", \\\"{x:325,y:517,t:1527188851730};\\\", \\\"{x:325,y:516,t:1527188851747};\\\", \\\"{x:326,y:516,t:1527188851764};\\\", \\\"{x:326,y:514,t:1527188851780};\\\", \\\"{x:326,y:509,t:1527188851796};\\\", \\\"{x:326,y:500,t:1527188851816};\\\", \\\"{x:328,y:494,t:1527188851830};\\\", \\\"{x:332,y:489,t:1527188851847};\\\", \\\"{x:337,y:486,t:1527188851863};\\\", \\\"{x:341,y:484,t:1527188851879};\\\", \\\"{x:345,y:483,t:1527188851897};\\\", \\\"{x:350,y:483,t:1527188851914};\\\", \\\"{x:363,y:487,t:1527188851929};\\\", \\\"{x:377,y:491,t:1527188851947};\\\", \\\"{x:392,y:497,t:1527188851964};\\\", \\\"{x:403,y:502,t:1527188851979};\\\", \\\"{x:412,y:508,t:1527188851997};\\\", \\\"{x:425,y:516,t:1527188852013};\\\", \\\"{x:426,y:517,t:1527188852029};\\\", \\\"{x:426,y:518,t:1527188852110};\\\", \\\"{x:426,y:519,t:1527188852118};\\\", \\\"{x:426,y:521,t:1527188852129};\\\", \\\"{x:426,y:523,t:1527188852146};\\\", \\\"{x:426,y:524,t:1527188852163};\\\", \\\"{x:425,y:524,t:1527188852180};\\\", \\\"{x:422,y:525,t:1527188852196};\\\", \\\"{x:416,y:525,t:1527188852214};\\\", \\\"{x:409,y:525,t:1527188852230};\\\", \\\"{x:403,y:525,t:1527188852246};\\\", \\\"{x:399,y:525,t:1527188852263};\\\", \\\"{x:395,y:525,t:1527188852280};\\\", \\\"{x:393,y:525,t:1527188852296};\\\", \\\"{x:390,y:523,t:1527188852314};\\\", \\\"{x:389,y:523,t:1527188859953};\\\", \\\"{x:390,y:526,t:1527188859961};\\\", \\\"{x:392,y:535,t:1527188859971};\\\", \\\"{x:401,y:554,t:1527188859988};\\\", \\\"{x:407,y:567,t:1527188860004};\\\", \\\"{x:413,y:578,t:1527188860023};\\\", \\\"{x:418,y:586,t:1527188860040};\\\", \\\"{x:422,y:592,t:1527188860055};\\\", \\\"{x:425,y:596,t:1527188860073};\\\", \\\"{x:426,y:598,t:1527188860209};\\\", \\\"{x:427,y:600,t:1527188860273};\\\", \\\"{x:428,y:601,t:1527188860290};\\\", \\\"{x:428,y:604,t:1527188860306};\\\", \\\"{x:431,y:606,t:1527188860323};\\\", \\\"{x:433,y:609,t:1527188860341};\\\", \\\"{x:435,y:613,t:1527188860358};\\\", \\\"{x:439,y:617,t:1527188860373};\\\", \\\"{x:441,y:621,t:1527188860392};\\\", \\\"{x:444,y:627,t:1527188860407};\\\", \\\"{x:446,y:630,t:1527188860423};\\\", \\\"{x:448,y:634,t:1527188860440};\\\", \\\"{x:451,y:642,t:1527188860456};\\\", \\\"{x:453,y:647,t:1527188860473};\\\", \\\"{x:454,y:648,t:1527188860490};\\\", \\\"{x:455,y:649,t:1527188862513};\\\", \\\"{x:455,y:653,t:1527188866355};\\\", \\\"{x:455,y:661,t:1527188866371};\\\", \\\"{x:455,y:671,t:1527188866388};\\\", \\\"{x:455,y:679,t:1527188866411};\\\", \\\"{x:455,y:682,t:1527188866428};\\\", \\\"{x:455,y:684,t:1527188866444};\\\", \\\"{x:455,y:685,t:1527188866461};\\\", \\\"{x:456,y:689,t:1527188866478};\\\", \\\"{x:458,y:691,t:1527188866494};\\\", \\\"{x:460,y:693,t:1527188866511};\\\", \\\"{x:464,y:697,t:1527188866529};\\\", \\\"{x:468,y:700,t:1527188866544};\\\", \\\"{x:472,y:704,t:1527188866562};\\\", \\\"{x:477,y:708,t:1527188866578};\\\", \\\"{x:485,y:716,t:1527188866595};\\\", \\\"{x:490,y:723,t:1527188866611};\\\", \\\"{x:496,y:730,t:1527188866628};\\\", \\\"{x:499,y:734,t:1527188866645};\\\", \\\"{x:502,y:737,t:1527188866662};\\\", \\\"{x:504,y:737,t:1527188866678};\\\", \\\"{x:505,y:738,t:1527188866695};\\\", \\\"{x:507,y:738,t:1527188866711};\\\", \\\"{x:507,y:739,t:1527188866729};\\\", \\\"{x:508,y:739,t:1527188866857};\\\", \\\"{x:508,y:736,t:1527188866865};\\\", \\\"{x:509,y:733,t:1527188866879};\\\", \\\"{x:510,y:730,t:1527188866895};\\\", \\\"{x:510,y:729,t:1527188866912};\\\", \\\"{x:511,y:726,t:1527188866929};\\\", \\\"{x:512,y:725,t:1527188866945};\\\", \\\"{x:512,y:724,t:1527188866962};\\\", \\\"{x:512,y:723,t:1527188866979};\\\", \\\"{x:512,y:722,t:1527188867001};\\\", \\\"{x:512,y:720,t:1527188867352};\\\", \\\"{x:505,y:709,t:1527188867362};\\\", \\\"{x:492,y:686,t:1527188867378};\\\", \\\"{x:490,y:672,t:1527188867395};\\\" ] }, { \\\"rt\\\": 68522, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 320702, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"U\\\", \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -12 PM-01 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:490,y:673,t:1527188868937};\\\", \\\"{x:490,y:674,t:1527188868952};\\\", \\\"{x:491,y:674,t:1527188868963};\\\", \\\"{x:494,y:677,t:1527188874785};\\\", \\\"{x:545,y:698,t:1527188874802};\\\", \\\"{x:641,y:738,t:1527188874818};\\\", \\\"{x:722,y:762,t:1527188874835};\\\", \\\"{x:779,y:774,t:1527188874852};\\\", \\\"{x:816,y:785,t:1527188874868};\\\", \\\"{x:847,y:795,t:1527188874885};\\\", \\\"{x:871,y:803,t:1527188874902};\\\", \\\"{x:888,y:807,t:1527188874920};\\\", \\\"{x:901,y:810,t:1527188874935};\\\", \\\"{x:911,y:813,t:1527188874952};\\\", \\\"{x:936,y:817,t:1527188874969};\\\", \\\"{x:965,y:821,t:1527188874985};\\\", \\\"{x:1006,y:824,t:1527188875003};\\\", \\\"{x:1054,y:825,t:1527188875019};\\\", \\\"{x:1107,y:831,t:1527188875035};\\\", \\\"{x:1149,y:831,t:1527188875052};\\\", \\\"{x:1175,y:832,t:1527188875070};\\\", \\\"{x:1186,y:832,t:1527188875085};\\\", \\\"{x:1187,y:832,t:1527188875170};\\\", \\\"{x:1193,y:832,t:1527188875185};\\\", \\\"{x:1206,y:830,t:1527188875202};\\\", \\\"{x:1214,y:828,t:1527188875221};\\\", \\\"{x:1216,y:827,t:1527188875234};\\\", \\\"{x:1217,y:827,t:1527188875272};\\\", \\\"{x:1218,y:826,t:1527188875284};\\\", \\\"{x:1218,y:827,t:1527188875521};\\\", \\\"{x:1218,y:828,t:1527188875545};\\\", \\\"{x:1217,y:828,t:1527188875553};\\\", \\\"{x:1217,y:829,t:1527188875569};\\\", \\\"{x:1216,y:830,t:1527188875593};\\\", \\\"{x:1216,y:831,t:1527188875609};\\\", \\\"{x:1216,y:836,t:1527188910876};\\\", \\\"{x:1216,y:842,t:1527188910881};\\\", \\\"{x:1216,y:851,t:1527188910898};\\\", \\\"{x:1216,y:860,t:1527188910914};\\\", \\\"{x:1217,y:869,t:1527188910931};\\\", \\\"{x:1217,y:876,t:1527188910948};\\\", \\\"{x:1221,y:885,t:1527188910964};\\\", \\\"{x:1226,y:896,t:1527188910981};\\\", \\\"{x:1231,y:905,t:1527188910998};\\\", \\\"{x:1235,y:912,t:1527188911014};\\\", \\\"{x:1238,y:918,t:1527188911031};\\\", \\\"{x:1242,y:925,t:1527188911047};\\\", \\\"{x:1247,y:932,t:1527188911064};\\\", \\\"{x:1260,y:944,t:1527188911081};\\\", \\\"{x:1276,y:954,t:1527188911098};\\\", \\\"{x:1291,y:961,t:1527188911115};\\\", \\\"{x:1307,y:968,t:1527188911131};\\\", \\\"{x:1325,y:973,t:1527188911148};\\\", \\\"{x:1346,y:979,t:1527188911164};\\\", \\\"{x:1365,y:984,t:1527188911181};\\\", \\\"{x:1380,y:987,t:1527188911199};\\\", \\\"{x:1394,y:988,t:1527188911215};\\\", \\\"{x:1407,y:989,t:1527188911231};\\\", \\\"{x:1418,y:989,t:1527188911247};\\\", \\\"{x:1432,y:989,t:1527188911264};\\\", \\\"{x:1440,y:989,t:1527188911280};\\\", \\\"{x:1443,y:989,t:1527188911297};\\\", \\\"{x:1444,y:989,t:1527188911457};\\\", \\\"{x:1444,y:988,t:1527188911497};\\\", \\\"{x:1444,y:987,t:1527188911515};\\\", \\\"{x:1442,y:985,t:1527188911532};\\\", \\\"{x:1441,y:984,t:1527188911548};\\\", \\\"{x:1440,y:984,t:1527188911569};\\\", \\\"{x:1438,y:983,t:1527188911609};\\\", \\\"{x:1437,y:982,t:1527188911624};\\\", \\\"{x:1436,y:982,t:1527188911721};\\\", \\\"{x:1434,y:982,t:1527188911737};\\\", \\\"{x:1431,y:982,t:1527188911748};\\\", \\\"{x:1426,y:982,t:1527188911765};\\\", \\\"{x:1422,y:981,t:1527188911782};\\\", \\\"{x:1420,y:980,t:1527188911798};\\\", \\\"{x:1418,y:979,t:1527188912017};\\\", \\\"{x:1418,y:978,t:1527188912032};\\\", \\\"{x:1418,y:976,t:1527188912048};\\\", \\\"{x:1418,y:973,t:1527188912065};\\\", \\\"{x:1418,y:972,t:1527188912081};\\\", \\\"{x:1417,y:972,t:1527188912193};\\\", \\\"{x:1415,y:969,t:1527188912201};\\\", \\\"{x:1414,y:969,t:1527188912217};\\\", \\\"{x:1414,y:968,t:1527188912730};\\\", \\\"{x:1413,y:968,t:1527188913450};\\\", \\\"{x:1393,y:952,t:1527188913467};\\\", \\\"{x:1337,y:925,t:1527188913483};\\\", \\\"{x:1223,y:892,t:1527188913500};\\\", \\\"{x:1097,y:863,t:1527188913516};\\\", \\\"{x:961,y:839,t:1527188913534};\\\", \\\"{x:821,y:807,t:1527188913549};\\\", \\\"{x:683,y:768,t:1527188913566};\\\", \\\"{x:553,y:734,t:1527188913584};\\\", \\\"{x:454,y:708,t:1527188913599};\\\", \\\"{x:390,y:689,t:1527188913616};\\\", \\\"{x:354,y:677,t:1527188913633};\\\", \\\"{x:351,y:675,t:1527188913649};\\\", \\\"{x:349,y:672,t:1527188913667};\\\", \\\"{x:349,y:662,t:1527188913683};\\\", \\\"{x:349,y:653,t:1527188913699};\\\", \\\"{x:349,y:640,t:1527188913718};\\\", \\\"{x:349,y:625,t:1527188913733};\\\", \\\"{x:347,y:610,t:1527188913750};\\\", \\\"{x:344,y:593,t:1527188913766};\\\", \\\"{x:342,y:573,t:1527188913785};\\\", \\\"{x:342,y:556,t:1527188913799};\\\", \\\"{x:347,y:529,t:1527188913817};\\\", \\\"{x:354,y:518,t:1527188913834};\\\", \\\"{x:363,y:504,t:1527188913850};\\\", \\\"{x:375,y:490,t:1527188913867};\\\", \\\"{x:394,y:479,t:1527188913884};\\\", \\\"{x:419,y:474,t:1527188913900};\\\", \\\"{x:452,y:470,t:1527188913917};\\\", \\\"{x:490,y:470,t:1527188913933};\\\", \\\"{x:545,y:474,t:1527188913951};\\\", \\\"{x:600,y:490,t:1527188913967};\\\", \\\"{x:645,y:504,t:1527188913984};\\\", \\\"{x:670,y:518,t:1527188914001};\\\", \\\"{x:671,y:519,t:1527188914016};\\\", \\\"{x:671,y:521,t:1527188914033};\\\", \\\"{x:671,y:522,t:1527188914051};\\\", \\\"{x:669,y:527,t:1527188914066};\\\", \\\"{x:667,y:529,t:1527188914083};\\\", \\\"{x:664,y:532,t:1527188914100};\\\", \\\"{x:660,y:540,t:1527188914118};\\\", \\\"{x:657,y:550,t:1527188914135};\\\", \\\"{x:655,y:558,t:1527188914151};\\\", \\\"{x:654,y:562,t:1527188914167};\\\", \\\"{x:653,y:563,t:1527188914183};\\\", \\\"{x:652,y:566,t:1527188914200};\\\", \\\"{x:651,y:570,t:1527188914217};\\\", \\\"{x:648,y:576,t:1527188914235};\\\", \\\"{x:648,y:582,t:1527188914252};\\\", \\\"{x:647,y:585,t:1527188914267};\\\", \\\"{x:646,y:585,t:1527188914283};\\\", \\\"{x:646,y:586,t:1527188914328};\\\", \\\"{x:644,y:586,t:1527188914335};\\\", \\\"{x:643,y:586,t:1527188914350};\\\", \\\"{x:641,y:586,t:1527188914367};\\\", \\\"{x:635,y:587,t:1527188914383};\\\", \\\"{x:628,y:589,t:1527188914399};\\\", \\\"{x:618,y:593,t:1527188914418};\\\", \\\"{x:610,y:594,t:1527188914433};\\\", \\\"{x:603,y:597,t:1527188914450};\\\", \\\"{x:595,y:601,t:1527188914468};\\\", \\\"{x:592,y:602,t:1527188914483};\\\", \\\"{x:589,y:604,t:1527188914501};\\\", \\\"{x:588,y:604,t:1527188914517};\\\", \\\"{x:589,y:604,t:1527188914745};\\\", \\\"{x:590,y:604,t:1527188914752};\\\", \\\"{x:591,y:604,t:1527188914767};\\\", \\\"{x:593,y:604,t:1527188914784};\\\", \\\"{x:594,y:604,t:1527188914801};\\\", \\\"{x:595,y:604,t:1527188914840};\\\", \\\"{x:596,y:604,t:1527188914856};\\\", \\\"{x:597,y:604,t:1527188914889};\\\", \\\"{x:597,y:603,t:1527188915193};\\\", \\\"{x:600,y:600,t:1527188915296};\\\", \\\"{x:601,y:600,t:1527188915320};\\\", \\\"{x:601,y:599,t:1527188915916};\\\", \\\"{x:602,y:599,t:1527188916020};\\\", \\\"{x:603,y:599,t:1527188916028};\\\", \\\"{x:604,y:599,t:1527188916043};\\\", \\\"{x:606,y:599,t:1527188916083};\\\", \\\"{x:607,y:599,t:1527188916099};\\\", \\\"{x:609,y:599,t:1527188916115};\\\", \\\"{x:610,y:599,t:1527188916132};\\\", \\\"{x:613,y:599,t:1527188916140};\\\", \\\"{x:615,y:599,t:1527188916155};\\\", \\\"{x:617,y:600,t:1527188916171};\\\", \\\"{x:621,y:601,t:1527188916189};\\\", \\\"{x:622,y:601,t:1527188916205};\\\", \\\"{x:623,y:602,t:1527188916222};\\\", \\\"{x:623,y:601,t:1527188916524};\\\", \\\"{x:621,y:601,t:1527188916538};\\\", \\\"{x:620,y:600,t:1527188916868};\\\", \\\"{x:618,y:598,t:1527188916884};\\\", \\\"{x:615,y:598,t:1527188916892};\\\", \\\"{x:611,y:598,t:1527188916905};\\\", \\\"{x:603,y:598,t:1527188916922};\\\", \\\"{x:594,y:598,t:1527188916940};\\\", \\\"{x:590,y:597,t:1527188916955};\\\", \\\"{x:589,y:597,t:1527188916971};\\\", \\\"{x:592,y:597,t:1527188917156};\\\", \\\"{x:595,y:597,t:1527188917173};\\\", \\\"{x:599,y:597,t:1527188917189};\\\", \\\"{x:600,y:597,t:1527188917206};\\\", \\\"{x:602,y:597,t:1527188917300};\\\", \\\"{x:603,y:597,t:1527188917307};\\\", \\\"{x:604,y:597,t:1527188917322};\\\", \\\"{x:606,y:597,t:1527188917339};\\\", \\\"{x:607,y:597,t:1527188917356};\\\", \\\"{x:608,y:597,t:1527188917988};\\\", \\\"{x:613,y:599,t:1527188917996};\\\", \\\"{x:621,y:601,t:1527188918008};\\\", \\\"{x:644,y:610,t:1527188918024};\\\", \\\"{x:666,y:617,t:1527188918040};\\\", \\\"{x:683,y:620,t:1527188918056};\\\", \\\"{x:696,y:622,t:1527188918072};\\\", \\\"{x:705,y:623,t:1527188918089};\\\", \\\"{x:706,y:623,t:1527188920323};\\\", \\\"{x:704,y:627,t:1527188920331};\\\", \\\"{x:695,y:629,t:1527188920342};\\\", \\\"{x:669,y:634,t:1527188920358};\\\", \\\"{x:639,y:637,t:1527188920375};\\\", \\\"{x:599,y:641,t:1527188920392};\\\", \\\"{x:564,y:641,t:1527188920409};\\\", \\\"{x:533,y:641,t:1527188920425};\\\", \\\"{x:501,y:635,t:1527188920442};\\\", \\\"{x:475,y:624,t:1527188920459};\\\", \\\"{x:468,y:621,t:1527188920474};\\\", \\\"{x:466,y:619,t:1527188920492};\\\", \\\"{x:463,y:616,t:1527188920509};\\\", \\\"{x:462,y:615,t:1527188920525};\\\", \\\"{x:458,y:611,t:1527188920542};\\\", \\\"{x:453,y:604,t:1527188920559};\\\", \\\"{x:443,y:596,t:1527188920575};\\\", \\\"{x:424,y:583,t:1527188920592};\\\", \\\"{x:399,y:571,t:1527188920609};\\\", \\\"{x:369,y:558,t:1527188920625};\\\", \\\"{x:343,y:551,t:1527188920642};\\\", \\\"{x:314,y:542,t:1527188920660};\\\", \\\"{x:305,y:541,t:1527188920675};\\\", \\\"{x:302,y:540,t:1527188920692};\\\", \\\"{x:300,y:540,t:1527188920709};\\\", \\\"{x:297,y:540,t:1527188920724};\\\", \\\"{x:288,y:540,t:1527188920742};\\\", \\\"{x:274,y:540,t:1527188920759};\\\", \\\"{x:259,y:540,t:1527188920774};\\\", \\\"{x:246,y:540,t:1527188920792};\\\", \\\"{x:231,y:540,t:1527188920809};\\\", \\\"{x:221,y:537,t:1527188920826};\\\", \\\"{x:220,y:537,t:1527188920842};\\\", \\\"{x:219,y:536,t:1527188920860};\\\", \\\"{x:217,y:536,t:1527188920899};\\\", \\\"{x:216,y:536,t:1527188920915};\\\", \\\"{x:213,y:536,t:1527188920925};\\\", \\\"{x:208,y:536,t:1527188920942};\\\", \\\"{x:200,y:536,t:1527188920959};\\\", \\\"{x:193,y:537,t:1527188920977};\\\", \\\"{x:189,y:537,t:1527188920992};\\\", \\\"{x:187,y:538,t:1527188921008};\\\", \\\"{x:185,y:538,t:1527188921026};\\\", \\\"{x:184,y:538,t:1527188921042};\\\", \\\"{x:183,y:539,t:1527188921059};\\\", \\\"{x:183,y:540,t:1527188921075};\\\", \\\"{x:182,y:541,t:1527188921092};\\\", \\\"{x:179,y:543,t:1527188921108};\\\", \\\"{x:178,y:544,t:1527188921127};\\\", \\\"{x:175,y:547,t:1527188921142};\\\", \\\"{x:173,y:549,t:1527188921159};\\\", \\\"{x:171,y:551,t:1527188921176};\\\", \\\"{x:169,y:557,t:1527188921192};\\\", \\\"{x:169,y:564,t:1527188921209};\\\", \\\"{x:172,y:570,t:1527188921226};\\\", \\\"{x:188,y:577,t:1527188921243};\\\", \\\"{x:228,y:587,t:1527188921260};\\\", \\\"{x:268,y:588,t:1527188921276};\\\", \\\"{x:321,y:588,t:1527188921293};\\\", \\\"{x:364,y:590,t:1527188921309};\\\", \\\"{x:393,y:590,t:1527188921326};\\\", \\\"{x:411,y:589,t:1527188921343};\\\", \\\"{x:417,y:587,t:1527188921359};\\\", \\\"{x:418,y:586,t:1527188921376};\\\", \\\"{x:420,y:585,t:1527188921411};\\\", \\\"{x:420,y:584,t:1527188921451};\\\", \\\"{x:420,y:581,t:1527188921460};\\\", \\\"{x:420,y:578,t:1527188921475};\\\", \\\"{x:420,y:573,t:1527188921493};\\\", \\\"{x:419,y:569,t:1527188921509};\\\", \\\"{x:414,y:563,t:1527188921526};\\\", \\\"{x:408,y:557,t:1527188921542};\\\", \\\"{x:399,y:554,t:1527188921558};\\\", \\\"{x:394,y:554,t:1527188921576};\\\", \\\"{x:385,y:554,t:1527188921593};\\\", \\\"{x:378,y:554,t:1527188921609};\\\", \\\"{x:374,y:554,t:1527188921626};\\\", \\\"{x:367,y:559,t:1527188921643};\\\", \\\"{x:365,y:563,t:1527188921659};\\\", \\\"{x:363,y:567,t:1527188921676};\\\", \\\"{x:362,y:573,t:1527188921693};\\\", \\\"{x:362,y:580,t:1527188921709};\\\", \\\"{x:362,y:586,t:1527188921726};\\\", \\\"{x:362,y:592,t:1527188921743};\\\", \\\"{x:363,y:598,t:1527188921759};\\\", \\\"{x:366,y:607,t:1527188921776};\\\", \\\"{x:367,y:611,t:1527188921793};\\\", \\\"{x:368,y:615,t:1527188921810};\\\", \\\"{x:370,y:616,t:1527188921826};\\\", \\\"{x:370,y:619,t:1527188921996};\\\", \\\"{x:361,y:619,t:1527188922011};\\\", \\\"{x:328,y:624,t:1527188922029};\\\", \\\"{x:301,y:625,t:1527188922043};\\\", \\\"{x:277,y:625,t:1527188922060};\\\", \\\"{x:261,y:627,t:1527188922076};\\\", \\\"{x:255,y:627,t:1527188922093};\\\", \\\"{x:254,y:628,t:1527188922109};\\\", \\\"{x:253,y:629,t:1527188922125};\\\", \\\"{x:253,y:630,t:1527188922143};\\\", \\\"{x:252,y:632,t:1527188922160};\\\", \\\"{x:252,y:633,t:1527188922176};\\\", \\\"{x:249,y:636,t:1527188922193};\\\", \\\"{x:244,y:639,t:1527188922210};\\\", \\\"{x:241,y:642,t:1527188922226};\\\", \\\"{x:236,y:645,t:1527188922243};\\\", \\\"{x:234,y:647,t:1527188922259};\\\", \\\"{x:229,y:647,t:1527188922276};\\\", \\\"{x:221,y:649,t:1527188922293};\\\", \\\"{x:214,y:650,t:1527188922310};\\\", \\\"{x:206,y:650,t:1527188922326};\\\", \\\"{x:197,y:650,t:1527188922343};\\\", \\\"{x:188,y:650,t:1527188922360};\\\", \\\"{x:179,y:650,t:1527188922376};\\\", \\\"{x:173,y:649,t:1527188922393};\\\", \\\"{x:168,y:648,t:1527188922410};\\\", \\\"{x:164,y:648,t:1527188922427};\\\", \\\"{x:162,y:646,t:1527188922444};\\\", \\\"{x:161,y:646,t:1527188922460};\\\", \\\"{x:159,y:645,t:1527188922507};\\\", \\\"{x:159,y:644,t:1527188922515};\\\", \\\"{x:157,y:642,t:1527188922527};\\\", \\\"{x:156,y:641,t:1527188922547};\\\", \\\"{x:155,y:641,t:1527188928548};\\\", \\\"{x:155,y:640,t:1527188936228};\\\", \\\"{x:165,y:639,t:1527188936238};\\\", \\\"{x:224,y:649,t:1527188936255};\\\", \\\"{x:308,y:662,t:1527188936272};\\\", \\\"{x:390,y:683,t:1527188936288};\\\", \\\"{x:463,y:705,t:1527188936305};\\\", \\\"{x:503,y:719,t:1527188936321};\\\", \\\"{x:533,y:732,t:1527188936337};\\\", \\\"{x:566,y:746,t:1527188936355};\\\", \\\"{x:593,y:757,t:1527188936371};\\\", \\\"{x:619,y:768,t:1527188936388};\\\", \\\"{x:637,y:775,t:1527188936404};\\\", \\\"{x:649,y:778,t:1527188936422};\\\", \\\"{x:655,y:779,t:1527188936439};\\\", \\\"{x:656,y:779,t:1527188936455};\\\", \\\"{x:647,y:779,t:1527188936532};\\\", \\\"{x:636,y:774,t:1527188936539};\\\", \\\"{x:599,y:758,t:1527188936556};\\\", \\\"{x:563,y:743,t:1527188936571};\\\", \\\"{x:528,y:729,t:1527188936590};\\\", \\\"{x:509,y:722,t:1527188936605};\\\", \\\"{x:500,y:718,t:1527188936621};\\\", \\\"{x:498,y:718,t:1527188936638};\\\", \\\"{x:495,y:717,t:1527188937515};\\\", \\\"{x:490,y:714,t:1527188937523};\\\", \\\"{x:489,y:713,t:1527188937539};\\\", \\\"{x:488,y:713,t:1527188937556};\\\" ] }, { \\\"rt\\\": 74878, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 397119, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:702,t:1527188978573};\\\", \\\"{x:525,y:689,t:1527188978581};\\\", \\\"{x:554,y:677,t:1527188978590};\\\", \\\"{x:628,y:646,t:1527188978608};\\\", \\\"{x:725,y:599,t:1527188978626};\\\", \\\"{x:813,y:562,t:1527188978642};\\\", \\\"{x:881,y:525,t:1527188978659};\\\", \\\"{x:938,y:494,t:1527188978676};\\\", \\\"{x:964,y:479,t:1527188978692};\\\", \\\"{x:979,y:470,t:1527188978709};\\\", \\\"{x:981,y:467,t:1527188978726};\\\", \\\"{x:981,y:466,t:1527188978798};\\\", \\\"{x:980,y:466,t:1527188978808};\\\", \\\"{x:976,y:463,t:1527188978825};\\\", \\\"{x:963,y:458,t:1527188978842};\\\", \\\"{x:938,y:453,t:1527188978858};\\\", \\\"{x:902,y:453,t:1527188978876};\\\", \\\"{x:852,y:464,t:1527188978893};\\\", \\\"{x:794,y:481,t:1527188978909};\\\", \\\"{x:718,y:503,t:1527188978926};\\\", \\\"{x:694,y:512,t:1527188978943};\\\", \\\"{x:684,y:517,t:1527188978959};\\\", \\\"{x:683,y:518,t:1527188978976};\\\", \\\"{x:683,y:521,t:1527188978993};\\\", \\\"{x:684,y:527,t:1527188979009};\\\", \\\"{x:685,y:533,t:1527188979026};\\\", \\\"{x:685,y:539,t:1527188979044};\\\", \\\"{x:684,y:545,t:1527188979060};\\\", \\\"{x:684,y:550,t:1527188979076};\\\", \\\"{x:684,y:556,t:1527188979093};\\\", \\\"{x:684,y:561,t:1527188979108};\\\", \\\"{x:683,y:565,t:1527188979125};\\\", \\\"{x:682,y:567,t:1527188979143};\\\", \\\"{x:681,y:567,t:1527188979160};\\\", \\\"{x:677,y:567,t:1527188979175};\\\", \\\"{x:675,y:567,t:1527188979192};\\\", \\\"{x:670,y:567,t:1527188979210};\\\", \\\"{x:662,y:567,t:1527188979226};\\\", \\\"{x:650,y:564,t:1527188979242};\\\", \\\"{x:641,y:561,t:1527188979260};\\\", \\\"{x:639,y:560,t:1527188979276};\\\", \\\"{x:637,y:560,t:1527188979293};\\\", \\\"{x:635,y:559,t:1527188979309};\\\", \\\"{x:633,y:559,t:1527188979325};\\\", \\\"{x:631,y:559,t:1527188979343};\\\", \\\"{x:627,y:559,t:1527188979360};\\\", \\\"{x:623,y:559,t:1527188979375};\\\", \\\"{x:619,y:559,t:1527188979393};\\\", \\\"{x:616,y:559,t:1527188979410};\\\", \\\"{x:614,y:559,t:1527188979426};\\\", \\\"{x:613,y:559,t:1527188979503};\\\", \\\"{x:612,y:558,t:1527188979510};\\\", \\\"{x:611,y:557,t:1527188979543};\\\", \\\"{x:608,y:561,t:1527189012479};\\\", \\\"{x:593,y:577,t:1527189012488};\\\", \\\"{x:571,y:605,t:1527189012503};\\\", \\\"{x:553,y:627,t:1527189012520};\\\", \\\"{x:541,y:644,t:1527189012536};\\\", \\\"{x:532,y:657,t:1527189012554};\\\", \\\"{x:530,y:660,t:1527189012569};\\\", \\\"{x:529,y:661,t:1527189012586};\\\", \\\"{x:529,y:663,t:1527189012637};\\\", \\\"{x:528,y:667,t:1527189012653};\\\", \\\"{x:528,y:670,t:1527189012669};\\\", \\\"{x:527,y:671,t:1527189012687};\\\", \\\"{x:527,y:672,t:1527189012709};\\\", \\\"{x:527,y:674,t:1527189012720};\\\", \\\"{x:527,y:681,t:1527189012736};\\\", \\\"{x:527,y:687,t:1527189012754};\\\", \\\"{x:527,y:694,t:1527189012769};\\\", \\\"{x:527,y:701,t:1527189012787};\\\", \\\"{x:528,y:705,t:1527189012802};\\\", \\\"{x:528,y:706,t:1527189012819};\\\", \\\"{x:528,y:708,t:1527189012836};\\\", \\\"{x:528,y:711,t:1527189012853};\\\", \\\"{x:528,y:715,t:1527189012869};\\\", \\\"{x:528,y:720,t:1527189012886};\\\", \\\"{x:528,y:727,t:1527189012904};\\\", \\\"{x:528,y:732,t:1527189012920};\\\", \\\"{x:528,y:735,t:1527189012936};\\\", \\\"{x:529,y:735,t:1527189014158};\\\" ] }, { \\\"rt\\\": 88609, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 487265, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -03 PM-03 PM-10 AM-11 AM-11 AM-11 AM-12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:728,t:1527189022086};\\\", \\\"{x:578,y:679,t:1527189022097};\\\", \\\"{x:688,y:581,t:1527189022111};\\\", \\\"{x:789,y:521,t:1527189022128};\\\", \\\"{x:900,y:469,t:1527189022144};\\\", \\\"{x:991,y:429,t:1527189022161};\\\", \\\"{x:1055,y:403,t:1527189022178};\\\", \\\"{x:1104,y:391,t:1527189022194};\\\", \\\"{x:1160,y:376,t:1527189022210};\\\", \\\"{x:1221,y:366,t:1527189022228};\\\", \\\"{x:1280,y:358,t:1527189022244};\\\", \\\"{x:1333,y:352,t:1527189022261};\\\", \\\"{x:1396,y:347,t:1527189022277};\\\", \\\"{x:1419,y:347,t:1527189022294};\\\", \\\"{x:1438,y:347,t:1527189022310};\\\", \\\"{x:1447,y:346,t:1527189022328};\\\", \\\"{x:1448,y:346,t:1527189022343};\\\", \\\"{x:1451,y:349,t:1527189022361};\\\", \\\"{x:1456,y:377,t:1527189022377};\\\", \\\"{x:1464,y:419,t:1527189022395};\\\", \\\"{x:1465,y:445,t:1527189022411};\\\", \\\"{x:1465,y:464,t:1527189022428};\\\", \\\"{x:1465,y:479,t:1527189022444};\\\", \\\"{x:1465,y:485,t:1527189022460};\\\", \\\"{x:1465,y:487,t:1527189022485};\\\", \\\"{x:1464,y:489,t:1527189022502};\\\", \\\"{x:1460,y:492,t:1527189022511};\\\", \\\"{x:1451,y:502,t:1527189022528};\\\", \\\"{x:1442,y:513,t:1527189022545};\\\", \\\"{x:1435,y:518,t:1527189022561};\\\", \\\"{x:1425,y:525,t:1527189022578};\\\", \\\"{x:1416,y:533,t:1527189022595};\\\", \\\"{x:1402,y:539,t:1527189022611};\\\", \\\"{x:1385,y:541,t:1527189022628};\\\", \\\"{x:1363,y:541,t:1527189022644};\\\", \\\"{x:1343,y:541,t:1527189022661};\\\", \\\"{x:1322,y:543,t:1527189022678};\\\", \\\"{x:1308,y:543,t:1527189022695};\\\", \\\"{x:1303,y:543,t:1527189022711};\\\", \\\"{x:1297,y:542,t:1527189022728};\\\", \\\"{x:1296,y:541,t:1527189022745};\\\", \\\"{x:1295,y:540,t:1527189022766};\\\", \\\"{x:1295,y:538,t:1527189022781};\\\", \\\"{x:1295,y:536,t:1527189022795};\\\", \\\"{x:1295,y:533,t:1527189022812};\\\", \\\"{x:1295,y:531,t:1527189022829};\\\", \\\"{x:1295,y:530,t:1527189022854};\\\", \\\"{x:1295,y:529,t:1527189022861};\\\", \\\"{x:1296,y:527,t:1527189022878};\\\", \\\"{x:1297,y:525,t:1527189022896};\\\", \\\"{x:1300,y:522,t:1527189022912};\\\", \\\"{x:1303,y:519,t:1527189022928};\\\", \\\"{x:1304,y:517,t:1527189022945};\\\", \\\"{x:1305,y:515,t:1527189022962};\\\", \\\"{x:1306,y:515,t:1527189022979};\\\", \\\"{x:1307,y:514,t:1527189022998};\\\", \\\"{x:1308,y:512,t:1527189023047};\\\", \\\"{x:1309,y:509,t:1527189023062};\\\", \\\"{x:1310,y:508,t:1527189023079};\\\", \\\"{x:1310,y:506,t:1527189024517};\\\", \\\"{x:1310,y:503,t:1527189024529};\\\", \\\"{x:1310,y:501,t:1527189024546};\\\", \\\"{x:1310,y:499,t:1527189024564};\\\", \\\"{x:1311,y:498,t:1527189024579};\\\", \\\"{x:1311,y:496,t:1527189024606};\\\", \\\"{x:1311,y:497,t:1527189025222};\\\", \\\"{x:1311,y:499,t:1527189025230};\\\", \\\"{x:1311,y:502,t:1527189025248};\\\", \\\"{x:1311,y:506,t:1527189025264};\\\", \\\"{x:1310,y:508,t:1527189025281};\\\", \\\"{x:1310,y:512,t:1527189025297};\\\", \\\"{x:1309,y:515,t:1527189025313};\\\", \\\"{x:1308,y:520,t:1527189025331};\\\", \\\"{x:1308,y:523,t:1527189025348};\\\", \\\"{x:1308,y:526,t:1527189025363};\\\", \\\"{x:1307,y:529,t:1527189025380};\\\", \\\"{x:1306,y:531,t:1527189025398};\\\", \\\"{x:1306,y:533,t:1527189025414};\\\", \\\"{x:1306,y:534,t:1527189025430};\\\", \\\"{x:1306,y:535,t:1527189025447};\\\", \\\"{x:1306,y:537,t:1527189025464};\\\", \\\"{x:1306,y:538,t:1527189025480};\\\", \\\"{x:1306,y:539,t:1527189025497};\\\", \\\"{x:1306,y:541,t:1527189025514};\\\", \\\"{x:1306,y:542,t:1527189025534};\\\", \\\"{x:1306,y:543,t:1527189025548};\\\", \\\"{x:1306,y:544,t:1527189025564};\\\", \\\"{x:1306,y:545,t:1527189025590};\\\", \\\"{x:1306,y:547,t:1527189025606};\\\", \\\"{x:1306,y:548,t:1527189025614};\\\", \\\"{x:1306,y:549,t:1527189025630};\\\", \\\"{x:1306,y:551,t:1527189025648};\\\", \\\"{x:1306,y:552,t:1527189025665};\\\", \\\"{x:1306,y:554,t:1527189025681};\\\", \\\"{x:1306,y:556,t:1527189025697};\\\", \\\"{x:1306,y:560,t:1527189025714};\\\", \\\"{x:1306,y:565,t:1527189025731};\\\", \\\"{x:1308,y:574,t:1527189025747};\\\", \\\"{x:1310,y:583,t:1527189025764};\\\", \\\"{x:1314,y:593,t:1527189025780};\\\", \\\"{x:1317,y:605,t:1527189025798};\\\", \\\"{x:1321,y:615,t:1527189025814};\\\", \\\"{x:1324,y:624,t:1527189025831};\\\", \\\"{x:1327,y:632,t:1527189025847};\\\", \\\"{x:1330,y:637,t:1527189025865};\\\", \\\"{x:1334,y:642,t:1527189025880};\\\", \\\"{x:1337,y:647,t:1527189025897};\\\", \\\"{x:1341,y:654,t:1527189025915};\\\", \\\"{x:1345,y:661,t:1527189025930};\\\", \\\"{x:1347,y:665,t:1527189025947};\\\", \\\"{x:1350,y:670,t:1527189025965};\\\", \\\"{x:1353,y:674,t:1527189025981};\\\", \\\"{x:1360,y:682,t:1527189025997};\\\", \\\"{x:1370,y:693,t:1527189026014};\\\", \\\"{x:1380,y:701,t:1527189026030};\\\", \\\"{x:1394,y:713,t:1527189026046};\\\", \\\"{x:1411,y:727,t:1527189026064};\\\", \\\"{x:1432,y:740,t:1527189026080};\\\", \\\"{x:1462,y:765,t:1527189026097};\\\", \\\"{x:1500,y:797,t:1527189026114};\\\", \\\"{x:1524,y:817,t:1527189026131};\\\", \\\"{x:1538,y:828,t:1527189026146};\\\", \\\"{x:1540,y:832,t:1527189026164};\\\", \\\"{x:1542,y:834,t:1527189026180};\\\", \\\"{x:1542,y:835,t:1527189026318};\\\", \\\"{x:1542,y:838,t:1527189026331};\\\", \\\"{x:1540,y:847,t:1527189026347};\\\", \\\"{x:1537,y:856,t:1527189026364};\\\", \\\"{x:1531,y:870,t:1527189026381};\\\", \\\"{x:1529,y:878,t:1527189026397};\\\", \\\"{x:1526,y:887,t:1527189026414};\\\", \\\"{x:1525,y:895,t:1527189026431};\\\", \\\"{x:1525,y:905,t:1527189026448};\\\", \\\"{x:1525,y:916,t:1527189026463};\\\", \\\"{x:1525,y:922,t:1527189026482};\\\", \\\"{x:1525,y:928,t:1527189026497};\\\", \\\"{x:1525,y:933,t:1527189026515};\\\", \\\"{x:1525,y:937,t:1527189026531};\\\", \\\"{x:1525,y:946,t:1527189026548};\\\", \\\"{x:1525,y:954,t:1527189026565};\\\", \\\"{x:1526,y:962,t:1527189026581};\\\", \\\"{x:1527,y:963,t:1527189026606};\\\", \\\"{x:1528,y:965,t:1527189026615};\\\", \\\"{x:1531,y:967,t:1527189026631};\\\", \\\"{x:1532,y:968,t:1527189026648};\\\", \\\"{x:1534,y:969,t:1527189026664};\\\", \\\"{x:1535,y:969,t:1527189026693};\\\", \\\"{x:1536,y:970,t:1527189026702};\\\", \\\"{x:1538,y:972,t:1527189026714};\\\", \\\"{x:1541,y:974,t:1527189026731};\\\", \\\"{x:1544,y:978,t:1527189026749};\\\", \\\"{x:1545,y:980,t:1527189026764};\\\", \\\"{x:1547,y:981,t:1527189026781};\\\", \\\"{x:1547,y:982,t:1527189026798};\\\", \\\"{x:1547,y:980,t:1527189027046};\\\", \\\"{x:1548,y:978,t:1527189027054};\\\", \\\"{x:1548,y:977,t:1527189027066};\\\", \\\"{x:1548,y:976,t:1527189027081};\\\", \\\"{x:1548,y:975,t:1527189027098};\\\", \\\"{x:1548,y:974,t:1527189027230};\\\", \\\"{x:1548,y:972,t:1527189027238};\\\", \\\"{x:1548,y:970,t:1527189027248};\\\", \\\"{x:1548,y:969,t:1527189027270};\\\", \\\"{x:1548,y:967,t:1527189027294};\\\", \\\"{x:1548,y:966,t:1527189027310};\\\", \\\"{x:1548,y:967,t:1527189033526};\\\", \\\"{x:1551,y:972,t:1527189033537};\\\", \\\"{x:1555,y:979,t:1527189033553};\\\", \\\"{x:1557,y:983,t:1527189033571};\\\", \\\"{x:1559,y:987,t:1527189033587};\\\", \\\"{x:1558,y:988,t:1527189037849};\\\", \\\"{x:1545,y:989,t:1527189037860};\\\", \\\"{x:1520,y:994,t:1527189037877};\\\", \\\"{x:1486,y:1008,t:1527189037894};\\\", \\\"{x:1446,y:1020,t:1527189037911};\\\", \\\"{x:1405,y:1036,t:1527189037928};\\\", \\\"{x:1383,y:1047,t:1527189037945};\\\", \\\"{x:1370,y:1053,t:1527189037960};\\\", \\\"{x:1364,y:1056,t:1527189037977};\\\", \\\"{x:1361,y:1058,t:1527189037994};\\\", \\\"{x:1359,y:1059,t:1527189038010};\\\", \\\"{x:1351,y:1064,t:1527189038028};\\\", \\\"{x:1344,y:1066,t:1527189038044};\\\", \\\"{x:1337,y:1069,t:1527189038060};\\\", \\\"{x:1324,y:1073,t:1527189038077};\\\", \\\"{x:1301,y:1077,t:1527189038095};\\\", \\\"{x:1277,y:1077,t:1527189038110};\\\", \\\"{x:1251,y:1076,t:1527189038127};\\\", \\\"{x:1221,y:1063,t:1527189038144};\\\", \\\"{x:1183,y:1033,t:1527189038161};\\\", \\\"{x:1142,y:1002,t:1527189038177};\\\", \\\"{x:1122,y:988,t:1527189038195};\\\", \\\"{x:1100,y:966,t:1527189038211};\\\", \\\"{x:1080,y:949,t:1527189038227};\\\", \\\"{x:1070,y:940,t:1527189038245};\\\", \\\"{x:1067,y:935,t:1527189038260};\\\", \\\"{x:1066,y:934,t:1527189038277};\\\", \\\"{x:1068,y:934,t:1527189038337};\\\", \\\"{x:1069,y:934,t:1527189038345};\\\", \\\"{x:1072,y:934,t:1527189038361};\\\", \\\"{x:1088,y:934,t:1527189038377};\\\", \\\"{x:1103,y:934,t:1527189038394};\\\", \\\"{x:1118,y:937,t:1527189038411};\\\", \\\"{x:1134,y:942,t:1527189038428};\\\", \\\"{x:1151,y:953,t:1527189038444};\\\", \\\"{x:1167,y:964,t:1527189038461};\\\", \\\"{x:1182,y:974,t:1527189038477};\\\", \\\"{x:1190,y:980,t:1527189038494};\\\", \\\"{x:1193,y:983,t:1527189038511};\\\", \\\"{x:1195,y:984,t:1527189038527};\\\", \\\"{x:1196,y:984,t:1527189038713};\\\", \\\"{x:1197,y:983,t:1527189038727};\\\", \\\"{x:1199,y:980,t:1527189038745};\\\", \\\"{x:1200,y:976,t:1527189038760};\\\", \\\"{x:1201,y:975,t:1527189038778};\\\", \\\"{x:1201,y:972,t:1527189038794};\\\", \\\"{x:1201,y:970,t:1527189038812};\\\", \\\"{x:1203,y:967,t:1527189038829};\\\", \\\"{x:1204,y:964,t:1527189038845};\\\", \\\"{x:1206,y:962,t:1527189038861};\\\", \\\"{x:1208,y:959,t:1527189038878};\\\", \\\"{x:1208,y:958,t:1527189038894};\\\", \\\"{x:1209,y:958,t:1527189039034};\\\", \\\"{x:1210,y:958,t:1527189039044};\\\", \\\"{x:1211,y:958,t:1527189039061};\\\", \\\"{x:1214,y:958,t:1527189039078};\\\", \\\"{x:1216,y:958,t:1527189039094};\\\", \\\"{x:1219,y:959,t:1527189039111};\\\", \\\"{x:1221,y:960,t:1527189039129};\\\", \\\"{x:1223,y:961,t:1527189039145};\\\", \\\"{x:1224,y:961,t:1527189039161};\\\", \\\"{x:1225,y:961,t:1527189039193};\\\", \\\"{x:1225,y:962,t:1527189039201};\\\", \\\"{x:1227,y:962,t:1527189039217};\\\", \\\"{x:1228,y:962,t:1527189039233};\\\", \\\"{x:1229,y:963,t:1527189039245};\\\", \\\"{x:1233,y:963,t:1527189039262};\\\", \\\"{x:1239,y:967,t:1527189039278};\\\", \\\"{x:1248,y:968,t:1527189039295};\\\", \\\"{x:1255,y:971,t:1527189039312};\\\", \\\"{x:1262,y:972,t:1527189039328};\\\", \\\"{x:1273,y:972,t:1527189039345};\\\", \\\"{x:1282,y:969,t:1527189039362};\\\", \\\"{x:1288,y:967,t:1527189039378};\\\", \\\"{x:1290,y:965,t:1527189039396};\\\", \\\"{x:1292,y:965,t:1527189039412};\\\", \\\"{x:1293,y:963,t:1527189039522};\\\", \\\"{x:1293,y:960,t:1527189039529};\\\", \\\"{x:1293,y:959,t:1527189039601};\\\", \\\"{x:1293,y:957,t:1527189039612};\\\", \\\"{x:1293,y:955,t:1527189039628};\\\", \\\"{x:1293,y:954,t:1527189039646};\\\", \\\"{x:1293,y:953,t:1527189039662};\\\", \\\"{x:1292,y:953,t:1527189039809};\\\", \\\"{x:1291,y:953,t:1527189039817};\\\", \\\"{x:1289,y:953,t:1527189039833};\\\", \\\"{x:1288,y:953,t:1527189039848};\\\", \\\"{x:1287,y:953,t:1527189039863};\\\", \\\"{x:1285,y:953,t:1527189039878};\\\", \\\"{x:1284,y:953,t:1527189039897};\\\", \\\"{x:1283,y:954,t:1527189039913};\\\", \\\"{x:1282,y:956,t:1527189044098};\\\", \\\"{x:1279,y:962,t:1527189044116};\\\", \\\"{x:1278,y:966,t:1527189044132};\\\", \\\"{x:1277,y:969,t:1527189044149};\\\", \\\"{x:1276,y:970,t:1527189044168};\\\", \\\"{x:1276,y:968,t:1527189044529};\\\", \\\"{x:1276,y:965,t:1527189044537};\\\", \\\"{x:1276,y:964,t:1527189044548};\\\", \\\"{x:1276,y:963,t:1527189044565};\\\", \\\"{x:1276,y:961,t:1527189044582};\\\", \\\"{x:1279,y:961,t:1527189044938};\\\", \\\"{x:1281,y:961,t:1527189044950};\\\", \\\"{x:1286,y:963,t:1527189044966};\\\", \\\"{x:1291,y:966,t:1527189044982};\\\", \\\"{x:1294,y:967,t:1527189044999};\\\", \\\"{x:1299,y:968,t:1527189045015};\\\", \\\"{x:1301,y:969,t:1527189045032};\\\", \\\"{x:1303,y:970,t:1527189045049};\\\", \\\"{x:1306,y:972,t:1527189045066};\\\", \\\"{x:1310,y:973,t:1527189045082};\\\", \\\"{x:1316,y:975,t:1527189045099};\\\", \\\"{x:1318,y:976,t:1527189045116};\\\", \\\"{x:1321,y:976,t:1527189045132};\\\", \\\"{x:1322,y:976,t:1527189045150};\\\", \\\"{x:1323,y:976,t:1527189045265};\\\", \\\"{x:1323,y:975,t:1527189045273};\\\", \\\"{x:1323,y:972,t:1527189045282};\\\", \\\"{x:1323,y:968,t:1527189045299};\\\", \\\"{x:1323,y:964,t:1527189045317};\\\", \\\"{x:1323,y:960,t:1527189045333};\\\", \\\"{x:1323,y:959,t:1527189045349};\\\", \\\"{x:1322,y:958,t:1527189045366};\\\", \\\"{x:1321,y:958,t:1527189045474};\\\", \\\"{x:1319,y:957,t:1527189045483};\\\", \\\"{x:1316,y:957,t:1527189045500};\\\", \\\"{x:1313,y:957,t:1527189045517};\\\", \\\"{x:1312,y:957,t:1527189045537};\\\", \\\"{x:1310,y:957,t:1527189045674};\\\", \\\"{x:1309,y:957,t:1527189045705};\\\", \\\"{x:1309,y:958,t:1527189045717};\\\", \\\"{x:1309,y:959,t:1527189045734};\\\", \\\"{x:1309,y:960,t:1527189045750};\\\", \\\"{x:1310,y:961,t:1527189045906};\\\", \\\"{x:1312,y:962,t:1527189045917};\\\", \\\"{x:1317,y:964,t:1527189045934};\\\", \\\"{x:1319,y:964,t:1527189045953};\\\", \\\"{x:1319,y:965,t:1527189045967};\\\", \\\"{x:1320,y:965,t:1527189048066};\\\", \\\"{x:1321,y:967,t:1527189048081};\\\", \\\"{x:1321,y:968,t:1527189048097};\\\", \\\"{x:1321,y:970,t:1527189048114};\\\", \\\"{x:1321,y:971,t:1527189048834};\\\", \\\"{x:1320,y:972,t:1527189048849};\\\", \\\"{x:1320,y:973,t:1527189048865};\\\", \\\"{x:1319,y:973,t:1527189048873};\\\", \\\"{x:1318,y:973,t:1527189049226};\\\", \\\"{x:1317,y:973,t:1527189049236};\\\", \\\"{x:1317,y:972,t:1527189049253};\\\", \\\"{x:1316,y:971,t:1527189051473};\\\", \\\"{x:1316,y:968,t:1527189051487};\\\", \\\"{x:1316,y:965,t:1527189051505};\\\", \\\"{x:1316,y:964,t:1527189051522};\\\", \\\"{x:1315,y:963,t:1527189051539};\\\", \\\"{x:1314,y:963,t:1527189057426};\\\", \\\"{x:1312,y:963,t:1527189057465};\\\", \\\"{x:1312,y:965,t:1527189057714};\\\", \\\"{x:1313,y:965,t:1527189057727};\\\", \\\"{x:1315,y:965,t:1527189057744};\\\", \\\"{x:1320,y:966,t:1527189057760};\\\", \\\"{x:1327,y:969,t:1527189057776};\\\", \\\"{x:1329,y:969,t:1527189057792};\\\", \\\"{x:1330,y:970,t:1527189058017};\\\", \\\"{x:1330,y:971,t:1527189058026};\\\", \\\"{x:1326,y:971,t:1527189058044};\\\", \\\"{x:1322,y:971,t:1527189058060};\\\", \\\"{x:1320,y:971,t:1527189058077};\\\", \\\"{x:1319,y:971,t:1527189058094};\\\", \\\"{x:1317,y:971,t:1527189058193};\\\", \\\"{x:1316,y:971,t:1527189058211};\\\", \\\"{x:1314,y:970,t:1527189058226};\\\", \\\"{x:1313,y:970,t:1527189058243};\\\", \\\"{x:1312,y:969,t:1527189058361};\\\", \\\"{x:1311,y:968,t:1527189060153};\\\", \\\"{x:1310,y:968,t:1527189061593};\\\", \\\"{x:1300,y:948,t:1527189061601};\\\", \\\"{x:1275,y:894,t:1527189061612};\\\", \\\"{x:1215,y:772,t:1527189061629};\\\", \\\"{x:1134,y:663,t:1527189061646};\\\", \\\"{x:1026,y:564,t:1527189061663};\\\", \\\"{x:922,y:484,t:1527189061679};\\\", \\\"{x:823,y:417,t:1527189061696};\\\", \\\"{x:708,y:338,t:1527189061713};\\\", \\\"{x:664,y:309,t:1527189061729};\\\", \\\"{x:633,y:288,t:1527189061746};\\\", \\\"{x:615,y:273,t:1527189061762};\\\", \\\"{x:601,y:259,t:1527189061779};\\\", \\\"{x:589,y:251,t:1527189061796};\\\", \\\"{x:587,y:250,t:1527189061813};\\\", \\\"{x:586,y:250,t:1527189061849};\\\", \\\"{x:586,y:252,t:1527189061863};\\\", \\\"{x:589,y:262,t:1527189061879};\\\", \\\"{x:601,y:291,t:1527189061896};\\\", \\\"{x:626,y:327,t:1527189061912};\\\", \\\"{x:661,y:368,t:1527189061929};\\\", \\\"{x:711,y:423,t:1527189061945};\\\", \\\"{x:758,y:461,t:1527189061963};\\\", \\\"{x:805,y:503,t:1527189061979};\\\", \\\"{x:852,y:554,t:1527189061996};\\\", \\\"{x:887,y:598,t:1527189062013};\\\", \\\"{x:904,y:617,t:1527189062028};\\\", \\\"{x:912,y:624,t:1527189062046};\\\", \\\"{x:914,y:626,t:1527189062063};\\\", \\\"{x:914,y:628,t:1527189062080};\\\", \\\"{x:914,y:630,t:1527189062097};\\\", \\\"{x:914,y:631,t:1527189062113};\\\", \\\"{x:913,y:630,t:1527189062185};\\\", \\\"{x:909,y:621,t:1527189062197};\\\", \\\"{x:896,y:597,t:1527189062213};\\\", \\\"{x:883,y:581,t:1527189062231};\\\", \\\"{x:864,y:568,t:1527189062247};\\\", \\\"{x:846,y:558,t:1527189062263};\\\", \\\"{x:836,y:552,t:1527189062280};\\\", \\\"{x:835,y:552,t:1527189062424};\\\", \\\"{x:835,y:551,t:1527189062432};\\\", \\\"{x:835,y:550,t:1527189062448};\\\", \\\"{x:838,y:548,t:1527189062464};\\\", \\\"{x:839,y:547,t:1527189062480};\\\", \\\"{x:840,y:546,t:1527189062513};\\\", \\\"{x:840,y:545,t:1527189062553};\\\", \\\"{x:840,y:544,t:1527189062564};\\\", \\\"{x:840,y:543,t:1527189062580};\\\", \\\"{x:840,y:541,t:1527189062597};\\\", \\\"{x:840,y:540,t:1527189062614};\\\", \\\"{x:841,y:539,t:1527189062630};\\\", \\\"{x:842,y:539,t:1527189063282};\\\", \\\"{x:864,y:559,t:1527189063299};\\\", \\\"{x:901,y:595,t:1527189063315};\\\", \\\"{x:945,y:635,t:1527189063331};\\\", \\\"{x:1001,y:673,t:1527189063348};\\\", \\\"{x:1056,y:717,t:1527189063364};\\\", \\\"{x:1126,y:766,t:1527189063381};\\\", \\\"{x:1203,y:818,t:1527189063398};\\\", \\\"{x:1259,y:855,t:1527189063414};\\\", \\\"{x:1290,y:877,t:1527189063430};\\\", \\\"{x:1311,y:893,t:1527189063448};\\\", \\\"{x:1314,y:895,t:1527189063464};\\\", \\\"{x:1314,y:896,t:1527189063512};\\\", \\\"{x:1314,y:897,t:1527189063520};\\\", \\\"{x:1314,y:898,t:1527189063531};\\\", \\\"{x:1313,y:902,t:1527189063549};\\\", \\\"{x:1312,y:907,t:1527189063564};\\\", \\\"{x:1312,y:915,t:1527189063581};\\\", \\\"{x:1309,y:928,t:1527189063598};\\\", \\\"{x:1309,y:939,t:1527189063614};\\\", \\\"{x:1309,y:950,t:1527189063631};\\\", \\\"{x:1309,y:956,t:1527189063649};\\\", \\\"{x:1309,y:959,t:1527189063665};\\\", \\\"{x:1309,y:965,t:1527189063681};\\\", \\\"{x:1309,y:971,t:1527189063698};\\\", \\\"{x:1309,y:977,t:1527189063714};\\\", \\\"{x:1309,y:982,t:1527189063731};\\\", \\\"{x:1309,y:986,t:1527189063748};\\\", \\\"{x:1310,y:988,t:1527189063765};\\\", \\\"{x:1310,y:991,t:1527189063782};\\\", \\\"{x:1312,y:994,t:1527189063798};\\\", \\\"{x:1312,y:992,t:1527189063905};\\\", \\\"{x:1312,y:989,t:1527189063914};\\\", \\\"{x:1312,y:984,t:1527189063931};\\\", \\\"{x:1312,y:979,t:1527189063948};\\\", \\\"{x:1312,y:974,t:1527189063965};\\\", \\\"{x:1312,y:972,t:1527189063982};\\\", \\\"{x:1312,y:969,t:1527189063999};\\\", \\\"{x:1313,y:967,t:1527189064416};\\\", \\\"{x:1313,y:966,t:1527189064432};\\\", \\\"{x:1314,y:965,t:1527189064448};\\\", \\\"{x:1315,y:963,t:1527189064465};\\\", \\\"{x:1316,y:963,t:1527189064482};\\\", \\\"{x:1317,y:963,t:1527189064520};\\\", \\\"{x:1309,y:956,t:1527189065202};\\\", \\\"{x:1282,y:929,t:1527189065215};\\\", \\\"{x:1145,y:809,t:1527189065233};\\\", \\\"{x:1046,y:725,t:1527189065250};\\\", \\\"{x:976,y:669,t:1527189065266};\\\", \\\"{x:913,y:622,t:1527189065283};\\\", \\\"{x:871,y:592,t:1527189065299};\\\", \\\"{x:852,y:577,t:1527189065314};\\\", \\\"{x:846,y:571,t:1527189065330};\\\", \\\"{x:846,y:569,t:1527189065360};\\\", \\\"{x:846,y:568,t:1527189065440};\\\", \\\"{x:846,y:566,t:1527189065456};\\\", \\\"{x:846,y:565,t:1527189065479};\\\", \\\"{x:846,y:564,t:1527189065488};\\\", \\\"{x:846,y:562,t:1527189065499};\\\", \\\"{x:847,y:559,t:1527189065517};\\\", \\\"{x:847,y:556,t:1527189065533};\\\", \\\"{x:847,y:553,t:1527189065549};\\\", \\\"{x:847,y:548,t:1527189065567};\\\", \\\"{x:847,y:542,t:1527189065584};\\\", \\\"{x:847,y:538,t:1527189065599};\\\", \\\"{x:844,y:532,t:1527189065616};\\\", \\\"{x:843,y:530,t:1527189065633};\\\", \\\"{x:842,y:529,t:1527189065649};\\\", \\\"{x:841,y:529,t:1527189065761};\\\", \\\"{x:841,y:547,t:1527189073914};\\\", \\\"{x:841,y:567,t:1527189073927};\\\", \\\"{x:841,y:595,t:1527189073942};\\\", \\\"{x:850,y:631,t:1527189073972};\\\", \\\"{x:857,y:645,t:1527189073989};\\\", \\\"{x:861,y:654,t:1527189074006};\\\", \\\"{x:863,y:658,t:1527189074022};\\\", \\\"{x:865,y:664,t:1527189074039};\\\", \\\"{x:865,y:667,t:1527189074056};\\\", \\\"{x:868,y:674,t:1527189074073};\\\", \\\"{x:873,y:686,t:1527189074089};\\\", \\\"{x:880,y:701,t:1527189074107};\\\", \\\"{x:892,y:715,t:1527189074123};\\\", \\\"{x:916,y:735,t:1527189074139};\\\", \\\"{x:961,y:766,t:1527189074157};\\\", \\\"{x:1022,y:805,t:1527189074174};\\\", \\\"{x:1098,y:847,t:1527189074189};\\\", \\\"{x:1176,y:883,t:1527189074207};\\\", \\\"{x:1254,y:923,t:1527189074224};\\\", \\\"{x:1326,y:958,t:1527189074239};\\\", \\\"{x:1386,y:983,t:1527189074256};\\\", \\\"{x:1399,y:989,t:1527189074273};\\\", \\\"{x:1395,y:989,t:1527189074442};\\\", \\\"{x:1381,y:988,t:1527189074457};\\\", \\\"{x:1364,y:985,t:1527189074474};\\\", \\\"{x:1349,y:984,t:1527189074490};\\\", \\\"{x:1337,y:984,t:1527189074507};\\\", \\\"{x:1328,y:983,t:1527189074524};\\\", \\\"{x:1325,y:983,t:1527189074540};\\\", \\\"{x:1323,y:982,t:1527189074556};\\\", \\\"{x:1322,y:982,t:1527189074574};\\\", \\\"{x:1321,y:982,t:1527189074600};\\\", \\\"{x:1320,y:982,t:1527189074608};\\\", \\\"{x:1319,y:982,t:1527189074624};\\\", \\\"{x:1317,y:982,t:1527189074640};\\\", \\\"{x:1307,y:976,t:1527189074656};\\\", \\\"{x:1295,y:967,t:1527189074674};\\\", \\\"{x:1279,y:956,t:1527189074691};\\\", \\\"{x:1270,y:949,t:1527189074706};\\\", \\\"{x:1265,y:946,t:1527189074724};\\\", \\\"{x:1263,y:945,t:1527189074741};\\\", \\\"{x:1265,y:945,t:1527189074898};\\\", \\\"{x:1266,y:945,t:1527189074907};\\\", \\\"{x:1272,y:946,t:1527189074924};\\\", \\\"{x:1275,y:947,t:1527189074941};\\\", \\\"{x:1277,y:948,t:1527189074957};\\\", \\\"{x:1279,y:948,t:1527189074974};\\\", \\\"{x:1280,y:949,t:1527189074991};\\\", \\\"{x:1281,y:950,t:1527189075025};\\\", \\\"{x:1283,y:950,t:1527189075041};\\\", \\\"{x:1286,y:953,t:1527189075058};\\\", \\\"{x:1289,y:957,t:1527189075074};\\\", \\\"{x:1292,y:960,t:1527189075092};\\\", \\\"{x:1295,y:964,t:1527189075108};\\\", \\\"{x:1297,y:965,t:1527189075124};\\\", \\\"{x:1298,y:966,t:1527189075141};\\\", \\\"{x:1298,y:967,t:1527189075158};\\\", \\\"{x:1299,y:968,t:1527189075174};\\\", \\\"{x:1300,y:968,t:1527189075191};\\\", \\\"{x:1301,y:968,t:1527189075208};\\\", \\\"{x:1302,y:968,t:1527189075224};\\\", \\\"{x:1303,y:968,t:1527189075338};\\\", \\\"{x:1304,y:968,t:1527189075385};\\\", \\\"{x:1305,y:968,t:1527189075401};\\\", \\\"{x:1306,y:968,t:1527189075441};\\\", \\\"{x:1308,y:968,t:1527189075458};\\\", \\\"{x:1310,y:970,t:1527189075474};\\\", \\\"{x:1312,y:970,t:1527189075490};\\\", \\\"{x:1314,y:970,t:1527189075508};\\\", \\\"{x:1315,y:970,t:1527189075524};\\\", \\\"{x:1315,y:969,t:1527189075665};\\\", \\\"{x:1315,y:967,t:1527189075675};\\\", \\\"{x:1315,y:966,t:1527189075691};\\\", \\\"{x:1314,y:963,t:1527189075809};\\\", \\\"{x:1314,y:961,t:1527189075825};\\\", \\\"{x:1312,y:964,t:1527189086785};\\\", \\\"{x:1311,y:964,t:1527189086801};\\\", \\\"{x:1313,y:963,t:1527189091337};\\\", \\\"{x:1315,y:963,t:1527189091354};\\\", \\\"{x:1316,y:962,t:1527189091371};\\\", \\\"{x:1316,y:963,t:1527189091817};\\\", \\\"{x:1312,y:963,t:1527189100780};\\\", \\\"{x:1262,y:943,t:1527189100799};\\\", \\\"{x:1149,y:890,t:1527189100815};\\\", \\\"{x:1045,y:832,t:1527189100832};\\\", \\\"{x:918,y:776,t:1527189100849};\\\", \\\"{x:794,y:721,t:1527189100865};\\\", \\\"{x:667,y:667,t:1527189100882};\\\", \\\"{x:563,y:624,t:1527189100900};\\\", \\\"{x:478,y:589,t:1527189100916};\\\", \\\"{x:419,y:564,t:1527189100930};\\\", \\\"{x:409,y:559,t:1527189100961};\\\", \\\"{x:408,y:559,t:1527189100977};\\\", \\\"{x:407,y:560,t:1527189101051};\\\", \\\"{x:407,y:562,t:1527189101063};\\\", \\\"{x:407,y:574,t:1527189101077};\\\", \\\"{x:407,y:591,t:1527189101099};\\\", \\\"{x:414,y:616,t:1527189101115};\\\", \\\"{x:422,y:634,t:1527189101132};\\\", \\\"{x:430,y:651,t:1527189101148};\\\", \\\"{x:440,y:667,t:1527189101165};\\\", \\\"{x:448,y:681,t:1527189101181};\\\", \\\"{x:454,y:688,t:1527189101197};\\\", \\\"{x:457,y:691,t:1527189101215};\\\", \\\"{x:458,y:691,t:1527189101232};\\\", \\\"{x:460,y:691,t:1527189101356};\\\", \\\"{x:461,y:691,t:1527189101365};\\\", \\\"{x:463,y:694,t:1527189101382};\\\", \\\"{x:468,y:698,t:1527189101398};\\\", \\\"{x:473,y:703,t:1527189101415};\\\", \\\"{x:478,y:711,t:1527189101432};\\\", \\\"{x:485,y:718,t:1527189101449};\\\", \\\"{x:492,y:724,t:1527189101465};\\\", \\\"{x:501,y:729,t:1527189101482};\\\", \\\"{x:509,y:733,t:1527189101498};\\\", \\\"{x:519,y:739,t:1527189101515};\\\", \\\"{x:523,y:741,t:1527189101531};\\\", \\\"{x:525,y:741,t:1527189101548};\\\", \\\"{x:525,y:739,t:1527189101595};\\\", \\\"{x:525,y:738,t:1527189101612};\\\", \\\"{x:526,y:737,t:1527189101627};\\\", \\\"{x:526,y:736,t:1527189101764};\\\", \\\"{x:526,y:735,t:1527189101771};\\\", \\\"{x:526,y:734,t:1527189101787};\\\", \\\"{x:526,y:733,t:1527189101799};\\\", \\\"{x:526,y:732,t:1527189101828};\\\" ] }, { \\\"rt\\\": 20429, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 509250, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:732,t:1527189108972};\\\", \\\"{x:572,y:732,t:1527189108980};\\\", \\\"{x:638,y:732,t:1527189108994};\\\", \\\"{x:716,y:732,t:1527189109010};\\\", \\\"{x:753,y:735,t:1527189109019};\\\", \\\"{x:810,y:744,t:1527189109036};\\\", \\\"{x:864,y:762,t:1527189109053};\\\", \\\"{x:919,y:779,t:1527189109070};\\\", \\\"{x:970,y:787,t:1527189109086};\\\", \\\"{x:1011,y:791,t:1527189109103};\\\", \\\"{x:1036,y:792,t:1527189109120};\\\", \\\"{x:1053,y:792,t:1527189109137};\\\", \\\"{x:1067,y:792,t:1527189109153};\\\", \\\"{x:1084,y:792,t:1527189109170};\\\", \\\"{x:1108,y:792,t:1527189109187};\\\", \\\"{x:1158,y:788,t:1527189109203};\\\", \\\"{x:1183,y:781,t:1527189109221};\\\", \\\"{x:1198,y:771,t:1527189109237};\\\", \\\"{x:1210,y:763,t:1527189109254};\\\", \\\"{x:1220,y:754,t:1527189109270};\\\", \\\"{x:1231,y:742,t:1527189109286};\\\", \\\"{x:1237,y:725,t:1527189109303};\\\", \\\"{x:1241,y:694,t:1527189109321};\\\", \\\"{x:1241,y:668,t:1527189109336};\\\", \\\"{x:1234,y:647,t:1527189109354};\\\", \\\"{x:1220,y:611,t:1527189109371};\\\", \\\"{x:1216,y:602,t:1527189109386};\\\", \\\"{x:1211,y:592,t:1527189109404};\\\", \\\"{x:1211,y:585,t:1527189109421};\\\", \\\"{x:1212,y:578,t:1527189109437};\\\", \\\"{x:1215,y:573,t:1527189109454};\\\", \\\"{x:1217,y:571,t:1527189109471};\\\", \\\"{x:1219,y:568,t:1527189109486};\\\", \\\"{x:1225,y:563,t:1527189109504};\\\", \\\"{x:1228,y:557,t:1527189109521};\\\", \\\"{x:1230,y:553,t:1527189109537};\\\", \\\"{x:1233,y:550,t:1527189109554};\\\", \\\"{x:1236,y:545,t:1527189109571};\\\", \\\"{x:1238,y:540,t:1527189109587};\\\", \\\"{x:1240,y:531,t:1527189109603};\\\", \\\"{x:1241,y:525,t:1527189109621};\\\", \\\"{x:1241,y:521,t:1527189109637};\\\", \\\"{x:1241,y:516,t:1527189109653};\\\", \\\"{x:1241,y:515,t:1527189109671};\\\", \\\"{x:1241,y:519,t:1527189110180};\\\", \\\"{x:1241,y:527,t:1527189110188};\\\", \\\"{x:1241,y:533,t:1527189110204};\\\", \\\"{x:1241,y:537,t:1527189110221};\\\", \\\"{x:1241,y:538,t:1527189110238};\\\", \\\"{x:1241,y:540,t:1527189110412};\\\", \\\"{x:1240,y:542,t:1527189110421};\\\", \\\"{x:1239,y:546,t:1527189110438};\\\", \\\"{x:1239,y:547,t:1527189110454};\\\", \\\"{x:1238,y:548,t:1527189110471};\\\", \\\"{x:1238,y:549,t:1527189110499};\\\", \\\"{x:1238,y:550,t:1527189110523};\\\", \\\"{x:1237,y:553,t:1527189110537};\\\", \\\"{x:1237,y:555,t:1527189110553};\\\", \\\"{x:1237,y:556,t:1527189110570};\\\", \\\"{x:1237,y:562,t:1527189110587};\\\", \\\"{x:1241,y:566,t:1527189110603};\\\", \\\"{x:1249,y:568,t:1527189110621};\\\", \\\"{x:1257,y:573,t:1527189110638};\\\", \\\"{x:1261,y:573,t:1527189110653};\\\", \\\"{x:1263,y:576,t:1527189110670};\\\", \\\"{x:1266,y:576,t:1527189110688};\\\", \\\"{x:1267,y:575,t:1527189111108};\\\", \\\"{x:1267,y:574,t:1527189111139};\\\", \\\"{x:1267,y:573,t:1527189111164};\\\", \\\"{x:1265,y:569,t:1527189111372};\\\", \\\"{x:1232,y:558,t:1527189111388};\\\", \\\"{x:1173,y:548,t:1527189111405};\\\", \\\"{x:1087,y:537,t:1527189111421};\\\", \\\"{x:976,y:523,t:1527189111438};\\\", \\\"{x:845,y:497,t:1527189111457};\\\", \\\"{x:734,y:481,t:1527189111472};\\\", \\\"{x:623,y:465,t:1527189111487};\\\", \\\"{x:531,y:451,t:1527189111506};\\\", \\\"{x:458,y:438,t:1527189111523};\\\", \\\"{x:432,y:431,t:1527189111539};\\\", \\\"{x:420,y:427,t:1527189111557};\\\", \\\"{x:417,y:426,t:1527189111574};\\\", \\\"{x:416,y:426,t:1527189111589};\\\", \\\"{x:415,y:427,t:1527189111606};\\\", \\\"{x:413,y:436,t:1527189111623};\\\", \\\"{x:411,y:446,t:1527189111640};\\\", \\\"{x:410,y:456,t:1527189111656};\\\", \\\"{x:408,y:465,t:1527189111673};\\\", \\\"{x:408,y:471,t:1527189111689};\\\", \\\"{x:409,y:475,t:1527189111706};\\\", \\\"{x:434,y:491,t:1527189111724};\\\", \\\"{x:466,y:499,t:1527189111740};\\\", \\\"{x:500,y:510,t:1527189111757};\\\", \\\"{x:527,y:513,t:1527189111772};\\\", \\\"{x:546,y:515,t:1527189111790};\\\", \\\"{x:551,y:515,t:1527189111806};\\\", \\\"{x:554,y:514,t:1527189111866};\\\", \\\"{x:557,y:512,t:1527189111875};\\\", \\\"{x:560,y:511,t:1527189111890};\\\", \\\"{x:568,y:506,t:1527189111906};\\\", \\\"{x:582,y:498,t:1527189111924};\\\", \\\"{x:587,y:494,t:1527189111941};\\\", \\\"{x:588,y:493,t:1527189111956};\\\", \\\"{x:589,y:493,t:1527189112060};\\\", \\\"{x:591,y:493,t:1527189112084};\\\", \\\"{x:593,y:493,t:1527189112091};\\\", \\\"{x:596,y:493,t:1527189112107};\\\", \\\"{x:597,y:493,t:1527189112124};\\\", \\\"{x:599,y:493,t:1527189112141};\\\", \\\"{x:601,y:494,t:1527189112159};\\\", \\\"{x:603,y:494,t:1527189112173};\\\", \\\"{x:607,y:496,t:1527189112189};\\\", \\\"{x:610,y:498,t:1527189112206};\\\", \\\"{x:613,y:498,t:1527189112223};\\\", \\\"{x:614,y:499,t:1527189112239};\\\", \\\"{x:615,y:499,t:1527189112257};\\\", \\\"{x:615,y:500,t:1527189117228};\\\", \\\"{x:614,y:502,t:1527189117245};\\\", \\\"{x:612,y:505,t:1527189117261};\\\", \\\"{x:609,y:512,t:1527189117278};\\\", \\\"{x:608,y:525,t:1527189117297};\\\", \\\"{x:608,y:533,t:1527189117311};\\\", \\\"{x:609,y:543,t:1527189117328};\\\", \\\"{x:611,y:547,t:1527189117345};\\\", \\\"{x:618,y:551,t:1527189117362};\\\", \\\"{x:629,y:556,t:1527189117378};\\\", \\\"{x:652,y:562,t:1527189117395};\\\", \\\"{x:662,y:563,t:1527189117412};\\\", \\\"{x:671,y:563,t:1527189117428};\\\", \\\"{x:683,y:564,t:1527189117444};\\\", \\\"{x:700,y:564,t:1527189117461};\\\", \\\"{x:718,y:564,t:1527189117478};\\\", \\\"{x:735,y:564,t:1527189117496};\\\", \\\"{x:746,y:564,t:1527189117511};\\\", \\\"{x:751,y:564,t:1527189117528};\\\", \\\"{x:754,y:563,t:1527189117545};\\\", \\\"{x:757,y:562,t:1527189117588};\\\", \\\"{x:764,y:559,t:1527189117594};\\\", \\\"{x:781,y:552,t:1527189117613};\\\", \\\"{x:798,y:550,t:1527189117628};\\\", \\\"{x:809,y:548,t:1527189117645};\\\", \\\"{x:814,y:546,t:1527189117661};\\\", \\\"{x:816,y:546,t:1527189117732};\\\", \\\"{x:817,y:546,t:1527189117745};\\\", \\\"{x:820,y:546,t:1527189117761};\\\", \\\"{x:827,y:542,t:1527189117778};\\\", \\\"{x:831,y:539,t:1527189117794};\\\", \\\"{x:830,y:538,t:1527189118636};\\\", \\\"{x:829,y:538,t:1527189121812};\\\", \\\"{x:827,y:541,t:1527189121819};\\\", \\\"{x:823,y:548,t:1527189121831};\\\", \\\"{x:817,y:559,t:1527189121849};\\\", \\\"{x:809,y:573,t:1527189121864};\\\", \\\"{x:802,y:585,t:1527189121882};\\\", \\\"{x:796,y:594,t:1527189121898};\\\", \\\"{x:788,y:611,t:1527189121915};\\\", \\\"{x:783,y:619,t:1527189121931};\\\", \\\"{x:776,y:629,t:1527189121947};\\\", \\\"{x:768,y:639,t:1527189121965};\\\", \\\"{x:760,y:650,t:1527189121982};\\\", \\\"{x:748,y:664,t:1527189121998};\\\", \\\"{x:738,y:678,t:1527189122015};\\\", \\\"{x:727,y:690,t:1527189122032};\\\", \\\"{x:716,y:702,t:1527189122048};\\\", \\\"{x:702,y:712,t:1527189122064};\\\", \\\"{x:690,y:722,t:1527189122082};\\\", \\\"{x:676,y:732,t:1527189122098};\\\", \\\"{x:657,y:748,t:1527189122114};\\\", \\\"{x:645,y:756,t:1527189122132};\\\", \\\"{x:634,y:764,t:1527189122149};\\\", \\\"{x:623,y:771,t:1527189122165};\\\", \\\"{x:609,y:780,t:1527189122182};\\\", \\\"{x:597,y:784,t:1527189122198};\\\", \\\"{x:584,y:790,t:1527189122215};\\\", \\\"{x:570,y:791,t:1527189122232};\\\", \\\"{x:558,y:794,t:1527189122249};\\\", \\\"{x:550,y:794,t:1527189122265};\\\", \\\"{x:544,y:794,t:1527189122282};\\\", \\\"{x:538,y:794,t:1527189122299};\\\", \\\"{x:533,y:794,t:1527189122315};\\\", \\\"{x:529,y:791,t:1527189122332};\\\", \\\"{x:525,y:788,t:1527189122349};\\\", \\\"{x:520,y:785,t:1527189122365};\\\", \\\"{x:517,y:782,t:1527189122382};\\\", \\\"{x:515,y:780,t:1527189122400};\\\", \\\"{x:512,y:776,t:1527189122415};\\\", \\\"{x:508,y:768,t:1527189122432};\\\", \\\"{x:505,y:763,t:1527189122449};\\\", \\\"{x:504,y:758,t:1527189122466};\\\", \\\"{x:500,y:750,t:1527189122483};\\\", \\\"{x:497,y:745,t:1527189122498};\\\" ] }, { \\\"rt\\\": 68768, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 579340, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-5-F -F -I -I -I -E -E -M -O -O -O -O -X -X -O -O -O -O -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:740,t:1527189135060};\\\", \\\"{x:556,y:712,t:1527189135080};\\\", \\\"{x:650,y:676,t:1527189135100};\\\", \\\"{x:738,y:656,t:1527189135124};\\\", \\\"{x:791,y:656,t:1527189135141};\\\", \\\"{x:841,y:656,t:1527189135157};\\\", \\\"{x:886,y:656,t:1527189135174};\\\", \\\"{x:923,y:656,t:1527189135191};\\\", \\\"{x:951,y:655,t:1527189135208};\\\", \\\"{x:972,y:654,t:1527189135223};\\\", \\\"{x:990,y:650,t:1527189135241};\\\", \\\"{x:1014,y:647,t:1527189135258};\\\", \\\"{x:1045,y:641,t:1527189135274};\\\", \\\"{x:1083,y:635,t:1527189135290};\\\", \\\"{x:1104,y:632,t:1527189135308};\\\", \\\"{x:1122,y:630,t:1527189135324};\\\", \\\"{x:1143,y:628,t:1527189135341};\\\", \\\"{x:1164,y:628,t:1527189135358};\\\", \\\"{x:1184,y:631,t:1527189135374};\\\", \\\"{x:1202,y:638,t:1527189135391};\\\", \\\"{x:1221,y:643,t:1527189135408};\\\", \\\"{x:1232,y:643,t:1527189135424};\\\", \\\"{x:1239,y:643,t:1527189135441};\\\", \\\"{x:1240,y:643,t:1527189135458};\\\", \\\"{x:1240,y:641,t:1527189135683};\\\", \\\"{x:1239,y:640,t:1527189135699};\\\", \\\"{x:1237,y:640,t:1527189135708};\\\", \\\"{x:1232,y:636,t:1527189135725};\\\", \\\"{x:1227,y:635,t:1527189135741};\\\", \\\"{x:1226,y:634,t:1527189135758};\\\", \\\"{x:1225,y:634,t:1527189135787};\\\", \\\"{x:1225,y:633,t:1527189135795};\\\", \\\"{x:1224,y:633,t:1527189135812};\\\", \\\"{x:1222,y:632,t:1527189135825};\\\", \\\"{x:1221,y:630,t:1527189135841};\\\", \\\"{x:1219,y:628,t:1527189135858};\\\", \\\"{x:1218,y:626,t:1527189135875};\\\", \\\"{x:1219,y:626,t:1527189138563};\\\", \\\"{x:1225,y:627,t:1527189138577};\\\", \\\"{x:1230,y:628,t:1527189138593};\\\", \\\"{x:1231,y:629,t:1527189138609};\\\", \\\"{x:1234,y:629,t:1527189138626};\\\", \\\"{x:1236,y:630,t:1527189138644};\\\", \\\"{x:1239,y:630,t:1527189138660};\\\", \\\"{x:1245,y:632,t:1527189138676};\\\", \\\"{x:1254,y:634,t:1527189138693};\\\", \\\"{x:1265,y:636,t:1527189138710};\\\", \\\"{x:1277,y:640,t:1527189138726};\\\", \\\"{x:1288,y:642,t:1527189138744};\\\", \\\"{x:1297,y:645,t:1527189138760};\\\", \\\"{x:1300,y:646,t:1527189138777};\\\", \\\"{x:1301,y:646,t:1527189138859};\\\", \\\"{x:1302,y:648,t:1527189138876};\\\", \\\"{x:1305,y:648,t:1527189138893};\\\", \\\"{x:1311,y:654,t:1527189138910};\\\", \\\"{x:1318,y:663,t:1527189138926};\\\", \\\"{x:1325,y:671,t:1527189138942};\\\", \\\"{x:1330,y:676,t:1527189138960};\\\", \\\"{x:1331,y:678,t:1527189138976};\\\", \\\"{x:1332,y:680,t:1527189138993};\\\", \\\"{x:1336,y:683,t:1527189139010};\\\", \\\"{x:1341,y:688,t:1527189139025};\\\", \\\"{x:1349,y:695,t:1527189139043};\\\", \\\"{x:1351,y:698,t:1527189139060};\\\", \\\"{x:1353,y:701,t:1527189139076};\\\", \\\"{x:1354,y:702,t:1527189139093};\\\", \\\"{x:1356,y:705,t:1527189139109};\\\", \\\"{x:1358,y:708,t:1527189139126};\\\", \\\"{x:1359,y:709,t:1527189139143};\\\", \\\"{x:1358,y:708,t:1527189139500};\\\", \\\"{x:1356,y:706,t:1527189139660};\\\", \\\"{x:1354,y:701,t:1527189139677};\\\", \\\"{x:1351,y:697,t:1527189139694};\\\", \\\"{x:1351,y:696,t:1527189139711};\\\", \\\"{x:1350,y:696,t:1527189141228};\\\", \\\"{x:1349,y:697,t:1527189141244};\\\", \\\"{x:1349,y:698,t:1527189141261};\\\", \\\"{x:1349,y:699,t:1527189141277};\\\", \\\"{x:1348,y:700,t:1527189141295};\\\", \\\"{x:1347,y:701,t:1527189148044};\\\", \\\"{x:1345,y:706,t:1527189148053};\\\", \\\"{x:1343,y:713,t:1527189148064};\\\", \\\"{x:1338,y:727,t:1527189148082};\\\", \\\"{x:1328,y:741,t:1527189148099};\\\", \\\"{x:1320,y:755,t:1527189148115};\\\", \\\"{x:1308,y:769,t:1527189148131};\\\", \\\"{x:1300,y:779,t:1527189148148};\\\", \\\"{x:1294,y:788,t:1527189148165};\\\", \\\"{x:1289,y:795,t:1527189148182};\\\", \\\"{x:1285,y:803,t:1527189148199};\\\", \\\"{x:1277,y:812,t:1527189148215};\\\", \\\"{x:1272,y:817,t:1527189148232};\\\", \\\"{x:1265,y:822,t:1527189148249};\\\", \\\"{x:1260,y:826,t:1527189148265};\\\", \\\"{x:1255,y:829,t:1527189148281};\\\", \\\"{x:1249,y:832,t:1527189148298};\\\", \\\"{x:1245,y:834,t:1527189148315};\\\", \\\"{x:1237,y:836,t:1527189148332};\\\", \\\"{x:1229,y:837,t:1527189148349};\\\", \\\"{x:1217,y:838,t:1527189148365};\\\", \\\"{x:1206,y:838,t:1527189148382};\\\", \\\"{x:1195,y:838,t:1527189148398};\\\", \\\"{x:1185,y:838,t:1527189148415};\\\", \\\"{x:1182,y:838,t:1527189148432};\\\", \\\"{x:1175,y:835,t:1527189148448};\\\", \\\"{x:1168,y:831,t:1527189148465};\\\", \\\"{x:1165,y:828,t:1527189148482};\\\", \\\"{x:1164,y:827,t:1527189148507};\\\", \\\"{x:1163,y:826,t:1527189148533};\\\", \\\"{x:1163,y:825,t:1527189148549};\\\", \\\"{x:1162,y:823,t:1527189148566};\\\", \\\"{x:1162,y:822,t:1527189148587};\\\", \\\"{x:1162,y:821,t:1527189148599};\\\", \\\"{x:1162,y:819,t:1527189148615};\\\", \\\"{x:1162,y:816,t:1527189148632};\\\", \\\"{x:1162,y:814,t:1527189148649};\\\", \\\"{x:1162,y:810,t:1527189148666};\\\", \\\"{x:1162,y:809,t:1527189148682};\\\", \\\"{x:1162,y:806,t:1527189148699};\\\", \\\"{x:1163,y:795,t:1527189148715};\\\", \\\"{x:1165,y:790,t:1527189148733};\\\", \\\"{x:1165,y:786,t:1527189148749};\\\", \\\"{x:1166,y:786,t:1527189148804};\\\", \\\"{x:1167,y:785,t:1527189148859};\\\", \\\"{x:1167,y:784,t:1527189148868};\\\", \\\"{x:1167,y:782,t:1527189148881};\\\", \\\"{x:1167,y:780,t:1527189148899};\\\", \\\"{x:1171,y:768,t:1527189148915};\\\", \\\"{x:1174,y:758,t:1527189148934};\\\", \\\"{x:1176,y:750,t:1527189148949};\\\", \\\"{x:1178,y:741,t:1527189148967};\\\", \\\"{x:1181,y:737,t:1527189148982};\\\", \\\"{x:1181,y:742,t:1527189149116};\\\", \\\"{x:1181,y:751,t:1527189149133};\\\", \\\"{x:1181,y:757,t:1527189149150};\\\", \\\"{x:1181,y:763,t:1527189149166};\\\", \\\"{x:1181,y:768,t:1527189149183};\\\", \\\"{x:1181,y:773,t:1527189149200};\\\", \\\"{x:1181,y:779,t:1527189149216};\\\", \\\"{x:1181,y:780,t:1527189149232};\\\", \\\"{x:1182,y:780,t:1527189149363};\\\", \\\"{x:1182,y:779,t:1527189149410};\\\", \\\"{x:1182,y:777,t:1527189149419};\\\", \\\"{x:1182,y:775,t:1527189149433};\\\", \\\"{x:1182,y:772,t:1527189149449};\\\", \\\"{x:1182,y:769,t:1527189149466};\\\", \\\"{x:1182,y:768,t:1527189149534};\\\", \\\"{x:1181,y:768,t:1527189163631};\\\", \\\"{x:1183,y:763,t:1527189163644};\\\", \\\"{x:1191,y:748,t:1527189163662};\\\", \\\"{x:1202,y:733,t:1527189163677};\\\", \\\"{x:1211,y:717,t:1527189163694};\\\", \\\"{x:1220,y:703,t:1527189163710};\\\", \\\"{x:1233,y:687,t:1527189163727};\\\", \\\"{x:1238,y:680,t:1527189163744};\\\", \\\"{x:1244,y:670,t:1527189163761};\\\", \\\"{x:1251,y:660,t:1527189163777};\\\", \\\"{x:1257,y:648,t:1527189163794};\\\", \\\"{x:1269,y:629,t:1527189163811};\\\", \\\"{x:1279,y:615,t:1527189163827};\\\", \\\"{x:1289,y:598,t:1527189163844};\\\", \\\"{x:1299,y:581,t:1527189163861};\\\", \\\"{x:1306,y:566,t:1527189163876};\\\", \\\"{x:1311,y:549,t:1527189163894};\\\", \\\"{x:1320,y:524,t:1527189163911};\\\", \\\"{x:1328,y:510,t:1527189163927};\\\", \\\"{x:1333,y:500,t:1527189163944};\\\", \\\"{x:1337,y:494,t:1527189163961};\\\", \\\"{x:1340,y:489,t:1527189163976};\\\", \\\"{x:1340,y:487,t:1527189163994};\\\", \\\"{x:1340,y:485,t:1527189164011};\\\", \\\"{x:1340,y:484,t:1527189164078};\\\", \\\"{x:1337,y:483,t:1527189164094};\\\", \\\"{x:1332,y:483,t:1527189164110};\\\", \\\"{x:1324,y:486,t:1527189164128};\\\", \\\"{x:1312,y:501,t:1527189164143};\\\", \\\"{x:1294,y:525,t:1527189164161};\\\", \\\"{x:1282,y:537,t:1527189164178};\\\", \\\"{x:1273,y:547,t:1527189164194};\\\", \\\"{x:1270,y:552,t:1527189164211};\\\", \\\"{x:1268,y:555,t:1527189164228};\\\", \\\"{x:1268,y:556,t:1527189164244};\\\", \\\"{x:1268,y:557,t:1527189164261};\\\", \\\"{x:1267,y:559,t:1527189164278};\\\", \\\"{x:1267,y:560,t:1527189164294};\\\", \\\"{x:1267,y:562,t:1527189164310};\\\", \\\"{x:1267,y:563,t:1527189164328};\\\", \\\"{x:1266,y:563,t:1527189164343};\\\", \\\"{x:1266,y:564,t:1527189164743};\\\", \\\"{x:1267,y:564,t:1527189164750};\\\", \\\"{x:1270,y:562,t:1527189164761};\\\", \\\"{x:1275,y:556,t:1527189164778};\\\", \\\"{x:1278,y:553,t:1527189164794};\\\", \\\"{x:1280,y:549,t:1527189164811};\\\", \\\"{x:1280,y:550,t:1527189165815};\\\", \\\"{x:1280,y:553,t:1527189165828};\\\", \\\"{x:1278,y:556,t:1527189165845};\\\", \\\"{x:1277,y:559,t:1527189165863};\\\", \\\"{x:1277,y:560,t:1527189165878};\\\", \\\"{x:1277,y:561,t:1527189165894};\\\", \\\"{x:1277,y:567,t:1527189171647};\\\", \\\"{x:1289,y:600,t:1527189171666};\\\", \\\"{x:1300,y:642,t:1527189171682};\\\", \\\"{x:1316,y:692,t:1527189171698};\\\", \\\"{x:1328,y:737,t:1527189171715};\\\", \\\"{x:1336,y:768,t:1527189171731};\\\", \\\"{x:1345,y:796,t:1527189171748};\\\", \\\"{x:1352,y:820,t:1527189171765};\\\", \\\"{x:1361,y:841,t:1527189171782};\\\", \\\"{x:1374,y:869,t:1527189171798};\\\", \\\"{x:1381,y:880,t:1527189171815};\\\", \\\"{x:1384,y:885,t:1527189171832};\\\", \\\"{x:1384,y:886,t:1527189171848};\\\", \\\"{x:1384,y:885,t:1527189171999};\\\", \\\"{x:1378,y:874,t:1527189172015};\\\", \\\"{x:1368,y:863,t:1527189172032};\\\", \\\"{x:1354,y:846,t:1527189172048};\\\", \\\"{x:1347,y:839,t:1527189172065};\\\", \\\"{x:1342,y:834,t:1527189172083};\\\", \\\"{x:1337,y:829,t:1527189172099};\\\", \\\"{x:1335,y:826,t:1527189172115};\\\", \\\"{x:1333,y:823,t:1527189172132};\\\", \\\"{x:1333,y:821,t:1527189172148};\\\", \\\"{x:1332,y:819,t:1527189172166};\\\", \\\"{x:1331,y:817,t:1527189172182};\\\", \\\"{x:1331,y:816,t:1527189172198};\\\", \\\"{x:1330,y:812,t:1527189172214};\\\", \\\"{x:1328,y:808,t:1527189172232};\\\", \\\"{x:1328,y:804,t:1527189172248};\\\", \\\"{x:1326,y:800,t:1527189172265};\\\", \\\"{x:1325,y:794,t:1527189172282};\\\", \\\"{x:1324,y:793,t:1527189172297};\\\", \\\"{x:1324,y:790,t:1527189172315};\\\", \\\"{x:1324,y:789,t:1527189172365};\\\", \\\"{x:1324,y:795,t:1527189172454};\\\", \\\"{x:1324,y:804,t:1527189172465};\\\", \\\"{x:1328,y:817,t:1527189172482};\\\", \\\"{x:1328,y:835,t:1527189172498};\\\", \\\"{x:1332,y:856,t:1527189172515};\\\", \\\"{x:1337,y:874,t:1527189172532};\\\", \\\"{x:1341,y:890,t:1527189172547};\\\", \\\"{x:1347,y:903,t:1527189172565};\\\", \\\"{x:1352,y:914,t:1527189172581};\\\", \\\"{x:1354,y:916,t:1527189172597};\\\", \\\"{x:1355,y:918,t:1527189172615};\\\", \\\"{x:1356,y:919,t:1527189172632};\\\", \\\"{x:1356,y:920,t:1527189172654};\\\", \\\"{x:1356,y:921,t:1527189172685};\\\", \\\"{x:1356,y:919,t:1527189172823};\\\", \\\"{x:1356,y:915,t:1527189172831};\\\", \\\"{x:1360,y:908,t:1527189172848};\\\", \\\"{x:1363,y:903,t:1527189172865};\\\", \\\"{x:1367,y:898,t:1527189172882};\\\", \\\"{x:1371,y:893,t:1527189172899};\\\", \\\"{x:1372,y:891,t:1527189172914};\\\", \\\"{x:1372,y:889,t:1527189172932};\\\", \\\"{x:1372,y:888,t:1527189174519};\\\", \\\"{x:1373,y:884,t:1527189174533};\\\", \\\"{x:1392,y:870,t:1527189174550};\\\", \\\"{x:1405,y:861,t:1527189174567};\\\", \\\"{x:1423,y:852,t:1527189174583};\\\", \\\"{x:1435,y:843,t:1527189174600};\\\", \\\"{x:1444,y:838,t:1527189174616};\\\", \\\"{x:1449,y:834,t:1527189174634};\\\", \\\"{x:1452,y:830,t:1527189174650};\\\", \\\"{x:1455,y:826,t:1527189174666};\\\", \\\"{x:1461,y:818,t:1527189174683};\\\", \\\"{x:1470,y:808,t:1527189174700};\\\", \\\"{x:1481,y:794,t:1527189174715};\\\", \\\"{x:1491,y:783,t:1527189174732};\\\", \\\"{x:1506,y:766,t:1527189174749};\\\", \\\"{x:1516,y:753,t:1527189174766};\\\", \\\"{x:1524,y:743,t:1527189174783};\\\", \\\"{x:1531,y:732,t:1527189174800};\\\", \\\"{x:1537,y:723,t:1527189174816};\\\", \\\"{x:1540,y:720,t:1527189174833};\\\", \\\"{x:1542,y:717,t:1527189174850};\\\", \\\"{x:1542,y:716,t:1527189174865};\\\", \\\"{x:1543,y:716,t:1527189174910};\\\", \\\"{x:1542,y:716,t:1527189174998};\\\", \\\"{x:1540,y:716,t:1527189175014};\\\", \\\"{x:1539,y:716,t:1527189175022};\\\", \\\"{x:1537,y:717,t:1527189175038};\\\", \\\"{x:1537,y:718,t:1527189175049};\\\", \\\"{x:1534,y:721,t:1527189175066};\\\", \\\"{x:1533,y:724,t:1527189175083};\\\", \\\"{x:1533,y:725,t:1527189175103};\\\", \\\"{x:1532,y:727,t:1527189175116};\\\", \\\"{x:1532,y:728,t:1527189175133};\\\", \\\"{x:1531,y:730,t:1527189175150};\\\", \\\"{x:1529,y:731,t:1527189175215};\\\", \\\"{x:1529,y:732,t:1527189175223};\\\", \\\"{x:1529,y:733,t:1527189175233};\\\", \\\"{x:1527,y:736,t:1527189175250};\\\", \\\"{x:1526,y:739,t:1527189175267};\\\", \\\"{x:1525,y:742,t:1527189175283};\\\", \\\"{x:1521,y:747,t:1527189175301};\\\", \\\"{x:1520,y:749,t:1527189175318};\\\", \\\"{x:1520,y:751,t:1527189175333};\\\", \\\"{x:1518,y:752,t:1527189175350};\\\", \\\"{x:1517,y:754,t:1527189175366};\\\", \\\"{x:1517,y:756,t:1527189175383};\\\", \\\"{x:1514,y:759,t:1527189175401};\\\", \\\"{x:1513,y:763,t:1527189175433};\\\", \\\"{x:1512,y:764,t:1527189175451};\\\", \\\"{x:1511,y:765,t:1527189175467};\\\", \\\"{x:1511,y:766,t:1527189175483};\\\", \\\"{x:1511,y:767,t:1527189175574};\\\", \\\"{x:1510,y:769,t:1527189175584};\\\", \\\"{x:1509,y:772,t:1527189175600};\\\", \\\"{x:1509,y:773,t:1527189175617};\\\", \\\"{x:1509,y:772,t:1527189176031};\\\", \\\"{x:1509,y:769,t:1527189176038};\\\", \\\"{x:1511,y:764,t:1527189176051};\\\", \\\"{x:1512,y:764,t:1527189176067};\\\", \\\"{x:1513,y:761,t:1527189176084};\\\", \\\"{x:1512,y:762,t:1527189177247};\\\", \\\"{x:1511,y:764,t:1527189177254};\\\", \\\"{x:1509,y:768,t:1527189177268};\\\", \\\"{x:1502,y:779,t:1527189177284};\\\", \\\"{x:1496,y:787,t:1527189177301};\\\", \\\"{x:1490,y:794,t:1527189177318};\\\", \\\"{x:1489,y:799,t:1527189177334};\\\", \\\"{x:1487,y:801,t:1527189177351};\\\", \\\"{x:1486,y:802,t:1527189177367};\\\", \\\"{x:1484,y:804,t:1527189177743};\\\", \\\"{x:1483,y:804,t:1527189177752};\\\", \\\"{x:1482,y:809,t:1527189177768};\\\", \\\"{x:1479,y:815,t:1527189177785};\\\", \\\"{x:1476,y:823,t:1527189177801};\\\", \\\"{x:1473,y:828,t:1527189177819};\\\", \\\"{x:1471,y:833,t:1527189177836};\\\", \\\"{x:1470,y:837,t:1527189177851};\\\", \\\"{x:1468,y:839,t:1527189177868};\\\", \\\"{x:1468,y:836,t:1527189178535};\\\", \\\"{x:1468,y:833,t:1527189178552};\\\", \\\"{x:1470,y:828,t:1527189178568};\\\", \\\"{x:1472,y:823,t:1527189178586};\\\", \\\"{x:1474,y:818,t:1527189178603};\\\", \\\"{x:1476,y:814,t:1527189178618};\\\", \\\"{x:1477,y:812,t:1527189178636};\\\", \\\"{x:1479,y:809,t:1527189178653};\\\", \\\"{x:1480,y:806,t:1527189178668};\\\", \\\"{x:1481,y:803,t:1527189178685};\\\", \\\"{x:1484,y:798,t:1527189178702};\\\", \\\"{x:1487,y:792,t:1527189178718};\\\", \\\"{x:1490,y:787,t:1527189178736};\\\", \\\"{x:1494,y:782,t:1527189178752};\\\", \\\"{x:1498,y:776,t:1527189178769};\\\", \\\"{x:1500,y:772,t:1527189178786};\\\", \\\"{x:1503,y:769,t:1527189178802};\\\", \\\"{x:1504,y:767,t:1527189178819};\\\", \\\"{x:1505,y:765,t:1527189179071};\\\", \\\"{x:1507,y:763,t:1527189179085};\\\", \\\"{x:1516,y:758,t:1527189179102};\\\", \\\"{x:1520,y:755,t:1527189179120};\\\", \\\"{x:1523,y:754,t:1527189179137};\\\", \\\"{x:1525,y:753,t:1527189179153};\\\", \\\"{x:1526,y:754,t:1527189179279};\\\", \\\"{x:1526,y:755,t:1527189179286};\\\", \\\"{x:1527,y:758,t:1527189179302};\\\", \\\"{x:1527,y:759,t:1527189179320};\\\", \\\"{x:1527,y:762,t:1527189180271};\\\", \\\"{x:1527,y:765,t:1527189180286};\\\", \\\"{x:1527,y:768,t:1527189180304};\\\", \\\"{x:1527,y:769,t:1527189180320};\\\", \\\"{x:1527,y:771,t:1527189180336};\\\", \\\"{x:1526,y:771,t:1527189182822};\\\", \\\"{x:1525,y:771,t:1527189182838};\\\", \\\"{x:1517,y:779,t:1527189182854};\\\", \\\"{x:1511,y:787,t:1527189182870};\\\", \\\"{x:1503,y:794,t:1527189182888};\\\", \\\"{x:1498,y:800,t:1527189182905};\\\", \\\"{x:1495,y:801,t:1527189182921};\\\", \\\"{x:1495,y:800,t:1527189183143};\\\", \\\"{x:1495,y:799,t:1527189183174};\\\", \\\"{x:1495,y:798,t:1527189183263};\\\", \\\"{x:1495,y:797,t:1527189183272};\\\", \\\"{x:1495,y:796,t:1527189183288};\\\", \\\"{x:1495,y:794,t:1527189183305};\\\", \\\"{x:1496,y:792,t:1527189183322};\\\", \\\"{x:1497,y:791,t:1527189183338};\\\", \\\"{x:1498,y:789,t:1527189183354};\\\", \\\"{x:1498,y:788,t:1527189183375};\\\", \\\"{x:1499,y:787,t:1527189183390};\\\", \\\"{x:1499,y:785,t:1527189183414};\\\", \\\"{x:1499,y:784,t:1527189183431};\\\", \\\"{x:1500,y:784,t:1527189183438};\\\", \\\"{x:1501,y:783,t:1527189183455};\\\", \\\"{x:1501,y:782,t:1527189183471};\\\", \\\"{x:1501,y:781,t:1527189183551};\\\", \\\"{x:1501,y:780,t:1527189183566};\\\", \\\"{x:1501,y:779,t:1527189183574};\\\", \\\"{x:1501,y:778,t:1527189183590};\\\", \\\"{x:1502,y:777,t:1527189183606};\\\", \\\"{x:1502,y:776,t:1527189183622};\\\", \\\"{x:1502,y:775,t:1527189183638};\\\", \\\"{x:1502,y:773,t:1527189183671};\\\", \\\"{x:1504,y:772,t:1527189183688};\\\", \\\"{x:1505,y:770,t:1527189183710};\\\", \\\"{x:1505,y:769,t:1527189183726};\\\", \\\"{x:1507,y:767,t:1527189183743};\\\", \\\"{x:1507,y:766,t:1527189183758};\\\", \\\"{x:1508,y:765,t:1527189183771};\\\", \\\"{x:1509,y:763,t:1527189183789};\\\", \\\"{x:1509,y:760,t:1527189183805};\\\", \\\"{x:1511,y:758,t:1527189183822};\\\", \\\"{x:1514,y:754,t:1527189183838};\\\", \\\"{x:1515,y:753,t:1527189183854};\\\", \\\"{x:1515,y:752,t:1527189183871};\\\", \\\"{x:1515,y:754,t:1527189190975};\\\", \\\"{x:1513,y:760,t:1527189190992};\\\", \\\"{x:1511,y:763,t:1527189191009};\\\", \\\"{x:1511,y:764,t:1527189191026};\\\", \\\"{x:1510,y:766,t:1527189191041};\\\", \\\"{x:1509,y:767,t:1527189191060};\\\", \\\"{x:1509,y:769,t:1527189191076};\\\", \\\"{x:1509,y:772,t:1527189191092};\\\", \\\"{x:1507,y:775,t:1527189191109};\\\", \\\"{x:1506,y:778,t:1527189191126};\\\", \\\"{x:1504,y:781,t:1527189191142};\\\", \\\"{x:1503,y:783,t:1527189191159};\\\", \\\"{x:1502,y:785,t:1527189191176};\\\", \\\"{x:1500,y:788,t:1527189191192};\\\", \\\"{x:1496,y:793,t:1527189191209};\\\", \\\"{x:1492,y:797,t:1527189191226};\\\", \\\"{x:1487,y:802,t:1527189191242};\\\", \\\"{x:1484,y:807,t:1527189191259};\\\", \\\"{x:1477,y:812,t:1527189191275};\\\", \\\"{x:1471,y:817,t:1527189191292};\\\", \\\"{x:1461,y:824,t:1527189191308};\\\", \\\"{x:1453,y:828,t:1527189191326};\\\", \\\"{x:1445,y:833,t:1527189191341};\\\", \\\"{x:1440,y:835,t:1527189191358};\\\", \\\"{x:1434,y:839,t:1527189191376};\\\", \\\"{x:1427,y:843,t:1527189191393};\\\", \\\"{x:1422,y:846,t:1527189191409};\\\", \\\"{x:1417,y:848,t:1527189191426};\\\", \\\"{x:1414,y:849,t:1527189191442};\\\", \\\"{x:1410,y:850,t:1527189191458};\\\", \\\"{x:1403,y:852,t:1527189191476};\\\", \\\"{x:1397,y:853,t:1527189191493};\\\", \\\"{x:1390,y:854,t:1527189191509};\\\", \\\"{x:1372,y:858,t:1527189191526};\\\", \\\"{x:1360,y:859,t:1527189191541};\\\", \\\"{x:1343,y:860,t:1527189191559};\\\", \\\"{x:1331,y:860,t:1527189191575};\\\", \\\"{x:1318,y:860,t:1527189191592};\\\", \\\"{x:1309,y:860,t:1527189191609};\\\", \\\"{x:1300,y:860,t:1527189191626};\\\", \\\"{x:1290,y:860,t:1527189191643};\\\", \\\"{x:1276,y:860,t:1527189191659};\\\", \\\"{x:1257,y:856,t:1527189191676};\\\", \\\"{x:1236,y:854,t:1527189191692};\\\", \\\"{x:1208,y:846,t:1527189191708};\\\", \\\"{x:1161,y:832,t:1527189191726};\\\", \\\"{x:1121,y:816,t:1527189191742};\\\", \\\"{x:1077,y:800,t:1527189191759};\\\", \\\"{x:1034,y:785,t:1527189191776};\\\", \\\"{x:992,y:772,t:1527189191792};\\\", \\\"{x:962,y:762,t:1527189191809};\\\", \\\"{x:927,y:748,t:1527189191825};\\\", \\\"{x:895,y:738,t:1527189191843};\\\", \\\"{x:858,y:721,t:1527189191859};\\\", \\\"{x:829,y:709,t:1527189191876};\\\", \\\"{x:811,y:701,t:1527189191893};\\\", \\\"{x:792,y:690,t:1527189191908};\\\", \\\"{x:765,y:667,t:1527189191926};\\\", \\\"{x:736,y:648,t:1527189191943};\\\", \\\"{x:706,y:630,t:1527189191960};\\\", \\\"{x:692,y:623,t:1527189191975};\\\", \\\"{x:683,y:618,t:1527189191992};\\\", \\\"{x:681,y:615,t:1527189192009};\\\", \\\"{x:681,y:611,t:1527189192024};\\\", \\\"{x:681,y:609,t:1527189192041};\\\", \\\"{x:682,y:605,t:1527189192059};\\\", \\\"{x:684,y:602,t:1527189192074};\\\", \\\"{x:689,y:597,t:1527189192092};\\\", \\\"{x:698,y:592,t:1527189192109};\\\", \\\"{x:714,y:588,t:1527189192125};\\\", \\\"{x:738,y:588,t:1527189192142};\\\", \\\"{x:772,y:594,t:1527189192159};\\\", \\\"{x:791,y:597,t:1527189192175};\\\", \\\"{x:804,y:599,t:1527189192191};\\\", \\\"{x:808,y:600,t:1527189192208};\\\", \\\"{x:812,y:603,t:1527189192226};\\\", \\\"{x:816,y:606,t:1527189192242};\\\", \\\"{x:821,y:610,t:1527189192259};\\\", \\\"{x:824,y:612,t:1527189192275};\\\", \\\"{x:825,y:613,t:1527189192318};\\\", \\\"{x:824,y:613,t:1527189192325};\\\", \\\"{x:820,y:615,t:1527189192342};\\\", \\\"{x:810,y:616,t:1527189192359};\\\", \\\"{x:788,y:616,t:1527189192375};\\\", \\\"{x:760,y:616,t:1527189192392};\\\", \\\"{x:723,y:624,t:1527189192409};\\\", \\\"{x:699,y:631,t:1527189192425};\\\", \\\"{x:682,y:635,t:1527189192443};\\\", \\\"{x:673,y:635,t:1527189192458};\\\", \\\"{x:671,y:635,t:1527189192476};\\\", \\\"{x:670,y:635,t:1527189192501};\\\", \\\"{x:670,y:634,t:1527189192509};\\\", \\\"{x:670,y:629,t:1527189192526};\\\", \\\"{x:670,y:623,t:1527189192542};\\\", \\\"{x:670,y:616,t:1527189192558};\\\", \\\"{x:667,y:607,t:1527189192576};\\\", \\\"{x:665,y:598,t:1527189192592};\\\", \\\"{x:662,y:587,t:1527189192609};\\\", \\\"{x:656,y:577,t:1527189192626};\\\", \\\"{x:645,y:567,t:1527189192642};\\\", \\\"{x:630,y:561,t:1527189192659};\\\", \\\"{x:614,y:560,t:1527189192675};\\\", \\\"{x:602,y:560,t:1527189192693};\\\", \\\"{x:590,y:560,t:1527189192709};\\\", \\\"{x:589,y:560,t:1527189192725};\\\", \\\"{x:588,y:561,t:1527189192838};\\\", \\\"{x:588,y:562,t:1527189192845};\\\", \\\"{x:588,y:564,t:1527189192861};\\\", \\\"{x:588,y:569,t:1527189192875};\\\", \\\"{x:589,y:573,t:1527189192893};\\\", \\\"{x:592,y:576,t:1527189192909};\\\", \\\"{x:593,y:576,t:1527189192925};\\\", \\\"{x:594,y:576,t:1527189192965};\\\", \\\"{x:596,y:576,t:1527189192975};\\\", \\\"{x:603,y:577,t:1527189192993};\\\", \\\"{x:610,y:581,t:1527189193009};\\\", \\\"{x:616,y:583,t:1527189193026};\\\", \\\"{x:621,y:585,t:1527189193043};\\\", \\\"{x:621,y:584,t:1527189193126};\\\", \\\"{x:620,y:582,t:1527189193143};\\\", \\\"{x:620,y:581,t:1527189193278};\\\", \\\"{x:619,y:581,t:1527189193292};\\\", \\\"{x:614,y:580,t:1527189193310};\\\", \\\"{x:613,y:580,t:1527189193326};\\\", \\\"{x:611,y:580,t:1527189193342};\\\", \\\"{x:609,y:578,t:1527189193360};\\\", \\\"{x:608,y:578,t:1527189193377};\\\", \\\"{x:608,y:577,t:1527189193393};\\\", \\\"{x:605,y:577,t:1527189193410};\\\", \\\"{x:604,y:577,t:1527189193426};\\\", \\\"{x:602,y:576,t:1527189193442};\\\", \\\"{x:601,y:576,t:1527189193477};\\\", \\\"{x:602,y:576,t:1527189193757};\\\", \\\"{x:610,y:576,t:1527189193766};\\\", \\\"{x:617,y:576,t:1527189193776};\\\", \\\"{x:637,y:580,t:1527189193794};\\\", \\\"{x:659,y:582,t:1527189193810};\\\", \\\"{x:681,y:585,t:1527189193827};\\\", \\\"{x:699,y:587,t:1527189193843};\\\", \\\"{x:713,y:589,t:1527189193860};\\\", \\\"{x:721,y:589,t:1527189193877};\\\", \\\"{x:733,y:589,t:1527189193894};\\\", \\\"{x:741,y:589,t:1527189193910};\\\", \\\"{x:751,y:588,t:1527189193926};\\\", \\\"{x:768,y:585,t:1527189193943};\\\", \\\"{x:784,y:583,t:1527189193961};\\\", \\\"{x:798,y:581,t:1527189193976};\\\", \\\"{x:805,y:579,t:1527189193994};\\\", \\\"{x:806,y:579,t:1527189194010};\\\", \\\"{x:807,y:578,t:1527189194062};\\\", \\\"{x:808,y:578,t:1527189194134};\\\", \\\"{x:810,y:578,t:1527189194144};\\\", \\\"{x:811,y:578,t:1527189194238};\\\", \\\"{x:812,y:578,t:1527189194245};\\\", \\\"{x:814,y:578,t:1527189194261};\\\", \\\"{x:819,y:578,t:1527189194278};\\\", \\\"{x:821,y:578,t:1527189194294};\\\", \\\"{x:822,y:578,t:1527189194311};\\\", \\\"{x:823,y:578,t:1527189194430};\\\", \\\"{x:824,y:578,t:1527189194444};\\\", \\\"{x:825,y:578,t:1527189194462};\\\", \\\"{x:825,y:579,t:1527189194493};\\\", \\\"{x:825,y:579,t:1527189194537};\\\", \\\"{x:823,y:579,t:1527189194694};\\\", \\\"{x:812,y:582,t:1527189194711};\\\", \\\"{x:796,y:591,t:1527189194727};\\\", \\\"{x:779,y:603,t:1527189194744};\\\", \\\"{x:764,y:620,t:1527189194760};\\\", \\\"{x:755,y:632,t:1527189194779};\\\", \\\"{x:741,y:650,t:1527189194794};\\\", \\\"{x:728,y:667,t:1527189194811};\\\", \\\"{x:711,y:685,t:1527189194828};\\\", \\\"{x:686,y:702,t:1527189194844};\\\", \\\"{x:662,y:715,t:1527189194860};\\\", \\\"{x:625,y:727,t:1527189194878};\\\", \\\"{x:604,y:732,t:1527189194895};\\\", \\\"{x:585,y:733,t:1527189194911};\\\", \\\"{x:571,y:735,t:1527189194928};\\\", \\\"{x:559,y:735,t:1527189194947};\\\", \\\"{x:547,y:732,t:1527189194961};\\\", \\\"{x:534,y:727,t:1527189194978};\\\", \\\"{x:521,y:721,t:1527189194995};\\\", \\\"{x:515,y:719,t:1527189195011};\\\", \\\"{x:512,y:719,t:1527189195028};\\\", \\\"{x:508,y:719,t:1527189195045};\\\", \\\"{x:505,y:719,t:1527189195061};\\\", \\\"{x:503,y:719,t:1527189195077};\\\", \\\"{x:502,y:719,t:1527189195094};\\\", \\\"{x:501,y:719,t:1527189195117};\\\", \\\"{x:501,y:721,t:1527189195303};\\\", \\\"{x:503,y:724,t:1527189195311};\\\", \\\"{x:507,y:727,t:1527189195328};\\\", \\\"{x:508,y:728,t:1527189195344};\\\", \\\"{x:508,y:729,t:1527189195365};\\\" ] }, { \\\"rt\\\": 81890, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 662802, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -F -F -G -G -G -G -G -F -F -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:729,t:1527189197309};\\\", \\\"{x:510,y:729,t:1527189197313};\\\", \\\"{x:511,y:728,t:1527189197329};\\\", \\\"{x:516,y:728,t:1527189197346};\\\", \\\"{x:517,y:728,t:1527189197373};\\\", \\\"{x:519,y:727,t:1527189197381};\\\", \\\"{x:521,y:726,t:1527189197395};\\\", \\\"{x:523,y:726,t:1527189197413};\\\", \\\"{x:526,y:725,t:1527189197429};\\\", \\\"{x:538,y:722,t:1527189197445};\\\", \\\"{x:541,y:719,t:1527189197463};\\\", \\\"{x:550,y:715,t:1527189197480};\\\", \\\"{x:559,y:710,t:1527189197497};\\\", \\\"{x:567,y:707,t:1527189197513};\\\", \\\"{x:570,y:705,t:1527189197530};\\\", \\\"{x:571,y:705,t:1527189197547};\\\", \\\"{x:572,y:705,t:1527189197654};\\\", \\\"{x:573,y:705,t:1527189197694};\\\", \\\"{x:572,y:704,t:1527189199014};\\\", \\\"{x:571,y:704,t:1527189199038};\\\", \\\"{x:571,y:703,t:1527189199048};\\\", \\\"{x:568,y:702,t:1527189201830};\\\", \\\"{x:553,y:694,t:1527189201839};\\\", \\\"{x:535,y:686,t:1527189201852};\\\", \\\"{x:469,y:657,t:1527189201870};\\\", \\\"{x:308,y:591,t:1527189201886};\\\", \\\"{x:89,y:525,t:1527189201918};\\\", \\\"{x:0,y:500,t:1527189201933};\\\", \\\"{x:0,y:480,t:1527189201949};\\\", \\\"{x:0,y:467,t:1527189201965};\\\", \\\"{x:0,y:461,t:1527189201983};\\\", \\\"{x:0,y:460,t:1527189202000};\\\", \\\"{x:0,y:458,t:1527189202037};\\\", \\\"{x:0,y:457,t:1527189202053};\\\", \\\"{x:4,y:454,t:1527189202067};\\\", \\\"{x:12,y:451,t:1527189202083};\\\", \\\"{x:26,y:447,t:1527189202099};\\\", \\\"{x:86,y:451,t:1527189202117};\\\", \\\"{x:115,y:456,t:1527189202133};\\\", \\\"{x:199,y:472,t:1527189202150};\\\", \\\"{x:236,y:478,t:1527189202167};\\\", \\\"{x:263,y:482,t:1527189202183};\\\", \\\"{x:283,y:488,t:1527189202201};\\\", \\\"{x:291,y:489,t:1527189202217};\\\", \\\"{x:290,y:489,t:1527189202397};\\\", \\\"{x:287,y:489,t:1527189202405};\\\", \\\"{x:285,y:489,t:1527189202418};\\\", \\\"{x:280,y:487,t:1527189202433};\\\", \\\"{x:269,y:482,t:1527189202452};\\\", \\\"{x:257,y:477,t:1527189202468};\\\", \\\"{x:250,y:474,t:1527189202483};\\\", \\\"{x:250,y:473,t:1527189202501};\\\", \\\"{x:255,y:472,t:1527189202630};\\\", \\\"{x:260,y:469,t:1527189202638};\\\", \\\"{x:270,y:466,t:1527189202650};\\\", \\\"{x:296,y:464,t:1527189202667};\\\", \\\"{x:329,y:464,t:1527189202684};\\\", \\\"{x:363,y:464,t:1527189202701};\\\", \\\"{x:399,y:464,t:1527189202717};\\\", \\\"{x:453,y:464,t:1527189202734};\\\", \\\"{x:482,y:464,t:1527189202751};\\\", \\\"{x:514,y:464,t:1527189202768};\\\", \\\"{x:547,y:464,t:1527189202784};\\\", \\\"{x:582,y:464,t:1527189202801};\\\", \\\"{x:611,y:469,t:1527189202818};\\\", \\\"{x:642,y:473,t:1527189202834};\\\", \\\"{x:675,y:477,t:1527189202851};\\\", \\\"{x:722,y:485,t:1527189202867};\\\", \\\"{x:785,y:498,t:1527189202885};\\\", \\\"{x:900,y:513,t:1527189202901};\\\", \\\"{x:998,y:528,t:1527189202918};\\\", \\\"{x:1100,y:542,t:1527189202934};\\\", \\\"{x:1221,y:567,t:1527189202951};\\\", \\\"{x:1348,y:601,t:1527189202966};\\\", \\\"{x:1478,y:624,t:1527189202984};\\\", \\\"{x:1612,y:645,t:1527189203001};\\\", \\\"{x:1713,y:653,t:1527189203017};\\\", \\\"{x:1762,y:655,t:1527189203034};\\\", \\\"{x:1764,y:655,t:1527189203051};\\\", \\\"{x:1767,y:655,t:1527189203566};\\\", \\\"{x:1770,y:652,t:1527189203574};\\\", \\\"{x:1777,y:646,t:1527189203584};\\\", \\\"{x:1792,y:628,t:1527189203602};\\\", \\\"{x:1810,y:611,t:1527189203618};\\\", \\\"{x:1826,y:597,t:1527189203635};\\\", \\\"{x:1839,y:583,t:1527189203651};\\\", \\\"{x:1848,y:573,t:1527189203669};\\\", \\\"{x:1856,y:564,t:1527189203684};\\\", \\\"{x:1870,y:552,t:1527189203702};\\\", \\\"{x:1889,y:540,t:1527189203718};\\\", \\\"{x:1912,y:525,t:1527189203735};\\\", \\\"{x:1886,y:509,t:1527189203926};\\\", \\\"{x:1846,y:524,t:1527189203935};\\\", \\\"{x:1752,y:566,t:1527189203952};\\\", \\\"{x:1652,y:600,t:1527189203968};\\\", \\\"{x:1563,y:625,t:1527189203986};\\\", \\\"{x:1476,y:654,t:1527189204003};\\\", \\\"{x:1424,y:667,t:1527189204019};\\\", \\\"{x:1398,y:676,t:1527189204035};\\\", \\\"{x:1392,y:678,t:1527189204053};\\\", \\\"{x:1389,y:669,t:1527189204191};\\\", \\\"{x:1379,y:644,t:1527189204203};\\\", \\\"{x:1346,y:580,t:1527189204220};\\\", \\\"{x:1309,y:522,t:1527189204236};\\\", \\\"{x:1289,y:498,t:1527189204252};\\\", \\\"{x:1273,y:488,t:1527189204269};\\\", \\\"{x:1265,y:484,t:1527189204286};\\\", \\\"{x:1264,y:484,t:1527189204303};\\\", \\\"{x:1262,y:484,t:1527189204325};\\\", \\\"{x:1261,y:484,t:1527189204336};\\\", \\\"{x:1257,y:484,t:1527189204353};\\\", \\\"{x:1251,y:485,t:1527189204369};\\\", \\\"{x:1246,y:487,t:1527189204386};\\\", \\\"{x:1241,y:489,t:1527189204403};\\\", \\\"{x:1238,y:491,t:1527189204419};\\\", \\\"{x:1234,y:493,t:1527189204437};\\\", \\\"{x:1232,y:494,t:1527189204453};\\\", \\\"{x:1234,y:494,t:1527189204574};\\\", \\\"{x:1235,y:494,t:1527189204587};\\\", \\\"{x:1244,y:493,t:1527189204604};\\\", \\\"{x:1255,y:493,t:1527189204621};\\\", \\\"{x:1274,y:493,t:1527189204638};\\\", \\\"{x:1291,y:493,t:1527189204654};\\\", \\\"{x:1307,y:493,t:1527189204671};\\\", \\\"{x:1324,y:493,t:1527189204687};\\\", \\\"{x:1343,y:493,t:1527189204703};\\\", \\\"{x:1365,y:493,t:1527189204721};\\\", \\\"{x:1388,y:493,t:1527189204738};\\\", \\\"{x:1411,y:493,t:1527189204753};\\\", \\\"{x:1432,y:493,t:1527189204770};\\\", \\\"{x:1454,y:493,t:1527189204787};\\\", \\\"{x:1480,y:493,t:1527189204805};\\\", \\\"{x:1516,y:498,t:1527189204821};\\\", \\\"{x:1574,y:507,t:1527189204838};\\\", \\\"{x:1600,y:509,t:1527189204854};\\\", \\\"{x:1623,y:511,t:1527189204871};\\\", \\\"{x:1640,y:511,t:1527189204888};\\\", \\\"{x:1652,y:511,t:1527189204904};\\\", \\\"{x:1662,y:511,t:1527189204921};\\\", \\\"{x:1666,y:511,t:1527189204938};\\\", \\\"{x:1668,y:510,t:1527189204955};\\\", \\\"{x:1668,y:512,t:1527189226586};\\\", \\\"{x:1647,y:564,t:1527189226602};\\\", \\\"{x:1623,y:617,t:1527189226621};\\\", \\\"{x:1605,y:663,t:1527189226635};\\\", \\\"{x:1583,y:708,t:1527189226652};\\\", \\\"{x:1565,y:736,t:1527189226669};\\\", \\\"{x:1551,y:756,t:1527189226685};\\\", \\\"{x:1537,y:774,t:1527189226703};\\\", \\\"{x:1530,y:787,t:1527189226719};\\\", \\\"{x:1523,y:798,t:1527189226736};\\\", \\\"{x:1517,y:806,t:1527189226753};\\\", \\\"{x:1513,y:811,t:1527189226769};\\\", \\\"{x:1510,y:816,t:1527189226785};\\\", \\\"{x:1505,y:824,t:1527189226803};\\\", \\\"{x:1500,y:830,t:1527189226821};\\\", \\\"{x:1494,y:832,t:1527189226836};\\\", \\\"{x:1488,y:832,t:1527189226853};\\\", \\\"{x:1479,y:820,t:1527189226869};\\\", \\\"{x:1467,y:805,t:1527189226886};\\\", \\\"{x:1452,y:787,t:1527189226902};\\\", \\\"{x:1437,y:775,t:1527189226920};\\\", \\\"{x:1418,y:767,t:1527189226936};\\\", \\\"{x:1399,y:762,t:1527189226952};\\\", \\\"{x:1385,y:761,t:1527189226969};\\\", \\\"{x:1375,y:761,t:1527189226986};\\\", \\\"{x:1365,y:760,t:1527189227003};\\\", \\\"{x:1363,y:759,t:1527189227020};\\\", \\\"{x:1362,y:759,t:1527189227037};\\\", \\\"{x:1361,y:759,t:1527189227065};\\\", \\\"{x:1361,y:758,t:1527189227121};\\\", \\\"{x:1361,y:754,t:1527189227137};\\\", \\\"{x:1361,y:752,t:1527189227153};\\\", \\\"{x:1361,y:747,t:1527189227170};\\\", \\\"{x:1358,y:741,t:1527189227187};\\\", \\\"{x:1352,y:730,t:1527189227204};\\\", \\\"{x:1348,y:722,t:1527189227219};\\\", \\\"{x:1346,y:718,t:1527189227237};\\\", \\\"{x:1345,y:716,t:1527189227254};\\\", \\\"{x:1345,y:713,t:1527189227270};\\\", \\\"{x:1345,y:712,t:1527189227287};\\\", \\\"{x:1345,y:711,t:1527189227304};\\\", \\\"{x:1345,y:710,t:1527189227320};\\\", \\\"{x:1345,y:709,t:1527189227345};\\\", \\\"{x:1345,y:708,t:1527189227369};\\\", \\\"{x:1345,y:707,t:1527189227433};\\\", \\\"{x:1345,y:706,t:1527189227449};\\\", \\\"{x:1345,y:705,t:1527189227456};\\\", \\\"{x:1345,y:704,t:1527189227471};\\\", \\\"{x:1345,y:703,t:1527189227489};\\\", \\\"{x:1345,y:701,t:1527189227507};\\\", \\\"{x:1345,y:699,t:1527189227553};\\\", \\\"{x:1345,y:698,t:1527189227571};\\\", \\\"{x:1345,y:696,t:1527189227588};\\\", \\\"{x:1345,y:695,t:1527189227603};\\\", \\\"{x:1347,y:691,t:1527189241955};\\\", \\\"{x:1352,y:686,t:1527189241968};\\\", \\\"{x:1363,y:674,t:1527189241984};\\\", \\\"{x:1375,y:661,t:1527189242000};\\\", \\\"{x:1379,y:657,t:1527189242017};\\\", \\\"{x:1382,y:654,t:1527189242033};\\\", \\\"{x:1387,y:650,t:1527189242051};\\\", \\\"{x:1391,y:648,t:1527189242067};\\\", \\\"{x:1393,y:645,t:1527189242084};\\\", \\\"{x:1397,y:642,t:1527189242101};\\\", \\\"{x:1402,y:638,t:1527189242118};\\\", \\\"{x:1407,y:634,t:1527189242135};\\\", \\\"{x:1411,y:630,t:1527189242150};\\\", \\\"{x:1416,y:626,t:1527189242168};\\\", \\\"{x:1425,y:615,t:1527189242185};\\\", \\\"{x:1431,y:607,t:1527189242201};\\\", \\\"{x:1437,y:602,t:1527189242218};\\\", \\\"{x:1442,y:596,t:1527189242234};\\\", \\\"{x:1445,y:591,t:1527189242251};\\\", \\\"{x:1447,y:589,t:1527189242268};\\\", \\\"{x:1447,y:588,t:1527189242285};\\\", \\\"{x:1447,y:587,t:1527189242302};\\\", \\\"{x:1447,y:586,t:1527189242317};\\\", \\\"{x:1448,y:585,t:1527189242335};\\\", \\\"{x:1448,y:584,t:1527189242352};\\\", \\\"{x:1448,y:582,t:1527189242368};\\\", \\\"{x:1448,y:581,t:1527189242384};\\\", \\\"{x:1447,y:580,t:1527189242401};\\\", \\\"{x:1446,y:579,t:1527189242417};\\\", \\\"{x:1444,y:578,t:1527189242434};\\\", \\\"{x:1442,y:576,t:1527189242451};\\\", \\\"{x:1439,y:575,t:1527189242468};\\\", \\\"{x:1438,y:575,t:1527189242484};\\\", \\\"{x:1437,y:575,t:1527189242545};\\\", \\\"{x:1436,y:575,t:1527189242553};\\\", \\\"{x:1434,y:573,t:1527189242569};\\\", \\\"{x:1430,y:572,t:1527189242584};\\\", \\\"{x:1429,y:572,t:1527189242602};\\\", \\\"{x:1426,y:572,t:1527189242620};\\\", \\\"{x:1423,y:571,t:1527189242634};\\\", \\\"{x:1422,y:571,t:1527189242652};\\\", \\\"{x:1421,y:571,t:1527189242669};\\\", \\\"{x:1420,y:570,t:1527189242826};\\\", \\\"{x:1419,y:569,t:1527189242836};\\\", \\\"{x:1416,y:569,t:1527189242852};\\\", \\\"{x:1415,y:568,t:1527189242869};\\\", \\\"{x:1415,y:567,t:1527189243161};\\\", \\\"{x:1414,y:567,t:1527189243801};\\\", \\\"{x:1413,y:567,t:1527189243817};\\\", \\\"{x:1412,y:567,t:1527189243824};\\\", \\\"{x:1410,y:567,t:1527189243836};\\\", \\\"{x:1407,y:566,t:1527189243854};\\\", \\\"{x:1406,y:566,t:1527189243880};\\\", \\\"{x:1406,y:564,t:1527189244097};\\\", \\\"{x:1407,y:563,t:1527189244113};\\\", \\\"{x:1408,y:562,t:1527189244121};\\\", \\\"{x:1410,y:562,t:1527189244139};\\\", \\\"{x:1411,y:562,t:1527189245329};\\\", \\\"{x:1412,y:562,t:1527189245340};\\\", \\\"{x:1417,y:562,t:1527189245357};\\\", \\\"{x:1418,y:562,t:1527189245374};\\\", \\\"{x:1419,y:562,t:1527189245760};\\\", \\\"{x:1419,y:563,t:1527189245774};\\\", \\\"{x:1418,y:564,t:1527189245792};\\\", \\\"{x:1417,y:564,t:1527189245809};\\\", \\\"{x:1416,y:564,t:1527189245825};\\\", \\\"{x:1415,y:564,t:1527189247937};\\\", \\\"{x:1400,y:574,t:1527189247946};\\\", \\\"{x:1344,y:599,t:1527189247963};\\\", \\\"{x:1264,y:619,t:1527189247980};\\\", \\\"{x:1177,y:638,t:1527189247996};\\\", \\\"{x:1074,y:654,t:1527189248012};\\\", \\\"{x:979,y:658,t:1527189248030};\\\", \\\"{x:887,y:658,t:1527189248046};\\\", \\\"{x:823,y:658,t:1527189248063};\\\", \\\"{x:773,y:658,t:1527189248080};\\\", \\\"{x:744,y:658,t:1527189248095};\\\", \\\"{x:722,y:659,t:1527189248112};\\\", \\\"{x:710,y:662,t:1527189248129};\\\", \\\"{x:699,y:663,t:1527189248146};\\\", \\\"{x:682,y:664,t:1527189248162};\\\", \\\"{x:652,y:664,t:1527189248180};\\\", \\\"{x:607,y:664,t:1527189248197};\\\", \\\"{x:540,y:664,t:1527189248212};\\\", \\\"{x:468,y:656,t:1527189248231};\\\", \\\"{x:399,y:637,t:1527189248246};\\\", \\\"{x:371,y:627,t:1527189248264};\\\", \\\"{x:364,y:613,t:1527189248289};\\\", \\\"{x:380,y:597,t:1527189248306};\\\", \\\"{x:402,y:586,t:1527189248322};\\\", \\\"{x:430,y:578,t:1527189248341};\\\", \\\"{x:461,y:572,t:1527189248357};\\\", \\\"{x:492,y:567,t:1527189248374};\\\", \\\"{x:532,y:562,t:1527189248392};\\\", \\\"{x:581,y:559,t:1527189248407};\\\", \\\"{x:662,y:559,t:1527189248423};\\\", \\\"{x:718,y:559,t:1527189248441};\\\", \\\"{x:762,y:559,t:1527189248457};\\\", \\\"{x:799,y:559,t:1527189248474};\\\", \\\"{x:827,y:559,t:1527189248491};\\\", \\\"{x:849,y:559,t:1527189248507};\\\", \\\"{x:861,y:559,t:1527189248524};\\\", \\\"{x:864,y:559,t:1527189248541};\\\", \\\"{x:867,y:557,t:1527189248609};\\\", \\\"{x:877,y:552,t:1527189248626};\\\", \\\"{x:880,y:550,t:1527189248641};\\\", \\\"{x:882,y:549,t:1527189248657};\\\", \\\"{x:879,y:549,t:1527189248712};\\\", \\\"{x:876,y:549,t:1527189248724};\\\", \\\"{x:871,y:550,t:1527189248740};\\\", \\\"{x:866,y:550,t:1527189248757};\\\", \\\"{x:860,y:552,t:1527189248774};\\\", \\\"{x:856,y:552,t:1527189248791};\\\", \\\"{x:853,y:552,t:1527189248807};\\\", \\\"{x:852,y:552,t:1527189248824};\\\", \\\"{x:850,y:552,t:1527189248842};\\\", \\\"{x:844,y:552,t:1527189248858};\\\", \\\"{x:841,y:552,t:1527189248875};\\\", \\\"{x:840,y:552,t:1527189248892};\\\", \\\"{x:838,y:551,t:1527189248909};\\\", \\\"{x:834,y:548,t:1527189248924};\\\", \\\"{x:828,y:544,t:1527189248942};\\\", \\\"{x:819,y:539,t:1527189248960};\\\", \\\"{x:817,y:538,t:1527189248974};\\\", \\\"{x:817,y:537,t:1527189248991};\\\", \\\"{x:819,y:537,t:1527189249817};\\\", \\\"{x:827,y:537,t:1527189249827};\\\", \\\"{x:867,y:547,t:1527189249842};\\\", \\\"{x:919,y:560,t:1527189249858};\\\", \\\"{x:972,y:572,t:1527189249874};\\\", \\\"{x:1016,y:584,t:1527189249892};\\\", \\\"{x:1067,y:594,t:1527189249908};\\\", \\\"{x:1126,y:610,t:1527189249926};\\\", \\\"{x:1189,y:626,t:1527189249942};\\\", \\\"{x:1257,y:641,t:1527189249958};\\\", \\\"{x:1314,y:653,t:1527189249975};\\\", \\\"{x:1376,y:663,t:1527189249992};\\\", \\\"{x:1409,y:666,t:1527189250009};\\\", \\\"{x:1442,y:671,t:1527189250025};\\\", \\\"{x:1464,y:671,t:1527189250042};\\\", \\\"{x:1476,y:671,t:1527189250058};\\\", \\\"{x:1484,y:671,t:1527189250075};\\\", \\\"{x:1485,y:671,t:1527189250160};\\\", \\\"{x:1486,y:671,t:1527189250191};\\\", \\\"{x:1486,y:667,t:1527189250216};\\\", \\\"{x:1486,y:662,t:1527189250226};\\\", \\\"{x:1480,y:653,t:1527189250243};\\\", \\\"{x:1474,y:648,t:1527189250259};\\\", \\\"{x:1469,y:645,t:1527189250275};\\\", \\\"{x:1467,y:645,t:1527189250293};\\\", \\\"{x:1467,y:644,t:1527189250309};\\\", \\\"{x:1464,y:641,t:1527189250449};\\\", \\\"{x:1458,y:636,t:1527189250459};\\\", \\\"{x:1441,y:625,t:1527189250475};\\\", \\\"{x:1427,y:619,t:1527189250492};\\\", \\\"{x:1420,y:614,t:1527189250509};\\\", \\\"{x:1420,y:612,t:1527189250650};\\\", \\\"{x:1420,y:611,t:1527189250660};\\\", \\\"{x:1420,y:606,t:1527189250677};\\\", \\\"{x:1420,y:599,t:1527189250693};\\\", \\\"{x:1423,y:592,t:1527189250709};\\\", \\\"{x:1425,y:586,t:1527189250726};\\\", \\\"{x:1427,y:581,t:1527189250743};\\\", \\\"{x:1429,y:579,t:1527189250760};\\\", \\\"{x:1429,y:577,t:1527189250857};\\\", \\\"{x:1427,y:576,t:1527189250872};\\\", \\\"{x:1426,y:575,t:1527189250880};\\\", \\\"{x:1424,y:575,t:1527189250893};\\\", \\\"{x:1424,y:574,t:1527189250910};\\\", \\\"{x:1423,y:574,t:1527189250929};\\\", \\\"{x:1420,y:574,t:1527189251169};\\\", \\\"{x:1408,y:578,t:1527189251177};\\\", \\\"{x:1368,y:589,t:1527189251194};\\\", \\\"{x:1317,y:608,t:1527189251210};\\\", \\\"{x:1245,y:628,t:1527189251226};\\\", \\\"{x:1168,y:644,t:1527189251244};\\\", \\\"{x:1098,y:655,t:1527189251259};\\\", \\\"{x:1048,y:661,t:1527189251276};\\\", \\\"{x:1019,y:663,t:1527189251293};\\\", \\\"{x:1000,y:663,t:1527189251309};\\\", \\\"{x:987,y:666,t:1527189251326};\\\", \\\"{x:974,y:667,t:1527189251344};\\\", \\\"{x:959,y:669,t:1527189251360};\\\", \\\"{x:931,y:671,t:1527189251376};\\\", \\\"{x:908,y:671,t:1527189251393};\\\", \\\"{x:890,y:671,t:1527189251410};\\\", \\\"{x:884,y:670,t:1527189251427};\\\", \\\"{x:883,y:659,t:1527189251443};\\\", \\\"{x:883,y:637,t:1527189251459};\\\", \\\"{x:883,y:612,t:1527189251477};\\\", \\\"{x:883,y:591,t:1527189251494};\\\", \\\"{x:878,y:571,t:1527189251510};\\\", \\\"{x:868,y:564,t:1527189251524};\\\", \\\"{x:849,y:554,t:1527189251542};\\\", \\\"{x:831,y:545,t:1527189251557};\\\", \\\"{x:800,y:535,t:1527189251576};\\\", \\\"{x:782,y:531,t:1527189251593};\\\", \\\"{x:758,y:525,t:1527189251611};\\\", \\\"{x:742,y:520,t:1527189251627};\\\", \\\"{x:739,y:519,t:1527189251643};\\\", \\\"{x:739,y:518,t:1527189251663};\\\", \\\"{x:739,y:517,t:1527189251681};\\\", \\\"{x:742,y:517,t:1527189251693};\\\", \\\"{x:743,y:517,t:1527189251712};\\\", \\\"{x:744,y:516,t:1527189251726};\\\", \\\"{x:748,y:516,t:1527189251743};\\\", \\\"{x:767,y:518,t:1527189251761};\\\", \\\"{x:783,y:521,t:1527189251776};\\\", \\\"{x:795,y:525,t:1527189251794};\\\", \\\"{x:810,y:531,t:1527189251811};\\\", \\\"{x:814,y:531,t:1527189251826};\\\", \\\"{x:815,y:531,t:1527189251843};\\\", \\\"{x:817,y:533,t:1527189251905};\\\", \\\"{x:822,y:534,t:1527189251912};\\\", \\\"{x:831,y:539,t:1527189251927};\\\", \\\"{x:846,y:543,t:1527189251944};\\\", \\\"{x:852,y:547,t:1527189251960};\\\", \\\"{x:853,y:547,t:1527189251977};\\\", \\\"{x:853,y:548,t:1527189252047};\\\", \\\"{x:853,y:549,t:1527189252064};\\\", \\\"{x:851,y:549,t:1527189252241};\\\", \\\"{x:850,y:548,t:1527189252248};\\\", \\\"{x:849,y:548,t:1527189252260};\\\", \\\"{x:849,y:547,t:1527189252277};\\\", \\\"{x:848,y:547,t:1527189252295};\\\", \\\"{x:846,y:546,t:1527189252311};\\\", \\\"{x:845,y:546,t:1527189252327};\\\", \\\"{x:844,y:546,t:1527189252369};\\\", \\\"{x:842,y:544,t:1527189252378};\\\", \\\"{x:841,y:544,t:1527189252400};\\\", \\\"{x:840,y:543,t:1527189252489};\\\", \\\"{x:839,y:543,t:1527189252504};\\\", \\\"{x:844,y:543,t:1527189253297};\\\", \\\"{x:851,y:545,t:1527189253312};\\\", \\\"{x:868,y:552,t:1527189253329};\\\", \\\"{x:880,y:557,t:1527189253345};\\\", \\\"{x:893,y:563,t:1527189253362};\\\", \\\"{x:914,y:572,t:1527189253378};\\\", \\\"{x:946,y:583,t:1527189253394};\\\", \\\"{x:989,y:592,t:1527189253412};\\\", \\\"{x:1032,y:605,t:1527189253429};\\\", \\\"{x:1068,y:611,t:1527189253445};\\\", \\\"{x:1098,y:613,t:1527189253461};\\\", \\\"{x:1134,y:619,t:1527189253479};\\\", \\\"{x:1171,y:625,t:1527189253495};\\\", \\\"{x:1202,y:627,t:1527189253511};\\\", \\\"{x:1231,y:627,t:1527189253528};\\\", \\\"{x:1247,y:627,t:1527189253545};\\\", \\\"{x:1261,y:627,t:1527189253561};\\\", \\\"{x:1278,y:623,t:1527189253578};\\\", \\\"{x:1298,y:617,t:1527189253595};\\\", \\\"{x:1313,y:611,t:1527189253611};\\\", \\\"{x:1329,y:603,t:1527189253628};\\\", \\\"{x:1333,y:601,t:1527189253645};\\\", \\\"{x:1337,y:599,t:1527189253661};\\\", \\\"{x:1341,y:594,t:1527189253679};\\\", \\\"{x:1347,y:589,t:1527189253695};\\\", \\\"{x:1355,y:584,t:1527189253712};\\\", \\\"{x:1362,y:581,t:1527189253728};\\\", \\\"{x:1364,y:580,t:1527189253745};\\\", \\\"{x:1365,y:579,t:1527189253800};\\\", \\\"{x:1366,y:578,t:1527189253849};\\\", \\\"{x:1372,y:575,t:1527189253862};\\\", \\\"{x:1388,y:573,t:1527189253878};\\\", \\\"{x:1396,y:569,t:1527189253895};\\\", \\\"{x:1400,y:568,t:1527189253911};\\\", \\\"{x:1401,y:568,t:1527189253952};\\\", \\\"{x:1402,y:567,t:1527189254073};\\\", \\\"{x:1402,y:566,t:1527189254097};\\\", \\\"{x:1402,y:564,t:1527189254121};\\\", \\\"{x:1404,y:563,t:1527189254153};\\\", \\\"{x:1404,y:562,t:1527189254162};\\\", \\\"{x:1406,y:561,t:1527189254179};\\\", \\\"{x:1407,y:561,t:1527189254196};\\\", \\\"{x:1409,y:560,t:1527189254213};\\\", \\\"{x:1411,y:559,t:1527189254229};\\\", \\\"{x:1414,y:559,t:1527189254246};\\\", \\\"{x:1417,y:557,t:1527189254264};\\\", \\\"{x:1418,y:557,t:1527189254278};\\\", \\\"{x:1421,y:557,t:1527189254297};\\\", \\\"{x:1424,y:557,t:1527189254313};\\\", \\\"{x:1425,y:557,t:1527189254529};\\\", \\\"{x:1425,y:560,t:1527189254546};\\\", \\\"{x:1424,y:562,t:1527189254563};\\\", \\\"{x:1423,y:563,t:1527189254581};\\\", \\\"{x:1421,y:564,t:1527189254596};\\\", \\\"{x:1420,y:564,t:1527189255114};\\\", \\\"{x:1417,y:566,t:1527189255130};\\\", \\\"{x:1415,y:566,t:1527189255209};\\\", \\\"{x:1414,y:568,t:1527189265649};\\\", \\\"{x:1411,y:570,t:1527189265657};\\\", \\\"{x:1408,y:570,t:1527189265672};\\\", \\\"{x:1404,y:572,t:1527189265689};\\\", \\\"{x:1403,y:572,t:1527189267417};\\\", \\\"{x:1403,y:574,t:1527189267424};\\\", \\\"{x:1402,y:574,t:1527189267439};\\\", \\\"{x:1402,y:575,t:1527189267464};\\\", \\\"{x:1399,y:576,t:1527189267729};\\\", \\\"{x:1396,y:577,t:1527189267740};\\\", \\\"{x:1394,y:578,t:1527189267757};\\\", \\\"{x:1395,y:578,t:1527189268145};\\\", \\\"{x:1397,y:578,t:1527189268160};\\\", \\\"{x:1401,y:577,t:1527189268174};\\\", \\\"{x:1405,y:575,t:1527189268191};\\\", \\\"{x:1412,y:572,t:1527189268207};\\\", \\\"{x:1416,y:571,t:1527189268223};\\\", \\\"{x:1419,y:569,t:1527189268241};\\\", \\\"{x:1420,y:568,t:1527189268257};\\\", \\\"{x:1424,y:575,t:1527189269777};\\\", \\\"{x:1425,y:586,t:1527189269792};\\\", \\\"{x:1430,y:615,t:1527189269808};\\\", \\\"{x:1431,y:626,t:1527189269824};\\\", \\\"{x:1433,y:631,t:1527189269842};\\\", \\\"{x:1433,y:633,t:1527189269858};\\\", \\\"{x:1433,y:634,t:1527189269875};\\\", \\\"{x:1434,y:636,t:1527189269891};\\\", \\\"{x:1434,y:637,t:1527189269908};\\\", \\\"{x:1435,y:640,t:1527189269924};\\\", \\\"{x:1435,y:641,t:1527189269941};\\\", \\\"{x:1436,y:644,t:1527189269958};\\\", \\\"{x:1436,y:645,t:1527189269975};\\\", \\\"{x:1437,y:646,t:1527189270345};\\\", \\\"{x:1438,y:644,t:1527189270360};\\\", \\\"{x:1438,y:643,t:1527189270376};\\\", \\\"{x:1439,y:639,t:1527189270392};\\\", \\\"{x:1440,y:638,t:1527189270409};\\\", \\\"{x:1440,y:637,t:1527189270425};\\\", \\\"{x:1439,y:637,t:1527189270921};\\\", \\\"{x:1429,y:643,t:1527189270929};\\\", \\\"{x:1415,y:654,t:1527189270943};\\\", \\\"{x:1380,y:687,t:1527189270960};\\\", \\\"{x:1343,y:725,t:1527189270976};\\\", \\\"{x:1300,y:784,t:1527189270992};\\\", \\\"{x:1282,y:817,t:1527189271009};\\\", \\\"{x:1270,y:836,t:1527189271025};\\\", \\\"{x:1264,y:849,t:1527189271042};\\\", \\\"{x:1263,y:853,t:1527189271059};\\\", \\\"{x:1263,y:854,t:1527189271168};\\\", \\\"{x:1265,y:854,t:1527189271192};\\\", \\\"{x:1271,y:848,t:1527189271210};\\\", \\\"{x:1279,y:838,t:1527189271225};\\\", \\\"{x:1289,y:820,t:1527189271243};\\\", \\\"{x:1298,y:806,t:1527189271260};\\\", \\\"{x:1302,y:793,t:1527189271275};\\\", \\\"{x:1302,y:775,t:1527189271293};\\\", \\\"{x:1302,y:761,t:1527189271310};\\\", \\\"{x:1302,y:748,t:1527189271326};\\\", \\\"{x:1300,y:739,t:1527189271343};\\\", \\\"{x:1298,y:733,t:1527189271360};\\\", \\\"{x:1296,y:727,t:1527189271377};\\\", \\\"{x:1295,y:719,t:1527189271393};\\\", \\\"{x:1295,y:716,t:1527189271410};\\\", \\\"{x:1295,y:709,t:1527189271427};\\\", \\\"{x:1297,y:703,t:1527189271443};\\\", \\\"{x:1301,y:697,t:1527189271460};\\\", \\\"{x:1310,y:692,t:1527189271477};\\\", \\\"{x:1325,y:687,t:1527189271493};\\\", \\\"{x:1337,y:681,t:1527189271510};\\\", \\\"{x:1350,y:676,t:1527189271527};\\\", \\\"{x:1356,y:673,t:1527189271543};\\\", \\\"{x:1357,y:673,t:1527189271559};\\\", \\\"{x:1356,y:673,t:1527189271649};\\\", \\\"{x:1354,y:673,t:1527189271660};\\\", \\\"{x:1351,y:673,t:1527189271677};\\\", \\\"{x:1348,y:674,t:1527189271693};\\\", \\\"{x:1343,y:677,t:1527189271709};\\\", \\\"{x:1339,y:681,t:1527189271727};\\\", \\\"{x:1333,y:686,t:1527189271743};\\\", \\\"{x:1332,y:689,t:1527189271760};\\\", \\\"{x:1331,y:691,t:1527189271776};\\\", \\\"{x:1331,y:692,t:1527189271800};\\\", \\\"{x:1333,y:691,t:1527189272145};\\\", \\\"{x:1334,y:690,t:1527189272160};\\\", \\\"{x:1338,y:688,t:1527189272177};\\\", \\\"{x:1339,y:687,t:1527189272305};\\\", \\\"{x:1342,y:690,t:1527189272849};\\\", \\\"{x:1344,y:691,t:1527189272862};\\\", \\\"{x:1345,y:693,t:1527189272878};\\\", \\\"{x:1346,y:694,t:1527189272893};\\\", \\\"{x:1347,y:694,t:1527189272911};\\\", \\\"{x:1347,y:695,t:1527189272928};\\\", \\\"{x:1346,y:699,t:1527189275033};\\\", \\\"{x:1334,y:715,t:1527189275047};\\\", \\\"{x:1292,y:753,t:1527189275063};\\\", \\\"{x:1244,y:786,t:1527189275079};\\\", \\\"{x:1206,y:810,t:1527189275096};\\\", \\\"{x:1170,y:827,t:1527189275113};\\\", \\\"{x:1154,y:834,t:1527189275129};\\\", \\\"{x:1150,y:836,t:1527189275146};\\\", \\\"{x:1151,y:836,t:1527189275352};\\\", \\\"{x:1157,y:835,t:1527189275362};\\\", \\\"{x:1170,y:831,t:1527189275380};\\\", \\\"{x:1181,y:828,t:1527189275395};\\\", \\\"{x:1188,y:827,t:1527189275413};\\\", \\\"{x:1189,y:827,t:1527189275430};\\\", \\\"{x:1190,y:826,t:1527189275768};\\\", \\\"{x:1192,y:826,t:1527189275779};\\\", \\\"{x:1197,y:824,t:1527189275796};\\\", \\\"{x:1200,y:822,t:1527189275813};\\\", \\\"{x:1202,y:822,t:1527189275830};\\\", \\\"{x:1203,y:822,t:1527189275847};\\\", \\\"{x:1205,y:822,t:1527189275969};\\\", \\\"{x:1205,y:821,t:1527189275980};\\\", \\\"{x:1206,y:821,t:1527189275997};\\\", \\\"{x:1208,y:819,t:1527189276014};\\\", \\\"{x:1211,y:818,t:1527189276030};\\\", \\\"{x:1215,y:815,t:1527189276047};\\\", \\\"{x:1217,y:814,t:1527189276064};\\\", \\\"{x:1218,y:814,t:1527189276089};\\\", \\\"{x:1218,y:813,t:1527189276145};\\\", \\\"{x:1219,y:812,t:1527189276836};\\\", \\\"{x:1217,y:804,t:1527189276851};\\\", \\\"{x:1212,y:777,t:1527189276867};\\\", \\\"{x:1214,y:767,t:1527189276883};\\\", \\\"{x:1216,y:758,t:1527189276900};\\\", \\\"{x:1216,y:749,t:1527189276916};\\\", \\\"{x:1218,y:741,t:1527189276934};\\\", \\\"{x:1220,y:731,t:1527189276950};\\\", \\\"{x:1225,y:716,t:1527189276967};\\\", \\\"{x:1230,y:704,t:1527189276985};\\\", \\\"{x:1233,y:692,t:1527189277000};\\\", \\\"{x:1236,y:683,t:1527189277017};\\\", \\\"{x:1238,y:678,t:1527189277034};\\\", \\\"{x:1239,y:674,t:1527189277051};\\\", \\\"{x:1242,y:662,t:1527189277067};\\\", \\\"{x:1245,y:653,t:1527189277083};\\\", \\\"{x:1249,y:638,t:1527189277100};\\\", \\\"{x:1253,y:621,t:1527189277117};\\\", \\\"{x:1258,y:603,t:1527189277134};\\\", \\\"{x:1264,y:586,t:1527189277150};\\\", \\\"{x:1268,y:570,t:1527189277167};\\\", \\\"{x:1269,y:556,t:1527189277184};\\\", \\\"{x:1271,y:547,t:1527189277201};\\\", \\\"{x:1272,y:540,t:1527189277217};\\\", \\\"{x:1272,y:537,t:1527189277234};\\\", \\\"{x:1273,y:534,t:1527189277251};\\\", \\\"{x:1273,y:536,t:1527189277452};\\\", \\\"{x:1273,y:547,t:1527189277467};\\\", \\\"{x:1273,y:559,t:1527189277484};\\\", \\\"{x:1274,y:568,t:1527189277502};\\\", \\\"{x:1275,y:573,t:1527189277518};\\\", \\\"{x:1276,y:575,t:1527189277535};\\\", \\\"{x:1277,y:576,t:1527189277552};\\\", \\\"{x:1275,y:589,t:1527189278156};\\\", \\\"{x:1259,y:612,t:1527189278169};\\\", \\\"{x:1207,y:672,t:1527189278185};\\\", \\\"{x:1155,y:729,t:1527189278201};\\\", \\\"{x:1082,y:780,t:1527189278218};\\\", \\\"{x:968,y:829,t:1527189278236};\\\", \\\"{x:896,y:862,t:1527189278252};\\\", \\\"{x:831,y:895,t:1527189278268};\\\", \\\"{x:785,y:920,t:1527189278285};\\\", \\\"{x:757,y:928,t:1527189278301};\\\", \\\"{x:731,y:935,t:1527189278318};\\\", \\\"{x:705,y:937,t:1527189278335};\\\", \\\"{x:678,y:937,t:1527189278351};\\\", \\\"{x:645,y:925,t:1527189278368};\\\", \\\"{x:601,y:907,t:1527189278385};\\\", \\\"{x:544,y:876,t:1527189278401};\\\", \\\"{x:506,y:856,t:1527189278418};\\\", \\\"{x:488,y:838,t:1527189278435};\\\", \\\"{x:485,y:821,t:1527189278451};\\\", \\\"{x:485,y:802,t:1527189278468};\\\", \\\"{x:490,y:780,t:1527189278485};\\\", \\\"{x:497,y:761,t:1527189278501};\\\", \\\"{x:506,y:747,t:1527189278519};\\\", \\\"{x:508,y:730,t:1527189278535};\\\", \\\"{x:508,y:717,t:1527189278552};\\\", \\\"{x:505,y:712,t:1527189278561};\\\", \\\"{x:502,y:710,t:1527189278577};\\\", \\\"{x:502,y:709,t:1527189278593};\\\", \\\"{x:501,y:709,t:1527189278731};\\\", \\\"{x:501,y:711,t:1527189278744};\\\", \\\"{x:501,y:719,t:1527189278761};\\\", \\\"{x:504,y:732,t:1527189278779};\\\", \\\"{x:506,y:744,t:1527189278794};\\\", \\\"{x:510,y:753,t:1527189278819};\\\", \\\"{x:510,y:754,t:1527189278836};\\\", \\\"{x:511,y:754,t:1527189279139};\\\", \\\"{x:514,y:754,t:1527189279152};\\\", \\\"{x:520,y:751,t:1527189279169};\\\", \\\"{x:528,y:747,t:1527189279186};\\\", \\\"{x:530,y:744,t:1527189279202};\\\" ] }, { \\\"rt\\\": 113784, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 778118, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -E -B -B -B -B -B -J -J -J -J -09 AM-I -E -F -J -B -B -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:533,y:743,t:1527189290467};\\\", \\\"{x:540,y:742,t:1527189290475};\\\", \\\"{x:552,y:742,t:1527189290486};\\\", \\\"{x:579,y:742,t:1527189290504};\\\", \\\"{x:611,y:742,t:1527189290520};\\\", \\\"{x:649,y:742,t:1527189290536};\\\", \\\"{x:705,y:742,t:1527189290560};\\\", \\\"{x:742,y:742,t:1527189290577};\\\", \\\"{x:773,y:742,t:1527189290593};\\\", \\\"{x:823,y:742,t:1527189290610};\\\", \\\"{x:849,y:742,t:1527189290627};\\\", \\\"{x:870,y:739,t:1527189290643};\\\", \\\"{x:895,y:739,t:1527189290660};\\\", \\\"{x:922,y:739,t:1527189290678};\\\", \\\"{x:946,y:740,t:1527189290693};\\\", \\\"{x:961,y:744,t:1527189290711};\\\", \\\"{x:968,y:748,t:1527189290728};\\\", \\\"{x:974,y:756,t:1527189290743};\\\", \\\"{x:984,y:770,t:1527189290761};\\\", \\\"{x:997,y:786,t:1527189290778};\\\", \\\"{x:1013,y:798,t:1527189290794};\\\", \\\"{x:1032,y:806,t:1527189290811};\\\", \\\"{x:1046,y:809,t:1527189290827};\\\", \\\"{x:1063,y:812,t:1527189290844};\\\", \\\"{x:1089,y:818,t:1527189290861};\\\", \\\"{x:1121,y:821,t:1527189290878};\\\", \\\"{x:1153,y:826,t:1527189290894};\\\", \\\"{x:1179,y:830,t:1527189290911};\\\", \\\"{x:1205,y:833,t:1527189290928};\\\", \\\"{x:1228,y:836,t:1527189290944};\\\", \\\"{x:1243,y:838,t:1527189290961};\\\", \\\"{x:1249,y:838,t:1527189290978};\\\", \\\"{x:1251,y:838,t:1527189290994};\\\", \\\"{x:1250,y:838,t:1527189291148};\\\", \\\"{x:1248,y:839,t:1527189291161};\\\", \\\"{x:1245,y:839,t:1527189291178};\\\", \\\"{x:1237,y:840,t:1527189291195};\\\", \\\"{x:1231,y:840,t:1527189291211};\\\", \\\"{x:1214,y:841,t:1527189291228};\\\", \\\"{x:1208,y:842,t:1527189291245};\\\", \\\"{x:1207,y:842,t:1527189291340};\\\", \\\"{x:1205,y:836,t:1527189291347};\\\", \\\"{x:1201,y:822,t:1527189291361};\\\", \\\"{x:1189,y:795,t:1527189291378};\\\", \\\"{x:1180,y:772,t:1527189291396};\\\", \\\"{x:1180,y:768,t:1527189291414};\\\", \\\"{x:1180,y:764,t:1527189291427};\\\", \\\"{x:1180,y:763,t:1527189293964};\\\", \\\"{x:1181,y:759,t:1527189293979};\\\", \\\"{x:1197,y:730,t:1527189293997};\\\", \\\"{x:1210,y:710,t:1527189294013};\\\", \\\"{x:1218,y:692,t:1527189294030};\\\", \\\"{x:1224,y:683,t:1527189294046};\\\", \\\"{x:1228,y:676,t:1527189294063};\\\", \\\"{x:1233,y:668,t:1527189294080};\\\", \\\"{x:1236,y:661,t:1527189294096};\\\", \\\"{x:1240,y:653,t:1527189294113};\\\", \\\"{x:1245,y:642,t:1527189294130};\\\", \\\"{x:1250,y:628,t:1527189294146};\\\", \\\"{x:1259,y:608,t:1527189294163};\\\", \\\"{x:1264,y:596,t:1527189294179};\\\", \\\"{x:1268,y:582,t:1527189294196};\\\", \\\"{x:1271,y:573,t:1527189294213};\\\", \\\"{x:1273,y:569,t:1527189294230};\\\", \\\"{x:1274,y:566,t:1527189294246};\\\", \\\"{x:1275,y:562,t:1527189294264};\\\", \\\"{x:1276,y:559,t:1527189294281};\\\", \\\"{x:1277,y:558,t:1527189294297};\\\", \\\"{x:1277,y:555,t:1527189294314};\\\", \\\"{x:1277,y:553,t:1527189294330};\\\", \\\"{x:1280,y:549,t:1527189294347};\\\", \\\"{x:1281,y:546,t:1527189294364};\\\", \\\"{x:1281,y:545,t:1527189294380};\\\", \\\"{x:1282,y:545,t:1527189315851};\\\", \\\"{x:1302,y:584,t:1527189315861};\\\", \\\"{x:1339,y:647,t:1527189315878};\\\", \\\"{x:1384,y:713,t:1527189315894};\\\", \\\"{x:1432,y:781,t:1527189315911};\\\", \\\"{x:1484,y:841,t:1527189315928};\\\", \\\"{x:1534,y:899,t:1527189315945};\\\", \\\"{x:1591,y:954,t:1527189315961};\\\", \\\"{x:1642,y:1004,t:1527189315978};\\\", \\\"{x:1715,y:1069,t:1527189315996};\\\", \\\"{x:1756,y:1104,t:1527189316011};\\\", \\\"{x:1795,y:1136,t:1527189316028};\\\", \\\"{x:1821,y:1159,t:1527189316045};\\\", \\\"{x:1826,y:1162,t:1527189316060};\\\", \\\"{x:1824,y:1160,t:1527189316131};\\\", \\\"{x:1812,y:1152,t:1527189316145};\\\", \\\"{x:1775,y:1128,t:1527189316160};\\\", \\\"{x:1727,y:1093,t:1527189316178};\\\", \\\"{x:1637,y:1038,t:1527189316195};\\\", \\\"{x:1565,y:992,t:1527189316211};\\\", \\\"{x:1506,y:951,t:1527189316228};\\\", \\\"{x:1465,y:925,t:1527189316245};\\\", \\\"{x:1445,y:912,t:1527189316261};\\\", \\\"{x:1438,y:906,t:1527189316278};\\\", \\\"{x:1437,y:904,t:1527189316295};\\\", \\\"{x:1436,y:900,t:1527189316331};\\\", \\\"{x:1433,y:894,t:1527189316346};\\\", \\\"{x:1428,y:886,t:1527189316361};\\\", \\\"{x:1426,y:883,t:1527189316378};\\\", \\\"{x:1423,y:879,t:1527189316396};\\\", \\\"{x:1409,y:866,t:1527189316411};\\\", \\\"{x:1390,y:851,t:1527189316428};\\\", \\\"{x:1366,y:834,t:1527189316445};\\\", \\\"{x:1333,y:814,t:1527189316463};\\\", \\\"{x:1297,y:789,t:1527189316478};\\\", \\\"{x:1260,y:762,t:1527189316495};\\\", \\\"{x:1246,y:753,t:1527189316511};\\\", \\\"{x:1244,y:751,t:1527189316528};\\\", \\\"{x:1244,y:750,t:1527189316610};\\\", \\\"{x:1244,y:748,t:1527189316643};\\\", \\\"{x:1245,y:748,t:1527189316650};\\\", \\\"{x:1246,y:748,t:1527189316662};\\\", \\\"{x:1252,y:746,t:1527189316678};\\\", \\\"{x:1261,y:744,t:1527189316695};\\\", \\\"{x:1275,y:741,t:1527189316712};\\\", \\\"{x:1289,y:739,t:1527189316728};\\\", \\\"{x:1307,y:739,t:1527189316745};\\\", \\\"{x:1328,y:739,t:1527189316762};\\\", \\\"{x:1343,y:738,t:1527189316778};\\\", \\\"{x:1351,y:736,t:1527189316795};\\\", \\\"{x:1350,y:736,t:1527189316908};\\\", \\\"{x:1349,y:737,t:1527189316915};\\\", \\\"{x:1347,y:740,t:1527189316928};\\\", \\\"{x:1344,y:745,t:1527189316945};\\\", \\\"{x:1343,y:749,t:1527189316962};\\\", \\\"{x:1342,y:752,t:1527189316979};\\\", \\\"{x:1342,y:755,t:1527189316994};\\\", \\\"{x:1340,y:764,t:1527189317012};\\\", \\\"{x:1340,y:771,t:1527189317029};\\\", \\\"{x:1340,y:775,t:1527189317045};\\\", \\\"{x:1340,y:776,t:1527189317062};\\\", \\\"{x:1341,y:778,t:1527189317204};\\\", \\\"{x:1342,y:778,t:1527189317236};\\\", \\\"{x:1343,y:778,t:1527189317275};\\\", \\\"{x:1344,y:777,t:1527189317283};\\\", \\\"{x:1346,y:774,t:1527189317295};\\\", \\\"{x:1347,y:772,t:1527189317312};\\\", \\\"{x:1348,y:769,t:1527189317329};\\\", \\\"{x:1350,y:767,t:1527189317346};\\\", \\\"{x:1351,y:765,t:1527189317362};\\\", \\\"{x:1351,y:764,t:1527189317379};\\\", \\\"{x:1351,y:762,t:1527189317404};\\\", \\\"{x:1350,y:762,t:1527189318315};\\\", \\\"{x:1349,y:763,t:1527189318331};\\\", \\\"{x:1348,y:764,t:1527189318891};\\\", \\\"{x:1345,y:767,t:1527189318899};\\\", \\\"{x:1344,y:769,t:1527189318914};\\\", \\\"{x:1341,y:772,t:1527189318930};\\\", \\\"{x:1339,y:776,t:1527189318946};\\\", \\\"{x:1339,y:777,t:1527189318964};\\\", \\\"{x:1338,y:778,t:1527189319059};\\\", \\\"{x:1337,y:779,t:1527189319067};\\\", \\\"{x:1337,y:780,t:1527189319080};\\\", \\\"{x:1336,y:783,t:1527189319097};\\\", \\\"{x:1335,y:784,t:1527189319113};\\\", \\\"{x:1335,y:785,t:1527189319131};\\\", \\\"{x:1335,y:786,t:1527189319147};\\\", \\\"{x:1335,y:787,t:1527189319163};\\\", \\\"{x:1334,y:788,t:1527189319180};\\\", \\\"{x:1333,y:789,t:1527189319198};\\\", \\\"{x:1332,y:792,t:1527189319213};\\\", \\\"{x:1331,y:793,t:1527189319230};\\\", \\\"{x:1331,y:794,t:1527189319247};\\\", \\\"{x:1329,y:797,t:1527189319264};\\\", \\\"{x:1328,y:798,t:1527189319281};\\\", \\\"{x:1328,y:799,t:1527189319297};\\\", \\\"{x:1327,y:800,t:1527189319313};\\\", \\\"{x:1327,y:801,t:1527189319331};\\\", \\\"{x:1325,y:803,t:1527189319347};\\\", \\\"{x:1325,y:804,t:1527189319387};\\\", \\\"{x:1324,y:806,t:1527189319412};\\\", \\\"{x:1323,y:807,t:1527189319460};\\\", \\\"{x:1322,y:805,t:1527189319932};\\\", \\\"{x:1325,y:791,t:1527189319947};\\\", \\\"{x:1330,y:780,t:1527189319965};\\\", \\\"{x:1334,y:773,t:1527189319980};\\\", \\\"{x:1336,y:768,t:1527189319998};\\\", \\\"{x:1339,y:764,t:1527189320014};\\\", \\\"{x:1340,y:763,t:1527189320604};\\\", \\\"{x:1339,y:763,t:1527189321900};\\\", \\\"{x:1337,y:769,t:1527189321916};\\\", \\\"{x:1335,y:774,t:1527189321932};\\\", \\\"{x:1333,y:779,t:1527189321948};\\\", \\\"{x:1331,y:782,t:1527189321966};\\\", \\\"{x:1331,y:784,t:1527189321982};\\\", \\\"{x:1329,y:786,t:1527189321999};\\\", \\\"{x:1329,y:788,t:1527189322016};\\\", \\\"{x:1328,y:790,t:1527189322033};\\\", \\\"{x:1327,y:792,t:1527189322049};\\\", \\\"{x:1326,y:794,t:1527189322065};\\\", \\\"{x:1325,y:796,t:1527189322082};\\\", \\\"{x:1324,y:799,t:1527189322099};\\\", \\\"{x:1322,y:803,t:1527189322115};\\\", \\\"{x:1321,y:805,t:1527189322132};\\\", \\\"{x:1318,y:809,t:1527189322148};\\\", \\\"{x:1317,y:813,t:1527189322166};\\\", \\\"{x:1315,y:817,t:1527189322182};\\\", \\\"{x:1313,y:821,t:1527189322199};\\\", \\\"{x:1310,y:824,t:1527189322215};\\\", \\\"{x:1307,y:829,t:1527189322233};\\\", \\\"{x:1303,y:837,t:1527189322249};\\\", \\\"{x:1299,y:843,t:1527189322266};\\\", \\\"{x:1297,y:846,t:1527189322282};\\\", \\\"{x:1293,y:853,t:1527189322299};\\\", \\\"{x:1290,y:857,t:1527189322316};\\\", \\\"{x:1287,y:862,t:1527189322333};\\\", \\\"{x:1286,y:864,t:1527189322349};\\\", \\\"{x:1285,y:866,t:1527189322365};\\\", \\\"{x:1283,y:867,t:1527189322381};\\\", \\\"{x:1283,y:868,t:1527189322399};\\\", \\\"{x:1280,y:871,t:1527189322415};\\\", \\\"{x:1279,y:872,t:1527189322432};\\\", \\\"{x:1278,y:874,t:1527189322449};\\\", \\\"{x:1276,y:877,t:1527189322465};\\\", \\\"{x:1274,y:879,t:1527189322482};\\\", \\\"{x:1270,y:884,t:1527189322498};\\\", \\\"{x:1269,y:886,t:1527189322515};\\\", \\\"{x:1268,y:888,t:1527189322532};\\\", \\\"{x:1267,y:888,t:1527189322549};\\\", \\\"{x:1267,y:890,t:1527189322565};\\\", \\\"{x:1265,y:894,t:1527189322582};\\\", \\\"{x:1263,y:896,t:1527189322600};\\\", \\\"{x:1260,y:901,t:1527189322615};\\\", \\\"{x:1256,y:910,t:1527189322632};\\\", \\\"{x:1252,y:918,t:1527189322650};\\\", \\\"{x:1248,y:924,t:1527189322665};\\\", \\\"{x:1246,y:927,t:1527189322682};\\\", \\\"{x:1243,y:935,t:1527189322698};\\\", \\\"{x:1239,y:941,t:1527189322715};\\\", \\\"{x:1238,y:945,t:1527189322732};\\\", \\\"{x:1236,y:948,t:1527189322749};\\\", \\\"{x:1234,y:951,t:1527189322766};\\\", \\\"{x:1233,y:952,t:1527189323028};\\\", \\\"{x:1236,y:954,t:1527189323035};\\\", \\\"{x:1242,y:955,t:1527189323049};\\\", \\\"{x:1245,y:957,t:1527189323066};\\\", \\\"{x:1248,y:957,t:1527189323082};\\\", \\\"{x:1250,y:958,t:1527189323099};\\\", \\\"{x:1257,y:955,t:1527189329715};\\\", \\\"{x:1268,y:945,t:1527189329723};\\\", \\\"{x:1278,y:936,t:1527189329738};\\\", \\\"{x:1300,y:917,t:1527189329753};\\\", \\\"{x:1323,y:897,t:1527189329771};\\\", \\\"{x:1330,y:891,t:1527189329787};\\\", \\\"{x:1334,y:885,t:1527189329803};\\\", \\\"{x:1340,y:878,t:1527189329820};\\\", \\\"{x:1348,y:868,t:1527189329838};\\\", \\\"{x:1356,y:858,t:1527189329853};\\\", \\\"{x:1363,y:846,t:1527189329871};\\\", \\\"{x:1370,y:833,t:1527189329888};\\\", \\\"{x:1375,y:821,t:1527189329904};\\\", \\\"{x:1379,y:812,t:1527189329921};\\\", \\\"{x:1380,y:805,t:1527189329938};\\\", \\\"{x:1382,y:798,t:1527189329953};\\\", \\\"{x:1382,y:793,t:1527189329971};\\\", \\\"{x:1382,y:790,t:1527189329987};\\\", \\\"{x:1382,y:787,t:1527189330004};\\\", \\\"{x:1382,y:784,t:1527189330021};\\\", \\\"{x:1382,y:780,t:1527189330038};\\\", \\\"{x:1381,y:775,t:1527189330053};\\\", \\\"{x:1375,y:769,t:1527189330070};\\\", \\\"{x:1367,y:762,t:1527189330087};\\\", \\\"{x:1360,y:757,t:1527189330103};\\\", \\\"{x:1354,y:753,t:1527189330120};\\\", \\\"{x:1351,y:752,t:1527189330137};\\\", \\\"{x:1350,y:752,t:1527189330155};\\\", \\\"{x:1349,y:751,t:1527189330267};\\\", \\\"{x:1347,y:751,t:1527189330371};\\\", \\\"{x:1343,y:751,t:1527189330387};\\\", \\\"{x:1341,y:754,t:1527189330404};\\\", \\\"{x:1339,y:758,t:1527189330420};\\\", \\\"{x:1338,y:760,t:1527189330437};\\\", \\\"{x:1338,y:761,t:1527189330454};\\\", \\\"{x:1339,y:762,t:1527189330883};\\\", \\\"{x:1340,y:762,t:1527189331404};\\\", \\\"{x:1341,y:762,t:1527189331422};\\\", \\\"{x:1342,y:762,t:1527189332244};\\\", \\\"{x:1344,y:762,t:1527189332273};\\\", \\\"{x:1345,y:762,t:1527189332292};\\\", \\\"{x:1346,y:762,t:1527189332307};\\\", \\\"{x:1349,y:762,t:1527189332323};\\\", \\\"{x:1356,y:764,t:1527189332341};\\\", \\\"{x:1360,y:766,t:1527189332356};\\\", \\\"{x:1363,y:767,t:1527189332373};\\\", \\\"{x:1362,y:767,t:1527189332652};\\\", \\\"{x:1360,y:767,t:1527189332659};\\\", \\\"{x:1359,y:767,t:1527189332673};\\\", \\\"{x:1355,y:767,t:1527189332688};\\\", \\\"{x:1352,y:766,t:1527189332706};\\\", \\\"{x:1351,y:765,t:1527189332779};\\\", \\\"{x:1350,y:765,t:1527189332790};\\\", \\\"{x:1349,y:765,t:1527189332806};\\\", \\\"{x:1348,y:764,t:1527189333179};\\\", \\\"{x:1347,y:765,t:1527189333563};\\\", \\\"{x:1345,y:767,t:1527189333573};\\\", \\\"{x:1342,y:773,t:1527189333591};\\\", \\\"{x:1338,y:777,t:1527189333607};\\\", \\\"{x:1335,y:781,t:1527189333623};\\\", \\\"{x:1335,y:782,t:1527189333640};\\\", \\\"{x:1333,y:784,t:1527189333657};\\\", \\\"{x:1332,y:786,t:1527189333673};\\\", \\\"{x:1331,y:788,t:1527189333690};\\\", \\\"{x:1328,y:793,t:1527189333707};\\\", \\\"{x:1326,y:795,t:1527189333723};\\\", \\\"{x:1326,y:796,t:1527189333740};\\\", \\\"{x:1325,y:798,t:1527189333757};\\\", \\\"{x:1325,y:799,t:1527189333773};\\\", \\\"{x:1324,y:801,t:1527189333790};\\\", \\\"{x:1322,y:804,t:1527189333807};\\\", \\\"{x:1321,y:806,t:1527189333824};\\\", \\\"{x:1320,y:807,t:1527189333840};\\\", \\\"{x:1319,y:810,t:1527189333857};\\\", \\\"{x:1318,y:811,t:1527189333874};\\\", \\\"{x:1317,y:812,t:1527189333890};\\\", \\\"{x:1315,y:816,t:1527189333907};\\\", \\\"{x:1315,y:818,t:1527189333924};\\\", \\\"{x:1313,y:821,t:1527189333940};\\\", \\\"{x:1312,y:823,t:1527189333957};\\\", \\\"{x:1311,y:824,t:1527189333974};\\\", \\\"{x:1310,y:826,t:1527189333990};\\\", \\\"{x:1309,y:829,t:1527189334007};\\\", \\\"{x:1307,y:831,t:1527189334024};\\\", \\\"{x:1306,y:834,t:1527189334040};\\\", \\\"{x:1305,y:836,t:1527189334057};\\\", \\\"{x:1303,y:839,t:1527189334074};\\\", \\\"{x:1302,y:842,t:1527189334090};\\\", \\\"{x:1301,y:846,t:1527189334107};\\\", \\\"{x:1299,y:850,t:1527189334124};\\\", \\\"{x:1297,y:853,t:1527189334140};\\\", \\\"{x:1297,y:855,t:1527189334157};\\\", \\\"{x:1297,y:856,t:1527189334174};\\\", \\\"{x:1296,y:858,t:1527189334190};\\\", \\\"{x:1295,y:859,t:1527189334207};\\\", \\\"{x:1294,y:861,t:1527189334224};\\\", \\\"{x:1293,y:864,t:1527189334240};\\\", \\\"{x:1291,y:867,t:1527189334257};\\\", \\\"{x:1290,y:871,t:1527189334274};\\\", \\\"{x:1289,y:874,t:1527189334291};\\\", \\\"{x:1285,y:880,t:1527189334307};\\\", \\\"{x:1283,y:884,t:1527189334324};\\\", \\\"{x:1280,y:887,t:1527189334340};\\\", \\\"{x:1275,y:894,t:1527189334357};\\\", \\\"{x:1271,y:900,t:1527189334374};\\\", \\\"{x:1266,y:906,t:1527189334391};\\\", \\\"{x:1262,y:912,t:1527189334407};\\\", \\\"{x:1259,y:916,t:1527189334424};\\\", \\\"{x:1258,y:920,t:1527189334440};\\\", \\\"{x:1256,y:922,t:1527189334457};\\\", \\\"{x:1254,y:924,t:1527189334474};\\\", \\\"{x:1253,y:926,t:1527189334491};\\\", \\\"{x:1252,y:928,t:1527189334507};\\\", \\\"{x:1252,y:930,t:1527189334531};\\\", \\\"{x:1251,y:931,t:1527189334542};\\\", \\\"{x:1251,y:933,t:1527189334557};\\\", \\\"{x:1251,y:935,t:1527189334574};\\\", \\\"{x:1250,y:936,t:1527189334591};\\\", \\\"{x:1250,y:938,t:1527189334607};\\\", \\\"{x:1250,y:941,t:1527189334624};\\\", \\\"{x:1250,y:942,t:1527189334641};\\\", \\\"{x:1249,y:944,t:1527189334659};\\\", \\\"{x:1249,y:946,t:1527189334715};\\\", \\\"{x:1249,y:947,t:1527189334724};\\\", \\\"{x:1249,y:949,t:1527189334741};\\\", \\\"{x:1248,y:950,t:1527189334757};\\\", \\\"{x:1247,y:952,t:1527189334779};\\\", \\\"{x:1247,y:953,t:1527189334828};\\\", \\\"{x:1247,y:955,t:1527189334867};\\\", \\\"{x:1246,y:956,t:1527189334891};\\\", \\\"{x:1246,y:957,t:1527189334907};\\\", \\\"{x:1246,y:959,t:1527189334924};\\\", \\\"{x:1246,y:961,t:1527189334941};\\\", \\\"{x:1248,y:958,t:1527189338823};\\\", \\\"{x:1262,y:943,t:1527189338830};\\\", \\\"{x:1284,y:927,t:1527189338847};\\\", \\\"{x:1302,y:913,t:1527189338864};\\\", \\\"{x:1313,y:896,t:1527189338881};\\\", \\\"{x:1319,y:888,t:1527189338897};\\\", \\\"{x:1323,y:883,t:1527189338914};\\\", \\\"{x:1324,y:882,t:1527189338931};\\\", \\\"{x:1325,y:881,t:1527189338947};\\\", \\\"{x:1325,y:880,t:1527189338964};\\\", \\\"{x:1325,y:879,t:1527189339047};\\\", \\\"{x:1325,y:877,t:1527189339239};\\\", \\\"{x:1324,y:875,t:1527189339270};\\\", \\\"{x:1323,y:875,t:1527189339281};\\\", \\\"{x:1315,y:878,t:1527189339298};\\\", \\\"{x:1305,y:884,t:1527189339313};\\\", \\\"{x:1294,y:890,t:1527189339331};\\\", \\\"{x:1284,y:895,t:1527189339348};\\\", \\\"{x:1277,y:898,t:1527189339364};\\\", \\\"{x:1273,y:900,t:1527189339380};\\\", \\\"{x:1270,y:901,t:1527189339398};\\\", \\\"{x:1268,y:902,t:1527189339414};\\\", \\\"{x:1267,y:902,t:1527189339447};\\\", \\\"{x:1266,y:903,t:1527189339463};\\\", \\\"{x:1264,y:903,t:1527189340335};\\\", \\\"{x:1261,y:902,t:1527189340347};\\\", \\\"{x:1251,y:899,t:1527189340364};\\\", \\\"{x:1243,y:894,t:1527189340382};\\\", \\\"{x:1235,y:889,t:1527189340398};\\\", \\\"{x:1224,y:885,t:1527189340414};\\\", \\\"{x:1223,y:884,t:1527189340447};\\\", \\\"{x:1223,y:883,t:1527189340479};\\\", \\\"{x:1222,y:882,t:1527189340486};\\\", \\\"{x:1222,y:881,t:1527189340497};\\\", \\\"{x:1222,y:878,t:1527189340514};\\\", \\\"{x:1219,y:873,t:1527189340532};\\\", \\\"{x:1218,y:867,t:1527189340548};\\\", \\\"{x:1216,y:864,t:1527189340565};\\\", \\\"{x:1215,y:859,t:1527189340582};\\\", \\\"{x:1215,y:854,t:1527189340598};\\\", \\\"{x:1215,y:846,t:1527189340614};\\\", \\\"{x:1215,y:841,t:1527189340631};\\\", \\\"{x:1214,y:837,t:1527189340649};\\\", \\\"{x:1212,y:830,t:1527189340665};\\\", \\\"{x:1211,y:825,t:1527189340681};\\\", \\\"{x:1209,y:819,t:1527189340698};\\\", \\\"{x:1207,y:817,t:1527189340715};\\\", \\\"{x:1206,y:815,t:1527189340735};\\\", \\\"{x:1206,y:816,t:1527189341023};\\\", \\\"{x:1206,y:817,t:1527189341032};\\\", \\\"{x:1206,y:818,t:1527189341049};\\\", \\\"{x:1206,y:819,t:1527189341079};\\\", \\\"{x:1209,y:819,t:1527189341487};\\\", \\\"{x:1212,y:821,t:1527189341499};\\\", \\\"{x:1219,y:824,t:1527189341516};\\\", \\\"{x:1223,y:825,t:1527189341532};\\\", \\\"{x:1225,y:826,t:1527189341549};\\\", \\\"{x:1224,y:826,t:1527189341767};\\\", \\\"{x:1223,y:825,t:1527189341783};\\\", \\\"{x:1222,y:825,t:1527189341799};\\\", \\\"{x:1220,y:824,t:1527189341855};\\\", \\\"{x:1218,y:824,t:1527189341878};\\\", \\\"{x:1217,y:824,t:1527189341885};\\\", \\\"{x:1217,y:823,t:1527189341898};\\\", \\\"{x:1215,y:823,t:1527189341915};\\\", \\\"{x:1214,y:823,t:1527189341932};\\\", \\\"{x:1212,y:822,t:1527189341948};\\\", \\\"{x:1211,y:822,t:1527189342918};\\\", \\\"{x:1212,y:825,t:1527189342934};\\\", \\\"{x:1214,y:834,t:1527189342950};\\\", \\\"{x:1217,y:845,t:1527189342967};\\\", \\\"{x:1219,y:848,t:1527189342982};\\\", \\\"{x:1220,y:853,t:1527189343000};\\\", \\\"{x:1221,y:855,t:1527189343017};\\\", \\\"{x:1221,y:860,t:1527189343032};\\\", \\\"{x:1224,y:866,t:1527189343050};\\\", \\\"{x:1226,y:875,t:1527189343066};\\\", \\\"{x:1228,y:881,t:1527189343082};\\\", \\\"{x:1230,y:890,t:1527189343099};\\\", \\\"{x:1232,y:896,t:1527189343117};\\\", \\\"{x:1233,y:901,t:1527189343132};\\\", \\\"{x:1234,y:904,t:1527189343150};\\\", \\\"{x:1235,y:910,t:1527189343165};\\\", \\\"{x:1236,y:914,t:1527189343182};\\\", \\\"{x:1236,y:915,t:1527189343199};\\\", \\\"{x:1236,y:917,t:1527189343216};\\\", \\\"{x:1236,y:918,t:1527189343232};\\\", \\\"{x:1237,y:919,t:1527189343250};\\\", \\\"{x:1237,y:920,t:1527189343266};\\\", \\\"{x:1237,y:921,t:1527189343283};\\\", \\\"{x:1238,y:923,t:1527189343299};\\\", \\\"{x:1239,y:925,t:1527189343317};\\\", \\\"{x:1240,y:928,t:1527189343333};\\\", \\\"{x:1242,y:931,t:1527189343349};\\\", \\\"{x:1243,y:933,t:1527189343366};\\\", \\\"{x:1245,y:934,t:1527189343383};\\\", \\\"{x:1247,y:938,t:1527189343399};\\\", \\\"{x:1250,y:941,t:1527189343417};\\\", \\\"{x:1256,y:945,t:1527189343434};\\\", \\\"{x:1262,y:948,t:1527189343450};\\\", \\\"{x:1266,y:950,t:1527189343466};\\\", \\\"{x:1267,y:950,t:1527189343483};\\\", \\\"{x:1268,y:951,t:1527189343502};\\\", \\\"{x:1269,y:952,t:1527189343526};\\\", \\\"{x:1270,y:952,t:1527189343534};\\\", \\\"{x:1271,y:954,t:1527189343550};\\\", \\\"{x:1274,y:957,t:1527189343566};\\\", \\\"{x:1276,y:957,t:1527189343584};\\\", \\\"{x:1277,y:957,t:1527189344999};\\\", \\\"{x:1278,y:958,t:1527189345039};\\\", \\\"{x:1279,y:958,t:1527189345051};\\\", \\\"{x:1279,y:956,t:1527189348831};\\\", \\\"{x:1259,y:935,t:1527189348839};\\\", \\\"{x:1185,y:871,t:1527189348854};\\\", \\\"{x:1085,y:806,t:1527189348870};\\\", \\\"{x:981,y:748,t:1527189348887};\\\", \\\"{x:893,y:707,t:1527189348904};\\\", \\\"{x:832,y:683,t:1527189348920};\\\", \\\"{x:787,y:661,t:1527189348936};\\\", \\\"{x:766,y:646,t:1527189348954};\\\", \\\"{x:758,y:634,t:1527189348970};\\\", \\\"{x:755,y:626,t:1527189348989};\\\", \\\"{x:754,y:619,t:1527189349003};\\\", \\\"{x:753,y:613,t:1527189349019};\\\", \\\"{x:751,y:612,t:1527189349028};\\\", \\\"{x:736,y:607,t:1527189349045};\\\", \\\"{x:718,y:605,t:1527189349063};\\\", \\\"{x:693,y:602,t:1527189349079};\\\", \\\"{x:666,y:596,t:1527189349095};\\\", \\\"{x:654,y:594,t:1527189349112};\\\", \\\"{x:646,y:591,t:1527189349130};\\\", \\\"{x:641,y:588,t:1527189349145};\\\", \\\"{x:637,y:587,t:1527189349162};\\\", \\\"{x:631,y:584,t:1527189349179};\\\", \\\"{x:622,y:583,t:1527189349195};\\\", \\\"{x:611,y:579,t:1527189349213};\\\", \\\"{x:588,y:572,t:1527189349230};\\\", \\\"{x:571,y:571,t:1527189349246};\\\", \\\"{x:554,y:568,t:1527189349263};\\\", \\\"{x:538,y:566,t:1527189349279};\\\", \\\"{x:522,y:563,t:1527189349295};\\\", \\\"{x:515,y:563,t:1527189349313};\\\", \\\"{x:512,y:563,t:1527189349329};\\\", \\\"{x:511,y:563,t:1527189349345};\\\", \\\"{x:509,y:563,t:1527189349363};\\\", \\\"{x:508,y:563,t:1527189349378};\\\", \\\"{x:503,y:560,t:1527189349396};\\\", \\\"{x:491,y:556,t:1527189349413};\\\", \\\"{x:463,y:549,t:1527189349431};\\\", \\\"{x:440,y:549,t:1527189349446};\\\", \\\"{x:415,y:551,t:1527189349463};\\\", \\\"{x:388,y:561,t:1527189349480};\\\", \\\"{x:365,y:571,t:1527189349496};\\\", \\\"{x:355,y:578,t:1527189349512};\\\", \\\"{x:349,y:585,t:1527189349530};\\\", \\\"{x:349,y:589,t:1527189349546};\\\", \\\"{x:349,y:593,t:1527189349563};\\\", \\\"{x:350,y:596,t:1527189349580};\\\", \\\"{x:352,y:598,t:1527189349596};\\\", \\\"{x:353,y:597,t:1527189349637};\\\", \\\"{x:353,y:591,t:1527189349647};\\\", \\\"{x:356,y:570,t:1527189349662};\\\", \\\"{x:358,y:549,t:1527189349680};\\\", \\\"{x:364,y:528,t:1527189349697};\\\", \\\"{x:373,y:515,t:1527189349714};\\\", \\\"{x:379,y:508,t:1527189349730};\\\", \\\"{x:381,y:505,t:1527189349746};\\\", \\\"{x:382,y:504,t:1527189349763};\\\", \\\"{x:391,y:507,t:1527189350718};\\\", \\\"{x:407,y:522,t:1527189350732};\\\", \\\"{x:463,y:560,t:1527189350747};\\\", \\\"{x:543,y:606,t:1527189350763};\\\", \\\"{x:630,y:654,t:1527189350781};\\\", \\\"{x:764,y:730,t:1527189350797};\\\", \\\"{x:857,y:787,t:1527189350813};\\\", \\\"{x:942,y:836,t:1527189350830};\\\", \\\"{x:1011,y:881,t:1527189350848};\\\", \\\"{x:1069,y:916,t:1527189350863};\\\", \\\"{x:1125,y:954,t:1527189350881};\\\", \\\"{x:1163,y:978,t:1527189350898};\\\", \\\"{x:1193,y:995,t:1527189350914};\\\", \\\"{x:1216,y:1007,t:1527189350931};\\\", \\\"{x:1239,y:1020,t:1527189350948};\\\", \\\"{x:1260,y:1031,t:1527189350964};\\\", \\\"{x:1283,y:1040,t:1527189350981};\\\", \\\"{x:1307,y:1050,t:1527189350998};\\\", \\\"{x:1311,y:1050,t:1527189351014};\\\", \\\"{x:1313,y:1047,t:1527189351078};\\\", \\\"{x:1313,y:1040,t:1527189351086};\\\", \\\"{x:1314,y:1032,t:1527189351098};\\\", \\\"{x:1315,y:1013,t:1527189351114};\\\", \\\"{x:1315,y:992,t:1527189351131};\\\", \\\"{x:1315,y:976,t:1527189351148};\\\", \\\"{x:1315,y:965,t:1527189351164};\\\", \\\"{x:1315,y:959,t:1527189351182};\\\", \\\"{x:1315,y:950,t:1527189351198};\\\", \\\"{x:1312,y:942,t:1527189351214};\\\", \\\"{x:1311,y:935,t:1527189351231};\\\", \\\"{x:1308,y:930,t:1527189351248};\\\", \\\"{x:1305,y:922,t:1527189351265};\\\", \\\"{x:1303,y:918,t:1527189351282};\\\", \\\"{x:1299,y:910,t:1527189351299};\\\", \\\"{x:1291,y:899,t:1527189351315};\\\", \\\"{x:1279,y:883,t:1527189351332};\\\", \\\"{x:1263,y:865,t:1527189351348};\\\", \\\"{x:1241,y:843,t:1527189351365};\\\", \\\"{x:1223,y:826,t:1527189351381};\\\", \\\"{x:1207,y:814,t:1527189351398};\\\", \\\"{x:1202,y:811,t:1527189351416};\\\", \\\"{x:1200,y:809,t:1527189351431};\\\", \\\"{x:1199,y:808,t:1527189351487};\\\", \\\"{x:1199,y:807,t:1527189351502};\\\", \\\"{x:1198,y:805,t:1527189351518};\\\", \\\"{x:1197,y:805,t:1527189351531};\\\", \\\"{x:1197,y:804,t:1527189351548};\\\", \\\"{x:1197,y:803,t:1527189351566};\\\", \\\"{x:1197,y:802,t:1527189351581};\\\", \\\"{x:1195,y:799,t:1527189351598};\\\", \\\"{x:1195,y:797,t:1527189351616};\\\", \\\"{x:1195,y:795,t:1527189351631};\\\", \\\"{x:1193,y:792,t:1527189351648};\\\", \\\"{x:1193,y:789,t:1527189351665};\\\", \\\"{x:1191,y:787,t:1527189351682};\\\", \\\"{x:1191,y:786,t:1527189351698};\\\", \\\"{x:1190,y:785,t:1527189351715};\\\", \\\"{x:1189,y:784,t:1527189351783};\\\", \\\"{x:1189,y:782,t:1527189351799};\\\", \\\"{x:1189,y:778,t:1527189351815};\\\", \\\"{x:1186,y:774,t:1527189351832};\\\", \\\"{x:1186,y:773,t:1527189351854};\\\", \\\"{x:1185,y:771,t:1527189352062};\\\", \\\"{x:1181,y:768,t:1527189352071};\\\", \\\"{x:1179,y:765,t:1527189352082};\\\", \\\"{x:1175,y:762,t:1527189352099};\\\", \\\"{x:1174,y:761,t:1527189352115};\\\", \\\"{x:1175,y:764,t:1527189352351};\\\", \\\"{x:1176,y:771,t:1527189352366};\\\", \\\"{x:1182,y:788,t:1527189352383};\\\", \\\"{x:1186,y:798,t:1527189352399};\\\", \\\"{x:1189,y:808,t:1527189352415};\\\", \\\"{x:1194,y:822,t:1527189352432};\\\", \\\"{x:1198,y:831,t:1527189352449};\\\", \\\"{x:1202,y:839,t:1527189352465};\\\", \\\"{x:1208,y:847,t:1527189352482};\\\", \\\"{x:1212,y:852,t:1527189352500};\\\", \\\"{x:1217,y:859,t:1527189352515};\\\", \\\"{x:1223,y:867,t:1527189352532};\\\", \\\"{x:1232,y:880,t:1527189352550};\\\", \\\"{x:1246,y:901,t:1527189352566};\\\", \\\"{x:1257,y:913,t:1527189352582};\\\", \\\"{x:1264,y:923,t:1527189352600};\\\", \\\"{x:1268,y:929,t:1527189352616};\\\", \\\"{x:1271,y:932,t:1527189352632};\\\", \\\"{x:1273,y:937,t:1527189352649};\\\", \\\"{x:1276,y:942,t:1527189352666};\\\", \\\"{x:1278,y:946,t:1527189352682};\\\", \\\"{x:1281,y:949,t:1527189352700};\\\", \\\"{x:1283,y:951,t:1527189352719};\\\", \\\"{x:1283,y:952,t:1527189352732};\\\", \\\"{x:1285,y:954,t:1527189352750};\\\", \\\"{x:1285,y:955,t:1527189352766};\\\", \\\"{x:1280,y:954,t:1527189353183};\\\", \\\"{x:1250,y:947,t:1527189353199};\\\", \\\"{x:1180,y:936,t:1527189353217};\\\", \\\"{x:1111,y:928,t:1527189353233};\\\", \\\"{x:1051,y:916,t:1527189353249};\\\", \\\"{x:1010,y:906,t:1527189353266};\\\", \\\"{x:964,y:889,t:1527189353283};\\\", \\\"{x:931,y:868,t:1527189353299};\\\", \\\"{x:907,y:844,t:1527189353316};\\\", \\\"{x:881,y:812,t:1527189353333};\\\", \\\"{x:856,y:778,t:1527189353349};\\\", \\\"{x:818,y:739,t:1527189353366};\\\", \\\"{x:789,y:723,t:1527189353383};\\\", \\\"{x:758,y:707,t:1527189353399};\\\", \\\"{x:725,y:688,t:1527189353416};\\\", \\\"{x:687,y:666,t:1527189353434};\\\", \\\"{x:633,y:636,t:1527189353450};\\\", \\\"{x:597,y:619,t:1527189353466};\\\", \\\"{x:560,y:608,t:1527189353482};\\\", \\\"{x:530,y:602,t:1527189353499};\\\", \\\"{x:508,y:600,t:1527189353516};\\\", \\\"{x:491,y:595,t:1527189353533};\\\", \\\"{x:468,y:589,t:1527189353549};\\\", \\\"{x:461,y:586,t:1527189353565};\\\", \\\"{x:458,y:584,t:1527189353582};\\\", \\\"{x:455,y:583,t:1527189353599};\\\", \\\"{x:454,y:582,t:1527189353615};\\\", \\\"{x:452,y:582,t:1527189353632};\\\", \\\"{x:452,y:581,t:1527189353649};\\\", \\\"{x:451,y:581,t:1527189353669};\\\", \\\"{x:451,y:580,t:1527189353702};\\\", \\\"{x:449,y:580,t:1527189354702};\\\", \\\"{x:444,y:582,t:1527189354717};\\\", \\\"{x:418,y:595,t:1527189354735};\\\", \\\"{x:401,y:598,t:1527189354750};\\\", \\\"{x:392,y:602,t:1527189354767};\\\", \\\"{x:391,y:602,t:1527189354784};\\\", \\\"{x:390,y:602,t:1527189354813};\\\", \\\"{x:389,y:600,t:1527189354878};\\\", \\\"{x:387,y:596,t:1527189354885};\\\", \\\"{x:382,y:590,t:1527189354900};\\\", \\\"{x:374,y:579,t:1527189354917};\\\", \\\"{x:358,y:566,t:1527189354933};\\\", \\\"{x:348,y:562,t:1527189354951};\\\", \\\"{x:344,y:562,t:1527189354966};\\\", \\\"{x:342,y:561,t:1527189354983};\\\", \\\"{x:337,y:561,t:1527189355001};\\\", \\\"{x:335,y:561,t:1527189355017};\\\", \\\"{x:330,y:562,t:1527189355034};\\\", \\\"{x:325,y:563,t:1527189355052};\\\", \\\"{x:318,y:565,t:1527189355068};\\\", \\\"{x:311,y:566,t:1527189355084};\\\", \\\"{x:298,y:566,t:1527189355101};\\\", \\\"{x:279,y:564,t:1527189355117};\\\", \\\"{x:264,y:557,t:1527189355134};\\\", \\\"{x:251,y:552,t:1527189355152};\\\", \\\"{x:242,y:549,t:1527189355168};\\\", \\\"{x:234,y:545,t:1527189355183};\\\", \\\"{x:229,y:542,t:1527189355200};\\\", \\\"{x:224,y:539,t:1527189355217};\\\", \\\"{x:212,y:533,t:1527189355234};\\\", \\\"{x:201,y:527,t:1527189355250};\\\", \\\"{x:189,y:522,t:1527189355268};\\\", \\\"{x:178,y:517,t:1527189355285};\\\", \\\"{x:167,y:511,t:1527189355301};\\\", \\\"{x:156,y:504,t:1527189355317};\\\", \\\"{x:151,y:501,t:1527189355334};\\\", \\\"{x:144,y:497,t:1527189355351};\\\", \\\"{x:139,y:495,t:1527189355368};\\\", \\\"{x:134,y:493,t:1527189355383};\\\", \\\"{x:132,y:493,t:1527189355401};\\\", \\\"{x:132,y:492,t:1527189355421};\\\", \\\"{x:133,y:492,t:1527189355550};\\\", \\\"{x:136,y:492,t:1527189355568};\\\", \\\"{x:139,y:492,t:1527189355584};\\\", \\\"{x:141,y:492,t:1527189355601};\\\", \\\"{x:141,y:493,t:1527189355629};\\\", \\\"{x:143,y:493,t:1527189355686};\\\", \\\"{x:144,y:494,t:1527189355710};\\\", \\\"{x:147,y:494,t:1527189355726};\\\", \\\"{x:148,y:495,t:1527189355734};\\\", \\\"{x:150,y:496,t:1527189355758};\\\", \\\"{x:151,y:496,t:1527189355807};\\\", \\\"{x:153,y:496,t:1527189355854};\\\", \\\"{x:154,y:496,t:1527189355902};\\\", \\\"{x:154,y:497,t:1527189355918};\\\", \\\"{x:156,y:498,t:1527189355935};\\\", \\\"{x:157,y:498,t:1527189355958};\\\", \\\"{x:158,y:499,t:1527189355974};\\\", \\\"{x:159,y:499,t:1527189355985};\\\", \\\"{x:160,y:499,t:1527189356002};\\\", \\\"{x:160,y:500,t:1527189356022};\\\", \\\"{x:161,y:501,t:1527189356035};\\\", \\\"{x:162,y:501,t:1527189356110};\\\", \\\"{x:163,y:501,t:1527189356150};\\\", \\\"{x:164,y:502,t:1527189356158};\\\", \\\"{x:165,y:502,t:1527189356174};\\\", \\\"{x:166,y:502,t:1527189356185};\\\", \\\"{x:167,y:502,t:1527189356214};\\\", \\\"{x:169,y:502,t:1527189356734};\\\", \\\"{x:178,y:504,t:1527189356742};\\\", \\\"{x:192,y:507,t:1527189356752};\\\", \\\"{x:265,y:529,t:1527189356771};\\\", \\\"{x:384,y:563,t:1527189356786};\\\", \\\"{x:522,y:604,t:1527189356802};\\\", \\\"{x:664,y:647,t:1527189356819};\\\", \\\"{x:846,y:704,t:1527189356835};\\\", \\\"{x:1020,y:754,t:1527189356851};\\\", \\\"{x:1191,y:797,t:1527189356868};\\\", \\\"{x:1365,y:826,t:1527189356885};\\\", \\\"{x:1415,y:826,t:1527189356902};\\\", \\\"{x:1433,y:824,t:1527189356919};\\\", \\\"{x:1439,y:820,t:1527189356935};\\\", \\\"{x:1439,y:818,t:1527189356973};\\\", \\\"{x:1439,y:815,t:1527189356985};\\\", \\\"{x:1439,y:806,t:1527189357002};\\\", \\\"{x:1439,y:791,t:1527189357019};\\\", \\\"{x:1439,y:768,t:1527189357036};\\\", \\\"{x:1437,y:744,t:1527189357052};\\\", \\\"{x:1424,y:721,t:1527189357069};\\\", \\\"{x:1382,y:674,t:1527189357086};\\\", \\\"{x:1356,y:650,t:1527189357102};\\\", \\\"{x:1342,y:633,t:1527189357119};\\\", \\\"{x:1332,y:618,t:1527189357136};\\\", \\\"{x:1324,y:605,t:1527189357152};\\\", \\\"{x:1317,y:590,t:1527189357169};\\\", \\\"{x:1311,y:584,t:1527189357187};\\\", \\\"{x:1305,y:577,t:1527189357203};\\\", \\\"{x:1300,y:571,t:1527189357219};\\\", \\\"{x:1298,y:568,t:1527189357236};\\\", \\\"{x:1298,y:567,t:1527189357254};\\\", \\\"{x:1298,y:566,t:1527189357831};\\\", \\\"{x:1296,y:566,t:1527189357839};\\\", \\\"{x:1294,y:565,t:1527189357854};\\\", \\\"{x:1287,y:564,t:1527189357871};\\\", \\\"{x:1286,y:564,t:1527189357887};\\\", \\\"{x:1285,y:564,t:1527189357904};\\\", \\\"{x:1284,y:566,t:1527189358158};\\\", \\\"{x:1287,y:576,t:1527189358171};\\\", \\\"{x:1301,y:601,t:1527189358188};\\\", \\\"{x:1319,y:632,t:1527189358204};\\\", \\\"{x:1330,y:650,t:1527189358220};\\\", \\\"{x:1341,y:665,t:1527189358237};\\\", \\\"{x:1355,y:684,t:1527189358254};\\\", \\\"{x:1376,y:712,t:1527189358271};\\\", \\\"{x:1388,y:726,t:1527189358287};\\\", \\\"{x:1397,y:738,t:1527189358303};\\\", \\\"{x:1404,y:748,t:1527189358320};\\\", \\\"{x:1412,y:759,t:1527189358337};\\\", \\\"{x:1419,y:774,t:1527189358353};\\\", \\\"{x:1426,y:786,t:1527189358370};\\\", \\\"{x:1430,y:793,t:1527189358387};\\\", \\\"{x:1433,y:796,t:1527189358403};\\\", \\\"{x:1434,y:799,t:1527189358420};\\\", \\\"{x:1435,y:801,t:1527189358437};\\\", \\\"{x:1435,y:804,t:1527189358454};\\\", \\\"{x:1435,y:821,t:1527189358471};\\\", \\\"{x:1436,y:828,t:1527189358487};\\\", \\\"{x:1436,y:839,t:1527189358504};\\\", \\\"{x:1436,y:852,t:1527189358521};\\\", \\\"{x:1436,y:863,t:1527189358537};\\\", \\\"{x:1438,y:873,t:1527189358554};\\\", \\\"{x:1438,y:885,t:1527189358570};\\\", \\\"{x:1438,y:896,t:1527189358588};\\\", \\\"{x:1439,y:909,t:1527189358605};\\\", \\\"{x:1441,y:918,t:1527189358621};\\\", \\\"{x:1444,y:926,t:1527189358637};\\\", \\\"{x:1447,y:933,t:1527189358654};\\\", \\\"{x:1449,y:939,t:1527189358670};\\\", \\\"{x:1454,y:947,t:1527189358688};\\\", \\\"{x:1458,y:952,t:1527189358704};\\\", \\\"{x:1462,y:957,t:1527189358720};\\\", \\\"{x:1466,y:961,t:1527189358737};\\\", \\\"{x:1470,y:964,t:1527189358753};\\\", \\\"{x:1473,y:967,t:1527189358769};\\\", \\\"{x:1474,y:968,t:1527189358786};\\\", \\\"{x:1475,y:968,t:1527189358804};\\\", \\\"{x:1477,y:968,t:1527189358949};\\\", \\\"{x:1478,y:966,t:1527189358956};\\\", \\\"{x:1479,y:964,t:1527189358971};\\\", \\\"{x:1479,y:962,t:1527189358987};\\\", \\\"{x:1481,y:958,t:1527189359004};\\\", \\\"{x:1481,y:953,t:1527189359021};\\\", \\\"{x:1481,y:951,t:1527189359037};\\\", \\\"{x:1481,y:950,t:1527189359054};\\\", \\\"{x:1481,y:949,t:1527189359070};\\\", \\\"{x:1481,y:948,t:1527189359093};\\\", \\\"{x:1481,y:947,t:1527189359104};\\\", \\\"{x:1481,y:946,t:1527189359120};\\\", \\\"{x:1481,y:945,t:1527189359137};\\\", \\\"{x:1481,y:943,t:1527189361511};\\\", \\\"{x:1468,y:933,t:1527189361523};\\\", \\\"{x:1399,y:904,t:1527189361540};\\\", \\\"{x:1316,y:863,t:1527189361557};\\\", \\\"{x:1250,y:823,t:1527189361574};\\\", \\\"{x:1213,y:804,t:1527189361589};\\\", \\\"{x:1201,y:795,t:1527189361606};\\\", \\\"{x:1204,y:789,t:1527189361623};\\\", \\\"{x:1215,y:779,t:1527189361640};\\\", \\\"{x:1231,y:765,t:1527189361657};\\\", \\\"{x:1247,y:752,t:1527189361674};\\\", \\\"{x:1259,y:741,t:1527189361690};\\\", \\\"{x:1269,y:733,t:1527189361707};\\\", \\\"{x:1280,y:724,t:1527189361723};\\\", \\\"{x:1285,y:719,t:1527189361740};\\\", \\\"{x:1290,y:713,t:1527189361756};\\\", \\\"{x:1296,y:704,t:1527189361773};\\\", \\\"{x:1301,y:696,t:1527189361790};\\\", \\\"{x:1309,y:687,t:1527189361807};\\\", \\\"{x:1313,y:682,t:1527189361824};\\\", \\\"{x:1316,y:678,t:1527189361841};\\\", \\\"{x:1316,y:677,t:1527189361856};\\\", \\\"{x:1317,y:676,t:1527189361925};\\\", \\\"{x:1318,y:675,t:1527189361940};\\\", \\\"{x:1319,y:675,t:1527189361982};\\\", \\\"{x:1320,y:675,t:1527189361989};\\\", \\\"{x:1322,y:678,t:1527189362006};\\\", \\\"{x:1325,y:685,t:1527189362023};\\\", \\\"{x:1328,y:698,t:1527189362040};\\\", \\\"{x:1330,y:706,t:1527189362056};\\\", \\\"{x:1330,y:710,t:1527189362073};\\\", \\\"{x:1331,y:713,t:1527189362091};\\\", \\\"{x:1331,y:714,t:1527189362106};\\\", \\\"{x:1332,y:715,t:1527189362124};\\\", \\\"{x:1332,y:713,t:1527189362287};\\\", \\\"{x:1332,y:711,t:1527189362294};\\\", \\\"{x:1334,y:707,t:1527189362307};\\\", \\\"{x:1338,y:700,t:1527189362323};\\\", \\\"{x:1342,y:696,t:1527189362341};\\\", \\\"{x:1342,y:695,t:1527189362357};\\\", \\\"{x:1343,y:699,t:1527189362935};\\\", \\\"{x:1343,y:705,t:1527189362942};\\\", \\\"{x:1346,y:715,t:1527189362959};\\\", \\\"{x:1348,y:724,t:1527189362974};\\\", \\\"{x:1350,y:732,t:1527189362992};\\\", \\\"{x:1352,y:737,t:1527189363007};\\\", \\\"{x:1353,y:743,t:1527189363025};\\\", \\\"{x:1355,y:748,t:1527189363041};\\\", \\\"{x:1356,y:755,t:1527189363057};\\\", \\\"{x:1360,y:763,t:1527189363075};\\\", \\\"{x:1362,y:772,t:1527189363092};\\\", \\\"{x:1363,y:777,t:1527189363108};\\\", \\\"{x:1365,y:782,t:1527189363125};\\\", \\\"{x:1368,y:789,t:1527189363142};\\\", \\\"{x:1371,y:797,t:1527189363158};\\\", \\\"{x:1375,y:807,t:1527189363174};\\\", \\\"{x:1380,y:817,t:1527189363191};\\\", \\\"{x:1381,y:821,t:1527189363208};\\\", \\\"{x:1382,y:823,t:1527189363224};\\\", \\\"{x:1384,y:827,t:1527189363241};\\\", \\\"{x:1386,y:830,t:1527189363258};\\\", \\\"{x:1387,y:834,t:1527189363275};\\\", \\\"{x:1388,y:836,t:1527189363292};\\\", \\\"{x:1391,y:840,t:1527189363307};\\\", \\\"{x:1393,y:845,t:1527189363325};\\\", \\\"{x:1400,y:853,t:1527189363342};\\\", \\\"{x:1401,y:855,t:1527189363358};\\\", \\\"{x:1405,y:860,t:1527189363374};\\\", \\\"{x:1408,y:863,t:1527189363392};\\\", \\\"{x:1410,y:866,t:1527189363408};\\\", \\\"{x:1413,y:869,t:1527189363424};\\\", \\\"{x:1417,y:877,t:1527189363442};\\\", \\\"{x:1423,y:883,t:1527189363459};\\\", \\\"{x:1427,y:888,t:1527189363475};\\\", \\\"{x:1433,y:893,t:1527189363492};\\\", \\\"{x:1440,y:898,t:1527189363508};\\\", \\\"{x:1444,y:902,t:1527189363525};\\\", \\\"{x:1450,y:908,t:1527189363542};\\\", \\\"{x:1454,y:912,t:1527189363559};\\\", \\\"{x:1459,y:916,t:1527189363575};\\\", \\\"{x:1463,y:918,t:1527189363592};\\\", \\\"{x:1466,y:921,t:1527189363609};\\\", \\\"{x:1468,y:923,t:1527189363625};\\\", \\\"{x:1468,y:924,t:1527189363814};\\\", \\\"{x:1470,y:925,t:1527189363826};\\\", \\\"{x:1471,y:930,t:1527189363841};\\\", \\\"{x:1473,y:934,t:1527189363859};\\\", \\\"{x:1475,y:939,t:1527189363876};\\\", \\\"{x:1477,y:945,t:1527189363892};\\\", \\\"{x:1480,y:955,t:1527189363909};\\\", \\\"{x:1482,y:963,t:1527189363926};\\\", \\\"{x:1483,y:966,t:1527189363942};\\\", \\\"{x:1483,y:965,t:1527189364303};\\\", \\\"{x:1483,y:961,t:1527189364495};\\\", \\\"{x:1482,y:956,t:1527189364509};\\\", \\\"{x:1474,y:943,t:1527189364526};\\\", \\\"{x:1459,y:924,t:1527189364542};\\\", \\\"{x:1434,y:898,t:1527189364559};\\\", \\\"{x:1394,y:867,t:1527189364576};\\\", \\\"{x:1366,y:841,t:1527189364593};\\\", \\\"{x:1345,y:824,t:1527189364610};\\\", \\\"{x:1332,y:805,t:1527189364626};\\\", \\\"{x:1321,y:787,t:1527189364643};\\\", \\\"{x:1314,y:770,t:1527189364660};\\\", \\\"{x:1310,y:754,t:1527189364676};\\\", \\\"{x:1308,y:742,t:1527189364693};\\\", \\\"{x:1304,y:731,t:1527189364710};\\\", \\\"{x:1303,y:727,t:1527189364726};\\\", \\\"{x:1303,y:721,t:1527189364742};\\\", \\\"{x:1303,y:716,t:1527189364760};\\\", \\\"{x:1303,y:713,t:1527189364775};\\\", \\\"{x:1303,y:709,t:1527189364793};\\\", \\\"{x:1304,y:705,t:1527189364810};\\\", \\\"{x:1306,y:700,t:1527189364826};\\\", \\\"{x:1309,y:698,t:1527189364843};\\\", \\\"{x:1309,y:695,t:1527189364860};\\\", \\\"{x:1312,y:692,t:1527189364875};\\\", \\\"{x:1316,y:686,t:1527189364894};\\\", \\\"{x:1320,y:681,t:1527189364910};\\\", \\\"{x:1321,y:679,t:1527189364927};\\\", \\\"{x:1322,y:679,t:1527189364943};\\\", \\\"{x:1322,y:678,t:1527189364960};\\\", \\\"{x:1323,y:680,t:1527189365078};\\\", \\\"{x:1325,y:685,t:1527189365093};\\\", \\\"{x:1330,y:697,t:1527189365110};\\\", \\\"{x:1337,y:706,t:1527189365126};\\\", \\\"{x:1341,y:712,t:1527189365143};\\\", \\\"{x:1344,y:717,t:1527189365160};\\\", \\\"{x:1345,y:719,t:1527189365177};\\\", \\\"{x:1346,y:720,t:1527189365193};\\\", \\\"{x:1346,y:722,t:1527189365210};\\\", \\\"{x:1346,y:724,t:1527189365406};\\\", \\\"{x:1346,y:730,t:1527189365414};\\\", \\\"{x:1346,y:735,t:1527189365427};\\\", \\\"{x:1338,y:751,t:1527189365442};\\\", \\\"{x:1330,y:769,t:1527189365460};\\\", \\\"{x:1321,y:789,t:1527189365477};\\\", \\\"{x:1309,y:821,t:1527189365495};\\\", \\\"{x:1305,y:838,t:1527189365510};\\\", \\\"{x:1300,y:851,t:1527189365526};\\\", \\\"{x:1300,y:856,t:1527189365544};\\\", \\\"{x:1300,y:855,t:1527189365687};\\\", \\\"{x:1300,y:851,t:1527189365694};\\\", \\\"{x:1304,y:838,t:1527189365710};\\\", \\\"{x:1307,y:826,t:1527189365727};\\\", \\\"{x:1311,y:813,t:1527189365744};\\\", \\\"{x:1311,y:805,t:1527189365759};\\\", \\\"{x:1311,y:798,t:1527189365776};\\\", \\\"{x:1311,y:792,t:1527189365793};\\\", \\\"{x:1311,y:790,t:1527189365809};\\\", \\\"{x:1310,y:787,t:1527189365827};\\\", \\\"{x:1310,y:786,t:1527189365843};\\\", \\\"{x:1310,y:785,t:1527189365860};\\\", \\\"{x:1309,y:785,t:1527189365877};\\\", \\\"{x:1309,y:783,t:1527189366183};\\\", \\\"{x:1309,y:780,t:1527189366194};\\\", \\\"{x:1312,y:777,t:1527189366211};\\\", \\\"{x:1314,y:774,t:1527189366227};\\\", \\\"{x:1314,y:773,t:1527189366244};\\\", \\\"{x:1315,y:772,t:1527189366261};\\\", \\\"{x:1315,y:767,t:1527189368239};\\\", \\\"{x:1315,y:743,t:1527189368247};\\\", \\\"{x:1330,y:700,t:1527189368262};\\\", \\\"{x:1340,y:666,t:1527189368279};\\\", \\\"{x:1347,y:641,t:1527189368296};\\\", \\\"{x:1350,y:628,t:1527189368312};\\\", \\\"{x:1352,y:625,t:1527189368329};\\\", \\\"{x:1349,y:623,t:1527189369927};\\\", \\\"{x:1348,y:622,t:1527189369934};\\\", \\\"{x:1345,y:620,t:1527189369947};\\\", \\\"{x:1344,y:620,t:1527189369964};\\\", \\\"{x:1343,y:620,t:1527189369980};\\\", \\\"{x:1340,y:619,t:1527189370134};\\\", \\\"{x:1335,y:614,t:1527189370147};\\\", \\\"{x:1319,y:597,t:1527189370163};\\\", \\\"{x:1296,y:580,t:1527189370180};\\\", \\\"{x:1269,y:561,t:1527189370196};\\\", \\\"{x:1249,y:552,t:1527189370213};\\\", \\\"{x:1246,y:551,t:1527189370231};\\\", \\\"{x:1246,y:552,t:1527189370278};\\\", \\\"{x:1242,y:559,t:1527189370285};\\\", \\\"{x:1241,y:566,t:1527189370297};\\\", \\\"{x:1235,y:584,t:1527189370314};\\\", \\\"{x:1227,y:612,t:1527189370330};\\\", \\\"{x:1217,y:647,t:1527189370347};\\\", \\\"{x:1211,y:684,t:1527189370364};\\\", \\\"{x:1207,y:722,t:1527189370381};\\\", \\\"{x:1207,y:751,t:1527189370397};\\\", \\\"{x:1205,y:785,t:1527189370414};\\\", \\\"{x:1202,y:798,t:1527189370431};\\\", \\\"{x:1200,y:802,t:1527189370448};\\\", \\\"{x:1199,y:803,t:1527189370465};\\\", \\\"{x:1198,y:804,t:1527189370481};\\\", \\\"{x:1196,y:804,t:1527189370694};\\\", \\\"{x:1193,y:800,t:1527189370702};\\\", \\\"{x:1191,y:795,t:1527189370714};\\\", \\\"{x:1185,y:784,t:1527189370731};\\\", \\\"{x:1178,y:773,t:1527189370748};\\\", \\\"{x:1171,y:762,t:1527189370764};\\\", \\\"{x:1167,y:758,t:1527189370782};\\\", \\\"{x:1169,y:766,t:1527189371062};\\\", \\\"{x:1174,y:772,t:1527189371070};\\\", \\\"{x:1177,y:778,t:1527189371081};\\\", \\\"{x:1184,y:789,t:1527189371098};\\\", \\\"{x:1190,y:799,t:1527189371115};\\\", \\\"{x:1195,y:805,t:1527189371132};\\\", \\\"{x:1199,y:811,t:1527189371148};\\\", \\\"{x:1201,y:813,t:1527189371165};\\\", \\\"{x:1201,y:814,t:1527189371181};\\\", \\\"{x:1201,y:816,t:1527189371302};\\\", \\\"{x:1203,y:824,t:1527189371315};\\\", \\\"{x:1214,y:843,t:1527189371332};\\\", \\\"{x:1222,y:854,t:1527189371349};\\\", \\\"{x:1226,y:859,t:1527189371365};\\\", \\\"{x:1229,y:866,t:1527189371382};\\\", \\\"{x:1230,y:867,t:1527189371486};\\\", \\\"{x:1230,y:866,t:1527189371498};\\\", \\\"{x:1231,y:861,t:1527189371515};\\\", \\\"{x:1231,y:859,t:1527189371966};\\\", \\\"{x:1226,y:847,t:1527189371982};\\\", \\\"{x:1219,y:832,t:1527189371999};\\\", \\\"{x:1217,y:825,t:1527189372015};\\\", \\\"{x:1217,y:824,t:1527189372032};\\\", \\\"{x:1217,y:823,t:1527189372049};\\\", \\\"{x:1218,y:820,t:1527189372065};\\\", \\\"{x:1225,y:812,t:1527189372082};\\\", \\\"{x:1242,y:800,t:1527189372099};\\\", \\\"{x:1263,y:784,t:1527189372116};\\\", \\\"{x:1290,y:766,t:1527189372132};\\\", \\\"{x:1312,y:749,t:1527189372149};\\\", \\\"{x:1340,y:728,t:1527189372165};\\\", \\\"{x:1355,y:715,t:1527189372182};\\\", \\\"{x:1365,y:702,t:1527189372199};\\\", \\\"{x:1369,y:696,t:1527189372216};\\\", \\\"{x:1371,y:693,t:1527189372233};\\\", \\\"{x:1370,y:692,t:1527189372359};\\\", \\\"{x:1368,y:694,t:1527189372367};\\\", \\\"{x:1361,y:719,t:1527189372382};\\\", \\\"{x:1353,y:740,t:1527189372398};\\\", \\\"{x:1350,y:753,t:1527189372415};\\\", \\\"{x:1348,y:764,t:1527189372433};\\\", \\\"{x:1347,y:767,t:1527189372448};\\\", \\\"{x:1347,y:770,t:1527189372466};\\\", \\\"{x:1347,y:773,t:1527189372482};\\\", \\\"{x:1347,y:775,t:1527189372499};\\\", \\\"{x:1347,y:776,t:1527189372515};\\\", \\\"{x:1346,y:780,t:1527189372533};\\\", \\\"{x:1345,y:782,t:1527189372550};\\\", \\\"{x:1344,y:782,t:1527189372566};\\\", \\\"{x:1344,y:781,t:1527189372662};\\\", \\\"{x:1344,y:776,t:1527189372670};\\\", \\\"{x:1345,y:772,t:1527189372684};\\\", \\\"{x:1346,y:765,t:1527189372700};\\\", \\\"{x:1348,y:759,t:1527189372716};\\\", \\\"{x:1349,y:755,t:1527189372734};\\\", \\\"{x:1349,y:754,t:1527189372749};\\\", \\\"{x:1348,y:755,t:1527189373063};\\\", \\\"{x:1347,y:755,t:1527189373086};\\\", \\\"{x:1347,y:757,t:1527189373326};\\\", \\\"{x:1344,y:762,t:1527189373335};\\\", \\\"{x:1340,y:769,t:1527189373350};\\\", \\\"{x:1335,y:777,t:1527189373367};\\\", \\\"{x:1331,y:784,t:1527189373383};\\\", \\\"{x:1326,y:791,t:1527189373400};\\\", \\\"{x:1324,y:794,t:1527189373417};\\\", \\\"{x:1324,y:795,t:1527189373439};\\\", \\\"{x:1323,y:796,t:1527189373486};\\\", \\\"{x:1322,y:797,t:1527189373502};\\\", \\\"{x:1322,y:798,t:1527189373517};\\\", \\\"{x:1320,y:801,t:1527189373533};\\\", \\\"{x:1317,y:807,t:1527189373550};\\\", \\\"{x:1315,y:810,t:1527189373567};\\\", \\\"{x:1313,y:813,t:1527189373583};\\\", \\\"{x:1312,y:816,t:1527189373600};\\\", \\\"{x:1310,y:818,t:1527189373617};\\\", \\\"{x:1310,y:820,t:1527189373633};\\\", \\\"{x:1310,y:821,t:1527189373650};\\\", \\\"{x:1309,y:823,t:1527189373667};\\\", \\\"{x:1307,y:827,t:1527189373682};\\\", \\\"{x:1306,y:830,t:1527189373699};\\\", \\\"{x:1306,y:834,t:1527189373716};\\\", \\\"{x:1302,y:842,t:1527189373733};\\\", \\\"{x:1299,y:846,t:1527189373749};\\\", \\\"{x:1298,y:850,t:1527189373766};\\\", \\\"{x:1298,y:851,t:1527189373784};\\\", \\\"{x:1297,y:853,t:1527189373800};\\\", \\\"{x:1296,y:856,t:1527189373816};\\\", \\\"{x:1295,y:859,t:1527189373833};\\\", \\\"{x:1294,y:863,t:1527189373849};\\\", \\\"{x:1291,y:870,t:1527189373866};\\\", \\\"{x:1289,y:879,t:1527189373884};\\\", \\\"{x:1284,y:888,t:1527189373899};\\\", \\\"{x:1281,y:895,t:1527189373917};\\\", \\\"{x:1276,y:906,t:1527189373932};\\\", \\\"{x:1274,y:912,t:1527189373950};\\\", \\\"{x:1272,y:917,t:1527189373966};\\\", \\\"{x:1270,y:923,t:1527189373983};\\\", \\\"{x:1268,y:926,t:1527189373999};\\\", \\\"{x:1267,y:931,t:1527189374016};\\\", \\\"{x:1265,y:934,t:1527189374034};\\\", \\\"{x:1265,y:936,t:1527189374050};\\\", \\\"{x:1264,y:938,t:1527189374066};\\\", \\\"{x:1263,y:939,t:1527189374084};\\\", \\\"{x:1263,y:940,t:1527189374278};\\\", \\\"{x:1262,y:940,t:1527189374286};\\\", \\\"{x:1261,y:943,t:1527189374301};\\\", \\\"{x:1259,y:946,t:1527189374317};\\\", \\\"{x:1255,y:951,t:1527189374334};\\\", \\\"{x:1251,y:956,t:1527189374351};\\\", \\\"{x:1249,y:958,t:1527189374366};\\\", \\\"{x:1249,y:960,t:1527189374385};\\\", \\\"{x:1248,y:960,t:1527189374402};\\\", \\\"{x:1246,y:960,t:1527189388431};\\\", \\\"{x:1163,y:922,t:1527189388446};\\\", \\\"{x:1056,y:856,t:1527189388463};\\\", \\\"{x:944,y:793,t:1527189388480};\\\", \\\"{x:838,y:741,t:1527189388497};\\\", \\\"{x:737,y:683,t:1527189388513};\\\", \\\"{x:648,y:638,t:1527189388530};\\\", \\\"{x:581,y:596,t:1527189388547};\\\", \\\"{x:549,y:577,t:1527189388564};\\\", \\\"{x:536,y:566,t:1527189388579};\\\", \\\"{x:533,y:562,t:1527189388596};\\\", \\\"{x:532,y:561,t:1527189388612};\\\", \\\"{x:532,y:558,t:1527189388626};\\\", \\\"{x:532,y:557,t:1527189388643};\\\", \\\"{x:532,y:556,t:1527189388660};\\\", \\\"{x:534,y:558,t:1527189388782};\\\", \\\"{x:541,y:573,t:1527189388794};\\\", \\\"{x:556,y:602,t:1527189388811};\\\", \\\"{x:567,y:623,t:1527189388827};\\\", \\\"{x:576,y:651,t:1527189388844};\\\", \\\"{x:582,y:694,t:1527189388861};\\\", \\\"{x:583,y:704,t:1527189388878};\\\", \\\"{x:583,y:706,t:1527189388901};\\\", \\\"{x:584,y:709,t:1527189388911};\\\", \\\"{x:585,y:713,t:1527189388928};\\\", \\\"{x:586,y:714,t:1527189388946};\\\", \\\"{x:586,y:715,t:1527189388965};\\\", \\\"{x:585,y:716,t:1527189389005};\\\", \\\"{x:584,y:716,t:1527189389030};\\\", \\\"{x:580,y:716,t:1527189389046};\\\", \\\"{x:572,y:717,t:1527189389061};\\\", \\\"{x:564,y:717,t:1527189389079};\\\", \\\"{x:553,y:721,t:1527189389096};\\\", \\\"{x:543,y:723,t:1527189389112};\\\", \\\"{x:530,y:727,t:1527189389128};\\\", \\\"{x:513,y:732,t:1527189389146};\\\", \\\"{x:495,y:746,t:1527189389162};\\\", \\\"{x:479,y:756,t:1527189389180};\\\", \\\"{x:467,y:763,t:1527189389195};\\\", \\\"{x:460,y:766,t:1527189389211};\\\", \\\"{x:456,y:767,t:1527189389229};\\\", \\\"{x:452,y:767,t:1527189389245};\\\", \\\"{x:447,y:767,t:1527189389261};\\\", \\\"{x:446,y:767,t:1527189389279};\\\", \\\"{x:444,y:767,t:1527189389357};\\\", \\\"{x:443,y:766,t:1527189389364};\\\", \\\"{x:439,y:764,t:1527189389378};\\\", \\\"{x:431,y:759,t:1527189389395};\\\", \\\"{x:421,y:753,t:1527189389411};\\\", \\\"{x:408,y:746,t:1527189389429};\\\", \\\"{x:392,y:737,t:1527189389444};\\\", \\\"{x:385,y:735,t:1527189389462};\\\", \\\"{x:385,y:736,t:1527189389630};\\\", \\\"{x:404,y:752,t:1527189389646};\\\", \\\"{x:424,y:762,t:1527189389663};\\\", \\\"{x:435,y:766,t:1527189389678};\\\", \\\"{x:439,y:768,t:1527189389696};\\\", \\\"{x:441,y:768,t:1527189389712};\\\", \\\"{x:442,y:768,t:1527189389766};\\\", \\\"{x:443,y:768,t:1527189389790};\\\", \\\"{x:445,y:768,t:1527189389798};\\\", \\\"{x:446,y:768,t:1527189389813};\\\", \\\"{x:451,y:766,t:1527189389829};\\\", \\\"{x:457,y:763,t:1527189389846};\\\", \\\"{x:460,y:762,t:1527189389862};\\\", \\\"{x:464,y:761,t:1527189389879};\\\", \\\"{x:469,y:759,t:1527189389896};\\\", \\\"{x:475,y:755,t:1527189389913};\\\", \\\"{x:476,y:755,t:1527189389929};\\\", \\\"{x:478,y:754,t:1527189389947};\\\", \\\"{x:479,y:753,t:1527189389962};\\\", \\\"{x:481,y:753,t:1527189389979};\\\", \\\"{x:482,y:752,t:1527189390166};\\\", \\\"{x:483,y:752,t:1527189390179};\\\", \\\"{x:484,y:752,t:1527189390196};\\\", \\\"{x:485,y:751,t:1527189390212};\\\", \\\"{x:488,y:749,t:1527189390886};\\\", \\\"{x:488,y:748,t:1527189390896};\\\", \\\"{x:490,y:748,t:1527189390913};\\\", \\\"{x:491,y:747,t:1527189391374};\\\", \\\"{x:495,y:745,t:1527189391382};\\\", \\\"{x:496,y:744,t:1527189391398};\\\", \\\"{x:498,y:744,t:1527189391413};\\\", \\\"{x:498,y:743,t:1527189391430};\\\" ] }, { \\\"rt\\\": 51609, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 831253, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:763,t:1527189398987};\\\", \\\"{x:488,y:815,t:1527189399007};\\\", \\\"{x:474,y:887,t:1527189399023};\\\", \\\"{x:467,y:908,t:1527189399037};\\\", \\\"{x:460,y:933,t:1527189399053};\\\", \\\"{x:455,y:950,t:1527189399069};\\\", \\\"{x:453,y:957,t:1527189399087};\\\", \\\"{x:450,y:966,t:1527189399945};\\\", \\\"{x:434,y:984,t:1527189399953};\\\", \\\"{x:404,y:1036,t:1527189399971};\\\", \\\"{x:401,y:1037,t:1527189399987};\\\", \\\"{x:401,y:1033,t:1527189400609};\\\", \\\"{x:402,y:1031,t:1527189400621};\\\", \\\"{x:399,y:1022,t:1527189400637};\\\", \\\"{x:398,y:1020,t:1527189400654};\\\", \\\"{x:398,y:1017,t:1527189400670};\\\", \\\"{x:398,y:1016,t:1527189400687};\\\", \\\"{x:399,y:1015,t:1527189400745};\\\", \\\"{x:404,y:1011,t:1527189400753};\\\", \\\"{x:420,y:1008,t:1527189400770};\\\", \\\"{x:466,y:1001,t:1527189400787};\\\", \\\"{x:541,y:992,t:1527189400804};\\\", \\\"{x:628,y:988,t:1527189400821};\\\", \\\"{x:736,y:988,t:1527189400836};\\\", \\\"{x:880,y:988,t:1527189400854};\\\", \\\"{x:993,y:988,t:1527189400871};\\\", \\\"{x:1060,y:988,t:1527189400887};\\\", \\\"{x:1076,y:990,t:1527189400904};\\\", \\\"{x:1080,y:994,t:1527189400921};\\\", \\\"{x:1080,y:1023,t:1527189400937};\\\", \\\"{x:1074,y:1064,t:1527189400954};\\\", \\\"{x:1071,y:1073,t:1527189400970};\\\", \\\"{x:1071,y:1070,t:1527189401233};\\\", \\\"{x:1071,y:1067,t:1527189401249};\\\", \\\"{x:1070,y:1065,t:1527189401256};\\\", \\\"{x:1070,y:1063,t:1527189401271};\\\", \\\"{x:1079,y:1052,t:1527189401287};\\\", \\\"{x:1091,y:1042,t:1527189401304};\\\", \\\"{x:1115,y:1024,t:1527189401321};\\\", \\\"{x:1136,y:1012,t:1527189401337};\\\", \\\"{x:1150,y:1001,t:1527189401354};\\\", \\\"{x:1160,y:995,t:1527189401370};\\\", \\\"{x:1171,y:984,t:1527189401386};\\\", \\\"{x:1183,y:973,t:1527189401403};\\\", \\\"{x:1190,y:964,t:1527189401420};\\\", \\\"{x:1194,y:958,t:1527189401436};\\\", \\\"{x:1198,y:955,t:1527189401453};\\\", \\\"{x:1199,y:955,t:1527189401470};\\\", \\\"{x:1200,y:954,t:1527189401649};\\\", \\\"{x:1206,y:950,t:1527189401656};\\\", \\\"{x:1216,y:945,t:1527189401671};\\\", \\\"{x:1232,y:930,t:1527189401687};\\\", \\\"{x:1238,y:891,t:1527189401704};\\\", \\\"{x:1237,y:836,t:1527189401720};\\\", \\\"{x:1232,y:802,t:1527189401737};\\\", \\\"{x:1230,y:784,t:1527189401754};\\\", \\\"{x:1230,y:776,t:1527189401771};\\\", \\\"{x:1230,y:773,t:1527189401787};\\\", \\\"{x:1230,y:767,t:1527189401804};\\\", \\\"{x:1230,y:759,t:1527189401820};\\\", \\\"{x:1229,y:748,t:1527189401837};\\\", \\\"{x:1221,y:725,t:1527189401853};\\\", \\\"{x:1218,y:714,t:1527189401870};\\\", \\\"{x:1216,y:710,t:1527189401886};\\\", \\\"{x:1216,y:709,t:1527189401905};\\\", \\\"{x:1216,y:708,t:1527189401929};\\\", \\\"{x:1216,y:707,t:1527189401936};\\\", \\\"{x:1218,y:704,t:1527189401954};\\\", \\\"{x:1225,y:702,t:1527189401971};\\\", \\\"{x:1229,y:700,t:1527189401987};\\\", \\\"{x:1230,y:700,t:1527189402004};\\\", \\\"{x:1233,y:701,t:1527189402049};\\\", \\\"{x:1239,y:709,t:1527189402057};\\\", \\\"{x:1246,y:716,t:1527189402071};\\\", \\\"{x:1260,y:733,t:1527189402087};\\\", \\\"{x:1273,y:754,t:1527189402104};\\\", \\\"{x:1287,y:777,t:1527189402121};\\\", \\\"{x:1292,y:784,t:1527189402137};\\\", \\\"{x:1294,y:786,t:1527189402154};\\\", \\\"{x:1297,y:786,t:1527189402257};\\\", \\\"{x:1298,y:783,t:1527189402270};\\\", \\\"{x:1299,y:775,t:1527189402286};\\\", \\\"{x:1300,y:763,t:1527189402304};\\\", \\\"{x:1300,y:737,t:1527189402322};\\\", \\\"{x:1300,y:728,t:1527189402337};\\\", \\\"{x:1298,y:719,t:1527189402354};\\\", \\\"{x:1296,y:715,t:1527189402370};\\\", \\\"{x:1296,y:714,t:1527189402387};\\\", \\\"{x:1296,y:710,t:1527189402404};\\\", \\\"{x:1288,y:710,t:1527189402793};\\\", \\\"{x:1273,y:719,t:1527189402804};\\\", \\\"{x:1215,y:745,t:1527189402821};\\\", \\\"{x:1134,y:756,t:1527189402837};\\\", \\\"{x:1012,y:758,t:1527189402853};\\\", \\\"{x:865,y:758,t:1527189402870};\\\", \\\"{x:727,y:758,t:1527189402887};\\\", \\\"{x:622,y:758,t:1527189402903};\\\", \\\"{x:589,y:758,t:1527189402921};\\\", \\\"{x:590,y:757,t:1527189402937};\\\", \\\"{x:599,y:749,t:1527189402953};\\\", \\\"{x:601,y:747,t:1527189402969};\\\", \\\"{x:603,y:744,t:1527189403233};\\\", \\\"{x:603,y:741,t:1527189403241};\\\", \\\"{x:605,y:735,t:1527189403253};\\\", \\\"{x:610,y:718,t:1527189403270};\\\", \\\"{x:612,y:696,t:1527189403287};\\\", \\\"{x:616,y:674,t:1527189403304};\\\", \\\"{x:625,y:646,t:1527189403320};\\\", \\\"{x:635,y:611,t:1527189403338};\\\", \\\"{x:642,y:585,t:1527189403353};\\\", \\\"{x:651,y:561,t:1527189403369};\\\", \\\"{x:663,y:532,t:1527189403394};\\\", \\\"{x:673,y:514,t:1527189403411};\\\", \\\"{x:679,y:502,t:1527189403426};\\\", \\\"{x:684,y:491,t:1527189403443};\\\", \\\"{x:684,y:485,t:1527189403460};\\\", \\\"{x:684,y:483,t:1527189403476};\\\", \\\"{x:676,y:478,t:1527189403493};\\\", \\\"{x:667,y:474,t:1527189403509};\\\", \\\"{x:658,y:473,t:1527189403526};\\\", \\\"{x:652,y:473,t:1527189403544};\\\", \\\"{x:640,y:473,t:1527189403559};\\\", \\\"{x:621,y:477,t:1527189403576};\\\", \\\"{x:610,y:482,t:1527189403593};\\\", \\\"{x:603,y:485,t:1527189403609};\\\", \\\"{x:599,y:488,t:1527189403627};\\\", \\\"{x:598,y:489,t:1527189403643};\\\", \\\"{x:596,y:491,t:1527189403661};\\\", \\\"{x:594,y:494,t:1527189403676};\\\", \\\"{x:593,y:496,t:1527189403693};\\\", \\\"{x:592,y:496,t:1527189403720};\\\", \\\"{x:591,y:497,t:1527189403728};\\\", \\\"{x:590,y:498,t:1527189403744};\\\", \\\"{x:590,y:499,t:1527189403776};\\\", \\\"{x:591,y:499,t:1527189403977};\\\", \\\"{x:592,y:499,t:1527189403995};\\\", \\\"{x:593,y:499,t:1527189404011};\\\", \\\"{x:594,y:499,t:1527189404027};\\\", \\\"{x:595,y:499,t:1527189404045};\\\", \\\"{x:596,y:499,t:1527189404061};\\\", \\\"{x:597,y:499,t:1527189404081};\\\", \\\"{x:598,y:499,t:1527189404120};\\\", \\\"{x:599,y:499,t:1527189404128};\\\", \\\"{x:600,y:499,t:1527189404145};\\\", \\\"{x:601,y:499,t:1527189404160};\\\", \\\"{x:602,y:499,t:1527189404177};\\\", \\\"{x:603,y:499,t:1527189404697};\\\", \\\"{x:607,y:502,t:1527189404711};\\\", \\\"{x:612,y:503,t:1527189404727};\\\", \\\"{x:617,y:506,t:1527189404745};\\\", \\\"{x:621,y:509,t:1527189404761};\\\", \\\"{x:634,y:517,t:1527189404778};\\\", \\\"{x:662,y:529,t:1527189404795};\\\", \\\"{x:726,y:550,t:1527189404811};\\\", \\\"{x:808,y:568,t:1527189404827};\\\", \\\"{x:900,y:594,t:1527189404844};\\\", \\\"{x:1001,y:614,t:1527189404861};\\\", \\\"{x:1102,y:637,t:1527189404877};\\\", \\\"{x:1189,y:651,t:1527189404895};\\\", \\\"{x:1236,y:657,t:1527189404912};\\\", \\\"{x:1252,y:657,t:1527189404927};\\\", \\\"{x:1257,y:657,t:1527189404944};\\\", \\\"{x:1262,y:651,t:1527189407193};\\\", \\\"{x:1268,y:645,t:1527189407201};\\\", \\\"{x:1273,y:636,t:1527189407214};\\\", \\\"{x:1279,y:622,t:1527189407230};\\\", \\\"{x:1284,y:611,t:1527189407247};\\\", \\\"{x:1284,y:607,t:1527189407265};\\\", \\\"{x:1284,y:604,t:1527189407457};\\\", \\\"{x:1285,y:601,t:1527189407464};\\\", \\\"{x:1285,y:597,t:1527189407480};\\\", \\\"{x:1289,y:587,t:1527189407497};\\\", \\\"{x:1290,y:583,t:1527189407514};\\\", \\\"{x:1293,y:577,t:1527189407530};\\\", \\\"{x:1293,y:575,t:1527189407547};\\\", \\\"{x:1293,y:574,t:1527189407564};\\\", \\\"{x:1293,y:573,t:1527189407580};\\\", \\\"{x:1293,y:571,t:1527189407597};\\\", \\\"{x:1293,y:570,t:1527189407614};\\\", \\\"{x:1294,y:570,t:1527189407630};\\\", \\\"{x:1293,y:570,t:1527189407705};\\\", \\\"{x:1291,y:571,t:1527189407721};\\\", \\\"{x:1291,y:575,t:1527189407731};\\\", \\\"{x:1291,y:583,t:1527189407747};\\\", \\\"{x:1292,y:596,t:1527189407764};\\\", \\\"{x:1300,y:612,t:1527189407781};\\\", \\\"{x:1316,y:632,t:1527189407798};\\\", \\\"{x:1334,y:650,t:1527189407815};\\\", \\\"{x:1349,y:665,t:1527189407831};\\\", \\\"{x:1357,y:675,t:1527189407847};\\\", \\\"{x:1363,y:683,t:1527189407865};\\\", \\\"{x:1367,y:692,t:1527189407881};\\\", \\\"{x:1368,y:694,t:1527189407897};\\\", \\\"{x:1368,y:695,t:1527189407914};\\\", \\\"{x:1368,y:696,t:1527189408057};\\\", \\\"{x:1368,y:699,t:1527189408065};\\\", \\\"{x:1367,y:705,t:1527189408080};\\\", \\\"{x:1364,y:711,t:1527189408098};\\\", \\\"{x:1364,y:714,t:1527189408113};\\\", \\\"{x:1363,y:716,t:1527189408130};\\\", \\\"{x:1363,y:717,t:1527189408148};\\\", \\\"{x:1363,y:719,t:1527189408168};\\\", \\\"{x:1363,y:720,t:1527189408180};\\\", \\\"{x:1363,y:723,t:1527189408198};\\\", \\\"{x:1363,y:727,t:1527189408214};\\\", \\\"{x:1364,y:732,t:1527189408231};\\\", \\\"{x:1367,y:738,t:1527189408247};\\\", \\\"{x:1371,y:744,t:1527189408263};\\\", \\\"{x:1377,y:756,t:1527189408281};\\\", \\\"{x:1381,y:762,t:1527189408298};\\\", \\\"{x:1384,y:767,t:1527189408313};\\\", \\\"{x:1385,y:773,t:1527189408330};\\\", \\\"{x:1389,y:781,t:1527189408347};\\\", \\\"{x:1394,y:790,t:1527189408364};\\\", \\\"{x:1397,y:798,t:1527189408381};\\\", \\\"{x:1401,y:805,t:1527189408398};\\\", \\\"{x:1405,y:811,t:1527189408414};\\\", \\\"{x:1407,y:816,t:1527189408431};\\\", \\\"{x:1411,y:821,t:1527189408448};\\\", \\\"{x:1414,y:828,t:1527189408465};\\\", \\\"{x:1417,y:833,t:1527189408481};\\\", \\\"{x:1422,y:842,t:1527189408498};\\\", \\\"{x:1425,y:851,t:1527189408515};\\\", \\\"{x:1429,y:859,t:1527189408531};\\\", \\\"{x:1436,y:869,t:1527189408548};\\\", \\\"{x:1438,y:872,t:1527189408565};\\\", \\\"{x:1439,y:874,t:1527189408581};\\\", \\\"{x:1441,y:876,t:1527189408598};\\\", \\\"{x:1441,y:879,t:1527189408615};\\\", \\\"{x:1443,y:882,t:1527189408631};\\\", \\\"{x:1445,y:886,t:1527189408648};\\\", \\\"{x:1449,y:893,t:1527189408665};\\\", \\\"{x:1452,y:898,t:1527189408681};\\\", \\\"{x:1453,y:899,t:1527189408698};\\\", \\\"{x:1455,y:904,t:1527189408715};\\\", \\\"{x:1456,y:911,t:1527189408731};\\\", \\\"{x:1460,y:917,t:1527189408748};\\\", \\\"{x:1462,y:921,t:1527189408765};\\\", \\\"{x:1465,y:925,t:1527189408781};\\\", \\\"{x:1467,y:929,t:1527189408798};\\\", \\\"{x:1469,y:933,t:1527189408815};\\\", \\\"{x:1471,y:935,t:1527189408832};\\\", \\\"{x:1471,y:937,t:1527189408849};\\\", \\\"{x:1471,y:938,t:1527189408865};\\\", \\\"{x:1472,y:939,t:1527189408883};\\\", \\\"{x:1473,y:941,t:1527189408898};\\\", \\\"{x:1473,y:942,t:1527189408915};\\\", \\\"{x:1475,y:945,t:1527189408932};\\\", \\\"{x:1475,y:946,t:1527189408948};\\\", \\\"{x:1476,y:948,t:1527189408965};\\\", \\\"{x:1477,y:948,t:1527189408982};\\\", \\\"{x:1477,y:950,t:1527189408998};\\\", \\\"{x:1477,y:951,t:1527189409025};\\\", \\\"{x:1478,y:952,t:1527189409041};\\\", \\\"{x:1478,y:953,t:1527189409049};\\\", \\\"{x:1479,y:955,t:1527189409065};\\\", \\\"{x:1479,y:957,t:1527189409082};\\\", \\\"{x:1480,y:958,t:1527189409098};\\\", \\\"{x:1482,y:962,t:1527189422458};\\\", \\\"{x:1483,y:966,t:1527189422465};\\\", \\\"{x:1485,y:968,t:1527189422477};\\\", \\\"{x:1487,y:975,t:1527189422494};\\\", \\\"{x:1489,y:976,t:1527189422510};\\\", \\\"{x:1489,y:975,t:1527189422713};\\\", \\\"{x:1489,y:972,t:1527189422726};\\\", \\\"{x:1487,y:968,t:1527189422745};\\\", \\\"{x:1486,y:963,t:1527189422760};\\\", \\\"{x:1483,y:957,t:1527189422777};\\\", \\\"{x:1483,y:956,t:1527189422929};\\\", \\\"{x:1483,y:959,t:1527189423121};\\\", \\\"{x:1481,y:963,t:1527189423129};\\\", \\\"{x:1481,y:965,t:1527189423145};\\\", \\\"{x:1480,y:967,t:1527189423161};\\\", \\\"{x:1480,y:968,t:1527189444369};\\\", \\\"{x:1480,y:969,t:1527189444801};\\\", \\\"{x:1481,y:970,t:1527189444816};\\\", \\\"{x:1481,y:972,t:1527189444905};\\\", \\\"{x:1482,y:973,t:1527189444953};\\\", \\\"{x:1482,y:975,t:1527189445049};\\\", \\\"{x:1482,y:976,t:1527189445063};\\\", \\\"{x:1482,y:978,t:1527189445080};\\\", \\\"{x:1482,y:979,t:1527189445095};\\\", \\\"{x:1482,y:987,t:1527189445113};\\\", \\\"{x:1477,y:995,t:1527189445130};\\\", \\\"{x:1470,y:1005,t:1527189445145};\\\", \\\"{x:1461,y:1011,t:1527189445163};\\\", \\\"{x:1450,y:1017,t:1527189445180};\\\", \\\"{x:1436,y:1020,t:1527189445196};\\\", \\\"{x:1420,y:1022,t:1527189445213};\\\", \\\"{x:1411,y:1023,t:1527189445230};\\\", \\\"{x:1389,y:1019,t:1527189445246};\\\", \\\"{x:1370,y:1008,t:1527189445263};\\\", \\\"{x:1355,y:990,t:1527189445280};\\\", \\\"{x:1345,y:977,t:1527189445296};\\\", \\\"{x:1325,y:953,t:1527189445313};\\\", \\\"{x:1302,y:929,t:1527189445330};\\\", \\\"{x:1277,y:894,t:1527189445346};\\\", \\\"{x:1250,y:857,t:1527189445363};\\\", \\\"{x:1240,y:842,t:1527189445380};\\\", \\\"{x:1232,y:830,t:1527189445396};\\\", \\\"{x:1222,y:818,t:1527189445413};\\\", \\\"{x:1210,y:806,t:1527189445430};\\\", \\\"{x:1209,y:805,t:1527189445447};\\\", \\\"{x:1208,y:805,t:1527189445871};\\\", \\\"{x:1207,y:804,t:1527189445888};\\\", \\\"{x:1207,y:803,t:1527189445895};\\\", \\\"{x:1206,y:801,t:1527189445913};\\\", \\\"{x:1203,y:798,t:1527189445929};\\\", \\\"{x:1195,y:789,t:1527189445946};\\\", \\\"{x:1182,y:780,t:1527189445963};\\\", \\\"{x:1160,y:766,t:1527189445979};\\\", \\\"{x:1108,y:739,t:1527189445996};\\\", \\\"{x:1017,y:704,t:1527189446013};\\\", \\\"{x:915,y:659,t:1527189446029};\\\", \\\"{x:813,y:612,t:1527189446047};\\\", \\\"{x:728,y:563,t:1527189446064};\\\", \\\"{x:655,y:523,t:1527189446079};\\\", \\\"{x:625,y:509,t:1527189446089};\\\", \\\"{x:616,y:505,t:1527189446105};\\\", \\\"{x:614,y:503,t:1527189446127};\\\", \\\"{x:614,y:500,t:1527189446144};\\\", \\\"{x:620,y:497,t:1527189446161};\\\", \\\"{x:635,y:495,t:1527189446178};\\\", \\\"{x:643,y:495,t:1527189446194};\\\", \\\"{x:645,y:495,t:1527189446211};\\\", \\\"{x:648,y:495,t:1527189446255};\\\", \\\"{x:658,y:497,t:1527189446263};\\\", \\\"{x:666,y:499,t:1527189446277};\\\", \\\"{x:680,y:508,t:1527189446294};\\\", \\\"{x:689,y:518,t:1527189446311};\\\", \\\"{x:696,y:535,t:1527189446327};\\\", \\\"{x:700,y:548,t:1527189446344};\\\", \\\"{x:700,y:566,t:1527189446361};\\\", \\\"{x:700,y:591,t:1527189446378};\\\", \\\"{x:698,y:620,t:1527189446394};\\\", \\\"{x:696,y:641,t:1527189446411};\\\", \\\"{x:696,y:653,t:1527189446428};\\\", \\\"{x:696,y:656,t:1527189446444};\\\", \\\"{x:695,y:658,t:1527189446461};\\\", \\\"{x:693,y:659,t:1527189446478};\\\", \\\"{x:688,y:662,t:1527189446494};\\\", \\\"{x:680,y:668,t:1527189446511};\\\", \\\"{x:671,y:680,t:1527189446528};\\\", \\\"{x:662,y:691,t:1527189446545};\\\", \\\"{x:653,y:698,t:1527189446561};\\\", \\\"{x:643,y:701,t:1527189446578};\\\", \\\"{x:631,y:705,t:1527189446595};\\\", \\\"{x:628,y:705,t:1527189446612};\\\", \\\"{x:627,y:706,t:1527189446628};\\\", \\\"{x:623,y:707,t:1527189446644};\\\", \\\"{x:619,y:708,t:1527189446661};\\\", \\\"{x:617,y:710,t:1527189446678};\\\", \\\"{x:612,y:712,t:1527189446696};\\\", \\\"{x:609,y:715,t:1527189446712};\\\", \\\"{x:606,y:718,t:1527189446728};\\\", \\\"{x:601,y:720,t:1527189446746};\\\", \\\"{x:597,y:723,t:1527189446762};\\\", \\\"{x:592,y:726,t:1527189446779};\\\", \\\"{x:581,y:729,t:1527189446795};\\\", \\\"{x:574,y:730,t:1527189446811};\\\", \\\"{x:570,y:732,t:1527189446828};\\\", \\\"{x:565,y:735,t:1527189446845};\\\", \\\"{x:562,y:736,t:1527189446862};\\\", \\\"{x:559,y:739,t:1527189446878};\\\", \\\"{x:552,y:742,t:1527189446895};\\\", \\\"{x:545,y:746,t:1527189446912};\\\", \\\"{x:540,y:748,t:1527189446928};\\\", \\\"{x:537,y:750,t:1527189446946};\\\", \\\"{x:535,y:751,t:1527189446962};\\\", \\\"{x:533,y:752,t:1527189446978};\\\", \\\"{x:532,y:753,t:1527189446995};\\\", \\\"{x:531,y:753,t:1527189447121};\\\", \\\"{x:528,y:752,t:1527189447129};\\\", \\\"{x:523,y:747,t:1527189447146};\\\", \\\"{x:513,y:739,t:1527189447163};\\\", \\\"{x:507,y:735,t:1527189447179};\\\", \\\"{x:499,y:729,t:1527189447195};\\\", \\\"{x:495,y:728,t:1527189447212};\\\", \\\"{x:494,y:726,t:1527189447229};\\\" ] }, { \\\"rt\\\": 29898, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 862388, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-02 PM-02 PM-01 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:726,t:1527189450921};\\\", \\\"{x:514,y:733,t:1527189450937};\\\", \\\"{x:533,y:741,t:1527189450954};\\\", \\\"{x:557,y:757,t:1527189450972};\\\", \\\"{x:578,y:768,t:1527189450988};\\\", \\\"{x:614,y:786,t:1527189451004};\\\", \\\"{x:676,y:818,t:1527189451015};\\\", \\\"{x:738,y:852,t:1527189451031};\\\", \\\"{x:810,y:885,t:1527189451048};\\\", \\\"{x:885,y:917,t:1527189451065};\\\", \\\"{x:959,y:946,t:1527189451081};\\\", \\\"{x:1052,y:986,t:1527189451099};\\\", \\\"{x:1140,y:1019,t:1527189451116};\\\", \\\"{x:1210,y:1043,t:1527189451131};\\\", \\\"{x:1252,y:1056,t:1527189451149};\\\", \\\"{x:1268,y:1061,t:1527189451166};\\\", \\\"{x:1270,y:1061,t:1527189451182};\\\", \\\"{x:1271,y:1061,t:1527189451401};\\\", \\\"{x:1273,y:1061,t:1527189451560};\\\", \\\"{x:1277,y:1061,t:1527189451569};\\\", \\\"{x:1286,y:1061,t:1527189451583};\\\", \\\"{x:1311,y:1061,t:1527189451598};\\\", \\\"{x:1388,y:1061,t:1527189451616};\\\", \\\"{x:1446,y:1061,t:1527189451632};\\\", \\\"{x:1505,y:1061,t:1527189451649};\\\", \\\"{x:1544,y:1061,t:1527189451666};\\\", \\\"{x:1579,y:1061,t:1527189451683};\\\", \\\"{x:1602,y:1059,t:1527189451699};\\\", \\\"{x:1619,y:1057,t:1527189451716};\\\", \\\"{x:1632,y:1053,t:1527189451733};\\\", \\\"{x:1641,y:1050,t:1527189451749};\\\", \\\"{x:1651,y:1050,t:1527189451766};\\\", \\\"{x:1662,y:1050,t:1527189451783};\\\", \\\"{x:1677,y:1055,t:1527189451799};\\\", \\\"{x:1690,y:1061,t:1527189451816};\\\", \\\"{x:1692,y:1061,t:1527189451832};\\\", \\\"{x:1692,y:1060,t:1527189452449};\\\", \\\"{x:1676,y:1053,t:1527189452467};\\\", \\\"{x:1650,y:1040,t:1527189452483};\\\", \\\"{x:1615,y:1024,t:1527189452500};\\\", \\\"{x:1586,y:1010,t:1527189452517};\\\", \\\"{x:1548,y:995,t:1527189452533};\\\", \\\"{x:1499,y:976,t:1527189452550};\\\", \\\"{x:1460,y:964,t:1527189452568};\\\", \\\"{x:1436,y:958,t:1527189452583};\\\", \\\"{x:1422,y:956,t:1527189452600};\\\", \\\"{x:1420,y:956,t:1527189452617};\\\", \\\"{x:1419,y:956,t:1527189452713};\\\", \\\"{x:1417,y:959,t:1527189452721};\\\", \\\"{x:1417,y:967,t:1527189452733};\\\", \\\"{x:1417,y:992,t:1527189452751};\\\", \\\"{x:1417,y:1014,t:1527189452767};\\\", \\\"{x:1425,y:1034,t:1527189452784};\\\", \\\"{x:1435,y:1061,t:1527189452801};\\\", \\\"{x:1438,y:1071,t:1527189452816};\\\", \\\"{x:1440,y:1075,t:1527189452834};\\\", \\\"{x:1442,y:1078,t:1527189452850};\\\", \\\"{x:1443,y:1079,t:1527189452867};\\\", \\\"{x:1444,y:1079,t:1527189452888};\\\", \\\"{x:1445,y:1079,t:1527189452900};\\\", \\\"{x:1450,y:1078,t:1527189452917};\\\", \\\"{x:1460,y:1064,t:1527189452933};\\\", \\\"{x:1471,y:1049,t:1527189452951};\\\", \\\"{x:1485,y:1028,t:1527189452967};\\\", \\\"{x:1497,y:1004,t:1527189452984};\\\", \\\"{x:1500,y:993,t:1527189453001};\\\", \\\"{x:1500,y:984,t:1527189453017};\\\", \\\"{x:1500,y:975,t:1527189453034};\\\", \\\"{x:1499,y:968,t:1527189453050};\\\", \\\"{x:1498,y:964,t:1527189453068};\\\", \\\"{x:1497,y:962,t:1527189453085};\\\", \\\"{x:1496,y:962,t:1527189453225};\\\", \\\"{x:1495,y:964,t:1527189453235};\\\", \\\"{x:1494,y:968,t:1527189453252};\\\", \\\"{x:1491,y:974,t:1527189453267};\\\", \\\"{x:1489,y:978,t:1527189453284};\\\", \\\"{x:1487,y:980,t:1527189453301};\\\", \\\"{x:1485,y:977,t:1527189453504};\\\", \\\"{x:1484,y:974,t:1527189453517};\\\", \\\"{x:1484,y:971,t:1527189453534};\\\", \\\"{x:1482,y:968,t:1527189453552};\\\", \\\"{x:1481,y:965,t:1527189453568};\\\", \\\"{x:1480,y:964,t:1527189453585};\\\", \\\"{x:1479,y:963,t:1527189453608};\\\", \\\"{x:1478,y:963,t:1527189453619};\\\", \\\"{x:1478,y:962,t:1527189453634};\\\", \\\"{x:1474,y:961,t:1527189453651};\\\", \\\"{x:1469,y:958,t:1527189453668};\\\", \\\"{x:1466,y:957,t:1527189453684};\\\", \\\"{x:1466,y:955,t:1527189453873};\\\", \\\"{x:1467,y:954,t:1527189453884};\\\", \\\"{x:1470,y:953,t:1527189453901};\\\", \\\"{x:1473,y:951,t:1527189453918};\\\", \\\"{x:1474,y:951,t:1527189453934};\\\", \\\"{x:1475,y:951,t:1527189453951};\\\", \\\"{x:1477,y:950,t:1527189453969};\\\", \\\"{x:1478,y:950,t:1527189453984};\\\", \\\"{x:1480,y:950,t:1527189454001};\\\", \\\"{x:1481,y:950,t:1527189454025};\\\", \\\"{x:1483,y:950,t:1527189454034};\\\", \\\"{x:1484,y:950,t:1527189454057};\\\", \\\"{x:1485,y:950,t:1527189454069};\\\", \\\"{x:1486,y:950,t:1527189454085};\\\", \\\"{x:1488,y:951,t:1527189455161};\\\", \\\"{x:1489,y:951,t:1527189455176};\\\", \\\"{x:1488,y:951,t:1527189455192};\\\", \\\"{x:1488,y:952,t:1527189455888};\\\", \\\"{x:1489,y:954,t:1527189455992};\\\", \\\"{x:1490,y:958,t:1527189456002};\\\", \\\"{x:1490,y:965,t:1527189456019};\\\", \\\"{x:1491,y:970,t:1527189456036};\\\", \\\"{x:1491,y:971,t:1527189456105};\\\", \\\"{x:1491,y:972,t:1527189456128};\\\", \\\"{x:1491,y:973,t:1527189456145};\\\", \\\"{x:1491,y:974,t:1527189456193};\\\", \\\"{x:1491,y:975,t:1527189456204};\\\", \\\"{x:1491,y:977,t:1527189456219};\\\", \\\"{x:1491,y:979,t:1527189456237};\\\", \\\"{x:1491,y:980,t:1527189456253};\\\", \\\"{x:1491,y:981,t:1527189456270};\\\", \\\"{x:1490,y:982,t:1527189456286};\\\", \\\"{x:1489,y:982,t:1527189456305};\\\", \\\"{x:1488,y:982,t:1527189456329};\\\", \\\"{x:1487,y:982,t:1527189456337};\\\", \\\"{x:1486,y:982,t:1527189456353};\\\", \\\"{x:1484,y:982,t:1527189456370};\\\", \\\"{x:1481,y:982,t:1527189456386};\\\", \\\"{x:1481,y:981,t:1527189456404};\\\", \\\"{x:1479,y:980,t:1527189456421};\\\", \\\"{x:1478,y:979,t:1527189456437};\\\", \\\"{x:1476,y:979,t:1527189456780};\\\", \\\"{x:1473,y:979,t:1527189456789};\\\", \\\"{x:1470,y:980,t:1527189456806};\\\", \\\"{x:1470,y:981,t:1527189456823};\\\", \\\"{x:1469,y:981,t:1527189456916};\\\", \\\"{x:1468,y:981,t:1527189456924};\\\", \\\"{x:1465,y:981,t:1527189456945};\\\", \\\"{x:1439,y:981,t:1527189456995};\\\", \\\"{x:1434,y:981,t:1527189457006};\\\", \\\"{x:1418,y:981,t:1527189457023};\\\", \\\"{x:1404,y:985,t:1527189457040};\\\", \\\"{x:1392,y:988,t:1527189457056};\\\", \\\"{x:1381,y:990,t:1527189457072};\\\", \\\"{x:1366,y:994,t:1527189457091};\\\", \\\"{x:1361,y:995,t:1527189457106};\\\", \\\"{x:1355,y:998,t:1527189457122};\\\", \\\"{x:1354,y:998,t:1527189457140};\\\", \\\"{x:1353,y:998,t:1527189457156};\\\", \\\"{x:1351,y:998,t:1527189457203};\\\", \\\"{x:1350,y:998,t:1527189457211};\\\", \\\"{x:1344,y:998,t:1527189457223};\\\", \\\"{x:1334,y:996,t:1527189457240};\\\", \\\"{x:1325,y:992,t:1527189457257};\\\", \\\"{x:1315,y:991,t:1527189457273};\\\", \\\"{x:1308,y:990,t:1527189457290};\\\", \\\"{x:1303,y:988,t:1527189457307};\\\", \\\"{x:1303,y:987,t:1527189457372};\\\", \\\"{x:1303,y:985,t:1527189457391};\\\", \\\"{x:1303,y:981,t:1527189457407};\\\", \\\"{x:1307,y:977,t:1527189457423};\\\", \\\"{x:1310,y:974,t:1527189457440};\\\", \\\"{x:1316,y:972,t:1527189457457};\\\", \\\"{x:1322,y:970,t:1527189457473};\\\", \\\"{x:1327,y:969,t:1527189457489};\\\", \\\"{x:1330,y:969,t:1527189457507};\\\", \\\"{x:1331,y:969,t:1527189457523};\\\", \\\"{x:1333,y:969,t:1527189457540};\\\", \\\"{x:1336,y:969,t:1527189457557};\\\", \\\"{x:1339,y:969,t:1527189457584};\\\", \\\"{x:1340,y:970,t:1527189457589};\\\", \\\"{x:1345,y:971,t:1527189457621};\\\", \\\"{x:1346,y:972,t:1527189457635};\\\", \\\"{x:1346,y:975,t:1527189459596};\\\", \\\"{x:1346,y:981,t:1527189459608};\\\", \\\"{x:1346,y:995,t:1527189459627};\\\", \\\"{x:1346,y:1004,t:1527189459643};\\\", \\\"{x:1346,y:1011,t:1527189459658};\\\", \\\"{x:1346,y:1015,t:1527189459675};\\\", \\\"{x:1346,y:1013,t:1527189459908};\\\", \\\"{x:1346,y:1012,t:1527189459923};\\\", \\\"{x:1346,y:1011,t:1527189459932};\\\", \\\"{x:1346,y:1010,t:1527189459942};\\\", \\\"{x:1346,y:1008,t:1527189459960};\\\", \\\"{x:1346,y:1005,t:1527189459975};\\\", \\\"{x:1346,y:1003,t:1527189459993};\\\", \\\"{x:1341,y:1000,t:1527189460251};\\\", \\\"{x:1324,y:991,t:1527189460260};\\\", \\\"{x:1266,y:963,t:1527189460276};\\\", \\\"{x:1152,y:906,t:1527189460293};\\\", \\\"{x:1040,y:842,t:1527189460310};\\\", \\\"{x:954,y:805,t:1527189460327};\\\", \\\"{x:891,y:777,t:1527189460342};\\\", \\\"{x:849,y:757,t:1527189460359};\\\", \\\"{x:830,y:747,t:1527189460377};\\\", \\\"{x:823,y:743,t:1527189460393};\\\", \\\"{x:819,y:737,t:1527189460409};\\\", \\\"{x:817,y:734,t:1527189460427};\\\", \\\"{x:808,y:719,t:1527189460442};\\\", \\\"{x:763,y:683,t:1527189460460};\\\", \\\"{x:701,y:639,t:1527189460476};\\\", \\\"{x:628,y:602,t:1527189460494};\\\", \\\"{x:571,y:578,t:1527189460509};\\\", \\\"{x:541,y:571,t:1527189460525};\\\", \\\"{x:527,y:570,t:1527189460542};\\\", \\\"{x:521,y:569,t:1527189460559};\\\", \\\"{x:519,y:568,t:1527189460576};\\\", \\\"{x:518,y:568,t:1527189460650};\\\", \\\"{x:521,y:568,t:1527189460707};\\\", \\\"{x:526,y:569,t:1527189460715};\\\", \\\"{x:530,y:569,t:1527189460726};\\\", \\\"{x:539,y:569,t:1527189460743};\\\", \\\"{x:550,y:569,t:1527189460759};\\\", \\\"{x:564,y:565,t:1527189460776};\\\", \\\"{x:581,y:561,t:1527189460794};\\\", \\\"{x:596,y:559,t:1527189460809};\\\", \\\"{x:616,y:556,t:1527189460826};\\\", \\\"{x:639,y:552,t:1527189460845};\\\", \\\"{x:646,y:549,t:1527189460860};\\\", \\\"{x:650,y:546,t:1527189460876};\\\", \\\"{x:649,y:544,t:1527189460955};\\\", \\\"{x:643,y:542,t:1527189460963};\\\", \\\"{x:637,y:539,t:1527189460976};\\\", \\\"{x:626,y:537,t:1527189460993};\\\", \\\"{x:613,y:537,t:1527189461009};\\\", \\\"{x:601,y:538,t:1527189461026};\\\", \\\"{x:590,y:540,t:1527189461043};\\\", \\\"{x:587,y:542,t:1527189461059};\\\", \\\"{x:586,y:542,t:1527189461082};\\\", \\\"{x:585,y:542,t:1527189461123};\\\", \\\"{x:583,y:543,t:1527189461131};\\\", \\\"{x:583,y:544,t:1527189461143};\\\", \\\"{x:574,y:545,t:1527189461159};\\\", \\\"{x:562,y:547,t:1527189461177};\\\", \\\"{x:545,y:547,t:1527189461193};\\\", \\\"{x:521,y:547,t:1527189461210};\\\", \\\"{x:480,y:538,t:1527189461228};\\\", \\\"{x:436,y:531,t:1527189461243};\\\", \\\"{x:433,y:531,t:1527189461260};\\\", \\\"{x:431,y:531,t:1527189461427};\\\", \\\"{x:429,y:531,t:1527189461444};\\\", \\\"{x:426,y:531,t:1527189461460};\\\", \\\"{x:425,y:531,t:1527189461483};\\\", \\\"{x:424,y:531,t:1527189461495};\\\", \\\"{x:423,y:532,t:1527189461510};\\\", \\\"{x:420,y:532,t:1527189461528};\\\", \\\"{x:416,y:533,t:1527189461546};\\\", \\\"{x:413,y:533,t:1527189461560};\\\", \\\"{x:409,y:533,t:1527189461578};\\\", \\\"{x:408,y:534,t:1527189461593};\\\", \\\"{x:407,y:534,t:1527189461611};\\\", \\\"{x:407,y:535,t:1527189461627};\\\", \\\"{x:406,y:535,t:1527189461643};\\\", \\\"{x:404,y:536,t:1527189461661};\\\", \\\"{x:402,y:537,t:1527189461683};\\\", \\\"{x:401,y:538,t:1527189461699};\\\", \\\"{x:400,y:538,t:1527189461715};\\\", \\\"{x:399,y:539,t:1527189461747};\\\", \\\"{x:397,y:540,t:1527189461779};\\\", \\\"{x:396,y:541,t:1527189461844};\\\", \\\"{x:395,y:541,t:1527189461861};\\\", \\\"{x:394,y:542,t:1527189461882};\\\", \\\"{x:393,y:542,t:1527189461899};\\\", \\\"{x:392,y:543,t:1527189461910};\\\", \\\"{x:391,y:544,t:1527189461927};\\\", \\\"{x:390,y:544,t:1527189461947};\\\", \\\"{x:389,y:544,t:1527189461963};\\\", \\\"{x:388,y:544,t:1527189461977};\\\", \\\"{x:388,y:545,t:1527189463932};\\\", \\\"{x:398,y:545,t:1527189463946};\\\", \\\"{x:429,y:545,t:1527189463964};\\\", \\\"{x:501,y:548,t:1527189463979};\\\", \\\"{x:551,y:548,t:1527189463995};\\\", \\\"{x:596,y:548,t:1527189464012};\\\", \\\"{x:628,y:545,t:1527189464028};\\\", \\\"{x:663,y:543,t:1527189464046};\\\", \\\"{x:697,y:543,t:1527189464062};\\\", \\\"{x:724,y:542,t:1527189464079};\\\", \\\"{x:750,y:537,t:1527189464095};\\\", \\\"{x:768,y:537,t:1527189464112};\\\", \\\"{x:776,y:537,t:1527189464129};\\\", \\\"{x:772,y:538,t:1527189464203};\\\", \\\"{x:768,y:539,t:1527189464212};\\\", \\\"{x:754,y:541,t:1527189464229};\\\", \\\"{x:736,y:541,t:1527189464245};\\\", \\\"{x:724,y:541,t:1527189464263};\\\", \\\"{x:715,y:541,t:1527189464281};\\\", \\\"{x:704,y:541,t:1527189464295};\\\", \\\"{x:692,y:541,t:1527189464312};\\\", \\\"{x:681,y:541,t:1527189464329};\\\", \\\"{x:667,y:541,t:1527189464346};\\\", \\\"{x:645,y:536,t:1527189464362};\\\", \\\"{x:612,y:533,t:1527189464379};\\\", \\\"{x:582,y:528,t:1527189464396};\\\", \\\"{x:538,y:520,t:1527189464413};\\\", \\\"{x:495,y:513,t:1527189464429};\\\", \\\"{x:448,y:499,t:1527189464445};\\\", \\\"{x:412,y:491,t:1527189464462};\\\", \\\"{x:378,y:481,t:1527189464479};\\\", \\\"{x:348,y:474,t:1527189464497};\\\", \\\"{x:326,y:471,t:1527189464512};\\\", \\\"{x:319,y:471,t:1527189464529};\\\", \\\"{x:315,y:471,t:1527189464546};\\\", \\\"{x:306,y:474,t:1527189464562};\\\", \\\"{x:290,y:480,t:1527189464579};\\\", \\\"{x:276,y:484,t:1527189464596};\\\", \\\"{x:269,y:488,t:1527189464615};\\\", \\\"{x:268,y:488,t:1527189464629};\\\", \\\"{x:267,y:488,t:1527189464646};\\\", \\\"{x:265,y:489,t:1527189464667};\\\", \\\"{x:263,y:491,t:1527189464679};\\\", \\\"{x:260,y:502,t:1527189464697};\\\", \\\"{x:260,y:521,t:1527189464713};\\\", \\\"{x:263,y:540,t:1527189464730};\\\", \\\"{x:277,y:560,t:1527189464747};\\\", \\\"{x:293,y:579,t:1527189464762};\\\", \\\"{x:330,y:603,t:1527189464781};\\\", \\\"{x:376,y:621,t:1527189464796};\\\", \\\"{x:413,y:638,t:1527189464812};\\\", \\\"{x:461,y:655,t:1527189464829};\\\", \\\"{x:487,y:663,t:1527189464846};\\\", \\\"{x:498,y:666,t:1527189464862};\\\", \\\"{x:494,y:665,t:1527189464947};\\\", \\\"{x:484,y:661,t:1527189464962};\\\", \\\"{x:466,y:654,t:1527189464979};\\\", \\\"{x:446,y:645,t:1527189464996};\\\", \\\"{x:433,y:640,t:1527189465012};\\\", \\\"{x:421,y:632,t:1527189465030};\\\", \\\"{x:409,y:624,t:1527189465047};\\\", \\\"{x:400,y:619,t:1527189465064};\\\", \\\"{x:392,y:615,t:1527189465080};\\\", \\\"{x:391,y:614,t:1527189465097};\\\", \\\"{x:390,y:614,t:1527189465243};\\\", \\\"{x:389,y:614,t:1527189465259};\\\", \\\"{x:388,y:619,t:1527189477971};\\\", \\\"{x:398,y:648,t:1527189477992};\\\", \\\"{x:409,y:671,t:1527189478005};\\\", \\\"{x:421,y:689,t:1527189478022};\\\", \\\"{x:432,y:701,t:1527189478040};\\\", \\\"{x:435,y:704,t:1527189478057};\\\", \\\"{x:437,y:705,t:1527189478073};\\\", \\\"{x:437,y:706,t:1527189478244};\\\", \\\"{x:440,y:711,t:1527189478258};\\\", \\\"{x:444,y:716,t:1527189478275};\\\", \\\"{x:453,y:728,t:1527189478292};\\\", \\\"{x:462,y:736,t:1527189478306};\\\", \\\"{x:468,y:741,t:1527189478323};\\\", \\\"{x:470,y:742,t:1527189478340};\\\", \\\"{x:471,y:743,t:1527189478378};\\\", \\\"{x:472,y:743,t:1527189478390};\\\", \\\"{x:473,y:743,t:1527189478407};\\\", \\\"{x:477,y:745,t:1527189478422};\\\", \\\"{x:478,y:746,t:1527189478440};\\\", \\\"{x:479,y:746,t:1527189478457};\\\", \\\"{x:479,y:745,t:1527189479115};\\\", \\\"{x:480,y:743,t:1527189479125};\\\", \\\"{x:480,y:739,t:1527189479141};\\\", \\\"{x:481,y:736,t:1527189479158};\\\", \\\"{x:481,y:735,t:1527189479175};\\\", \\\"{x:481,y:733,t:1527189479195};\\\", \\\"{x:481,y:732,t:1527189479355};\\\" ] }, { \\\"rt\\\": 16269, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 879937, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-G -G -10 AM-10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:732,t:1527189482100};\\\", \\\"{x:493,y:732,t:1527189482114};\\\", \\\"{x:561,y:734,t:1527189482137};\\\", \\\"{x:625,y:742,t:1527189482148};\\\", \\\"{x:704,y:757,t:1527189482164};\\\", \\\"{x:820,y:788,t:1527189482180};\\\", \\\"{x:891,y:808,t:1527189482193};\\\", \\\"{x:1069,y:862,t:1527189482210};\\\", \\\"{x:1350,y:935,t:1527189482226};\\\", \\\"{x:1489,y:963,t:1527189482244};\\\", \\\"{x:1578,y:975,t:1527189482261};\\\", \\\"{x:1612,y:976,t:1527189482278};\\\", \\\"{x:1616,y:976,t:1527189482294};\\\", \\\"{x:1615,y:975,t:1527189482322};\\\", \\\"{x:1611,y:973,t:1527189482331};\\\", \\\"{x:1603,y:969,t:1527189482345};\\\", \\\"{x:1586,y:957,t:1527189482361};\\\", \\\"{x:1566,y:942,t:1527189482377};\\\", \\\"{x:1547,y:924,t:1527189482394};\\\", \\\"{x:1519,y:896,t:1527189482411};\\\", \\\"{x:1473,y:854,t:1527189482427};\\\", \\\"{x:1448,y:831,t:1527189482444};\\\", \\\"{x:1428,y:814,t:1527189482460};\\\", \\\"{x:1410,y:797,t:1527189482478};\\\", \\\"{x:1390,y:776,t:1527189482495};\\\", \\\"{x:1355,y:741,t:1527189482510};\\\", \\\"{x:1308,y:701,t:1527189482528};\\\", \\\"{x:1245,y:661,t:1527189482545};\\\", \\\"{x:1196,y:631,t:1527189482560};\\\", \\\"{x:1178,y:623,t:1527189482579};\\\", \\\"{x:1179,y:623,t:1527189482604};\\\", \\\"{x:1185,y:623,t:1527189482611};\\\", \\\"{x:1193,y:627,t:1527189482628};\\\", \\\"{x:1199,y:629,t:1527189482644};\\\", \\\"{x:1203,y:630,t:1527189482661};\\\", \\\"{x:1205,y:632,t:1527189482716};\\\", \\\"{x:1210,y:637,t:1527189482728};\\\", \\\"{x:1225,y:649,t:1527189482744};\\\", \\\"{x:1243,y:665,t:1527189482762};\\\", \\\"{x:1267,y:685,t:1527189482778};\\\", \\\"{x:1294,y:712,t:1527189482795};\\\", \\\"{x:1319,y:757,t:1527189482811};\\\", \\\"{x:1324,y:794,t:1527189482827};\\\", \\\"{x:1326,y:834,t:1527189482844};\\\", \\\"{x:1322,y:872,t:1527189482861};\\\", \\\"{x:1314,y:903,t:1527189482878};\\\", \\\"{x:1310,y:930,t:1527189482895};\\\", \\\"{x:1310,y:942,t:1527189482912};\\\", \\\"{x:1306,y:951,t:1527189482927};\\\", \\\"{x:1304,y:953,t:1527189482944};\\\", \\\"{x:1302,y:954,t:1527189482962};\\\", \\\"{x:1301,y:956,t:1527189482977};\\\", \\\"{x:1299,y:956,t:1527189483108};\\\", \\\"{x:1298,y:958,t:1527189483228};\\\", \\\"{x:1297,y:959,t:1527189483244};\\\", \\\"{x:1292,y:962,t:1527189483262};\\\", \\\"{x:1288,y:963,t:1527189483279};\\\", \\\"{x:1285,y:964,t:1527189483295};\\\", \\\"{x:1285,y:963,t:1527189483588};\\\", \\\"{x:1279,y:957,t:1527189483596};\\\", \\\"{x:1267,y:957,t:1527189483612};\\\", \\\"{x:1263,y:952,t:1527189483629};\\\", \\\"{x:1256,y:950,t:1527189483646};\\\", \\\"{x:1253,y:950,t:1527189483662};\\\", \\\"{x:1251,y:950,t:1527189483679};\\\", \\\"{x:1249,y:950,t:1527189483696};\\\", \\\"{x:1246,y:951,t:1527189483711};\\\", \\\"{x:1242,y:952,t:1527189483729};\\\", \\\"{x:1235,y:952,t:1527189483746};\\\", \\\"{x:1220,y:952,t:1527189483762};\\\", \\\"{x:1207,y:952,t:1527189483779};\\\", \\\"{x:1206,y:953,t:1527189483796};\\\", \\\"{x:1207,y:953,t:1527189483924};\\\", \\\"{x:1207,y:951,t:1527189483931};\\\", \\\"{x:1211,y:946,t:1527189483946};\\\", \\\"{x:1215,y:940,t:1527189483962};\\\", \\\"{x:1220,y:934,t:1527189483979};\\\", \\\"{x:1227,y:926,t:1527189483996};\\\", \\\"{x:1233,y:920,t:1527189484012};\\\", \\\"{x:1241,y:911,t:1527189484029};\\\", \\\"{x:1246,y:907,t:1527189484046};\\\", \\\"{x:1252,y:899,t:1527189484062};\\\", \\\"{x:1258,y:891,t:1527189484079};\\\", \\\"{x:1262,y:884,t:1527189484096};\\\", \\\"{x:1269,y:874,t:1527189484113};\\\", \\\"{x:1275,y:867,t:1527189484129};\\\", \\\"{x:1281,y:857,t:1527189484146};\\\", \\\"{x:1286,y:848,t:1527189484163};\\\", \\\"{x:1290,y:841,t:1527189484179};\\\", \\\"{x:1297,y:827,t:1527189484195};\\\", \\\"{x:1299,y:822,t:1527189484213};\\\", \\\"{x:1302,y:816,t:1527189484229};\\\", \\\"{x:1305,y:811,t:1527189484246};\\\", \\\"{x:1307,y:805,t:1527189484264};\\\", \\\"{x:1310,y:799,t:1527189484278};\\\", \\\"{x:1312,y:792,t:1527189484296};\\\", \\\"{x:1316,y:783,t:1527189484312};\\\", \\\"{x:1320,y:772,t:1527189484328};\\\", \\\"{x:1326,y:762,t:1527189484345};\\\", \\\"{x:1332,y:750,t:1527189484362};\\\", \\\"{x:1337,y:736,t:1527189484378};\\\", \\\"{x:1346,y:719,t:1527189484395};\\\", \\\"{x:1348,y:713,t:1527189484412};\\\", \\\"{x:1352,y:705,t:1527189484428};\\\", \\\"{x:1356,y:697,t:1527189484445};\\\", \\\"{x:1361,y:692,t:1527189484462};\\\", \\\"{x:1364,y:686,t:1527189484479};\\\", \\\"{x:1367,y:681,t:1527189484496};\\\", \\\"{x:1371,y:676,t:1527189484513};\\\", \\\"{x:1379,y:665,t:1527189484528};\\\", \\\"{x:1389,y:647,t:1527189484546};\\\", \\\"{x:1398,y:635,t:1527189484563};\\\", \\\"{x:1403,y:625,t:1527189484579};\\\", \\\"{x:1406,y:620,t:1527189484595};\\\", \\\"{x:1410,y:612,t:1527189484613};\\\", \\\"{x:1412,y:605,t:1527189484630};\\\", \\\"{x:1413,y:601,t:1527189484646};\\\", \\\"{x:1414,y:594,t:1527189484664};\\\", \\\"{x:1414,y:588,t:1527189484680};\\\", \\\"{x:1414,y:581,t:1527189484695};\\\", \\\"{x:1414,y:577,t:1527189484713};\\\", \\\"{x:1414,y:571,t:1527189484730};\\\", \\\"{x:1414,y:566,t:1527189484749};\\\", \\\"{x:1415,y:560,t:1527189484763};\\\", \\\"{x:1416,y:557,t:1527189484779};\\\", \\\"{x:1416,y:556,t:1527189484795};\\\", \\\"{x:1416,y:555,t:1527189484812};\\\", \\\"{x:1413,y:554,t:1527189485372};\\\", \\\"{x:1403,y:560,t:1527189485380};\\\", \\\"{x:1363,y:583,t:1527189485397};\\\", \\\"{x:1297,y:622,t:1527189485412};\\\", \\\"{x:1229,y:658,t:1527189485430};\\\", \\\"{x:1144,y:693,t:1527189485447};\\\", \\\"{x:1049,y:723,t:1527189485464};\\\", \\\"{x:954,y:742,t:1527189485480};\\\", \\\"{x:859,y:756,t:1527189485497};\\\", \\\"{x:762,y:756,t:1527189485514};\\\", \\\"{x:651,y:753,t:1527189485530};\\\", \\\"{x:531,y:734,t:1527189485547};\\\", \\\"{x:425,y:705,t:1527189485563};\\\", \\\"{x:424,y:703,t:1527189485579};\\\", \\\"{x:424,y:701,t:1527189485596};\\\", \\\"{x:424,y:700,t:1527189485860};\\\", \\\"{x:434,y:698,t:1527189485882};\\\", \\\"{x:446,y:694,t:1527189485896};\\\", \\\"{x:500,y:677,t:1527189485914};\\\", \\\"{x:637,y:656,t:1527189485930};\\\", \\\"{x:697,y:648,t:1527189485946};\\\", \\\"{x:843,y:638,t:1527189485963};\\\", \\\"{x:927,y:636,t:1527189485980};\\\", \\\"{x:983,y:636,t:1527189485996};\\\", \\\"{x:1008,y:636,t:1527189486013};\\\", \\\"{x:1017,y:636,t:1527189486030};\\\", \\\"{x:1016,y:635,t:1527189486050};\\\", \\\"{x:1013,y:633,t:1527189486067};\\\", \\\"{x:1012,y:631,t:1527189486081};\\\", \\\"{x:1012,y:630,t:1527189486204};\\\", \\\"{x:1004,y:626,t:1527189486214};\\\", \\\"{x:980,y:617,t:1527189486232};\\\", \\\"{x:948,y:601,t:1527189486249};\\\", \\\"{x:910,y:586,t:1527189486264};\\\", \\\"{x:865,y:562,t:1527189486280};\\\", \\\"{x:830,y:547,t:1527189486298};\\\", \\\"{x:813,y:539,t:1527189486313};\\\", \\\"{x:809,y:535,t:1527189486330};\\\", \\\"{x:810,y:532,t:1527189486346};\\\", \\\"{x:813,y:530,t:1527189486363};\\\", \\\"{x:815,y:529,t:1527189486380};\\\", \\\"{x:816,y:528,t:1527189486442};\\\", \\\"{x:817,y:528,t:1527189486523};\\\", \\\"{x:818,y:528,t:1527189486531};\\\", \\\"{x:820,y:528,t:1527189486548};\\\", \\\"{x:823,y:528,t:1527189486564};\\\", \\\"{x:826,y:531,t:1527189486582};\\\", \\\"{x:829,y:533,t:1527189486597};\\\", \\\"{x:832,y:536,t:1527189486614};\\\", \\\"{x:834,y:538,t:1527189486629};\\\", \\\"{x:835,y:538,t:1527189486646};\\\", \\\"{x:836,y:539,t:1527189486663};\\\", \\\"{x:837,y:540,t:1527189487339};\\\", \\\"{x:844,y:568,t:1527189487349};\\\", \\\"{x:871,y:660,t:1527189487364};\\\", \\\"{x:918,y:754,t:1527189487382};\\\", \\\"{x:996,y:860,t:1527189487398};\\\", \\\"{x:1093,y:944,t:1527189487414};\\\", \\\"{x:1198,y:1014,t:1527189487431};\\\", \\\"{x:1284,y:1055,t:1527189487449};\\\", \\\"{x:1317,y:1074,t:1527189487464};\\\", \\\"{x:1321,y:1077,t:1527189487481};\\\", \\\"{x:1293,y:1082,t:1527189487498};\\\", \\\"{x:1248,y:1082,t:1527189487515};\\\", \\\"{x:1201,y:1093,t:1527189487531};\\\", \\\"{x:1197,y:1092,t:1527189487548};\\\", \\\"{x:1197,y:1091,t:1527189487564};\\\", \\\"{x:1196,y:1091,t:1527189487947};\\\", \\\"{x:1192,y:1088,t:1527189487965};\\\", \\\"{x:1183,y:1083,t:1527189487982};\\\", \\\"{x:1168,y:1075,t:1527189487998};\\\", \\\"{x:1157,y:1068,t:1527189488015};\\\", \\\"{x:1149,y:1063,t:1527189488031};\\\", \\\"{x:1142,y:1058,t:1527189488049};\\\", \\\"{x:1135,y:1051,t:1527189488066};\\\", \\\"{x:1128,y:1045,t:1527189488082};\\\", \\\"{x:1120,y:1036,t:1527189488100};\\\", \\\"{x:1115,y:1032,t:1527189488116};\\\", \\\"{x:1115,y:1031,t:1527189488132};\\\", \\\"{x:1115,y:1030,t:1527189488149};\\\", \\\"{x:1115,y:1029,t:1527189488179};\\\", \\\"{x:1115,y:1027,t:1527189488188};\\\", \\\"{x:1115,y:1025,t:1527189488199};\\\", \\\"{x:1122,y:1019,t:1527189488215};\\\", \\\"{x:1134,y:1012,t:1527189488232};\\\", \\\"{x:1151,y:1000,t:1527189488249};\\\", \\\"{x:1172,y:985,t:1527189488266};\\\", \\\"{x:1195,y:967,t:1527189488281};\\\", \\\"{x:1244,y:937,t:1527189488298};\\\", \\\"{x:1262,y:927,t:1527189488316};\\\", \\\"{x:1271,y:922,t:1527189488331};\\\", \\\"{x:1272,y:922,t:1527189488348};\\\", \\\"{x:1274,y:921,t:1527189488365};\\\", \\\"{x:1273,y:924,t:1527189488572};\\\", \\\"{x:1270,y:933,t:1527189488583};\\\", \\\"{x:1270,y:950,t:1527189488599};\\\", \\\"{x:1271,y:958,t:1527189488616};\\\", \\\"{x:1271,y:962,t:1527189488632};\\\", \\\"{x:1271,y:963,t:1527189488650};\\\", \\\"{x:1271,y:964,t:1527189488698};\\\", \\\"{x:1271,y:965,t:1527189488716};\\\", \\\"{x:1270,y:965,t:1527189488732};\\\", \\\"{x:1266,y:965,t:1527189488748};\\\", \\\"{x:1258,y:966,t:1527189488765};\\\", \\\"{x:1248,y:966,t:1527189488782};\\\", \\\"{x:1239,y:966,t:1527189488799};\\\", \\\"{x:1237,y:966,t:1527189488815};\\\", \\\"{x:1236,y:966,t:1527189488843};\\\", \\\"{x:1236,y:967,t:1527189488851};\\\", \\\"{x:1235,y:967,t:1527189488867};\\\", \\\"{x:1234,y:967,t:1527189488882};\\\", \\\"{x:1232,y:967,t:1527189488899};\\\", \\\"{x:1229,y:967,t:1527189488916};\\\", \\\"{x:1227,y:969,t:1527189488933};\\\", \\\"{x:1224,y:970,t:1527189488949};\\\", \\\"{x:1220,y:972,t:1527189488966};\\\", \\\"{x:1218,y:973,t:1527189488983};\\\", \\\"{x:1217,y:974,t:1527189489000};\\\", \\\"{x:1213,y:975,t:1527189489015};\\\", \\\"{x:1211,y:977,t:1527189489033};\\\", \\\"{x:1207,y:982,t:1527189489050};\\\", \\\"{x:1204,y:986,t:1527189489067};\\\", \\\"{x:1202,y:988,t:1527189489083};\\\", \\\"{x:1202,y:989,t:1527189489115};\\\", \\\"{x:1202,y:978,t:1527189494700};\\\", \\\"{x:1195,y:969,t:1527189494707};\\\", \\\"{x:1190,y:961,t:1527189494722};\\\", \\\"{x:1178,y:949,t:1527189494737};\\\", \\\"{x:1168,y:944,t:1527189494754};\\\", \\\"{x:1162,y:944,t:1527189494771};\\\", \\\"{x:1159,y:944,t:1527189494787};\\\", \\\"{x:1156,y:944,t:1527189494805};\\\", \\\"{x:1153,y:944,t:1527189494821};\\\", \\\"{x:1148,y:944,t:1527189494837};\\\", \\\"{x:1140,y:944,t:1527189494854};\\\", \\\"{x:1126,y:944,t:1527189494871};\\\", \\\"{x:1105,y:940,t:1527189494887};\\\", \\\"{x:1087,y:936,t:1527189494905};\\\", \\\"{x:1080,y:934,t:1527189494921};\\\", \\\"{x:1079,y:934,t:1527189494938};\\\", \\\"{x:1078,y:933,t:1527189495012};\\\", \\\"{x:1078,y:930,t:1527189495022};\\\", \\\"{x:1077,y:925,t:1527189495037};\\\", \\\"{x:1075,y:923,t:1527189495054};\\\", \\\"{x:1068,y:920,t:1527189495071};\\\", \\\"{x:1045,y:915,t:1527189495088};\\\", \\\"{x:989,y:908,t:1527189495104};\\\", \\\"{x:896,y:884,t:1527189495121};\\\", \\\"{x:826,y:853,t:1527189495138};\\\", \\\"{x:743,y:831,t:1527189495154};\\\", \\\"{x:575,y:790,t:1527189495171};\\\", \\\"{x:470,y:762,t:1527189495188};\\\", \\\"{x:414,y:750,t:1527189495204};\\\", \\\"{x:396,y:754,t:1527189495221};\\\", \\\"{x:398,y:761,t:1527189495238};\\\", \\\"{x:451,y:793,t:1527189495254};\\\", \\\"{x:455,y:796,t:1527189495271};\\\", \\\"{x:456,y:796,t:1527189495484};\\\", \\\"{x:457,y:796,t:1527189495563};\\\", \\\"{x:458,y:795,t:1527189495587};\\\", \\\"{x:461,y:788,t:1527189495606};\\\", \\\"{x:462,y:785,t:1527189495622};\\\", \\\"{x:464,y:782,t:1527189495638};\\\", \\\"{x:465,y:780,t:1527189495655};\\\", \\\"{x:465,y:779,t:1527189495671};\\\", \\\"{x:466,y:778,t:1527189495688};\\\", \\\"{x:466,y:776,t:1527189495705};\\\", \\\"{x:467,y:772,t:1527189495721};\\\", \\\"{x:468,y:769,t:1527189495738};\\\", \\\"{x:469,y:763,t:1527189495755};\\\", \\\"{x:471,y:759,t:1527189495771};\\\", \\\"{x:471,y:754,t:1527189495789};\\\", \\\"{x:473,y:750,t:1527189495805};\\\", \\\"{x:473,y:747,t:1527189495821};\\\", \\\"{x:473,y:746,t:1527189495838};\\\", \\\"{x:474,y:743,t:1527189495855};\\\", \\\"{x:474,y:742,t:1527189495874};\\\", \\\"{x:474,y:741,t:1527189495888};\\\", \\\"{x:475,y:740,t:1527189495905};\\\", \\\"{x:475,y:736,t:1527189495921};\\\", \\\"{x:477,y:731,t:1527189495938};\\\" ] }, { \\\"rt\\\": 28156, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 909350, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:476,y:735,t:1527189500099};\\\", \\\"{x:476,y:743,t:1527189500107};\\\", \\\"{x:475,y:743,t:1527189500118};\\\", \\\"{x:474,y:743,t:1527189500420};\\\", \\\"{x:474,y:742,t:1527189500476};\\\", \\\"{x:475,y:741,t:1527189500484};\\\", \\\"{x:477,y:739,t:1527189500501};\\\", \\\"{x:485,y:735,t:1527189500517};\\\", \\\"{x:504,y:728,t:1527189500534};\\\", \\\"{x:534,y:719,t:1527189500552};\\\", \\\"{x:584,y:713,t:1527189500567};\\\", \\\"{x:648,y:705,t:1527189500583};\\\", \\\"{x:693,y:703,t:1527189500591};\\\", \\\"{x:779,y:703,t:1527189500609};\\\", \\\"{x:879,y:703,t:1527189500625};\\\", \\\"{x:994,y:710,t:1527189500642};\\\", \\\"{x:1144,y:754,t:1527189500658};\\\", \\\"{x:1216,y:773,t:1527189500675};\\\", \\\"{x:1247,y:782,t:1527189500692};\\\", \\\"{x:1269,y:790,t:1527189500709};\\\", \\\"{x:1278,y:796,t:1527189500726};\\\", \\\"{x:1281,y:799,t:1527189500742};\\\", \\\"{x:1282,y:801,t:1527189500759};\\\", \\\"{x:1282,y:802,t:1527189500776};\\\", \\\"{x:1282,y:800,t:1527189500962};\\\", \\\"{x:1281,y:799,t:1527189500978};\\\", \\\"{x:1280,y:797,t:1527189500994};\\\", \\\"{x:1280,y:796,t:1527189501009};\\\", \\\"{x:1280,y:795,t:1527189501123};\\\", \\\"{x:1280,y:794,t:1527189501139};\\\", \\\"{x:1280,y:793,t:1527189501163};\\\", \\\"{x:1280,y:792,t:1527189501187};\\\", \\\"{x:1280,y:791,t:1527189501202};\\\", \\\"{x:1280,y:790,t:1527189501218};\\\", \\\"{x:1279,y:789,t:1527189501227};\\\", \\\"{x:1278,y:788,t:1527189501267};\\\", \\\"{x:1278,y:789,t:1527189502811};\\\", \\\"{x:1283,y:803,t:1527189502829};\\\", \\\"{x:1293,y:821,t:1527189502845};\\\", \\\"{x:1309,y:844,t:1527189502861};\\\", \\\"{x:1328,y:870,t:1527189502879};\\\", \\\"{x:1353,y:896,t:1527189502896};\\\", \\\"{x:1375,y:915,t:1527189502912};\\\", \\\"{x:1390,y:925,t:1527189502929};\\\", \\\"{x:1399,y:929,t:1527189502946};\\\", \\\"{x:1403,y:930,t:1527189502962};\\\", \\\"{x:1404,y:930,t:1527189503418};\\\", \\\"{x:1405,y:930,t:1527189503429};\\\", \\\"{x:1409,y:931,t:1527189503445};\\\", \\\"{x:1411,y:932,t:1527189503462};\\\", \\\"{x:1414,y:932,t:1527189503479};\\\", \\\"{x:1415,y:933,t:1527189503495};\\\", \\\"{x:1416,y:933,t:1527189503612};\\\", \\\"{x:1420,y:934,t:1527189503630};\\\", \\\"{x:1425,y:934,t:1527189503646};\\\", \\\"{x:1430,y:934,t:1527189503663};\\\", \\\"{x:1435,y:934,t:1527189503680};\\\", \\\"{x:1441,y:934,t:1527189503696};\\\", \\\"{x:1447,y:934,t:1527189503712};\\\", \\\"{x:1450,y:934,t:1527189503729};\\\", \\\"{x:1451,y:934,t:1527189506396};\\\", \\\"{x:1461,y:928,t:1527189506403};\\\", \\\"{x:1476,y:911,t:1527189506416};\\\", \\\"{x:1504,y:883,t:1527189506433};\\\", \\\"{x:1529,y:863,t:1527189506450};\\\", \\\"{x:1559,y:837,t:1527189506467};\\\", \\\"{x:1574,y:820,t:1527189506483};\\\", \\\"{x:1588,y:802,t:1527189506500};\\\", \\\"{x:1601,y:787,t:1527189506517};\\\", \\\"{x:1611,y:773,t:1527189506533};\\\", \\\"{x:1623,y:759,t:1527189506550};\\\", \\\"{x:1633,y:744,t:1527189506567};\\\", \\\"{x:1644,y:731,t:1527189506582};\\\", \\\"{x:1652,y:720,t:1527189506600};\\\", \\\"{x:1655,y:713,t:1527189506617};\\\", \\\"{x:1657,y:707,t:1527189506633};\\\", \\\"{x:1657,y:703,t:1527189506650};\\\", \\\"{x:1658,y:698,t:1527189506667};\\\", \\\"{x:1658,y:696,t:1527189506683};\\\", \\\"{x:1658,y:694,t:1527189506700};\\\", \\\"{x:1658,y:692,t:1527189506717};\\\", \\\"{x:1658,y:691,t:1527189506734};\\\", \\\"{x:1657,y:689,t:1527189506763};\\\", \\\"{x:1655,y:689,t:1527189506771};\\\", \\\"{x:1650,y:688,t:1527189506784};\\\", \\\"{x:1644,y:688,t:1527189506800};\\\", \\\"{x:1634,y:688,t:1527189506817};\\\", \\\"{x:1622,y:688,t:1527189506834};\\\", \\\"{x:1612,y:688,t:1527189506850};\\\", \\\"{x:1599,y:692,t:1527189506868};\\\", \\\"{x:1598,y:693,t:1527189506884};\\\", \\\"{x:1600,y:692,t:1527189507092};\\\", \\\"{x:1602,y:692,t:1527189507107};\\\", \\\"{x:1604,y:690,t:1527189507117};\\\", \\\"{x:1607,y:689,t:1527189507133};\\\", \\\"{x:1608,y:688,t:1527189507151};\\\", \\\"{x:1610,y:688,t:1527189507167};\\\", \\\"{x:1611,y:688,t:1527189507867};\\\", \\\"{x:1609,y:692,t:1527189507886};\\\", \\\"{x:1607,y:703,t:1527189507902};\\\", \\\"{x:1604,y:709,t:1527189507918};\\\", \\\"{x:1603,y:714,t:1527189507935};\\\", \\\"{x:1602,y:717,t:1527189507952};\\\", \\\"{x:1602,y:720,t:1527189507968};\\\", \\\"{x:1601,y:721,t:1527189507985};\\\", \\\"{x:1600,y:724,t:1527189508002};\\\", \\\"{x:1599,y:728,t:1527189508018};\\\", \\\"{x:1597,y:736,t:1527189508035};\\\", \\\"{x:1595,y:742,t:1527189508051};\\\", \\\"{x:1592,y:748,t:1527189508067};\\\", \\\"{x:1591,y:750,t:1527189508085};\\\", \\\"{x:1590,y:753,t:1527189508102};\\\", \\\"{x:1589,y:756,t:1527189508118};\\\", \\\"{x:1588,y:758,t:1527189508135};\\\", \\\"{x:1585,y:764,t:1527189508151};\\\", \\\"{x:1582,y:769,t:1527189508169};\\\", \\\"{x:1577,y:776,t:1527189508185};\\\", \\\"{x:1574,y:781,t:1527189508202};\\\", \\\"{x:1571,y:787,t:1527189508220};\\\", \\\"{x:1570,y:789,t:1527189508235};\\\", \\\"{x:1567,y:793,t:1527189508251};\\\", \\\"{x:1565,y:796,t:1527189508269};\\\", \\\"{x:1562,y:798,t:1527189508285};\\\", \\\"{x:1559,y:800,t:1527189508302};\\\", \\\"{x:1556,y:803,t:1527189508319};\\\", \\\"{x:1554,y:804,t:1527189508335};\\\", \\\"{x:1552,y:806,t:1527189508352};\\\", \\\"{x:1548,y:809,t:1527189508369};\\\", \\\"{x:1547,y:810,t:1527189508385};\\\", \\\"{x:1545,y:812,t:1527189508402};\\\", \\\"{x:1542,y:814,t:1527189508419};\\\", \\\"{x:1539,y:817,t:1527189508435};\\\", \\\"{x:1535,y:819,t:1527189508452};\\\", \\\"{x:1534,y:820,t:1527189508469};\\\", \\\"{x:1531,y:823,t:1527189508486};\\\", \\\"{x:1528,y:826,t:1527189508502};\\\", \\\"{x:1526,y:829,t:1527189508518};\\\", \\\"{x:1523,y:832,t:1527189508535};\\\", \\\"{x:1520,y:837,t:1527189508552};\\\", \\\"{x:1516,y:843,t:1527189508569};\\\", \\\"{x:1513,y:848,t:1527189508586};\\\", \\\"{x:1509,y:855,t:1527189508602};\\\", \\\"{x:1502,y:868,t:1527189508619};\\\", \\\"{x:1499,y:877,t:1527189508635};\\\", \\\"{x:1495,y:886,t:1527189508652};\\\", \\\"{x:1493,y:896,t:1527189508669};\\\", \\\"{x:1490,y:903,t:1527189508687};\\\", \\\"{x:1490,y:907,t:1527189508702};\\\", \\\"{x:1487,y:914,t:1527189508719};\\\", \\\"{x:1486,y:921,t:1527189508736};\\\", \\\"{x:1485,y:924,t:1527189508753};\\\", \\\"{x:1484,y:927,t:1527189508769};\\\", \\\"{x:1483,y:928,t:1527189508786};\\\", \\\"{x:1483,y:930,t:1527189508803};\\\", \\\"{x:1482,y:932,t:1527189508819};\\\", \\\"{x:1480,y:934,t:1527189508836};\\\", \\\"{x:1480,y:937,t:1527189508853};\\\", \\\"{x:1480,y:939,t:1527189508869};\\\", \\\"{x:1480,y:941,t:1527189508886};\\\", \\\"{x:1480,y:943,t:1527189508903};\\\", \\\"{x:1480,y:944,t:1527189508918};\\\", \\\"{x:1479,y:946,t:1527189508935};\\\", \\\"{x:1478,y:949,t:1527189508953};\\\", \\\"{x:1478,y:950,t:1527189508969};\\\", \\\"{x:1477,y:951,t:1527189508986};\\\", \\\"{x:1476,y:952,t:1527189509003};\\\", \\\"{x:1476,y:953,t:1527189509019};\\\", \\\"{x:1476,y:956,t:1527189509036};\\\", \\\"{x:1476,y:957,t:1527189512010};\\\", \\\"{x:1476,y:959,t:1527189512023};\\\", \\\"{x:1476,y:964,t:1527189512040};\\\", \\\"{x:1476,y:966,t:1527189512056};\\\", \\\"{x:1476,y:967,t:1527189512155};\\\", \\\"{x:1476,y:970,t:1527189512163};\\\", \\\"{x:1476,y:971,t:1527189512180};\\\", \\\"{x:1476,y:973,t:1527189512190};\\\", \\\"{x:1476,y:975,t:1527189512346};\\\", \\\"{x:1476,y:976,t:1527189512363};\\\", \\\"{x:1476,y:977,t:1527189512386};\\\", \\\"{x:1477,y:977,t:1527189512419};\\\", \\\"{x:1478,y:978,t:1527189512451};\\\", \\\"{x:1469,y:977,t:1527189521743};\\\", \\\"{x:1433,y:968,t:1527189521757};\\\", \\\"{x:1321,y:931,t:1527189521773};\\\", \\\"{x:1219,y:901,t:1527189521789};\\\", \\\"{x:1121,y:871,t:1527189521805};\\\", \\\"{x:1022,y:836,t:1527189521821};\\\", \\\"{x:969,y:818,t:1527189521838};\\\", \\\"{x:916,y:803,t:1527189521855};\\\", \\\"{x:857,y:787,t:1527189521871};\\\", \\\"{x:793,y:766,t:1527189521889};\\\", \\\"{x:735,y:740,t:1527189521905};\\\", \\\"{x:698,y:713,t:1527189521921};\\\", \\\"{x:677,y:694,t:1527189521938};\\\", \\\"{x:677,y:691,t:1527189521955};\\\", \\\"{x:678,y:689,t:1527189521971};\\\", \\\"{x:679,y:687,t:1527189522160};\\\", \\\"{x:681,y:683,t:1527189522172};\\\", \\\"{x:685,y:674,t:1527189522189};\\\", \\\"{x:690,y:655,t:1527189522207};\\\", \\\"{x:695,y:638,t:1527189522222};\\\", \\\"{x:701,y:621,t:1527189522240};\\\", \\\"{x:714,y:602,t:1527189522255};\\\", \\\"{x:733,y:584,t:1527189522272};\\\", \\\"{x:754,y:560,t:1527189522296};\\\", \\\"{x:759,y:541,t:1527189522314};\\\", \\\"{x:758,y:527,t:1527189522330};\\\", \\\"{x:742,y:512,t:1527189522347};\\\", \\\"{x:710,y:499,t:1527189522364};\\\", \\\"{x:670,y:491,t:1527189522380};\\\", \\\"{x:633,y:486,t:1527189522397};\\\", \\\"{x:592,y:486,t:1527189522413};\\\", \\\"{x:576,y:486,t:1527189522430};\\\", \\\"{x:569,y:486,t:1527189522447};\\\", \\\"{x:567,y:486,t:1527189522463};\\\", \\\"{x:567,y:487,t:1527189522480};\\\", \\\"{x:566,y:489,t:1527189522497};\\\", \\\"{x:565,y:493,t:1527189522514};\\\", \\\"{x:565,y:496,t:1527189522529};\\\", \\\"{x:565,y:498,t:1527189522546};\\\", \\\"{x:566,y:499,t:1527189522564};\\\", \\\"{x:567,y:499,t:1527189522580};\\\", \\\"{x:569,y:500,t:1527189522606};\\\", \\\"{x:572,y:501,t:1527189522622};\\\", \\\"{x:573,y:502,t:1527189522638};\\\", \\\"{x:577,y:502,t:1527189522647};\\\", \\\"{x:587,y:504,t:1527189522664};\\\", \\\"{x:592,y:504,t:1527189522680};\\\", \\\"{x:602,y:508,t:1527189522697};\\\", \\\"{x:610,y:509,t:1527189522714};\\\", \\\"{x:611,y:510,t:1527189522729};\\\", \\\"{x:616,y:510,t:1527189523078};\\\", \\\"{x:626,y:505,t:1527189523086};\\\", \\\"{x:645,y:501,t:1527189523097};\\\", \\\"{x:702,y:490,t:1527189523114};\\\", \\\"{x:760,y:486,t:1527189523131};\\\", \\\"{x:810,y:486,t:1527189523147};\\\", \\\"{x:835,y:483,t:1527189523164};\\\", \\\"{x:844,y:480,t:1527189523181};\\\", \\\"{x:846,y:480,t:1527189523196};\\\", \\\"{x:847,y:481,t:1527189523367};\\\", \\\"{x:849,y:492,t:1527189523384};\\\", \\\"{x:854,y:504,t:1527189523398};\\\", \\\"{x:857,y:510,t:1527189523413};\\\", \\\"{x:858,y:512,t:1527189523431};\\\", \\\"{x:859,y:513,t:1527189523448};\\\", \\\"{x:856,y:513,t:1527189523606};\\\", \\\"{x:854,y:512,t:1527189523614};\\\", \\\"{x:852,y:510,t:1527189523631};\\\", \\\"{x:848,y:507,t:1527189523648};\\\", \\\"{x:845,y:505,t:1527189523665};\\\", \\\"{x:845,y:504,t:1527189523681};\\\", \\\"{x:844,y:504,t:1527189523735};\\\", \\\"{x:843,y:504,t:1527189523748};\\\", \\\"{x:842,y:503,t:1527189523766};\\\", \\\"{x:840,y:501,t:1527189523783};\\\", \\\"{x:839,y:501,t:1527189523798};\\\", \\\"{x:838,y:501,t:1527189523855};\\\", \\\"{x:837,y:501,t:1527189524110};\\\", \\\"{x:822,y:514,t:1527189524117};\\\", \\\"{x:802,y:530,t:1527189524132};\\\", \\\"{x:742,y:575,t:1527189524148};\\\", \\\"{x:681,y:616,t:1527189524165};\\\", \\\"{x:617,y:652,t:1527189524182};\\\", \\\"{x:595,y:665,t:1527189524198};\\\", \\\"{x:580,y:675,t:1527189524215};\\\", \\\"{x:573,y:680,t:1527189524232};\\\", \\\"{x:570,y:684,t:1527189524248};\\\", \\\"{x:567,y:687,t:1527189524265};\\\", \\\"{x:563,y:690,t:1527189524282};\\\", \\\"{x:556,y:695,t:1527189524298};\\\", \\\"{x:546,y:702,t:1527189524315};\\\", \\\"{x:540,y:708,t:1527189524332};\\\", \\\"{x:538,y:709,t:1527189524348};\\\", \\\"{x:538,y:711,t:1527189524383};\\\", \\\"{x:538,y:713,t:1527189524398};\\\", \\\"{x:538,y:719,t:1527189524415};\\\", \\\"{x:540,y:729,t:1527189524433};\\\", \\\"{x:544,y:741,t:1527189524447};\\\", \\\"{x:546,y:752,t:1527189524465};\\\", \\\"{x:551,y:760,t:1527189524483};\\\", \\\"{x:553,y:765,t:1527189524499};\\\", \\\"{x:554,y:766,t:1527189524515};\\\", \\\"{x:554,y:763,t:1527189524647};\\\", \\\"{x:554,y:761,t:1527189524655};\\\", \\\"{x:552,y:756,t:1527189524665};\\\", \\\"{x:549,y:751,t:1527189524684};\\\", \\\"{x:546,y:745,t:1527189524699};\\\", \\\"{x:541,y:737,t:1527189524714};\\\", \\\"{x:536,y:731,t:1527189524732};\\\", \\\"{x:531,y:726,t:1527189524749};\\\", \\\"{x:530,y:725,t:1527189524765};\\\", \\\"{x:529,y:724,t:1527189524782};\\\", \\\"{x:528,y:724,t:1527189525023};\\\", \\\"{x:526,y:724,t:1527189525032};\\\", \\\"{x:523,y:724,t:1527189525049};\\\", \\\"{x:523,y:725,t:1527189525086};\\\" ] }, { \\\"rt\\\": 8928, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 919550, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:730,t:1527189528791};\\\", \\\"{x:558,y:743,t:1527189528804};\\\", \\\"{x:615,y:763,t:1527189528822};\\\", \\\"{x:687,y:798,t:1527189528837};\\\", \\\"{x:773,y:835,t:1527189528853};\\\", \\\"{x:866,y:875,t:1527189528868};\\\", \\\"{x:974,y:921,t:1527189528885};\\\", \\\"{x:1099,y:975,t:1527189528901};\\\", \\\"{x:1165,y:1001,t:1527189528918};\\\", \\\"{x:1217,y:1023,t:1527189528935};\\\", \\\"{x:1269,y:1042,t:1527189528952};\\\", \\\"{x:1311,y:1053,t:1527189528968};\\\", \\\"{x:1345,y:1065,t:1527189528986};\\\", \\\"{x:1374,y:1072,t:1527189529002};\\\", \\\"{x:1408,y:1083,t:1527189529019};\\\", \\\"{x:1430,y:1085,t:1527189529035};\\\", \\\"{x:1443,y:1085,t:1527189529053};\\\", \\\"{x:1447,y:1085,t:1527189529068};\\\", \\\"{x:1448,y:1084,t:1527189529086};\\\", \\\"{x:1453,y:1077,t:1527189529102};\\\", \\\"{x:1461,y:1065,t:1527189529118};\\\", \\\"{x:1468,y:1045,t:1527189529135};\\\", \\\"{x:1479,y:1030,t:1527189529152};\\\", \\\"{x:1487,y:1022,t:1527189529169};\\\", \\\"{x:1498,y:1015,t:1527189529185};\\\", \\\"{x:1514,y:1005,t:1527189529202};\\\", \\\"{x:1532,y:994,t:1527189529219};\\\", \\\"{x:1549,y:986,t:1527189529235};\\\", \\\"{x:1563,y:981,t:1527189529252};\\\", \\\"{x:1577,y:976,t:1527189529269};\\\", \\\"{x:1579,y:975,t:1527189529285};\\\", \\\"{x:1582,y:972,t:1527189529302};\\\", \\\"{x:1582,y:971,t:1527189529438};\\\", \\\"{x:1580,y:970,t:1527189529452};\\\", \\\"{x:1569,y:969,t:1527189529469};\\\", \\\"{x:1557,y:968,t:1527189529485};\\\", \\\"{x:1542,y:968,t:1527189529502};\\\", \\\"{x:1540,y:968,t:1527189529520};\\\", \\\"{x:1539,y:967,t:1527189529719};\\\", \\\"{x:1539,y:966,t:1527189529743};\\\", \\\"{x:1539,y:965,t:1527189529766};\\\", \\\"{x:1539,y:964,t:1527189529784};\\\", \\\"{x:1539,y:963,t:1527189529791};\\\", \\\"{x:1540,y:963,t:1527189530919};\\\", \\\"{x:1541,y:963,t:1527189531847};\\\", \\\"{x:1542,y:962,t:1527189531855};\\\", \\\"{x:1544,y:962,t:1527189531879};\\\", \\\"{x:1545,y:961,t:1527189531895};\\\", \\\"{x:1547,y:961,t:1527189532743};\\\", \\\"{x:1548,y:961,t:1527189532767};\\\", \\\"{x:1549,y:961,t:1527189532783};\\\", \\\"{x:1549,y:962,t:1527189532791};\\\", \\\"{x:1550,y:962,t:1527189532805};\\\", \\\"{x:1552,y:963,t:1527189532838};\\\", \\\"{x:1553,y:964,t:1527189532853};\\\", \\\"{x:1556,y:967,t:1527189532870};\\\", \\\"{x:1557,y:967,t:1527189532887};\\\", \\\"{x:1558,y:968,t:1527189532904};\\\", \\\"{x:1560,y:968,t:1527189532926};\\\", \\\"{x:1560,y:969,t:1527189533023};\\\", \\\"{x:1560,y:970,t:1527189533037};\\\", \\\"{x:1560,y:971,t:1527189533055};\\\", \\\"{x:1559,y:972,t:1527189533071};\\\", \\\"{x:1558,y:973,t:1527189533096};\\\", \\\"{x:1550,y:969,t:1527189533959};\\\", \\\"{x:1535,y:960,t:1527189533972};\\\", \\\"{x:1474,y:934,t:1527189533989};\\\", \\\"{x:1372,y:891,t:1527189534005};\\\", \\\"{x:1229,y:827,t:1527189534023};\\\", \\\"{x:974,y:716,t:1527189534039};\\\", \\\"{x:820,y:648,t:1527189534055};\\\", \\\"{x:701,y:600,t:1527189534072};\\\", \\\"{x:628,y:563,t:1527189534091};\\\", \\\"{x:587,y:537,t:1527189534106};\\\", \\\"{x:568,y:525,t:1527189534122};\\\", \\\"{x:557,y:515,t:1527189534140};\\\", \\\"{x:552,y:505,t:1527189534156};\\\", \\\"{x:550,y:501,t:1527189534173};\\\", \\\"{x:548,y:494,t:1527189534189};\\\", \\\"{x:547,y:490,t:1527189534206};\\\", \\\"{x:546,y:487,t:1527189534224};\\\", \\\"{x:545,y:485,t:1527189534240};\\\", \\\"{x:547,y:484,t:1527189534277};\\\", \\\"{x:553,y:486,t:1527189534290};\\\", \\\"{x:569,y:493,t:1527189534307};\\\", \\\"{x:583,y:502,t:1527189534323};\\\", \\\"{x:592,y:511,t:1527189534339};\\\", \\\"{x:593,y:520,t:1527189534357};\\\", \\\"{x:596,y:535,t:1527189534374};\\\", \\\"{x:595,y:546,t:1527189534389};\\\", \\\"{x:591,y:558,t:1527189534407};\\\", \\\"{x:590,y:563,t:1527189534424};\\\", \\\"{x:590,y:565,t:1527189534440};\\\", \\\"{x:590,y:567,t:1527189534456};\\\", \\\"{x:590,y:568,t:1527189534526};\\\", \\\"{x:590,y:570,t:1527189534542};\\\", \\\"{x:590,y:571,t:1527189534557};\\\", \\\"{x:592,y:574,t:1527189534573};\\\", \\\"{x:593,y:575,t:1527189534589};\\\", \\\"{x:598,y:578,t:1527189534606};\\\", \\\"{x:603,y:581,t:1527189534623};\\\", \\\"{x:604,y:582,t:1527189534639};\\\", \\\"{x:602,y:582,t:1527189535054};\\\", \\\"{x:601,y:581,t:1527189535062};\\\", \\\"{x:599,y:581,t:1527189535086};\\\", \\\"{x:598,y:582,t:1527189535094};\\\", \\\"{x:596,y:584,t:1527189535107};\\\", \\\"{x:592,y:587,t:1527189535123};\\\", \\\"{x:589,y:590,t:1527189535140};\\\", \\\"{x:589,y:592,t:1527189535158};\\\", \\\"{x:589,y:599,t:1527189535174};\\\", \\\"{x:585,y:621,t:1527189535191};\\\", \\\"{x:578,y:643,t:1527189535208};\\\", \\\"{x:569,y:669,t:1527189535223};\\\", \\\"{x:561,y:695,t:1527189535241};\\\", \\\"{x:557,y:716,t:1527189535257};\\\", \\\"{x:552,y:730,t:1527189535274};\\\", \\\"{x:551,y:736,t:1527189535290};\\\", \\\"{x:549,y:739,t:1527189535308};\\\", \\\"{x:549,y:740,t:1527189535342};\\\", \\\"{x:548,y:740,t:1527189535447};\\\", \\\"{x:547,y:740,t:1527189535479};\\\", \\\"{x:547,y:739,t:1527189536294};\\\", \\\"{x:547,y:738,t:1527189536308};\\\", \\\"{x:549,y:737,t:1527189536324};\\\", \\\"{x:549,y:734,t:1527189536341};\\\", \\\"{x:550,y:733,t:1527189536358};\\\", \\\"{x:550,y:732,t:1527189536391};\\\" ] }, { \\\"rt\\\": 210688, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 1131533, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-01 PM-11 AM-M -F -11 AM-F -C -O -Z -K -A -A \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:550,y:731,t:1527189539263};\\\", \\\"{x:549,y:714,t:1527189539277};\\\", \\\"{x:517,y:667,t:1527189539295};\\\", \\\"{x:503,y:634,t:1527189539312};\\\", \\\"{x:489,y:589,t:1527189539328};\\\", \\\"{x:469,y:520,t:1527189539360};\\\", \\\"{x:464,y:491,t:1527189539378};\\\", \\\"{x:464,y:468,t:1527189539393};\\\", \\\"{x:464,y:448,t:1527189539410};\\\", \\\"{x:474,y:431,t:1527189539427};\\\", \\\"{x:483,y:420,t:1527189539444};\\\", \\\"{x:489,y:413,t:1527189539461};\\\", \\\"{x:491,y:413,t:1527189539478};\\\", \\\"{x:490,y:413,t:1527189539598};\\\", \\\"{x:481,y:418,t:1527189539611};\\\", \\\"{x:460,y:432,t:1527189539628};\\\", \\\"{x:435,y:450,t:1527189539643};\\\", \\\"{x:418,y:462,t:1527189539661};\\\", \\\"{x:398,y:474,t:1527189539678};\\\", \\\"{x:395,y:476,t:1527189539694};\\\", \\\"{x:394,y:478,t:1527189539711};\\\", \\\"{x:394,y:479,t:1527189539727};\\\", \\\"{x:397,y:479,t:1527189539887};\\\", \\\"{x:402,y:479,t:1527189539894};\\\", \\\"{x:417,y:482,t:1527189539911};\\\", \\\"{x:431,y:483,t:1527189539928};\\\", \\\"{x:449,y:487,t:1527189539945};\\\", \\\"{x:467,y:489,t:1527189539961};\\\", \\\"{x:483,y:494,t:1527189539978};\\\", \\\"{x:492,y:495,t:1527189539996};\\\", \\\"{x:496,y:497,t:1527189540011};\\\", \\\"{x:499,y:496,t:1527189540247};\\\", \\\"{x:502,y:493,t:1527189540262};\\\", \\\"{x:505,y:489,t:1527189540278};\\\", \\\"{x:507,y:486,t:1527189540295};\\\", \\\"{x:509,y:484,t:1527189540312};\\\", \\\"{x:510,y:483,t:1527189540328};\\\", \\\"{x:512,y:481,t:1527189540346};\\\", \\\"{x:513,y:479,t:1527189540362};\\\", \\\"{x:516,y:478,t:1527189540379};\\\", \\\"{x:518,y:477,t:1527189540396};\\\", \\\"{x:522,y:475,t:1527189540412};\\\", \\\"{x:526,y:473,t:1527189540428};\\\", \\\"{x:529,y:472,t:1527189540445};\\\", \\\"{x:537,y:472,t:1527189540463};\\\", \\\"{x:539,y:471,t:1527189540478};\\\", \\\"{x:545,y:471,t:1527189540495};\\\", \\\"{x:547,y:471,t:1527189540512};\\\", \\\"{x:547,y:470,t:1527189540542};\\\", \\\"{x:548,y:470,t:1527189540967};\\\", \\\"{x:549,y:470,t:1527189540979};\\\", \\\"{x:550,y:470,t:1527189541278};\\\", \\\"{x:554,y:468,t:1527189541294};\\\", \\\"{x:565,y:466,t:1527189541312};\\\", \\\"{x:585,y:466,t:1527189541329};\\\", \\\"{x:616,y:467,t:1527189541346};\\\", \\\"{x:668,y:487,t:1527189541362};\\\", \\\"{x:752,y:516,t:1527189541380};\\\", \\\"{x:865,y:566,t:1527189541397};\\\", \\\"{x:980,y:612,t:1527189541412};\\\", \\\"{x:1082,y:674,t:1527189541430};\\\", \\\"{x:1154,y:710,t:1527189541446};\\\", \\\"{x:1154,y:711,t:1527189541816};\\\", \\\"{x:1159,y:717,t:1527189541829};\\\", \\\"{x:1253,y:765,t:1527189541847};\\\", \\\"{x:1386,y:826,t:1527189541863};\\\", \\\"{x:1517,y:870,t:1527189541878};\\\", \\\"{x:1602,y:891,t:1527189541896};\\\", \\\"{x:1654,y:897,t:1527189541913};\\\", \\\"{x:1655,y:897,t:1527189541929};\\\", \\\"{x:1655,y:896,t:1527189542007};\\\", \\\"{x:1659,y:890,t:1527189542046};\\\", \\\"{x:1659,y:883,t:1527189542063};\\\", \\\"{x:1659,y:877,t:1527189542079};\\\", \\\"{x:1658,y:874,t:1527189542096};\\\", \\\"{x:1653,y:872,t:1527189542113};\\\", \\\"{x:1647,y:870,t:1527189542130};\\\", \\\"{x:1635,y:870,t:1527189542146};\\\", \\\"{x:1621,y:870,t:1527189542163};\\\", \\\"{x:1609,y:882,t:1527189542179};\\\", \\\"{x:1593,y:897,t:1527189542196};\\\", \\\"{x:1580,y:903,t:1527189542214};\\\", \\\"{x:1574,y:909,t:1527189542229};\\\", \\\"{x:1562,y:917,t:1527189542246};\\\", \\\"{x:1561,y:917,t:1527189542262};\\\", \\\"{x:1560,y:917,t:1527189542335};\\\", \\\"{x:1559,y:917,t:1527189542350};\\\", \\\"{x:1556,y:917,t:1527189542364};\\\", \\\"{x:1548,y:917,t:1527189542380};\\\", \\\"{x:1544,y:917,t:1527189542396};\\\", \\\"{x:1529,y:922,t:1527189542414};\\\", \\\"{x:1521,y:927,t:1527189542431};\\\", \\\"{x:1519,y:928,t:1527189542792};\\\", \\\"{x:1519,y:931,t:1527189542799};\\\", \\\"{x:1517,y:933,t:1527189542813};\\\", \\\"{x:1508,y:939,t:1527189542830};\\\", \\\"{x:1504,y:942,t:1527189542846};\\\", \\\"{x:1504,y:943,t:1527189542878};\\\", \\\"{x:1504,y:944,t:1527189542894};\\\", \\\"{x:1504,y:945,t:1527189542902};\\\", \\\"{x:1504,y:946,t:1527189542913};\\\", \\\"{x:1504,y:948,t:1527189542929};\\\", \\\"{x:1504,y:950,t:1527189542947};\\\", \\\"{x:1504,y:953,t:1527189542963};\\\", \\\"{x:1504,y:957,t:1527189542980};\\\", \\\"{x:1504,y:962,t:1527189542997};\\\", \\\"{x:1504,y:967,t:1527189543013};\\\", \\\"{x:1504,y:972,t:1527189543031};\\\", \\\"{x:1504,y:975,t:1527189543046};\\\", \\\"{x:1504,y:976,t:1527189543063};\\\", \\\"{x:1503,y:977,t:1527189543312};\\\", \\\"{x:1501,y:977,t:1527189543319};\\\", \\\"{x:1499,y:976,t:1527189543334};\\\", \\\"{x:1497,y:975,t:1527189543347};\\\", \\\"{x:1489,y:970,t:1527189543364};\\\", \\\"{x:1479,y:963,t:1527189543382};\\\", \\\"{x:1476,y:962,t:1527189543398};\\\", \\\"{x:1473,y:960,t:1527189543415};\\\", \\\"{x:1473,y:959,t:1527189543559};\\\", \\\"{x:1474,y:959,t:1527189543624};\\\", \\\"{x:1475,y:959,t:1527189543630};\\\", \\\"{x:1476,y:959,t:1527189543648};\\\", \\\"{x:1479,y:957,t:1527189543664};\\\", \\\"{x:1480,y:956,t:1527189543680};\\\", \\\"{x:1481,y:955,t:1527189543711};\\\", \\\"{x:1480,y:955,t:1527189544319};\\\", \\\"{x:1478,y:957,t:1527189544332};\\\", \\\"{x:1477,y:959,t:1527189544347};\\\", \\\"{x:1476,y:961,t:1527189544365};\\\", \\\"{x:1475,y:961,t:1527189544382};\\\", \\\"{x:1468,y:965,t:1527189553207};\\\", \\\"{x:1461,y:968,t:1527189553221};\\\", \\\"{x:1444,y:974,t:1527189553236};\\\", \\\"{x:1429,y:981,t:1527189553254};\\\", \\\"{x:1408,y:989,t:1527189553271};\\\", \\\"{x:1401,y:994,t:1527189553287};\\\", \\\"{x:1396,y:997,t:1527189553304};\\\", \\\"{x:1389,y:1000,t:1527189553321};\\\", \\\"{x:1385,y:1002,t:1527189553337};\\\", \\\"{x:1382,y:1004,t:1527189553354};\\\", \\\"{x:1378,y:1006,t:1527189553371};\\\", \\\"{x:1373,y:1008,t:1527189553387};\\\", \\\"{x:1368,y:1010,t:1527189553403};\\\", \\\"{x:1361,y:1011,t:1527189553422};\\\", \\\"{x:1352,y:1015,t:1527189553438};\\\", \\\"{x:1342,y:1017,t:1527189553454};\\\", \\\"{x:1314,y:1021,t:1527189553470};\\\", \\\"{x:1286,y:1025,t:1527189553488};\\\", \\\"{x:1259,y:1031,t:1527189553504};\\\", \\\"{x:1236,y:1038,t:1527189553521};\\\", \\\"{x:1215,y:1042,t:1527189553538};\\\", \\\"{x:1197,y:1047,t:1527189553554};\\\", \\\"{x:1181,y:1047,t:1527189553571};\\\", \\\"{x:1165,y:1047,t:1527189553587};\\\", \\\"{x:1158,y:1047,t:1527189553604};\\\", \\\"{x:1157,y:1047,t:1527189553621};\\\", \\\"{x:1157,y:1045,t:1527189554015};\\\", \\\"{x:1155,y:1045,t:1527189554023};\\\", \\\"{x:1155,y:1044,t:1527189554038};\\\", \\\"{x:1154,y:1044,t:1527189554055};\\\", \\\"{x:1159,y:1041,t:1527189568614};\\\", \\\"{x:1218,y:1014,t:1527189568630};\\\", \\\"{x:1297,y:974,t:1527189568648};\\\", \\\"{x:1354,y:928,t:1527189568665};\\\", \\\"{x:1383,y:901,t:1527189568683};\\\", \\\"{x:1401,y:884,t:1527189568698};\\\", \\\"{x:1421,y:864,t:1527189568714};\\\", \\\"{x:1432,y:851,t:1527189568731};\\\", \\\"{x:1441,y:844,t:1527189568747};\\\", \\\"{x:1449,y:835,t:1527189568764};\\\", \\\"{x:1458,y:825,t:1527189568781};\\\", \\\"{x:1463,y:819,t:1527189568797};\\\", \\\"{x:1467,y:805,t:1527189568813};\\\", \\\"{x:1469,y:793,t:1527189568831};\\\", \\\"{x:1473,y:772,t:1527189568847};\\\", \\\"{x:1466,y:742,t:1527189568864};\\\", \\\"{x:1424,y:705,t:1527189568881};\\\", \\\"{x:1349,y:683,t:1527189568897};\\\", \\\"{x:1215,y:658,t:1527189568915};\\\", \\\"{x:1027,y:635,t:1527189568931};\\\", \\\"{x:786,y:621,t:1527189568948};\\\", \\\"{x:543,y:621,t:1527189568965};\\\", \\\"{x:362,y:608,t:1527189568981};\\\", \\\"{x:285,y:592,t:1527189568997};\\\", \\\"{x:272,y:586,t:1527189569015};\\\", \\\"{x:277,y:581,t:1527189569036};\\\", \\\"{x:301,y:577,t:1527189569051};\\\", \\\"{x:341,y:573,t:1527189569068};\\\", \\\"{x:405,y:573,t:1527189569084};\\\", \\\"{x:488,y:573,t:1527189569101};\\\", \\\"{x:597,y:573,t:1527189569117};\\\", \\\"{x:653,y:574,t:1527189569135};\\\", \\\"{x:690,y:579,t:1527189569151};\\\", \\\"{x:708,y:588,t:1527189569168};\\\", \\\"{x:721,y:596,t:1527189569185};\\\", \\\"{x:733,y:609,t:1527189569204};\\\", \\\"{x:746,y:623,t:1527189569218};\\\", \\\"{x:755,y:629,t:1527189569235};\\\", \\\"{x:759,y:633,t:1527189569251};\\\", \\\"{x:763,y:635,t:1527189569268};\\\", \\\"{x:765,y:635,t:1527189569285};\\\", \\\"{x:767,y:632,t:1527189569366};\\\", \\\"{x:773,y:626,t:1527189569373};\\\", \\\"{x:779,y:620,t:1527189569385};\\\", \\\"{x:798,y:613,t:1527189569401};\\\", \\\"{x:825,y:601,t:1527189569419};\\\", \\\"{x:854,y:591,t:1527189569435};\\\", \\\"{x:866,y:585,t:1527189569452};\\\", \\\"{x:869,y:583,t:1527189569469};\\\", \\\"{x:868,y:583,t:1527189569599};\\\", \\\"{x:866,y:583,t:1527189569606};\\\", \\\"{x:864,y:583,t:1527189569620};\\\", \\\"{x:850,y:587,t:1527189569637};\\\", \\\"{x:837,y:589,t:1527189569653};\\\", \\\"{x:822,y:592,t:1527189569671};\\\", \\\"{x:810,y:593,t:1527189569686};\\\", \\\"{x:809,y:593,t:1527189569710};\\\", \\\"{x:810,y:593,t:1527189570174};\\\", \\\"{x:813,y:593,t:1527189570184};\\\", \\\"{x:820,y:593,t:1527189570200};\\\", \\\"{x:826,y:593,t:1527189570217};\\\", \\\"{x:833,y:593,t:1527189570233};\\\", \\\"{x:836,y:592,t:1527189570252};\\\", \\\"{x:837,y:593,t:1527189570766};\\\", \\\"{x:829,y:605,t:1527189570774};\\\", \\\"{x:812,y:618,t:1527189570787};\\\", \\\"{x:775,y:645,t:1527189570803};\\\", \\\"{x:729,y:681,t:1527189570820};\\\", \\\"{x:673,y:721,t:1527189570836};\\\", \\\"{x:622,y:756,t:1527189570853};\\\", \\\"{x:594,y:782,t:1527189570869};\\\", \\\"{x:580,y:802,t:1527189570886};\\\", \\\"{x:573,y:812,t:1527189570904};\\\", \\\"{x:572,y:813,t:1527189570921};\\\", \\\"{x:581,y:780,t:1527189621866};\\\", \\\"{x:595,y:733,t:1527189621876};\\\", \\\"{x:618,y:678,t:1527189621893};\\\", \\\"{x:657,y:610,t:1527189621910};\\\", \\\"{x:706,y:528,t:1527189621929};\\\", \\\"{x:742,y:482,t:1527189621943};\\\", \\\"{x:757,y:465,t:1527189621960};\\\", \\\"{x:769,y:451,t:1527189621980};\\\", \\\"{x:775,y:444,t:1527189621997};\\\", \\\"{x:777,y:439,t:1527189622013};\\\", \\\"{x:778,y:432,t:1527189622030};\\\", \\\"{x:778,y:426,t:1527189622048};\\\", \\\"{x:778,y:414,t:1527189622063};\\\", \\\"{x:778,y:402,t:1527189622080};\\\", \\\"{x:778,y:401,t:1527189622120};\\\", \\\"{x:774,y:401,t:1527189622130};\\\", \\\"{x:766,y:411,t:1527189622148};\\\", \\\"{x:762,y:435,t:1527189622163};\\\", \\\"{x:764,y:485,t:1527189622181};\\\", \\\"{x:791,y:541,t:1527189622198};\\\", \\\"{x:824,y:608,t:1527189622214};\\\", \\\"{x:862,y:664,t:1527189622230};\\\", \\\"{x:899,y:699,t:1527189622247};\\\", \\\"{x:918,y:713,t:1527189622264};\\\", \\\"{x:926,y:716,t:1527189622280};\\\", \\\"{x:926,y:711,t:1527189622392};\\\", \\\"{x:925,y:702,t:1527189622399};\\\", \\\"{x:923,y:694,t:1527189622414};\\\", \\\"{x:920,y:683,t:1527189622430};\\\", \\\"{x:914,y:671,t:1527189622447};\\\", \\\"{x:909,y:665,t:1527189622464};\\\", \\\"{x:906,y:661,t:1527189622479};\\\", \\\"{x:903,y:657,t:1527189622496};\\\", \\\"{x:899,y:649,t:1527189622513};\\\", \\\"{x:893,y:637,t:1527189622530};\\\", \\\"{x:881,y:621,t:1527189622547};\\\", \\\"{x:867,y:607,t:1527189622564};\\\", \\\"{x:853,y:597,t:1527189622579};\\\", \\\"{x:841,y:591,t:1527189622597};\\\", \\\"{x:832,y:587,t:1527189622615};\\\", \\\"{x:829,y:584,t:1527189622632};\\\", \\\"{x:828,y:584,t:1527189622647};\\\", \\\"{x:824,y:581,t:1527189622665};\\\", \\\"{x:822,y:581,t:1527189622681};\\\", \\\"{x:822,y:580,t:1527189622697};\\\", \\\"{x:821,y:582,t:1527189623049};\\\", \\\"{x:821,y:585,t:1527189623065};\\\", \\\"{x:821,y:589,t:1527189623083};\\\", \\\"{x:821,y:592,t:1527189623100};\\\", \\\"{x:824,y:594,t:1527189623546};\\\", \\\"{x:828,y:596,t:1527189623565};\\\", \\\"{x:829,y:596,t:1527189623581};\\\", \\\"{x:829,y:597,t:1527189623599};\\\", \\\"{x:829,y:599,t:1527189623769};\\\", \\\"{x:827,y:605,t:1527189623783};\\\", \\\"{x:822,y:622,t:1527189623802};\\\", \\\"{x:820,y:624,t:1527189623815};\\\", \\\"{x:820,y:619,t:1527189623888};\\\", \\\"{x:821,y:613,t:1527189623899};\\\", \\\"{x:824,y:605,t:1527189623916};\\\", \\\"{x:825,y:601,t:1527189623933};\\\", \\\"{x:825,y:597,t:1527189623948};\\\", \\\"{x:825,y:596,t:1527189623968};\\\", \\\"{x:824,y:596,t:1527189624569};\\\", \\\"{x:816,y:611,t:1527189624584};\\\", \\\"{x:799,y:645,t:1527189624600};\\\", \\\"{x:784,y:677,t:1527189624615};\\\", \\\"{x:760,y:714,t:1527189624633};\\\", \\\"{x:751,y:726,t:1527189624650};\\\", \\\"{x:750,y:727,t:1527189624667};\\\", \\\"{x:752,y:696,t:1527189664484};\\\", \\\"{x:760,y:632,t:1527189664493};\\\", \\\"{x:766,y:586,t:1527189664505};\\\", \\\"{x:812,y:365,t:1527189664539};\\\", \\\"{x:817,y:322,t:1527189664551};\\\", \\\"{x:817,y:258,t:1527189664568};\\\", \\\"{x:806,y:211,t:1527189664585};\\\", \\\"{x:795,y:187,t:1527189664601};\\\", \\\"{x:779,y:166,t:1527189664618};\\\", \\\"{x:774,y:163,t:1527189664635};\\\", \\\"{x:771,y:163,t:1527189664651};\\\", \\\"{x:769,y:162,t:1527189664668};\\\", \\\"{x:768,y:163,t:1527189664685};\\\", \\\"{x:780,y:180,t:1527189664701};\\\", \\\"{x:817,y:224,t:1527189664718};\\\", \\\"{x:873,y:274,t:1527189664735};\\\", \\\"{x:946,y:328,t:1527189664752};\\\", \\\"{x:1029,y:385,t:1527189664768};\\\", \\\"{x:1092,y:452,t:1527189664786};\\\", \\\"{x:1201,y:603,t:1527189664803};\\\", \\\"{x:1266,y:730,t:1527189664818};\\\", \\\"{x:1312,y:843,t:1527189664836};\\\", \\\"{x:1322,y:940,t:1527189664853};\\\", \\\"{x:1322,y:1006,t:1527189664870};\\\", \\\"{x:1322,y:1048,t:1527189664886};\\\", \\\"{x:1324,y:1069,t:1527189664903};\\\", \\\"{x:1327,y:1078,t:1527189664919};\\\", \\\"{x:1327,y:1079,t:1527189664939};\\\", \\\"{x:1327,y:1082,t:1527189664952};\\\", \\\"{x:1326,y:1093,t:1527189664969};\\\", \\\"{x:1318,y:1112,t:1527189664987};\\\", \\\"{x:1314,y:1118,t:1527189665003};\\\", \\\"{x:1310,y:1120,t:1527189665019};\\\", \\\"{x:1305,y:1122,t:1527189665036};\\\", \\\"{x:1302,y:1124,t:1527189665053};\\\", \\\"{x:1302,y:1118,t:1527189665084};\\\", \\\"{x:1302,y:1103,t:1527189665091};\\\", \\\"{x:1302,y:1088,t:1527189665103};\\\", \\\"{x:1302,y:1073,t:1527189665119};\\\", \\\"{x:1303,y:1055,t:1527189665136};\\\", \\\"{x:1303,y:1039,t:1527189665154};\\\", \\\"{x:1304,y:1026,t:1527189665169};\\\", \\\"{x:1308,y:1018,t:1527189665187};\\\", \\\"{x:1310,y:1016,t:1527189665203};\\\", \\\"{x:1310,y:1015,t:1527189665219};\\\", \\\"{x:1310,y:1014,t:1527189665237};\\\", \\\"{x:1311,y:1014,t:1527189665254};\\\", \\\"{x:1311,y:1011,t:1527189665271};\\\", \\\"{x:1311,y:1006,t:1527189665287};\\\", \\\"{x:1304,y:999,t:1527189665304};\\\", \\\"{x:1292,y:985,t:1527189665320};\\\", \\\"{x:1276,y:970,t:1527189665337};\\\", \\\"{x:1266,y:965,t:1527189665355};\\\", \\\"{x:1261,y:962,t:1527189665370};\\\", \\\"{x:1260,y:961,t:1527189665435};\\\", \\\"{x:1260,y:959,t:1527189665443};\\\", \\\"{x:1260,y:956,t:1527189665453};\\\", \\\"{x:1260,y:951,t:1527189665471};\\\", \\\"{x:1262,y:941,t:1527189665488};\\\", \\\"{x:1267,y:925,t:1527189665504};\\\", \\\"{x:1277,y:904,t:1527189665521};\\\", \\\"{x:1287,y:873,t:1527189665538};\\\", \\\"{x:1296,y:837,t:1527189665554};\\\", \\\"{x:1311,y:788,t:1527189665571};\\\", \\\"{x:1315,y:766,t:1527189665588};\\\", \\\"{x:1322,y:743,t:1527189665604};\\\", \\\"{x:1331,y:725,t:1527189665621};\\\", \\\"{x:1338,y:710,t:1527189665637};\\\", \\\"{x:1345,y:696,t:1527189665655};\\\", \\\"{x:1355,y:683,t:1527189665673};\\\", \\\"{x:1365,y:670,t:1527189665688};\\\", \\\"{x:1378,y:655,t:1527189665705};\\\", \\\"{x:1382,y:649,t:1527189665722};\\\", \\\"{x:1384,y:646,t:1527189665738};\\\", \\\"{x:1390,y:641,t:1527189665755};\\\", \\\"{x:1397,y:636,t:1527189665771};\\\", \\\"{x:1408,y:629,t:1527189665788};\\\", \\\"{x:1414,y:626,t:1527189665805};\\\", \\\"{x:1418,y:624,t:1527189665821};\\\", \\\"{x:1419,y:623,t:1527189665838};\\\", \\\"{x:1420,y:623,t:1527189665854};\\\", \\\"{x:1419,y:623,t:1527189666003};\\\", \\\"{x:1419,y:624,t:1527189666019};\\\", \\\"{x:1419,y:626,t:1527189666027};\\\", \\\"{x:1419,y:627,t:1527189666039};\\\", \\\"{x:1419,y:630,t:1527189666055};\\\", \\\"{x:1420,y:631,t:1527189666072};\\\", \\\"{x:1423,y:632,t:1527189666089};\\\", \\\"{x:1426,y:633,t:1527189666105};\\\", \\\"{x:1426,y:634,t:1527189666123};\\\", \\\"{x:1428,y:634,t:1527189666138};\\\", \\\"{x:1429,y:634,t:1527189666156};\\\", \\\"{x:1431,y:636,t:1527189666173};\\\", \\\"{x:1433,y:638,t:1527189666189};\\\", \\\"{x:1434,y:638,t:1527189666205};\\\", \\\"{x:1435,y:639,t:1527189666222};\\\", \\\"{x:1436,y:640,t:1527189666259};\\\", \\\"{x:1436,y:639,t:1527189666596};\\\", \\\"{x:1437,y:638,t:1527189666607};\\\", \\\"{x:1437,y:637,t:1527189666624};\\\", \\\"{x:1439,y:635,t:1527189666641};\\\", \\\"{x:1440,y:633,t:1527189666659};\\\", \\\"{x:1441,y:632,t:1527189666795};\\\", \\\"{x:1442,y:632,t:1527189666807};\\\", \\\"{x:1443,y:632,t:1527189666843};\\\", \\\"{x:1445,y:632,t:1527189666875};\\\", \\\"{x:1446,y:634,t:1527189673044};\\\", \\\"{x:1446,y:642,t:1527189673057};\\\", \\\"{x:1448,y:663,t:1527189673073};\\\", \\\"{x:1452,y:676,t:1527189673090};\\\", \\\"{x:1455,y:683,t:1527189673106};\\\", \\\"{x:1455,y:684,t:1527189673123};\\\", \\\"{x:1456,y:686,t:1527189673275};\\\", \\\"{x:1457,y:688,t:1527189673290};\\\", \\\"{x:1459,y:691,t:1527189673306};\\\", \\\"{x:1459,y:692,t:1527189673330};\\\", \\\"{x:1459,y:693,t:1527189673340};\\\", \\\"{x:1460,y:694,t:1527189673356};\\\", \\\"{x:1461,y:694,t:1527189673374};\\\", \\\"{x:1462,y:694,t:1527189673402};\\\", \\\"{x:1462,y:695,t:1527189673411};\\\", \\\"{x:1464,y:695,t:1527189673459};\\\", \\\"{x:1465,y:695,t:1527189673523};\\\", \\\"{x:1466,y:697,t:1527189673541};\\\", \\\"{x:1467,y:697,t:1527189673562};\\\", \\\"{x:1468,y:697,t:1527189673603};\\\", \\\"{x:1470,y:697,t:1527189673651};\\\", \\\"{x:1472,y:700,t:1527189674412};\\\", \\\"{x:1475,y:708,t:1527189674426};\\\", \\\"{x:1482,y:729,t:1527189674443};\\\", \\\"{x:1488,y:742,t:1527189674460};\\\", \\\"{x:1492,y:748,t:1527189674476};\\\", \\\"{x:1494,y:752,t:1527189674494};\\\", \\\"{x:1495,y:757,t:1527189674510};\\\", \\\"{x:1496,y:758,t:1527189674525};\\\", \\\"{x:1496,y:759,t:1527189674542};\\\", \\\"{x:1497,y:761,t:1527189674559};\\\", \\\"{x:1497,y:762,t:1527189674585};\\\", \\\"{x:1498,y:763,t:1527189674593};\\\", \\\"{x:1499,y:765,t:1527189674609};\\\", \\\"{x:1502,y:771,t:1527189674625};\\\", \\\"{x:1502,y:772,t:1527189674658};\\\", \\\"{x:1502,y:773,t:1527189674762};\\\", \\\"{x:1503,y:774,t:1527189674777};\\\", \\\"{x:1504,y:775,t:1527189674794};\\\", \\\"{x:1505,y:775,t:1527189674834};\\\", \\\"{x:1506,y:775,t:1527189675131};\\\", \\\"{x:1508,y:774,t:1527189675187};\\\", \\\"{x:1509,y:772,t:1527189675195};\\\", \\\"{x:1511,y:768,t:1527189675210};\\\", \\\"{x:1512,y:767,t:1527189675228};\\\", \\\"{x:1513,y:766,t:1527189675245};\\\", \\\"{x:1513,y:767,t:1527189676139};\\\", \\\"{x:1514,y:770,t:1527189676148};\\\", \\\"{x:1516,y:776,t:1527189676164};\\\", \\\"{x:1517,y:779,t:1527189676180};\\\", \\\"{x:1518,y:782,t:1527189676197};\\\", \\\"{x:1519,y:786,t:1527189676214};\\\", \\\"{x:1519,y:788,t:1527189676231};\\\", \\\"{x:1520,y:792,t:1527189676247};\\\", \\\"{x:1521,y:794,t:1527189676264};\\\", \\\"{x:1523,y:800,t:1527189676281};\\\", \\\"{x:1525,y:805,t:1527189676297};\\\", \\\"{x:1527,y:812,t:1527189676314};\\\", \\\"{x:1530,y:817,t:1527189676331};\\\", \\\"{x:1530,y:819,t:1527189676348};\\\", \\\"{x:1531,y:820,t:1527189676379};\\\", \\\"{x:1532,y:820,t:1527189676427};\\\", \\\"{x:1533,y:820,t:1527189676476};\\\", \\\"{x:1534,y:821,t:1527189676563};\\\", \\\"{x:1535,y:821,t:1527189676588};\\\", \\\"{x:1536,y:821,t:1527189676659};\\\", \\\"{x:1537,y:822,t:1527189676683};\\\", \\\"{x:1538,y:822,t:1527189676795};\\\", \\\"{x:1540,y:823,t:1527189677387};\\\", \\\"{x:1541,y:824,t:1527189677427};\\\", \\\"{x:1541,y:825,t:1527189677434};\\\", \\\"{x:1542,y:826,t:1527189677450};\\\", \\\"{x:1543,y:832,t:1527189677467};\\\", \\\"{x:1545,y:838,t:1527189677484};\\\", \\\"{x:1546,y:844,t:1527189677500};\\\", \\\"{x:1547,y:849,t:1527189677517};\\\", \\\"{x:1547,y:853,t:1527189677534};\\\", \\\"{x:1549,y:857,t:1527189677550};\\\", \\\"{x:1550,y:860,t:1527189677567};\\\", \\\"{x:1551,y:866,t:1527189677584};\\\", \\\"{x:1553,y:871,t:1527189677601};\\\", \\\"{x:1554,y:876,t:1527189677618};\\\", \\\"{x:1558,y:883,t:1527189677635};\\\", \\\"{x:1561,y:890,t:1527189677650};\\\", \\\"{x:1561,y:891,t:1527189677667};\\\", \\\"{x:1562,y:892,t:1527189677684};\\\", \\\"{x:1562,y:893,t:1527189677707};\\\", \\\"{x:1563,y:893,t:1527189677717};\\\", \\\"{x:1564,y:895,t:1527189677734};\\\", \\\"{x:1565,y:896,t:1527189677751};\\\", \\\"{x:1566,y:897,t:1527189677767};\\\", \\\"{x:1566,y:898,t:1527189677783};\\\", \\\"{x:1567,y:898,t:1527189677801};\\\", \\\"{x:1570,y:899,t:1527189677817};\\\", \\\"{x:1571,y:900,t:1527189677834};\\\", \\\"{x:1572,y:900,t:1527189677851};\\\", \\\"{x:1573,y:901,t:1527189677868};\\\", \\\"{x:1576,y:901,t:1527189677884};\\\", \\\"{x:1578,y:901,t:1527189677906};\\\", \\\"{x:1581,y:904,t:1527189677918};\\\", \\\"{x:1587,y:904,t:1527189677935};\\\", \\\"{x:1595,y:904,t:1527189677951};\\\", \\\"{x:1598,y:905,t:1527189677968};\\\", \\\"{x:1599,y:905,t:1527189677986};\\\", \\\"{x:1599,y:904,t:1527189678163};\\\", \\\"{x:1599,y:903,t:1527189678171};\\\", \\\"{x:1597,y:902,t:1527189678187};\\\", \\\"{x:1595,y:901,t:1527189678202};\\\", \\\"{x:1590,y:900,t:1527189678219};\\\", \\\"{x:1588,y:900,t:1527189678235};\\\", \\\"{x:1587,y:900,t:1527189678315};\\\", \\\"{x:1586,y:899,t:1527189678371};\\\", \\\"{x:1586,y:898,t:1527189678387};\\\", \\\"{x:1586,y:897,t:1527189678403};\\\", \\\"{x:1584,y:895,t:1527189678419};\\\", \\\"{x:1582,y:892,t:1527189678437};\\\", \\\"{x:1582,y:891,t:1527189678454};\\\", \\\"{x:1582,y:890,t:1527189678470};\\\", \\\"{x:1582,y:892,t:1527189678859};\\\", \\\"{x:1581,y:895,t:1527189678871};\\\", \\\"{x:1581,y:901,t:1527189678888};\\\", \\\"{x:1581,y:906,t:1527189678904};\\\", \\\"{x:1582,y:910,t:1527189678921};\\\", \\\"{x:1582,y:913,t:1527189678938};\\\", \\\"{x:1583,y:917,t:1527189678954};\\\", \\\"{x:1583,y:920,t:1527189678971};\\\", \\\"{x:1584,y:928,t:1527189678987};\\\", \\\"{x:1584,y:931,t:1527189679005};\\\", \\\"{x:1587,y:935,t:1527189679022};\\\", \\\"{x:1587,y:938,t:1527189679037};\\\", \\\"{x:1587,y:940,t:1527189679055};\\\", \\\"{x:1589,y:942,t:1527189679072};\\\", \\\"{x:1590,y:945,t:1527189679088};\\\", \\\"{x:1591,y:947,t:1527189679104};\\\", \\\"{x:1592,y:948,t:1527189679121};\\\", \\\"{x:1592,y:949,t:1527189679139};\\\", \\\"{x:1593,y:950,t:1527189679155};\\\", \\\"{x:1595,y:951,t:1527189679171};\\\", \\\"{x:1595,y:952,t:1527189679189};\\\", \\\"{x:1596,y:953,t:1527189679204};\\\", \\\"{x:1597,y:953,t:1527189679222};\\\", \\\"{x:1598,y:954,t:1527189679243};\\\", \\\"{x:1599,y:954,t:1527189679254};\\\", \\\"{x:1601,y:956,t:1527189679271};\\\", \\\"{x:1603,y:957,t:1527189679289};\\\", \\\"{x:1605,y:958,t:1527189679306};\\\", \\\"{x:1606,y:959,t:1527189679321};\\\", \\\"{x:1606,y:960,t:1527189679691};\\\", \\\"{x:1608,y:961,t:1527189679707};\\\", \\\"{x:1607,y:961,t:1527189680804};\\\", \\\"{x:1607,y:960,t:1527189684548};\\\", \\\"{x:1604,y:953,t:1527189684555};\\\", \\\"{x:1599,y:946,t:1527189684567};\\\", \\\"{x:1588,y:932,t:1527189684584};\\\", \\\"{x:1577,y:918,t:1527189684602};\\\", \\\"{x:1558,y:904,t:1527189684619};\\\", \\\"{x:1551,y:899,t:1527189684635};\\\", \\\"{x:1546,y:894,t:1527189684651};\\\", \\\"{x:1543,y:887,t:1527189684668};\\\", \\\"{x:1541,y:880,t:1527189684685};\\\", \\\"{x:1538,y:875,t:1527189684701};\\\", \\\"{x:1536,y:872,t:1527189684718};\\\", \\\"{x:1536,y:869,t:1527189684734};\\\", \\\"{x:1535,y:867,t:1527189684752};\\\", \\\"{x:1533,y:862,t:1527189684769};\\\", \\\"{x:1533,y:860,t:1527189684786};\\\", \\\"{x:1532,y:855,t:1527189684803};\\\", \\\"{x:1532,y:853,t:1527189684819};\\\", \\\"{x:1532,y:850,t:1527189684835};\\\", \\\"{x:1531,y:844,t:1527189684852};\\\", \\\"{x:1528,y:835,t:1527189684869};\\\", \\\"{x:1527,y:826,t:1527189684886};\\\", \\\"{x:1525,y:820,t:1527189684903};\\\", \\\"{x:1524,y:816,t:1527189684918};\\\", \\\"{x:1524,y:810,t:1527189684936};\\\", \\\"{x:1524,y:809,t:1527189684953};\\\", \\\"{x:1524,y:807,t:1527189684969};\\\", \\\"{x:1524,y:804,t:1527189684986};\\\", \\\"{x:1521,y:799,t:1527189685003};\\\", \\\"{x:1521,y:797,t:1527189685267};\\\", \\\"{x:1522,y:796,t:1527189685315};\\\", \\\"{x:1524,y:795,t:1527189685339};\\\", \\\"{x:1526,y:793,t:1527189685371};\\\", \\\"{x:1527,y:792,t:1527189685403};\\\", \\\"{x:1528,y:792,t:1527189685420};\\\", \\\"{x:1527,y:793,t:1527189685660};\\\", \\\"{x:1526,y:796,t:1527189685670};\\\", \\\"{x:1523,y:802,t:1527189685687};\\\", \\\"{x:1520,y:808,t:1527189685704};\\\", \\\"{x:1517,y:814,t:1527189685721};\\\", \\\"{x:1514,y:818,t:1527189685738};\\\", \\\"{x:1511,y:824,t:1527189685755};\\\", \\\"{x:1507,y:830,t:1527189685771};\\\", \\\"{x:1505,y:836,t:1527189685788};\\\", \\\"{x:1501,y:844,t:1527189685804};\\\", \\\"{x:1497,y:851,t:1527189685820};\\\", \\\"{x:1494,y:859,t:1527189685837};\\\", \\\"{x:1490,y:864,t:1527189685854};\\\", \\\"{x:1489,y:868,t:1527189685871};\\\", \\\"{x:1486,y:874,t:1527189685887};\\\", \\\"{x:1483,y:879,t:1527189685905};\\\", \\\"{x:1481,y:883,t:1527189685921};\\\", \\\"{x:1479,y:885,t:1527189685937};\\\", \\\"{x:1477,y:889,t:1527189685954};\\\", \\\"{x:1475,y:892,t:1527189685972};\\\", \\\"{x:1474,y:893,t:1527189685988};\\\", \\\"{x:1474,y:895,t:1527189686004};\\\", \\\"{x:1472,y:897,t:1527189686022};\\\", \\\"{x:1472,y:898,t:1527189686039};\\\", \\\"{x:1472,y:899,t:1527189686055};\\\", \\\"{x:1471,y:900,t:1527189686072};\\\", \\\"{x:1471,y:901,t:1527189686088};\\\", \\\"{x:1470,y:903,t:1527189686105};\\\", \\\"{x:1469,y:904,t:1527189686121};\\\", \\\"{x:1466,y:907,t:1527189686138};\\\", \\\"{x:1464,y:910,t:1527189686155};\\\", \\\"{x:1461,y:913,t:1527189686172};\\\", \\\"{x:1458,y:919,t:1527189686188};\\\", \\\"{x:1457,y:921,t:1527189686205};\\\", \\\"{x:1455,y:924,t:1527189686221};\\\", \\\"{x:1452,y:927,t:1527189686238};\\\", \\\"{x:1450,y:930,t:1527189686255};\\\", \\\"{x:1448,y:932,t:1527189686273};\\\", \\\"{x:1447,y:934,t:1527189686289};\\\", \\\"{x:1446,y:935,t:1527189686305};\\\", \\\"{x:1444,y:937,t:1527189686323};\\\", \\\"{x:1442,y:938,t:1527189686347};\\\", \\\"{x:1442,y:940,t:1527189686363};\\\", \\\"{x:1441,y:941,t:1527189686387};\\\", \\\"{x:1441,y:942,t:1527189686395};\\\", \\\"{x:1440,y:944,t:1527189686411};\\\", \\\"{x:1439,y:944,t:1527189686423};\\\", \\\"{x:1439,y:946,t:1527189686440};\\\", \\\"{x:1439,y:949,t:1527189686456};\\\", \\\"{x:1438,y:951,t:1527189686473};\\\", \\\"{x:1437,y:953,t:1527189686490};\\\", \\\"{x:1437,y:954,t:1527189686507};\\\", \\\"{x:1437,y:955,t:1527189686523};\\\", \\\"{x:1437,y:958,t:1527189686540};\\\", \\\"{x:1437,y:959,t:1527189686557};\\\", \\\"{x:1437,y:960,t:1527189686619};\\\", \\\"{x:1439,y:961,t:1527189686635};\\\", \\\"{x:1439,y:962,t:1527189686659};\\\", \\\"{x:1441,y:962,t:1527189686826};\\\", \\\"{x:1442,y:962,t:1527189686906};\\\", \\\"{x:1442,y:963,t:1527189686938};\\\", \\\"{x:1443,y:962,t:1527189687380};\\\", \\\"{x:1445,y:959,t:1527189687391};\\\", \\\"{x:1446,y:956,t:1527189687409};\\\", \\\"{x:1448,y:952,t:1527189687425};\\\", \\\"{x:1451,y:950,t:1527189687442};\\\", \\\"{x:1455,y:948,t:1527189687459};\\\", \\\"{x:1456,y:946,t:1527189687474};\\\", \\\"{x:1462,y:942,t:1527189687492};\\\", \\\"{x:1468,y:939,t:1527189687509};\\\", \\\"{x:1471,y:938,t:1527189687526};\\\", \\\"{x:1473,y:936,t:1527189687542};\\\", \\\"{x:1475,y:935,t:1527189687559};\\\", \\\"{x:1477,y:934,t:1527189687576};\\\", \\\"{x:1479,y:933,t:1527189687592};\\\", \\\"{x:1479,y:932,t:1527189687609};\\\", \\\"{x:1479,y:933,t:1527189687915};\\\", \\\"{x:1479,y:934,t:1527189687931};\\\", \\\"{x:1479,y:936,t:1527189687942};\\\", \\\"{x:1478,y:938,t:1527189687960};\\\", \\\"{x:1476,y:942,t:1527189687977};\\\", \\\"{x:1474,y:948,t:1527189687993};\\\", \\\"{x:1473,y:951,t:1527189688011};\\\", \\\"{x:1472,y:954,t:1527189688027};\\\", \\\"{x:1471,y:956,t:1527189688043};\\\", \\\"{x:1471,y:957,t:1527189688060};\\\", \\\"{x:1472,y:957,t:1527189688219};\\\", \\\"{x:1473,y:955,t:1527189688227};\\\", \\\"{x:1475,y:952,t:1527189688244};\\\", \\\"{x:1478,y:949,t:1527189688261};\\\", \\\"{x:1480,y:944,t:1527189688277};\\\", \\\"{x:1484,y:938,t:1527189688294};\\\", \\\"{x:1487,y:934,t:1527189688311};\\\", \\\"{x:1490,y:930,t:1527189688328};\\\", \\\"{x:1492,y:927,t:1527189688344};\\\", \\\"{x:1494,y:922,t:1527189688361};\\\", \\\"{x:1498,y:915,t:1527189688378};\\\", \\\"{x:1501,y:911,t:1527189688394};\\\", \\\"{x:1507,y:899,t:1527189688411};\\\", \\\"{x:1510,y:894,t:1527189688427};\\\", \\\"{x:1514,y:886,t:1527189688444};\\\", \\\"{x:1515,y:885,t:1527189688461};\\\", \\\"{x:1517,y:880,t:1527189688478};\\\", \\\"{x:1517,y:878,t:1527189688495};\\\", \\\"{x:1519,y:872,t:1527189688511};\\\", \\\"{x:1522,y:868,t:1527189688528};\\\", \\\"{x:1524,y:865,t:1527189688545};\\\", \\\"{x:1527,y:859,t:1527189688561};\\\", \\\"{x:1530,y:854,t:1527189688578};\\\", \\\"{x:1532,y:848,t:1527189688595};\\\", \\\"{x:1534,y:846,t:1527189688611};\\\", \\\"{x:1535,y:843,t:1527189688628};\\\", \\\"{x:1537,y:840,t:1527189688645};\\\", \\\"{x:1541,y:835,t:1527189688662};\\\", \\\"{x:1543,y:829,t:1527189688678};\\\", \\\"{x:1547,y:823,t:1527189688695};\\\", \\\"{x:1554,y:814,t:1527189688712};\\\", \\\"{x:1559,y:807,t:1527189688728};\\\", \\\"{x:1565,y:801,t:1527189688746};\\\", \\\"{x:1569,y:794,t:1527189688762};\\\", \\\"{x:1580,y:781,t:1527189688779};\\\", \\\"{x:1583,y:777,t:1527189688795};\\\", \\\"{x:1585,y:774,t:1527189688812};\\\", \\\"{x:1593,y:766,t:1527189688829};\\\", \\\"{x:1597,y:760,t:1527189688845};\\\", \\\"{x:1598,y:757,t:1527189688862};\\\", \\\"{x:1601,y:752,t:1527189688878};\\\", \\\"{x:1604,y:746,t:1527189688896};\\\", \\\"{x:1608,y:740,t:1527189688912};\\\", \\\"{x:1612,y:735,t:1527189688929};\\\", \\\"{x:1614,y:731,t:1527189688946};\\\", \\\"{x:1617,y:724,t:1527189688962};\\\", \\\"{x:1622,y:710,t:1527189688978};\\\", \\\"{x:1624,y:705,t:1527189688996};\\\", \\\"{x:1626,y:700,t:1527189689013};\\\", \\\"{x:1626,y:695,t:1527189689029};\\\", \\\"{x:1626,y:692,t:1527189689046};\\\", \\\"{x:1626,y:689,t:1527189689063};\\\", \\\"{x:1626,y:686,t:1527189689079};\\\", \\\"{x:1626,y:685,t:1527189689096};\\\", \\\"{x:1626,y:683,t:1527189689113};\\\", \\\"{x:1626,y:682,t:1527189689129};\\\", \\\"{x:1626,y:681,t:1527189689204};\\\", \\\"{x:1625,y:681,t:1527189689235};\\\", \\\"{x:1622,y:681,t:1527189689246};\\\", \\\"{x:1618,y:681,t:1527189689263};\\\", \\\"{x:1614,y:684,t:1527189689280};\\\", \\\"{x:1611,y:687,t:1527189689296};\\\", \\\"{x:1608,y:692,t:1527189689314};\\\", \\\"{x:1606,y:696,t:1527189689330};\\\", \\\"{x:1605,y:698,t:1527189689347};\\\", \\\"{x:1605,y:699,t:1527189689371};\\\", \\\"{x:1603,y:701,t:1527189689387};\\\", \\\"{x:1603,y:702,t:1527189689516};\\\", \\\"{x:1603,y:703,t:1527189689715};\\\", \\\"{x:1604,y:703,t:1527189689731};\\\", \\\"{x:1605,y:702,t:1527189689748};\\\", \\\"{x:1606,y:702,t:1527189689764};\\\", \\\"{x:1607,y:701,t:1527189689781};\\\", \\\"{x:1607,y:700,t:1527189689798};\\\", \\\"{x:1608,y:700,t:1527189689814};\\\", \\\"{x:1608,y:704,t:1527189690427};\\\", \\\"{x:1602,y:717,t:1527189690435};\\\", \\\"{x:1598,y:730,t:1527189690449};\\\", \\\"{x:1590,y:746,t:1527189690466};\\\", \\\"{x:1586,y:757,t:1527189690483};\\\", \\\"{x:1584,y:762,t:1527189690499};\\\", \\\"{x:1582,y:769,t:1527189690516};\\\", \\\"{x:1579,y:780,t:1527189690533};\\\", \\\"{x:1574,y:793,t:1527189690550};\\\", \\\"{x:1571,y:806,t:1527189690566};\\\", \\\"{x:1569,y:813,t:1527189690583};\\\", \\\"{x:1568,y:820,t:1527189690602};\\\", \\\"{x:1565,y:826,t:1527189690616};\\\", \\\"{x:1564,y:831,t:1527189690633};\\\", \\\"{x:1562,y:837,t:1527189690650};\\\", \\\"{x:1558,y:845,t:1527189690667};\\\", \\\"{x:1556,y:850,t:1527189690683};\\\", \\\"{x:1551,y:858,t:1527189690700};\\\", \\\"{x:1546,y:867,t:1527189690717};\\\", \\\"{x:1542,y:874,t:1527189690733};\\\", \\\"{x:1540,y:877,t:1527189690750};\\\", \\\"{x:1539,y:879,t:1527189690767};\\\", \\\"{x:1536,y:883,t:1527189690783};\\\", \\\"{x:1534,y:885,t:1527189690801};\\\", \\\"{x:1530,y:889,t:1527189690817};\\\", \\\"{x:1527,y:893,t:1527189690834};\\\", \\\"{x:1523,y:897,t:1527189690850};\\\", \\\"{x:1519,y:899,t:1527189690867};\\\", \\\"{x:1517,y:901,t:1527189690884};\\\", \\\"{x:1513,y:904,t:1527189690900};\\\", \\\"{x:1511,y:905,t:1527189690917};\\\", \\\"{x:1509,y:907,t:1527189690934};\\\", \\\"{x:1507,y:908,t:1527189690950};\\\", \\\"{x:1507,y:909,t:1527189690967};\\\", \\\"{x:1505,y:909,t:1527189690984};\\\", \\\"{x:1504,y:911,t:1527189691002};\\\", \\\"{x:1501,y:910,t:1527189694939};\\\", \\\"{x:1495,y:908,t:1527189694946};\\\", \\\"{x:1485,y:904,t:1527189694960};\\\", \\\"{x:1471,y:901,t:1527189694977};\\\", \\\"{x:1459,y:899,t:1527189694994};\\\", \\\"{x:1453,y:896,t:1527189695010};\\\", \\\"{x:1450,y:895,t:1527189695027};\\\", \\\"{x:1450,y:893,t:1527189695179};\\\", \\\"{x:1448,y:888,t:1527189695194};\\\", \\\"{x:1448,y:876,t:1527189695211};\\\", \\\"{x:1448,y:868,t:1527189695228};\\\", \\\"{x:1448,y:858,t:1527189695245};\\\", \\\"{x:1448,y:853,t:1527189695261};\\\", \\\"{x:1448,y:850,t:1527189695279};\\\", \\\"{x:1448,y:846,t:1527189695294};\\\", \\\"{x:1448,y:844,t:1527189695311};\\\", \\\"{x:1448,y:843,t:1527189695328};\\\", \\\"{x:1448,y:841,t:1527189695346};\\\", \\\"{x:1447,y:839,t:1527189695363};\\\", \\\"{x:1446,y:838,t:1527189695419};\\\", \\\"{x:1445,y:823,t:1527189699855};\\\", \\\"{x:1445,y:779,t:1527189699863};\\\", \\\"{x:1445,y:743,t:1527189699876};\\\", \\\"{x:1445,y:676,t:1527189699893};\\\", \\\"{x:1446,y:591,t:1527189699910};\\\", \\\"{x:1453,y:549,t:1527189699926};\\\", \\\"{x:1463,y:510,t:1527189699943};\\\", \\\"{x:1473,y:479,t:1527189699961};\\\", \\\"{x:1478,y:460,t:1527189699976};\\\", \\\"{x:1481,y:442,t:1527189699993};\\\", \\\"{x:1481,y:434,t:1527189700010};\\\", \\\"{x:1481,y:423,t:1527189700027};\\\", \\\"{x:1481,y:416,t:1527189700043};\\\", \\\"{x:1477,y:408,t:1527189700060};\\\", \\\"{x:1470,y:398,t:1527189700077};\\\", \\\"{x:1465,y:391,t:1527189700094};\\\", \\\"{x:1459,y:377,t:1527189700110};\\\", \\\"{x:1454,y:366,t:1527189700126};\\\", \\\"{x:1449,y:352,t:1527189700143};\\\", \\\"{x:1445,y:339,t:1527189700161};\\\", \\\"{x:1443,y:328,t:1527189700177};\\\", \\\"{x:1441,y:316,t:1527189700195};\\\", \\\"{x:1441,y:305,t:1527189700210};\\\", \\\"{x:1441,y:297,t:1527189700228};\\\", \\\"{x:1442,y:293,t:1527189700244};\\\", \\\"{x:1444,y:289,t:1527189700260};\\\", \\\"{x:1445,y:288,t:1527189700277};\\\", \\\"{x:1447,y:286,t:1527189700295};\\\", \\\"{x:1448,y:284,t:1527189700310};\\\", \\\"{x:1452,y:281,t:1527189700327};\\\", \\\"{x:1456,y:278,t:1527189700344};\\\", \\\"{x:1457,y:277,t:1527189700361};\\\", \\\"{x:1459,y:276,t:1527189700377};\\\", \\\"{x:1460,y:275,t:1527189700407};\\\", \\\"{x:1461,y:275,t:1527189700463};\\\", \\\"{x:1462,y:275,t:1527189700478};\\\", \\\"{x:1464,y:278,t:1527189700495};\\\", \\\"{x:1465,y:281,t:1527189700511};\\\", \\\"{x:1465,y:283,t:1527189700528};\\\", \\\"{x:1466,y:286,t:1527189700545};\\\", \\\"{x:1467,y:288,t:1527189700562};\\\", \\\"{x:1467,y:289,t:1527189700578};\\\", \\\"{x:1467,y:290,t:1527189700595};\\\", \\\"{x:1467,y:292,t:1527189700611};\\\", \\\"{x:1468,y:295,t:1527189700628};\\\", \\\"{x:1468,y:296,t:1527189700645};\\\", \\\"{x:1469,y:298,t:1527189700661};\\\", \\\"{x:1471,y:298,t:1527189701023};\\\", \\\"{x:1472,y:299,t:1527189701038};\\\", \\\"{x:1472,y:300,t:1527189701046};\\\", \\\"{x:1474,y:300,t:1527189701063};\\\", \\\"{x:1477,y:301,t:1527189701079};\\\", \\\"{x:1478,y:301,t:1527189701117};\\\", \\\"{x:1479,y:314,t:1527189715896};\\\", \\\"{x:1449,y:358,t:1527189715902};\\\", \\\"{x:1415,y:403,t:1527189715916};\\\", \\\"{x:1361,y:455,t:1527189715933};\\\", \\\"{x:1329,y:479,t:1527189715950};\\\", \\\"{x:1318,y:486,t:1527189715965};\\\", \\\"{x:1315,y:495,t:1527189715982};\\\", \\\"{x:1315,y:509,t:1527189716000};\\\", \\\"{x:1315,y:524,t:1527189716016};\\\", \\\"{x:1315,y:531,t:1527189716033};\\\", \\\"{x:1315,y:537,t:1527189716050};\\\", \\\"{x:1315,y:553,t:1527189716066};\\\", \\\"{x:1315,y:579,t:1527189716082};\\\", \\\"{x:1313,y:609,t:1527189716100};\\\", \\\"{x:1313,y:640,t:1527189716117};\\\", \\\"{x:1313,y:663,t:1527189716133};\\\", \\\"{x:1317,y:687,t:1527189716149};\\\", \\\"{x:1318,y:691,t:1527189716166};\\\", \\\"{x:1318,y:696,t:1527189716182};\\\", \\\"{x:1318,y:704,t:1527189716200};\\\", \\\"{x:1318,y:722,t:1527189716216};\\\", \\\"{x:1316,y:737,t:1527189716233};\\\", \\\"{x:1312,y:750,t:1527189716249};\\\", \\\"{x:1311,y:758,t:1527189716267};\\\", \\\"{x:1308,y:765,t:1527189716284};\\\", \\\"{x:1307,y:770,t:1527189716299};\\\", \\\"{x:1306,y:780,t:1527189716317};\\\", \\\"{x:1303,y:788,t:1527189716334};\\\", \\\"{x:1297,y:798,t:1527189716351};\\\", \\\"{x:1290,y:810,t:1527189716368};\\\", \\\"{x:1280,y:826,t:1527189716384};\\\", \\\"{x:1266,y:845,t:1527189716400};\\\", \\\"{x:1249,y:869,t:1527189716417};\\\", \\\"{x:1231,y:894,t:1527189716434};\\\", \\\"{x:1201,y:930,t:1527189716450};\\\", \\\"{x:1170,y:960,t:1527189716466};\\\", \\\"{x:1146,y:990,t:1527189716483};\\\", \\\"{x:1124,y:1016,t:1527189716501};\\\", \\\"{x:1104,y:1039,t:1527189716518};\\\", \\\"{x:1087,y:1050,t:1527189716534};\\\", \\\"{x:1075,y:1056,t:1527189716551};\\\", \\\"{x:1068,y:1057,t:1527189716568};\\\", \\\"{x:1062,y:1057,t:1527189716583};\\\", \\\"{x:1061,y:1057,t:1527189716601};\\\", \\\"{x:1060,y:1057,t:1527189716618};\\\", \\\"{x:1065,y:1044,t:1527189716635};\\\", \\\"{x:1082,y:1025,t:1527189716650};\\\", \\\"{x:1102,y:1004,t:1527189716668};\\\", \\\"{x:1122,y:987,t:1527189716685};\\\", \\\"{x:1146,y:967,t:1527189716701};\\\", \\\"{x:1167,y:949,t:1527189716718};\\\", \\\"{x:1189,y:929,t:1527189716735};\\\", \\\"{x:1200,y:921,t:1527189716751};\\\", \\\"{x:1207,y:916,t:1527189716768};\\\", \\\"{x:1214,y:912,t:1527189716785};\\\", \\\"{x:1222,y:903,t:1527189716802};\\\", \\\"{x:1231,y:893,t:1527189716818};\\\", \\\"{x:1239,y:884,t:1527189716835};\\\", \\\"{x:1250,y:870,t:1527189716852};\\\", \\\"{x:1259,y:857,t:1527189716868};\\\", \\\"{x:1271,y:842,t:1527189716885};\\\", \\\"{x:1295,y:804,t:1527189716902};\\\", \\\"{x:1304,y:791,t:1527189716918};\\\", \\\"{x:1313,y:779,t:1527189716934};\\\", \\\"{x:1319,y:769,t:1527189716951};\\\", \\\"{x:1322,y:761,t:1527189716968};\\\", \\\"{x:1323,y:756,t:1527189716984};\\\", \\\"{x:1324,y:747,t:1527189717002};\\\", \\\"{x:1327,y:737,t:1527189717018};\\\", \\\"{x:1327,y:730,t:1527189717034};\\\", \\\"{x:1327,y:726,t:1527189717051};\\\", \\\"{x:1327,y:720,t:1527189717069};\\\", \\\"{x:1325,y:705,t:1527189717086};\\\", \\\"{x:1325,y:694,t:1527189717101};\\\", \\\"{x:1325,y:681,t:1527189717118};\\\", \\\"{x:1325,y:665,t:1527189717135};\\\", \\\"{x:1325,y:649,t:1527189717152};\\\", \\\"{x:1327,y:628,t:1527189717169};\\\", \\\"{x:1332,y:616,t:1527189717186};\\\", \\\"{x:1338,y:602,t:1527189717203};\\\", \\\"{x:1343,y:590,t:1527189717219};\\\", \\\"{x:1349,y:584,t:1527189717235};\\\", \\\"{x:1353,y:577,t:1527189717252};\\\", \\\"{x:1356,y:574,t:1527189717268};\\\", \\\"{x:1359,y:570,t:1527189717286};\\\", \\\"{x:1359,y:568,t:1527189717302};\\\", \\\"{x:1360,y:563,t:1527189717320};\\\", \\\"{x:1363,y:551,t:1527189717336};\\\", \\\"{x:1365,y:530,t:1527189717353};\\\", \\\"{x:1367,y:522,t:1527189717370};\\\", \\\"{x:1373,y:515,t:1527189717386};\\\", \\\"{x:1375,y:511,t:1527189717403};\\\", \\\"{x:1377,y:506,t:1527189717420};\\\", \\\"{x:1379,y:503,t:1527189717436};\\\", \\\"{x:1382,y:499,t:1527189717454};\\\", \\\"{x:1386,y:493,t:1527189717470};\\\", \\\"{x:1389,y:488,t:1527189717487};\\\", \\\"{x:1393,y:483,t:1527189717503};\\\", \\\"{x:1397,y:479,t:1527189717520};\\\", \\\"{x:1404,y:465,t:1527189717537};\\\", \\\"{x:1406,y:446,t:1527189717554};\\\", \\\"{x:1409,y:436,t:1527189717570};\\\", \\\"{x:1411,y:430,t:1527189717587};\\\", \\\"{x:1413,y:426,t:1527189717605};\\\", \\\"{x:1416,y:418,t:1527189717621};\\\", \\\"{x:1420,y:407,t:1527189717638};\\\", \\\"{x:1423,y:402,t:1527189717654};\\\", \\\"{x:1426,y:398,t:1527189717670};\\\", \\\"{x:1427,y:394,t:1527189717687};\\\", \\\"{x:1429,y:392,t:1527189717704};\\\", \\\"{x:1430,y:387,t:1527189717720};\\\", \\\"{x:1431,y:380,t:1527189717736};\\\", \\\"{x:1435,y:360,t:1527189717754};\\\", \\\"{x:1435,y:353,t:1527189717771};\\\", \\\"{x:1438,y:349,t:1527189717787};\\\", \\\"{x:1442,y:342,t:1527189717805};\\\", \\\"{x:1444,y:337,t:1527189717821};\\\", \\\"{x:1448,y:331,t:1527189717837};\\\", \\\"{x:1451,y:326,t:1527189717854};\\\", \\\"{x:1456,y:319,t:1527189717870};\\\", \\\"{x:1458,y:316,t:1527189717888};\\\", \\\"{x:1461,y:313,t:1527189717904};\\\", \\\"{x:1466,y:308,t:1527189717921};\\\", \\\"{x:1472,y:304,t:1527189717938};\\\", \\\"{x:1475,y:301,t:1527189717954};\\\", \\\"{x:1476,y:300,t:1527189717971};\\\", \\\"{x:1475,y:300,t:1527189718439};\\\", \\\"{x:1463,y:305,t:1527189718456};\\\", \\\"{x:1449,y:312,t:1527189718472};\\\", \\\"{x:1435,y:323,t:1527189718489};\\\", \\\"{x:1417,y:335,t:1527189718506};\\\", \\\"{x:1392,y:354,t:1527189718522};\\\", \\\"{x:1341,y:390,t:1527189718539};\\\", \\\"{x:1265,y:448,t:1527189718556};\\\", \\\"{x:1171,y:509,t:1527189718573};\\\", \\\"{x:1088,y:569,t:1527189718589};\\\", \\\"{x:996,y:630,t:1527189718607};\\\", \\\"{x:957,y:658,t:1527189718622};\\\", \\\"{x:920,y:682,t:1527189718639};\\\", \\\"{x:887,y:703,t:1527189718656};\\\", \\\"{x:850,y:723,t:1527189718673};\\\", \\\"{x:811,y:739,t:1527189718689};\\\", \\\"{x:770,y:755,t:1527189718706};\\\", \\\"{x:730,y:771,t:1527189718723};\\\", \\\"{x:689,y:780,t:1527189718740};\\\", \\\"{x:651,y:782,t:1527189718755};\\\", \\\"{x:606,y:782,t:1527189718773};\\\", \\\"{x:560,y:774,t:1527189718790};\\\", \\\"{x:538,y:757,t:1527189718808};\\\", \\\"{x:517,y:734,t:1527189718822};\\\", \\\"{x:483,y:700,t:1527189718839};\\\", \\\"{x:462,y:680,t:1527189718850};\\\", \\\"{x:407,y:634,t:1527189718866};\\\", \\\"{x:362,y:602,t:1527189718883};\\\", \\\"{x:337,y:583,t:1527189718899};\\\", \\\"{x:334,y:578,t:1527189718915};\\\", \\\"{x:334,y:572,t:1527189718933};\\\", \\\"{x:345,y:560,t:1527189718950};\\\", \\\"{x:355,y:553,t:1527189718965};\\\", \\\"{x:357,y:551,t:1527189718982};\\\", \\\"{x:360,y:549,t:1527189718999};\\\", \\\"{x:362,y:548,t:1527189719016};\\\", \\\"{x:364,y:547,t:1527189719032};\\\", \\\"{x:365,y:547,t:1527189719049};\\\", \\\"{x:368,y:545,t:1527189719066};\\\", \\\"{x:371,y:545,t:1527189719082};\\\", \\\"{x:380,y:545,t:1527189719100};\\\", \\\"{x:389,y:545,t:1527189719116};\\\", \\\"{x:395,y:546,t:1527189719132};\\\", \\\"{x:399,y:551,t:1527189719149};\\\", \\\"{x:401,y:557,t:1527189719165};\\\", \\\"{x:401,y:568,t:1527189719182};\\\", \\\"{x:401,y:582,t:1527189719199};\\\", \\\"{x:405,y:596,t:1527189719216};\\\", \\\"{x:419,y:608,t:1527189719233};\\\", \\\"{x:445,y:610,t:1527189719249};\\\", \\\"{x:484,y:610,t:1527189719266};\\\", \\\"{x:535,y:610,t:1527189719282};\\\", \\\"{x:592,y:597,t:1527189719300};\\\", \\\"{x:644,y:579,t:1527189719316};\\\", \\\"{x:671,y:565,t:1527189719333};\\\", \\\"{x:681,y:560,t:1527189719349};\\\", \\\"{x:680,y:559,t:1527189719366};\\\", \\\"{x:673,y:558,t:1527189719383};\\\", \\\"{x:667,y:558,t:1527189719399};\\\", \\\"{x:660,y:557,t:1527189719417};\\\", \\\"{x:652,y:557,t:1527189719432};\\\", \\\"{x:645,y:557,t:1527189719450};\\\", \\\"{x:636,y:559,t:1527189719467};\\\", \\\"{x:620,y:566,t:1527189719483};\\\", \\\"{x:599,y:576,t:1527189719500};\\\", \\\"{x:573,y:588,t:1527189719516};\\\", \\\"{x:555,y:599,t:1527189719532};\\\", \\\"{x:551,y:602,t:1527189719549};\\\", \\\"{x:551,y:603,t:1527189719598};\\\", \\\"{x:552,y:603,t:1527189719621};\\\", \\\"{x:554,y:603,t:1527189719632};\\\", \\\"{x:557,y:603,t:1527189719649};\\\", \\\"{x:563,y:603,t:1527189719666};\\\", \\\"{x:566,y:603,t:1527189719682};\\\", \\\"{x:569,y:602,t:1527189719700};\\\", \\\"{x:573,y:600,t:1527189719716};\\\", \\\"{x:577,y:599,t:1527189719733};\\\", \\\"{x:577,y:598,t:1527189719782};\\\", \\\"{x:566,y:593,t:1527189719799};\\\", \\\"{x:530,y:589,t:1527189719815};\\\", \\\"{x:455,y:589,t:1527189719834};\\\", \\\"{x:363,y:586,t:1527189719848};\\\", \\\"{x:299,y:586,t:1527189719866};\\\", \\\"{x:260,y:586,t:1527189719884};\\\", \\\"{x:245,y:586,t:1527189719899};\\\", \\\"{x:241,y:586,t:1527189719916};\\\", \\\"{x:241,y:587,t:1527189719933};\\\", \\\"{x:239,y:590,t:1527189719950};\\\", \\\"{x:238,y:593,t:1527189719967};\\\", \\\"{x:237,y:594,t:1527189719984};\\\", \\\"{x:233,y:596,t:1527189720000};\\\", \\\"{x:226,y:599,t:1527189720017};\\\", \\\"{x:222,y:602,t:1527189720033};\\\", \\\"{x:224,y:602,t:1527189720086};\\\", \\\"{x:228,y:602,t:1527189720101};\\\", \\\"{x:241,y:601,t:1527189720116};\\\", \\\"{x:263,y:597,t:1527189720134};\\\", \\\"{x:272,y:594,t:1527189720150};\\\", \\\"{x:273,y:593,t:1527189720169};\\\", \\\"{x:277,y:593,t:1527189720294};\\\", \\\"{x:282,y:593,t:1527189720301};\\\", \\\"{x:293,y:593,t:1527189720316};\\\", \\\"{x:335,y:593,t:1527189720333};\\\", \\\"{x:368,y:593,t:1527189720350};\\\", \\\"{x:388,y:593,t:1527189720367};\\\", \\\"{x:396,y:593,t:1527189720384};\\\", \\\"{x:397,y:593,t:1527189720401};\\\", \\\"{x:396,y:593,t:1527189720494};\\\", \\\"{x:395,y:594,t:1527189720502};\\\", \\\"{x:394,y:594,t:1527189720517};\\\", \\\"{x:393,y:594,t:1527189720535};\\\", \\\"{x:392,y:594,t:1527189720551};\\\", \\\"{x:392,y:597,t:1527189721326};\\\", \\\"{x:389,y:611,t:1527189721336};\\\", \\\"{x:376,y:640,t:1527189721352};\\\", \\\"{x:372,y:657,t:1527189721368};\\\", \\\"{x:369,y:673,t:1527189721384};\\\", \\\"{x:369,y:685,t:1527189721400};\\\", \\\"{x:369,y:694,t:1527189721417};\\\", \\\"{x:369,y:704,t:1527189721434};\\\", \\\"{x:373,y:722,t:1527189721450};\\\", \\\"{x:379,y:740,t:1527189721467};\\\", \\\"{x:384,y:752,t:1527189721484};\\\", \\\"{x:386,y:761,t:1527189721500};\\\", \\\"{x:390,y:773,t:1527189721517};\\\", \\\"{x:391,y:775,t:1527189721534};\\\", \\\"{x:391,y:776,t:1527189721565};\\\", \\\"{x:394,y:776,t:1527189737695};\\\", \\\"{x:408,y:772,t:1527189737702};\\\", \\\"{x:421,y:766,t:1527189737717};\\\", \\\"{x:443,y:760,t:1527189737733};\\\", \\\"{x:483,y:748,t:1527189737751};\\\", \\\"{x:508,y:742,t:1527189737767};\\\", \\\"{x:523,y:734,t:1527189737782};\\\", \\\"{x:538,y:727,t:1527189737800};\\\", \\\"{x:551,y:719,t:1527189737814};\\\", \\\"{x:570,y:707,t:1527189737831};\\\", \\\"{x:581,y:700,t:1527189737848};\\\", \\\"{x:588,y:695,t:1527189737864};\\\", \\\"{x:589,y:694,t:1527189737881};\\\", \\\"{x:590,y:694,t:1527189737898};\\\", \\\"{x:590,y:693,t:1527189737925};\\\", \\\"{x:590,y:692,t:1527189737933};\\\", \\\"{x:590,y:689,t:1527189737948};\\\", \\\"{x:591,y:684,t:1527189737964};\\\", \\\"{x:600,y:664,t:1527189737981};\\\", \\\"{x:605,y:650,t:1527189737998};\\\", \\\"{x:611,y:633,t:1527189738016};\\\", \\\"{x:617,y:620,t:1527189738031};\\\", \\\"{x:619,y:609,t:1527189738049};\\\", \\\"{x:620,y:600,t:1527189738064};\\\", \\\"{x:620,y:596,t:1527189738081};\\\", \\\"{x:620,y:593,t:1527189738099};\\\", \\\"{x:620,y:592,t:1527189738114};\\\", \\\"{x:618,y:591,t:1527189738902};\\\", \\\"{x:614,y:594,t:1527189738916};\\\", \\\"{x:602,y:610,t:1527189738934};\\\", \\\"{x:590,y:630,t:1527189738950};\\\", \\\"{x:578,y:659,t:1527189738965};\\\", \\\"{x:573,y:680,t:1527189738982};\\\", \\\"{x:568,y:698,t:1527189738999};\\\", \\\"{x:568,y:709,t:1527189739016};\\\", \\\"{x:568,y:717,t:1527189739032};\\\", \\\"{x:568,y:723,t:1527189739048};\\\", \\\"{x:568,y:727,t:1527189739065};\\\", \\\"{x:568,y:731,t:1527189739082};\\\", \\\"{x:568,y:732,t:1527189739098};\\\", \\\"{x:568,y:733,t:1527189739115};\\\", \\\"{x:568,y:734,t:1527189739132};\\\", \\\"{x:568,y:738,t:1527189747222};\\\", \\\"{x:552,y:756,t:1527189747240};\\\", \\\"{x:537,y:767,t:1527189747255};\\\", \\\"{x:525,y:773,t:1527189747271};\\\", \\\"{x:519,y:775,t:1527189747288};\\\", \\\"{x:519,y:774,t:1527189747413};\\\", \\\"{x:519,y:771,t:1527189747421};\\\", \\\"{x:519,y:768,t:1527189747438};\\\", \\\"{x:519,y:764,t:1527189747455};\\\", \\\"{x:519,y:763,t:1527189747473};\\\", \\\"{x:519,y:760,t:1527189747489};\\\", \\\"{x:519,y:758,t:1527189747506};\\\", \\\"{x:520,y:757,t:1527189747534};\\\", \\\"{x:520,y:756,t:1527189747550};\\\", \\\"{x:520,y:755,t:1527189747558};\\\", \\\"{x:520,y:754,t:1527189747573};\\\" ] }, { \\\"rt\\\": 155007, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 1288053, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Any dot that the diagonal line with positive/increasing slope beginning at 12pm passes through\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 18701, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 1307761, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 19941, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 1328719, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 9827, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 1339876, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"NVGH4\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"kilo\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"NVGH4\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2412,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":2413,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2414,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2415,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2416,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2420,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2422,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2429,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2430,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2432,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2434,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2435,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":2440,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2450,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":2455,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2460,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2461,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2463,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2464,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2465,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":2470,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2471,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2472,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2473,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2523,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2588,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2589,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2591,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2592,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2593,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2596,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2597,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2598},{\"nodeType\":3,\"id\":2599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2600,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2602,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2603,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 251, dom: 934, initialDom: 1016",
  "javascriptErrors": []
}