var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3d3cadc5190a863ccbd028ff5f5dac2a",
  "created": "2018-05-24T12:22:28.8652115-07:00",
  "lastActivity": "2018-05-24T12:25:57.8474815-07:00",
  "pageViews": [
    {
      "id": "0524286676561c3fea6bdc7cb54157ef52d2f969",
      "startTime": "2018-05-24T12:22:29.0884952-07:00",
      "endTime": "2018-05-24T12:25:57.8474815-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 209492,
      "engagementTime": 159552,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 209492,
  "engagementTime": 159552,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=NVGH4",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "21ce685fe53de5a339bd26cf494220ab",
  "gdpr": false
}