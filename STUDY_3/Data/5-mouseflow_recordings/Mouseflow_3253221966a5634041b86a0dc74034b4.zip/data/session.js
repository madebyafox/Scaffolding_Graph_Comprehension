var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3253221966a5634041b86a0dc74034b4",
  "created": "2018-05-25T09:18:15.2469434-07:00",
  "lastActivity": "2018-05-25T09:18:30.5659434-07:00",
  "pageViews": [
    {
      "id": "05251594b85bcc0c9161f4e29eef111a08e160fe",
      "startTime": "2018-05-25T09:18:15.2469434-07:00",
      "endTime": "2018-05-25T09:18:30.5659434-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 15319,
      "engagementTime": 15319,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15319,
  "engagementTime": 15319,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=EJPRM",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "47ab4a6bc8aa45e29b2fe7c526a03fca",
  "gdpr": false
}