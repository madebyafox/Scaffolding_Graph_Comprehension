var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ec79ee85a99dc52ad0a22176c3cb70ea",
  "created": "2018-05-29T10:05:55.5065437-07:00",
  "lastActivity": "2018-05-29T10:07:02.1875437-07:00",
  "pageViews": [
    {
      "id": "05295566d5c0dd6f6a33342542df146fa506e60c",
      "startTime": "2018-05-29T10:05:55.5065437-07:00",
      "endTime": "2018-05-29T10:07:02.1875437-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 66681,
      "engagementTime": 66333,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 66681,
  "engagementTime": 66333,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FUXZY",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a18f9865c8da1fef6a08dfa4bdb7c17d",
  "gdpr": false
}