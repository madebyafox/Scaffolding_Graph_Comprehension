var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c9092c2e7a484ea26a34b3ded7b4fe0e",
  "created": "2018-05-25T11:16:32.9642602-07:00",
  "lastActivity": "2018-05-25T11:18:38.5322602-07:00",
  "pageViews": [
    {
      "id": "05253356316c2a41e210b4426db873664f393177",
      "startTime": "2018-05-25T11:16:32.9642602-07:00",
      "endTime": "2018-05-25T11:18:38.5322602-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 125568,
      "engagementTime": 105882,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 125568,
  "engagementTime": 105882,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=55GO7",
    "CONDITION=114"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7ad18137cb246aa937ffbaefede0f199",
  "gdpr": false
}